

# Generated at 2022-06-22 05:09:24.911266
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from .utils import _nested_range
    from time import sleep

    mono = MonoWorker()

    def echoer(msg):
        # sleep(0.5)
        return len(msg)

    for msg in _nested_range(5, 0, '<'):
        future = mono.submit(echoer, msg)
        with future:
            x = future.result()
            print("{} of len {}".format(msg, x))


# Generated at 2022-06-22 05:09:36.604994
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    Tests constructor of `MonoWorker` class.
    """
    import time
    import threading
    import queue
    import unittest

    class TestMonoWorker(unittest.TestCase):
        """
        Tests `MonoWorker` class.
        """
        def setUp(self):
            self.monoworker = MonoWorker()
            self.enqueue_event = threading.Event()

        def enqueue(self, items):
            """
            Enqueues items.
            """
            for item in items:
                self.monoworker.submit(self.blocking_task, item)
                time.sleep(0.1)

        def blocking_task(self, x):
            """
            Blocks on a queue until the event occurs.
            """
            q = queue.Queue

# Generated at 2022-06-22 05:09:46.451634
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    def mono(i, **kwargs):
        sleep(i)
        return i

    w = MonoWorker()
    assert w.submit(mono, 1)
    assert not w.submit(mono, 0)

    sleep(1)
    assert not w.submit(mono, 0)
    assert w.submit(mono, 0)
    sleep(1)
    assert w.submit(mono, 0)
    assert w.submit(mono, 0)
    assert w.submit(mono, 0)
    sleep(1)
    assert not w.submit(mono, 0)
    # Test sequence
    assert w.submit(mono, 0).result() == 0
    assert w.submit(mono, 1).result() == 1
    sleep(1)
    assert not w

# Generated at 2022-06-22 05:09:57.464630
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random

    def wait_n_do(n):
        time.sleep(n)
        return n

    mw = MonoWorker()
    f1 = mw.submit(wait_n_do, 1)
    time.sleep(0.1)
    assert not f1.done()
    f2 = mw.submit(wait_n_do, 2)
    time.sleep(0.1)
    assert not f1.done()
    assert not f2.done()
    assert f2.running()
    assert not f1.running()
    result = f2.result()
    assert result == 2
    assert not f1.done()  # re-inserted
    assert not f1.running()
    assert f1.cancel()

# Generated at 2022-06-22 05:10:08.517713
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def _side_effect(x):
        sleep(x)
        return x

    def _check_done(x):
        assert(x.done())

    # Test for side effects
    w = MonoWorker()
    res = [w.submit(_side_effect, x) for x in range(10)]
    for r in res:
        assert(not r.done())
    for r in res:
        r.result()
        _check_done(r)

    # Test for latest waiting
    w = MonoWorker()
    res = [w.submit(_check_done, w.submit(_side_effect, x)) for x in range(10)]
    for r in res:
        r.result()
        _check_done(r)

# Generated at 2022-06-22 05:10:12.882484
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    futures = []
    def loop(f, i):
        while True:
            f.submit(tqdm_auto.write, "hello world")
            futures.append(f.futures)
    f = MonoWorker()
    loop(f, 1)

# Generated at 2022-06-22 05:10:20.131469
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import concurrent.futures

    def worker(n, wait, raise_):
        time.sleep(wait)
        if raise_:
            raise Exception("I raise")
        return n * 2

    def job(n, wait, raise_, abort):
        for i in tqdm_auto.trange(wait):
            time.sleep(1)
            if abort():
                return n  # don't re-raise

    worker_pool = MonoWorker()

    def abort():
        abort.i += 1
        return abort.i > 2

    abort.i = 0
    for i in tqdm_auto.trange(6, desc='abort'):
        worker_pool.submit(worker, i, i, i % 2 == 0)

# Generated at 2022-06-22 05:10:27.897894
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import traceback

    def task():
        for i in tqdm_auto.trange(5, desc='task', leave=True, mininterval=0):
            time.sleep(.1)
            yield

    worker = MonoWorker()
    try:
        worker.submit(task)()  # run task (should work)
        worker.submit(task)()  # run another task (should error)
    except BaseException as e:
        tqdm_auto.write(str(e))
        traceback.print_exc()
    worker.submit(task)()  # run another task (should work)

# Generated at 2022-06-22 05:10:33.618228
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from collections import Counter
    from concurrent.futures import Future

    def _(x, y=0):
        time.sleep(x)
        return x + y

    mw = MonoWorker()
    _ = [mw.submit(_, x) for x in [2, 2, 3, 4]]
    # check all jobs are done
    assert all(f.done() for f in mw.futures)
    # 2 first jobs should be cancelled
    assert all(f.cancelled() for f in mw.futures)[:2]
    # check 3rd job returned value
    assert mw.futures[2].result() == 3
    # check 4th job returned value
    assert mw.futures[3].result() == 4
    # check if jobs are added only once


# Generated at 2022-06-22 05:10:43.989766
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    random.seed('MonoWorker')
    import sys

    def write(msg):
        sys.stderr.write(msg)

    import time
    worker = MonoWorker()
    write("Starting tests\n")
    for i in range(10):
        msg = '#' + str(i)
        write("\nSubmitting task %s\n" % msg)
        future = worker.submit(time.sleep, random.randint(0, 10) / 10.0)
        future.add_done_callback(lambda f, txt=msg: write("Task %s done!\n" % txt))
    write("\n")
    time.sleep(0.4)

if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-22 05:10:56.673043
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # import time

    # from .utils_test import assert_equal

    counter = 0
    m = MonoWorker()

    def func(p):
        # time.sleep(p)
        return p

    # Two fast jobs
    m.submit(func, 0)
    m.submit(func, 0)
    # A slow job
    m.submit(func, 1)
    # New fast job
    m.submit(func, 0)
    # A longer job
    m.submit(func, 2)
    # New fast job, discarded
    m.submit(func, 0)

    # assert_equal(m.futures[0].result(), 0)
    # assert_equal(m.futures[1].result(), 0)
    # assert_equal(m.futures[2].result(), 2)


# Generated at 2022-06-22 05:11:06.800915
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import unittest

    class TestException(Exception):
        pass

    class TestMonoWorker(unittest.TestCase):
        def setUp(self):
            self.worker = MonoWorker()

        def test_submit(self):
            self.assertIsNone(self.worker.submit(time.sleep, -1))
            self.assertRaises(
                TestException,
                self.worker.submit, time.sleep, -1, None, func2=TestException)
            self.assertRaises(
                TestException, self.worker.submit, TestException)
            # Assert that the result is not discared
            self.assertIsNotNone(
                self.worker.submit(time.sleep, -1).result(1.5))

# Generated at 2022-06-22 05:11:14.626437
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import mock
    from concurrent.futures import Future

    # create single task that sleeps until timeout
    def submit():
        import time
        time.sleep(1)

    # specify max timeout
    max_timeout = 0.1

    # init MonoWorker
    mw = MonoWorker()

    with mock.patch('tqdm.contrib.concurrency.MonoWorker.pool.submit') as mock_submit:
        # test if new task is submitted before timeout
        mock_submit.return_value = Future()
        mw.submit(submit)
        mock_submit.assert_called_once()

        # test if new task overwrites old with same time
        mock_submit.reset_mock()
        mock_submit.return_value = Future()
        mw.submit(submit)
        mock_submit.assert_

# Generated at 2022-06-22 05:11:25.433044
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Test of the MonoWorker object
    """
    import time
    import random
    import threading
    mw = MonoWorker()
    nb_finish = 0
    runtime_list = []
    def long_running_job(seconds):
        """
        A long running job, will be called by the MonoWorker in parallel
        """
        time.sleep(seconds)
        runtime_list.append(seconds)
        with mw.pool._shutdown_lock:
            mw.pool._threads.clear()
            mw.pool._shutdown_thread()
        return seconds
    with tqdm_auto.tqdm(total=20) as pbar:
        for _ in range(10):
            seconds = random.uniform(1, 3)

# Generated at 2022-06-22 05:11:36.003722
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    @tqdm_auto
    def f(x):
        for _ in _range(10):
            time.sleep(0.1)
            if tqdm_auto.is_suspended():
                return x
        return 2*x

    m = MonoWorker()
    tqdm_auto.write('Submitting 1st')
    g = m.submit(f, 1)
    tqdm_auto.write('Submitting 2nd')
    h = m.submit(f, 2)
    tqdm_auto.write('Suspending 1st')
    m.futures[0].suspend()
    tqdm_auto.write('Terminating 1st')
    m.futures[0].terminate()


# Generated at 2022-06-22 05:11:37.053309
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    MonoWorker()


# Generated at 2022-06-22 05:11:48.365838
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def hello_world(words):
        time.sleep(1)
        print(' '.join(sorted(words)))
    mw = MonoWorker()
    # Test with one job
    mw.submit(hello_world, "world")
    mw.submit(hello_world, "world")
    mw.submit(hello_world, "world")
    # Test with two jobs
    mw.submit(hello_world, "beautiful")
    mw.submit(hello_world, "world")
    mw.submit(hello_world, "world")
    # Test with three jobs
    mw.submit(hello_world, "hello")
    mw.submit(hello_world, "beautiful")
    mw.submit(hello_world, "world")
    # Test with four jobs
   

# Generated at 2022-06-22 05:11:59.507215
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Setup
    import time, threading
    def sleep_print_1():
        time.sleep(1)
        print(1)
    def sleep_print_2():
        time.sleep(2)
        print(2)
    def sleep_print_3():
        time.sleep(3)
        print(3)
    worker = MonoWorker()

    # Submit
    worker.submit(sleep_print_1)
    worker.submit(sleep_print_2)
    print(0)
    worker.submit(sleep_print_3)
    time.sleep(0.1)
    worker.submit(sleep_print_1)
    time.sleep(0.1)
    worker.submit(sleep_print_2)
    time.sleep(0.1)

    # Cleanup

# Generated at 2022-06-22 05:12:11.166683
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from concurrent.futures import TimeoutError
    mw = MonoWorker()
    assert len(mw.futures) == 0
    f0 = mw.submit(time.sleep, 0.05)
    time.sleep(0.02)
    assert len(mw.futures) == 1
    f1 = mw.submit(time.sleep, 0.05)
    time.sleep(0.04)
    assert len(mw.futures) == 1
    f1.result(0.02)
    assert len(mw.futures) == 0
    assert f0.done()
    assert not f0.cancelled()
    try:
        f1.result(0.02)
    except TimeoutError:
        pass
    else:
        raise Exception

# Generated at 2022-06-22 05:12:15.528644
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import random
    def sleep_random(i):
        print(i)
        time.sleep(random.random())
        return i

    worker = MonoWorker()
    futures = [worker.submit(sleep_random, i) for i in range(5)]
    for future in futures:
        future.result()

# Generated at 2022-06-22 05:12:33.841806
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from sys import version_info as version

    def func(x):
        sleep(1)
        return x

    def print_done_future(done_future):
        if version[0] == 3:  # Python 3
            print(done_future.result())

    mw = MonoWorker()
    done_future1 = mw.submit(func, 1)
    done_future2 = mw.submit(func, 2)  # replace waiting
    done_future1.add_done_callback(print_done_future)
    done_future2.add_done_callback(print_done_future)

    # Future is cancelled on current MonoWorker and will not be invoked
    done_future3 = mw.submit(func, 3)

# Generated at 2022-06-22 05:12:45.332976
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random

    class MyException(Exception):
        pass

    def task_error(x):
        if x == 1:
            raise MyException(x)
        elif x == 2:
            raise Exception(x)
        else:
            return x

    def task_ok(x):
        return x

    def task_sleep(x):
        from time import sleep
        sleep(x/50.0)
        return x

    def assert_done(x):
        return x.done()

    def assert_cancelled(x):
        return x.cancelled()

    def assert_value_error(x):
        return x.exception() is not None

    def assert_return_value(x, val):
        try:
            return x.result() == val
        except Exception:
            return False


# Generated at 2022-06-22 05:12:55.023042
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    mono = MonoWorker()
    a = 0
    def add(n):
        time.sleep(1)
        global a
        a += n
        return a
    mono.submit(add, 5)
    mono.submit(add, 3)
    mono.submit(add, 4)
    assert a == 0, 'MonoWorker did not clear waiting task'
    mono.futures[0].result()
    assert a == 4, 'MonoWorkerd not waiting for previous task'
    mono.submit(add, 5)
    assert a == 4, 'MonoWorkerd not waiting for previous task'
    mono.futures[0].result()
    assert a == 9, 'MonoWorkerd not waiting for previous task'
    time.sleep(1)

# Generated at 2022-06-22 05:12:57.543377
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test to see if the constructor of class MonoWorker works or not"""
    worker = MonoWorker()
    assert worker.pool.__class__.__name__ == "ThreadPoolExecutor", "Test fail, should be ThreadPoolExecutor"
    assert worker.futures.__class__.__name__ == "deque", "Test fail, should be deque"


# Generated at 2022-06-22 05:13:02.979754
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test class constructor"""
    mw = MonoWorker()
    assert mw.pool.__class__.__name__ == "ThreadPoolExecutor"
    assert mw.pool._max_workers == 1
    assert mw.futures.__class__.__name__ == "deque"
    assert len(mw.futures) == 0


# Generated at 2022-06-22 05:13:12.506290
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from ..auto import trange

    def i(i):
        from time import sleep
        tqdm_auto.write("i({}): sleeping".format(i))
        sleep(1)
        tqdm_auto.write("i({}): done".format(i))
        return i

    tqdm_auto.write("---")
    # Basic
    mw = MonoWorker()
    for i in trange(3, desc="Basic"):
        waiting = mw.submit(i, i)
        tqdm_auto.write("waiting for i({}): {}".format(i, waiting))
        tqdm_auto.write("ii({}): {}".format(i, waiting.result()))
    # Advanced
    mw = MonoWorker()

# Generated at 2022-06-22 05:13:17.909216
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def print_msg(msg):
        print(msg)

    mono = MonoWorker()
    mono.submit(print_msg, 'task 1')
    mono.submit(print_msg, 'task 2')
    mono.submit(print_msg, 'task 3')
    mono.submit(print_msg, 'task 4')


if __name__ == "__main__":
    test_MonoWorker()

# Generated at 2022-06-22 05:13:27.912838
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def func(*args, **kwargs):
        sleep(1)
        return None

    mw = MonoWorker()

    # submit 1st
    f1 = mw.submit(func)
    sleep(0.5)
    assert len(mw.futures) == 1
    assert mw.futures[0] is f1

    # submit 2nd
    f2 = mw.submit(func)
    sleep(0.5)
    assert len(mw.futures) == 2
    assert mw.futures[0] is f1
    assert mw.futures[1] is f2

    # submit 3rd
    f3 = mw.submit(func)
    sleep(0.5)

# Generated at 2022-06-22 05:13:30.163185
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    MonoWorker()


# Generated at 2022-06-22 05:13:37.988022
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def f(x, k=0.01, s=None):
        sleep(k)
        if s:
            tqdm_auto.write(s)
        return x

    mw = MonoWorker()
    f1 = mw.submit(f, 1, k=0.05, s="s1")
    f2 = mw.submit(f, 2, k=0.1, s="s2")
    sleep(0.01)
    assert not f1.done()
    assert f2.done() and f2.result() == 2
    f3 = mw.submit(f, 3, k=0.01, s="s3")
    assert f3.done() and f3.result() == 3
    sleep(0.05)

# Generated at 2022-06-22 05:13:54.498381
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    from concurrent.futures import Future
    m = MonoWorker()
    
    assert isinstance(m.submit(time.sleep, 0.01), Future)
    assert len(m.futures) == 1
    assert not m.futures[0].done()
    assert isinstance(m.submit(threading.Event().wait), Future)
    assert len(m.futures) == 2
    assert not m.futures[0].done()
    assert not m.futures[1].done()
    assert isinstance(m.submit(time.sleep, 0.01), Future)
    assert len(m.futures) == 1
    assert not m.futures[0].done()
    m.futures[0].result()  # wait for execution

# Generated at 2022-06-22 05:13:57.153909
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    Unit test for constructor of class MonoWorker
    """
    mw = MonoWorker()
    assert(isinstance(mw, MonoWorker))

# Generated at 2022-06-22 05:14:03.595950
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import sys, time
    from threading import Event

    stop = Event()

    def printer(char, t):
        while not stop.wait(t):
            sys.stdout.write(char + ' ')

    worker = MonoWorker()
    worker.submit(printer, 'a', 0.1)
    time.sleep(0.2)
    worker.submit(printer, 'b', 0.1)
    time.sleep(0.2)
    stop.set()

# Generated at 2022-06-22 05:14:10.894212
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    Unit test for constructor of class MonoWorker.
    """
    from multiprocessing import Process
    from multiprocessing.pool import ThreadPool
    from threading import Thread
    import time

    def test_threads(n):
        pool = ThreadPool(1)
        res = [None] * (n + 1)
        for i in range(n, -1, -1):
            res[i] = pool.apply_async(time.sleep, (i, ))
        res[-1].wait()  # wait for last one to finish
        time.sleep(1)
        assert res[-1].ready() and not res[0].ready()

    def test_processes(n):
        pool = ThreadPool(1)
        res = [None] * (n + 1)

# Generated at 2022-06-22 05:14:13.359844
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()
    assert mw.pool is not None
    assert mw.futures is not None

# Generated at 2022-06-22 05:14:24.916217
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from warnings import catch_warnings
    from . import format_sizeof

    def proc():
        m, s = divmod(sleep(2), 60)
        return "worker finished in {:02d}:{:02d} minutes" \
            .format(int(m), int(s))

    with catch_warnings(record=True) as w:
        mw = MonoWorker()
        # Run 1
        assert len(mw.futures) == 0
        assert mw.submit(proc) != None
        assert len(mw.futures) == 1
        # Run 2 - replace waiting noop
        assert mw.submit(None) == None
        assert len(mw.futures) == 1
        # Run 3 - replace waiting proc
        assert mw.submit(proc)

# Generated at 2022-06-22 05:14:30.963386
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from ..contrib._tqdm_test_utils import print_test

    mono = MonoWorker()

    def somefunc():
        pass

    print_test(None, 'submit')
    mono.submit(somefunc)
    print_test(None, 'submit (again)')
    mono.submit(somefunc)
    print_test(None, 'submit (again again)')
    mono.submit(somefunc)

# Generated at 2022-06-22 05:14:39.038972
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test constructor of MonoWorker class."""
    mono = MonoWorker()
    # pylint: disable=unused-variable
    # pylint: disable=unused-argument, unnecessary-lambda
    from operator import add
    from time import sleep
    from threading import current_thread

    def tester(a, b):
        """Test function for submission to MonoWorker class."""
        sleep(3)
        return add(a, b)

    def log(a, b, result):
        """Logging function for submission to MonoWorker class."""
        tqdm_auto.write(
            "Adding {} and {} in thread {} yields {}".format(
                a, b, current_thread(), result))

    mono.submit(tester, 3, 5)
    mono.submit(tester, 1, 2)


# Generated at 2022-06-22 05:14:49.975100
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import sys
    import time
    import threading

    def say(name, seconds, out=sys.stdout):
        tqdm_auto.write(name + " begin", file=out)
        time.sleep(seconds)
        tqdm_auto.write(name + " end", file=out)
        return name

    mw = MonoWorker()

    t1 = threading.Thread(target=mw.submit, args=(say, "hello", 10),
                          kwargs=dict(out=sys.stderr))
    t2 = threading.Thread(target=mw.submit, args=(say, "world", 10))
    t3 = threading.Thread(target=mw.submit, args=(say, "hello", 10),
                          kwargs=dict(out=sys.stderr))

# Generated at 2022-06-22 05:14:53.299231
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test constructor of class MonoWorker"""
    w = MonoWorker()
    assert w.pool._max_workers == 1
    assert w.futures.maxlen == 2
    

# Generated at 2022-06-22 05:15:16.237431
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # pylint: disable=missing-docstring
    import time

    def func(index, sleep):
        time.sleep(sleep)
        return index, sleep

    def print_func(index, sleep):
        print(index, sleep)

    mw = MonoWorker()
    mw.submit(print_func, 0, 1)
    mw.submit(print_func, 1, 2)
    time.sleep(1)
    mw.submit(print_func, 2, 1)
    mw.submit(print_func, 3, 2)
    time.sleep(1)
    mw.submit(print_func, 4, 2)
    time.sleep(1)

    mw = MonoWorker()
    assert mw.submit(func, 0, 1).result() == (0, 1)
   

# Generated at 2022-06-22 05:15:18.611141
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mp = MonoWorker()
    assert len(mp.futures) == 0
    assert str(mp.futures.maxlen) == "2"


# Generated at 2022-06-22 05:15:29.624530
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test MonoWorker."""
    from ..utils import _range
    import operator as op
    import time

    def mul(x):
        """Multiply by 2."""
        time.sleep(1)
        return x * 2

    mono_worker = MonoWorker()

    # Start 4 tasks
    tqdm_auto.write('Start 4 mul tasks...')
    f4 = mono_worker.submit(mul, 4)
    f5 = mono_worker.submit(mul, 5)
    f2 = mono_worker.submit(mul, 2)
    f7 = mono_worker.submit(mul, 7)
    time.sleep(0.5)

    # Only f7 is running
    assert not f4.done() and not f5.done() and not f2.done() and f7.done

# Generated at 2022-06-22 05:15:40.314007
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from threading import Event
    from time import sleep

    # Test the running task
    def wait_long(wait):
        sleep(wait)

    mw = MonoWorker()
    assert len(mw.futures) == 0
    e = Event()
    e.clear()
    _ = mw.submit(e.wait)
    assert len(mw.futures) == 1
    e.set()
    assert len(mw.futures) == 0

    # Test the waiting task
    mw = MonoWorker()
    assert len(mw.futures) == 0
    e = Event()
    e.set()
    _ = mw.submit(e.wait)
    assert len(mw.futures) == 0

    # Test the cancellation of the waiting task
    mw

# Generated at 2022-06-22 05:15:42.635534
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from .tqdm import tqdm

    def test_func(i):
        sleep(1)
        return i

    with tqdm(total=3) as t:
        m = MonoWorker()
        fs = [m.submit(test_func, i) for i in range(3)]
        for f in fs:
            t.update()
            f.result()



# Generated at 2022-06-22 05:15:51.722284
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    import time

    def get_result(self, idx):
        time.sleep(random.uniform(1, 5))
        return idx

    # create a MonoWorker, then submit 3 tasks (0, 1, 2)
    # 0 is running, 1 is waiting and 2 is discarded

    print('Running test "test_MonoWorker_submit"...')
    mono_worker = MonoWorker()
    futures = []
    for idx in range(3):
        futures.append(mono_worker.submit(get_result, mono_worker, idx))

    print('Waiting for running task to complete...')
    for f in futures:
        f.result()

# Generated at 2022-06-22 05:15:56.478989
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import multiprocessing
    from concurrent.futures import ThreadPoolExecutor

    def wait(n):
        time.sleep(n)
        return n

    def test_running():
        m = MonoWorker()
        f = m.submit(wait, 0.01)
        assert f.done()
        assert f.result() == 0.01
        f = m.submit(wait, 0.01)
        assert not f.done()
        assert f.result() == 0.01
        m.submit(wait, 0.01)
        assert f.done()

    def test_concurrent(n=100):
        m = MonoWorker()
        t = ThreadPoolExecutor(max_workers=multiprocessing.cpu_count())
        fs = deque()

# Generated at 2022-06-22 05:16:07.236755
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from functools import partial
    from concurrent.futures import ThreadPoolExecutor

    def f(x, delay=0.1):
        sleep(delay)
        return x * x

    mw = MonoWorker()

    class C:
        def __init__(self):
            self.x = 0

        def incr(self):
            self.x += 1
            return self.x

    c = C()

    # non-blocking
    # assert len(mw.futures) == 0
    # mw.submit(f, 0)
    # assert len(mw.futures) == 1
    # mw.submit(f, 1)
    # assert len(mw.futures) == 1
    # assert mw.futures.pop().result() ==

# Generated at 2022-06-22 05:16:16.055472
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def resubmit(t):
        t.submit(sleep, 0.1)
        time.sleep(0.2)

    def sleep(t=0):
        time.sleep(t)

    t = MonoWorker()
    t.submit(sleep, 0.5)
    t.submit(sleep, 0.3)
    t.submit(sleep, 0.2)
    t.submit(resubmit, t)
    t.submit(sleep, 0.1)
    time.sleep(0.5)
    assert len(t.futures) == 1  # only last task is running
    assert t.futures[0].result() is None



# Generated at 2022-06-22 05:16:17.962478
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    MonoWorker().submit(lambda: 1)

# Generated at 2022-06-22 05:16:59.554772
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time, traceback

    def task(i, seconds, fail=False):
        """
        Sleep and print `i` and `fail` if fail is True.

        :return: i
        """
        time.sleep(seconds)
        tqdm_auto.write(i)
        if fail:
            raise Exception(i)
        return i

    # test
    mw = MonoWorker()
    fs = [mw.submit(task, i, 0.01) for i in range(10)]
    for f in fs:
        f.result()  # Wait for completion
    mw.pool.shutdown(wait=True)

    # test wrong method
    mw = MonoWorker()
    fs = [mw.submit(task, i, 0.01) for i in range(4)]

# Generated at 2022-06-22 05:17:10.710656
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import subprocess

    def wait_and_echo(n, msg):
        time.sleep(n)
        return msg

    mono = MonoWorker()
    mono.submit(wait_and_echo, 10, "A")

    tqdm_auto.write("B")

    mono.submit(wait_and_echo, 2, "C")

    tqdm_auto.write("D")

    mono.submit(wait_and_echo, 1, "E")

    tqdm_auto.write("F")

    tqdm_auto.write("G\n")

    mono.futures[0].result()
    mono.futures[1].result()

    tqdm_auto.write("H")

    mono.futures[1].result()

# Generated at 2022-06-22 05:17:19.212970
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time, random
    from threading import Event
    from unittest import TestCase
    from .tests import RandomSleep

    class Test_MonoWorker(TestCase):
        def setUp(self):
            self.pool = ThreadPoolExecutor(max_workers=1)
            self.worker = MonoWorker()
            self.events = [Event() for _ in range(4)]

        def test_MonoWorker__submit(self):
            def run(event, sleep):
                event.wait()
                time.sleep(sleep)
                return sleep

            for _ in range(2):
                self.events[0].set()
                # run in thread pool
                res = self.pool.submit(run, self.events[0],
                                       RandomSleep().next())
                # run in MonoWorker
                delay = Random

# Generated at 2022-06-22 05:17:24.601750
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from sys import stderr
    mw = MonoWorker()
    with tqdm_auto.tqdm(file=stderr) as t:
        for _ in range(10):
            mw.submit(t.update)
            sleep(0.1)
        mw.submit(t.update, 2)

if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-22 05:17:31.399490
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Unit test + example for MonoWorker.submit()
    """
    import time

    def f1(*args, **kwargs):
        time.sleep(10)
        return args, kwargs

    def f2(*args, **kwargs):
        return args, kwargs

    mw = MonoWorker()
    job = mw.submit(f1, 1, 2, a=1)
    assert len(mw.futures) == 1
    assert mw.futures[0] is job
    assert job.running()
    job = mw.submit(f2, 1, 2, a=1)
    assert len(mw.futures) == 1
    assert mw.futures[0] is job
    assert job.running()
    job.result()  # wait

# Generated at 2022-06-22 05:17:37.988729
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    Unit test for constructor of class MonoWorker
    """
    worker = MonoWorker()

    assert isinstance(worker.pool, ThreadPoolExecutor),\
        "Failed to handle initialization of worker.pool"

    assert hasattr(worker, "futures"),\
        "Failed to handle initialization of worker.futures"

    assert isinstance(worker.futures, deque),\
        "Failed to instantiate worker.futures"


# Generated at 2022-06-22 05:17:49.480542
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test `MonoWorker`"""

    import random

    def f(x):
        import time
        time.sleep(random.randint(0, 4))
        return x * 2

    with MonoWorker() as worker:
        future = worker.submit(f, 3)
        future = worker.submit(f, 4)
        assert future.result() == 8
    assert 8 == future.result()

    with MonoWorker() as worker:
        future = worker.submit(f, 3)
        future = worker.submit(f, 4)
        assert future.result() == 8
        worker.submit(f, 5)
        future = worker.submit(f, 4)
        assert future.result() == 8
    assert 8 == future.result()


# Generated at 2022-06-22 05:18:01.094354
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading

    def long_func(t=2):
        time.sleep(t)

    def short_func():
        long_func(t=0.1)

    def err_func():
        raise AssertionError

    def get_futures(mw):
        return list(
            filter(None.__ne__, (mw.futures.popleft(), mw.futures.popleft())))

    # no running task, no waiting task

    mw = MonoWorker()
    mw.submit(long_func)
    running, _ = get_futures(mw)
    assert running.result(1) is None

    # with running task, no waiting task

    mw = MonoWorker()
    mw.submit(long_func)
   

# Generated at 2022-06-22 05:18:10.967118
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """`tqdm_contrib.MonoWorker` unit test."""
    mw = MonoWorker()

    # Submit some work
    work = mw.submit(tqdm_auto.sleep, 0.1)

    # Work is currently waiting...
    assert len(mw.futures) == 1
    assert not work.done()
    assert not work.result(timeout=0)

    # Submit some more work
    work = mw.submit(tqdm_auto.sleep, 0.2)

    # Old work is dropped
    assert len(mw.futures) == 1
    assert not work.done()
    assert not work.result(timeout=0)

    # Wait for work to finish
    work.result()

# Generated at 2022-06-22 05:18:19.129953
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from threading import Lock
    from time import sleep
    from ..utils import FormatCustomTextExtension

    def test_func(index, lock, print_index, sleep_time=0.4):
        with lock:
            print_index[0] = index
            tqdm_auto.write("test_func {}".format(index))

        sleep(sleep_time)
        tqdm_auto.write("test_func {} done".format(index))

    lock = Lock()
    print_index = [0]
    worker = MonoWorker()
    worker.submit(test_func, -1, lock, print_index, 0.1)
    worker.submit(test_func, 2, lock, print_index, 0.1)
    worker.submit(test_func, 3, lock, print_index, 0.1)
