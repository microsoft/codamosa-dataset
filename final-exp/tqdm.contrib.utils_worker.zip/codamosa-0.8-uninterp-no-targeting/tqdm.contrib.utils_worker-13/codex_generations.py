

# Generated at 2022-06-22 05:09:21.552261
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random

    class Track(object):
        def __init__(self):
            self.data = []

        def append(self, x):
            self.data.append(x)

    def sleep(x):
        time.sleep(random.randint(1, 10) / 5)
        return x

    # stop each worker after 3 jobs
    worker = MonoWorker()
    track = Track()
    N_WORKERS = 4
    for _ in range(N_WORKERS):
        for i in range(3):
            worker.submit(sleep, i)
    # cancel last worker
    worker.submit(lambda: None).cancel()
    N_WORKERS -= 1
    N_JOBS = N_WORKERS * 3
    # collect the result

# Generated at 2022-06-22 05:09:27.917685
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from .misc import test_kwargs

    args = test_kwargs(a=1, b=2)

    def test_func(*args, **kwargs):
        for i in range(5):
            time.sleep(0.5)
        return args, kwargs

    worker = MonoWorker()
    for i in range(5):
        worker.submit(test_func, *args, **kwargs)

# Generated at 2022-06-22 05:09:38.523124
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from concurrent.futures import Future
    def _test(sleep_time, running=False, done=False):
        if running:
            time.sleep(sleep_time)
        return Future()
    m = MonoWorker()
    assert len(m.futures) == 0
    _test(1, done=True)
    m.submit(_test, sleep_time=1)
    time.sleep(0.1)
    assert len(m.futures) == 1
    m.submit(_test, sleep_time=1, running=True)
    time.sleep(0.1)
    assert len(m.futures) == 1
    time.sleep(1)
    assert len(m.futures) == 1
    m.submit(_test, sleep_time=1)
    time

# Generated at 2022-06-22 05:09:43.825525
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def run(a, b):
        """Return sum of ``a`` and ``b``"""
        return a + b
    mono_worker = MonoWorker()
    assert mono_worker.submit(run, 1, 2).result() == 3
    assert mono_worker.submit(run, 3, 4).result() == 7



# Generated at 2022-06-22 05:09:46.304170
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Constructor for class MonoWorker"""
    m = MonoWorker()
    assert m.pool
    assert m.futures
    assert len(m.futures) == 0


# Generated at 2022-06-22 05:09:51.025451
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    # create a thread pool
    mw = MonoWorker()

    # get the number of maximum workers of the pool
    max_workers = mw.pool._max_workers

    # check the number
    assert max_workers == 1, 'The number of workers is not correct.'

# Generated at 2022-06-22 05:09:53.560809
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Tests constructor of class MonoWorker"""
    mw = MonoWorker()
    assert mw
    futures = mw.futures
    assert futures
    assert len(futures) == 0
    assert len(futures) == futures.maxlen == 2

# Generated at 2022-06-22 05:10:01.354880
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import os
    import sys
    from time import sleep
    from ..utils import MakeTestDelay  # NOQA

    delay = MakeTestDelay(0.1)
    pool_num_workers = os.cpu_count()

    def long_task():
        delay()
        return 2

    def background_task():
        delay()
        return 3

    if sys.version_info < (3, 0):
        # ThreadPoolExecutor is not compatible with Python 2
        return


# Generated at 2022-06-22 05:10:09.472762
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from tqdm.auto import trange
    from threading import Thread
    from time import sleep
    mw = MonoWorker()
    for i in trange(20):
        if i == 0:
            mw.submit(sleep, 0.2)
            continue
        if i == 10:
            mw.submit(sleep, 0.1)
            mw.submit(sleep, 0.3)
        if i == 15:
            mw.submit(sleep, 0.2)
        if i == 20:
            mw.submit(sleep, 0.1)
        if i == 30:
            mw.submit(sleep, 0.1)

    class WaitingTask(Thread):
        def run(self):
            while True:
                mw.submit(sleep, 0.1)
    WaitingTask().start()


# Generated at 2022-06-22 05:10:15.031464
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    test_mw = MonoWorker()
    test_mw.submit(sleep, 0.1)
    test_mw.submit(sleep, 0.2)  # sleep(0.1) should be cancelled
    assert len(test_mw.futures) == 1
    test_mw.futures[0].result()  # block until 0.2 completed

# Generated at 2022-06-22 05:10:25.413050
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from threading import Event
    from time import sleep

    # Create a MonoWorker and submit two tasks, 1 and 2
    mw = MonoWorker()
    e1 = Event()
    e2 = Event()
    f1 = mw.submit(lambda: e1.wait())
    f2 = mw.submit(lambda: e2.wait())
    # Only task 2 should be waiting
    assert len(mw.futures) == 1
    assert mw.futures[0] is f2
    # Cancel task 1
    f1.cancel()
    assert f1.cancelled()
    assert not f2.cancel()  # need to catch exception for Python 2.7
    # Submit task 2 again
    f1 = mw.submit(lambda: e1.wait())

# Generated at 2022-06-22 05:10:31.902680
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import sys
    import time
    import contextlib

    # Switch `tqdm.std*` to *actual* `sys.std*` in case they differ:
    with contextlib.nullcontext():
        with contextlib.redirect_stdout(sys.__stdout__):
            with contextlib.redirect_stderr(sys.__stderr__):
                mw = MonoWorker()

    # We need:
    # 1. A function that blocks for some time
    # 2. A function that raises an exception (to be captured)
    def sleep_and_print(s):  # pragma: no cover
        """Blocking wait for `s` seconds then print."""
        time.sleep(s)
        tqdm_auto.write('slept ' + str(s) + 's')


# Generated at 2022-06-22 05:10:37.709579
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from multiprocessing import Queue

    q = Queue()

    def f():
        time.sleep(2)
        q.put("hello")

    mw = MonoWorker()
    f1 = mw.submit(f)
    f2 = mw.submit(f) #f2 should replace f1
    assert f1.cancelled() and not f2.done()
    assert q.get() == "hello"

# Generated at 2022-06-22 05:10:45.805402
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import threading

    class SleepingWorker(threading.Thread):
        def __init__(self, worker):
            self.worker_id = worker.worker_id
            self.sleeping_time = worker.sleeping_time
            super(SleepingWorker, self).__init__()

        def run(self):
            print('Worker %i is going to sleep for %i seconds' % (
                self.worker_id, self.sleeping_time))
            time.sleep(self.sleeping_time)
            print('Worker %i just woke up' % self.worker_id)

    class Worker(object):
        def __init__(self, worker_id, sleeping_time):
            self.worker_id = worker_id
            self.sleeping_time = sleeping_time


# Generated at 2022-06-22 05:10:56.064176
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    Test `tqdm.contrib.MonoWorker` for correctness
    """
    from threading import Event
    from time import sleep
    mw = MonoWorker()
    e = Event()

    def waiter(evt, dur):
        """
        Waits for ``dur`` seconds and calls ``evt.set()``
        """
        sleep(dur)
        evt.set()

    # Assert that current running task is replaced by next task
    # that is submitted when current running task ends
    def test_1():
        evt = Event()
        assert not evt.is_set()
        mw.submit(waiter, evt, 10)
        sleep(2)
        mw.submit(waiter, e, 0.3)
        sleep(2)
        assert e.wait

# Generated at 2022-06-22 05:11:02.852106
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    class A:
        pass
    try:
        a = MonoWorker()
        b = MonoWorker()
        assert(a == b)
        assert(a is not b)
        assert(a.__dict__ == b.__dict__)
        assert(a.__dict__ is not b.__dict__)
        b = A()
        assert(a != b)
        assert(a is not b)
    except:
        assert(False)


# Generated at 2022-06-22 05:11:12.710222
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import warnings

    def do_1():
        time.sleep(0.5)
        return 1
    def do_2():
        time.sleep(3)
        return 2
    def do_3():
        time.sleep(0.7)
        return 3
    def error():
        raise ValueError("foo")

    mono = MonoWorker()
    with warnings.catch_warnings(record=True) as w:
        assert mono.submit(do_1)
        assert len(w) == 0

        # This is discarded because running
        assert mono.submit(do_2)
        assert len(w) == 0

        # This is discarded because waiting
        assert mono.submit(do_3)
        assert len(w) == 0

        # This raises an exception
        assert mono.submit(error)


# Generated at 2022-06-22 05:11:18.045442
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    """
    worker = MonoWorker()
    # Test 1
    assert worker.pool
    assert worker.futures
    # Test 2
    assert worker.pool.__dict__['_max_workers'] == 1
    assert worker.futures.maxlen == 2
    # Test 3
    assert len(worker.futures) == 0

# Generated at 2022-06-22 05:11:28.240636
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import randint
    mw = MonoWorker()
    def _test_submit(p, pause=0.01):
        sleep(pause)
        print(p)
        return p
    mw.submit(_test_submit, p=1)
    mw.submit(_test_submit, p=2)
    sleep(0.1)
    mw.submit(_test_submit, p=3)
    sleep(0.1)
    mw.submit(_test_submit, p=4)
    sleep(0.1)
    mw.submit(_test_submit, p=5)
    sleep(0.1)


if __name__ == '__main__':  # pragma: no cover
    test_MonoWorker_submit()

# Generated at 2022-06-22 05:11:39.841181
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import concurrent.futures
    from .tqdm_monkey import stdout
    from .tqdm_tqdm import tqdm

    def log(s, *args):
        tqdm_auto.write(s.format(*args))

    def wait(t, task):
        log('Submitting {}', task)
        time.sleep(t)
        return task

    def test(wait_times):
        log('\n')
        log('Testing with wait_times = {}', wait_times)
        log('\n')
        mono_worker = MonoWorker()
        last_result = None
        for idx, wait_time in enumerate(wait_times):
            f = mono_worker.submit(wait, wait_time, idx)
            if f:
                last_result = f

# Generated at 2022-06-22 05:11:52.591294
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep, strftime, time

    def bar(seconds):
        for _ in tqdm_auto.tqdm(range(seconds), desc=strftime("%H:%M:%S")):
            sleep(1)

    loop = 1
    tic = time()
    mono = MonoWorker()
    for _ in range(loop):
        mono.submit(bar, 1)
        mono.submit(bar, 2)
        mono.submit(bar, 1)
        mono.submit(bar, 3)
        mono.submit(bar, 2)
    mono.submit(bar, 1)
    mono.submit(bar, 2)
    mono.submit(bar, 1)
    mono.submit(bar, 3)
    mono.submit(bar, 2)

# Generated at 2022-06-22 05:11:54.000063
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    assert MonoWorker()


# Generated at 2022-06-22 05:12:04.985179
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def wait(duration):
        time.sleep(duration)
        return duration

    def wait_and_print(duration):
        result = wait(duration)
        print(result)

    # Tests
    m = MonoWorker()
    future = m.submit(wait_and_print, 1)
    future_list = [m.submit(wait_and_print, 0.5),
                   m.submit(wait_and_print, 0.5),
                   m.submit(wait_and_print, 0.5),
                   m.submit(wait_and_print, 0.5),
                   m.submit(wait_and_print, 0.5),
                   m.submit(wait_and_print, 0.5)]
    time.sleep(0.8)

# Generated at 2022-06-22 05:12:07.266536
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    MonoWorker()


if __name__ == '__main__':
    test_MonoWorker()

# Generated at 2022-06-22 05:12:18.086222
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    def long_work():
        time.sleep(random.random() + 0.05)
        return 1
    worker = MonoWorker()
    results = []
    last_waiting = None
    for i in range(10):
        last_waiting = worker.submit(long_work)
        results.append(None)
        while last_waiting.running():
            time.sleep(0.01)
        if last_waiting.done():
            results.pop()
            results.append(last_waiting.result())
    assert (results == [1] * 10)
    threading.current_thread().join(0.01)
    threading.current_thread().join(0.01)
    threading.current_thread().join(0.01)
   

# Generated at 2022-06-22 05:12:29.943678
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    >>> import multiprocessing as mp
    >>> def subproc_func(x, timeout=1):
    ...     mp.get_context('spawn').get_start_method()
    ...     from time import sleep
    ...     sleep(timeout)
    ...     return x**2
    >>> w = MonoWorker()
    >>> w.submit(subproc_func, 6)
    <Future at 0x... state=running>
    >>> w.submit(subproc_func, 2, timeout=0.5)
    >>> res = w.submit(subproc_func, 3, timeout=5)
    >>> res.result()
    9
    """
    pass


if __name__ == "__main__":
    """
    Unit testing
    """
    import doctest
    doctest.testmod()

# Generated at 2022-06-22 05:12:34.265442
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    mw = MonoWorker()

    def test_func_0():
        print('Test running 0')
        time.sleep(1)
        print('Test finished 0')

    def test_func_1():
        print('Test running 1')
        time.sleep(1)
        print('Test finished 1')

    def test_func_2():
        print('Test running 2')
        raise Exception('Test errored 2')

    mw.submit(test_func_0)
    mw.submit(test_func_1)
    mw.submit(test_func_2)
    mw.submit(test_func_0)
    mw.submit(test_func_1)

# Generated at 2022-06-22 05:12:45.698664
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import pytest
    import tqdm.contrib.test_utils

    def func(n):
        time.sleep(n)
        return n

    mw = tqdm.contrib.test_utils.MonoWorker()  # doesn't really work in IPython
    r = mw.submit(func, 1.5)
    assert not r.done()
    mw.submit(func, 0.5)
    with pytest.raises(Exception):
        r.result()
    assert r.cancel()  # returns True if cancel() succeeds, else False
    time.sleep(2)
    assert r.cancelled()
    assert not r.done()
    mw.submit(func, 0.5)
    time.sleep(2)
    assert mw.futures and m

# Generated at 2022-06-22 05:12:55.397987
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import concurrent.futures
    import time

    def echo(num, delay=0.1):
        time.sleep(delay)
        return num

    monoworker = MonoWorker()

    # Run a job
    assert monoworker.submit(echo, 1)
    time.sleep(0.1)

    # Run another job
    assert monoworker.submit(echo, 2)
    time.sleep(0.1)

    # Submit another job
    assert monoworker.submit(echo, 3)
    time.sleep(0.1)
    assert monoworker.futures[0].result() == 3

    # Submit another job
    assert monoworker.submit(echo, 4)
    time.sleep(0.1)

# Generated at 2022-06-22 05:12:59.987220
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from multiprocessing import cpu_count
    from time import sleep

    n = cpu_count() * 10

    current_waiter = [None]
    def waiter(delay):
        current_waiter[0] = sleep(delay)

    tasks = [MonoWorker().submit(waiter, 1) for i in range(n)]
    sleep(0.75)
    current_waiter[0].cancel()
    sleep(1)

# Generated at 2022-06-22 05:13:06.179295
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    >>> worker = MonoWorker()
    """

# Generated at 2022-06-22 05:13:13.685908
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from concurrent.futures import Future
    import time

    def foo(i):
        time.sleep(0.1)
        return i * i

    mw = MonoWorker()
    f0 = mw.submit(foo, 0)
    assert isinstance(f0, Future)
    f1 = mw.submit(foo, 1)
    assert isinstance(f1, Future)
    f2 = mw.submit(foo, 2)
    assert isinstance(f2, Future)
    assert f0.done()
    assert f1.done()
    assert not f0.cancelled()
    assert f0.result() == 0
    assert f1.result() == 1
    assert not f2.done()

    def bar(i):
        return i * i


# Generated at 2022-06-22 05:13:24.352440
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from concurrent.futures import CancelledError

    mw = MonoWorker()
    assert len(mw.futures) == 0
    print('submit1')
    mw.submit(sleep, 10)
    assert len(mw.futures) == 1
    assert mw.futures[0].running()

    print('submit2')
    mw.submit(sleep, 1)  # should discard first
    assert len(mw.futures) == 1
    assert mw.futures[0].running()

    print('submit3')
    mw.submit(sleep, 1)
    assert len(mw.futures) == 1
    assert mw.futures[0].running()

    print('sleep')
    sleep(3)
    assert len

# Generated at 2022-06-22 05:13:31.023725
# Unit test for method submit of class MonoWorker

# Generated at 2022-06-22 05:13:38.316933
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import random
    import threading
    from queue import Queue  # Python 3.x
    #from Queue import Queue  # Python 2.x
    import tqdm

    def timefunc(func, *args, **kwargs):
        """
        Wraps `func(*args, **kwargs)`
        and returns time elapsed in seconds.
        """
        start = time.time()
        ret = func(*args, **kwargs)
        return time.time() - start, ret

    def echo(x):
        time.sleep(random.random())
        return x

    def test(N, execlen=.001):
        """
        Repeatedly submit `echo(i)` to `MonoWorker`.
        """
        q = Queue()
        q.put(0)

       

# Generated at 2022-06-22 05:13:46.901445
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def bar(a, b):
        return a + b

    foo = MonoWorker()
    assert foo.submit(bar, 1, b=1).result() == 2
    with tqdm_auto.external_write_mode():
        with tqdm_auto.tqdm(total=100, mininterval=0.1) as pbar:
            assert foo.submit(bar, pbar.n + 1, b=1).result() == 2
            try:
                foo.submit(bar, pbar.n + 1, b=1).result()
            except Exception as e:
                assert str(e) == 'MonoWorker future is cancelled'
            else:
                raise ValueError("Should have raised Exception!")
        assert foo.submit(bar, pbar.n + 1, b=1).result() == 2

# Generated at 2022-06-22 05:13:54.172772
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    # The 'time.sleep' function is a simple example
    def f1(): time.sleep(3)
    def f2(): time.sleep(2)
    def f3(): time.sleep(1)
    # Create a MonoWorker object
    mw = MonoWorker()
    # Submit some function to it
    mw.submit(f1)
    mw.submit(f2)
    mw.submit(f3)
    # Each function should be executed once
    # and executed in the order that they were submitted
    # (f1, f2, f3)

# Generated at 2022-06-22 05:14:02.806241
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    desc = 'Testing MonoWorker'
    with tqdm_auto.tqdm(desc=desc, leave=False) as t:
        mw = MonoWorker()
        assert len(mw.futures) == 0, desc + ' (init)'
        assert mw.submit(pow, 2, 10), desc + ' (submit)'
        assert len(mw.futures) == 1, desc + ' (1st)'
        assert mw.submit(pow, 3, 10), desc + ' (submit)'
        assert len(mw.futures) == 1, desc + ' (2nd)'
        t.update(1)

# Generated at 2022-06-22 05:14:10.452452
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from sys import platform
    from time import sleep

    def dummy_busy_loop(t):
        sleep(t)
        return t

    # Check [unit-testable] behaviour (not platform-specific)
    mw = MonoWorker()
    running = mw.submit(dummy_busy_loop, 0.1)
    assert running.result() == dummy_busy_loop(0.1)
    assert len(mw.futures) == 1
    assert running.done()

    waiting = mw.submit(dummy_busy_loop, 0.3)
    assert waiting.result() == dummy_busy_loop(0.3)
    assert len(mw.futures) == 2
    assert running.done()
    assert waiting.done()


# Generated at 2022-06-22 05:14:15.944109
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from random import randrange
    mw = MonoWorker()
    mw.submit(sleep, randrange(5, 10))
    sleep(5)
    mw.submit(sleep, randrange(5, 10))
    sleep(5)
    mw.submit(sleep, randrange(5, 10))
    sleep(5)

# Generated at 2022-06-22 05:14:28.967865
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()
    assert len(mw.futures) == 0
    mw.submit(lambda x: x * 2, 10)
    assert len(mw.futures) == 1
    mw.submit(lambda x: x * 2, 10)
    assert len(mw.futures) == 2
    mw.futures.popleft().cancel()
    assert len(mw.futures) == 1
    mw.futures.popleft().cancel()
    assert len(mw.futures) == 0

# Generated at 2022-06-22 05:14:37.752605
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # pylint: disable=redefined-outer-name
    # pylint: disable=too-many-locals
    from time import sleep
    from threading import Event
    from collections import defaultdict

    def wait():
        """Synchronous sleep for 0.1s."""
        sleep(0.2)

    def func(n):
        """Sleep for 0.1s and then return n."""
        sleep(0.1)
        return n

    def func_supply_promise(promise, n):
        """Sleep for 0.1s, then fulfill promise with n."""
        sleep(0.1)
        promise.set(n)

    def func_supply(n):
        """Sleep for 0.1s and then return n."""
        sleep(0.1)
        return n


# Generated at 2022-06-22 05:14:49.887632
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading

    def assert_in(elem, container, msg=''):
        assert elem in container, \
            '{} not found in {}'.format(elem, container)

    def assert_not_in(elem, container, msg=''):
        assert elem not in container, \
            '{} found in {}'.format(elem, container)

    def assert_is_none(obj, msg=''):
        assert obj is None, '{!r} is not None'.format(obj)

    def assert_is_not_none(obj, msg=''):
        assert obj is not None, '{!r} is None'.format(obj)


# Generated at 2022-06-22 05:14:53.003828
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    .. code-block:: python

        >>> from tqdm.contrib.concurrency import MonoWorker
        >>> m = MonoWorker()

    """

# Generated at 2022-06-22 05:15:03.488324
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep

    def some_task(msg):
        sleep(0.1)
        tqdm_auto.write(msg)

    mw = MonoWorker()
    mw.submit(some_task, 'A')
    sleep(0.5)
    mw.submit(some_task, 'B')
    sleep(0.5)
    mw.submit(some_task, 'C')
    sleep(0.5)
    mw.submit(some_task, 'D')
    sleep(0.5)
    mw.submit(some_task, 'E')
    sleep(0.5)
    mw.submit(some_task, 'F')

# Generated at 2022-06-22 05:15:11.058943
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def raise_error(x):
        x / 0

    worker = MonoWorker()
    for i in range(4):
        worker.submit(raise_error, 1)
        worker.submit(raise_error, 1)
        worker.submit(raise_error, 1)
        worker.submit(raise_error, 1)
        worker.submit(raise_error, 1)
        worker.submit(raise_error, 1)
        worker.submit(raise_error, 1)

if __name__ == '__main__':
    test_MonoWorker()

# Generated at 2022-06-22 05:15:21.009129
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from multiprocessing import cpu_count, Pool
    import time

    def throw(v):
        time.sleep(3)
        raise v
    def return_v(v):
        time.sleep(3)
        return v

    pmulti = Pool(cpu_count())
    m0 = MonoWorker()
    m1 = MonoWorker()

    pmulti.map(return_v, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
    res = []
    for v in tqdm_auto(range(10), desc='submit'):
        if v == 5:
            res.append(m0.submit(throw, v))
        elif v == 6:
            res.append(m1.submit(throw, v))

# Generated at 2022-06-22 05:15:31.001527
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def _exit_sleep_task(wait_time=0.01):
        # a no-op that simply sleeps for 'wait_time' seconds
        sleep(wait_time)

    # Create a new MonoWorker
    mono = MonoWorker()

    # Submit a task
    task = mono.submit(_exit_sleep_task)
    # Check that the task is not done
    assert not task.done()

    # Wait a little
    sleep(0.05)

    # Another task is submitted
    task2 = mono.submit(_exit_sleep_task)
    # Wait again
    sleep(0.05)
    # Task 2 is completed
    assert task2.done()

    # Wait for task to finish
    task.result()
    # Check if task is finished
    assert task.done()

# Generated at 2022-06-22 05:15:39.133401
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import sys
    import threading
    from tqdm import tqdm

    def thread_func(name, worker, lock, barrier, sleep_sec, fail_sec):
        with tqdm(total=2, desc=name) as pbar:
            tqdm_auto.write('{name} #1'.format(name=name))
            with lock:
                worker.submit(time.sleep, sleep_sec)
            tqdm_auto.write('{name} #2'.format(name=name))
            barrier.wait()
            # This will only be executed by 1 thread
            if name == "Thread 1":
                tqdm_auto.write('{name} #3'.format(name=name))
                # This will cancel the call to time.sleep in Thread 2

# Generated at 2022-06-22 05:15:49.653613
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def oneliner():
        """
        A task that takes some time to complete and prints intermediate results
        """
        for i in tqdm_auto.tqdm(range(10)):
            print(i)
            time.sleep(0.1)

    print("Test: MonoWorker(max_workers=1)")
    mw = MonoWorker()
    t1 = time.time()
    w1 = mw.submit(oneliner)
    w2 = mw.submit(oneliner)
    w1.result()
    w2.result()
    tqdm_auto.write("Waiting time is around 1.9 seconds.")
    print("One task is running, other tasks are waiting!")
    print("Test: MonoWorker(max_tasks=1)")

# Generated at 2022-06-22 05:16:16.474319
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from queue import LifoQueue
    from .threads import deco_thread

    # Configure test parameters
    numbers = [1, 2, 3, 4, 5]
    output = [None]
    pool = MonoWorker()

    # Asynchronous function
    @deco_thread(pool=pool)
    def async_func(i, delay=0.1, output=output):
        time.sleep(delay)
        output[0] = i
        return i

    # Function to run asynchronous function in order and
    # assert that the last one to complete is the last to be submitted
    def test_func(ordered_numbers, output=output):
        output[0] = None  # Reset output
        pool = MonoWorker()  # Reset pool
        queues = [LifoQueue() for i in numbers]


# Generated at 2022-06-22 05:16:18.747582
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test constructor of class MonoWorker"""
    passes = 0
    class_object = MonoWorker()
    assert (type(class_object) is MonoWorker)
    assert (class_object.pool is not None)
    assert (class_object.futures is not None)
    passes += 1
    print("Passed constructor of class MonoWorker")
    return passes


# Generated at 2022-06-22 05:16:21.172802
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    worker = MonoWorker()
    assert worker.pool._max_workers == 1
    assert not worker.futures


# Generated at 2022-06-22 05:16:30.165425
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Test method submit of class `MonoWorker`.
    """
    import time
    try:
        from unittest.mock import patch
    except ImportError:  # pragma: no cover
        from mock import patch  # type: ignore

    class _MonoWorkerTest(MonoWorker):
        def __init__(self):
            super(_MonoWorkerTest, self).__init__()
            self.run_order = []

        def func(self, begin, duration):
            self.run_order.append(begin)
            time.sleep(duration)
            self.run_order.append(begin + duration)

    def run(monoworker, begin, duration):
        monoworker.func(begin, duration)

    # test simultaneous
    monoworker = _MonoWorker

# Generated at 2022-06-22 05:16:36.185110
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def _test():
        mw = MonoWorker()
        for i in range(5):
            print("Iteration %d/4" % i)
            mw.submit(sleep, 0.1)
            sleep(0.1)
        print("Goodbye!")

    _test()


# Generated at 2022-06-22 05:16:42.822018
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import random
    import sched
    import time

    def rand_int():
        tqdm_auto.write("4")
        return 4
    def rand_int_delayed():
        s = sched.scheduler()
        done = False

        def schedule_call(timer):
            assert not done
            time.sleep(timer)
            assert not done
            done = True
            tqdm_auto.write("4")
        s.enter(0.5, 1, schedule_call, (0.5,))
        s.run()
        return 4

    r = MonoWorker()
    r.submit(rand_int)
    time.sleep(0.1)
    r.submit(rand_int)
    time.sleep(0.1)
    f = r.submit(rand_int_delayed)


# Generated at 2022-06-22 05:16:49.583950
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep

    def f(x):
        sleep(0.1)
        return x

    m = MonoWorker()
    assert m.submit(f, 10).result() == 10
    assert m.submit(f, 20).result() == 20
    assert m.submit(f, 30).result() == 30
    assert m.submit(f, 40).result() == 40
    assert m.submit(f, 50).result() == 50
    assert m.submit(f, 60).result() == 60

# Generated at 2022-06-22 05:16:58.029331
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker."""
    def f0():
        pass

    def f1():
        return 1

    def f2():
        return 2

    worker = MonoWorker()

    # basic
    assert worker.submit(f0) is None
    assert worker.submit(f0) is None
    assert worker.submit(f0) is None

    # test queue
    assert worker.submit(f1).result() == 1
    assert worker.submit(f2).result() == 2
    assert worker.submit(f1).result() == 1


if __name__ == "__main__":
    from .tests import test_MonoWorker
    test_MonoWorker.main()

# Generated at 2022-06-22 05:17:10.016669
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import random

    def wait(hid_tqdm, seconds):
        for i in hid_tqdm(range(seconds)):
            time.sleep(1)
        return seconds

    def try_wait(seconds):
        mw = MonoWorker()
        fut = mw.submit(wait, tqdm_auto.tqdm(total=seconds, mininterval=1.0, desc="waiting"),
                        seconds)
        return fut.result()

    # Ensure that out-of-order wait requests don't break anything
    assert try_wait(3) == 3
    assert try_wait(2) == 3
    assert try_wait(5) == 5
    assert try_wait(4) == 5
    assert try_wait(1) == 5

    # Ensure that concurrent wait requests don't break anything


# Generated at 2022-06-22 05:17:18.697865
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import monotonic as time
    from multiprocessing import Manager, Process
    from random import random, randint
    from collections import Counter
    from operator import itemgetter

    def submitter(submit, results, wait=0.1, **kwargs):
        rsleep = random() * wait
        tqdm_auto.write(rsleep)
        while True:
            future = submit(sleep, rsleep, **kwargs)
            if future.result() is None:
                break
            rsleep = random() * wait
            results.append(rsleep)
            tqdm_auto.write(rsleep)

    def sleep(dur=0.01):
        """
        Sleep for a certain amount of time and return the duration.
        """
        t = time()

# Generated at 2022-06-22 05:17:58.703108
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random, time
    mw = MonoWorker()
    # too fast
    def f(x=1, y=2):
        time.sleep(random.uniform(0.4, 0.6))
        return x + y
    # submit several too-fast tasks (will be ignored)
    for i in range(5):
        mw.submit(f, 3, i)
    time.sleep(0.2)
    # submit a task (will be ignored)
    mw.submit(f, 2)
    time.sleep(0.2)
    # submit a task (will be accepted)
    mw.submit(f, 3)
    time.sleep(0.2)
    # submit a task (handling of exception differs between python2/3)
    # try:
    #     mw.submit(

# Generated at 2022-06-22 05:18:01.758574
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def raise_exc(exc):
        raise exc

    try:
        MonoWorker()
    except Exception:
        assert False, "Error in class MonoWorker constructor"
    else:
        assert True



# Generated at 2022-06-22 05:18:12.371192
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import concurrent.futures
    from tqdm.contrib.utils import MonoWorker
    from tqdm import tqdm

    mw = MonoWorker()
    n = 10
    result = []

    def submit_task(i):
        if i % 2:
            raise ValueError("err" + repr(i))
        else:
            return i

    def wait_task(i):
        mw.submit(submit_task, i)

    list(tqdm(
        concurrent.futures.ThreadPoolExecutor(max_workers=3).map(
            wait_task, range(n)), total=n))
    assert len(mw.futures) == 0

    for i in range(n):
        mw.submit(submit_task, i)

# Generated at 2022-06-22 05:18:19.522186
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import builtins
    import time
    worker = MonoWorker()
    print('running')
    worker.submit(time.sleep, 1)
    print('waiting')
    worker.submit(time.sleep, 2)  # waits 1s
    print('discarded')
    worker.submit(builtins.print, '\nhello world\n')  # discarded
    print('callback')



# Generated at 2022-06-22 05:18:30.420491
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """MonoWorker: submit(func)"""
    import operator
    import sys
    import time

    result = []
    o = MonoWorker()
    o.submit(time.sleep, 0.1)  # current = 0.1
    o.submit(time.sleep, 0.1)  # current = 0.1
    o.submit(time.sleep, 0.2)  # new = 0.2
    assert operator.eq(list(f.done() for f in o.futures), [False, True])
    o.submit(result.append, 0.1)  # 0.1 is discarded
    o.submit(result.append, 0.2)
    # sleep after all job submissions (should have no effect)
    time.sleep(0.1)

# Generated at 2022-06-22 05:18:36.245660
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    def _test():
        a = MonoWorker()
        a.submit(sleep, 3)
        b = MonoWorker()
        b.submit(sleep, 2)
        c = MonoWorker()
        c.submit(sleep, 1)
        res = c.submit(sleep, 0.1)
        assert not res.done(), res
    return _test

if __name__ == "__main__":
    from ..utils import _test_env
    _test_env.run(None)

# Generated at 2022-06-22 05:18:42.484765
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    inp = [1, 1, 1, 1]
    expected = [2, 4, 1, 1]

    m = MonoWorker()
    for exp in expected:
        m.submit(time.sleep, exp)

    def tm_sleep(*args, **kwargs):
        assert False

    try:
        m.submit(tm_sleep)
        assert False
    except AssertionError:
        assert True

# Generated at 2022-06-22 05:18:51.573104
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from .monitor import Monitor
    def A():
        time.sleep(0.1)
    def B():
        time.sleep(0.5)
    def C():
        time.sleep(1)

    m = Monitor(lambda: time.clock())
    with m, MonoWorker() as p:
        f1 = p.submit(A)
        f2 = p.submit(B)
        m.check(0.1)
        f3 = p.submit(C)

    assert f1.done()
    assert not f2.done()
    assert f3.done()
    assert m.time <= 0.6

# Generated at 2022-06-22 05:19:01.365567
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def blocking_and_count_call(n, s=0.1):
        import time
        time.sleep(s)
        return n

    mw = MonoWorker()
    assert len(mw.futures) == 0, mw.futures

    w0 = mw.submit(blocking_and_count_call, 0)
    assert len(mw.futures) == 1, mw.futures

    w1 = mw.submit(blocking_and_count_call, 1)
    assert len(mw.futures) == 1, mw.futures

    w2 = mw.submit(blocking_and_count_call, 2)
    assert len(mw.futures) == 1, mw.futures

    assert w2.done() is False
   

# Generated at 2022-06-22 05:19:07.811012
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    if __name__ != '__main__':
        return

    def _incr(n):
        """An example of an IO process"""
        time.sleep(1)
        return n + 1

    mw = MonoWorker()
    _f = mw.submit(_incr, 0)  # _f is a Future

    assert 1 == _f.result()

    _f = mw.submit(_incr, 10)
    _g = mw.submit(_incr, 1)

    assert 11 == _f.result()
    assert 2 == _g.result()