

# Generated at 2022-06-22 05:09:20.702573
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    worker = MonoWorker()
    assert worker.pool._max_workers == 1
    assert not worker.futures


# Generated at 2022-06-22 05:09:29.310067
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    def bad():
        raise IOError()

    def good():
        time.sleep(2)

    mw = MonoWorker()
    g1 = mw.submit(good)
    b1 = mw.submit(bad)
    g2 = mw.submit(good)
    b2 = mw.submit(bad)
    g3 = mw.submit(good)
    b3 = mw.submit(bad)
    assert g1.done()
    assert b1.done()
    assert g2.done()
    assert b2.done()
    assert not g3.done()
    assert b3.done()

# Generated at 2022-06-22 05:09:40.676986
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from threading import RLock, Condition

    class Producer(object):
        """Producer class"""
        def __init__(self):
            self.lock = RLock()
            self.cvar = Condition(self.lock)

        def produce(self, msg):
            """produce"""
            with self.lock:
                self.cvar.acquire()
                sleep(2)
                if msg is not None:
                    with open('/dev/null', 'w') as fout:
                        fout.write(msg)
                self.cvar.notify()  # producer produces
                self.cvar.wait()
                self.cvar.release()

    class Consumer(object):
        """Consumer class"""
        def __init__(self, producer):
            self.producer = producer


# Generated at 2022-06-22 05:09:49.020903
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    # Define a worker
    worker = MonoWorker()
    # Define a task to be submitted to the worker
    def task(id, delay=0.2, random_fail=False):
        time.sleep(delay)
        if random_fail and random.random() < 0.4:
            raise Exception('random task {}'.format(id))
        return (id, 'done')
    # Submit tasks simultaneously
    print('Submitting tasks ...')
    for i in range(10):
        worker.submit(task, i, delay=random.random())
    print('Submitted')
    # Access the task results in a while loop
    j = 0
    while True:
        id, state = worker.submit(task, j).result()
        print('Task {}: {}'.format(id, state))

# Generated at 2022-06-22 05:09:51.675325
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    pass

if __name__ == "__main__":
    from doctest import testmod
    testmod()

# Generated at 2022-06-22 05:10:00.333639
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Failed tests may raise AssertionError."""
    import time
    import threading
    m = MonoWorker()

    # test submit ordering
    def wait2secs():
        time.sleep(2)
    m.submit(wait2secs)
    m.submit(wait2secs)
    m.submit(wait2secs)  # test waiting drop
    m.submit(wait2secs)  # test running drop

    # test that running task is not dropped
    def wait4seconds():
        time.sleep(4)
    m.submit(wait4seconds)
    m.submit(wait4seconds)

    # test that waiting task is not dropped (if no running task)
    m.submit(wait2secs)
    time.sleep(1)
    m.submit(wait2secs)
   

# Generated at 2022-06-22 05:10:07.724277
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test MonoWorker class construction."""
    from time import sleep
    from subprocess import check_output

    def waiting_func(x):
        sleep(x)
        return x

    mw = MonoWorker()
    for i in range(3):
        f = mw.submit(waiting_func, 1)

    assert str(f) in check_output(['ps', 'x'])

    sleep(2)
    assert str(f) not in check_output(['ps', 'x'])


if __name__ == "__main__":
    test_MonoWorker()

# Generated at 2022-06-22 05:10:09.519296
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    worker = MonoWorker()
    assert worker.pool
    assert worker.futures
    assert len(worker.futures) == 0



# Generated at 2022-06-22 05:10:18.876315
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    The method `submit` of the class `MonoWorker` supports one running task and
    one waiting task.
    The waiting task is the most recent submitted (others are discarded).
    """
    from time import sleep
    from threading import Lock

    # The function to call in the worker thread.
    def worker_func(sleep_time, lock):
        """Launch a thread which will sleep for a given amount of seconds."""
        with lock:
            tqdm_auto.write("Adding " + str(sleep_time) + "s to sleep")
        sleep(sleep_time)
        with lock:
            tqdm_auto.write("Finished sleeping")

    # Create a thread pool with only one thread.
    mono_worker = MonoWorker()

    # Lock to allow writing without race conditions.
    lock = Lock()

# Generated at 2022-06-22 05:10:27.863803
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    mw = MonoWorker()

    # Test task (1-2 second delay, return exit status)
    def t(e, delay):
        time.sleep(delay)
        return e

    # Wait-Cancel-Wait-Cancel-Wait-Cancel
    def wcwcwc(e, delay):
        mw.submit(t, e, delay)
        time.sleep(delay / 4)
        mw.submit(t, e + 1, delay / 2)
        time.sleep(delay / 4)
        mw.submit(t, e + 2, delay / 2)
        time.sleep(delay / 2)

    # Submit three wait-cancel-wait-cancel-wait-cancel chains concurrently

# Generated at 2022-06-22 05:10:39.047387
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():  # pragma: no cover
    import time
    from multiprocessing import Process
    from multiprocessing import cpu_count

    import tqdm

    def busy_func():
        time.sleep(0.1)

    def run_in_background(status_bar, target, args=(), kwargs=None):
        if kwargs is None:
            kwargs = {}
        process = Process(target=target, args=args, kwargs=kwargs)
        process.start()
        with open(status_bar.file.name, 'w') as status_file:
            while process.is_alive():
                status_bar.update()
                status_file.write(status_bar.desc + '\n')
                status_file.flush()
                time.sleep(status_bar.n)

   

# Generated at 2022-06-22 05:10:48.886198
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    dummy, output = [], []
    def out(*args):
        output.append("".join(map(str, args)))
    def add(i):
        return i + 1
    # single task
    for add_1 in [add] * 1:
        for add_2 in [add] * 1:
            output[:] = []
            mw = MonoWorker()
            a = mw.submit(add_1, 3)
            b = mw.submit(add_2, a.result())
            out(b.result())
            assert output == ["5"]
            output[:] = []
            mw = MonoWorker()
            a = mw.submit(add_1, 4)
            b = mw.submit(add_2, a.result())
            out(b.result())

# Generated at 2022-06-22 05:10:54.261789
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    def test_func(x):
        time.sleep(x)
    mw = MonoWorker()
    f1 = mw.submit(test_func, 1)
    f2 = mw.submit(test_func, 2)
    f3 = mw.submit(test_func, 3)
    f1.result()
    f2.result()
    f3.result()

# Generated at 2022-06-22 05:11:03.516346
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import os
    import multiprocessing
    from queue import Queue

    def wait_until_file_exists(filepath):
        time.sleep(1)
        open(filepath, 'w').close()
    # end of unit test

    # start testing
    os.system("rm -rf /tmp/test_MonoWorker_submit")
    os.system("mkdir /tmp/test_MonoWorker_submit")
    os.chdir("/tmp/test_MonoWorker_submit")

    fname1 = "t1"
    fname2 = "t2"
    fname3 = "t3"
    m = MonoWorker()
    q = Queue()


# Generated at 2022-06-22 05:11:13.091191
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import unittest
    import time

    class TestMonoWorker(unittest.TestCase):
        def setUp(self):
            self.foobar = Foobar()

        def test_two_tasks(self):
            self.assertEqual(len(self.foobar.futures), 0)
            self.foobar.submit(time.sleep, 1)
            self.assertEqual(len(self.foobar.futures), 1)
            self.foobar.submit(time.sleep, 0.5)
            self.assertEqual(len(self.foobar.futures), 1)

        def test_task_overflow(self):
            self.assertEqual(len(self.foobar.futures), 0)

# Generated at 2022-06-22 05:11:18.775099
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from random import random

    def foo():
        sleep(random())  # random sleep
        return "hoi"

    w = MonoWorker()
    for _ in range(10):
        assert w.submit(foo)
    assert w.submit(foo).result() == "hoi"
    for _ in range(10):
        assert w.submit(foo)

# Generated at 2022-06-22 05:11:29.259152
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep

    mw = MonoWorker()
    test = mw.futures.maxlen
    assert test == 2

    mw.submit(sleep, 1)
    assert len(mw.futures) == 1
    mw.submit(sleep, 2)
    assert len(mw.futures) == 1
    mw.submit(sleep, 3)
    assert len(mw.futures) == 1
    mw.submit(sleep, 4)
    assert len(mw.futures) == 1

    mw.submit(sleep, 0)
    assert len(mw.futures) == 1
    mw.submit(sleep, -1)
    assert len(mw.futures) == 1

# Generated at 2022-06-22 05:11:40.937332
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    # init
    running = []
    waiter = []
    done = []

    def check_state(state):
        assert set(running) == state['running']
        assert set(waiter) == state['waiter']
        assert set(done) == state['done']

    def check_order(order):
        for i, id_ in enumerate(order):
            assert done[i].result() == id_
        assert not done[-1].cancelled()

    def submit_waiter(coro_id, wait_time, cancel_id=None, block=False):
        # submit waiter
        if block:
            waiter.append(coro_id)
            yield None

        block_time = wait_time + time.time()

# Generated at 2022-06-22 05:11:51.893278
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    Unit test for constructor of class MonoWorker
    """
    from time import sleep
    from threading import Thread, Event
    from random import randint

    # Define test function
    def test_func(n, exit_flag=None, delay=None):
        """
        Sleep for n seconds.
        """
        tqdm_auto.write('Starting test_func...')
        if exit_flag is not None:
            while not exit_flag.is_set():
                if randint(0,9) == 0:
                    break
                sleep(0.1)

        if delay is not None:
            sleep(delay)

        tqdm_auto.write('Finished test_func.')
        return n


    # Create and use a mono worker
    MonoWorker_test = MonoWorker()
    exit

# Generated at 2022-06-22 05:11:55.267441
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Test `MonoWorker.submit` method.
    """
    import time
    worker = MonoWorker()
    assert worker.submit(time.sleep, 1).done()
    assert not worker.submit(time.sleep, 1).done()

# Generated at 2022-06-22 05:12:10.063991
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from concurrent.futures import Future
    from time import sleep
    from nose.tools import with_setup

    def setup():
        for i in range(3):
            try:
                sleep(.01)  # wait for pending futures to finish
            except RuntimeError:
                pass

    def teardown():
        worker.futures.clear()
        worker.pool.shutdown(wait=True)

    worker = MonoWorker()

    def func(x):
        sleep(.02)
        return x

    @with_setup(setup, teardown)
    def test_submit_three():
        assert len(worker.futures) == 0
        fut1 = worker.submit(func, 1)
        assert isinstance(fut1, Future)
        assert len(worker.futures) == 1
        fut

# Generated at 2022-06-22 05:12:17.892911
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mono = MonoWorker()

    def func(i, t):
        time.sleep(t)
        return i

    for i in range(10):
        mono.submit(func, i, i / 10)
    assert len(mono.futures) == 1
    time.sleep(0.1)
    assert len(mono.futures) == 2
    time.sleep(0.2)
    assert len(mono.futures) == 1
    time.sleep(0.9)
    assert len(mono.futures) == 1

# Generated at 2022-06-22 05:12:23.578191
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import random

    M = MonoWorker()

    def rand_func():
        time.sleep(random.random())

    for i in range(10):
        M.submit(rand_func)
    assert len(M.futures) == 1

if __name__ == '__main__':
    test_MonoWorker()

# Generated at 2022-06-22 05:12:29.476399
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    m = MonoWorker()
    assert m.submit(time.sleep, 0.1)
    assert m.submit(time.sleep, 0.2)
    assert m.submit(time.sleep, 0.3)
    assert m.submit(time.sleep, 0.4)
# Run unit tests
if __name__ == '__main__':
    test_MonoWorker()

# Generated at 2022-06-22 05:12:31.367670
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import threading
    import time

    def f(x):
        time.sleep(x)
        return x * x

    mw = MonoWorker()
    futures = [mw.submit(f, x) for x in [4, 1, 5, 2]]
    time.sleep(6.5)
    for future in futures:
        assert future.done()
        assert future.result() == future.args[0] * future.args[0]

# Generated at 2022-06-22 05:12:40.561420
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import tqdm
    m = MonoWorker()
    m.submit(sleepsum, 1, 1).result()
    with tqdm.tqdm(total=None) as pbar:

        def sum_update(x):
            pbar.update(x)

        for i in range(5):
            m.submit(sleepsum, i, i, callback=sum_update)
            # sleep a bit to allow the task to start
            import time
            time.sleep(0.2)
    m.submit(sleepsum, 1, 2).result()



# Generated at 2022-06-22 05:12:48.279584
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from unittest import TestCase
    from unittest.case import SkipTest

    if tqdm_auto.tqdm.get_lock():
        raise SkipTest
    test_lock = Lock()

    class Tests(TestCase):
        """
        Test that submitted tasks are run in the order they are submitted.
        Tests by submitting a task which calls a function to increment an
        integer and then assert that the integer is at the expected value
        """
        def test_submit(self):
            tqdm_auto.tqdm.set_lock(test_lock)

# Generated at 2022-06-22 05:12:57.666198
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import sys

    def test_fn(x):
        time.sleep(x)
        return x

    if len(sys.argv) > 1:
        test_fn(float(sys.argv[1]))
    else:
        import subprocess

        def subprocess_MonoWorker_test(x):
            p = subprocess.Popen([sys.executable, __file__, str(x)])
            p.communicate()
            assert not p.poll()
    
        mw = MonoWorker()
        mw.submit(subprocess_MonoWorker_test, 1)
        mw.submit(subprocess_MonoWorker_test, 0.1)
        mw.submit(subprocess_MonoWorker_test, 0.5)

# Generated at 2022-06-22 05:12:58.768389
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    MonoWorker()


# vim:set ts=4 sw=4 et:

# Generated at 2022-06-22 05:13:02.333791
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker."""
    mono_worker = MonoWorker()
    assert mono_worker.pool
    assert mono_worker.futures

# Generated at 2022-06-22 05:13:14.755956
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import multiprocessing as mp
    NUM_TEST = 10000
    RAND_SIZE = 20

    def print_random(n):
        for i in range(n):
            time.sleep(random.random() * .01)
            print("test%d_proc%d" % (n, mp.current_process()._identity[0]))
    mw = MonoWorker()
    for i in range(NUM_TEST):
        n = random.randint(1, RAND_SIZE)
        mw.submit(print_random, n)
    time.sleep(1)
    assert len(mw.futures) != 0



# Generated at 2022-06-22 05:13:24.880846
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test if MonoWorker works"""
    from queue import Queue
    from time import sleep

    def someFunc():
        sleep(0.02)

    AC = 0
    for _ in range(10):
        AC = (AC + 1) % 5
        q = Queue()
        for _ in range(5):
            q.put(someFunc)
        monoWorker = MonoWorker()
        for _ in range(AC):
            q.get()()
        while True:
            try:
                monoWorker.submit(q.get(timeout=0.07))
            except:
                break
        assert monoWorker.futures == deque(), \
            "MonoWorker should be empty after all process"

# Generated at 2022-06-22 05:13:36.641439
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Unit test for method submit of class MonoWorker"""
    from time import sleep
    from random import uniform
    worker = MonoWorker()
    sleep(uniform(0.1, 0.5))

    def func(b, sleep_time=0.1):
        """Sleep for sleep_time and return the parameter"""
        sleep(sleep_time)
        return b

    # No task running nor waiting
    worker.submit(func, 1, 0.2)
    assert worker.futures[0].result() == 1
    assert len(worker.futures) == 1

    # Task waiting, and new task submitted
    # -> task waiting is discarded, and new task is waiting
    sleep(uniform(0.1, 0.5))
    worker.submit(func, 2, 0.2)
    assert worker.futures

# Generated at 2022-06-22 05:13:45.908666
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from unittest import TestCase

    class T(TestCase):
        def test(self):
            self.assertEqual(1, 1)

    class F(object):
        def __init__(self, *args, **kwargs):
            sleep(.01)
            self.args = args
            self.kwargs = kwargs

        def __call__(self):
            return self.args, self.kwargs

    mw = MonoWorker()
    for arg in range(3):
        future = mw.submit(F, arg)
        mw.submit(T().test)
        sleep(.05)
        assert future.done()
        args, kwargs = future.result()
        self.assertEqual(arg, args[0])

# Generated at 2022-06-22 05:13:55.774176
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from ..utils import _supports_unicode
    import time
    from .utils import WaitTask

    m = MonoWorker()
    assert len(m.futures) == 0  # assert is empty
    m.submit(WaitTask, 0.1)
    assert len(m.futures) == 1  # assert only one task queued
    m.submit(WaitTask, 0.2)
    assert len(m.futures) == 1  # assert waiting task replaced
    m.submit(WaitTask, 0.3)
    assert len(m.futures) == 1  # assert waiting task replaced
    time.sleep(0.2)
    assert len(m.futures) == 1  # assert first task still running
    m.submit(WaitTask, 0.4)

# Generated at 2022-06-22 05:14:05.572744
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    Tests the `MonoWorker` class by trying to run two dummy threads
    and making sure that only the last one is waiting/running.
    """
    import time
    import random
    import sys

    def crash(val):
        raise ValueError(val)

    def run(val):
        time.sleep(random.random())
        return val

    def dummy():
        mw = MonoWorker()

        # submit a task that will crash, wait for the thread and crash again:
        mw.submit(crash, 42)
        time.sleep(0.001)
        try:
            mw.submit(crash, 42)
        except ValueError:
            pass  # expected
        else:
            raise AssertionError('Crashing thread was not replaced')

        # submit a task that will run, then cancel

# Generated at 2022-06-22 05:14:10.185759
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import multiprocessing as mp
    import random
    import time

    mw = MonoWorker()
    assert mw.pool.__class__.__name__ == 'ThreadPoolExecutor'

    def func():
        time.sleep(random.randrange(1, 3))
        print("From {}: {}".format(mp.current_process().name, "task finished"))

    for i in range(0, 4):
        mw.submit(func)

    time.sleep(5)
    print("End")

# Generated at 2022-06-22 05:14:14.885408
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()
    assert repr(mw.pool) == '<ThreadPoolExecutor (running=0, ' \
                            'concurrent=1)>'
    assert mw.futures.maxlen == 2
    assert not len(mw.futures)



# Generated at 2022-06-22 05:14:25.738946
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Create a MonoWorker object and check that submit function
    works as expected.
    """
    from time import sleep
    from concurrent.futures import ThreadPoolExecutor
    from .workers import MonoWorker

    def runfunc(x):
        sleep(x)
        return x

    mw = MonoWorker()
    for i in range(10):
        mw.submit(runfunc, i)

    # Check that pool has exactly one active task
    assert len(mw.pool._threads) == 1

    # Check that all submitted tasks are completed
    for i in range(10):
        assert i == mw.futures[i].result()


if __name__ == "__main__":
    test_MonoWorker_submit()

# Generated at 2022-06-22 05:14:34.155128
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from itertools import count
    worker = MonoWorker()
    timeout = 0.5
    with tqdm_auto.tqdm(desc="[MonoWorker]", total=timeout,
                        smoothing=0, dynamic_ncols=True) as t:
        for i in count():
            task = worker.submit(sleep, 1)
            while not task.done():
                sleep(0.1)
                t.update(0.1)
            t.set_description("[MonoWorker] ITER #%d" % i)
            if t.n > timeout:
                break

# Generated at 2022-06-22 05:14:55.001777
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    mw = MonoWorker()

    def wait(t, m):
        time.sleep(t)
        return m

    def wait_1():
        fp = mw.submit(wait, 1, 1)
        while (not fp.done()) and (not fp.cancelled()):
            time.sleep(0.01)
        return fp.result()

    def wait_0():
        fp = mw.submit(wait, 0, 0)
        while (not fp.done()) and (not fp.cancelled()):
            time.sleep(0.01)
        return fp.result()

    fp = mw.submit(wait, 0, 0)
    assert fp == wait_1()
    assert wait_0() == 0

# Generated at 2022-06-22 05:15:06.093931
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from .test_concurrent import TestPoolExecutor as test_pool_executor
    pool_executor = TestPoolExecutor()
    mono_worker = MonoWorker()
    print (mono_worker.pool)
    print (mono_worker.pool.__class__)
    print (mono_worker.pool.__doc__)
    print (pool_executor.__doc__)
    print (test_pool_executor.__name__)
    print (test_pool_executor.__module__)
    print (test_pool_executor.__doc__)
    # print (type(i))
    # print (type(type(i)))
    # print (__class__)
    # print (__name__)
    # print (__module__)
    # print (__doc__

# Generated at 2022-06-22 05:15:17.566877
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    # test exceptions
    import tqdm.contrib.concurrency as tcc
    O1 = tcc.MonoWorker()
    O1.submit(eval, '2+2')
    time.sleep(1.1)
    O2 = tcc.MonoWorker()
    O2.submit(eval, '1/0')
    time.sleep(1.1)
    # test replacement
    O3 = tcc.MonoWorker()
    O3.submit(time.sleep, 0.2)
    time.sleep(0.1)
    O3.submit(time.sleep, 0.5)
    time.sleep(0.5)
    # test cancel
    O4 = tcc.MonoWorker()
    O4.submit(time.sleep, 0.1)


# Generated at 2022-06-22 05:15:26.182856
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import os
    import threading
    import time

    def wait(seconds):
        time.sleep(seconds)
        return seconds

    with MonoWorker() as worker:
        t = threading.Thread(target=worker.submit,
                             args=(wait, 1))
        t.start()
        t = threading.Thread(target=worker.submit,
                             args=(wait, 1))
        t.start()
        time.sleep(0.2)
        os.system("tasklist | findstr /C:'python.exe'")

# Generated at 2022-06-22 05:15:35.440643
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    def test_task(i, *args, **kwargs):
        time.sleep(.1)
        return i + 1

    mw = MonoWorker()

    # submit a task
    task0 = mw.submit(test_task, 0)
    assert task0.result() == 1

    # overwrite pending task
    task1 = mw.submit(test_task, 1)
    task1.cancel()

    # submit with other tasks pending
    task2 = mw.submit(test_task, 2)
    task2.cancel()
    task3 = mw.submit(test_task, 3)
    assert task3.result() == 4

    # submit with no tasks pending
    task4 = mw.submit(test_task, 4)
    assert task4.result() == 5

   

# Generated at 2022-06-22 05:15:45.072306
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # pylint: disable=invalid-name
    from time import sleep
    mw = MonoWorker()
    running = mw.submit(sleep, 0.2)
    assert len(mw.futures) == 1  # len=1 as running
    assert mw.futures[-1] == running
    waiting = mw.submit(sleep, 0.2)
    assert len(mw.futures) == 1  # len=1 as waiting
    assert mw.futures[-1] == waiting
    assert waiting.done()  # `running` killed and `waiting` done
    assert running.done()

# Generated at 2022-06-22 05:15:57.366477
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def error_func(a, b):
        return a/b
    def add_func(a, b):
        return a + b
    def sleep_func(a, b):
        import time
        time.sleep(a)
        return a + b

    mw = MonoWorker()
    assert len(mw.futures) == 0
    assert mw.submit(add_func, 1, 1)
    assert len(mw.futures) == 1
    assert mw.submit(add_func, 2, 2)
    assert len(mw.futures) == 1
    assert mw.submit(error_func, 1, 0)
    assert len(mw.futures) == 1
    assert mw.submit(sleep_func, 5, 2)

# Generated at 2022-06-22 05:16:08.156424
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Test task replacement"""
    import time
    monoworker = MonoWorker()
    # submit 1-2
    fut1 = monoworker.submit(time.sleep, 0.1)
    fut2 = monoworker.submit(time.sleep, 0.2)
    # submit 2-1 (should replace 1)
    fut1 = monoworker.submit(time.sleep, 0.1)
    # submit 1-3 (should replace 2, wait 1-2)
    fut3 = monoworker.submit(time.sleep, 0.3)
    # submit 3-2 (should replace 1-2)
    fut2 = monoworker.submit(time.sleep, 0.2)
    # submit 2-4 (should replace 3)

# Generated at 2022-06-22 05:16:15.741020
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import numpy as np
    np.random.seed(0)

    def f(x):
        time.sleep(np.random.rand())
        return x

    mw = MonoWorker()
    run = None
    for y in np.random.rand(10):
        run = mw.submit(f, y)
        print("submitted", run)
        time.sleep(0.2)
        print("running", run, "returned", run.result())
    print("done:", run, "returned", run.result())

# Generated at 2022-06-22 05:16:23.568916
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import sys

    def test(i):
        time.sleep(0.2)
        tqdm_auto.write(str(i))

    mw = MonoWorker()
    mw.submit(test, 0)
    tqdm_auto.write("submitted 0")
    for i in range(1, 11):
        mw.submit(test, i)
        tqdm_auto.write("submitted %d" % i)

if __name__ == "__main__":
    test_MonoWorker_submit()

# Generated at 2022-06-22 05:16:57.540797
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random

    def f(n):
        time.sleep(n)
        return "f({})".format(n)

    mw = MonoWorker()
    # [0, 1)
    rands = [random.random() for _ in range(10)]
    rfuts = [mw.submit(f, r) for r in rands]

    # should be done in rfuts[-1]
    assert rfuts[-1].result() == "f({})".format(rands[-1])

    # should be done in rfuts[-2]
    assert rfuts[-2].result() == "f({})".format(rands[-2])

# Generated at 2022-06-22 05:17:05.173827
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def _waiting_job(fn, arg):
        from time import sleep
        from os.path import exists
        from errno import ENOENT
        sleep(3)  # wait for `_running_job` to finish
        try:
            res = exists(arg)
        except Exception as e:
            if e.errno == ENOENT:  # file not found error
                res = False
            else:  # unknown error
                raise e
        fn(arg, res)

    def _running_job(fn, arg):
        from time import sleep
        from os.path import exists
        sleep(0.01)  # this should be interrupted
        res = exists(arg)
        fn(arg, res)

    class Logger(object):
        """Object that records all calls to its methods."""

# Generated at 2022-06-22 05:17:13.157004
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from os import remove
    from os.path import exists
    from random import random
    from os import listdir
    tempfile = 'test_tempfile.txt'
    def echo(tempfile, i):
        remove(tempfile)
        sleep(max(0.001, random() * 0.1))
        with open(tempfile, 'w'):
            pass
        return i
    mw = MonoWorker()
    mw.submit(echo, tempfile, 0)
    mw.submit(echo, tempfile, 1)
    mw.submit(echo, tempfile, 2)
    mw.submit(echo, tempfile, 3)
    assert exists(tempfile)
    assert mw.futures[0].result() == 3
    remove(tempfile)
    #
   

# Generated at 2022-06-22 05:17:14.028163
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()



# Generated at 2022-06-22 05:17:23.114937
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from .utils import format_sizeof
    import time
    import random
    import sys

    def do_work(v):
        """Simulate some workload"""
        time.sleep(v / 100)
        return v

    def get_random_list_of_strings(size=1024 ** 2):
        alphabet = list(map(str, range(10)))
        return [''.join(str(random.choice(alphabet)) * random.randint(1, 8))
                for _ in range(size)]

    # initialise MonoWorker
    worker = MonoWorker()
    # set up some initial data
    seq = get_random_list_of_strings(size=10)

# Generated at 2022-06-22 05:17:30.385331
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import multiprocessing
    import queue
    from operator import is_
    from time import sleep

    from ..tqdm import trange

    def null(x):
        sleep(0.3)
        return x

    def tqdm_test(i,**kwargs):
        with MonoWorker() as pool:
            with trange(i, **kwargs) as t:
                for j in t:
                    try:
                        t.set_description("Working on {}".format(j), refresh=False)
                        future = pool.submit(null,j)
                        while(not future.done()):
                            sleep(0.1)
                    except queue.Empty:
                        pass
                    finally:
                        yield j

    def imap_test(i):
        for j in range(i):
            yield null(j)



# Generated at 2022-06-22 05:17:38.808190
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import randint

    def rand_task():
        sleep(randint(10, 100) / 10.)
        return randint(10, 100)

    with tqdm_auto.tqdm(total=100) as bar:
        tasks = [bar.add_worker().submit(rand_task) for _ in range(100)]
        while any(not task.done() for task in tasks):
            sleep(1)
            bar.update()
        bar.close()

if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-22 05:17:47.198225
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mw = MonoWorker()

    def run(t):
        time.sleep(t)
        return t

    assert (mw.submit(run, 0.1) is
            mw.submit(run, 0.1))  # equal timeout and results

    mw.submit(run, 0.3)  # discard shorter
    assert len(mw.futures) == 1

    assert mw.submit(run, 0.1) is not mw.submit(run, 0.1)  # unequal results
    assert len(mw.futures) == 2

# Generated at 2022-06-22 05:17:58.944920
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from itertools import product
    from multiprocessing import Process
    from operator import mul

    def _test():
        mw = MonoWorker()
        prod_ranges = [(range(1, i), range(i, 2*i)) for i in [1, 2, 5, 10]]
        prod_ranges = product(*prod_ranges)  # Cartesian product
        for pr in prod_ranges:
            tqdm_auto.write('='*30)
            tqdm_auto.write(pr)

            # Force waiting
            for p in pr:
                for i in p:
                    time.sleep(1)
                    mw.submit(mul, i, 2)

            # Wait for all results

# Generated at 2022-06-22 05:18:07.509438
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from .interactive_python import MonoWorker
    from multiprocessing.pool import ThreadPool
    from multiprocessing import Pool
    from threading import Thread
    from concurrent.futures import ThreadPoolExecutor

    def _test(worker, n=1):
        def task(i):
            time.sleep(0.1)
            return i
        for i in tqdm_auto.trange(n, desc='aaa'):
            future = worker.submit(task, i)
            future.result()

    with ThreadPool(1) as mtp:
        with ThreadPoolExecutor(1) as mtpe:
            _test(MonoWorker())
            _test(MonoWorker())
            _test(MonoWorker())
            _test(MonoWorker(), 100)
            _