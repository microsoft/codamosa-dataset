

# Generated at 2022-06-22 05:09:21.397014
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from multiprocessing import Process
    from sys import executable

    def _task(*args):
        sleep(*args)
        return args

    worker = MonoWorker()

    p = Process(target=executable, args=('-c',
        'from tqdm import tqdm; from tqdm.contrib import MonoWorker; '
        'worker = MonoWorker(); '
        'f = worker.submit(_task, 3); '
        'with tqdm(total=100) as pbar: '
        '    while True: '
        '        try: '
        '            x = f.result(0.1); break '
        '        except Exception: '
        '            pbar.update(10) '
        '    print(x)',
    ))
    p.start()


# Generated at 2022-06-22 05:09:32.100553
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Unit test for method submit of class MonoWorker.
    """
    import time
    import random
    from concurrent.futures.thread import _WorkItem
    from contextlib import contextmanager

    @contextmanager
    def mock_sleep(_):
        yield

    def mock_random():
        return random.random()

    def mock_time():
        return time.time()

    def mock_cancel() -> None:
        pass

    def mock_result() -> _WorkItem:
        return _WorkItem(None, None, None, None)

    # monkey patch
    import sys
    monkey_patch_dict = {
        'time': mock_time,
        'sleep': mock_sleep,
        'random': mock_random,
        'tqdm_auto': tqdm_auto,
    }

# Generated at 2022-06-22 05:09:36.535002
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    Unit test for constructor of class MonoWorker
    """
    worker = MonoWorker()
    assert worker.futures.maxlen == 2
    assert len(worker.futures) == 0


# Generated at 2022-06-22 05:09:46.379077
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    from multiprocessing import Manager, Process, Value
    from concurrent.futures import ThreadPoolExecutor
    from ..utils import _range

    class CustomException(Exception):
        pass

    def f(which, sleep_sec, n):
        time.sleep(sleep_sec)
        if which == 'a':
            raise CustomException()
        for _ in _range(n):
            time.sleep(random.random() / 100.)
            with counter.get_lock():
                counter.value += 1

    m = Manager()
    counter = m.Value('i', 0)
    mw = MonoWorker()

# Generated at 2022-06-22 05:09:47.607790
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    MonoWorker()


# Generated at 2022-06-22 05:09:52.567069
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    # Test without a running task
    if __name__ == "__main__":
        mw = MonoWorker()
        mw.submit(test_MonoWorker)
    # Test with a running task
    mw = MonoWorker()
    mw.submit(mw.submit, test_MonoWorker)

# Generated at 2022-06-22 05:10:00.017961
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import concurrent.futures

    executor = MonoWorker()

    # Load concurrent.futures for Python 2 back-compatibility
    futures = []
    for i in tqdm_auto(range(3), desc="Filling queue"):
        futures.append(executor.submit(time.sleep, 5))
        time.sleep(3)

    for i, f in enumerate(futures, 1):
        assert f.done(), "future {} did not return".format(i)
        print(str(f.exception()) or f.result())


if __name__ == "__main__":
    test_MonoWorker()

# Generated at 2022-06-22 05:10:09.170172
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def worker(x):
        sleep(x)
        return x

    m = MonoWorker()
    assert m.futures == deque([], 2)
    for i in range(4):
        for j in range(4):
            m.submit(worker, 0.2)
            assert len(m.futures) == 1
        sleep(0.21)
        assert len(m.futures) in (0, 1)
        if m.futures:  # clean up
            while not m.futures[0].done():
                sleep(0.001)
            m.futures = deque([], 2)
    for i in range(4):
        m.submit(worker, 0.2)
        sleep(0.1)

# Generated at 2022-06-22 05:10:16.937726
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    # import sys
    # Check execution of multiple tasks (should work)
    import time
    m = MonoWorker()
    for i in range(3):
        m.submit(time.sleep, 0.1)
    m.submit(time.sleep, 0.1).result()
    m.submit(time.sleep, 0.1).result()
    m.submit(time.sleep, 0.1).result()
    # Check exception in thread (should print to stderr)
    # f = m.submit(int, 'd').result()
    # sys.stderr.write(str(f) + '\n')

# Generated at 2022-06-22 05:10:25.012805
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import unittest

    # https://github.com/tqdm/tqdm/issues/644
    class MockFuture(object):
        """Mock of concurrent.futures.Future"""

        def __init__(self, state, exception=None):
            self.state = state
            self.exception = exception
            self.done_callbacks = []

        def add_done_callback(self, callback):
            """Add the callback to the done callback list"""
            self.done_callbacks.append(callback)

        def done(self):
            """Return whether the future is done or not"""
            return self.state >= 1

        def result(self):
            """Return the result"""
            if self.state == 2:
                return "result"

# Generated at 2022-06-22 05:10:33.362347
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mq = MonoWorker()
    # func0110()
    #     mq.submit(func0, 1, 0)
    #         waiting = mq.pool.submit(func0, 1, 0)
    #             func0(1, 0)
    #                 func0(0, 0)
    #                     print(1)
    #                     print(0)
    #                 print(1)
    #             print()
    #         print(1)
    #     print(0)
    # print()
    def func0110():
        mq.submit(func0, 1, 0)
        print(0)

    def func0(i, j):
        # print('func0({}, {})'.format(i, j))
        if i > 0:
            print(i)

# Generated at 2022-06-22 05:10:43.661310
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    import traceback as tb
    from ..utils import write

    def foo(n):
        sleep(random())
        return 'foo {}'.format(n)

    def bar(n):
        sleep(random())
        return 'bar {}'.format(n)

    def baz(n):
        sleep(random())
        return 'baz {}'.format(n)

    def goo(n):
        sleep(random())
        raise RuntimeError('goo {}'.format(n))

    def hoo(n):
        sleep(random())
        raise TypeError('hoo {}'.format(n))

    def poo(n):
        sleep(random())
        1 // 0

    def loo(n):
        sleep(random())

# Generated at 2022-06-22 05:10:54.050491
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def foo(x):
        print('foo', x)
        return x

    def bar(x):
        print('bar', x)
        return x

    def baz(x):
        print('baz', x)
        return x

    # Test
    mw = MonoWorker()

    # first task
    f = mw.submit(foo, 1)
    assert f.result() == 1

    # second task
    g = mw.submit(bar, 2)
    assert g.result() == 2

    # third task
    h = mw.submit(foo, 3)
    assert h.result() == 3

    # fourth task (should cancel the third task, which was waiting)
    i = mw.submit(bar, 4)
    assert i.result() == 4

    # fifth task

# Generated at 2022-06-22 05:11:03.442060
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    def f(x):
        sleep(x)
        return x

    mw = MonoWorker()
    assert len(mw.futures) == 0
    assert mw.pool._work_queue.qsize() == 0

    cf1 = mw.submit(f, 4)
    assert len(mw.futures) == 1
    assert mw.pool._work_queue.qsize() == 1

    cf2 = mw.submit(f, 3)
    assert len(mw.futures) == 2
    assert mw.pool._work_queue.qsize() == 1
    assert cf1.cancel() is False

    cf3 = mw.submit(f, 2)
    assert len(mw.futures) == 1
    assert mw.pool._

# Generated at 2022-06-22 05:11:10.009249
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import random
    import multiprocessing
    from .utils import _cleandoc_

    class _Test(object):
        """Mock class of dict"""
        def __getitem__(self, _):
            time.sleep(random.random() / 1000)
            return None
        def __contains__(self, _):
            return True

    def _verify_len(func):
        """Verify that the second argument is a dict"""
        def wrapper(mw, *args, **kwargs):
            assert isinstance(args[1], _Test)
            func(mw, *args, **kwargs)
        return wrapper


# Generated at 2022-06-22 05:11:15.009098
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import sys
    import random
    from tqdm import trange

    with tqdm_auto.tqdm(total=0, desc="test_worker") as t:
        def runner(x, delay=0.005):
            time.sleep(delay)
            sys.stdout.write(str(x))

        worker = MonoWorker()
        for i in trange(0, 100):
            delay = random.random() * 0.01
            worker.submit(runner, i, delay)
            t.update()
        t.close()


if __name__ == '__main__':
    test_MonoWorker()

# Generated at 2022-06-22 05:11:25.730567
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import concurrent.futures
    import time

    def foo1(n, msg):
        time.sleep(n)
        print(msg)

    def foo2(n, msg):
        time.sleep(n)
        print(msg)
        return msg

    def foo3(n, msg):
        time.sleep(n)
        raise Exception('foo3')

    MW = MonoWorker()
    f = MW.submit(foo1, 1, 'a')
    assert not MW.futures[0].done()
    f = MW.submit(foo2, 1, 'b')
    assert not MW.futures[0].done()
    assert f.result() == 'b'
    assert MW.futures[0].result() == 'b'

# Generated at 2022-06-22 05:11:36.308207
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep

    class DummyError(Exception):
        pass

    def dummy_task(time, val):
        sleep(time)
        return val

    mono = MonoWorker()
    fut0 = mono.submit(dummy_task, 0.1, 0)
    fut1 = mono.submit(dummy_task, 0.2, 1)
    fut2 = mono.submit(dummy_task, 0.3, 2)

    assert fut1.done() is False
    assert fut0.result() == 0
    assert fut1.done() is True
    assert fut1.cancelled() is True
    assert fut2.done() is False
    assert fut2.result() == 2

    fut3 = mono.submit(dummy_task, 0.4, 3)
    assert fut2.done() is True


# Generated at 2022-06-22 05:11:47.791095
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    from concurrent.futures import Future

    # mocking
    def _mock_sleep(secs):
        time.sleep(0.01 + 0.01 * random.random())
        return secs

    def _mock_cancel():
        pass

    def _mock_future():
        return Future()

    ############
    # EXECUTION
    ############

    mw = MonoWorker()

    # submit a few tasks
    mw._pool.submit = _mock_sleep
    mw.submit(1.0)
    mw.submit(2.0)
    mw.submit(3.0)

    # cancel and wait
    mw._futures[0].cancel = _mock_cancel

# Generated at 2022-06-22 05:11:58.920303
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from unittest import TestCase, main
    from time import sleep
    from random import random, shuffle
    from functools import partial

    class Test_MonoWorker(TestCase):
        def test_MonoWorker(self):
            mw = MonoWorker()
            prints = [0]

            def _print(value):
                sleep(random() / 10)
                prints[0] += value

            _f = partial(_print, 1)
            future1 = mw.submit(_f)
            future1.result()
            self.assertEqual(prints[0], 1)

            _f = partial(_print, 2)
            future2 = mw.submit(_f)
            future2.result()
            self.assertEqual(prints[0], 3)

            _f = partial(_print, 3)
           

# Generated at 2022-06-22 05:12:12.900721
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import CancelledError

    def simple_stream(i):
        """A generator that prints a `str(int(i))` and calls `time.sleep(i)`."""
        tqdm_auto.write("{}".format(i))
        time.sleep(i)

    def complex_stream(i):
        """A generator that prints a `str(int(i))` once a second."""
        for j in range(int(i)):
            tqdm_auto.write("{}".format(i))
            time.sleep(1)

    mw = MonoWorker()

    # stream simple_stream(0)
    mw.submit(simple_stream, 0)
    # stream simple_stream(0.5)

# Generated at 2022-06-22 05:12:13.443777
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    MonoWorker()

# Generated at 2022-06-22 05:12:14.548030
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    assert MonoWorker().futures.maxl

# Generated at 2022-06-22 05:12:19.525138
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    try:
        import pytest
        pytest.importorskip("concurrent.futures")
    except ImportError:
        pass
    else:
        monoWorker = MonoWorker()
        monoWorker.submit(lambda s=None: s or "test", "test")

if __name__ == "__main__":
    test_MonoWorker()

# Generated at 2022-06-22 05:12:31.355845
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import randint
    from collections import defaultdict
    from threading import Thread
    from concurrent.futures import ThreadPoolExecutor
    from ..utils import format_sizeof

    class MonoWorkerTest(object):
        def __init__(self, max_n_workers=3):
            self.pool = ThreadPoolExecutor(max_workers=max_n_workers)
            self.worker = MonoWorker()
            self.results = defaultdict(list)

        def submit(self, func, *args, **kwargs):
            """`func(*args, **kwargs)` may replace currently waiting task."""
            future = self.worker.submit(func, *args, **kwargs)
            if future is not None:
                future.add_done_callback(self._results_callback)

       

# Generated at 2022-06-22 05:12:43.143128
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep, time
    from concurrent.futures import TimeoutError

    def func(sleep_secs):
        sleep(sleep_secs)
        return time()

    # Testing with real threading
    mono = MonoWorker()

    tqdm_auto.write("Should print after 0 secs:")
    r1 = mono.submit(func, 0)
    assert r1.result(timeout=2) >= time() - 1E-3
    assert str(r1.exception(timeout=2)) == 'None'

    tqdm_auto.write("Should print after 1 sec:")
    r2 = mono.submit(func, 1)
    assert r2.result(timeout=2) >= time() - 1E-3
    assert str(r2.exception(timeout=2)) == 'None'



# Generated at 2022-06-22 05:12:45.219318
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    MonoWorker()

# Generated at 2022-06-22 05:12:52.790438
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from concurrent.futures import Future
    mw = MonoWorker()

    def func(n):
        time.sleep(n)
        return n

    def test_future_type(f):
        assert isinstance(f, Future)

    test_future_type(mw.submit(func, 1))
    test_future_type(mw.submit(func, 2))
    assert len(mw.futures) == 1
    assert mw.futures[0].result() == 2
    assert len(mw.futures) == 1

# Generated at 2022-06-22 05:13:00.984457
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import unittest
    import sys
    import os
    from contextlib import closing
    from concurrent.futures import ThreadPoolExecutor, as_completed
    import munch
    import pandas as pd
    import pandarallel as pda

    # initialize ETL object
    class ETL(munch.Munch):
        def __init__(self, *args, **kwargs):
            super(ETL, self).__init__(*args, **kwargs)

        def process(self):
            if self.data is None:
                self.data = pd.DataFrame()
            tqdm_auto.write(f"Processing {self.id} with {self.process_type}")
            time.sleep(1)

# Generated at 2022-06-22 05:13:09.746311
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from multiprocessing import cpu_count  # can't parallelise in ThreadPool
    from threading import Thread
    from time import sleep
    from ..utils import make_test_counter

    N = cpu_count()
    counter = make_test_counter()

    def func(i):
        sleep(0.1)
        counter.update(i)
        return i

    def run():
        MonoWorker().submit(func, N - 1)

    threads = [Thread(target=run) for _ in range(N)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    assert counter.count == N  # exactly one task succeeded

# Generated at 2022-06-22 05:13:25.685936
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    class FakeFuture(object):
        def __init__(self, done, result=None):
            self.done = done
            self.exception = None
            self._result = result

        def cancel(self):
            pass

        def result(self):
            if self.exception is not None:
                raise self.exception
            return self._result

    class FakePool(object):
        def __init__(self):
            self.submitted = []

        def submit(self, func, *args, **kwargs):
            self.submitted.append((func, args, kwargs))
            if func(*args, **kwargs) == "exception":
                return FakeFuture(done=True, result=Exception("exception"))
            return FakeFuture(False)

    mw = MonoWorker()
   

# Generated at 2022-06-22 05:13:36.881961
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from subprocess import check_call
    import time

    worker = MonoWorker()
    check_call(['git', 'config', '--global', 'user.email',
                'tqdm.tests@github.com'])
    check_call(['git', 'config', '--global', 'user.name', 'tqdm.tests'])
    check_call(['git', 'config', '--global', 'color.ui', 'false'])

    def cmd():
        import time
        time.sleep(2)
        check_call(['git', 'commit', '-m', 'test'])
        assert open('test').read() == 'test', repr(open('test').read())

    worker.submit(cmd)
    # Submit again just after the first task has finished
    # to test that it doesn't raise an exception

# Generated at 2022-06-22 05:13:46.493544
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import multiprocessing
    from multiprocessing import Process, Event
    from threading import Thread

    def run(stop_event):
        def wait_event(stop_event):
            while True:
                time.sleep(1)
                if stop_event.is_set():
                    break
                #print(stop_event.is_set())

        #c1 = Thread(target=wait_event, args=(stop_event,), name="c1")
        #c1.start()
        #print("Thread started")
        #wait_event(stop_event)
        #c1.join()
        #print("Thread joined")
        wait_event(stop_event)
        #print("Thread exited")


    stop_event = Event()
    #c2 = Process(target=run, args=(stop

# Generated at 2022-06-22 05:13:56.187742
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    class Count(object):
        def __init__(self, name, sleep_time=0.1, cancel_time=1e10):
            self.name = name
            self.sleep_time = sleep_time
            self.cancel_time = cancel_time

        def run(self):
            tqdm_auto.write(self.name)
            sleep(self.sleep_time)

    # test setting `cancel_time`
    a = Count('a', sleep_time=0.3, cancel_time=0.2)
    b = Count('b')
    c = Count('c', sleep_time=0.1)

    p = MonoWorker()

    a_job = p.submit(a.run)
    b_job = p.submit(b.run)
    c_

# Generated at 2022-06-22 05:14:06.085282
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    tqdm_auto.write = print
    tqdm_auto.monitor_interval = 0.5

    def wait_for(x, duration):
        """Wait for 'duration' seconds then return 'x'."""
        time.sleep(duration)
        return x

    def test_1():
        """Run 2 tasks with same duration (1st is not scheduled)."""
        futures = []
        with tqdm_auto.tqdm_gui(range(2)) as t:
            for i in t:
                futures.append(t.mono_worker.submit(wait_for, i, 0.5))
            for future in futures:
                future.result()  # wait for all to complete

    def test_2():
        """Run 3 tasks, 2nd is stopped, 3rd is not scheduled."""
       

# Generated at 2022-06-22 05:14:11.986360
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import string

    def f(n):
        time.sleep(n)
        return n

    mw = MonoWorker()
    mw.submit(f, 0.5)
    mw.submit(f, 0.5)
    mw.submit(f, 0.5)
    assert mw.futures[0].cancel()

    mw = MonoWorker()
    mw.submit(f, 0.5)
    mw.submit(f, 0.5)
    assert mw.futures[0].cancel()
    mw.submit(f, 0.5)
    assert mw.futures[0].cancel()

    mw = MonoWorker()

# Generated at 2022-06-22 05:14:17.125145
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def nop(*args, **kwargs):
        pass
    monoworker = MonoWorker()
    for i in range(4):
        monoworker.submit(nop, i)
    assert monoworker.futures[0].result() == 3
    assert monoworker.futures[1] == None

# Generated at 2022-06-22 05:14:21.640251
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def slow_square(x):
        from time import sleep
        sleep(.001)
        return x ** 2
    mw = MonoWorker()
    for x in range(8):
        mw.submit(slow_square, x)
    for f in mw.futures:
        f.result()

# Generated at 2022-06-22 05:14:29.930716
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from concurrent.futures import ThreadPoolExecutor

    # Prepare
    from time import sleep
    from threading import Thread, Event
    from os import remove
    from sys import stdout as sysstdout
    sysstdout.flush()  # ensure flushing buffer for subprocess
    fname = 'test_MonoWorker_submit.tmp'
    if not hasattr(test_MonoWorker_submit, 'fname_count'):
        test_MonoWorker_submit.fname_count = 0
        try:
            remove(fname)
        except Exception:
            pass
    else:
        test_MonoWorker_submit.fname_count += 1
    fname += str(test_MonoWorker_submit.fname_count)
    done = Event()


# Generated at 2022-06-22 05:14:38.343954
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def action(arg):
        import time
        time.sleep(arg)

    mw = MonoWorker()

    mw.submit(action, 0.5)
    mw.submit(action, 0.5)
    mw.submit(action, 0.5)
    mw.submit(action, 0.5)
    mw.submit(action, 0.5)
    mw.submit(action, 0.5)
    mw.submit(action, 0.5)
    mw.submit(action, 0.5)
    mw.submit(action, 0.5)
    mw.submit(action, 0.5)
    mw.submit(action, 0.5)
    mw.submit(action, 0.5)
    mw.submit(action, 0.5)
    m

# Generated at 2022-06-22 05:14:54.755382
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from subprocess import check_output, CalledProcessError
    from warnings import catch_warnings, simplefilter
    from platform import system

    # noinspection PyUnresolvedReferences
    import __main__ as main
    method = main.test_MonoWorker_submit
    worker = MonoWorker()
    n = 10

    with tqdm_auto.tqdm(total=n, ncols=0) as t:
        for i in range(n):
            i = i + 1000
            t.update()
            sleep(random())
            if random() > 0.5:  # 50% chance that the following task
                # waits for the next iteration
                continue  # `i` won't be updated until next iteration

            # Here: random() <= 0.5, i.e

# Generated at 2022-06-22 05:14:57.449158
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    # Initialize instance of MonoWorker class
    m = MonoWorker()


# Generated at 2022-06-22 05:15:07.507456
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time, sys

    def sleep(duration):
        time.sleep(duration)

    def first_func():
        print('first')
        sleep(1)
        return "first"

    def second_func():
        print('second')
        sleep(1)
        return "second"

    def third_func():
        print('third')
        sleep(1)
        return "third"

    def fourth_func():
        print('fourth')
        sleep(1)
        return "fourth"

    def fifth_func():
        print('fifth')
        sleep(1)
        return "fifth"

    def sixth_func():
        print('sixth')
        sleep(1)
        return "sixth"

    def seventh_func():
        print('seventh')
        sleep(1)
        return "seventh"

# Generated at 2022-06-22 05:15:16.764114
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def sub(i):
        import time, sys
        tqdm_auto.write('sub({}) started'.format(i))
        time.sleep(1)
        sys.stdout.write('sub({}) done'.format(i))
        return 1/i
    w = MonoWorker()
    w.submit(sub, 4)
    w.submit(sub, 3)
    w.submit(sub, 2)
    w.submit(sub, 1)
    res = sum(f.result() for f in w.futures)
    assert res == 1  # all done?

# Generated at 2022-06-22 05:15:23.479778
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def _test(task_running, task_waiting, task_submitted, task_func, task_args,
              task_kwargs):
        """
        Common test function for ``task_running``, ``task_waiting``, and
        ``task_submitted``

        :param task: ``None``, ``False``, or ``True``
        """
        from time import sleep
        from threading import Event
        from ..utils import FormatCustomText

        def _loop(event, n, desc, unit_scale, unit, leave, ncols=80, **kw):
            if task_running is not None:
                assert (not task_running) == event.is_set()
                event.set()
                sleep(0.1)
            if task_running is False:
                raise ValueError('Abort running task')

           

# Generated at 2022-06-22 05:15:32.591150
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def test_func(*args, **kwargs):
        return args[0] + kwargs['add']
    worker = MonoWorker()
    assert len(worker.futures) == 0
    future = worker.submit(test_func, 1, add=2)
    assert len(worker.futures) == 1
    assert future.result() == 3
    future = worker.submit(test_func, 1, add=3)
    assert len(worker.futures) == 1
    assert future.result() == 4
    worker.submit(test_func, 1, add=4)
    assert len(worker.futures) == 1
    future = worker.submit(test_func, 1, add=5)
    assert len(worker.futures) == 1
    assert future.result() == 6

# Generated at 2022-06-22 05:15:34.037879
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()
    assert mw


# Generated at 2022-06-22 05:15:39.216747
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def test_func(n):
        time.sleep(n)
        return n

    m = MonoWorker()
    try:
        futures = [m.submit(test_func, n) for n in [1, 0.5, 0.25, 0.125, 0.0625]]
    except Exception as e:
        tqdm_auto.write(str(e))
    time.sleep(2)
    assert all(f.done() for f in futures)
    assert [f.result() for f in futures] == [1]*len(futures)

# Generated at 2022-06-22 05:15:49.737357
# Unit test for constructor of class MonoWorker

# Generated at 2022-06-22 05:16:01.826282
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def echo(n):
        import time
        time.sleep(1)
        print('echo(%d)' % n)
        return n
    worker = MonoWorker()
    # Test cancellation of waiting task when new task is submitted
    t01 = worker.submit(echo, 0)
    t02 = worker.submit(echo, 1)
    t03 = worker.submit(echo, 2)
    t01.result()
    t02.result()
    t03.result()
    # Test cancellation of running task when new task is submitted
    t10 = worker.submit(echo, 0)
    t11 = worker.submit(echo, 1)
    t12 = worker.submit(echo, 2)
    t12.result()

# Generated at 2022-06-22 05:16:21.537680
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    worker = MonoWorker()
    def test_func(i):
        return i * i
    worker.submit(test_func, 2)
    assert worker.futures[0].result() == 4

# Generated at 2022-06-22 05:16:30.579085
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from ..utils import format_sizeof

    class Dummy:
        def __init__(self):
            self.count = 0
            self.size = 0

    def monoworker_print(msg):
        print(msg)

    def monoworker_sleep_print(dummy, msleep):
        # print('Sleeping {}...'.format(dummy.count))
        sleep(msleep)
        monoworker_print('{} sleep {}'.format(dummy.count, msleep))
        dummy.count += 1
        dummy.size += 1

    def monoworker_sleep_write(dummy, msleep):
        # print('Sleeping {}...'.format(dummy.count))
        sleep(msleep)

# Generated at 2022-06-22 05:16:39.529051
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    def func(sleep_time, *args, **kwargs):
        time.sleep(sleep_time)
        return sleep_time
    mw = MonoWorker()
    assert mw.submit(func, 3)
    assert mw.submit(func, 2)
    assert mw.submit(func, 1)  # this one replaces the 2-second task
    ret = mw.submit(func, 0).result()
    assert ret == 0
    ret = mw.submit(func, 2).result()  # this one is ignored, because 2 is running
    assert ret == 0
    assert mw.submit(func, 3).result() == 3

# Generated at 2022-06-22 05:16:50.762606
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import numpy as np
    from ..utils import format_interval

    def _f(function, sleep, n, x):
        time.sleep(sleep)
        ret = function(x)
        print('{} {}: {}'.format(n, format_interval(sleep), ret))
        return ret

    def _g(x):
        return x * 2

    def _h(x):
        return x

    mw = MonoWorker()
    print('Submitting task 0...')
    t0 = mw.submit(_f, _g, 0.1, 0, 42)
    print('Submitting task 1...')
    t1 = mw.submit(_f, _g, 1, 1, 42)
    print('Holding task 1...')
    time.sleep(0.5)
    print

# Generated at 2022-06-22 05:16:51.711417
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    MonoWorker()
    time.sleep(1.1)
    MonoWorker()
    time.sleep(1.1)

# Generated at 2022-06-22 05:17:00.327454
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import random
    import numpy as np
    mw = MonoWorker()
    # Define a dummy function
    def print_c(i):
        print("Called: "+str(i))
        time.sleep(random.randint(1,3))
        return i
    # Start many tasks
    tasks = []
    for i in range(10):
        tasks.append(mw.submit(print_c, i))
    # Disturb the order of tasks
    np.random.shuffle(tasks)
    # Retrieve the results
    for t in tasks:
        print("Result: "+str(t.result()))
    # Start another task
    mw.submit(print_c, 'last')

if __name__ == '__main__':
    test_MonoWorker()

# Generated at 2022-06-22 05:17:03.210575
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Constructor of class MonoWorker"""
    MonoWorker()


# Generated at 2022-06-22 05:17:12.003556
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range
    from ..utils import _decr_instances

    durations = []
    seen_args = []
    seen_kwargs = []
    tasks = [
        (durations.append, (1,), {}),
        (time.sleep, (2,), {}),
        (durations.append, (3,), {}),
        (durations.append, (4,), {}),
        (durations.append, (5,), {}),
        (durations.append, (6,), {}),
    ]

    mh = MonoWorker()
    for task in tasks:
        mh.submit(*task)

    # assert that all tasks are done

# Generated at 2022-06-22 05:17:18.771341
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import os

    def test_f(n):
        time.sleep(n)
        return '{} {}'.format(os.getpid(), n)

    m = MonoWorker()

    m.submit(test_f, 1.0)
    m.submit(test_f, 2.0)
    time.sleep(1.0)
    m.submit(test_f, 3.0)
    time.sleep(0.5)
    m.submit(test_f, 4.0)
    time.sleep(3.0)

    print(' '.join([f.result() for f in m.futures]))

# Generated at 2022-06-22 05:17:27.373830
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Test MonoWorker.submit()"""
    import time
    import random

    def worker(counter, prog_bar):
        """Sample worker"""
        has_prog_bar = True if prog_bar is not None else False
        try:
            while True:
                if has_prog_bar and prog_bar.n >= counter:
                    break
                time.sleep(counter)
        except tqdm_auto.TqdmKeyboardInterrupt:
            # special case to prevent a `RuntimeError`
            pass

    updater = MonoWorker()
    for i in tqdm_auto.trange(4, desc='Test MonoWorker.submit()'):
        work_count = random.randrange(1, 3)
        for _ in range(work_count):
            updater.submit(worker, i, None)

# Generated at 2022-06-22 05:18:07.019681
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    mono = MonoWorker()
    assert mono.futures.maxlen == 2
    mono.submit(time.sleep, 1) # start runner
    mono.submit(lambda: 'waiting') # start waiting, cancel runner
    assert mono.futures.popleft().result() == 'waiting'
    assert len(mono.futures) == 0

# Generated at 2022-06-22 05:18:18.058416
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from os import system

    class A(MonoWorker):
        def __init__(self, cmd_str):
            super(A, self).__init__()
            self.cmd_str = cmd_str
        def submit(self, text):
            return super(A, self).submit(system, self.cmd_str
                                                + ' ' + text)

    def each_submit_results(a, b, c, d, e, f, g, h, i, j):
        for t in [a, b, c, d, e, f, g, h, i, j]:
            t.result()
            sleep(0.5)


# Generated at 2022-06-22 05:18:29.271424
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test parallel processing."""
    import time
    import random
    worker = MonoWorker()
    def f(n):
        time.sleep(random.random())
        return n**2

    running = worker.submit(f, 1)
    for i in tqdm_auto.tqdm(range(10), 'wait', leave=True):
        time.sleep(.2)
        if running.done():
            break

    assert running.done()
    assert running.result() == 1
    # Now submit new tasks
    results = []
    for i in tqdm_auto.tqdm(range(20), 'submit', leave=True):
        running = worker.submit(f, i)
        results.append(running)

    for running in results:
        assert not running.done()

# Generated at 2022-06-22 05:18:33.775495
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def _test(nthreads):
        mw = MonoWorker()
        assert nthreads == len(mw.pool._threads)
        assert nthreads == len(mw.pool._work_queue)
        assert 0 == len(mw.pool._threads_holding)

    _test(1)

    def _test(nthreads):
        mw = MonoWorker(nthreads)
        assert nthreads == len(mw.pool._threads)
        assert nthreads == len(mw.pool._work_queue)
        assert 0 == len(mw.pool._threads_holding)

    _test(0)
    _test(1)
    _test(10)


# Generated at 2022-06-22 05:18:37.134995
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker"""
    test_obj = MonoWorker()
    assert isinstance(test_obj, MonoWorker)


# Generated at 2022-06-22 05:18:41.585696
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Check that MonoWorker.submit() returns a future"""
    # Arrange
    import time
    import random
    import multiprocessing

    def f(x, y=0):
        time.sleep(random.random() / multiprocessing.cpu_count())
        return x + y

    def g(x):
        time.sleep(random.random() / multiprocessing.cpu_count())
        raise ValueError(x)

    # Act
    a = MonoWorker()
    b = a.submit(f, 1)
    c = a.submit(f, 2, 2)
    d = a.submit(g, 2, 2)

    # Assert
    assert b.done()
    assert b.result() == 1
    assert c.done()
    assert c.result() == 4
    assert d

# Generated at 2022-06-22 05:18:52.861667
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from unittest import main

    def func(n):
        return n

    def test_basic():
        m = MonoWorker()
        m.submit(func, 1)
        m.submit(func, 2)
        m.submit(func, 3)
        m.submit(func, 1)
        assert len(m.futures) == 1
        assert m.futures[0].result() == 1
    test_basic()

    def test_exception():
        m = MonoWorker()
        m.submit(func, 1)
        m.submit(lambda: 1 / 0)
        assert len(m.futures) == 1
        assert m.futures[0].result() == 1
    test_exception()

    if __name__ == "__main__":
        main()

# Generated at 2022-06-22 05:19:02.255207
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from ..utils import format_sizeof

    def test_func(x=0, s=0):
        sleep(s)
        return x
    mw = MonoWorker()
    x0 = mw.submit(test_func, 0, 2)
    x1 = mw.submit(test_func, 1, 4)
    x2 = mw.submit(test_func, 2, 8)
    assert format_sizeof(x0) == "1.00e-06 B"
    assert format_sizeof(x1) == "1.00e-06 B"
    assert format_sizeof(x2) == "1.00e-06 B"
    assert x0.result() == 0
    assert x1.result() == 2
    assert x2.result() == 2

# Generated at 2022-06-22 05:19:09.509331
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def f(n):
        time.sleep(n)
        return n

    mw = MonoWorker()

    assert mw.submit(f, 0.2).result() == 0.2
    assert mw.submit(f, 0.1).result() == 0.1
    assert mw.submit(f, 0.3).result() == 0.3

    assert len(mw.futures) == 1
    assert mw.submit(f, 0.4).result() == 0.4
    assert mw.submit(f, 0.1).result() == 0.1
    assert mw.submit(f, 0.2).result() == 0.2

    assert len(mw.futures) == 1
    assert mw.submit(f, 0.4).result() == 0.4