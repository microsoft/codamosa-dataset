

# Generated at 2022-06-22 05:09:29.010873
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from concurrent.futures import wait
    import time
    from .utils import Timer

    def f(i, delay=0.1):
        time.sleep(delay)
        return i

    mw = MonoWorker()
    with Timer() as timer:
        for i in range(10):
            mw.submit(f, i, delay=0.1)
    print('=' * 70)
    print(timer())

    with Timer() as timer:
        for i in range(10):
            mw.submit(f, i, delay=0.9)
    print('=' * 70)
    print(timer())

    with Timer() as timer:
        for i in range(10):
            mw.submit(f, i, delay=0.1)
    print('=' * 70)
    print

# Generated at 2022-06-22 05:09:40.328359
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from unittest import TestCase

    import requests

    from . import setup_tests

    class TestMonoWorkerSubmit(TestCase):
        def test_MonoWorker_submit(self):
            def infinite_sleep():
                sleep(99999)

            def get_requests():
                return requests.get('https://www.python.org')

            mono_worker = MonoWorker()
            self.assertIsNone(mono_worker.submit(infinite_sleep))

            # after 1 second, the infinite_sleep() process should be killed
            sleep(1)
            self.assertIsNotNone(mono_worker.submit(get_requests))

            # the result is not expected to be None
            res = mono_worker.submit(get_requests).result()
            self.assertIsNotNone

# Generated at 2022-06-22 05:09:46.154326
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    a = MonoWorker()
    assert a.submit(time.sleep, 0.1).done()
    b = a.submit(time.sleep, 0.2)
    assert not b.done()
    assert a.submit(time.sleep, 0.3).cancelled()
    assert not b.done()
    time.sleep(0.4)
    assert b.done()
    assert a.submit(time.sleep, 0.1).done()

# Generated at 2022-06-22 05:09:51.025258
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()
    assert len(mw.futures) == 0
    assert mw.futures.maxlen == 2
    assert not mw.futures.maxlen > len(mw.futures)


# Generated at 2022-06-22 05:09:54.037982
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep

    def func(a, b):
        sleep(a)
        return b

    mw = MonoWorker()
    for i in range(5):
        mw.submit(func, i, i)
    for i in mw.futures:
        print(i.result())

if __name__ == '__main__':
    test_MonoWorker()

# Generated at 2022-06-22 05:10:01.481726
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import randint
    from threading import current_thread

    def foo(bar):
        sleep(randint(1, 10) / 10)
        return current_thread().name + ' ' + bar + 's'

    mw = MonoWorker()
    for i in range(10):
        mw.submit(foo, str(i))
    assert len(mw.futures) == 2
    assert all(f.done() for f in mw.futures)
    assert any(f.cancelled() for f in mw.futures)
    assert not all(f.cancelled() for f in mw.futures)

    results = [f.result() for f in mw.futures if not f.cancelled()]

# Generated at 2022-06-22 05:10:09.495163
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import traceback

    def test_single_submit():
        def foo(*args):
            time.sleep(0.1)
            return args[0] + args[1]
        mw = MonoWorker()
        mw.submit(foo, 1, 2)  # wait
        mw.submit(foo, 3, 4)  # replace waiting
        mw.submit(foo, 5, 6)  # discard

        mw.futures[0].result() == 3
        mw.futures[1].result() == 7  # served

    def test_multi_submit():
        def foo():
            time.sleep(0.1)
            return 1

        mw = MonoWorker()
        mw.submit(foo)  # wait
        mw.submit(foo)  # replace waiting

# Generated at 2022-06-22 05:10:17.849171
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    # test 1: simple run
    def test_print(num):
        sleep(.2)
        print(num)
    MonoWorker().submit(test_print, 1)
    # test 2: replace waiting task
    MonoWorker().submit(test_print, 2)
    MonoWorker().submit(test_print, 3)
    # test 3: replace running task
    MonoWorker().submit(test_print, 4)
    MonoWorker().submit(test_print, 5)
    MonoWorker().submit(test_print, 6)
    # test 4: test waiting task
    MonoWorker().submit(sleep, .5)

# Generated at 2022-06-22 05:10:22.861863
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from sys import exc_info

    # test with wait
    worker = MonoWorker()

    def test_wait(x, wait=1):
        sleep(wait)
        return x

    assert worker.submit(test_wait, 1, wait=3).result() == 1
    assert worker.submit(test_wait, 2, wait=2).result() == 1
    assert worker.submit(test_wait, 3, wait=1).result() == 2
    assert worker.submit(test_wait, 4, wait=0).result() == 3

    # test with error
    d = worker.submit(test_wait, 1, wait=0)


# Generated at 2022-06-22 05:10:30.163151
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time, random
    mw = MonoWorker()
    tt0 = time.time()
    mw.submit(lambda: time.sleep(0.5 * random.random()))
    time.sleep(1)
    assert (time.time() - tt0) < 2, 'First task not executed'
    tt0 = time.time()
    mw.submit(lambda: time.sleep(0.5 * random.random()))
    time.sleep(1)
    assert (time.time() - tt0) < 2, 'Second task not executed'
    tt0 = time.time()
    mw.submit(lambda: time.sleep(1))
    time.sleep(1)
    assert (time.time() - tt0) < 2, 'Third task not executed'

# Generated at 2022-06-22 05:10:39.480608
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    test_list = [MonoWorker(), MonoWorker(), MonoWorker()]
    for test in test_list:
        assert test.pool._max_workers == 1
        assert test.futures.maxlen == 2


# Generated at 2022-06-22 05:10:44.268234
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Unit test for method submit of class MonoWorker"""
    import time

    def func(s):
        time.sleep(s)
        return s

    mw = MonoWorker()

    assert mw.submit(func, 3)
    assert mw.submit(func, 2).result() == 2
# ---


if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-22 05:10:45.214220
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()
    assert mw.futures.maxlen == 2

# Generated at 2022-06-22 05:10:53.509081
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from threading import Event
    from queue import Queue

    def func1(event):
        event.wait()

    def func2(queue):
        queue.get()

    is_timed_out = False
    event = Event()
    queue = Queue()
    mono_worker = MonoWorker()

    try:
        mono_worker.submit(func1, event).result()
    except Exception:
        is_timed_out = True
    mono_worker.submit(func2, queue).result()
    assert is_timed_out is True

# Generated at 2022-06-22 05:11:02.108624
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def f(i):
        import time
        time.sleep(1)
        return i
    import tqdm
    t = MonoWorker()
    t.submit(f, 1)
    t.submit(f, 2)
    t.submit(f, 3)
    t.submit(f, 4)
    t.submit(f, 5)
    t.submit(f, 6)
    t.submit(f, 7)  # running
    while len(t.futures):
        try:
            t.futures.popleft().result()
        except Exception as e:
            t.submit(f, 8)
            t.submit(f, 9)
            tqdm_auto.write(str(e))

# Generated at 2022-06-22 05:11:03.765273
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker"""
    mw = MonoWorker()
    assert (mw.pool is not None)



# Generated at 2022-06-22 05:11:10.226888
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    def f1():
        time.sleep(1.0)
        return 1.0
    def f2():
        time.sleep(0.5)
        return 2.0
    def f3():
        time.sleep(0.25)
        return 3.0
    m = MonoWorker()
    assert m.submit(f1).result() == 1.0
    t0 = time.time()
    m.submit(f2)
    assert m.submit(f3).result() == 3.0
    assert time.time() > t0 + 0.5
    assert time.time() < t0 + 0.75
    assert m.futures[0].result() == 2.0
    time.sleep(1.0)
    assert m.futures[0].result() == 1.0

# Generated at 2022-06-22 05:11:16.202541
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from multiprocessing import Value
    from threading import Lock, Thread
    from unittest import TestCase

    class TestSubmit(TestCase):
        lock = Lock()
        value = Value('i', 0)

        def my_thread(self, n, sleep_duration=0.1):
            with self.lock:
                self.value.value += n


# Generated at 2022-06-22 05:11:26.724766
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test that only one task may run at a time"""
    import time
    mw = MonoWorker()

    def func(duration):
        time.sleep(duration)

    f1 = mw.submit(func, 3)
    f2 = mw.submit(func, 3)
    f3 = mw.submit(func, 3)
    assert f1 is not f2
    assert f2 is not f3
    assert f3 is not f1
    assert f1.done()
    assert f2.done()
    assert f3.done()

    def func(duration):
        time.sleep(duration)
        return 'ok'

    f1 = mw.submit(func, 3)
    f2 = mw.submit(func, 3)
    assert f1 is not f2
    assert f1.done

# Generated at 2022-06-22 05:11:37.396435
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test: Run some concurrent tasks concurrently"""
    import time
    import multiprocessing
    from concurrent.futures import ThreadPoolExecutor as TPE

    def test_fct(x):
        time.sleep(0.2)
        return 2 * x

    with TPE(max_workers=multiprocessing.cpu_count()) as pool:
        monoworker = MonoWorker()
        results = []
        futures = []
        for i in range(20):
            results.append(pool.submit(test_fct, i))
            futures.append(monoworker.submit(test_fct, i))
        for result, future in zip(results, futures):
            print("{} = {} ?".format(result.result(), future.result()))
            assert result.result() == future.result()

# Generated at 2022-06-22 05:11:50.155971
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test for `MonoWorker`"""
    worker = MonoWorker()
    assert not worker.futures

    def dummy(*args, **kwargs):
        pass

    worker.submit(dummy, 1)
    assert len(worker.futures) == 1

    worker.submit(dummy, 2)
    assert len(worker.futures) == 1

    worker.submit(dummy, 3)
    assert len(worker.futures) == 1

    worker.submit(dummy, 4)
    assert len(worker.futures) == 1

    worker.submit(dummy, 5)
    assert len(worker.futures) == 1


if __name__ == "__main__":
    test_MonoWorker()

# Generated at 2022-06-22 05:12:01.469462
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    python -m tqdm.contrib.io.MonoWorker
    """
    import time

    mw = MonoWorker()

    def slow(n, t=1.0):
        time.sleep(t)
        return n

    f1 = mw.submit(slow, 1, t=1000)
    f2 = mw.submit(slow, 2, t=10)
    f3 = mw.submit(slow, 3, t=0)
    assert f1.result() == 2
    assert f2.result() == 3
    assert f3.result() == 3
    f4 = mw.submit(slow, 4, t=100)
    assert f4.result() == 4

if __name__ == "__main__":
    test_MonoWorker()

# Generated at 2022-06-22 05:12:08.208120
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    m = MonoWorker()
    import time
    import random
    import string

    def rand(j):
        time.sleep(random.random() * 4)
        return ''.join(random.sample(string.lowercase, j))

    def test_submit(j):
        fut = m.submit(rand, j)
        assert fut.result() == rand(j)

    for j in range(10):
        test_submit(j)

# Generated at 2022-06-22 05:12:18.086009
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import datetime as dt

    def func1():
        time.sleep(0.5)
        return dt.datetime.now()

    def func2():
        time.sleep(0.5)
        return dt.datetime.now()

    worker = MonoWorker()
    start = dt.datetime.now()
    for i in range(3):
        worker.submit(func1)
        worker.submit(func2)
        time.sleep(0.06)

    assert worker.futures.popleft().result() > start
    assert worker.futures.popleft().result() > start
    assert not worker.futures
    worker.pool.shutdown()



# Generated at 2022-06-22 05:12:28.217461
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from time import time as now
    from random import randint
    from threading import current_thread

    def hard_work(foo):
        sleep(foo)
        return (randint(1, 10), now(), current_thread())

    mw = MonoWorker()
    first = mw.submit(hard_work, 3)
    second = mw.submit(hard_work, 1)
    # first should have been cancelled
    assert first.cancelled()
    # second should finish before 3 seconds
    assert second.result()[1] - now() < 3
    # first should finish after 3 seconds
    assert first.result()[1] - now() > 2

# Generated at 2022-06-22 05:12:35.444454
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def foo(t):
        time.sleep(t)
        return t

    worker = MonoWorker()
    f = worker.submit(foo, .1)
    g = worker.submit(foo, .2)
    assert g.result() == .2
    assert f.done()
    assert f.result() == .1

    # First future should still be available
    assert worker.futures and not worker.futures[0].done()
    assert worker.futures and worker.futures[0].result() == .2

# Generated at 2022-06-22 05:12:46.191242
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from ..utils import _decode_preferred_encoding

    def _(msg):
        return _decode_preferred_encoding(msg)

    def task(seconds):
        sleep(seconds)
        tqdm_auto.write("done: slept for {}s".format(seconds))
        return seconds

    pool = MonoWorker()
    assert pool.futures.maxlen == 2
    assert not len(pool.futures)

    assert pool.submit(task, 2)
    assert len(pool.futures)
    assert not pool.submit(task, 1)
    assert len(pool.futures)

    tqdm_auto.write("submitted tasks, waiting")
    assert len(pool.futures) == pool.futures.maxlen

    # wait


# Generated at 2022-06-22 05:12:55.866183
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from ..utils import format_sizeof
    from ..utils import identity
    from time import sleep
    from random import random
    from itertools import repeat

    mw = MonoWorker()


    def test_func():
        sleep(random())
        return str(int(10 * random()))


    def test_func_exc():
        raise Exception('test exc')


    def test_func_fail():
        sleep(random())
        raise Exception('test fail')


    for i in tqdm_auto(repeat(None, 10), ascii=True):
        mw.submit(test_func)
        sleep(0.001)
        if random() < 0.3:
            mw.submit(test_func_fail)

# Generated at 2022-06-22 05:13:05.155071
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test constructor of class MonoWorker."""
    try:
        from ..utils import _range
        from .monitoring import TqdmSynchronisationWarning  # NOQA
    except (ImportError, RuntimeError):
        return

    def test_func(x):
        """Function to test if MonoWorker works correctly."""
        tqdm_auto.write(str(x), file=open('/dev/null', 'a'))

    mono_worker = MonoWorker()

    # Submit a task
    mono_worker.submit(test_func, 1)

    # Wait the execution of the first task
    while mono_worker.futures[0].running():
        pass

    # Submit a second task and check that the first task is terminated
    mono_worker.submit(test_func, 2)
    assert not mono_worker

# Generated at 2022-06-22 05:13:13.432230
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from sys import stdin

    def _test():
        import sys
        from time import sleep
        from tqdm import tqdm

        for _ in tqdm(range(10), desc='_test 1', leave=True):
            sleep(0.1)
        sys.stdout.write('abc\n')
        sys.stdout.flush()
        for _ in tqdm(range(10), desc='_test 2', leave=True):
            sleep(0.1)
        sys.stdout.write('def\n')
        sys.stdout.flush()

    # Create class instance
    mono = MonoWorker()

    # Start test
    mono.submit(_test)

    # Test waiting
    while mono.futures:
        sleep(0.2)

    # Test auto-

# Generated at 2022-06-22 05:13:30.289786
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    >>> from tqdm.contrib import MonoWorker
    >>> w = MonoWorker()
    >>> w.submit(lambda: 'foo')
    <Future at 0x... state=running>
    >>> w.submit(lambda: 'bar')
    <Future at 0x... state=pending>
    >>> w.submit(lambda: 'foobar')
    <Future at 0x... state=pending>
    >>> w.submit(lambda: 'barfoo')
    <Future at 0x... state=pending>
    >>> w.submit(lambda: 'bar')
    >>> w.submit(lambda: 'foo')
    >>> w.submit(lambda: 'foobar')
    >>> w.submit(lambda: 'barfoo')
    """
    pass

if __name__ == "__main__":
    import doctest

# Generated at 2022-06-22 05:13:38.041319
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    def _sleep_n_return(t, x):
        time.sleep(t)
        return x

    mw = MonoWorker()
    mw.submit(_sleep_n_return, 1, "foo")
    print(mw)  # sanity check: no error
    mw.submit(_sleep_n_return, 2, "bar")
    print(mw)  # sanity check: no error
    assert mw.futures[0].done() == False
    assert mw.futures[1].done() == False
    mw.submit(_sleep_n_return, 3, "baz")
    assert mw.futures[0].done() == True
    assert mw.futures[1].done() == False
    assert mw.futures[1].result()

# Generated at 2022-06-22 05:13:46.830900
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    # Setup
    import time
    l = 0

    def f():
        time.sleep(1)
        global l
        l += 1

    # Test with one task
    m = MonoWorker()
    m.submit(f); time.sleep(0.3)
    assert l == 0
    time.sleep(1); assert l == 1

    # Test with two tasks
    m.submit(f); time.sleep(0.3)
    assert l == 1
    m.submit(f); time.sleep(0.3)
    assert l == 1
    time.sleep(1); assert l == 2
    m.submit(f); time.sleep(0.3)
    assert l == 2
    time.sleep(1); assert l == 3

    # Test with three tasks

# Generated at 2022-06-22 05:13:56.042102
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def hang():
        time.sleep(0.01)

    def die():
        raise RuntimeError()

    def fail_if_alive():
        assert not worker.futures[0].running()

    worker = MonoWorker()
    worker.submit(hang).result()
    worker.submit(die).result()  # die should not stop hang from finishing
    worker.submit(hang).result()
    worker.submit(hang).result()
    worker.submit(hang).result()
    worker.submit(hang).result()
    worker.submit(hang).result().add_done_callback(fail_if_alive)
    worker.submit(die)  # die should not stop hang from finishing


# Generated at 2022-06-22 05:14:05.912178
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import threading
    import sys

    def inc(x, delay=0.1):
        time.sleep(delay)
        return x + 1

    class IncThread(threading.Thread):
        def __init__(self, bar, x, delay=0.1):
            self.x = x
            self.delay = delay
            super(IncThread, self).__init__()
            self.start()
            self.bar = bar

        def run(self):
            time.sleep(self.delay)
            self.x += 1
            self.bar.update()

    n = 3  # should be a multiple of 2
    mw = MonoWorker()
    futures = list()
    bar = tqdm_auto.tqdm(total=n)
    for x in range(n):
        futures

# Generated at 2022-06-22 05:14:15.363787
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    def test_1(event):
        time.sleep(1)
        event.wait()
    def test_2(event):
        time.sleep(1)
        event.wait()
    def test_3(event):
        time.sleep(1)
        event.wait()

    from concurrent.futures import ThreadPoolExecutor
    pool = ThreadPoolExecutor(max_workers=3)

    import threading
    event = threading.Event()
    futures = [pool.submit(test_1, event),
               pool.submit(test_2, event),
               pool.submit(test_3, event)]

    event.set()

    for f in futures:
        f.result()

    # from multiprocessing import Manager
    # manager = Manager()

    # from multiprocessing.d

# Generated at 2022-06-22 05:14:20.440777
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    >>> def func(i):
    ...     return i
    >>> m = MonoWorker()
    >>> m.submit(func, 0)
    >>> m.submit(func, 1)
    >>> m.submit(func, 2)
    >>> m.submit(func, 3)
    >>> assert m.futures[0].result() == 3
    """
    pass

# Generated at 2022-06-22 05:14:29.746797
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import itertools
    import pprint
    from subprocess import Popen, PIPE, STDOUT

    def ff(sleep_sec):
        time.sleep(sleep_sec)
        return sleep_sec

    def pprint_result(futures):
        for future in futures:
            pprint.pprint(future.result())

    mw = MonoWorker()
    for i in range(5):
        mw.submit(ff, i)

    time.sleep(2)
    pprint_result(mw.futures)

    for i in range(5, 10):
        mw.submit(ff, i)

    time.sleep(2)
    pprint_result(mw.futures)


# Generated at 2022-06-22 05:14:38.173917
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from concurrent.futures import Future
    from itertools import chain

    def _sleep_one_second():
        sleep(1)
        return 1

    mono_worker = MonoWorker()
    assert mono_worker.pool.shutdown(wait=False) is None
    assert not mono_worker.futures
    assert mono_worker.submit(_sleep_one_second)
    assert len(mono_worker.futures) == 1
    assert mono_worker.pool.shutdown(wait=False) is None
    assert mono_worker.submit(_sleep_one_second)
    assert len(mono_worker.futures) == 2
    assert mono_worker.submit(_sleep_one_second)
    assert len(mono_worker.futures) == 2

# Generated at 2022-06-22 05:14:45.277419
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    def job(n):
        time.sleep(n)
        tqdm_auto.write("{} finished".format(n))

    worker = MonoWorker()
    worker.submit(job, 2)
    worker.submit(job, 1)  # should be discarded
    worker.submit(job, 3)  # should be replaced
    tqdm_auto.write("submit finish")

# Generated at 2022-06-22 05:15:03.793969
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    def slow(t):
        time.sleep(t)
    def fast(t):
        return t
    mw = MonoWorker()
    mw.submit(slow, 0.5)
    mw.submit(fast, 0.1)
    time.sleep(0.05)
    assert len(mw.futures) == 1
    mw.futures.pop().result()
    mw.submit(fast, 1.0)
    time.sleep(0.1)
    assert len(mw.futures) == 1
    assert mw.futures[0].result() == 1.0

# Generated at 2022-06-22 05:15:10.934111
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from ..utils import _range
    from time import sleep

    def immediate(i):
        sleep(0.5)
        return i

    def slow(*args):
        sleep(2)
        return args

    worker = MonoWorker()
    pbar = tqdm_auto.tqdm(total=3, desc=str(worker))
    for num in _range(3):
        waiter = worker.submit(immediate, num)
        pbar.update()
        pbar.set_description(str(worker))
        waiter.result()

# Generated at 2022-06-22 05:15:13.809379
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from .tests import test_MonoWorker as _test_MonoWorker
    _test_MonoWorker()

# Generated at 2022-06-22 05:15:20.303028
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    M = MonoWorker()

    def f1():
        time.sleep(0.1)
        print("f1")
        return 1
    def f2():
        time.sleep(0.2)
        print("f2")
        return 2
    def f3():
        time.sleep(0.3)
        print("f3")
        return 3

    for i in range(4):
        M.submit(f1)
        M.submit(f2)
        M.submit(f3)

    time.sleep(1)

# Generated at 2022-06-22 05:15:30.521916
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from multiprocessing import Pool, cpu_count
    from random import random
    from time import sleep
    import psutil
    import sys
    try:
        from os import getpid
    except ImportError:
        getpid = lambda: None

    process_cpu_percent = psutil.Process(getpid()).cpu_percent if getpid() else None
    # print('cpu_count', cpu_count())
    # print('process_cpu_percent', process_cpu_percent())
    # print('psutil.Process', psutil.Process(getpid()).cmdline())

    def test_MonoWorker_progress(init=False):
        def test_MonoWorker_progress_inner(a, b, c):
            sleep(a)
            # print('func', a)
            return a


# Generated at 2022-06-22 05:15:32.307381
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    m = MonoWorker()
    assert m.futures.maxlen == 2
    assert len(m.futures) == 0


# Generated at 2022-06-22 05:15:40.355486
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    def print_and_sleep(n):
        print("Printing and sleeping {}".format(n))
        time.sleep(n)
        return n
    mw = MonoWorker()
    # Submit one task
    assert mw.submit(print_and_sleep, 1)
    time.sleep(0.1)
    # Submit another task
    assert mw.submit(print_and_sleep, 2)
    time.sleep(3)
    assert mw.futures[0].result() == 2

# Generated at 2022-06-22 05:15:43.916936
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Run a unit-test of `MonoWorker`'s constructor."""
    import time
    from random import randrange
    from .tqdm import tqdm

    def hello(sec):
        time.sleep(sec)
        return sec

    mw = MonoWorker()
    results = []
    for _ in range(3):
        wait = randrange(5)
        results.append(mw.submit(hello, wait))
        time.sleep(0.25)
    for result in tqdm(results, desc='waiting for results'):
        print(result.result())


# Run a unit-test of `MonoWorker`'s constructor.
if __name__ == '__main__':
    test_MonoWorker()

# Generated at 2022-06-22 05:15:56.136727
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def test_func(a, b, c=4, d=5):
        time.sleep(1)
        return a + b + c + d

    worker = MonoWorker()

    t0 = time.time()
    future_1 = worker.submit(test_func, 1, 2)
    future_2 = worker.submit(test_func, 1, 2, 3)
    future_3 = worker.submit(test_func, 1, 2, d=9)
    future_4 = worker.submit(test_func, 1, 2, d=9)
    print(future_1.result(), future_2.result(),
          future_3.result(), future_4.result())
    print(time.time() - t0)


if __name__ == '__main__':
    test_Mono

# Generated at 2022-06-22 05:16:06.220934
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import unittest

    class Test_MonoWorker_submit(unittest.TestCase):
        def setUp(self):
            self.mw = MonoWorker()

        def test_last_awaiting_task_is_cancelled(self):
            mw = self.mw
            counter = 0
            def count():
                while True:
                    counter += 1

            mw.submit(count)
            mw.submit(count)  # doesn't start while other is running
            time.sleep(.1)  # wait for the first thread to start
            self.assertEqual(counter, 0)
            mw.submit(count)  # starts now!
            time.sleep(.1)  # let it count a little
            self.assertGreaterEqual(counter, 1)

       

# Generated at 2022-06-22 05:16:31.454719
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    random.seed(0)

    # time.sleep => 0.061039 per call
    ACTION_DURATION_BASE = 0.061039

    # init
    mw = MonoWorker()
    future0 = None
    future1 = None

    # not replace running
    future0 = mw.submit(time.sleep, 3 * ACTION_DURATION_BASE)
    time.sleep(ACTION_DURATION_BASE)
    assert future0.running()
    # replace waiting
    future1 = mw.submit(time.sleep, 1 * ACTION_DURATION_BASE)
    time.sleep(ACTION_DURATION_BASE)
    assert future1.running()
    assert future0.running()

    # replace running
    future0 = mw.submit

# Generated at 2022-06-22 05:16:41.173249
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    import concurrent.futures
    import unittest

    M = MonoWorker()

    def dummy_func(*args):
        time.sleep(1)
        return args

    class Test(unittest.TestCase):
        def test_0_func_args(self):
            """Only one task can be running at a time (queue size 1)"""
            start = time.time()
            futures = []
            for i in range(4):
                future = M.submit(dummy_func, i)
                futures.append(future)
            for i in range(4):
                self.assertEqual(i, futures[i].result())
            elapsed = time.time() - start
            self.assertGreater(elapsed, 1)
            self.assertLess(elapsed, 2)

# Generated at 2022-06-22 05:16:49.764698
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from .util import PrintTask

    def test_one_worker():
        task = PrintTask()
        worker = MonoWorker()
        for _ in range(10):
            task.submit(worker)
        worker.pool.shutdown()

    def test_two_workers():
        task = PrintTask()
        worker = MonoWorker()
        for _ in range(5):
            task.submit(worker)
        tqdm_auto.write("\n")
        for _ in range(5):
            task.submit(worker)
        worker.pool.shutdown()

    test_one_worker()
    test_two_workers()

# Generated at 2022-06-22 05:16:55.680463
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    >>> from tqdm.contrib import MonoWorker
    >>> from tqdm import tqdm
    >>> mw = MonoWorker()
    >>> tasks = [mw.submit(sleep, 0.1) for i in range(3)]
    >>> for task in tqdm(tasks):
    ...     print(task.result())
    [########################################] 100%
    2
    """
    pass



# Generated at 2022-06-22 05:17:04.160164
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def func_raise_exception(*args, **kwargs):
        sleep(0.1)
        raise Exception('You should ' + ' '.join(args) + '!')

    import sys
    _stderr = sys.stderr
    sys.stderr = open('/dev/null', 'w', buffering=1)  # disable stderr
    try:
        # case 1: submit a new task
        mw = MonoWorker()
        mw.submit(func_raise_exception, 'test1', 'test2')
        mw.submit(func_raise_exception, 'test3', 'test4')
        result = mw.futures[0].result()
    except Exception as e:
        result = str(e)
    sys.stderr = _

# Generated at 2022-06-22 05:17:07.931878
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def func():
        raise Exception()

    mw = MonoWorker()
    mw.submit(func)
    mw.submit(func)
    mw.submit(func)
    mw.submit(func)
    mw.submit(func)

# Generated at 2022-06-22 05:17:17.870700
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    Unit test for constructor of class MonoWorker
    """
    # Case 1: Succeed with new task
    mono = MonoWorker()
    assert mono.submit(lambda *_: True)

    # Case 2: Fail with new task
    try:
        mono.submit(lambda *_: 1 / 0)
    except ZeroDivisionError:
        tqdm_auto.write("ZeroDivisionError")
    assert not mono.submit(lambda *_: True)

    # Case 3: Succeed with old task
    assert mono.submit(lambda *_: True)
    try:
        mono.submit(lambda *_: 1 / 0)
    except ZeroDivisionError:
        tqdm_auto.write("ZeroDivisionError")
    assert mono.submit(lambda *_: True)

    # Case 4: Fail with

# Generated at 2022-06-22 05:17:23.166163
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from threading import current_thread
    from time import sleep

    def func():
        sleep(1)
        return current_thread()

    pool = MonoWorker()
    for _ in range(4):
        pool.submit(func)
    assert pool.futures[0].result() is not pool.futures[1].result()


if __name__ == "__main__":
    test_MonoWorker()

# Generated at 2022-06-22 05:17:27.268830
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from os import getpid

    def worker():
        tqdm_auto.write(str(getpid()))
        sleep(4.3)

    worker_pool = MonoWorker()
    for i in range(4):
        worker_pool.submit(worker)
        sleep(0.7)


if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-22 05:17:33.191278
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from multiprocessing import Process, Pipe
    from ..utils import _environ_cols_wrapper
    
    environ_cols_wrapper = _environ_cols_wrapper

    def on_bar_update(bar, n=None):
        time.sleep(1)
        bar.n = n
        bar.update()

    def handle_bar_update(pipe, bar, n=None):
        # Simulate child process by resetting the environment variables
        # that are responsible for controlling the tqdm's output
        environ_cols_wrapper(term_width=0,
                             cols=None,
                             unicode=None,
                             file=None)
        # Send output to main process
        pipe = pipe.dup()
        tqdm_auto.set_lock(pipe)



# Generated at 2022-06-22 05:18:02.804576
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    pass


if __name__ == '__main__':
    test_MonoWorker()

# Generated at 2022-06-22 05:18:13.565366
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import collections
    import time
    from threading import Lock
    from tqdm import trange
    from .rs_shell_helpers import _enumerate_writable_drives
    from .rs_shell_helpers import _get_drive_free_space
    from .rs_shell_helpers import _create_file_in_path

    def task(path, size):
        from threading import Lock
        from os import stat
        from os.path import join
        from .rs_shell_helpers import _enumerate_writable_drives
        from .rs_shell_helpers import _create_file_in_path
        _create_file_in_path(join(path, 'test.txt'), size)
        time.sleep(3)


# Generated at 2022-06-22 05:18:17.260544
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    assert MonoWorker()


# Unit test
if __name__ == '__main__':
    test_MonoWorker()

# Generated at 2022-06-22 05:18:28.349375
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    worker = MonoWorker()
    assert worker.pool
    assert worker.futures
    assert len(worker.futures) == 0

    def task1(t):
        time.sleep(t)
        return "1"

    def task2(t):
        time.sleep(t)
        return "2"

    def task3(t):
        time.sleep(t)
        return "3"

    def task4(t):
        time.sleep(t)
        return "4"

    f1 = worker.submit(task1, 1)
    assert len(worker.futures) == 1
    assert f1.result() == "1"

    f2 = worker.submit(task2, 2)
    assert len(worker.futures) == 1
    assert f1.result

# Generated at 2022-06-22 05:18:35.082353
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def sample_func(msg, sleep_time):
        time.sleep(sleep_time)
        tqdm_auto.write(msg)

    w = MonoWorker()
    w.submit(sample_func, "one", 0.1)
    w.submit(sample_func, "two", 0.3)
    w.submit(sample_func, "three", 0.5)
    w.submit(sample_func, "four", 0.7)
    time.sleep(1)

# Generated at 2022-06-22 05:18:45.587047
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import concurrent.futures
    import multiprocessing as mp

    def worker(x, wait):
        time.sleep(wait)
        return x

    with mp.Pool(1) as pool:
        with tqdm_auto.tqdm(total=11) as pbar:
            mono_worker = MonoWorker()

            for i in range(10):
                mono_worker.submit(worker, i, 1)
                pbar.update(1)

            mono_worker.submit(worker, 10, 1)
            pbar.update(1)

            mono_worker.submit(worker, 11, 1)
            pbar.update(1)

            mono_worker.submit(worker, 12, 1)
            pbar.update(1)
            # => 11, 12

            mono_worker.submit

# Generated at 2022-06-22 05:18:47.378642
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    my_worker = MonoWorker()
    assert isinstance(my_worker, MonoWorker)


# Generated at 2022-06-22 05:18:58.560246
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import multiprocessing
    import time

    def f(i):
        time.sleep(1)
        return i

    pool = MonoWorker()
    assert not pool.futures
    pool.submit(f, 1)
    assert len(pool.futures) == 1
    pool.submit(f, 2)
    assert len(pool.futures) == 2
    f1 = pool.futures[0]
    f2 = pool.futures[1]
    assert not f1.done()
    assert not f2.done()
    assert f1.result() == 1
    assert f2.result() == 2
    assert len(pool.futures) == 1
    assert f2.result() == 2
    assert len(pool.futures) == 1
    assert f2.result

# Generated at 2022-06-22 05:19:02.625327
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    Test MonoWorker()
    """
    from concurrent.futures import ThreadPoolExecutor
    from .import asyncio
    from .asyncio import Future

    # Test error detection
    # Test state
    # Test Future
    # Test blocking

# Generated at 2022-06-22 05:19:03.387083
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    worker = MonoWorker()
