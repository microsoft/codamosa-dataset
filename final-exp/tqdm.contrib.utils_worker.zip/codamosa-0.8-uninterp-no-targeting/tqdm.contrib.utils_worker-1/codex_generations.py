

# Generated at 2022-06-22 05:09:17.817344
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    worker = MonoWorker()
    assert worker.pool
    assert worker.futures
    assert len(worker.futures) == 0


# Generated at 2022-06-22 05:09:28.758611
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from nose.tools import assert_equals

    def work():
        time.sleep(2)
        return 42

    mono_worker = MonoWorker()
    f1 = mono_worker.submit(work)
    time.sleep(1)
    f2 = mono_worker.submit(work)
    f3 = mono_worker.submit(work)
    time.sleep(3)
    assert_equals(f2.result(), 42)
    assert_equals(f3.cancelled(), True)

    # Cleanup before exit
    # https://docs.python.org/3/library/concurrent.futures.html#concurrent.futures.Future
    # "If the underlying callable was not able to execute, Future.result() will raise the original exception."
    # Hence, we avoid error messages

# Generated at 2022-06-22 05:09:30.050332
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    # pylint: disable=pointless-statement
    MonoWorker()

# Generated at 2022-06-22 05:09:31.126306
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test MonoWorker constructor"""
    MonoWorker()

# Generated at 2022-06-22 05:09:42.875163
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import operator
    import time

    mw = MonoWorker()

    def h():
        time.sleep(1)
        return 42

    assert mw.submit(operator.add, 1, 1) == 2
    assert mw.submit(h) == 42  # cancels the previous task

    # task that takes a long time
    long_task = mw.submit(h)

    # task that takes a short time
    short_task = mw.submit(operator.add, 1, 1)

    # the long task is still being processed
    assert long_task.result(timeout=0) is None
    # the short task is cancelled
    assert short_task.result(timeout=0) is None
    # the long task is still being processed
    assert long_task.result(timeout=0) is None
    # the long task

# Generated at 2022-06-22 05:09:50.037371
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()
    from concurrent.futures import CancelledError
    try:
        mw.submit(lambda: None)
        print("!")
        mw.submit(lambda: None)
        print("!")
        mw.submit(lambda: None)
        print("!")
    except CancelledError:
        print(".")
    try:
        mw.submit(lambda: 2 / 0)
        print("!")
        mw.submit(lambda: 2 / 0)
        print("!")
        mw.submit(lambda: 2 / 0)
        print("!")
    except ZeroDivisionError:
        print(".")

# Generated at 2022-06-22 05:09:59.665122
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import logging
    logging.basicConfig(filename='test_MonoWorker.log', level=logging.DEBUG)

    def worker(n):
        import time
        logging.debug('%d' % n)
        time.sleep(n)  # wait n seconds
        return n

    # Test 1:
    mw = MonoWorker()
    assert not mw.futures, mw.futures
    assert mw.futures.maxlen == 2, mw.futures
    assert mw.submit(worker, 1) is not None, mw.futures
    assert mw.submit(worker, 2) is not None, mw.futures
    assert len(mw.futures) == mw.futures.maxlen, mw.futures
    assert mw

# Generated at 2022-06-22 05:10:09.110059
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import traceback

    def foo():
        time.sleep(0.1)
        return 1

    def bar():
        time.sleep(0.2)
        return 2

    def zub():
        time.sleep(0.3)
        return 3

    def qux():
        time.sleep(0.4)
        return 4

    def eq(a, b):
        try:
            assert(a == b)
        except Exception:
            traceback.print_exc()

    mw = MonoWorker()

    # [submit foo, wait] -> [submit bar, wait]
    eq(mw.futures, deque([]))
    a = mw.submit(foo)
    eq(mw.futures, deque([a]))

# Generated at 2022-06-22 05:10:17.746190
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from threading import Event
    from time import sleep
    from multiprocessing import cpu_count

    def wait_for(*args, **kwargs):
        sleep(1)

    def check_submit(num, n_max=3, n_pool=None):
        stop_event = Event()
        mw = MonoWorker() if n_pool is None else MonoWorker(n_pool)
        for i in range(num):
            mw.submit(wait_for, stop_event)
        assert len(mw.futures) <= n_max

    check_submit(3)
    check_submit(3, n_max=2)
    check_submit(3, n_pool=cpu_count())

# Generated at 2022-06-22 05:10:22.758461
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    @MonoWorker()
    def _f_no_args():
        time.sleep(1)
        return 'no_args'

    @MonoWorker()
    def _f_args(*args):
        time.sleep(1)
        return args

    # discard if result not done
    assert _f_no_args() == _f_no_args()
    assert _f_args(1) == _f_args(2)
    # cancel waiting and re-insert running if result done
    assert _f_no_args() == _f_no_args()
    assert _f_args(1) == _f_args(2)

    assert _f_args(1).result() == (1,)  # last inserted task
    assert _f_args(2).result() == (2,)  #

# Generated at 2022-06-22 05:10:31.620896
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import itertools

    def test_func(i):  # noqa
        time.sleep(0.1)
        return i

    worker = MonoWorker()
    waitings = [worker.submit(test_func, i) for i in itertools.count()]
    while len(waitings) > 0:
        waitings[0].result()
        waitings.pop(0)

# Generated at 2022-06-22 05:10:40.865980
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from nose.tools import assert_equal
    from random import randrange
    from concurrent.futures import as_completed

    def add(x, y):
        return x + y
    m = MonoWorker()
    results = []
    for _ in range(100):
        x = randrange(100)
        y = randrange(100)
        result = m.submit(add, x, y)
        results.append((result, x, y))
    for result, x, y in results:
        assert_equal(result.result(), x + y)
    results = []
    m = MonoWorker()
    for _ in range(100):
        x = randrange(100)
        y = randrange(100)
        result = m.submit(add, x, y)

# Generated at 2022-06-22 05:10:51.160334
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    Tests the constructor of MonoWorker.
    """
    from multiprocessing import cpu_count
    from .test_async import wait_iter
    import time

    def test_func():
        """
        Returns the time of wait.
        """
        start_time = time.time()
        time.sleep(5)
        return time.time() - start_time

    assert cpu_count() > 1, "Make sure you have more than 1 CPU"

    worker = MonoWorker()
    worker.pool.submit(test_func)
    test_futures = [worker.submit(test_func) for _ in range(2)]

    wait_iter(test_futures)

# Generated at 2022-06-22 05:10:51.939064
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    MonoWorker()


# Generated at 2022-06-22 05:10:58.019025
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test constructor of MonoWorker."""
    from time import sleep
    from multiprocessing.pool import ThreadPool

    def test_submission(job):
        """Helper to test submission"""
        import threading
        sleep(0.1)
        return threading.current_thread().name

    def test_s(s):
        """Helper to test submission"""
        sleep(0.1)
        return s

    with ThreadPool(2) as pool:
        with tqdm_auto.tqdm(total=10) as t:
            with MonoWorker() as mw:
                for i in range(10):
                    # print('submit', 'test_submission', t.total, i)
                    f1 = mw.submit(test_submission, (t.total, i))
                    # print('submit', '

# Generated at 2022-06-22 05:11:07.157586
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from ..std import time
    import sys
    import threading
    sys.stderr.write('Testing MonoWorker class\n')

    def long(x=1):
        time.sleep(0.15)
        return x

    def short(x=1):
        time.sleep(0.05)
        return x

    mw = MonoWorker()
    r1 = mw.submit(long, 2)
    r2 = mw.submit(short, 3)
    r3 = mw.submit(long, 4)
    time.sleep(0.06)
    assert r3.done()
    assert r2.done()
    assert not r1.done()
    assert r3.result() == 4
    assert r2.result() == 3
    assert not r1.done()
    assert r1

# Generated at 2022-06-22 05:11:14.791351
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from threading import Lock
    import time
    import warnings

    # Suppress warnings about exceptions being raised in ThreadPoolExecutor
    # threads.
    # Reference: https://github.com/python/cpython/blob/3.8/Lib/test/test_concurrent_futures.py#L29
    import logging
    logger = logging.getLogger('concurrent.futures')
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.NullHandler())
    logger_thread = logging.getLogger('concurrent.futures.thread')
    logger_thread.setLevel(logging.DEBUG)
    logger_thread.addHandler(logging.NullHandler())
    warnings.simplefilter('ignore', ResourceWarning)


# Generated at 2022-06-22 05:11:19.475966
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    def timeout_func():
        time.sleep(10)

    def timeout_func_2():
        time.sleep(2)
        timeout_func3()

    def timeout_func3():
        time.sleep(2)

    mw = MonoWorker()
    mw.submit(timeout_func)
    mw.submit(timeout_func_2)

# Generated at 2022-06-22 05:11:29.931754
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from .concurrent import try_await
    import time

    dt = 0.25

    def print_nap(n):
        """Sleep for `n*dt` seconds, print and return `n`."""
        try_await(time.sleep(n * dt))
        tqdm_auto.write("{}".format(n))
        return n

    mw = MonoWorker()

    # even
    mw.submit(print_nap, 0)
    mw.submit(print_nap, 1)
    mw.submit(print_nap, 2)
    mw.submit(print_nap, 3)

    if mw.futures[0].result() != 1:
        raise AssertionError("MonoWorker should execute most recent waiting")

# Generated at 2022-06-22 05:11:33.514578
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Checks that the constructor of MonoWorker passes the following tests."""
    worker = MonoWorker()
    assert worker.pool != None
    assert worker.futures != None


# Generated at 2022-06-22 05:11:52.709546
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from unittest.case import TestCase
    import time

    tests = []

    def test_function_name(func):
        """
        Alternative to unittest.FunctionTestCase
        """

        class TestClass(TestCase):
            def runTest(self):
                func(self)

        return type("%s_TestClass" % func.__name__,
                    (TestClass,),
                    dict(__module__='MonoWorker_submit'))

    def test_basic(self):
        t = MonoWorker()

        def runner():
            time.sleep(0.1)
            return "ok"

        ok = t.submit(runner)
        while not ok.done():
            time.sleep(0.05)

# Generated at 2022-06-22 05:12:04.186004
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from concurrent.futures import CancelledError

    # test MonoWorker class with closure
    def func(i):
        sleep(i)
        return "hello_world_" + str(i)

    monoworker = MonoWorker()
    r1 = monoworker.submit(func, 2)
    sleep(1)
    tqdm_auto.write("waiting_task has been submitted...")
    r2 = monoworker.submit(func, 1)
    tqdm_auto.write("running_task has been submitted...")
    sleep(3)
    tqdm_auto.write("running_task finished: " + r2.result())

# Generated at 2022-06-22 05:12:09.419500
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from subprocess import call
    """Testing that constructor works"""
    #print("\n",call([sys.executable, '-c', 'import tqdm.contrib; tqdm.contrib.test()']))
    assert not call([sys.executable, '-c', 'import tqdm.contrib; tqdm.contrib.MonoWorker()'])

# Generated at 2022-06-22 05:12:20.174791
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    import os

    # in-process
    def recursive_call(func, to_call):
        if to_call:
            return func(lambda: recursive_call(func, to_call-1))
        else:
            return os.getpid()

    # out-of-process, but with only one worker
    worker = MonoWorker()
    def worker_call(func):
        return worker.submit(func).result()
    def worker_call_recursive(to_call):
        return recursive_call(worker_call, to_call)

    def assert_pid(pid):
        if pid != os.getpid():
            raise Exception("%d != %d" % (pid, os.getpid()))
    assert_pid(recursive_call(lambda f: f(), 2))
    assert_

# Generated at 2022-06-22 05:12:31.992706
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random

    def _sleep(delay_ms, force=False):
        sleep(delay_ms / 1000.)
        return random()

    def run(io, n=10000, delay_ms=10, force=False):
        mw = MonoWorker()
        with tqdm_auto.tqdm(total=n, unit='delay', unit_scale=True) as pbar:
            for i in range(n):
                future = mw.submit(_sleep, delay_ms, force=force)
                yield future
                pbar.update()

    n = 10000
    delay_ms = 10

    sleep_proc = run(tqdm_auto, n=n, delay_ms=delay_ms)
    for _ in sleep_proc:
        pass

    # Generate an exception in the

# Generated at 2022-06-22 05:12:43.696659
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from os import getpid
    from inspect import getouterframes, currentframe

    def f():
        sleep(1)
        lock.acquire()
        print(getpid(), 'f:', getouterframes(currentframe())[1][3],
              'to_write', to_write.qsize(), 'to_read', to_read.qsize())
        lock.release()
        to_write.append('f')

    def g():
        sleep(1)
        lock.acquire()
        print(getpid(), 'g:', getouterframes(currentframe())[1][3],
              'to_write', to_write.qsize(), 'to_read', to_read.qsize())
        lock.release()
        to_write.append('g')


# Generated at 2022-06-22 05:12:51.140797
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import concurrent.futures
    def test_func(i: int):
        time.sleep(i)
        return i
    m = MonoWorker()
    f1 = m.submit(test_func, 2)
    f2 = m.submit(test_func, 0)
    assert f1.result() == 2
    assert f2.result() == 0


if __name__ == '__main__':
    from . import __main__
    __main__.auto_import()

# Generated at 2022-06-22 05:12:59.739731
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from .timer import Timer
    timer = Timer()

    # create a MonoWorker
    mw = MonoWorker()

    # dummy function to check if it is called
    def dummy_function(arg):
        return arg + 1

    # submit a task
    f1 = mw.submit(dummy_function, 1)
    result1 = f1.result()
    assert result1 == 2

    # submit second task that is too slow
    mw.submit(time.sleep, 3)

    # submit third task that is to be run (2nd task is discarded)
    f3 = mw.submit(dummy_function, 4)
    result3 = f3.result()
    assert result3 == 5

    # make sure that second task is not run
    assert timer.secs() < 2

# Generated at 2022-06-22 05:13:10.274209
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from random import random
    from unittest import TestCase
    worker = MonoWorker()
    logging = []
    def _test_func(random_factor, task_id, t=1):
        logging.append(('start', task_id))
        time.sleep(random_factor * t)
        logging.append(('stop', task_id))
    results = [worker.submit(_test_func, random(), i) for i in range(4)]
    for result in results:
        result.result()
    expected_logging = [('start', 0), ('stop', 0), ('start', 1), ('stop', 1),
                        ('start', 2), ('stop', 2), ('start', 3), ('stop', 3)]
    TestCase().assertEqual(expected_logging, logging)

# Generated at 2022-06-22 05:13:11.318121
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    try:
        MonoWorker()
    except Exception:
        raise


# Generated at 2022-06-22 05:13:28.031956
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from collections import namedtuple
    from concurrent.futures import Future
    import multiprocessing
    # dummy functions
    def nodelay():
        sleep(0)
    def delay_n(n):
        sleep(n * 0.1)
        return n
    # parameters
    Task = namedtuple('Task', ['delay', 'result'])
    nproc = multiprocessing.cpu_count()
    ntask = 5
    nfinish = 2
    # check constructor
    try:
        mw = MonoWorker()
    except Exception as e:
        print(e)
    else:
        assert isinstance(mw.pool, ThreadPoolExecutor)
        assert isinstance(mw.futures, deque)

# Generated at 2022-06-22 05:13:37.439325
# Unit test for constructor of class MonoWorker
def test_MonoWorker():  # pragma: no cover
    import multiprocessing as mp
    import time
    from ..auto import tqdm

    def worker(x):
        time.sleep(0.1)
        return x**2

    def test(worker):
        with tqdm(total=4) as t:
            for i in range(4):
                worker.submit(worker, i)
                t.update()

        with tqdm(total=2) as t:
            for i in range(2):
                worker.submit(worker, i)
                time.sleep(0.3)
                t.update()

    test(MonoWorker())
    mp.set_start_method('spawn')
    test(MonoWorker())
    mp.set_start_method('fork')
    test(MonoWorker())

# Generated at 2022-06-22 05:13:46.758578
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event

    stop = Event()
    mw = MonoWorker()

    def f(timeout, stop):
        e = stop.wait(timeout)
        if e:
            return 'canceled'
        else:
            return 'running'

    assert len(mw.futures) == 0
    # blocking:
    mw.submit(f, 5, stop)
    time.sleep(0.1)
    assert len(mw.futures) == 1
    # non-blocking with "running" discard:
    mw.submit(f, 0.5, stop)
    time.sleep(0.2)
    assert len(mw.futures) == 1
    # blocking:
    mw.submit(f, 0.2, stop)
    time.sleep

# Generated at 2022-06-22 05:13:55.929289
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import functools
    from ..utils import _range

    def run_forever(i):
        for _ in _range(1, -1, -0.01):
            time.sleep(1e-3)
        return i

    with tqdm_auto.tqdm(desc='MonoWorker test', total=2) as t:
        mono = MonoWorker()
        t.update(1)
        r1 = mono.submit(run_forever, 10)
        t.update(1)
        r2 = mono.submit(functools.partial(run_forever, 20))
        assert r1.cancel()
        assert not r2.cancel()
        assert r2.result() == 20

# Generated at 2022-06-22 05:14:03.540345
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from multiprocessing import Process
    from time import sleep

    def test_MonoWorker_process(worker):
        sleep(0.1)
        for i in range(4):
            sleep(0.1 * i)
            worker.submit(sleep, 0.2 * i)
        sleep(1)  # last one will start running
        sleep(3)  # last one will complete

    MonoWorker_process = Process(target=test_MonoWorker_process,
                                 args=(MonoWorker(),))
    MonoWorker_process.start()
    MonoWorker_process.join()

# Generated at 2022-06-22 05:14:05.631575
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def my_task():
        pass

    future_task = MonoWorker().submit(my_task)
    assert (future_task is not None)

# Generated at 2022-06-22 05:14:14.982818
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import sys

    pool = MonoWorker()
    def test_func(a, b, c=3):
        time.sleep(a)
        # sys.stderr.write("%s %s %s\n" % (a, b, c))
    a = pool.submit(test_func, 2, 'A')
    b = pool.submit(test_func, 3, 'B')
    c = pool.submit(test_func, 1, 'C')
    d = pool.submit(test_func, 4, 'D')
    e = pool.submit(test_func, 6, 'E')
    f = pool.submit(test_func, 5, 'F')
    a.result()
    b.result()
    c.result()
    d.result()
    e.result()


# Generated at 2022-06-22 05:14:26.169001
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random

    def worker(sleep_sec=1, return_val=None):
        time.sleep(sleep_sec)
        return return_val

    def test_worker(aWorker=None, num_func_secs=1, num_secs=10):
        with tqdm_auto.tqdm(total=num_secs, desc='MonoWorker') as pbar:
            while pbar.last_print_t <= pbar.total_time:
                aWorker.submit(worker, random.random()/num_func_secs,
                               pbar.last_print_t)
                time.sleep(random.random()/num_func_secs)
                pbar.update(random.random())


# Generated at 2022-06-22 05:14:32.409549
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    worker = MonoWorker()
    ev = Event()
    def task():
        sleep(0.5)
        ev.set()
    worker.submit(task)
    assert(not ev.is_set())
    worker.submit(task)
    assert(not ev.is_set())
    ev.wait(1)
    assert(ev.is_set())

# Generated at 2022-06-22 05:14:40.119508
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Test method submit of class MonoWorker"""
    import time
    import threading
    import multiprocessing
    from multiprocessing import Process

    def _worker_submit(worker, queue, func, duration, args, kwargs):
        for i in tqdm_auto.trange(3, desc='worker'):
            future = worker.submit(func, *args, **kwargs)
            assert (future.running())
            queue.put(future)
            time.sleep(duration)
            future.result()
            assert (not future.running())
            assert (future.done())

    # 1: thread

# Generated at 2022-06-22 05:14:57.946238
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from .mono_tqdm import test_MonoTqdm, test_apply

    def _test_func(x):
        time.sleep(0.1)
        return x**2

    MonoWorker()  # check constructor
    test_apply(_test_func, MonoWorker())  # check submit

    # check submit on many tasks (may help debugging)
    test_MonoTqdm()

# Generated at 2022-06-22 05:15:08.668475
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import sys
    import os
    import time
    import random

    N = 10
    I = 10000
    T = 1
    threads = MonoWorker()
    theanswer = list(range(I))
    random.shuffle(theanswer)

    def stest(n, i, t):
        time.sleep(t)
        assert i == theanswer[int(n)], \
            "FAIL: Expected answer {0} but got {1}".format(theanswer[int(n)], i)
        sys.stdout.write("{0:2} {1}, ".format(n, i))
        sys.stdout.flush()

    sys.stdout.write("\n{0:12}\n".format('STARTING TESTS'))

# Generated at 2022-06-22 05:15:19.685721
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def dummy_task(duration):
        time.sleep(duration)

    mw = MonoWorker()

    dummy_task(3)
    mw.submit(dummy_task, 2)  # no print
    mw.submit(dummy_task, 1)  # no print
    mw.submit(dummy_task, 0)  # no print
    mw.submit(dummy_task, 3)  # 3-2 (1st)
    mw.submit(dummy_task, 2)  # 2-3 (2nd)
    mw.submit(dummy_task, 1)  # 1-2 (3rd)
    mw.submit(dummy_task, 0)  # 0-1 (4th)

    # Cancel 1st future

# Generated at 2022-06-22 05:15:30.482184
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading

    def func1(n):
        time.sleep(n)
        return n

    def func2(n):
        while n > 0:
            time.sleep(0.5)  # race with func3(0.3)
            n -= 0.5

    def func3(n):
        # Expected time: n + 2*0.5 = n + 1 > n
        # Best use case: n = 0.3
        # Otherwise: n = 0, and this function does nothing
        func2(n)
        # Increase the sleep time to make func3 a bit slower than func2.
        # This way, func1 and func3 are submitted to the thread pool at the
        # same time. As func3 takes longer than func1, the result of func3
        # will be printed before the result of

# Generated at 2022-06-22 05:15:31.674482
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test MonoWorker constructor"""
    MonoWorker()



# Generated at 2022-06-22 05:15:43.002041
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from .utils import get_test_data, WorkerTest
    iw, ow, ew = get_test_data()

    def f():
        for i in iw:
            yield i

    def g():
        for i in iw:
            yield (i, i)

    def h():
        for i in iw:
            yield (i, i, i)

    worker = MonoWorker()
    assert worker.futures == deque([], 2)

    worker.submit(WorkerTest, 1, f(), ow, ew)
    assert worker.futures == deque([], 2)

    worker.submit(WorkerTest, 2, g(), ow, ew)
    assert worker.futures == deque([], 2)


# Generated at 2022-06-22 05:15:55.137502
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    mwrk = MonoWorker()

    def sleep():
        time.sleep(.5)

    def sleep_and_print(msg):
        time.sleep(.5)
        tqdm_auto.write(msg)

    func_args = (sleep, sleep_and_print), (None, ('a',), ('b',))
    expect = ("a", "b")

    start_time = time.time()
    for i, (func, args) in enumerate(zip(*func_args)):
        mwrk.submit(func, *args)

    actual = tuple(f.result() for f in mwrk.futures)
    assert actual == expect, actual

    assert time.time() - start_time >= .5, time.time() - start_time

# Generated at 2022-06-22 05:15:58.692425
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test case for MonoWorker constructor"""
    obj = MonoWorker()
    assert len(obj.pool._threads) == 1
    assert obj.futures.maxlen == 2

if __name__ == '__main__':
    test_MonoWorker()

# Generated at 2022-06-22 05:15:59.945757
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker."""
    assert MonoWorker()

# Generated at 2022-06-22 05:16:10.886854
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    from concurrent.futures import Future
    from operator import add

    def test_submit(expected_running, expected_waiting=None,
                    submitted_func=add, submitted_args=(1, 1),
                    submitted_kwargs=None):
        mw = MonoWorker()
        running_arg = random.randint(0, 1000)
        waiting_arg = random.randint(0, 1000)
        submitted_kwargs = submitted_kwargs or {}

        # mock submit
        def mock_submit(func, *args, **kwargs):
            if func is submitted_func and args == submitted_args and \
               kwargs == submitted_kwargs:
                return mock_waiting
            else:
                return mock_running
        mock_running = Future()
        mock_running.set_

# Generated at 2022-06-22 05:16:49.951515
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from threading import current_thread
    from concurrent.futures import ThreadPoolExecutor
    from .ftp import TqdmUpToDateFTPFile

    with TqdmUpToDateFTPFile('localhost', 'user', 'pass', '/', '/').open('w') as f:
        f.write('tqdm')

    def func():
        assert current_thread().daemon

    mw = MonoWorker()
    mw.submit(func)
    mw.submit(func)
    mw.submit(func)
    mw.submit(time.sleep, 0.1)
    mw.submit(time.sleep, 0.1)
    mw.submit(time.sleep, 0.1)
    time.sleep(0.1)


# Generated at 2022-06-22 05:16:57.131772
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import tqdm.contrib

    class ExpectedFailException(Exception):
        pass

    def myfunc():
        time.sleep(.1)
        raise ExpectedFailException("My error message")

    with tqdm.contrib.MonoWorker() as mw:
        with tqdm.tqdm(total=10) as t:
            for i in range(10):
                assert t.total == 10
                mw.submit(myfunc).add_done_callback(t.update)
                time.sleep(.1)

# Generated at 2022-06-22 05:17:04.967313
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from os import path
    from math import pow, ceil
    from random import random, randint, shuffle
    from itertools import chain
    from threading import Thread

    def progress():
        for _ in tqdm_auto.tqdm(range(10)):
            sleep(0.1)

    def exec_time(x):
        sleep(x)

    def random_io_time(r=3):
        return 0.01 + random() * 0.999 + random() * pow(10, -randint(0, r))

    # Get random file size
    random_file_sizes = []
    with open(__file__, 'rb') as f:
        content = f.read()

# Generated at 2022-06-22 05:17:13.070808
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import time
    import timeit
    from random import random

    def do_sleep(duration):
        """
        Sleep for duration sec (to simulate work).
        """
        t0 = time()
        timeit.default_timer()  # sleep() does not use time.time()
        tqdm_auto.sleep(duration)
        tend = time()
        return tend - t0

    mw = MonoWorker()
    durations = [random() for i in range(10)]
    # Submit jobs asynchronously and wait
    futures = [mw.submit(do_sleep, duration) for duration in durations]
    # Check that each task has been executed (and no more!)
    assert all(f.done() for f in futures)

# Generated at 2022-06-22 05:17:22.006799
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Test for class MonoWorker method submit"""
    from multiprocessing import SimpleQueue
    from time import sleep

    def _f_put(q, k):
        q.put(k)  # `tqdm` uses `write` so that the process should be ended

    def _f_sleep(x):
        # sleep(x)
        pass

    def _f_raise(e):
        raise e

    def _f_get(q):
        return q.get()

    q = SimpleQueue()
    mw = MonoWorker()
    assert mw.submit(_f_put, q, 1)
    assert mw.submit(_f_put, q, 1)
    assert mw.submit(_f_put, q, 1)
    assert mw.submit(_f_sleep, 1)
    assert mw

# Generated at 2022-06-22 05:17:29.721055
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from subprocess import Popen, PIPE
    from os import devnull
    import time
    import tempfile
    import random

    # keep old value
    OLD_DEVNULL = tempfile.TemporaryFile()
    try:
        devnull.seek(0)
        OLD_DEVNULL.write(devnull.read())
        devnull.seek(0)
    finally:
        OLD_DEVNULL.seek(0)

    devnull.seek(0)
    devnull.truncate(0)  # clear devnull
    NUM_LINES = 10
    N = 5  # number of processes to run

    #print(">>> Test MonoWorker.submit")
    #print("NOTE: line numbers in stdout are interleaved")
    #print("NOTE: stdout is going to devnull (aka `{}

# Generated at 2022-06-22 05:17:33.795285
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()
    assert mw.futures.maxlen == 2
    assert len(mw.futures) == 0


# Generated at 2022-06-22 05:17:39.894962
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    # TODO: somehow mock or sleep `time.sleep`?
    import time

    def task(duration):
        tqdm_auto.write('starting task')
        time.sleep(duration)
        tqdm_auto.write('done with task')

    mono = MonoWorker()

    for d in range(5):
        mono.submit(task, d)

    # test waiting for the last task
    mono.futures[-1].result()


if __name__ == "__main__":
    test_MonoWorker()

# Generated at 2022-06-22 05:17:51.116038
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def test(func, args, kwargs, exp_results):
        results = []
        mw = MonoWorker()
        for exp_res in exp_results:
            prev = mw.submit(func, *args, **kwargs)
            prev.add_done_callback(lambda f: results.append(f.result()))
            assert prev.done() == (exp_res is None)
        return results

    # Empty
    assert test(None, None, None, []) == []

    # No discard
    assert test(lambda: 1, (), {}, [1]) == [1]

    # Discard
    assert test(lambda: 1, (), {}, [None, 1]) == [None, 1]

    # Discard then execute

# Generated at 2022-06-22 05:18:01.093075
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import time
    from time import sleep

    def wait(n=1, i=None):
        sleep(n)
        return time() - start

    start = time()
    mono = MonoWorker()
    for j in range(5):
        i = mono.submit(wait, 1, i)
        assert i is not None
        assert i.running()
        sleep(.1)
        assert i.done() or i.cancelled()
    assert len(mono.futures) == 1  # only running
    sleep(1.1)
    assert len(mono.futures) == 1
    assert mono.futures[0].done()