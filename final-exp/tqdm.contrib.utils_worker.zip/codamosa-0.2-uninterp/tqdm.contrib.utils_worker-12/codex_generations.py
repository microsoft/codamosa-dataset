

# Generated at 2022-06-18 11:36:30.467592
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up

    def func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in range(10):
        mw.submit(func, i)
        _term_move_up()
        print(i)
        time.sleep(0.01)
    time.sleep(0.2)

# Generated at 2022-06-18 11:36:34.567040
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up

    def f(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in range(10):
        mw.submit(f, i)
    for i in range(10):
        assert mw.futures[0].result() == i
        tqdm_auto.write(_term_move_up() + '\r')

# Generated at 2022-06-18 11:36:38.948270
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Lock
    from concurrent.futures import as_completed

    def func(x, sleep_time=0.1):
        sleep(sleep_time)
        return x

    mw = MonoWorker()
    lock = Lock()
    results = []

    for i in range(10):
        sleep_time = random()
        future = mw.submit(func, i, sleep_time=sleep_time)
        if future is not None:
            results.append(future)

    for future in as_completed(results):
        with lock:
            print(future.result())

# Generated at 2022-06-18 11:36:50.110444
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import TimeoutError

    def wait(t, e):
        e.wait(t)
        return t

    mw = MonoWorker()
    e = Event()
    t0 = time.time()
    f0 = mw.submit(wait, 1, e)
    assert f0.result(0.5) == 1
    assert time.time() - t0 > 0.5
    t0 = time.time()
    f1 = mw.submit(wait, 1, e)
    assert f1.result(0.5) == 1
    assert time.time() - t0 < 0.5
    t0 = time.time()
    f2 = mw.submit(wait, 1, e)

# Generated at 2022-06-18 11:37:00.876845
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    from concurrent.futures import ThreadPoolExecutor

    def test_func(i):
        time.sleep(random.random())
        return i

    def test_func_error(i):
        time.sleep(random.random())
        raise ValueError(i)

    def test_func_cancel(i):
        time.sleep(random.random())
        return i

    def test_func_cancel_error(i):
        time.sleep(random.random())
        raise ValueError(i)

    def test_func_cancel_error_2(i):
        time.sleep(random.random())
        raise ValueError(i)

    def test_func_cancel_error_3(i):
        time.sleep(random.random())
        raise Value

# Generated at 2022-06-18 11:37:12.037773
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from concurrent.futures import as_completed
    from tqdm.contrib.concurrent import MonoWorker

    def func(x):
        sleep(x)
        return x

    mw = MonoWorker()
    lock = Lock()
    with lock:
        futures = [mw.submit(func, x) for x in [1, 2, 3, 4, 5]]
    for future in as_completed(futures):
        with lock:
            tqdm_auto.write(str(future.result()))
    assert len(futures) == 5
    assert futures[0].result() == 5
    assert futures[1].result() == 5
    assert futures[2].result() == 5
    assert futures[3].result() == 5
   

# Generated at 2022-06-18 11:37:23.319141
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event

    def func(x, y, z, e):
        e.wait()
        return x + y + z

    e = Event()
    mw = MonoWorker()
    f1 = mw.submit(func, 1, 2, 3, e)
    f2 = mw.submit(func, 4, 5, 6, e)
    f3 = mw.submit(func, 7, 8, 9, e)
    assert f1.done()
    assert not f2.done()
    assert not f3.done()
    assert f2.result() == 15
    assert f3.result() == 24
    e.set()
    assert f1.result() == 6
    assert f2.result() == 15
    assert f3.result() == 24

# Generated at 2022-06-18 11:37:28.770655
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.05)

    assert len(mw.futures) == 1
    assert mw.futures[0].result() == 9

# Generated at 2022-06-18 11:37:37.800281
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up
    from ..utils import _range

    def _test_func(i):
        time.sleep(0.1)
        return i

    def _test_func_exception(i):
        raise Exception("test exception")

    def _test_func_cancel(i):
        time.sleep(0.1)
        return i

    def _test_func_cancel_exception(i):
        time.sleep(0.1)
        raise Exception("test exception")

    def _test_func_cancel_exception_2(i):
        time.sleep(0.1)
        raise Exception("test exception")

    def _test_func_cancel_exception_3(i):
        time.sleep(0.1)

# Generated at 2022-06-18 11:37:47.670264
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from threading import Event
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def test_submit(self):
            def f(x):
                time.sleep(x)
                return x

            mw = MonoWorker()
            self.assertEqual(len(mw.futures), 0)
            self.assertIsInstance(mw.submit(f, 0.1), Future)
            self.assertEqual(len(mw.futures), 1)
            self.assertIsInstance(mw.submit(f, 0.2), Future)
            self.assertEqual(len(mw.futures), 2)
            self.assertIsInstance(mw.submit(f, 0.3), Future)


# Generated at 2022-06-18 11:37:56.520562
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Lock
    from concurrent.futures import as_completed

    mw = MonoWorker()
    lock = Lock()
    results = []

    def f(i):
        sleep(random())
        with lock:
            results.append(i)

    for i in range(10):
        mw.submit(f, i)

    for future in as_completed(mw.futures):
        future.result()

    assert results == list(range(10))

# Generated at 2022-06-18 11:38:02.770987
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(3):
        mw.submit(func, i)
    time.sleep(0.1)
    assert len(mw.futures) == 1
    time.sleep(1)
    assert len(mw.futures) == 1
    time.sleep(1)
    assert len(mw.futures) == 0

# Generated at 2022-06-18 11:38:10.533706
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from ..utils import _range

    def _test_submit(n, sleep, max_workers, max_len, expected):
        mw = MonoWorker()
        mw.pool = ThreadPoolExecutor(max_workers=max_workers)
        mw.futures = deque([], max_len)
        e = Event()
        e.clear()
        f = Future()
        f.set_result(None)
        mw.futures.append(f)
        for i in _range(n):
            mw.submit(time.sleep, sleep)
            e.wait(sleep + 0.1)
            if len(mw.futures) != expected:
                return False
            e.clear()
       

# Generated at 2022-06-18 11:38:20.425272
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_time
    from ..utils import format_size
    from ..utils import format_speed
    from ..utils import format_eta
    from ..utils import format_size_short
    from ..utils import format_interval_short
    from ..utils import format_time_short
    from ..utils import format_eta_short
    from ..utils import format_sizeof_short
    from ..utils import format_number_short
    from ..utils import format_speed_short
    from ..utils import format_meter_short
    from ..utils import format_time_type
    from ..utils import format_interval_type
    from ..utils import format_size

# Generated at 2022-06-18 11:38:31.500195
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import as_completed

    def foo(x):
        time.sleep(0.1)
        return x

    def bar(x):
        time.sleep(0.1)
        raise Exception('bar')

    def baz(x):
        time.sleep(0.1)
        return x

    def qux(x):
        time.sleep(0.1)
        raise Exception('qux')

    def quux(x):
        time.sleep(0.1)
        return x

    def quuz(x):
        time.sleep(0.1)
        raise Exception('quuz')

    def corge(x):
        time.sleep(0.1)
        return x

    def grault(x):
        time.sleep

# Generated at 2022-06-18 11:38:37.170501
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Lock

    lock = Lock()
    with tqdm_auto.tqdm(total=10) as t:
        def func(i):
            sleep(random())
            with lock:
                t.update(1)
            return i

        mw = MonoWorker()
        for i in range(10):
            mw.submit(func, i)
            sleep(random())

# Generated at 2022-06-18 11:38:46.769304
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from ..utils import _range

    def _sleep(sec):
        time.sleep(sec)
        return sec

    def _test_submit(mw, sleep_secs, expected_secs):
        for sec in sleep_secs:
            mw.submit(_sleep, sec)
        for sec in expected_secs:
            assert mw.futures.popleft().result() == sec

    mw = MonoWorker()
    _test_submit(mw, [0.1, 0.2, 0.3], [0.3])
    _test_submit(mw, [0.1, 0.2, 0.3], [0.3])

# Generated at 2022-06-18 11:38:57.907391
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def test_submit(self):
            def func(x, y, z=1):
                time.sleep(z)
                return x + y

            def func_exception(x, y, z=1):
                time.sleep(z)
                raise Exception('test_exception')

            def func_cancel(x, y, z=1):
                time.sleep(z)
                return x + y

            def func_cancel_exception(x, y, z=1):
                time.sleep(z)
                raise Exception('test_cancel_exception')


# Generated at 2022-06-18 11:39:06.081642
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import as_completed
    from ..utils import _term_move_up

    def wait_for(event):
        event.wait()
        return 'done'

    def wait_for_long(event):
        time.sleep(1)
        event.wait()
        return 'done'

    def wait_for_longer(event):
        time.sleep(2)
        event.wait()
        return 'done'

    def wait_for_longest(event):
        time.sleep(3)
        event.wait()
        return 'done'

    def wait_for_longest_and_cancel(event):
        time.sleep(3)
        event.wait()
        return 'done'


# Generated at 2022-06-18 11:39:13.261294
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    from concurrent.futures import ThreadPoolExecutor
    from ..utils import _range

    def func(x):
        time.sleep(random.random())
        return x

    def test_func(x):
        time.sleep(random.random())
        return x

    def test_func_error(x):
        time.sleep(random.random())
        raise ValueError(x)

    def test_func_cancel(x):
        time.sleep(random.random())
        return x

    def test_func_cancel_error(x):
        time.sleep(random.random())
        raise ValueError(x)

    def test_func_cancel_error_2(x):
        time.sleep(random.random())
        raise ValueError(x)



# Generated at 2022-06-18 11:39:26.748778
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event

    def wait(duration, event):
        event.wait(duration)
        return duration

    def wait_and_cancel(duration, event):
        event.wait(duration)
        return duration

    def wait_and_raise(duration, event):
        event.wait(duration)
        raise Exception("{}".format(duration))

    def test_submit(func, duration):
        event = Event()
        worker = MonoWorker()
        future = worker.submit(func, duration, event)
        assert future.result() == duration
        assert len(worker.futures) == 1
        assert worker.futures[0] is future

    def test_submit_cancel(func, duration):
        event = Event()
        worker = MonoWorker()
        future = worker.submit

# Generated at 2022-06-18 11:39:34.146413
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from ..utils import _range

    def func(i):
        time.sleep(0.5)
        return i

    def test_submit(i):
        mw.submit(func, i)

    mw = MonoWorker()
    for i in _range(10):
        test_submit(i)
        time.sleep(0.1)
    assert len(mw.futures) == 1
    assert isinstance(mw.futures[0], Future)
    assert mw.futures[0].result() == 9

# Generated at 2022-06-18 11:39:42.004679
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future

    def func(x, y, z):
        time.sleep(x)
        return y + z

    def func_exception(x, y, z):
        raise Exception("test")

    def func_cancel(x, y, z):
        time.sleep(x)
        return y + z

    def func_cancel_exception(x, y, z):
        time.sleep(x)
        raise Exception("test")

    def func_cancel_exception_2(x, y, z):
        time.sleep(x)
        raise Exception("test")

    def func_cancel_exception_3(x, y, z):
        time.sleep(x)
        raise Exception("test")


# Generated at 2022-06-18 11:39:47.826336
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
    for i in _range(10):
        mw.submit(f, i)
    for i in _range(10):
        mw.submit(f, i)
    for i in _range(10):
        mw.submit(f, i)
    for i in _range(10):
        mw.submit(f, i)
    for i in _range(10):
        mw.submit(f, i)
    for i in _range(10):
        mw.submit(f, i)
    for i in _range(10):
        m

# Generated at 2022-06-18 11:39:59.671087
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from .utils import _range

    def _test_submit(n, sleep_time, max_workers, max_futures,
                     expected_output, expected_exception):
        """
        Test `MonoWorker.submit` with `n` tasks, each sleeping for
        `sleep_time` seconds.
        """
        def _func(i):
            time.sleep(sleep_time)
            return i

        mw = MonoWorker()
        mw.pool = ThreadPoolExecutor(max_workers=max_workers)
        mw.futures = deque([], max_futures)
        output = []
        exception = None

# Generated at 2022-06-18 11:40:09.476374
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import as_completed

    def wait_and_return(n, e):
        e.wait()
        return n

    def wait_and_return_with_exception(n, e):
        e.wait()
        raise Exception(n)

    def test_submit(f, e, n=10):
        mw = MonoWorker()
        futures = [mw.submit(f, i, e) for i in range(n)]
        for i in range(n):
            e.set()
            e.clear()
        for future in as_completed(futures):
            assert future.result() == n - 1

    def test_submit_with_exception(f, e, n=10):
        mw = MonoWorker()

# Generated at 2022-06-18 11:40:15.932886
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    mw.submit(f, 1)
    mw.submit(f, 2)
    mw.submit(f, 3)
    mw.submit(f, 4)
    mw.submit(f, 5)
    mw.submit(f, 6)
    mw.submit(f, 7)
    mw.submit(f, 8)
    mw.submit(f, 9)
    mw.submit(f, 10)
    mw.submit(f, 11)
    mw.submit(f, 12)
    mw.submit(f, 13)
    mw.submit(f, 14)
   

# Generated at 2022-06-18 11:40:22.862855
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    from concurrent.futures import as_completed

    def _test_func(x):
        time.sleep(random.random() / 10)
        return x

    mw = MonoWorker()
    futs = []
    for i in range(10):
        futs.append(mw.submit(_test_func, i))
    for fut in as_completed(futs):
        assert fut.result() == 9

# Generated at 2022-06-18 11:40:32.722294
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    mw.submit(func, 1)
    mw.submit(func, 2)
    mw.submit(func, 3)
    mw.submit(func, 4)
    mw.submit(func, 5)
    mw.submit(func, 6)
    mw.submit(func, 7)
    mw.submit(func, 8)
    mw.submit(func, 9)
    mw.submit(func, 10)
    mw.submit(func, 11)
    mw.submit(func, 12)
    mw.submit(func, 13)
    mw.submit(func, 14)
   

# Generated at 2022-06-18 11:40:39.425388
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import TimeoutError
    from ..utils import _range

    def test_func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(5):
        mw.submit(test_func, i)
        time.sleep(0.05)

    for i in _range(5):
        try:
            assert mw.futures[i].result(timeout=0.2) == i
        except TimeoutError:
            assert i == 0
        except Exception as e:
            tqdm_auto.write(str(e))
            assert False

# Generated at 2022-06-18 11:40:51.643324
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
    assert mw.futures[0].result() == 9
    assert len(mw.futures) == 1

# Generated at 2022-06-18 11:40:56.834269
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event

    def wait_for_event(event, timeout=None):
        event.wait(timeout)
        return event.is_set()

    def wait_for_event_with_timeout(event, timeout=None):
        return wait_for_event(event, timeout)

    def wait_for_event_without_timeout(event, timeout=None):
        return wait_for_event(event)

    event = Event()
    worker = MonoWorker()

    # submit a task that will wait for an event
    future = worker.submit(wait_for_event_with_timeout, event)
    assert not future.done()

    # submit another task that will wait for an event, but with a timeout
    future = worker.submit(wait_for_event_without_timeout, event)
   

# Generated at 2022-06-18 11:41:05.053044
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(1)
        return x

    def test_func(x):
        time.sleep(1)
        raise Exception('test_func')

    mw = MonoWorker()
    for i in _range(5):
        mw.submit(func, i)
    for i in _range(5):
        mw.submit(test_func, i)
    for i in _range(5):
        mw.submit(func, i)
    for i in _range(5):
        mw.submit(test_func, i)
    for i in _range(5):
        mw.submit(func, i)
    for i in _range(5):
        mw.submit(test_func, i)
   

# Generated at 2022-06-18 11:41:12.847379
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Lock
    from concurrent.futures import as_completed
    from tqdm import tqdm

    def func(x, y, z, sleep_time=0.1, lock=None):
        if lock:
            lock.acquire()
        sleep(sleep_time)
        if lock:
            lock.release()
        return x + y + z

    lock = Lock()
    mw = MonoWorker()
    with tqdm(total=100) as t:
        futures = [mw.submit(func, i, i, i, random(), lock)
                   for i in range(100)]
        for future in as_completed(futures):
            t.update()
            assert future.result() == 3 * future.args[0]

# Generated at 2022-06-18 11:41:19.415030
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter

    def _test_MonoWorker_submit(n_tasks, n_workers, n_bytes, n_seconds):
        def _test_MonoWorker_submit_task(n_bytes, n_seconds):
            time.sleep(n_seconds)
            return n_bytes

        def _test_MonoWorker_submit_task_error(n_bytes, n_seconds):
            time.sleep(n_seconds)
            raise Exception("Error")

        def _test_MonoWorker_submit_task_cancel(n_bytes, n_seconds, event):
            time.sleep(n_seconds)


# Generated at 2022-06-18 11:41:23.452286
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
        time.sleep(0.01)

# Generated at 2022-06-18 11:41:31.955260
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Thread
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def test_submit(self):
            def func(x):
                sleep(x)
                return x

            mw = MonoWorker()
            self.assertEqual(len(mw.futures), 0)
            mw.submit(func, 0.1)
            self.assertEqual(len(mw.futures), 1)
            mw.submit(func, 0.2)
            self.assertEqual(len(mw.futures), 1)
            mw.submit(func, 0.3)
            self.assertEqual(len(mw.futures), 1)
            mw.submit(func, 0.4)
            self

# Generated at 2022-06-18 11:41:36.534102
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from .utils import _range

    def f(x):
        time.sleep(0.01)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
    time.sleep(0.1)
    assert len(mw.futures) == 1
    assert mw.futures[0].result() == 9

# Generated at 2022-06-18 11:41:45.770822
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import Future

    def func(x, y, z):
        sleep(z)
        return x + y

    def test_func(x, y, z):
        sleep(z)
        return x + y

    def test_func_exception(x, y, z):
        raise Exception("test_func_exception")

    def test_func_cancel(x, y, z):
        sleep(z)
        return x + y

    def test_func_cancel_exception(x, y, z):
        raise Exception("test_func_cancel_exception")

    def test_func_cancel_exception_2(x, y, z):
        raise Exception("test_func_cancel_exception_2")



# Generated at 2022-06-18 11:41:50.105058
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import as_completed
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    futures = [mw.submit(f, x) for x in _range(3)]
    for future in as_completed(futures):
        assert future.result() == 2

# Generated at 2022-06-18 11:42:07.868795
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)
    time.sleep(1)

# Generated at 2022-06-18 11:42:17.700413
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from threading import Event

    def func(x, y, z):
        time.sleep(z)
        return x + y

    def test_func(x, y, z):
        assert isinstance(x, int)
        assert isinstance(y, int)
        assert isinstance(z, float)
        return x + y

    def test_func_exception(x, y, z):
        raise Exception("test_func_exception")

    def test_func_cancel(x, y, z):
        time.sleep(z)
        return x + y

    def test_func_cancel_exception(x, y, z):
        time.sleep(z)
        raise Exception("test_func_cancel_exception")


# Generated at 2022-06-18 11:42:20.424770
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
    for i in _range(10):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:42:24.799319
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from .utils import _range

    def func(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
        time.sleep(0.05)
    for i in _range(10):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:42:34.242709
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading

    def func(x):
        time.sleep(random.random())
        return x

    mw = MonoWorker()

    def submit(x):
        return mw.submit(func, x)

    def submit_all(xs):
        return [submit(x) for x in xs]

    def get_all(futures):
        return [f.result() for f in futures]

    def assert_equal(xs, ys):
        assert xs == ys, '{} != {}'.format(xs, ys)

    def assert_equal_get_all(futures, xs):
        assert_equal(get_all(futures), xs)

    def assert_equal_submit_all(xs, ys):
        assert_equal_

# Generated at 2022-06-18 11:42:40.547924
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import as_completed
    from threading import Lock
    from ..utils import _range

    def _test_func(i, lock):
        time.sleep(0.1)
        with lock:
            tqdm_auto.write("{}".format(i))

    lock = Lock()
    mw = MonoWorker()
    futures = [mw.submit(_test_func, i, lock) for i in _range(10)]
    for future in as_completed(futures):
        future.result()

# Generated at 2022-06-18 11:42:48.354946
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def setUp(self):
            self.mw = MonoWorker()
            self.func_called = Event()
            self.func_called.clear()
            self.func_args = None
            self.func_kwargs = None

        def func(self, *args, **kwargs):
            self.func_args = args
            self.func_kwargs = kwargs
            self.func_called.set()

        def test_submit(self):
            self.mw.submit(self.func, 1, 2, 3)
            self.assertTrue(self.func_called.wait(1))

# Generated at 2022-06-18 11:42:56.084028
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from multiprocessing import Queue
    from multiprocessing.pool import ThreadPool

    def func(x, q, e):
        q.put(x)
        e.wait()

    q = Queue()
    e = Event()
    mw = MonoWorker()
    mw.submit(func, 1, q, e)
    sleep(0.1)
    mw.submit(func, 2, q, e)
    sleep(0.1)
    mw.submit(func, 3, q, e)
    sleep(0.1)
    assert q.get() == 3
    e.set()
    sleep(0.1)
    assert q.get() == 3
    assert q.empty()

    # Test that it works with ThreadPool

# Generated at 2022-06-18 11:43:02.709020
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from concurrent.futures import Future
    from concurrent.futures import TimeoutError
    from concurrent.futures import CancelledError
    from concurrent.futures import BrokenExecutor
    from concurrent.futures import BrokenThreadPool
    from concurrent.futures import BrokenProcessPool
    from concurrent.futures import BrokenExecutor
    from concurrent.futures import BrokenThreadPool
    from concurrent.futures import BrokenProcessPool

    def _test_submit(func, *args, **kwargs):
        """
        Test `MonoWorker.submit` with `func(*args, **kwargs)`.
        """

# Generated at 2022-06-18 11:43:07.914489
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from tqdm.contrib.concurrent import MonoWorker

    def wait_for_event(event):
        event.wait()
        return 'done'

    def wait_for_future(future):
        future.result()
        return 'done'

    def wait_for_time(seconds):
        time.sleep(seconds)
        return 'done'

    def test_submit(func, *args, **kwargs):
        worker = MonoWorker()
        assert len(worker.futures) == 0
        future = worker.submit(func, *args, **kwargs)
        assert len(worker.futures) == 1
        assert future.result() == 'done'
        assert len(worker.futures) == 0



# Generated at 2022-06-18 11:43:47.733338
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from multiprocessing import Process

    def _test_MonoWorker_submit(q):
        def _submit(func, *args, **kwargs):
            q.put(func(*args, **kwargs))
        mw = MonoWorker()
        mw.submit(_submit, lambda: 1)
        mw.submit(_submit, lambda: 2)
        mw.submit(_submit, lambda: 3)
        mw.submit(_submit, lambda: 4)
        mw.submit(_submit, lambda: 5)
        mw.submit(_submit, lambda: 6)
        mw.submit(_submit, lambda: 7)
        mw.submit(_submit, lambda: 8)
        mw.submit(_submit, lambda: 9)

# Generated at 2022-06-18 11:43:56.167052
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Lock
    from concurrent.futures import CancelledError

    def wait_and_return(n):
        time.sleep(n)
        return n

    def wait_and_raise(n):
        time.sleep(n)
        raise Exception("{}".format(n))

    def wait_and_return_with_lock(n, lock):
        with lock:
            time.sleep(n)
            return n

    def wait_and_raise_with_lock(n, lock):
        with lock:
            time.sleep(n)
            raise Exception("{}".format(n))

    def test_submit(func, *args, **kwargs):
        mw = MonoWorker()
        assert len(mw.futures) == 0

# Generated at 2022-06-18 11:44:03.553792
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Lock
    from concurrent.futures import Future
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def setUp(self):
            self.lock = Lock()
            self.worker = MonoWorker()

        def test_submit(self):
            def func(x, y):
                with self.lock:
                    self.assertEqual(x, 1)
                    self.assertEqual(y, 2)
                    self.assertEqual(len(self.worker.futures), 1)
                    self.assertIsInstance(self.worker.futures[0], Future)
                    time.sleep(0.1)
                    return x + y
            future = self.worker.submit(func, 1, y=2)

# Generated at 2022-06-18 11:44:07.566380
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
    for i in _range(10):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:44:16.420077
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter

    def test_func(i):
        time.sleep(1)
        return i

    mw = MonoWorker()
    t = tqdm_auto(total=10, unit='B', unit_scale=True, unit_divisor=1024,
                  miniters=1, mininterval=0.1,
                  desc='test', leave=True, file=tqdm_auto.get_instances()[-1].file)
    for i in range(10):
        mw.submit(test_func, i)
        t.update(format_sizeof(i, unit='B', unit_scale=True, unit_divisor=1024))
        t.set_post

# Generated at 2022-06-18 11:44:23.338559
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import as_completed
    from ..utils import FormatCustomText
    from ..std import timeit

    def test_func(x):
        sleep(x)
        return x

    def test_func_exception(x):
        raise Exception("test_func_exception")

    def test_func_cancel(x):
        sleep(x)
        return x

    def test_func_cancel_exception(x):
        sleep(x)
        raise Exception("test_func_cancel_exception")

    def test_func_cancel_exception_2(x):
        sleep(x)
        raise Exception("test_func_cancel_exception_2")


# Generated at 2022-06-18 11:44:32.277036
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Lock
    from concurrent.futures import Future
    from contextlib import contextmanager

    @contextmanager
    def lock_context():
        lock = Lock()
        lock.acquire()
        try:
            yield lock
        finally:
            lock.release()

    def wait(lock, timeout):
        with lock_context():
            time.sleep(timeout)

    def wait_and_return(lock, timeout, return_value):
        wait(lock, timeout)
        return return_value

    def wait_and_raise(lock, timeout, exception):
        wait(lock, timeout)
        raise exception

    def wait_and_return_future(lock, timeout, return_value):
        wait(lock, timeout)
        return Future()


# Generated at 2022-06-18 11:44:40.265828
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from threading import Event

    def func(x, y, z):
        time.sleep(0.1)
        return x + y + z

    def func_exception(x, y, z):
        time.sleep(0.1)
        raise Exception('test exception')

    def func_cancel(x, y, z):
        time.sleep(0.1)
        return x + y + z

    def func_cancel_exception(x, y, z):
        time.sleep(0.1)
        raise Exception('test exception')

    def func_cancel_exception_cancel(x, y, z):
        time.sleep(0.1)
        raise Exception('test exception')


# Generated at 2022-06-18 11:44:47.428574
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from concurrent.futures import as_completed
    from ..utils import format_sizeof

    def test_func(i, lock):
        with lock:
            tqdm_auto.write('test_func({})'.format(i))
        sleep(0.1)
        return i

    lock = Lock()
    mw = MonoWorker()
    for i in range(10):
        mw.submit(test_func, i, lock)
    for future in as_completed(mw.futures):
        tqdm_auto.write('{} = {}'.format(future, future.result()))
    tqdm_auto.write('{}'.format(format_sizeof(mw)))

# Generated at 2022-06-18 11:44:55.866515
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from .utils import _range

    def _test(func, *args, **kwargs):
        """
        Test that `func(*args, **kwargs)` is called once and only once.
        """
        called = Event()
        result = []

        def _func(*args, **kwargs):
            assert not called.is_set()
            called.set()
            result.append(func(*args, **kwargs))

        worker = MonoWorker()
        future = worker.submit(_func, *args, **kwargs)
        assert isinstance(future, Future)
        assert not called.is_set()
        assert not future.done()
        assert not future.cancelled()
        assert future.result() is None
        assert called