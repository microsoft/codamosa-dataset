

# Generated at 2022-06-18 11:36:31.733415
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from multiprocessing import Process

    def func(x, y, z, e):
        sleep(x)
        e.set()
        return x + y + z

    e = Event()
    mw = MonoWorker()
    p = Process(target=mw.submit, args=(func, 1, 2, 3, e))
    p.start()
    assert not e.is_set()
    p.join()
    assert e.is_set()
    assert mw.futures[0].result() == 6

# Generated at 2022-06-18 11:36:40.126850
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future

    def func(x, y, z, e):
        e.wait()
        return x + y + z

    e = Event()
    mw = MonoWorker()
    f1 = mw.submit(func, 1, 2, 3, e)
    assert isinstance(f1, Future)
    assert not f1.done()
    assert len(mw.futures) == 1
    f2 = mw.submit(func, 4, 5, 6, e)
    assert isinstance(f2, Future)
    assert not f2.done()
    assert len(mw.futures) == 1
    assert f1.cancel()
    assert len(mw.futures) == 1

# Generated at 2022-06-18 11:36:49.181401
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import as_completed

    def f(x, wait=0.1, sleep_=0.1):
        sleep(sleep_)
        return x

    mw = MonoWorker()
    e = Event()
    e.set()
    for i in range(10):
        mw.submit(f, i, sleep_=0.1)
        e.wait()
        e.clear()
        sleep(0.05)
        e.set()
    for f in as_completed(mw.futures):
        assert f.result() == 9

# Generated at 2022-06-18 11:36:59.833961
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    mw.submit(f, 1)
    mw.submit(f, 2)
    mw.submit(f, 3)
    mw.submit(f, 4)
    mw.submit(f, 5)
    mw.submit(f, 6)
    mw.submit(f, 7)
    mw.submit(f, 8)
    mw.submit(f, 9)
    mw.submit(f, 10)
    mw.submit(f, 11)
    mw.submit(f, 12)
    mw.submit(f, 13)
    mw.submit(f, 14)
   

# Generated at 2022-06-18 11:37:11.240369
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import as_completed
    from ..utils import FormatCustomText

    def f(x):
        sleep(x)
        return x

    with tqdm_auto.tqdm(total=10, desc='test',
                        bar_format=FormatCustomText('{desc}: {n_fmt}/{total_fmt}')) as t:
        mw = MonoWorker()
        e = Event()
        e.set()
        for i in range(10):
            mw.submit(f, i)
            if i == 5:
                e.clear()
            e.wait()
            t.update()
        for future in as_completed(mw.futures):
            assert future.result() == 9

# Generated at 2022-06-18 11:37:22.005214
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from ..utils import _range

    def wait_for(t):
        time.sleep(t)
        return t

    def wait_for_cancel(t, e):
        e.wait()
        return t

    def wait_for_exception(t):
        raise Exception("Exception raised")

    def wait_for_exception_cancel(t, e):
        e.wait()
        raise Exception("Exception raised")

    def test_func(func, args, kwargs, expected_result, expected_exception=False):
        e = Event()
        mw = MonoWorker()
        future = mw.submit(func, *args, **kwargs)
        if expected_exception:
            assert future.exception() is not None

# Generated at 2022-06-18 11:37:32.978228
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import as_completed
    from ..utils import _range

    def slow_square(x):
        time.sleep(0.1)
        return x ** 2

    with tqdm_auto.tqdm(total=10) as t:
        mw = MonoWorker()
        for i in _range(10):
            mw.submit(slow_square, i)
            t.update()

    with tqdm_auto.tqdm(total=10) as t:
        mw = MonoWorker()
        for i in _range(10):
            mw.submit(slow_square, i)
            t.update()
            time.sleep(0.1)

    with tqdm_auto.tqdm(total=10) as t:
        mw

# Generated at 2022-06-18 11:37:42.237133
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def test_submit(self):
            def func(x, y):
                time.sleep(x)
                return x + y

            def func_exception(x, y):
                time.sleep(x)
                raise Exception('test_exception')

            def func_cancel(x, y, e):
                time.sleep(x)
                e.wait()
                return x + y

            def func_cancel_exception(x, y, e):
                time.sleep(x)
                e.wait()
                raise Exception('test_exception')

            mw = MonoWorker()

# Generated at 2022-06-18 11:37:51.978833
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event

    def wait_and_return(seconds, value):
        time.sleep(seconds)
        return value

    def wait_and_raise(seconds, exception):
        time.sleep(seconds)
        raise exception

    def wait_and_return_after_cancel(seconds, value, cancel_event):
        cancel_event.wait()
        return value

    def wait_and_raise_after_cancel(seconds, exception, cancel_event):
        cancel_event.wait()
        raise exception

    def test_wait_and_return():
        worker = MonoWorker()
        cancel_event = Event()
        future = worker.submit(wait_and_return_after_cancel, 0.1, 42, cancel_event)
        assert future.result() == 42

# Generated at 2022-06-18 11:38:01.421860
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from tqdm.contrib.concurrent import MonoWorker

    def _test_submit(mw, func, *args, **kwargs):
        """
        Test that `mw.submit(func, *args, **kwargs)`
        returns a `Future` object.
        """
        f = mw.submit(func, *args, **kwargs)
        assert isinstance(f, Future)
        return f

    def _test_submit_cancel(mw, func, *args, **kwargs):
        """
        Test that `mw.submit(func, *args, **kwargs)`
        returns a `Future` object and cancels the previous one.
        """

# Generated at 2022-06-18 11:38:07.479300
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.01)
    time.sleep(0.2)
    assert mw.futures[0].result() == 9

# Generated at 2022-06-18 11:38:17.018540
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def setUp(self):
            self.mw = MonoWorker()

        def test_submit(self):
            def func(x):
                time.sleep(x)
                return x

            f1 = self.mw.submit(func, 1)
            self.assertIsInstance(f1, Future)
            self.assertEqual(f1.result(), 1)

            f2 = self.mw.submit(func, 2)
            self.assertIsInstance(f2, Future)
            self.assertEqual(f2.result(), 2)

            f3 = self.mw.submit(func, 3)
            self.assertIsInstance(f3, Future)


# Generated at 2022-06-18 11:38:25.061375
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from multiprocessing import Value
    from concurrent.futures import as_completed

    def func(i, lock, counter):
        with lock:
            counter.value += 1
            sleep(i)
            counter.value -= 1

    lock = Lock()
    counter = Value('i', 0)
    mw = MonoWorker()
    futures = [mw.submit(func, i, lock, counter) for i in range(10)]
    for future in as_completed(futures):
        assert future.result() is None
    assert counter.value == 0

# Generated at 2022-06-18 11:38:36.051012
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from threading import Event
    from unittest import TestCase

    class Test(TestCase):
        def setUp(self):
            self.mw = MonoWorker()
            self.ev = Event()
            self.ev.clear()
            self.fut = None
            self.fut_val = None

        def tearDown(self):
            if self.fut is not None:
                self.fut.cancel()

        def test_submit(self):
            self.fut = self.mw.submit(self.ev.wait)
            self.assertIsInstance(self.fut, Future)
            self.assertFalse(self.fut.done())
            self.assertFalse(self.fut.cancelled())
            self.assertIs

# Generated at 2022-06-18 11:38:40.341030
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import TimeoutError
    from ..utils import _range

    def func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
    for i in _range(10):
        try:
            assert mw.futures[0].result(timeout=0.01) == i
        except TimeoutError:
            pass

# Generated at 2022-06-18 11:38:51.844164
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import TimeoutError

    def _test_func(i, j):
        time.sleep(i)
        return i + j

    mw = MonoWorker()
    assert mw.submit(_test_func, 1, 2).result() == 3
    assert mw.submit(_test_func, 2, 3).result() == 5
    assert mw.submit(_test_func, 3, 4).result() == 7
    assert mw.submit(_test_func, 4, 5).result() == 9
    assert mw.submit(_test_func, 5, 6).result() == 11
    assert mw.submit(_test_func, 6, 7).result() == 13
    assert mw.submit(_test_func, 7, 8).result() == 15

# Generated at 2022-06-18 11:38:56.657726
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.05)
    mw.pool.shutdown()

# Generated at 2022-06-18 11:39:01.147111
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def test_func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(test_func, i)
    for i in _range(10):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:39:08.679008
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    from concurrent.futures import Future
    from ..utils import _range

    def _test_func(i):
        time.sleep(random.random())
        return i

    def _test_thread(mw, i):
        f = mw.submit(_test_func, i)
        assert isinstance(f, Future)
        assert f.result() == i

    mw = MonoWorker()
    threads = [threading.Thread(target=_test_thread, args=(mw, i))
               for i in _range(10)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

# Generated at 2022-06-18 11:39:16.331717
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase, main

    class Test(TestCase):
        def test(self):
            def f(x):
                sleep(x)
                return x

            mw = MonoWorker()
            self.assertEqual(len(mw.futures), 0)
            self.assertIsInstance(mw.submit(f, 0.1), Future)
            self.assertEqual(len(mw.futures), 1)
            self.assertIsInstance(mw.submit(f, 0.2), Future)
            self.assertEqual(len(mw.futures), 1)
            self.assertIsInstance(mw.submit(f, 0.3), Future)

# Generated at 2022-06-18 11:39:24.954881
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def do_work(i):
        time.sleep(0.1)
        return i

    worker = MonoWorker()
    for i in _range(5):
        worker.submit(do_work, i)
        time.sleep(0.05)

    for i in _range(5):
        assert worker.futures[i].result() == i

# Generated at 2022-06-18 11:39:30.001588
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(5):
        mw.submit(f, i)
    time.sleep(0.1)
    assert len(mw.futures) == 1
    assert mw.futures[0].result() == 4

# Generated at 2022-06-18 11:39:38.558771
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event

    def wait_for_event(event, timeout):
        event.wait(timeout)
        return event.is_set()

    def wait_for_event_with_timeout(event, timeout):
        return wait_for_event(event, timeout)

    def wait_for_event_without_timeout(event):
        return wait_for_event(event, None)

    def wait_for_event_with_timeout_and_raise(event, timeout):
        if not wait_for_event(event, timeout):
            raise RuntimeError("event timed out")

    def wait_for_event_without_timeout_and_raise(event):
        if not wait_for_event(event, None):
            raise RuntimeError("event timed out")


# Generated at 2022-06-18 11:39:42.592818
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    from concurrent.futures import as_completed

    def func(x):
        time.sleep(random.random() / 10)
        return x

    mw = MonoWorker()
    futures = [mw.submit(func, i) for i in range(10)]
    for future in as_completed(futures):
        assert future.result() == futures.index(future)

# Generated at 2022-06-18 11:39:47.164022
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def wait(n):
        time.sleep(n)
        return n

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(wait, i)
        time.sleep(0.1)
    assert mw.futures[0].result() == 9
    assert mw.futures[1].result() == 8

# Generated at 2022-06-18 11:39:59.182095
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event

    def func(i, evt):
        evt.wait()
        sleep(0.1)
        return i

    evt = Event()
    mw = MonoWorker()
    assert mw.submit(func, 1, evt) == mw.submit(func, 2, evt)
    assert mw.submit(func, 3, evt) == mw.submit(func, 4, evt)
    assert mw.submit(func, 5, evt) == mw.submit(func, 6, evt)
    assert mw.submit(func, 7, evt) == mw.submit(func, 8, evt)
    assert mw.submit(func, 9, evt) == mw.submit(func, 10, evt)
   

# Generated at 2022-06-18 11:40:09.030280
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def test_submit(self):
            def func(x):
                time.sleep(x)
                return x

            def func_exception(x):
                raise Exception(x)

            def func_cancel(x):
                e = Event()
                e.wait()
                return x

            mw = MonoWorker()
            f1 = mw.submit(func, 1)
            self.assertIsInstance(f1, Future)
            self.assertEqual(f1.result(), 1)
            f2 = mw.submit(func, 2)
            self.assertIsInstance(f2, Future)

# Generated at 2022-06-18 11:40:13.419697
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event

    def func(i, e):
        e.wait()
        return i

    e = Event()
    mw = MonoWorker()
    for i in range(10):
        mw.submit(func, i, e)
    assert len(mw.futures) == 1
    e.set()
    assert mw.futures[0].result() == 9

# Generated at 2022-06-18 11:40:18.821333
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from multiprocessing import Value

    def func(i, lock, val):
        sleep(0.1)
        with lock:
            val.value = i

    lock = Lock()
    val = Value('i', 0)
    mw = MonoWorker()
    for i in range(10):
        mw.submit(func, i, lock, val)
        sleep(0.05)
    assert val.value == 9

# Generated at 2022-06-18 11:40:29.787376
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import TimeoutError

    def wait(seconds, event):
        time.sleep(seconds)
        event.set()

    def wait_and_raise(seconds, event):
        time.sleep(seconds)
        event.set()
        raise ValueError("Raising error")

    def wait_and_return(seconds, event):
        time.sleep(seconds)
        event.set()
        return "Returning value"

    def wait_and_timeout(seconds, event):
        time.sleep(seconds)
        event.set()
        raise TimeoutError("Raising timeout")

    def test_wait(seconds, event, func):
        worker = MonoWorker()
        future = worker.submit(func, seconds, event)
        assert not event.is_set

# Generated at 2022-06-18 11:40:44.098350
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    from concurrent.futures import Future
    from contextlib import contextmanager

    @contextmanager
    def assert_raises(exception):
        try:
            yield
        except exception:
            pass
        else:
            raise AssertionError("Did not raise %s" % exception)

    def sleep(t):
        time.sleep(t)
        return t

    def sleep_random(t):
        time.sleep(t * random.random())
        return t

    def sleep_random_error(t):
        time.sleep(t * random.random())
        raise Exception("sleep_random_error")

    def sleep_random_cancel(t):
        time.sleep(t * random.random())
        raise Future.cancelled()


# Generated at 2022-06-18 11:40:50.207897
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase, main

    class Test(TestCase):
        def test_submit(self):
            mw = MonoWorker()
            e = Event()
            f = Future()
            f.set_result(None)
            mw.futures.append(f)
            mw.submit(e.wait)
            self.assertEqual(len(mw.futures), 1)
            e.set()
            sleep(0.1)
            self.assertEqual(len(mw.futures), 0)

    main()

# Generated at 2022-06-18 11:40:56.062975
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from .tqdm_test_utils import FakeTqdmFile

    def test_func(x, y):
        time.sleep(0.1)
        return x + y

    with FakeTqdmFile(isatty=True) as f:
        mw = MonoWorker()
        assert mw.submit(test_func, 1, 2) == 3
        assert mw.submit(test_func, 3, 4) == 7
        assert mw.submit(test_func, 5, 6) == 11
        assert mw.submit(test_func, 7, 8) == 15
        assert mw.submit(test_func, 9, 10) == 19
        assert mw.submit(test_func, 11, 12) == 23
        assert mw.submit

# Generated at 2022-06-18 11:41:02.623785
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Thread

    def func(x):
        sleep(random())
        return x

    def test_thread(mw, x):
        mw.submit(func, x)

    mw = MonoWorker()
    threads = [Thread(target=test_thread, args=(mw, x))
               for x in range(10)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    assert len(mw.futures) == 1
    assert mw.futures[0].result() == 9

# Generated at 2022-06-18 11:41:06.777070
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in range(5):
        mw.submit(func, i)
        time.sleep(0.1)
        _term_move_up()
        print('\r', end='')
    print('\rDone')

# Generated at 2022-06-18 11:41:14.532708
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from ..utils import _range

    def _test_func(x):
        time.sleep(x)
        return x

    def _test_func_exception(x):
        raise Exception("test exception")

    def _test_func_cancel(x):
        time.sleep(x)
        return x

    def _test_func_cancel_exception(x):
        time.sleep(x)
        raise Exception("test exception")

    def _test_func_cancel_exception_2(x):
        time.sleep(x)
        raise Exception("test exception")

    def _test_func_cancel_exception_3(x):
        time.sleep(x)
        raise Exception("test exception")


# Generated at 2022-06-18 11:41:17.116279
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random

    def f(x):
        time.sleep(random.random() * 0.1)
        return x

    mw = MonoWorker()
    for i in range(10):
        mw.submit(f, i)
        time.sleep(0.05)

# Generated at 2022-06-18 11:41:25.924853
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def _test_submit(n, sleep):
        mw = MonoWorker()
        for i in _range(n):
            mw.submit(time.sleep, sleep)
        time.sleep(sleep * n)

    _test_submit(1, 1)
    _test_submit(2, 1)
    _test_submit(2, 2)
    _test_submit(3, 1)
    _test_submit(3, 2)
    _test_submit(3, 3)
    _test_submit(4, 1)
    _test_submit(4, 2)
    _test_submit(4, 3)
    _test_submit(4, 4)
    _test_submit(5, 1)
    _test_submit(5, 2)
   

# Generated at 2022-06-18 11:41:32.176090
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def _test_MonoWorker_submit(n, sleep):
        mw = MonoWorker()
        for i in _range(n):
            mw.submit(time.sleep, sleep)
        time.sleep(sleep * n)

    _test_MonoWorker_submit(10, 0.1)
    _test_MonoWorker_submit(10, 0.1)
    _test_MonoWorker_submit(10, 0.1)
    _test_MonoWorker_submit(10, 0.1)
    _test_MonoWorker_submit(10, 0.1)
    _test_MonoWorker_submit(10, 0.1)
    _test_MonoWorker_submit(10, 0.1)
    _

# Generated at 2022-06-18 11:41:41.332327
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    with tqdm_auto.tqdm(total=10) as t:
        for i in _range(10):
            mw.submit(f, i)
            t.update()
            _term_move_up()
            t.set_description(str(mw.futures))
            _term_move_up()
            t.set_description(str(mw.futures))
            _term_move_up()
            t.set_description(str(mw.futures))
            _term_move_up()

# Generated at 2022-06-18 11:42:06.552968
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def _test_submit(n, sleep=0.01):
        mw = MonoWorker()
        for i in _range(n):
            mw.submit(time.sleep, sleep)
        time.sleep(sleep * n * 2)

    _test_submit(1)
    _test_submit(2)
    _test_submit(3)
    _test_submit(4)
    _test_submit(5)
    _test_submit(6)
    _test_submit(7)
    _test_submit(8)
    _test_submit(9)
    _test_submit(10)
    _test_submit(11)
    _test_submit(12)
    _test_submit(13)
    _test_submit(14)
   

# Generated at 2022-06-18 11:42:12.252082
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.05)
    for i in _range(10):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:42:17.209457
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
        time.sleep(0.1)

    assert mw.futures[0].result() == 9
    assert mw.futures[1].result() == 8

# Generated at 2022-06-18 11:42:19.038233
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
        time.sleep(0.1)

# Generated at 2022-06-18 11:42:25.357392
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event

    def wait_and_print(n, wait_event):
        wait_event.wait()
        sleep(0.1)
        tqdm_auto.write(str(n))

    wait_event = Event()
    wait_event.clear()
    worker = MonoWorker()
    for i in range(5):
        worker.submit(wait_and_print, i, wait_event)
    wait_event.set()
    sleep(0.5)
    assert len(worker.futures) == 1
    assert worker.futures[0].done()
    assert worker.futures[0].result() is None

# Generated at 2022-06-18 11:42:34.795421
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import Future

    def func(x):
        sleep(x)
        return x

    def test_func(x, e):
        e.wait()
        return func(x)

    def test_func_err(x, e):
        e.wait()
        raise Exception(x)

    def test_func_cancel(x, e):
        e.wait()
        return x

    def test_func_cancel_err(x, e):
        e.wait()
        raise Exception(x)

    def test_func_cancel_err_2(x, e):
        e.wait()
        raise Exception(x)

    def test_func_cancel_err_3(x, e):
        e.wait()
       

# Generated at 2022-06-18 11:42:39.177534
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.05)
    assert mw.futures[0].result() == 9

# Generated at 2022-06-18 11:42:46.795885
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def setUp(self):
            self.mw = MonoWorker()
            self.mw.pool.shutdown()
            self.mw.pool = ThreadPoolExecutor(max_workers=1)
            self.mw.futures = deque([], 2)

        def tearDown(self):
            self.mw.pool.shutdown()

        def test_submit(self):
            def func(x):
                time.sleep(x)
                return x

            def func_exception(x):
                raise Exception("x={}".format(x))

            def func_cancel(x):
                time.sleep(x)


# Generated at 2022-06-18 11:42:54.681903
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from multiprocessing import Process
    from multiprocessing.connection import Listener, Client
    from multiprocessing.reduction import reduce_connection
    from multiprocessing.managers import BaseManager

    class MonoWorkerManager(BaseManager):
        pass

    MonoWorkerManager.register('MonoWorker', MonoWorker)

    def worker_process(address, authkey):
        listener = Listener(address, authkey=authkey)
        conn = listener.accept()
        listener.close()
        mw = MonoWorkerManager.get_server().MonoWorker()
        while True:
            try:
                func, args, kwargs = conn.recv()
            except EOFError:
                break

# Generated at 2022-06-18 11:42:59.229463
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import TimeoutError
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
    for i in _range(10):
        try:
            assert mw.futures[0].result(timeout=0.1) == i
        except TimeoutError:
            pass

# Generated at 2022-06-18 11:43:40.652268
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Event

    def func(x, event):
        sleep(random())
        event.set()

    event = Event()
    worker = MonoWorker()
    worker.submit(func, 1, event)
    assert not event.is_set()
    worker.submit(func, 2, event)
    assert not event.is_set()
    event.wait()
    assert event.is_set()

# Generated at 2022-06-18 11:43:48.645067
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from .tqdm_test_classes import PretendTqdmFile
    from .tqdm_test_classes import tqdm_cls_patched as tqdm_cls
    from .tqdm_test_classes import tqdm_cls_patched_no_desc as tqdm_cls_no_desc

    # Test 1
    with PretendTqdmFile() as f:
        mw = MonoWorker()
        mw.submit(tqdm_cls, range(10), file=f)
        mw.submit(tqdm_cls, range(10), file=f)
        mw.submit(tqdm_cls, range(10), file=f)

# Generated at 2022-06-18 11:43:57.056087
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from threading import Event

    def _test_submit(mw, func, *args, **kwargs):
        """
        Test that `mw.submit(func, *args, **kwargs)`
        returns a `Future` that will be `done()`
        after `func(*args, **kwargs)` returns.
        """
        future = mw.submit(func, *args, **kwargs)
        assert isinstance(future, Future)
        assert not future.done()
        time.sleep(0.1)
        assert future.done()
        return future


# Generated at 2022-06-18 11:44:04.631584
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from ..utils import _range

    def func(x, y, z, e):
        e.wait()
        return x + y + z

    e = Event()
    mw = MonoWorker()
    for i in _range(10):
        f = mw.submit(func, i, i, i, e)
        assert isinstance(f, Future)
        assert not f.done()
    e.set()
    for i in _range(10):
        f = mw.submit(func, i, i, i, e)
        assert isinstance(f, Future)
        assert f.done()
        assert f.result() == 3 * i
    time.sleep(0.1)

# Generated at 2022-06-18 11:44:12.157082
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from concurrent.futures import as_completed
    from tqdm.contrib.concurrency import MonoWorker

    def func(i, sleep_time, lock):
        with lock:
            tqdm_auto.write('func({})'.format(i))
        sleep(sleep_time)
        return i

    lock = Lock()
    mw = MonoWorker()
    futures = [mw.submit(func, i, i, lock) for i in range(5)]
    for future in as_completed(futures):
        tqdm_auto.write('{}'.format(future.result()))

# Generated at 2022-06-18 11:44:16.616635
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    from concurrent.futures import as_completed

    def f(x):
        time.sleep(random.random())
        return x

    mw = MonoWorker()
    futures = [mw.submit(f, i) for i in range(10)]
    for future in as_completed(futures):
        assert future.result() == futures.index(future)

# Generated at 2022-06-18 11:44:23.198625
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from threading import Event
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def test_submit(self):
            def func(x):
                time.sleep(x)
                return x

            def func_exception(x):
                raise Exception("test exception")

            def func_cancel(x):
                time.sleep(x)
                return x

            def func_cancel_exception(x):
                time.sleep(x)
                raise Exception("test exception")

            def func_cancel_exception_event(x):
                time.sleep(x)
                event.wait()
                raise Exception("test exception")

            event = Event()
            worker = MonoWorker()

            # test submit
            future = worker

# Generated at 2022-06-18 11:44:32.276559
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    from ..utils import _range

    def _test_MonoWorker_submit(n, m):
        """
        n: number of tasks
        m: number of threads
        """
        mw = MonoWorker()
        for i in _range(n):
            mw.submit(time.sleep, 0.1)
            time.sleep(0.01)
        for i in _range(m):
            threading.Thread(target=mw.submit, args=(time.sleep, 0.1)).start()
            time.sleep(0.01)
        time.sleep(0.2)

    _test_MonoWorker_submit(10, 10)
    _test_MonoWorker_submit(10, 100)

# Generated at 2022-06-18 11:44:40.267600
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event

    def func(x, y, z, e):
        sleep(x)
        e.set()
        return x + y + z

    e = Event()
    mw = MonoWorker()
    assert mw.submit(func, 0.1, 1, 2, e)
    assert mw.submit(func, 0.2, 3, 4, e)
    assert mw.submit(func, 0.3, 5, 6, e)
    assert mw.submit(func, 0.4, 7, 8, e)
    assert mw.submit(func, 0.5, 9, 10, e)
    assert mw.submit(func, 0.6, 11, 12, e)

# Generated at 2022-06-18 11:44:45.590208
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def _test_submit(n):
        mw = MonoWorker()
        for i in _range(n):
            mw.submit(time.sleep, 0.1)
        time.sleep(0.2)
        assert len(mw.futures) == 1
        assert mw.futures[0].done()
        assert mw.futures[0].result() is None

    _test_submit(1)
    _test_submit(2)
    _test_submit(3)

# Generated at 2022-06-18 11:46:02.119809
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    mw.submit(func, 1)
    mw.submit(func, 2)
    mw.submit(func, 3)
    mw.submit(func, 4)
    mw.submit(func, 5)
    mw.submit(func, 6)
    mw.submit(func, 7)
    mw.submit(func, 8)
    mw.submit(func, 9)
    mw.submit(func, 10)
    mw.submit(func, 11)
    mw.submit(func, 12)
    mw.submit(func, 13)
    mw.submit(func, 14)
   

# Generated at 2022-06-18 11:46:08.673523
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def wait(t):
        time.sleep(t)
        return t

    def wait_and_print(t):
        time.sleep(t)
        tqdm_auto.write(str(t))
        return t

    def wait_and_raise(t):
        time.sleep(t)
        raise Exception(t)

    def wait_and_cancel(t):
        time.sleep(t)
        return t

    def wait_and_cancel_and_print(t):
        time.sleep(t)
        tqdm_auto.write(str(t))
        return t

    def wait_and_cancel_and_raise(t):
        time.sleep(t)
        raise Exception(t)


# Generated at 2022-06-18 11:46:18.025388
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from ..utils import _range

    def _test_submit(n_tasks, n_workers, n_iter, n_sleep, n_cancel):
        """
        n_tasks: number of tasks to submit
        n_workers: number of workers in the pool
        n_iter: number of iterations in each task
        n_sleep: number of seconds to sleep in each iteration
        n_cancel: number of tasks to cancel
        """
        def _task(i, n_iter, n_sleep, e):
            for _ in _range(n_iter):
                time.sleep(n_sleep)
                if e.is_set():
                    break
            return i

        e = Event()
        mw = MonoWorker()
       

# Generated at 2022-06-18 11:46:21.951392
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
        time.sleep(0.05)

# Generated at 2022-06-18 11:46:26.835978
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Thread
    from queue import Queue

    def worker(q):
        q.put(1)
        sleep(0.1)
        q.put(2)

    q = Queue()
    mw = MonoWorker()
    t = Thread(target=worker, args=(q,))
    t.start()
    mw.submit(worker, q)
    assert q.get() == 1
    assert q.get() == 2
    assert q.empty()
    t.join()