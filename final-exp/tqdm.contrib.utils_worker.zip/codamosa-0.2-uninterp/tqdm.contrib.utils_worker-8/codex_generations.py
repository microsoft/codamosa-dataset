

# Generated at 2022-06-18 11:36:28.198384
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import TimeoutError
    from ..utils import _range

    def _test_MonoWorker_submit(n, sleep, timeout):
        mw = MonoWorker()
        for i in _range(n):
            mw.submit(time.sleep, sleep)
        try:
            mw.futures[0].result(timeout=timeout)
        except TimeoutError:
            pass
        else:
            raise AssertionError("TimeoutError expected")

    _test_MonoWorker_submit(1, 0.1, 0.05)
    _test_MonoWorker_submit(2, 0.1, 0.05)
    _test_MonoWorker_submit(3, 0.1, 0.05)

# Generated at 2022-06-18 11:36:35.470953
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import CancelledError

    def f(x, e):
        sleep(x)
        e.set()
        return x

    mw = MonoWorker()
    e1 = Event()
    e2 = Event()
    e3 = Event()
    e4 = Event()
    f1 = mw.submit(f, 1, e1)
    f2 = mw.submit(f, 2, e2)
    f3 = mw.submit(f, 3, e3)
    f4 = mw.submit(f, 4, e4)
    assert not e1.is_set()
    assert not e2.is_set()
    assert not e3.is_set()
    assert not e4.is_set()


# Generated at 2022-06-18 11:36:46.222420
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import as_completed

    def f(x, e):
        e.wait()
        return x

    e = Event()
    mw = MonoWorker()
    futures = [mw.submit(f, i, e) for i in range(3)]
    assert len(mw.futures) == 1
    assert mw.futures[0] == futures[-1]
    e.set()
    for i, future in enumerate(as_completed(futures)):
        assert future.result() == i
    assert len(mw.futures) == 0

    e.clear()
    futures = [mw.submit(f, i, e) for i in range(3)]

# Generated at 2022-06-18 11:36:56.346666
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Thread
    from multiprocessing import Process

    def f(x):
        sleep(random())
        return x

    def test(cls):
        mw = cls()
        for i in range(10):
            mw.submit(f, i)
        for i in range(10):
            assert mw.futures[0].result() == i

    test(MonoWorker)
    test(lambda: MonoWorker())
    test(lambda: MonoWorker())

    def test_thread(cls):
        mw = cls()
        threads = [Thread(target=mw.submit, args=(f, i))
                   for i in range(10)]
        for t in threads:
            t.start()

# Generated at 2022-06-18 11:37:08.168700
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    import multiprocessing
    from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
    from multiprocessing import Process, Queue

    def _test_submit(pool, n_tasks, n_workers, n_cores, n_runs):
        """
        Test `MonoWorker.submit` with `pool` (`ThreadPoolExecutor` or
        `ProcessPoolExecutor`).
        """
        def _test_task(i):
            """
            Test task: sleep for a random amount of time, then return the
            task index.
            """
            time.sleep(random.random())
            return i


# Generated at 2022-06-18 11:37:13.023696
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(i):
        time.sleep(1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)


if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-18 11:37:23.612701
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def wait(n):
        time.sleep(n)
        return n

    def test_submit(n_iter, n_wait):
        mw = MonoWorker()
        for i in _range(n_iter):
            mw.submit(wait, n_wait)
        return mw

    mw = test_submit(10, 1)
    assert mw.futures[0].result() == 1
    assert len(mw.futures) == 1

    mw = test_submit(10, 0.1)
    assert mw.futures[0].result() == 0.1
    assert len(mw.futures) == 1

    mw = test_submit(10, 0.1)

# Generated at 2022-06-18 11:37:28.325582
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(3):
        mw.submit(f, i)
        time.sleep(0.1)
    assert mw.futures[0].result() == 2

# Generated at 2022-06-18 11:37:33.686898
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    from concurrent.futures import as_completed

    def f(x):
        time.sleep(random.random())
        return x

    mw = MonoWorker()
    futures = [mw.submit(f, i) for i in range(10)]
    for future in as_completed(futures):
        assert future.result() == futures.index(future)

# Generated at 2022-06-18 11:37:39.742405
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range
    from ..std import time as time_std

    def func(x):
        time_std.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
    time.sleep(0.5)
    assert mw.futures[0].done()
    assert not mw.futures[1].done()

# Generated at 2022-06-18 11:37:51.243673
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Lock
    from concurrent.futures import Future
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def test_submit(self):
            def func(x):
                time.sleep(x)
                return x

            mw = MonoWorker()
            mw.submit(func, 0.1)
            mw.submit(func, 0.2)
            mw.submit(func, 0.3)
            mw.submit(func, 0.4)
            mw.submit(func, 0.5)
            mw.submit(func, 0.6)
            mw.submit(func, 0.7)
            mw.submit(func, 0.8)
            mw.submit(func, 0.9)
            mw

# Generated at 2022-06-18 11:37:55.173468
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def test_func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(test_func, i)
        time.sleep(0.1)

# Generated at 2022-06-18 11:38:03.980447
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Lock
    from concurrent.futures import Future
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def test_submit(self):
            def func(x):
                time.sleep(x)
                return x

            def func_exception(x):
                raise Exception('test')

            mw = MonoWorker()
            self.assertEqual(len(mw.futures), 0)
            self.assertIsNone(mw.submit(func, 0.1))
            self.assertEqual(len(mw.futures), 1)
            self.assertIsNone(mw.submit(func, 0.1))
            self.assertEqual(len(mw.futures), 1)

# Generated at 2022-06-18 11:38:08.242836
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from ..utils import _range

    def func(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
    assert isinstance(mw.futures[0], Future)
    assert mw.futures[0].result() == 9

# Generated at 2022-06-18 11:38:17.847209
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    assert not mw.futures
    for i in _range(3):
        mw.submit(func, i)
    assert len(mw.futures) == 1
    assert mw.futures[0].result() == 2
    for i in _range(3):
        mw.submit(func, i)
    assert len(mw.futures) == 1
    assert mw.futures[0].result() == 2
    for i in _range(3):
        mw.submit(func, i)
    assert len(mw.futures) == 1
    assert mw.futures[0].result

# Generated at 2022-06-18 11:38:28.406143
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase, main

    class TestMonoWorker(TestCase):
        def setUp(self):
            self.mw = MonoWorker()
            self.evt = Event()
            self.evt.clear()
            self.fut = Future()
            self.fut.set_result(None)

        def test_submit(self):
            def func():
                self.evt.wait()
                return 'ok'

            fut = self.mw.submit(func)
            self.assertIsInstance(fut, Future)
            self.assertEqual(fut.result(), 'ok')

            self.mw.submit(func)
            self.assertIsInstance(fut, Future)
           

# Generated at 2022-06-18 11:38:38.421880
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up

    def test_func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    mw.submit(test_func, 1)
    mw.submit(test_func, 2)
    mw.submit(test_func, 3)
    mw.submit(test_func, 4)
    mw.submit(test_func, 5)
    mw.submit(test_func, 6)
    mw.submit(test_func, 7)
    mw.submit(test_func, 8)
    mw.submit(test_func, 9)
    mw.submit(test_func, 10)
    mw.submit(test_func, 11)

# Generated at 2022-06-18 11:38:43.505642
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
        time.sleep(0.1)

    assert mw.futures[0].result() == 9
    assert mw.futures[1].result() == 8

# Generated at 2022-06-18 11:38:47.456977
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..auto import trange

    def func(i):
        time.sleep(i)
        return i

    mw = MonoWorker()
    for i in trange(3):
        mw.submit(func, i)
        time.sleep(0.1)

# Generated at 2022-06-18 11:38:58.442231
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase, main

    class Test(TestCase):
        def test_submit(self):
            def f(x):
                sleep(0.1)
                return x

            mw = MonoWorker()
            f1 = mw.submit(f, 1)
            f2 = mw.submit(f, 2)
            f3 = mw.submit(f, 3)
            self.assertEqual(f1.result(), 1)
            self.assertEqual(f2.result(), 2)
            self.assertEqual(f3.result(), 3)

        def test_submit_cancel(self):
            def f(x):
                sleep(0.1)
                return x

            m

# Generated at 2022-06-18 11:39:05.403768
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
    time.sleep(2)
    assert mw.futures[0].result() == 9

# Generated at 2022-06-18 11:39:12.797909
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import TimeoutError
    from ..utils import _range

    def _test(n, sleep=0.1):
        mw = MonoWorker()
        for i in _range(n):
            mw.submit(time.sleep, sleep)
        time.sleep(sleep * n)
        assert len(mw.futures) == 1
        assert mw.futures[0].done()

    _test(1)
    _test(2)
    _test(3)
    _test(4)
    _test(5)
    _test(6)
    _test(7)
    _test(8)
    _test(9)
    _test(10)


# Generated at 2022-06-18 11:39:20.202398
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def _sleep(t):
        time.sleep(t)
        return t

    def _sleep_tqdm(t):
        for _ in tqdm_auto(_range(t), desc='_sleep_tqdm'):
            time.sleep(1)
        return t

    def _sleep_tqdm_2(t):
        for _ in tqdm_auto(_range(t), desc='_sleep_tqdm_2'):
            time.sleep(1)
        return t

    def _sleep_tqdm_3(t):
        for _ in tqdm_auto(_range(t), desc='_sleep_tqdm_3'):
            time.sleep(1)
        return t


# Generated at 2022-06-18 11:39:28.364180
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    from concurrent.futures import Future
    from ..utils import _range

    def _test_submit(n, sleep_time, wait_time):
        """
        Test that `MonoWorker.submit` works as expected.
        """
        def _sleep(t):
            time.sleep(t)
            return t

        def _wait(f):
            f.result()

        mw = MonoWorker()
        for i in _range(n):
            mw.submit(_sleep, sleep_time)
            time.sleep(wait_time)
        for i in _range(n):
            mw.submit(_wait, Future())
            time.sleep(wait_time)

    n = 10
    sleep_time = 0.1
    wait_time = 0.

# Generated at 2022-06-18 11:39:33.302526
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(5):
        mw.submit(f, i)
    for i in _range(5):
        assert mw.futures[i].result() == 4 - i

# Generated at 2022-06-18 11:39:41.248945
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    from threading import Event
    from concurrent.futures import Future

    def func(x, y, z, delay=0.1):
        time.sleep(delay)
        return x + y + z

    def func_raises(x, y, z, delay=0.1):
        time.sleep(delay)
        raise ValueError(x + y + z)

    def func_cancel(x, y, z, delay=0.1, event=None):
        time.sleep(delay)
        event.wait()
        return x + y + z

    def func_cancel_raises(x, y, z, delay=0.1, event=None):
        time.sleep(delay)
        event.wait()
        raise ValueError(x + y + z)


# Generated at 2022-06-18 11:39:50.695559
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def setUp(self):
            self.mw = MonoWorker()
            self.func = lambda: None
            self.args = ()
            self.kwargs = {}
            self.event = Event()

        def test_submit(self):
            """Test that the most recent task is executed."""
            self.mw.submit(self.func, *self.args, **self.kwargs)
            self.mw.submit(self.func, *self.args, **self.kwargs)
            self.mw.submit(self.func, *self.args, **self.kwargs)

# Generated at 2022-06-18 11:39:56.541246
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    from concurrent.futures import as_completed

    def f(x):
        time.sleep(random.random())
        return x

    mw = MonoWorker()
    futures = [mw.submit(f, i) for i in range(10)]
    for future in as_completed(futures):
        print(future.result())

# Generated at 2022-06-18 11:40:06.454660
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Thread
    from ..utils import format_sizeof

    def _test_submit(worker):
        def _submit(i):
            worker.submit(time.sleep, i)
            time.sleep(0.1)

        threads = [Thread(target=_submit, args=(i,)) for i in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

    tqdm_auto.write("Testing MonoWorker.submit()")
    tqdm_auto.write("MonoWorker.submit() should only run one task at a time")
    tqdm_auto.write("MonoWorker.submit() should only keep the most recent task")

# Generated at 2022-06-18 11:40:09.835469
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
        time.sleep(0.1)

# Generated at 2022-06-18 11:40:27.324753
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event

    def func(i, e):
        time.sleep(i)
        e.set()

    e1 = Event()
    e2 = Event()
    e3 = Event()
    mw = MonoWorker()
    mw.submit(func, 1, e1)
    mw.submit(func, 2, e2)
    mw.submit(func, 3, e3)
    assert not e1.is_set()
    assert not e2.is_set()
    assert e3.is_set()
    assert not e1.is_set()
    assert not e2.is_set()
    assert e3.is_set()
    time.sleep(1)
    assert e1.is_set()
    assert not e2.is_set()


# Generated at 2022-06-18 11:40:35.669554
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future

    def func(x):
        time.sleep(x)
        return x

    def func_exception(x):
        time.sleep(x)
        raise Exception('exception')

    def func_cancel(x):
        time.sleep(x)
        return x

    def func_cancel_exception(x):
        time.sleep(x)
        raise Exception('exception')

    def func_cancel_exception_cancel(x):
        time.sleep(x)
        raise Exception('exception')

    def func_cancel_exception_cancel_exception(x):
        time.sleep(x)
        raise Exception('exception')


# Generated at 2022-06-18 11:40:43.040186
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import TimeoutError

    def func(x, y, z, evt):
        evt.wait()
        return x + y + z

    evt = Event()
    mw = MonoWorker()
    f1 = mw.submit(func, 1, 2, 3, evt)
    f2 = mw.submit(func, 4, 5, 6, evt)
    f3 = mw.submit(func, 7, 8, 9, evt)
    f4 = mw.submit(func, 10, 11, 12, evt)
    assert f1.done()
    assert f2.done()
    assert f3.done()
    assert not f4.done()

# Generated at 2022-06-18 11:40:50.176006
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from threading import Event
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def test_submit(self):
            def func(x, y, z):
                time.sleep(z)
                return x + y

            def func_exception(x, y, z):
                time.sleep(z)
                raise Exception('test_exception')

            def func_cancel(x, y, z):
                time.sleep(z)
                return x + y

            def func_cancel_exception(x, y, z):
                time.sleep(z)
                raise Exception('test_cancel_exception')


# Generated at 2022-06-18 11:40:55.076320
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event

    def wait_and_print(i, e):
        e.wait()
        print(i)

    e = Event()
    mw = MonoWorker()
    mw.submit(wait_and_print, 1, e)
    mw.submit(wait_and_print, 2, e)
    mw.submit(wait_and_print, 3, e)
    sleep(0.1)
    e.set()
    sleep(0.1)
    assert mw.futures[0].result() == 3
    assert mw.futures[1].result() == 2

# Generated at 2022-06-18 11:41:02.744006
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future

    def wait_and_return(wait_time, return_value):
        time.sleep(wait_time)
        return return_value

    def wait_and_raise(wait_time, exception):
        time.sleep(wait_time)
        raise exception

    def wait_and_cancel(wait_time, event):
        event.wait()
        time.sleep(wait_time)

    def test_submit(func, *args, **kwargs):
        worker = MonoWorker()
        future = worker.submit(func, *args, **kwargs)
        assert isinstance(future, Future)
        assert future.done() == False
        return future


# Generated at 2022-06-18 11:41:06.889386
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(5):
        mw.submit(f, i)
        time.sleep(0.1)
    assert mw.futures[0].result() == 4
    assert len(mw.futures) == 1

# Generated at 2022-06-18 11:41:14.604465
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    from threading import Event
    from concurrent.futures import Future

    def func(x, y, z):
        time.sleep(random.random())
        return x + y + z

    def test_func(x, y, z):
        time.sleep(random.random())
        return x + y + z

    def test_func_exception(x, y, z):
        time.sleep(random.random())
        raise Exception('test_func_exception')

    def test_func_cancel(x, y, z):
        time.sleep(random.random())
        return x + y + z

    def test_func_cancel_exception(x, y, z):
        time.sleep(random.random())

# Generated at 2022-06-18 11:41:17.768530
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(5):
        mw.submit(func, i)
    for i in _range(5):
        assert mw.futures[i].result() == 4 - i

# Generated at 2022-06-18 11:41:25.339498
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import unittest
    from concurrent.futures import as_completed

    class TestMonoWorker(unittest.TestCase):
        def test_submit(self):
            def func(x):
                time.sleep(random.random())
                return x

            mw = MonoWorker()
            futures = []
            for i in range(10):
                futures.append(mw.submit(func, i))
            for f in as_completed(futures):
                self.assertEqual(f.result(), 9)

    unittest.main(argv=['first-arg-is-ignored'], exit=False)

# Generated at 2022-06-18 11:41:47.155943
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    from concurrent.futures import Future
    from ..utils import _range

    def _sleep_and_return(x, delay=0.1):
        time.sleep(delay)
        return x

    def _check_future(fut, expected):
        assert isinstance(fut, Future)
        assert fut.result() == expected

    def _check_futures(futures, expected):
        assert len(futures) == len(expected)
        for fut, exp in zip(futures, expected):
            _check_future(fut, exp)

    def _check_futures_in_order(futures, expected):
        assert len(futures) == len(expected)
        for fut, exp in zip(futures, expected):
            _check

# Generated at 2022-06-18 11:41:51.439426
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
    for i in _range(10):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:41:57.337911
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(5):
        mw.submit(f, i)
        time.sleep(0.05)
    for i in _range(5):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:42:06.374262
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import TimeoutError
    from ..utils import _range

    def _test_submit(n, sleep, timeout):
        mw = MonoWorker()
        for i in _range(n):
            mw.submit(time.sleep, sleep)
        try:
            mw.futures[0].result(timeout=timeout)
        except TimeoutError:
            pass
        assert len(mw.futures) == 1
        assert not mw.futures[0].done()

    _test_submit(n=3, sleep=0.1, timeout=0.05)
    _test_submit(n=3, sleep=0.1, timeout=0.15)

# Generated at 2022-06-18 11:42:16.568997
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from unittest import TestCase, main

    class Test(TestCase):
        def test_submit(self):
            def f(x):
                sleep(x)
                return x

            mw = MonoWorker()
            e = Event()
            e.set()
            mw.submit(e.wait)
            mw.submit(e.wait)
            mw.submit(e.wait)
            mw.submit(e.wait)
            mw.submit(e.wait)
            mw.submit(e.wait)
            mw.submit(e.wait)
            mw.submit(e.wait)
            mw.submit(e.wait)
            mw.submit(e.wait)
            mw.submit(e.wait)

# Generated at 2022-06-18 11:42:21.432034
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def sleep_and_return(x, sleep_time=0.1):
        time.sleep(sleep_time)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(sleep_and_return, i)
    time.sleep(0.5)
    assert len(mw.futures) == 1
    assert mw.futures[0].result() == 9

# Generated at 2022-06-18 11:42:24.068042
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event

    def func(i, e):
        e.wait()
        return i

    e = Event()
    mw = MonoWorker()
    for i in range(5):
        mw.submit(func, i, e)
    e.set()
    time.sleep(0.1)
    assert mw.futures[0].result() == 4

# Generated at 2022-06-18 11:42:33.416009
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    from threading import Lock
    from concurrent.futures import Future
    from ..utils import _range

    def _test_MonoWorker_submit(n, sleep=0.01, sleep_max=0.1,
                                sleep_rand=0.1, sleep_rand_max=0.5):
        """
        Test `MonoWorker.submit` with `n` tasks.

        Parameters
        ----------
        n  : int
            Number of tasks to submit.
        sleep  : float
            Sleep time for each task.
        sleep_max  : float
            Maximum sleep time for each task.
        sleep_rand  : float
            Random sleep time for each task.
        sleep_rand_max  : float
            Maximum random sleep time for each task.
        """
        # Initialize

# Generated at 2022-06-18 11:42:42.246701
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event

    def func(x, y, z):
        sleep(x)
        return x + y + z

    def test_func(x, y, z, evt):
        evt.wait()
        return func(x, y, z)

    def test_func_exception(x, y, z, evt):
        evt.wait()
        raise Exception('test_func_exception')

    def test_func_cancel(x, y, z, evt):
        evt.wait()
        while True:
            sleep(1)

    mw = MonoWorker()
    evt = Event()
    evt.clear()
    assert mw.submit(test_func, 1, 2, 3, evt) is None
    assert mw.submit

# Generated at 2022-06-18 11:42:45.867230
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
    assert mw.futures[0].result() == 9
    assert mw.futures[1].result() == 8

# Generated at 2022-06-18 11:43:30.093048
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import unittest

    class TestMonoWorker(unittest.TestCase):
        def setUp(self):
            self.worker = MonoWorker()

        def test_submit(self):
            def func(x):
                time.sleep(random.random())
                return x

            for i in range(10):
                self.worker.submit(func, i)
                time.sleep(random.random())

            for i in range(10):
                self.assertEqual(self.worker.futures[i].result(), i)

    unittest.main()

# Generated at 2022-06-18 11:43:34.202430
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(3):
        mw.submit(f, i)
        time.sleep(0.05)
    assert mw.futures[0].result() == 2

# Generated at 2022-06-18 11:43:40.281961
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event

    def f(x, e):
        e.wait()
        return x

    e = Event()
    mw = MonoWorker()
    mw.submit(f, 1, e)
    mw.submit(f, 2, e)
    mw.submit(f, 3, e)
    mw.submit(f, 4, e)
    mw.submit(f, 5, e)
    sleep(0.1)
    assert len(mw.futures) == 1
    e.set()
    assert mw.futures[0].result() == 5

# Generated at 2022-06-18 11:43:48.280776
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future

    def func(x):
        time.sleep(x)
        return x

    def func_exception(x):
        raise Exception("x={}".format(x))

    def func_cancel(x):
        time.sleep(x)
        return x

    def func_cancel_exception(x):
        time.sleep(x)
        raise Exception("x={}".format(x))

    def func_cancel_exception_2(x):
        time.sleep(x)
        raise Exception("x={}".format(x))

    def func_cancel_exception_3(x):
        time.sleep(x)
        raise Exception("x={}".format(x))


# Generated at 2022-06-18 11:43:56.729704
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def test_submit(self):
            def func(x):
                sleep(x)
                return x

            def func_exception(x):
                raise Exception(x)

            def func_cancel(x):
                sleep(x)
                return x

            def func_cancel_exception(x):
                sleep(x)
                raise Exception(x)

            def func_cancel_exception_cancel(x):
                sleep(x)
                raise Exception(x)

            def func_cancel_exception_cancel_exception(x):
                sleep(x)
                raise Exception(x)


# Generated at 2022-06-18 11:44:04.225715
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from concurrent.futures import Future
    from multiprocessing import Value
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def test_submit(self):
            lock = Lock()
            counter = Value('i', 0)
            def increment(n):
                sleep(n)
                with lock:
                    counter.value += 1
            mw = MonoWorker()
            self.assertEqual(len(mw.futures), 0)
            f1 = mw.submit(increment, 0.1)
            self.assertIsInstance(f1, Future)
            self.assertEqual(len(mw.futures), 1)
            f2 = mw.submit(increment, 0.2)
            self

# Generated at 2022-06-18 11:44:08.897115
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.05)
    for i in _range(10):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:44:16.776554
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Lock
    from concurrent.futures import Future
    from unittest import TestCase, main

    class Test(TestCase):
        def setUp(self):
            self.lock = Lock()
            self.worker = MonoWorker()
            self.futures = []

        def test_submit(self):
            def func(i):
                time.sleep(0.1)
                with self.lock:
                    self.futures.append(i)
            for i in range(10):
                self.worker.submit(func, i)
            time.sleep(0.2)
            with self.lock:
                self.assertEqual(self.futures, [9])

    main()

# Generated at 2022-06-18 11:44:23.605139
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    import concurrent.futures

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    assert mw.submit(f, 0.1).result() == 0.1
    assert mw.submit(f, 0.2).result() == 0.2
    assert mw.submit(f, 0.3).result() == 0.3
    assert mw.submit(f, 0.4).result() == 0.4
    assert mw.submit(f, 0.5).result() == 0.5
    assert mw.submit(f, 0.6).result() == 0.6
    assert mw.submit(f, 0.7).result() == 0.7
    assert mw.submit(f, 0.8).result

# Generated at 2022-06-18 11:44:32.702912
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def _test(n, sleep, desc=None):
        if desc is None:
            desc = "test {}".format(n)
        with tqdm_auto.tqdm(total=n, desc=desc) as t:
            for _ in _range(n):
                time.sleep(sleep)
                t.update()

    mw = MonoWorker()
    mw.submit(_test, 10, 0.1, "test 1")
    mw.submit(_test, 10, 0.1, "test 2")
    mw.submit(_test, 10, 0.1, "test 3")
    mw.submit(_test, 10, 0.1, "test 4")
    mw.submit(_test, 10, 0.1, "test 5")
    m