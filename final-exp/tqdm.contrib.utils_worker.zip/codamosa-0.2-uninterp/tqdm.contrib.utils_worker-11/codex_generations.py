

# Generated at 2022-06-18 11:36:30.264508
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def _test_func(i):
        time.sleep(0.1)
        return i

    worker = MonoWorker()
    for i in _range(10):
        worker.submit(_test_func, i)
    time.sleep(1)

# Generated at 2022-06-18 11:36:36.917514
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def test_submit(self):
            def func(x):
                sleep(x)
                return x

            mw = MonoWorker()
            self.assertEqual(len(mw.futures), 0)
            f1 = mw.submit(func, 1)
            self.assertEqual(len(mw.futures), 1)
            self.assertEqual(f1.result(), 1)
            f2 = mw.submit(func, 2)
            self.assertEqual(len(mw.futures), 1)
            self.assertEqual(f2.result(), 2)
            f3 = m

# Generated at 2022-06-18 11:36:47.581920
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    from concurrent.futures import Future

    def _test_submit(mw, func, *args, **kwargs):
        """
        Test `mw.submit(func, *args, **kwargs)`
        """
        # Test that the function is called
        func_called = [False]
        def func_wrapper(*args, **kwargs):
            func_called[0] = True
            return func(*args, **kwargs)
        future = mw.submit(func_wrapper, *args, **kwargs)
        assert isinstance(future, Future)
        assert future.done()
        assert func_called[0]
        assert future.result() == func(*args, **kwargs)

        # Test that the function is called only once

# Generated at 2022-06-18 11:36:57.581043
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from threading import Event
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def test_submit(self):
            def func(x):
                time.sleep(x)
                return x

            mw = MonoWorker()
            f1 = mw.submit(func, 1)
            f2 = mw.submit(func, 2)
            f3 = mw.submit(func, 3)
            f4 = mw.submit(func, 4)
            self.assertIsInstance(f1, Future)
            self.assertIsInstance(f2, Future)
            self.assertIsInstance(f3, Future)
            self.assertIsInstance(f4, Future)

# Generated at 2022-06-18 11:37:09.679372
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import TimeoutError

    def wait_for(e, timeout=0.1):
        """Wait for event `e` to be set or timeout"""
        e.wait(timeout)
        if not e.is_set():
            raise TimeoutError()

    def wait_for_not(e, timeout=0.1):
        """Wait for event `e` to not be set or timeout"""
        e.wait(timeout)
        if e.is_set():
            raise TimeoutError()

    def wait_for_event(e, timeout=0.1):
        """Wait for event `e` to be set or timeout"""
        e.wait(timeout)
        if not e.is_set():
            raise TimeoutError()
        e.clear()

   

# Generated at 2022-06-18 11:37:18.136809
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from .utils import TestTqdmIO

    def func(x):
        time.sleep(x)
        return x

    with TestTqdmIO() as t:
        worker = MonoWorker()
        for i in range(3):
            worker.submit(func, i)
        time.sleep(1)
        worker.submit(func, 3)
        time.sleep(1)
        worker.submit(func, 4)
        time.sleep(1)
        worker.submit(func, 5)
        time.sleep(1)
        worker.submit(func, 6)
        time.sleep(1)
        worker.submit(func, 7)
        time.sleep(1)
        worker.submit(func, 8)
        time.sleep(1)
        worker.submit(func, 9)


# Generated at 2022-06-18 11:37:27.033547
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from ..utils import _range

    def func(i):
        time.sleep(0.01)
        return i

    def test_func(i):
        time.sleep(0.01)
        raise Exception("test_func")

    mw = MonoWorker()
    for i in _range(10):
        f = mw.submit(func, i)
        assert isinstance(f, Future)
        assert f.result() == i
    for i in _range(10):
        f = mw.submit(test_func, i)
        try:
            f.result()
        except Exception:
            pass
        else:
            assert False, "Exception not raised"

# Generated at 2022-06-18 11:37:32.838750
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def _test_submit(n, sleep):
        mw = MonoWorker()
        for i in _range(n):
            mw.submit(time.sleep, sleep)
            time.sleep(sleep / 10)

    _test_submit(10, 0.1)
    _test_submit(10, 0.2)
    _test_submit(10, 0.3)

# Generated at 2022-06-18 11:37:40.358883
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from concurrent.futures import Future
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def setUp(self):
            self.lock = Lock()
            self.worker = MonoWorker()
            self.futures = []

        def test_submit(self):
            def func(i):
                with self.lock:
                    self.futures.append(i)
                sleep(0.1)
                return i

            for i in range(5):
                self.worker.submit(func, i)
            sleep(0.5)
            with self.lock:
                self.assertEqual(self.futures, [4])


# Generated at 2022-06-18 11:37:45.265243
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
    for i in _range(10):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:37:57.028329
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Lock
    from concurrent.futures import as_completed

    def func(x, y, z):
        sleep(random())
        return x + y + z

    def test_func(x, y, z):
        sleep(random())
        return x + y + z

    def test_func_exception(x, y, z):
        sleep(random())
        raise Exception(x + y + z)

    def test_func_lock(x, y, z, lock):
        sleep(random())
        with lock:
            return x + y + z

    def test_func_lock_exception(x, y, z, lock):
        sleep(random())
        with lock:
            raise Exception(x + y + z)


# Generated at 2022-06-18 11:38:05.226759
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from ..utils import _range

    def _test_func(x):
        time.sleep(0.1)
        return x

    def _test_func_exception(x):
        raise Exception("test exception")

    def _test_func_cancel(x):
        for _ in _range(10):
            time.sleep(0.01)
            if x.done():
                return

    def _test_func_cancel_exception(x):
        for _ in _range(10):
            time.sleep(0.01)
            if x.done():
                raise Exception("test exception")

    def _test_func_cancel_exception_2(x):
        for _ in _range(10):
            time.sleep(0.01)


# Generated at 2022-06-18 11:38:09.305014
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(5):
        mw.submit(f, i)
        time.sleep(0.05)
    time.sleep(0.1)
    assert mw.futures[0].result() == 4

# Generated at 2022-06-18 11:38:13.872543
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def test_func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(5):
        mw.submit(test_func, i)
        time.sleep(0.05)
    assert mw.futures[0].result() == 4

# Generated at 2022-06-18 11:38:24.267362
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event

    def wait_for_event(event):
        event.wait()

    def wait_for_time(seconds):
        time.sleep(seconds)

    def wait_for_exception():
        raise Exception("test exception")

    event = Event()
    worker = MonoWorker()
    assert len(worker.futures) == 0
    assert worker.submit(wait_for_event, event)
    assert len(worker.futures) == 1
    assert worker.submit(wait_for_time, 0.1)
    assert len(worker.futures) == 1
    assert worker.submit(wait_for_exception)
    assert len(worker.futures) == 1
    assert worker.submit(wait_for_time, 0.1)

# Generated at 2022-06-18 11:38:35.298362
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import as_completed

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    mw.submit(f, 1)
    mw.submit(f, 2)
    mw.submit(f, 3)
    mw.submit(f, 4)
    mw.submit(f, 5)
    mw.submit(f, 6)
    mw.submit(f, 7)
    mw.submit(f, 8)
    mw.submit(f, 9)
    mw.submit(f, 10)
    mw.submit(f, 11)
    mw.submit(f, 12)
    mw.submit(f, 13)
    mw.submit(f, 14)


# Generated at 2022-06-18 11:38:42.564388
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from ..utils import format_sizeof

    def func(x):
        sleep(x)
        return x

    def test(n, x):
        mw = MonoWorker()
        for i in range(n):
            mw.submit(func, x)
        return mw

    def test_sizeof(n, x):
        mw = test(n, x)
        return format_sizeof(mw)

    assert test_sizeof(0, 0) == '0 B'
    assert test_sizeof(1, 0) == '0 B'
    assert test_sizeof(2, 0) == '0 B'
    assert test_sizeof(3, 0) == '0 B'


# Generated at 2022-06-18 11:38:48.472818
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
        time.sleep(0.1)
    for i in _range(10):
        mw.submit(func, i)
        time.sleep(0.1)

# Generated at 2022-06-18 11:38:59.141607
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import sys
    import threading
    from concurrent.futures import Future
    from ..utils import _range

    def _test_func(x):
        time.sleep(0.1)
        return x

    # Test with no running task
    worker = MonoWorker()
    for i in _range(10):
        future = worker.submit(_test_func, i)
        assert future.result() == i

    # Test with running task
    worker = MonoWorker()
    future = worker.submit(_test_func, 0)
    for i in _range(1, 10):
        future = worker.submit(_test_func, i)
        assert future.result() == i

    # Test with running and waiting tasks
    worker = MonoWorker()
    future = worker.submit(_test_func, 0)


# Generated at 2022-06-18 11:39:05.922490
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range
    from ..std import time as time_std

    def _test_submit(n, sleep_time):
        def _test_func(i):
            time.sleep(sleep_time)
            return i

        mw = MonoWorker()
        for i in _range(n):
            mw.submit(_test_func, i)
        time_std.sleep(sleep_time * n)
        assert mw.futures[0].done()
        assert mw.futures[0].result() == n - 1

    _test_submit(10, 0.1)
    _test_submit(10, 0.5)

# Generated at 2022-06-18 11:39:17.850536
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import as_completed

    def f(x, wait, e):
        sleep(wait)
        e.set()
        return x

    e = Event()
    mw = MonoWorker()
    f1 = mw.submit(f, 1, 1, e)
    f2 = mw.submit(f, 2, 2, e)
    f3 = mw.submit(f, 3, 3, e)
    f4 = mw.submit(f, 4, 4, e)
    f5 = mw.submit(f, 5, 5, e)
    f6 = mw.submit(f, 6, 6, e)
    f7 = mw.submit(f, 7, 7, e)
    f8 = m

# Generated at 2022-06-18 11:39:21.628015
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(5):
        mw.submit(f, i)
    time.sleep(1)
    assert mw.futures[0].result() == 4
    assert len(mw.futures) == 1

# Generated at 2022-06-18 11:39:30.376327
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading

    def worker(i):
        time.sleep(random.random())
        return i

    mw = MonoWorker()
    for i in range(10):
        mw.submit(worker, i)
    time.sleep(0.1)
    assert len(mw.futures) == 1
    assert mw.futures[0].result() == 9
    time.sleep(0.1)
    assert len(mw.futures) == 0

    def worker(i):
        time.sleep(random.random())
        return i

    mw = MonoWorker()
    for i in range(10):
        mw.submit(worker, i)
    time.sleep(0.1)

# Generated at 2022-06-18 11:39:34.599343
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(5):
        mw.submit(f, i)
        time.sleep(0.1)
    assert mw.futures[0].result() == 4

# Generated at 2022-06-18 11:39:42.284781
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import Future
    from contextlib import contextmanager

    @contextmanager
    def assert_no_exception(msg=None):
        try:
            yield
        except Exception as e:
            raise AssertionError(msg or str(e))

    def wait_for_future(future, timeout=1):
        event = Event()
        future.add_done_callback(lambda f: event.set())
        event.wait(timeout)

    def wait_for_futures(futures, timeout=1):
        events = [Event() for _ in futures]
        for future, event in zip(futures, events):
            future.add_done_callback(lambda f: event.set())

# Generated at 2022-06-18 11:39:52.565363
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import TimeoutError
    from ..utils import _range

    def _test_submit(mw, n_tasks, timeout, n_workers=1):
        """
        Test `MonoWorker.submit` with `n_tasks` tasks.
        """
        def _task(i):
            time.sleep(timeout)
            return i

        results = []
        for i in _range(n_tasks):
            results.append(mw.submit(_task, i))
        for i in _range(n_tasks):
            try:
                results[i].result(timeout=timeout)
            except TimeoutError:
                pass
        assert len(results) == n_tasks
        assert len(mw.futures) == n_workers

# Generated at 2022-06-18 11:40:00.732919
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event

    def func(x, y, z, e):
        sleep(x)
        e.set()
        return x + y + z

    e = Event()
    mw = MonoWorker()
    assert mw.submit(func, 1, 2, 3, e) == 6
    assert not e.is_set()
    assert mw.submit(func, 2, 3, 4, e) == 9
    assert not e.is_set()
    assert mw.submit(func, 3, 4, 5, e) == 12
    assert e.is_set()

# Generated at 2022-06-18 11:40:08.444314
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up
    from ..utils import _range

    def func(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
        tqdm_auto.write("{}".format(i))
        _term_move_up()
    for i in _range(10):
        tqdm_auto.write("{}".format(mw.futures[0].result()))
        _term_move_up()

# Generated at 2022-06-18 11:40:15.476491
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from ..utils import _range

    def _test_MonoWorker_submit(n, sleep):
        def _test_MonoWorker_submit_func(i):
            time.sleep(sleep)
            return i

        mw = MonoWorker()
        futures = []
        for i in _range(n):
            futures.append(mw.submit(_test_MonoWorker_submit_func, i))
        for i, f in enumerate(futures):
            assert isinstance(f, Future)
            assert f.result() == i
        assert len(mw.futures) == 1
        assert mw.futures[0].result() == n - 1

    _test_MonoWorker_submit(10, 0.1)


# Generated at 2022-06-18 11:40:26.357168
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import as_completed

    def func(x, y, z, sleep_time=0.1, sleep_time_2=0.2):
        sleep(sleep_time)
        return x + y + z

    mw = MonoWorker()
    e = Event()
    e.set()
    f1 = mw.submit(func, 1, 2, 3, sleep_time=0.5)
    f2 = mw.submit(func, 4, 5, 6, sleep_time=0.5)
    f3 = mw.submit(func, 7, 8, 9, sleep_time=0.5)
    f4 = mw.submit(func, 10, 11, 12, sleep_time=0.5)
    f5

# Generated at 2022-06-18 11:40:39.673381
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import as_completed
    from ..utils import format_sizeof

    def test_func(i, j):
        time.sleep(0.1)
        return i + j

    mw = MonoWorker()
    for i in range(10):
        mw.submit(test_func, i, i)
    for future in as_completed(mw.futures):
        print(future.result())

    print(format_sizeof(mw))

# Generated at 2022-06-18 11:40:46.736900
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Thread
    from concurrent.futures import Future
    from functools import partial

    def _test_MonoWorker_submit(mw, tqdm_kwargs, sleep_time, n_tasks):
        """
        :param mw: MonoWorker instance
        :param tqdm_kwargs: tqdm kwargs
        :param sleep_time: sleep time
        :param n_tasks: number of tasks
        """
        def _submit(i):
            """
            :param i: task index
            """
            with tqdm_auto(**tqdm_kwargs) as t:
                sleep(sleep_time * random())
                t.set_description("Task {}".format(i))


# Generated at 2022-06-18 11:40:51.643998
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from multiprocessing import Process
    from multiprocessing.connection import Listener
    from multiprocessing.connection import Client
    from multiprocessing.connection import wait

    def server(evt, address):
        with Listener(address) as listener:
            conn = listener.accept()
            evt.set()
            conn.send(conn.recv())
            conn.close()

    def client(address, data):
        evt = Event()
        p = Process(target=server, args=(evt, address))
        p.start()
        evt.wait()
        with Client(address) as conn:
            conn.send(data)
            return conn.recv()

    def func(address, data):
        return client(address, data)



# Generated at 2022-06-18 11:40:56.013360
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
    time.sleep(0.1)
    assert mw.futures[0].done()
    assert not mw.futures[1].done()
    time.sleep(0.1)
    assert mw.futures[1].done()
    assert mw.futures[0].result() == 9
    assert mw.futures[1].result() == 8

# Generated at 2022-06-18 11:41:04.096178
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Event
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def test_submit(self):
            def func(x, y, z):
                sleep(x)
                return x + y + z

            def test_func(x, y, z, e):
                e.set()
                return x + y + z

            e = Event()
            mw = MonoWorker()
            for _ in range(10):
                x = random()
                y = random()
                z = random()
                f = mw.submit(func, x, y, z)
                self.assertEqual(f.result(), x + y + z)
            for _ in range(10):
                x = random()
                y = random

# Generated at 2022-06-18 11:41:08.773593
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def _test_func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(_test_func, i)
    for i in _range(10):
        assert mw.futures[i].result() == i


if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-18 11:41:13.532138
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    from concurrent.futures import TimeoutError

    def func(i):
        time.sleep(random.random())
        return i

    mw = MonoWorker()
    for i in range(10):
        mw.submit(func, i)
    for i in range(10):
        try:
            assert mw.futures[0].result(timeout=0.1) == i
        except TimeoutError:
            pass

# Generated at 2022-06-18 11:41:18.643637
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import as_completed
    from itertools import count

    def func(x, evt):
        evt.wait()
        return x

    evt = Event()
    mw = MonoWorker()
    for i in count():
        mw.submit(func, i, evt)
        sleep(0.1)
        if i == 10:
            evt.set()
        if i == 20:
            break

    for future in as_completed(mw.futures):
        assert future.result() == 20

# Generated at 2022-06-18 11:41:28.001846
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
        time.sleep(0.1)
    for i in _range(10):
        mw.submit(func, i)
        time.sleep(0.1)
    for i in _range(10):
        mw.submit(func, i)
        time.sleep(0.1)
    for i in _range(10):
        mw.submit(func, i)
        time.sleep(0.1)
    for i in _range(10):
        mw.submit(func, i)
        time.sleep(0.1)

# Generated at 2022-06-18 11:41:33.818050
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import TimeoutError
    from tqdm.contrib.concurrent import MonoWorker

    def func(x):
        time.sleep(x)
        return x

    worker = MonoWorker()
    assert worker.submit(func, 1)
    assert worker.submit(func, 2)
    assert worker.submit(func, 3)
    assert worker.submit(func, 4)
    assert worker.submit(func, 5)
    assert worker.submit(func, 6)
    assert worker.submit(func, 7)
    assert worker.submit(func, 8)
    assert worker.submit(func, 9)
    assert worker.submit(func, 10)
    assert worker.submit(func, 11)
    assert worker.submit(func, 12)

# Generated at 2022-06-18 11:41:57.195907
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
    time.sleep(0.5)
    assert mw.futures[0].done()
    assert mw.futures[0].result() == 9
    assert len(mw.futures) == 1
    assert not mw.futures[0].cancel()
    assert mw.futures[0].done()
    assert mw.futures[0].result() == 9
    assert len(mw.futures) == 1

# Generated at 2022-06-18 11:42:06.884852
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)

# Generated at 2022-06-18 11:42:16.998130
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import as_completed

    def wait(duration, event):
        event.wait(duration)
        return duration

    def wait_and_cancel(duration, event):
        event.wait(duration)
        return duration

    def wait_and_raise(duration, event):
        event.wait(duration)
        raise Exception("Raised after {}s".format(duration))

    def wait_and_return(duration, event):
        event.wait(duration)
        return duration

    def wait_and_return_and_raise(duration, event):
        event.wait(duration)
        return duration

    def wait_and_return_and_raise_and_cancel(duration, event):
        event.wait(duration)
        return duration


# Generated at 2022-06-18 11:42:21.217026
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
    time.sleep(0.1)
    assert len(mw.futures) == 1
    assert mw.futures[0].result() == 9

# Generated at 2022-06-18 11:42:30.194034
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Thread
    from concurrent.futures import as_completed

    def func(x):
        sleep(random())
        return x

    mw = MonoWorker()
    futures = [mw.submit(func, i) for i in range(10)]
    for f in as_completed(futures):
        assert f.result() == futures.index(f)

    # Test that the waiting task is the most recent submitted
    mw = MonoWorker()
    futures = [mw.submit(func, i) for i in range(10)]
    for f in as_completed(futures):
        assert f.result() == futures.index(f)

    # Test that the waiting task is the most recent submitted
    mw = MonoWorker()

# Generated at 2022-06-18 11:42:39.598618
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import as_completed
    from tqdm.contrib.concurrency import MonoWorker

    def func(x):
        sleep(x)
        return x

    mw = MonoWorker()
    e = Event()
    e.clear()
    assert mw.submit(func, 0.1) == mw.submit(func, 0.2)
    assert mw.submit(func, 0.3) == mw.submit(func, 0.4)
    assert mw.submit(func, 0.5) == mw.submit(func, 0.6)
    assert mw.submit(func, 0.7) == mw.submit(func, 0.8)
    assert mw.submit(func, 0.9) == m

# Generated at 2022-06-18 11:42:47.285812
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future

    def wait(n):
        time.sleep(n)
        return n

    def wait_and_cancel(n, event):
        event.wait()
        return wait(n)

    def wait_and_raise(n):
        time.sleep(n)
        raise RuntimeError("{}".format(n))

    def wait_and_cancel_or_raise(n, event):
        event.wait()
        return wait_and_raise(n)

    def test_wait(n, event=None):
        mw = MonoWorker()
        if event is None:
            future = mw.submit(wait, n)
        else:
            future = mw.submit(wait_and_cancel, n, event)

# Generated at 2022-06-18 11:42:50.972212
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)
    assert mw.futures[0].result() == 9

# Generated at 2022-06-18 11:42:57.444567
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def _test_submit(n, sleep=0.1):
        mw = MonoWorker()
        for i in _range(n):
            mw.submit(time.sleep, sleep)
        time.sleep(sleep * n)

    _test_submit(1)
    _test_submit(2)
    _test_submit(3)
    _test_submit(4)
    _test_submit(5)
    _test_submit(6)
    _test_submit(7)
    _test_submit(8)
    _test_submit(9)
    _test_submit(10)

# Generated at 2022-06-18 11:43:03.625612
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    from concurrent.futures import as_completed

    def func(x):
        time.sleep(random.random() / 10)
        return x

    mw = MonoWorker()
    futures = [mw.submit(func, i) for i in range(10)]
    for future in as_completed(futures):
        assert future.result() == futures.index(future)

    # Test that the waiting task is the most recent submitted
    mw = MonoWorker()
    futures = [mw.submit(func, i) for i in range(10)]
    for future in as_completed(futures):
        assert future.result() == futures.index(future)

    # Test that the waiting task is the most recent submitted
    mw = MonoWorker

# Generated at 2022-06-18 11:43:50.777662
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(i):
        time.sleep(0.1)
        return i

    worker = MonoWorker()
    for i in _range(5):
        worker.submit(func, i)
        time.sleep(0.05)
    assert worker.futures[0].result() == 4

# Generated at 2022-06-18 11:43:58.950988
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def test_submit(self):
            def func(x):
                sleep(x)
                return x

            def func_exception(x):
                raise Exception(x)

            def func_cancel(x, e):
                e.wait()
                return x

            def func_cancel_exception(x, e):
                e.wait()
                raise Exception(x)

            mw = MonoWorker()
            self.assertEqual(len(mw.futures), 0)

            # submit
            f1 = mw.submit(func, 1)
            self.assertIsInstance(f1, Future)

# Generated at 2022-06-18 11:44:07.034741
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Lock
    from concurrent.futures import as_completed
    from tqdm import tqdm

    def func(x):
        sleep(random())
        return x

    def func_exception(x):
        raise Exception('test')

    def func_lock(x, lock):
        with lock:
            sleep(random())
            return x

    def func_lock_exception(x, lock):
        with lock:
            raise Exception('test')

    def test(func, *args, **kwargs):
        worker = MonoWorker()
        futures = [worker.submit(func, i, *args, **kwargs)
                   for i in range(10)]

# Generated at 2022-06-18 11:44:15.838531
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def test_submit(self):
            def wait(t):
                time.sleep(t)
                return t

            mw = MonoWorker()
            e = Event()
            e.clear()
            f1 = mw.submit(wait, 1)
            f2 = mw.submit(wait, 2)
            f3 = mw.submit(wait, 3)
            f4 = mw.submit(wait, 4)
            f5 = mw.submit(wait, 5)
            f6 = mw.submit(wait, 6)
            f7 = mw.submit(wait, 7)
            f8 = mw.submit(wait, 8)
            f9 = mw

# Generated at 2022-06-18 11:44:22.998700
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import TimeoutError

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    f1 = mw.submit(f, 1)
    f2 = mw.submit(f, 2)
    f3 = mw.submit(f, 3)
    assert f1.done()
    assert f2.done()
    assert not f3.done()
    assert f3.result(timeout=0.5) == 3
    assert f3.done()
    assert f3.result(timeout=0.5) == 3
    assert f3.done()
    assert f3.result(timeout=0.5) == 3
    assert f3.done()

# Generated at 2022-06-18 11:44:32.022482
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Lock
    from concurrent.futures import as_completed
    from tqdm.contrib.concurrency import MonoWorker

    def f(x):
        sleep(random())
        return x

    def g(x):
        sleep(random())
        raise Exception('g')

    def h(x):
        sleep(random())
        raise Exception('h')

    def i(x):
        sleep(random())
        raise Exception('i')

    def j(x):
        sleep(random())
        raise Exception('j')

    def k(x):
        sleep(random())
        raise Exception('k')

    def l(x):
        sleep(random())
        raise Exception('l')

    def m(x):
        sleep(random())
       

# Generated at 2022-06-18 11:44:39.598468
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from concurrent.futures import as_completed
    from ..utils import _range

    def worker(i):
        sleep(0.1)
        return i

    def test(n, max_workers=1):
        mw = MonoWorker()
        futures = [mw.submit(worker, i) for i in _range(n)]
        with tqdm_auto.tqdm(total=n, desc='test', miniters=1) as pbar:
            for f in as_completed(futures):
                pbar.update()
                assert f.result() == pbar.n - 1

    test(10)
    test(10, max_workers=2)

# Generated at 2022-06-18 11:44:42.016423
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
        time.sleep(0.01)

# Generated at 2022-06-18 11:44:46.960034
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Thread
    from queue import Queue

    def worker(q):
        for i in range(3):
            sleep(0.1)
            q.put(i)

    q = Queue()
    mw = MonoWorker()
    t = Thread(target=worker, args=(q,))
    t.start()
    for i in range(3):
        mw.submit(q.get)
    t.join()

# Generated at 2022-06-18 11:44:51.282594
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(i):
        time.sleep(1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)
    for i in _range(10):
        assert mw.futures[i].result() == i