

# Generated at 2022-06-18 11:36:34.302365
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import Future
    from nose.tools import assert_equal, assert_true, assert_false

    def wait(seconds):
        sleep(seconds)
        return seconds

    def wait_and_cancel(seconds, cancel_event):
        sleep(seconds)
        cancel_event.set()
        return seconds

    def wait_and_raise(seconds):
        sleep(seconds)
        raise Exception("wait_and_raise")

    def wait_and_cancel_and_raise(seconds, cancel_event):
        sleep(seconds)
        cancel_event.set()
        raise Exception("wait_and_cancel_and_raise")


# Generated at 2022-06-18 11:36:44.910377
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    from concurrent.futures import Future
    from ..utils import _range

    def _test_MonoWorker_submit(n, sleep_time, max_workers, max_tasks):
        def _test_MonoWorker_submit_func(i):
            time.sleep(sleep_time)
            return i

        def _test_MonoWorker_submit_func_exception(i):
            time.sleep(sleep_time)
            raise ValueError(i)

        def _test_MonoWorker_submit_func_cancel(i):
            time.sleep(sleep_time)
            return i

        def _test_MonoWorker_submit_func_cancel_exception(i):
            time.sleep(sleep_time)
            raise ValueError

# Generated at 2022-06-18 11:36:55.045278
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from unittest import TestCase

    class Test(TestCase):
        def setUp(self):
            self.lock = Lock()
            self.mono = MonoWorker()
            self.count = 0

        def test_submit(self):
            self.mono.submit(self.incr, 1)
            sleep(0.1)
            self.mono.submit(self.incr, 2)
            sleep(0.1)
            self.mono.submit(self.incr, 3)
            sleep(0.1)
            self.mono.submit(self.incr, 4)
            sleep(0.1)
            self.mono.submit(self.incr, 5)
            sleep(0.1)

# Generated at 2022-06-18 11:36:59.222271
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
        time.sleep(0.1)

# Generated at 2022-06-18 11:37:06.289456
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    from concurrent.futures import as_completed

    def func(x):
        time.sleep(random.random())
        return x

    mw = MonoWorker()
    futures = []
    for i in range(10):
        futures.append(mw.submit(func, i))

    for f in as_completed(futures):
        assert f.result() == 9

# Generated at 2022-06-18 11:37:15.535505
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    from concurrent.futures import as_completed

    def func(x):
        time.sleep(random.random() / 10)
        return x

    mw = MonoWorker()
    futures = [mw.submit(func, i) for i in range(10)]
    for f in as_completed(futures):
        assert f.result() == futures.index(f)

    # test that the waiting task is the most recent submitted
    def func(x):
        time.sleep(random.random() / 10)
        return x

    mw = MonoWorker()
    futures = [mw.submit(func, i) for i in range(10)]
    for f in as_completed(futures):
        assert f.result() == futures.index

# Generated at 2022-06-18 11:37:25.704536
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up
    from ..utils import _range

    def _test_submit(n):
        mw = MonoWorker()
        for i in _range(n):
            mw.submit(time.sleep, 0.1)
        for i in _range(n):
            mw.submit(time.sleep, 0.1)
            _term_move_up()
            print('\r' + ' ' * 80)
        for i in _range(n):
            mw.submit(time.sleep, 0.1)
            _term_move_up()
            print('\r' + ' ' * 80)
            _term_move_up()
            print('\r' + ' ' * 80)

    _test_submit(3)

# Generated at 2022-06-18 11:37:35.687030
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from .utils import _test_MonoWorker_submit

    def func(x):
        time.sleep(x)
        return x

    def func_exception(x):
        raise Exception('test')

    def func_cancel(x):
        time.sleep(x)
        return x

    def func_cancel_exception(x):
        time.sleep(x)
        raise Exception('test')

    def func_cancel_exception_exception(x):
        time.sleep(x)
        raise Exception('test')

    def func_cancel_exception_exception_exception(x):
        time.sleep(x)
        raise Exception('test')


# Generated at 2022-06-18 11:37:39.333057
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
        time.sleep(0.05)

# Generated at 2022-06-18 11:37:49.065886
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def _test_submit(n):
        mw = MonoWorker()
        for i in _range(n):
            mw.submit(time.sleep, 0.1)
        for i in _range(n):
            mw.submit(time.sleep, 0.1)
        for i in _range(n):
            mw.submit(time.sleep, 0.1)
        for i in _range(n):
            mw.submit(time.sleep, 0.1)
        for i in _range(n):
            mw.submit(time.sleep, 0.1)
        for i in _range(n):
            mw.submit(time.sleep, 0.1)

# Generated at 2022-06-18 11:37:58.104433
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up
    from ..utils import _range

    def print_n(n):
        for _ in _range(n):
            tqdm_auto.write('.')
            time.sleep(0.1)
        return n

    mw = MonoWorker()
    for i in _range(5):
        mw.submit(print_n, i)
        time.sleep(0.2)
    time.sleep(1)
    tqdm_auto.write(_term_move_up() + 'Done')

# Generated at 2022-06-18 11:38:04.908110
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up
    from ..utils import _range

    def func(x):
        time.sleep(0.1)
        return x

    def test_submit(n):
        with tqdm_auto.tqdm(total=n) as t:
            mw = MonoWorker()
            for i in _range(n):
                mw.submit(func, i)
                t.update()
            while mw.futures:
                time.sleep(0.01)
                t.refresh()
                _term_move_up()

    test_submit(10)
    test_submit(100)

# Generated at 2022-06-18 11:38:10.233594
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import as_completed

    def func(x, y, z, evt):
        evt.wait()
        return x + y + z

    evt = Event()
    evt.clear()
    mw = MonoWorker()
    f1 = mw.submit(func, 1, 2, 3, evt)
    f2 = mw.submit(func, 4, 5, 6, evt)
    f3 = mw.submit(func, 7, 8, 9, evt)
    assert f1.cancel()
    assert not f2.cancel()
    assert f3.cancel()
    evt.set()
    sleep(0.1)
    assert f2.result() == 4 + 5 + 6
   

# Generated at 2022-06-18 11:38:15.403423
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
    for i in _range(10):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:38:19.646106
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random

    def func(x):
        sleep(random())
        return x

    mw = MonoWorker()
    for i in range(10):
        mw.submit(func, i)
    for i in range(10):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:38:30.552238
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def _test_submit(n, sleep):
        mw = MonoWorker()
        for i in _range(n):
            mw.submit(time.sleep, sleep)
        for i in _range(n):
            mw.submit(time.sleep, sleep)
        for i in _range(n):
            mw.submit(time.sleep, sleep)

    _test_submit(1, 0.1)
    _test_submit(2, 0.1)
    _test_submit(3, 0.1)
    _test_submit(4, 0.1)
    _test_submit(5, 0.1)
    _test_submit(6, 0.1)
    _test_submit(7, 0.1)

# Generated at 2022-06-18 11:38:38.395509
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def _test_submit(n, sleep_time, max_workers):
        mw = MonoWorker()
        mw.pool = ThreadPoolExecutor(max_workers=max_workers)
        for i in _range(n):
            mw.submit(time.sleep, sleep_time)
        time.sleep(sleep_time * 2)

    for max_workers in [1, 2]:
        for n in [1, 2, 3, 4]:
            for sleep_time in [0.01, 0.1, 1]:
                _test_submit(n, sleep_time, max_workers)

# Generated at 2022-06-18 11:38:43.855947
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Thread
    from multiprocessing import Queue

    def func(q, i):
        sleep(0.1)
        q.put(i)

    q = Queue()
    mw = MonoWorker()
    for i in range(10):
        mw.submit(func, q, i)
    Thread(target=mw.pool.shutdown).start()
    assert q.get() == 9

# Generated at 2022-06-18 11:38:55.282214
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from threading import Event

    def wait(seconds):
        time.sleep(seconds)
        return seconds

    def wait_and_cancel(seconds, event):
        event.wait()
        return wait(seconds)

    def wait_and_raise(seconds):
        time.sleep(seconds)
        raise Exception('Raised after {} seconds'.format(seconds))

    def wait_and_cancel_and_raise(seconds, event):
        event.wait()
        return wait_and_raise(seconds)

    def test_wait(seconds):
        worker = MonoWorker()
        future = worker.submit(wait, seconds)
        assert isinstance(future, Future)
        assert future.result() == seconds


# Generated at 2022-06-18 11:39:02.601492
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event

    def f(x, e):
        e.wait()
        return x

    e = Event()
    mw = MonoWorker()
    assert len(mw.futures) == 0
    mw.submit(f, 1, e)
    assert len(mw.futures) == 1
    mw.submit(f, 2, e)
    assert len(mw.futures) == 1
    e.set()
    time.sleep(0.1)
    assert len(mw.futures) == 0
    assert mw.futures[0].result() == 2

# Generated at 2022-06-18 11:39:13.600902
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def test_submit(self):
            def func(x):
                time.sleep(x)
                return x

            mw = MonoWorker()
            f1 = mw.submit(func, 1)
            f2 = mw.submit(func, 2)
            self.assertEqual(f1.result(), 1)
            self.assertEqual(f2.result(), 2)

            f3 = mw.submit(func, 3)
            self.assertEqual(f3.result(), 3)

            f4 = mw.submit(func, 4)
            self.assertEqual(f4.result(), 4)


# Generated at 2022-06-18 11:39:17.244085
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def worker(i):
        time.sleep(1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(worker, i)
    for i in _range(10):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:39:20.326505
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(i):
        time.sleep(1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
    for i in _range(10):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:39:28.476809
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from threading import Event
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def test_submit(self):
            def func(x):
                time.sleep(x)
                return x

            mw = MonoWorker()
            f1 = mw.submit(func, 1)
            f2 = mw.submit(func, 2)
            f3 = mw.submit(func, 3)
            f4 = mw.submit(func, 4)
            self.assertIsInstance(f1, Future)
            self.assertIsInstance(f2, Future)
            self.assertIsInstance(f3, Future)
            self.assertIsInstance(f4, Future)

# Generated at 2022-06-18 11:39:37.545477
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    mw.submit(f, 1)
    mw.submit(f, 2)
    mw.submit(f, 3)
    mw.submit(f, 4)
    mw.submit(f, 5)
    mw.submit(f, 6)
    mw.submit(f, 7)
    mw.submit(f, 8)
    mw.submit(f, 9)
    mw.submit(f, 10)
    mw.submit(f, 11)
    mw.submit(f, 12)
    mw.submit(f, 13)
    mw.submit(f, 14)
   

# Generated at 2022-06-18 11:39:44.805746
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from ..utils import _range

    def _test_func(i):
        time.sleep(0.1)
        return i

    def _test_func_exception(i):
        raise Exception("test exception")

    def _test_func_cancel(i):
        time.sleep(1)
        return i

    def _test_func_cancel_exception(i):
        time.sleep(1)
        raise Exception("test exception")

    def _test_func_cancel_exception_2(i):
        time.sleep(1)
        raise Exception("test exception 2")

    def _test_func_cancel_exception_3(i):
        time.sleep(1)
        raise Exception("test exception 3")


# Generated at 2022-06-18 11:39:49.360496
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(i):
        time.sleep(0.5)
        return i

    mw = MonoWorker()
    for i in _range(5):
        mw.submit(func, i)
        time.sleep(0.1)
    time.sleep(2)

# Generated at 2022-06-18 11:39:54.027202
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)

# Generated at 2022-06-18 11:40:01.906146
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import as_completed
    from ..utils import format_sizeof

    def test_func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    futures = [mw.submit(test_func, x) for x in [1, 2, 3, 4, 5]]
    for f in as_completed(futures):
        print(format_sizeof(f.result()))
    print(format_sizeof(mw.futures))

# Generated at 2022-06-18 11:40:10.949700
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import TimeoutError

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    assert mw.submit(f, 1)
    assert mw.submit(f, 2)
    assert mw.submit(f, 3)
    assert mw.submit(f, 4)
    assert mw.submit(f, 5)
    assert mw.submit(f, 6)
    assert mw.submit(f, 7)
    assert mw.submit(f, 8)
    assert mw.submit(f, 9)
    assert mw.submit(f, 10)
    assert mw.submit(f, 11)
    assert mw.submit(f, 12)
    assert mw.submit(f, 13)

# Generated at 2022-06-18 11:40:24.617590
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from .utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
    assert mw.futures[0].result() == 9
    assert mw.futures[1].result() == 8

# Generated at 2022-06-18 11:40:32.312547
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Lock
    from concurrent.futures import as_completed
    from tqdm.contrib.concurrency import MonoWorker

    def func(x):
        sleep(random())
        return x

    with MonoWorker() as worker:
        with tqdm_auto.tqdm(total=10) as t:
            futures = [worker.submit(func, i) for i in range(10)]
            for future in as_completed(futures):
                t.update()
                assert future.result() == t.n - 1

# Generated at 2022-06-18 11:40:38.878589
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from ..utils import _range

    def _test_submit(mw, func, *args, **kwargs):
        """
        Test that `mw.submit(func, *args, **kwargs)` returns a `Future`
        that is not done and that `func(*args, **kwargs)` is called.
        """
        future = mw.submit(func, *args, **kwargs)
        assert isinstance(future, Future)
        assert not future.done()
        time.sleep(0.1)
        assert future.done()
        return future


# Generated at 2022-06-18 11:40:42.226706
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.01)
    assert mw.futures[0].result() == 9

# Generated at 2022-06-18 11:40:47.059936
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in range(5):
        mw.submit(func, i)
        time.sleep(0.1)
        _term_move_up()
        print(i)
    print(mw.futures)
    print(mw.futures[0].result())
    print(mw.futures[1].result())

# Generated at 2022-06-18 11:40:51.901087
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import as_completed

    def func(x):
        sleep(x)
        return x

    mw = MonoWorker()
    e = Event()
    e.set()
    mw.submit(e.wait)
    e.clear()
    mw.submit(e.wait)
    e.set()
    mw.submit(e.wait)
    e.clear()
    mw.submit(e.wait)
    e.set()
    mw.submit(e.wait)
    e.clear()
    mw.submit(e.wait)
    e.set()
    mw.submit(e.wait)
    e.clear()
    mw.submit(e.wait)
    e.set()

# Generated at 2022-06-18 11:40:56.973063
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from random import random
    from threading import Lock
    from concurrent.futures import as_completed

    def func(x, y):
        time.sleep(random())
        return x + y

    def test_submit(x, y, expected):
        mw = MonoWorker()
        assert mw.submit(func, x, y).result() == expected

    test_submit(1, 2, 3)
    test_submit(1, 2, 3)
    test_submit(1, 2, 3)
    test_submit(1, 2, 3)
    test_submit(1, 2, 3)
    test_submit(1, 2, 3)
    test_submit(1, 2, 3)
    test_submit(1, 2, 3)

# Generated at 2022-06-18 11:41:01.034100
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.01)
    for i in _range(10):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:41:09.285568
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    from concurrent.futures import as_completed

    def func(x):
        time.sleep(random.random())
        return x

    mw = MonoWorker()
    futures = [mw.submit(func, i) for i in range(10)]
    for future in as_completed(futures):
        assert future.result() == futures.index(future)

    # Test that the waiting task is the most recent submitted
    def func2(x):
        time.sleep(random.random())
        return x

    mw = MonoWorker()
    futures = [mw.submit(func2, i) for i in range(10)]
    for future in as_completed(futures):
        assert future.result() == futures.index(future)



# Generated at 2022-06-18 11:41:16.779925
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Thread
    from queue import Queue

    def worker(q, i):
        q.put(i)
        sleep(0.1)
        q.put(i)

    q = Queue()
    mw = MonoWorker()
    for i in range(10):
        mw.submit(worker, q, i)
    for i in range(10):
        assert q.get() == i
        assert q.get() == i
    assert q.empty()

    # Test that the most recent task is kept
    q = Queue()
    mw = MonoWorker()
    for i in range(10):
        mw.submit(worker, q, i)
        sleep(0.01)
    for i in range(10):
        assert q.get() == i

# Generated at 2022-06-18 11:41:38.906958
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def slow_square(x):
        time.sleep(0.1)
        return x ** 2

    with MonoWorker() as pool:
        for _ in _range(10):
            pool.submit(slow_square, _)
        for _ in _range(10):
            assert pool.submit(slow_square, _).result() == _ ** 2
        for _ in _range(10):
            assert pool.submit(slow_square, _).result() == _ ** 2

# Generated at 2022-06-18 11:41:47.664333
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from threading import Event

    def func(x):
        time.sleep(x)
        return x

    def func_exception(x):
        raise Exception("func_exception")

    def func_cancel(x):
        time.sleep(x)
        return x

    def func_cancel_exception(x):
        time.sleep(x)
        raise Exception("func_cancel_exception")

    def func_cancel_exception_cancel(x):
        time.sleep(x)
        raise Exception("func_cancel_exception_cancel")

    def func_cancel_exception_cancel_exception(x):
        time.sleep(x)

# Generated at 2022-06-18 11:41:56.014164
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from ..utils import _range

    def _test_submit(n, sleep, maxlen):
        mw = MonoWorker()
        mw.futures = deque([], maxlen)
        for i in _range(n):
            mw.submit(time.sleep, sleep)
        assert len(mw.futures) == min(n, maxlen)
        for i in _range(n):
            assert isinstance(mw.futures[i], Future)

    for n in _range(10):
        for sleep in [0, 0.1]:
            for maxlen in [1, 2]:
                _test_submit(n, sleep, maxlen)

# Generated at 2022-06-18 11:42:02.566302
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
        time.sleep(0.1)
    time.sleep(1)
    assert len(mw.futures) == 1
    assert mw.futures[0].result() == 9

# Generated at 2022-06-18 11:42:07.324821
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
        time.sleep(0.1)
    for i in _range(10):
        mw.submit(func, i)
        time.sleep(0.1)

# Generated at 2022-06-18 11:42:12.300519
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from random import random

    def func(x):
        time.sleep(random())
        return x

    worker = MonoWorker()
    for i in range(10):
        worker.submit(func, i)
    for i in range(10):
        assert worker.futures[0].result() == i

# Generated at 2022-06-18 11:42:20.963260
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from concurrent.futures import Future

    def func(x):
        sleep(x)
        return x

    def func_exception(x):
        raise Exception(x)

    def func_cancel(x):
        sleep(x)
        return x

    def func_cancel_exception(x):
        sleep(x)
        raise Exception(x)

    def func_cancel_exception_2(x):
        sleep(x)
        raise Exception(x)

    def func_cancel_exception_3(x):
        sleep(x)
        raise Exception(x)

    def func_cancel_exception_4(x):
        sleep(x)
        raise Exception(x)


# Generated at 2022-06-18 11:42:25.037957
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.05)
    time.sleep(0.5)

# Generated at 2022-06-18 11:42:34.485975
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    mw.submit(f, 1)
    mw.submit(f, 2)
    mw.submit(f, 3)
    mw.submit(f, 4)
    mw.submit(f, 5)
    mw.submit(f, 6)
    mw.submit(f, 7)
    mw.submit(f, 8)
    mw.submit(f, 9)
    mw.submit(f, 10)
    mw.submit(f, 11)
    mw.submit(f, 12)
    mw.submit(f, 13)
    mw.submit(f, 14)
   

# Generated at 2022-06-18 11:42:43.033451
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
    for i in _range(10):
        mw.submit(func, i)
    for i in _range(10):
        mw.submit(func, i)
    for i in _range(10):
        mw.submit(func, i)
    for i in _range(10):
        mw.submit(func, i)
    for i in _range(10):
        mw.submit(func, i)
    for i in _range(10):
        mw.submit(func, i)
    for i in _range(10):
        m

# Generated at 2022-06-18 11:43:25.942364
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
    for i in _range(10):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:43:29.229137
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.01)
    for i in _range(10):
        assert mw.futures[0].result() == i

# Generated at 2022-06-18 11:43:32.998378
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random

    def func(x):
        sleep(random())
        return x

    mw = MonoWorker()
    for i in range(10):
        mw.submit(func, i)
    for i in range(10):
        assert mw.futures[0].result() == i

# Generated at 2022-06-18 11:43:38.448699
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    with tqdm_auto.tqdm(total=10, desc='test') as t:
        mw = MonoWorker()
        for i in _range(10):
            mw.submit(f, i)
            t.update()
            _term_move_up()
            t.set_description('test %d' % i)
            t.refresh()
            time.sleep(0.1)

# Generated at 2022-06-18 11:43:46.468776
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def wait(t):
        time.sleep(t)
        return t

    mw = MonoWorker()
    assert mw.submit(wait, 0.1)
    assert mw.submit(wait, 0.2)
    assert mw.submit(wait, 0.3)
    assert mw.submit(wait, 0.4)
    assert mw.submit(wait, 0.5)
    assert mw.submit(wait, 0.6)
    assert mw.submit(wait, 0.7)
    assert mw.submit(wait, 0.8)
    assert mw.submit(wait, 0.9)
    assert mw.submit(wait, 1.0)
    assert mw.submit(wait, 1.1)

# Generated at 2022-06-18 11:43:54.833272
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def test_submit(self):
            def func(x):
                sleep(x)
                return x

            mw = MonoWorker()
            future1 = mw.submit(func, 1)
            future2 = mw.submit(func, 2)
            future3 = mw.submit(func, 3)
            self.assertIsInstance(future1, Future)
            self.assertIsInstance(future2, Future)
            self.assertIsInstance(future3, Future)
            self.assertEqual(future1.result(), 1)
            self.assertEqual(future2.result(), 2)

# Generated at 2022-06-18 11:44:01.644789
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from .utils import TestTqdmIO

    def func(x):
        time.sleep(x)
        return x

    with TestTqdmIO() as io:
        mw = MonoWorker()
        assert len(mw.futures) == 0
        assert mw.submit(func, 0.1)
        assert len(mw.futures) == 1
        assert isinstance(mw.futures[0], Future)
        assert mw.submit(func, 0.1)
        assert len(mw.futures) == 1
        assert isinstance(mw.futures[0], Future)
        assert mw.submit(func, 0.1)
        assert len(mw.futures) == 1

# Generated at 2022-06-18 11:44:10.226239
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Thread
    from multiprocessing import Queue
    from concurrent.futures import Future

    def _test_submit(q, mw, func, args, kwargs):
        q.put(mw.submit(func, *args, **kwargs))

    def _test_wait(q, mw, func, args, kwargs):
        q.put(mw.submit(func, *args, **kwargs).result())

    def _test_wait_all(q, mw, func, args, kwargs):
        q.put(mw.submit(func, *args, **kwargs).result())
        q.put(mw.submit(func, *args, **kwargs).result())


# Generated at 2022-06-18 11:44:14.069339
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)
    assert mw.futures[0].result() == 9

# Generated at 2022-06-18 11:44:21.632138
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_time
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_time
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_time
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_

# Generated at 2022-06-18 11:46:08.325859
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    from concurrent.futures import Future
    from ..utils import _range

    def func(x):
        time.sleep(random.random() * 0.1)
        return x

    def test_func(x):
        time.sleep(random.random() * 0.1)
        return x

    def test_func_exception(x):
        time.sleep(random.random() * 0.1)
        raise Exception("test_func_exception")

    def test_func_cancel(x):
        time.sleep(random.random() * 0.1)
        return x

    def test_func_cancel_exception(x):
        time.sleep(random.random() * 0.1)
        raise Exception("test_func_cancel_exception")

# Generated at 2022-06-18 11:46:12.583026
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def test_func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(test_func, i)
        time.sleep(0.01)
    assert mw.futures[0].result() == 9
    assert mw.futures[1].result() == 8

# Generated at 2022-06-18 11:46:18.652019
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
        time.sleep(0.01)
    for i in _range(10):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:46:26.605988
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Lock
    from concurrent.futures import Future

    def _test(func, *args, **kwargs):
        """
        Test that `func(*args, **kwargs)` is called once and only once.
        """
        lock = Lock()
        lock.acquire()
        future = Future()
        future.set_result(None)

        def _func(*args, **kwargs):
            lock.acquire()
            future.set_result(func(*args, **kwargs))
            lock.release()

        worker = MonoWorker()
        worker.submit(_func, *args, **kwargs)
        lock.release()
        return future.result()

    def _test_func(x):
        time.sleep(0.1)
        return x
