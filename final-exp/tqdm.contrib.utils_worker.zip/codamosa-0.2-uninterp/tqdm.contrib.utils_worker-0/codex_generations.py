

# Generated at 2022-06-18 11:36:30.455955
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
    time.sleep(0.1)
    assert len(mw.futures) == 1
    assert mw.futures[0].result() == 9

# Generated at 2022-06-18 11:36:35.530761
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import as_completed
    from .utils import _range

    def _test_func(i, e):
        e.wait()
        sleep(0.1)
        return i

    e = Event()
    mw = MonoWorker()
    futures = [mw.submit(_test_func, i, e) for i in _range(10)]
    e.set()
    for i, f in enumerate(as_completed(futures)):
        assert f.result() == i

# Generated at 2022-06-18 11:36:42.077235
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Lock
    from concurrent.futures import as_completed

    def func(arg, lock):
        sleep(random())
        with lock:
            tqdm_auto.write("{}".format(arg))

    lock = Lock()
    worker = MonoWorker()
    futures = [worker.submit(func, i, lock) for i in range(10)]
    for future in as_completed(futures):
        future.result()

# Generated at 2022-06-18 11:36:52.942186
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Event
    from concurrent.futures import as_completed

    def func(wait, *args, **kwargs):
        sleep(wait)
        return wait, args, kwargs

    def func_exception(wait, *args, **kwargs):
        sleep(wait)
        raise Exception("Exception raised")

    def func_cancel(wait, *args, **kwargs):
        sleep(wait)
        return wait, args, kwargs

    def func_cancel_exception(wait, *args, **kwargs):
        sleep(wait)
        raise Exception("Exception raised")

    def func_cancel_exception_cancel(wait, *args, **kwargs):
        sleep(wait)
        raise Exception("Exception raised")


# Generated at 2022-06-18 11:36:57.622554
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random

    def func(x):
        sleep(random())
        return x

    mw = MonoWorker()
    for i in range(10):
        mw.submit(func, i)
        sleep(random())
    for i in range(10):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:37:09.726214
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    from ..utils import format_sizeof

    def test_func(x):
        time.sleep(random.random() * 0.1)
        return x

    mw = MonoWorker()
    for i in range(10):
        mw.submit(test_func, i)
        time.sleep(random.random() * 0.1)

    for i in range(10):
        mw.submit(test_func, i)
        time.sleep(random.random() * 0.1)

    for i in range(10):
        mw.submit(test_func, i)
        time.sleep(random.random() * 0.1)

    for i in range(10):
        mw.submit(test_func, i)

# Generated at 2022-06-18 11:37:17.522993
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import ThreadPoolExecutor
    from ..auto import tqdm as tqdm_auto

    def func(x):
        time.sleep(x)
        return x

    with ThreadPoolExecutor(max_workers=1) as pool:
        with tqdm_auto.tqdm(total=10) as t:
            for i in range(10):
                pool.submit(func, i)
                t.update()

    with ThreadPoolExecutor(max_workers=1) as pool:
        with tqdm_auto.tqdm(total=10) as t:
            for i in range(10):
                pool.submit(func, i)
                t.update()


# Generated at 2022-06-18 11:37:27.162937
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def setUp(self):
            self.mw = MonoWorker()
            self.event = Event()

        def test_submit(self):
            def func():
                self.event.wait()
                return 1
            future = self.mw.submit(func)
            self.assertIsInstance(future, Future)
            self.assertEqual(future.result(), 1)

        def test_submit_replace(self):
            def func():
                time.sleep(1)
                return 1
            future = self.mw.submit(func)
            self.assertIsInstance(future, Future)

# Generated at 2022-06-18 11:37:36.702338
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(5):
        mw.submit(func, i)
    for i in _range(5):
        mw.submit(func, i)
    for i in _range(5):
        mw.submit(func, i)
    for i in _range(5):
        mw.submit(func, i)
    for i in _range(5):
        mw.submit(func, i)
    for i in _range(5):
        mw.submit(func, i)
    for i in _range(5):
        mw.submit(func, i)
    for i in _range(5):
        m

# Generated at 2022-06-18 11:37:43.271837
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
        time.sleep(0.1)
    for i in _range(10):
        mw.submit(func, i)
        time.sleep(0.1)
    for i in _range(10):
        mw.submit(func, i)
        time.sleep(0.1)

# Generated at 2022-06-18 11:37:54.999445
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from ..utils import _range

    def _test_submit(mw, func, args, kwargs, expected_result, expected_len):
        """
        Test `mw.submit(func, *args, **kwargs)`
        """
        future = mw.submit(func, *args, **kwargs)
        assert isinstance(future, Future)
        assert len(mw.futures) == expected_len
        assert future.result() == expected_result

    def _test_submit_exception(mw, func, args, kwargs, expected_len):
        """
        Test `mw.submit(func, *args, **kwargs)`
        """
        future = mw.submit(func, *args, **kwargs)
       

# Generated at 2022-06-18 11:38:03.887158
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event

    def f(x, e):
        e.wait()
        return x

    e = Event()
    mw = MonoWorker()
    assert len(mw.futures) == 0
    assert mw.submit(f, 1, e) is not None
    assert len(mw.futures) == 1
    assert mw.submit(f, 2, e) is not None
    assert len(mw.futures) == 1
    assert mw.submit(f, 3, e) is not None
    assert len(mw.futures) == 1
    e.set()
    time.sleep(0.1)
    assert len(mw.futures) == 0
    assert mw.submit(f, 4, e) is not None


# Generated at 2022-06-18 11:38:10.837160
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def wait(n):
        time.sleep(n)
        return n

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(wait, i)
    time.sleep(0.1)
    assert mw.futures[0].done()
    assert not mw.futures[1].done()
    time.sleep(0.1)
    assert mw.futures[0].done()
    assert mw.futures[1].done()
    assert mw.futures[0].result() == 9
    assert mw.futures[1].result() == 8

# Generated at 2022-06-18 11:38:20.035631
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import TimeoutError

    def wait_for_event(event, timeout=None):
        try:
            event.wait(timeout)
        except TimeoutError:
            pass
        return event.is_set()

    def test_submit(timeout=None):
        event = Event()
        worker = MonoWorker()
        assert not event.is_set()
        assert not worker.submit(wait_for_event, event, timeout)
        assert not event.is_set()
        event.set()
        assert worker.submit(wait_for_event, event, timeout)

    test_submit()
    time.sleep(0.1)
    test_submit(timeout=0.1)

# Generated at 2022-06-18 11:38:30.989328
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Lock
    from concurrent.futures import as_completed
    from tqdm.contrib.concurrency import MonoWorker

    def func(x):
        sleep(random() / 10)
        return x

    with MonoWorker() as worker:
        futures = [worker.submit(func, i) for i in range(10)]
        for future in as_completed(futures):
            assert future.result() == futures.index(future)

    with MonoWorker() as worker:
        futures = [worker.submit(func, i) for i in range(10)]
        for future in as_completed(futures):
            assert future.result() == futures.index(future)


# Generated at 2022-06-18 11:38:40.085119
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Lock
    from concurrent.futures import Future
    from unittest import TestCase, main

    class TestMonoWorker(TestCase):
        def setUp(self):
            self.mw = MonoWorker()
            self.lock = Lock()
            self.counter = 0

        def test_submit(self):
            def func(x):
                sleep(random())
                with self.lock:
                    self.counter += x
                return x

            for _ in range(10):
                self.mw.submit(func, 1)
            self.assertEqual(self.counter, 1)

            for _ in range(10):
                self.mw.submit(func, 2)
            self.assertEqual(self.counter, 3)

           

# Generated at 2022-06-18 11:38:51.483842
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    from threading import Thread
    from concurrent.futures import as_completed

    def func(x):
        time.sleep(random.random())
        return x

    mw = MonoWorker()
    futures = []
    for i in range(10):
        futures.append(mw.submit(func, i))
    for f in as_completed(futures):
        assert f.result() == 9

    # Test with a thread
    def thread_func(mw):
        for i in range(10):
            mw.submit(func, i)
    thread = Thread(target=thread_func, args=(mw,))
    thread.start()
    thread.join()
    for f in as_completed(futures):
        assert f.result() == 9

# Generated at 2022-06-18 11:39:01.353589
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Lock
    from multiprocessing import cpu_count
    from concurrent.futures import ThreadPoolExecutor
    from tqdm.contrib.concurrency import MonoWorker

    def func(x):
        sleep(random())
        return x

    # test MonoWorker
    mw = MonoWorker()
    for i in range(10):
        mw.submit(func, i)
    assert mw.futures[0].result() == 9

    # test ThreadPoolExecutor
    tpe = ThreadPoolExecutor(max_workers=cpu_count())
    for i in range(10):
        tpe.submit(func, i)
    assert tpe.shutdown(wait=True) is None

    # test ThreadPoolExecutor with lock


# Generated at 2022-06-18 11:39:05.758745
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from .utils import _range

    def slow_square(x):
        time.sleep(0.1)
        return x ** 2

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(slow_square, i)
    time.sleep(0.5)
    assert len(mw.futures) == 1
    assert mw.futures[0].result() == 81

# Generated at 2022-06-18 11:39:13.049225
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    from concurrent.futures import as_completed
    from ..utils import format_sizeof

    def _test_func(x):
        time.sleep(random.random())
        return x

    def _test_func_exception(x):
        time.sleep(random.random())
        raise Exception('test exception')

    def _test_func_cancel(x):
        time.sleep(random.random())
        return x

    def _test_func_cancel_exception(x):
        time.sleep(random.random())
        raise Exception('test exception')

    def _test_func_cancel_exception_2(x):
        time.sleep(random.random())
        raise Exception('test exception')


# Generated at 2022-06-18 11:39:22.812701
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from tqdm import tqdm

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in tqdm(range(10)):
        mw.submit(f, i)
    assert mw.futures[0].result() == 9
    assert mw.futures[1].result() == 8

# Generated at 2022-06-18 11:39:31.861604
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import TimeoutError

    def wait_and_return(wait_time, return_value):
        time.sleep(wait_time)
        return return_value

    def wait_and_raise(wait_time, exception):
        time.sleep(wait_time)
        raise exception

    def wait_and_return_with_timeout(wait_time, return_value, timeout,
                                     timeout_event):
        time.sleep(wait_time)
        if timeout_event.wait(timeout):
            return return_value
        else:
            raise TimeoutError

    def test_submit(func, *args, **kwargs):
        worker = MonoWorker()
        future = worker.submit(func, *args, **kwargs)
        assert future.result()

# Generated at 2022-06-18 11:39:40.039272
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.01)
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.01)
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.01)
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.01)
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.01)

# Generated at 2022-06-18 11:39:44.412046
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    from concurrent.futures import TimeoutError

    def func(x):
        time.sleep(random.random())
        return x

    mw = MonoWorker()
    for i in range(10):
        mw.submit(func, i)
    for i in range(10):
        try:
            assert mw.futures[0].result(timeout=0.1) == i
        except TimeoutError:
            pass

# Generated at 2022-06-18 11:39:55.684317
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from multiprocessing import Process
    from multiprocessing.connection import Listener
    from multiprocessing.connection import Client
    from multiprocessing.connection import wait
    from multiprocessing.connection import deliver_challenge
    from multiprocessing.connection import answer_challenge
    from multiprocessing.connection import AuthenticationError
    from multiprocessing.connection import ForkingPickler
    from multiprocessing.connection import reduce_connection
    from multiprocessing.connection import _write_to_socket
    from multiprocessing.connection import _read_from_socket
    from multiprocessing.connection import _close
    from multiprocessing.connection import _check_readable
    from multiprocessing.connection import _check_writable
    from multiprocessing.connection import _check_

# Generated at 2022-06-18 11:40:05.875549
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from nose.tools import assert_equal

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    assert_equal(len(mw.futures), 0)
    assert_equal(mw.submit(func, 0.1), mw.futures[0])
    assert_equal(len(mw.futures), 1)
    assert_equal(mw.submit(func, 0.1), mw.futures[0])
    assert_equal(len(mw.futures), 1)
    assert_equal(mw.submit(func, 0.1), mw.futures[0])
    assert_equal(len(mw.futures), 1)
   

# Generated at 2022-06-18 11:40:14.000023
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    from concurrent.futures import Future
    from multiprocessing import Queue

    def _test_MonoWorker_submit(q):
        def _test_func(x, y):
            time.sleep(random.random())
            return x + y

        mw = MonoWorker()
        for i in range(10):
            x = random.randint(0, 10)
            y = random.randint(0, 10)
            future = mw.submit(_test_func, x, y)
            assert isinstance(future, Future)
            assert future.result() == x + y
        q.put(True)

    q = Queue()
    t = threading.Thread(target=_test_MonoWorker_submit, args=(q,))


# Generated at 2022-06-18 11:40:24.319969
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up
    from ..std import time as time_std
    from ..std import sleep as sleep_std
    from ..std import print as print_std

    def _test_MonoWorker_submit(n_tasks, n_workers, sleep_time):
        """
        n_tasks: number of tasks to submit
        n_workers: number of workers to use
        sleep_time: time to sleep per task
        """
        worker = MonoWorker()
        tasks = []
        for i in range(n_tasks):
            tasks.append(worker.submit(sleep_std, sleep_time))
        tqdm_auto.write("\n")
        for i in range(n_tasks):
            tasks[i].result()

# Generated at 2022-06-18 11:40:30.092928
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
        time.sleep(0.01)
    assert mw.futures[0].result() == 9
    assert mw.futures[1].result() == 8

# Generated at 2022-06-18 11:40:34.218789
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
    assert mw.futures[0].result() == 9
    assert mw.futures[1].result() == 8

# Generated at 2022-06-18 11:40:50.341967
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from ..utils import _range

    def _test_func(i, wait_event):
        wait_event.wait()
        return i

    def _test_func_exception(i, wait_event):
        wait_event.wait()
        raise Exception("test exception")

    def _test_func_cancel(i, wait_event):
        wait_event.wait()
        return i

    def _test_func_cancel_exception(i, wait_event):
        wait_event.wait()
        raise Exception("test exception")

    def _test_func_cancel_exception_cancel(i, wait_event):
        wait_event.wait()
        raise Exception("test exception")


# Generated at 2022-06-18 11:40:56.135805
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import TimeoutError

    def wait(seconds):
        time.sleep(seconds)
        return seconds

    def wait_and_fail(seconds):
        time.sleep(seconds)
        raise Exception("Failed after {} seconds".format(seconds))

    def wait_and_fail_timeout(seconds):
        time.sleep(seconds)
        raise TimeoutError("Timed out after {} seconds".format(seconds))

    mw = MonoWorker()

    # Test 1: submit a task that takes 5 seconds
    #         submit another task that takes 1 second
    #         the second task should replace the first task
    #         the first task should be cancelled
    #         the second task should be completed
    #         the first task should be completed with a CancelledError

# Generated at 2022-06-18 11:41:04.239725
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import TimeoutError

    def func(x, y, z, e):
        e.wait()
        return x + y + z

    e = Event()
    mw = MonoWorker()
    f1 = mw.submit(func, 1, 2, 3, e)
    f2 = mw.submit(func, 4, 5, 6, e)
    f3 = mw.submit(func, 7, 8, 9, e)
    assert f1.cancel()
    assert not f2.cancel()
    assert f3.cancel()
    e.set()
    assert f2.result() == 12
    assert f1.cancelled()
    assert f3.cancelled()

# Generated at 2022-06-18 11:41:08.666306
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import as_completed
    from ..utils import format_sizeof

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    futures = [mw.submit(func, x) for x in range(3)]
    for f in as_completed(futures):
        print(f.result())
    print(format_sizeof(mw))

# Generated at 2022-06-18 11:41:12.885148
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
        time.sleep(0.05)
    for i in _range(10):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:41:16.679908
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Lock

    lock = Lock()
    mw = MonoWorker()

    def test_func(i):
        time.sleep(0.1)
        with lock:
            print("test_func({})".format(i))

    for i in range(10):
        mw.submit(test_func, i)

    time.sleep(0.5)

# Generated at 2022-06-18 11:41:20.801584
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    import unittest

    class TestMonoWorker(unittest.TestCase):
        def test_submit(self):
            def sleep_and_print(n):
                time.sleep(n)
                tqdm_auto.write(str(n))

            mw = MonoWorker()
            for _ in range(10):
                mw.submit(sleep_and_print, random.random())
                time.sleep(0.1)

    threading.Thread(target=unittest.main).start()

# Generated at 2022-06-18 11:41:29.657386
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Thread
    from multiprocessing import Process
    from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor

    def _test_MonoWorker_submit(pool, sleep_time, n_tasks):
        mw = MonoWorker()
        for i in range(n_tasks):
            mw.submit(pool.submit, sleep, sleep_time * random())
        sleep(sleep_time * n_tasks)
        assert len(mw.futures) == 1
        assert mw.futures[0].done()


# Generated at 2022-06-18 11:41:38.104132
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    mw = MonoWorker()
    for i in range(10):
        mw.submit(sleep, random())
    mw.submit(sleep, 1)
    mw.submit(sleep, 1)
    mw.submit(sleep, 1)
    mw.submit(sleep, 1)
    mw.submit(sleep, 1)
    mw.submit(sleep, 1)
    mw.submit(sleep, 1)
    mw.submit(sleep, 1)
    mw.submit(sleep, 1)
    mw.submit(sleep, 1)
    mw.submit(sleep, 1)
    mw.submit(sleep, 1)
    mw.submit(sleep, 1)
    mw.submit(sleep, 1)

# Generated at 2022-06-18 11:41:47.122960
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import as_completed

    def func(x, y, z, sleep_time=0.1, event=None):
        if event is not None:
            event.wait()
        sleep(sleep_time)
        return x + y + z

    event = Event()
    worker = MonoWorker()
    futures = [worker.submit(func, 1, 2, 3, sleep_time=0.5, event=event),
               worker.submit(func, 4, 5, 6, sleep_time=0.5, event=event),
               worker.submit(func, 7, 8, 9, sleep_time=0.5, event=event)]
    event.set()
    for future in as_completed(futures):
        assert future.result

# Generated at 2022-06-18 11:42:06.928050
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
    for i in _range(10):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:42:14.335888
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def wait(i, t):
        time.sleep(t)
        return i

    def wait_and_print(i, t):
        time.sleep(t)
        tqdm_auto.write(str(i))
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(wait, i, i / 10)
    for i in _range(10):
        mw.submit(wait_and_print, i, i / 10)

# Generated at 2022-06-18 11:42:22.320374
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event

    def func(x, y, z, e):
        e.wait()
        return x + y + z

    e = Event()
    mw = MonoWorker()
    f1 = mw.submit(func, 1, 2, 3, e)
    f2 = mw.submit(func, 4, 5, 6, e)
    f3 = mw.submit(func, 7, 8, 9, e)
    assert not f1.done()
    assert not f2.done()
    assert not f3.done()
    e.set()
    time.sleep(0.1)
    assert f1.done()
    assert f2.done()
    assert f3.done()
    assert f1.result() == 6
    assert f2.result() == 15

# Generated at 2022-06-18 11:42:31.948436
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def test_func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    assert mw.submit(test_func, 1)
    assert mw.submit(test_func, 2)
    assert mw.submit(test_func, 3)
    assert mw.submit(test_func, 4)
    assert mw.submit(test_func, 5)
    assert mw.submit(test_func, 6)
    assert mw.submit(test_func, 7)
    assert mw.submit(test_func, 8)
    assert mw.submit(test_func, 9)
    assert mw.submit(test_func, 10)
    assert mw.submit(test_func, 11)

# Generated at 2022-06-18 11:42:37.147232
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    w = MonoWorker()
    for i in _range(10):
        w.submit(f, i)
        tqdm_auto.write('{}'.format(i))
        _term_move_up()
    tqdm_auto.write('Done')

# Generated at 2022-06-18 11:42:41.950161
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up

    def func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in range(5):
        mw.submit(func, i)
        time.sleep(0.05)
    time.sleep(0.2)
    _term_move_up()
    assert mw.futures[0].result() == 4

# Generated at 2022-06-18 11:42:49.557048
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Thread
    from multiprocessing import Queue
    from concurrent.futures import Future

    def _test_MonoWorker_submit(q):
        def _test_MonoWorker_submit_func(i):
            sleep(random())
            return i

        mw = MonoWorker()
        for i in range(10):
            future = mw.submit(_test_MonoWorker_submit_func, i)
            assert isinstance(future, Future)
            q.put(future.result())

    q = Queue()
    t = Thread(target=_test_MonoWorker_submit, args=(q,))
    t.start()
    for i in range(10):
        assert q.get() == i
    t.join

# Generated at 2022-06-18 11:42:57.409479
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    f1 = mw.submit(f, 1)
    f2 = mw.submit(f, 2)
    f3 = mw.submit(f, 3)
    f4 = mw.submit(f, 4)
    f5 = mw.submit(f, 5)
    f6 = mw.submit(f, 6)
    f7 = mw.submit(f, 7)
    f8 = mw.submit(f, 8)
    f9 = mw.submit(f, 9)
    f10 = mw.submit(f, 10)
    f11 = mw.submit(f, 11)
   

# Generated at 2022-06-18 11:43:01.616163
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import TimeoutError
    from ..utils import _range

    def func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
    for i in _range(10):
        try:
            assert mw.futures[0].result(timeout=0.1) == i
        except TimeoutError:
            pass

# Generated at 2022-06-18 11:43:06.753054
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event

    def wait_for_event(event, timeout=None):
        """
        Wait for event to be set.
        """
        event.wait(timeout)
        return event.is_set()

    def wait_for_event_and_set(event, timeout=None):
        """
        Wait for event to be set and set it.
        """
        event.wait(timeout)
        event.set()
        return event.is_set()

    def wait_for_event_and_clear(event, timeout=None):
        """
        Wait for event to be set and clear it.
        """
        event.wait(timeout)
        event.clear()
        return event.is_set()


# Generated at 2022-06-18 11:43:52.878425
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import TimeoutError

    def func(x, y, z, e):
        sleep(x)
        if e.is_set():
            return x + y + z
        else:
            raise TimeoutError()

    e = Event()
    m = MonoWorker()
    f = m.submit(func, 1, 2, 3, e)
    assert f.result(timeout=0.5) == 6
    e.set()
    f = m.submit(func, 1, 2, 3, e)
    assert f.result(timeout=0.5) == 6
    f = m.submit(func, 1, 2, 3, e)
    assert f.result(timeout=0.5) == 6
    e.clear()
    f

# Generated at 2022-06-18 11:44:00.566192
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Lock
    from concurrent.futures import Future
    from ..utils import _range

    def func(i):
        time.sleep(0.1)
        return i

    def test_func(i):
        time.sleep(0.1)
        return i

    def test_func_exception(i):
        time.sleep(0.1)
        raise Exception("test_func_exception")

    def test_func_cancel(i):
        time.sleep(0.1)
        return i

    def test_func_cancel_exception(i):
        time.sleep(0.1)
        raise Exception("test_func_cancel_exception")

    def test_func_cancel_exception_2(i):
        time.sleep(0.1)

# Generated at 2022-06-18 11:44:09.035306
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import as_completed

    def sleep_and_return(seconds, value):
        sleep(seconds)
        return value

    def test_submit(seconds, value):
        worker = MonoWorker()
        future = worker.submit(sleep_and_return, seconds, value)
        assert future.result() == value

    test_submit(0.1, 1)
    test_submit(0.2, 2)
    test_submit(0.3, 3)
    test_submit(0.4, 4)
    test_submit(0.5, 5)

    worker = MonoWorker()
    future1 = worker.submit(sleep_and_return, 0.1, 1)

# Generated at 2022-06-18 11:44:14.588431
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from concurrent.futures import as_completed
    from tqdm.contrib.concurrent import MonoWorker

    mw = MonoWorker()
    lock = Lock()
    with lock:
        for i in range(10):
            mw.submit(sleep, 0.1)
        for f in as_completed(mw.futures):
            f.result()
    assert len(mw.futures) == 1

# Generated at 2022-06-18 11:44:22.102907
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future

    def wait(t):
        time.sleep(t)
        return t

    def wait_and_cancel(t, cancel_event):
        cancel_event.wait()
        return t

    def wait_and_cancel_other(t, cancel_event):
        cancel_event.wait()
        return t

    def wait_and_cancel_other_with_exception(t, cancel_event):
        cancel_event.wait()
        raise Exception("wait_and_cancel_other_with_exception")

    def wait_and_cancel_with_exception(t, cancel_event):
        cancel_event.wait()
        raise Exception("wait_and_cancel_with_exception")


# Generated at 2022-06-18 11:44:30.766610
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event

    def wait(secs, event):
        time.sleep(secs)
        event.set()

    def wait_and_return(secs, event):
        time.sleep(secs)
        event.set()
        return secs

    def wait_and_raise(secs, event):
        time.sleep(secs)
        event.set()
        raise ValueError(secs)

    def test_wait(func):
        event = Event()
        worker = MonoWorker()
        for secs in [1, 2, 3, 4, 5]:
            worker.submit(func, secs, event)
            assert not event.is_set()
            time.sleep(0.1)
            assert not event.is_set()

# Generated at 2022-06-18 11:44:36.854556
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random

    def f(x):
        sleep(random())
        return x

    mw = MonoWorker()
    f1 = mw.submit(f, 1)
    f2 = mw.submit(f, 2)
    f3 = mw.submit(f, 3)
    f4 = mw.submit(f, 4)
    assert f1.result() == 1
    assert f2.result() == 2
    assert f3.result() == 3
    assert f4.result() == 4

# Generated at 2022-06-18 11:44:43.679364
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import CancelledError

    def wait_for(e):
        e.wait()

    def wait_for_cancel(e):
        try:
            e.wait()
        except CancelledError:
            pass

    def wait_for_cancel_and_raise(e):
        try:
            e.wait()
        except CancelledError:
            raise ValueError

    def wait_for_cancel_and_raise_after(e, delay):
        try:
            e.wait(delay)
        except CancelledError:
            sleep(delay)
            raise ValueError


# Generated at 2022-06-18 11:44:52.550874
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase, main

    class Test(TestCase):
        def test_submit(self):
            def func(x):
                time.sleep(0.1)
                return x

            mw = MonoWorker()
            f1 = mw.submit(func, 1)
            f2 = mw.submit(func, 2)
            f3 = mw.submit(func, 3)
            self.assertEqual(f1.result(), 1)
            self.assertEqual(f2.result(), 2)
            self.assertEqual(f3.result(), 3)

            # Test that the waiting task is cancelled
            # when a new task is submitted
            def func(x, e):
                e.wait()

# Generated at 2022-06-18 11:44:58.180643
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(5):
        mw.submit(func, i)
        time.sleep(0.05)
    time.sleep(0.5)
    assert mw.futures[0].done()
    assert mw.futures[0].result() == 4
    assert len(mw.futures) == 1