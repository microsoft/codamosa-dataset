

# Generated at 2022-06-18 11:36:17.404773
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)

if __name__ == "__main__":
    test_MonoWorker_submit()

# Generated at 2022-06-18 11:36:21.640831
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    import unittest

    class TestMonoWorker(unittest.TestCase):
        def test_submit(self):
            def func(x):
                time.sleep(random.random())
                return x

            mw = MonoWorker()
            for i in range(10):
                mw.submit(func, i)
            for i in range(10):
                self.assertEqual(mw.futures[i].result(), i)

    unittest.main(verbosity=2)

# Generated at 2022-06-18 11:36:30.004324
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from ..utils import format_sizeof

    def wait_for_event(event, timeout=None):
        """
        Wait for event to be set.
        """
        event.wait(timeout)
        return event.is_set()

    def wait_for_event_with_timeout(event, timeout=None):
        """
        Wait for event to be set with timeout.
        """
        return wait_for_event(event, timeout)

    def wait_for_event_without_timeout(event, timeout=None):
        """
        Wait for event to be set without timeout.
        """
        return wait_for_event(event)


# Generated at 2022-06-18 11:36:33.951256
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.01)
    for i in _range(10):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:36:37.918534
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
        time.sleep(0.05)

# Generated at 2022-06-18 11:36:48.801668
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    import sys
    from ..utils import _range

    def sleep_and_print(t, msg):
        time.sleep(t)
        tqdm_auto.write(msg)

    def test_submit(t, msg):
        tqdm_auto.write("submit: " + msg)
        return sleep_and_print(t, msg)

    def test_submit_cancel(t, msg):
        tqdm_auto.write("submit: " + msg)
        return sleep_and_print(t, msg)

    def test_submit_wait(t, msg):
        tqdm_auto.write("submit: " + msg)
        return sleep_and_print(t, msg)


# Generated at 2022-06-18 11:36:56.940796
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range
    from ..std import time as time_std

    def wait(t):
        time_std.sleep(t)
        return t

    def test_submit(t):
        mw = MonoWorker()
        for i in _range(t):
            mw.submit(wait, i)
        time_std.sleep(t + 1)
        assert mw.futures[0].result() == t - 1

    test_submit(1)
    test_submit(2)
    test_submit(3)
    test_submit(4)
    test_submit(5)

# Generated at 2022-06-18 11:37:08.955713
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from threading import Thread
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def setUp(self):
            self.mw = MonoWorker()

        def test_submit(self):
            def func(x):
                time.sleep(x)
                return x

            def func_exception(x):
                raise Exception('test')

            def func_cancel(x):
                time.sleep(x)
                return x

            def func_cancel_exception(x):
                time.sleep(x)
                raise Exception('test')

            def func_cancel_exception_2(x):
                time.sleep(x)
                raise Exception('test')


# Generated at 2022-06-18 11:37:12.557643
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)

# Generated at 2022-06-18 11:37:18.421702
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from .utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
    assert len(mw.futures) == 1
    assert mw.futures[0].result() == 9
    assert mw.futures[0].done()

# Generated at 2022-06-18 11:37:25.743350
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(5):
        mw.submit(f, i)
        time.sleep(0.01)

    for i in _range(5):
        mw.submit(f, i)
        time.sleep(0.01)

# Generated at 2022-06-18 11:37:35.717291
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from multiprocessing import Process
    from threading import Thread
    from queue import Queue

    def func(i, q):
        time.sleep(1)
        q.put(i)

    def test_process(q):
        mw = MonoWorker()
        for i in range(5):
            mw.submit(func, i, q)
        for i in range(5):
            assert q.get() == i

    def test_thread(q):
        mw = MonoWorker()
        for i in range(5):
            mw.submit(func, i, q)
        for i in range(5):
            assert q.get() == i

    q = Queue()
    p = Process(target=test_process, args=(q,))
    p.start()
   

# Generated at 2022-06-18 11:37:41.020113
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    from concurrent.futures import as_completed
    from ..utils import _range

    def func(i):
        time.sleep(random.random())
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
    for f in as_completed(mw.futures):
        assert f.result() == 9

# Generated at 2022-06-18 11:37:46.361606
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)

    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)

# Generated at 2022-06-18 11:37:55.894412
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from .utils import TestTqdmIO

    def func(x):
        time.sleep(x)
        return x

    with TestTqdmIO() as io:
        worker = MonoWorker()
        assert len(worker.futures) == 0
        assert worker.submit(func, 1) is not None
        assert len(worker.futures) == 1
        assert worker.submit(func, 2) is not None
        assert len(worker.futures) == 1
        assert isinstance(worker.futures[0], Future)
        assert worker.futures[0].result() == 2
        assert len(worker.futures) == 1
        assert worker.submit(func, 3) is not None
        assert len(worker.futures)

# Generated at 2022-06-18 11:38:03.176637
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from itertools import count
    from threading import Lock
    from concurrent.futures import as_completed

    def task(i):
        sleep(random())
        return i

    mw = MonoWorker()
    lock = Lock()
    results = []
    for i in count():
        with lock:
            results.append(mw.submit(task, i))
        if i > 10:
            break
    for future in as_completed(results):
        with lock:
            results.remove(future)
        assert future.result() == i
    assert not results

# Generated at 2022-06-18 11:38:09.560580
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Event
    from concurrent.futures import as_completed

    def func(x, y, z, sleep_time=0.1):
        sleep(sleep_time)
        return x + y + z

    mw = MonoWorker()
    e = Event()
    e.set()
    for i in range(10):
        mw.submit(func, i, i, i, sleep_time=random())
        if e.is_set():
            e.clear()
            for future in as_completed(mw.futures):
                assert future.result() == 3 * i
            e.set()

# Generated at 2022-06-18 11:38:19.514382
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(5):
        mw.submit(f, i)
    time.sleep(1)
    for i in _range(5):
        mw.submit(f, i)
    time.sleep(1)
    for i in _range(5):
        mw.submit(f, i)
    time.sleep(1)
    for i in _range(5):
        mw.submit(f, i)
    time.sleep(1)
    for i in _range(5):
        mw.submit(f, i)
    time.sleep(1)

# Generated at 2022-06-18 11:38:24.596654
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
    for i in _range(10):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:38:35.552406
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def test_submit(self):
            def func(x):
                time.sleep(0.1)
                return x

            mw = MonoWorker()
            f1 = mw.submit(func, 1)
            f2 = mw.submit(func, 2)
            f3 = mw.submit(func, 3)
            self.assertEqual(f1.result(), 1)
            self.assertEqual(f2.result(), 2)
            self.assertEqual(f3.result(), 3)

        def test_submit_cancel(self):
            def func(x):
                time.sleep(0.1)
                return

# Generated at 2022-06-18 11:38:50.953630
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from multiprocessing import Process
    from multiprocessing.connection import Listener
    from multiprocessing.connection import Client
    from multiprocessing.connection import wait
    from multiprocessing.connection import address_type

    def server(evt, address):
        with Listener(address, authkey=b'peekaboo') as listener:
            conn = listener.accept()
            evt.set()
            while True:
                msg = conn.recv()
                if msg == b'close':
                    break
                conn.send(msg)
            listener.close()

    def client(address):
        evt = Event()
        p = Process(target=server, args=(evt, address))
        p.start()
        evt.wait()

# Generated at 2022-06-18 11:39:00.937645
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future

    def wait_for(seconds):
        time.sleep(seconds)
        return seconds

    def wait_for_cancel(seconds, event):
        event.wait()
        return seconds

    def wait_for_exception(seconds):
        raise Exception("I'm an exception")

    def wait_for_cancel_exception(seconds, event):
        event.wait()
        raise Exception("I'm an exception")

    def wait_for_cancel_exception_2(seconds, event):
        event.wait()
        raise Exception("I'm an exception")

    def wait_for_cancel_exception_3(seconds, event):
        event.wait()
        raise Exception("I'm an exception")


# Generated at 2022-06-18 11:39:07.663217
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from multiprocessing import Process
    from .utils import _range

    def _test_MonoWorker_submit(q, e):
        mw = MonoWorker()
        for i in _range(10):
            mw.submit(time.sleep, 0.1)
            q.put(i)
        e.wait()

    q = tqdm_auto.Queue()
    e = Event()
    p = Process(target=_test_MonoWorker_submit, args=(q, e))
    p.start()
    try:
        for i in _range(10):
            assert q.get() == i
        e.set()
    finally:
        p.join()

# Generated at 2022-06-18 11:39:13.974804
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from threading import Event
    from unittest import TestCase

    class Test(TestCase):
        def setUp(self):
            self.worker = MonoWorker()
            self.event = Event()

        def test_submit(self):
            def func():
                self.event.wait()
                return 'done'

            future = self.worker.submit(func)
            self.assertIsInstance(future, Future)
            self.assertFalse(future.done())
            self.assertEqual(future.result(), 'done')
            self.assertTrue(future.done())

        def test_submit_cancel(self):
            def func():
                self.event.wait()
                return 'done'

            future = self.worker.submit(func)

# Generated at 2022-06-18 11:39:20.838289
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def test_submit(self):
            mw = MonoWorker()
            evt = Event()
            evt.set()

            def wait_and_set(evt):
                evt.wait()
                evt.set()

            evt.clear()
            mw.submit(wait_and_set, evt)
            time.sleep(0.1)
            self.assertFalse(evt.is_set())
            evt.set()
            time.sleep(0.1)
            self.assertTrue(evt.is_set())

            evt.clear()
            mw.submit(wait_and_set, evt)

# Generated at 2022-06-18 11:39:24.735234
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.05)
    assert mw.futures[0].result() == 9

# Generated at 2022-06-18 11:39:33.957700
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future

    def func(x, y, z):
        time.sleep(x)
        return x + y + z

    def func_exception(x, y, z):
        raise Exception("x={}, y={}, z={}".format(x, y, z))

    def func_cancel(x, y, z):
        time.sleep(x)
        return x + y + z

    def func_cancel_exception(x, y, z):
        time.sleep(x)
        raise Exception("x={}, y={}, z={}".format(x, y, z))

    def func_cancel_exception_2(x, y, z):
        time.sleep(x)

# Generated at 2022-06-18 11:39:41.910595
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from concurrent.futures import Future
    from unittest import TestCase, main

    class TestMonoWorker(TestCase):
        def setUp(self):
            self.mw = MonoWorker()
            self.lock = Lock()
            self.counter = 0

        def test_submit(self):
            def func():
                with self.lock:
                    self.counter += 1
                sleep(0.1)
                with self.lock:
                    self.counter -= 1

            self.assertEqual(self.counter, 0)
            self.mw.submit(func)
            sleep(0.05)
            self.assertEqual(self.counter, 1)
            self.mw.submit(func)
            sleep(0.05)

# Generated at 2022-06-18 11:39:48.059252
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from concurrent.futures import as_completed
    from ..utils import _range

    def do_work(i, lock):
        sleep(0.1)
        with lock:
            tqdm_auto.write("{} done".format(i))

    lock = Lock()
    worker = MonoWorker()
    for i in _range(10):
        worker.submit(do_work, i, lock)
    for future in as_completed(worker.futures):
        future.result()

# Generated at 2022-06-18 11:39:59.878615
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event

    def func(x, y, z, e):
        sleep(x)
        e.set()
        return x + y + z

    e = Event()
    mw = MonoWorker()
    assert mw.submit(func, 0.1, 1, 2, e)
    assert mw.submit(func, 0.2, 3, 4, e)
    assert mw.submit(func, 0.3, 5, 6, e)
    assert mw.submit(func, 0.4, 7, 8, e)
    assert mw.submit(func, 0.5, 9, 10, e)
    e.wait()
    assert mw.futures[0].result() == 21
    assert mw.futures[1].result() == 15

# Generated at 2022-06-18 11:40:12.582416
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def _test_submit(n):
        def _test_submit_inner(n):
            time.sleep(n)
            return n

        mw = MonoWorker()
        for i in _range(n):
            mw.submit(_test_submit_inner, i)
            time.sleep(0.1)
        assert mw.futures[0].result() == n - 1

    _test_submit(10)
    _test_submit(100)

# Generated at 2022-06-18 11:40:22.546680
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def sleep_and_return(x, sleep_time=0.1):
        time.sleep(sleep_time)
        return x

    def test_case(n, sleep_time=0.1):
        mw = MonoWorker()
        for i in _range(n):
            mw.submit(sleep_and_return, i, sleep_time=sleep_time)
        for i in _range(n):
            assert mw.futures[i].result() == n - 1 - i

    test_case(1)
    test_case(2)
    test_case(3)
    test_case(4)
    test_case(5)
    test_case(6)
    test_case(7)
    test_case(8)
   

# Generated at 2022-06-18 11:40:32.536721
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def _test_submit(n, sleep=0.1):
        def _f(i):
            time.sleep(sleep)
            return i

        mw = MonoWorker()
        for i in _range(n):
            mw.submit(_f, i)
        return [f.result() for f in mw.futures]

    assert _test_submit(1) == [0]
    assert _test_submit(2) == [1]
    assert _test_submit(3) == [2]
    assert _test_submit(4) == [3]
    assert _test_submit(5) == [4]
    assert _test_submit(6) == [5]
    assert _test_submit(7) == [6]
    assert _test_

# Generated at 2022-06-18 11:40:40.148848
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event

    def wait_and_print(s, wait_time, stop_event):
        time.sleep(wait_time)
        if not stop_event.is_set():
            tqdm_auto.write(s)

    stop_event = Event()
    mw = MonoWorker()
    mw.submit(wait_and_print, 'a', 1, stop_event)
    mw.submit(wait_and_print, 'b', 2, stop_event)
    mw.submit(wait_and_print, 'c', 3, stop_event)
    mw.submit(wait_and_print, 'd', 4, stop_event)
    mw.submit(wait_and_print, 'e', 5, stop_event)

# Generated at 2022-06-18 11:40:43.825239
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    from concurrent.futures import as_completed

    def f(x):
        time.sleep(random.random())
        return x

    mw = MonoWorker()
    futures = [mw.submit(f, i) for i in range(10)]
    for future in as_completed(futures):
        assert future.result() == futures.index(future)

# Generated at 2022-06-18 11:40:50.974874
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Lock
    from multiprocessing import Queue
    from concurrent.futures import CancelledError

    def func(x, y, z):
        sleep(random())
        return x + y + z

    def test_func(x, y, z, q):
        try:
            q.put(func(x, y, z))
        except CancelledError:
            q.put(None)

    def test_submit(mw, x, y, z):
        q = Queue()
        f = mw.submit(test_func, x, y, z, q)
        assert q.get() == x + y + z
        assert f.done()
        assert f.result() == x + y + z

    # Test single submit
    m

# Generated at 2022-06-18 11:40:53.198068
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
    assert mw.futures[0].result() == 9

# Generated at 2022-06-18 11:40:59.549486
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    from threading import Lock
    from concurrent.futures import Future
    from ..utils import _range


# Generated at 2022-06-18 11:41:07.823186
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from ..utils import _term_move_up

    def func(x, y, z, e):
        time.sleep(x)
        tqdm_auto.write('{} {} {}'.format(y, z, e.is_set()))
        return x + y + z

    e = Event()
    e.set()
    mw = MonoWorker()
    f1 = mw.submit(func, 0.1, 1, 2, e)
    f2 = mw.submit(func, 0.2, 3, 4, e)
    f3 = mw.submit(func, 0.3, 5, 6, e)
    f4 = mw.submit(func, 0.4, 7, 8, e)

# Generated at 2022-06-18 11:41:11.789991
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading

    def func(i):
        time.sleep(random.random())
        return i

    mw = MonoWorker()
    futures = []
    for i in range(10):
        futures.append(mw.submit(func, i))
    for f in futures:
        assert f.result() == 9

# Generated at 2022-06-18 11:41:32.328831
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event

    def f(x, e):
        e.wait()
        return x

    e = Event()
    mw = MonoWorker()
    f1 = mw.submit(f, 1, e)
    f2 = mw.submit(f, 2, e)
    f3 = mw.submit(f, 3, e)
    f4 = mw.submit(f, 4, e)
    f5 = mw.submit(f, 5, e)
    f6 = mw.submit(f, 6, e)
    f7 = mw.submit(f, 7, e)
    f8 = mw.submit(f, 8, e)
    f9 = mw.submit(f, 9, e)

# Generated at 2022-06-18 11:41:41.459351
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event

    def wait_for_event(event, timeout=None):
        event.wait(timeout)
        return event.is_set()

    def wait_for_event_with_timeout(event, timeout=None):
        event.wait(timeout)
        return event.is_set()

    def wait_for_event_with_timeout_and_raise(event, timeout=None):
        event.wait(timeout)
        if event.is_set():
            raise RuntimeError('event is set')
        return event.is_set()

    def wait_for_event_with_timeout_and_raise_and_cancel(event, timeout=None):
        event.wait(timeout)
        if event.is_set():
            raise RuntimeError('event is set')
        return event.is_

# Generated at 2022-06-18 11:41:49.181833
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import as_completed

    def func(x, y, z, e):
        sleep(y)
        e.set()
        return x + z

    e = Event()
    mw = MonoWorker()
    f1 = mw.submit(func, 1, 0.1, 2, e)
    f2 = mw.submit(func, 3, 0.2, 4, e)
    f3 = mw.submit(func, 5, 0.3, 6, e)
    f4 = mw.submit(func, 7, 0.4, 8, e)
    f5 = mw.submit(func, 9, 0.5, 10, e)

# Generated at 2022-06-18 11:41:59.300696
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from threading import Thread

    def sleep(t):
        time.sleep(t)
        return t

    def wait(f):
        return f.result()

    def wait_all(fs):
        return [f.result() for f in fs]

    def wait_any(fs):
        return next(f for f in fs if f.done()).result()

    def wait_any_exc(fs):
        return next(f for f in fs if f.exception()).exception()

    def wait_all_exc(fs):
        return [f.exception() for f in fs]

    def wait_any_cancel(fs):
        return next(f for f in fs if f.cancelled()).cancelled()


# Generated at 2022-06-18 11:42:09.304714
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future

    def func(x):
        time.sleep(x)
        return x

    def func_error(x):
        time.sleep(x)
        raise Exception('error')

    def func_cancel(x, e):
        time.sleep(x)
        e.wait()
        return x

    def func_cancel_error(x, e):
        time.sleep(x)
        e.wait()
        raise Exception('error')

    def func_cancel_error_2(x, e):
        time.sleep(x)
        e.wait()
        raise Exception('error')

    def func_cancel_error_3(x, e):
        time.sleep(x)
        e.wait()
        raise Exception

# Generated at 2022-06-18 11:42:14.481544
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def _test_func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(_test_func, i)
    for i in _range(10):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:42:22.404237
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from itertools import count
    from multiprocessing import cpu_count
    from concurrent.futures import ThreadPoolExecutor

    def func(i):
        sleep(random())
        return i

    def test_MonoWorker_submit_helper(max_workers):
        mw = MonoWorker()
        for i in count():
            mw.submit(func, i)
            if i >= max_workers:
                break
        return mw

    def test_ThreadPoolExecutor_submit_helper(max_workers):
        tpe = ThreadPoolExecutor(max_workers=max_workers)
        for i in count():
            tpe.submit(func, i)
            if i >= max_workers:
                break
        return tpe


# Generated at 2022-06-18 11:42:26.677696
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def slow_square(x):
        time.sleep(x)
        return x ** 2

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(slow_square, i)
    assert mw.futures[0].result() == 81

# Generated at 2022-06-18 11:42:35.915324
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Event
    from concurrent.futures import as_completed
    from tqdm.contrib.concurrent import MonoWorker

    def func(x, delay=0.1, fail=False):
        sleep(delay)
        if fail:
            raise Exception("Failed")
        return x

    def test_func(x, delay=0.1, fail=False):
        """
        Test `MonoWorker.submit` with `func`.
        """
        mw = MonoWorker()
        futures = [mw.submit(func, x, delay=delay, fail=fail)
                   for x in range(x)]
        for f in as_completed(futures):
            assert f.result() == x - 1


# Generated at 2022-06-18 11:42:44.309929
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def slow_square(x):
        time.sleep(0.1)
        return x ** 2

    def fast_square(x):
        return x ** 2

    def slow_cube(x):
        time.sleep(0.1)
        return x ** 3

    def fast_cube(x):
        return x ** 3

    def slow_quad(x):
        time.sleep(0.1)
        return x ** 4

    def fast_quad(x):
        return x ** 4

    def slow_quint(x):
        time.sleep(0.1)
        return x ** 5

    def fast_quint(x):
        return x ** 5

    def slow_sext(x):
        time.sleep(0.1)
        return x ** 6

# Generated at 2022-06-18 11:43:23.071753
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def test_submit(self):
            def func(x):
                time.sleep(x)
                return x

            def func_exception(x):
                time.sleep(x)
                raise Exception("Exception raised")

            def func_cancel(x):
                time.sleep(x)
                return x

            def func_cancel_exception(x):
                time.sleep(x)
                raise Exception("Exception raised")

            def func_cancel_exception_cancel(x):
                time.sleep(x)
                raise Exception("Exception raised")


# Generated at 2022-06-18 11:43:29.149780
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading

    def func(x):
        time.sleep(random.random())
        return x

    mw = MonoWorker()
    for i in range(10):
        mw.submit(func, i)
    time.sleep(1)
    assert len(mw.futures) == 1
    assert mw.futures[0].result() == 9

    # test that the running task is not replaced
    mw = MonoWorker()
    for i in range(10):
        mw.submit(func, i)
    time.sleep(1)
    assert len(mw.futures) == 1
    assert mw.futures[0].result() == 9

    # test that the waiting task is not replaced
    mw = MonoWorker()


# Generated at 2022-06-18 11:43:33.429819
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def test_func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(5):
        mw.submit(test_func, i)
        time.sleep(0.05)
    time.sleep(0.5)
    assert mw.futures[0].result() == 4

# Generated at 2022-06-18 11:43:38.626734
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def _test_submit(n, sleep=0.01):
        def _test_submit_inner(n, sleep=0.01):
            for _ in _range(n):
                time.sleep(sleep)
                yield

        mw = MonoWorker()
        for _ in _range(n):
            mw.submit(_test_submit_inner, n, sleep)
            time.sleep(sleep)

    test_MonoWorker_submit.__doc__ = _test_submit.__doc__
    _test_submit(10)

# Generated at 2022-06-18 11:43:46.710579
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from concurrent.futures import Future

    def _test_func(x):
        sleep(x)
        return x

    def _test_func_exception(x):
        raise Exception("test exception")

    def _test_func_cancel(x):
        sleep(x)
        return x

    def _test_func_cancel_exception(x):
        sleep(x)
        raise Exception("test exception")

    def _test_func_cancel_exception_2(x):
        sleep(x)
        raise Exception("test exception")

    def _test_func_cancel_exception_3(x):
        sleep(x)
        raise Exception("test exception")


# Generated at 2022-06-18 11:43:50.381464
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random

    def func(x):
        sleep(random())
        return x

    mw = MonoWorker()
    for i in range(10):
        mw.submit(func, i)
    for i in range(10):
        assert mw.futures[0].result() == i

# Generated at 2022-06-18 11:43:54.986426
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.05)
    for i in _range(10):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:44:00.607214
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def _test_submit(n, sleep, max_workers):
        mw = MonoWorker()
        mw.pool = ThreadPoolExecutor(max_workers=max_workers)
        for i in _range(n):
            mw.submit(time.sleep, sleep)
        time.sleep(sleep)

    for max_workers in (1, 2):
        for sleep in (0.1, 0.2, 0.3):
            for n in (1, 2, 3):
                yield _test_submit, n, sleep, max_workers

# Generated at 2022-06-18 11:44:04.556587
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def test_func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(test_func, i)
    assert len(mw.futures) == 1
    assert mw.futures[0].result() == 9

# Generated at 2022-06-18 11:44:13.282143
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event

    def wait_and_return(n, event):
        event.wait()
        return n

    mw = MonoWorker()
    e1 = Event()
    e2 = Event()
    e3 = Event()
    f1 = mw.submit(wait_and_return, 1, e1)
    f2 = mw.submit(wait_and_return, 2, e2)
    f3 = mw.submit(wait_and_return, 3, e3)
    assert f1.result() == 1
    assert f2.result() == 2
    assert f3.result() == 3
    e1.set()
    e2.set()
    e3.set()
    time.sleep(0.1)

# Generated at 2022-06-18 11:45:36.613327
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import as_completed
    from ..utils import _range

    def f(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
    for future in as_completed(mw.futures):
        assert future.result() == 9

# Generated at 2022-06-18 11:45:42.195090
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    mw.submit(f, 1)
    mw.submit(f, 2)
    mw.submit(f, 3)
    mw.submit(f, 4)
    mw.submit(f, 5)
    mw.submit(f, 6)
    mw.submit(f, 7)
    mw.submit(f, 8)
    mw.submit(f, 9)
    mw.submit(f, 10)
    mw.submit(f, 11)
    mw.submit(f, 12)
    mw.submit(f, 13)
    mw.submit(f, 14)
   

# Generated at 2022-06-18 11:45:45.677187
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
        time.sleep(0.01)

    for i in _range(10):
        mw.submit(func, i)
        time.sleep(0.01)

# Generated at 2022-06-18 11:45:52.871397
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Thread

    def func(x):
        sleep(random())
        return x

    mw = MonoWorker()
    for i in range(10):
        mw.submit(func, i)
    for i in range(10):
        assert mw.futures[0].result() == i

    def func2(x):
        sleep(random())
        raise Exception('test')

    mw = MonoWorker()
    for i in range(10):
        mw.submit(func2, i)
    for i in range(10):
        assert mw.futures[0].result() == i

    def func3(x):
        sleep(random())
        raise Exception('test')

    mw = MonoWorker()

# Generated at 2022-06-18 11:46:00.361226
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)

# Generated at 2022-06-18 11:46:04.354172
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from ..utils import _range

    def func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
    assert isinstance(mw.futures[0], Future)
    assert mw.futures[0].result() == 9

# Generated at 2022-06-18 11:46:11.951762
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    from ..utils import _term_move_up

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    assert mw.submit(f, 0.1)
    assert mw.submit(f, 0.2)
    assert mw.submit(f, 0.3)
    assert mw.submit(f, 0.4)
    assert mw.submit(f, 0.5)
    assert mw.submit(f, 0.6)
    assert mw.submit(f, 0.7)
    assert mw.submit(f, 0.8)
    assert mw.submit(f, 0.9)
    assert mw.submit(f, 1.0)