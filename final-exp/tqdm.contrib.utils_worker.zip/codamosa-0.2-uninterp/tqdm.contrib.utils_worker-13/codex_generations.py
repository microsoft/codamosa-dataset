

# Generated at 2022-06-18 11:36:28.878167
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def test_submit(self):
            def func(x):
                sleep(x)
                return x

            mw = MonoWorker()
            f1 = mw.submit(func, 1)
            f2 = mw.submit(func, 2)
            f3 = mw.submit(func, 3)
            f4 = mw.submit(func, 4)
            f5 = mw.submit(func, 5)
            self.assertIsInstance(f1, Future)
            self.assertIsInstance(f2, Future)
            self.assertIsInstance(f3, Future)

# Generated at 2022-06-18 11:36:30.782804
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
        time.sleep(0.1)

# Generated at 2022-06-18 11:36:33.970487
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def wait(n):
        time.sleep(n)
        return n

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(wait, i)
    for i in _range(10):
        assert mw.futures[0].result() == i

# Generated at 2022-06-18 11:36:44.471454
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def test_submit(self):
            def func(x):
                sleep(x)
                return x

            def func_exception(x):
                raise Exception(x)

            def func_cancel(x, e):
                sleep(x)
                e.set()

            def func_cancel_exception(x, e):
                e.set()
                raise Exception(x)

            def func_cancel_exception_2(x, e):
                e.set()
                raise Exception(x)

            def func_cancel_exception_3(x, e):
                e.set()
                raise Exception(x)



# Generated at 2022-06-18 11:36:54.638522
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Event

    def func(x, y, z, e):
        sleep(random())
        e.set()
        return x + y + z

    e = Event()
    mw = MonoWorker()
    f = mw.submit(func, 1, 2, 3, e)
    assert not e.is_set()
    assert f.result() == 6
    assert e.is_set()
    e.clear()
    f = mw.submit(func, 1, 2, 3, e)
    assert not e.is_set()
    assert f.result() == 6
    assert e.is_set()
    e.clear()
    f = mw.submit(func, 1, 2, 3, e)
    assert not e.is_

# Generated at 2022-06-18 11:37:06.478710
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from ..utils import format_sizeof

    def wait_for_event(event, timeout=None):
        """Wait for event to be set, or timeout"""
        event.wait(timeout)
        return event.is_set()

    def wait_for_event_or_cancel(event, timeout=None):
        """Wait for event to be set, or timeout, or cancel"""
        try:
            return wait_for_event(event, timeout)
        except Exception:
            return False

    def wait_for_event_or_cancel_with_progress(event, timeout=None):
        """Wait for event to be set, or timeout, or cancel, with progress"""

# Generated at 2022-06-18 11:37:15.638055
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Thread
    from multiprocessing import Process
    from concurrent.futures import Future
    from concurrent.futures import CancelledError

    def _test(func, *args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            return e

    def _test_func(x):
        sleep(random())
        return x

    def _test_func_exception(x):
        sleep(random())
        raise Exception(x)

    def _test_func_cancel(x):
        sleep(random())
        raise CancelledError(x)

    def _test_func_cancel_exception(x):
        sleep(random())
        raise CancelledError(x)


# Generated at 2022-06-18 11:37:25.742868
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from multiprocessing import Process
    from multiprocessing.connection import Listener
    from threading import Thread

    def server(address):
        with Listener(address) as listener:
            with listener.accept() as conn:
                conn.send(1)
                time.sleep(0.1)
                conn.send(2)
                time.sleep(0.1)
                conn.send(3)
                time.sleep(0.1)
                conn.send(4)
                time.sleep(0.1)
                conn.send(5)
                time.sleep(0.1)
                conn.send(6)
                time.sleep(0.1)
                conn.send(7)
                time.sleep(0.1)
                conn.send(8)

# Generated at 2022-06-18 11:37:35.717144
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading

    def sleep_random(n):
        time.sleep(random.random() * n)

    def test_submit(n, m):
        mw = MonoWorker()
        for i in range(n):
            mw.submit(sleep_random, m)
        time.sleep(m * 0.1)
        assert len(mw.futures) == 1

    for n in [1, 2, 3, 4, 5, 10, 100]:
        for m in [0.1, 0.2, 0.5, 1.0, 2.0]:
            test_submit(n, m)

    # Test that the waiting task is the most recent submitted
    mw = MonoWorker()
    mw.submit(sleep_random, 0.1)

# Generated at 2022-06-18 11:37:45.267056
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import as_completed

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    mw.submit(f, 1)
    mw.submit(f, 2)
    mw.submit(f, 3)
    mw.submit(f, 4)
    mw.submit(f, 5)
    mw.submit(f, 6)
    mw.submit(f, 7)
    mw.submit(f, 8)
    mw.submit(f, 9)
    mw.submit(f, 10)
    mw.submit(f, 11)
    mw.submit(f, 12)
    mw.submit(f, 13)
    mw.submit(f, 14)


# Generated at 2022-06-18 11:37:56.924473
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from concurrent.futures import Future
    from contextlib import contextmanager

    @contextmanager
    def lock_and_sleep(lock, duration):
        lock.acquire()
        try:
            sleep(duration)
        finally:
            lock.release()

    def func(lock, duration):
        with lock_and_sleep(lock, duration):
            return duration

    lock = Lock()
    worker = MonoWorker()
    assert len(worker.futures) == 0
    assert worker.submit(func, lock, 0.1) is not None
    assert len(worker.futures) == 1
    assert worker.submit(func, lock, 0.1) is not None
    assert len(worker.futures) == 1

# Generated at 2022-06-18 11:38:03.684780
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Lock
    from concurrent.futures import as_completed
    from tqdm.contrib.concurrent import MonoWorker

    def func(x):
        sleep(random())
        return x

    mw = MonoWorker()
    lock = Lock()
    results = []

    for i in range(10):
        mw.submit(func, i)

    for f in as_completed(mw.futures):
        with lock:
            results.append(f.result())

    assert results == sorted(results)

# Generated at 2022-06-18 11:38:11.642808
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from concurrent.futures import Future
    from unittest import TestCase

    class MonoWorkerTest(MonoWorker):
        def __init__(self):
            super(MonoWorkerTest, self).__init__()
            self.lock = Lock()
            self.counter = 0
            self.running = None
            self.waiting = None

        def submit(self, func, *args, **kwargs):
            with self.lock:
                self.counter += 1
                self.running = self.counter
                self.waiting = None
            return super(MonoWorkerTest, self).submit(func, *args, **kwargs)


# Generated at 2022-06-18 11:38:16.100948
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from itertools import count

    def func(i):
        sleep(random())
        return i

    mw = MonoWorker()
    for i in count():
        mw.submit(func, i)
        sleep(0.1)

# Generated at 2022-06-18 11:38:25.941435
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from ..utils import _range

    def _test_func(x):
        time.sleep(0.1)
        return x

    def _test_func_exception(x):
        raise Exception("test exception")

    def _test_func_cancel(x):
        time.sleep(1)
        return x

    def _test_func_cancel_exception(x):
        time.sleep(1)
        raise Exception("test exception")

    def _test_func_cancel_exception_ignore(x):
        time.sleep(1)
        raise Exception("test exception")

    def _test_func_cancel_exception_ignore_2(x):
        time.sleep(1)
        raise Exception("test exception")


# Generated at 2022-06-18 11:38:31.934215
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock

    def func(i, lock):
        with lock:
            print(i)
            sleep(0.1)
            print(i)

    lock = Lock()
    worker = MonoWorker()
    for i in range(5):
        worker.submit(func, i, lock)
        sleep(0.05)

# Generated at 2022-06-18 11:38:40.561559
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event

    def wait(t, e):
        time.sleep(t)
        e.set()

    def wait_and_return(t, e):
        time.sleep(t)
        e.set()
        return t

    def wait_and_raise(t, e):
        time.sleep(t)
        e.set()
        raise RuntimeError(t)

    def wait_and_return_and_raise(t, e):
        time.sleep(t)
        e.set()
        return t
        raise RuntimeError(t)

    def wait_and_raise_and_return(t, e):
        time.sleep(t)
        e.set()
        raise RuntimeError(t)
        return t


# Generated at 2022-06-18 11:38:52.261123
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    assert len(mw.futures) == 0
    f1 = mw.submit(f, 1)
    assert len(mw.futures) == 1
    assert isinstance(f1, Future)
    f2 = mw.submit(f, 2)
    assert len(mw.futures) == 1
    assert isinstance(f2, Future)
    assert f2 is mw.futures[0]
    assert f2.result() == 2
    assert f1.cancelled()
    f3 = mw.submit(f, 3)

# Generated at 2022-06-18 11:39:01.958272
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import as_completed

    def func(x, y, z, delay=0.1):
        time.sleep(delay)
        return x + y + z

    worker = MonoWorker()
    assert len(worker.futures) == 0

    # submit first task
    fut1 = worker.submit(func, 1, 2, 3)
    assert len(worker.futures) == 1
    assert fut1.result() == 6

    # submit second task
    fut2 = worker.submit(func, 4, 5, 6)
    assert len(worker.futures) == 1
    assert fut2.result() == 15

    # submit third task
    fut3 = worker.submit(func, 7, 8, 9)

# Generated at 2022-06-18 11:39:09.947562
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Event
    from concurrent.futures import as_completed
    from tqdm.contrib.concurrency import MonoWorker

    def test_func(x, y, z):
        sleep(random())
        return x + y + z

    def test_func_exception(x, y, z):
        sleep(random())
        raise Exception('test_func_exception')

    def test_func_cancel(x, y, z):
        sleep(random())
        if not e.is_set():
            e.wait()
        return x + y + z

    e = Event()
    mw = MonoWorker()
    for _ in range(10):
        mw.submit(test_func, 1, 2, 3)

# Generated at 2022-06-18 11:39:17.312253
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(5):
        mw.submit(func, i)
        time.sleep(0.1)

# Generated at 2022-06-18 11:39:20.920088
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import as_completed
    from ..utils import _range

    def func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(5):
        mw.submit(func, i)
    for future in as_completed(mw.futures):
        assert future.result() == 4

# Generated at 2022-06-18 11:39:25.725658
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from multiprocessing import cpu_count
    from concurrent.futures import as_completed

    def func(x):
        sleep(random())
        return x

    with MonoWorker() as worker:
        futures = [worker.submit(func, i) for i in range(cpu_count())]
        for future in as_completed(futures):
            assert future.result() == futures.index(future)

# Generated at 2022-06-18 11:39:32.003724
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up
    from ..utils import _range

    def _test_submit(n, sleep):
        mw = MonoWorker()
        for i in _range(n):
            mw.submit(time.sleep, sleep)
            tqdm_auto.write("{}".format(i))
            _term_move_up()

    _test_submit(10, 0.1)
    _test_submit(10, 0.5)

# Generated at 2022-06-18 11:39:37.777839
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up
    from ..utils import _range

    def _test_func(i):
        time.sleep(0.1)
        return i

    with tqdm_auto.tqdm(total=10) as t:
        mw = MonoWorker()
        for i in _range(10):
            mw.submit(_test_func, i)
            t.update()
            t.write('{}'.format(i))
            _term_move_up()

# Generated at 2022-06-18 11:39:41.014021
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Lock
    from concurrent.futures import Future
    from tqdm.contrib.concurrency import MonoWorker

    def func(x):
        sleep(random())
        return x

    def test_submit(n, max_workers):
        mw = MonoWorker()
        mw.pool = ThreadPoolExecutor(max_workers=max_workers)
        mw.futures = deque([], max_workers)
        mw.pool._work_queue = deque([], max_workers)
        mw.pool._work_queue._all_tasks_done = Lock()
        mw.pool._work_queue._unfinished_tasks = 0
        mw.pool._work_queue._cond = Lock()
        mw.pool._

# Generated at 2022-06-18 11:39:44.833096
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
        time.sleep(0.1)
    assert mw.futures[0].result() == 9
    assert mw.futures[1].result() == 8

# Generated at 2022-06-18 11:39:48.842337
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)
    time.sleep(10)

# Generated at 2022-06-18 11:39:56.425315
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def test_func(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(test_func, i)
    time.sleep(0.5)
    assert len(mw.futures) == 1
    assert mw.futures[0].result() == 9

# Generated at 2022-06-18 11:40:06.368871
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    assert len(mw.futures) == 0
    assert mw.submit(f, 1)
    assert len(mw.futures) == 1
    assert mw.submit(f, 2)
    assert len(mw.futures) == 1
    assert mw.submit(f, 3)
    assert len(mw.futures) == 1
    assert mw.submit(f, 4)
    assert len(mw.futures) == 1
    assert mw.submit(f, 5)
    assert len(mw.futures) == 1
    assert mw.submit(f, 6)
    assert len

# Generated at 2022-06-18 11:40:24.277812
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from ..utils import _range

    def func(x):
        time.sleep(0.1)
        return x

    def test_func(x):
        time.sleep(0.1)
        return x

    def test_func_exception(x):
        time.sleep(0.1)
        raise Exception("test_func_exception")

    def test_func_cancel(x):
        time.sleep(0.1)
        return x

    def test_func_cancel_exception(x):
        time.sleep(0.1)
        raise Exception("test_func_cancel_exception")

    def test_func_cancel_exception_2(x):
        time.sleep(0.1)

# Generated at 2022-06-18 11:40:33.777586
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def test_submit(self):
            def func(n):
                time.sleep(n)
                return n

            def func_exception(n):
                raise Exception('test exception')

            def func_cancel(n):
                time.sleep(n)
                return n

            def func_cancel_exception(n):
                time.sleep(n)
                raise Exception('test exception')

            def func_cancel_exception_2(n):
                time.sleep(n)
                raise Exception('test exception')

            def func_cancel_exception_3(n):
                time.sleep(n)

# Generated at 2022-06-18 11:40:40.051450
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up
    from ..utils import _range

    def _print(s):
        tqdm_auto.write(s)
        time.sleep(1)

    def _print_and_return(s):
        _print(s)
        return s

    def _print_and_raise(s):
        _print(s)
        raise Exception(s)

    def _print_and_return_after_raise(s):
        try:
            _print_and_raise(s)
        except Exception as e:
            tqdm_auto.write(str(e))
        return s


# Generated at 2022-06-18 11:40:47.163358
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event

    def func(i, wait_event):
        sleep(i)
        wait_event.set()

    wait_event = Event()
    worker = MonoWorker()
    wait_event.clear()
    worker.submit(func, 1, wait_event)
    wait_event.wait()
    wait_event.clear()
    worker.submit(func, 2, wait_event)
    wait_event.wait()
    wait_event.clear()
    worker.submit(func, 3, wait_event)
    wait_event.wait()
    wait_event.clear()
    worker.submit(func, 4, wait_event)
    wait_event.wait()
    wait_event.clear()
    worker.submit(func, 5, wait_event)
    wait_

# Generated at 2022-06-18 11:40:52.082386
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up
    from ..utils import _range

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i / 10)
        tqdm_auto.write("{}".format(i))
        _term_move_up()
    for i in _range(10):
        mw.submit(func, i / 10)
        tqdm_auto.write("{}".format(i))
        _term_move_up()
    for i in _range(10):
        mw.submit(func, i / 10)
        tqdm_auto.write("{}".format(i))
        _term_move_up()


# Generated at 2022-06-18 11:40:58.001143
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event

    def wait(seconds, event):
        event.wait(seconds)

    def wait_and_return(seconds, event):
        event.wait(seconds)
        return seconds

    def wait_and_raise(seconds, event):
        event.wait(seconds)
        raise Exception("Raised after {} seconds".format(seconds))

    def wait_and_return_or_raise(seconds, event):
        event.wait(seconds)
        if seconds == 1:
            raise Exception("Raised after {} seconds".format(seconds))
        return seconds

    def test_wait(seconds, event):
        start = time.time()
        worker = MonoWorker()
        future = worker.submit(wait, seconds, event)
        future.result()
        end = time.time()

# Generated at 2022-06-18 11:41:06.254340
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    from threading import Lock
    from concurrent.futures import Future
    from ..utils import _range

    def wait_for_future(fut):
        while not fut.done():
            time.sleep(0.01)

    def test_func(i):
        time.sleep(random.random() / 10)
        return i

    def test_func_exception(i):
        time.sleep(random.random() / 10)
        raise Exception("test_func_exception")

    def test_func_cancel(i):
        time.sleep(random.random() / 10)
        return i

    def test_func_cancel_exception(i):
        time.sleep(random.random() / 10)
        raise Exception("test_func_cancel_exception")

   

# Generated at 2022-06-18 11:41:14.032451
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    from multiprocessing import Process

    def test_func(x):
        time.sleep(x)
        return x

    def test_thread(x, mw):
        time.sleep(x)
        mw.submit(test_func, x)

    def test_process(x, mw):
        time.sleep(x)
        mw.submit(test_func, x)

    mw = MonoWorker()
    assert len(mw.futures) == 0
    mw.submit(test_func, 0.1)
    assert len(mw.futures) == 1
    mw.submit(test_func, 0.2)
    assert len(mw.futures) == 1

# Generated at 2022-06-18 11:41:16.952777
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.05)

# Generated at 2022-06-18 11:41:25.653673
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from random import random
    from threading import Event

    def func(x):
        time.sleep(random())
        return x

    def func_exception(x):
        raise Exception("Exception")

    def func_event(x, event):
        time.sleep(random())
        event.set()
        return x

    def func_event_exception(x, event):
        time.sleep(random())
        event.set()
        raise Exception("Exception")

    def test_func(func, func_exception, func_event, func_event_exception):
        worker = MonoWorker()
        event = Event()
        assert len(worker.futures) == 0
        assert worker.submit(func, 1) is not None
        assert len(worker.futures) == 1
        assert worker

# Generated at 2022-06-18 11:41:49.094091
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import TimeoutError

    def wait_and_return(wait_time, return_value):
        time.sleep(wait_time)
        return return_value

    def wait_and_raise(wait_time, exception):
        time.sleep(wait_time)
        raise exception

    def wait_and_return_with_timeout(wait_time, return_value, timeout):
        time.sleep(wait_time)
        if timeout.is_set():
            return return_value
        else:
            raise TimeoutError

    def wait_and_raise_with_timeout(wait_time, exception, timeout):
        time.sleep(wait_time)
        if timeout.is_set():
            raise exception
        else:
            raise TimeoutError


# Generated at 2022-06-18 11:41:59.217369
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future

    def func(x):
        time.sleep(x)
        return x

    def assert_future_done(future, expected):
        assert isinstance(future, Future)
        assert future.done()
        assert future.result() == expected

    def assert_future_cancelled(future):
        assert isinstance(future, Future)
        assert future.done()
        assert future.cancelled()

    def assert_future_running(future):
        assert isinstance(future, Future)
        assert not future.done()
        assert not future.cancelled()

    def assert_future_none(future):
        assert future is None


# Generated at 2022-06-18 11:42:09.206253
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import as_completed
    from ..utils import format_sizeof

    def wait_and_return(seconds, return_value):
        sleep(seconds)
        return return_value

    def wait_and_raise(seconds, exception):
        sleep(seconds)
        raise exception

    def wait_and_return_sizeof(seconds, return_value):
        sleep(seconds)
        return format_sizeof(return_value)

    def wait_and_raise_sizeof(seconds, exception):
        sleep(seconds)
        raise exception

    def test_MonoWorker_submit_return():
        """Test MonoWorker.submit with return value."""
        mw = MonoWorker()
        for i in range(5):
            mw.submit

# Generated at 2022-06-18 11:42:18.679893
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import TimeoutError
    from ..utils import _range

    def wait(t):
        time.sleep(t)
        return t

    def wait_and_raise(t):
        time.sleep(t)
        raise ValueError(t)

    def wait_and_cancel(t):
        time.sleep(t)
        raise TimeoutError()

    def wait_and_cancel_and_raise(t):
        time.sleep(t)
        raise TimeoutError()
        raise ValueError(t)

    def wait_and_cancel_and_raise_and_cancel(t):
        time.sleep(t)
        raise TimeoutError()
        raise ValueError(t)
        raise TimeoutError()


# Generated at 2022-06-18 11:42:20.804993
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)

# Generated at 2022-06-18 11:42:26.916717
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up
    from ..utils import _range

    def _test_func(x):
        time.sleep(0.1)
        return x

    with tqdm_auto.tqdm(total=10, desc='test') as t:
        mw = MonoWorker()
        for i in _range(10):
            mw.submit(_test_func, i)
            t.update()
            _term_move_up()
            t.set_description('test {}'.format(i))

# Generated at 2022-06-18 11:42:36.188730
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event

    def func(x, sleep_time=0.1, wait_event=None):
        if wait_event is not None:
            wait_event.wait()
        sleep(sleep_time)
        return x

    wait_event = Event()
    wait_event.clear()
    mw = MonoWorker()
    f1 = mw.submit(func, 1, wait_event=wait_event)
    f2 = mw.submit(func, 2)
    f3 = mw.submit(func, 3)
    assert f1.done()
    assert not f2.done()
    assert not f3.done()
    assert f2.result() == 2
    assert f3.result() == 3
    wait_event.set()
    assert f1.result

# Generated at 2022-06-18 11:42:44.549289
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import as_completed
    from ..utils import format_sizeof

    def func(x, y, z, sleep_time=0.01, event=None):
        sleep(sleep_time)
        if event is not None:
            event.set()
        return x + y + z

    mw = MonoWorker()
    e = Event()
    e.clear()
    f1 = mw.submit(func, 1, 2, 3, sleep_time=0.1, event=e)
    e.wait()
    assert f1.done()
    assert f1.result() == 6
    e.clear()
    f2 = mw.submit(func, 1, 2, 3, sleep_time=0.1, event=e)

# Generated at 2022-06-18 11:42:50.044618
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock

    def f(x, lock):
        with lock:
            print(x)
            sleep(1)

    lock = Lock()
    mw = MonoWorker()
    for i in range(5):
        mw.submit(f, i, lock)
    sleep(2)
    for i in range(5):
        mw.submit(f, i, lock)
    sleep(2)
    for i in range(5):
        mw.submit(f, i, lock)
    sleep(2)

# Generated at 2022-06-18 11:42:57.927915
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Thread
    from queue import Queue

    def _test_MonoWorker_submit(q, mw):
        q.put(mw.submit(sleep, 1))
        q.put(mw.submit(sleep, 2))
        q.put(mw.submit(sleep, 3))
        q.put(mw.submit(sleep, 4))

    q = Queue()
    mw = MonoWorker()
    t = Thread(target=_test_MonoWorker_submit, args=(q, mw))
    t.start()
    t.join()
    assert q.get().result() == 4
    assert q.get().result() == 4
    assert q.get().result() == 4
    assert q.get().result() == 4

# Generated at 2022-06-18 11:43:45.356570
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
    time.sleep(0.1)
    assert len(mw.futures) == 1
    assert mw.futures[0].result() == 9
    time.sleep(9)
    assert len(mw.futures) == 0

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
    time.sleep(0.1)
    assert len(mw.futures) == 1
    assert mw.futures[0].result() == 9
   

# Generated at 2022-06-18 11:43:53.706951
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    from ..utils import _range

    def func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
    for i in _range(10):
        mw.submit(func, i)
    for i in _range(10):
        mw.submit(func, i)
    for i in _range(10):
        mw.submit(func, i)
    for i in _range(10):
        mw.submit(func, i)
    for i in _range(10):
        mw.submit(func, i)
    for i in _range(10):
        mw.submit(func, i)

# Generated at 2022-06-18 11:44:01.104891
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(5):
        mw.submit(func, i)
    time.sleep(2)
    for i in _range(5):
        mw.submit(func, i)
    time.sleep(2)
    for i in _range(5):
        mw.submit(func, i)
    time.sleep(2)
    for i in _range(5):
        mw.submit(func, i)
    time.sleep(2)
    for i in _range(5):
        mw.submit(func, i)
    time.sleep(2)

# Generated at 2022-06-18 11:44:09.742572
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    from threading import Event
    from concurrent.futures import as_completed
    from ..utils import _term_move_up

    def func(i, sleep=0.1):
        time.sleep(sleep)
        return i

    def test_func(i, sleep=0.1):
        time.sleep(sleep)
        return i

    def test_func_exception(i, sleep=0.1):
        time.sleep(sleep)
        raise Exception('test_func_exception')

    def test_func_cancel(i, sleep=0.1):
        time.sleep(sleep)
        if i == 0:
            raise Exception('test_func_cancel')


# Generated at 2022-06-18 11:44:13.956447
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
    for i in _range(10):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:44:21.536564
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from threading import Lock
    from unittest import TestCase

    class Test(TestCase):
        def setUp(self):
            self.lock = Lock()
            self.count = 0
            self.worker = MonoWorker()

        def test_submit(self):
            self.assertEqual(len(self.worker.futures), 0)
            self.worker.submit(self.inc)
            self.assertEqual(len(self.worker.futures), 1)
            self.worker.submit(self.inc)
            self.assertEqual(len(self.worker.futures), 1)
            self.worker.submit(self.inc)
            self.assertEqual(len(self.worker.futures), 1)

# Generated at 2022-06-18 11:44:29.932473
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Thread
    from concurrent.futures import wait

    def slow_func(x):
        sleep(random())
        return x

    def test_func(x):
        return x

    def test_func_exception(x):
        raise Exception('test_func_exception')

    def test_func_cancel(x):
        sleep(random())
        return x

    def test_func_cancel_exception(x):
        sleep(random())
        raise Exception('test_func_cancel_exception')

    def test_func_cancel_exception_2(x):
        sleep(random())
        raise Exception('test_func_cancel_exception_2')


# Generated at 2022-06-18 11:44:36.157420
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from . import _test_MonoWorker_submit
    _test_MonoWorker_submit.test_MonoWorker_submit(MonoWorker)
    _test_MonoWorker_submit.test_MonoWorker_submit(MonoWorker,
                                                   sleep_time=0.1)
    _test_MonoWorker_submit.test_MonoWorker_submit(MonoWorker,
                                                   sleep_time=0.1,
                                                   sleep_func=time.sleep)

# Generated at 2022-06-18 11:44:43.199894
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from ..utils import _range

    def test_func(i):
        time.sleep(0.1)
        return i

    def test_func_exception(i):
        raise Exception("test_func_exception(%d)" % i)

    def test_func_cancel(i):
        time.sleep(0.1)
        return i

    def test_func_cancel_exception(i):
        time.sleep(0.1)
        raise Exception("test_func_cancel_exception(%d)" % i)

    def test_func_cancel_exception_no_sleep(i):
        raise Exception("test_func_cancel_exception_no_sleep(%d)" % i)


# Generated at 2022-06-18 11:44:51.921127
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_time
    from ..utils import format_size
    from ..utils import format_speed
    from ..utils import format_eta
    from ..utils import format_size_str
    from ..utils import format_interval_str
    from ..utils import format_meter_str
    from ..utils import format_number_str
    from ..utils import format_time_str
    from ..utils import format_size_str
    from ..utils import format_speed_str
    from ..utils import format_eta_str
    from ..utils import format_sizeof_str
    from ..utils import format_sizeof_str
    from ..utils import format_inter