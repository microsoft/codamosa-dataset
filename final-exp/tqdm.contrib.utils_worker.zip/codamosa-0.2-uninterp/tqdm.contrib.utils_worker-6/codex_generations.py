

# Generated at 2022-06-18 11:36:30.041684
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up
    from ..std import time as time_std

    def func(n):
        time.sleep(n)
        return n

    mw = MonoWorker()
    with tqdm_auto.tqdm(total=10, desc='test_MonoWorker_submit') as t:
        for i in range(10):
            mw.submit(func, i)
            t.update()
            time_std.sleep(0.1)
            _term_move_up()
            t.refresh()
    assert t.n == 10

# Generated at 2022-06-18 11:36:33.713923
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
    assert len(mw.futures) == 1
    assert mw.futures[0].result() == 9

# Generated at 2022-06-18 11:36:36.069608
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
        time.sleep(0.1)

# Generated at 2022-06-18 11:36:40.493615
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Lock
    from multiprocessing import Value
    from concurrent.futures import as_completed
    from tqdm.contrib.concurrent import MonoWorker

    def worker(i, lock, counter):
        sleep(random())
        with lock:
            counter.value += 1
        return i

    lock = Lock()
    counter = Value('i', 0)
    mw = MonoWorker()
    futures = [mw.submit(worker, i, lock, counter) for i in range(10)]
    for future in as_completed(futures):
        assert future.result() == counter.value - 1



# Generated at 2022-06-18 11:36:51.761538
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import randint
    from threading import Lock
    from multiprocessing import Value
    from concurrent.futures import as_completed

    def func(x, y, z, sleep_time, lock, counter):
        """
        Simulate a function that takes a while to complete.
        """
        with lock:
            counter.value += 1
        sleep(sleep_time)
        return x + y + z

    lock = Lock()
    counter = Value('i', 0)
    mono_worker = MonoWorker()
    futures = []
    for _ in range(10):
        sleep_time = randint(1, 3)
        future = mono_worker.submit(func, 1, 2, 3, sleep_time, lock, counter)
        futures.append(future)

# Generated at 2022-06-18 11:37:02.389804
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future

    def _test(func, *args, **kwargs):
        """
        Run `func(*args, **kwargs)` and return the result.
        If `func` is a `Future`, wait for it to finish.
        """
        if isinstance(func, Future):
            return func.result()
        else:
            return func(*args, **kwargs)

    def _test_submit(worker, func, *args, **kwargs):
        """
        Run `worker.submit(func, *args, **kwargs)` and return the result.
        If `func` is a `Future`, wait for it to finish.
        """
        if isinstance(func, Future):
            return worker.submit(lambda: func.result())

# Generated at 2022-06-18 11:37:13.351183
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from concurrent.futures import Future
    from unittest import TestCase

    class Test(TestCase):
        def setUp(self):
            self.lock = Lock()
            self.counter = 0
            self.worker = MonoWorker()

        def test_submit(self):
            def inc():
                with self.lock:
                    self.counter += 1
                sleep(0.1)
                with self.lock:
                    self.counter += 1

            self.worker.submit(inc)
            self.worker.submit(inc)
            self.worker.submit(inc)
            sleep(0.2)
            self.assertEqual(self.counter, 2)


# Generated at 2022-06-18 11:37:21.208773
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Lock
    from multiprocessing import Process

    def worker(mw, lock, i):
        with lock:
            print("{} started".format(i))
        sleep(random())
        with lock:
            print("{} finished".format(i))

    mw = MonoWorker()
    lock = Lock()
    for i in range(10):
        Process(target=worker, args=(mw, lock, i)).start()
        mw.submit(worker, mw, lock, i)


# Generated at 2022-06-18 11:37:26.066437
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
    for i in _range(10):
        assert mw.futures[0].result() == i
        assert len(mw.futures) == 1

# Generated at 2022-06-18 11:37:33.790568
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    import concurrent.futures
    import unittest

    class TestMonoWorker(unittest.TestCase):
        def test_submit(self):
            def func(i):
                time.sleep(random.random() * 0.1)
                return i

            mw = MonoWorker()
            for i in range(10):
                mw.submit(func, i)
            for i in range(10):
                self.assertEqual(mw.futures[i].result(), i)

    unittest.main(verbosity=2)

# Generated at 2022-06-18 11:37:42.846770
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    from concurrent.futures import CancelledError

    def func(x):
        time.sleep(random.random())
        return x

    mw = MonoWorker()
    for i in range(10):
        mw.submit(func, i)
    for i in range(10):
        assert mw.futures[0].result() == i
    try:
        mw.futures[1].result()
    except CancelledError:
        pass
    else:
        raise AssertionError('Should have been cancelled')

# Generated at 2022-06-18 11:37:48.065140
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event

    def func(i, e):
        e.wait()
        return i

    e = Event()
    mw = MonoWorker()
    for i in range(10):
        mw.submit(func, i, e)
    e.set()
    time.sleep(0.1)
    assert mw.futures[0].result() == 9

# Generated at 2022-06-18 11:37:54.376842
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from ..utils import _range

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        assert isinstance(mw.submit(func, i), Future)
        assert len(mw.futures) == 1
    assert mw.futures[0].result() == 9
    assert len(mw.futures) == 1

# Generated at 2022-06-18 11:38:03.408685
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def _test_submit(mw, func, *args, **kwargs):
        """
        :param mw: MonoWorker instance
        :param func: function to submit
        :param args: positional arguments to func
        :param kwargs: keyword arguments to func
        """
        # Submit a task
        future = mw.submit(func, *args, **kwargs)
        # Wait for the task to complete
        future.result()
        # Submit a task that will be cancelled
        future = mw.submit(func, *args, **kwargs)
        # Wait for the task to complete
        future.result()


# Generated at 2022-06-18 11:38:06.796034
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
    for i in _range(10):
        assert mw.futures[0].result() == i

# Generated at 2022-06-18 11:38:16.176743
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Event
    from concurrent.futures import as_completed
    from tqdm.contrib.concurrency import MonoWorker

    def f(x):
        sleep(random())
        return x

    mw = MonoWorker()
    e = Event()
    e.set()
    for i in range(10):
        mw.submit(f, i)
        if i % 2 == 0:
            e.wait()
            e.clear()
    for i in range(10):
        mw.submit(f, i)
        if i % 2 == 0:
            e.wait()
            e.clear()
    for i in range(10):
        mw.submit(f, i)
        if i % 2 == 0:
            e

# Generated at 2022-06-18 11:38:26.040572
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event

    def func(x, y, z, e):
        time.sleep(x)
        e.set()
        return x + y + z

    e = Event()
    mw = MonoWorker()
    assert mw.submit(func, 1, 2, 3, e)
    assert not e.is_set()
    assert mw.submit(func, 0, 2, 3, e)
    assert e.wait(2)
    assert mw.submit(func, 1, 2, 3, e)
    assert e.wait(2)
    assert mw.submit(func, 1, 2, 3, e)
    assert e.wait(2)
    assert mw.submit(func, 1, 2, 3, e)
    assert e.wait(2)

# Generated at 2022-06-18 11:38:36.966678
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    from ..utils import _term_move_up

    def _test_func(x):
        time.sleep(x)
        return x

    def _test_func_exception(x):
        raise Exception("test exception")

    def _test_func_cancel(x):
        time.sleep(x)
        return x

    def _test_func_cancel_exception(x):
        time.sleep(x)
        raise Exception("test exception")

    def _test_func_cancel_exception_2(x):
        time.sleep(x)
        raise Exception("test exception")

    def _test_func_cancel_exception_3(x):
        time.sleep(x)
        raise Exception("test exception")


# Generated at 2022-06-18 11:38:40.852001
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.05)

    for i in _range(10):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:38:46.103639
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def _test_MonoWorker_submit(n):
        mw = MonoWorker()
        for i in _range(n):
            mw.submit(time.sleep, 0.1)
        for i in _range(n):
            mw.submit(time.sleep, 0.1)
        for i in _range(n):
            mw.submit(time.sleep, 0.1)
        mw.pool.shutdown()

    _test_MonoWorker_submit(1)
    _test_MonoWorker_submit(2)
    _test_MonoWorker_submit(3)
    _test_MonoWorker_submit(4)
    _test_MonoWorker_submit(5)

# Generated at 2022-06-18 11:39:00.160683
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase

    class Test(TestCase):
        def test_submit(self):
            def f(x):
                time.sleep(x)
                return x

            mw = MonoWorker()
            f1 = mw.submit(f, 0.1)
            f2 = mw.submit(f, 0.2)
            f3 = mw.submit(f, 0.3)
            self.assertEqual(f1.result(), 0.1)
            self.assertEqual(f2.result(), 0.2)
            self.assertEqual(f3.result(), 0.3)

            # test that waiting task is cancelled
            f1 = mw.submit(f, 0.1)


# Generated at 2022-06-18 11:39:07.759211
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import Future

    def func(x):
        sleep(x)
        return x

    def test_func(x, event):
        event.wait()
        return func(x)

    def test_func_exception(x, event):
        event.wait()
        raise Exception(x)

    def test_func_cancel(x, event):
        event.wait()
        return func(x)

    def test_func_cancel_exception(x, event):
        event.wait()
        raise Exception(x)

    def test_func_cancel_exception_ignore(x, event):
        event.wait()
        raise Exception(x)


# Generated at 2022-06-18 11:39:14.069941
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(5):
        mw.submit(f, i)
        time.sleep(0.1)
    mw.submit(f, 5)
    time.sleep(0.1)
    mw.submit(f, 6)
    time.sleep(0.1)
    mw.submit(f, 7)
    time.sleep(0.1)
    mw.submit(f, 8)
    time.sleep(0.1)
    mw.submit(f, 9)
    time.sleep(0.1)
    mw.submit(f, 10)
    time.sleep(0.1)
    m

# Generated at 2022-06-18 11:39:20.901652
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Thread
    from queue import Queue

    def _test_submit(q, mw, func, *args, **kwargs):
        q.put(mw.submit(func, *args, **kwargs))

    def _test_submit_wait(q, mw, func, *args, **kwargs):
        q.put(mw.submit(func, *args, **kwargs).result())

    def _test_submit_wait_exc(q, mw, func, *args, **kwargs):
        try:
            mw.submit(func, *args, **kwargs).result()
        except Exception as e:
            q.put(e)


# Generated at 2022-06-18 11:39:29.322257
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Lock
    from multiprocessing import cpu_count

    # Test parameters
    n_tasks = cpu_count() * 2
    sleep_time = 0.1
    n_sleeps = 5
    n_workers = cpu_count()
    n_tasks_per_worker = n_tasks // n_workers

    # Test variables
    lock = Lock()
    n_finished = 0
    n_cancelled = 0
    n_running = 0
    n_waiting = 0

    def task(i):
        sleep(sleep_time)
        with lock:
            nonlocal n_finished
            n_finished += 1
            n_running -= 1

    def worker():
        nonlocal n_running, n_waiting
        mw = Mono

# Generated at 2022-06-18 11:39:38.140272
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from tqdm.contrib.concurrent import MonoWorker

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    assert len(mw.futures) == 0
    f1 = mw.submit(f, 1)
    assert isinstance(f1, Future)
    assert len(mw.futures) == 1
    f2 = mw.submit(f, 2)
    assert isinstance(f2, Future)
    assert len(mw.futures) == 1
    f3 = mw.submit(f, 3)
    assert isinstance(f3, Future)
    assert len(mw.futures) == 1
    assert f1.done()

# Generated at 2022-06-18 11:39:42.179369
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
    time.sleep(0.5)
    assert len(mw.futures) == 1
    assert mw.futures[0].result() == 9

# Generated at 2022-06-18 11:39:52.438995
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from threading import Event
    from unittest import TestCase
    from unittest.mock import Mock

    class TestMonoWorker(TestCase):
        def setUp(self):
            self.mw = MonoWorker()
            self.mock_func = Mock(side_effect=lambda x: time.sleep(x))
            self.mock_func.__name__ = 'mock_func'

        def test_submit(self):
            """
            Test that the most recent submitted task is the only one running.
            """
            self.assertEqual(len(self.mw.futures), 0)
            self.mw.submit(self.mock_func, 0.1)

# Generated at 2022-06-18 11:40:03.370634
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event

    def wait(duration, event):
        event.wait(duration)
        return duration

    def wait_and_cancel(duration, event):
        event.wait(duration)
        return duration

    def wait_and_fail(duration, event):
        event.wait(duration)
        raise Exception("fail")

    def wait_and_cancel_and_fail(duration, event):
        event.wait(duration)
        raise Exception("fail")

    def wait_and_cancel_and_fail_and_cancel(duration, event):
        event.wait(duration)
        raise Exception("fail")

    def wait_and_cancel_and_fail_and_cancel_and_fail(duration, event):
        event.wait(duration)
        raise Exception("fail")



# Generated at 2022-06-18 11:40:08.122898
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
    for i in _range(10):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:40:26.305675
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Lock
    from concurrent.futures import as_completed
    from tqdm.contrib.concurrency import MonoWorker

    def func(x):
        sleep(random())
        return x

    mw = MonoWorker()
    lock = Lock()
    results = []
    with tqdm_auto.tqdm(total=10, desc='test_MonoWorker_submit') as t:
        for i in range(10):
            mw.submit(func, i)
            for future in as_completed(mw.futures):
                with lock:
                    results.append(future.result())
                    t.update()
    assert results == list(range(10))

# Generated at 2022-06-18 11:40:33.741316
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
    time.sleep(0.1)
    assert mw.futures[0].done()
    assert not mw.futures[1].done()
    time.sleep(0.1)
    assert mw.futures[1].done()
    assert mw.futures[0].result() == 9
    assert mw.futures[1].result() == 8

# Generated at 2022-06-18 11:40:37.541206
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Thread
    from concurrent.futures import as_completed

    def func(x):
        sleep(random())
        return x

    mw = MonoWorker()
    futures = []
    for i in range(10):
        futures.append(mw.submit(func, i))
    for f in as_completed(futures):
        assert f.result() == 9

# Generated at 2022-06-18 11:40:43.925718
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import TimeoutError

    def wait(secs, result=None):
        time.sleep(secs)
        return result

    def wait_and_raise(secs, exc):
        time.sleep(secs)
        raise exc

    def wait_and_cancel(secs, event):
        event.wait()
        time.sleep(secs)

    def wait_and_cancel_and_raise(secs, event, exc):
        event.wait()
        time.sleep(secs)
        raise exc

    def test_wait(secs, result=None):
        start = time.time()
        assert wait(secs, result) == result
        assert time.time() - start >= secs


# Generated at 2022-06-18 11:40:51.075927
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up

    def f(x):
        time.sleep(1)
        return x

    mw = MonoWorker()
    mw.submit(f, 1)
    mw.submit(f, 2)
    mw.submit(f, 3)
    mw.submit(f, 4)
    mw.submit(f, 5)
    mw.submit(f, 6)
    mw.submit(f, 7)
    mw.submit(f, 8)
    mw.submit(f, 9)
    mw.submit(f, 10)
    mw.submit(f, 11)
    mw.submit(f, 12)
    mw.submit(f, 13)
    mw.submit(f, 14)
   

# Generated at 2022-06-18 11:40:53.640030
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def slow_square(x):
        time.sleep(0.1)
        return x ** 2

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(slow_square, i)
        time.sleep(0.01)
    time.sleep(0.5)

# Generated at 2022-06-18 11:40:55.768944
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)

# Generated at 2022-06-18 11:40:59.895353
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event

    def func(i, e):
        e.wait()
        return i

    e = Event()
    mw = MonoWorker()
    for i in range(5):
        mw.submit(func, i, e)
    assert len(mw.futures) == 1
    e.set()
    assert mw.futures[0].result() == 4

# Generated at 2022-06-18 11:41:08.153535
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def test_submit(self):
            def f(x):
                time.sleep(0.1)
                return x

            def g(x):
                time.sleep(0.1)
                return x

            def h(x):
                time.sleep(0.1)
                return x

            def i(x):
                time.sleep(0.1)
                return x

            def j(x):
                time.sleep(0.1)
                return x

            def k(x):
                time.sleep(0.1)
                return x

            def l(x):
                time.sleep(0.1)
                return x

           

# Generated at 2022-06-18 11:41:15.766336
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Lock
    from multiprocessing import cpu_count
    from concurrent.futures import as_completed
    from tqdm.contrib.concurrency import MonoWorker

    def f(x):
        sleep(random())
        return x

    def g(x):
        sleep(random())
        raise Exception(x)

    def h(x):
        sleep(random())
        raise KeyboardInterrupt(x)

    def i(x):
        sleep(random())
        raise SystemExit(x)

    def j(x):
        sleep(random())
        raise StopIteration(x)

    def k(x):
        sleep(random())
        raise GeneratorExit(x)

    def l(x):
        sleep(random())
        raise MemoryError

# Generated at 2022-06-18 11:41:35.742049
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def slow_square(x):
        time.sleep(0.1)
        return x ** 2

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(slow_square, i)
        time.sleep(0.01)
    assert mw.futures[0].result() == 81

# Generated at 2022-06-18 11:41:45.356097
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def setUp(self):
            self.mw = MonoWorker()
            self.futures = []

        def tearDown(self):
            for future in self.futures:
                if not future.done():
                    future.cancel()

        def test_submit(self):
            def func(x):
                sleep(x)
                return x

            for i in range(10):
                self.futures.append(self.mw.submit(func, i))
                sleep(0.1)

            for i, future in enumerate(self.futures):
                self.assertEqual(future.result(), i)

# Generated at 2022-06-18 11:41:53.848937
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    assert mw.submit(f, 0.1)
    assert mw.submit(f, 0.2)
    assert mw.submit(f, 0.3)
    assert mw.submit(f, 0.4)
    assert mw.submit(f, 0.5)
    assert mw.submit(f, 0.6)
    assert mw.submit(f, 0.7)
    assert mw.submit(f, 0.8)
    assert mw.submit(f, 0.9)
    assert mw.submit(f, 1.0)
    assert mw.submit(f, 1.1)
   

# Generated at 2022-06-18 11:42:04.456879
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    assert mw.submit(func, 1)
    assert mw.submit(func, 2)
    assert mw.submit(func, 3)
    assert mw.submit(func, 4)
    assert mw.submit(func, 5)
    assert mw.submit(func, 6)
    assert mw.submit(func, 7)
    assert mw.submit(func, 8)
    assert mw.submit(func, 9)
    assert mw.submit(func, 10)
    assert mw.submit(func, 11)
    assert mw.submit(func, 12)
    assert mw.submit(func, 13)
    assert mw.submit(func, 14)

# Generated at 2022-06-18 11:42:10.643125
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def _test(n, sleep_time):
        """
        Sleeps for `sleep_time` seconds, then returns `n`.
        """
        time.sleep(sleep_time)
        return n

    worker = MonoWorker()
    for i in _range(10):
        worker.submit(_test, i, i / 10)
    for i in _range(10):
        assert worker.futures[0].result() == i

# Generated at 2022-06-18 11:42:15.911313
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(5):
        mw.submit(f, i)
        time.sleep(0.1)
    assert mw.futures[0].result() == 4
    assert len(mw.futures) == 1

# Generated at 2022-06-18 11:42:23.265647
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    from threading import Lock
    from concurrent.futures import ThreadPoolExecutor

    def f(x):
        time.sleep(random.random())
        return x

    def g(x):
        time.sleep(random.random())
        raise Exception("g(%s)" % x)

    def h(x):
        time.sleep(random.random())
        raise Exception("h(%s)" % x)

    def i(x):
        time.sleep(random.random())
        raise Exception("i(%s)" % x)

    def j(x):
        time.sleep(random.random())
        raise Exception("j(%s)" % x)

    def k(x):
        time.sleep(random.random())
        raise Exception("k(%s)" % x)



# Generated at 2022-06-18 11:42:32.753061
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading

    def f(x):
        time.sleep(1)
        return x

    mw = MonoWorker()
    mw.submit(f, 1)
    mw.submit(f, 2)
    mw.submit(f, 3)
    mw.submit(f, 4)
    mw.submit(f, 5)
    mw.submit(f, 6)
    mw.submit(f, 7)
    mw.submit(f, 8)
    mw.submit(f, 9)
    mw.submit(f, 10)
    mw.submit(f, 11)
    mw.submit(f, 12)
    mw.submit(f, 13)
    mw.submit(f, 14)

# Generated at 2022-06-18 11:42:36.961049
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
    for i in _range(10):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:42:45.012708
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase

    class _Test(TestCase):
        def test_submit(self):
            def _func(i):
                sleep(0.1)
                return i

            def _func_exception(i):
                raise Exception("Exception")

            def _func_cancel(i):
                while not e.is_set():
                    sleep(0.1)
                return i

            e = Event()
            mw = MonoWorker()
            for i in range(10):
                f = mw.submit(_func, i)
                self.assertTrue(isinstance(f, Future))
                self.assertEqual(f.result(), i)
            for i in range(10):
                f = m

# Generated at 2022-06-18 11:43:33.793795
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up

    def func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in range(5):
        mw.submit(func, i)
        time.sleep(0.05)
        print('\r', end='')
        _term_move_up()
    print('\r', end='')
    _term_move_up()
    print('\r', end='')
    _term_move_up()
    print('\r', end='')
    _term_move_up()
    print('\r', end='')
    _term_move_up()
    print('\r', end='')
    _term_move_up()

# Generated at 2022-06-18 11:43:41.242722
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import as_completed
    from ..utils import FormatCustomText

    def func(x, y, z, sleep_time=0.1):
        sleep(sleep_time)
        return x + y + z

    def test_func(x, y, z, sleep_time=0.1):
        sleep(sleep_time)
        return x + y + z

    def test_func_2(x, y, z, sleep_time=0.1):
        sleep(sleep_time)
        return x + y + z

    def test_func_3(x, y, z, sleep_time=0.1):
        sleep(sleep_time)
        return x + y + z


# Generated at 2022-06-18 11:43:44.911611
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(5):
        mw.submit(f, i)
        time.sleep(0.1)

    assert mw.futures[0].result() == 4

# Generated at 2022-06-18 11:43:53.119901
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from queue import Queue
    from concurrent.futures import Future

    def func(x, y):
        sleep(x)
        return x + y

    def func_raise(x, y):
        sleep(x)
        raise Exception('test')

    def func_cancel(x, y):
        sleep(x)
        return x + y

    def func_cancel_raise(x, y):
        sleep(x)
        raise Exception('test')

    def func_cancel_raise_cancel(x, y):
        sleep(x)
        raise Exception('test')

    def func_cancel_raise_cancel_raise(x, y):
        sleep(x)
        raise Exception('test')


# Generated at 2022-06-18 11:44:00.717322
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    from concurrent.futures import as_completed

    def func(x):
        time.sleep(random.random() * 0.1)
        return x

    mw = MonoWorker()
    futures = [mw.submit(func, i) for i in range(10)]
    for f in as_completed(futures):
        assert f.result() == futures.index(f)

    # Test that waiting task is replaced
    mw = MonoWorker()
    futures = [mw.submit(func, i) for i in range(10)]
    time.sleep(0.2)
    for f in as_completed(futures):
        assert f.result() == futures.index(f)

    # Test that running task is not replaced
    m

# Generated at 2022-06-18 11:44:09.270638
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading

    def f(x):
        time.sleep(random.random())
        return x

    mw = MonoWorker()
    for i in range(10):
        mw.submit(f, i)
    time.sleep(0.1)
    assert len(mw.futures) == 1
    time.sleep(0.5)
    assert len(mw.futures) == 0

    mw = MonoWorker()
    for i in range(10):
        mw.submit(f, i)
    time.sleep(0.1)
    assert len(mw.futures) == 1
    time.sleep(0.5)
    assert len(mw.futures) == 0

    mw = MonoWorker()

# Generated at 2022-06-18 11:44:17.658438
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from ..utils import _range

    def _test_submit(mw, func, args, kwargs, expected_result,
                     expected_cancelled, expected_running, expected_waiting):
        # submit
        future = mw.submit(func, *args, **kwargs)
        assert isinstance(future, Future)
        assert future.running() == expected_running
        assert future.cancelled() == expected_cancelled
        assert future.done() == expected_cancelled
        assert future.result() == expected_result
        assert future.exception() is None
        # check queue
        assert len(mw.futures) == expected_waiting
        if expected_waiting:
            assert mw.futures

# Generated at 2022-06-18 11:44:25.014031
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import string

    def random_string(length=10):
        return ''.join(random.choice(string.ascii_letters) for _ in range(length))

    def random_sleep(length=1):
        time.sleep(random.random() * length)

    def random_task():
        random_sleep()
        return random_string()

    def test_task(task, expected):
        assert task.result() == expected

    def test_task_cancel(task):
        assert task.cancelled()

    def test_task_exception(task):
        assert task.exception() is not None

    def test_task_timeout(task):
        assert task.exception() is not None

    def test_task_timeout_cancel(task):
        assert task.exception

# Generated at 2022-06-18 11:44:29.932337
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up

    def _test_func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in range(5):
        mw.submit(_test_func, i)
        time.sleep(0.05)
        tqdm_auto.write('\n' + str(i))
        _term_move_up()

# Generated at 2022-06-18 11:44:38.590386
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import as_completed

    def wait_and_return(seconds, return_value):
        time.sleep(seconds)
        return return_value

    def wait_and_raise(seconds, exception):
        time.sleep(seconds)
        raise exception

    def wait_and_cancel(seconds, event):
        event.wait()
        time.sleep(seconds)

    def wait_and_cancel_with_return(seconds, event):
        event.wait()
        time.sleep(seconds)
        return 'cancelled'

    def wait_and_cancel_with_raise(seconds, event):
        event.wait()
        time.sleep(seconds)
        raise Exception('cancelled')


# Generated at 2022-06-18 11:46:18.482624
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Thread
    from concurrent.futures import as_completed

    def func(x):
        sleep(random())
        return x

    mw = MonoWorker()
    futures = [mw.submit(func, i) for i in range(10)]
    for f in as_completed(futures):
        assert f.result() == futures.index(f)

    # Test that only one task is running at a time
    mw = MonoWorker()
    futures = [mw.submit(func, i) for i in range(10)]
    for f in as_completed(futures):
        assert f.result() == futures.index(f)

    # Test that only one task is running at a time
    mw = MonoWorker()

# Generated at 2022-06-18 11:46:22.666329
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def sleep(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(sleep, i)
    for i in _range(10):
        assert mw.futures[0].result() == i