

# Generated at 2022-06-18 11:36:30.492230
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from ..utils import _term_move_up

    def func(i, e):
        time.sleep(0.1)
        e.set()
        return i

    e = Event()
    mw = MonoWorker()
    for i in range(5):
        e.clear()
        f = mw.submit(func, i, e)
        tqdm_auto.write('{}'.format(i))
        e.wait()
        tqdm_auto.write('{}'.format(f.result()))
        _term_move_up()

# Generated at 2022-06-18 11:36:33.792399
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
    assert mw.futures[0].result() == 9
    assert mw.futures[1].result() == 8

# Generated at 2022-06-18 11:36:44.084504
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from ..utils import _range

    def wait_for_event(event, timeout=None):
        """Wait for event to be set or timeout"""
        event.wait(timeout)
        return event.is_set()

    def wait_for_event_with_timeout(event, timeout=None):
        """Wait for event to be set or timeout"""
        event.wait(timeout)
        return event.is_set()

    def wait_for_event_with_timeout_and_exception(event, timeout=None):
        """Wait for event to be set or timeout"""
        event.wait(timeout)
        if not event.is_set():
            raise RuntimeError("Timeout")
        return event.is_set()


# Generated at 2022-06-18 11:36:53.558407
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    import unittest

    def _test_func(x):
        time.sleep(random.random() / 10)
        return x

    class TestMonoWorker(unittest.TestCase):
        def test_submit(self):
            mw = MonoWorker()
            for i in range(10):
                mw.submit(_test_func, i)
            time.sleep(0.5)
            self.assertEqual(mw.futures[0].result(), 9)

    unittest.main(argv=['first-arg-is-ignored'], exit=False)
    time.sleep(0.5)
    print('\n')

# Generated at 2022-06-18 11:37:05.266388
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase, main

    class Test(TestCase):
        def test_submit(self):
            def func(a, b):
                time.sleep(1)
                return a + b

            mw = MonoWorker()
            f1 = mw.submit(func, 1, 2)
            f2 = mw.submit(func, 3, 4)
            f3 = mw.submit(func, 5, 6)
            self.assertEqual(f1.result(), 3)
            self.assertEqual(f2.result(), 7)
            self.assertEqual(f3.result(), 11)

        def test_submit_cancel(self):
            def func(a, b):
                time.sleep

# Generated at 2022-06-18 11:37:14.837271
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future

    def func(x, y, z):
        time.sleep(x)
        return x + y + z

    def test_submit(x, y, z):
        """
        Test the submit method of MonoWorker.
        """
        mw = MonoWorker()
        f1 = mw.submit(func, x, y, z)
        f2 = mw.submit(func, x, y, z)
        f3 = mw.submit(func, x, y, z)
        assert f1 is f2
        assert f2 is f3
        assert f1 is not None
        assert f1.done() is False
        assert f1.result() == x + y + z
        assert f1.done() is True


# Generated at 2022-06-18 11:37:25.119187
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from ..utils import _range

    def _test_submit(mw, func, *args, **kwargs):
        """
        :param mw: MonoWorker instance
        :param func: function to submit
        :param args: positional arguments for `func`
        :param kwargs: keyword arguments for `func`
        :return: `func`'s return value
        """
        future = mw.submit(func, *args, **kwargs)
        assert isinstance(future, Future)
        assert not future.done()
        assert future.result() == func(*args, **kwargs)
        assert future.done()


# Generated at 2022-06-18 11:37:29.957825
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(3):
        mw.submit(func, i)
        time.sleep(0.1)
    assert mw.futures[0].result() == 2

# Generated at 2022-06-18 11:37:38.535924
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up

    def _test_func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    mw.submit(_test_func, 1)
    mw.submit(_test_func, 2)
    mw.submit(_test_func, 3)
    mw.submit(_test_func, 4)
    mw.submit(_test_func, 5)
    mw.submit(_test_func, 6)
    mw.submit(_test_func, 7)
    mw.submit(_test_func, 8)
    mw.submit(_test_func, 9)
    mw.submit(_test_func, 10)
    mw.submit(_test_func, 11)

# Generated at 2022-06-18 11:37:48.466220
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import TimeoutError
    from ..utils import _range

    def wait(seconds):
        time.sleep(seconds)
        return seconds

    def wait_and_raise(seconds):
        time.sleep(seconds)
        raise RuntimeError(seconds)

    def wait_and_cancel(seconds):
        time.sleep(seconds)
        raise TimeoutError()

    def wait_and_cancel_and_raise(seconds):
        time.sleep(seconds)
        raise TimeoutError()
        raise RuntimeError(seconds)

    def wait_and_raise_and_cancel(seconds):
        time.sleep(seconds)
        raise RuntimeError(seconds)
        raise TimeoutError()


# Generated at 2022-06-18 11:38:00.557647
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import as_completed

    def wait_for_event(event, timeout=None):
        event.wait(timeout)
        return event.is_set()

    def wait_for_event_with_timeout(event, timeout=None):
        return wait_for_event(event, timeout)

    def wait_for_event_without_timeout(event, timeout=None):
        return wait_for_event(event)

    def wait_for_event_with_timeout_and_args(event, timeout=None, *args, **kwargs):
        return wait_for_event(event, timeout)

    def wait_for_event_without_timeout_and_args(event, timeout=None, *args, **kwargs):
        return wait_for_

# Generated at 2022-06-18 11:38:07.628761
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event

    def wait_and_return(wait_time, return_value):
        time.sleep(wait_time)
        return return_value

    worker = MonoWorker()
    wait_time = 0.1
    return_value = 'test'
    future = worker.submit(wait_and_return, wait_time, return_value)
    assert future.result() == return_value

    # Test that the second task replaces the first
    wait_time = 0.2
    return_value = 'test2'
    future = worker.submit(wait_and_return, wait_time, return_value)
    assert future.result() == return_value

    # Test that the third task is discarded
    wait_time = 0.3
    return_value = 'test3'
    future = worker

# Generated at 2022-06-18 11:38:17.155443
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Thread
    from concurrent.futures import as_completed

    def func(x):
        sleep(random())
        return x

    mw = MonoWorker()
    futures = [mw.submit(func, i) for i in range(10)]
    for f in as_completed(futures):
        assert f.result() == futures.index(f)

    # Test that waiting task is replaced
    mw = MonoWorker()
    futures = [mw.submit(func, i) for i in range(10)]
    for f in as_completed(futures):
        assert f.result() == futures.index(f)

    # Test that running task is not replaced
    mw = MonoWorker()

# Generated at 2022-06-18 11:38:27.206844
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Event
    from concurrent.futures import as_completed

    def func(x, y, z, sleep_time=0.1):
        sleep(sleep_time)
        return x + y + z

    # Test 1
    mw = MonoWorker()
    f1 = mw.submit(func, 1, 2, 3)
    f2 = mw.submit(func, 4, 5, 6)
    f3 = mw.submit(func, 7, 8, 9)
    assert f1.done()
    assert f2.done()
    assert not f3.done()
    assert f3.result() == 7 + 8 + 9

    # Test 2
    mw = MonoWorker()

# Generated at 2022-06-18 11:38:37.771420
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import TimeoutError

    def wait_for_event(event, timeout):
        """Wait for event to be set or timeout"""
        if not event.wait(timeout):
            raise TimeoutError

    def wait_for_event_and_return(event, timeout, return_value):
        """Wait for event to be set or timeout"""
        wait_for_event(event, timeout)
        return return_value

    def test_submit(timeout=0.5):
        """Test submit method of class MonoWorker"""
        event = Event()
        worker = MonoWorker()
        future = worker.submit(wait_for_event, event, timeout)
        assert future.running()
        assert not future.done()
        assert not future.cancelled()

# Generated at 2022-06-18 11:38:40.887842
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
        time.sleep(0.05)

# Generated at 2022-06-18 11:38:44.172469
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def test_func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(test_func, i)
        time.sleep(0.05)

    for i in _range(10):
        mw.submit(test_func, i)
        time.sleep(0.05)

# Generated at 2022-06-18 11:38:55.635784
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import TimeoutError

    def wait_for_event(event, timeout):
        event.wait(timeout)
        return event.is_set()

    def wait_for_event_with_timeout(event, timeout):
        try:
            return wait_for_event(event, timeout)
        except TimeoutError:
            return False

    def wait_for_event_with_timeout_and_cancel(event, timeout):
        try:
            return wait_for_event(event, timeout)
        except TimeoutError:
            return False
        finally:
            event.set()


# Generated at 2022-06-18 11:39:04.423614
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import CancelledError

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    assert mw.futures == deque([], 2)
    assert mw.submit(f, 1)
    assert mw.futures == deque([mw.futures[0]], 2)
    assert mw.submit(f, 2)
    assert mw.futures == deque([mw.futures[0], mw.futures[1]], 2)
    assert mw.submit(f, 3)
    assert mw.futures == deque([mw.futures[1]], 2)
    assert mw.futures[0].result() == 2
    assert m

# Generated at 2022-06-18 11:39:12.107141
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import TimeoutError

    def func(x):
        sleep(x)
        return x

    def test_submit(x, y, z):
        mw = MonoWorker()
        f1 = mw.submit(func, x)
        f2 = mw.submit(func, y)
        f3 = mw.submit(func, z)
        assert f1.done()
        assert f2.done()
        assert not f3.done()
        assert f1.result() == x
        assert f2.result() == z
        assert f3.result() == z

    test_submit(1, 2, 3)
    test_submit(1, 3, 2)
    test_submit(2, 1, 3)
    test

# Generated at 2022-06-18 11:39:24.436880
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from ..utils import _range

    def _test_MonoWorker_submit_helper(
            n_tasks=3, n_runs=3, n_sleeps=3, n_cancels=2):
        """
        n_tasks: number of tasks to submit
        n_runs: number of times to submit tasks
        n_sleeps: number of sleeps per task
        n_cancels: number of tasks to cancel
        """
        worker = MonoWorker()
        results = []

# Generated at 2022-06-18 11:39:33.726458
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from multiprocessing import Process, Queue
    from threading import Thread
    from ..utils import _range

    def _test_MonoWorker_submit(q):
        def _submit(i):
            time.sleep(0.1)
            q.put(i)
        mw = MonoWorker()
        for i in _range(10):
            mw.submit(_submit, i)
        time.sleep(0.5)
        assert q.qsize() == 1
        mw.submit(_submit, 10)
        time.sleep(0.5)
        assert q.qsize() == 2
        mw.submit(_submit, 11)
        time.sleep(0.5)
        assert q.qsize() == 3
        mw.submit(_submit, 12)
        time.sleep

# Generated at 2022-06-18 11:39:39.248799
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Lock

    def func(x):
        sleep(random())
        return x

    mw = MonoWorker()
    lock = Lock()
    for i in range(10):
        with lock:
            mw.submit(func, i)
            sleep(random())
            print(i)
        sleep(random())
    sleep(0.1)
    assert len(mw.futures) == 1
    assert mw.futures[0].result() == 9

# Generated at 2022-06-18 11:39:42.110258
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)

# Generated at 2022-06-18 11:39:44.906774
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.05)

# Generated at 2022-06-18 11:39:56.657538
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from concurrent.futures import as_completed
    from tqdm.contrib.concurrency import MonoWorker

    lock = Lock()
    mw = MonoWorker()

    def f(x):
        sleep(x)
        with lock:
            tqdm_auto.write("f({})".format(x))
        return x

    def g(x):
        sleep(x)
        with lock:
            tqdm_auto.write("g({})".format(x))
        return x

    futures = [mw.submit(f, x) for x in [1, 2, 3, 4]]
    for future in as_completed(futures):
        assert future.result() == 4


# Generated at 2022-06-18 11:40:06.547005
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from concurrent.futures import as_completed
    from tqdm.contrib.concurrent import MonoWorker

    def f(x):
        sleep(x)
        return x

    mw = MonoWorker()
    mw.submit(f, 1)
    mw.submit(f, 2)
    mw.submit(f, 3)
    mw.submit(f, 4)
    mw.submit(f, 5)
    mw.submit(f, 6)
    mw.submit(f, 7)
    mw.submit(f, 8)
    mw.submit(f, 9)
    mw.submit(f, 10)
    mw.submit(f, 11)
    mw.submit(f, 12)

# Generated at 2022-06-18 11:40:14.408930
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Lock
    from concurrent.futures import as_completed
    from tqdm.contrib.concurrency import MonoWorker

    def f(x):
        sleep(random())
        return x

    def g(x):
        sleep(random())
        raise ValueError(x)

    def h(x):
        sleep(random())
        raise Exception(x)

    def i(x):
        sleep(random())
        raise KeyboardInterrupt(x)

    def j(x):
        sleep(random())
        raise SystemExit(x)

    def k(x):
        sleep(random())
        raise StopIteration(x)

    def l(x):
        sleep(random())
        raise GeneratorExit(x)


# Generated at 2022-06-18 11:40:24.853523
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from multiprocessing import Process
    from threading import Thread

    def test_func(x):
        time.sleep(x)
        return x

    def test_func_exception(x):
        time.sleep(x)
        raise Exception("test exception")

    def test_func_cancel(x):
        time.sleep(x)
        return x

    def test_func_cancel_exception(x):
        time.sleep(x)
        raise Exception("test exception")

    def test_func_cancel_exception_2(x):
        time.sleep(x)
        raise Exception("test exception")

    def test_func_cancel_exception_3(x):
        time.sleep(x)
        raise Exception("test exception")


# Generated at 2022-06-18 11:40:34.184585
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from ..utils import _range

    def _test_submit(mw, n, sleep, cancel):
        """
        :param mw: MonoWorker instance
        :param n: number of tasks to submit
        :param sleep: time to sleep between tasks
        :param cancel: cancel last task
        """
        futures = []
        for i in _range(n):
            futures.append(mw.submit(time.sleep, sleep))
            time.sleep(sleep)
        if cancel:
            futures[-1].cancel()
        for f in futures:
            f.result()


# Generated at 2022-06-18 11:40:50.609329
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase

    class Test(TestCase):
        def setUp(self):
            self.worker = MonoWorker()
            self.event = Event()
            self.event.clear()

        def tearDown(self):
            self.worker.pool.shutdown(wait=True)

        def test_submit(self):
            def func(event):
                event.wait()
                return 'done'

            future = self.worker.submit(func, self.event)
            self.assertIsInstance(future, Future)
            self.assertFalse(future.done())
            self.event.set()
            self.assertEqual(future.result(), 'done')


# Generated at 2022-06-18 11:40:56.318393
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Thread
    from queue import Queue
    from concurrent.futures import as_completed

    def _test_submit(q, mw, func, *args, **kwargs):
        q.put(mw.submit(func, *args, **kwargs))

    def _test_submit_wait(q, mw, func, *args, **kwargs):
        q.put(mw.submit(func, *args, **kwargs).result())

    def _test_submit_wait_timeout(q, mw, func, *args, **kwargs):
        q.put(mw.submit(func, *args, **kwargs).result(timeout=0.1))


# Generated at 2022-06-18 11:41:04.453082
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from ..utils import _range

    def _test_submit(mw, n_tasks, n_workers, n_tasks_per_worker,
                     n_tasks_per_worker_max, n_tasks_per_worker_min):
        """Test `MonoWorker.submit`."""
        # pylint: disable=too-many-arguments
        # pylint: disable=too-many-locals
        # pylint: disable=too-many-statements
        # pylint: disable=too-many-branches
        # pylint: disable=too-many-nested-blocks
        # pylint: disable=too-many-boolean-expressions
        # pylint: disable=

# Generated at 2022-06-18 11:41:12.309126
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from threading import Event

    def _test_submit(mw, func, *args, **kwargs):
        """
        Test `mw.submit(func, *args, **kwargs)`
        """
        mw.submit(func, *args, **kwargs)
        assert len(mw.futures) == 1
        assert isinstance(mw.futures[0], Future)
        assert not mw.futures[0].done()
        assert not mw.futures[0].cancelled()

    def _test_submit_cancel(mw, func, *args, **kwargs):
        """
        Test `mw.submit(func, *args, **kwargs)`
        """

# Generated at 2022-06-18 11:41:19.038697
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import Future

    def func(x):
        sleep(x)
        return x

    def test(x):
        mw = MonoWorker()
        f1 = mw.submit(func, x)
        f2 = mw.submit(func, x)
        assert isinstance(f1, Future)
        assert isinstance(f2, Future)
        assert f1 is f2
        assert f1.done()
        assert f2.done()
        assert f1.result() == x
        assert f2.result() == x

    test(0.1)
    test(0.2)
    test(0.3)
    test(0.4)
    test(0.5)
    test(0.6)
   

# Generated at 2022-06-18 11:41:28.291904
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range
    from ..auto import trange

    def wait(t):
        time.sleep(t)
        return t

    def wait_and_print(t):
        time.sleep(t)
        tqdm_auto.write('{}'.format(t))
        return t

    def wait_and_print_exc(t):
        time.sleep(t)
        tqdm_auto.write('{}'.format(t))
        raise Exception('{}'.format(t))

    def wait_and_print_cancel(t):
        time.sleep(t)
        tqdm_auto.write('{}'.format(t))
        return t

    def wait_and_print_cancel_exc(t):
        time.sleep(t)
        tq

# Generated at 2022-06-18 11:41:34.027784
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from concurrent.futures import Future
    from contextlib import contextmanager

    @contextmanager
    def lock_context(lock):
        lock.acquire()
        try:
            yield
        finally:
            lock.release()

    def test_func(x, y, lock):
        with lock_context(lock):
            sleep(x)
            return x + y

    lock = Lock()
    mw = MonoWorker()
    f1 = mw.submit(test_func, 1, 1, lock)
    f2 = mw.submit(test_func, 2, 2, lock)
    f3 = mw.submit(test_func, 3, 3, lock)
    assert isinstance(f1, Future)
    assert isinstance(f2, Future)

# Generated at 2022-06-18 11:41:43.390433
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import as_completed

    def test_func(x, y, z, evt):
        evt.wait()
        return x + y + z

    evt = Event()
    mw = MonoWorker()
    f1 = mw.submit(test_func, 1, 2, 3, evt)
    f2 = mw.submit(test_func, 4, 5, 6, evt)
    f3 = mw.submit(test_func, 7, 8, 9, evt)
    f4 = mw.submit(test_func, 10, 11, 12, evt)
    f5 = mw.submit(test_func, 13, 14, 15, evt)

# Generated at 2022-06-18 11:41:47.260015
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
    assert mw.futures[0].result() == 9
    assert mw.futures[1].result() == 8

# Generated at 2022-06-18 11:41:51.640055
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i / 10)
    for i in _range(10):
        assert mw.futures[i].result() == i / 10

# Generated at 2022-06-18 11:42:14.419042
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from tqdm.contrib.concurrency import MonoWorker

    def wait_for_event(event, timeout=1):
        """Wait for event to be set or timeout"""
        event.wait(timeout)
        return event.is_set()

    def wait_for_future(future, timeout=1):
        """Wait for future to be done or timeout"""
        start = time.time()
        while not future.done():
            if time.time() - start > timeout:
                break
        return future.done()

    def wait_for_future_result(future, timeout=1):
        """Wait for future to be done or timeout"""
        start = time.time()

# Generated at 2022-06-18 11:42:22.375247
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)

# Generated at 2022-06-18 11:42:29.068293
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from . import tqdm_test_cases

    def f(x):
        time.sleep(x)
        return x

    def test_case(n, desc=None):
        mw = MonoWorker()
        t = tqdm_auto.tqdm(total=n, desc=desc)
        for i in range(n):
            mw.submit(f, 0.1)
            t.update()
        t.close()

    for desc, n in tqdm_test_cases.items():
        test_case(n, desc)

# Generated at 2022-06-18 11:42:38.568464
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up

    def wait(n):
        time.sleep(n)
        return n

    mw = MonoWorker()
    mw.submit(wait, 1)
    mw.submit(wait, 2)
    mw.submit(wait, 3)
    mw.submit(wait, 4)
    mw.submit(wait, 5)
    mw.submit(wait, 6)
    mw.submit(wait, 7)
    mw.submit(wait, 8)
    mw.submit(wait, 9)
    mw.submit(wait, 10)
    mw.submit(wait, 11)
    mw.submit(wait, 12)
    mw.submit(wait, 13)
    mw.submit(wait, 14)
   

# Generated at 2022-06-18 11:42:42.888213
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(5):
        mw.submit(f, i)
    time.sleep(0.1)
    assert len(mw.futures) == 1
    assert mw.futures[0].result() == 4

# Generated at 2022-06-18 11:42:50.437934
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import TimeoutError

    def wait(t, e):
        e.wait(t)
        return t

    e = Event()
    mw = MonoWorker()
    f1 = mw.submit(wait, 1, e)
    f2 = mw.submit(wait, 2, e)
    f3 = mw.submit(wait, 3, e)
    assert f1.done()
    assert f2.done()
    assert f3.done()
    assert f1.cancelled()
    assert f2.cancelled()
    assert not f3.cancelled()
    assert f3.result() == 3
    e.set()
    assert f3.result() == 3

# Generated at 2022-06-18 11:42:58.196352
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future

    def wait_for_event(event):
        event.wait()
        return True

    def wait_for_future(future):
        future.result()
        return True

    def wait_for_time(seconds):
        time.sleep(seconds)
        return True

    def wait_for_nothing():
        return True

    def wait_for_exception():
        raise Exception("test")

    def test_submit(func, *args, **kwargs):
        worker = MonoWorker()
        assert len(worker.futures) == 0
        future = worker.submit(func, *args, **kwargs)
        assert len(worker.futures) == 1
        assert future.result()

# Generated at 2022-06-18 11:43:04.123503
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from ..utils import _range

    def _test_func(x):
        time.sleep(0.1)
        return x

    def _test_func_err(x):
        time.sleep(0.1)
        raise Exception('test')

    def _test_func_cancel(x, ev):
        time.sleep(0.1)
        ev.wait()
        return x

    def _test_func_cancel_err(x, ev):
        time.sleep(0.1)
        ev.wait()
        raise Exception('test')

    def _test_func_cancel_err_2(x, ev):
        time.sleep(0.1)
        ev.wait()
        raise Exception('test')



# Generated at 2022-06-18 11:43:06.246351
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from .utils import _range

    def slow_square(x):
        time.sleep(0.1)
        return x ** 2

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(slow_square, i)
        time.sleep(0.05)

# Generated at 2022-06-18 11:43:08.744496
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
    for i in _range(10):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:44:00.505212
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from .utils import _range

    def _test_MonoWorker_submit(n_tasks, n_workers, sleep_time):
        mw = MonoWorker()
        with tqdm_auto.tqdm(total=n_tasks) as pbar:
            for i in _range(n_tasks):
                mw.submit(time.sleep, sleep_time)
                pbar.update()
                time.sleep(sleep_time / n_workers)

    _test_MonoWorker_submit(n_tasks=10, n_workers=1, sleep_time=0.1)
    _test_MonoWorker_submit(n_tasks=10, n_workers=2, sleep_time=0.1)

# Generated at 2022-06-18 11:44:08.216939
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from concurrent.futures import as_completed
    from itertools import count
    from random import random
    from sys import stdout

    def func(i):
        sleep(random())
        return i

    mw = MonoWorker()
    for i in count():
        mw.submit(func, i)
        if i % 10 == 0:
            stdout.write('\r')
            stdout.flush()
            stdout.write(str(i))
            stdout.flush()
        if i > 100:
            break
    stdout.write('\n')
    stdout.flush()

    for f in as_completed(mw.futures):
        print(f.result())

# Generated at 2022-06-18 11:44:16.886575
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import TimeoutError
    from ..utils import _range

    def wait(seconds):
        time.sleep(seconds)
        return seconds

    def wait_and_cancel(seconds, event):
        event.wait()
        return wait(seconds)

    def wait_and_raise(seconds):
        time.sleep(seconds)
        raise Exception("Raised after {} seconds".format(seconds))

    def wait_and_timeout(seconds, event):
        event.wait()
        return wait_and_raise(seconds)

    def test_submit(seconds, event=None):
        worker = MonoWorker()
        if event:
            future = worker.submit(wait_and_cancel, seconds, event)

# Generated at 2022-06-18 11:44:19.624815
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random

    def func(x):
        time.sleep(random.random())
        return x

    mw = MonoWorker()
    for i in range(10):
        mw.submit(func, i)
    assert mw.futures[0].result() == 9

# Generated at 2022-06-18 11:44:27.461652
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def slow_square(x):
        time.sleep(0.1)
        return x ** 2

    def slow_cube(x):
        time.sleep(0.1)
        return x ** 3

    def slow_quad(x):
        time.sleep(0.1)
        return x ** 4

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(slow_square, i)
    for i in _range(10):
        mw.submit(slow_cube, i)
    for i in _range(10):
        mw.submit(slow_quad, i)

    for i in _range(10):
        assert mw.futures[i].result() == i ** 4

# Generated at 2022-06-18 11:44:36.311186
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from threading import Event
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def test_submit(self):
            def func(x):
                time.sleep(x)
                return x

            def func_exception(x):
                raise Exception('test exception')

            mw = MonoWorker()
            self.assertIsInstance(mw.submit(func, 0.1), Future)
            self.assertIsInstance(mw.submit(func, 0.1), Future)
            self.assertIsInstance(mw.submit(func, 0.1), Future)
            self.assertIsInstance(mw.submit(func, 0.1), Future)

# Generated at 2022-06-18 11:44:43.316436
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase

    class Test(TestCase):
        def setUp(self):
            self.mw = MonoWorker()
            self.e = Event()

        def test_submit(self):
            def _submit(i):
                self.e.wait()
                return i

            for i in range(10):
                f = self.mw.submit(_submit, i)
                self.assertIsInstance(f, Future)
                self.assertEqual(f.result(), i)

        def test_submit_exception(self):
            def _submit(i):
                self.e.wait()
                raise Exception(i)


# Generated at 2022-06-18 11:44:52.099164
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future

    def wait(t, e):
        e.wait()
        return t

    def run(t, e, f):
        time.sleep(t)
        e.set()
        return f

    def test_wait_run(t, e, f):
        e = Event()
        f = Future()
        mw = MonoWorker()
        mw.submit(wait, t, e)
        mw.submit(run, t, e, f)
        assert f.result() == f

    def test_run_wait(t, e, f):
        e = Event()
        f = Future()
        mw = MonoWorker()
        mw.submit(run, t, e, f)

# Generated at 2022-06-18 11:45:00.180927
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from ..utils import _term_move_up

    def _test_func(i):
        time.sleep(0.1)
        return i

    def _test_func_exc(i):
        time.sleep(0.1)
        raise Exception("test exception")

    def _test_func_cancel(i):
        time.sleep(0.1)
        return i

    def _test_func_cancel_exc(i):
        time.sleep(0.1)
        raise Exception("test exception")

    def _test_func_cancel_exc_cancel(i):
        time.sleep(0.1)
        raise Exception("test exception")


# Generated at 2022-06-18 11:45:08.182406
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def test_submit(self):
            def func(x, y, z):
                time.sleep(z)
                return x + y

            def func_exception(x, y, z):
                time.sleep(z)
                raise Exception('test_MonoWorker_submit')

            def func_cancel(x, y, z):
                time.sleep(z)
                return x + y

            def func_cancel_exception(x, y, z):
                time.sleep(z)
                raise Exception('test_MonoWorker_submit')
