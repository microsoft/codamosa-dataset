

# Generated at 2022-06-18 11:36:32.503376
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up

    def func(i):
        time.sleep(1)
        return i

    mw = MonoWorker()
    for i in range(5):
        mw.submit(func, i)
        tqdm_auto.write("{}".format(i))
        _term_move_up()
    time.sleep(5)
    for i in range(5):
        mw.submit(func, i)
        tqdm_auto.write("{}".format(i))
        _term_move_up()
    time.sleep(5)
    for i in range(5):
        mw.submit(func, i)
        tqdm_auto.write("{}".format(i))
        _term_move_up()
   

# Generated at 2022-06-18 11:36:41.261477
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import TimeoutError

    def wait_for_event(event, timeout):
        """
        Wait for event to be set, or raise TimeoutError.
        """
        event.wait(timeout)
        if not event.is_set():
            raise TimeoutError("Event not set")

    def wait_for_event_and_return(event, timeout):
        """
        Wait for event to be set, or raise TimeoutError.
        """
        event.wait(timeout)
        if not event.is_set():
            raise TimeoutError("Event not set")
        return "Event set"


# Generated at 2022-06-18 11:36:52.465053
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from .utils import _test_cls_docstring

    def wait_for_event(event, timeout=None):
        """
        Wait for event to be set, or timeout.
        Returns True if event is set, False if timeout.
        """
        event.wait(timeout)
        return event.is_set()

    def wait_for_future(future, timeout=None):
        """
        Wait for future to be done, or timeout.
        Returns True if future is done, False if timeout.
        """
        return wait_for_event(future._condition, timeout)


# Generated at 2022-06-18 11:36:57.538766
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(5):
        mw.submit(func, i)
        time.sleep(0.1)
    time.sleep(0.5)
    assert mw.futures[0].result() == 4

# Generated at 2022-06-18 11:37:09.630795
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from concurrent.futures import as_completed
    from tqdm.contrib.concurrency import MonoWorker

    def func(x, sleep_time=0.1):
        sleep(sleep_time)
        return x

    mw = MonoWorker()
    lock = Lock()
    results = []

    def submit(x):
        with lock:
            results.append(mw.submit(func, x))

    submit(1)
    submit(2)
    submit(3)
    submit(4)
    submit(5)
    submit(6)
    submit(7)
    submit(8)
    submit(9)
    submit(10)


# Generated at 2022-06-18 11:37:17.472417
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Lock
    from concurrent.futures import as_completed

    def func(x, y, z, sleep_time=0.1):
        sleep(sleep_time)
        return x + y + z

    mw = MonoWorker()
    lock = Lock()
    results = []

    def submit_func(x, y, z, sleep_time=0.1):
        with lock:
            results.append(mw.submit(func, x, y, z, sleep_time=sleep_time))

    submit_func(1, 2, 3)
    submit_func(4, 5, 6)
    submit_func(7, 8, 9)
    submit_func(10, 11, 12)
    submit_func(13, 14, 15)

# Generated at 2022-06-18 11:37:23.513973
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)

    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)

# Generated at 2022-06-18 11:37:28.175062
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(1)
        return x

    mw = MonoWorker()
    for i in _range(3):
        mw.submit(f, i)
        time.sleep(0.5)
    assert mw.futures[0].result() == 2

# Generated at 2022-06-18 11:37:37.411566
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from ..utils import _range

    def _test_submit(n_tasks, n_workers, n_sleep, n_cancel, n_done, n_running):
        """
        n_tasks: number of tasks to submit
        n_workers: number of workers in the pool
        n_sleep: number of tasks to sleep
        n_cancel: number of tasks to cancel
        n_done: number of tasks to complete
        n_running: number of tasks to keep running
        """
        mw = MonoWorker()
        mw.pool = ThreadPoolExecutor(max_workers=n_workers)
        futures = []

# Generated at 2022-06-18 11:37:46.031210
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import format_sizeof

    def test_func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in range(10):
        mw.submit(test_func, i)
    for i in range(10):
        assert mw.futures[i].result() == 9 - i

    # Test with large data
    mw = MonoWorker()
    for i in range(10):
        mw.submit(test_func, format_sizeof(i))
    for i in range(10):
        assert mw.futures[i].result() == format_sizeof(9 - i)

# Generated at 2022-06-18 11:37:53.812625
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(5):
        mw.submit(func, i)
        time.sleep(0.05)
    for i in _range(5):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:38:02.955699
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from concurrent.futures import Future
    from unittest import TestCase

    class Test(TestCase):
        def setUp(self):
            self.lock = Lock()
            self.worker = MonoWorker()
            self.calls = []

        def func(self, *args, **kwargs):
            with self.lock:
                self.calls.append((args, kwargs))
            sleep(0.1)
            return args, kwargs

        def test_submit(self):
            self.assertEqual(len(self.calls), 0)
            self.worker.submit(self.func, 1, 2, 3, a=4, b=5)
            self.assertEqual(len(self.calls), 1)

# Generated at 2022-06-18 11:38:10.750690
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up

    def test_func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    mw.submit(test_func, 1)
    mw.submit(test_func, 2)
    mw.submit(test_func, 3)
    mw.submit(test_func, 4)
    mw.submit(test_func, 5)
    mw.submit(test_func, 6)
    mw.submit(test_func, 7)
    mw.submit(test_func, 8)
    mw.submit(test_func, 9)
    mw.submit(test_func, 10)
    mw.submit(test_func, 11)

# Generated at 2022-06-18 11:38:20.636729
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event

    def wait(t, e):
        time.sleep(t)
        e.set()

    e = Event()
    mw = MonoWorker()
    mw.submit(wait, 0.1, e)
    assert not e.is_set()
    mw.submit(wait, 0.2, e)
    assert not e.is_set()
    mw.submit(wait, 0.3, e)
    assert not e.is_set()
    mw.submit(wait, 0.4, e)
    assert not e.is_set()
    mw.submit(wait, 0.5, e)
    assert not e.is_set()
    mw.submit(wait, 0.6, e)
    assert not e.is_set()


# Generated at 2022-06-18 11:38:31.880689
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from ..utils import format_sizeof

    def test_func(x):
        time.sleep(x)
        return x

    def test_func_exception(x):
        time.sleep(x)
        raise Exception("test_func_exception")

    def test_func_cancel(x, e):
        time.sleep(x)
        e.wait()
        return x

    def test_func_cancel_exception(x, e):
        time.sleep(x)
        e.wait()
        raise Exception("test_func_cancel_exception")

    def test_func_cancel_exception_2(x, e):
        time.sleep(x)
        e.wait()

# Generated at 2022-06-18 11:38:40.529421
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event

    def wait(seconds):
        time.sleep(seconds)

    def wait_and_set(seconds, event):
        time.sleep(seconds)
        event.set()

    def wait_and_raise(seconds):
        time.sleep(seconds)
        raise Exception("Raised exception")

    def wait_and_return(seconds):
        time.sleep(seconds)
        return seconds

    def test_wait(seconds):
        mw = MonoWorker()
        mw.submit(wait, seconds)
        time.sleep(seconds / 2)
        mw.submit(wait, seconds)
        time.sleep(seconds / 2)
        mw.submit(wait, seconds)
        time.sleep(seconds / 2)
        mw.submit(wait, seconds)

# Generated at 2022-06-18 11:38:52.205046
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Thread
    from queue import Queue
    from concurrent.futures import Future
    from contextlib import contextmanager

    @contextmanager
    def _test_MonoWorker_submit(n_tasks, n_workers, n_threads,
                                n_submits, n_cancels, n_terminates):
        """
        :param n_tasks: number of tasks to be submitted
        :param n_workers: number of workers to be used
        :param n_threads: number of threads to be used
        :param n_submits: number of times to submit a task
        :param n_cancels: number of times to cancel a task
        :param n_terminates: number of times to terminate a task
        """
        # Create a MonoWorker

# Generated at 2022-06-18 11:38:57.315285
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
        time.sleep(0.01)
    assert mw.futures[0].result() == 9

# Generated at 2022-06-18 11:39:05.659700
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def test_submit(self):
            # Test that the most recent task is always running
            # and that the previous task is cancelled
            def task(i, e):
                e.wait()
                return i

            e = Event()
            e.set()
            mw = MonoWorker()
            f1 = mw.submit(task, 1, e)
            sleep(0.1)
            f2 = mw.submit(task, 2, e)
            sleep(0.1)
            f3 = mw.submit(task, 3, e)
            sleep(0.1)

# Generated at 2022-06-18 11:39:12.170878
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase

    class Test(TestCase):
        def test(self):
            # create a MonoWorker
            mw = MonoWorker()

            # create a Future
            f = Future()

            # create a function that sets the Future
            def set_future(f):
                time.sleep(0.1)
                f.set_result(True)

            # submit the function to the MonoWorker
            mw.submit(set_future, f)

            # wait for the Future to be set
            f.result()

    # run the test
    Test().test()

# Generated at 2022-06-18 11:39:25.508394
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from multiprocessing import Value
    from concurrent.futures import CancelledError
    from nose.tools import assert_equal, assert_raises
    from nose.plugins.skip import SkipTest
    try:
        from nose.tools import assert_is_instance
    except ImportError:
        def assert_is_instance(obj, cls):
            assert_equal(type(obj), cls)

    def test_func(x, y, z, sleep_time=0.1):
        sleep(sleep_time)
        return x + y + z

    def test_func_exception(x, y, z):
        raise Exception("test_func_exception")

    def test_func_cancel(x, y, z):
        sleep(1)
        return x

# Generated at 2022-06-18 11:39:32.525605
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
        time.sleep(0.05)
    time.sleep(0.1)
    assert mw.futures[0].done()
    assert mw.futures[1].done()
    assert mw.futures[0].result() == 9
    assert mw.futures[1].result() == 9

# Generated at 2022-06-18 11:39:40.527591
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from concurrent.futures import as_completed

    def func(x, lock):
        sleep(x)
        with lock:
            print("func({})".format(x))

    lock = Lock()
    mw = MonoWorker()
    mw.submit(func, 1, lock)
    mw.submit(func, 2, lock)
    mw.submit(func, 3, lock)
    mw.submit(func, 4, lock)
    mw.submit(func, 5, lock)
    mw.submit(func, 6, lock)
    mw.submit(func, 7, lock)
    mw.submit(func, 8, lock)
    mw.submit(func, 9, lock)

# Generated at 2022-06-18 11:39:48.466514
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from . import _range

    def slow_square(x):
        time.sleep(0.1)
        return x ** 2

    mw = MonoWorker()
    for _ in tqdm_auto(_range(10)):
        mw.submit(slow_square, _)
    for _ in tqdm_auto(_range(10)):
        mw.submit(slow_square, _)
    for _ in tqdm_auto(_range(10)):
        mw.submit(slow_square, _)
    for _ in tqdm_auto(_range(10)):
        mw.submit(slow_square, _)
    for _ in tqdm_auto(_range(10)):
        mw.submit(slow_square, _)

# Generated at 2022-06-18 11:40:00.127271
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from multiprocessing import Process
    from multiprocessing.connection import Listener
    from multiprocessing.connection import Client

    def worker(e, l):
        """
        Waits for `e` to be set, then starts a listener on `l` and waits for
        a connection. Once connected, it sends the string "Hello" and closes
        the connection.
        """
        e.wait()
        listener = Listener(l)
        conn = listener.accept()
        conn.send("Hello")
        conn.close()
        listener.close()

    def client(l):
        """
        Connects to a listener on `l` and waits for a string. Once received,
        it returns the string.
        """

# Generated at 2022-06-18 11:40:08.238044
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range
    from ..std import time as time_std

    def func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(5):
        mw.submit(func, i)
        time_std.sleep(0.05)
    time_std.sleep(0.2)
    assert mw.futures[0].done()
    assert mw.futures[1].done()
    assert mw.futures[0].result() == 4
    assert mw.futures[1].result() == 3

# Generated at 2022-06-18 11:40:12.263497
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
    assert mw.futures[0].result() == 9
    assert mw.futures[1].result() == 8

# Generated at 2022-06-18 11:40:15.434226
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)
    time.sleep(10)

# Generated at 2022-06-18 11:40:26.306182
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import as_completed
    from .tqdm_test_cases import tqdm_test_cases

    def test_func(x, sleep_time, stop_event):
        """Sleep for `sleep_time` seconds and return `x`."""
        sleep(sleep_time)
        if stop_event.is_set():
            raise Exception("stop_event is set")
        return x

    for desc, kwargs in tqdm_test_cases():
        with tqdm_auto.tqdm(**kwargs) as t:
            stop_event = Event()
            worker = MonoWorker()
            futures = [worker.submit(test_func, i, i, stop_event)
                       for i in t]

# Generated at 2022-06-18 11:40:31.060968
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
    for i in _range(10):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:40:43.342681
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)
    time.sleep(1)

# Generated at 2022-06-18 11:40:47.034658
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.05)
    assert mw.futures[0].result() == 9

# Generated at 2022-06-18 11:40:50.439752
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(5):
        mw.submit(f, i)
    assert mw.futures[0].result() == 4
    assert mw.futures[1].result() == 3

# Generated at 2022-06-18 11:40:54.267881
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Lock
    from concurrent.futures import as_completed

    def f(x):
        sleep(random())
        return x

    mw = MonoWorker()
    lock = Lock()
    with lock:
        for i in range(10):
            mw.submit(f, i)
        for future in as_completed(mw.futures):
            assert future.result() == 9

# Generated at 2022-06-18 11:41:01.100455
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import Future
    from multiprocessing import Process
    from multiprocessing.connection import Listener, Client
    from multiprocessing.managers import BaseManager
    from multiprocessing.reduction import reduce_connection

    class MyManager(BaseManager):
        pass

    MyManager.register('MonoWorker', MonoWorker)

    def server(e, conn):
        m = MyManager()
        m.start()
        mw = m.MonoWorker()
        e.wait()
        conn.send(reduce_connection(conn))
        conn.close()
        e.wait()
        conn = Listener(conn, authkey=b'tqdm')
        conn = conn.accept()

# Generated at 2022-06-18 11:41:09.357182
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Lock
    from concurrent.futures import Future
    from unittest import TestCase

    class Test(TestCase):
        def setUp(self):
            self.lock = Lock()
            self.mono = MonoWorker()

        def test_submit(self):
            """
            Test that only one task is running at a time, and that the most
            recent task is waiting to run.
            """
            def func(i):
                time.sleep(0.1)
                with self.lock:
                    self.assertEqual(len(self.mono.futures), 1)
                    self.assertIsInstance(self.mono.futures[0], Future)
                    self.assertFalse(self.mono.futures[0].done())

# Generated at 2022-06-18 11:41:12.631402
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def _test_func(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(_test_func, i)
        time.sleep(0.01)

# Generated at 2022-06-18 11:41:16.174153
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Lock

    lock = Lock()
    def func(i):
        sleep(random())
        with lock:
            print(i)

    mw = MonoWorker()
    for i in range(10):
        mw.submit(func, i)
    sleep(1)
    print('done')

# Generated at 2022-06-18 11:41:21.821176
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    assert len(mw.futures) == 0
    assert mw.futures.maxlen == 2

    # submit first task
    f1 = mw.submit(func, 1)
    assert isinstance(f1, Future)
    assert len(mw.futures) == 1
    assert mw.futures[0] is f1
    assert not f1.done()

    # submit second task
    f2 = mw.submit(func, 2)
    assert isinstance(f2, Future)
    assert len(mw.futures) == 2
    assert mw.futures

# Generated at 2022-06-18 11:41:27.125341
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from tqdm import tqdm
    from concurrent.futures import as_completed

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    futures = [mw.submit(f, x) for x in tqdm(range(10))]
    for future in as_completed(futures):
        assert future.result() == futures.index(future)

# Generated at 2022-06-18 11:41:50.490009
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def _test_MonoWorker_submit(n, m):
        """
        n: number of tasks
        m: number of tasks to run concurrently
        """
        mw = MonoWorker()
        for i in _range(n):
            mw.submit(time.sleep, 0.1)
        for i in _range(m):
            mw.submit(time.sleep, 0.1)
        for i in _range(n):
            mw.submit(time.sleep, 0.1)
        for i in _range(m):
            mw.submit(time.sleep, 0.1)
        for i in _range(n):
            mw.submit(time.sleep, 0.1)
        for i in _range(m):
            mw

# Generated at 2022-06-18 11:41:54.846099
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)
    assert mw.futures[0].result() == 9

# Generated at 2022-06-18 11:42:05.351364
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from ..utils import _range

    def wait_and_return(result, wait_time=0.1):
        time.sleep(wait_time)
        return result

    def wait_and_raise(wait_time=0.1):
        time.sleep(wait_time)
        raise ValueError('test')

    def wait_and_cancel(wait_time=0.1):
        time.sleep(wait_time)
        return Future().cancel()

    def wait_and_cancel_after(wait_time=0.1):
        time.sleep(wait_time)
        f = Future()
        f.set_result(None)
        return f.cancel()


# Generated at 2022-06-18 11:42:15.578759
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase

    class Test(TestCase):
        def setUp(self):
            self.worker = MonoWorker()
            self.event = Event()

        def test_submit(self):
            def func(arg):
                self.event.wait()
                return arg

            for i in range(3):
                future = self.worker.submit(func, i)
                self.assertIsInstance(future, Future)
                self.assertEqual(future.result(), i)
            self.event.set()

        def test_submit_cancel(self):
            def func(arg):
                self.event.wait()
                return arg


# Generated at 2022-06-18 11:42:23.071771
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    from concurrent.futures import Future

    def func(x):
        time.sleep(random.random() / 10)
        return x

    def test_submit(x):
        mw = MonoWorker()
        f = mw.submit(func, x)
        assert isinstance(f, Future)
        assert f.result() == x

    for i in range(10):
        test_submit(i)

    def test_submit_cancel(x):
        mw = MonoWorker()
        f = mw.submit(func, x)
        assert isinstance(f, Future)
        assert f.result() == x
        f = mw.submit(func, x + 1)
        assert isinstance(f, Future)
        f.cancel()


# Generated at 2022-06-18 11:42:32.596875
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    mw.submit(f, 0.1)
    mw.submit(f, 0.2)
    mw.submit(f, 0.3)
    mw.submit(f, 0.4)
    mw.submit(f, 0.5)
    mw.submit(f, 0.6)
    mw.submit(f, 0.7)
    mw.submit(f, 0.8)
    mw.submit(f, 0.9)
    mw.submit(f, 1.0)
    mw.submit(f, 1.1)
    mw.submit(f, 1.2)

# Generated at 2022-06-18 11:42:41.451401
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase, main

    class TestMonoWorker(TestCase):
        def setUp(self):
            self.mw = MonoWorker()
            self.event = Event()

        def test_submit(self):
            def func(x):
                self.event.wait()
                return x
            self.mw.submit(func, 1)
            self.mw.submit(func, 2)
            self.mw.submit(func, 3)
            self.mw.submit(func, 4)
            self.mw.submit(func, 5)
            self.mw.submit(func, 6)
            self.mw.submit(func, 7)

# Generated at 2022-06-18 11:42:45.410527
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
        time.sleep(0)
    assert mw.futures[0].result() == 9
    assert mw.futures[1].result() == 8

# Generated at 2022-06-18 11:42:49.278836
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import TimeoutError

    def func(x):
        time.sleep(x)
        return x

    def test_func(x, y, z):
        time.sleep(x)
        return x, y, z

    def test_func_exception(x, y, z):
        time.sleep(x)
        raise Exception(x, y, z)

    def test_func_cancel(x, y, z):
        time.sleep(x)
        if z.is_set():
            return x, y, z
        else:
            raise TimeoutError()

    def test_func_cancel_exception(x, y, z):
        time.sleep(x)

# Generated at 2022-06-18 11:42:57.071926
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from ..utils import _range

    def func(x):
        time.sleep(x)
        return x

    def test_func(x):
        time.sleep(x)
        return x

    def test_func_exception(x):
        time.sleep(x)
        raise Exception('test exception')

    def test_func_cancel(x):
        time.sleep(x)
        return x

    def test_func_cancel_exception(x):
        time.sleep(x)
        raise Exception('test exception')

    def test_func_cancel_exception_2(x):
        time.sleep(x)
        raise Exception('test exception')


# Generated at 2022-06-18 11:43:51.186955
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    import unittest
    from concurrent.futures import TimeoutError

    class TestMonoWorker(unittest.TestCase):
        def setUp(self):
            self.mw = MonoWorker()

        def test_submit(self):
            def func(x):
                time.sleep(random.random())
                return x

            def test_func(x):
                self.assertEqual(x, self.mw.submit(func, x).result())

            for x in range(10):
                threading.Thread(target=test_func, args=(x,)).start()

        def test_submit_replace(self):
            def func(x):
                time.sleep(random.random())
                return x


# Generated at 2022-06-18 11:43:56.204540
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from .utils import TestTqdmIO

    def func(i):
        time.sleep(0.1)
        return i

    with TestTqdmIO() as t:
        mw = MonoWorker()
        for i in range(5):
            mw.submit(func, i)
        time.sleep(0.5)
        assert t.out == '0\n1\n2\n3\n4\n'

# Generated at 2022-06-18 11:44:03.590936
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from concurrent.futures import as_completed

    def f(x):
        sleep(x)
        return x

    mw = MonoWorker()
    mw.submit(f, 1)
    mw.submit(f, 2)
    mw.submit(f, 3)
    mw.submit(f, 4)
    mw.submit(f, 5)
    mw.submit(f, 6)
    mw.submit(f, 7)
    mw.submit(f, 8)
    mw.submit(f, 9)
    mw.submit(f, 10)
    mw.submit(f, 11)
    mw.submit(f, 12)
    mw.submit(f, 13)

# Generated at 2022-06-18 11:44:12.344567
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Lock
    from concurrent.futures import as_completed
    from tqdm.contrib.concurrency import MonoWorker

    def _test_func(x, y, z, sleep_time=0.01):
        sleep(sleep_time)
        return x + y + z

    def _test_func_exception(x, y, z, sleep_time=0.01):
        sleep(sleep_time)
        raise Exception("{} + {} + {}".format(x, y, z))

    def _test_func_cancel(x, y, z, sleep_time=0.01):
        sleep(sleep_time)
        return x + y + z


# Generated at 2022-06-18 11:44:20.193489
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase

    class Test(TestCase):
        def test_submit(self):
            def func(x):
                time.sleep(x)
                return x

            def func_exception(x):
                raise Exception(x)

            def func_cancel(x):
                time.sleep(x)
                return x

            def func_cancel_exception(x):
                time.sleep(x)
                raise Exception(x)

            def func_cancel_exception_2(x):
                time.sleep(x)
                raise Exception(x)

            def func_cancel_exception_3(x):
                time.sleep(x)
                raise Exception(x)


# Generated at 2022-06-18 11:44:28.157443
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def _sleep(t):
        time.sleep(t)
        return t

    mw = MonoWorker()
    for i in _range(3):
        mw.submit(_sleep, 0.1)
    assert len(mw.futures) == 1
    assert mw.futures[0].result() == 0.1
    for i in _range(3):
        mw.submit(_sleep, 0.1)
    assert len(mw.futures) == 1
    assert mw.futures[0].result() == 0.1
    for i in _range(3):
        mw.submit(_sleep, 0.1)
    assert len(mw.futures) == 1

# Generated at 2022-06-18 11:44:32.021829
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def _test_func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(_test_func, i)
        time.sleep(0.01)

# Generated at 2022-06-18 11:44:40.162903
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
    time.sleep(1)
    assert mw.futures[0].done()
    assert not mw.futures[0].cancelled()
    assert mw.futures[0].result() == 9
    assert len(mw.futures) == 1
    assert mw.futures[0].done()
    assert not mw.futures[0].cancelled()
    assert mw.futures[0].result() == 9
    time.sleep(10)
    assert len(mw.futures) == 1


# Generated at 2022-06-18 11:44:47.536214
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import Future

    def func(x):
        sleep(x)
        return x

    def func_exception(x):
        raise Exception(x)

    def func_cancel(x, e):
        e.wait()
        return x

    def func_cancel_exception(x, e):
        e.wait()
        raise Exception(x)

    def test_func(func, *args, **kwargs):
        mw = MonoWorker()
        f1 = mw.submit(func, *args, **kwargs)
        assert isinstance(f1, Future)
        f2 = mw.submit(func, *args, **kwargs)
        assert isinstance(f2, Future)
        assert f1 is not f

# Generated at 2022-06-18 11:44:50.692620
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(5):
        mw.submit(func, i)
        time.sleep(0.1)