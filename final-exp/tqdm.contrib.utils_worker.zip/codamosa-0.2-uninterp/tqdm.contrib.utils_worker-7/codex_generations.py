

# Generated at 2022-06-18 11:36:34.207893
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from threading import Thread

    def _submit(mw, func, *args, **kwargs):
        return mw.submit(func, *args, **kwargs)

    def _wait(futures):
        for f in futures:
            f.result()

    def _sleep(t):
        time.sleep(t)
        return t

    def _test_submit(mw, func, *args, **kwargs):
        futures = []
        for _ in range(3):
            futures.append(_submit(mw, func, *args, **kwargs))
        _wait(futures)

    mw = MonoWorker()
    _test_submit(mw, _sleep, 0.1)

# Generated at 2022-06-18 11:36:44.764449
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import TimeoutError

    def _test_MonoWorker_submit(func, *args, **kwargs):
        mw = MonoWorker()
        e = Event()
        e.clear()
        f = mw.submit(func, *args, **kwargs)
        f.add_done_callback(lambda _: e.set())
        e.wait(timeout=1)
        assert f.done()
        assert f.result() == args[0]
        f = mw.submit(func, *args, **kwargs)
        f.add_done_callback(lambda _: e.set())
        e.wait(timeout=1)
        assert f.done()
        assert f.result() == args[0]
        f = mw

# Generated at 2022-06-18 11:36:54.918689
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import as_completed
    from ..utils import format_sizeof

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    mw.submit(func, 1)
    mw.submit(func, 2)
    mw.submit(func, 3)
    mw.submit(func, 4)
    mw.submit(func, 5)
    mw.submit(func, 6)
    mw.submit(func, 7)
    mw.submit(func, 8)
    mw.submit(func, 9)
    mw.submit(func, 10)
    mw.submit(func, 11)
    mw.submit(func, 12)
    mw.submit

# Generated at 2022-06-18 11:37:02.532449
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up

    def _test_func(x):
        time.sleep(x)
        return x

    with tqdm_auto.tqdm(total=10, desc='test') as t:
        mw = MonoWorker()
        for i in range(10):
            mw.submit(_test_func, i)
            t.update()
            time.sleep(0.1)
            tqdm_auto.write(_term_move_up() + '\r')

# Generated at 2022-06-18 11:37:13.473151
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading

    def sleep_random(t):
        time.sleep(t * random.random())

    def test_func(t):
        sleep_random(t)
        return t

    def test_func_exception(t):
        sleep_random(t)
        raise Exception("test_func_exception")

    def test_func_cancel(t):
        sleep_random(t)
        return t

    def test_func_cancel_exception(t):
        sleep_random(t)
        raise Exception("test_func_cancel_exception")

    def test_func_cancel_exception_after_cancel(t):
        sleep_random(t)
        raise Exception("test_func_cancel_exception_after_cancel")


# Generated at 2022-06-18 11:37:23.024385
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Lock
    from concurrent.futures import as_completed
    from tqdm.contrib.concurrency import MonoWorker

    def func(x, y, z):
        sleep(random() * 0.1)
        return x + y + z

    mw = MonoWorker()
    lock = Lock()
    with lock:
        futures = [mw.submit(func, i, i, i) for i in range(10)]
    for future in as_completed(futures):
        with lock:
            tqdm_auto.write(str(future.result()))

if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-18 11:37:33.255883
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Thread
    from concurrent.futures import Future

    def func(x):
        sleep(random())
        return x

    def test_submit(x):
        def submit(x):
            return mw.submit(func, x)
        return submit(x)

    mw = MonoWorker()
    assert len(mw.futures) == 0
    assert test_submit(1) == test_submit(2) == test_submit(3) == test_submit(4)
    assert len(mw.futures) == 1
    assert test_submit(5) == test_submit(6) == test_submit(7) == test_submit(8)
    assert len(mw.futures) == 1

# Generated at 2022-06-18 11:37:42.791345
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event

    def wait_for_event(event):
        event.wait()
        return True

    def wait_for_timeout(timeout):
        sleep(timeout)
        return True

    def wait_for_event_or_timeout(event, timeout):
        event.wait(timeout)
        return True

    def wait_for_timeout_or_event(timeout, event):
        sleep(timeout)
        event.wait()
        return True

    def wait_for_timeout_and_event(timeout, event):
        sleep(timeout)
        event.wait()
        return True

    def wait_for_event_and_timeout(event, timeout):
        event.wait()
        sleep(timeout)
        return True


# Generated at 2022-06-18 11:37:52.574256
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from multiprocessing import Process
    from threading import Thread

    def wait(t):
        time.sleep(t)

    def wait_and_print(t, s):
        time.sleep(t)
        tqdm_auto.write(s)

    def wait_and_return(t, s):
        time.sleep(t)
        return s

    def wait_and_raise(t, e):
        time.sleep(t)
        raise e

    def test_submit(func, *args, **kwargs):
        mw = MonoWorker()
        mw.submit(func, *args, **kwargs)

    def test_submit_and_wait(func, *args, **kwargs):
        mw = MonoWorker()

# Generated at 2022-06-18 11:37:59.171216
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up
    from ..std import time as time_std

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    with tqdm_auto.tqdm(total=3, desc='test_MonoWorker_submit') as t:
        for x in range(3):
            mw.submit(func, x)
            t.update()
            time_std.sleep(0.1)
            _term_move_up()

# Generated at 2022-06-18 11:38:08.704615
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def test_submit(self):
            def func(x):
                time.sleep(x)
                return x

            mw = MonoWorker()
            f1 = mw.submit(func, 1)
            f2 = mw.submit(func, 2)
            f3 = mw.submit(func, 3)
            self.assertEqual(f1.result(), 1)
            self.assertEqual(f2.result(), 2)
            self.assertEqual(f3.result(), 3)

        def test_submit_cancel(self):
            def func(x):
                time.sleep(x)
                return x

            m

# Generated at 2022-06-18 11:38:13.602120
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import TimeoutError

    def func(x, y, z, e):
        time.sleep(0.1)
        e.set()
        return x + y + z

    e = Event()
    mw = MonoWorker()
    f1 = mw.submit(func, 1, 2, 3, e)
    f2 = mw.submit(func, 4, 5, 6, e)
    f3 = mw.submit(func, 7, 8, 9, e)
    f4 = mw.submit(func, 10, 11, 12, e)
    f5 = mw.submit(func, 13, 14, 15, e)
    f6 = mw.submit(func, 16, 17, 18, e)

# Generated at 2022-06-18 11:38:24.040314
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from ..utils import _range

    def _test_func(x):
        time.sleep(0.1)
        return x

    def _test_func_err(x):
        raise ValueError(x)

    def _test_func_cancel(x):
        time.sleep(0.1)
        return x

    def _test_func_cancel_err(x):
        time.sleep(0.1)
        raise ValueError(x)

    def _test_func_cancel_err_cancel(x):
        time.sleep(0.1)
        raise ValueError(x)

    def _test_func_cancel_err_cancel_err(x):
        time.sleep(0.1)
        raise ValueError(x)

# Generated at 2022-06-18 11:38:35.078783
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Thread
    from concurrent.futures import wait
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def test_submit(self):
            def f(x):
                sleep(x)
                return x

            mw = MonoWorker()
            self.assertEqual(len(mw.futures), 0)
            mw.submit(f, 0.1)
            self.assertEqual(len(mw.futures), 1)
            mw.submit(f, 0.1)
            self.assertEqual(len(mw.futures), 1)
            mw.submit(f, 0.1)
            self.assertEqual(len(mw.futures), 1)
            mw.submit

# Generated at 2022-06-18 11:38:38.378082
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
        time.sleep(0.05)

    assert mw.futures[0].result() == 9
    assert mw.futures[1].result() == 8

# Generated at 2022-06-18 11:38:48.776989
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def test_submit(self):
            def func(x):
                time.sleep(x)
                return x

            def func_exception(x):
                raise Exception(x)

            def func_cancel(x, event):
                event.wait()
                return x

            def func_cancel_exception(x, event):
                event.wait()
                raise Exception(x)

            def func_cancel_exception_no_wait(x, event):
                raise Exception(x)

            def func_cancel_no_wait(x, event):
                return x


# Generated at 2022-06-18 11:38:54.443812
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
        time.sleep(0.01)
    assert mw.futures[0].result() == 9

# Generated at 2022-06-18 11:39:03.544164
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    from concurrent.futures import Future

    def _test_MonoWorker_submit(mw):
        def _test_MonoWorker_submit_func(i):
            time.sleep(random.random())
            return i

        def _test_MonoWorker_submit_func_exception(i):
            time.sleep(random.random())
            raise Exception("test_MonoWorker_submit_func_exception")

        def _test_MonoWorker_submit_func_cancel(i):
            time.sleep(random.random())
            return i

        def _test_MonoWorker_submit_func_cancel_exception(i):
            time.sleep(random.random())

# Generated at 2022-06-18 11:39:09.376265
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Event
    from concurrent.futures import as_completed

    def func(x, sleep_time, event):
        sleep(sleep_time)
        event.set()
        return x

    event = Event()
    mw = MonoWorker()
    for _ in range(10):
        event.clear()
        mw.submit(func, random(), random(), event)
        event.wait()
    for future in as_completed(mw.futures):
        assert future.result() is not None

# Generated at 2022-06-18 11:39:13.252349
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(5):
        mw.submit(f, i)
        time.sleep(0.5)
    assert mw.futures[0].result() == 4
    assert len(mw.futures) == 1

# Generated at 2022-06-18 11:39:22.518410
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
    time.sleep(0.1)
    assert len(mw.futures) == 1
    assert mw.futures[0].result() == 9

# Generated at 2022-06-18 11:39:29.046843
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from random import random
    from threading import Lock
    from concurrent.futures import as_completed

    def func(x, y, z, lock):
        time.sleep(random())
        with lock:
            tqdm_auto.write("{} {} {}".format(x, y, z))

    lock = Lock()
    mw = MonoWorker()
    for i in range(10):
        mw.submit(func, i, i + 1, i + 2, lock)
    for f in as_completed(mw.futures):
        f.result()

# Generated at 2022-06-18 11:39:34.907287
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(5):
        mw.submit(func, i)
        time.sleep(0.05)
    time.sleep(0.2)
    assert mw.futures[0].result() == 4
    assert mw.futures[1].result() == 3

# Generated at 2022-06-18 11:39:42.559000
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import TimeoutError
    from ..utils import _range

    def wait_for_event(event, timeout):
        event.wait(timeout)
        if not event.is_set():
            raise TimeoutError()

    def wait_for_event_with_timeout(event, timeout):
        try:
            wait_for_event(event, timeout)
        except TimeoutError:
            return False
        else:
            return True

    def wait_for_event_with_timeout_and_cancel(event, timeout):
        try:
            wait_for_event(event, timeout)
        except TimeoutError:
            return False
        else:
            return True


# Generated at 2022-06-18 11:39:46.801591
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
    for i in _range(10):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:39:57.655639
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event

    def wait_for_event(event):
        event.wait()

    def wait_for_time(t):
        time.sleep(t)

    worker = MonoWorker()
    event = Event()
    event.clear()
    future = worker.submit(wait_for_event, event)
    assert not future.done()
    assert len(worker.futures) == 1
    future = worker.submit(wait_for_time, 1)
    assert not future.done()
    assert len(worker.futures) == 1
    event.set()
    future.result()
    assert future.done()
    assert len(worker.futures) == 0

# Generated at 2022-06-18 11:40:01.303295
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def foo(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(foo, i)
        time.sleep(0.1)

# Generated at 2022-06-18 11:40:10.700772
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from concurrent.futures import as_completed

    def _test_MonoWorker_submit(func, *args, **kwargs):
        """
        Unit test for method submit of class MonoWorker.
        """
        mw = MonoWorker()
        lock = Lock()
        lock.acquire()
        futures = []
        for i in range(10):
            futures.append(mw.submit(func, i, lock, *args, **kwargs))
        lock.release()
        for future in as_completed(futures):
            assert future.result() == 9

    def func(i, lock, sleep_time=0.1):
        """
        Test function.
        """
        lock.acquire()
        sleep(sleep_time)


# Generated at 2022-06-18 11:40:16.420912
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from itertools import count
    from concurrent.futures import as_completed

    def func(x, wait=0.1, done=None):
        if done is not None:
            done.wait()
        sleep(wait)
        return x

    done = Event()
    done.set()
    worker = MonoWorker()
    futures = [worker.submit(func, i) for i in range(3)]
    assert len(futures) == 3
    assert len(worker.futures) == 1
    assert futures[-1] == worker.futures[0]
    assert futures[-1].result() == 2
    assert futures[-2].result() == 1
    assert futures[-3].result() == 0

    done.clear()
   

# Generated at 2022-06-18 11:40:22.088629
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
    for i in _range(10):
        assert mw.futures[i].result() == i


# Generated at 2022-06-18 11:40:34.081867
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(5):
        mw.submit(f, i)
        time.sleep(0.1)
    assert mw.futures[-1].result() == 4

# Generated at 2022-06-18 11:40:40.281506
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from tqdm.contrib import MonoWorker

    def func(x, y, z):
        time.sleep(x)
        return x + y + z

    def wait_for_future(future):
        while not future.done():
            time.sleep(0.1)

    def assert_future_result(future, expected_result):
        assert future.result() == expected_result

    def assert_future_cancelled(future):
        assert future.cancelled()

    def assert_future_not_cancelled(future):
        assert not future.cancelled()

    def assert_future_not_done(future):
        assert not future.done()


# Generated at 2022-06-18 11:40:43.404131
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random

    def func(x):
        sleep(random())
        return x

    mw = MonoWorker()
    for i in range(10):
        mw.submit(func, i)
    for i in range(10):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:40:50.541557
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up
    from ..utils import _range

    def slow_square(x):
        time.sleep(0.1)
        return x ** 2

    def slow_cube(x):
        time.sleep(0.1)
        return x ** 3

    def slow_quad(x):
        time.sleep(0.1)
        return x ** 4

    def slow_pent(x):
        time.sleep(0.1)
        return x ** 5

    def slow_hex(x):
        time.sleep(0.1)
        return x ** 6

    def slow_hept(x):
        time.sleep(0.1)
        return x ** 7

    def slow_oct(x):
        time.sleep(0.1)
        return x ** 8

# Generated at 2022-06-18 11:40:56.267480
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from multiprocessing import Process
    from multiprocessing.connection import Listener
    from multiprocessing.connection import Client

    def server(e, conn):
        e.wait()
        conn.send(1)
        conn.close()

    def client(e, conn):
        e.wait()
        conn.send(2)
        conn.close()

    def test_func(e, conn):
        e.wait()
        conn.send(3)
        conn.close()

    def test_func_exception(e, conn):
        e.wait()
        raise Exception('test_func_exception')

    def test_func_cancel(e, conn):
        e.wait()
        time.sleep(10)
        conn.send(4)

# Generated at 2022-06-18 11:41:04.417249
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Lock
    from concurrent.futures import Future
    from ..utils import _range

    def _test_func(i):
        time.sleep(i)
        return i

    def _test_func_exception(i):
        time.sleep(i)
        raise Exception("test_func_exception")

    def _test_func_cancel(i):
        time.sleep(i)
        return i

    def _test_func_cancel_exception(i):
        time.sleep(i)
        raise Exception("test_func_cancel_exception")

    def _test_func_cancel_exception_2(i):
        time.sleep(i)
        raise Exception("test_func_cancel_exception_2")


# Generated at 2022-06-18 11:41:12.271472
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import TimeoutError

    def func(event):
        event.wait()

    event = Event()
    mw = MonoWorker()
    f1 = mw.submit(func, event)
    f2 = mw.submit(func, event)
    f3 = mw.submit(func, event)
    assert f1.done()
    assert f2.done()
    assert not f3.done()
    assert f3.cancel()
    assert f3.done()
    assert not f3.result(timeout=0)
    assert f3.exception(timeout=0) is None
    event.set()
    assert f3.result(timeout=0) is None
    assert f3.exception(timeout=0) is None
   

# Generated at 2022-06-18 11:41:19.011490
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from ..utils import _range

    def wait(t):
        time.sleep(t)
        return t

    def wait_cancel(t, e):
        e.wait()
        return t

    def wait_raise(t):
        time.sleep(t)
        raise Exception("{}".format(t))

    def wait_raise_cancel(t, e):
        e.wait()
        raise Exception("{}".format(t))

    def test(func, *args, **kwargs):
        mw = MonoWorker()
        for i in _range(10):
            f = mw.submit(func, i, *args, **kwargs)
            assert isinstance(f, Future)
            assert f.result

# Generated at 2022-06-18 11:41:28.292632
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from ..utils import _range

    def _test_func(i, e):
        e.wait()
        return i

    e = Event()
    mw = MonoWorker()
    for i in _range(5):
        f = mw.submit(_test_func, i, e)
        assert isinstance(f, Future)
        assert f.running()
    assert len(mw.futures) == 1
    e.set()
    time.sleep(0.1)
    assert len(mw.futures) == 0
    for i in _range(5):
        f = mw.submit(_test_func, i, e)
        assert isinstance(f, Future)
        assert f.running()
   

# Generated at 2022-06-18 11:41:31.361551
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)

# Generated at 2022-06-18 11:41:57.388804
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    import multiprocessing
    from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor

    def f(x):
        time.sleep(random.random())
        return x

    def test_submit(pool):
        mw = MonoWorker()
        for i in range(10):
            mw.submit(pool.submit, f, i)
            time.sleep(random.random() * 0.1)
        for i in range(10):
            assert mw.futures[i].result() == i

    def test_submit_threads():
        test_submit(ThreadPoolExecutor(max_workers=1))

    def test_submit_processes():
        test_submit(ProcessPoolExecutor(max_workers=1))


# Generated at 2022-06-18 11:42:07.088838
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from threading import Event

    def test_func(i, e):
        e.wait()
        return i

    e = Event()
    mw = MonoWorker()
    f1 = mw.submit(test_func, 1, e)
    f2 = mw.submit(test_func, 2, e)
    assert isinstance(f1, Future)
    assert isinstance(f2, Future)
    assert f1.done() is False
    assert f2.done() is False
    assert f1.cancel() is False
    assert f2.cancel() is False
    e.set()
    time.sleep(0.1)
    assert f1.done() is True
    assert f2.done() is True
    assert f1.result

# Generated at 2022-06-18 11:42:12.494258
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
    for i in _range(10):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:42:21.145785
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(5):
        mw.submit(f, i)
        time.sleep(0.1)
    assert mw.futures[0].result() == 4
    assert len(mw.futures) == 1

    mw.submit(f, 5)
    assert mw.futures[0].result() == 5
    assert len(mw.futures) == 1

    mw.submit(f, 6)
    assert mw.futures[0].result() == 6
    assert len(mw.futures) == 1

    mw.submit(f, 7)

# Generated at 2022-06-18 11:42:30.153423
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import format_sizeof
    from ..utils import format_interval

    def test_func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in tqdm_auto.tqdm(range(10), desc='test_MonoWorker_submit'):
        mw.submit(test_func, i)

    # Test that the last task is not discarded
    mw = MonoWorker()
    for i in tqdm_auto.tqdm(range(10), desc='test_MonoWorker_submit'):
        mw.submit(test_func, i)
    assert mw.futures[0].result() == 9

    # Test that the last task is not discarded
    mw = MonoWorker()

# Generated at 2022-06-18 11:42:39.507236
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    assert len(mw.futures) == 0
    assert mw.submit(func, 1) is not None
    assert len(mw.futures) == 1
    assert mw.submit(func, 2) is not None
    assert len(mw.futures) == 1
    assert mw.submit(func, 3) is not None
    assert len(mw.futures) == 1
    assert mw.submit(func, 4) is not None
    assert len(mw.futures) == 1
    assert mw.submit(func, 5) is not None

# Generated at 2022-06-18 11:42:47.196053
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from ..utils import _term_move_up

    def _test_func(i, evt):
        evt.wait()
        time.sleep(0.1)
        return i

    evt = Event()
    mw = MonoWorker()
    for i in range(5):
        mw.submit(_test_func, i, evt)
    evt.set()
    for i in range(5):
        assert mw.futures[i].result() == 4

    # Test that the most recent task is kept
    evt.clear()
    for i in range(5):
        mw.submit(_test_func, i, evt)
    evt.set()

# Generated at 2022-06-18 11:42:55.049761
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    from threading import Thread
    from queue import Queue
    from concurrent.futures import Future
    from concurrent.futures import CancelledError
    from concurrent.futures import TimeoutError

    def _run_test(mw, q):
        for i in range(10):
            mw.submit(time.sleep, random.random() / 10)
            q.put(None)
        for i in range(10):
            q.get()
            mw.submit(time.sleep, random.random() / 10)
        for i in range(10):
            q.get()
            mw.submit(time.sleep, random.random() / 10)
            q.get()
        for i in range(10):
            q.get()

# Generated at 2022-06-18 11:43:01.903861
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    from concurrent.futures import Future
    from ..utils import _range


# Generated at 2022-06-18 11:43:06.966772
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    from multiprocessing import Process
    from multiprocessing.pool import ThreadPool

    def _test_MonoWorker_submit_thread(mw, n, sleep, lock):
        with lock:
            tqdm_auto.write("thread {}".format(n))
        time.sleep(sleep)
        mw.submit(lambda: n)

    def _test_MonoWorker_submit_process(mw, n, sleep, lock):
        with lock:
            tqdm_auto.write("process {}".format(n))
        time.sleep(sleep)
        mw.submit(lambda: n)

    def _test_MonoWorker_submit_thread_pool(mw, n, sleep, lock):
        with lock:
            tqdm

# Generated at 2022-06-18 11:44:00.943167
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from concurrent.futures import Future
    from tqdm.contrib.concurrency import MonoWorker

    def func(x):
        sleep(x)
        return x

    worker = MonoWorker()
    assert len(worker.futures) == 0

    # submit 1st task
    f1 = worker.submit(func, 1)
    assert isinstance(f1, Future)
    assert len(worker.futures) == 1
    assert worker.futures[0] == f1

    # submit 2nd task
    f2 = worker.submit(func, 2)
    assert isinstance(f2, Future)
    assert len(worker.futures) == 1
    assert worker.futures[0] == f2

    # submit 3rd task

# Generated at 2022-06-18 11:44:09.550495
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future

    def func(x, y, z):
        time.sleep(x)
        return x + y + z

    def test_func(x, y, z, e):
        e.wait()
        return func(x, y, z)

    def test_func_cancel(x, y, z, e):
        e.wait()
        return func(x, y, z)

    def test_func_exception(x, y, z, e):
        e.wait()
        raise Exception("test_func_exception")

    def test_func_cancel_exception(x, y, z, e):
        e.wait()
        raise Exception("test_func_cancel_exception")


# Generated at 2022-06-18 11:44:17.830424
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def test_submit(self):
            def func(n, e):
                sleep(n)
                e.set()
            e = Event()
            mw = MonoWorker()
            mw.submit(func, 0.1, e)
            self.assertTrue(e.wait(0.2))
            e.clear()
            mw.submit(func, 0.1, e)
            self.assertTrue(e.wait(0.2))
            e.clear()
            mw.submit(func, 0.1, e)
            self.assertTrue(e.wait(0.2))
            e.clear()

# Generated at 2022-06-18 11:44:21.538227
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.05)
    for i in _range(10):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:44:29.933258
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Thread
    from queue import Queue
    from unittest import TestCase, main

    class TestMonoWorker(TestCase):
        def setUp(self):
            self.mw = MonoWorker()
            self.q = Queue()

        def test_submit(self):
            def f(x):
                sleep(x)
                self.q.put(x)
            self.mw.submit(f, 0.1)
            self.mw.submit(f, 0.2)
            self.mw.submit(f, 0.3)
            self.mw.submit(f, 0.4)
            self.mw.submit(f, 0.5)
            self.mw.submit(f, 0.6)

# Generated at 2022-06-18 11:44:38.590460
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def test_submit(self):
            def func(x, y, z):
                sleep(0.1)
                return x + y + z

            def func2(x, y, z):
                sleep(0.1)
                return x * y * z

            def func3(x, y, z):
                sleep(0.1)
                return x - y - z

            def func4(x, y, z):
                sleep(0.1)
                return x / y / z

            def func5(x, y, z):
                sleep(0.1)
                return x ** y ** z


# Generated at 2022-06-18 11:44:41.869870
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)
    time.sleep(1)
    assert mw.futures[0].result() == 9
    assert len(mw.futures) == 1

# Generated at 2022-06-18 11:44:50.053868
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future

    def _test_func(x, y, z, evt):
        evt.wait()
        return x + y + z

    def _test_func_exc(x, y, z, evt):
        evt.wait()
        raise Exception('test exception')

    def _test_func_cancel(x, y, z, evt):
        evt.wait()
        return x + y + z

    def _test_func_cancel_exc(x, y, z, evt):
        evt.wait()
        raise Exception('test exception')

    def _test_func_cancel_exc_2(x, y, z, evt):
        evt.wait()
        raise Exception('test exception')

   

# Generated at 2022-06-18 11:44:58.684130
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(3):
        mw.submit(f, i)
    assert mw.futures[0].result() == 2
    assert mw.futures[1].result() == 1
    assert len(mw.futures) == 2
    mw.submit(f, 3)
    assert mw.futures[0].result() == 3
    assert mw.futures[1].result() == 2
    assert len(mw.futures) == 2
    mw.submit(f, 4)
    assert mw.futures[0].result() == 4
    assert mw.futures

# Generated at 2022-06-18 11:45:02.670279
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(5):
        mw.submit(f, i)
        time.sleep(0.05)
    time.sleep(0.2)
    assert mw.futures[0].result() == 4