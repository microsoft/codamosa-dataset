

# Generated at 2022-06-18 11:36:33.819919
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase

    class Test(TestCase):
        def test_submit(self):
            def func(x):
                time.sleep(x)
                return x

            mw = MonoWorker()
            f1 = mw.submit(func, 0.1)
            f2 = mw.submit(func, 0.2)
            f3 = mw.submit(func, 0.3)
            f4 = mw.submit(func, 0.4)
            self.assertIsInstance(f1, Future)
            self.assertIsInstance(f2, Future)
            self.assertIsInstance(f3, Future)
            self.assertIsInstance(f4, Future)

# Generated at 2022-06-18 11:36:37.918619
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
        time.sleep(0.05)
    time.sleep(0.5)

# Generated at 2022-06-18 11:36:44.516137
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(5):
        mw.submit(func, i)
        time.sleep(0.1)
    time.sleep(1)
    assert mw.futures[0].result() == 4
    assert len(mw.futures) == 1

# Generated at 2022-06-18 11:36:49.959414
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)

# Generated at 2022-06-18 11:37:00.778364
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import TimeoutError

    def wait(seconds):
        time.sleep(seconds)

    def wait_with_event(seconds, event):
        event.wait(seconds)

    def wait_with_event_and_timeout(seconds, event, timeout):
        event.wait(timeout)
        time.sleep(seconds)

    def wait_with_timeout(seconds, timeout):
        time.sleep(seconds)

    def wait_with_timeout_and_event(seconds, timeout, event):
        event.wait(timeout)
        time.sleep(seconds)

    def wait_with_timeout_and_event_and_timeout(seconds, timeout, event, timeout2):
        event.wait(timeout)
        time.sleep(seconds)


# Generated at 2022-06-18 11:37:06.337860
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def test_func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(5):
        mw.submit(test_func, i)
        time.sleep(0.05)
    time.sleep(0.5)

# Generated at 2022-06-18 11:37:15.536356
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from ..utils import _range

    def wait_for_event(event, timeout=1):
        """Wait for event to be set or timeout"""
        event.wait(timeout)
        return event.is_set()

    def wait_for_event_with_tqdm(event, timeout=1):
        """Wait for event to be set or timeout"""
        for _ in tqdm_auto(_range(timeout * 100), leave=False):
            if event.is_set():
                break
            time.sleep(0.01)
        return event.is_set()

    def wait_for_event_with_tqdm_and_cancel(event, timeout=1):
        """Wait for event to be set or timeout"""

# Generated at 2022-06-18 11:37:25.704561
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Lock
    from concurrent.futures import Future
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def setUp(self):
            self.lock = Lock()
            self.mono_worker = MonoWorker()
            self.futures = []

        def test_submit(self):
            def func(i):
                time.sleep(0.1)
                return i

            for i in range(10):
                future = self.mono_worker.submit(func, i)
                self.futures.append(future)

            for i, future in enumerate(self.futures):
                self.assertEqual(future.result(), i)

        def test_submit_cancel(self):
            def func(i):
                time

# Generated at 2022-06-18 11:37:35.676143
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future

    def _test_submit(mw, func, *args, **kwargs):
        """
        Test `mw.submit(func, *args, **kwargs)`
        """
        assert isinstance(mw.submit(func, *args, **kwargs), Future)

    def _test_submit_cancel(mw, func, *args, **kwargs):
        """
        Test `mw.submit(func, *args, **kwargs)`
        """
        assert isinstance(mw.submit(func, *args, **kwargs), Future)
        assert mw.futures[-1].cancel()


# Generated at 2022-06-18 11:37:40.074577
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def wait(t):
        time.sleep(t)
        return t

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(wait, i)
    assert mw.futures[0].result() == 9
    assert mw.futures[1].result() == 8

# Generated at 2022-06-18 11:37:51.625606
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from threading import Thread
    from queue import Queue

    def _submit(worker, func, *args, **kwargs):
        return worker.submit(func, *args, **kwargs)

    def _run(func, *args, **kwargs):
        return func(*args, **kwargs)

    def _wait(future):
        return future.result()

    def _sleep(t):
        time.sleep(t)

    def _wait_for(future, t):
        time.sleep(t)
        return future.result()

    def _wait_for_all(futures, t):
        time.sleep(t)
        return [f.result() for f in futures]


# Generated at 2022-06-18 11:38:01.098741
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future

    def _test_submit(mw, func, *args, **kwargs):
        """
        Test that `mw.submit(func, *args, **kwargs)` returns a future
        that is not done and that is cancelled when another future is
        submitted to `mw`.
        """
        f = mw.submit(func, *args, **kwargs)
        assert isinstance(f, Future)
        assert not f.done()
        mw.submit(func, *args, **kwargs)
        assert f.done()
        assert f.cancelled()


# Generated at 2022-06-18 11:38:07.593929
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import as_completed

    def f(x, e):
        e.wait()
        return x

    e = Event()
    mw = MonoWorker()
    f1 = mw.submit(f, 1, e)
    f2 = mw.submit(f, 2, e)
    f3 = mw.submit(f, 3, e)
    sleep(0.1)
    assert f1.done()
    assert not f2.done()
    assert not f3.done()
    e.set()
    for f in as_completed([f2, f3]):
        assert f.result() == 2

# Generated at 2022-06-18 11:38:13.162889
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    with tqdm_auto.tqdm(total=10) as t:
        for i in _range(10):
            mw.submit(f, i)
            t.update()
            tqdm_auto.write('{}'.format(i))
            _term_move_up()

# Generated at 2022-06-18 11:38:23.643547
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event

    def func(x, y, z, e):
        sleep(x)
        e.set()
        return x + y + z

    e = Event()
    mw = MonoWorker()
    assert mw.submit(func, 0.1, 1, 2, e)
    assert mw.submit(func, 0.2, 3, 4, e)
    assert mw.submit(func, 0.3, 5, 6, e)
    assert mw.submit(func, 0.4, 7, 8, e)
    assert mw.submit(func, 0.5, 9, 10, e)
    assert mw.submit(func, 0.6, 11, 12, e)

# Generated at 2022-06-18 11:38:32.569332
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import format_sizeof
    from ..utils import format_interval

    def test_func(i, sleep=0.1):
        time.sleep(sleep)
        return i

    mw = MonoWorker()
    for i in tqdm_auto.tqdm(range(10), desc='test_MonoWorker_submit'):
        mw.submit(test_func, i, sleep=0.1)
        time.sleep(0.05)

    print('\n' + format_sizeof(mw))
    print(format_interval(mw.futures[0].result()))

# Generated at 2022-06-18 11:38:37.614456
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)
    assert mw.futures[0].result() == 9
    assert mw.futures[1].result() == 8

# Generated at 2022-06-18 11:38:47.321399
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Lock
    from concurrent.futures import as_completed
    from tqdm.contrib.concurrent import MonoWorker

    def func(x):
        sleep(random())
        return x

    def test_submit(n, m):
        mw = MonoWorker()
        with tqdm_auto.tqdm(total=n) as pbar:
            for i in range(n):
                mw.submit(func, i)
                pbar.update()
                sleep(random() / m)
        return mw

    def test_submit_with_lock(n, m):
        lock = Lock()
        mw = MonoWorker()

# Generated at 2022-06-18 11:38:52.097280
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    import multiprocessing
    from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
    from multiprocessing import Queue

    def _test_submit(pool, n_tasks, n_workers, n_runs, n_sleeps,
                     n_sleep_max, n_sleep_min, n_sleep_mean,
                     n_sleep_std, n_sleep_median, n_sleep_mode):
        """
        Test `MonoWorker.submit` with `pool` (`ThreadPoolExecutor` or
        `ProcessPoolExecutor`).
        """
        def _task(n_sleep):
            time.sleep(n_sleep)
            return n_sleep


# Generated at 2022-06-18 11:38:58.310210
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Lock

    def f(x):
        sleep(random())
        return x

    mw = MonoWorker()
    lock = Lock()
    with lock:
        for i in range(10):
            mw.submit(f, i)
            sleep(random())
        for i in range(10):
            assert mw.futures[0].result() == i
            sleep(random())

# Generated at 2022-06-18 11:39:09.701171
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    mw.submit(f, 0.5)
    mw.submit(f, 0.5)
    mw.submit(f, 0.5)
    mw.submit(f, 0.5)
    mw.submit(f, 0.5)
    mw.submit(f, 0.5)
    mw.submit(f, 0.5)
    mw.submit(f, 0.5)
    mw.submit(f, 0.5)
    mw.submit(f, 0.5)
    mw.submit(f, 0.5)
    mw.submit(f, 0.5)

# Generated at 2022-06-18 11:39:17.705782
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    from concurrent.futures import ThreadPoolExecutor

    def func(x):
        time.sleep(random.random())
        return x

    def test_submit(n, m):
        """Test `MonoWorker.submit` with `n` tasks and `m` workers."""
        pool = ThreadPoolExecutor(max_workers=m)
        mono = MonoWorker()
        futures = []
        for i in range(n):
            futures.append(pool.submit(func, i))
            futures.append(mono.submit(func, i))
        for i in range(n):
            assert futures[i].result() == futures[i + n].result()

    test_submit(10, 1)
    test_submit(10, 2)
    test_submit

# Generated at 2022-06-18 11:39:21.028461
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
    for i in _range(10):
        assert mw.futures[0].result() == 9 - i

# Generated at 2022-06-18 11:39:24.917393
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
    for i in _range(10):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:39:34.190213
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from ..utils import _range

    def test_func(x):
        time.sleep(0.1)
        return x

    def test_func_exception(x):
        time.sleep(0.1)
        raise Exception('test_func_exception')

    def test_func_cancel(x):
        time.sleep(0.1)
        return x

    def test_func_cancel_exception(x):
        time.sleep(0.1)
        raise Exception('test_func_cancel_exception')

    def test_func_cancel_exception_wait(x):
        time.sleep(0.1)
        raise Exception('test_func_cancel_exception_wait')


# Generated at 2022-06-18 11:39:39.322615
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    from threading import Event

    def wait_random(evt):
        evt.wait()
        time.sleep(random.random())

    evt = Event()
    mw = MonoWorker()
    for i in range(10):
        mw.submit(wait_random, evt)
    evt.set()
    time.sleep(1)
    assert len(mw.futures) == 1
    assert mw.futures[0].done()

# Generated at 2022-06-18 11:39:46.158117
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def _test_submit(n, sleep):
        def _test_func(i):
            time.sleep(sleep)
            return i

        mw = MonoWorker()
        for i in _range(n):
            mw.submit(_test_func, i, sleep=sleep)
        assert len(mw.futures) == 1
        assert mw.futures[0].result() == n - 1

    _test_submit(1, 0.1)
    _test_submit(2, 0.1)
    _test_submit(3, 0.1)
    _test_submit(4, 0.1)
    _test_submit(5, 0.1)
    _test_submit(6, 0.1)

# Generated at 2022-06-18 11:39:58.225902
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase, main

    class Test(TestCase):
        def test(self):
            mw = MonoWorker()
            e = Event()
            f1 = Future()
            f2 = Future()
            f3 = Future()
            f4 = Future()
            f5 = Future()
            f6 = Future()
            f7 = Future()
            f8 = Future()
            f9 = Future()
            f10 = Future()
            f11 = Future()
            f12 = Future()
            f13 = Future()
            f14 = Future()
            f15 = Future()
            f16 = Future()
            f17 = Future()
            f18 = Future()
            f19 = Future()
            f

# Generated at 2022-06-18 11:40:08.070605
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event

    def wait_and_return(event, result):
        event.wait()
        return result

    def wait_and_raise(event, exception):
        event.wait()
        raise exception

    def test_wait_and_return(event, result):
        assert MonoWorker().submit(wait_and_return, event, result).result() == result

    def test_wait_and_raise(event, exception):
        assert MonoWorker().submit(wait_and_raise, event, exception).result() == exception

    for result in [None, True, False, 0, 1, -1, "", "a", [], [1], {}, {1: 2}]:
        test_wait_and_return(Event(), result)

# Generated at 2022-06-18 11:40:15.301878
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Thread
    from queue import Queue

    def f(x):
        sleep(x)
        return x

    def g(x):
        sleep(x)
        raise Exception("x={}".format(x))

    def h(x):
        sleep(x)
        raise KeyboardInterrupt

    def run(f, *args, **kwargs):
        try:
            return f(*args, **kwargs)
        except Exception as e:
            return e

    def run_in_thread(f, *args, **kwargs):
        q = Queue()
        t = Thread(target=run, args=(f,) + args, kwargs=kwargs, daemon=True)
        t.start()
        t.join()
        q.put(t.result)
        return

# Generated at 2022-06-18 11:40:28.212609
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    from concurrent.futures import as_completed
    from ..utils import _range

    def f(x):
        time.sleep(random.random() * 0.01)
        return x

    mw = MonoWorker()
    futures = [mw.submit(f, x) for x in _range(10)]
    for future in as_completed(futures):
        assert future.result() == futures.pop(0).result()

# Generated at 2022-06-18 11:40:36.292916
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random

    def f(x):
        sleep(random())
        return x

    mw = MonoWorker()
    mw.submit(f, 1)
    mw.submit(f, 2)
    mw.submit(f, 3)
    mw.submit(f, 4)
    mw.submit(f, 5)
    mw.submit(f, 6)
    mw.submit(f, 7)
    mw.submit(f, 8)
    mw.submit(f, 9)
    mw.submit(f, 10)
    mw.submit(f, 11)
    mw.submit(f, 12)
    mw.submit(f, 13)
    mw.submit(f, 14)

# Generated at 2022-06-18 11:40:43.503079
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    from concurrent.futures import Future
    from ..utils import _range

    def _test_MonoWorker_submit(n_tasks, n_workers):
        """
        Test that MonoWorker.submit(func, *args, **kwargs)
        only runs the most recent task.
        """
        def func(i):
            time.sleep(random.random() / 10)
            return i

        def check_results(results):
            assert len(results) == n_tasks
            for i in _range(n_tasks):
                assert results[i] == i

        def submit_tasks(mw):
            results = []
            for i in _range(n_tasks):
                future = mw.submit(func, i)

# Generated at 2022-06-18 11:40:50.640458
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event

    def sleep(t, e):
        e.wait()
        time.sleep(t)

    def test(t, e):
        mw = MonoWorker()
        e.set()
        mw.submit(sleep, t, e)
        time.sleep(t / 2)
        mw.submit(sleep, t, e)
        time.sleep(t / 2)
        mw.submit(sleep, t, e)
        time.sleep(t / 2)
        mw.submit(sleep, t, e)
        time.sleep(t / 2)
        mw.submit(sleep, t, e)
        time.sleep(t / 2)
        mw.submit(sleep, t, e)
        time.sleep(t / 2)
        mw

# Generated at 2022-06-18 11:40:56.325234
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase

    class MonoWorkerTest(TestCase):
        def test_submit(self):
            def func(x):
                sleep(x)
                return x

            mw = MonoWorker()
            self.assertEqual(len(mw.futures), 0)
            f1 = mw.submit(func, 1)
            self.assertEqual(len(mw.futures), 1)
            self.assertIsInstance(f1, Future)
            self.assertFalse(f1.done())
            f2 = mw.submit(func, 2)
            self.assertEqual(len(mw.futures), 1)

# Generated at 2022-06-18 11:41:04.489834
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import TimeoutError

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    assert mw.submit(f, 1)
    assert mw.submit(f, 2)
    assert mw.submit(f, 3)
    assert mw.submit(f, 4)
    assert mw.submit(f, 5)
    assert mw.submit(f, 6)
    assert mw.submit(f, 7)
    assert mw.submit(f, 8)
    assert mw.submit(f, 9)
    assert mw.submit(f, 10)
    assert mw.submit(f, 11)
    assert mw.submit(f, 12)
    assert mw.submit(f, 13)

# Generated at 2022-06-18 11:41:12.343834
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event

    def wait_and_return(seconds, return_value):
        time.sleep(seconds)
        return return_value

    def wait_and_raise(seconds, exception):
        time.sleep(seconds)
        raise exception

    def wait_and_return_with_callback(seconds, return_value, callback):
        time.sleep(seconds)
        callback()
        return return_value

    def wait_and_raise_with_callback(seconds, exception, callback):
        time.sleep(seconds)
        callback()
        raise exception

    def wait_and_return_with_callback_and_args(seconds, return_value,
                                               callback, *args):
        time.sleep(seconds)
        callback(*args)
        return return_value


# Generated at 2022-06-18 11:41:16.865110
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def setUp(self):
            self.mw = MonoWorker()
            self.e = Event()
            self.f = Future()

        def test_submit(self):
            self.mw.submit(self.e.wait)
            self.mw.submit(self.f.set_result, None)
            self.e.set()
            self.f.result()

    TestMonoWorker().test_submit()

# Generated at 2022-06-18 11:41:21.675534
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.01)
    assert mw.futures[0].result() == 9
    assert mw.futures[1].result() == 8

# Generated at 2022-06-18 11:41:25.420787
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
        time.sleep(0.01)

# Generated at 2022-06-18 11:41:48.146260
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from multiprocessing import Value
    from concurrent.futures import as_completed
    from tqdm import tqdm

    def func(i, lock, counter):
        with lock:
            counter.value += 1
        sleep(0.1)
        return i

    lock = Lock()
    counter = Value('i', 0)
    mw = MonoWorker()
    futures = [mw.submit(func, i, lock, counter) for i in tqdm(range(10))]
    for future in as_completed(futures):
        assert future.result() == futures.index(future)
    assert counter.value == 1

# Generated at 2022-06-18 11:41:58.007417
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    assert len(mw.futures) == 0

    # submit first task
    f1 = mw.submit(func, 1)
    assert isinstance(f1, Future)
    assert len(mw.futures) == 1

    # submit second task
    f2 = mw.submit(func, 2)
    assert isinstance(f2, Future)
    assert len(mw.futures) == 2

    # submit third task
    f3 = mw.submit(func, 3)
    assert isinstance(f3, Future)
    assert len(mw.futures) == 2

    # check that second task is running

# Generated at 2022-06-18 11:42:06.270983
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Lock
    from concurrent.futures import Future
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def test_submit(self):
            def func(x):
                sleep(random() * 0.1)
                return x

            mw = MonoWorker()
            lock = Lock()
            with lock:
                for i in range(10):
                    f = mw.submit(func, i)
                    self.assertIsInstance(f, Future)
                    self.assertEqual(f.result(), i)

    test = TestMonoWorker()
    test.test_submit()

# Generated at 2022-06-18 11:42:13.053887
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def _test_func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(_test_func, i)
        time.sleep(0.01)
    time.sleep(0.5)  # wait for all to finish
    assert mw.futures[0].result() == 9
    assert mw.futures[1].result() == 9

# Generated at 2022-06-18 11:42:21.568984
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future

    def sleep_and_return(t, ret):
        time.sleep(t)
        return ret

    def sleep_and_raise(t, exc):
        time.sleep(t)
        raise exc

    def sleep_and_cancel(t, evt):
        time.sleep(t)
        evt.set()

    def test_submit(func, *args, **kwargs):
        """
        Test that `func(*args, **kwargs)` is submitted to the MonoWorker.
        """
        mw = MonoWorker()
        f = mw.submit(func, *args, **kwargs)
        assert isinstance(f, Future)
        assert f.done() is False
        return f


# Generated at 2022-06-18 11:42:30.802641
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from tqdm import tqdm

    def _test_MonoWorker_submit(mw, func, args, kwargs, expected_result):
        """
        Test `mw.submit(func, *args, **kwargs)` against `expected_result`.
        """
        future = mw.submit(func, *args, **kwargs)
        assert isinstance(future, Future)
        assert future.result() == expected_result

    def _test_MonoWorker_submit_exception(mw, func, args, kwargs, expected_exception):
        """
        Test `mw.submit(func, *args, **kwargs)` against `expected_exception`.
        """

# Generated at 2022-06-18 11:42:39.944755
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up
    from ..utils import _range

    def _test_func(x):
        time.sleep(x)
        return x

    def _test_func_exception(x):
        raise Exception('test exception')

    def _test_func_cancel(x):
        for _ in _range(x):
            time.sleep(1)
            tqdm_auto.write('test cancel')
        return x

    def _test_func_cancel_exception(x):
        for _ in _range(x):
            time.sleep(1)
            tqdm_auto.write('test cancel exception')
        raise Exception('test cancel exception')


# Generated at 2022-06-18 11:42:45.246253
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    from concurrent.futures import as_completed
    from ..utils import format_sizeof

    def func(x):
        time.sleep(random.random() * 0.1)
        return x

    mw = MonoWorker()
    futures = []
    for i in range(10):
        futures.append(mw.submit(func, i))
    for f in as_completed(futures):
        print(f.result())

    # Test memory usage
    print(format_sizeof(mw))

# Generated at 2022-06-18 11:42:53.078686
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Thread
    from queue import Queue

    def func(x, y):
        sleep(x)
        return x + y

    def test_thread(q, mw, x, y):
        q.put(mw.submit(func, x, y))

    q = Queue()
    mw = MonoWorker()
    t1 = Thread(target=test_thread, args=(q, mw, 1, 1))
    t2 = Thread(target=test_thread, args=(q, mw, 2, 2))
    t3 = Thread(target=test_thread, args=(q, mw, 3, 3))
    t1.start()
    t2.start()
    t3.start()
    t1.join()
    t2.join()
    t

# Generated at 2022-06-18 11:43:00.382431
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import TimeoutError
    from ..utils import _term_move_up

    def _test_func(i, evt):
        evt.wait()
        return i

    def _test_func_exception(i, evt):
        evt.wait()
        raise Exception("test exception")

    def _test_func_timeout(i, evt):
        evt.wait()
        raise TimeoutError()

    def _test_func_cancel(i, evt):
        evt.wait()
        raise Exception("test exception")

    def _test_func_cancel_timeout(i, evt):
        evt.wait()
        raise TimeoutError()


# Generated at 2022-06-18 11:43:49.102855
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from concurrent.futures import as_completed
    from unittest import TestCase, main

    class TestMonoWorker(TestCase):
        def setUp(self):
            self.mw = MonoWorker()
            self.lock = Lock()
            self.results = []

        def test_submit(self):
            def func(i):
                sleep(0.1)
                with self.lock:
                    self.results.append(i)
            for i in range(10):
                self.mw.submit(func, i)
            for future in as_completed(self.mw.futures):
                future.result()
            self.assertEqual(len(self.results), 1)

    main()

# Generated at 2022-06-18 11:43:53.320888
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def _test_MonoWorker_submit(n, sleep):
        worker = MonoWorker()
        for i in _range(n):
            worker.submit(time.sleep, sleep)
        time.sleep(sleep)

    _test_MonoWorker_submit(10, 0.01)
    _test_MonoWorker_submit(10, 0.1)

# Generated at 2022-06-18 11:43:57.692001
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)
    assert mw.futures[0].result() == 9
    assert len(mw.futures) == 1

# Generated at 2022-06-18 11:44:05.457212
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def sleep(t):
        time.sleep(t)
        return t

    mw = MonoWorker()
    for i in _range(3):
        mw.submit(sleep, i)
    for i in _range(3):
        mw.submit(sleep, i)
    for i in _range(3):
        mw.submit(sleep, i)
    for i in _range(3):
        mw.submit(sleep, i)
    for i in _range(3):
        mw.submit(sleep, i)
    for i in _range(3):
        mw.submit(sleep, i)
    for i in _range(3):
        mw.submit(sleep, i)
    for i in _range(3):
        m

# Generated at 2022-06-18 11:44:14.328144
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    from concurrent.futures import Future
    from ..utils import _range

    def _test_MonoWorker_submit(n, m, sleep, seed):
        random.seed(seed)
        mw = MonoWorker()
        for _ in _range(n):
            mw.submit(time.sleep, sleep)
        for _ in _range(m):
            mw.submit(time.sleep, sleep)
            time.sleep(sleep)
        for _ in _range(n):
            mw.submit(time.sleep, sleep)
        for _ in _range(m):
            mw.submit(time.sleep, sleep)
            time.sleep(sleep)
        for _ in _range(n):
            mw.submit(time.sleep, sleep)

# Generated at 2022-06-18 11:44:21.851974
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from .tests import TestCase, _range

    class TestMonoWorker(TestCase):
        def test_submit(self):
            mw = MonoWorker()
            for i in _range(10):
                mw.submit(time.sleep, 0.1)
            mw.submit(time.sleep, 0.1)
            mw.submit(time.sleep, 0.1)
            mw.submit(time.sleep, 0.1)
            mw.submit(time.sleep, 0.1)
            mw.submit(time.sleep, 0.1)
            mw.submit(time.sleep, 0.1)
            mw.submit(time.sleep, 0.1)
            mw.submit(time.sleep, 0.1)

# Generated at 2022-06-18 11:44:25.827890
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
    for i in _range(10):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:44:29.517604
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def test_func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(test_func, i)
        time.sleep(0.05)

# Generated at 2022-06-18 11:44:38.257076
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Thread
    from concurrent.futures import as_completed
    from tqdm import tqdm

    def func(x):
        sleep(random())
        return x

    mw = MonoWorker()
    futures = [mw.submit(func, i) for i in range(10)]
    for f in tqdm(as_completed(futures), total=len(futures)):
        assert f.result() == futures.index(f)

    # test that the last submitted task is the only one running
    mw = MonoWorker()
    futures = [mw.submit(func, i) for i in range(10)]

# Generated at 2022-06-18 11:44:41.280836
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
        time.sleep(0.01)
    for i in _range(10):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:46:05.863321
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from threading import Event

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    assert len(mw.futures) == 0
    assert isinstance(mw.submit(func, 0.1), Future)
    assert len(mw.futures) == 1
    assert isinstance(mw.submit(func, 0.1), Future)
    assert len(mw.futures) == 1
    assert isinstance(mw.submit(func, 0.1), Future)
    assert len(mw.futures) == 1
    assert isinstance(mw.submit(func, 0.1), Future)
    assert len(mw.futures) == 1
    assert isinstance

# Generated at 2022-06-18 11:46:13.422654
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Lock
    from concurrent.futures import as_completed

    def func(i, delay=0.01):
        sleep(delay)
        return i

    def test(n=10, delay=0.01):
        mw = MonoWorker()
        futures = [mw.submit(func, i, delay=delay) for i in range(n)]
        for i, f in enumerate(as_completed(futures)):
            assert f.result() == i

    test()
    test(n=100)
    test(n=100, delay=0.1)

    def func(i, lock, delay=0.01):
        sleep(delay)
        with lock:
            tqdm_auto.write(str(i))


# Generated at 2022-06-18 11:46:23.845028
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    from multiprocessing import Pool
    from concurrent.futures import ThreadPoolExecutor

    def f(x):
        time.sleep(random.random())
        return x

    def g(x):
        time.sleep(random.random())
        raise ValueError(x)

    def h(x):
        time.sleep(random.random())
        return x

    def i(x):
        time.sleep(random.random())
        raise ValueError(x)

    def j(x):
        time.sleep(random.random())
        return x

    def k(x):
        time.sleep(random.random())
        raise ValueError(x)

    def l(x):
        time.sleep(random.random())
        return x
