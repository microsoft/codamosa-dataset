

# Generated at 2022-06-18 11:36:31.808230
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up
    from ..utils import _range
    from ..utils import _unich
    from ..utils import _unicode

    def test_func(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    with tqdm_auto.tqdm(total=10, desc='test') as t:
        for i in _range(10):
            mw.submit(test_func, i)
            t.update()
            t.write(_unicode(_unich(0x258F)) + _term_move_up() +
                    _unicode(_unich(0x258F)))
            time.sleep(0.1)
    assert mw.futures[0].result() == 9

# Generated at 2022-06-18 11:36:40.210627
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase

    class Test(TestCase):
        def setUp(self):
            self.mw = MonoWorker()
            self.e = Event()
            self.f = Future()

        def test_submit(self):
            self.mw.submit(self.e.wait)
            self.assertFalse(self.e.is_set())
            self.e.set()
            self.assertTrue(self.e.is_set())
            self.mw.submit(self.f.set_result, True)
            self.assertTrue(self.f.result())

        def test_submit_replace(self):
            self.mw.submit(self.e.wait)

# Generated at 2022-06-18 11:36:45.348519
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def sleep_func(duration):
        time.sleep(duration)
        return duration

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(sleep_func, i)
        time.sleep(0.1)

# Generated at 2022-06-18 11:36:55.484479
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up
    from ..utils import _range

    def f(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        tqdm_auto.write('{}'.format(i))
        _term_move_up()
    for i in _range(10):
        mw.submit(f, i)
        tqdm_auto.write('{}'.format(i))
        _term_move_up()
    for i in _range(10):
        mw.submit(f, i)
        tqdm_auto.write('{}'.format(i))
        _term_move_up()

# Generated at 2022-06-18 11:37:07.336059
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import as_completed
    from ..utils import _range

    def test_func(i, wait, done):
        sleep(wait)
        done.set()
        return i

    done = Event()
    done.clear()
    mw = MonoWorker()
    mw.submit(test_func, 0, 0.1, done)
    done.wait()
    assert done.is_set()

    done.clear()
    mw.submit(test_func, 1, 0.1, done)
    done.wait()
    assert done.is_set()

    done.clear()
    mw.submit(test_func, 2, 0.1, done)
    done.wait()
    assert done.is_set()

   

# Generated at 2022-06-18 11:37:13.991809
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Thread
    from queue import Queue

    def func(x):
        sleep(x)
        return x

    q = Queue()

    def worker(mw):
        for i in range(10):
            mw.submit(func, i)
            sleep(0.1)
        q.put(None)

    mw = MonoWorker()
    t = Thread(target=worker, args=(mw,))
    t.start()
    q.get()
    t.join()

# Generated at 2022-06-18 11:37:18.604873
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
    assert mw.futures[0].result() == 9
    assert mw.futures[1].result() == 8

# Generated at 2022-06-18 11:37:27.870173
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    assert len(mw.futures) == 0
    mw.submit(f, 1)
    assert len(mw.futures) == 1
    mw.submit(f, 2)
    assert len(mw.futures) == 1
    mw.submit(f, 3)
    assert len(mw.futures) == 1
    mw.submit(f, 4)
    assert len(mw.futures) == 1
    mw.submit(f, 5)
    assert len(mw.futures) == 1
    mw.submit(f, 6)

# Generated at 2022-06-18 11:37:32.495328
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def sleep(t):
        time.sleep(t)
        return t

    mw = MonoWorker()
    for i in _range(3):
        mw.submit(sleep, i)
        time.sleep(0.1)
    assert mw.futures[0].result() == 2

# Generated at 2022-06-18 11:37:40.123180
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    from concurrent.futures import Future

    def _test_func(x):
        time.sleep(random.random())
        return x

    def _test_func_exception(x):
        raise Exception("test exception")

    def _test_func_cancel(x):
        time.sleep(random.random())
        return x

    def _test_func_cancel_exception(x):
        time.sleep(random.random())
        raise Exception("test exception")

    def _test_func_cancel_exception_2(x):
        time.sleep(random.random())
        raise Exception("test exception")

    def _test_func_cancel_exception_3(x):
        time.sleep(random.random())

# Generated at 2022-06-18 11:37:51.686126
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase, main

    class TestMonoWorker(TestCase):
        def test_submit(self):
            def func(x):
                sleep(x)
                return x

            mw = MonoWorker()
            self.assertEqual(len(mw.futures), 0)
            self.assertIsInstance(mw.submit(func, 1), Future)
            self.assertEqual(len(mw.futures), 1)
            self.assertIsInstance(mw.submit(func, 2), Future)
            self.assertEqual(len(mw.futures), 1)
            self.assertIsInstance(mw.submit(func, 3), Future)

# Generated at 2022-06-18 11:37:56.744338
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(5):
        mw.submit(f, i)
        time.sleep(0.05)
    time.sleep(0.2)
    assert mw.futures[0].result() == 4

# Generated at 2022-06-18 11:38:05.053356
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from concurrent.futures import Future

    def func(x):
        sleep(0.1)
        return x

    def func_exception(x):
        raise Exception("{}".format(x))

    def func_lock(x, lock):
        lock.acquire()
        sleep(0.1)
        lock.release()
        return x

    def func_lock_exception(x, lock):
        lock.acquire()
        raise Exception("{}".format(x))

    def test_func(func, args, kwargs, expected_result):
        mw = MonoWorker()
        future = mw.submit(func, *args, **kwargs)
        assert isinstance(future, Future)
        assert future.result() == expected_result

# Generated at 2022-06-18 11:38:13.306648
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Lock
    from concurrent.futures import as_completed

    def func(x):
        sleep(random())
        return x

    def test(n):
        mw = MonoWorker()
        futures = [mw.submit(func, i) for i in range(n)]
        for f in as_completed(futures):
            assert f.result() == n - 1

    for n in range(1, 10):
        test(n)

    # Test that the lock is working
    lock = Lock()
    mw = MonoWorker()
    futures = [mw.submit(lock.acquire) for _ in range(2)]
    for f in as_completed(futures):
        assert f.result() is True

# Generated at 2022-06-18 11:38:23.755004
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from tqdm.contrib.concurrent import MonoWorker

    def func(x):
        time.sleep(x)
        return x

    def test_submit(x, y, z):
        mw = MonoWorker()
        f1 = mw.submit(func, x)
        f2 = mw.submit(func, y)
        f3 = mw.submit(func, z)
        assert f1.result() == x
        assert f2.result() == y
        assert f3.result() == z

    test_submit(1, 2, 3)
    test_submit(3, 2, 1)
    test_submit(2, 3, 1)


# Generated at 2022-06-18 11:38:34.812258
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_time
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_time
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_time
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_time
    from ..utils import format_

# Generated at 2022-06-18 11:38:41.546377
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up
    from ..utils import _range

    def _test_MonoWorker_submit(n, sleep):
        with tqdm_auto.tqdm(total=n, desc='test_MonoWorker_submit') as t:
            mw = MonoWorker()
            for i in _range(n):
                mw.submit(time.sleep, sleep)
                t.update()
                _term_move_up()
                tqdm_auto.write('\r')

    for n in [1, 2, 3]:
        for sleep in [0, 0.1]:
            _test_MonoWorker_submit(n, sleep)

# Generated at 2022-06-18 11:38:53.640805
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from ..utils import _range

    def _test_func(i, evt):
        evt.wait()
        time.sleep(0.1)
        return i

    def _test_func_exception(i, evt):
        evt.wait()
        raise Exception("test_func_exception")

    def _test_func_cancel(i, evt):
        evt.wait()
        time.sleep(0.1)
        return i

    def _test_func_cancel_exception(i, evt):
        evt.wait()
        raise Exception("test_func_cancel_exception")

    def _test_func_cancel_exception_2(i, evt):
        ev

# Generated at 2022-06-18 11:38:58.877379
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.05)
    for i in _range(10):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:39:06.717351
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import as_completed
    from ..utils import _range

    def _test_submit(func, *args, **kwargs):
        mw = MonoWorker()
        futures = [mw.submit(func, *args, **kwargs) for _ in _range(10)]
        for f in as_completed(futures):
            assert f.result() == 'done'

    def func():
        time.sleep(0.1)
        return 'done'

    _test_submit(func)
    _test_submit(func, 1)
    _test_submit(func, 1, 2)
    _test_submit(func, 1, 2, 3)
    _test_submit(func, 1, 2, 3, 4)

# Generated at 2022-06-18 11:39:14.305942
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(5):
        mw.submit(f, i)
        time.sleep(0.1)
    time.sleep(1)
    assert mw.futures[0].result() == 4

# Generated at 2022-06-18 11:39:18.772581
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def _test_submit(n, sleep, max_workers=1):
        mw = MonoWorker()
        for i in _range(n):
            mw.submit(time.sleep, sleep)
        mw.pool.shutdown()

    _test_submit(10, 0.1)
    _test_submit(10, 0.1, max_workers=2)

# Generated at 2022-06-18 11:39:22.776481
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)

    for i in _range(10):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:39:27.324436
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def _test_func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(_test_func, i)
    time.sleep(0.5)
    assert mw.futures[0].done()
    assert not mw.futures[1].done()

# Generated at 2022-06-18 11:39:36.694668
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    mw.submit(f, 1)
    mw.submit(f, 2)
    mw.submit(f, 3)
    mw.submit(f, 4)
    mw.submit(f, 5)
    mw.submit(f, 6)
    mw.submit(f, 7)
    mw.submit(f, 8)
    mw.submit(f, 9)
    mw.submit(f, 10)
    mw.submit(f, 11)
    mw.submit(f, 12)
    mw.submit(f, 13)
    mw.submit(f, 14)
   

# Generated at 2022-06-18 11:39:40.787423
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)
    assert mw.futures[0].result() == 9
    assert len(mw.futures) == 1

# Generated at 2022-06-18 11:39:47.090243
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def test_submit(self):
            def func(x, y):
                time.sleep(x)
                return x + y

            def func_exception(x, y):
                time.sleep(x)
                raise Exception("test exception")

            def func_cancel(x, y):
                time.sleep(x)
                return x + y

            def func_cancel_exception(x, y):
                time.sleep(x)
                raise Exception("test exception")

            def func_cancel_exception_2(x, y):
                time.sleep(x)
                raise Exception("test exception")


# Generated at 2022-06-18 11:39:59.097505
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading

    def func(x):
        time.sleep(random.random())
        return x

    mw = MonoWorker()
    for i in range(10):
        mw.submit(func, i)
        time.sleep(random.random())

    for i in range(10):
        mw.submit(func, i)
        time.sleep(random.random())

    for i in range(10):
        mw.submit(func, i)
        time.sleep(random.random())

    for i in range(10):
        mw.submit(func, i)
        time.sleep(random.random())

    for i in range(10):
        mw.submit(func, i)
        time.sleep(random.random())


# Generated at 2022-06-18 11:40:05.971926
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(5):
        mw.submit(func, i)
        time.sleep(0.1)
    for i in _range(5):
        mw.submit(func, i)
        time.sleep(0.1)
    for i in _range(5):
        mw.submit(func, i)
        time.sleep(0.1)

# Generated at 2022-06-18 11:40:10.711920
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(5):
        mw.submit(func, i)
        time.sleep(0.05)
    for i in _range(5):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:40:28.415061
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    from concurrent.futures import ThreadPoolExecutor
    from ..auto import tqdm as tqdm_auto

    def test_func(x):
        time.sleep(random.random())
        return x

    def test_func_exception(x):
        time.sleep(random.random())
        raise Exception("test_func_exception")

    def test_func_cancel(x):
        time.sleep(random.random())
        return x

    def test_func_cancel_exception(x):
        time.sleep(random.random())
        raise Exception("test_func_cancel_exception")

    def test_func_cancel_exception_2(x):
        time.sleep(random.random())

# Generated at 2022-06-18 11:40:36.465471
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    from threading import Event
    from concurrent.futures import TimeoutError

    def _test_func(x, y, z, e, t):
        time.sleep(t)
        if e.is_set():
            raise Exception("Cancelled")
        return x + y + z

    def _test_func_timeout(x, y, z, e, t):
        time.sleep(t)
        if e.is_set():
            raise Exception("Cancelled")
        return x + y + z

    def _test_func_cancel(x, y, z, e, t):
        time.sleep(t)
        if e.is_set():
            raise Exception("Cancelled")
        return x + y + z


# Generated at 2022-06-18 11:40:42.533275
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    from multiprocessing import cpu_count
    from concurrent.futures import ThreadPoolExecutor

    def func(x):
        time.sleep(random.random() / cpu_count())
        return x

    mw = MonoWorker()
    with ThreadPoolExecutor(max_workers=cpu_count()) as pool:
        futures = [pool.submit(mw.submit, func, i) for i in range(100)]
        for f in futures:
            f.result()
        assert len(mw.futures) == 1
        assert mw.futures[0].result() == 99

# Generated at 2022-06-18 11:40:48.533496
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)

# Generated at 2022-06-18 11:40:53.375899
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import as_completed
    from threading import Lock
    from tqdm.contrib.concurrent import MonoWorker

    def wait(t):
        time.sleep(t)
        return t

    mw = MonoWorker()
    lock = Lock()
    with lock:
        for i in tqdm_auto.trange(10):
            mw.submit(wait, i)
            time.sleep(0.1)
    for f in as_completed(mw.futures):
        assert f.result() == 9

# Generated at 2022-06-18 11:40:56.647798
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    from threading import Event

    def func(i, e):
        time.sleep(random.random())
        e.set()
        return i

    e = Event()
    mw = MonoWorker()
    for i in range(10):
        e.clear()
        mw.submit(func, i, e)
        e.wait()
    assert mw.futures[0].result() == 9

# Generated at 2022-06-18 11:41:04.857849
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Thread
    from queue import Queue
    from random import random

    def worker(q, n):
        sleep(random())
        q.put(n)

    q = Queue()
    mw = MonoWorker()
    for i in range(10):
        mw.submit(worker, q, i)
    for i in range(10):
        assert q.get() == i

    def worker_exc(q, n):
        sleep(random())
        raise Exception("test")

    q = Queue()
    mw = MonoWorker()
    for i in range(10):
        mw.submit(worker_exc, q, i)
    for i in range(10):
        assert q.empty()


# Generated at 2022-06-18 11:41:11.791541
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event

    def func(x, event):
        event.wait()
        return x

    mw = MonoWorker()
    e = Event()
    e.clear()
    f1 = mw.submit(func, 1, e)
    f2 = mw.submit(func, 2, e)
    f3 = mw.submit(func, 3, e)
    assert f1.done()
    assert not f2.done()
    assert not f3.done()
    assert f2.result() == 2
    e.set()
    time.sleep(0.1)
    assert f3.done()
    assert f3.result() == 3

# Generated at 2022-06-18 11:41:18.673548
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase

    class Test(TestCase):
        def setUp(self):
            self.worker = MonoWorker()
            self.event = Event()

        def test_submit(self):
            def func(x):
                self.event.wait()
                return x

            self.event.clear()
            future = self.worker.submit(func, 1)
            self.assertIsInstance(future, Future)
            self.assertEqual(future.result(), 1)

            self.event.clear()
            future = self.worker.submit(func, 2)
            self.assertIsInstance(future, Future)
            self.assertEqual(future.result(), 2)

            self.event.clear()
           

# Generated at 2022-06-18 11:41:28.048630
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def setUp(self):
            self.mw = MonoWorker()
            self.mw.pool = ThreadPoolExecutor(max_workers=1)
            self.mw.futures = deque([], 2)
            self.func_called = Event()
            self.func_called.clear()

        def func(self, *args, **kwargs):
            self.func_called.set()
            return args, kwargs

        def test_submit(self):
            """
            Test that the function is called, and that the future is returned.
            """

# Generated at 2022-06-18 11:41:47.896814
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event

    def wait(t, e):
        e.wait()
        time.sleep(t)
        return t

    e = Event()
    mw = MonoWorker()
    f1 = mw.submit(wait, 1, e)
    f2 = mw.submit(wait, 2, e)
    f3 = mw.submit(wait, 3, e)
    e.set()
    assert f1.result() == 1
    assert f2.result() == 2
    assert f3.result() == 3

# Generated at 2022-06-18 11:41:51.723178
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
        time.sleep(0.05)
    time.sleep(0.5)

# Generated at 2022-06-18 11:41:59.175513
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Lock
    from concurrent.futures import as_completed

    def f(x, lock):
        sleep(random())
        with lock:
            tqdm_auto.write('{}'.format(x))

    lock = Lock()
    mw = MonoWorker()
    for i in range(10):
        mw.submit(f, i, lock)
    for f in as_completed(mw.futures):
        f.result()

# Generated at 2022-06-18 11:42:08.335350
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import as_completed

    def f(x, e):
        e.wait()
        return x

    e = Event()
    mw = MonoWorker()
    f1 = mw.submit(f, 1, e)
    f2 = mw.submit(f, 2, e)
    f3 = mw.submit(f, 3, e)
    assert f1.done()
    assert f2.done()
    assert not f3.done()
    e.set()
    assert f3.result() == 3
    assert list(as_completed([f1, f2, f3])) == [f1, f2, f3]

# Generated at 2022-06-18 11:42:18.018398
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def wait(t):
        time.sleep(t)
        return t

    mw = MonoWorker()
    assert mw.submit(wait, 1) is not None
    assert mw.submit(wait, 2) is not None
    assert mw.submit(wait, 3) is not None
    assert mw.submit(wait, 4) is not None
    assert mw.submit(wait, 5) is not None
    assert mw.submit(wait, 6) is not None
    assert mw.submit(wait, 7) is not None
    assert mw.submit(wait, 8) is not None
    assert mw.submit(wait, 9) is not None
    assert mw.submit(wait, 10) is not None

# Generated at 2022-06-18 11:42:22.343511
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Lock

    def func(x, y, z):
        sleep(random())
        return x + y + z

    mw = MonoWorker()
    lock = Lock()
    with lock:
        for i in range(10):
            mw.submit(func, i, i, i)
            sleep(random())

    with lock:
        for i in range(10):
            mw.submit(func, i, i, i)
            sleep(random())

# Generated at 2022-06-18 11:42:31.947280
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import as_completed

    def wait_for_event(event):
        event.wait()
        return 'done'

    def wait_for_time(seconds):
        time.sleep(seconds)
        return 'done'

    def wait_for_time_with_exception(seconds):
        time.sleep(seconds)
        raise Exception('exception')

    def wait_for_time_with_cancel(seconds):
        time.sleep(seconds)
        raise Exception('cancelled')

    def wait_for_time_with_cancel_and_exception(seconds):
        time.sleep(seconds)
        raise Exception('cancelled and exception')


# Generated at 2022-06-18 11:42:40.737935
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase, main

    class TestMonoWorker(TestCase):
        def test_submit(self):
            def func(x, y, z):
                sleep(x)
                return y + z

            def func_exception(x, y, z):
                sleep(x)
                raise Exception("test_submit")

            def func_cancel(x, y, z):
                sleep(x)
                return y + z

            def func_cancel_exception(x, y, z):
                sleep(x)
                raise Exception("test_submit")

            def func_cancel_exception_2(x, y, z):
                sleep(x)
                raise Exception("test_submit")



# Generated at 2022-06-18 11:42:45.965029
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from concurrent.futures import as_completed
    from tqdm.contrib.concurrent import MonoWorker

    def f(x):
        sleep(x)
        return x

    mw = MonoWorker()
    lock = Lock()
    with lock:
        for i in range(10):
            mw.submit(f, i)
        for future in as_completed(mw.futures):
            assert future.result() == 9


# Generated at 2022-06-18 11:42:53.768933
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def setUp(self):
            self.mw = MonoWorker()
            self.evt = Event()
            self.evt.clear()
            self.evt2 = Event()
            self.evt2.clear()
            self.evt3 = Event()
            self.evt3.clear()
            self.evt4 = Event()
            self.evt4.clear()
            self.evt5 = Event()
            self.evt5.clear()
            self.evt6 = Event()
            self.evt6.clear()
            self.evt7 = Event()
            self.evt7.clear

# Generated at 2022-06-18 11:43:34.145585
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Lock
    from multiprocessing import Process

    def worker(lock, worker, n, sleep_time):
        with lock:
            tqdm_auto.write("{} start".format(worker))
        sleep(sleep_time)
        with lock:
            tqdm_auto.write("{} end".format(worker))
        return n

    def test_worker(lock, n):
        mw = MonoWorker()
        for i in range(n):
            mw.submit(worker, lock, i, random())
        for i in range(n):
            mw.submit(worker, lock, i, random())
        for i in range(n):
            mw.submit(worker, lock, i, random())

# Generated at 2022-06-18 11:43:41.740324
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import as_completed

    def func(x, y, z, sleep_time=0.1, wait_event=None):
        if wait_event is not None:
            wait_event.wait()
        sleep(sleep_time)
        return x + y + z

    mw = MonoWorker()
    wait_event = Event()
    wait_event.clear()
    f1 = mw.submit(func, 1, 2, 3, wait_event=wait_event)
    f2 = mw.submit(func, 4, 5, 6)
    f3 = mw.submit(func, 7, 8, 9)
    wait_event.set()

# Generated at 2022-06-18 11:43:49.940687
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from concurrent.futures import Future
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def setUp(self):
            self.mw = MonoWorker()
            self.lock = Lock()
            self.counter = 0

        def test_submit(self):
            def incr():
                with self.lock:
                    self.counter += 1
                sleep(0.1)
                with self.lock:
                    self.counter += 1
            self.mw.submit(incr)
            self.mw.submit(incr)
            self.mw.submit(incr)
            sleep(0.2)
            self.assertEqual(self.counter, 2)
            sleep(0.1)

# Generated at 2022-06-18 11:43:58.129615
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from ..utils import _range

    def wait(t):
        time.sleep(t)
        return t

    def wait_and_cancel(t, future):
        time.sleep(t)
        future.cancel()
        return t

    def wait_and_cancel_all(t, futures):
        time.sleep(t)
        for f in futures:
            f.cancel()
        return t

    def wait_and_raise(t):
        time.sleep(t)
        raise Exception('Exception')

    def wait_and_raise_cancelled(t):
        time.sleep(t)
        raise Exception('Exception')


# Generated at 2022-06-18 11:44:05.969178
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import format_sizeof

    def func(x):
        time.sleep(x)
        return x

    def test_submit(x):
        mw = MonoWorker()
        f1 = mw.submit(func, x)
        f2 = mw.submit(func, x)
        f3 = mw.submit(func, x)
        assert f1.done()
        assert f2.done()
        assert not f3.done()
        assert f1.result() == x
        assert f2.result() == x
        assert f3.result() == x

    test_submit(1)
    test_submit(2)
    test_submit(3)
    test_submit(4)
    test_submit(5)
    test_submit(6)
    test_

# Generated at 2022-06-18 11:44:14.848402
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def setUp(self):
            self.mw = MonoWorker()
            self.futures = self.mw.futures
            self.futures.append(Future())
            self.futures.append(Future())

        def test_submit_cancel(self):
            self.futures[0].set_result(1)
            self.futures[1].set_result(2)
            self.mw.submit(lambda: 3)
            self.assertEqual(self.futures[0].result(), 1)
            self.assertEqual(self.futures[1].result(), 2)
           

# Generated at 2022-06-18 11:44:22.315404
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from ..utils import _range

    def wait_for_event(event):
        event.wait()

    def wait_for_future(future):
        future.result()

    def wait_for_future_with_timeout(future, timeout):
        future.result(timeout=timeout)

    def wait_for_future_with_timeout_and_cancel(future, timeout):
        try:
            future.result(timeout=timeout)
        except Exception:
            pass
        finally:
            future.cancel()

    def wait_for_future_with_timeout_and_cancel_and_exception(future, timeout):
        try:
            future.result(timeout=timeout)
        except Exception:
            pass

# Generated at 2022-06-18 11:44:27.164652
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up
    from ..utils import _range

    def wait(t):
        time.sleep(t)
        return t

    mw = MonoWorker()
    for i in _range(10):
        t = mw.submit(wait, i)
        tqdm_auto.write('{} {}'.format(i, t))
        _term_move_up()

# Generated at 2022-06-18 11:44:36.080649
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Lock
    from concurrent.futures import Future
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def setUp(self):
            self.mw = MonoWorker()
            self.lock = Lock()
            self.count = 0

        def test_submit(self):
            self.mw.submit(self.incr, 1)
            self.mw.submit(self.incr, 2)
            self.mw.submit(self.incr, 3)
            self.mw.submit(self.incr, 4)
            self.mw.submit(self.incr, 5)
            self.mw.submit(self.incr, 6)
            self.mw.submit(self.incr, 7)
            self

# Generated at 2022-06-18 11:44:43.140547
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import TimeoutError
    from ..utils import _term_move_up

    def func(x, y, z, wait_event):
        wait_event.wait()
        return x + y + z

    def test_func(x, y, z, wait_event):
        return func(x, y, z, wait_event)

    def test_func_cancel(x, y, z, wait_event):
        return func(x, y, z, wait_event)

    def test_func_exception(x, y, z, wait_event):
        raise Exception("test_func_exception")

    def test_func_timeout(x, y, z, wait_event):
        time.sleep(2)

# Generated at 2022-06-18 11:46:27.173932
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from concurrent.futures import Future
    from unittest import TestCase, main

    class TestMonoWorker(TestCase):
        def setUp(self):
            self.lock = Lock()
            self.mw = MonoWorker()
            self.futures = []

        def tearDown(self):
            for f in self.futures:
                f.cancel()

        def test_submit(self):
            def func(i):
                with self.lock:
                    self.assertEqual(len(self.futures), i)
                    self.futures.append(Future())
                sleep(0.1)
                with self.lock:
                    self.assertEqual(len(self.futures), i + 1)