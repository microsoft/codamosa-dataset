

# Generated at 2022-06-18 11:36:27.629192
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import format_sizeof
    from ..utils import format_interval

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in range(5):
        mw.submit(func, i)
        time.sleep(0.1)

    t0 = time.time()
    for i in range(5):
        mw.submit(func, i)
        time.sleep(0.1)
    t1 = time.time()

    tqdm_auto.write("\n" + format_sizeof(mw))
    tqdm_auto.write(format_interval(t1 - t0))

# Generated at 2022-06-18 11:36:33.249954
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    from threading import Lock
    from concurrent.futures import Future

    def func(x):
        time.sleep(random.random())
        return x

    mw = MonoWorker()
    lock = Lock()
    futs = []
    for i in range(10):
        with lock:
            futs.append(mw.submit(func, i))
        time.sleep(random.random() / 10)
    for fut in futs:
        assert isinstance(fut, Future)
        assert fut.result() in range(10)

# Generated at 2022-06-18 11:36:41.150642
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event

    def func(x, y, z, e):
        e.wait()
        return x + y + z

    e = Event()
    mw = MonoWorker()
    f1 = mw.submit(func, 1, 2, 3, e)
    f2 = mw.submit(func, 4, 5, 6, e)
    f3 = mw.submit(func, 7, 8, 9, e)
    time.sleep(0.1)
    assert f1.cancelled()
    assert f2.cancelled()
    assert not f3.cancelled()
    e.set()
    assert f3.result() == 7 + 8 + 9

# Generated at 2022-06-18 11:36:47.483706
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.05)
    for i in _range(10):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:36:54.089757
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import current_thread
    from concurrent.futures import as_completed
    from tqdm import tqdm

    def test_func(i):
        sleep(0.1)
        return i, current_thread()

    mw = MonoWorker()
    for i in tqdm(range(10)):
        mw.submit(test_func, i)
    for f in as_completed(mw.futures):
        print(f.result())

# Generated at 2022-06-18 11:37:05.765248
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from .utils import _range
    from .utils import _timeit

    def _test_MonoWorker_submit(n, sleep):
        mw = MonoWorker()
        for i in _range(n):
            mw.submit(time.sleep, sleep)
        time.sleep(sleep)
        return mw

    def _test_MonoWorker_submit_with_tqdm(n, sleep):
        mw = MonoWorker()
        for i in tqdm_auto.tqdm(_range(n)):
            mw.submit(time.sleep, sleep)
        time.sleep(sleep)
        return mw

    n = 10
    sleep = 0.1
    mw = _test_MonoWorker_submit(n, sleep)

# Generated at 2022-06-18 11:37:15.211084
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from ..utils import _range

    def wait_for_event(event, timeout):
        """Wait for event to be set, or timeout"""
        event.wait(timeout)
        return event.is_set()

    def wait_for_event_with_tqdm(event, timeout):
        """Wait for event to be set, or timeout"""
        for _ in tqdm_auto(_range(timeout)):
            if event.is_set():
                break
            sleep(1)
        return event.is_set()

    def wait_for_event_with_tqdm_and_cancel(event, timeout):
        """Wait for event to be set, or timeout"""

# Generated at 2022-06-18 11:37:19.188585
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)
    time.sleep(1)

# Generated at 2022-06-18 11:37:28.255732
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    import unittest

    class TestMonoWorker(unittest.TestCase):
        def test_submit(self):
            def func(x):
                time.sleep(random.random())
                return x

            mw = MonoWorker()
            for i in range(10):
                mw.submit(func, i)
            time.sleep(0.1)
            self.assertEqual(len(mw.futures), 1)
            self.assertEqual(mw.futures[0].result(), 9)

        def test_submit_cancel(self):
            def func(x):
                time.sleep(random.random())
                return x

            mw = MonoWorker()

# Generated at 2022-06-18 11:37:37.477047
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event

    def wait(t, e):
        e.wait()
        time.sleep(t)
        return t

    mw = MonoWorker()
    e = Event()
    e.set()
    assert mw.submit(wait, 1, e).result() == 1
    e.clear()
    assert mw.submit(wait, 2, e).result() == 2
    e.set()
    assert mw.submit(wait, 3, e).result() == 3
    e.clear()
    assert mw.submit(wait, 4, e).result() == 4
    e.set()
    assert mw.submit(wait, 5, e).result() == 5
    e.clear()
    assert mw.submit(wait, 6, e).result() == 6
    e

# Generated at 2022-06-18 11:37:49.259532
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Lock
    from multiprocessing import Process

    def worker(lock, mono, i):
        with lock:
            tqdm_auto.write("{} started".format(i))
        sleep(random())
        with lock:
            tqdm_auto.write("{} finished".format(i))

    lock = Lock()
    mono = MonoWorker()
    for i in range(10):
        mono.submit(worker, lock, mono, i)
    sleep(1)
    mono.submit(worker, lock, mono, "last")
    sleep(1)

    def worker_process(lock, mono, i):
        with lock:
            tqdm_auto.write("{} started".format(i))
        sleep(random())

# Generated at 2022-06-18 11:37:58.859214
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    mw.submit(f, 1)
    mw.submit(f, 2)
    mw.submit(f, 3)
    mw.submit(f, 4)
    mw.submit(f, 5)
    mw.submit(f, 6)
    mw.submit(f, 7)
    mw.submit(f, 8)
    mw.submit(f, 9)
    mw.submit(f, 10)
    mw.submit(f, 11)
    mw.submit(f, 12)
    mw.submit(f, 13)
    mw.submit(f, 14)
   

# Generated at 2022-06-18 11:38:02.228419
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)

# Generated at 2022-06-18 11:38:09.782648
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from . import tqdm_test_module

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    assert mw.submit(func, 0.1)
    assert mw.submit(func, 0.2)
    assert mw.submit(func, 0.3)
    assert mw.submit(func, 0.4)
    assert mw.submit(func, 0.5)
    assert mw.submit(func, 0.6)
    assert mw.submit(func, 0.7)
    assert mw.submit(func, 0.8)
    assert mw.submit(func, 0.9)
    assert mw.submit(func, 1.0)
    assert mw.submit(func, 1.1)
   

# Generated at 2022-06-18 11:38:19.734893
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up

    def wait(t):
        time.sleep(t)
        return t

    mw = MonoWorker()
    assert mw.submit(wait, 0.1)
    assert mw.submit(wait, 0.2)
    assert mw.submit(wait, 0.3)
    assert mw.submit(wait, 0.4)
    assert mw.submit(wait, 0.5)
    assert mw.submit(wait, 0.6)
    assert mw.submit(wait, 0.7)
    assert mw.submit(wait, 0.8)
    assert mw.submit(wait, 0.9)
    assert mw.submit(wait, 1.0)
    assert mw.submit(wait, 1.1)
   

# Generated at 2022-06-18 11:38:24.837003
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def _test_func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(_test_func, i)
    for i in _range(10):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:38:35.821031
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from threading import Event
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def test_submit(self):
            def func(x):
                time.sleep(x)
                return x

            def func_exception(x):
                raise Exception("Exception")

            def func_cancel(x):
                time.sleep(x)
                return x

            def func_cancel_exception(x):
                time.sleep(x)
                raise Exception("Exception")

            def func_cancel_exception_2(x):
                time.sleep(x)
                raise Exception("Exception")

            def func_cancel_exception_3(x):
                time.sleep(x)
                raise Exception("Exception")


# Generated at 2022-06-18 11:38:38.205276
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from .utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
    assert mw.futures[0].result() == 9

# Generated at 2022-06-18 11:38:43.599247
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Thread
    from queue import Queue

    def worker(q, i):
        sleep(0.1)
        q.put(i)

    q = Queue()
    mw = MonoWorker()
    for i in range(5):
        mw.submit(worker, q, i)
    for i in range(5):
        assert q.get() == i



# Generated at 2022-06-18 11:38:49.137467
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(i):
        time.sleep(0.01)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
    for i in _range(10):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:38:57.542688
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)
    assert mw.futures[0].result() == 9

# Generated at 2022-06-18 11:39:05.837731
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from itertools import count
    from threading import Lock
    from concurrent.futures import as_completed

    def func(i):
        sleep(random())
        return i

    def test(n):
        mw = MonoWorker()
        futures = [mw.submit(func, i) for i in range(n)]
        assert len(futures) == n
        assert len(mw.futures) == 1
        assert futures[-1] == mw.futures[0]
        assert futures[-1].done()
        assert futures[-1].result() == n - 1
        assert len(mw.pool._threads) == 1
        assert len(mw.pool._work_queue) == 0
        assert mw.pool._

# Generated at 2022-06-18 11:39:13.121230
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase

    class Test(TestCase):
        def setUp(self):
            self.mw = MonoWorker()
            self.ev = Event()

        def test_submit(self):
            def func(x):
                self.ev.wait()
                return x
            f1 = self.mw.submit(func, 1)
            f2 = self.mw.submit(func, 2)
            self.assertEqual(f1.result(), 1)
            self.assertEqual(f2.result(), 2)
            self.assertEqual(f1.result(), 1)
            self.assertEqual(f2.result(), 2)

# Generated at 2022-06-18 11:39:20.429433
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Thread
    from queue import Queue

    def func(arg):
        sleep(0.1)
        return arg

    def test_func(arg):
        sleep(0.1)
        return arg

    def test_func_exception(arg):
        sleep(0.1)
        raise Exception('test_func_exception')

    def test_func_cancel(arg):
        sleep(0.1)
        return arg

    def test_func_cancel_exception(arg):
        sleep(0.1)
        raise Exception('test_func_cancel_exception')

    def test_func_cancel_exception_2(arg):
        sleep(0.1)
        raise Exception('test_func_cancel_exception_2')


# Generated at 2022-06-18 11:39:28.666091
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Lock
    from multiprocessing import cpu_count
    from concurrent.futures import ThreadPoolExecutor

    def func(x, y, z):
        sleep(random())
        return x + y + z

    def test_submit(n):
        mw = MonoWorker()
        lock = Lock()
        with ThreadPoolExecutor(max_workers=cpu_count()) as pool:
            for _ in range(n):
                pool.submit(mw.submit, func, 1, 2, z=3)
                with lock:
                    assert len(mw.futures) <= 1
            for _ in range(n):
                with lock:
                    assert len(mw.futures) <= 1

# Generated at 2022-06-18 11:39:37.656806
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Lock
    from queue import Queue
    from concurrent.futures import Future

    def func(x):
        time.sleep(x)
        return x

    def test_func(x):
        time.sleep(x)
        return x

    def test_func_exception(x):
        time.sleep(x)
        raise Exception("test_func_exception")

    def test_func_cancel(x):
        time.sleep(x)
        return x

    def test_func_cancel_exception(x):
        time.sleep(x)
        raise Exception("test_func_cancel_exception")

    def test_func_cancel_exception_2(x):
        time.sleep(x)

# Generated at 2022-06-18 11:39:40.825178
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.01)

# Generated at 2022-06-18 11:39:43.507442
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)

# Generated at 2022-06-18 11:39:47.246013
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from ..utils import _range

    def test_func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(test_func, i)
    assert len(mw.futures) == 1
    assert isinstance(mw.futures[0], Future)
    assert mw.futures[0].result() == 9

# Generated at 2022-06-18 11:39:59.269288
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from multiprocessing import Process
    from multiprocessing.connection import Listener, Client

    def _test_MonoWorker_submit(e, f, l):
        mw = MonoWorker()
        e.wait()
        f.set()
        mw.submit(l.accept)
        mw.submit(l.accept)
        mw.submit(l.accept)
        mw.submit(l.accept)
        mw.submit(l.accept)
        mw.submit(l.accept)
        mw.submit(l.accept)
        mw.submit(l.accept)
        mw.submit(l.accept)
        mw.submit(l.accept)
        mw.submit

# Generated at 2022-06-18 11:40:14.610819
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from concurrent.futures import wait
    from tqdm.contrib.concurrent import MonoWorker

    def func(x):
        sleep(x)
        return x

    def test_func(x):
        sleep(x)
        return x

    def test_func_exception(x):
        sleep(x)
        raise Exception("test_func_exception")

    def test_func_lock(x, lock):
        sleep(x)
        with lock:
            return x

    def test_func_lock_exception(x, lock):
        sleep(x)
        with lock:
            raise Exception("test_func_lock_exception")

    def test_func_lock_exception_2(x, lock):
        sleep(x)
       

# Generated at 2022-06-18 11:40:25.121309
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Lock
    from concurrent.futures import as_completed
    from ..utils import _range

    def f(x):
        sleep(random())
        return x

    def g(x):
        sleep(random())
        raise Exception("{}".format(x))

    def h(x):
        sleep(random())
        raise KeyboardInterrupt()

    def i(x):
        sleep(random())
        raise StopIteration()

    def j(x):
        sleep(random())
        raise GeneratorExit()

    def k(x):
        sleep(random())
        raise SystemExit()

    def l(x):
        sleep(random())
        raise MemoryError()

    def m(x):
        sleep(random())
        raise RuntimeError()

   

# Generated at 2022-06-18 11:40:30.879877
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def _test_func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(_test_func, i)
        time.sleep(0.05)
    time.sleep(0.5)
    assert mw.futures[0].result() == 9

# Generated at 2022-06-18 11:40:38.042152
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Thread
    from queue import Queue
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def setUp(self):
            self.q = Queue()
            self.mw = MonoWorker()

        def test_submit(self):
            def f(x):
                sleep(x)
                self.q.put(x)
            self.mw.submit(f, 0.5)
            self.mw.submit(f, 0.1)
            self.mw.submit(f, 0.2)
            self.mw.submit(f, 0.3)
            self.mw.submit(f, 0.4)
            self.assertEqual(self.q.get(), 0.1)
            self.assertE

# Generated at 2022-06-18 11:40:44.510622
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import as_completed

    def wait(seconds):
        time.sleep(seconds)
        return seconds

    def wait_cancel(seconds, cancel):
        time.sleep(seconds)
        cancel.wait()
        return seconds

    def wait_cancel_exception(seconds, cancel):
        time.sleep(seconds)
        cancel.wait()
        raise Exception("Cancelled")

    worker = MonoWorker()
    cancel = Event()
    assert worker.submit(wait, 1) == worker.submit(wait, 2)
    assert worker.submit(wait, 3) == worker.submit(wait, 4)
    assert worker.submit(wait, 5) == worker.submit(wait, 6)
    assert worker.submit(wait, 7) == worker.submit

# Generated at 2022-06-18 11:40:51.671986
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import as_completed

    def func(x, y, z):
        sleep(x)
        return x + y + z

    def test(x, y, z, expected):
        mw = MonoWorker()
        future = mw.submit(func, x, y, z)
        assert future.result() == expected

    test(1, 2, 3, 6)
    test(1, 2, 3, 6)
    test(1, 2, 3, 6)
    test(1, 2, 3, 6)

    mw = MonoWorker()
    future = mw.submit(func, 1, 2, 3)
    assert future.result() == 6
    future = mw.submit(func, 1, 2, 3)


# Generated at 2022-06-18 11:40:54.601081
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
    for i in _range(10):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:41:01.580708
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    f1 = mw.submit(func, 1)
    f2 = mw.submit(func, 2)
    f3 = mw.submit(func, 3)
    f4 = mw.submit(func, 4)
    f5 = mw.submit(func, 5)
    f6 = mw.submit(func, 6)
    f7 = mw.submit(func, 7)
    f8 = mw.submit(func, 8)
    f9 = mw.submit(func, 9)
    f10 = mw.submit(func, 10)
    f11 = mw.submit(func, 11)
   

# Generated at 2022-06-18 11:41:09.892458
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase

    class Test(TestCase):
        def setUp(self):
            self.worker = MonoWorker()
            self.event = Event()
            self.event.clear()
            self.futures = []

        def tearDown(self):
            for future in self.futures:
                future.cancel()

        def test_submit(self):
            def func(i):
                self.event.wait()
                return i

            for i in range(5):
                future = self.worker.submit(func, i)
                self.futures.append(future)
                self.assertIsInstance(future, Future)

            self.event.set()
            time.sleep(0.1)

# Generated at 2022-06-18 11:41:17.244690
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from ..utils import _range

    def _test_submit(n, sleep=0.1):
        mw = MonoWorker()
        for i in _range(n):
            mw.submit(time.sleep, sleep)
        assert len(mw.futures) == 1
        assert isinstance(mw.futures[0], Future)
        mw.futures[0].result()

    _test_submit(1)
    _test_submit(2)
    _test_submit(3)
    _test_submit(4)
    _test_submit(5)
    _test_submit(6)
    _test_submit(7)
    _test_submit(8)
    _test_submit(9)
    _test_

# Generated at 2022-06-18 11:41:41.538963
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future

    def _test_func(i, wait_event):
        wait_event.wait()
        return i

    def _test_func_exception(i, wait_event):
        wait_event.wait()
        raise Exception(i)

    def _test_func_cancel(i, wait_event):
        wait_event.wait()
        return i

    def _test_func_cancel_exception(i, wait_event):
        wait_event.wait()
        raise Exception(i)

    def _test_func_cancel_exception_ignore(i, wait_event):
        wait_event.wait()
        raise Exception(i)


# Generated at 2022-06-18 11:41:45.239813
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
    assert mw.futures[0].result() == 9

# Generated at 2022-06-18 11:41:53.645309
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def test_submit(self):
            def func(x, y, z):
                sleep(0.1)
                return x + y + z

            mw = MonoWorker()
            self.assertEqual(len(mw.futures), 0)
            f1 = mw.submit(func, 1, 2, 3)
            self.assertEqual(len(mw.futures), 1)
            self.assertEqual(f1.result(), 6)
            self.assertEqual(len(mw.futures), 0)
            f2 = mw.submit(func, 4, 5, 6)
            self

# Generated at 2022-06-18 11:42:04.284293
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    mw.submit(f, 1)
    mw.submit(f, 2)
    mw.submit(f, 3)
    mw.submit(f, 4)
    mw.submit(f, 5)
    mw.submit(f, 6)
    mw.submit(f, 7)
    mw.submit(f, 8)
    mw.submit(f, 9)
    mw.submit(f, 10)
    mw.submit(f, 11)
    mw.submit(f, 12)
    mw.submit(f, 13)
    mw.submit(f, 14)
   

# Generated at 2022-06-18 11:42:14.480992
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    mw.submit(f, 1)
    mw.submit(f, 2)
    mw.submit(f, 3)
    mw.submit(f, 4)
    mw.submit(f, 5)
    mw.submit(f, 6)
    mw.submit(f, 7)
    mw.submit(f, 8)
    mw.submit(f, 9)
    mw.submit(f, 10)
    mw.submit(f, 11)
    mw.submit(f, 12)
    mw.submit(f, 13)
    mw.submit(f, 14)
   

# Generated at 2022-06-18 11:42:22.405333
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(5):
        mw.submit(f, i)
        time.sleep(0.1)

    for i in _range(5):
        mw.submit(f, i)
        time.sleep(0.1)

    for i in _range(5):
        mw.submit(f, i)
        time.sleep(0.1)

    for i in _range(5):
        mw.submit(f, i)
        time.sleep(0.1)

    for i in _range(5):
        mw.submit(f, i)
        time.sleep(0.1)


# Generated at 2022-06-18 11:42:31.946572
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event

    def wait_and_set(event, timeout):
        time.sleep(timeout)
        event.set()

    e1 = Event()
    e2 = Event()
    e3 = Event()
    e4 = Event()
    e5 = Event()
    e6 = Event()

    mw = MonoWorker()
    mw.submit(wait_and_set, e1, 0.1)
    mw.submit(wait_and_set, e2, 0.2)
    mw.submit(wait_and_set, e3, 0.3)
    mw.submit(wait_and_set, e4, 0.4)
    mw.submit(wait_and_set, e5, 0.5)

# Generated at 2022-06-18 11:42:40.737208
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from . import _test_MonoWorker_submit

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    assert mw.submit(f, 0.1) is not None
    assert mw.submit(f, 0.2) is not None
    assert mw.submit(f, 0.3) is not None
    assert mw.submit(f, 0.4) is not None
    assert mw.submit(f, 0.5) is not None
    assert mw.submit(f, 0.6) is not None
    assert mw.submit(f, 0.7) is not None
    assert mw.submit(f, 0.8) is not None
    assert mw.submit(f, 0.9) is not None


# Generated at 2022-06-18 11:42:48.589344
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    from concurrent.futures import Future
    from ..utils import _range

    def _test_submit(n, m, sleep_time=0.01, sleep_time_max=0.1):
        """
        Test `MonoWorker.submit` with `n` tasks and `m` threads.
        """
        def _test_task(i):
            time.sleep(random.random() * sleep_time_max)
            return i

        def _test_thread(i):
            time.sleep(random.random() * sleep_time_max)
            return i

        def _test_thread_submit(i):
            time.sleep(random.random() * sleep_time_max)
            return i


# Generated at 2022-06-18 11:42:52.155474
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random

    def func(x):
        sleep(random() / 10)
        return x

    mw = MonoWorker()
    for i in range(10):
        mw.submit(func, i)
    for i in range(10):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:43:45.024001
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    import multiprocessing
    from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor

    def test_submit(executor, sleep_time=0.1):
        """
        Test that the most recent submitted task is the one that runs.
        """
        def func(i):
            time.sleep(sleep_time)
            return i

        def run_submit(i):
            return executor.submit(func, i)

        def run_submit_with_sleep(i):
            time.sleep(sleep_time)
            return executor.submit(func, i)

        def run_submit_with_sleep_and_cancel(i):
            time.sleep(sleep_time)
            future = executor.submit(func, i)
            time.sleep

# Generated at 2022-06-18 11:43:48.098831
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)

# Generated at 2022-06-18 11:43:56.507022
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase

    class Test(TestCase):
        def test_submit(self):
            def func(x):
                time.sleep(x)
                return x

            def func_error(x):
                raise ValueError(x)

            def func_cancel(x):
                e = Event()
                e.wait()
                return x

            def func_cancel_error(x):
                e = Event()
                e.wait()
                raise ValueError(x)

            def func_cancel_error_cancel(x):
                e = Event()
                e.wait()
                raise ValueError(x)

            def func_cancel_error_cancel_error(x):
                e = Event()


# Generated at 2022-06-18 11:44:01.327421
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
    time.sleep(0.5)
    assert mw.futures[0].done()
    assert mw.futures[1].done()
    assert mw.futures[0].result() == 9
    assert mw.futures[1].result() == 9

# Generated at 2022-06-18 11:44:04.667519
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(5):
        mw.submit(func, i)
        time.sleep(0.1)
    time.sleep(1)

# Generated at 2022-06-18 11:44:08.304276
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.05)

# Generated at 2022-06-18 11:44:16.922126
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading

    def f(x):
        time.sleep(random.random() / 10)
        return x

    mw = MonoWorker()
    for i in range(10):
        mw.submit(f, i)
    time.sleep(0.1)
    assert len(mw.futures) == 1
    assert mw.futures[0].result() == 9
    time.sleep(0.1)
    assert len(mw.futures) == 0

    def g(x):
        time.sleep(random.random() / 10)
        return x

    mw = MonoWorker()
    for i in range(10):
        mw.submit(g, i)
    time.sleep(0.1)

# Generated at 2022-06-18 11:44:23.817324
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from threading import Event

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    f1 = mw.submit(func, 1)
    assert isinstance(f1, Future)
    assert f1.running()
    assert not f1.done()
    assert f1.result() == 1
    assert f1.done()

    f2 = mw.submit(func, 2)
    assert f2.running()
    assert not f2.done()
    assert f2.result() == 2
    assert f2.done()

    f3 = mw.submit(func, 3)
    assert f3.running()
    assert not f3.done()
    assert f3.result() == 3


# Generated at 2022-06-18 11:44:32.862938
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import sys

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    mw.submit(f, 1)
    mw.submit(f, 2)
    mw.submit(f, 3)
    mw.submit(f, 4)
    mw.submit(f, 5)
    mw.submit(f, 6)
    mw.submit(f, 7)
    mw.submit(f, 8)
    mw.submit(f, 9)
    mw.submit(f, 10)
    mw.submit(f, 11)
    mw.submit(f, 12)
    mw.submit(f, 13)
    mw.submit(f, 14)

# Generated at 2022-06-18 11:44:40.670131
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def slow_square(x):
        time.sleep(.1)
        return x ** 2

    def slow_cube(x):
        time.sleep(.1)
        return x ** 3

    def slow_factorial(x):
        time.sleep(.1)
        if x <= 1:
            return 1
        else:
            return x * slow_factorial(x - 1)

    def slow_fibonacci(x):
        time.sleep(.1)
        if x <= 1:
            return 1
        else:
            return slow_fibonacci(x - 1) + slow_fibonacci(x - 2)

    def slow_fibonacci_iter(x):
        time.sleep(.1)
        a, b = 1

# Generated at 2022-06-18 11:46:24.654163
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import TimeoutError

    def wait_for_event(event, timeout):
        event.wait(timeout)
        if not event.is_set():
            raise TimeoutError("event not set")

    def wait_for_event_with_timeout(event, timeout):
        try:
            wait_for_event(event, timeout)
        except TimeoutError:
            return False
        else:
            return True

    def wait_for_event_with_timeout_and_cancel(event, timeout):
        try:
            wait_for_event(event, timeout)
        except TimeoutError:
            return False
        else:
            return True
