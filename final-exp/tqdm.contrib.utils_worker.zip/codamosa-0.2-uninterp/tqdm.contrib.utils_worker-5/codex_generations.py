

# Generated at 2022-06-18 11:36:33.886625
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from ..utils import _range

    def _test_submit(func, *args, **kwargs):
        mw = MonoWorker()
        for _ in _range(10):
            mw.submit(func, *args, **kwargs)
        for _ in _range(10):
            time.sleep(0.1)
            assert len(mw.futures) == 1
            assert isinstance(mw.futures[0], Future)
            assert not mw.futures[0].done()
        mw.futures[0].result()
        assert mw.futures[0].done()

    def _test_submit_cancel(func, *args, **kwargs):
        mw = MonoWorker()

# Generated at 2022-06-18 11:36:44.240958
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    from concurrent.futures import as_completed

    def func(x):
        time.sleep(random.random())
        return x

    mw = MonoWorker()
    futures = []
    for i in range(10):
        futures.append(mw.submit(func, i))
    for f in as_completed(futures):
        assert f.result() == 9

    # Test that the waiting task is the most recent submitted
    futures = []
    for i in range(10):
        futures.append(mw.submit(func, i))
    for f in as_completed(futures):
        assert f.result() == 9

    # Test that the waiting task is the most recent submitted
    # even if it is submitted after the running task
   

# Generated at 2022-06-18 11:36:54.451769
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from unittest.mock import Mock

    def func(x):
        time.sleep(x)
        return x

    def test_submit(x, y, z, expected_result):
        """
        Test that the result of func(x) is expected_result.
        """
        mw = MonoWorker()
        fx = mw.submit(func, x)
        fy = mw.submit(func, y)
        fz = mw.submit(func, z)
        assert fx.result() == expected_result
        assert fy.result() == expected_result
        assert fz.result() == expected_result

    test_submit(1, 2, 3, 3)

# Generated at 2022-06-18 11:37:06.243104
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from ..utils import format_sizeof

    def wait_and_return(seconds, return_value):
        time.sleep(seconds)
        return return_value

    def wait_and_raise(seconds, exception):
        time.sleep(seconds)
        raise exception

    def wait_and_return_after_event(seconds, return_value, event):
        event.wait(seconds)
        return return_value

    def wait_and_raise_after_event(seconds, exception, event):
        event.wait(seconds)
        raise exception

    def test_submit(func, *args, **kwargs):
        worker = MonoWorker()
        future = worker.submit(func, *args, **kwargs)
        assert future.done() == False
        future.result()

# Generated at 2022-06-18 11:37:15.463604
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import as_completed

    def func(x, y, z, e):
        sleep(x)
        e.set()
        return x + y + z

    e = Event()
    mw = MonoWorker()
    f1 = mw.submit(func, 1, 2, 3, e)
    f2 = mw.submit(func, 2, 3, 4, e)
    f3 = mw.submit(func, 3, 4, 5, e)
    f4 = mw.submit(func, 4, 5, 6, e)
    e.wait()
    assert f1.cancelled()
    assert f2.cancelled()
    assert not f3.cancelled()
    assert not f4.cance

# Generated at 2022-06-18 11:37:21.332333
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    from threading import Lock

    def func(i, lock):
        time.sleep(random.random())
        with lock:
            tqdm_auto.write("{}".format(i))

    lock = Lock()
    mw = MonoWorker()
    for i in range(10):
        mw.submit(func, i, lock)
        time.sleep(random.random())

# Generated at 2022-06-18 11:37:29.084306
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event

    def func(x, y, z, e):
        time.sleep(x)
        e.set()
        return x + y + z

    e = Event()
    mw = MonoWorker()
    assert mw.submit(func, 0.5, 1, 2, e)
    assert mw.submit(func, 0.5, 1, 2, e)
    assert mw.submit(func, 0.5, 1, 2, e)
    assert mw.submit(func, 0.5, 1, 2, e)
    assert mw.submit(func, 0.5, 1, 2, e)
    assert mw.submit(func, 0.5, 1, 2, e)

# Generated at 2022-06-18 11:37:33.686891
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
        time.sleep(0.1)
    assert mw.futures[0].result() == 9

# Generated at 2022-06-18 11:37:40.516284
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Lock
    from multiprocessing import Process

    def func(x, y, z, lock):
        sleep(random())
        with lock:
            print('func({}, {}, {})'.format(x, y, z))

    lock = Lock()
    worker = MonoWorker()
    for i in range(10):
        Process(target=worker.submit,
                args=(func, i, i, i, lock)).start()
    sleep(1)
    print('Done')

# Generated at 2022-06-18 11:37:50.386876
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import as_completed
    from unittest import TestCase

    class Test(TestCase):
        def test(self):
            def func(x, y, z):
                sleep(x)
                return x + y + z

            mw = MonoWorker()
            ev = Event()
            ev.wait(0.1)
            self.assertFalse(ev.is_set())
            mw.submit(ev.set)
            ev.wait(0.1)
            self.assertTrue(ev.is_set())
            ev.clear()
            ev.wait(0.1)
            self.assertFalse(ev.is_set())
            mw.submit(ev.set)
            mw.submit(ev.set)
           

# Generated at 2022-06-18 11:38:02.268888
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import TimeoutError
    from ..utils import _range

    def slow_inc(x):
        time.sleep(0.1)
        return x + 1

    def slow_exc(x):
        time.sleep(0.1)
        raise ValueError(x)

    def slow_exc_timeout(x):
        time.sleep(0.1)
        raise TimeoutError(x)

    def slow_exc_cancel(x):
        time.sleep(0.1)
        raise TimeoutError(x)

    def slow_exc_cancel_2(x):
        time.sleep(0.1)
        raise TimeoutError(x)

    def slow_exc_cancel_3(x):
        time.sleep(0.1)
        raise TimeoutError

# Generated at 2022-06-18 11:38:09.820461
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from ..utils import _range

    def wait(t, e):
        e.wait()
        return t

    def wait_and_raise(t, e):
        e.wait()
        raise Exception("{}".format(t))

    def wait_and_cancel(t, e):
        e.wait()
        raise Exception("{}".format(t))

    def wait_and_cancel_and_raise(t, e):
        e.wait()
        raise Exception("{}".format(t))

    def wait_and_cancel_and_raise_and_cancel(t, e):
        e.wait()
        raise Exception("{}".format(t))


# Generated at 2022-06-18 11:38:19.735799
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up
    from ..utils import _range

    def func(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
        tqdm_auto.write("{}".format(i))
        _term_move_up()
    for i in _range(10):
        mw.submit(func, i)
        tqdm_auto.write("{}".format(i))
        _term_move_up()
    for i in _range(10):
        mw.submit(func, i)
        tqdm_auto.write("{}".format(i))
        _term_move_up()

# Generated at 2022-06-18 11:38:30.636631
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event

    def wait_for_event(event, timeout=None):
        event.wait(timeout)
        return event.is_set()

    def wait_for_event_with_timeout(event, timeout=None):
        return wait_for_event(event, timeout)

    def wait_for_event_without_timeout(event, timeout=None):
        return wait_for_event(event)

    def wait_for_event_with_timeout_and_args(event, timeout=None, *args, **kwargs):
        return wait_for_event(event, timeout)

    def wait_for_event_with_timeout_and_kwargs(event, timeout=None, **kwargs):
        return wait_for_event(event, timeout)


# Generated at 2022-06-18 11:38:38.116863
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Lock
    from concurrent.futures import as_completed
    from tqdm.contrib.concurrency import MonoWorker

    def worker(i, lock):
        sleep(random())
        with lock:
            tqdm_auto.write("{} finished".format(i))

    lock = Lock()
    mw = MonoWorker()
    for i in range(10):
        mw.submit(worker, i, lock)
    for f in as_completed(mw.futures):
        f.result()

# Generated at 2022-06-18 11:38:48.368765
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import TimeoutError

    def func(x, y, z):
        sleep(x)
        return x + y + z

    def test_func(x, y, z, e):
        e.wait()
        return func(x, y, z)

    e = Event()
    mw = MonoWorker()
    f1 = mw.submit(test_func, 1, 2, 3, e)
    f2 = mw.submit(test_func, 2, 3, 4, e)
    f3 = mw.submit(test_func, 3, 4, 5, e)
    assert f1.done()
    assert f2.done()
    assert not f3.done()
    assert f2.result() == 9
   

# Generated at 2022-06-18 11:38:59.053484
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Lock
    from concurrent.futures import Future
    from ..utils import _range

    def func(x):
        time.sleep(0.1)
        return x

    def test_submit(n, m):
        """Test `MonoWorker.submit` with `n` threads and `m` tasks."""
        mw = MonoWorker()
        lock = Lock()
        results = []
        for i in _range(m):
            with lock:
                results.append(mw.submit(func, i))

        for i in _range(m):
            assert isinstance(results[i], Future)
            assert results[i].result() == i

    test_submit(1, 1)
    test_submit(1, 2)
    test_submit(1, 3)
   

# Generated at 2022-06-18 11:39:04.179052
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from ..utils import _range

    def func(i, evt):
        evt.wait()
        sleep(0.1)
        return i

    evt = Event()
    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i, evt)
    evt.set()
    assert mw.futures[0].result() == 9

# Generated at 2022-06-18 11:39:07.963311
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def test_func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(test_func, i)
        time.sleep(0.05)
    assert mw.futures[0].result() == 9
    assert mw.futures[1].result() == 8

# Generated at 2022-06-18 11:39:14.105899
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event

    def wait_for_event(event):
        event.wait()
        return True

    def wait_for_time(seconds):
        time.sleep(seconds)
        return True

    def wait_for_time_and_event(seconds, event):
        time.sleep(seconds)
        event.wait()
        return True

    def wait_for_time_and_event_and_raise(seconds, event):
        time.sleep(seconds)
        event.wait()
        raise Exception("Raised")

    def wait_for_time_and_event_and_raise_and_return(seconds, event):
        time.sleep(seconds)
        event.wait()
        raise Exception("Raised")
        return True


# Generated at 2022-06-18 11:39:23.830984
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def slow_square(x):
        time.sleep(0.1)
        return x ** 2

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(slow_square, i)
    time.sleep(0.5)
    assert mw.futures[0].result() == 81

# Generated at 2022-06-18 11:39:33.206807
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event

    def wait(duration):
        time.sleep(duration)

    def wait_and_set(duration, event):
        time.sleep(duration)
        event.set()

    def wait_and_raise(duration):
        time.sleep(duration)
        raise Exception("test")

    def wait_and_return(duration, value):
        time.sleep(duration)
        return value

    def wait_and_return_and_set(duration, value, event):
        time.sleep(duration)
        event.set()
        return value

    def wait_and_return_and_raise(duration, value):
        time.sleep(duration)
        raise Exception("test")
        return value


# Generated at 2022-06-18 11:39:36.621199
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.05)

# Generated at 2022-06-18 11:39:44.054047
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up

    def test_func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    f1 = mw.submit(test_func, 1)
    f2 = mw.submit(test_func, 2)
    f3 = mw.submit(test_func, 3)
    f4 = mw.submit(test_func, 4)
    f5 = mw.submit(test_func, 5)
    f6 = mw.submit(test_func, 6)
    f7 = mw.submit(test_func, 7)
    f8 = mw.submit(test_func, 8)
    f9 = mw.submit(test_func, 9)

# Generated at 2022-06-18 11:39:48.985033
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def _test(n):
        time.sleep(n)
        return n

    mw = MonoWorker()
    for i in _range(5):
        mw.submit(_test, i)
    time.sleep(0.1)
    assert mw.futures[0].result() == 4

# Generated at 2022-06-18 11:40:00.571688
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    mw.submit(f, 1)
    mw.submit(f, 2)
    mw.submit(f, 3)
    mw.submit(f, 4)
    mw.submit(f, 5)
    mw.submit(f, 6)
    mw.submit(f, 7)
    mw.submit(f, 8)
    mw.submit(f, 9)
    mw.submit(f, 10)
    mw.submit(f, 11)
    mw.submit(f, 12)
    mw.submit(f, 13)
    mw.submit(f, 14)
    mw.submit(f, 15)
    m

# Generated at 2022-06-18 11:40:10.350781
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from concurrent.futures import Future
    from unittest import TestCase, main

    class TestMonoWorker(TestCase):
        def setUp(self):
            self.mw = MonoWorker()
            self.lock = Lock()
            self.counter = 0

        def test_submit(self):
            def incr(n):
                with self.lock:
                    self.counter += n
                    sleep(0.1)
                    self.counter -= n
            for i in range(10):
                self.mw.submit(incr, 1)
            sleep(0.5)
            self.assertEqual(self.counter, 0)


# Generated at 2022-06-18 11:40:15.278231
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Thread
    from queue import Queue

    def func(i):
        sleep(i)
        return i

    def test_func(i, q):
        q.put(i)

    def test_submit(i, q):
        mw = MonoWorker()
        mw.submit(test_func, i, q)

    q = Queue()
    for i in range(5):
        Thread(target=test_submit, args=(i, q)).start()
    for i in range(5):
        assert q.get() == 4

# Generated at 2022-06-18 11:40:26.120078
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import TimeoutError
    from .utils import TestCase

    class TestMonoWorker(TestCase):
        def test_submit(self):
            def f(x):
                time.sleep(x)
                return x

            mw = MonoWorker()
            self.assertEqual(len(mw.futures), 0)
            mw.submit(f, 0.1)
            self.assertEqual(len(mw.futures), 1)
            mw.submit(f, 0.2)
            self.assertEqual(len(mw.futures), 1)
            self.assertEqual(mw.futures[0].result(), 0.2)
            mw.submit(f, 0.3)

# Generated at 2022-06-18 11:40:33.602454
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def _test_submit(n):
        """
        Test that `MonoWorker.submit` works as expected.
        """
        def _test_func(i):
            time.sleep(0.1)
            return i

        mw = MonoWorker()
        for i in _range(n):
            mw.submit(_test_func, i)
        for i in _range(n):
            assert mw.futures[i].result() == i

    _test_submit(1)
    _test_submit(2)
    _test_submit(3)

# Generated at 2022-06-18 11:40:50.341890
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase

    class MonoWorkerTest(TestCase):
        def test_submit(self):
            def func(x, y, z, e):
                e.wait()
                return x + y + z

            e = Event()
            mw = MonoWorker()
            f1 = mw.submit(func, 1, 2, 3, e)
            f2 = mw.submit(func, 4, 5, 6, e)
            self.assertIsInstance(f1, Future)
            self.assertIsInstance(f2, Future)
            self.assertEqual(f1, f2)
            self.assertFalse(f1.done())
            self.assertFalse(f2.done())

# Generated at 2022-06-18 11:40:56.136788
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from ..utils import _term_move_up

    def wait_for_event(event, timeout=None):
        """
        Wait for event to be set or timeout to expire.
        """
        if timeout is None:
            while not event.is_set():
                time.sleep(0.1)
        else:
            while not event.wait(timeout):
                time.sleep(0.1)

    def test_func(event, timeout=None):
        """
        Wait for event to be set or timeout to expire.
        """
        wait_for_event(event, timeout)
        return "test_func"


# Generated at 2022-06-18 11:41:04.278041
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import Future
    from unittest import TestCase

    class Test(TestCase):
        def test_submit(self):
            def f(x):
                time.sleep(x)
                return x

            mw = MonoWorker()
            f1 = mw.submit(f, 1)
            f2 = mw.submit(f, 2)
            f3 = mw.submit(f, 3)
            self.assertEqual(f1.result(), 1)
            self.assertEqual(f2.result(), 2)
            self.assertEqual(f3.result(), 3)

            # test cancel
            f1 = mw.submit(f, 1)
            f2 = mw.submit(f, 2)

# Generated at 2022-06-18 11:41:09.031947
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Thread
    from concurrent.futures import as_completed

    def func(x):
        sleep(random())
        return x

    mw = MonoWorker()
    futures = []
    for i in range(10):
        futures.append(mw.submit(func, i))
        sleep(random())

    for f in as_completed(futures):
        assert f.result() == 9

# Generated at 2022-06-18 11:41:12.343510
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.05)

# Generated at 2022-06-18 11:41:19.064844
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    from concurrent.futures import as_completed
    from ..utils import _range

    def wait(t):
        time.sleep(t)
        return t

    def wait_random():
        return wait(random.random())

    def wait_random_with_exception():
        if random.random() < 0.5:
            raise Exception("Random exception")
        else:
            return wait_random()

    def wait_random_with_cancel():
        if random.random() < 0.5:
            raise Exception("Random exception")
        else:
            return wait_random()

    def wait_random_with_cancel_and_exception():
        if random.random() < 0.5:
            raise Exception("Random exception")
        else:
            return wait

# Generated at 2022-06-18 11:41:28.002213
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Lock
    from concurrent.futures import as_completed
    from tqdm.contrib.concurrency import MonoWorker

    def test_func(x):
        sleep(random() * 0.1)
        return x

    lock = Lock()
    mw = MonoWorker()
    futures = [mw.submit(test_func, i) for i in range(10)]
    for f in as_completed(futures):
        with lock:
            tqdm_auto.write(str(f.result()))
    assert len(mw.futures) == 1
    assert mw.futures[0].done()
    assert mw.futures[0].result() == 9

# Generated at 2022-06-18 11:41:33.795528
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    mw.submit(f, 1)
    mw.submit(f, 2)
    mw.submit(f, 3)
    mw.submit(f, 4)
    mw.submit(f, 5)
    mw.submit(f, 6)
    mw.submit(f, 7)
    mw.submit(f, 8)
    mw.submit(f, 9)
    mw.submit(f, 10)
    mw.submit(f, 11)
    mw.submit(f, 12)
    mw.submit(f, 13)
    mw.submit(f, 14)
   

# Generated at 2022-06-18 11:41:43.147589
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import as_completed

    def test_func(i, wait_event):
        wait_event.wait()
        return i

    wait_event = Event()
    wait_event.clear()

    mw = MonoWorker()
    futures = [mw.submit(test_func, i, wait_event) for i in range(5)]

    # Check that only one task is running
    assert len([f for f in futures if f.running()]) == 1
    # Check that the running task is the last one
    assert futures[-1].running()

    # Check that the other tasks are waiting
    assert len([f for f in futures if not f.done()]) == 1
    assert not futures[-2].done()

    # Check that the other tasks are

# Generated at 2022-06-18 11:41:47.928216
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Lock
    from concurrent.futures import as_completed

    def test_func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    lock = Lock()
    with lock:
        for i in range(10):
            mw.submit(test_func, i)
        for future in as_completed(mw.futures):
            assert future.result() == 9

# Generated at 2022-06-18 11:42:09.925319
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.05)
    for i in _range(10):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:42:18.056795
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event

    def func(x, y, z, e):
        e.wait()
        return x + y + z

    e = Event()
    mw = MonoWorker()
    f1 = mw.submit(func, 1, 2, 3, e)
    f2 = mw.submit(func, 4, 5, 6, e)
    f3 = mw.submit(func, 7, 8, 9, e)
    assert f1.done()
    assert f2.done()
    assert not f3.done()
    e.set()
    time.sleep(0.1)
    assert f3.result() == 24

# Generated at 2022-06-18 11:42:23.513440
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from multiprocessing import Value
    from concurrent.futures import as_completed

    lock = Lock()
    counter = Value('i', 0)

    def inc():
        with lock:
            counter.value += 1
            sleep(0.1)
            counter.value -= 1

    mw = MonoWorker()
    futures = []
    for _ in range(10):
        futures.append(mw.submit(inc))
        sleep(0.01)
    for future in as_completed(futures):
        future.result()
    assert counter.value == 0

# Generated at 2022-06-18 11:42:27.354468
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)
    time.sleep(1)

# Generated at 2022-06-18 11:42:31.447557
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func(x):
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(func, i)
        time.sleep(0.05)

# Generated at 2022-06-18 11:42:40.282835
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading

    def f(x):
        time.sleep(random.random() / 10)
        return x

    mw = MonoWorker()
    for i in range(10):
        mw.submit(f, i)
    time.sleep(0.1)
    assert len(mw.futures) == 1
    assert mw.futures[0].result() == 9

    mw = MonoWorker()
    for i in range(10):
        mw.submit(f, i)
        time.sleep(0.01)
    time.sleep(0.1)
    assert len(mw.futures) == 1
    assert mw.futures[0].result() == 9

    mw = MonoWorker()

# Generated at 2022-06-18 11:42:48.025097
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from threading import Lock
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def setUp(self):
            self.mw = MonoWorker()
            self.lock = Lock()
            self.futures = []

        def test_submit(self):
            def func(i):
                with self.lock:
                    self.futures.append(i)
                time.sleep(0.1)
                return i

            for i in range(10):
                self.mw.submit(func, i)

            for i in range(10):
                self.assertEqual(self.futures[i], i)


# Generated at 2022-06-18 11:42:55.824662
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def wait(n):
        time.sleep(n)
        return n

    def wait_and_raise(n):
        time.sleep(n)
        raise Exception('wait_and_raise')

    def wait_and_cancel(n):
        time.sleep(n)
        raise Exception('wait_and_cancel')

    def wait_and_cancel_and_raise(n):
        time.sleep(n)
        raise Exception('wait_and_cancel_and_raise')

    def wait_and_cancel_and_raise_and_cancel(n):
        time.sleep(n)
        raise Exception('wait_and_cancel_and_raise_and_cancel')


# Generated at 2022-06-18 11:43:02.476206
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up
    from ..std import time as time_std

    def func(n):
        time.sleep(n)
        return n

    def test_func(n):
        with tqdm_auto.tqdm(total=n, desc='test_func') as t:
            for i in range(n):
                time.sleep(1)
                t.update()

    mw = MonoWorker()
    mw.submit(func, 1)
    mw.submit(func, 2)
    mw.submit(func, 3)
    mw.submit(func, 4)
    mw.submit(func, 5)
    mw.submit(func, 6)
    mw.submit(func, 7)

# Generated at 2022-06-18 11:43:07.700198
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import as_completed
    from tqdm import tqdm

    def wait(seconds, event=None):
        """Wait for `seconds` seconds, then set `event`."""
        sleep(seconds)
        if event:
            event.set()

    # Test 1: waiting task is replaced by a new task
    worker = MonoWorker()
    event = Event()
    worker.submit(wait, 1, event)
    worker.submit(wait, 0.5)
    assert not event.is_set()
    sleep(1)
    assert event.is_set()

    # Test 2: waiting task is not replaced by a new task
    worker = MonoWorker()
    event = Event()
    worker.submit(wait, 1, event)


# Generated at 2022-06-18 11:43:51.186947
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)
    assert mw.futures[0].result() == 9

# Generated at 2022-06-18 11:43:57.380950
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    from concurrent.futures import as_completed
    from ..utils import format_sizeof

    def test_func(x):
        time.sleep(random.random())
        return x

    mw = MonoWorker()
    futures = [mw.submit(test_func, i) for i in range(10)]
    for future in as_completed(futures):
        print(format_sizeof(future.result()))

if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-18 11:44:00.136805
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(i):
        time.sleep(i)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.5)

# Generated at 2022-06-18 11:44:08.402200
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    from ..utils import _range

    def _test_func(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(_test_func, i)
        time.sleep(0.01)
    for i in _range(10):
        assert mw.futures[i].result() == i

    def _test_func_err(i):
        time.sleep(0.1)
        raise ValueError(i)

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(_test_func_err, i)
        time.sleep(0.01)
    for i in _range(10):
        assert mw.f

# Generated at 2022-06-18 11:44:16.991243
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(3):
        mw.submit(f, i)
    for i in _range(3):
        mw.submit(f, i)
    for i in _range(3):
        mw.submit(f, i)
    for i in _range(3):
        mw.submit(f, i)
    for i in _range(3):
        mw.submit(f, i)
    for i in _range(3):
        mw.submit(f, i)
    for i in _range(3):
        mw.submit(f, i)
    for i in _range(3):
        m

# Generated at 2022-06-18 11:44:21.548463
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    with tqdm_auto.tqdm(total=10, desc='test_MonoWorker_submit') as t:
        for i in _range(10):
            mw.submit(f, i)
            t.update()
            _term_move_up()
            time.sleep(0.1)

# Generated at 2022-06-18 11:44:29.933886
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range
    from ..std import time as time_std

    def f(x):
        time_std.sleep(x)
        return x

    def g(x):
        time_std.sleep(x)
        raise Exception(x)

    def h(x):
        time_std.sleep(x)
        return x

    def i(x):
        time_std.sleep(x)
        raise Exception(x)

    def j(x):
        time_std.sleep(x)
        return x

    def k(x):
        time_std.sleep(x)
        raise Exception(x)

    def l(x):
        time_std.sleep(x)
        return x

    def m(x):
        time_std.sleep(x)
        raise Exception

# Generated at 2022-06-18 11:44:34.552371
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
    for i in _range(10):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:44:38.770122
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)

    for i in _range(10):
        mw.submit(f, i)
        time.sleep(0.1)

# Generated at 2022-06-18 11:44:45.735380
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import as_completed
    from tqdm.contrib.concurrent import MonoWorker

    def f(x, e):
        sleep(x)
        e.set()

    e = Event()
    mw = MonoWorker()
    mw.submit(f, 1, e)
    mw.submit(f, 0.5, e)
    mw.submit(f, 0.1, e)
    mw.submit(f, 0.01, e)
    mw.submit(f, 0.001, e)
    mw.submit(f, 0.0001, e)
    mw.submit(f, 0.00001, e)
    mw.submit(f, 0.000001, e)
   

# Generated at 2022-06-18 11:46:11.498631
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import TimeoutError

    def test_func(i, sleep_time, event):
        sleep(sleep_time)
        event.set()
        return i

    def test_func_exception(i, sleep_time, event):
        sleep(sleep_time)
        event.set()
        raise Exception("test_func_exception")

    def test_func_timeout(i, sleep_time, event):
        sleep(sleep_time)
        event.set()
        return i

    def test_func_timeout_exception(i, sleep_time, event):
        sleep(sleep_time)
        event.set()
        raise Exception("test_func_timeout_exception")


# Generated at 2022-06-18 11:46:15.881766
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random

    def f(x):
        sleep(random())
        return x

    mw = MonoWorker()
    for i in range(10):
        mw.submit(f, i)
    for i in range(10):
        assert mw.futures[i].result() == i

# Generated at 2022-06-18 11:46:24.831375
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from threading import Event

    def _test_submit(mw, func, *args, **kwargs):
        """
        Test `mw.submit(func, *args, **kwargs)` and return the future.
        """
        e = Event()
        def _func(*args, **kwargs):
            e.wait()
            return func(*args, **kwargs)
        f = mw.submit(_func, *args, **kwargs)
        assert isinstance(f, Future)
        assert not f.done()
        e.set()
        return f
