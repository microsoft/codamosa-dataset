

# Generated at 2022-06-23 18:58:29.482725
# Unit test for method __repr__ of class Environment

# Generated at 2022-06-23 18:58:30.751386
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    x = Environment(program_name='http')
    print(x)


# Generated at 2022-06-23 18:58:39.655327
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == True
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stdout_encoding == 'utf8'
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == True
    assert env.stderr_encoding == 'utf8'
    assert env.colors == 256
    assert env.program_name == 'http'


# Generated at 2022-06-23 18:58:42.341594
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    pass



# Generated at 2022-06-23 18:58:51.954665
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    from httpie import ExitStatus
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.utils import VERSION
    from urllib3 import disable_warnings; disable_warnings()
    from urllib3.exceptions import InsecureRequestWarning
    from httpie import ExitStatus
    from httpie.compat import is_windows
    from httpie.config import Config
    from httpie.utils import VERSION
    program_name = 'http'
    devnull = open(os.devnull, 'w+')
    stdin = sys.stdin
    stdin_isatty = stdin.isatty()
    stdout = sys.stdout
    stdout_isatty = stdout.isatty()

# Generated at 2022-06-23 18:58:57.567387
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    observed_value = []

    class StdErr:
        def write(self, msg):
            observed_value.append(msg)

    class Env:
        _orig_stderr = StdErr()
        program_name = 'http'

    env = Env()
    env.log_error("Test Message")
    expected_value = '\nhttp: error: Test Message\n\n'

    assert ''.join(observed_value) == expected_value

# Generated at 2022-06-23 18:59:03.643545
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    """
    要求:
    - `Environment` 实例可以用 `str(env)` 或 `repr(env)` 来打印
    - 打印出来是当前环境的配置
    - 这些配置可以通过关键字参数传递给 `Environment` 的构造函数来改变它们
    """
    # given
    env = Environment()
    import os

# Generated at 2022-06-23 18:59:14.643665
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    from .utils import MockEnvironment
    from .config import ConfigImpl
    from .help import BANNER

    mock_env = MockEnvironment(config = ConfigImpl())
    assert type(mock_env) == Environment
    assert str(mock_env) == '<Environment {\'config\': <ConfigImpl>}>'
    assert repr(mock_env) == '<Environment {\'config\': <ConfigImpl>}>'

    mock_env2 = MockEnvironment()
    assert str(mock_env2) == '<Environment {\'config\': <ConfigImpl>, \'program_name\': \'http\'}>'
    assert repr(mock_env2) == '<Environment {\'config\': <ConfigImpl>, \'program_name\': \'http\'}>'
    print(BANNER)

# Generated at 2022-06-23 18:59:24.851102
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    e = Environment()
    e.test = "test"

# Generated at 2022-06-23 18:59:34.123001
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment(stderr=open('./error/log_error.txt','w'))
    msg1 = 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.'
    env.log_error(msg1, 'warning')
    msg2 = "It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum."
    env.log_error(msg2)


if __name__ == "__main__":
    test_Environment_log_error()

# Generated at 2022-06-23 18:59:45.320613
# Unit test for constructor of class Environment
def test_Environment():
    fdno = os.open(os.devnull, os.O_RDONLY)
    devnull_stdin = os.fdopen(fdno, 'rb')
    custom_env = Environment(
        stdin=devnull_stdin,
        stdin_encoding='ascii',
        stdout=StringIO(),
        stdout_encoding='latin1',
        stderr=BytesIO(),
        program_name='httpie!!',
        config_dir=Path('/home/user/.config'),
    )
    assert custom_env.devnull is None
    assert custom_env.stdin is not sys.stdin
    assert custom_env.stdin is devnull_stdin
    assert custom_env.stdin_encoding == 'ascii'

# Generated at 2022-06-23 18:59:47.402607
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.devnull == open(os.devnull, 'w+')

# Generated at 2022-06-23 18:59:53.762851
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    assert repr(Environment(stdin='in', stdout='out', stderr='err')) == \
           "<Environment {'is_windows': False, 'stdin': 'in', 'stdin_isatty': False, 'stdin_encoding': None, 'stdout': 'out', 'stdout_isatty': False, 'stdout_encoding': None, 'stderr': 'err', 'stderr_isatty': False, 'colors': 256, 'program_name': 'http', 'config': <Config []>, 'config_dir': PosixPath('/home/jd/.config/httpie')}>"



# Generated at 2022-06-23 19:00:00.990574
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from httpie import ExitStatus
    from io import StringIO

    env = Environment()
    env._orig_stderr = StringIO()
    env.log_error('msg', level='error')
    assert env._orig_stderr.getvalue() == '\nhttp: error: msg\n\n'
    env._orig_stderr = StringIO()
    env.log_error('msg', level='warning')
    assert env._orig_stderr.getvalue() == '\nhttp: warning: msg\n\n'

# Generated at 2022-06-23 19:00:02.710213
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(foobar='foo')
    assert env.foobar == 'foo'

# Generated at 2022-06-23 19:00:05.629025
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(devnull=None)
    dict_ = dict(env)
    dict_['config'] = env.config
    assert str(env) == repr_dict(dict_)

# Generated at 2022-06-23 19:00:06.645385
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment() is not None


# Generated at 2022-06-23 19:00:10.352251
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    import sys
    env = Environment(
        stdin=open(os.devnull, 'rb'),
        stdout=sys.stdout,
        stderr=sys.stderr
    )
    print(env.__dict__)
    print(env)

# Generated at 2022-06-23 19:00:16.224344
# Unit test for constructor of class Environment
def test_Environment():
    environ = Environment(stdin=sys.stdin, stdout=sys.stdout,
            stderr=sys.stderr, config_dir=Path('/usr/local/lib/httpie'),
            colors = 256, is_windows = False)
    print(environ.stdin)
    print(environ.stdout)
    print(environ.stderr)
    print(environ.config_dir)
    print(environ.colors)
    print(environ.is_windows)

test_Environment()

# Generated at 2022-06-23 19:00:23.635878
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()

    assert '<Environment' in str(env)
    assert 'config_dir' in str(env)
    assert 'stdin' in str(env)
    assert 'stdin_isatty' in str(env)
    assert 'stdin_encoding' in str(env)
    assert 'stdout' in str(env)
    assert 'stdout_isatty' in str(env)
    assert 'stdout_encoding' in str(env)
    assert 'colors' in str(env)
    assert 'program_name' in str(env)

    env2 = Environment(program_name='HTTPie')
    assert 'HTTPie' in str(env2)

    assert '>' in str(env)


# Generated at 2022-06-23 19:00:25.734045
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    # stdout_isatty = False
    print(env)



# Generated at 2022-06-23 19:00:27.090398
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    assert repr(Environment()) == '<Environment {}>'



# Generated at 2022-06-23 19:00:36.075073
# Unit test for constructor of class Environment
def test_Environment():
    default = Environment()
    print('Default Environment: ', default)
    custom = Environment(
        devnull=sys.stdin,
        stdin=sys.stdin,
        stdin_isatty=False,
        stdin_encoding='utf8',
        stdout=sys.stdout,
        stdout_isatty=False,
        stdout_encoding='utf8',
        stderr=sys.stderr,
        stderr_isatty=False,
        colors=16,
        program_name='httpie',
    )
    print('Custom Environment: ', custom)

test_Environment()

# Generated at 2022-06-23 19:00:38.516410
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    environment = Environment()
    environment.log_error('Test Error Message')
    environment.log_error('Test Warning Message', level='warning')
    assert True

# Generated at 2022-06-23 19:00:48.210465
# Unit test for constructor of class Environment
def test_Environment():

    env = Environment()

    print(env.colors)
    print(env.config_dir)
    print(env.devnull)
    print(env.is_windows)
    print(env.program_name)
    print(env.stderr)
    print(env.stderr_isatty)
    print(env.stdin)
    print(env.stdin_encoding)
    print(env.stdin_isatty)
    print(env.stdout)
    print(env.stdout_encoding)
    print(env.stdout_isatty)


if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-23 19:00:49.906093
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    assert isinstance(str(env), str)

# Generated at 2022-06-23 19:00:57.432447
# Unit test for constructor of class Environment
def test_Environment():
    import io
    import tempfile

    f = io.BytesIO()

    # Create a temporary file
    temp = tempfile.TemporaryFile(mode='w+t')

    # Create the environment
    env = Environment(
        stdin=f,
        stdout=temp,
    )

    # Check if the environment created is an object of class Environment
    assert isinstance(env, Environment)

    # Check if the attributes are correctly set
    assert env.stdin is f
    assert env.stdout is temp

# Generated at 2022-06-23 19:00:58.598140
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()

# Generated at 2022-06-23 19:01:04.965114
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import StringIO
    stderr = StringIO()
    try:
        env = Environment(stderr=stderr)
        env.log_error('test', level='error')
        assert 'error: test' in stderr.getvalue()
        env.log_error('test', level='warning')
        assert 'warning: test' in stderr.getvalue()
    finally:
        stderr.close()

# Generated at 2022-06-23 19:01:13.487512
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    # Create a Environment object named env
    env = Environment()
    # Test if the attr stdout_isatty has been assigned to the right value
    assert env.stdout_isatty == True
    # Test the result of str() function

# Generated at 2022-06-23 19:01:24.137160
# Unit test for constructor of class Environment
def test_Environment():
    import io
    import sys
    import os
    import tempfile
    import shutil
    env = Environment(stdin = io.StringIO('hi'))
    os.environ['HOME'] = '~'
    os.environ['USERPROFILE'] = '/etc/'
    env.config_dir = tempfile.mkdtemp(suffix='httpie')
    env = Environment(config_dir = env.config_dir)
    temp = tempfile.mktemp(suffix='test')
    with open(temp, 'w') as f:
        f.write('aaa')
    env = Environment(config_dir = temp)
    shutil.rmtree(env.config_dir)
    env.config_dir = os.path.join(env.config_dir, '..', '..')

# Generated at 2022-06-23 19:01:31.881063
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    stdout = io.StringIO()
    stderr = io.StringIO()
    env = Environment(
        stdout=stdout,
        stderr=stderr,
        program_name='http_test'
    )
    msg="error"
    env.log_error(msg, level='error')
    env.log_error(msg, level='warning')

#if __name__=="__main__":
#    test_Environment_log_error()

# Generated at 2022-06-23 19:01:40.733490
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    stderr = io.StringIO()
    env = Environment(
        stderr=stderr,
        program_name='httpie_test_program'
    )
    env.log_error('Custom error')
    assert 'httpie_test_program: error: Custom error' in stderr.getvalue()

    stderr = io.StringIO()
    env = Environment(
        stderr=stderr,
        program_name='httpie_test_program'
    )
    env.log_error('Custom warning', level='warning')
    assert 'httpie_test_program: warning: Custom warning' in stderr.getvalue()

    # Test method throws assertion if level is not 'error' or 'warning'
    stderr = io.StringIO()

# Generated at 2022-06-23 19:01:47.670078
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import StringIO
    class Test(StringIO):
        def __init__(self, s):
            StringIO.__init__(self, s)
        def getvalue(self):
            return StringIO.getvalue(self)
    s = Test("")
    env = Environment()
    env.config_dir = DEFAULT_CONFIG_DIR
    env.stderr = s
    env.program_name = 'http'
    env.log_error("This is an error")
    expected = """http: error: This is an error
"""
    actual = s.getvalue()
    assert actual == expected

# Generated at 2022-06-23 19:01:49.253449
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    print(env.program_name)
    print(env.stderr_isatty)


# Generated at 2022-06-23 19:01:59.417730
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    expected = "<Environment {'colors': 256, 'config': <Config {}, 'program_name': 'http', 'stdin': <_io.TextIOWrapper name='<stdin>' mode='r' encoding='utf8'>, 'stdin_isatty': True, 'stdin_encoding': 'utf8', 'stdout': <_io.TextIOWrapper name='<stdout>' mode='w' encoding='utf8'>, 'stdout_isatty': True, 'stdout_encoding': 'utf8', 'stderr': <_io.TextIOWrapper name='<stderr>' mode='w' encoding='utf8'>, 'stderr_isatty': True, 'is_windows': False}>}>"
    assert repr(env) == expected



# Generated at 2022-06-23 19:02:11.577388
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    assert repr(env) == '<Environment {"colors": 256, "config": <Config []>, "is_windows": false, "program_name": "http", "stdin": <_io.TextIOWrapper name="<stdin>" mode="r" encoding="utf-8">, "stdin_encoding": "utf8", "stdin_isatty": true, "stdout": <_io.TextIOWrapper name="<stdout>" mode="w" encoding="utf-8">, "stdout_encoding": "utf8", "stdout_isatty": true, "stderr": <_io.TextIOWrapper name="<stderr>" mode="w" encoding="utf-8">, "stderr_isatty": true}>'



# Generated at 2022-06-23 19:02:15.998001
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment(
        program_name="Program",
        stderr=io.StringIO(),
    )
    env.log_error("Test")
    assert env.stderr.getvalue() == '\nProgram: error: Test\n\n'


# Generated at 2022-06-23 19:02:27.254643
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()

# Generated at 2022-06-23 19:02:33.646863
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    print(env)
    env = Environment(devnull=None, stdin=None, stdin_isatty=False, stdin_encoding=None, stdout=None, stdout_isatty=False, stdout_encoding=None, stderr=None, stderr_isatty=False, colors=256, program_name='http')
    print(env)



# Generated at 2022-06-23 19:02:36.605087
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment(stdout_isatty=True)
    assert e.stdout_isatty == True
    print(e)
    # assert False

test_Environment()

# Generated at 2022-06-23 19:02:45.817146
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    assert str(env) == "{'config': None, 'is_windows': False, 'stdin': <_io.TextIOWrapper name='<stdin>' encoding='utf8'>, 'stdin_isatty': True, 'stdin_encoding': 'utf8', 'stdout': <_io.TextIOWrapper name='<stdout>' encoding='utf8'>, 'stdout_isatty': True, 'stdout_encoding': 'utf8', 'stderr': <_io.TextIOWrapper name='<stderr>' encoding='utf8'>, 'stderr_isatty': True, 'program_name': 'http', 'colors': 256}"

# Generated at 2022-06-23 19:02:57.289075
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    # Act
    env = Environment(colors=256,  config_dir='path')
    result = env.__repr__()

    #Assert
    assert type(result) == str
    assert result == '<Environment {' + \
        '"colors": 256, ' + \
        '"config": <Config {\'config_dir\': \'path\'}>, ' + \
        '"stdin_isatty": False, ' + \
        '"stderr_isatty": True, ' + \
        '"stdout_isatty": True, ' + \
        '"is_windows": false, ' + \
        '"program_name": "http", ' + \
        '"config_dir": \'path\'}>'

# Generated at 2022-06-23 19:03:08.004937
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = httpie.environment.Environment()
    actual = str(env)

# Generated at 2022-06-23 19:03:15.487493
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    assert all(key in str(env) for key in ['colors', 'config', 
        'is_windows', 'program_name', 'stderr', 'stdin', 'stdout'])
    assert not any(key in str(env) for key in ['_devnull', '_orig_stderr'])
    assert str(type(env)) == '<class httpie.context.Environment>'


# Generated at 2022-06-23 19:03:19.768025
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    environment = Environment()
    msg = 'test_Environment_log_error'
    # print to stderr by default
    if hasattr(environment, '_orig_stderr'):
        environment._orig_stderr = sys.stderr
    environment.log_error(msg)
    assert True


env = Environment()

# Generated at 2022-06-23 19:03:31.034089
# Unit test for method __repr__ of class Environment

# Generated at 2022-06-23 19:03:33.889913
# Unit test for method log_error of class Environment
def test_Environment_log_error():
	newEnv = Environment()
	newEnv.log_error('Test message')
	newEnv.log_error('Test message', 'warning')
	
	assert True == True

# Generated at 2022-06-23 19:03:35.073523
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    pass



# Generated at 2022-06-23 19:03:44.939440
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    # Test for normal situations
    env = Environment()
    env.stderr = StringIO()
    env.log_error("Test: Test for normal situations")
    print(env.stderr.getvalue())
    assert env.stderr.getvalue() == "http: error: Test: Test for normal situations\n\n"

    # Test for variable "level"
    env.stderr = StringIO()
    env.log_error("Test: Test for variable level", "warning")
    print(env.stderr.getvalue())
    assert env.stderr.getvalue() == "http: warning: Test: Test for variable level\n\n"

# Generated at 2022-06-23 19:03:54.637646
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    os_name = "os_name"
    config_dir = "config_dir"
    stdin = "stdin"
    stdin_isatty = "stdin_isatty"
    stdin_encoding = "stdin_encoding"
    stdout = "stdout"
    stdout_isatty = "stdout_isatty"
    stdout_encoding = "stdout_encoding"
    stderr = "stderr"
    stderr_isatty = "stderr_isatty"
    colors = "colors"
    program_name = "program_name"


# Generated at 2022-06-23 19:03:59.974134
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(is_windows=True)
    assert(env.is_windows)

    env1 = Environment(config_dir = Path("./bin"))
    assert(env1.config_dir == Path("./bin"))

    class StdinClass:
        isatty = True

    stdin = StdinClass()
    env2 = Environment(stdin=stdin, stdin_encoding="ascii",
                       stdout=sys.stdout, stderr=sys.stderr)
    assert(env2.stdin_isatty)
    assert(env2.stdin_encoding == "ascii")

    env3 = Environment()
    assert(env3.stdout_isatty)
    assert(env3.stdout_encoding == 'utf8')


# Generated at 2022-06-23 19:04:04.598928
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env._devnull = None
    env.log_error('test error')

if __name__ == '__main__':
    env = Environment()
    env.log_error('test error')
    env.log_error('test warning', level='warning')

# Generated at 2022-06-23 19:04:12.479270
# Unit test for constructor of class Environment
def test_Environment():
    with Environment(devnull=None, is_windows=False,
                     config_dir=DEFAULT_CONFIG_DIR, stdin=sys.stdin,
                     stdin_isatty=sys.stdin.isatty(),
                     stdin_encoding=sys.stdin.encoding,
                     stdout=sys.stdout, stdout_isatty=sys.stdout.isatty(),
                     stdout_encoding=sys.stdout.encoding,
                     stderr=sys.stderr, stderr_isatty=sys.stderr.isatty(),
                     colors=256, program_name='http') as env:
        assert env is not None

# Generated at 2022-06-23 19:04:13.783145
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    DEFAULT_ENVIRONMENT = Environment()
    assert DEFAULT_ENVIRONMENT.__repr__() == '<Environment (config=None)>'

# Generated at 2022-06-23 19:04:25.167420
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        stdout=StringIO(), stderr=StringIO(),
        stdin_encoding='latin1', stdout_encoding='ascii'
    )
    if sys.version_info[0] < 3:
        expected_base_class_attrs = {
            '__doc__': None,
            '__module__': 'httpie.context',
            '_orig_stderr': sys.stderr,
            '_devnull': None,
            '_config': None,
        }

# Generated at 2022-06-23 19:04:34.369276
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import StringIO
    class stdout_object():
        def write(self, msg):
            if msg:
                assert msg == '\nhttp: error: msg1\n\n'

    class stdout_object2():
        def write(self, msg):
            if msg:
                assert msg == '\nhttp: warning: msg1\n\n'
    with open(os.devnull, 'w+') as devnull:
        class_object = Environment(devnull=devnull, stderr=stdout_object())
        class_object.log_error('msg1')
        class_object.log_error('msg1', level='warning')

# Generated at 2022-06-23 19:04:46.348241
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from httpie.core import main
    from httpie import ExitStatus

    results_list = []

    class EnvironmentMock(Environment):
        def __init__(self, devnull=None, **kwargs):
            super().__init__(devnull=devnull, **kwargs)

        def log_error(self, msg, level='error'):
            nonlocal results_list
            results_list.append([msg, level])

    devnull = open(os.devnull, 'w+')

    arguments = ['--debug']
    env_mock = EnvironmentMock(devnull=devnull)
    exit_status = main(arguments, env=env_mock)
    assert exit_status == ExitStatus.OK
    results_list_expected = [('request missing URL', 'error')]
    assert results_list == results

# Generated at 2022-06-23 19:04:54.372562
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    from io import open
    from tempfile import mkdtemp
    tempdir = mkdtemp()
    env = Environment(
        config_dir=tempdir,
        stdin=open(os.devnull),
        stdin_isatty=False,
        stdin_encoding='ascii',
        stdout=open(os.devnull),
        stdout_isatty=True,
        stdout_encoding='utf-8',
        stderr=open(os.devnull),
        stderr_isatty=True,
        colors=128,
        program_name='http-test',
    )

# Generated at 2022-06-23 19:04:55.547172
# Unit test for method log_error of class Environment
def test_Environment_log_error():

    e = Environment()
    e.log_error("This is a test")



# Generated at 2022-06-23 19:04:57.138428
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    environment = Environment()
    environment.log_error('')

# Generated at 2022-06-23 19:05:09.261630
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    """
    httpie/core.py
    ~~~~~~~~~~~~~~

    Tests for Environment

    :copyright: (c) 2020 Satoshi Tanimoto.
    :license: BSD, see LICENSE for more details.
    """
    import unittest

    class TestEnvironment(unittest.TestCase):
        def test_log_error_type(self):
            env = Environment()
            self.assertRaises(TypeError, env.log_error, 1)
            self.assertRaises(TypeError, env.log_error, 1, level='error')

        def test_log_error_value(self):
            env = Environment()
            self.assertRaises(AssertionError, env.log_error, 'test', level='test')

    unittest.main()

# Generated at 2022-06-23 19:05:15.461277
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import StringIO
    env = Environment(
        program_name='test',
        stderr=StringIO(),
    )
    env.log_error('test')
    assert env.stderr.getvalue() == '\ntest: error: test\n\n'

    env.stderr.close()
# !

environ = Environment()


# Generated at 2022-06-23 19:05:20.639420
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    stderr = sys.stderr
    sys.stderr = io.StringIO()
    env = Environment()
    env.log_error("I am an error")
    assert sys.stderr.getvalue() == "\nhttp: error: I am an error\n\n"
    sys.stderr = stderr


env = Environment()

# Generated at 2022-06-23 19:05:24.375231
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    arg_level = "error"
    print(arg_level)
    env = Environment()
    env.log_error('test',level=arg_level)
    #env.log_error('test', level='warning')

# Generated at 2022-06-23 19:05:35.658314
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from httpie.compat import is_windows
    from httpie import ExitStatus
    import shutil

    def remove_config_dir():
        if Environment.config_dir.exists():
            shutil.rmtree(str(Environment.config_dir))

    remove_config_dir()

    env = Environment()
    config = env.config
    assert not Environment.config_dir.exists()

    # Test case 1
    # Write to stderr if config is new
    assert config.is_new()
    env.log_error('this is a error')
    remove_config_dir()

    # Test case 2
    # Write to stderr if config file is invalid
    env.config_dir.mkdir(parents=True, exist_ok=True)

# Generated at 2022-06-23 19:05:45.647309
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        stdin= open(os.devnull),
        stdout= open(os.devnull),
        stderr= open(os.devnull)
    )
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == open(os.devnull)
    assert env.stdin_isatty == False
    assert env.stdin_encoding == None
    assert env.stdout == open(os.devnull)
    assert env.stdout_isatty == False
    assert env.stdout_encoding == None
    assert env.stderr == open(os.devnull)
    assert env.stderr_isatty == False
    assert env.program_name == 'http'
    assert env

# Generated at 2022-06-23 19:05:56.178550
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    # scenario 1
    env = Environment()

# Generated at 2022-06-23 19:06:07.083280
# Unit test for constructor of class Environment
def test_Environment():
    import sys
    import os
    from pathlib import Path
    from typing import IO, Optional

    try:
        import curses
    except ImportError:
        curses = None  # Compiled w/o curses

    from httpie.config import DEFAULT_CONFIG_DIR, Config, ConfigFileError

    from httpie.utils import repr_dict

    Environment.is_windows = True
    Environment.config_dir = DEFAULT_CONFIG_DIR
    Environment.stdin = sys.stdin  # `None` when closed fd (#791)
    Environment.stdin_isatty = Environment.stdin.isatty() if Environment.stdin else False
    Environment.stdin_encoding = None
    Environment.stdout = sys.stdout
    Environment.stdout_isatty = Environment.stdout.isatty()


# Generated at 2022-06-23 19:06:17.080901
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    import sys

    import os

    import httpie.core

    env = httpie.core.Environment()

    env.config_dir = '/home/jovyan/.config/httpie'

    env.stdin = sys.stdin

    env.stdin_isatty = True

    env.stdin_encoding = 'utf-8'

    env.stdout = sys.stdout

    env.stdout_isatty = True

    env.stdout_encoding = 'cp1252'

    env.stderr = sys.stderr

    env.stderr_isatty = True

    env.colors = 256

    env.program_name = 'ht'


# Generated at 2022-06-23 19:06:26.100211
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
            is_windows=True,
            config_dir="./config",
            stdin=None,
            stdin_isatty=False,
            stdin_encoding=None,
            stdout=sys.stdout,
            stdout_isatty=True,
            stdout_encoding=None,
            stderr=sys.stderr,
            stderr_isatty=True,
            colors=256,
            program_name="http",
            devnull=None
            )

    assert env.is_windows == True
    assert env.config_dir == "./config"
    assert env.stdin == None
    assert env.stdin_isatty == False
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout


# Generated at 2022-06-23 19:06:33.612796
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    # Setup
    env = Environment()

# Generated at 2022-06-23 19:06:42.610271
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    test_msg = "test message"
    env.log_error(test_msg)
    assert env._orig_stderr.getvalue() == f'\n{env.program_name}: error: {test_msg}\n\n'
    env._orig_stderr.seek(0)
    env.log_error(test_msg, level='warning')
    assert env._orig_stderr.getvalue() == f'\n{env.program_name}: error: {test_msg}\n\n\n{env.program_name}: warning: {test_msg}\n\n'


# Generated at 2022-06-23 19:06:48.989199
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    import io
    import contextlib
    with contextlib.redirect_stdout(io.StringIO()) as str_stdout, \
            contextlib.redirect_stderr(io.StringIO()) as str_stderr, \
            contextlib.redirect_stdin(io.StringIO()) as str_stdin:
        env.log_error('error')
        assert str_stderr.getvalue().strip() == 'http: error: error'
        env.log_error('warning', level='warning')
        assert str_stderr.getvalue().strip() == 'http: warning: warning'

# Generated at 2022-06-23 19:07:01.326237
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    from httpie.config import UnsetType
    from httpie import __version__
    env = Environment()
    print(env.__repr__())

# Generated at 2022-06-23 19:07:11.426586
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    env_str = str(env)
    assert '{' in env_str and '}' in env_str
    assert 'is_windows' in env_str and 'None' in env_str
    assert 'config' in env_str and 'True' in env_str
    assert 'stdin' in env_str and 'None' in env_str
    assert 'stdin_isatty' in env_str and 'True' in env_str
    assert 'stdin_encoding' in env_str and "'utf-8'" in env_str
    assert 'stdout' in env_str and 'True' in env_str
    assert 'stdout_isatty' in env_str and 'True' in env_str
    assert 'stdout_encoding' in env_str and "'utf-8'"

# Generated at 2022-06-23 19:07:22.919957
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(stdin = sys.stdin)
    assert str(env) == "{'stdin': <_io.TextIOWrapper name='<stdin>' mode='r' encoding='UTF-8'>, 'stdin_isatty': True, 'stdin_encoding': 'UTF-8', 'stdout': <_io.TextIOWrapper name='<stdout>' mode='w' encoding='UTF-8'>, 'stdout_isatty': True, 'stdout_encoding': 'UTF-8', 'stderr': <_io.TextIOWrapper name='<stderr>' mode='w' encoding='UTF-8'>, 'stderr_isatty': True, 'colors': 256, 'program_name': 'http', 'config': None}"

# Generated at 2022-06-23 19:07:28.740802
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        stdin_isatty=True,
        config_dir='/foo',
        program_name='httpxyz',
        colors=16,
    )
    assert env.stdin_isatty
    assert env.config_dir == Path('/foo')
    assert env.program_name == 'httpxyz'
    assert env.colors == 16

# Generated at 2022-06-23 19:07:34.276710
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment(config_dir=Path('/Users/test'), stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr, program_name='test')
    assert Environment()
    assert Environment(program_name='test')
    assert Environment(program_name='test', stdin=sys.stdin)
    assert Environment(program_name='test', stdin=sys.stdin, stdout=sys.stdout)
    assert Environment(program_name='test', stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr)

# Generated at 2022-06-23 19:07:41.975635
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    env_ = (
        '<Environment '
        '{'
        'config: <Config {}>, '
        'is_windows: False, '
        'program_name: "http", '
        'stdin: <_io.TextIOWrapper '
        'encoding="utf8" '
        'name="<stdin>" '
        'mode="r" '
        'closed=False>}>'
    )
    assert repr(env) ==  env_



# Generated at 2022-06-23 19:07:52.156306
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from httpie.config import Config
    from httpie.context import Environment
    import sys
    import os
    from pathlib import Path


# Generated at 2022-06-23 19:07:53.793827
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():

    from httpie.core import Environment

    env = Environment()
    print(env)



# Generated at 2022-06-23 19:08:03.831094
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        program_name='httpie-1.2.3',
        stdin='not stdin',
        stdout='not stdout',
        stderr='not stderr',
        devnull='not devnull',
        is_windows=True,
        config_dir=Path('~/.config/httpie'),
    )

# Generated at 2022-06-23 19:08:15.539081
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(is_windows=False, config_dir='/root/.httpie', stdin=sys.stdin, stdin_encoding='utf-8', stdout=sys.stdout, stdout_encoding='utf-8', stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http', _orig_stderr=sys.stderr)

# Generated at 2022-06-23 19:08:16.362073
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment()



# Generated at 2022-06-23 19:08:17.675581
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    env.__repr__()



# Generated at 2022-06-23 19:08:20.946026
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment(stdout=sys.stdout)
    env.log_error('hello', level='error')
    env.log_error('hello', level='warning')
    
test_Environment_log_error()

# Generated at 2022-06-23 19:08:29.009621
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    dict_of_env = {}
    dict_of_env['is_windows'] = env.is_windows
    dict_of_env['config_dir'] = env.config_dir
    dict_of_env['stdin'] = env.stdin
    dict_of_env['stdin_isatty'] = env.stdin_isatty
    dict_of_env['stdin_encoding'] = env.stdin_encoding
    dict_of_env['stdout'] = env.stdout
    dict_of_env['stdout_isatty'] = env.stdout_isatty
    dict_of_env['stdout_encoding'] = env.stdout_encoding
    dict_of_env['stderr'] = env.stderr
    dict_of_env