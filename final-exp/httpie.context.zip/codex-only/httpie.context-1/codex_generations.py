

# Generated at 2022-06-23 18:58:20.515597
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    from .test_main import http
    env = http.Environment()
    assert str(env) == '<Environment {config: {}, is_windows: False, ...}>'

# Generated at 2022-06-23 18:58:28.858104
# Unit test for constructor of class Environment
def test_Environment():
   env = Environment(devnull=open(os.devnull, 'w+'), is_windows=True,
        config_dir=Path('abc'), stdin=sys.stdin, stdout=sys.stdout, 
        stderr=sys.stderr, colors=256, program_name='http')
   assert isinstance(env, Environment)
   assert env.is_windows == True
   assert env.config_dir == Path('abc')
   assert env.stdin == sys.stdin
   assert env.stdout == sys.stdout
   assert env.stderr == sys.stderr
   assert env.colors == 256
   assert env.program_name == 'http'
   assert env.stdin_encoding == 'utf8'
   assert env.stdout_encoding == 'utf8'

# Generated at 2022-06-23 18:58:38.420514
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=False,
              config_dir=DEFAULT_CONFIG_DIR,
              stdin=sys.stdin,
              stdin_isatty=sys.stdin.isatty(),
              stdin_encoding=sys.stdin.encoding,
              stdout=sys.stdout,
              stdout_isatty=sys.stdout.isatty(),
              stdout_encoding=sys.stdout.encoding,
              stderr=sys.stderr,
              stderr_isatty=sys.stderr.isatty())
    assert env.devnull == None
    assert env.is_windows == False
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
   

# Generated at 2022-06-23 18:58:49.545377
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    environ = Environment()

# Generated at 2022-06-23 18:58:58.566602
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=sys.stdin, config_dir='config_dir', stdin=sys.stdin, stdin_isatty=True, stdin_encoding='stdin_encoding', stdout=sys.stdout, stdout_isatty=True, stdout_encoding='stdout_encoding', stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http')
    assert env.is_windows == False
    assert env.config_dir == 'config_dir'
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == True
    assert env.stdin_encoding == 'stdin_encoding'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty

# Generated at 2022-06-23 18:59:05.444660
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from httpie.utils import StdoutBytesIO
    env = Environment()
    fp = StdoutBytesIO()
    env.stderr = fp
    env.log_error('error_msg',level="error")
    env.log_error('warning_msg',level="warning")
    assert fp.getvalue() == b'\nhttp: error: error_msg\n\n\nhttp: warning: warning_msg\n\n'

# Generated at 2022-06-23 18:59:07.501299
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    assert str(env)


# Generated at 2022-06-23 18:59:10.166773
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error(msg='This is an error', level='error')
    env.log_error(msg='This is a warning', level='warning')

# Generated at 2022-06-23 18:59:15.613822
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    out = io.StringIO()
    env.stderr = out
    env.log_error("testing")
    assert out.getvalue() == '\nhttp: error: testing\n\n'

    out = io.StringIO()
    env.stderr = out
    env.log_error("testing", level='warning')
    assert out.getvalue() == '\nhttp: warning: testing\n\n'

# Generated at 2022-06-23 18:59:17.928161
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    stdout = __import__('io').StringIO()
    env = Environment(stderr=stdout)
    msg = 'Some error'
    env.log_error(msg)
    output = stdout.getvalue()
    assert(output == '\nhttp: error: ' + msg + '\n\n')



# Generated at 2022-06-23 18:59:27.597255
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import os
    import sys
    import io

    # Create a StringIO object to capture output written to sys.stderr.
    # It will be automatically closed at the end of with statement.
    std_err = io.StringIO()
    # Save the reference to original sys.stderr.
    old_stderr = sys.stderr
    # Replace original sys.stderr with StringIO object.
    sys.stderr = std_err


# Generated at 2022-06-23 18:59:37.683601
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():

    import copy
    e = copy.deepcopy(Environment())
    actual = str(e)

# Generated at 2022-06-23 18:59:45.320574
# Unit test for constructor of class Environment
def test_Environment():

    #test for constructor
    Environment()

    #test for class variables
    assert Environment.is_windows == is_windows

    assert Environment.config_dir == DEFAULT_CONFIG_DIR

    assert Environment.stdin == sys.stdin

    assert Environment.stdin_isatty

    assert Environment.stdout_isatty

    assert Environment.stdout

    assert Environment.stdout_encoding

    assert Environment.stderr

    assert Environment.stderr_isatty

    assert Environment.colors == 256

    assert Environment.program_name == 'http'



# Generated at 2022-06-23 18:59:52.329304
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env._config is None
    assert env.config.__class__.__name__ == 'Config'
    assert env.config_dir == 'httpie'
    assert env.stdin is not None
    assert env.stdout is not None
    assert env.stderr is not None
    assert env.is_windows is False
    assert env.stdin_isatty is True
    assert env.stdout_isatty is True
    assert env.stderr_isatty is True
    assert env.colors == 256
    assert env.program_name == 'http'
    env2 = Environment(stdout = sys.stdout, stdin = sys.stdin)
    assert env2.stdout == sys.stdout
    assert env2.stdin == sys.stdin

# Generated at 2022-06-23 18:59:59.122403
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    import re

    out = io.StringIO()
    env = Environment(stderr=out)

    env.log_error('uh-oh', level='error')
    env.log_error('uh-oh', level='warning')

    out.seek(0)
    output = out.read()

    assert re.match(r'\nhttp:\s+error:\s+uh-oh\n\n\nhttp:\s+warning:\s+uh-oh\n\n', output)

# Generated at 2022-06-23 19:00:04.205407
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(is_windows=True,
                      config_dir="/path/to/config/dir",
                      stdin=None,
                      stdin_isatty=True,
                      stdin_encoding="utf8",
                      stdout=sys.stdout,
                      stdout_isatty=False,
                      stdout_encoding="utf8",
                      stderr=sys.stderr,
                      stderr_isatty=False,
                      colors=256,
                      program_name="httpie")
    env_str = str(env)

    # Check if all attribute names are in the string
    attrs = [attr for attr in env.__dict__ if not attr.startswith("_")]
    for attr in attrs:
        assert attr in env_str

    # Check if all

# Generated at 2022-06-23 19:00:13.348157
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment(devnull=True)
    env.program_name = 'http'
    env.stderr = io.StringIO()
    env.log_error('foo bar')
    assert env.stderr.getvalue() == '\nhttp: error: foo bar\n\n'
    env.stderr = io.StringIO()
    env.log_error('foo bar', level='warning')
    assert env.stderr.getvalue() == '\nhttp: warning: foo bar\n\n'
    env.stderr = io.StringIO()
    env.log_error(Exception('foo bar'))
    assert env.stderr.getvalue() == '\nhttp: error: foo bar\n\n'

# Generated at 2022-06-23 19:00:20.639225
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment(
        is_windows=False,
        config_dir=None,
        stdin=None,
        stdin_isatty=False,
        stdin_encoding=None,
        stdout=None,
        stdout_isatty=False,
        stdout_encoding=None,
        stderr=None,
        stderr_isatty=False,
        colors=256,
        program_name='http'
    )


# Generated at 2022-06-23 19:00:30.731404
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(stdout_encoding = "utf8", stdin_encoding = "utf8", stdout_isatty = True, stdin_isatty = True)
    result = env.__str__()

# Generated at 2022-06-23 19:00:35.456515
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import sys
    import io
    def raise_exception(msg):
        raise ValueError(msg)

    env = Environment(stderr=io.StringIO())
    try:
        raise_exception('abcde')
    except ValueError as e:
        env.log_error(e)

if __name__ == '__main__':
    test_Environment_log_error()

# Generated at 2022-06-23 19:00:46.992610
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()

# Generated at 2022-06-23 19:00:49.012777
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name='httpie2')
    assert env.program_name == 'httpie2'

# Generated at 2022-06-23 19:01:00.721543
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(
        stdin_encoding=None,
        stdout_encoding=None
    )
    result = str(env)

# Generated at 2022-06-23 19:01:03.084659
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    stdout = io.StringIO()
    stderr = io.StringIO()
    env = Environment(stdout = stdout, stderr = stderr)
    env.log_error(msg = 'hello')
    assert stderr.getvalue() == '\nhttp: error: hello\n\n'

# Generated at 2022-06-23 19:01:04.966737
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    # Assert Environment.__str__() does not raise any exception
    assert Environment()



# Generated at 2022-06-23 19:01:10.816633
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    print(env)
    print(env.config)
    print(env._devnull)
    print(env.log_error(msg = "msg", level = "error"))

# Test the case where there is no devnull
env = Environment(devnull = None)

# Test the case where there is devnull
dv = open(os.devnull, "w")
env = Environment(devnull = dv)

# Generated at 2022-06-23 19:01:21.945961
# Unit test for method __str__ of class Environment
def test_Environment___str__():

    env = Environment()


# Generated at 2022-06-23 19:01:31.830052
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    assert str(env) == '{\n  "colors": 256,\n  "config_dir": "/home/kajens/.config/httpie",\n  "config": "https://raw.githubusercontent.com/jakubroztocil/httpie/master/httpie/config.json",\n  "is_windows": false,\n  "program_name": "http",\n  "stderr_encoding": "utf8",\n  "stdin_encoding": "utf8",\n  "stdout_encoding": "utf8"\n}'



# Generated at 2022-06-23 19:01:34.908368
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    def mocked_stderr_write(msg):
        assert msg == '\nhttp: error: foo\n\n'

    env = Environment(stderr=open(os.devnull, 'w+'))
    env._orig_stderr.write = mocked_stderr_write
    env.log_error('foo')

env = Environment()

# Generated at 2022-06-23 19:01:42.130627
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    env.__dict__.update(dict(
        is_windows = True,
        config_dir = '.httpie/',
        stdin = sys.stdin,
        stdin_isatty = False,
        stdin_encoding = 'utf8',
        stdout = sys.stdout,
        stdout_isatty = True,
        stdout_encoding = 'utf8',
        stderr = sys.stderr,
        stderr_isatty = True,
        colors = 256,
        program_name = 'http',
    ))

# Generated at 2022-06-23 19:01:51.951986
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    obj = Environment()

# Generated at 2022-06-23 19:02:01.241307
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import StringIO, TextIOWrapper

    dev = StringIO()
    stderr = TextIOWrapper(dev, 'utf8', line_buffering=True)
    env = Environment(stderr=stderr, program_name='http')

    # Check error message - log_error(msg, 'error')
    env.log_error('msg', 'error')
    assert dev.getvalue() == '\nhttp: error: msg\n\n'

    # Check warning message - log_error(msg, 'warning')
    dev.truncate(0)
    env.log_error('msg', 'warning')
    assert dev.getvalue() == '\nhttp: warning: msg\n\n'

# Generated at 2022-06-23 19:02:13.271793
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()

# Generated at 2022-06-23 19:02:15.032291
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    print(env)
    assert 0


# Generated at 2022-06-23 19:02:26.118144
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment(test_Environment___repr__=True)

# Generated at 2022-06-23 19:02:37.395291
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == (
        getattr(sys.stdin, 'encoding', None) or 'utf8')
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == (
        getattr(sys.stdout, 'encoding', None) or 'utf8')
    assert env.stderr == sys.stderr

# Generated at 2022-06-23 19:02:42.304467
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment(program_name='http2')
    env.stderr = io.StringIO()
    env.log_error('Invalid response')
    print(env.stderr.getvalue())
    env.log_error('Invalid response', level='warning')
    print(env.stderr.getvalue())



# Generated at 2022-06-23 19:02:47.930422
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment(stderr=io.StringIO())
    msg = "Test"
    env.program_name = 'http'

    # Test default level
    env.log_error(msg)
    assert env.stderr.getvalue() == "\nhttp: error: Test\n\n"

    # Test with level
    env.log_error(msg, level="warning")
    assert env.stderr.getvalue() == "\nhttp: error: Test\n\n\nhttp: warning: Test\n\n"

# Generated at 2022-06-23 19:02:58.866267
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    test_env = Environment(stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr, config_dir=DEFAULT_CONFIG_DIR)
    test_env.stdin_encoding = 'utf8'
    test_env.stdout_encoding = 'utf8'
    result = test_env.__repr__()

# Generated at 2022-06-23 19:03:09.250555
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    assert env.__repr__() == '<Environment {\'colors\': 256, \'is_windows\': True, \'program_name\': \'http\', \'stdin\': <_io.TextIOWrapper name=\'<stdin>\' mode=\'r\' encoding=\'cp936\'>, \'stdin_encoding\': \'cp936\', \'stdin_isatty\': True, \'stdout_encoding\': \'utf8\', \'stderr\': <colorama.ansitowin32.StreamWrapper object at 0x0000000002871F98>, \'stderr_isatty\': True, \'stdout\': <colorama.ansitowin32.StreamWrapper object at 0x0000000002871F60>}>'

# Generated at 2022-06-23 19:03:19.960443
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    env.config_dir = Path("http://example.com")
    env.program_name = 'curl'
    env.stdin = sys.stdin
    env.stdout = sys.stdout
    env.stderr = sys.stderr

# Generated at 2022-06-23 19:03:24.570176
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(foo='bar')
    env_str = str(env)
    assert env_str == "{'colors': 256, 'foo': 'bar', 'is_windows': False, 'program_name': 'http', 'stderr_isatty': True, 'stdin_isatty': True, 'stdout_isatty': True}"

# Generated at 2022-06-23 19:03:36.025602
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    sampleEnv = Environment()
    sampleEnv.stdout_encoding = 'utf8'

# Generated at 2022-06-23 19:03:38.750061
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    assert repr(Environment()) == '<Environment {}>'


if __name__ == '__main__':
    test_Environment___repr__()

# Generated at 2022-06-23 19:03:43.174568
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()

# Generated at 2022-06-23 19:03:53.386849
# Unit test for constructor of class Environment
def test_Environment():
    from pathlib import Path
    from io import TextIOWrapper
    import sys

    env = Environment()
    assert env.is_windows == sys.platform.startswith('win')
    if env.is_windows:
        assert env.config_dir == Path(os.environ['APPDATA']) / 'httpie'
    else:
        assert env.config_dir == Path.home() / '.config/httpie'
    assert isinstance(env.stdin, TextIOWrapper)
    assert env.stdin.readable()
    assert not env.stdin.writeable()
    assert env.stdin_isatty == sys.stdin.isatty()
    assert isinstance(env.stdout, TextIOWrapper)
    assert env.stdout.writeable()
    assert not env.std

# Generated at 2022-06-23 19:03:54.798664
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    assert repr(Environment())[0] == '<'

# Generated at 2022-06-23 19:04:06.809510
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull = 'abc')
    assert env.devnull == 'abc'
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == True
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == True
    assert env.program_name == 'http'
    assert env.colors == 256
    assert env._orig_stderr == sys.stderr
    assert env.is_windows == True
    assert env._devnull == 'abc'


# Generated at 2022-06-23 19:04:13.782433
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    assert str(Environment(curses = None, config_dir = 'D:\\_configdir_', stdin = None, stdout = sys.stdout, stderr = sys.stderr, program_name = 'HTTPie')) == "{'colors': 256, 'config_dir': 'D:\\_configdir_', 'is_windows': True, 'program_name': 'HTTPie', 'stderr': <_io.TextIOWrapper name='<stderr>' mode='w' encoding='utf-8'>, 'stdin': None, 'stdin_isatty': False, 'stdout': <_io.TextIOWrapper name='<stdout>' mode='w' encoding='utf-8'>, 'stdout_isatty': True}"


# Generated at 2022-06-23 19:04:14.166694
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    assert str(Environment())

# Generated at 2022-06-23 19:04:21.483159
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()

    assert env.is_windows == True
    assert env.config_dir == Path.home() / '.httpie'
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.stderr_encoding == sys.stderr.encoding
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == sys.stdout.encoding
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == sys.stdin.encoding
    assert env.colors

# Generated at 2022-06-23 19:04:33.082448
# Unit test for method __str__ of class Environment

# Generated at 2022-06-23 19:04:40.477675
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull='/dev/null')
    assert(env.devnull == '/dev/null' and env.is_windows == is_windows
    and env.stdin == sys.stdin and env.stdout == sys.stdout
    and env.stderr == sys.stderr and env.config_dir == DEFAULT_CONFIG_DIR)
    #print(env)
    pass

# Generated at 2022-06-23 19:04:50.085830
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    e = Environment(
        config_dir=DEFAULT_CONFIG_DIR,
        stdin=sys.stdin,
        stdin_encoding='utf8',
        stdin_isatty=sys.stdin.isatty(),
        stdout=sys.stdout,
        stdout_encoding='utf8',
        stdout_isatty=sys.stdout.isatty(),
        stderr=sys.stderr,
        stderr_isatty=sys.stderr.isatty(),
        program_name="http"
    )

# Generated at 2022-06-23 19:04:59.178676
# Unit test for constructor of class Environment
def test_Environment():
    os.devnull = 'devnull'

    env = Environment(
        stdin=None,
        stdin_isatty=False,
        stdin_encoding=None,
        stdout=sys.stdout,
        stdout_encoding=None,
        stderr=sys.stderr,
        stderr_isatty=True,
        devnull='devnull',
        program_name='http',
        colors=8
    )

    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin is None
    assert env.stdin_isatty is False
    assert env.stdin_encoding is None
    assert env.stdout is sys.stdout
    assert env.stdout_isatty is True

# Generated at 2022-06-23 19:05:10.257540
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from httpie.utils import as_bytestring as ub
    from httpie.utils import write_pycurl_chunks
    sample_file = '/tmp/sample_file.txt'
    sample_data_1 = 'data_a'
    sample_data_2 = 'data_b'

    env = Environment()
    env.stdin = open(sample_file, 'w+')
    env.stdin.write(sample_data_1)
    env.stdin.flush()
    env.stdout = open(sample_file, 'w+')
    env.stdout.write(sample_data_2)
    env.stdout.flush()
    print(env)
    env.stdin = open(sample_file, 'r')
    env.stdout = open(sample_file, 'r')
   

# Generated at 2022-06-23 19:05:21.173020
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import StringIO
    from httpie import ExitStatus
    from httpie.context import Environment
    env = Environment(program_name='http')
    stderr = StringIO()
    env.stderr = env._orig_stderr = stderr
    env.log_error('this is an error', level='error')
    env.log_error('this is a warning', level='warning')
    env.log_error(ExitStatus.OK)
    assert stderr.getvalue() == '\nhttp: error: this is an error\n\n' \
                                '\nhttp: warning: this is a warning\n\n' \
                                '\nhttp: error: 0\n\n'

env = Environment()

# Generated at 2022-06-23 19:05:28.346412
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    # GIVEN: a new environment
    expected = """\
{
 'stderr': <_io.TextIOWrapper encoding='utf-8'>,
 'stderr_encoding': 'utf-8',
 'stderr_isatty': True,
 'stdin': <_io.TextIOWrapper encoding='utf-8'>,
 'stdin_encoding': 'utf-8',
 'stdin_isatty': True,
 'stdout': <_io.TextIOWrapper encoding='utf-8'>,
 'stdout_encoding': 'utf-8',
 'stdout_isatty': True
}"""
    # WHEN: the environment is printed
    actual = str(Environment())
    # THEN: the string is equal to the expected string
    assert actual == expected

# Generated at 2022-06-23 19:05:30.272390
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    # Setup
    A = Environment
    
    # Exercise
    ret1 = str(A())
    ret2 = repr(A())
    
    # Verify
    assert len(ret1) > 0
    assert len(ret2) > 0


# Generated at 2022-06-23 19:05:38.698920
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert hasattr(env, 'config')
    assert hasattr(env, 'config_dir')
    assert hasattr(env, 'colors')
    assert hasattr(env, 'is_windows')
    assert hasattr(env, 'isatty')
    assert hasattr(env, 'program_name')
    assert hasattr(env, '_config')
    assert hasattr(env, '_devnull')
    assert hasattr(env, 'devnull')
    assert hasattr(env, 'log_error')
    assert hasattr(env, 'stderr')
    assert hasattr(env, 'stdin')
    assert hasattr(env, 'stdin_encoding')
    assert hasattr(env, 'stdout')
    assert hasattr(env, 'stdout_encoding')
   

# Generated at 2022-06-23 19:05:46.967291
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(program_name="http", stdin_encoding="utf8")
    assert env.__str__() == "{'is_windows': False, 'stdin_encoding': 'utf8', 'stderr_isatty': True, 'stdout_isatty': True, 'stdout_encoding': None, 'stdin_isatty': False, 'program_name': 'http', 'stderr': <_io.StringIO object at 0x0000020D1A2C1D08>, 'colors': 256, 'stdout': <_io.StringIO object at 0x0000020D1A2C1B88>, 'config': None, 'stdin': <_io.StringIO object at 0x0000020D1A2C1948>}"

# Generated at 2022-06-23 19:05:57.516937
# Unit test for method __str__ of class Environment

# Generated at 2022-06-23 19:06:08.912248
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from httpie.core import _encode  # private
    from httpie.core import main  # used in Environment
    from httpie.output.streams import get_binary_stream
    from httpie.utils import FormatControl

    class MockEnvironment(Environment):
        config = None
        devnull = None
        stdin = None
        stdin_isatty = False
        stdin_encoding = None
        stdout = get_binary_stream('stdout')
        stdout_isatty = stdout.isatty()
        stdout_encoding = None
        stderr = get_binary_stream('stderr')
        stderr_isatty = stderr.isatty()
        colors = None
        program_name = 'http'

    env = MockEnvironment()

# Generated at 2022-06-23 19:06:14.758950
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment(stderr=__import__('io').StringIO())
    env.log_error('msg', 'error')
    assert env.stderr.getvalue().strip() == 'http: error: msg'
    env.log_error('msg', 'warning')
    assert env.stderr.getvalue().strip() == 'http: error: msg\nhttp: warning: msg'

# Generated at 2022-06-23 19:06:20.678051
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    from httpie.context import Environment
    env = Environment()
    env.log_error.__globals__['stdout'] = io.StringIO()
    assert len(env.log_error.__globals__['stdout'].getvalue().strip()) == 0
    env.log_error('Hello Test!','warning')
    assert Enviro

# Generated at 2022-06-23 19:06:29.450205
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from httpie.environment import Environment
    from unittest.mock import MagicMock
    import sys

    stderr = sys.stderr
    stderr = MagicMock()
    env = Environment(stderr=stderr)
    env.log_error("this is a test", level='error')
    env.log_error("this is a test", level='warning')
    assert stderr.write.call_count == 2
    assert stderr.write.call_args_list[0][0][0] == "this is a test"
    assert stderr.write.call_args_list[1][0][0] == "this is a test"
    stderr.assert_called()



# Generated at 2022-06-23 19:06:31.531871
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    print(env)

test_Environment___str__()

# Generated at 2022-06-23 19:06:43.519046
# Unit test for constructor of class Environment
def test_Environment():
    config_dir = DEFAULT_CONFIG_DIR
    stdin_isatty = False
    stdin_encoding = 'utf8'
    stdout_isatty = True
    stdout_encoding = 'utf-8'
    stderr_isatty = True
    colors = 256

    # default
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == config_dir
    assert env.stdin is sys.stdin
    assert env.stdin_isatty == stdin_isatty
    assert env.stdin_encoding == stdin_encoding
    assert env.stdout is sys.stdout
    assert env.stdout_isatty == stdout_isatty
    assert env.stdout_encoding == stdout_encoding

# Generated at 2022-06-23 19:06:45.346077
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error("error")

# Test for method __repr__ of class Environment

# Generated at 2022-06-23 19:06:52.840936
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()

# Generated at 2022-06-23 19:06:56.426301
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    msg = 'this is a test'
    try:
        env.log_error(msg, level='error')
        assert True
    except:
        assert False


# Generated at 2022-06-23 19:07:03.970502
# Unit test for method __str__ of class Environment

# Generated at 2022-06-23 19:07:12.168491
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    env.stdout = sys.__stdout__
    env.stderr = sys.__stderr__
    env.stdin = sys.__stdin__
    env.is_windows = True
    env.config_dir = Path('C:/Users/swa/AppData/Roaming/httpie')
    env.stdin = sys.__stdin__
    env.stdout_encoding = sys.__stdout__
    env.stderr_encoding = sys.__stderr__
    env.devnull = open(os.devnull, 'w+')
    
    assert env.devnull.read() == b''
    # assert env.__str__() == '<Environment  {\'config_dir\': PosixPath(\'C:/Users/swa/AppData/Roaming/httpie

# Generated at 2022-06-23 19:07:17.687007
# Unit test for constructor of class Environment
def test_Environment():
    class TestEnv(Environment):
        pass
    env = TestEnv()
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.program_name == 'http'
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr

# Generated at 2022-06-23 19:07:20.217117
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    assert repr(env) == '<Environment {}>'
    env = Environment(foo=1)
    assert repr(env) == "<Environment {'foo': 1}>"



# Generated at 2022-06-23 19:07:29.679852
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    print("test_Environment___str__()")
    from httpie.environment import Environment
    from httpie.utils import repr_dict

    env = Environment(config_dir = "/Users/xurxo/httpie/httpie_config_dir")
    env.stdin = sys.stdin
    env.stdout = sys.stdout

    env.stdout_encoding = "utf8"
    env.stdin_encoding = "utf8"
    env.stderr_encoding = "utf8"

    env.is_windows = os.name == "nt"

    env.stderr_isatty = sys.stderr.isatty()
    env.stdout_isatty = sys.stdout.isatty()
    env.stdin_isatty = sys.stdin.isat

# Generated at 2022-06-23 19:07:31.437440
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error("msg", "error")
    env.log_error("msg", "warning")



# Generated at 2022-06-23 19:07:43.219945
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
   environment = Environment()

# Generated at 2022-06-23 19:07:53.218958
# Unit test for constructor of class Environment
def test_Environment():
    # Test the initialization
    env1 = Environment(stdin=None, stdin_isatty=None, stdin_encoding=None, stdout=None,
                       stdout_isatty=None, stdout_encoding=None,
                       stderr=None, stderr_isatty=None, colors=None, program_name=None,
                       is_windows=None, config_dir=None, devnull=None)
    assert isinstance(env1, Environment)
    assert env1.stdin == sys.stdin
    assert env1.stdin_isatty == sys.stdin.isatty() if sys.stdin else False
    assert env1.stdin_encoding == None
    assert env1.stdout == sys.stdout

# Generated at 2022-06-23 19:08:03.318802
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    assert repr(env) == '<Environment {config: <Config>, is_windows: False, config_dir: C:\\Users\\User\\.config\\httpie, stdin: <_io.TextIOWrapper name=<stdin> mode=<r> encoding=UTF-8>, stdin_isatty: True, stdin_encoding: utf8, stdout: <_io.TextIOWrapper name=<stdout> mode=<w> encoding=UTF-8>, stdout_isatty: True, stdout_encoding: utf8, stderr: <_io.TextIOWrapper name=<stderr> mode=<w> encoding=UTF-8>, stderr_isatty: True, colors: 256, program_name: http}>'

# Generated at 2022-06-23 19:08:15.084273
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(program_name='hello', config_dir='/tmp')

# Generated at 2022-06-23 19:08:25.367916
# Unit test for method __repr__ of class Environment