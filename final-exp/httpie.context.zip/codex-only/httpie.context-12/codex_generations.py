

# Generated at 2022-06-23 18:58:27.156091
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from httpie.core import main
    from httpie.core import Environment
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_CONFIG_DIR
    from copy import copy
    env = copy(Environment())
    env.stderr_isatty = False
    env.stdout_isatty = False
    config_dir = DEFAULT_CONFIG_DIR + 'config'
    env.config_dir = config_dir
    env.config = main.Config(directory=config_dir)
    envDict = str(env)

# Generated at 2022-06-23 18:58:32.072701
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.program_name = 'http'
    # Unit test for warning message
    with mock.patch.object(sys.stderr, 'write') as mock_write:
        env.log_error('test', level='warning')
    assert mock_write.called
    # Unit test for error message
    with mock.patch.object(sys.stderr, 'write') as mock_write:
        env.log_error('test', level='error')
    assert mock_write.called

env = Environment()

# Generated at 2022-06-23 18:58:40.748902
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(colors=256, stdout_isatty=True)
    if env.is_windows:
        assert str(env) == "{'colors': 256, 'is_windows': True, 'program_name': 'http', 'stderr': <colorama.ansitowin32.AnsiToWin32 object at 0x0000025A8346FEB8>, 'stdout': <colorama.ansitowin32.AnsiToWin32 object at 0x0000025A8346FEB8>, 'stdout_encoding': 'cp437', 'colors': 256, 'stdout_isatty': True, 'config': <httpie.config.Config at 0x000001C20FFA2E80>}"

# Generated at 2022-06-23 18:58:42.878177
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from httpie.core import Environment

    environment = Environment()
    environment.log_error('This is an error', level='error')
    environment.log_error('This is a warning', level='warning')

# Generated at 2022-06-23 18:58:52.522130
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    a = str(env)

# Generated at 2022-06-23 18:59:00.580722
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()

# Generated at 2022-06-23 18:59:08.946038
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None)
    assert hasattr(env,'is_windows')
    assert hasattr(env,'config_dir')
    assert hasattr(env,'stdin')
    assert hasattr(env,'stdin_isatty')
    assert hasattr(env,'stdout')
    assert hasattr(env,'stdout_isatty')
    assert hasattr(env,'stderr')
    assert hasattr(env,'stderr_isatty')
    assert hasattr(env,'colors')

# Generated at 2022-06-23 18:59:13.720221
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    import sys
    sys.stdin = open(os.devnull, 'w+')
    sys.stdout = open(os.devnull, 'w+')
    sys.stderr = open(os.devnull, 'w+')
    env = Environment()
    print(env.__str__())



# Generated at 2022-06-23 18:59:15.237317
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    # Nothing interesting to test here
    pass


# Generated at 2022-06-23 18:59:20.169196
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    #from io import StringIO
    with mock.patch('sys.stdout') as mystdout:
        env.log_error('msg')
        out, err = capsys.readouterr()
        assert out == '\nhttp: error: msg\n\n'

# Generated at 2022-06-23 18:59:23.688532
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import StringIO
    env = Environment()
    error = "ERROR"
    env.log_error(error)
    # assert method log_error of class Environment write correct error
    assert(env.stderr.getvalue()[9:15] == error)


# Generated at 2022-06-23 18:59:28.894994
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error('message', 'error')
    assert env._orig_stderr.getvalue() == '\nhttp: error: message\n\n'

    env = Environment()
    env.log_error('message', 'warning')
    assert env._orig_stderr.getvalue() == '\nhttp: warning: message\n\n'

# Generated at 2022-06-23 18:59:30.938262
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    environment = Environment()
    assert repr(environment) == '<Environment {}>'

# Generated at 2022-06-23 18:59:42.871269
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    # check the attributes of instance
    assert env.is_windows == True
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == True
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == True
    assert env.program_name == 'http'

    # Test the __str__ method
    env.stdin = None

# Generated at 2022-06-23 18:59:45.466843
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(is_windows=0, colors=10)
    assert env.is_windows == 0
    assert env.colors == 10

# Generated at 2022-06-23 18:59:52.542080
# Unit test for method __repr__ of class Environment

# Generated at 2022-06-23 18:59:59.392867
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    stdout = sys.stdout
    p = Popen(['python', '-c', 'from httpie.core import Environment;\
    from httpie.compat import StringIO;\
    import sys;\
    sys.stdout = StringIO();\
    Environment().log_error("Hello")'], stdout=PIPE)
    assert 'error: Hello' in p.stdout.readlines()[-1].decode()
    sys.stdout = stdout


# Generated at 2022-06-23 19:00:07.582803
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()

# Generated at 2022-06-23 19:00:15.561483
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    assert env._orig_stderr.write is sys.stderr.write
    env.program_name = 'httpie_test'
    result = env.log_error('test message', level='error')
    assert result is None
    result = env.log_error('test message', level='warning')
    assert result is None
    assert sys.stderr.write.call_args_list[0][0][0] == '\nhttpie_test: error: test message\n\n'
    assert sys.stderr.write.call_args_list[1][0][0] == '\nhttpie_test: warning: test message\n\n'


ENV = Environment()

# Generated at 2022-06-23 19:00:21.582679
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    class TestEnvironment(Environment):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.arg = 1
            self.kwarg = 2
    env = TestEnvironment(arg=1)
    assert env.__str__() == "{\'arg\': 1, \'kwarg\': 2, \'program_name\': \'http\'}"
    assert repr(env) == "<TestEnvironment {\'arg\': 1, \'kwarg\': 2, \'program_name\': \'http\'}>"

# Generated at 2022-06-23 19:00:31.451478
# Unit test for constructor of class Environment
def test_Environment():
    print('测试: Environment 对象构造函数能否正常工作')

    # 构造 Environment 对象
    env = Environment()

    # 比较各属性值是否正常
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == (sys.stdin.isatty() if sys.stdin else False)
    assert env.stdin_encoding == (getattr(sys.stdin, 'encoding', None) or 'utf8')
    assert env.stdout == sys.stdout

# Generated at 2022-06-23 19:00:39.793014
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        stdin_encoding='stdin_encoding',
        stdout_encoding='stdout_encoding',
        colors='color',
        config_dir='config_dir',
        program_name='program_name'
    )
    assert env.stdin_encoding == 'stdin_encoding'
    assert env.stdout_encoding == 'stdout_encoding'
    assert env.colors == 'color'
    assert env.config_dir == 'config_dir'
    assert env.program_name == 'program_name'

# Generated at 2022-06-23 19:00:45.451800
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment(stdout=StringIO(), stderr=StringIO(), config_dir='./')
    msg = 'This is an error'
    env.log_error(msg)
    assert env.stdout.getvalue() == ''
    assert env.stderr.getvalue() == f'\n{env.program_name}: error: {msg}\n\n'



# Generated at 2022-06-23 19:00:56.775605
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == sys.stdin.encoding
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == sys.stdout.encoding
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.program_name == 'http'

# Generated at 2022-06-23 19:01:07.954754
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    environment = Environment(is_windows=True, config_dir='config_dir', stdin='stdin', stdin_isatty=True,
                              stdin_encoding='stdin_encoding', stdout='stdout', stdout_isatty=True, stdout_encoding='stdout_encoding',
                              stderr='stderr', stderr_isatty=True, colors=256, program_name='http', devnull='devnull')

# Generated at 2022-06-23 19:01:11.125644
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    return_message = 'returned message'
    assert not env.stderr.isatty()
    assert env.log_error(return_message, 'error') == None


# Generated at 2022-06-23 19:01:20.059386
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    stdout = io.StringIO()
    stderr = io.StringIO()

    env = Environment(stderr=stderr, stdout=stdout, program_name='http')

    env.log_error('error_msg', level='error')
    assert stderr.getvalue() == '\nhttp: error: error_msg\n\n'

    env.log_error('warning_msg', level='warning')
    assert stderr.getvalue() == '\nhttp: error: error_msg\n\n\nhttp: warning: warning_msg\n\n'

# Generated at 2022-06-23 19:01:25.818712
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()

    # Test for class attribute stdout
    # Since the program is running in global scope, we could only test if stdout is a readable stream
    assert isinstance(env.stdout, io.TextIOWrapper)
    assert env.stdout.readable() == True
    assert env.stdout_isatty == True
    assert env.stdout_encoding == 'utf8'



# Generated at 2022-06-23 19:01:29.530516
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    import io
    import sys
    env = Environment()
    assert str(env)
    env.stdin = sys.stdin = io.StringIO()
    assert str(env)

# Generated at 2022-06-23 19:01:34.995878
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import StringIO
    from httpie.core import main
    from httpie.utils import dict2

    sio = StringIO()
    env = Environment(stderr=sio)
    args = dict2(env.config['main'], verbose=True, headers='a:b')
    try:
        env.log_error("Method_error", level='error')
    except 'AttributeError':
        pass

# Generated at 2022-06-23 19:01:44.823667
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    # Assign
    env = Environment()
    # Act
    result = repr(env)
    # Assert
    assert result == '<Environment {\'is_windows\': False, \'config_dir\': Path(\'~/.httpie\'), \'stdin\': <stdin>, \'stdin_isatty\': True, \'stdin_encoding\': \'utf8\', \'stdout\': <stdout>, \'stdout_isatty\': True, \'stdout_encoding\': \'utf8\', \'stderr\': <stderr>, \'stderr_isatty\': True, \'colors\': 256}>'



# Generated at 2022-06-23 19:01:52.191670
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    global is_windows, DEFAULT_CONFIG_DIR, sys, curses, os, Path, repr_dict
    env = Environment()
    assert env.__repr__() == '<Environment {\'colors\': 256, \'config\': {}, \'is_windows\': True, \'program_name\': \'http\', \'stderr_encoding\': None, \'stdin\': <_io.TextIOWrapper name=\'<stdin>\' mode=\'r\' encoding=\'utf-8\'>, \'stdin_encoding\': \'utf8\', \'stdout_encoding\': None}>'


# Generated at 2022-06-23 19:01:57.629133
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    import sys
    env = Environment()
    bck = sys.stderr
    sys.stderr = io.StringIO()
    env.log_error('test', level='warning')
    assert sys.stderr.getvalue() == '\nhttp: warning: test\n\n'
    sys.stderr = bck

# Generated at 2022-06-23 19:02:04.300126
# Unit test for constructor of class Environment
def test_Environment():
    import sys
    import os
    import curses

    print('\n### Test Environment():')
    stdin = sys.stdin
    stdout = sys.stdout
    stderr = sys.stderr

    env = Environment()
    print(env)

    env = Environment(stdin=None, stdin_encoding=None,
                      stdout=None, stdout_encoding=None,
                      stderr=None, stderr_isatty=None,
                      colors=None, program_name='http',
                      config_dir=None)
    print(env)


# Generated at 2022-06-23 19:02:08.036991
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert isinstance(env, Environment)
    assert isinstance(env.config, Config)
    assert isinstance(env.devnull, IO)

# Generated at 2022-06-23 19:02:08.576090
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    assert Environment() == Environment()

# Generated at 2022-06-23 19:02:10.111875
# Unit test for constructor of class Environment
def test_Environment():
    print('\n', Environment(devnull='haha', colors='haha'))

# Generated at 2022-06-23 19:02:16.571779
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment(
        config_dir='config dir',
        stdin='stdin',
        stdout='stdout',
        stderr='stderr'
    )
    assert str(env) == ("{\n"
                        "    stderr: stderr,\n"
                        "    stdout: stdout,\n"
                        "    config: None,\n"
                        "    stdin: stdin,\n"
                        "    config_dir: 'config dir'\n"
                        "}")

# Generated at 2022-06-23 19:02:27.979458
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()

# Generated at 2022-06-23 19:02:39.552478
# Unit test for constructor of class Environment
def test_Environment():
    with open('devnull', 'w') as devnull:
        e = Environment(devnull=devnull)
        # Test updating attributes with keyword arguments.
        e = Environment(is_windows=1,
                        config_dir='/etc',
                        stdin=devnull,
                        stdin_isatty=1,
                        stdin_encoding='utf8',
                        stdout=devnull,
                        stdout_isatty=1,
                        stdout_encoding='utf8',
                        stderr=devnull,
                        stderr_isatty=1,
                        colors=256,
                        program_name='http')
        assert e.is_windows == 1
        assert e.config_dir == '/etc'
        assert e.stdin == devnull
        assert e.stdin_isatty == 1
       

# Generated at 2022-06-23 19:02:45.942156
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(devnull=None, is_windows=True, 
                      config_dir=DEFAULT_CONFIG_DIR)

# Generated at 2022-06-23 19:02:48.078986
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    environment = Environment()
    pprint(environment)

test_Environment___str__()

"""

"""


# Generated at 2022-06-23 19:02:51.283971
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    # str() 불러오기
    str = Environment.__str__
    # do assert
    assert str(Environment()) == '{}'

# Generated at 2022-06-23 19:03:02.652698
# Unit test for constructor of class Environment
def test_Environment():
    expected_output = '''<Environment {
    'is_windows': False,
    'config_dir': '<class \'pathlib.Path\'>',
    'stderr': '<ipykernel.iostream.OutStream object at 0x7f279543b0f0>',
    'stdout': '<ipykernel.iostream.OutStream object at 0x7f27954b7550>',
    'stdin': '<ipykernel.iostream.InStream object at 0x7f27954b74e0>',
    'program_name': 'http',
    'stdin_isatty': True,
    'stderr_isatty': False,
    'stdout_isatty': True,
    'colors': 256
}>'''
    environment_test_

# Generated at 2022-06-23 19:03:10.768831
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    # Initialize env
    env = Environment(devnull=None, **{ 'is_windows': True, 'config_dir': DEFAULT_CONFIG_DIR, 'stdin': sys.stdin, 'stdin_isatty': sys.stdin.isatty(), 'stdin_encoding': None, 'stdout': sys.stdout, 'stdout_isatty': sys.stdout.isatty(), 'stdout_encoding': None, 'stderr': sys.stderr, 'stderr_isatty': sys.stderr.isatty(), 'colors': 256, 'program_name': 'http'})

    # Call __repr__ of env
    env_repr = env.__repr__()

    # Check env.__repr__ values

# Generated at 2022-06-23 19:03:18.585869
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull='/dev/null', config_dir='/config', stdin='/dev/stdin', stdout='/dev/stdout', stderr='/dev/stderr', colors='True', program_name='httpie')
    assert env.devnull == '/dev/null'
    assert env.config_dir == Path('/config')
    assert env.stdin == '/dev/stdin'
    assert env.stdout == '/dev/stdout'
    assert env.stderr == '/dev/stderr'
    assert env.colors == True
    assert env.program_name == 'httpie'


# Generated at 2022-06-23 19:03:28.075981
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    sys.stdin = StringIO("""{"data": "Hello World"}""")
    sys.stdout = StringIO()
    env = Environment()
    print(env)

# Generated at 2022-06-23 19:03:39.834100
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from httpie.compat import isatty

    devnull = open(os.devnull, 'w+')
    e = Environment(
        devnull=devnull,
        stdin=devnull,
        stdin_isatty=False,
        stdout_isatty=False,
        stderr_isatty=False,
        program_name='my-program',
        config_dir=Path('/custom/path'),
    )

    if isatty(sys.stdin):
        assert 'stdin_isatty=True' in str(e)

    if isatty(sys.stdout):
        assert 'stdout_isatty=True' in str(e)


# Generated at 2022-06-23 19:03:42.718620
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error('s')



# Generated at 2022-06-23 19:03:45.049016
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    test_Environment_instance = Environment()
    msg = "Any error or warning message"
    assert isinstance(test_Environment_instance.log_error(msg), str)

# Generated at 2022-06-23 19:03:51.463334
# Unit test for constructor of class Environment
def test_Environment():
    import sys
    # test to verify arguments in the  __init__ function is the same as the attributes in the class
    assert all(hasattr(Environment,attr) for attr in \
        ['is_windows','config_dir', 'stdin', 'stdin_isatty', 'stdin_encoding', 'stdout', 'stdout_isatty', 'stdout_encoding', 'stderr', 'stderr_isatty', 'colors', 'program_name'])

    # test to verify the default values of is_windows and program_name
    assert Environment().is_windows == sys.platform == 'win32'
    assert Environment().program_name == 'http'

# Generated at 2022-06-23 19:03:57.276580
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull="test",
                      stdin=sys.stdin,
                      stdout=sys.stdout,
                      stderr=sys.stderr,
                      stdin_encoding=sys.stdin.encoding,
                      stdout_encoding=sys.stdout.encoding)
    print(env.stdin_encoding)
    print(env.stdout_encoding)

# Generated at 2022-06-23 19:03:59.618015
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    assert Environment.__repr__(Environment(config_dir='./httpie')) == '<Environment {\'config_dir\': Path("./httpie")}>'


# Generated at 2022-06-23 19:04:01.838294
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(is_windows=True)


# Generated at 2022-06-23 19:04:02.500846
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    pass

# Generated at 2022-06-23 19:04:10.436493
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin = 'stdin', stdin_encoding = 'stdin_encoding', stdin_isatty = 'stdin_isatty', stdout = 'stdout', stdout_encoding = 'stdout_encoding', stdout_isatty = 'stdout_isatty', stderr = 'stderr', stderr_isatty = 'stderr_isatty')
    print(env.stdin)
    print(env.stdin_encoding)
    print(env.stdin_isatty)
    print(env.stdout)
    print(env.stdout_encoding)
    print(env.stdout_isatty)
    print(env.stderr)
    print(env.stderr_isatty)


# Generated at 2022-06-23 19:04:20.252096
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import mock
    mock_stdout = mock.Mock()
    mock_stderr = mock.Mock()

    env = Environment(stdout=mock_stdout, stderr=mock_stderr)
    
    env.log_error('This is a test message')
    
    assert not mock_stdout.write.called, "Was not supposed to write output to stdout"
    mock_stderr.write.assert_called_once_with('\nhttp: error: This is a test message\n\n')
    
    # clear mock
    mock_stderr.reset_mock()
    
    env.log_error('This is a warning message', level='warning')
    
    assert not mock_stdout.write.called, "Was not supposed to write output to stdout"
    mock

# Generated at 2022-06-23 19:04:30.228643
# Unit test for constructor of class Environment
def test_Environment():
    class MyEnv(Environment):
        pass

    env = MyEnv()
    assert env.__dict__
    assert env.__str__()
    assert env.__repr__()

    import io
    import httpie.config

    env = MyEnv(devnull=io.BytesIO(), config_dir=httpie.config.__file__)
    assert env.__dict__
    assert env.__str__()
    assert env.__repr__()

    env = MyEnv(devnull=io.BytesIO(), config_dir=1)
    assert env.__dict__
    assert env.__str__()
    assert env.__repr__()


# Generated at 2022-06-23 19:04:34.216143
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    import sys
    sys.stderr = io.StringIO()
    env = Environment()
    env.log_error("There is an error")
    assert sys.stderr.getvalue() == '\nhttp: error: There is an error\n\n'

# Generated at 2022-06-23 19:04:44.345378
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment(devnull=None)
    errors_expected = [
        "Error while trying to save config httpie/config, is not a directory",
        "Warning while trying to save config httpie/config, is not a directory"
    ]
    errors_actual = []
    def get_errors(msg, level='error'):
        errors_actual.append(f'{level}: {msg}')
    env.log_error = get_errors
    env.log_error(errors_expected[0])
    env.log_error(errors_expected[1], level='warning')
    assert errors_actual == errors_expected

# Generated at 2022-06-23 19:04:47.621219
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.devnull = open(os.devnull, 'w+')
    env.stderr = env.devnull
    env.log_error("Dummy error")

# Generated at 2022-06-23 19:04:53.834005
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import StringIO
    from unittest import TestCase
    from unittest.mock import patch
    Environment.stderr = StringIO()
    level = 'error'
    Environment().log_error('msg', level)
    with patch('httpie.core.Environment', Environment):
        with patch('httpie.core.Environment.stderr', Environment.stderr):
            TestCase().assertIn('msg', Environment.stderr.getvalue())
            TestCase().assertIn(level, Environment.stderr.getvalue())


__all__ = ('Environment', 'is_windows',)

# Generated at 2022-06-23 19:05:00.548198
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=False, config_dir=DEFAULT_CONFIG_DIR,
                      stdin=sys.stdin, stdin_isatty=sys.stdin.isatty(), stdin_encoding=None,
                      stdout=sys.stdout, stdout_isatty=sys.stdout.isatty(), stdout_encoding=None,
                      stderr=sys.stderr, stderr_isatty=sys.stderr.isatty(), colors=256,
                      program_name='http', config=None, _orig_stderr=sys.stderr, _devnull=None
                      )
    print(f'env.is_windows: {env.is_windows}')

# Generated at 2022-06-23 19:05:11.029512
# Unit test for constructor of class Environment
def test_Environment():
    global env
    env = Environment()

    assert env.is_windows == is_windows
    assert env.config_dir == Path(os.path.expanduser('~/.httpie'))
    assert env.stdin is sys.stdin
    assert env.stdout is sys.stdout
    assert env.stderr is sys.stderr
    assert env.colors == 256
    assert env.program_name == 'http'

    if not is_windows:
        if curses:
            try:
                curses.setupterm()
                colors = curses.tigetnum('colors')
                assert env.colors == colors
            except curses.error:
                assert env.colors == 256
    else:
        # noinspection PyUnresolvedReferences
        import colorama.initialise

# Generated at 2022-06-23 19:05:22.059927
# Unit test for constructor of class Environment
def test_Environment():
    s = sys.stdin
    assert not s.isatty()
    stdin_isatty1 = s.isatty()
    stdin1 = sys.stdin
    stdin_encoding1 = getattr(s, 'encoding', None) or 'utf8'
    s = sys.stdout
    assert not s.isatty()
    stdout_isatty1 = s.isatty()
    stdout1 = sys.stdout
    stdout_encoding1 = getattr(s, 'encoding', None) or 'utf8'

# Generated at 2022-06-23 19:05:24.721989
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment(stdin_encoding='utf-8')
    assert repr(env) == '<Environment {\'stdin_encoding\': \'utf-8\'}>'

# Generated at 2022-06-23 19:05:25.225720
# Unit test for method __repr__ of class Environment
def test_Environment___repr__(): pass


# Generated at 2022-06-23 19:05:29.920462
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    if hasattr(Environment, "__repr__"):
        env = Environment()
        repr_env = repr(env)
        if hasattr(env, "__repr__"):
            assert isinstance(repr_env, str)



# Generated at 2022-06-23 19:05:33.819070
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    environ = Environment(colors=8, devnull=open('/dev/null', 'w+'))
    assert repr(environ) == '<Environment {\'colors\': 8, \'config\': {}}>'

# Generated at 2022-06-23 19:05:36.876139
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error('This is a log error')
    env.log_error('This is a log warning', level='warning')

# Generated at 2022-06-23 19:05:38.880786
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    a = Environment()
    assert str(a) == f'<Environment {a}>'



# Generated at 2022-06-23 19:05:47.310441
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    import os
    import sys
    import platform
    from pathlib import Path
    from io import StringIO
    #defult

    """[测试 Environment 中 _str_ 方法]
    """
    # expected_output = '''
    # <Environment {'colors': 256, 'config_dir': PosixPath('/Users/liangzhichao/.httpie'), 'is_windows': False, 'program_name': 'http', 'stdin': <_io.TextIOWrapper name='<stdin>' mode='r' encoding='UTF-8'>, 'stdin_encoding': 'UTF-8', 'stdin_isatty': True, 'stdout': <_io.TextIOWrapper name='<stdout>' mode='w' encoding='UTF-8'>, 'stdout_enc

# Generated at 2022-06-23 19:05:57.835419
# Unit test for constructor of class Environment
def test_Environment():
    import io
    import pathlib
    # Create temporary environment.
    env = Environment(
        is_windows=False,
        config_dir=pathlib.Path('.httpie'),
        stdin=io.StringIO('test'),
        stdin_isatty=False,
        stdin_encoding='utf8',
        stdout=io.StringIO('test'),
        stdout_isatty=False,
        stdout_encoding=None,
        stderr=io.StringIO('test'),
        stderr_isatty=False,
        colors=256,
        program_name='http')
    output = env.__str__()

# Generated at 2022-06-23 19:06:04.059693
# Unit test for constructor of class Environment
def test_Environment():
    from io import StringIO
    from httpie.compat import isatty
    env = Environment(program_name='example', colors=256, stderr=StringIO())
    assert env.program_name == 'example'
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.colors == 256
    assert env.stdin is None
    assert env.stdin_isatty is False
    assert env.stdin_encoding is None
    assert env.stdout_isatty is True
    assert env.stdout_encoding is None
    assert env.stderr_isatty is False
    assert env.stderr_encoding is None
    assert env._orig_stderr is env.stderr
    assert env._devnull is env.devnull

# Generated at 2022-06-23 19:06:06.689502
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error('Test')
    assert env.log_error('Test') == None
    assert env.log_error('Test', level='warning') == None

# Generated at 2022-06-23 19:06:16.807892
# Unit test for constructor of class Environment
def test_Environment():
    import io, sys
    stdin = io.StringIO('abc')
    stdout = io.StringIO()
    stderr = io.StringIO()
    enc = io.TextIOWrapper(io.BytesIO(), encoding='utf8')
    e = Environment(
        stdin=stdin, stdout=stdout, stderr=stderr, stdin_encoding=enc.encoding,
        stdout_encoding=enc.encoding, stderr_encoding=enc.encoding,
        is_windows=False, config_dir=Path('abc'), program_name='abc',
        colors=256,
    )
    assert e.stdin == stdin
    assert e.stdin_isatty == False
    assert e.stdin_encoding == 'utf8'
    assert e.std

# Generated at 2022-06-23 19:06:27.264000
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    import sys
    import filecmp
    import os
    from httpie.config import Config
    from httpie.environment import Environment

    file1 = os.getcwd() + "/test_Environment_log_error.txt"
    file2 = os.getcwd() + "/test_Environment_log_error_expected.txt"

    # Test --debug flag
    sys.stdout = io.StringIO()
    env = Environment()
    # Test if files are same
    env.log_error('Debug')
    x = sys.stdout.getvalue()
    with open(file1, "w") as f:
        f.write(x)
    assert filecmp.cmp(file1, file2, shallow=False)

    # Test --verbose flag
    sys.stdout = io.StringIO()
   

# Generated at 2022-06-23 19:06:29.162639
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    envRepr = repr(env)
    assert type(envRepr) == str


# Generated at 2022-06-23 19:06:37.195185
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=1,stdin=2,stdout=3,stderr=4)
    assert env.is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == 2
    assert env.stdout == 3
    assert env.stderr == 4
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env.devnull == 1

# Generated at 2022-06-23 19:06:41.273462
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        devnull='/dev/null',
    )
    assert env.devnull == '/dev/null'
    assert env.stdin_encoding == 'utf8'
    assert env.stdout_encoding == 'utf8'


# Generated at 2022-06-23 19:06:44.498861
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    """
    Retorna forma de representacao do objeto
    :return:
    """

    # Uncomment the following lines
    # env = Environment()
    # repr_dict = repr(env)
    # print(repr_dict)

    pass



# Generated at 2022-06-23 19:06:46.574188
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert isinstance(env, Environment)
    assert is_windows == env.is_windows
    assert sys.stdin == env.stdin



# Generated at 2022-06-23 19:06:48.289861
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    """
    Unit test for method __repr__ of class Environment
    """
    environ = Environment()
    assert "Environment(" in repr(environ)

# Generated at 2022-06-23 19:06:54.518030
# Unit test for constructor of class Environment
def test_Environment():
    # Create an instance of the Environment class
    env = Environment()
    # Create an instance of class Config
    config = Config(directory=env.config_dir)

    # Check if env.config is equal to config
    assert env.config == config


# Generated at 2022-06-23 19:06:56.991184
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    e = Environment()
    e.log_error('hello', 'warning')
    print(e._orig_stderr.getvalue())
    pass

# Generated at 2022-06-23 19:06:59.688578
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        config_dir = 'test_config_dir'
    )
    assert env.config_dir == 'test_config_dir'


# Generated at 2022-06-23 19:07:03.962746
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    assert repr(Environment()) == '<Environment { }>'
    assert repr(Environment(devnull='foo')) == '<Environment { \'devnull\': \'foo\' }>'



# Generated at 2022-06-23 19:07:13.292256
# Unit test for method __str__ of class Environment

# Generated at 2022-06-23 19:07:17.509983
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert hasattr(env,'stderr')
    assert hasattr(env,'stdin')
    assert hasattr(env,'stdout')
    assert hasattr(env,'config_dir')
    return True


# Generated at 2022-06-23 19:07:28.169319
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    assert repr(env) == '<Environment {\n    "stdin": null,\n    "stdin_isatty": false,\n    "stdin_encoding": "utf8",\n    "stdout": <_io.TextIOWrapper encoding=\'UTF-8\'>,\n    "stdout_isatty": true,\n    "stdout_encoding": "utf8",\n    "stderr": <_io.TextIOWrapper encoding=\'UTF-8\'>,\n    "stderr_isatty": true,\n    "is_windows": false,\n    "config_dir": "/home/kamil/.config/httpie",\n    "colors": 256,\n    "program_name": "http"\n}>'



# Generated at 2022-06-23 19:07:35.767144
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment(devnull='foo', stdin='bar', stdin_encoding='baz', stdin_isatty=True, stdout='qux', stdout_encoding='quux', stdout_isatty=True, stderr='corge', stderr_isatty=True, colors=0, program_name='grault')
    assert str(env) == '{devnull: \'foo\', stdin: \'bar\', stdin_encoding: \'baz\', stdin_isatty: True, stdout: \'qux\', stdout_encoding: \'quux\', stdout_isatty: True, stderr: \'corge\', stderr_isatty: True, colors: 0, program_name: \'grault\'}'

# Generated at 2022-06-23 19:07:47.157122
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    class MyEnv(Environment):
        config_dir = DEFAULT_CONFIG_DIR
        stdin = sys.stdin
        stdin_isatty = sys.stdin.isatty()
        stdin_encoding = None
        stdout = sys.stdout
        stdout_isatty = sys.stdout.isatty()
        stdout_encoding = None
        stderr = sys.stderr
        stderr_isatty = sys.stderr.isatty()
        colors = 256
        program_name = 'http'
        if not is_windows:
            if curses:
                try:
                    curses.setupterm()
                    colors = curses.tigetnum('colors')
                except curses.error:
                    pass

# Generated at 2022-06-23 19:07:57.154644
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    class TestEnvironment(Environment):
        x = 1
        y = 2
        is_windows = True
        config_dir = 'config_dir'
        stdin = 'stdin'
        stdin_isatty = False
        stdin_encoding = 'stdin_encoding'
        stdout = 'stdout'
        stdout_isatty = False
        stdout_encoding = 'stdout_encoding'
        stderr = 'stderr'
        stderr_isatty = False
        colors = 256
        program_name = 'TEST'
        _config = 'config'


# Generated at 2022-06-23 19:08:00.195011
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    environ = Environment()
    assert str(environ) == '<Environment {}>'
    environ.is_windows = True
    environ.stdout_encoding = 'utf-8'
    assert str(environ) == '<Environment {is_windows: True, stdout_encoding: utf-8}>'

# Generated at 2022-06-23 19:08:07.227077
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    assert (Environment()).__str__() == "program_name='http', stdin=<stdin>, stdin_isatty=False, stdout=<stdout>, stdout_isatty=False, stdout_encoding='utf8', stderr=<stderr>, stderr_isatty=False, colors=256, config={'default_options': [], 'installation_dir': '/home/akshay/.config/httpie', 'config_dir': '/home/akshay/.config/httpie', 'colors': {'header': 'green', 'method': 'blue', 'scheme': 'blue', 'body': 'blue', 'status': 'yellow'}, 'style': 'default'}"

# Generated at 2022-06-23 19:08:13.521255
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from httpie.core import Environment
    from httpie.compat import is_windows

# Generated at 2022-06-23 19:08:15.173084
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    assert '<Environment {' in str(Environment())

# Generated at 2022-06-23 19:08:22.140977
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    try:
        env = Environment()
        msg = 'An example of an error or a warning'
        env.log_error(msg)
        assert msg in env._orig_stderr.getvalue()
        env.log_error(msg,level='warning')
        assert msg in env._orig_stderr.getvalue()
    except NameError:
        print("Name error")

if __name__ == "__main__":
    test_Environment_log_error()