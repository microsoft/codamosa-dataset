

# Generated at 2022-06-23 18:58:30.350758
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    myEnv = Environment()

# Generated at 2022-06-23 18:58:34.253766
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    e = Environment(self='self', colors=100, h=300, is_windows=False)
    assert repr(e) == "<Environment {'config': None, 'colors': 100, 'h': 300, 'is_windows': False, 'self': 'self'}>"

# Generated at 2022-06-23 18:58:42.009780
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(program_name = 'test',
                              config_dir = '/test/test/test',
                              is_windows = True,
                              stdin = 10,
                              stdin_isatty = True,
                              stdin_encoding = 'yes',
                              stdout = 20,
                              stdout_isatty = False,
                              stdout_encoding = 'no',
                              stderr = 30,
                              stderr_isatty = True,
                              colors = 8,
                              devnull = 40)
    assert environment.program_name == 'test'
    assert environment.config_dir == '/test/test/test'
    assert environment.is_windows == True
    assert environment.stdin == 10
    assert environment.stdin_isatty == True

# Generated at 2022-06-23 18:58:43.828190
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    assert repr_dict(env.__dict__) == str(env)

# Generated at 2022-06-23 18:58:53.361648
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    '''
    This is a functional test of Environment.__repr__()
    '''

# Generated at 2022-06-23 18:58:57.812400
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment(stderr = sys.stdout)
    msg = "error message"
    env.log_error(msg)
    assert(env._orig_stderr.write.called_once_with(f'\n{env.program_name}: error: {msg}\n\n'))

# Generated at 2022-06-23 18:59:10.081421
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()

# Generated at 2022-06-23 18:59:13.721662
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from httpie.context import Environment
    from httpie.config import DEFAULT_CONFIG_DIR
    env = Environment()
    assert 'config' in str(env)
    assert str(DEFAULT_CONFIG_DIR) in str(env)

# Generated at 2022-06-23 18:59:16.444941
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    assert env.__repr__() == '<Environment {config_dir: C:\\Users\\paul\\.config/httpie, is_windows: True}>'

# Generated at 2022-06-23 18:59:26.241723
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()

# Generated at 2022-06-23 18:59:36.380247
# Unit test for method __repr__ of class Environment

# Generated at 2022-06-23 18:59:38.705469
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    e = Environment(colors = 256 , colors = 256)
    print(repr(e))


# Generated at 2022-06-23 18:59:48.584609
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    d = eval(str(env))
    assert d['is_windows'] == env.is_windows
    assert d['config_dir'] == env.config_dir
    assert d['stdin'] == env.stdin
    assert d['stdin_isatty'] == env.stdin_isatty
    assert d['stdin_encoding'] == env.stdin_encoding
    assert d['stdout'] == env.stdout
    assert d['stdout_isatty'] == env.stdout_isatty
    assert d['stdout_encoding'] == env.stdout_encoding
    assert d['stderr'] == env.stderr
    assert d['stderr_isatty'] == env.stderr_isatty
    assert d['colors'] == env

# Generated at 2022-06-23 18:59:50.017919
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    environment = Environment()
    print(environment)


# Generated at 2022-06-23 18:59:57.095637
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull='devnull', foo='bar')
    assert env.devnull == 'devnull'
    assert env.foo == 'bar'
    assert type(env).__dict__['devnull'] is None
    assert env.__dict__['foo'] == 'bar'
    assert env.__str__() == '{\'devnull\': \'devnull\', \'foo\': \'bar\'}'
    assert env.__repr__() == '<Environment {\'devnull\': \'devnull\', \'foo\': \'bar\'}>'

    env = Environment(bar='foo')
    assert env.foo == 'bar'
    assert env.bar == 'foo'
    assert env.__dict__['bar'] == 'foo'

# Generated at 2022-06-23 18:59:58.946431
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert not env.stdin_isatty

# Generated at 2022-06-23 19:00:02.662208
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()

    assert env.is_windows == is_windows
    assert isinstance(env.config_dir, Path)
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr



# Generated at 2022-06-23 19:00:12.807245
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    import sys
    import os
    import httpie
    from httpie.config import Config
    from httpie.utils import get_terminal_size

    env = Environment(is_windows=True)

# Generated at 2022-06-23 19:00:13.694030
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    pass


# Generated at 2022-06-23 19:00:21.332137
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    fd = io.BytesIO()
    env = Environment(stderr=fd)

    env.log_error('Why yes, this is a test of log_error.')

    fd.seek(0)
    assert fd.read() == b'\nhttp: error: Why yes, this is a test of log_error.\n\n'

    fd.seek(0)
    fd.truncate()

    env.log_error('And this is a warning for log_error.', level='warning')

    fd.seek(0)
    assert fd.read() == b'\nhttp: warning: And this is a warning for log_error.\n\n'

# Generated at 2022-06-23 19:00:31.160958
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    log_file = open('log_test_file.txt', 'w+')
    env = Environment(stderr=log_file)

    msg = 'This is an error.'
    env.log_error(msg)
    log_file.seek(0)
    log_msg = log_file.read()
    assert log_msg == '\nhttp: error: This is an error.\n\n', 'Environment class method log_error does not work properly'

    # Reset the log file
    log_file.seek(0)
    log_file.truncate()

    msg = 'This is a warning.'
    env.log_error(msg, level='warning')
    log_file.seek(0)
    log_msg = log_file.read()

# Generated at 2022-06-23 19:00:33.017327
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name = 'name')
    assert env.program_name == 'name'

# Generated at 2022-06-23 19:00:34.679929
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    assert isinstance(str(env),str)

# Generated at 2022-06-23 19:00:42.368860
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    if is_windows:
        assert type(env.stdout).__module__ == 'colorama.ansitowin32'
        assert type(env.stderr).__module__ == 'colorama.ansitowin32'
    assert isinstance(env.config_dir, Path) and \
        env.config_dir == Config().directory
    assert isinstance(env.stdin, IO) and env.stdin is sys.stdin
    assert isinstance(env.stdin_isatty, bool)
    assert isinstance(env.stdout_isatty, bool)
    assert isinstance(env.stderr_isatty, bool)
    assert isinstance(env.stdout, IO) and env.stdout is sys.stdout

# Generated at 2022-06-23 19:00:43.489516
# Unit test for constructor of class Environment
def test_Environment():
    pass
    

# Generated at 2022-06-23 19:00:55.167030
# Unit test for constructor of class Environment
def test_Environment():
    def reset():
        env = Environment()
        env.stdin_isatty = False
        env.stdout_isatty = False
        env.stderr_isatty = False
        env.stdin_encoding = None
        env.stdout_encoding = None
        env._config = None
        env._devnull = None
        return env

    env = reset()

    env.stdout_isatty = True
    assert env.stdout_isatty
    assert env.stdout.isatty()

    assert env.config
    assert env.config.directory

    # All keyword arguments can be overwritten.

# Generated at 2022-06-23 19:01:06.464559
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()

# Generated at 2022-06-23 19:01:08.321075
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    environment = Environment()
    msg = "This is an error"
    assert environment.log_error(msg, level='error') == None

# Generated at 2022-06-23 19:01:10.077431
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    assert Environment.__repr__(Environment()) == '<Environment {}>'

# Generated at 2022-06-23 19:01:21.224825
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import StringIO
    from httpie.compat import is_py2
    from httpie.config import Config

    env = Environment(is_windows=True, program_name='http', config_dir='~/.httpie')

    # Prepares mocked config
    env._config = Config(directory=env.config_dir)
    # Prepares mocked stderr
    env._orig_stderr = StringIO()
    env.stderr = env._orig_stderr

    # Test for normal error level
    env.log_error('mymsg', level='error')
    assert env._orig_stderr.getvalue() == '\nhttp: error: mymsg\n\n'

# Generated at 2022-06-23 19:01:32.978533
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    # Test Environment.__str__
    default = sys.stdout
    stdout = sys.stdout = io.StringIO()
    # Test creation of environment object
    env = Environment(config_dir=Path(""), program_name='http')
    config_dir = env.config_dir
    # Assert that the config_dir is a Path object
    assert config_dir is not None
    assert isinstance(config_dir, Path)
    # Test __str__ method
    print(env)
    s = stdout.getvalue()

# Generated at 2022-06-23 19:01:39.100685
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.stdin == sys.stdin
    assert env.stderr == sys.stderr
    assert env.stdout == sys.stdout
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.stdout_isatty == sys.stdout.isatty()


# Generated at 2022-06-23 19:01:43.864605
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment(config_dir='/foo/bar', stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr)
    assert str(env) == "config=None, stdin={}, stdin_encoding=utf8, stdin_isatty=False, stdout=<httpie.compat.is_py26.Container object at 0x7fcfd7a76e10>, stdout_encoding=utf8, stdout_isatty=False, stderr=<httpie.compat.is_py26.Container object at 0x7fcfd7a762e8>, stderr_encoding=None, stderr_isatty=False, colors=256, config_dir='/foo/bar', is_windows=False, program_name='http'"


# Generated at 2022-06-23 19:01:49.143046
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    # Test that warning messages are written
    env = Environment(stdout=StringIO(), stderr=StringIO(), config_dir=Path(''))
    env.log_error('any message', level='warning')

    # Test that error messages are written
    env = Environment(stdout=StringIO(), stderr=StringIO(), config_dir=Path(''))
    env.log_error('any message', level='error')

# Generated at 2022-06-23 19:01:56.075466
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    import httpie.context
    httpie.context.env = Environment()

# Generated at 2022-06-23 19:01:58.130779
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    assert str(env) != ''



# Generated at 2022-06-23 19:01:59.469342
# Unit test for constructor of class Environment
def test_Environment():
    assert(Environment().stdout_isatty)

# Generated at 2022-06-23 19:02:11.627504
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()

# Generated at 2022-06-23 19:02:22.730352
# Unit test for constructor of class Environment
def test_Environment():
    def assert_about_equal(env: Environment, **kwargs):
        for key, value in kwargs.items():
            assert getattr(env, key) == value

    env = Environment()

# Generated at 2022-06-23 19:02:29.184658
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    class TestEnvironment(Environment):
        stderr = None
        stdout = None

    env = TestEnvironment(stderr=io.StringIO())
    env.program_name = 'mock'

    env.log_error('error')
    env.log_error('warning', 'warning')

    assert env.stderr.getvalue() == '\nmock: error: error\n\n\nmock: warning: warning\n\n'

# Generated at 2022-06-23 19:02:40.793833
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    environment = Environment()

# Generated at 2022-06-23 19:02:47.108629
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.config_dir is not None
    assert env.stdin is not None
    assert env.stdin_isatty is not None
    assert env.stdin_encoding is not None
    assert env.stdout is not None
    assert env.stdout_isatty is not None
    assert env.stdout_encoding is not None
    assert env.stderr is not None
    assert env.stderr_isatty is not None
    assert env.program_name is not None
    assert env.colors is not None

# Generated at 2022-06-23 19:02:50.967977
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.stdin = None
    env.devnull = "Error occured"
    env.log_error("Error occured")
    assert env.devnull == "Error occured"

# Generated at 2022-06-23 19:03:00.187857
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.devnull is None
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.stderr_encoding is None
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding is None
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding is None
    assert env.colors == 256
    assert env.program_name == 'http'

# Generated at 2022-06-23 19:03:03.761139
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    print(type(env))
    print(type(env.__dict__))
    print(str(env))
    print(repr(env))
    print(env.__dict__)

# Generated at 2022-06-23 19:03:04.404034
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error("test")
    assert 1==1

# Generated at 2022-06-23 19:03:11.524786
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    env.is_windows = True
    env.config_dir = DEFAULT_CONFIG_DIR
    env.stdin = sys.stdin
    env.stdin_isatty = False
    env.stdin_encoding = 'utf8'
    #env.stdout = sys.stdout
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'
    #env.stderr = sys.stderr
    env.stderr_isatty = True
    env.colors = 256
    env.program_name = 'http'
    actual = repr(env)

# Generated at 2022-06-23 19:03:19.846093
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert repr(env) == "<Environment 'colors': 256, 'config': None, 'config_dir': 'C:\\Users\\SREE PRIYA\\.config\\httpie', 'is_windows': True, 'program_name': 'http', 'stderr': <stderr>, 'stderr_encoding': 'utf8', 'stderr_isatty': True, 'stdin': <stdin>, 'stdin_encoding': 'utf8', 'stdin_isatty': True, 'stdout': <stdout>, 'stdout_encoding': 'utf8', 'stdout_isatty': True>"

# Generated at 2022-06-23 19:03:22.522839
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin_encoding=None, stdout_encoding=None)
    assert env.stdin_encoding is None
    assert env.stdout_encoding is None

# Generated at 2022-06-23 19:03:33.995021
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from pprint import pformat
    from httpie.core import Environment
    environ = Environment()
    

# Generated at 2022-06-23 19:03:45.694528
# Unit test for method __str__ of class Environment

# Generated at 2022-06-23 19:03:50.814360
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    import sys
    output = io.StringIO("")
    try:
        sys.stderr = output
        env = Environment()
        env.program_name = "http"
        env.log_error("test", level="error")
        env.log_error("test2", level="warning")
    finally:
        sys.stderr = sys.__stderr__
    assert output.getvalue() == '\nhttp: error: test\n\n\nhttp: warning: test2\n\n'

# Generated at 2022-06-23 19:03:55.127115
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    print('-'*60)
    print('Testing function test_Environment_log_error in module environment.py')
    print()

    env = Environment()
    env.log_error('test info', level='error')
    env.log_error('test info', level='warning')



# Generated at 2022-06-23 19:04:07.145286
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=sys.stdin,
                      stdout=sys.stdout,
                      stderr=sys.stderr,
                      config_dir=DEFAULT_CONFIG_DIR,
                      )

# Generated at 2022-06-23 19:04:07.761006
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    pass

# Generated at 2022-06-23 19:04:19.106403
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    print(f'{env}\n')
    env.config_dir = Path('~/.config')
    print(f'{env}\n')
    env.program_name = 'http'
    print(f'{env}\n')
    env.config = Config()
    print(f'{env}\n')

test_Environment___repr__()

env = Environment()

import textwrap


# Generated at 2022-06-23 19:04:20.478653
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    environment = Environment()
    assert repr(environment) == f'<Environment {environment}>'

# Generated at 2022-06-23 19:04:28.460480
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_encoding == sys.stdin.encoding
    assert env.stdout == sys.stdout
    assert env.stdout_encoding == sys.stdout.encoding
    assert env.stderr == sys.stderr
    assert env.colors == 256
    assert env.program_name == 'http'

# Generated at 2022-06-23 19:04:36.804099
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    class TryEnvironment(Environment):
        _std_stream = None
        _orig_stderr = None

    stderr_file = open('test.txt', 'w+')
    env = TryEnvironment(program_name="httpie", _orig_stderr=stderr_file)
    env.log_error("Invalid option", level='error')
    env.log_error("Invalid option", level='warning')
    stderr_file.close()
    log_file = open('test.txt', 'r')
    content = log_file.read()
    log_file.close()
    assert content == "httpie: error: Invalid option\n\nhttpie: warning: Invalid option\n\n"

# Generated at 2022-06-23 19:04:37.539983
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    print(str(Environment()))

# Generated at 2022-06-23 19:04:47.587186
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()

# Generated at 2022-06-23 19:04:52.163856
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(stdout_isatty=True)
    assert environment.is_windows == is_windows
    assert environment.colors == 256
    assert environment.stderr == sys.stderr
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == True
    assert environment.stderr_isatty == True
    assert environment.devnull == None

# Generated at 2022-06-23 19:04:55.979927
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    print(env.stdout)  # for coverage
    assert isinstance(env, Environment)
    assert env.stdin_isatty == sys.stdin.isatty()
    env.stdin_isatty = True
    assert env.stdin_isatty is True
    env.stdin_isatty = False
    assert env.stdin_isatty is False
    assert environment.stdin_isatty is False

environment = Environment()

# Generated at 2022-06-23 19:05:08.906430
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    os.environ['HOME'] = '/home/test'
    e0 = Environment()

# Generated at 2022-06-23 19:05:20.289997
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    # boilerplate for an object of type 'Environment'
    env = Environment()

    # boilerplate for an object of type 'Config'
    from httpie.config import Config
    config = Config()
    env._config = config

    # boilerplate for an object of type 'IO'
    from io import StringIO
    stdin = StringIO()
    env.stdin = stdin

    # boilerplate for an object of type 'IO'
    from io import StringIO
    stdout = StringIO()
    env.stdout = stdout

    # boilerplate for an object of type 'IO'
    from io import StringIO
    stderr = StringIO()
    env.stderr = stderr

    # boilerplate for an object of type 'IO'
    from io import StringIO
    devnull = StringIO()

# Generated at 2022-06-23 19:05:32.508927
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    expected = '''\
{'colors': 256,
 'config_dir': '/User/abc/.config/httpie',
 'is_windows': False,
 'program_name': 'http',
 'stderr': <httpie.core.StdoutStreamWriter name='<stderr>' mode='w' encoding='utf8'>,
 'stderr_encoding': 'utf8',
 'stderr_isatty': False,
 'stdin': None,
 'stdin_encoding': None,
 'stdin_isatty': False,
 'stdout': <httpie.core.StdoutStreamWriter name='<stdout>' mode='w' encoding='utf8'>,
 'stdout_encoding': 'utf8',
 'stdout_isatty': False}'''
    env = Environment()

# Generated at 2022-06-23 19:05:33.575596
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(name='hello', colors=128)
    assert env.name == 'hello'
    assert env.colors == 128

# Generated at 2022-06-23 19:05:37.892693
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    stdout = StringIO()
    stderr = StringIO()
    env = Environment(stdout=stdout, stderr=stderr)
    env.log_error('Error')
    assert 'Error' in stderr.getvalue()

# Generated at 2022-06-23 19:05:39.584583
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    assert repr(env) == '<Environment {}>'

# Generated at 2022-06-23 19:05:43.771302
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment(program_name='http', colors=256, stderr_isatty=True, stdout_isatty=False,
                                                 stdin_isatty=True, stdin_encoding='None',
                                                 stdout_encoding='None', stderr_encoding='None')
    print(env)

# Generated at 2022-06-23 19:05:44.487149
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    assert str(Environment())


# Generated at 2022-06-23 19:05:53.948702
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(
        program_name='http',
        stdin=sys.stdin,
        stdin_encoding=sys.stdin.encoding,
        stdin_isatty=sys.stdin.isatty(),
        stdout=sys.stdout,
        stdout_encoding=sys.stdout.encoding,
        stdout_isatty=sys.stdout.isatty(),
        stderr=sys.stderr,
        stderr_isatty=sys.stderr.isatty(),
        colors=256,
        is_windows=False,
        config_dir=DEFAULT_CONFIG_DIR)
    assert '<Environment {' in str(env)

# Generated at 2022-06-23 19:05:56.078144
# Unit test for constructor of class Environment
def test_Environment():
    Env = Environment(devnull=0)
    print(Env)

test_Environment()

# Generated at 2022-06-23 19:06:03.099842
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == bool(sys.stdin.isatty())
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == 'utf8'
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr
    assert env._dev

# Generated at 2022-06-23 19:06:11.823988
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    import sys
    import os
    import tempfile
    temp_file = tempfile.mkstemp()
    orig_stdout = sys.stdout
    sys.stdout = open(temp_file[-1], 'w+')
    orig_stderr = sys.stderr
    sys.stderr = open(temp_file[-1], 'w+')
    env = Environment()
    env.log_error("mismatched quotes")
    sys.stdout = orig_stdout
    sys.stderr = orig_stderr
    sys.stdout.write("\n")
    os.remove(temp_file[-1])

# Generated at 2022-06-23 19:06:14.093871
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment(devnull=1)
    assert isinstance(repr(env), str)

# Generated at 2022-06-23 19:06:25.514689
# Unit test for method __repr__ of class Environment

# Generated at 2022-06-23 19:06:33.241394
# Unit test for method __str__ of class Environment

# Generated at 2022-06-23 19:06:44.528057
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    def test_method(self):
        # noinspection PyUnresolvedReferences
        env = Environment()

# Generated at 2022-06-23 19:06:51.761715
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()

    msg = "oups"
    level = "warning"
    expected = "\nhttp: warning: oups\n\n"
    stream = io.StringIO()
    env.stderr = stream
    env.log_error(msg, level=level)
    assert expected == stream.getvalue()

    msg = "oups"
    level = "error"
    expected = "\nhttp: error: oups\n\n"
    stream = io.StringIO()
    env.stderr = stream
    env.log_error(msg, level=level)
    assert expected == stream.getvalue()

test_Environment_log_error()

# Generated at 2022-06-23 19:06:53.995553
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    assert '<Environment' in env.__repr__()


# Generated at 2022-06-23 19:07:03.023049
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from httpie.compat import is_windows
    from httpie.utils import StringWithAttrs
    if is_windows:
        import colorama
        colorama.init()
        del colorama
    obj = Environment()
    str(obj)
    assert isinstance(obj.stdin, StringWithAttrs)
    assert isinstance(obj.stdout, StringWithAttrs)
    assert isinstance(obj.stderr, StringWithAttrs)
    assert obj.config_dir.is_absolute()
    assert isinstance(obj.stdin_encoding, str)
    assert isinstance(obj.stdout_encoding, str)
    assert isinstance(obj.stderr_encoding, str)
    assert obj.stdout_encoding == 'utf-8'

# Generated at 2022-06-23 19:07:11.379270
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()

# Generated at 2022-06-23 19:07:22.920203
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    result = env.__repr__()
    print(result)

# Generated at 2022-06-23 19:07:32.442867
# Unit test for constructor of class Environment
def test_Environment():
    import io
    import httpie.core
    httpie.core.get_config_dir.cache_clear()
    assert Environment().config_dir == DEFAULT_CONFIG_DIR
    assert Environment().stdin.read() == sys.stdin.read()
    assert Environment().stdout.read() == sys.stdout.read()
    file = io.open('test_Environment.py', 'w')
    assert Environment(stdout=file).stdout == file
    assert Environment(stdin=file).stdin == file
    assert Environment(stderr=file).stderr == file
    file.close()
    os.remove('test_Environment.py')
    assert not os.path.isfile('test_Environment.py')

# Generated at 2022-06-23 19:07:44.380137
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment(stdout_isatty=True)

# Generated at 2022-06-23 19:07:51.926359
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import StringIO
    env = Environment()
    env.config_dir = Path('httpie')
    env_test = env.config
    assert env.config_dir == Path('httpie')
    tmp_stdout = StringIO()
    env._orig_stderr = tmp_stdout
    env.log_error('Test', level='warning')
    env.log_error('Test', level='error')
    assert tmp_stdout.getvalue() == '\nhttp: warning: Test\n\n\nhttp: error: Test\n\n'

# Generated at 2022-06-23 19:07:54.587359
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment(program_name='httpie')
    env.log_error('Unable to connect to server')
    env.log_error('Unable to connect to server', level='warning')



# Generated at 2022-06-23 19:08:04.503031
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    str1 = '\nEnvironment(bytes_received=0, config_dir=Path(~/.httpie), cookies=CookieJar([]), '
    str2 =         'orig_stderr_encoding=utf-8, orig_stderr=<_io.TextIOWrapper name=<stderr> mode=w encoding=utf-8>, '
    str3 =         'orig_stderr_isatty=True, orig_stderr_fileno=2, '
    str4 =         'orig_stderr_mode=w, program_name=http, is_windows=False, '
    str5 =         'config={}, devnull=None, stderr=<_io.TextIOWrapper name=<stderr> mode=w encoding=utf-8>, '

# Generated at 2022-06-23 19:08:13.913372
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    if not env.is_windows:
        assert env.stdin == sys.stdin
        assert env.stdout == sys.stdout
        assert env.stderr == sys.stderr
    assert env.colors == 256
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.program_name == 'http'
    assert env.stdin_encoding == 'utf8'
    assert env.stdout_encoding == 'utf8'
    assert env._orig_stderr == sys.stderr
    assert env._devnull == None

test_Environment()

# Generated at 2022-06-23 19:08:24.172478
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import StringIO
    from unittest import mock
    from httpie.environment import Environment

    # Mock the 'stderr' property of Environment class
    mocker = mock.patch.object(Environment, '_orig_stderr',
                               new_callable=StringIO)
    mock_stdout = mocker.start()

    # Capture the stdout by creating an instance
    mocker.stop()
    env = new(stderr=mock_stdout)

    env.log_error('Bad Request', 'error')
    env.log_error('Bad Request', 'warning')

    assert mock_stdout.getvalue() == '''\

http: error: Bad Request


http: warning: Bad Request

'''

