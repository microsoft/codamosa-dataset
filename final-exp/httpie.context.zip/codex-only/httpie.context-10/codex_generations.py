

# Generated at 2022-06-23 18:58:24.709046
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    assert 'config_dir' in env.__str__()
    assert 'colors' in env.__str__()



# Generated at 2022-06-23 18:58:25.576903
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    assert str(Environment())



# Generated at 2022-06-23 18:58:31.912611
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    obj = Environment()
    assert isinstance(obj.config_dir, Path)
    assert isinstance(obj.stdin, IO)
    assert type(obj.stdin_isatty) is bool
    assert obj.stdin_encoding is None
    assert type(obj.stdout) is IO
    assert isinstance(obj.stdout_isatty, bool)
    assert isinstance(obj.stdout_encoding, str)
    assert isinstance(obj.stderr, IO)
    assert type(obj.stderr_isatty) is bool
    assert type(obj.colors) is int
    assert type(obj.program_name) is str
    assert obj.__str__() is not None

# Generated at 2022-06-23 18:58:40.629016
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    """
    Method Environment.log_error test
    """
    try:
        import colorama
    except ImportError:
        pass
    else:
        # noinspection PyUnresolvedReferences
        from colorama import AnsiToWin32
        import sys
        import os
        from httpie.utils import make_temp_config_dir
        with make_temp_config_dir() as env.config_dir:
            env.stdout = AnsiToWin32(sys.stdout)
            env.stderr = AnsiToWin32(sys.stderr)
            env.log_error('test', level='error')
            env.stderr.flush()
            env.stdout.flush()
            sys.stdout.flush()
            sys.stderr.flush()

# Generated at 2022-06-23 18:58:47.997940
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env_test = Environment(devnull=None, config_dir=Path('/home/mstr/.httpie'), stdin=sys.stdin, stdin_isatty=sys.stdin.isatty(), stdin_encoding=None, stdout=sys.stdout, stdout_isatty=sys.stdout.isatty(), stdout_encoding=None, stderr=sys.stderr, stderr_isatty=sys.stderr.isatty(), colors=256, program_name='http', _config=None, _devnull=None, _orig_stderr=sys.stderr)

# Generated at 2022-06-23 18:58:51.314197
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    str_env = str(env)
    assert str_env[0]=='{'
    assert str_env[-1]=='}'
    assert str_env[1:4]=='\'c'


# Generated at 2022-06-23 18:58:59.909391
# Unit test for constructor of class Environment
def test_Environment():
    from httpie.config import DEFAULT_CONFIG_DIR
    import sys
    import os
    from pathlib import Path

    e=Environment()
    # Current environment is httpie.compat.is_windows
    assert e.is_windows is True, "Environment is_windows is not correct"
    # Current environment is httpie.config.DEFAULT_CONFIG_DIR
    assert e.config_dir is DEFAULT_CONFIG_DIR, "Environment config_dir is not correct"
    # Current environment is sys.stdin
    assert e.stdin is sys.stdin, "Environment stdin is not correct"
    # Current environment is sys.stdin.isatty()
    assert e.stdin_isatty is sys.stdin.isatty(), "Environment stdin_isatty is not correct"
    # Current environment is

# Generated at 2022-06-23 18:59:11.932879
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == True
    assert isinstance(env.config_dir, Path)
    assert isinstance(env.stdin, IO)
    assert env.stdin_isatty == True
    assert isinstance(env.stdin_encoding, str)
    assert isinstance(env.stdout, IO)
    assert env.stdout_isatty == True
    assert isinstance(env.stdout_encoding, str)
    assert isinstance(env.stderr, IO)
    assert env.stderr_isatty == True
    assert env.colors > 0
    assert isinstance(env.program_name, str)
    assert isinstance(env.config, Config)
    assert isinstance(env.devnull, IO)

# Generated at 2022-06-23 18:59:23.327106
# Unit test for method __repr__ of class Environment

# Generated at 2022-06-23 18:59:34.207866
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    from httpie.context import Environment
    env = Environment()
    assert env.__repr__() == "<Environment {'is_windows': False, 'config_dir': '/Users/jianing/.config/httpie', 'stdin': <_io.TextIOWrapper encoding='utf-8'>, 'stdin_isatty': True, 'stdin_encoding': 'utf8', 'stdout': <_io.TextIOWrapper encoding='utf-8'>, 'stdout_isatty': True, 'stdout_encoding': 'utf8', 'stderr': <_io.TextIOWrapper encoding='utf-8'>, 'stderr_isatty': True, 'stderr_encoding': 'utf8', 'colors': 256, 'program_name': 'http'}>"

# Unit test

# Generated at 2022-06-23 18:59:45.420917
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()

# Generated at 2022-06-23 18:59:54.333735
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(config_dir='/config_dir', stdin_encoding='utf8')

# Generated at 2022-06-23 19:00:02.032871
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import BytesIO
    class env_object(Environment):
        def __init__(self):
            super().__init__()
            self._orig_stderr = BytesIO()
    
    env = env_object()
    env.log_error("Hello, Error!","error")
    output = env._orig_stderr.getvalue().decode()
    assert "error" in output
    env.log_error("Hello, Warning!","warning")
    output = env._orig_stderr.getvalue().decode()
    assert "warning" in output

# Generated at 2022-06-23 19:00:12.377355
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    env.config_dir = Path('/home/test/.httpie')

# Generated at 2022-06-23 19:00:20.256536
# Unit test for method __repr__ of class Environment

# Generated at 2022-06-23 19:00:30.658269
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    env.stdin = io.StringIO()
    env.stdout = io.StringIO()
    env.stderr = io.StringIO()

# Generated at 2022-06-23 19:00:39.745789
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    actual = repr(env)

# Generated at 2022-06-23 19:00:49.631958
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    import sys
    import tempfile

    env = Environment()
    stdout = io.StringIO()
    sys.stdout = stdout
    env.log_error('Test', level='error')
    assert 'http: error: Test' in stdout.getvalue()
    stdout.close()
    sys.stdout = sys.__stdout__

    stdout = io.StringIO()
    sys.stdout = stdout
    env.log_error('Test', level='warning')
    assert 'http: warning: Test' in stdout.getvalue()
    stdout.close()
    sys.stdout = sys.__stdout__



# Generated at 2022-06-23 19:01:01.249751
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    import sys

    # devnull
    env = Environment(devnull=sys.stdin)

# Generated at 2022-06-23 19:01:09.509218
# Unit test for constructor of class Environment
def test_Environment():
    # testing default environment variables
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == env.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == env.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == env.stderr.isatty()
    assert env.program_name == 'http'

    # testing with non-existant config directory

# Generated at 2022-06-23 19:01:10.496467
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    assert Environment().log_error("Test Error")

# Generated at 2022-06-23 19:01:17.124277
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(is_windows=True, config_dir=Path(os.getcwd()), stdin=None, stdin_isatty=False, stdin_encoding=None, stdout=sys.stdout, stdout_isatty=True, stdout_encoding=None, stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http')
    print(env)

# Generated at 2022-06-23 19:01:28.424647
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(config_dir="/home/user/.httpie/", stdin=None, stdin_isatty=True, stdin_encoding="utf8",stdout=sys.stdout, stdout_isatty=True, stdout_encoding="utf8", stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http' )

# Generated at 2022-06-23 19:01:39.067533
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    from io import BytesIO

    env = Environment(
        devnull=BytesIO(),
        stdin=None,
        stdin_encoding=None,
        stdout=BytesIO(),
        stdout_encoding='utf8',
        stderr=BytesIO(),
        stderr_isatty=False,
        colors=256,
        program_name='http'
    )

    assert repr(env) == '<Environment {' \
                         '"colors": 256, ' \
                         '"config": <httpie.config.Config object at 0x0000015009E9F2C8>, ' \
                         '"is_windows": False, ' \
                         '"program_name": "http", ' \
                         '"stdin": None, ' \
                         '"stdin_encoding": None, '

# Generated at 2022-06-23 19:01:47.538204
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    import sys
    import unittest

    sys.stderr = io.StringIO()  # Workaround for pytest
    stderr = io.StringIO()

    class TestEnvironment(Environment):
        def __init__(self):
            super(TestEnvironment, self).__init__(
                stderr = stderr
            )

    env = TestEnvironment()
    env.log_error("Test message", level = 'error')
    assert stderr.getvalue() == '\nhttp: error: Test message\n\n'
    stderr.close()



# Generated at 2022-06-23 19:01:55.074574
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()

# Generated at 2022-06-23 19:02:03.406801
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    import httpie.core
    env = httpie.core.Environment()

# Generated at 2022-06-23 19:02:13.271898
# Unit test for method log_error of class Environment
def test_Environment_log_error():
   env = Environment()
   env.program_name = 'test'
   fd = open("test_log_error.txt", 'w')
   env.stderr = fd
   env._orig_stderr = fd
   msg = bytes("testmessage", "UTF-8").decode("unicode_escape")
   env.log_error(msg, level='error')
   fd.seek(0)
   filedata = fd.read()
   actual = filedata.replace("\n", "")
   expected = "test: error: testmessage"
   assert actual == expected
   env.stderr.close()

# Generated at 2022-06-23 19:02:24.081653
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    expected = '<Environment colors:256, colors:256, config_dir:/home/.config/httpie, is_windows:False, program_name:http, stderr:<_io.TextIOWrapper name=2 encoding=UTF-8>, stderr_encoding:UTF-8, stderr_isatty:True, stdin:<_io.TextIOWrapper name=0 encoding=UTF-8>, stdin_encoding:UTF-8, stdin_isatty:True, stdout:<_io.TextIOWrapper name=1 encoding=UTF-8>, stdout_encoding:UTF-8, stdout_isatty:True>'
    assert str(env) == expected

_env: Environment = Environment()
env = _env

# Generated at 2022-06-23 19:02:35.332642
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from httpie.config import Config
    from httpie.environment import Environment
    config = Config(directory='')
    config.load()
    env = Environment(config_dir=config.directory, config=config)

# Generated at 2022-06-23 19:02:45.587218
# Unit test for constructor of class Environment
def test_Environment():
    # Create a Object 'env' of the class Environment
    env = Environment()

    # Check if the class variable 'is_windows' of the created class object 'env' is True
    assert env.is_windows == True

    # Check if the class variable 'config_dir' of the created class object 'env' is DEFAULT_CONFIG_DIR
    assert env.config_dir == DEFAULT_CONFIG_DIR

    # Check if the class variable 'stdin' of the created class object 'env' is sys.stdin
    assert env.stdin == sys.stdin

    # Check if the class variable 'stdin_isatty' of the created class object 'env' is True
    assert env.stdin_isatty == True

    # Check if the class variable 'stdin_encoding' of the created class object 'env' is utf8

# Generated at 2022-06-23 19:02:49.262957
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    environment = Environment()
    assert environment.log_error('Warning') == ['\n', 'http', ':', ' ', 'warning', ':', ' ', 'Warning', '\n\n']

# Generated at 2022-06-23 19:02:53.735689
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    class TTY:
        encoding = 'utf8'
        def write(self, s):
            pass

    env = Environment(stdout=TTY(), stderr=TTY())
    env.log_error('error message 1')
    env.log_error('error message 2', level='warning')


# Generated at 2022-06-23 19:03:04.003335
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    """
    Unit test for method __str__ of class Environment.
    """
    print("test_Environment___str__()")
    # Get environment object
    env = Environment(config_dir='test_config_dir', stdin='test_stdin',
                      stdin_isatty=True, stdin_encoding='test_stdin_encoding',
                      stdout='test_stdout', stdout_isatty=True,
                      stdout_encoding='test_stdout_encoding',
                      stderr='test_stderr', stderr_isatty=True,
                      program_name='test_program_name',
                      devnull='None')
    print(env)



# Generated at 2022-06-23 19:03:11.372063
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    import sys
    sys.argv.append('http')
    env = Environment()
    envString = env.__str__()

# Generated at 2022-06-23 19:03:20.945662
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    e = Environment()

# Generated at 2022-06-23 19:03:32.479716
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(stdin = 'stdin', stdout = 'stdout', stderr = 'stderr')
    stdin = environment.stdin
    assert stdin == 'stdin'
    stdin_isatty = environment.stdin_isatty
    assert stdin_isatty == False
    stdin_encoding = environment.stdin_encoding
    assert stdin_encoding == None
    stdout = environment.stdout
    assert stdout == 'stdout'
    stdout_isatty = environment.stdout_isatty
    assert stdout_isatty == False
    stdout_encoding = environment.stdout_encoding
    assert stdout_encoding == None
    stderr = environment.stderr
    assert stderr == 'stderr'
    stder

# Generated at 2022-06-23 19:03:38.431169
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    assert repr(env) == "<Environment {'stdout_isatty': True, 'colors': 256, 'stdin_isatty': True, 'stdout_encoding': 'UTF-8', 'stderr_isatty': True, 'program_name': 'http', 'stdin_encoding': 'UTF-8'}>"


# Generated at 2022-06-23 19:03:39.941514
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    print(env)


env = Environment()

# Generated at 2022-06-23 19:03:50.807188
# Unit test for constructor of class Environment
def test_Environment():
    import io
    import tempfile
    stdin = io.BytesIO()
    stdout = io.StringIO()
    stderr = io.StringIO()
    config_dir = tempfile.mkdtemp()
    env = Environment(
        stdin=stdin, stdin_isatty=False,
        stdout=stdout, stdout_isatty=False,
        stderr=stderr, stderr_isatty=False,
        config_dir=Path(config_dir),
        colors=5, program_name='xxx'
    )
    # Check attributes
    assert env.is_windows == is_windows
    assert env.stdin == stdin
    assert env.stdin_isatty == False
    assert env.stdout == stdout
    assert env.stdout_isat

# Generated at 2022-06-23 19:03:53.822860
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    msg = "Hello"
    environment = Environment()
    stderr = io.StringIO()
    environment.stderr = stderr
    environment.log_error(msg)
    assert msg in stderr.getvalue()

# Generated at 2022-06-23 19:04:04.005131
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == 'utf8'
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert not env.is_windows

# Generated at 2022-06-23 19:04:08.349266
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    stream = io.StringIO('')
    expected = '\nhttpie: warning: msg\n\n'
    env = Environment(stderr=stream)
    env.log_error('msg', level='warning')
    assert stream.getvalue() == expected


# Generated at 2022-06-23 19:04:16.983814
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    msg = 'TEST'
    from io import StringIO
    stderr = StringIO()
    env.stderr = stderr
    env.program_name = 'test'
    for level in ['error', 'warning']:
        env.log_error(msg, level)
        e = stderr.getvalue()
        stderr.seek(0)
        stderr.truncate(0)
        assert e == f'\ntest: {level}: {msg}\n\n'

# Generated at 2022-06-23 19:04:24.593765
# Unit test for constructor of class Environment
def test_Environment():
    print("Testing Environment constructor")
    print("Default environment")
    e = Environment()
    print("Environment with stdin:")
    e = Environment(stdin=sys.stdin)
    print("Environment with stdin, stdout and stderr:")
    e = Environment(stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr)

if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-23 19:04:35.220886
# Unit test for constructor of class Environment
def test_Environment():
    import io
    s = io.StringIO()
    env = Environment()
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    env = Environment(stdout = s)
    assert env.stdout == s
    assert env.stderr == sys.stderr
    env = Environment(stderr = s)
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == s

    env = Environment(devnull = s)
    assert env.devnull == s
    env = Environment(devnull = None)
    assert env.devnull == None
    env.devnull = s
    assert env.devnull == s

# Generated at 2022-06-23 19:04:42.204838
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    import sys
    stream = io.StringIO()
    sys.stderr = stream
    env = Environment(program_name='prog', stderr=stream)
    env.log_error(msg='Test', level='error')
    msg = stream.getvalue()
    env.devnull.close()
    assert msg == '\nprog: error: Test\n\n'

# Generated at 2022-06-23 19:04:52.466002
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    assert Environment(stdin=None) == \
        """<Environment {'colors': 256, 'config_dir': PosixPath('/Users/yi/.config/httpie'), 'is_windows': False, 'program_name': 'http', 'stdin': None, 'stdin_encoding': 'utf8', 'stdin_isatty': False, 'stdout': <_io.TextIOWrapper name='<stdout>' mode='w' encoding='UTF-8'>, 'stdout_encoding': 'utf8', 'stdout_isatty': True, 'stderr': <_io.TextIOWrapper name='<stderr>' mode='w' encoding='UTF-8'>, 'stderr_isatty': True}>"""

# Generated at 2022-06-23 19:04:55.944277
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    assert str(Environment()) == "{'config': None, 'colors': 256, 'program_name': 'http'}"
    assert str(Environment(colors = 16,program_name = "http2")) == "{'config': None, 'colors': 16, 'program_name': 'http2'}"


# Generated at 2022-06-23 19:05:00.670664
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    output = repr(env)

# Generated at 2022-06-23 19:05:02.237846
# Unit test for constructor of class Environment
def test_Environment():
    # Create an environment and update it
    env = Environment()
    env.stdout = "stdout"
    assert env.stdout == "stdout"
    
    # Create an environment with a given stdout
    env = Environment(stdout="stdout")
    assert env.stdout == "stdout"

# Generated at 2022-06-23 19:05:07.065331
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment(colors=256)

# Generated at 2022-06-23 19:05:11.633990
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from click.testing import CliRunner
    from httpie.cli.main import main

    runner = CliRunner()
    result = runner.invoke(main, args=['--config=.', '--config-dir=./test', '--ignore-stdin', 'info'],
                           env={'HTTPIE_CONFIG_DIR': os.getcwd()})
    # TODO: test result output
    assert not result.exception

# Generated at 2022-06-23 19:05:21.822413
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment(
        is_windows=True,
        config_dir='httpie',
        stdin=None,
        stdin_isatty=False,
        stdin_encoding=None,
        stdout=sys.stdout,
        stdout_isatty=sys.stdout.isatty(),
        stdout_encoding=None,
        stderr=sys.stderr,
        stderr_isatty=sys.stderr.isatty(),
        colors=256,
        program_name='http'
    )
    print(env)
    print(env.__repr__())

if __name__ == '__main__':
    test_Environment___repr__()

# Generated at 2022-06-23 19:05:24.925261
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.stderr = io.StringIO()
    env.log_error('122')
    assert env.stderr.getvalue() == '\nhttp: error: 122\n\n'

# Generated at 2022-06-23 19:05:36.008280
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    str_env = str(env)

# Generated at 2022-06-23 19:05:45.745962
# Unit test for method __repr__ of class Environment

# Generated at 2022-06-23 19:05:49.902888
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment()
    assert type(e) == Environment
    assert e.is_windows == is_windows
    assert e.config_dir == DEFAULT_CONFIG_DIR
    assert e.colors == 256
    assert e.program_name == 'http'

# Generated at 2022-06-23 19:05:53.943593
# Unit test for constructor of class Environment
def test_Environment():
    import io
    import sys
    env = Environment()
    assert  isinstance(env, Environment)
    env = Environment(stdin = io.StringIO(sys.stdin.read()))
    assert isinstance(env, Environment)

# Unittest to check the type of attributes

# Generated at 2022-06-23 19:06:04.947009
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    e = Environment(config_dir = os.getcwd(), stdin = sys.stdin, stdout = sys.stdout, stderr = sys.stderr, program_name = 'http')

# Generated at 2022-06-23 19:06:14.684256
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    env.is_windows = True
    env.config_dir = DEFAULT_CONFIG_DIR
    env.stdin = sys.stdin
    env.stdin_isatty = True
    env.stdin_encoding = None
    env.stdout = sys.stdout
    env.stdout_isatty = True
    env.stdout_encoding = None
    env.stderr = sys.stderr
    env.stderr_isatty = True
    env.colors = 256
    env.program_name = 'http'
    assert str(env) == "http"
    assert repr(env) == "<Environment <http: http>>"


# Generated at 2022-06-23 19:06:19.886424
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    streams = [io.StringIO(), io.StringIO()]
    env = Environment(stderr=streams[0])
    env.log_error("abc", level="warning")
    assert streams[0].getvalue() == "http: warning: abc\n\n"


# Generated at 2022-06-23 19:06:29.450822
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    e = Environment()
    #assert str(e) == '<Environment {\'is_windows\': False, \'config_dir\': PosixPath(\'/home/httpie/.httpie\'), \'stdin\': <_io.TextIOWrapper name=\'<stdin>\' mode=\'r\' encoding=\'UTF-8\'>, \'stdin_isatty\': True, \'stdin_encoding\': \'utf8\', \'stdout\': <_io.TextIOWrapper name=\'<stdout>\' mode=\'w\' encoding=\'UTF-8\'>, \'stdout_isatty\': True, \'stdout_encoding\': \'utf8\', \'stderr\': <_io.TextIOWrapper name=\'<stderr>\' mode=\'w\' encoding=\'UTF-8

# Generated at 2022-06-23 19:06:33.884552
# Unit test for constructor of class Environment
def test_Environment():
    # test __init__
    env = Environment(stdout='codecs.getwriter("utf-8")')
    assert env.stdout == 'codecs.getwriter("utf-8")'



# Generated at 2022-06-23 19:06:44.884519
# Unit test for constructor of class Environment
def test_Environment():
    import io
    import tempfile
    tempLocal = tempfile.TemporaryFile()
    tempLocal.name = "tempFileName"
    tempLocal.encoding = "defaultencoding"
    tempLocal.stdin = 1
    env = Environment(stdout=tempLocal, stdin=tempLocal, stderr=tempLocal, config_dir=tempfile.gettempdir(), stdin_encoding= "defaultencoding", stdout_encoding= "defaultencoding", stderr_encoding= "defaultencoding", is_windows=False)
    assert env.config_dir == tempfile.gettempdir()
    assert env.stdout == tempLocal
    assert env.stdout_encoding == "defaultencoding"
    assert env.stderr == tempLocal

# Generated at 2022-06-23 19:06:52.890432
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()

# Generated at 2022-06-23 19:07:02.610711
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()

# Generated at 2022-06-23 19:07:06.514656
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    assert isinstance(env, Environment)
    assert isinstance(env.log_error, FunctionType)
    env.log_error('test')
    assert env.log_error('test') == None

test_Environment_log_error()

# Generated at 2022-06-23 19:07:12.568638
# Unit test for method __str__ of class Environment

# Generated at 2022-06-23 19:07:18.229524
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    sys.stdin.name = '<stdin>'
    sys.stdout.name = '<stdout>'
    sys.stderr.name = '<stderr>'
    try:
        print(Environment())
    finally:
        # Don't leave the terminal in a messed up state.
        sys.stdin.name = '<stdin>'

# Generated at 2022-06-23 19:07:27.940318
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    # Test warnings
    try:
        env = Environment()
        env.log_error('Test Warning Message', level="warning")
    except Exception as e:
        assert False, 'Unexpected exception when logging a warning: {}'.format(e)
    # Test errors
    try:
        env = Environment()
        env.log_error('Test Error Message', level="error")
    except Exception as e:
        assert False, 'Unexpected exception when logging an error: {}'.format(e)
    # Test for unexpected exception
    try:
        env = Environment()
        env.log_error('Unexpected exception', level="invalid")
    except Exception as e:
        assert "Unexpected exception when logging a log_level: invalid" in str(e)


# Generated at 2022-06-23 19:07:28.485146
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    assert True



# Generated at 2022-06-23 19:07:30.598322
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error("Hello", level='error')
    env.log_error("Hello again", level='warning')

# Generated at 2022-06-23 19:07:33.539589
# Unit test for constructor of class Environment
def test_Environment():

    class TestConf(Environment):
        def __init__(self, **kwargs):
            assert all(hasattr(type(self), attr) for attr in kwargs.keys())
            self.__dict__.update(**kwargs)
            
    env = TestConf()
    assert env



# Generated at 2022-06-23 19:07:38.800191
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    class _Error(Exception):
        pass

    env = Environment()

    # test case 1
    try:
        raise _Error('test_Error')
    except _Error as e:
        env.log_error(e, level='error')
        env.log_error(e, level='warning')



# Generated at 2022-06-23 19:07:47.024144
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment(stdout=io.StringIO(), stderr=io.StringIO())
    assert env.stderr == env._orig_stderr
    env.log_error('err_msg')
    assert env.stderr.getvalue() == '\nhttp: error: err_msg\n\n'
    env.stderr.truncate(0)
    env.log_error('err_msg', level='warning')
    assert env.stderr.getvalue() == '\nhttp: warning: err_msg\n\n'

# Generated at 2022-06-23 19:07:57.161987
# Unit test for constructor of class Environment
def test_Environment():
    """
    This unit test is for testing the constructor of the class Environment in the file environment.py.
    """
    from pathlib import Path
    from httpie import ExitStatus
    from httpie import ExitStatus
    from httpie.compat import is_windows
    from httpie.config import Config, ConfigFileError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.plugins import plugin_manager
    import sys

    class Environment():
        is_windows: bool = is_windows
        config_dir: Path = Path(__file__).parent
        stdin: Optional[IO] = sys.stdin  # `None` when closed fd (#791)
        stdin_isatty: bool = stdin.isatty() if stdin else False

# Generated at 2022-06-23 19:08:02.759442
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    """
    1. 测试 Environment 类型的 __str__() 方法
    1. 测试 Environment 类型的 __repr__() 方法
    1. 测试 Environment 类型的 config 属性
    """
    env = Environment(foo='bar')
    print(str(env))
    print(env)

# Generated at 2022-06-23 19:08:14.550539
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        stdin=None,
        stdin_isatty=False,
        stdin_encoding=None,
        stdout=sys.stdout,
        stdout_isatty=False,
        stdout_encoding=None,
        stderr=sys.stderr,
        stderr_isatty=False,
        program_name='http',
        devnull=None
    )
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == None
    assert env.stdin_isatty == False
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == False
    assert env.stdout

# Generated at 2022-06-23 19:08:25.216336
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()