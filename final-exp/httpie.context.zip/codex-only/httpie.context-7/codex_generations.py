

# Generated at 2022-06-23 18:58:30.665606
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import StringIO
    from httpie.compat import is_py37
    from httpie.environment import Environment
    from httpie.exceptions import InvalidOptions
    stderr = StringIO()
    env = Environment(stderr=stderr)
    # str(InvalidOptions) = "Invalid options: "
    msg = str(InvalidOptions()) + "Some error message"
    env.log_error(msg, level='error')
    stderr.seek(0)
    output = stderr.read()
    assert output.startswith("\nhttp: error: ")
    end = "\n\n"
    if is_py37:
        end += "\x1b[0m\n"
    assert output.endswith(end)

# Generated at 2022-06-23 18:58:39.900305
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from httpie.core import env
    env.stdout = None
    assert repr_dict(env) == '''{'colors': 256, 'config': <Config {}>, 'config_dir': PosixPath('/home/kevin/.httpie'), 'is_windows': False, 'stdin': None, 'stdin_encoding': 'utf8', 'stdin_isatty': False, 'stdout': None, 'stdout_encoding': 'utf8', 'stdout_isatty': False, 'stderr': <sys.stderr>, 'stderr_isatty': True}'''
    env.stdout = sys.stdout

# Generated at 2022-06-23 18:58:50.952857
# Unit test for constructor of class Environment
def test_Environment():
    # To test the Environment class, we first define a function to test if the function
    # behaves as expected when a certain combination of arguments is passed.
    def test_keywords(**kwargs):
        e = Environment(**kwargs)
        for name, value in kwargs.items():
            assert getattr(e, name) == value
        return e

    # Test the constructor of class Environment.

# Generated at 2022-06-23 18:58:59.641273
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    import sys
    import os

    config_dir = os.path.join(os.getcwd(), 'httpie-config')
    stdout = io.StringIO()
    stderr = io.StringIO()
    env = Environment(stdin=None, stdout=stdout, stderr=stderr)
    env.config_dir = config_dir
    env.log_error('error_msg', level='error')
    env.log_error('warning_msg', level='warning')

    stdout.seek(0)
    stderr.seek(0)

    assert(stdout.read() == '')
    assert(stderr.read() == '\nhttpie: error: error_msg\n\n\nhttpie: warning: warning_msg\n\n')


env

# Generated at 2022-06-23 18:59:11.930519
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment()
    assert e.is_windows == is_windows
    assert e.config_dir == DEFAULT_CONFIG_DIR
    assert e.stdin == sys.stdin
    assert e.stdin_isatty == sys.stdin.isatty()
    assert e.stdin_encoding == None
    assert e.stdout == sys.stdout
    assert e.stdout_isatty == sys.stdout.isatty()
    assert e.stdout_encoding == None
    assert e.stderr == sys.stderr
    assert e.stderr_isatty == sys.stderr.isatty()
    assert e.colors == 256
    assert e.program_name == 'http'
    assert e._orig_stderr == sys.stderr
   

# Generated at 2022-06-23 18:59:21.547079
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    class MyStringIO(io.StringIO):
        def __enter__(self):
            return self
        def __exit__(self, exc_type, exc_val, exc_tb):
            self.close()

    my_stderr = MyStringIO()
    env = Environment(stderr=my_stderr, colors=0)
    env.log_error('This is a test')
    stderr_text = my_stderr.getvalue()
    my_stderr.close()
    assert stderr_text == '\nhttp: error: This is a test\n\n'



# Generated at 2022-06-23 18:59:28.629149
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    assert env._orig_stderr

    import io
    stderr = io.StringIO()
    env.stderr = stderr

    msg = "test error"
    env.log_error(msg=msg, level='error')
    env.log_error(msg=msg, level='warning')

    assert msg in stderr.getvalue()
    assert msg in stderr.getvalue()
    stderr.close()

# Generated at 2022-06-23 18:59:38.639883
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    import os
    import tempfile
    env = Environment()
    env.is_windows = os.name == 'nt'
    env.config_dir = tempfile.gettempdir()
    env.config = 'test'
    env.stdin = sys.stdin
    env.stdin_isatty = sys.stdin.isatty()
    env.stdin_encoding = sys.stdin.encoding
    env.stdout = sys.stdout
    env.stdout_isatty = sys.stdout.isatty()
    env.stdout_encoding = sys.stdout.encoding
    env.colors = 256
    env.program_name = 'http'

# Generated at 2022-06-23 18:59:40.204747
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    temp = Environment(colors=2)
    print(temp)
    assert 1 == 1


# Generated at 2022-06-23 18:59:50.608568
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    class MyEnv(Environment):
        stdin = []
        stdout = []
        stderr = []
    e = MyEnv()
    e.config.default_options['verify'] = 'foobar'
    assert e.__repr__() == '<Environment {\'is_windows\': False, \'config_dir\': \'~/.config/httpie\', \'stdin\': [], \'stdin_isatty\': False, \'stdin_encoding\': None, \'stdout\': [], \'stdout_isatty\': False, \'stdout_encoding\': None, \'stderr\': [], \'stderr_isatty\': False, \'colors\': 256, \'program_name\': \'http\', \'config\': <Config (new)>}>'

# Generated at 2022-06-23 18:59:57.543560
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    # Log error to stderr by default
    with io.StringIO() as buf, contextlib.redirect_stderr(buf):
        env.log_error('test_Environment_log_error')
        buf.seek(0)
        assert buf.read().strip() == 'http: error: test_Environment_log_error'
    # Log warning to stderr by default
    with io.StringIO() as buf, contextlib.redirect_stderr(buf):
        env.log_error('test_Environment_log_error', level='warning')
        buf.seek(0)
        assert buf.read().strip() == 'http: warning: test_Environment_log_error'
    # Log error to stderr passed
    with io.StringIO() as buf:
        env.log_error

# Generated at 2022-06-23 19:00:02.197458
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    err_file = io.BytesIO()
    err_file.encoding = 'utf8'
    env = Environment(stderr=err_file)
    env.log_error('Parse error')
    expected = b'\nhttp: error: Parse error\n\n'
    assert err_file.getvalue() == expected

# Generated at 2022-06-23 19:00:09.035901
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    return prepr(
        Environment(
            is_windows=True,
            stdin=None,
            stdin_isatty=True,
            stdin_encoding='utf8',
            stdout=sys.stdout,
            stdout_isatty=True,
            stdout_encoding='utf8',
            stderr=sys.stderr,
            stderr_isatty=True,
            colors=256,
            program_name='http',
        )
    )

# Generated at 2022-06-23 19:00:18.091151
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    class FakeStderr:
        def __init__(self):
            self.content = []

        def write(self, msg):
            self.content.append(msg)

    env = Environment(
        stdout=sys.stdout, stderr=FakeStderr(), _orig_stderr=FakeStderr()
    )

    env.log_error('abc', level='error')
    assert env.stderr.content == ['\n', 'http: error: abc\n', '\n']
    assert env._orig_stderr.content == ['\n', 'http: error: abc\n', '\n']

    env.log_error('xyz', level='warning')

# Generated at 2022-06-23 19:00:24.727225
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from httpie import ExitStatus
    from httpie.utils import StdoutBytesIO
    from httpie.core import main
    from io import StringIO

    env = Environment()
    env._orig_stderr = stderr = StringIO()
    env.log_error('test')
    assert stderr.getvalue() == """\

http: warning: test

"""
    stderr.close()
    stderr = StringIO()
    env._orig_stderr = stderr
    env.log_error('his is a test')
    assert stderr.getvalue() == """\

http: warning: this is a test

"""
    stderr.close()
    stderr = StringIO()
    env._orig_stderr = stderr

# Generated at 2022-06-23 19:00:29.778657
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io

    stderr = io.StringIO()
    env = Environment(stderr=stderr)

    env.log_error( 'Test' )

    assert stderr.getvalue() == '\nhttp: error: Test\n\n'
    stderr.close()

# Generated at 2022-06-23 19:00:34.617392
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import StringIO
    from httpie.core import Environment
    test_Environment = Environment()
    test_Environment._orig_stderr = StringIO()
    test_Environment.log_error('This is a error')
    assert test_Environment._orig_stderr.getvalue() == '\nhttp: error: This is a error\n\n'

# Generated at 2022-06-23 19:00:42.345457
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment()
    assert getattr(e, 'is_windows') == Environment.is_windows
    assert getattr(e, 'config_dir') == Environment.config_dir
    assert getattr(e, 'stdin') == Environment.stdin
    assert getattr(e, 'stdin_isatty') == Environment.stdin_isatty
    assert getattr(e, 'stdin_encoding') == Environment.stdin_encoding
    assert getattr(e, 'stdout') == Environment.stdout
    assert getattr(e, 'stdout_isatty') == Environment.stdout_isatty
    assert getattr(e, 'stdout_encoding') == Environment.stdout_encoding
    assert getattr(e, 'stderr') == Environment.stderr

# Generated at 2022-06-23 19:00:52.735850
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == env.stdin.isatty()
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == env.stdout.isatty()
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == env.stderr.isatty()
    assert env.stdout_encoding is not None
    assert env.program_name == 'http'


# Generated at 2022-06-23 19:01:04.041000
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        stdin_encoding='foo_stdin',
        stdout_encoding='foo_stdout',
        stderr_encoding='foo_stderr',
        colors=123,
        devnull='bar_devnull'
    )
    assert env.stdin_encoding == 'foo_stdin'
    assert env.stdout_encoding == 'foo_stdout'
    assert env.stderr_encoding == 'foo_stderr'
    assert env.colors == 123
    assert env.devnull == 'bar_devnull'

# Generated at 2022-06-23 19:01:06.832283
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error('This is an error.')
    env.log_error('This is a warning',level='warning')

# Generated at 2022-06-23 19:01:07.900110
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
   env = Environment()
   repr(env)


# Generated at 2022-06-23 19:01:09.540788
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error("Python is awesome")

# Generated at 2022-06-23 19:01:20.685591
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    """Test method __repr__ of class Environment"""
    env = Environment(config_dir=Path('/home/user/httpie'))

# Generated at 2022-06-23 19:01:32.031619
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    # env.stderr = io.StringIO()

    httpie_stderr = io.BytesIO()
    env.stderr = io.TextIOWrapper(httpie_stderr, encoding=env.stdout_encoding)

    msg = 'oops! it is reported'
    env.log_error(msg)
    # assert env.stderr.getvalue() == \
    #        f'\n{env.program_name}: error: {msg}\n\n'
    assert httpie_stderr.getvalue() == \
           f'\n{env.program_name}: error: {msg}\n\n'.encode(env.stdout_encoding)

# test_Environment_log_error()

# Generated at 2022-06-23 19:01:40.044819
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    assert repr(env) == '<Environment {stdout_isatty: True, colors: 256, program_name: \'http\', config_dir: Path(\'/Users/mylove/.config/httpie\'), stderr_isatty: True, stderr: <_io.TextIOWrapper name=\'/dev/pts/2\' mode=\'w\' encoding=\'UTF-8\'>, stdin: <_io.TextIOWrapper name=\'/dev/pts/2\' mode=\'r\' encoding=\'UTF-8\'>, stdin_isatty: True, stdout_encoding: \'utf8\', stderr_encoding: \'utf8\'}>'


# Generated at 2022-06-23 19:01:50.796120
# Unit test for method __str__ of class Environment
def test_Environment___str__():

    # test_all_defaults
    env = Environment()
    assert "colors=256" in str(env)
    assert "config=None" in str(env)
    assert "devnull=None" in str(env)
    assert "is_windows=False" in str(env)
    assert "program_name='http'" in str(env)
    assert "stdin=<_io.TextIOWrapper" in str(env)
    assert "stdin_encoding='utf-8'" in str(env)
    assert "stdin_isatty=True" in str(env)
    assert "stdout=<_io.TextIOWrapper" in str(env)
    assert "stdout_encoding='utf-8'" in str(env)

# Generated at 2022-06-23 19:02:00.820584
# Unit test for method __str__ of class Environment

# Generated at 2022-06-23 19:02:12.155581
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    defaultValue = Environment()
    defaultValueStr = defaultValue.__str__()
    assert "DevNull = None" in defaultValueStr
    assert "stdin = <_io.TextIOWrapper" in defaultValueStr
    assert "stdin_encoding = None" in defaultValueStr
    assert "stdout = <_io.TextIOWrapper" in defaultValueStr
    assert "stdout_encoding = None" in defaultValueStr
    assert "stderr = <_io.TextIOWrapper" in defaultValueStr
    assert "stderr_isatty = True" in defaultValueStr
    assert "colors = 256" in defaultValueStr
    assert "program_name = 'http'" in defaultValueStr


# Generated at 2022-06-23 19:02:20.043394
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    assert str(env) == repr_dict({
        'is_windows': False,
        'config_dir': Path.home() / '.httpie',
        'stdin': sys.stdin,
        'stdin_isatty': sys.stdin.isatty(),
        'stdin_encoding': None,
        'stdout': sys.stdout,
        'stdout_isatty': sys.stdout.isatty(),
        'stdout_encoding': None,
        'stderr': sys.stderr,
        'stderr_isatty': sys.stderr.isatty(),
        'colors': 256,
        'program_name': 'http',
        'config': {}
    })


# Generated at 2022-06-23 19:02:21.858195
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error(msg = "foo")
    assert True


# Generated at 2022-06-23 19:02:28.640806
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    __tracebackhide__ = True
    # Default
    assert repr(env).endswith("'config': None}>")
    # Set config
    env.config_dir = '/path/to/config'
    # Reload config
    env._config = Config(directory=env.config_dir)
    assert repr(env).endswith("'config': Config()}>")

test_Environment___repr__()



# Generated at 2022-06-23 19:02:40.226352
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment(
        is_windows=False, config_dir='123', stdin='456', stdin_isatty=True,
        stdin_encoding='789', stdout='abc', stdout_isatty=True,
        stdout_encoding='def', stderr='ghi', stderr_isatty=True, colors=32,
        program_name='123', colors=90, colors=8, colors=256, colors=0,
        colors=None, colors=3, colors=5, colors=1
    )
    assert e.is_windows == False
    assert e.config_dir == Path('123')
    assert e.stdin == '456'
    assert e.stdin_isatty == True
    assert e.stdin_encoding == '789'
    assert e.std

# Generated at 2022-06-23 19:02:47.510818
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    assert Environment().program_name == 'http'
    assert Environment().config_dir == DEFAULT_CONFIG_DIR
    assert Environment().stdin == sys.stdin
    assert Environment().stdin_isatty == sys.stdin.isatty()
    assert Environment().stdin_encoding == None
    assert Environment().stdout == sys.stdout
    assert Environment().stdout_isatty == sys.stdout.isatty()
    assert Environment().stdout_encoding == None
    assert Environment().stderr == sys.stderr
    assert Environment().stderr_isatty == sys.stderr.isatty()
    assert Environment().config == Config(directory = 'C:\\Users\\USERNAME\\.config\\httpie')
    assert isinstance(Environment().config,Config)
    assert Environment().is_

# Generated at 2022-06-23 19:02:51.672872
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull='abc')
    assert env.devnull == 'abc'
    assert env.stderr_isatty == False
    env.devnull = None
    env.stderr_isatty = True



# Generated at 2022-06-23 19:02:56.902869
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    cap = io.StringIO()
    env = Environment(stderr=cap)
    env.log_error('message1')
    env.log_error('message2', level='warning')
    assert cap.getvalue() == ('\nhttp: error: message1\n\n'
                              '\nhttp: warning: message2\n\n')


# Generated at 2022-06-23 19:03:07.683127
# Unit test for constructor of class Environment
def test_Environment():
    stdin = [sys.stdin, None]
    stdout = [sys.stdout, None]
    stderr = [sys.stderr, None]
    program_name = ['http', '']
    devnull = [None, 'test']
    color = [16, 256]

    # to check the constructor of Environment class
    for i in range(2):
        env = Environment(stdin=stdin[i], stdout=stdout[i], stderr=stderr[i], program_name=program_name[i],
                          devnull=devnull[i], colors=color[i])

        assert env.is_windows == is_windows
        assert env.config_dir == DEFAULT_CONFIG_DIR
        assert env.stdin == stdin[i]
        assert env.stdout == std

# Generated at 2022-06-23 19:03:18.717076
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import sys
    import io
    import logging
    my_stderr = io.StringIO()
    sys.stderr = my_stderr
    logging.basicConfig(level=logging.DEBUG)

    program_name = 'http'
    dummy_msg = 'woops, something went wrong'
    error_msg = f'{dummy_msg}\n'
    warning_msg = f'{dummy_msg}\n'
    my_stderr.truncate(0)
    my_stderr.seek(0)
    env = Environment()
    env.log_error(dummy_msg)
    assert my_stderr.read() == error_msg
    my_stderr.truncate(0)
    my_stderr.seek(0)
    env.log_error

# Generated at 2022-06-23 19:03:24.159517
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows == is_windows
    assert environment.stdout == sys.stdout
    assert environment.stderr == sys.stderr
    assert environment.stdout_isatty == sys.stdout.isatty()
    assert environment.stderr_isatty == sys.stderr.isatty()
    assert environment.program_name == 'http'

# Generated at 2022-06-23 19:03:35.555361
# Unit test for constructor of class Environment
def test_Environment():
    os.environ['HTTPIE_CONFIG_DIR'] = 'C:\\Users\\Any\\'
    env = Environment()

    assert env.is_windows == True
    assert env.config_dir == Path(os.environ['HTTPIE_CONFIG_DIR'])
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == True if sys.stdin.isatty() else False
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True if sys.stdout.isatty() else False
    assert env.stdout_encoding == 'utf8'
    assert env.stderr == sys.stderr

# Generated at 2022-06-23 19:03:47.128781
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    obj = Environment()
    actual = '<Environment {'
    actual += '"devnull": None, '
    actual += '"is_windows": False, '
    actual += '"stderr_isatty": True, '
    actual += '"stdout_encoding": "utf8", '
    actual += '"program_name": "http", '
    actual += '"stdout_isatty": True, '
    actual += '"stderr": <_io.TextIOWrapper name=2 mode=w encoding=utf-8>, '
    actual += '"stdin_encoding": "utf8", '
    actual += '"config": <Config directory=/Users/zhaoyue/.config/httpie>, '
    actual += '"colors": 256, '

# Generated at 2022-06-23 19:03:57.025580
# Unit test for method __str__ of class Environment

# Generated at 2022-06-23 19:04:08.705937
# Unit test for constructor of class Environment
def test_Environment():
    _is_windows = False
    _config_dir = DEFAULT_CONFIG_DIR
    _stdin = sys.stdin
    _stdin_isatty = sys.stdin.isatty()
    _stdin_encoding = None
    _stdout = sys.stdout
    _stdout_isatty = sys.stdout.isatty()
    _stdout_encoding = None
    _stderr = sys.stderr
    _stderr_isatty = sys.stderr.isatty()
    _colors = 256
    _program_name = 'http'


# Generated at 2022-06-23 19:04:16.982256
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    # First, we will set a new stderr object to print to
    output = StringIO()
    env = Environment(stderr=output)
    env.log_error(msg="This is a test", level='warning')
    env.log_error(msg="This is a test 2", level='error')
    expected_output = '\nhttp: warning: This is a test\n\n\nhttp: error: This is a test 2\n\n'
    assert expected_output == output.getvalue()

# Generated at 2022-06-23 19:04:25.506346
# Unit test for constructor of class Environment
def test_Environment():
    import sys
    from pathlib import Path

    env = Environment(
        is_windows=True,
        config_dir=Path('.'),
        stdin=sys.stdin,
        stdout=sys.stdout,
        stderr=sys.stderr,
    )
    assert env.is_windows == True
    assert env.config_dir == Path('.')
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr

# Generated at 2022-06-23 19:04:28.604123
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name='http')
    assert env.program_name == 'http'
    assert  env.config_dir == DEFAULT_CONFIG_DIR

# Generated at 2022-06-23 19:04:37.668777
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment(devnull=None, is_windows=True, config_dir=DEFAULT_CONFIG_DIR, stdin=None, stdin_isatty=False, stdin_encoding=None, stdout=sys.stdout, stdout_isatty=True, stdout_encoding=None, stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http')
    # __repr__ is not being called because test is running
    print(env.__repr__())
    print(f'env = {env}')
    # __repr__ is not the same without default arguments
    assert env.__repr__() != '<Enviroment <httpie.config.Environment object at 0x7f42fd68fd90>'

# Generated at 2022-06-23 19:04:41.738279
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import StringIO

    devnull = StringIO()
    env = Environment(devnull=devnull)
    msg = ('Error_Message')
    env.log_error(msg)
    assert devnull.getvalue() == '\nhttp: error: Error_Message\n\n'

# Generated at 2022-06-23 19:04:51.077941
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()

# Generated at 2022-06-23 19:04:56.458984
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    class Env(Environment):
        def __init__(self):
            self.stderr = StringIO()
            self._orig_stderr = StringIO()

    env = Env()
    env.log_error('my message', level='warning')
    assert env._orig_stderr.getvalue() == '\nhttp: warning: my message\n\n'



# Generated at 2022-06-23 19:04:59.628397
# Unit test for constructor of class Environment
def test_Environment():
    assert (Environment().stdin_encoding is not None) is True

# Generated at 2022-06-23 19:05:10.461385
# Unit test for constructor of class Environment
def test_Environment():
    env1 = Environment()
    assert env1.is_windows == is_windows
    assert env1.config_dir == DEFAULT_CONFIG_DIR
    assert env1.stdin == sys.stdin
    assert env1.stdin_isatty == sys.stdin.isatty()
    assert env1.stdin_encoding == sys.stdin.encoding
    assert env1.stdout == sys.stdout
    assert env1.stdout_isatty == sys.stdout.isatty()
    assert env1.stdout_encoding == sys.stdout.encoding
    assert env1.stderr == sys.stderr
    assert env1.stderr_isatty == sys.stderr.isatty()
    assert env1.colors == 256

# Generated at 2022-06-23 19:05:21.983340
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()

# Generated at 2022-06-23 19:05:33.606355
# Unit test for method __str__ of class Environment
def test_Environment___str__():
	env = Environment()
	env.is_windows = False
	env.config_dir = Path()
	env.stdin = sys.stdin
	env.stdin_isatty = False
	env.stdin_encoding = 'utf8'
	env.stdout = sys.stdout
	env.stdout_isatty = True
	env.stdout_encoding = 'utf8'
	env.stderr = sys.stderr
	env.stderr_isatty = True
	env.colors = 256
	env.program_name = 'http'
	env.config = None
	env.devnull = None
	env._orig_stderr = env.stderr
	env._config = None

# Generated at 2022-06-23 19:05:44.452501
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(stdin_isatty=False, stdout_isatty=False, stderr_isatty=False, is_windows=False, config_dir='/home/httpie/.httpie', stdout_encoding='utf8', stderr_encoding='utf8')
    str_env = env.__str__()
    assert str_env == '{\'stdin_isatty\': False, \'stdout_isatty\': False, \'stderr_isatty\': False, \'is_windows\': False, \'config_dir\': Path(\'/home/httpie/.httpie\'), \'stdout_encoding\': \'utf8\', \'stderr_encoding\': \'utf8\', \'config\': <Config /home/httpie/.httpie>}'

# Generated at 2022-06-23 19:05:54.997605
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(config_dir='config_dir', stderr='stderr')
    assert env.is_windows == is_windows
    assert (env.config_dir == 'config_dir')
    assert env.stdin == sys.stdin
    assert (env.stderr == 'stderr')
    assert env.stdout == sys.stdout
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout_isatty == sys.stdout.isatty()
    assert not env.stdin_encoding == None
    assert env.stdout_encoding == 'utf8'
    assert not env.stderr_isatty == None
    assert env.colors == 256
    assert env.program_name == 'http'

# Generated at 2022-06-23 19:06:02.491511
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    # Instance with default values
    env = Environment()

# Generated at 2022-06-23 19:06:12.277643
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    e = Environment(stdin=None)
    assert e.__repr__() == '<Environment {\'stdin\': None, \'stdin_isatty\': False, \'stdin_encoding\': None, \'stdout\': <_io.TextIOWrapper name=\'<stdout>\' mode=\'w\' encoding=\'utf8\'>, \'stdout_isatty\': True, \'stdout_encoding\': \'utf8\', \'stderr\': <_io.TextIOWrapper name=\'<stderr>\' mode=\'w\' encoding=\'utf8\'>, \'stderr_isatty\': True, \'colors\': 256, \'program_name\': \'http\'}>'

# Generated at 2022-06-23 19:06:19.008547
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from httpie.context import Environment
    from click import echo

    env = Environment()
    env.config_dir = str('/root')
    env.program_name = str('http')
    env.is_windows = True
    env.stdin = echo
    env.stdin_isatty = False
    env.stdin_encoding = None
    env.stdout = echo
    env.stdout_isatty = False
    env.stdout_encoding = None
    env.stderr = echo
    env.stderr_isatty = False
    env.colors = 256

    str(env)

# Generated at 2022-06-23 19:06:22.602677
# Unit test for constructor of class Environment
def test_Environment():
    import pytest
    env = Environment(devnull = 3)
    assert env._devnull == 3
    with pytest.raises(AssertionError):
        env = Environment(this_is_not_a_attribute = 1)



# Generated at 2022-06-23 19:06:30.847187
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    
    # Constructor call
    environment = Environment()
    # Assertion message

# Generated at 2022-06-23 19:06:42.572793
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    expected_result_str = '{\'is_windows\': False, \'config_dir\': Path(\'/home/cs/.config/httpie\'), \'stdin\': <stdin> (closed), \'stdin_isatty\': False, \'stdout\': <stdout> (closed), \'stdout_isatty\': False, \'stderr\': <stderr> (closed), \'stderr_isatty\': False, \'colors\': 256, \'program_name\': \'http\', \'config\': <httpie.config.Config /home/cs/.config/httpie/config.json>}'

# Generated at 2022-06-23 19:06:44.734799
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    log = env.log_error("This is an error")
    assert log == "\nhttp: error: This is an error\n\n"


# Generated at 2022-06-23 19:06:51.839921
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None)

# Generated at 2022-06-23 19:07:00.998429
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    repr = repr_dict({
            'colors': 256,
            'stderr': sys.stderr,
            'stderr_isatty': 1,
            'stderr_encoding': None,
            'stdin': sys.stdin,
            'stdin_isatty': 1,
            'stdin_encoding': None,
            'stdout': sys.stdout,
            'stdout_isatty': 1,
            'stdout_encoding': None,
            'config': Config(directory='~/.config/httpie')
    })
    assert repr == str(env)


# Generated at 2022-06-23 19:07:06.652810
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    old_stderr = env.stderr
    new_stderr = StringIO()
    env.stderr = new_stderr
    try:
        env.log_error("error")
        assert new_stderr.getvalue() == "http: error: error\n\n"
    finally:
        env.stderr = old_stderr

# Generated at 2022-06-23 19:07:09.628158
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    # Test fixture for method log_error of class Environment.
    e = Environment()
    assert e.log_error(level='error') == 0
    assert e.log_error(level='warning') == 0


# Generated at 2022-06-23 19:07:14.431190
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    #Arrange
    env = Environment()

    #Act
    result = env.__str__()

    #Assert
    assert "Environment" in result
    assert 'config_dir' in result
    assert 'cwd' in result
    assert 'config' in result
    assert 'is_windows' in result
    assert 'program_name' in result
    assert 'stdin_encoding' in result
    assert 'stdout_encoding' in result

# Generated at 2022-06-23 19:07:16.923104
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.stdin is sys.stdin
    assert env.stdout is sys.stdout
    assert env.stderr is sys.stderr
    assert env._devnull is None

# Generated at 2022-06-23 19:07:27.337034
# Unit test for constructor of class Environment
def test_Environment():
    import locale
    import pytest
    import io
    stdout_encoding = locale.getpreferredencoding(False)
    stdin_encoding = locale.getpreferredencoding(False)

    env = Environment(
        config_dir='./config',
        is_windows=False,
        stdin=io.StringIO(),
        stdin_isatty=True,
        stdin_encoding='utf-8',
        stdout=io.StringIO(),
        stdout_isatty=True,
        stdout_encoding='utf-8',
        stderr=io.StringIO(),
        stderr_isatty=True,
        colors=256,
        program_name='http',
        devnull=None,
    )

    assert env.config_dir == './config'


# Generated at 2022-06-23 19:07:32.254366
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment(program_name='http')
    assert not hasattr(env, '_orig_stderr')
    env._orig_stderr = StringIO()
    msg = 'Error message'
    env.log_error(msg)
    actual_output = env._orig_stderr.getvalue()
    expected_output = '\nhttp: error: Error message\n\n'
    assert actual_output == expected_output

# Generated at 2022-06-23 19:07:44.200262
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    from httpie.context import Environment
    import sys

# Generated at 2022-06-23 19:07:53.985889
# Unit test for constructor of class Environment

# Generated at 2022-06-23 19:07:55.750866
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error('test-error')
    env.log_error('test-warning', level='warning')

# Generated at 2022-06-23 19:08:05.046039
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()

# Generated at 2022-06-23 19:08:16.101919
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()

# Generated at 2022-06-23 19:08:22.915983
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()

    assert repr(env) == '<Environment {}>'

    env.program_name = 'foo'
    env.config_dir = 'bar'
    class Foo:
        pass
    env._config = Foo()

    assert repr(env) == '<Environment {\'program_name\': \'foo\', \'config_dir\': \'bar\', \'config\': <Foo object at 0x7f2398d6ccc0>}>'