

# Generated at 2022-06-23 18:58:26.736778
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    # No Argument
    env = Environment()
    assert repr(env) == '<Environment>'
    # With Argument
    env = Environment(stdout_isatty=True)
    assert repr(env) == '<Environment {\'stdout_isatty\': True}>'



# Generated at 2022-06-23 18:58:37.687662
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin is sys.stdin
    assert env.stdin_isatty is sys.stdin.isatty()
    assert env.stdin_encoding is None
    assert env.stdout is sys.stdout
    assert env.stdout_isatty is sys.stdout.isatty()
    assert env.stdout_encoding is None
    assert env.stderr is sys.stderr
    assert env.stderr_isatty is sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'

    env = Environment(program_name='test')
    assert env.program

# Generated at 2022-06-23 18:58:42.379513
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import StringIO
    from httpie.config import Config
    _old_file = StringIO()
    _new_file = StringIO()
    env = Environment(stderr=_old_file.write)
    env.stderr = _new_file.write
    msg = 'this is error message'
    env.log_error(msg)
    assert _old_file.getvalue() == ''
    assert _new_file.getvalue() == f'\n{env.program_name}: error: {msg}\n\n'


# Generated at 2022-06-23 18:58:51.998008
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    import io
    import tempfile
    from httpie.config import DEFAULT_CONFIG_DIR
    dirpath = tempfile.TemporaryDirectory()
    config_dir = Path(dirpath.name)
    DEFAULT_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    config_path = DEFAULT_CONFIG_DIR / 'config.json'
    config_path.touch()

# Generated at 2022-06-23 18:59:00.296208
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment(stdin_isatty=False, stdout_isatty=True, stderr_isatty=False, colors=256)

# Generated at 2022-06-23 18:59:12.197330
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    assert repr(Environment()) == '<Environment {}>'

# Generated at 2022-06-23 18:59:23.637933
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    e = Environment()

# Generated at 2022-06-23 18:59:34.541522
# Unit test for constructor of class Environment
def test_Environment():
    import sys
    import os
    import warnings

    environment = Environment(devnull=os.devnull)

    if environment.stdin:
        assert environment.stdin.name == "stdin"
        assert environment.stdin_isatty == True
        assert environment.stdin_encoding == 'utf8'

    assert environment.stdout.name == "stdout"
    assert environment.stdout_isatty == True
    assert environment.stdout_encoding == 'utf8'

    assert environment.stderr.name == "stderr"
    assert environment.stderr_isatty == True

    assert environment.is_windows == False

    assert environment.colors == 256
    assert environment.program_name == "http"


# Generated at 2022-06-23 18:59:35.405199
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().program_name == 'http'

# Generated at 2022-06-23 18:59:39.809106
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(stdin_encoding = 'utf8', stdout_encoding = 'utf8', program_name = 'http', is_windows = False)
    assert isinstance(env.__str__(), str)


# Generated at 2022-06-23 18:59:50.193925
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == True
    assert env.config_dir == Path('~/.config/httpie')
    assert env.stdin_encoding == 'UTF-8'
    assert env.stdout_encoding == 'UTF-8'
    assert env.stderr_encoding == 'UTF-8'
    assert env.colors == 256
    assert env.program_name == 'http'
    assert str(env) == '{'
    assert repr(env) == '<Environment {}>'
    assert str(env.config) == 'Config(config_dir=Path("~/.config/httpie"))'
    assert repr(env.config) == 'Config(config_dir=Path("~/.config/httpie"))'

# Generated at 2022-06-23 18:59:57.200812
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()

# Generated at 2022-06-23 19:00:05.701029
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    class TestEnvironment(Environment):
        _orig_stderr: IO
        _devnull: IO
        stdin: IO
        stdin_isatty: bool
        stdin_encoding: str
        stdout: IO
        stdout_isatty: bool
        stdout_encoding: str
        stderr: IO
        stderr_isatty: bool
        colors: int
        program_name: str

    stderr_save = sys.stderr


# Generated at 2022-06-23 19:00:15.014865
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    assert str(env) == '{}'
    env.__dict__.update({'config_dir': '~', 'stdout_isatty': True, 'stdout': '/dev/null', 'stderr_isatty': True, 'stderr': '/dev/null', 'colors': 256, 'program_name': 'http', 'stdin_encoding': 'utf8', 'stdout_encoding': 'utf8'})

# Generated at 2022-06-23 19:00:23.793730
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()

    with patch.object(sys.stderr, 'write',
                      side_effect=lambda s: env.devnull.write(s)) as mock_write, \
            patch.object(sys.stderr, 'flush',
                         side_effect=lambda: env.devnull.flush()), \
            patch('httpie.context.is_windows', return_value=False), \
            patch('httpie.context.curses', None):
        env.log_error('test', level='error')
        mock_write.assert_called_once_with('\nhttp: error: test\n\n')
        env.log_error('test', level='warning')
        mock_write.assert_called_with('\nhttp: warning: test\n\n')


env = Environment()

# Generated at 2022-06-23 19:00:27.741060
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()

    def w_error(msg, level):
        assert level in ['error', 'warning']

    env._orig_stderr.write = w_error
    env.log_error("This is an error.")
    env.log_error("This is a warning.", level = 'warning')

# Generated at 2022-06-23 19:00:29.844475
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    assert env.__str__() != '{}'


# Generated at 2022-06-23 19:00:34.135272
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    import sys
    stderr = io.StringIO()
    environ = Environment(stderr=stderr)
    environ.log_error("Message d'erreur")
    sys.stdout.write(stderr.getvalue())
    stderr.close()

# Generated at 2022-06-23 19:00:45.853361
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(devnull=None, is_windows=False, config_dir= DEFAULT_CONFIG_DIR, stdin=sys.stdin, stdin_isatty=True, stdout=sys.stdout, stdout_isatty=True, stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http')

# Generated at 2022-06-23 19:00:57.540877
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()

# Generated at 2022-06-23 19:01:01.406368
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(colors=5, program_name='http')
    assert env.colors == 5
    assert env.program_name == 'http'

if __name__=='__main__':
    test_Environment()

# Generated at 2022-06-23 19:01:08.440475
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    result = Environment()
    assert result.__repr__() == '<Environment {config=<Config {user_config_path=Path(~/.httpie/config.json), system_config_path=Path(/usr/local/etc/httpie/config), directory=<Path not exists>, items={}, is_new=False}>, is_windows=False, stdin_isatty=True, stdout_isatty=True, stderr_isatty=True, colors=256}>'

# Generated at 2022-06-23 19:01:15.475487
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    import contextlib

    input_output = io.StringIO()
    myenv = Environment(stderr=input_output)
    myenv.log_error("Hello world", level='error')
    myenv.log_error("Hello world again", level='warning')
    output = input_output.getvalue()
    assert output == '\nhttp: error: Hello world\n\n\nhttp: warning: Hello world again\n\n'

# Generated at 2022-06-23 19:01:16.451943
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().is_windows == is_windows

# Generated at 2022-06-23 19:01:27.830976
# Unit test for constructor of class Environment
def test_Environment():
    # Test constructor of class Environment
    environment = Environment()
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin == sys.stdin
    assert environment.stdout == sys.stdout
    assert environment.stderr == sys.stderr
    assert environment.colors == 256
    assert environment.program_name == 'http'
    assert environment.is_windows == is_windows
    assert environment.stdin_isatty == environment.stdin.isatty()
    assert environment.stdout_isatty == environment.stdout.isatty()
    assert environment.stderr_isatty == environment.stderr.isatty()
    assert environment._devnull == None
    assert environment._config == None
    assert environment._orig_stderr == sys.stderr


# Generated at 2022-06-23 19:01:38.668336
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    import sys
    import os
    from pathlib import Path
    from typing import IO, Optional

    class Environemnt:
        is_windows: bool = False
        config_dir: Path = Path('~')
        stdin: Optional[IO] = None  # `None` when closed fd (#791)
        stdin_isatty: bool = False
        stdin_encoding: str = None
        stdout: IO = None
        stdout_isatty: bool = False
        stdout_encoding: str = None
        stderr: IO = None
        stderr_isatty: bool = False
        colors = 256
        program_name: str = 'http'

# Generated at 2022-06-23 19:01:47.885991
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == env.stdin.isatty()
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == env.stdout.isatty()
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == env.stderr.isatty()
    assert env.program_name == 'http'



# Generated at 2022-06-23 19:01:57.735120
# Unit test for constructor of class Environment
def test_Environment():
    import sys
    from httpie.utils import VERSION

    e = Environment(
        is_windows=True,
        config_dir=Path('/home/user/.config/httpie'),
        stdin=None,
        stdin_isatty=False,
        stdin_encoding=None,
        stdout=sys.stdout,
        stdout_isatty=sys.stdout.isatty(),
        stdout_encoding='utf8',
        stderr=sys.stderr,
        stderr_isatty=sys.stderr.isatty(),
        colors=256,
        program_name='http',
    )
    assert e.is_windows == True
    assert e.config_dir == Path('/home/user/.config/httpie')
    assert e.stdin

# Generated at 2022-06-23 19:02:04.346269
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    e = Environment()

# Generated at 2022-06-23 19:02:15.117957
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    from httpie.utils import make_environment

    result = repr(make_environment(stdin=None, config_dir='./test_data'))

# Generated at 2022-06-23 19:02:26.162756
# Unit test for constructor of class Environment
def test_Environment():
    from io import StringIO, TextIOWrapper
    from tempfile import TemporaryDirectory

    devnull = open('/dev/null', 'w')
    stdin_file = StringIO()
    stdout_file = StringIO()
    stderr_file = StringIO()
    with TemporaryDirectory() as tempdir:
        env = Environment(
            devnull=devnull,
            colors=16,
            config_dir=Path(tempdir),
            stdin=stdin_file,
            stdin_isatty=False,
            stdin_encoding='utf-7',
            stdout=stdout_file,
            stdout_isatty=False,
            stdout_encoding='utf-16',
            stderr=stderr_file,
            stderr_isatty=False
        )

# Generated at 2022-06-23 19:02:37.445075
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    import io
    import unittest
    env = Environment()
    env.config_dir = Path('test_dir')
    env.stdin = io.BytesIO(b'stdin')
    env.stdout = io.BytesIO()
    env.stderr = io.BytesIO()
    env.program_name = 'pytest'
    # The line belows is for coverage only.
    str(env)
    class Test(unittest.TestCase):
        def test(self):
            actual = str(env)
            self.assertIsInstance(actual, str)
            self.assertNotEqual(actual, '')

# Generated at 2022-06-23 19:02:39.646655
# Unit test for constructor of class Environment
def test_Environment():
    assert str(Environment())
    assert str(Environment(stdin=None))
    assert Environment(stdin=None).stdin

# Generated at 2022-06-23 19:02:44.747121
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.stdout_isatty
    assert env.stdin_isatty
    assert env.stderr_isatty
    assert env.stdout_encoding
    assert env.stdin_encoding
    assert env.config
    assert repr(env).startswith('<Environment ')
    assert str(env).startswith('{')
#test_Environment()

# Generated at 2022-06-23 19:02:47.504788
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert hasattr(env, 'is_windows')


# Generated at 2022-06-23 19:02:50.871348
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.config_dir = Path('/dev/null')   # Don't write to a possibly existing config file
    env.log_error('message', level='warning')

# Generated at 2022-06-23 19:03:02.252010
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    environment = Environment()
    actual = environment.__repr__()

# Generated at 2022-06-23 19:03:09.892705
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from test.env import EnvironmentTest
    assert str(EnvironmentTest()) == (
        "{"
        "colors: 256, "
        "config: <Config None>, "
        "config_dir: /root/.httpie, "
        "is_windows: True, "
        "program_name: 'http', "
        "stderr_encoding: None, "
        "stderr_isatty: False, "
        "stdin_encoding: 'utf8', "
        "stdin_isatty: True, "
        "stdout_encoding: 'utf8', "
        "stdout_isatty: True"
        "}"
    )



# Generated at 2022-06-23 19:03:19.487525
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.utils import mkdownloads
    from httpie.downloads import Path
    from httpie.utils import env
    import os
    import sys
    import pathlib
    config_dir = Path('/home/xyz/httpie')
    old = env.config_dir
    env.config_dir = config_dir

# Generated at 2022-06-23 19:03:30.722204
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(stdin=None, stdin_isatty=False, stdin_encoding=None, stdout=None, stdout_isatty=False, stdout_encoding='utf8', stderr=None, stderr_isatty=False, program_name='http')

# Generated at 2022-06-23 19:03:42.335409
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import re

    # Define a method to check the error messages
    def check_my_error_msg(mydll, level, msg, outstream):
        assert level in ['error', 'warning']
        assert re.match(r'^\w{3}: {0}: {1}$'.format(level, msg), outstream) is not None

    # From the beginning, the stderr is assigned as the outstream
    env = Environment()
    #outstream = env.stderr.getvalue()
    outstream = "httpie: error: Invalid value of True for argument --ignore-stdin"
    check_my_error_msg(env, level='error', msg='Invalid value of True for argument --ignore-stdin', outstream=outstream)
    #outstream = env.stderr.getvalue()

# Generated at 2022-06-23 19:03:49.793174
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment(
        a=1, b=2, c='foo', d=True,
        stdin_isatty=False,
        stdout_encoding='foo', stderr_encoding='bar'
    )
    assert e.a == 1
    assert e.b == 2
    assert e.c == 'foo'
    assert e.d
    assert not e.stdin_isatty
    assert e.stdout_encoding == 'foo'
    assert e.stderr_encoding == 'bar'

# Generated at 2022-06-23 19:03:54.400821
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    # Test that log_error behaves as expected when given a string.
    msg = 'This is a test.'
    stdout = io.StringIO()
    env = Environment(stderr=stdout)

    # Ensure that the default error message is given if the level is not specified.
    env.log_error(msg)
    assert stdout.getvalue() == '\nhttp: error: This is a test.\n\n'

    # Ensure that the correct error message is given for warnings.
    env.log_error(msg, level='warning')
    assert stdout.getvalue() == '\nhttp: error: This is a test.\n\n\nhttp: warning: This is a test.\n\n'

    # Ensure that the correct error message is given for errors.

# Generated at 2022-06-23 19:04:06.582457
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    e = Environment()

# Generated at 2022-06-23 19:04:08.463371
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.config == environment.config
    assert environment.config_dir == Path(DEFAULT_CONFIG_DIR)


# Generated at 2022-06-23 19:04:19.476181
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    saved_stderr = sys.stderr
    sys.stderr = StringIO()
    try:
        env = Environment()
        env.log_error('some message', level='error')
        assert sys.stderr.getvalue() == '\nhttp: error: some message\n\n'
        sys.stderr = StringIO()
        env.log_error('some message', level='warning')
        assert sys.stderr.getvalue() == '\nhttp: warning: some message\n\n'
        sys.stderr = StringIO()
        env.log_error('some message')
        assert sys.stderr.getvalue() == '\nhttp: error: some message\n\n'
    finally:
        sys.stderr = saved_stderr


env = Environment

# Generated at 2022-06-23 19:04:21.208120
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    assert isinstance(env.__str__(), str)

test_Environment___str__()

# Generated at 2022-06-23 19:04:22.627602
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    print(env)

#test_Environment___str__()

# Generated at 2022-06-23 19:04:25.837129
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.stdin_encoding == 'utf8'
    assert env.stdout_encoding == 'utf8'

test_Environment()

# Generated at 2022-06-23 19:04:35.183253
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    assert Environment().__repr__() == '<Environment {config: <Config {is_new: True, directory: ~/.config/httpie}>, colors: 256, is_windows: False, program_name: http, stderr: <httpie.output.StreamOutputWriter at 0x7f33a1db3e10>, stderr_isatty: True, stdin: <_io.TextIOWrapper name=0 encoding=utf-8>, stdin_encoding: utf-8, stdin_isatty: True, stdout: <httpie.output.StreamOutputWriter at 0x7f33a1db3dd8>, stdout_encoding: utf-8, stdout_isatty: True}>'

# Generated at 2022-06-23 19:04:46.721112
# Unit test for method __str__ of class Environment

# Generated at 2022-06-23 19:04:54.627579
# Unit test for method __str__ of class Environment
def test_Environment___str__():

    assert '<Environment {}>' == str(Environment())


# Generated at 2022-06-23 19:04:57.328466
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error(msg = "msg", level = "error")
    assert env._orig_stderr.write(f"\n{env.program_name}: error: msg\n\n")

# Generated at 2022-06-23 19:05:09.594917
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    """
    Method that tests the __repr__ method of class Environment.
    """

    # Case 1:
    # Check if the returned string is the same as the expected one when
    # the attributes of the class Environment are the default ones.

    environ = Environment()

# Generated at 2022-06-23 19:05:21.210456
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    import sys
    from pathlib import Path
    from httpie.config import Config, ConfigFileError
    from httpie import ExitStatus


    defaults = dict(Environment.__dict__)
    actual = dict(defaults)
    actual['config'] = Config({})
    actual['_orig_stderr'] = dict()
    actual['_devnull'] = dict()
    actual['stdout'] = sys.stdout
    actual['stderr'] = sys.stderr
    actual['stdin'] = sys.stdin
    actual['program_name'] = 'http'
    actual['is_windows'] = False
    actual['config_dir'] = Path('/home/nico/.config/httpie')
    actual['stdin_isatty'] = True
    actual['stdin_encoding'] = 'utf8'


# Generated at 2022-06-23 19:05:24.642658
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    repr_env = repr(env)
    assert repr_env.startswith('<Environment')
    assert repr_env.endswith('>')
    assert repr_env.count('\n') == 5
    assert repr_env.count('=') == 12


# Generated at 2022-06-23 19:05:27.558197
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=print, foo='bar')
    assert env.devnull is print
    assert env.foo == 'bar'

# Generated at 2022-06-23 19:05:29.537800
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    print(env)

test_Environment___repr__()

# Generated at 2022-06-23 19:05:31.192706
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error('test_Environment_log_error')

# Generated at 2022-06-23 19:05:38.928886
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    def test():
        env = Environment()
        msg = 'This is an interesting error'
        env.log_error(msg)
        msg2 = 'A warning'
        env.log_error(msg2, level='warning')
    sys.stderr = StringIO()
    test()
    sys.stderr = sys.__stderr__
    # TODO: This test passes on Windows, but 
    # https://github.com/jkbrzt/httpie/issues/1056 is still open
    #assert sys.stderr.getvalue().strip() == f"\nhttp: error: {msg}\n\n\nhttp: warning: {msg2}\n\n".strip()
    sys.stderr.close()


environ = Environment()

# Generated at 2022-06-23 19:05:43.728373
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    env = Environment(stderr=io.StringIO())
    env.program_name = "http"
    error = 'HTTP Error 429: Too Many Requests'
    env.log_error(error,'error')
    assert env.stderr.getvalue() == "\nhttp: error: HTTP Error 429: Too Many Requests\n\n"


# Generated at 2022-06-23 19:05:53.944308
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    e = Environment()
    assert type(e) is Environment
    assert e.is_windows == is_windows
    assert e.config_dir == DEFAULT_CONFIG_DIR
    assert e.stdin == sys.stdin
    assert e.stdin_isatty == sys.stdin.isatty()
    assert e.stdin_encoding == 'utf8'
    assert e.stdout == sys.stdout
    assert e.stdout_isatty == sys.stdout.isatty()
    assert e.stdout_encoding == 'utf8'
    assert e.stderr == sys.stderr
    assert e.stderr_isatty == sys.stderr.isatty()
    assert e.program_name == 'http'
    assert e.config_dir == DEFAULT_

# Generated at 2022-06-23 19:06:01.837031
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from httpie import Environment  as env
    environ = env()

# Generated at 2022-06-23 19:06:13.053623
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment()
    assert e.is_windows is False
    assert e.config_dir == DEFAULT_CONFIG_DIR
    assert e.stdin == sys.stdin
    assert e.stdin_isatty is True
    assert e.stdin_encoding == 'cp866'
    assert e.stdout == sys.stdout
    assert e.stdout_isatty is True
    assert e.stdout_encoding == 'cp866'
    assert e.stderr == sys.stderr
    assert e.stderr_isatty is True
    assert e.colors == 256
    assert e.program_name == 'http'

# Generated at 2022-06-23 19:06:23.271127
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    assert repr(Environment()) == '<Environment {}>'
    assert repr(Environment(colors=256)) == '<Environment {\'colors\': 256}>'
    assert repr(Environment(stdin_isatty=True, stdout_isatty=True)) == '<Environment {\'stdin_isatty\': True, \'stdout_isatty\': True}>'
    assert repr(Environment(color=256)) == '<Environment {}>'
    assert repr(Environment(color=256, colors=True)) == '<Environment {\'colors\': True}>'
    assert repr(Environment(color='True', colors=True)) == '<Environment {\'colors\': True}>'

# Generated at 2022-06-23 19:06:31.171803
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from httpie.utils import get_unittest_config_directory
    from httpie.client import Environment
    env = Environment(config_dir=get_unittest_config_directory())

# Generated at 2022-06-23 19:06:35.333075
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    from httpie import ExitStatus
    from httpie.exit import exit
    env = Environment()
    assert eval(repr(env), {'ExitStatus': ExitStatus, 'exit': exit}) == env

# Generated at 2022-06-23 19:06:37.242028
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    Environment().log_error('test_Environment_log_error')

# Generated at 2022-06-23 19:06:41.316424
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.stderr = io.StringIO()
    env.log_error("Test log_error")
    assert env.stderr.getvalue() == "http: error: Test log_error\n\n"


# Generated at 2022-06-23 19:06:47.337938
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    # Input
    msg = "test msg"
    
    # Expected output
    exp_out = '\nhttp: error: test msg\n\n'
    # Real output of the log_error method of the Environment class
    class_obj = Environment.__new__(Environment)
    class_obj.program_name = 'http'
    
    # Real output of the method of the Environment class
    real_out = class_obj.log_error(msg, level='error')
    
    # Test if method returns what is expected
    assert exp_out == real_out



# Generated at 2022-06-23 19:06:53.746644
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    assert repr_dict({
        'colors': 256,
        'config_dir': DEFAULT_CONFIG_DIR,
        'colors': 256,
        'config': None,
        'program_name': 'http',
        'stderr_isatty': True,
        'stdout_isatty': True,
        'stderr': sys.stderr,
        'stdout': sys.stdout,
        'stdin_isatty': True,
        'stdin': sys.stdin,
        'stdout_encoding': 'utf8',
        'is_windows': is_windows,
        'stdin_encoding': 'utf8',
        'stderr_encoding': 'utf8',
    }) == str(env)



# Generated at 2022-06-23 19:07:02.924406
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    def test(env, expected_repr):
        actual_repr = repr(env)
        if actual_repr != expected_repr:
            #
            raise AssertionError(
                '\n'
                f'Expected:\n{expected_repr!r}\n'
                f'Actual:\n{actual_repr!r}\n'
            )

    test(
        Environment(),
        '<Environment {}>'
    )

# Generated at 2022-06-23 19:07:06.464265
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    e = Environment(lorem='ipsum', dolor='sit', amet='consectetur')
    assert str(e) == "{'amet': 'consectetur', 'dolor': 'sit', 'lorem': 'ipsum'}"

# Generated at 2022-06-23 19:07:07.630844
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    Environment()


# Generated at 2022-06-23 19:07:15.880360
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert isinstance(env, Environment)
    assert env.is_windows == True
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == True
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == True
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._config == None
    assert env.config.directory == env.config_dir
    assert env.devnull == None
    assert env

# Generated at 2022-06-23 19:07:20.496583
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    t_env = Environment()
    t_str = t_env.__repr__()
    assert type(t_str) == str
    assert t_str.startswith('<Environment')
    assert 'colors: 256' in t_str
    assert 'is_windows: True' in t_str
    assert 'program_name: http' in t_str
    assert ('config: <Config '
            'directory: C:\\Users\\71916\\.httpie '
            'config_file_path: None '
            'is_new: True '
            'values: {}>') in t_str

# Generated at 2022-06-23 19:07:22.920081
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(foo='bar')
    assert env.foo == 'bar'
    assert env.stdin is sys.stdin
    assert env.stdout is sys.stdout
    assert env.stderr is sys.stderr

# Generated at 2022-06-23 19:07:31.437237
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    env.is_windows = True
    assert env.is_windows == True
    env.config_dir = Path('C:\\Users\\flysafe\\PycharmProjects\\httpie')
    assert env.config_dir == Path('C:\\Users\\flysafe\\PycharmProjects\\httpie')
    env.stdin = sys.stdin
    assert env.stdin == sys.stdin
    env.stdin_isatty = True
    assert env.stdin_isatty == True
    env.stdout = sys.stdout
    assert env.stdout == sys.stdout
    env.stdout_isatty = True
    assert env.stdout_isatty == True
    env.stderr = sys.stderr

# Generated at 2022-06-23 19:07:43.220056
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()

    assert env.is_windows is is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == env.stdin.isatty()
    assert env.stdin_encoding is None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == env.stdout.isatty()
    assert env.stdout_encoding is None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == env.stderr.isatty()
    assert env.program_name == 'http'
    assert env.colors == 256
    assert env.config_dir == DEFAULT_CONFIG_DIR
   

# Generated at 2022-06-23 19:07:53.049783
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=True, config_dir=DEFAULT_CONFIG_DIR, stdin=sys.stdin, stdin_isatty=sys.stdin.isatty(), stdin_encoding=None, stdout=sys.stdout, stdout_isatty=sys.stdout.isatty(), stdout_encoding=None, stderr=sys.stderr, stderr_isatty=sys.stderr.isatty(), colors=256, program_name='http', _config=None, _devnull=None, _orig_stderr=sys.stderr)
    assert env.devnull is not None
    assert env.config_dir == DEFAULT_CONFIG_DIR

# Generated at 2022-06-23 19:08:03.147670
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.stderr = io.StringIO()
    env.log_error("failed!")
    env.stderr_isatty = False
    env.log_error("failed again!", level='warning')
    env.stderr = sys.stderr
    env.stderr_isatty = True
    assert env.stderr.getvalue() == f"""\
\nhttp: error: failed!

\nhttp: warning: failed again!

"""
    env.stderr = io.StringIO()
    env.stderr_isatty = True
    env.program_name = 'httpie'
    env.log_error("failed again!", level='warning')

# Generated at 2022-06-23 19:08:05.893414
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    print(env)

if __name__ == "__main__":
    test_Environment___repr__()

# Generated at 2022-06-23 19:08:16.753561
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        devnull = 'xxx',
        is_windows = 'yyy',
        config_dir = 'zzz',
        stdin = 'qqq',
        stdin_isatty = 'www',
        stdin_encoding = 'eee',
        stdout = 'rrr',
        stdout_isatty = 'ttt',
        stdout_encoding = 'yyy',
        stderr = 'uuu',
        stderr_isatty = 'iii',
        program_name = 'ooo',
        _config = 'ppp'
    )
    #devnull = 'xxx',
    assert env.devnull == 'xxx'

    #is_windows = 'yyy',
    assert env.is_windows == 'yyy'

    #config_dir = 'zzz',

# Generated at 2022-06-23 19:08:19.634335
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    IOStream = StringIO()
    env.stderr = IOStream
    env.log_error('test message')
    assert IOStream.getvalue() == '\nhttp: error: test message\n\n'
    IOStream.close()



# Generated at 2022-06-23 19:08:26.367753
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    errorMessage = 'There was an error'
    warningMessage = 'There was a warning'
    env = Environment()
    output = io.StringIO()
    env.stderr = output
    env.log_error(errorMessage, 'error')
    env.log_error(warningMessage, 'warning')
    assert errorMessage.encode() in output.getvalue()
    assert warningMessage.encode() in output.getvalue()
    assert 'error' in output.getvalue()
    assert 'warning' in output.getvalue()
# End of unit test