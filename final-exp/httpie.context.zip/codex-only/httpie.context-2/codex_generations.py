

# Generated at 2022-06-23 18:58:19.621670
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error('test')

# Generated at 2022-06-23 18:58:26.390100
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    obj = Environment(stdin = sys.stdin, stdout = sys.stdout, stderr = sys.stderr, config_dir = DEFAULT_CONFIG_DIR, is_windows = is_windows, colors = 256, program_name = 'http', stdin_isatty = sys.stdin.isatty())

# Generated at 2022-06-23 18:58:32.787204
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    msg = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.'
    level = 'warning'
    env.log_error(msg, level)
    assert env.stderr.getvalue() == '\nhttp: warning: Lorem ipsum dolor sit amet, consectetur adipiscing elit.\n\n'

# Generated at 2022-06-23 18:58:41.148825
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment(
        stdin_encoding='1',
        stdout_encoding='2'
    )

# Generated at 2022-06-23 18:58:48.524217
# Unit test for method __str__ of class Environment

# Generated at 2022-06-23 18:58:57.850619
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    # Case 1
    env = Environment(
        config_dir=DEFAULT_CONFIG_DIR,
        stdin = None,
        stdin_isatty= False,
        stdin_encoding=None,
        stdout = sys.stdout,
        stdout_isatty = True,
        stdout_encoding=None,
        stderr = sys.stderr,
        stderr_isatty = True,
        colors=256,
        program_name='http'
    )

# Generated at 2022-06-23 18:59:00.394697
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from httpie.context import Environment
    env = Environment()
    assert str(env) == str(env).replace("'", '"')



# Generated at 2022-06-23 18:59:07.925705
# Unit test for constructor of class Environment
def test_Environment():
    # print(Environment())
    assert hasattr(Environment, '_orig_stderr') == True
    assert hasattr(Environment, '_devnull') == True
    assert hasattr(Environment, '_config') == True
    e = Environment()
    assert e.stdout_isatty == True
    assert e.stderr_isatty == True


if __name__ == "__main__":
    test_Environment()

# Generated at 2022-06-23 18:59:13.902699
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    import pytest
    env = Environment(stderr=io.StringIO())
    # Test if returns error with argument level='error'
    env.log_error('Error')
    assert env.stderr.getvalue() == '\nhttp: error: Error\n\n'
    # Test if returns warning with argument level='warning'
    env.log_error('Warning', level='warning')
    assert env.stderr.getvalue() == '\nhttp: error: Error\n\n\nhttp: warning: Warning\n\n'
    # Test if returns exception with argument level!=('error' or 'warning')
    with pytest.raises(AssertionError) as error:
        env.log_error('Warning', level='no error')

# Generated at 2022-06-23 18:59:24.422110
# Unit test for constructor of class Environment
def test_Environment():
    # Uncomment this line to run this script independently
    # import sys, os
    # sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))
    from httpie.compat import is_windows
    from httpie.stream import Stream
    import sys

    def get_attribute_value(Environment, attribute):
        return getattr(Environment, attribute)

    if __name__ == "__main__":
        # Get the actual environment
        env = Environment()
        assert get_attribute_value(env, 'is_windows') == is_windows()

        # Use keyword arguments to overwrite
        # any of the class attributes for this instance.
        devnull = Stream.null()
        env = Environment(devnull=devnull, stderr=devnull)

# Generated at 2022-06-23 18:59:35.192172
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    assert repr(Environment()) == "<Environment {'is_windows': False, 'config_dir': PosixPath('~/.config/httpie'), 'stdin': <_io.TextIOWrapper name='<stdin>' mode='r' encoding='UTF-8'>, 'stdin_isatty': True, 'stdout': <_io.TextIOWrapper name='<stdout>' mode='w' encoding='UTF-8'>, 'stdout_isatty': True, 'stderr': <_io.TextIOWrapper name='<stderr>' mode='w' encoding='UTF-8'>, 'stderr_isatty': True, 'colors': 256, 'program_name': 'http', 'config': {}}>"

# Generated at 2022-06-23 18:59:40.306277
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    class TestStd(object):
        def __init__(self):
            self.counter = 0

        def write(self, x: str) -> int:
            self.counter += 1
            return len(x)

    std = TestStd()
    env = Environment(stderr=std, stderr_isatty=False)
    msg = 'A message'
    env.log_error(msg)
    env.log_error(msg, level='warning')
    assert std.counter == 2



# Generated at 2022-06-23 18:59:41.773779
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    print(env)


# Generated at 2022-06-23 18:59:44.625404
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.stdin.mode == 'r'
    assert env.stdout.mode == 'w'
    assert env.devnull.mode == 'w+'

# Generated at 2022-06-23 18:59:48.503300
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    obj = Environment()
    func = getattr(obj, '__repr__', None)
    assert callable(func)
    assert func() == '<Environment {}>'
    assert func() == f'<Environment {{{func()}}}>'
# unit tests ends here

# tests for Environment.config

# Generated at 2022-06-23 18:59:51.432866
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().is_windows == is_windows
    assert Environment().stdout.encoding == 'utf8'
    assert Environment(stdout=StringIO()).stdout.encoding is None
    assert Environment(stderr=StringIO()).stderr.encoding is None

# Generated at 2022-06-23 18:59:58.149387
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()

# Generated at 2022-06-23 19:00:07.186574
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.stdin == sys.stdin # This is default value for stdin
    assert env.stdout == sys.stdout # This is default value for stdout
    assert env.stderr == sys.stderr # This is default value for stderr
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.is_windows == is_windows
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.stdin_encoding == 'utf8'
    assert env.stdout_encoding == 'utf8'
    assert env.program_name

# Generated at 2022-06-23 19:00:12.635256
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment(
        stderr = io.StringIO()
    )
    env.log_error('msg')

    assert env.stderr.getvalue() == '\nhttp: error: msg\n\n'

    env.log_error('msg2', level='warning')

    assert env.stderr.getvalue() == '\nhttp: error: msg\n\n\nhttp: warning: msg2\n\n'

# Generated at 2022-06-23 19:00:20.399718
# Unit test for constructor of class Environment
def test_Environment():
    class A(Environment):
        pass
    a = A()
    assert a.stdin is sys.stdin
    assert A().stdin is sys.stdin

    b = A(stdin=None)
    assert b.stdin is None
    assert b.stdin_isatty is False
    assert b.stdin_encoding is None

    c = A(stdin=StringIO())
    assert c.stdin_isatty is False
    assert c.stdin_encoding is None
    assert c.stdin_encoding == c.stdin_encoding

    d = A(stdin=StringIO(''), stdin_encoding='utf8')
    assert d.stdin_encoding == 'utf8'
    assert d.stdin_encoding == d.stdin_encoding


# Generated at 2022-06-23 19:00:23.350731
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():

    # function Environment__repr__ has no arguments (1 given)
    assert Environment().__repr__() == '<Environment {}>'
    assert Environment(stdin=sys.stdin).__repr__() == '<Environment {}>'


# Generated at 2022-06-23 19:00:33.542603
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    from httpie.config import Config
    from httpie.compat import is_windows
    env = Environment(is_windows=is_windows, config_dir='/home/user/.httpie/', stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr, colors=256, program_name='http')
    env._config = Config(directory='home/user/.httpie/')
    env._orig_stderr = sys.stderr
    env._devnull = open(os.devnull, 'w+')
    env.config_dir = 'E:/Python/httpie/.httpie/'
    env.stdin = sys.stdin
    env.stdin_isatty = sys.stdin.isatty()
    env.stdin_encoding = 'utf8'

# Generated at 2022-06-23 19:00:34.192628
# Unit test for constructor of class Environment
def test_Environment():
    print(Environment())

# Generated at 2022-06-23 19:00:41.831057
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    """
    Tests method Environment.log_error by connecting sys.stderr to a StringIO instance
    and checking the output against a string.
    """
    from io import StringIO
    import sys
    import os

    stderr = StringIO()
    env = Environment(program_name='httpie', stderr=stderr)
    env.log_error("test")

    assert stderr.getvalue() == "httpie: error: test\n\n"



# Generated at 2022-06-23 19:00:51.367120
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import StringIO

    import pytest
    stdout = StringIO()
    stderr = StringIO()

    e = Environment(stderr=stderr, stdout=stdout)
    e.config_dir = Path(__file__).parent / "config_test_files/test_Environment_log_error"
    e.stderr_isatty = False
    e.stdout_isatty = False
    e.log_error("Bazinga!")
    assert stdout.getvalue() == ''
    assert stderr.getvalue() == '\nhttp: error: Bazinga!\n\n'


# Generated at 2022-06-23 19:00:58.371638
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    dict = {'bool':True,'str':'str','list':[0,1,2,3],'dict':{'a':1,'b':2,'c':3}}
    env = Environment(**dict)
    assert env.__repr__() == '<Environment {\'bool\': True, \'str\': \'str\', \'list\': [0, 1, 2, 3], \'dict\': {\'a\': 1, \'b\': 2, \'c\': 3}}>'

# Generated at 2022-06-23 19:01:09.304503
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(is_windows=False, config_dir=DEFAULT_CONFIG_DIR, stdin=sys.stdin,
                 stdout=sys.stdout, stderr=sys.stderr, program_name=sys.argv[0])
    assert env.is_windows == False
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == getattr(sys.stdin, 'encoding', None) or 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()

# Generated at 2022-06-23 19:01:12.777013
# Unit test for constructor of class Environment
def test_Environment():
    # Change the class attribute to a new value
    # and make sure the instance value got changed
    # due to the multiple inheritance.
    env = Environment()
    env.config_dir = Path('/test/test')
    assert env.config_dir == Path('/test/test')

# Generated at 2022-06-23 19:01:20.327484
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment(program_name='Test')
    assert env.stderr != env._orig_stderr
    env.log_error('Backend')
    env.devnull.close()
    env.devnull = None
    with open(os.devnull, 'w') as devnull:
        env.devnull = devnull
        env.log_error('Frontend')

# Start of script
if __name__ == '__main__':
    test_Environment_log_error()

# Generated at 2022-06-23 19:01:22.692333
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(is_windows='windows', stdout='httpie print')
    assert env.is_windows, 'windows'
    assert env.stdout, 'httpie print'

# Generated at 2022-06-23 19:01:24.223949
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error('test')


# Generated at 2022-06-23 19:01:30.372996
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment(stdout=StringIO(), stderr=StringIO())
    env.log_error("test message")
    assert 'http: error: test message' in env.stderr.getvalue()
    env.log_error("test warning", level='warning')
    assert 'http: warning: test warning' in env.stderr.getvalue()

# Generated at 2022-06-23 19:01:31.830523
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error('test message')


# Generated at 2022-06-23 19:01:40.684252
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment(stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr)
    assert str(env) == '<Environment {config_dir: \'/Users/shanks/.httpie\', stdin: None, stdin_isatty: True, stdin_encoding: \'utf8\', stdout: <_io.TextIOWrapper name=\'<stdout>\' mode=\'w\' encoding=\'utf8\'>, stdout_isatty: True, stdout_encoding: \'utf8\', stderr: <_io.TextIOWrapper name=\'<stderr>\' mode=\'w\' encoding=\'utf8\'>, stderr_isatty: True, colors: 256, program_name: \'http\'}>'


# Generated at 2022-06-23 19:01:42.015356
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    pass


# Generated at 2022-06-23 19:01:51.857966
# Unit test for constructor of class Environment
def test_Environment():
    import sys

    def test_property(self,name, value):
        assert getattr(self, name) == value

    env = Environment(is_windows=True,
                      stdin=sys.stdin,
                      stdout=sys.stdout,
                      stderr=sys.stderr,
                      program_name='http',
                      config_dir=DEFAULT_CONFIG_DIR)

    # Test config_dir, stdin, stdout, stderr, program_name, is_windows
    test_property(env, 'config_dir', DEFAULT_CONFIG_DIR)
    test_property(env, 'stdin', sys.stdin )
    test_property(env, 'stdout', sys.stdout)
    test_property(env, 'stderr', sys.stderr)

# Generated at 2022-06-23 19:02:01.643299
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():

    e = Environment()

# Generated at 2022-06-23 19:02:13.622219
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
	# Test 1
	env = Environment(is_windows=False)
	expected = '<Environment {\'is_windows\': False, \'config_dir\': Path(\'/usr/local/etc/httpie\'), \'stdin\': <_io.BufferedReader name=0>, \'stdin_isatty\': False, \'stdout\': <_io.BufferedWriter name=1>, \'stdout_isatty\': False, \'stderr\': <_io.BufferedWriter name=2>, \'stderr_isatty\': False, \'colors\': 256, \'program_name\': \'http\'}>'
	assert repr(env) == expected
	# Test 2
	env = Environment()

# Generated at 2022-06-23 19:02:16.855875
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    environ = Environment()
    assert repr(environ) == f'<Environment {{' \
                            f'config: <httpie.config.Config config_dir={environ.config_dir!r}>' \
                            f'}}>'

# Generated at 2022-06-23 19:02:28.261624
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    actual = Environment(devnull=None, color=0,
        is_windows=False,
        config_dir=Path(r'/Users/chen/.config/httpie'),
        stdin=sys.stdin, stdin_isatty=True, stdin_encoding=None,
        stdout=sys.stdout, stdout_isatty=True, stdout_encoding=None,
        stderr=sys.stderr, stderr_isatty=True,
        colors=256,
        program_name='http')
    print(actual)

# Generated at 2022-06-23 19:02:39.839288
# Unit test for constructor of class Environment
def test_Environment():
    assert repr(Environment()) == "<Environment {'config_dir': '~/.config/httpie', 'stdin': <_io.TextIOWrapper name='<stdin>' mode='r' encoding='utf8'>, 'stdin_isatty': False, 'stdin_encoding': 'utf8', 'stdout': <_io.TextIOWrapper name='<stdout>' mode='w' encoding='utf8'>, 'stdout_isatty': True, 'stdout_encoding': 'utf8', 'stderr': <_io.TextIOWrapper name='<stderr>' mode='w' encoding='utf8'>, 'stderr_isatty': True, 'colors': 256, 'program_name': 'http', 'config': <Config {}>}>"


# Generated at 2022-06-23 19:02:45.230681
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name='httpie')
    assert env.program_name == 'httpie'
    assert env.stderr_isatty == env.stdout_isatty
    assert env.stdout_encoding == env.stdin_encoding
    assert env.stdout_encoding == (getattr(env.stdout, 'encoding', None) or 'utf8')
    assert isinstance(env.config_dir, Path)

# Generated at 2022-06-23 19:02:50.270836
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment(config_dir = 'a/b', colors = None, program_name = 'httpie')
    assert env.__repr__() == "<Environment {'config_dir': 'a/b', 'colors': None, 'program_name': 'httpie'}>"

# Generated at 2022-06-23 19:03:01.757365
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    # Setup
    e = Environment(stdin='stdin', stdout='stdout', stderr='stderr')
    # Exercise & Verify

# Generated at 2022-06-23 19:03:10.304866
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment()
    assert isinstance(e, Environment)
    assert e.is_windows == False
    assert e.config_dir == '/Users/Fry/.config/httpie'
    assert isinstance(e.stdin,IO)
    assert e.stdin_isatty == True
    assert e.stdin_encoding == 'utf8'
    assert isinstance(e.stdout,IO)
    assert e.stdout_isatty == True
    assert e.stdout_encoding == 'utf8'
    assert isinstance(e.stderr,IO)
    assert e.stderr_isatty == True
    assert e.colors == 256
    assert e.program_name == 'http'



if __name__ == '__main__':
    e = Environment()

# Generated at 2022-06-23 19:03:19.577862
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    import io
    import sys
    env = Environment(colors=256, config_dir='/home/.config/httpie', is_windows=True, program_name='http', stderr=io.StringIO(), stdin=io.StringIO(), stdout=io.StringIO())
    env.stderr.write = lambda *args: sys.stdout.write(str(args))
    env.stderr.flush = lambda: True
    env.stdout.write = lambda *args: sys.stdout.write(str(args))
    env.stdout.flush = lambda: True
    env.stdin.write = lambda *args: sys.stdout.write(str(args))
    env.stdin.flush = lambda: True
    print(env.__str__())

# Generated at 2022-06-23 19:03:30.827877
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    import pytest
    from httpie.core import main
    from httpie.config import parse_key_value_input
    import unittest.mock as mock
    import os
    import atexit
    
    class Args:
        def __init__(self, headers=[], data=[]):
            self.headers = headers
            self.data = data
            self.body = "Hello, World!"
        def __repr__(self):
            return 'Args({}, {}, {})'.format(self.headers, self.data, self.body)
    

# Generated at 2022-06-23 19:03:42.437047
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    from httpie.core import env
    repr_str = repr(env)

# Generated at 2022-06-23 19:03:44.939768
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    e = Environment()
    e_str = str(e)
    assert isinstance(e_str, str)


# Generated at 2022-06-23 19:03:54.598600
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    e = Environment()

# Generated at 2022-06-23 19:04:06.587219
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from io import StringIO, TextIOWrapper
    import sys
    import os
    from httpie.compat import is_windows
    sys.stdin = StringIO("hello")
    sys.stdout = TextIOWrapper(StringIO(), sys.stdout.encoding)
    sys.stderr = TextIOWrapper(StringIO(), sys.stderr.encoding)
    env = Environment()
    if not is_windows:
        if curses:
            try:
                curses.setupterm()
                colors = curses.tigetnum('colors')
            except curses.error:
                pass
        else:
            colors = 256
    else:
        colors = 256

# Generated at 2022-06-23 19:04:07.710065
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    assert Environment()



# Generated at 2022-06-23 19:04:19.106555
# Unit test for constructor of class Environment
def test_Environment():
    rtn = Environment(stdin=None, stdin_isatty=False, stdin_encoding=None, stdout=None, stdout_isatty=False, stdout_encoding=None, stderr=None, stderr_isatty=False, colors=256, program_name='http', _orig_stderr=None, _devnull=None)
    import sys
    rtn.stdin = sys.stdin
    rtn.stdout = sys.stdout
    rtn.stderr = sys.stderr
    assert rtn.stdin.buffer.raw == sys.__stdin__.buffer.raw
    assert rtn.stdin_isatty == rtn.stdin.isatty()

# Generated at 2022-06-23 19:04:30.226962
# Unit test for constructor of class Environment
def test_Environment():
    '''
    Dict is correctly created from initialised variables
    '''
    enc = 'utf8'
    test_stdin = 'test_stdin'
    test_stdin_enc = 'test_stdin_enc'
    test_stdout = 'test_stdout'
    test_stdout_enc = 'test_stdout_enc'
    test_stderr = 'test_stderr'
    test_verbosity = 'test_verbosity'
    test_config_dir = 'test_config_dir'
    test_colors = 'test_colors'


# Generated at 2022-06-23 19:04:38.851708
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(config_dir=DEFAULT_CONFIG_DIR)

# Generated at 2022-06-23 19:04:48.745123
# Unit test for constructor of class Environment
def test_Environment():
    import io
    import textwrap
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.utils import wrap_stream
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    if env.stdin is None:
        assert not env.stdin_isatty
    else:
        assert env.stdin_isatty
    assert env.stdin_encoding is None
    #assert env.stdout_isatty
    assert env.stdout_encoding is None
    #assert env.stderr_isatty
    assert env.colors == 256
    assert env.program_name == 'http'
    #

# Generated at 2022-06-23 19:04:49.958853
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    # TODO: This test is weak
    Environment().__str__()

# Generated at 2022-06-23 19:04:56.459711
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from .vendor.vistir.path import mkdir_p
    import tempfile
    import os
    path = mkdir_p(tempfile.gettempdir(),'httpie')
    env = Environment(config_dir=path)
    env.config_dir = os.path.join(path,'httpie')
    assert str(env).startswith('<Environment')
    os.rmdir(env.config_dir)
    os.rmdir(path)

# Generated at 2022-06-23 19:05:09.345231
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()

# Generated at 2022-06-23 19:05:16.732746
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(config_dir='C:\\Users\\ly\\AppData\\Roaming\\httpie',                             stdout_encoding=None,                             stdin_isatty=True,                             stderr_isatty=True,                             is_windows=True,                             program_name='http',                             stdout_isatty=True)
    print(env)

test_Environment()

# Generated at 2022-06-23 19:05:21.097953
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    import sys
    import pytest
    import httpie.env

    env = httpie.env.Environment()

    printed = io.StringIO()

    with pytest.raises(AssertionError) as einfo:
        env.log_error("sample error", level="test")

    env.log_error("sample error", level="warning")


# Generated at 2022-06-23 19:05:28.278230
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    import unittest

    class TestEnvironment(unittest.TestCase):
        def setUp(self):
            self.message = 'This is the error message'
            self.orig_stderr = sys.stderr
            sys.stderr = self.out = io.StringIO()
            self.env = Environment()
        def test_default_level(self):
            self.env.log_error(self.message)
            self.assertEqual(self.out.getvalue(), f'\nhttp: error: {self.message}\n\n')
        def test_error_level(self):
            self.env.log_error(self.message, level='error')

# Generated at 2022-06-23 19:05:37.718302
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    e = Environment(devnull=None, is_windows=False,
                    config_dir='/home/user/.config/httpie',
                    stdin=None,
                    stdin_isatty=False,
                    stdin_encoding='None',
                    stdout=sys.stdout,
                    stdout_isatty=True,
                    stdout_encoding='UTF-8',
                    stderr=sys.stderr,
                    stderr_isatty=True,
                    colors=256,
                    program_name='http')
    print(e)

# Generated at 2022-06-23 19:05:44.726774
# Unit test for method log_error of class Environment
def test_Environment_log_error():  # pragma: no cover
    from httpie.output.streams import UnsupportedEncoding

    env = Environment(stderr=sys.stdout)
    msg = 'Test error message'
    env.log_error(msg=msg)
    env.log_error(msg=msg, level='warning')  # Warning message
    # Error message as exception
    env.log_error(msg=UnsupportedEncoding(encoding=None))
    # Error message as instance with __str__ method
    env.log_error(msg=UnsupportedEncoding(encoding=None))

# Generated at 2022-06-23 19:05:49.219964
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdout=sys.stdout, stderr=sys.stderr, stdin=sys.stdin)
    assert isinstance(env, Environment)
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert env.stdin == sys.stdin


# Generated at 2022-06-23 19:05:59.061345
# Unit test for constructor of class Environment
def test_Environment():
    import sys
    import os

    from httpie.compat import is_windows
    from httpie.config import DEFAULT_CONFIG_DIR, Config, ConfigFileError

    from httpie.utils import repr_dict

    is_windows: bool = is_windows
    config_dir: Path = DEFAULT_CONFIG_DIR
    stdin: Optional[IO] = sys.stdin  # `None` when closed fd (#791)
    stdin_isatty: bool = stdin.isatty() if stdin else False
    stdin_encoding: str = None
    stdout: IO = sys.stdout
    stdout_isatty: bool = stdout.isatty()
    stdout_encoding: str = None
    stderr: IO = sys.stderr
    stderr_isat

# Generated at 2022-06-23 19:06:06.936699
# Unit test for constructor of class Environment
def test_Environment():
    import io
    import tempfile
    tempDir = tempfile.TemporaryDirectory()
    with io.StringIO() as stdout, io.StringIO() as stderr:
        with Environment(
                stdout=stdout, stderr=stderr, config_dir=tempDir.name) as env:
            env.config
            env.log_error("hello")
            env.__str__()
            env.__repr__()
            env.devnull = None
            env.devnull
test_Environment()

# Generated at 2022-06-23 19:06:16.371419
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    import sys

    assert str(Environment()) == str(
        Environment(
            config_dir="/home/wolverinn/.config/httpie",
            stdin="/dev/stdin",
            stdin_isatty=False,
            stdin_encoding="ANSI_X3.4-1968",
            stdout=sys.stdout,
            stdout_isatty=True,
            stdout_encoding="UTF-8",
            stderr=sys.stderr,
            stderr_isatty=True,
            colors=256,
            program_name="http",
            config={"__meta__": {"type": "dict"}, "colors": {"auto": True}},
        )
    )

# Generated at 2022-06-23 19:06:22.447687
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment(is_windows=True, stdout='<STDOUT>', stderr='<STDERR>', config_dir='<CONFIG_DIR>')
    env.config = '<CONFIG>'
    env.devnull = '<DEVNULL>'
    env._devnull = '<_DEVNULL>'
    env._orig_stderr = '<_ORIG_STDERR>'
    env.program_name = '<PROGRAM_NAME>'

# Generated at 2022-06-23 19:06:30.137381
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    env.is_windows = False
    env.config_dir = Path(DEFAULT_CONFIG_DIR)
    env.stdin = sys.stdin
    env.stdin_isatty = True
    env.stdin_encoding = 'utf8'
    env.stdout = sys.stdout
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'
    env.stderr = sys.stderr
    env.stderr_isatty = True
    env.colors = 16
    env.program_name = 'http'
    assert isinstance(str(env), str)


# Generated at 2022-06-23 19:06:32.539813
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    Env = Environment()
    print(Env)

test_Environment___repr__()

# Generated at 2022-06-23 19:06:41.807893
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    stderr = StringIO()
    env = Environment(stderr=stderr)
    env.log_error("Error message")
    assert stderr.getvalue() == """\

http: error: Error message

"""  # nopep8

    stderr = StringIO()
    env = Environment(devnull=StringIO(), stderr=stderr)
    env.log_error("Warning message", level="warning")
    assert stderr.getvalue() == """\

http: warning: Warning message

"""  # nopep8
    assert env.devnull.getvalue() == ""

# Generated at 2022-06-23 19:06:47.112703
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment(stderr=io.StringIO())
    env.log_error('test error')
    assert env.stderr.getvalue() == '\nhttp: error: test error\n\n'
    env.stderr.seek(0)
    env.stderr.truncate(0)
    env.log_error('test warning', level='warning')
    assert env.stderr.getvalue() == '\nhttp: warning: test warning\n\n'

# Generated at 2022-06-23 19:06:49.068838
# Unit test for constructor of class Environment
def test_Environment():
    Env = Environment(config_dir = "/usr/local/bin")
    assert Env.config_dir == "/usr/local/bin"

# Generated at 2022-06-23 19:06:52.135991
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    # TODO: add tests
    pass


# Generated at 2022-06-23 19:06:55.157116
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    assert str(Environment()) != ''
    assert str(Environment(colors=True, config_dir=DEFAULT_CONFIG_DIR)) != ''


# Generated at 2022-06-23 19:07:00.417414
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    stream = io.StringIO()
    msg = 'some_msg'
    level = 'error'
    env = Environment(stderr = stream)
    env.log_error(msg = msg, level = level)
    assert stream.getvalue() == '\nhttp: error: some_msg\n\n'
    
    

# Generated at 2022-06-23 19:07:05.635464
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    buf = io.StringIO()
    env = Environment(stderr=buf, program_name='test')
    env.log_error('test error')
    env.log_error('test warning', level='warning')
    assert 'test error' in buf.getvalue()
    assert 'test warning' in buf.getvalue()


# Generated at 2022-06-23 19:07:14.616298
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.downloads import Downloader
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.status import ExitStatus

# Generated at 2022-06-23 19:07:23.929650
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None)
    env.devnull = None
    assert env.stdin.isatty() == sys.stdin.isatty()
    assert env.stderr.isatty() == sys.stderr.isatty()
    assert env.stdout.isatty() == sys.stdout.isatty()
    assert env.stdin.encoding == sys.stdin.encoding
    assert env.stdout.encoding == sys.stdout.encoding
    assert env.stderr.encoding == sys.stderr.encoding
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._devnull is None
    assert env._orig_stderr == sys.stderr
    assert env.config_dir == DEFAULT

# Generated at 2022-06-23 19:07:31.437186
# Unit test for constructor of class Environment
def test_Environment():
    import sys
    import warnings
    import pytest
    env = Environment(stderr=sys.stdout)
    # Check if attribute can be added to instance
    env.test_attribute = 10
    assert env.test_attribute == 10
    # Check if it is possible to add attribute which does not exist in class
    with pytest.raises(AssertionError):
        env._config = 10
    # Check if the warning was printed
    with pytest.warns(UserWarning) as record:
        warnings.warn('test_warn')
    assert len(record) == 1
    assert record[0].message.args[0] == 'test_warn'
    assert env.stdout == sys.stdout

# Generated at 2022-06-23 19:07:39.204231
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from unittest.mock import Mock
    temp_stdout = Mock()
    try:
        sys.stderr = temp_stdout
        env = Environment()
        env.log_error("First OK", level='warning')
    except ValueError as e:
        print(f"Expected ValueError is : {e}")
    except Exception as e:
        print(f"Different exception is : {e}")
    else:
        print(f"test_log_error passed")


# Generated at 2022-06-23 19:07:46.669000
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(**{
        'is_windows': True,
        'config_dir': '/',
        'stdin': None,
        'stdin_isatty': False,
        'stdin_encoding': None,
        'stdout': None,
        'stdout_isatty': True,
        'stdout_encoding': None,
        'stderr': None,
        'stderr_isatty': False,
        'program_name': 'test',
    })

# Generated at 2022-06-23 19:07:50.235185
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    env = Environment(stderr=io.StringIO())
    env.log_error("test message")
    expected_output = "test message"
    assert env.stderr.getvalue().endswith(expected_output)

# Generated at 2022-06-23 19:08:00.126608
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    import pytest, sys
    from httpie.compat import is_windows

    env = Environment()
    print(env)
    
    assert isinstance(env.is_windows, bool)
    assert isinstance(env.config_dir, Path)
    assert isinstance(env.stdin, Optional[IO])
    assert isinstance(env.stdin_isatty, bool)
    assert isinstance(env.stdin_encoding, str)
    assert isinstance(env.stdout, IO)
    assert isinstance(env.stdout_isatty, bool)
    assert isinstance(env.stdout_encoding, str)
    assert isinstance(env.stderr, IO)
    assert isinstance(env.stderr_isatty, bool)
    assert isinstance(env.colors, int)

# Generated at 2022-06-23 19:08:07.963333
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from httpie.utils import temp_config_dir
    from httpie.config import Config
    from httpie.compat import is_windows
    from pathlib import Path

    with temp_config_dir() as temp_path:
        temp_path = Path(temp_path)
        config = Config(directory=temp_path)
        if is_windows:
            color = '0'
        else:
            color = '256'
        env = Environment(config_dir = temp_path,
                          stdin = sys.stdin,
                          stdout = sys.stdout,
                          stderr = sys.stderr,
                          colors = color,
                          devnull = os.devnull,
                          program_name = 'http')

# Generated at 2022-06-23 19:08:14.149659
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()

# Generated at 2022-06-23 19:08:19.845479
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment()
    print(e)
    print(e.stdin)
    print(e.stdin_encoding)
    print(e.stdout_encoding)
    print(e.config_dir)
    print(e.devnull)
    print(e.config)