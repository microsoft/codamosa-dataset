

# Generated at 2022-06-23 18:58:26.790371
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    output = io.StringIO()
    env = Environment(program_name='http', stderr=output)
    env.log_error('msg', 'warning')
    assert output.getvalue() == '\nhttp: warning: msg\n\n'
    output.close()


    # def log_debug(self, msg):
    #     if self.debug:
    #         self._orig_stderr.write(f'\n{self.program_name}: {msg}\n\n')

# Generated at 2022-06-23 18:58:31.294967
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    print(env)
    env2 = Environment(program_name='test http')
    print(env2)
    assert env.program_name == 'http', 'class default value must not change'

test_Environment()

# Generated at 2022-06-23 18:58:40.320546
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    class TestEnvironment(Environment):
        pass
    testEnvironment = TestEnvironment(
        is_windows=True,
        config_dir=Path(DEFAULT_CONFIG_DIR),
        stdin=sys.stdin,
        stdin_isatty=True,
        stdin_encoding='utf8',
        stdout=sys.stdout,
        stdout_isatty=True,
        stdout_encoding='utf8',
        stderr=sys.stderr,
        stderr_isatty=True,
        colors=256,
        program_name='http',
        config=Config(directory=Path(DEFAULT_CONFIG_DIR))
    )

# Generated at 2022-06-23 18:58:41.428776
# Unit test for constructor of class Environment
def test_Environment():
  env = Environment()
  print(env)

if __name__ == "__main__":
  test_Environment()

# Generated at 2022-06-23 18:58:43.173453
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env1 = Environment()
    default = str(env1)
    env2 = Environment(stdin_encoding = "uft8")
    actual = str(env2)
    assert actual == default

# Generated at 2022-06-23 18:58:52.749390
# Unit test for method __repr__ of class Environment

# Generated at 2022-06-23 18:59:01.316600
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    env.config_dir = "C:\\Users\\Test"
    env.stdin = sys.stdin
    env.stdout = sys.stdout
    env.stderr = sys.stderr


# Generated at 2022-06-23 18:59:12.780871
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from httpie.config import DEFAULT_CONFIG_DIR

    env = Environment(
        is_windows=False,
        config_dir=DEFAULT_CONFIG_DIR,
        stdin=None,
        stdin_isatty=False,
        stdin_encoding='utf8',
        stdout=sys.stdout,
        stdout_isatty=sys.stdout.isatty(),
        stdout_encoding='utf8',
        stderr=sys.stderr,
        stderr_isatty=sys.stderr.isatty(),
        colors=256,
        program_name='http'
    )


# Generated at 2022-06-23 18:59:23.896173
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    args = ['http']
    # print("Environment str method is: %s" % repr_dict(env.__str__()))

# Generated at 2022-06-23 18:59:30.673361
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.stdin = BytesIO()
    env.stdout = BytesIO()
    env.stderr = BytesIO()
    env.config_dir = Path('/tmp')
    env.program_name = 'http'
    env.log_error('test')
    assert env.stderr.getvalue() == b'\nhttp: error: test\n\n'


# Generated at 2022-06-23 18:59:39.489605
# Unit test for constructor of class Environment
def test_Environment():
    import os
    import sys
    from httpie.compat import is_windows

    def replace_stream(stream_name, new_stream):
        return setattr(env, stream_name, new_stream)

    # self.is_windows
    assert is_windows == env.is_windows

    # self.config_dir
    assert DEFAULT_CONFIG_DIR == env.config_dir

    # self.stdin
    assert sys.stdin == env.stdin
    replace_stream('stdin', None)
    assert env.stdin is None
    replace_stream('stdin', sys.stdin)

    # self.stdin_isatty
    if sys.stdin.isatty():
        assert env.stdin_isatty
    else:
        assert not env.stdin_isatty

   

# Generated at 2022-06-23 18:59:47.064422
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    import sys
    import unittest
    from unittest.mock import patch

    sys.stderr = io.StringIO()
    msg = 'Dummy Error Message'
    try:
        a = Environment()
        a.log_error(msg)
        error_log = sys.stderr.getvalue()
    finally:
        sys.stderr = sys.__stderr__

    unittest.TestCase().assertEqual(error_log, '\nhttp: error: ' + msg + '\n\n')

# Generated at 2022-06-23 18:59:50.518286
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    # Test Environment.__str__()
    env = Environment(colors=600,
                      devnull='a',
                      program_name='a',
                      _orig_stderr='a',
                      _devnull='a')
    assert str(env) == "{'colors': 600, 'config': None}"

# Generated at 2022-06-23 18:59:52.372628
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment()
    assert (e.__str__())
    assert (e.__repr__())
    


# Generated at 2022-06-23 18:59:53.453698
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    pass


# Generated at 2022-06-23 18:59:56.453533
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    assert type(env) == Environment, 'Environment() fail'
    assert env.__repr__() == '<Environment {}>', 'Environment().__repr__() fail'

test_Environment___repr__()

# Generated at 2022-06-23 19:00:05.414016
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    import io
    import sys
    env = Environment(stdin_isatty=True, stdout_isatty=False, stderr_isatty=True, stdin=io.StringIO(sys.platform), stdout=io.StringIO('stdout'), stderr=io.StringIO('stderr'), program_name='program name')

# Generated at 2022-06-23 19:00:14.791686
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    stdin, stdout, stderr = object(), object(), object()
    env = Environment(
        stdin=stdin,
        stdin_encoding='FOO',
        stdin_isatty=True,
        stdout=stdout,
        stdout_encoding='BAR',
        stdout_isatty=False,
        stderr=stderr,
        stderr_isatty=False,
        is_windows=False,
        colors=256,
        config_dir=Path(__file__),
        program_name='BAZ',
        foo='bar'
    )

# Generated at 2022-06-23 19:00:23.569448
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    target = Environment()
    expected = '<Environment {' \
               '\'stdin_encoding\': \'utf8\',' \
               ' \'stdout_encoding\': \'utf8\',' \
               ' \'stdin\': <_io.TextIOWrapper name=7 encoding=\'UTF-8\'>,' \
               ' \'stdin_isatty\': True,' \
               ' \'stderr\': <_io.TextIOWrapper name=8 encoding=\'UTF-8\'>,' \
               ' \'stderr_isatty\': True,' \
               ' \'stdout\': <_io.TextIOWrapper name=6 encoding=\'UTF-8\'>,' \
               ' \'stdout_isatty\': True}>'
    assert (str(target) == expected)

# Generated at 2022-06-23 19:00:28.484275
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    class Test:
        a: int
        b: int
        c: int
        d: int
        e: int
        f: int
    try:
        Test()
    except TypeError as e:
        print(e)

    t = Environment(a=1, b=2, c=3)
    print(repr(t))


# Generated at 2022-06-23 19:00:38.728840
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    os.environ["HTTPIE_CONFIG_DIR"] = "env_config"
    env = Environment()
    assert 'config_dir' in str(env)
    assert 'config' not in str(env)
    assert '_config' not in str(env)
    assert '_devnull' not in str(env)
    assert '<Environment' not in str(env)
    assert 'stdout_encoding' in str(env)
    assert 'stdin_encoding' in str(env)
    assert 'Program_name' not in str(env)
    assert 'devnull' not in str(env)
    assert '_orig_stderr' not in str(env)
    assert 'colors' in str(env)


# Generated at 2022-06-23 19:00:46.347750
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import StringIO
    import sys

    capturedOutput = StringIO()                  # Create StringIO object
    sys.stderr = capturedOutput
    en = Environment()
    en.log_error('error')
    assert capturedOutput.getvalue() == '\nhttp: error: error\n\n'
    en.log_error('error', level='warning')
    assert capturedOutput.getvalue() == '\nhttp: error: error\n\nhttp: warning: error\n\n'


# Generated at 2022-06-23 19:00:51.992648
# Unit test for constructor of class Environment

# Generated at 2022-06-23 19:00:53.567312
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    Environment(program_name='hi')
    assert True


# Generated at 2022-06-23 19:00:56.881126
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    import sys
    import os
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_CONFIG_DIR
    import Environment
    print(repr(Environment.Environment()))

# Generated at 2022-06-23 19:01:05.553529
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(
        stdin=StringIO("HEAD / HTTP/1.1\r\nHost: example.com\r\n\r\n"),
        stdin_encoding="utf-8",
        stdout=StringIO("HTTP/1.1 200 OK\r\n\r\n"),
        stdout_encoding="utf-8",
        stderr=StringIO(""),
        stderr_encoding="utf-8",
        is_windows=False,
        config_dir="test_config_dir",
        program_name="test_program_name"
    )

# Generated at 2022-06-23 19:01:07.323376
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    print(Environment())
    env = Environment(is_windows=True)
    print(Environment())

# Generated at 2022-06-23 19:01:08.321230
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    repr_dict(env)



# Generated at 2022-06-23 19:01:14.660299
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    from httpie.core import main
    from httpie.context import Environment

    ENV = Environment()
    assert '<Environment' in repr(ENV)
    assert 'default' not in repr(ENV)

    ENV.headers = None
    assert 'default' in repr(ENV)

    main.main(['--verbose', 'http', 'https://httpbin.org/get'])

# Generated at 2022-06-23 19:01:22.157901
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import StringIO
    from httpie.utils import get_encoded_stream
    from httpie.streams import FallbackEncodingStreamWriter

    # Create a new Environment class instance
    env = Environment()

    # Prepare the stderr object, it is actually a FileIO object
    # with an encoding attribute, so it simulates the real
    # stderr stream of the system
    stderr = StringIO()
    stderr.encoding = 'utf8'

    # Test
    # ------------------------------------------------
    # The stderr stream is not a tty, the FallbackEncodingStreamWriter
    # should be used
    env.stderr = stderr
    env.stderr_isatty = False
    env.log_error('test')

# Generated at 2022-06-23 19:01:27.450973
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(config_dir=DEFAULT_CONFIG_DIR)
    assert env.config_dir.is_dir()
    assert env.stderr_isatty
    config = default_environment.config


default_environment = Environment()
"""
The singleton for the actual environment.
"""

# Generated at 2022-06-23 19:01:38.424758
# Unit test for method __str__ of class Environment

# Generated at 2022-06-23 19:01:40.489938
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    repr = repr(env)
    repr.splitlines()

# Generated at 2022-06-23 19:01:51.145160
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    env.stdin = None
    env.config_dir = 'config dir'
    env.stdin_isatty = True
    env.stdin_encoding = True
    env.stdout = 'stdout'
    env.stdout_isatty = 'stdout_isatty'
    env.stdout_encoding = 'stdout_encoding'
    env.stderr = 'stderr'
    env.stderr_isatty = 'stderr_isatty'
    env.colors = 'colors'
    env.program_name = 'program_name'

# Generated at 2022-06-23 19:02:01.107201
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    global TERM, SHELL
    SHELL = "/bin/bash"
    TERM = "xterm-256color"
    environment = Environment()

# Generated at 2022-06-23 19:02:13.154571
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    class UnitTestEnvironment(Environment):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._orig_stderr = io.StringIO()
            self.stderr = self._orig_stderr
            self.program_name = 'HTTPie'

    env = UnitTestEnvironment()

    env.log_error('`Cannot decode bytes`', level='warning')
    env.log_error('Unknown error', level='error')
    stderr_output = env._orig_stderr.getvalue().split('\n')
    assert stderr_output[0] == 'HTTPie: warning: `Cannot decode bytes`'
    assert stderr_output[2] == 'HTTPie: error: Unknown error'

# Generated at 2022-06-23 19:02:16.678159
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment(devnull=None, is_windows=True, colors=1, program_name='hi')
    assert e.is_windows == True
    assert e.colors == 1
    assert e.program_name == 'hi'

# Generated at 2022-06-23 19:02:28.080754
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import six
    import io
    import warnings
    error = io.StringIO()
    warning = io.StringIO()
    env = Environment(stderr=io.StringIO())
    env.program_name = 'http'
    env.log_error('error', level='error')
    error.write(env.stderr.read())
    env.log_error('warning', level='warning')
    warning.write(env.stderr.read())
    assert error.getvalue() == '\nhttp: error: error\n\n'
    assert warning.getvalue() == '\nhttp: warning: warning\n\n'
    errors = io.StringIO()
    warnings.showwarning = errors.write
    env.log_error('warning', level='warning')

# Generated at 2022-06-23 19:02:39.646948
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert os.path.isdir(env.config_dir)
    assert env.config

    env = Environment(devnull = sys.stdout,
                      is_windows = True,
                      config_dir = os.getcwd(),
                      stdin = sys.stdout,
                      stdin_isatty = True,
                      stdin_encoding = 'utf-8',
                      stdout = sys.stderr,
                      stdout_isatty = True,
                      stdout_encoding = 'utf-8',
                      stderr = sys.stdin,
                      stderr_isatty = True,
                      colors = 10,
                      program_name = 'http test')

    assert env.config_dir == os.getcwd()
    assert env.stdin == sys.stdout

# Generated at 2022-06-23 19:02:46.416398
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()


# Generated at 2022-06-23 19:02:58.026262
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    e = Environment(devnull = None, is_windows = False, config_dir = '/home/httpie/config/',
        stdin = sys.stdin, stdin_isatty = sys.stdin.isatty(), stdin_encoding = 'utf-8',
        stdout = sys.stdout, stdout_isatty = sys.stdout.isatty(), stdout_encoding = 'utf-8',
        stderr = sys.stderr, stderr_isatty = sys.stderr.isatty(), colors = 256, program_name = 'http')

# Generated at 2022-06-23 19:03:04.056886
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows is False
    assert env.config_dir == Path.home() / '.config' / 'httpie'
    assert env.stderr_encoding is None
    assert env.stdin_encoding is None
    assert env.stdout_encoding is None
    assert env.curses is None


# Generated at 2022-06-23 19:03:07.454789
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    class DummyEnvironment(Environment):
        stdout_isatty = True

    env = DummyEnvironment()
    env.config_dir = Path(os.getcwd())
    env.program_name = 'http'
    env.stderr = 'out'

    msg = "Error"
    env.log_error(msg, level='error')
    msg = f"{env.program_name}: error: {msg} \n \n "
    assert env.stderr == msg

# Generated at 2022-06-23 19:03:11.172168
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    e = Environment()
    assert isinstance(e.__repr__(), str)
    print(e.__repr__())
    print(e.__repr__().__repr__())



# Generated at 2022-06-23 19:03:20.764421
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    import httpie
    env = httpie.Environment(program_name='test', colors=8, config_dir='test')

# Generated at 2022-06-23 19:03:21.915239
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    Environment(program_name="True")

# Generated at 2022-06-23 19:03:33.413200
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():

    import sys
    import os
    from pathlib import Path

    env = Environment()


# Generated at 2022-06-23 19:03:45.103409
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    test_repr = repr(env)

# Generated at 2022-06-23 19:03:52.191207
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    print(env)
    env.program_name = 'hello'
    print(env)

# Generated at 2022-06-23 19:04:04.092356
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from httpie.core import Environment
    from httpie.core import DEFAULT_CONFIG_DIR
    from httpie.config import Config
    from httpie.client import FileUpload
    import sys
    env = Environment()

# Generated at 2022-06-23 19:04:08.059062
# Unit test for constructor of class Environment
def test_Environment():
    e=Environment()
    assert(type(e.config)==httpie.config.Config)
    assert(type(e.devnull)==_io.TextIOWrapper)
    assert(type(str(e))==str)

# Generated at 2022-06-23 19:04:19.211246
# Unit test for method __repr__ of class Environment

# Generated at 2022-06-23 19:04:30.322895
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    result = env.__repr__()
    assert type(result) == str
    assert result == '<Environment {\'config\': None, \'stdin\': <_io.TextIOWrapper name=\'<stdin>\' mode=\'r\' encoding=\'cp850\'>, \'stdin_isatty\': True, \'stdout\': <_io.TextIOWrapper name=\'<stdout>\' mode=\'w\' encoding=\'cp850\'>, \'stdout_isatty\': True, \'stderr\': <_io.TextIOWrapper name=\'<stderr>\' mode=\'w\' encoding=\'cp850\'>, \'stderr_isatty\': True, \'program_name\': \'http\'}>'


# Generated at 2022-06-23 19:04:38.908431
# Unit test for method __str__ of class Environment

# Generated at 2022-06-23 19:04:48.787981
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    os.environ['HTTPIE_CONFIG_DIR'] = '''/tmp'''
    os.environ['HTTPIE_COLORS'] = '''256'''
    os.environ['HTTPIE_PROGRAM_NAME'] = '''http'''
    e = Environment(colors = 256, config_dir = '/tmp')
    assert str(e) == '''\
{'config_dir': '/tmp',
 'colors': 256,
 'program_name': 'http',
 'stderr_isatty': True,
 'stdout_isatty': True,
 'stdin_isatty': True,
 'is_windows': False,
 'config': <Config /tmp/config.json>}'''
    del os.environ['HTTPIE_CONFIG_DIR']

# Generated at 2022-06-23 19:04:58.522182
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    global config_dir
    if config_dir is None:
        config_dir = DEFAULT_CONFIG_DIR

# Generated at 2022-06-23 19:05:09.833704
# Unit test for method __str__ of class Environment

# Generated at 2022-06-23 19:05:14.678295
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from sys import stderr
    env = Environment(_orig_stderr=stderr)
    err = '这是一个错误'
    env.log_error(err)
    assert err == '这是一个错误'

# Generated at 2022-06-23 19:05:16.778815
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    print(Environment.__repr__(Environment()))

# Generated at 2022-06-23 19:05:25.365296
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment(is_windows=False,config_dir='test_config_dir')

# Generated at 2022-06-23 19:05:28.886882
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    stderr = io.StringIO()
    env = Environment(stderr=stderr)
    env.log_error('error message')
    assert stderr.getvalue() == '\nhttp: error: error message\n\n'

env = Environment()

# Generated at 2022-06-23 19:05:29.891107
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    assert repr(Environment()) == f'<{type(Environment()).__name__} {{}}>'



# Generated at 2022-06-23 19:05:30.714285
# Unit test for method __str__ of class Environment
def test_Environment___str__():
  assert True

# Generated at 2022-06-23 19:05:38.903440
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    assert repr(Environment()) == '<Environment {}>'
    assert repr(Environment(is_windows=True)) == '<Environment {\'is_windows\': True}>'

# Generated at 2022-06-23 19:05:47.310357
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()

# Generated at 2022-06-23 19:05:57.836635
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    from unittest import mock
    from . import Environment

    def create_Environment():
        # create a Environment object with sys.stderr temporarily mocked
        stream = io.StringIO()
        with mock.patch('sys.stderr', stream):
            env = Environment()
        return env, stream

    env, stream = create_Environment()
    msg = 'this is an error message'
    env.log_error(msg)
    assert stream.getvalue().startswith('http: error: this is an error message\n')

    env, stream = create_Environment()
    msg = 'this is a warning'
    env.log_error(msg, level='warning')
    assert stream.getvalue().startswith('http: warning: this is a warning\n')

    env, stream = create_Environment()
   

# Generated at 2022-06-23 19:06:09.355716
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from httpie.utils import no_color
    buffer = io.BytesIO()
    env = Environment(stderr=buffer, stdout=buffer)
    env.config_dir = None
    env.stdin_isatty = True
    env.stdout_isatty = True
    env.stderr_isatty = True
    env.stdin_encoding = 'ascii'
    env.stdout_encoding = 'ascii'
    env.stderr_encoding = 'ascii'
    env.program_name = 'http'
    env.colors = 256
    env.stdin = None
    env.stdout = buffer
    env.stderr = buffer


# Generated at 2022-06-23 19:06:18.676944
# Unit test for constructor of class Environment
def test_Environment():
    class StreamWithEncoding:
        def __init__(self, encoding):
            self.encoding = encoding

    class StreamWithoutEncoding:
        pass

    class StreamWithBadEncoding:
        encoding = 'no-encoding'

    assert Environment().stdin_encoding == 'utf8'
    assert Environment(stdin=StreamWithEncoding('custom-encoding')).stdin_encoding == 'custom-encoding'
    assert Environment(stdin=StreamWithoutEncoding).stdin_encoding == 'utf8'
    assert Environment(stdin=StreamWithBadEncoding).stdin_encoding == 'utf8'

    assert Environment().stdout_encoding == 'utf8'
    assert Environment(stdout=StreamWithEncoding('custom-encoding')).stdout_encoding == 'custom-encoding'
    assert Environment

# Generated at 2022-06-23 19:06:22.707996
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import StringIO
    out = StringIO()
    env = Environment(stderr=out)
    env.log_error(msg='error', level='error')
    assert out.getvalue() == '\nhttp: error: error\n\n'

# Generated at 2022-06-23 19:06:30.317248
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.utils import repr_dict
    if is_windows:
        import colorama
    else:
        colorama = None
    environ = Environment()
    defaults = dict(environ.__class__.__dict__)
    actual = dict(defaults)
    actual.update(environ.__dict__)
    actual['config'] = environ.config
    assert repr_dict({
        key: value
        for key, value in actual.items()
        if not key.startswith('_')
    }) == str(environ)
    if is_windows:
        del colorama

# Generated at 2022-06-23 19:06:42.235599
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    # arrange
    import os
    import sys
    import curses
    e = Environment()
    # act
    result = str(e)
    # assert

# Generated at 2022-06-23 19:06:49.963007
# Unit test for constructor of class Environment
def test_Environment():
    import sys
    import os

    config_dict = {
        'is_windows': True,
        'config_dir': os.path.dirname(os.path.dirname(__file__)),
        'stdin': None,
        'stdin_isatty': False,
        'stdin_encoding': None,
        'stdout': sys.stdout,
        'stdout_isatty': True,
        'stdout_encoding': None,
        'stderr': sys.stderr,
        'stderr_isatty': True,
        'colors': 256,
        'program_name': 'http'
    }

# Generated at 2022-06-23 19:07:01.430295
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    import sys

# Generated at 2022-06-23 19:07:04.410208
# Unit test for method log_error of class Environment
def test_Environment_log_error():  # noqa
    environment = Environment()
    environment.log_error('text')


if __name__ == '__main__':
    test_Environment_log_error()

# Generated at 2022-06-23 19:07:06.145883
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    assert repr(env) == '<Environment {}>'


env = Environment()

# Generated at 2022-06-23 19:07:09.852433
# Unit test for constructor of class Environment
def test_Environment():
    environ = Environment(stdin=None, stdout=None, stderr=None)
    assert environ._orig_stderr == environ.stderr
    assert environ._devnull is None
    assert environ.config.directory == DEFAULT_CONFIG_DIR

# Generated at 2022-06-23 19:07:17.375031
# Unit test for method __repr__ of class Environment

# Generated at 2022-06-23 19:07:27.979431
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(
        color=256,
        config_dir=DEFAULT_CONFIG_DIR,
        is_windows=is_windows,
        program_name='http',
        stderr=sys.stderr,
        stderr_encoding=None,
        stderr_isatty=sys.stderr.isatty(),
        stdin=sys.stdin,
        stdin_encoding=None,
        stdin_isatty=sys.stdin.isatty(),
        stdout=sys.stdout,
        stdout_encoding=None,
        stdout_isatty=sys.stdout.isatty()
    )

# Generated at 2022-06-23 19:07:34.550434
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    def f(level):
        env = Environment()
        env._orig_stderr = io.StringIO()
        env.log_error(msg, level)
        return env._orig_stderr.getvalue()
    msg = 'something went wrong'

    assert f('error') == '\nhttp: error: {}\n\n'.format(msg)
    assert f('warning') == '\nhttp: warning: {}\n\n'.format(msg)
    assert f('notice') == '\nhttp: warning: {}\n\n'.format(msg)
    # assert f('debug') == ''
    # assert f('info') == ''

# Generated at 2022-06-23 19:07:36.495581
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error("Test error")

# Generated at 2022-06-23 19:07:47.539798
# Unit test for method __str__ of class Environment

# Generated at 2022-06-23 19:07:57.490319
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    # create an instance
    env = Environment(program_name = 'http')

    # get the result of __str__()
    result = str(env)

    # assert the result

# Generated at 2022-06-23 19:08:06.182935
# Unit test for constructor of class Environment
def test_Environment():
    # testdevnull 为测试文件
    testdevnull = open('testdevnull', 'w+')
    testenv = Environment(devnull=testdevnull, program_name='ttt')
    testenv.config
    testenv.devnull
    print(testenv)
    print(testenv.config)
    print(testenv.devnull)
    print(testenv._orig_stderr)
    print(testenv.is_windows)
    print(testenv.config_dir)
    print(testenv.stdin)
    print(testenv.stdin_isatty)
    print(testenv.stdin_encoding)
    print(testenv.stdout)
    print(testenv.stdout_isatty)

# Generated at 2022-06-23 19:08:08.642115
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    actual = Environment(test = 100).__str__()
    expect = "{'test': 100}"
    assert actual == expect

# Generated at 2022-06-23 19:08:18.448220
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    # Execute the code to be tested
    result = str(env)
    # Verify the result

# Generated at 2022-06-23 19:08:20.468027
# Unit test for constructor of class Environment
def test_Environment():
    print('test below :')
    print(Environment().stdin)

# test_Environment()

# Generated at 2022-06-23 19:08:28.671590
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    assert repr(Environment()) == '<Environment {}>'
    env = Environment(
        config_dir='/etc',
        stdin=object(),
        stdin_isatty=True,
        stdin_encoding='1',
        stdout=object(),
        stdout_isatty=True,
        stdout_encoding='1',
        stderr=object(),
        stderr_isatty=True,
        colors=256,
        program_name='http',
    )