

# Generated at 2022-06-23 18:58:30.068870
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(
        is_windows=False,
        config_dir='/dir/dir',
        stdin='stdin',
        stdin_isatty=True,
        stdin_encoding='stdin_encoding',
        stdout='stdout',
        stdout_isatty=True,
        stdout_encoding='stdout_encoding',
        stderr='stderr',
        stderr_isatty=True,
        colors=256,
        program_name='http',
        config=Config(directory=""),
    )

# Generated at 2022-06-23 18:58:39.436946
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment()
    e.config_dir = Path('/tmp')
    assert e.config_dir == Path('/tmp')
    e.stdin = sys.stdin
    assert e.stdin == sys.stdin
    e.stdin_isatty = True
    assert e.stdin_isatty
    e.stdin_encoding = 'utf8'
    assert e.stdin_encoding == 'utf8'
    assert e.stdin_encoding == sys.stdin.encoding
    e.stdout = sys.stdout
    assert e.stdout == sys.stdout
    e.stdout_isatty = True
    assert e.stdout_isatty
    e.stdout_encoding = 'utf8'

# Generated at 2022-06-23 18:58:46.746604
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    env.a = 1
    env.b = 2
    env.c = 3
    assert repr(env) == '<Environment {\'a\': 1, \'b\': 2, \'c\': 3, \'config\': <Config {}>}>'
    assert str(env) == '{\'a\': 1, \'b\': 2, \'c\': 3, \'config\': <Config {}>}'

# Generated at 2022-06-23 18:58:56.289842
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from httpie import ExitStatus
    from httpie.core import main
    from httpie.context import Environment
    from httpie.utils import get_local_ip_address
    from httpie.utils import get_remote_ip_address
    exit_status = ExitStatus()
    http_env = Environment()
    args = main.parser.parse_args(args=[get_local_ip_address(),':8000'])
    args.remote, args.port = get_remote_ip_address(args.remote)
    args.follow_redirects = True
    args.session = None
    args.timeout = 60
    args.output_options = None
    args.__dict__

# Generated at 2022-06-23 18:59:02.972987
# Unit test for method __str__ of class Environment
def test_Environment___str__():


    assert repr(env) == '<Environment {' \
                        '"config_dir": "C:\\\\Users\\\\Admin\\\\.config\\\\httpie", ' \
                        '"colors": 256, ' \
                        '"program_name": "http", ' \
                        '"stdin": <_io.TextIOWrapper name=<stdin> mode=\'r\' encoding=\'cp936\'>, ' \
                        '"stdin_encoding": "cp936", ' \
                        '"stdin_isatty": false, ' \
                        '"stdout": <_io.TextIOWrapper name=<stdout> mode=\'w\' encoding=\'cp936\'>, ' \
                        '"stdout_encoding": "cp936", ' \
                        '"stdout_isatty": true, '

# Generated at 2022-06-23 18:59:08.621495
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    e = Environment(stdin_encoding='UTF-8', stdout_encoding='UTF-8')

# Generated at 2022-06-23 18:59:09.661254
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    assert str(env) != ''

# Generated at 2022-06-23 18:59:18.537912
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    import sys
    import os
    import random
    import string
    dirname = ''.join(random.choices(string.ascii_uppercase, k=6))
    devnull = None
    is_windows = False
    program_name = ''.join(random.choices(string.ascii_lowercase, k=8))
    stdin_encoding = ''.join(random.choices(string.ascii_lowercase, k=8))
    stdout_encoding = ''.join(random.choices(string.ascii_lowercase, k=8))

# Generated at 2022-06-23 18:59:25.853761
# Unit test for constructor of class Environment
def test_Environment():
    class MyEnv(Environment): pass
    env = MyEnv(stdout=1, stdin=2, stderr=3)
    assert env.stdout == 1
    assert env.stdin == 2
    assert env.stderr == 3
    assert env.stderr_isatty == False
    assert env.stdout_isatty == False
    assert env.stdin_isatty == False
    assert env.stderr_encoding == None
    assert env.stdout_encoding == None
    assert env.stdin_encoding == None
    #print(env.config)


# Generated at 2022-06-23 18:59:27.186927
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    assert '<Environment' in str(Environment())


# Generated at 2022-06-23 18:59:37.401961
# Unit test for method __str__ of class Environment

# Generated at 2022-06-23 18:59:39.500733
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    env_str = str(env)
    assert isinstance(env_str, str)

# Generated at 2022-06-23 18:59:49.701273
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env_ = Environment()

# Generated at 2022-06-23 18:59:56.972653
# Unit test for constructor of class Environment
def test_Environment():
  from httpie.utils import StdSim
  from httpie.compat import is_windows
  stdin, stdout, stderr = StdSim()
  env = Environment(
      is_windows=False, config_dir="~/.httpie",
      stdin=stdin, stdout=stdout, stderr=stderr
  )
  env.log_error("this is a test")
  assert env.is_windows is False
  assert env.config_dir == "~/.httpie"
  assert env.stdin is stdin
  assert env.stdout is stdout
  assert env.stderr is stderr
  assert env.stdin_isatty is False
  assert env.stdout_isatty is True
  assert env.stderr_isatty is True
  assert env

# Generated at 2022-06-23 19:00:02.493227
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()

# Generated at 2022-06-23 19:00:12.289352
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    assert str(env) == "{'colors': 256, 'is_windows': True, 'stderr': <colorama.AnsiToWin32 object at 0x000001F9A5FFB9C8>, 'stderr_encoding': None, 'stderr_isatty': True, 'stdin': <_io.TextIOWrapper name='<stdin>' mode='r' encoding='cp936'>, 'stdin_encoding': 'cp936', 'stdin_isatty': True, 'stdout': <colorama.AnsiToWin32 object at 0x000001F9A5FEDE48>, 'stdout_encoding': None, 'stdout_isatty': True}"


# Generated at 2022-06-23 19:00:16.787338
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment(stderr=io.StringIO())
    env.log_error('Everyone do the "Flock of Seagulls" dance')
    assert env.stderr.getvalue() == '\nhttp: error: Everyone do the "Flock of Seagulls" dance\n\n'

# Generated at 2022-06-23 19:00:18.965603
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(stdin_encoding='utf8', stdout_encoding='latin1')
    assert str(env)


# Generated at 2022-06-23 19:00:25.050413
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()

# Generated at 2022-06-23 19:00:35.864283
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()

# Generated at 2022-06-23 19:00:38.308495
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(config_dir='/tmp')
    assert  env.config_dir == Path('/tmp')
    assert env

# Generated at 2022-06-23 19:00:42.678116
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin_encoding="utf8", program_name="httpie", devnull=None)
    assert env.stdin_encoding == "utf8"
    assert env.program_name == "httpie"
    assert env.devnull is None

# Generated at 2022-06-23 19:00:51.202736
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    # Test log error
    environment = Environment()
    with patch.object(sys.stderr, "write") as mocked_write:
        # Test log error with level error
        environment.log_error("test error", level='error')
        mocked_write.assert_called_with('\nhttp: error: test error\n\n')
        # Test log error with level warning
        environment.log_error("test warning", level='warning')
        mocked_write.assert_called_with('\nhttp: warning: test warning\n\n')



# Generated at 2022-06-23 19:00:52.842381
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    assert env.__str__()


# Generated at 2022-06-23 19:01:02.564852
# Unit test for constructor of class Environment
def test_Environment():
    import io

    class TestEnvironment(Environment):
        pass

    # stdin
    stdin: TestEnvironment = TestEnvironment(stdin=io.StringIO())
    assert stdin.stdin.read() == ''
    assert stdin.stdin_isatty == False
    assert stdin.stdin_encoding == 'utf-8'

    # stdout
    stdout: TestEnvironment = TestEnvironment(stdout=io.StringIO())
    assert stdout.stdout.read() == ''
    assert stdout.stdout_isatty == False
    assert stdout.stdout_encoding == 'utf-8'
    assert stdout.stderr.read() == ''

    # config
    config: TestEnvironment = TestEnvironment(config_dir='./')
    assert config.config_dir == './'

   

# Generated at 2022-06-23 19:01:04.565290
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error('hello, world!')
    env.log_error('hello, world!', level='warning')

# Generated at 2022-06-23 19:01:10.507797
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()

    if env.stdin_isatty:
        encoded_string = env.stdin.encoding
        print(encoded_string)
    else:
        print("stdin is not tty")

    if env.stdout_isatty:
        encoded_string = env.stdout.encoding
        print(encoded_string)
    else:
        print("stdout is not tty")

test_Environment()

# Generated at 2022-06-23 19:01:21.638069
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()

# Generated at 2022-06-23 19:01:33.496493
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().is_windows == is_windows
    assert Environment().config_dir == DEFAULT_CONFIG_DIR
    assert Environment(program_name='http', colors=256, stdin=sys.stdin, stdin_isatty=sys.stdin.isatty(),
                       stdin_encoding=None, stdout=sys.stdout, stdout_isatty=sys.stdout.isatty(),
                       stderr=sys.stderr, colors=256, devnull=None, stdout_encoding=None, stderr_isatty=sys.stderr.isatty()).is_windows == is_windows

# Generated at 2022-06-23 19:01:34.891758
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert isinstance(env, Environment)



# Generated at 2022-06-23 19:01:41.604377
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().config.directory == DEFAULT_CONFIG_DIR
    assert Environment().stdout == sys.stdout
    assert Environment().stderr == sys.stderr
    assert Environment().stdin == sys.stdin
    assert Environment().stdout_isatty == sys.stdout.isatty()
    assert Environment().stdin_isatty == sys.stdin.isatty()
    assert Environment().stderr_isatty == sys.stderr.isatty()
    assert Environment().stdout_encoding == sys.stdout.encoding
    assert Environment().stdin_encoding == sys.stdin.encoding
    assert Environment().stderr_encoding == sys.stderr.encoding

# Generated at 2022-06-23 19:01:51.626651
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment(asd=True, num_colors=256, devnull=None, stdin=None, stdin_encoding='utf8', stdout='<buffer>', stdout_encoding='utf8', stderr='<buffer>', stderr_isatty=True, program_name='http')
    assert env.__repr__() == '<Environment {num_colors: 256, program_name: http, stdin_encoding: utf8, stdin: None, stdout_encoding: utf8, asd: True, stdout: <buffer>, stderr: <buffer>}>'

# Generated at 2022-06-23 19:01:55.130798
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdin_isatty=False)
    assert env.stdin is None
    assert env.stdin_isatty is False

if __name__ == "__main__":
    test_Environment()

# Generated at 2022-06-23 19:01:58.348510
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    if env.stdin_encoding:
        assert env.stdin_encoding in str(env)
    print(env)



# Generated at 2022-06-23 19:02:10.503622
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment(**{'is_windows': False, 'config_dir': None, 'stdin': sys.stdin, 'stdin_isatty': True, 'stdin_encoding': None, 'stdout': sys.stdout, 'stdout_isatty': True, 'stdout_encoding': None, 'stderr': sys.stderr, 'stderr_isatty': True, 'colors': 256, 'program_name': 'http'})

# Generated at 2022-06-23 19:02:13.699415
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    tmp_file = open('temp_file.txt', 'w')
    env.stderr = tmp_file
    env.log_error('Unable to proceed')

test_Environment_log_error()

# Generated at 2022-06-23 19:02:16.558845
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    class MyDevnull:
        def write(self, msg):
            print(msg)
    devnull = MyDevnull()
    env = Environment(devnull)
    env.log_error('test log_error')

# Generated at 2022-06-23 19:02:27.938187
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    import sys
    env = Environment(
        is_windows=False,
        stdin=sys.stdin,
        stdout=sys.stdout,
        stderr=sys.stderr,
        colors=256,
        program_name='http'
    )

# Generated at 2022-06-23 19:02:39.509335
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    import sys
    import os
    import tempfile
    def test_config_dir():
        temp_dir = tempfile.mkdtemp()
        env = Environment(config_dir = temp_dir)
        check(env)
        temp_dir_from_home, _ = os.path.split(temp_dir)
        env.config_dir = temp_dir_from_home
        check(env)
        os.rmdir(temp_dir_from_home)

    def test_stdin():
        env = Environment(stdin = sys.stdin)
        check(env)
        f = open(os.devnull, 'w')
        env.stdin = f
        check(env)
        f.close()

    def test_stdout():
        env = Environment(stdout = sys.stdout)
       

# Generated at 2022-06-23 19:02:46.784765
# Unit test for constructor of class Environment
def test_Environment():
    sys.argv = ['http']
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == env.stdin.isatty()
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == env.stdout.isatty()
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == env.stderr.isatty()
    assert env.config.env == env

# Generated at 2022-06-23 19:02:52.743542
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment(
        config_dir='../../data/config',
        stdout = 'out',
        stdout_encoding = 'out_encode'
    )
    assert e.config_dir == Path('../../data/config')
    assert e.stdout == 'out'
    assert e.stdout_encoding == 'out_encode'

# Generated at 2022-06-23 19:03:01.205162
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import StringIO
    from httpie.utils import devnull

    stdout = StringIO()
    stderr = StringIO()
    # The environment used by unit tests
    env = Environment(stdout=stdout, stderr=stderr, devnull=devnull)
    env._orig_stderr = stderr
    env.log_error('Testing httpie.Environment.log_error')
    assert stdout.getvalue() == ""
    assert stderr.getvalue() == "http: error: Testing httpie.Environment.log_error\n\n"

# Generated at 2022-06-23 19:03:04.002329
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment(stdin_isatty=True, stdout_isatty=True)
    assert '<Environment {}>'.format(str(env)) == repr(env)

# Generated at 2022-06-23 19:03:05.916019
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name='http')
    assert env.program_name == 'http'
    assert env.stderr is sys.stderr
    assert env.stdout is sys.stdout
    assert env.stdin is sys.stdin

# Generated at 2022-06-23 19:03:11.530368
# Unit test for constructor of class Environment
def test_Environment():
    # success
    env = Environment()
    assert env.stdout_isatty
    print(env)

    # failed
    env = Environment(stdin_encoding = None)
    env.stdin = None
    assert env.stdin_encoding == 'utf8'
    print(env)

    # failed
    env = Environment(stdin_encoding = 'utf8')
    assert env.stdin_encoding == 'utf8'
    print(env)

# Generated at 2022-06-23 19:03:15.618313
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(colors=256)
    str_env = str(env)
    assert "{" in str_env and "}" in str_env and "colors: 256" in str_env

test_Environment___str__()

env = Environment()

# Generated at 2022-06-23 19:03:24.702467
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    assert str(env) == "{'colors': 256, 'is_windows': False, 'program_name': 'http', 'stdout_isatty': True, 'stdout_encoding': 'utf8', 'stderr_encoding': None, 'stdout': <colorama.ansitowin32.AnsiToWin32 object at 0x000001E2D7F95240>, 'stdin_isatty': True, 'stdin': sys.stdin, 'stdin_encoding': 'utf8', 'stderr_isatty': True, 'config_dir': Path('~/.httpie'), 'stderr': sys.stderr, 'config': <httpie.config.Config object at 0x000001E2D7F08780>}"

# Generated at 2022-06-23 19:03:31.748762
# Unit test for constructor of class Environment
def test_Environment():
	env = Environment(stdin = sys.stdin,stdin_isatty = True,stdin_encoding = "utf8")
	assert env.stdin is not None, "Test Environment constructor: stdin is None"
	assert env.stdin_isatty is True, "Test Environment constructor: stdin_isatty is not True"
	assert env.stdin_encoding == "utf8", "Test Environment constructor: stdin_encoding is not 'utf8'"
	assert env.stdout == sys.stdout, "Test Environment constructor: stdout is not sys.stdout"
	assert env.stdout_isatty is sys.stdout.isatty(), "Test Environment constructor: stdout_isatty is not correct"

# Generated at 2022-06-23 19:03:39.803054
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        devnull = '_devnull',
        is_windows=False,
        config_dir='_config_dir',
        stdin='_stdin',
        stdin_isatty=True,
        stdin_encoding='_stdin_encoding',
        stdout='_stdout',
        stdout_isatty=True,
        stdout_encoding='_stdout_encoding',
        stderr='_stderr',
        stderr_isatty=True,
        colors=256,
        program_name='_program_name'
    )
    assert env.devnull == '_devnull'
    assert env.is_windows == False
    assert env.config_dir == '_config_dir'
    assert env.stdin == '_stdin'


# Generated at 2022-06-23 19:03:47.963032
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    stdout = io.StringIO()      # create "file" in memory
    _env = Environment(stderr=stdout)
    _env.program_name = 'any'
    _env.log_error('Any', level='error')
    assert stdout.getvalue() == '\nany: error: Any\n\n'
    _env.log_error('Any', level='warning')
    assert stdout.getvalue() == '\nany: error: Any\n\n\nany: warning: Any\n\n'

test_Environment_log_error()

# Generated at 2022-06-23 19:03:49.763846
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    print("test begin")
    a = Environment()
    print(a.__repr__())
    print("test end")


# Generated at 2022-06-23 19:03:57.823208
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    e = Environment()
    e.config_dir = '2'
    assert e.config_dir == 2
    e.stdin = 2
    e.stdin_isatty = 2
    e.stdin_encoding = 2
    e.stdout = 2
    e.stdout_isatty = 2
    e.stdout_encoding = 2
    e.stderr = 2
    e.stderr_isatty = 2
    e.program_name = '2'
    e.is_windows = 2
    e.colors = 2
    _ = str(e)
    _ = repr(e)

# Generated at 2022-06-23 19:04:02.294463
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    assert str(env) == str(dict(env.__dict__))
    env = Environment(devnull=None, colors=256, is_windows=False)
    assert str(env) == str(dict(env.__dict__))

# Generated at 2022-06-23 19:04:11.280354
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()

# Generated at 2022-06-23 19:04:16.173374
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(config_dir = DEFAULT_CONFIG_DIR/'hrc')
    assert DEFAULT_CONFIG_DIR in str(env)
    assert str(env).startswith('<Environment')
    assert str(env).endswith('>')


# Generated at 2022-06-23 19:04:28.604227
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(
        stdin=None,
        stdin_isatty=False,
        stdin_encoding=None,
        stdout=None,
        stdout_isatty=False,
        stdout_encoding=None,
        stderr=None,
        stderr_isatty=False,
        is_windows=False,
        config_dir=Path('config_dir'),
        colors=256,
        program_name='program_name'
    )


# Generated at 2022-06-23 19:04:33.133531
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(
        is_windows=1,
        config_dir='httpie',
        stdin=sys.stdin,
        stdin_isatty=1,
        stdin_encoding='utf8',
        stdout=sys.stdout,
        stdout_isatty=1,
        stdout_encoding='utf8',
        stderr=sys.stderr,
        stderr_isatty=1,
        colors=256,
        program_name='http'
    )

# Generated at 2022-06-23 19:04:40.124648
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    e = Environment()
    assert "type(self).__dict__" in str(e)
    assert "config" in str(e)
    assert "# Do not remove this line. Rather, put your custom configuration" in str(e)
    assert "colors = 256" in str(e)
    e.stdin = None
    assert "stdin = None" in str(e)

# Generated at 2022-06-23 19:04:49.792910
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    assert isinstance(env, Environment)
    assert isinstance(env.config_dir, Path)

    # _config: Optional[Config] = None
    # _orig_stderr: IO
    # _devnull: Optional[IO] = None
    assert isinstance(env._config, Config)
    assert isinstance(env._orig_stderr, IO)
    assert isinstance(env._devnull, IO)

    # is_windows: bool = is_windows
    # config_dir: Path = DEFAULT_CONFIG_DIR
    # stdin: Optional[IO] = sys.stdin  # `None` when closed fd (#791)
    # stdin_isatty: bool = stdin.isatty() if stdin else False
    # stdin_encoding: Optional[str]

# Generated at 2022-06-23 19:04:58.940601
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment(colors=256, program_name="http")
    env.config_dir = "~/.httpie"
    env.stdin = sys.stdin
    env.stdin_isatty = env.stdin.isatty()
    env.stdin_encoding = None
    env.stdout = sys.stdout
    env.stdout_isatty = env.stdout.isatty()
    env.stdout_encoding = None
    env.stderr = sys.stderr
    env.stderr_isatty = env.stderr.isatty()
    env.stderr_encoding = None
    env.is_windows = is_windows
    env.program_name = 'http'
    env.colors = 256
    assert env.__repr

# Generated at 2022-06-23 19:05:10.070463
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    environment = Environment()

# Generated at 2022-06-23 19:05:16.352518
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    print(env)
    print(env.stdout_isatty)
    print(env.stdout_encoding)
    print(env.devnull)
    print(env.program_name)
    print(env.config_dir)

env = Environment()

# Generated at 2022-06-23 19:05:25.044409
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    def test(**kwargs):
        env = Environment(**kwargs)
        return str(env)
    assert test(no_config=True, colors=256) == '''\
{'config': <Config [not initialized, no config file]>,
 'colors': 256,
 'is_windows': False,
 'program_name': 'http',
 'stdin': <_io.TextIOWrapper name=7 encoding='UTF-8'>,
 'stdin_encoding': 'utf8'}'''

# Generated at 2022-06-23 19:05:32.717753
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()

# Generated at 2022-06-23 19:05:40.984711
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import StringIO
    buf = StringIO()
    buf.write('')
    environ = Environment(stderr=buf)
    environ.log_error('some error message','error')
    assert buf.getvalue() == '\nhttp: error: some error message\n\n'
    buf = StringIO()
    buf.write('')
    environ = Environment(stderr=buf)
    environ.log_error('some warning message','warning')
    assert buf.getvalue() == '\nhttp: warning: some warning message\n\n'


# Generated at 2022-06-23 19:05:50.431349
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows is True
    assert env.config_dir.name == 'httpie'
    assert env.stdin.name == '<stdin>'
    assert env.stdin_isatty is True
    assert env.stdin_encoding == 'cp65001'
    assert env.stdout.name == '<stdout>'
    assert env.stdout_isatty is True
    assert env.stdout_encoding == 'cp65001'
    assert env.stderr.name == '<stderr>'
    assert env.stderr_isatty is True
    assert env.colors == 256
    assert env.program_name == 'http'

# Generated at 2022-06-23 19:05:59.544989
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment(stdout_isatty=True)
    assert env == '<Environment {' \
                   '"config": <Config ...>, ' \
                   '"stdout_isatty": True, ' \
                   '"stdin_encoding": "utf8", ' \
                   '"stdout_encoding": "utf8", ' \
                   '"colors": 256, ' \
                   '"is_windows": False, ' \
                   '"stdin": <_io.TextIOWrapper ...>, ' \
                   '"stderr": <_io.TextIOWrapper ...>, ' \
                   '"stdout": <_io.TextIOWrapper ...>, ' \
                   '"stderr_isatty": False, ' \
                   '"program_name": "http", ' \
                  

# Generated at 2022-06-23 19:06:10.777300
# Unit test for constructor of class Environment
def test_Environment():
    devnull = open(os.devnull, 'w+')

# Generated at 2022-06-23 19:06:17.079255
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error('this is an error', level='error')
    assert env._orig_stderr.getvalue() == '\nhttp: error: this is an error\n\n'
    env._orig_stderr.truncate(0)
    env.log_error('this is a warning', level='warning')
    assert env._orig_stderr.getvalue() == '\nhttp: warning: this is a warning\n\n'

# Generated at 2022-06-23 19:06:26.006658
# Unit test for method __str__ of class Environment
def test_Environment___str__():

    env = Environment()


# Generated at 2022-06-23 19:06:28.411349
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    Environment().log_error("Test Error")
    Environment().log_error("Test Warning", level='warning')
    Environment().log_error("Test Error", level='test')

# Generated at 2022-06-23 19:06:35.035346
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding is None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding is None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()

    # test keyword arguments to overwrite default class attributes.
    env = Environment(config_dir=Path('.'))
    assert env.config_dir == Path('.')

# Generated at 2022-06-23 19:06:45.783368
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    environment = Environment(is_windows=False,
                              config_dir=Path('/foo/bar'),
                              stdin='/foo/stdin',
                              stdin_isatty=True,
                              stdin_encoding='utf8',
                              stdout='/foo/stdout',
                              stdout_isatty=True,
                              stdout_encoding='utf8',
                              stderr='/foo/stderr',
                              stderr_isatty=True,
                              colors=256,
                              program_name='http',
                              _orig_stderr='/foo/orig_stderr',
                              _devnull='/foo/devnull',
                              _config=Config(directory=Path('/foo/bar')))

# Generated at 2022-06-23 19:06:49.186352
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    """
    >>> e = Environment()
    >>> e.log_error("My Error")
    http: error: My Error
    >>> e.log_error("My Error", level='warning')
    http: warning: My Error
    """
    pass

# Generated at 2022-06-23 19:06:55.797235
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    output = OutputCapture()
    try:
        e = Environment(stderr=StringIO(), program_name='http')
        e.log_error('Invalid URL')
        assert e.stderr.getvalue() == '\nhttp: error: Invalid URL\n\n'
    finally:
        output.restore()



# Generated at 2022-06-23 19:07:03.263669
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    # Bugfix: https://youtrack.jetbrains.com/issue/PY-42848
    from httpie.context import Environment
    env = Environment()
    assert repr(env) is not None
    assert eval(repr(env)) == env
    from httpie.context import Environment
    env.stdout = sys.stdout
    env.stderr = sys.stderr
    env.stdin = sys.stdin
    assert eval(repr(env)) == env
    env.stdout_encoding = "utf-8"
    env.stderr_encoding = "utf-8"
    env.stdin_encoding = "utf-8"
    assert eval(repr(env)) == env

# Generated at 2022-06-23 19:07:11.379320
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    import unittest

    class _TestEnvironment(Environment):
        _orig_stderr = stderr = io.StringIO()

    env = _TestEnvironment()
    env.log_error('test message')
    env.log_error('test warning', level='warning')

    stderr = _TestEnvironment.stderr
    assert stderr.getvalue() == '\nhttp: error: test message\n\n' \
                                '\nhttp: warning: test warning\n\n'
    stderr.close()

    try:
        env.log_error('test error', level='traceback')
    except AssertionError:
        pass
    else:
        assert False, "Should not reach this line"



# Generated at 2022-06-23 19:07:22.589432
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(config_dir='./httpie')

# Generated at 2022-06-23 19:07:31.126602
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    environment = Environment()


# Generated at 2022-06-23 19:07:35.306086
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdout=StringIO(),stderr=StringIO())

    print(env.stdout_encoding)
    print(env.stdout_isatty)
    assert env.stdout_encoding == None
    assert env.stdout_isatty == False

# Generated at 2022-06-23 19:07:41.481572
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    def _test(env):
        # Without the custom `__repr__` implementation,
        # the result would be "<_io.TextIOWrapper name='<stdout>' mode='w'>"
        # which is less informative.
        assert repr(env.stdout) == "<stdout>"

    _test({'stdout': sys.stdout})
    _test(Environment())

# Generated at 2022-06-23 19:07:43.321085
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error('Test')
    os.write(0, b'env_test')

# Generated at 2022-06-23 19:07:53.291617
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    import pytest
    if sys.version_info.major == 2:
        pytest.skip('skip test_Environment___str__() under python2')
    if not os.path.isdir('/home/test'):
        pytest.skip('skip test_Environment___str__() as not on Travis')
    this = Environment(is_windows=False, config_dir='/home/test')

# Generated at 2022-06-23 19:08:03.359518
# Unit test for method __repr__ of class Environment

# Generated at 2022-06-23 19:08:06.168824
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(foo='bar')
    assert 'colorama.initialize' in str(env) and 'foo' in str(env)

# Generated at 2022-06-23 19:08:16.939200
# Unit test for constructor of class Environment
def test_Environment():
    import io
    import os
    def create_test_stream(mode):
        stream = io.StringIO()
        stream.name = 'test'
        stream.mode = mode
        stream.encoding = 'utf-8'
        return stream
    def create_test_streams():
        return create_test_stream('r'), create_test_stream('w')
        
    # Default constructor of Environment
    stdin, stdout = create_test_streams()
    devnull = os.devnull
    e = Environment(devnull)
    assert e.is_windows == is_windows
    assert e.config_dir == DEFAULT_CONFIG_DIR
    assert e.stdin == stdin
    assert e.stdin_isatty == stdin.isatty()

# Generated at 2022-06-23 19:08:26.409465
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(stdin = sys.stdin)
    colorama = __import__('colorama')
    env.stdout = colorama.initialise.wrap_stream(
        env.stdout, convert=None, strip=None,
        autoreset=True, wrap=True
    )
    env.stderr = colorama.initialise.wrap_stream(
        env.stderr, convert=None, strip=None,
        autoreset=True, wrap=True
    )
    del colorama
    str(env)
    assert env.stdin is sys.stdin
    assert env.stdin_isatty is True
    assert env.stdout is sys.stdout
    assert env.stdout_isatty is True
    assert env.stderr is sys.stderr