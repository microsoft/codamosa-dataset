

# Generated at 2022-06-23 18:58:21.825305
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    """
    Check when standard streams are closed.
    """
    e = Environment()
    e.stdin.close()
    e.stdout.close()
    e.stderr.close()
    str(e)

# Generated at 2022-06-23 18:58:29.973579
# Unit test for constructor of class Environment
def test_Environment():
    import json
    import httpie
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == httpie.DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'

# Generated at 2022-06-23 18:58:39.324791
# Unit test for method __str__ of class Environment
def test_Environment___str__():
  env = Environment()

# Generated at 2022-06-23 18:58:46.959031
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    assert repr(Environment()) == '<Environment {"config": "[object]", "config_dir": "~/.config/httpie", "stdin": "", "stdin_encoding": "utf8", "stdin_isatty": true, "stdout": "", "stdout_encoding": "utf8", "stdout_isatty": true, "stderr": "", "stderr_isatty": true, "program_name": "http"}>'


# Generated at 2022-06-23 18:58:52.861490
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows == is_windows
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == sys.stdin.isatty()
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == sys.stdout.isatty()
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == sys.stderr.isatty()
    assert environment.colors == 256

# Generated at 2022-06-23 18:59:01.428482
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env_str = Environment(devnull=None, **environment.__dict__).__str__()
    assert env_str == '{' \
                      '\'stdin_isatty\': True, ' \
                      '\'stderr\': <built-in function stderr>, ' \
                      '\'stdout_isatty\': True, ' \
                      '\'config\': <httpie.config.Config object at 0x11b4ffc88>, ' \
                      '\'stdout_encoding\': \'UTF-8\', ' \
                      '\'stderr_isatty\': True, ' \
                      '\'stdin\': <_io.TextIOWrapper name=0 mode=\'r\' encoding=\'UTF-8\'>, ' \
                      '\'program_name\': \'httpie\', '

# Generated at 2022-06-23 18:59:03.263608
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    assert '<Environment' in repr(env)

# Generated at 2022-06-23 18:59:10.794113
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    stdout = io.StringIO()
    env = Environment(stdout=stdout)
    env.log_error('message')
    assert '\nhttp: error: message\n\n' == stdout.getvalue()
    stdout.truncate(0)
    stdout.seek(0)
    env.log_error('message', level='warning')
    assert '\nhttp: warning: message\n\n' == stdout.getvalue()


# Generated at 2022-06-23 18:59:15.147805
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment(stdin_isatty=False, stdout_isatty=True, stderr_isatty=False)
    print(repr(env))


# Generated at 2022-06-23 18:59:25.303531
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    mock_httpie = Environment(**{'program_name': 'mock_httpie'})


# Generated at 2022-06-23 18:59:35.823773
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    temp_stdin = sys.stdin
    sys.stdin = sys.stdout
    temp_stderr = sys.stderr
    sys.stderr = sys.stdout
    env = Environment()
    sys.stdin = temp_stdin
    sys.stderr = temp_stderr

# Generated at 2022-06-23 18:59:47.032640
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    # Assume the values at the moment of testing are those defined in the class
    # Unless they have been overwritten by the user or by httpie
    if __name__ == "__main__":
        for key, value in Environment.__dict__.items():
            if not key.startswith('__') and key != '_devnull':
                print(f'{key}: {value}')
            if key == '_devnull':
                print(f'{key}: {type(value)}')
        print()
        for key, value in Environment().__dict__.items():
            if not key.startswith('__') and key != '_devnull':
                print(f'{key}: {value}')
            if key == '_devnull':
                print(f'{key}: {type(value)}')

# Unit

# Generated at 2022-06-23 18:59:54.948968
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdout = sys.stdout, stderr = sys.stderr, stdin = sys.stdin, config_dir= '<TEST>')
    assert env.stderr == sys.stderr
    assert env.stdout == sys.stdout
    assert env.stdin == sys.stdin
    assert env.config_dir.__str__() == '<TEST>'
    assert env._orig_stderr == sys.stderr
    assert env._devnull is None
    env.devnull = 1
    assert env.devnull == 1
    assert isinstance(env.config, Config)
    assert isinstance(env.program_name, str)
    assert not env.stdin_isatty
    env.stdin = sys.stderr
    assert env.stdin_

# Generated at 2022-06-23 18:59:57.476724
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env._orig_stderr = sys.stderr
    env.log_error("This is a test")

# Generated at 2022-06-23 19:00:06.452819
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=True, config_dir=DEFAULT_CONFIG_DIR, stdin=sys.stdin,
                      stdin_isatty=sys.stdin.isatty(), stdin_encoding=None,
                      stdout=sys.stdout, stdout_isatty=sys.stdout.isatty(), stdout_encoding=None, stderr=sys.stderr,
                      stderr_isatty=sys.stderr.isatty(), colors=256, program_name='http')

    assert env.is_windows is True
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env

# Generated at 2022-06-23 19:00:13.732846
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    # Case 1: log_error is loggin an error message
    env = Environment()
    msg = "test_message_1"
    env.log_error(msg)
    assert env._orig_stderr.read() == "\nhttp: warning: test_message_1\n\n"

    # Case 2: log_error is loggin a warning message
    env = Environment()
    msg = "test_message_2"
    env.log_error(msg, level="warning")
    assert env._orig_stderr.read() == "\nhttp: warning: test_message_2\n\n"

# Generated at 2022-06-23 19:00:17.280905
# Unit test for constructor of class Environment
def test_Environment():
    import io
    import os
    import re

# Generated at 2022-06-23 19:00:24.248687
# Unit test for method __str__ of class Environment
def test_Environment___str__():
	env = Environment()
	print(env)
	print(repr_dict(env))
	print(env.__str__())
	print(env.__repr__())
	print(repr(env))
	defaults = dict(type(env).__dict__)
	actual = dict(defaults)
	actual.update(env.__dict__)
	print(defaults)
	print(actual)
	print(type(env).__dict__)
	print(env.__dict__)
	print(env.__dict__.items())
	print(type(env.__dict__.items()))
	print(env.is_windows)
	print(env.config_dir)
	print(env.stdin)
	print(env.stdin_isatty)

# Generated at 2022-06-23 19:00:34.777159
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    import os
    import pty
    stdin, stdout = pty.openpty()
    stdin_old = os.dup(0)
    os.dup2(stdin, 0)
    env = Environment()

# Generated at 2022-06-23 19:00:46.349600
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        devnull=1,
        is_windows=True,
        program_name=1,
        config_dir=1,
        stdin=1,
        stdin_isatty=True,
        stdin_encoding=1,
        stdout=1,
        stdout_isatty=True,
        stdout_encoding=1,
        stderr=1,
        stderr_isatty=True,
        colors=1,
    )
    assert env.devnull == 1
    assert env.is_windows == True
    assert env.program_name == 1
    assert env.config_dir == 1
    assert env.stdin == 1
    assert env.stdin_isatty == True
    assert env.stdin_encoding == 1

# Generated at 2022-06-23 19:00:51.616563
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io

    class MockStdErr:
        def __init__(self):
            self.written = ""

        def write(self, s):
            self.written += s

        def __str__(self):
            return self.written

    err = MockStdErr()
    env = Environment(stderr=err, program_name="Httpie")
    env.log_error("random error", level="error")
    assert str(err) == "\nHttpie: error: random error\n\n"



# Generated at 2022-06-23 19:01:02.040225
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    from io import StringIO
    test_env = Environment(stdout=StringIO(), stdin=StringIO())
    # test_env.config.__dict__.update(dict(http__ignore_stdin=True,
    #                                      http__pretty=True,
    #                                      http__style=None,
    #                                      http__print_bodies=True,
    #                                      http__verify=True,
    #                                      http__follow_redirects=True,
    #                                      http__timeout=30,
    #                                      http__max_redirects=10,
    #                                      http__auth_type=None,
    #                                      http__auth_username=None,
    #                                      http__auth_password=None,
    #                                      http__download_output=None,
    #                                      http

# Generated at 2022-06-23 19:01:10.778406
# Unit test for constructor of class Environment
def test_Environment():
    #call the constructor of class Environment
    from httpie.config import Config
    from httpie.context import Environment
    from pathlib import Path
    from typing import IO
    e1 = Environment()
    assert e1.config_dir == Path('/home/user/.config/httpie')
    assert e1.stdin == sys.stdin
    assert e1.stdin_isatty is True
    assert e1.stdin_encoding is None
    assert e1.stdout == sys.stdout
    assert e1.stdout_isatty is True
    assert e1.stdout_encoding is None
    assert e1.stderr == sys.stderr
    assert e1.stderr_isatty is True
    assert e1.stderr_encoding is None
    assert e1.col

# Generated at 2022-06-23 19:01:20.460010
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows == is_windows
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == True
    assert environment.stdin_encoding == sys.stdin.encoding
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == True
    assert environment.stdout_encoding == sys.stdout.encoding
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == True
    assert environment.program_name == "http"

# Generated at 2022-06-23 19:01:22.801422
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    assert str(env).startswith("{'is_windows': False")
    assert str(env).endswith("}")

# Generated at 2022-06-23 19:01:24.224646
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    assert not hasattr(Environment, '__str__') 


# Generated at 2022-06-23 19:01:36.393159
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    msg = str(env)
    print(msg)

# Generated at 2022-06-23 19:01:38.347335
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=0, colors=256)
    assert env.devnull == 0
    assert env.colors == 256



# Generated at 2022-06-23 19:01:50.008429
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(is_windows=True, devnull=0, stdout=1)
    # test that attributes have been set correctly
    assert env.is_windows, "Value of is_windows attribute has not been set correctly"
    assert env.devnull, "Value of devnull attribute has not been set correctly"
    assert env.stdout, "Value of stdout attribute has not been set correctly"
    # test that default attributes have not been overwritten
    assert env.config_dir == DEFAULT_CONFIG_DIR, "Default value of config_dir attribute has been set incorrectly"
    assert env.stdin is sys.stdin, "Default value of stdin attribute has been set incorrectly"
    assert env.stdin_isatty, "Default value of stdin_isatty attribute has been set incorrectly"
    assert env.stdout_isatty

# Generated at 2022-06-23 19:01:54.904290
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin_isatty
    assert env.stdout_isatty
    assert env.stderr_isatty
    assert env.stdin_encoding
    assert env.stdout_encoding
    assert 'httpie' in str(env)

# Generated at 2022-06-23 19:02:03.328457
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    # Given
    env = Environment(devnull=None, colors=256, is_windows=False, program_name='http', stderr_isatty=True, stdin_isatty=True, stdout_isatty=True, config_dir='/home/andreas/.config/httpie')

    # When
    result = str(env)

    # Then

# Generated at 2022-06-23 19:02:14.718856
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    """
    The function of this unit test is to test the function __str__ of class Environment.
    """
    default = {'is_windows': False, 'config_dir': Path(DEFAULT_CONFIG_DIR),
               'stdin': sys.stdin, 'stdin_isatty': sys.stdin.isatty(),
               'stdout': sys.stdout, 'stdout_isatty': sys.stdout.isatty(),
               'stderr': sys.stderr, 'stderr_isatty': sys.stderr.isatty(),
               'colors': 256, 'program_name': 'http'}
    file = open(os.devnull, 'w+')
    config = Config(directory=DEFAULT_CONFIG_DIR)
    config_dict = config.__dict__

# Generated at 2022-06-23 19:02:23.068106
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    import io

    actual_stdin = io.StringIO()
    actual_stdin.__class__.encoding = None
    actual_stdin_encoding = None

    actual_stdout = io.StringIO()
    actual_stdout.__class__.encoding = None
    actual_stdout_encoding = None


# Generated at 2022-06-23 19:02:28.660561
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()

# Generated at 2022-06-23 19:02:40.226227
# Unit test for method __str__ of class Environment

# Generated at 2022-06-23 19:02:48.488817
# Unit test for method __str__ of class Environment

# Generated at 2022-06-23 19:02:53.193613
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(
        is_windows=True,
        config_dir='/a/b/c',
        program_name='http',
        stdin=sys.stdin)
    assert repr_dict(eval(str(env))) == repr_dict(env.__dict__)


# Generated at 2022-06-23 19:02:54.648390
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    assert str(Environment()) == '{}'


# Generated at 2022-06-23 19:02:58.677910
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert isinstance(env.config, Config)
    assert not env.config.is_new()
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr

# Generated at 2022-06-23 19:03:05.031325
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment(is_windows=False,program_name='test',devnull=sys.stdout)
    result = str(env)
    assert(result == "{'is_windows': False, 'program_name': 'test', 'devnull': <_io.TextIOWrapper name='<stdout>' mode='w' encoding='cp936'>, 'config': <Config: {}>}")



# Generated at 2022-06-23 19:03:15.216115
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment(is_windows=True)

# Generated at 2022-06-23 19:03:17.660529
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(colors=16)
    assert env.colors == 16
    with pytest.raises(AssertionError):
        env = Environment(invalid_argument=True)

# Generated at 2022-06-23 19:03:27.163899
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment()
    e.stdout_encoding = None
    assert e.stdout_encoding == 'utf8'
    assert e.stdin_encoding == 'utf8'
    assert e.is_windows == is_windows
    assert e.stdin == sys.stdin
    assert e.stdout == sys.stdout
    assert e.stderr == sys.stderr
    assert e.stdout_isatty == sys.stdout.isatty()
    assert e.stdin_isatty == sys.stdin.isatty()
    assert e.stderr_isatty == sys.stderr.isatty()
    assert e._orig_stderr == sys.stderr
    assert e._devnull is None
    assert e.program_name == 'http'


# Generated at 2022-06-23 19:03:38.910240
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    try:
        import httpie.plugins  # noqa
    except ImportError:
        plugins = []
    else:
        from httpie.plugins import plugin_manager

        plugins = plugin_manager.plugin_names()
    import httpie.core
    import httpie.downloads
    import httpie.__about__
    import httpie.config
    if Environment.is_windows:
        import colorama
    env = Environment(devnull=1, config_dir=2, stdin=3, stdin_isatty=4, stdin_encoding=5, stdout=6, stdout_isatty=7, stdout_encoding=8, stderr=9, stderr_isatty=10, colors=11, program_name=12)

# Generated at 2022-06-23 19:03:46.654556
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    print(env)
    env.stdout = 10
    env.stdout_isatty = False
    env.stdout_encoding = 'utf-8'
    env.stderr = 10
    env.stderr_isatty = False
    env.stderr_encoding = 'utf-8'
    env.colors = 10
    env._devnull = 10
    env._config = 10
    env.program_name = 'http'
    print(env)


# Generated at 2022-06-23 19:03:51.219324
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env_log = Environment(stderr = StringIO())
    actual_msg = '\nhttp: error: some test message\n\n'
    env.log_error('some test message')
    env_log.log_error('some test message')
    assert actual_msg == env_log.stderr.getvalue()

# Generated at 2022-06-23 19:03:54.031464
# Unit test for constructor of class Environment
def test_Environment():
  env = Environment()
  assert env.stdout_isatty is True
  assert 'Environment' in str(env)
  assert 'program_name' in str(env)
  assert 'Environment' in repr(env)

# Generated at 2022-06-23 19:04:06.195802
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        is_windows=True,
        stdin=None,
        stdin_isatty=False,
        stdin_encoding='utf8',
        stdout=None,
        stdout_isatty=False,
        stdout_encoding='utf8',
        stderr=None,
        stderr_isatty=False,
        devnull=None,
        program_name='http',
        _config=None,
        _orig_stderr=None,
        config_dir=None
    )

    assert env.is_windows == True
    assert env.stdin == None
    assert env.stdin_isatty == False
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == None
    assert env.stdout_is

# Generated at 2022-06-23 19:04:13.807755
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment(
        is_windows=True,
        config_dir=DEFAULT_CONFIG_DIR,
        stdin=sys.stdin if sys.stdin.isatty() else None,
        stdin_isatty=True,
        stdin_encoding='utf8',
        stdout=sys.stdout,
        stdout_isatty=True,
        stdout_encoding='utf8',
        stderr=sys.stderr,
        stderr_isatty=True,
        colors=256,
        program_name='http'
    )
    assert env.is_windows == True
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == True
    assert env

# Generated at 2022-06-23 19:04:16.943333
# Unit test for constructor of class Environment
def test_Environment():
    # Test non-default constructor attributes
    env = Environment(colors=16)
    assert env.colors == 16
    # Test default constructor attributes
    env = Environment()
    assert env.config_dir == DEFAULT_CONFIG_DIR

# Generated at 2022-06-23 19:04:29.098956
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from httpie.context import Environment
    import io
    import _io
    stdin_isatty = True
    stdout_isatty = True
    stderr_isatty = True
    stdin = io.TextIOWrapper(_io.StringIO('test'), encoding='utf-8')
    stdout = io.TextIOWrapper(_io.StringIO('test'), encoding='utf-8')
    stderr = io.TextIOWrapper(_io.StringIO('test'), encoding='utf-8')
    stdin_encoding = 'utf-8'
    stdout_encoding = 'utf-8'

# Generated at 2022-06-23 19:04:37.245870
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    import sys
    import os
    import pathlib
    env = Environment()
    buffer = io.StringIO()
    env._orig_stderr = buffer
    env.program_name = 'http'
    env.log_error('No such config file',level='error')
    assert buffer.getvalue() == '\nhttp: error: No such config file\n\n'
    buffer = io.StringIO()
    env._orig_stderr = buffer
    env.program_name = 'http'
    env.log_error('No such config file',level='warning')
    assert buffer.getvalue() == '\nhttp: warning: No such config file\n\n'


# Generated at 2022-06-23 19:04:47.373919
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    import sys
    import httpie.config
    e = Environment(stdin = sys.stdin,
                    stdin_isatty = sys.stdin.isatty(),
                    stdin_encoding = getattr(sys.stdin, 'encoding', None) or 'utf8',
                    stdout = sys.stdout,
                    stdout_isatty = sys.stdout.isatty(),
                    stdout_encoding = getattr(sys.stdout, 'encoding', None) or 'utf8',
                    stderr = sys.stderr,
                    stderr_isatty = sys.stderr.isatty(),
                    program_name = 'http',
                    config_dir = httpie.config.DEFAULT_CONFIG_DIR,
                    colors = 256)

# Generated at 2022-06-23 19:04:53.105211
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    env.stdin = None
    env.config_dir = Path.cwd()
    env.stdout_encoding = 'utf8'
    env.stdout_isatty = True
    env.stderr_isatty = True
    env.stderr_encoding = 'utf8'
    env.colors = 256
    env.program_name = 'httpie'

    # env.config = None
    # print(env.__repr__())
    # assert 0



# Generated at 2022-06-23 19:04:57.187626
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin_isatty=True, stdout_isatty=False, stderr_isatty=True, devnull=None)
    assert env.stdin_isatty == True
    assert env.stdout_isatty == False
    assert env.stderr_isatty == True
    assert env.devnull is None

# Generated at 2022-06-23 19:04:59.887397
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    repr(env)
    str(env)


# Generated at 2022-06-23 19:05:10.071372
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    from contextlib import redirect_stderr
    from httpie.utils import get_response
    from httpie.client import parse_response
    from httpie.compat import is_windows
    Environment.log_error(msg='test')
    f = io.StringIO()
    with redirect_stderr(f):
        Environment.log_error(msg='test')
    res = f.getvalue()
    if is_windows:
        res = res.replace('[2K', '')
    res = res.strip().splitlines()
    assert len(res) == 3
    assert res[0] == ''
    assert res[1] == 'http: error: test'
    assert res[2] == ''


environ = Environment()

# Generated at 2022-06-23 19:05:21.661357
# Unit test for method __repr__ of class Environment

# Generated at 2022-06-23 19:05:24.695355
# Unit test for constructor of class Environment
def test_Environment():
    import sys
    import os
    en = Environment(stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr, is_windows=os.name == 'nt', colors=256)
    print(en)

# Generated at 2022-06-23 19:05:35.870066
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from httpie.core import Environment
    env = Environment()
    res = str(env)

# Generated at 2022-06-23 19:05:38.557805
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdout_encoding='ascii')
    assert env.stdout_encoding == 'ascii'


# Generated at 2022-06-23 19:05:47.111062
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()

# Generated at 2022-06-23 19:05:57.637321
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    # Test case:
    # - Create object Environment
    # - Print object Environment
    env = Environment(devnull=False)

# Generated at 2022-06-23 19:06:03.932562
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    with open(os.devnull, 'r') as stream:
        env = Environment(devnull=stream)

# Generated at 2022-06-23 19:06:13.048101
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    class Test(Environment):
        pass

    test = Test(is_windows=True, colors=256,
                stdin=None, stdout=None, stderr=None,
                stdin_isatty=True, stdout_isatty=True,
                stderr_isatty=True)
    assert str(test) == "{'is_windows': True, 'colors': 256, 'stdin': None, 'stdin_isatty': True, 'stdout': None, 'stdout_isatty': True, 'stderr': None, 'stderr_isatty': True, 'config': <Config {}>}"

# Generated at 2022-06-23 19:06:19.100919
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    stdout = io.StringIO()
    stream = io.StringIO()
    env = Environment(stderr=stream, stdout=stdout)
    env.log_error('This is a message')
    assert stream.getvalue() == '\nhttp: error: This is a message\n\n'
    assert stdout.getvalue() == ''

# Generated at 2022-06-23 19:06:27.049878
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.stdin
    assert env.stdout
    assert env.stderr
    env1 = Environment(stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr)
    assert env1.stdin == sys.stdin
    assert env1.stdout == sys.stdout
    assert env1.stderr == sys.stderr
    assert env1.stdin_isatty
    assert env1.stdout_isatty
    assert env1.stderr_isatty
    assert env1.is_windows

# Generated at 2022-06-23 19:06:34.123345
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    environments = [
        Environment(),
        Environment(
            stdin = sys.stdin,
            stdout = sys.stdout,
            stderr = sys.stderr,
            is_windows = True,
            config_dir = DEFAULT_CONFIG_DIR,
            stdin_isatty = True,
            stdin_encoding = None,
            stdout_isatty = True,
            stdout_encoding = None,
            stderr_isatty = True,
            colors = 256,
            program_name = 'http'
        )
    ]

# Generated at 2022-06-23 19:06:44.021301
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    class MockStream:
        def __init__(self):
            self.acc = []
        
        def write(self, str):
            self.acc.append(str)

        def clear(self):
            self.acc = []
    
    env = Environment(stderr=MockStream())

    env.log_error('msg1')
    assert env.stderr.acc[0] == '\nhttp: error: msg1\n\n'

    env.stderr.clear()
    env.log_error('msg2', level='warning')
    assert env.stderr.acc[0] == '\nhttp: warning: msg2\n\n'

# Generated at 2022-06-23 19:06:51.314676
# Unit test for method __repr__ of class Environment

# Generated at 2022-06-23 19:06:59.591818
# Unit test for constructor of class Environment
def test_Environment():
    stdin_mock = StringIO()
    stdout_mock = StringIO()
    stderr_mock = StringIO()
    env = Environment(
        stdin=stdin_mock,
        stdout=stdout_mock,
        stderr=stderr_mock,
        program_name='https'
    )
    assert env.program_name == 'https'
    assert env.stdin == stdin_mock
    assert env.stdout == stdout_mock
    assert env.stderr == stderr_mock

# Generated at 2022-06-23 19:07:10.780929
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    environment = Environment()
    environment.config_dir = Path('./')
    environment.stdin = ''
    environment.stdin_isatty = True
    environment.stdin_encoding = 'utf8'
    environment.stdout = ''
    environment.stdout_isatty = True
    environment.stdout_encoding = 'utf8'
    environment.stderr = ''
    environment.stderr_isatty = True

# Generated at 2022-06-23 19:07:13.155033
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error("hello")
    assert True

# Generated at 2022-06-23 19:07:23.379853
# Unit test for method __str__ of class Environment

# Generated at 2022-06-23 19:07:28.225321
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    assert repr(Environment()) == "<Environment {'is_windows': False, 'config_dir': PosixPath('/home/httpie/.config/httpie'), 'stdin': <stdin>, 'stdin_isatty': False, 'stdin_encoding': None, 'stdout': <stdout>, 'stdout_isatty': True, 'stdout_encoding': None, 'stderr': <stderr>, 'stderr_isatty': True, 'colors': 256, 'program_name': 'http', 'config': <httpie.config.Config directory='/home/httpie/.config/httpie'>}>"

# Generated at 2022-06-23 19:07:35.790925
# Unit test for method __str__ of class Environment
def test_Environment___str__():
  env = Environment()
  print(env)


# Generated at 2022-06-23 19:07:47.156992
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    # Test all properties of env to make sure that __repr__ won't raise
    env.stdout
    env.stdout_isatty
    env.stdout_encoding
    env.stderr
    env.stderr_isatty
    env.stderr_encoding
    env.colors
    env.program_name
    env.config

    env.devnull
    env._devnull
    env.stderr = env._orig_stderr = env.stdout
    env.stdout = env.stdin = env.config_dir = env.is_windows = env._config = object()
    repr(env)
    env._config = None
    repr(env)
    env._orig_stderr = None
    repr(env)

# Generated at 2022-06-23 19:07:57.154810
# Unit test for method __repr__ of class Environment

# Generated at 2022-06-23 19:08:00.530762
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    class MyEnv(Environment):
        def __init__(self):
            pass

    env = MyEnv()
    assert type(env).__name__ == 'MyEnv'
    assert env.__repr__()


# Generated at 2022-06-23 19:08:05.741736
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    import io
    stdin_encoding = 'stdin_encoding'
    stdout_encoding = 'stdout_encoding'
    fd = io.StringIO()
    e = Environment(stdout = fd,stdin = fd,
                    stdout_encoding = stdout_encoding,
                    stdin_encoding = stdin_encoding)
    e.program_name = 'test_program'
    assert f'\n{e.program_name}: warning: test' in str(e.log_error('test'))
    assert str(e).find('config') != -1

if __name__ == '__main__':
    import pytest
    pytest.main(f'{__file__}')

# Generated at 2022-06-23 19:08:10.814754
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin_encoding='cp1251', stdout_encoding='cp737')
    assert env.stdin_encoding == 'cp1251'
    assert env.stdout_encoding == 'cp737'
    assert env.stdin is sys.stdin

# Generated at 2022-06-23 19:08:15.214721
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment(program_name='http', config_dir=str(Path('./config_dir'))).program_name == 'http'
    assert Environment(program_name='http', config_dir=str(Path('./config_dir'))).config_dir == Path('./config_dir')

# Generated at 2022-06-23 19:08:22.533178
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import sys
    from httpie.core import Environment
    from httpie.compat import is_windows
    from httpie.output.streams import STDOUT_ENCODING
    from io import StringIO
    stderr = StringIO()
    env = Environment(stderr=stderr)
    env.log_error("ahihi","error")
    #assert stderr.getvalue() == f'\n{env.program_name}: error: ahihi\n\n'
