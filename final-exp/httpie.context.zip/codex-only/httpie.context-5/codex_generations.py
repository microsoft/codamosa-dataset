

# Generated at 2022-06-23 18:58:29.116592
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    import os
    import tempfile

    temp_file = tempfile.TemporaryFile()
    os.write(temp_file.fileno(), b"")
    try:
        env = Environment()

        temp_file.seek(0, io.SEEK_SET)
        env._orig_stderr = temp_file

        env.log_error("Error_message")

        temp_file.seek(0, io.SEEK_SET)
        assert b'http: error: Error_message\n\n' == temp_file.read()
    finally:
        temp_file.close()

# ----------------------------

# Generated at 2022-06-23 18:58:38.610138
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    import sys
    import os

    from httpie.environment import Environment

    # case 1:
    e = Environment(stdin=sys.stdin, stdin_encoding=None, stdout=sys.stdout,
                    stdout_encoding=None, stderr=sys.stderr, stderr_isatty=True,
                    colors=256, program_name='http')

# Generated at 2022-06-23 18:58:49.620477
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    # test empty object
    e=Environment()

# Generated at 2022-06-23 18:58:51.953855
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error('test_error', 'warning')
    env.log_error('test_error')


# Generated at 2022-06-23 18:58:56.566958
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error("Test")
    try:
        env.log_error("Test", level='error')
    except Exception:
        pass
    try:
        env.log_error("Test", level='warning')
    except Exception:
        pass
    try:
        env.log_error("Test", level='test')
    except Exception:
        pass



# Generated at 2022-06-23 18:59:02.124223
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    global fake_stderr
    fake_stderr = ''
    _stderr = sys.stderr
    sys.stderr = open(os.devnull, 'w+')
    env = Environment()
    env._orig_stderr = MagicMock()
    env._orig_stderr.write = MagicMock(return_value=None)

    env.log_error('test')
    env._orig_stderr.write.assert_called_once_with(
        "\nhttp: error: test\n\n")
    sys.stderr = _stderr

test_Environment_log_error()

# Generated at 2022-06-23 18:59:13.843383
# Unit test for constructor of class Environment
def test_Environment():
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.utils import env
    env._Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding is None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding is None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()

# Generated at 2022-06-23 18:59:20.814269
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    values = set()
    for k in dir(Environment):
        if k.startswith('_') or k.endswith('_'):
            continue
        value = getattr(Environment, k)
        if not isinstance(value, type):
            values.add(value)
    environment = Environment()
    as_str = str(environment)
    for value in values:
        if isinstance(value, str) and value:
            assert value in as_str

# Generated at 2022-06-23 18:59:29.218030
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    log = sys.stderr = io.StringIO()
    env.log_error('message')
    sys.stderr = log
    assert log.getvalue() == '\nhttp: error: message\n\n'
    log.close()
    log = sys.stderr = io.StringIO()
    env.log_error('message', level='warning')
    sys.stderr = log
    assert log.getvalue() == '\nhttp: warning: message\n\n'
    log.close()
    log = sys.stderr = io.StringIO()
    env.log_error('message', level='other')
    sys.stderr = log
    assert log.getvalue() == ''
    log.close()
    del env, log

# Generated at 2022-06-23 18:59:32.130673
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    if __name__ == "__main__":
        env = Environment()
        print(repr(env))



# Generated at 2022-06-23 18:59:43.283303
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from httpie.utils import get_response, MockEnvironment
    from httpie.client import HTTPieHTTPError
    from httpie.core import main

    env = MockEnvironment()
    env.stdout_encoding = 'iso2022_jp'
    env.stderr_encoding = 'iso2022_jp'
    env.stdout = open(os.devnull, 'w+')
    env.stderr = open(os.devnull, 'w+')
    env._orig_stderr = open(os.devnull, 'w+')
    env._devnull = open(os.devnull, 'w+')

    directory = Path(__file__).parent
    env.config_dir = directory
    config_file = directory / 'config.json'

# Generated at 2022-06-23 18:59:53.114996
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from io import StringIO
    from httpie.compat import is_windows
    env = Environment()

# Generated at 2022-06-23 19:00:00.520149
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io

    class StreamMock:
        def __init__(self):
            self.s = io.StringIO()

        def write(self, data):
            self.s.write(data)

        def getvalue(self):
            return self.s.getvalue()

    mock = StreamMock()

    env = Environment(stderr=mock)
    msg = 'This is an error'
    env.log_error(msg)

    expected = f'\nhttp: error: {msg}\n\n'
    assert mock.getvalue() == expected

# Generated at 2022-06-23 19:00:10.069828
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == True
    assert env.config_dir == Path(os.getenv('HOME', '.') + '/.config/httpie')
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()

# Generated at 2022-06-23 19:00:16.829571
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin = 12, stdout = "stdout", stderr = "stderr", program_name = "program_name")
    assert env.stdin == 12
    assert env.stdout == "stdout"
    assert env.stderr == "stderr"
    assert env.program_name == "program_name"


# Generated at 2022-06-23 19:00:25.734301
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import tempfile
    import io

    class MockStderr(object):
        def __init__(self):
            self.err = tempfile.NamedTemporaryFile(delete=False)

        def write(self, msg):
            self.err.write(msg.encode())

        def __del__(self):
            self.err.close()
            os.unlink(self.err.name)

    def mock_env_log_error(program_name, stderr):
        env = Environment(program_name=program_name, stderr=stderr)
        env.log_error('Failed to read config file')
        with open(stderr.err.name, 'rb') as f:
            return f.read().decode('utf-8')


# Generated at 2022-06-23 19:00:36.654019
# Unit test for constructor of class Environment
def test_Environment():
    import sys
    import os
    from pathlib import Path
    from typing import IO, Optional


    try:
        import curses
    except ImportError:
        curses = None  # Compiled w/o curses

    from httpie.compat import is_windows
    from httpie.config import DEFAULT_CONFIG_DIR, Config, ConfigFileError

    from httpie.utils import repr_dict


    class Environment:
        """
        Information about the execution context
        (standard streams, config directory, etc).

        By default, it represents the actual environment.
        All of the attributes can be overwritten though, which
        is used by the test suite to simulate various scenarios.

        """
        is_windows: bool = is_windows
        config_dir: Path = DEFAULT_CONFIG_DIR

# Generated at 2022-06-23 19:00:43.089078
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    stdin = StringIO("Hello World")
    stdout = StringIO()
    stderr = StringIO()
    env.stdin = stdin
    env.stdout = stdout
    env.stderr = stderr
    print("Welcome to test")
    print("Is this true?", file = stderr)
    assert env.stdin == stdin, "stdin not set properly"
    assert env.stdout == stdout, "stdout not set properly"
    assert env.stderr == stderr, "stdout not set properly"
    assert env.stdin_isatty, "stdin_isatty not set properly"
    assert env.stdout_isatty, "stdout_isatty not set properly"

# Generated at 2022-06-23 19:00:46.605531
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    s = Environment(a = '1', b= '2').__repr__()
    assert s == '<Environment {a: \'1\', b: \'2\'}>'


# Generated at 2022-06-23 19:00:58.257082
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    environment = Environment()
    assert str(environment) == '<Environment {' \
                               '\'is_windows\': False, ' \
                               '\'config_dir\': PosixPath(\'.httpie\'), ' \
                               '\'stdin\': <_io.TextIOWrapper name=7 mode=\'r\' encoding=\'UTF-8\'>, ' \
                               '\'stdin_isatty\': True, ' \
                               '\'stdin_encoding\': \'UTF-8\', ' \
                               '\'stdout\': <_io.TextIOWrapper name=1 mode=\'w\' encoding=\'UTF-8\'>, ' \
                               '\'stdout_isatty\': True, ' \
                               '\'stdout_encoding\': \'UTF-8\', '

# Generated at 2022-06-23 19:01:04.642267
# Unit test for constructor of class Environment
def test_Environment():
    new_environment = Environment()
    assert new_environment.__dict__['stdin'] == sys.stdin
    assert new_environment.__dict__['stdin_encoding'] == 'utf8'
    assert new_environment.__dict__['stdout'] == sys.stdout
    assert new_environment.__dict__['stdout_encoding'] == 'utf8'
    assert new_environment.__dict__['stderr'] == sys.stderr

# Generated at 2022-06-23 19:01:14.249885
# Unit test for constructor of class Environment
def test_Environment():
    # Creating object of class Environment and checking
    # if the value of each class attribute is correct
    env = Environment(devnull='/dev/null', is_windows=True, config_dir=DEFAULT_CONFIG_DIR, stdin=None, stdin_isatty=False, stdin_encoding=None, stdout=sys.stdout, stdout_isatty=True, stdout_encoding='utf-8', stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http')
    assert env.devnull == '/dev/null' and env.is_windows == True and env.config_dir == DEFAULT_CONFIG_DIR and env.stdin is None and env.stdin_isatty is False and env.stdin_encoding is None and env.std

# Generated at 2022-06-23 19:01:16.622855
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    environment = Environment()
    environment.log_error('test')
    # stdout will print something like `http: error: test\n`

# Generated at 2022-06-23 19:01:28.029275
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(devnull=None, colors=256, config_dir=DEFAULT_CONFIG_DIR, is_windows=is_windows, program_name='http', stderr=sys.stderr, stderr_encoding=None, stderr_isatty=True, stdin=sys.stdin, stdin_encoding='utf8', stdin_isatty=True, stdout=sys.stdout, stdout_encoding='utf8', stdout_isatty=True)
    result = env.__str__()

# Generated at 2022-06-23 19:01:38.796424
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    stdout = sys.stdout
    stdout_encoding = getattr(stdout, 'encoding', None) or 'utf8'
    stdin = sys.stdin
    stdin_encoding = getattr(stdin, 'encoding', None) or 'utf8'
    #assert all(hasattr(type(self), attr) for attr in kwargs.keys())
    env = Environment()
    #print(env.__dict__)
    del env.__dict__['_config']
    del env.__dict__['_orig_stderr']
    del env.__dict__['_devnull']
    env.__dict__['stdin_isatty'] = True
    env.__dict__['stdout_isatty'] = True

# Generated at 2022-06-23 19:01:48.580323
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    e = Environment()
    assert repr(e) == "<Environment {'config': <Config '~/.httpie-test.py'>, 'stdin': <_io.TextIOWrapper name='<stdin>'>, 'stdin_isatty': False, 'stdin_encoding': 'utf8', 'stdout': <_io.TextIOWrapper name='<stdout>'>, 'stdout_isatty': False, 'stdout_encoding': 'utf8', 'stderr': <_io.TextIOWrapper name='<stderr>'>, 'stderr_isatty': False, 'colors': 256, 'program_name': 'http'}>"

# Generated at 2022-06-23 19:01:52.311780
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    # GIVEN: An instance of Environment class
    env = Environment()
    # WHEN: We call __repr__ method
    repr_env = repr(env)
    # THEN: The string format is right
    assert repr_env == "<Environment {'config': <Config {}, config_dir: '{config_dir}\n}'>}>"

# Generated at 2022-06-23 19:01:54.096382
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    print("The env is: ")
    print(Environment())

# Generated at 2022-06-23 19:01:55.416307
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error('Some error message')

# Generated at 2022-06-23 19:01:59.578640
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    sys.stderr = StringIO()
    env.log_error("testing", level="warning")
    expected_output = '\nhttp: warning: testing\n\n'
    assert sys.stderr.getvalue() == expected_output

# Generated at 2022-06-23 19:02:02.820481
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    assert env.__repr__() == '<Environment <http.core.env.Environment <class \'http.core.env.Environment\'> at 0x000002E6E13396A0>>>'


# Generated at 2022-06-23 19:02:14.525201
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    env_repr = repr(env)
    assert isinstance(env_repr, str)
    assert env_repr == '<Environment {'
    assert env_repr == '<Environment {'
    assert env_repr == '<Environment {'
    assert env_repr == '<Environment {'
    assert env_repr == '<Environment {'
    assert env_repr == '<Environment {'
    assert env_repr == '<Environment {'
    assert env_repr == '<Environment {'
    assert env_repr == '<Environment {'
    assert env_repr == '<Environment {'
    assert env_repr == '<Environment {'
    assert env_repr == '<Environment {'
    assert env_repr == '<Environment {'


# Generated at 2022-06-23 19:02:16.072240
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment()
    print(e)


# test_Environment()

# Generated at 2022-06-23 19:02:27.354393
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
  env = Environment()

# Generated at 2022-06-23 19:02:38.905242
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(is_windows=True,stdin=None,config_dir='test',stdin_encoding=None,stdout=sys.stdout,
                      stdout_isatty=sys.stdout.isatty(),stdout_encoding=None,stderr=sys.stderr,
                      stderr_isatty=sys.stderr.isatty(),colors=256,program_name='test')
    assert env.is_windows == True
    assert env.stdin == None
    assert env.config_dir == 'test'
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.st

# Generated at 2022-06-23 19:02:47.753523
# Unit test for method __repr__ of class Environment

# Generated at 2022-06-23 19:02:50.065744
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error('error')
    env.log_error('warning','warning')

# Generated at 2022-06-23 19:02:51.184757
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    assert env


# Generated at 2022-06-23 19:03:02.504768
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()

# Generated at 2022-06-23 19:03:10.667416
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import unittest
    import io
    import textwrap
    class TestEnvironment(unittest.TestCase):
        def test_log_error(self):
            """
            The error and warning messages should start with the program name
            and be wrapped in newlines.
            """
            env = Environment(program_name='foo', stderr=io.StringIO())
            env.log_error('bar', level='warning')
            self.assertEqual(env.stderr.getvalue(),
                             '\nfoo: warning: bar\n\n')

            env = Environment(program_name='foo', stderr=io.StringIO())
            env.log_error(textwrap.dedent("""
                baz
                qux
            """).strip(), level='warning')

# Generated at 2022-06-23 19:03:12.613932
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.config_dir == Path(DEFAULT_CONFIG_DIR), "Error in default"

# Generated at 2022-06-23 19:03:22.324688
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == getattr(env.stdin, 'encoding', None) or 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == getattr(env.stdout, 'encoding', None) or 'utf8'
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()

# Generated at 2022-06-23 19:03:33.784269
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    class TestCase(unittest.TestCase):
        msg = 'error_message'

    test_case = TestCase()
    environment = Environment()

    suite = unittest.TestSuite()
    suite.addTest(test_case)
    runner = unittest.TextTestRunner(stream=StringIO())
    result = runner.run(suite)

    target = environment._orig_stderr
    assert target.write.call_count == 0
    target.write.side_effect = result.stream.write
    target.flush.return_value = None

    # Make call
    environment.log_error(test_case.msg, level='error')
    # Validate call

# Generated at 2022-06-23 19:03:40.924649
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_encoding is None
    assert env.stdout == sys.stdout
    assert env.stdout_encoding is None
    assert env.stderr == sys.stderr
    assert env.program_name == 'http'


# Generated at 2022-06-23 19:03:51.676494
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    import sys
    from os.path import sep
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.compat import is_windows
    from httpie.Environment import Environment
    from httpie.utils import repr_dict

    temp_dir = DEFAULT_CONFIG_DIR + sep + 'httpie'
    c = Environment()

# Generated at 2022-06-23 19:04:03.396133
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    def check(expected_stdout, level, stderr = None):
        if stderr == None:
            f = open(os.devnull, 'w+')
            stderr = f.fileno()
        env = Environment(stdout = StringIO(), stderr = stderr, program_name = 'http')
        msg = "This is a test message"
        env.log_error(msg, level)
        actual_stdout = env.stdout.getvalue()
        assert actual_stdout == expected_stdout

    check('\nhttp: error: This is a test message\n\n', 'error')
    check('\nhttp: warning: This is a test message\n\n', 'warning')

# Generated at 2022-06-23 19:04:08.142326
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment(stdout=None, stderr=None)
    env.config_dir = Path('_')
    env._config = None
    env.devnull = None
    env.log_error('Error output test')
    env.log_error('Warning output test', level='warning')



# Generated at 2022-06-23 19:04:19.211514
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import sys
    import os
    from pathlib import Path
    from typing import Optional, IO
    # sys.stdout = open(os.devnull, 'w')
    orig_sys_stderr = sys.stderr
    sys.stderr = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "log_error_out.txt"), 'w')

# Generated at 2022-06-23 19:04:20.571068
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull="NULL")
    assert env._devnull == "NULL"

# Generated at 2022-06-23 19:04:23.091046
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():

    environment = Environment(stdout_encoding = 'stdout_encoding')
    print(repr(environment))
    print(environment.stdout_encoding)

# Generated at 2022-06-23 19:04:27.797478
# Unit test for constructor of class Environment
def test_Environment():
    import sys
    import os

    global is_windows
    global stdin
    global stdin_isatty
    global stdin_encoding
    global stdout
    global stdout_isatty
    global stdout_encoding
    global stderr
    global stderr_isatty
    global colors
    global program_name
    global config_dir
    global config

    is_windows = True
    stdin = None
    stdin_isatty = False
    stdin_encoding = None
    stdout = sys.stdout
    stdout_isatty = sys.stdout.isatty()
    stdout_encoding = None
    stderr = sys.stderr
    stderr_isatty = sys.stderr.isatty()
    stderr_enc

# Generated at 2022-06-23 19:04:32.857583
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    out = sys.stderr.write
    sys.stderr.write = lambda x: None
    env.log_error("this is an error", level='error')
    env.log_error("this is a warning", level='warning')
    sys.stderr.write = out



# Generated at 2022-06-23 19:04:43.435380
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    msg = 'A mock error message'
    # Test message logged by default
    env.log_error(msg)
    assert f'{env.program_name}: error: {msg}' in env.stderr.getvalue()
    assert msg not in env.stdout.getvalue()
    # Test warning message logged
    env.stdout.truncate(0)
    env.stderr.truncate(0)
    env.log_error(msg, level='warning')
    assert f'{env.program_name}: warning: {msg}' in env.stderr.getvalue()
    assert msg not in env.stdout.getvalue()

# Generated at 2022-06-23 19:04:46.009015
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdout_encoding='utf8')
    print(env)
    assert env.stdout_encoding == 'utf8'


# Generated at 2022-06-23 19:04:53.105373
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env_=Environment(stdin='1',stdout='2',stderr='3')
    s=env_.__repr__()
    assert s=="<Environment {'stdin': '1', 'stdin_isatty': False, 'stdin_encoding': None, 'stdout': '2', 'stdout_isatty': False, 'stdout_encoding': None, 'stderr': '3', 'stderr_isatty': False, 'colors': 256, 'program_name': 'http', 'is_windows': False, 'config_dir': PosixPath('/home/httpie/.config/httpie')}>", "test failed"


# Generated at 2022-06-23 19:04:54.085961
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    assert str(env)
    env = Environment(colors=256)
    assert str(env)

# Generated at 2022-06-23 19:05:00.654697
# Unit test for constructor of class Environment
def test_Environment():
    # Given
    e = Environment()
    # When and Then
    assert e.is_windows == is_windows
    assert e.config_dir == DEFAULT_CONFIG_DIR
    assert e.stdin == sys.stdin
    assert e.stdin_isatty == e.stdin.isatty()
    assert e.stdout == sys.stdout
    assert e.stdout_isatty == e.stdout.isatty()
    assert e.stderr == sys.stderr
    assert e.stderr_isatty == e.stderr.isatty()
    assert e.program_name == 'http'
    assert e.stdin_encoding == None
    assert e.stdout_encoding == None
    assert e.stderr_encoding == None
    assert str

# Generated at 2022-06-23 19:05:11.092270
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from pprint import pprint
    import os
    import sys
    from httpie.compat import is_windows
    env_t = Environment()

    env_t.is_windows = is_windows
    env_t.config_dir = os.path.dirname(os.__file__)
    env_t.stdin = sys.stdin
    env_t.stdin_isatty = True
    env_t.stdin_encoding = sys.stdin.encoding
    env_t.stdout = sys.stdout
    env_t.stdout_isatty = True
    env_t.stdout_encoding = sys.stdout.encoding
    env_t.stderr = sys.stderr
    env_t.stderr_isatty = True
    env_t._

# Generated at 2022-06-23 19:05:12.476816
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    assert str(Environment())


# Generated at 2022-06-23 19:05:22.803530
# Unit test for method __str__ of class Environment
def test_Environment___str__():

    stdout = 1
    stderr = 1

    env = Environment(
        devnull=0, 
        is_windows=0, 
        config_dir=0, 
        stdin=0, 
        stdin_isatty=1, 
        stdin_encoding=1, 
        stdout=stdout, 
        stdout_isatty=1, 
        stdout_encoding=1, 
        stderr=stderr, 
        stderr_isatty=1, 
        colors=1, 
        program_name=1, 
        _orig_stderr=1, 
        _devnull=1, 
        _config=1, 
        config=1
    )


# Generated at 2022-06-23 19:05:26.710118
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment(is_windows=False, stdin_encoding='utf8', stdout_encoding='utf8')
    assert repr(env) == '<Environment {\n  "is_windows": false,\n  "stdin_encoding": "utf8",\n  "stdout_encoding": "utf8"\n}>'



# Generated at 2022-06-23 19:05:34.421628
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None)
    assert env.stdin is None
    assert not env.stdin_isatty
    assert env.stdin_encoding is None
    assert env.stdout is sys.stdout
    assert env.stdout_isatty
    assert env.stdout_encoding is not None
    assert env.stderr is sys.stderr
    assert env.stderr_isatty
    assert env.colors == 256
    assert env.program_name == 'http'

# Generated at 2022-06-23 19:05:45.100263
# Unit test for constructor of class Environment
def test_Environment():
    from httpie.utils import Dummy

    env = Environment()
    assert hasattr(env, 'program_name')
    assert hasattr(env, 'config')

    # Argument with default
    env = Environment(program_name='http')
    assert env.program_name == 'http'

    # Argument without default - must be error!
    stdin = StringIO()
    env = Environment(stdin=stdin)
    assert env.stdin == stdin

    # Invalid argument - must be error!
    try:
        env = Environment(invalid='invalid')
        assert False, "shoule raise an exception"
    except:
        assert True

    # is_windows attribute
    env = Environment(is_windows=True)
    assert env.is_windows

    # config attribute

# Generated at 2022-06-23 19:05:48.754123
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment(stderr=open("test.log", "w"), program_name="httpie")
    env.log_error("test")
    assert open("test.log").read()=='\nhttpie: error: test\n\n'


# Generated at 2022-06-23 19:05:55.173806
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env._orig_stderr = io.StringIO()
    env.log_error("test error message")
    env.log_error("test warning message", level='warning')
    f = io.StringIO('\nhttp: error: test error message\n\n\nhttp: warning: test warning message\n\n')
    assert env._orig_stderr.getvalue() == f.getvalue()

# Generated at 2022-06-23 19:06:02.585716
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(program_name = "http")

# Generated at 2022-06-23 19:06:04.526893
# Unit test for constructor of class Environment
def test_Environment():
    def test():
        print(env.__class__.__name__)
        print(env.__str__())
        print(env.__repr__())
        print(env.stdin)
    env = Environment()
    test()

if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-23 19:06:15.244197
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().is_windows == is_windows
    assert Environment().stdin == sys.stdin
    assert Environment().stdin_encoding == \
           (getattr(sys.stdin, 'encoding', None) or 'utf-8')
    assert Environment().stdin_isatty == sys.stdin.isatty()
    assert Environment().stdout == sys.stdout
    assert Environment().stdout_encoding == \
           (getattr(sys.stdout, 'encoding', None) or 'utf-8')
    assert Environment().stdout_isatty == sys.stdout.isatty()
    assert Environment().stderr == sys.stderr
    assert Environment().stderr_isatty == sys.stderr.isatty()
    assert Environment().config_dir == DEFAULT_CONFIG_

# Generated at 2022-06-23 19:06:19.784362
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment(is_windows=True, config_dir=DEFAULT_CONFIG_DIR, stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr, program_name='http')
    env.__repr__()

# Generated at 2022-06-23 19:06:29.360833
# Unit test for method log_error of class Environment
def test_Environment_log_error():

    class DummyEnvironment:
        is_windows: bool = is_windows
        config_dir: Path = DEFAULT_CONFIG_DIR
        stdin: Optional[IO] = sys.stdin  # `None` when closed fd (#791)
        stdin_isatty: bool = stdin.isatty() if stdin else False
        stdin_encoding: str = None
        stdout: IO = sys.stdout
        stdout_isatty: bool = stdout.isatty()
        stdout_encoding: str = None
        stderr: IO = sys.stderr
        stderr_isatty: bool = stderr.isatty()
        colors = 256
        program_name: str = 'http'

# Generated at 2022-06-23 19:06:37.051324
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    if env.stdout_encoding is None:
        env.stdout_encoding = getattr(env.stdout, 'encoding', None) or 'utf8'
    env.stdout_encoding
    env.stdout_isatty
    env.program_name
    env._devnull
    env.config

if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-23 19:06:47.592323
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import StringIO
    from httpie.output.streams import write_to_request_log

    def initiate(**kwargs):
        env = Environment(**kwargs)

        # Create a modified environment object to mimic error
        env.stderr = StringIO()
        env.program_name = 'http'

        return env

    # Test case 1: Blank error
    env = initiate(stderr=StringIO())
    env.log_error('')
    assert len(env.stderr.getvalue().strip()) == 0

    # Test case 2: Valid error
    env = initiate(stderr=StringIO())
    env.log_error('JSONDecodeError')
    assert len(env.stderr.getvalue().strip()) != 0
    assert b'http' in env.stderr.getvalue

# Generated at 2022-06-23 19:06:52.136459
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    assert str(env) == '<Environment {}>'
    env.stdin = None
    assert str(env) == '<Environment {stdin=None}>'


# Generated at 2022-06-23 19:07:01.497910
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=open('/dev/stdin'))
    assert env.is_windows
    assert env.config_dir == Path(DEFAULT_CONFIG_DIR)
    assert env.stdin == open('/dev/stdin')
    assert env.stdin_isatty
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty
    assert env.stdout_encoding == 'utf8'
    assert env.stderr == sys.stderr
    assert env.stderr_isatty
    assert env.colors == 256
    print(env)
    print(repr(env))

# Generated at 2022-06-23 19:07:08.062842
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    assert env._orig_stderr == env.stderr
    env._orig_stderr = StringIO()
    env.log_error('error: operation completed successfully', level='error')
    env.log_error('warning: operation completed successfully', level='warning')
    assert env._orig_stderr.getvalue() == '\nhttp: error: operation completed successfully\n\n\nhttp: warning: operation completed successfully\n\n'

# Generated at 2022-06-23 19:07:14.318245
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    env.stdin = None
    assert env.stdin is None
    env.stdout = None
    assert env.stdout is None
    env.stderr = None
    assert env.stderr is None
    assert env._config is None
    print(env)
    env.config
    assert env._config is not None
    # env.devnull
    # assert env._devnull is not None

# Generated at 2022-06-23 19:07:23.815136
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import sys
    import os

    from tempfile import NamedTemporaryFile

    from httpie.context import Environment

    with NamedTemporaryFile(mode='w+') as fp, \
         redirect_stderr(fp):
        Environment()\
            .log_error('This is an error', level='error')
        fp.seek(0)
        assert fp.read().splitlines() == \
               ['http: error: This is an error'], \
               'Testing method log_error of class Environment. Error level'
        fp.seek(0)
        assert fp.read() != \
               'http: warning: This is an error', \
               'Testing method log_error of class Environment. Error level'
        fp.truncate(0)


# Generated at 2022-06-23 19:07:33.934530
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()

# Generated at 2022-06-23 19:07:45.868347
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    stdin: IO = sys.stdin  # `None` when closed fd (#791)
    stdin_isatty: bool = stdin.isatty() if stdin else False
    stdin_encoding: str = None
    stdout: IO = sys.stdout
    stdout_isatty: bool = stdout.isatty()
    stdout_encoding: str = None
    stderr: IO = sys.stderr
    stderr_isatty: bool = stderr.isatty()
    colors = 256
    program_name: str = 'http'
    if not is_windows:
        if curses:
            try:
                curses.setupterm()
                colors = curses.tigetnum('colors')
            except curses.error:
                pass

# Generated at 2022-06-23 19:07:54.816301
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    e = Environment()
    assert str(e) == """{'colors': 0, 'config_dir': '~/.config/httpie', 'is_windows': False, 'program_name': 'http', 'stdin': <_io.TextIOWrapper name='<stdin>' mode='r' encoding='utf-8'>, 'stdin_encoding': None, 'stdin_isatty': True, 'stdout': <_io.TextIOWrapper name='<stdout>' mode='w' encoding='utf-8'>, 'stdout_encoding': None, 'stdout_isatty': True, 'stderr': <_io.TextIOWrapper name='<stderr>' mode='w' encoding='utf-8'>, 'stderr_isatty': True}"""

# Generated at 2022-06-23 19:07:59.769785
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    import sys

    sys.stderr = io.StringIO()

    env = Environment()
    env.log_error('hello')
    assert sys.stderr.getvalue() == '\nhttp: error: hello\n\n'
    sys.stderr = sys.__stderr__

    del sys, io

# Generated at 2022-06-23 19:08:07.708373
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    pass
    # stdout_encoding = locale.getpreferredencoding()
    # stdin_encoding = locale.getpreferredencoding()
    # my_stdin = io.TextIOWrapper(sys.stdin.buffer, encoding = stdin_encoding)
    # my_stdout = io.TextIOWrapper(sys.stdout.buffer, encoding = stdout_encoding)
    # my_stderr = io.TextIOWrapper(sys.stderr.buffer, encoding = stdout_encoding)
    # my_env = Environment(program_name = "http",
    #                      stdin = my_stdin,
    #                      stdout = my_stdout,
    #                      stderr = my_stderr,
    #                      stdin_encoding = stdin_enc

# Generated at 2022-06-23 19:08:13.935459
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert not env.is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin is sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding is None
    assert env.stdout is sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding is None
    assert env.stderr is sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()

    env = Environment(colors=8, config_dir='/path/to/config', stdin=None, stdout=None, stderr=None)
    assert env

# Generated at 2022-06-23 19:08:16.329138
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    assert repr(env.log_error("Text"))


# Generated at 2022-06-23 19:08:22.928634
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    from httpie.config import Config
    from httpie.plugins import builtin
