

# Generated at 2022-06-23 18:58:30.351743
# Unit test for constructor of class Environment
def test_Environment():
    Env = Environment(colors=1, stdin=None, stdin_isatty=True, stdin_encoding='utf8', stdout=None, stdout_isatty=False, stdout_encoding='utf8', stderr=None)
    if Env.colors == 1 and Env.stdin is None and Env.stdin_isatty is True and Env.stdin_encoding == 'utf8' and Env.stdout is None and Env.stdout_isatty is False and Env.stdout_encoding == 'utf8' and Env.stderr is None:
        print("Environment 对象创建成功")
    else:
        print("Environment 对象创建失败")


# Generated at 2022-06-23 18:58:39.655162
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from httpie.config import Config
    from httpie.output.streams import STREAM_OUTPUT
    import os
    import sys

    class Env(Environment):
        pass

    env = Env(
        devnull=None,
        is_windows=False,
        config_dir=Config.DEFAULT_CONFIG_DIR,
        stdin=sys.stdin,
        stdin_isatty=True,
        stdin_encoding=None,
        stdout=sys.stdout,
        stdout_isatty=False,
        stdout_encoding=None,
        stderr=sys.stderr,
        stderr_isatty=False,
        colors=256,
        program_name='http',
        config=Config(directory=None),
    )

    assert str

# Generated at 2022-06-23 18:58:45.164669
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.stdin == sys.stdin
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.devnull == None
    assert env.colors == 256
    assert env.program_name == 'http'


# Generated at 2022-06-23 18:58:56.115034
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    e = Environment(devnull=None, stdin=None, stdin_isatty=True, stdin_encoding=None, stdout=None, stdout_isatty=True, stdout_encoding=None, stderr=None, stderr_isatty=True, colors=256, program_name='test', config_dir='.', is_windows=False)
    e.stdin = None
    assert str(e) == "{'is_windows': False, 'program_name': 'test', 'stdin': None, 'stdin_isatty': True, 'stdout': None, 'stdout_isatty': True, 'stderr': None, 'stderr_isatty': True, 'colors': 256, 'config': <Config directory='.'>}"


# Generated at 2022-06-23 18:58:58.575086
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin='', stdout='', stderr='')
    assert env.stdin == ''
    assert env.stdout == ''
    assert env.stderr == ''



# Generated at 2022-06-23 18:59:10.603914
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment(stdin_isatty=True, stdout_isatty=False, is_windows=False)

# Generated at 2022-06-23 18:59:19.138876
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import unittest.mock
    import io
    env = Environment()
    env._orig_stderr = io.StringIO()
    env.log_error("This is a error message\n")
    assert unittest.mock.call("\nhttp: error: This is a error message\n\n") in env._orig_stderr.write.mock_calls
    env.log_error("This is a level message\n", level='warning')
    assert unittest.mock.call("\nhttp: warning: This is a level message\n\n") in env._orig_stderr.write.mock_calls
    env.log_error("This is a unknown level\n", level='unknown')

# Generated at 2022-06-23 18:59:28.189429
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdout_isatty=False)
    assert env.stdout_isatty == False
    env = Environment(stdout_isatty=True)
    assert env.stdout_isatty == True
    env = Environment(stderr_isatty=False)
    assert env.stderr_isatty == False
    env = Environment(stderr_isatty=True)
    assert env.stderr_isatty == True
    env = Environment(is_windows=True)
    assert env.is_windows == True
    env = Environment(is_windows=False)
    assert env.is_windows == False
    env = Environment(colors=10)
    assert env.colors == 10
    env = Environment(program_name="httpie")
    assert env.program_

# Generated at 2022-06-23 18:59:29.750543
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    print(env)


# Generated at 2022-06-23 18:59:32.242309
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error('error message', level='error')


# Generated at 2022-06-23 18:59:40.389554
# Unit test for constructor of class Environment
def test_Environment():
    # :
    '''test the constructor of class Environment'''

    e = Environment()
    assert e.is_windows == is_windows
    assert e.stdin == sys.stdin
    assert e.stdout == sys.stdout
    assert e.stderr == sys.stderr

    with open(os.devnull, 'w+') as devnull:
        # :
        '''construct an environment with devnull'''
        e = Environment(devnull, config_dir=DEFAULT_CONFIG_DIR)
        assert e.is_windows == is_windows
        assert e.stdin == sys.stdin
        assert e.stdout == sys.stdout
        assert e.stderr == sys.stderr
        assert e.devnull == devnull



# Generated at 2022-06-23 18:59:46.842220
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    import sys
    import os

    env = Environment()
    env.stderr = io.StringIO()
    msg = "message"
    env.log_error(msg)
    assert msg in env.stderr.getvalue()

    env._orig_stderr = sys.stdout
    env.stderr = io.StringIO()
    env.log_error(msg)
    assert msg not in env.stderr.getvalue()

# Generated at 2022-06-23 18:59:55.372993
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    env.config_dir = Path('/path/to/config/dir')
    env.stdin_isatty = True
    env.stdout_isatty = False
    env.stderr_isatty = False
    env.stdout_encoding = 'abc'
    env.stderr_encoding = 'def'
    env.program_name = 'http'
    env.colors = 256
    env.config._config_dict = {'user_agent': 'acme-client/0.1'}

# Generated at 2022-06-23 19:00:04.858775
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    assert isinstance(env.__repr__(), str)

# Generated at 2022-06-23 19:00:14.447682
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    from httpie.cli.utils import Environment
    env = Environment()
    import io

# Generated at 2022-06-23 19:00:20.442322
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    os.environ.pop('EDITOR', None)
    env = Environment()
    name = 'USAGE'
    env.config.set(name, 'any')
    print(env.__repr__())
    env.config.set(name, 'default')
    print(env.__repr__())
    env.config.clear()
    env.__dict__[name] = 'default'
    print(env.__repr__())
    env.__dict__.pop(name)
    print(env.__repr__())

# Generated at 2022-06-23 19:00:21.971272
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error('hello')
    env.log_error('world', level='warning')

# Generated at 2022-06-23 19:00:28.900901
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    import sys
    from httpie.context import Environment
    try:
        sys.stderr = io.StringIO()
        env = Environment()
        env.log_error("Hello")
        print(sys.stderr.getvalue())
        assert sys.stderr.getvalue() == '\nhttp: error: Hello\n\n'
    finally:
        sys.stderr = sys.__stderr__


# Generated at 2022-06-23 19:00:40.108197
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    try:
        sys.stdin
    except AttributeError:
        sys.stdin = None

# Generated at 2022-06-23 19:00:51.937761
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    """
    Unit test for Environment.log_error
    """
    # get the environment
    env = Environment()
    # prepare the test
    class CollectingStream(StringIO):
        def write(self, data):
            self.buf += data
    fd = CollectingStream()
    # execute
    save_stderr = env._orig_stderr
    try:
        env._orig_stderr = fd
        env.log_error('test_log_error')
    except Exception:
        raise
    finally:
        env._orig_stderr = save_stderr
    # verify
    expected = '\nhttp: error: test_log_error\n\n'
    assert fd.buf == expected, f'actual={fd.buf}'



# Generated at 2022-06-23 19:01:03.301176
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    import json
    env = Environment(
        is_windows=True,
        config_dir='/home',
        stdout='1',
        a=1,
        devnull=2,
        _devnull=3,
        _config=4,
        _orig_stderr=5,
        program_name='8'
    )
    assert json.loads(str(env)) == {
        'a': 1,
        'config': 4,
        'colors': 256,
        'config_dir': '/home',
        'is_windows': True,
        'program_name': '8',
        'stdout': '1',
        'stdout_isatty': True,
        'stderr_isatty': True,
        'stdin_isatty': True
    }

# Generated at 2022-06-23 19:01:06.088582
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    environment = Environment()
    environment._orig_stderr = sys.stderr
    environment.log_error('Test')
    environment.log_error('Test', level='warning')

# Generated at 2022-06-23 19:01:17.173629
# Unit test for constructor of class Environment
def test_Environment():
    import sys
    import os
    import platform

    if 'Windows' in platform.uname():
        my_env = Environment(is_windows=True, program_name='http')
    elif 'Darwin' in platform.uname():
        my_env = Environment(is_windows=False, program_name='http')
    else:
        my_env = Environment(is_windows=False, program_name='http')
    
    # Check whether the output is sth. like <Environment {'colors': 256, 'is_windows': False, 'program_name': 'http'}>

# Generated at 2022-06-23 19:01:28.476498
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    stdin = StringIO('hello')
    stdout = StringIO()
    stderr = StringIO()
    env = Environment(
        stdin=stdin,
        stdin_isatty=False,
        stdout=stdout,
        stdout_isatty=False,
        stderr=stderr,
        stderr_isatty=False,
        colors=256,
        program_name='http'
    )

# Generated at 2022-06-23 19:01:39.100534
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
  env = Environment()

# Generated at 2022-06-23 19:01:39.591877
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    assert True

# Generated at 2022-06-23 19:01:50.458994
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    import sys
    from tempfile import TemporaryFile
    from pathlib import Path
    from io import StringIO
    from httpie import io

    orig_sys_stdin = sys.stdin
    orig_sys_stdout = sys.stdout
    orig_sys_stderr = sys.stderr
    stdin = TemporaryFile('w+')
    stdout = TemporaryFile('w+')
    stderr = TemporaryFile('w+')
    sys.stdin = stdin
    sys.stdout = stdout
    sys.stderr = stderr

    env = Environment()
    env_str = str(env)
    assert '<Environment' in env_str, f'Unexpected env_str {env_str}'

# Generated at 2022-06-23 19:02:00.311241
# Unit test for constructor of class Environment
def test_Environment():
    '''
    Test the constructor of class Environment
    :return:
    '''
    env = Environment(devnull=None, is_windows=False, config_dir=DEFAULT_CONFIG_DIR,
                        stdin=sys.stdin, stdin_isatty=sys.stdin.isatty(),
                        stdin_encoding=sys.stdin.encoding, stdout=sys.stdout,
                        stdout_isatty=sys.stdout.isatty(), stdout_encoding=sys.stdout.encoding,
                        stderr=sys.stderr, stderr_isatty=sys.stderr.isatty(),
                        program_name='http')
    print("test_Environment:", env)


# Generated at 2022-06-23 19:02:12.466824
# Unit test for constructor of class Environment
def test_Environment():
    import os
    import sys
    from httpie.plugins import builtin

    assert Environment.config_dir == DEFAULT_CONFIG_DIR
    
    test_env = Environment(stdin=sys.stdin,
                           stdout=sys.stdout,
                           stderr=sys.stderr,
                           program_name='test-http',
                           config_dir=os.getcwd())

    assert test_env.config_dir == os.getcwd()
    assert test_env.program_name == 'test-http'
    assert test_env.stdin == sys.stdin
    assert test_env.stdout == sys.stdout
    assert test_env.stderr == sys.stderr


if __name__ == "__main__":
    test_Environment()

# Generated at 2022-06-23 19:02:16.503278
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(is_windows=True, stdin=open('kajsdh', 'r'))
    assert env.is_windows == True
    assert env.stdin == open('kajsdh', 'r')
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr



# Generated at 2022-06-23 19:02:17.646926
# Unit test for method __str__ of class Environment
def test_Environment___str__():
   pass


# Generated at 2022-06-23 19:02:19.217044
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    e = Environment()
    print(e.__repr__())


# Generated at 2022-06-23 19:02:20.696587
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    repr(env)
    assert repr(env)

# Generated at 2022-06-23 19:02:32.237254
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    out1 = Environment(stdout_encoding='utf-8')

# Generated at 2022-06-23 19:02:32.900970
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    pass

# Generated at 2022-06-23 19:02:34.881949
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    a = Environment()
    assert a.__repr__() == '<Environment {}>'



# Generated at 2022-06-23 19:02:40.504340
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    class Stderr:
        def write(self, data):
            self.data = data

    stderr = Stderr()
    data = 'test'
    env = Environment(stderr=stderr)
    env.log_error(data)
    assert stderr.data == f'\nhttp: error: {data}\n\n'

# Generated at 2022-06-23 19:02:48.642368
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    test_object = Environment(is_windows=is_windows,
                              config_dir=DEFAULT_CONFIG_DIR,
                              stdin=sys.stdin,
                              stdout=sys.stdout,
                              stderr=sys.stderr,
                              program_name='http')

# Generated at 2022-06-23 19:02:56.427516
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.program_name = 'http.py'
    env.stderr = io.StringIO()
    assert env.stderr.getvalue() == '', \
        'Environment.__init__() did not set stderr properly'
    env.log_error('hello world', 'error')
    assert env.stderr.getvalue() == '\nhttp.py: error: hello world\n\n', \
        'Environment.log_error() did not output the correct string'



# Generated at 2022-06-23 19:03:07.270971
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    # initialization
    my_Env = Environment()
    # testing result
    assert repr(my_Env) == '<Environment {\'colors\': 256, \'config\': <httpie.config.Config {}>, \'stderr\': <httpie.output.writers.StdErrOutputWriterEchoModes>, \'stderr_encoding\': \'uft8\', \'stderr_isatty\': True, \'stdin\': <_io.BufferedReader name=0>, \'stdin_encoding\': \'utf8\', \'stdin_isatty\': True, \'stdout\': <_io.TextIOWrapper encoding=\'utf8\'>, \'stdout_encoding\': \'utf8\', \'stdout_isatty\': True}>'
    return True


# Unit

# Generated at 2022-06-23 19:03:10.842071
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None)
    print(env)
    assert env.stdin is None
    assert env.stdin_isatty is False
    assert env.stdin_encoding is None
    assert not env.is_windows
    env = Environment(stdout_encoding='latiny')
    print(env)
    assert env.stdout_encoding == 'latiny'

# Generated at 2022-06-23 19:03:18.631382
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import StringIO

    class DevNull:
        def __init__(self):
            self.value = ""

        def write(self, value):
            self.value += value

    actual_stderr = StringIO()
    devnull = DevNull()
    env = Environment(
        stderr=actual_stderr,
        stdin=None,
        stdout=None,
        devnull=devnull
    )

    env.log_error(msg="test_log_error", level="warning")
    assert devnull.value == "\nhttp: warning: test_log_error\n\n"


env = Environment()

# Generated at 2022-06-23 19:03:25.167913
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env._orig_stderr = io.StringIO()

    env.log_error('test msg', level='error')
    assert env._orig_stderr.getvalue() == '\nhttp: error: test msg\n\n'

    env._orig_stderr = io.StringIO()

    env.log_error('test msg', level='warning')
    assert env._orig_stderr.getvalue() == '\nhttp: warning: test msg\n\n'


# Generated at 2022-06-23 19:03:29.970990
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    # Check the environment class is returned as expected
    env = Environment()
    env_dict = dict(env.__dict__)
    env_dict.pop('_orig_stderr')
    env_dict.pop('_devnull')
    assert env.__str__() == repr_dict(env_dict)

# Generated at 2022-06-23 19:03:38.961643
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert isinstance(env.stdin, IO)
    assert isinstance(env.stdout, IO)
    assert isinstance(env.stderr, IO)
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.program_name == 'http'


# Generated at 2022-06-23 19:03:43.323694
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()

# Generated at 2022-06-23 19:03:52.906649
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert isinstance(env, Environment)
    assert isinstance(env.config_dir, Path)
    assert isinstance(env.stdin,IO)
    assert isinstance(env.stdin_isatty,bool)
    assert isinstance(env.stdin_encoding,str)
    assert isinstance(env.stdout,IO)
    assert isinstance(env.stdout_isatty,bool)
    assert isinstance(env.stdout_encoding,str)
    assert isinstance(env.stderr,IO)
    assert isinstance(env.stderr_isatty,bool)
    assert isinstance(env.colors,int)
    assert isinstance(env.program_name,str)

# Generated at 2022-06-23 19:04:04.901116
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from httpie import __version__
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.utils import Version
    from httpie import config
    from pytest import raises
    from pathlib import Path
    from tempfile import TemporaryFile
    from typing import IO
    from io import TextIOWrapper
    from io import BytesIO

    # 1. Environment with default value
    env = Environment()
    env_str = str(env)

# Generated at 2022-06-23 19:04:13.098415
# Unit test for constructor of class Environment
def test_Environment():
    
    # Assert that all defaults from the class are here with no added variables
    environment_test_config = Environment()
    assert len(environment_test_config.__dict__) == len(Environment.__dict__)
    assert len(environment_test_config.__dict__) > 0

    # Assert that variables can be overwritten
    environment_test_config = Environment(stdout='test')
    assert environment_test_config.stdout == 'test'

    # Assert that __str__ and __repr__ work
    assert str(environment_test_config) != 'test'
    assert repr(environment_test_config) != 'test'

    # Assert that devnull works
    assert environment_test_config.devnull != None

    # Assert that log_error works

# Generated at 2022-06-23 19:04:23.067795
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.stdin_isatty
    assert env.stdout_isatty
    assert not env.stderr_isatty
    assert env.config_dir == Path.home() / '.config/httpie'
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == type(sys.stdin).encoding
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == type(sys.stdout).encoding
    assert env.stderr_isatty == sys.stderr.isatty()

if __name__ == "__main__":
    test_Environment()

# Generated at 2022-06-23 19:04:25.410764
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    assert repr(env) == '<Environment {}>'


# Generated at 2022-06-23 19:04:28.502800
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    msg = 'test error'
    try_to_log = env.log_error(msg, 'error')
    assert try_to_log

# Generated at 2022-06-23 19:04:32.710568
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    stderr = io.StringIO()
    env = Environment(stderr=stderr)
    env.log_error("message")
    assert stderr.getvalue().strip() == "http: error: message"


# Generated at 2022-06-23 19:04:35.462466
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    assert str(Environment()) == 'http'
    assert str(Environment(program_name='httpie')) == 'httpie'



# Generated at 2022-06-23 19:04:37.644830
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    print(env)

# Generated at 2022-06-23 19:04:47.668101
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    actual = Environment()

# Generated at 2022-06-23 19:04:55.264405
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from unittest.mock import Mock
    from httpie import ExitStatus
    from httpie import ExitStatus
    from httpie.cli.argtypes import KeyValueArg
    from httpie.plugins import plugin_manager
    from httpie.plugins import builtin

    #  test for unit test: method log_error of class Environment
    env =Environment()
    env.stdout = Mock()
    env.stderr = Mock()
    env.stdin = Mock()
    env._devnull = Mock()
    env._orig_stderr =Mock()
    env.stdin_isatty =False
    env.stdout_isatty =False
    env.stderr_isatty =False
    env.stdin_encoding ='utf8'
    env.stdout_encoding ='utf8'


# Generated at 2022-06-23 19:04:55.984943
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    print(SysEnv())


# Generated at 2022-06-23 19:05:08.904991
# Unit test for constructor of class Environment
def test_Environment():
    import io
    from httpie.compat import is_bytes
    from httpie.utils import learn_encoding
    from httpie.output.streams import write_raw_chunk
    from httpie.output.streams import get_encoded_chunks

    # Test File-like io.BytesIO
    bytes_io = io.BytesIO()
    env = Environment(stdin=bytes_io)
    assert isinstance(env.stdin, io.BytesIO)
    assert env.stdin_isatty is False

    # Test File-like io.StringIO
    str_io = io.StringIO()
    env = Environment(stdin=str_io)
    assert isinstance(env.stdin, io.StringIO)
    assert env.stdin_isatty is False

    # Test devnull
    env

# Generated at 2022-06-23 19:05:20.289723
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    e = Environment(
        is_windows=False,
        config_dir=Path("/home/mainuser/.config/httpie"),
        stdin=sys.stdin,
        stdin_isatty=False,
        stdin_encoding=None,
        stdout=sys.stdout,
        stdout_isatty=True,
        stdout_encoding="utf-8",
        stderr=sys.stderr,
        stderr_isatty=True,
        program_name="http",
        devnull=None
    )

# Generated at 2022-06-23 19:05:23.635497
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment(foo='bar')
    assert env.__repr__() == "<Environment {'foo': 'bar', 'program_name': 'http'}>"


# Generated at 2022-06-23 19:05:35.056954
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    print("Unit test for method __str__ of class Environment")
    # arrange

# Generated at 2022-06-23 19:05:44.093551
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(
        config_dir=Path('/etc/config'),
        colors=20,
        devnull=None,
        is_windows=False,
        program_name='http',
        stderr=sys.stderr,
        stdin=sys.stdin,
        stdout=sys.stdout,
    )
    assert str(env) == str(
        {
            'config': None,
            'config_dir': Path('/etc/config'),
            'colors': 20,
            'is_windows': False,
            'program_name': 'http'
        }
    )



# Generated at 2022-06-23 19:05:49.081405
# Unit test for constructor of class Environment
def test_Environment():
    stdout_isatty, stderr_isatty=True, True
    e = Environment(stdout_isatty=stdout_isatty, stderr_isatty=stderr_isatty)
    assert e.stdout_isatty == stdout_isatty
    assert e.stderr_isatty == stderr_isatty


# Generated at 2022-06-23 19:05:59.022926
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    # Test cases
    class testCase:
        def __init__(self, input, expected):
            self.input = input
            self.expected = expected

    # Create test cases

# Generated at 2022-06-23 19:06:10.677175
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()

# Generated at 2022-06-23 19:06:14.908939
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    class MyEnvironment(Environment):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)

    MyEnvironment(a=1, b=2).__str__()
    MyEnvironment(a=1, b=2).__str__()

# Generated at 2022-06-23 19:06:26.157606
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(config_dir="config_dir")
    string = str(env)

# Generated at 2022-06-23 19:06:33.641982
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    if env.stdin is not None:
        assert env.stdin == sys.stdin
        assert env.stdin_isatty == sys.stdin.isatty()
    else:
        assert env.stdin_isatty == False
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
   

# Generated at 2022-06-23 19:06:40.659168
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    class C(Environment):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    assert str(C(a=1, b=2, c=3)) == "{'a': 1, 'b': 2, 'c': 3}"
    assert str(C(a=1, b=2, c=3, _c=4)) == "{'a': 1, 'b': 2, 'c': 3}"

# Generated at 2022-06-23 19:06:42.844520
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment(devnull=False)
    assert env.log_error, "Error log function of Environment is not working!"

# Generated at 2022-06-23 19:06:51.605812
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    e = Environment()
    assert e.__repr__() == "<Environment {'is_windows': False, 'config_dir': PosixPath('/home/alberto/.config/httpie'), 'stdin': <_io.TextIOWrapper encoding='UTF-8'>, 'stdin_isatty': True, 'stdin_encoding': 'UTF-8', 'stdout': <_io.TextIOWrapper encoding='UTF-8'>, 'stdout_isatty': True, 'stdout_encoding': 'UTF-8', 'stderr': <_io.TextIOWrapper encoding='UTF-8'>, 'stderr_isatty': True, 'colors': 256, 'program_name': 'http', 'config': {'__meta__': {}, 'style': 'paraiso-dark'}}>"

# Generated at 2022-06-23 19:06:56.940438
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from httpie.client import Environment as ClientEnvironment
    from httpie.core import Environment as CoreEnvironment

    env = CoreEnvironment(devnull=1)
    assert str(env) == "{\'devnull\': 1}"

    env = ClientEnvironment(devnull=1)
    assert str(env) == "{\'devnull\': 1}"

# Generated at 2022-06-23 19:07:03.688644
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from httpie.core import exit_status
    env = Environment()
    env.stderr = StringIO()
    env.log_error('error')
    assert env.stderr.getvalue() == '\nhttp: error: error\n\n'
    env.log_error('warning', level='warning')
    assert env.stderr.getvalue() == '\nhttp: error: error\n\n\nhttp: warning: warning\n\n'
    try:
        env.log_error('error', level='unknown')
    except AssertionError:
        pass
    else:
        assert False
    assert exit_status == 0

test_Environment_log_error()

# Generated at 2022-06-23 19:07:11.087372
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    assert repr_dict({}) == '{}'
    assert repr_dict({"username": "root", "password": "toor"}) == '{username=root, password=toor}'
    assert repr_dict({"username": "admin", "password": "12345"}) != '{username=root, password=toor}'
    assert repr_dict({"username": "root", "password": "toor"}) != '{username=root, password=toor}'


if __name__ == '__main__':
    test_Environment___str__()

__all__ = ('Environment',)

# Generated at 2022-06-23 19:07:12.609056
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    assert str(env) == str(env.__dict__)


# Generated at 2022-06-23 19:07:17.910467
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(is_windows = False, config_dir = "httpie", stdin = sys.stdin, 
                        stdin_encoding = "utf8", stdout = sys.stdout, stdout_encoding = "utf8", 
                        stderr = sys.stdout, stderr_isatty = True)


# Generated at 2022-06-23 19:07:28.389555
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(program_name="test_Environment", config_dir="/test_Environment",
        stdin=None, stdin_isatty=False, stdin_encoding=None, stdout=None, stdout_isatty=False,
        stdout_encoding=None, stderr=None, stderr_isatty=False, colors=256, config=None,
        is_windows=False, _orig_stderr=None, _devnull=None)

# Generated at 2022-06-23 19:07:35.885846
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    def clear():
        sys.stderr.truncate(0)
        sys.stderr.seek(0)
        sys.stderr.write("")

    sys.stderr = open(os.devnull, "w")


# Generated at 2022-06-23 19:07:46.089856
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    """
    >>> import sys
    >>> env = Environment(stdin=None)
    >>> env
    <Environment {'colors': 256, 'config': <Config {'is_new': True, 'config_dir': None, 'default_options': {}, 'config_path': None}>, ...}>
    >>> env.stdin = sys.stdin
    >>> env.stdout = sys.stdout
    >>> env.stderr = sys.stderr
    >>> env
    <Environment {'colors': 256, 'config': <Config {'is_new': True, 'config_dir': None, 'default_options': {}, 'config_path': None}>, ...}>
    """
    pass


# Generated at 2022-06-23 19:07:48.725184
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert isinstance(env.config_dir, Path)
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.program_name == 'http'

# Generated at 2022-06-23 19:07:53.312303
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    msg = 'This is a random message'
    expected = f'\nhttp: error: {msg}\n\n'
    assert env.log_error(msg) == expected
    assert env.log_error(msg, level='warning') == f'\nhttp: warning: {msg}\n\n'


__all__ = ('Environment',)

# Generated at 2022-06-23 19:07:58.349764
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    class TestEnvironment(Environment):
        stdout = io.StringIO()
        stdin = io.StringIO()
        stderr = io.StringIO()
        def __init__(self):
            pass
    e = TestEnvironment()
    e.log_error("Log Error Message")
    e.log_error("Log Warning Message", level="warning")
    assert "http: error: Log Error Message" in e.stderr.getvalue()
    assert "http: warning: Log Warning Message" in e.stderr.getvalue()

# Generated at 2022-06-23 19:08:03.519560
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from httpie.config import DefaultConfig
    from httpie.output.streams import DefaultEnvironment
    from httpie.input.streams import DefaultStreams
    env = Environment(**DefaultEnvironment().__dict__,
                      config=DefaultConfig())

    # there is no need to test all the values,
    # just a few to check if __str__ works
    assert env.__str__().__len__() > 0

# Generated at 2022-06-23 19:08:07.618585
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    from httpie.context import Environment
    assert repr(Environment()) == '<Environment {}>'

    assert repr(Environment(foo='bar')) == "<Environment {'foo': 'bar'}>"


# Generated at 2022-06-23 19:08:17.858099
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    import sys
    import os
    import pathlib
    try:
        import curses
    except ImportError:
        curses = None  # Compiled w/o curses
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_CONFIG_DIR, Config
    from httpie.utils import repr_dict
    from httpie.streams import StdoutBytesIO
    from httpie.status import ExitStatus
    from httpie.cli.config import ConfigDirectoryMixin
    from httpie.cli.abc import Configurable
    from httpie.cli.config_dir import ConfigDir
    from httpie.cli.invocation import Invocation
    from httpie.cli.terminal import Terminal
    from httpie.cli.exceptions import UsageError
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPD

# Generated at 2022-06-23 19:08:23.539545
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdin_isatty=False, stdin_encoding='utf8',
                stdout=sys.stdout, stdout_isatty=True, stdout_encoding='utf8',
                stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http',
                devnull=None,)
    print(env)
    print(env.stdout_encoding)

if __name__ == "__main__":
    test_Environment()