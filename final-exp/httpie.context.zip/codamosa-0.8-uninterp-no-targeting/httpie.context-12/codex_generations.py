

# Generated at 2022-06-21 13:40:07.119553
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    from httpie.utils import strip_ansi
    from httpie.compat import isatty
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.output import BINARY_SUPPRESSED_NOTICE
    from httpie.compat import pyver
    env = Environment()
    actual = env.__repr__()

# Generated at 2022-06-21 13:40:15.796529
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == Environment.is_windows
    assert env.config_dir == Environment.config_dir
    assert env.stdin == Environment.stdin
    assert env.stdout == Environment.stdout
    assert env.stderr == Environment.stderr
    assert env.program_name == Environment.program_name

    env._config = Config()
    assert env.config == Config()

    env._orig_stderr = None
    assert env._orig_stderr is None

    env._devnull = None
    assert env._devnull is None

# Generated at 2022-06-21 13:40:18.484209
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    assert env.__str__() == f'<Environment {{{env}}}>'

# Generated at 2022-06-21 13:40:30.177505
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    import os
    import uuid
    import fcntl
    with open(os.devnull, 'w+') as DEVNULL:
        try:
            fcntl.ioctl(DEVNULL, None)
        except IOError:
            pass # this can fail if DEVNULL was closed before
        else:
            env = Environment(devnull=DEVNULL)

# Generated at 2022-06-21 13:40:42.898600
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    from json import loads
    from jsonschema import validate
    from jsonschema.exceptions import ValidationError

    env = Environment()
    env_dict_str = env.__repr__().lstrip('<httpie.core.Environment ') \
        .rstrip('>')
    env_dict = loads(env_dict_str)

# Generated at 2022-06-21 13:40:53.318510
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    from httpie import ExitStatus
    from httpie.input import SEP_CREDENTIALS
    from httpie.plugins import PluginManager
    temp_env = Environment()
    temp_env.config_dir = Path(__file__)
    temp_env.stdin = open(__file__)
    temp_env.stdout = temp_env.stdin
    temp_env.stderr = temp_env.stdin
    temp_env.program_name = 'test'
    temp_env.default_options = ['--ignore-stdin']
    temp_env.plugins = PluginManager()
    temp_env.exit_status = ExitStatus.OK
    temp_env.output_options = {'pretty': 'all'}

# Generated at 2022-06-21 13:41:03.512406
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    e = Environment(
        stdin=open(__file__),
        stdin_encoding='utf16',
        stdout=object,
        stdout_encoding='latin1',
        stderr=object,
        program_name='server'
    )
    e.config.load()
    assert '{"colors": 256, "config": …, "is_windows": …, "program_name": "server", "stdin": …, "stdin_encoding": "utf16", "stdout": …, "stdout_encoding": "latin1", "stdout_isatty": false}' == str(e)


# Generated at 2022-06-21 13:41:13.991709
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(is_windows=True, config_dir=DEFAULT_CONFIG_DIR, stdin=sys.stdin, stdin_isatty=sys.stdin.isatty(), stdin_encoding=None, 
    stdout=sys.stdout, stdout_isatty=sys.stdout.isatty(), stdout_encoding=None, 
    stderr=sys.stderr, stderr_isatty=sys.stderr.isatty(), colors=256, program_name='http', _orig_stderr=sys.stderr, 
    _devnull = None, _config = None)
    assert is_windows
    assert config_dir == DEFAULT_CONFIG_DIR
    assert stdin == sys.stdin
    assert stdin_isatty == sys

# Generated at 2022-06-21 13:41:21.775344
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    class MyEnvironment(Environment):
        def __init__(self):
            super().__init__()
            self.a = 1
            self.b = 2

    env = MyEnvironment()
    assert str(env) == '{a: 1, b: 2, colors: 256, is_windows: False, program_name: \'http\', '
    env.a = 3
    assert str(env) == '{a: 3, b: 2, colors: 256, is_windows: False, program_name: \'http\', '


# Generated at 2022-06-21 13:41:27.067997
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    class FakeFile:
        def __init__(self):
            self.str = ''
            self.write = lambda s : self.str.join(s)
    file = FakeFile()
    env = Environment(stderr=file)
    env.log_error('message', level='warning')
    assert file.str == '\nhttp: warning: message\n\n'

# Generated at 2022-06-21 13:41:33.449105
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(is_windows=True)
    assert env.is_windows is True

# Generated at 2022-06-21 13:41:38.662963
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment(stderr=StringIO())
    try:
        raise Exception('test')
    except Exception as e:
        env.log_error(e)

    stderr = env.stderr.getvalue()
    expected_output = f'\n{env.program_name}: error: test\n\n'
    assert stderr == expected_output


# Generated at 2022-06-21 13:41:45.924773
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    console_encoding = 'utf8'
    env = Environment(
        stdin=None,
        stdin_isatty=False,
        stdin_encoding=None,
        stdout=open(os.devnull, 'w'),
        stdout_isatty=True,
        stdout_encoding=console_encoding,
        stderr=open(os.devnull, 'w'),
        stderr_isatty=False,
        colors=88,
    )
    actual = repr(env)

# Generated at 2022-06-21 13:41:56.919531
# Unit test for constructor of class Environment
def test_Environment():
    e1 = Environment(devnull = None, is_windows = True, config_dir = DEFAULT_CONFIG_DIR, stdin = None, stdin_isatty = False, stdin_encoding = None, stdout = sys.stdout, stdout_isatty = True, stdout_encoding = None, stderr = sys.stderr, stderr_isatty = True, colors = 256, program_name = 'http')
    assert e1.is_windows == is_windows
    assert e1.config_dir == DEFAULT_CONFIG_DIR
    assert e1.stdin == None
    assert e1.stdin_isatty == False
    assert e1.stdin_encoding == None
    assert e1.stdout == sys.stdout
    assert e1.stdout_isatty

# Generated at 2022-06-21 13:42:08.380337
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    fake_stdout_StringIO = StringIO()
    fake_stderr_StringIO = StringIO()
    # This is a static method, any instance will do
    env = Environment(devnull=fake_stdout_StringIO, stderr=fake_stderr_StringIO, program_name='Name')
    env.log_error(msg='Test Error Message')

    fake_stdout_StringIO.seek(0)
    fake_stderr_StringIO.seek(0)

    assert fake_stdout_StringIO.read() == ''
    assert fake_stderr_StringIO.read() == '\nName: error: Test Error Message\n\n'
    del fake_stdout_StringIO
    del fake_stderr_StringIO

# Generated at 2022-06-21 13:42:20.045058
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    def check(env, expected_lines: str):
        actual_lines = str(env).splitlines()
        assert len(actual_lines) == len(expected_lines), f'\n' + str(env)
        for actual, expected in zip(actual_lines, expected_lines):
            assert actual == expected


# Generated at 2022-06-21 13:42:25.623577
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    os.getenv()
    defaults = dict(Environment.__dict__)
    actual = dict(defaults)
    # actual.update(env.__dict__)
    # actual['config'] = env.config
    s = dict(str(defaults))
    ss = dict(str(actual))
    # env
    assert s == ss
    # assert s == '<Environment {'
    # assert s == 'stdin: '
    # assert s == "stdin: <_io.TextIOWrapper name='<stdin>' mode='r' encoding=''>"
    # assert s == 'stdin_isatty: '
    # assert s == 'stdout: '
    # assert s == "stdout: <_io.TextIOWrapper name='<stdout>' mode='w' encoding=''>"


# Generated at 2022-06-21 13:42:29.793041
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    environment = Environment()
    msg = 'Bad request'
    level = 'warning'
    actual = environment.log_error(msg, level)
    expected = '\nhttp: warning: Bad request\n\n'
    assert actual == expected

# Generated at 2022-06-21 13:42:39.631783
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(stdin_isatty=False, stdout_isatty=False, stderr_isatty=False, program_name='http', config_dir=DEFAULT_CONFIG_DIR)
    assert str(env) == '{\'config_dir\': \'/Users/abhishek/.config\', \'is_windows\': False, \'program_name\': \'http\', \'config\': <Config directory=\'/Users/abhishek/.config\' color=<autodetect> style=<default> default_options=<default>>, \'stdin_isatty\': False, \'stdout_isatty\': False, \'stderr_isatty\': False}'

# Generated at 2022-06-21 13:42:51.445977
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from httpie.utils import strip_ansi
    from httpie.core import main
    from io import BytesIO
    from httpie.client import Client
    from httpie.output.streams import WriteStream
    from httpie.output.writers import write_error
    from httpie.plugins import plugin_manager
    from httpie.context import Environment, ExitStatus
    env = Environment()
    assert env == Environment()

    # Setup stdout = BytesIO
    # noinspection PyTypeChecker
    env.stdout = BytesIO()

    # Setup WriteStream
    write_stream = WriteStream(isatty=env.stdout_isatty,
                               env=env,
                               color_settings=plugin_manager.color_settings())
    # Setup Client

# Generated at 2022-06-21 13:43:02.397510
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    stderr = io.StringIO()
    env = Environment(stderr=stderr)
    env.log_error('testing', level='warning')
    assert stderr.getvalue() == '\nhttp: warning: testing\n\n'


# Generated at 2022-06-21 13:43:04.401950
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    assert env.__repr__() == '<Environment {...}>'

# Generated at 2022-06-21 13:43:13.437984
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()

# Generated at 2022-06-21 13:43:21.980383
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.stderr_isatty == True
    assert env.stdout_isatty == True
    assert env.stdin_isatty == True
    env2 = Environment(stdout_isatty=False)
    assert env2.stdout_isatty == False
    env3 = Environment(stderr_isatty=False, stdout_isatty=False)
    assert env3.stdout_isatty == False
    assert env3.stderr_isatty == False

# Generated at 2022-06-21 13:43:27.571745
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    # Test Environment Class
    env = Environment()
    stderr = env.stderr
    # set stderr to a null stream
    env.stderr = env.devnull
    env.log_error("test_msg")
    # restore original stderr
    env.stderr = stderr



# Generated at 2022-06-21 13:43:37.629912
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdout=None, stdin=None, stderr=None)
    assert env.stdout is None
    assert env.stdin is None
    assert env.stderr is None

    env = Environment(stdout=None)
    assert env.stdout is not None
    assert env.stdin is not None
    assert env.stderr is not None
    assert env.stdout_isatty is False
    assert env.stdin_isatty is False
    assert env.stderr_isatty is False
    assert env._devnull is None
    assert env._config is None

    env.devnull = 1
    assert env._devnull == 1


# Generated at 2022-06-21 13:43:45.717018
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()

# Generated at 2022-06-21 13:43:57.024743
# Unit test for constructor of class Environment
def test_Environment():
    class MockFile:
        def __init__(self, type='r'):
            self.mode = type
            self.closed = False
            self.encoding = 'utf8'
            self.isatty = False

        def write(self, msg: str):
            pass

        def close(self):
            self.closed = True

    mock_file = MockFile()
    is_windows = True
    mock_stdin = MockFile('r')
    mock_stdout = MockFile('w')
    mock_stderr = MockFile('w')

# Generated at 2022-06-21 13:44:00.247719
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env._orig_stderr = StringIO()
    env.program_name = 'http'
    msg = 'test error message'
    env.log_error(msg, level='error')
    assert env._orig_stderr.getvalue() == '\nhttp: error: test error message\n\n'


# Generated at 2022-06-21 13:44:07.849944
# Unit test for method __str__ of class Environment

# Generated at 2022-06-21 13:44:24.361936
# Unit test for method __repr__ of class Environment

# Generated at 2022-06-21 13:44:26.516215
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    print(Environment())


if __name__ == "__main__":
    test_Environment___str__()

# Generated at 2022-06-21 13:44:30.693166
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.stderr_isatty == True
    assert env.stdin is sys.stdin
    assert env.stdout is sys.stdout
    assert env.colors == 256
    assert env.stdin_encoding == 'UTF-8'

# Generated at 2022-06-21 13:44:32.120819
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    print(str(env))
    {}

# Generated at 2022-06-21 13:44:41.728720
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows in [True, False]
    assert Path == type(env.config_dir)
    assert env.stdin.readable()
    assert hasattr(env, 'stdin_isatty')
    assert env.stdout.writable()
    assert hasattr(env, 'stdout_isatty')
    assert env.stderr.writable()
    assert hasattr(env, 'stderr_isatty')
    assert hasattr(env, 'colors')
    assert 'http' == env.program_name
    assert Config == type(env.config)

test_Environment()

# Generated at 2022-06-21 13:44:43.306527
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    print(env)



# Generated at 2022-06-21 13:44:48.304334
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert env._orig_stderr == sys.stderr

# Generated at 2022-06-21 13:44:54.895315
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    import sys

    def output_of(f):
        stdout = sys.stdout
        stderr = sys.stderr
        try:
            s = io.StringIO()
            sys.stdout = sys.stderr = s
            f()
            sys.stdout.flush()
            return s.getvalue()
        finally:
            sys.stdout = stdout
            sys.stderr = stderr

    env = Environment(program_name='httpie')
    env.stdout_encoding = 'utf8'

    s = output_of(lambda: env.log_error('error message'))
    assert s == '\nhttpie: error: error message\n\n'

    s = output_of(lambda: env.log_error('warning message', 'warning'))


# Generated at 2022-06-21 13:45:05.734506
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin is sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding is None
    assert env.stdout is sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding is None
    assert env.stderr is sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'

if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-21 13:45:14.931438
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.environment import Environment
    from httpie.utils import repr_dict
    ev = Environment()

# Generated at 2022-06-21 13:45:41.191325
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    from httpie.utils import strip_ansi
    from httpie.compat import is_windows
    from colorama import Fore, AnsiToWin32
    env = Environment()

# Generated at 2022-06-21 13:45:45.790945
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    # Test case 1
    env = Environment()
    env.log_error("File Log Error", level='error')
    env.log_error("File Log Warning", level='warning')
    # Test case 2
    env.log_error("File Log Error", level='info')

# Generated at 2022-06-21 13:45:50.542826
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    import sys
    sys.stderr = io.StringIO()  # Reset stderr to a buffer
    e = Environment()
    e.log_error('just a test')

    assert str(sys.stderr.getvalue()) == '\nhttp: error: just a test\n\n'
    assert type(sys.stderr.getvalue()) == str



# Generated at 2022-06-21 13:45:59.668982
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(stdin=None, stdout=sys.stdout, stderr=sys.stdout, stdin_encoding='stdin_encoding', stdout_encoding='stdout_encoding')
    env.config_dir = 'actual'
    env._config = Config(directory=env.config_dir)
    env._devnull = sys.stdout
    env._orig_stderr = sys.stdout
    env.program_name = 'program_name'
    env.colors = 24
    env.colors = 24

# Generated at 2022-06-21 13:46:11.602918
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    import tempfile

    stdin = tempfile.TemporaryFile('w+')
    stdout = tempfile.TemporaryFile('w+')
    stderr = tempfile.TemporaryFile('w+')

    env = Environment(
        config_dir='~/.config/httpie',
        stdin=stdin,
        stdin_isatty=True,
        stdin_encoding='utf8',
        stdout=stdout,
        stdout_isatty=True,
        stdout_encoding='utf8',
        stderr=stderr,
        stderr_isatty=True,
        colors=256,
        program_name='http'
    )
    assert type(env) is Environment

    stdin.write(u'GET\n')
    stdin.seek(0)

# Generated at 2022-06-21 13:46:17.250817
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    assert repr(Environment(stdin=sys.stdin, follow=True, check_status=True)) \
           == "Environment(follow=True, check_status=True, stdin=sys.stdin, stdin_isatty=True, stdin_encoding='cp932')"

if __name__ == '__main__':
    import doctest

    doctest.testmod()
    test_Environment___repr__()

# Generated at 2022-06-21 13:46:24.005073
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import contextlib
    from httpie import Environment
    from httpie.utils import get_response_stream, get_request_item_stream
    from httpie.plugins.output.streams import is_tty
    from httpie.status import ExitStatus
    from httpie import ExitStatus


    env = Environment()

    assert is_tty(env.stdout)

    with get_request_item_stream(env) as request_item_stream:
        assert not is_tty(request_item_stream)

    with get_response_stream(env, ExitStatus.OK) as response_stream:
        assert is_tty(response_stream)

    assert env.stdout_isatty
    assert env.stderr_isatty


# Generated at 2022-06-21 13:46:36.333055
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    e = Environment()

# Generated at 2022-06-21 13:46:39.338228
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=open("/dev/null"))
    assert env.stdin.closed
    assert env.stdout.closed
    env.close()



# Generated at 2022-06-21 13:46:46.686352
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    environment = Environment()
    from io import StringIO
    import sys
    orig_stderr = sys.stderr
    def reset_stderr():
        sys.stderr = orig_stderr
    try:
        sio = StringIO()
        sys.stderr = sio
        environment.log_error("message")
        sio.seek(0)
        assert sio.read() == r"""
http: error: message

"""
    finally:
        reset_stderr()
    reset_stderr()

# Generated at 2022-06-21 13:47:30.797053
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(True)
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()


if __name__ == '__main__':
    print(test_Environment.__doc__)
    test_Environment()
    print('Done')

# Generated at 2022-06-21 13:47:32.945200
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error('Some message', level='error')


# Generated at 2022-06-21 13:47:36.861479
# Unit test for constructor of class Environment
def test_Environment():
    from httpie.client import TestEnvironment
    env = TestEnvironment()
    assert (env.stdout == sys.stdout) is False
    assert (env.stdout.buffer == sys.stdout.buffer) is True

# Generated at 2022-06-21 13:47:40.247311
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    """Unit test for method __repr__ of class Environment"""
    env = Environment()
    assert repr(env).__contains__(f"<{type(env).__name__}")

# Generated at 2022-06-21 13:47:49.740511
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    import sys
    import os
    from pathlib import Path
    from typing import IO, Optional


    try:
        import curses
    except ImportError:
        curses = None  # Compiled w/o curses

    from httpie.compat import is_windows
    from httpie.config import DEFAULT_CONFIG_DIR, Config, ConfigFileError

    from httpie.utils import repr_dict

    is_windows: bool = is_windows
    config_dir: Path = DEFAULT_CONFIG_DIR
    stdin: Optional[IO] = sys.stdin  # `None` when closed fd (#791)
    stdin_isatty: bool = stdin.isatty() if stdin else False
    stdin_encoding: str = None
    stdout: IO = sys.stdout
    stdout_isat

# Generated at 2022-06-21 13:47:51.667051
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    assert env.__repr__() == '<Environment {}>'

# Generated at 2022-06-21 13:47:55.933885
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    # Initialize env
    env = Environment()

    # Get the string representation of the object
    str_representation = env.__str__()
    print(str_representation)


# Generated at 2022-06-21 13:48:06.172202
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    # Scenario: Test for error
    # Given : Test for error
    stdout = sys.stdout
    stderr = sys.stderr
    env = Environment()

    # When : Display error message
    try:
        env.log_error('test error')
    except:
        # Then :
        assert env.stderr == stderr
        assert env.stdout == stdout
    else:
        assert False, 'Expected exception'

    # Scenario: Test for warning
    # Given : Test for warning
    try:
        env.log_error('test Warning', level='Warning')
    except:
        # Then :
        assert env.stderr == stderr
        assert env.stdout == stdout
    else:
        assert False, 'Expected exception'

    # Scenario: Test for

# Generated at 2022-06-21 13:48:17.909751
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(program_name = 'http')

# Generated at 2022-06-21 13:48:29.197782
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment()
    #vars = {'is_windows': is_windows, 'config_dir': DEFAULT_CONFIG_DIR, 'stdin': sys.stdin, 'stdin_isatty': sys.stdin.isatty(), \
    #    'stdin_encoding': sys.stdin.encoding, 'stdout': sys.stdout, 'stdout_isatty': sys.stdout.isatty(), 'stdout_encoding': sys.stdout.encoding, \
    #    'stderr': sys.stderr, 'stderr_isatty': sys.stderr.isatty(), 'colors': 256, 'program_name': 'http'}
    #assert (e.__dict__ == vars)

# Generated at 2022-06-21 13:49:54.523822
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=False, config_dir=".httpie", stdin=None, stdin_isatty=False,
                      stdout_encoding=None, stdout=sys.stdout, stdout_isatty=True, stderr=sys.stderr,
                      stderr_isatty=True, colors=8, program_name='http', stdin_encoding=None)
    env.config_dir = "~/.httpie"
    assert env.config_dir == "~/.httpie"