

# Generated at 2022-06-21 13:39:55.413372
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    s = Environment().log_error("hello")
    assert s == 'http: error: hello'


# Generated at 2022-06-21 13:40:00.658745
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    import unittest.mock as mock
    env = Environment(stderr=mock.MagicMock())
    env.stderr.write = mock.Mock()
    env.log_error('test log error', level='warning')
    env.stderr.write.assert_called_once_with(
        '\nhttp: warning: test log error\n\n')

# Generated at 2022-06-21 13:40:10.918051
# Unit test for method __str__ of class Environment

# Generated at 2022-06-21 13:40:14.473536
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    assert repr(env) == '<Environment {}>'
    env = Environment(devnull='a')
    assert repr(env) == '<Environment {devnull: a}>'

# Generated at 2022-06-21 13:40:23.695283
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    assert repr(Environment()) == '<Environment {}>'
    e = Environment(stdin_isatty=1)
    assert repr(e) == '<Environment {\'stdin_isatty\': True}>'
    e.stdin_isatty = False
    assert repr(e) == '<Environment {\'stdin_isatty\': False}>'
    e.colors = 16
    assert repr(e) == '<Environment {\'stdin_isatty\': False, \'colors\': 16}>'


# Generated at 2022-06-21 13:40:27.847059
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env=Environment()
    env.config_dir=None
    env.stdin_encoding='utf8'
    env.stdout_encoding='utf8'
    print(env)


# Generated at 2022-06-21 13:40:32.440208
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    """
    Test if log_error function logs a message with given level at the stderr.
    """
    e = Environment()
    e._orig_stderr = io.StringIO()
    e.program_name = 'test_program'
    e.log_error("test_message", level='test_level')
    expected = """\
test_program: test_level: test_message
"""
    assert e._orig_stderr.getvalue() == expected

# Generated at 2022-06-21 13:40:44.429118
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    import sys
    import StringIO
    sout = StringIO.StringIO()
    env = Environment(stdout=sout)

# Generated at 2022-06-21 13:40:48.548499
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    stdin = StringIO()
    stderr = StringIO()
    env = Environment(stdin=stdin, stderr=stderr)
    print(env)
    assert stdin.getvalue() == ''
    assert stderr.getvalue() == ''



# Generated at 2022-06-21 13:40:52.937290
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    with open('test.log', 'w') as f:
        env.stderr = f
        env.log_error('new error')
        env.log_error('new warning', level='warning')
    with open('test.log') as f:
        assert f.read() == '\nhttp: error: new error\n\n\nhttp: warning: new warning\n\n'
    os.remove('test.log')
# /test_Environment_log_error


# Generated at 2022-06-21 13:41:07.479083
# Unit test for method __str__ of class Environment
def test_Environment___str__():

    # Environment
    environment = Environment(
        is_windows = False,
        config_dir = Path('httpie'),
        stdin = sys.stdin,
        stdin_isatty = sys.stdin.isatty(),
        stdin_encoding = 'utf8',
        stdout = sys.stdout,
        stdout_isatty = sys.stdout.isatty(),
        stdout_encoding = 'utf8',
        stderr = sys.stderr,
        stderr_isatty = sys.stderr.isatty(),
        colors = 256,
        program_name = 'httpie',
    )
    print(environment)

# Generated at 2022-06-21 13:41:17.101601
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from io import StringIO
    from httpie.environment import Environment
    from httpie.compat import is_macos
    import sys
    env = Environment(stdin=sys.stdin, stdin_isatty=sys.stdin.isatty())

# Generated at 2022-06-21 13:41:28.240524
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import StringIO
    from unittest import TestCase
    class Test_Environment_log_error(TestCase):
        def test_error(self):
            env = Environment()
            env.stderr = StringIO()
            env.log_error('this is an error')
            actual_output = env.stderr.getvalue()
            expected_output = '\nhttp: error: this is an error\n\n'
            self.assertEqual(actual_output, expected_output)

        def test_warning(self):
            env = Environment()
            env.stderr = StringIO()
            env.log_error('this is a warning', level='warning')
            actual_output = env.stderr.getvalue()

# Generated at 2022-06-21 13:41:36.899128
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    with Environment(
            config_dir=None,
            stdin=None,
            stdin_isatty=False,
            stdin_encoding=None,
            stdout=None,
            stdout_isatty=False,
            colors=256,
            program_name='http',
            stderr=None
    ) as env:
        env.config_dir = None
        env.devnull = None
        env.is_windows = False
        env.stdin = None
        env.stdin_isatty = False
        env.stdin_encoding = None
        env.stdout = None
        env.stdout_isatty = False
        env.stdout_encoding = None
        env.colors = 256
        env.program_name = 'http'
        env.stderr

# Generated at 2022-06-21 13:41:41.091559
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    assert repr(Environment()) == '<Environment {\'colors\': 256, \'config\': <Config <None>>, \'is_windows\': False, \'program_name\': \'http\', \'stdin_isatty\': True, \'stdout_isatty\': True, \'stderr_isatty\': True}>'

# Generated at 2022-06-21 13:41:53.862528
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    environment = Environment()

# Generated at 2022-06-21 13:42:05.372410
# Unit test for constructor of class Environment
def test_Environment():
    conn = Environment()
    for i in conn.__dict__:
        assert (conn.__dict__[i]) == (Environment.__dict__[i])

    # All Attributes
    assert conn.is_windows == is_windows
    assert conn.config_dir == DEFAULT_CONFIG_DIR
    assert conn.stdin == sys.stdin
    assert conn.stdin_isatty == (sys.stdin.isatty() if sys.stdin else False)
    assert conn.stdin_encoding == (getattr(sys.stdin, 'encoding', None) or 'utf8')
    assert conn.stdout == sys.stdout
    assert conn.stdout_isatty == sys.stdout.isatty()

# Generated at 2022-06-21 13:42:09.166545
# Unit test for constructor of class Environment
def test_Environment():
    # Environment is the only class in this module,
    # so no docstring needed.
    pass

# This function tests the Environment class
# by calling it, with arguments to its constructor.
# This test function has no docstring because it
# is not imported by other modules.

# Generated at 2022-06-21 13:42:12.310713
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(no='yes', yes='no')
    assert env.is_windows == True
    assert env.no == 'yes'
    assert env.yes == 'no'


# Generated at 2022-06-21 13:42:13.917062
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    assert Environment().__repr__() == '<Environment {}>'



# Generated at 2022-06-21 13:42:24.708752
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    """
    Create instance of class Environment.
    No parameters -> default values
    """
    env = Environment()

# Generated at 2022-06-21 13:42:30.481922
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    stderr = io.StringIO()
    env.stderr = stderr
    env.program_name = 'httpie'
    env.log_error('some message')
    expected_log = '\nhttpie: error: some message\n\n'
    assert stderr.getvalue() == expected_log

# Generated at 2022-06-21 13:42:35.640748
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment(
        stdout=sys.stdout, stderr=sys.stderr,
        stdin=sys.stdin
    )
    msg = 'This is an error log.'
    env.log_error(msg)
    assert env.stderr.getvalue() == f'\nhttp: error: {msg}\n\n'

# Generated at 2022-06-21 13:42:42.039877
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    class_dict = dict(type(env).__dict__);
    defaults = {key: value for key, value in class_dict.items() if not key.startswith('_')}
    actual = {key: value for key, value in class_dict.items() if not key.startswith('_')}
    actual['config'] = 'configuration_dict'
    assert str(env) == repr_dict(actual)

# Generated at 2022-06-21 13:42:50.076418
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    assert env._orig_stderr == sys.stderr

    env.stderr = StringIO()
    env.log_error("Error Message")
    assert env.stderr.getvalue() == "http: error: Error Message" + '\n\n'

    env.stderr = StringIO()
    env.log_error("Warning Message", level="warning")
    assert env.stderr.getvalue() == "http: warning: Warning Message" + '\n\n'



# Generated at 2022-06-21 13:42:59.668039
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
  env = Environment()
  assert repr(env) == '<Environment {}>'

# Generated at 2022-06-21 13:43:05.869668
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    stdin = io.StringIO('a')
    stdout = io.StringIO()
    stderr = io.StringIO()
    env = Environment(stdin=stdin, stdout=stdout, stderr=stderr)
    env.log_error("exception", level="warning")
    assert stderr.getvalue() == '\nhttp: warning: exception\n\n'

# Generated at 2022-06-21 13:43:09.597390
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(k1="v1", k2="v2")
    assert env.k1 == "v1"
    assert env.k2 == "v2"

    env2 = Environment()
    assert env2.k1 is None
    assert env2.k2 is None

# Generated at 2022-06-21 13:43:20.797837
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment()
    assert(type(e) is Environment)
    assert(e.is_windows == is_windows)
    assert(e.config_dir == DEFAULT_CONFIG_DIR)
    assert(e.stdin == sys.stdin)
    assert(e.stdin_isatty == sys.stdin.isatty())
    assert(e.stdin_encoding == None)
    assert(e.stdout == sys.stdout)
    assert(e.stdout_isatty == sys.stdout.isatty())
    assert(e.stdout_encoding == None)
    assert(e.stderr == sys.stderr)
    assert(e.stderr_isatty == sys.stderr.isatty())

# Generated at 2022-06-21 13:43:32.861331
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    # Positive tests
    env = Environment(stdin="stdin-value",
                      stdin_isatty="stdin_isatty-value",
                      stdin_encoding="stdin_encoding-value",
                      stdout="stdout-value",
                      stdout_isatty="stdout_isatty-value",
                      stdout_encoding="stdout_encoding-value",
                      stderr="stderr-value",
                      stderr_isatty="stderr_isatty-value",
                      colors="colors-value",
                      program_name="program_name-value",
                      _orig_stderr="_orig_stderr-value",
                      _config="_config-value",
                      _devnull="_devnull-value")


# Generated at 2022-06-21 13:43:53.233755
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_encoding == env.stdin.encoding
    assert env.stdout == sys.stdout
    assert env.stdout_encoding == env.stdout.encoding
    assert env.stderr == sys.stderr
    assert env.stderr_encoding == env.stderr.encoding
    assert env.colors == 256
    if not is_windows:
        if curses:
            try:
                curses.setupterm()
                colors = curses.tigetnum('colors')
            except curses.error:
                pass

# Generated at 2022-06-21 13:44:02.002646
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import StringIO
    stderr = StringIO()
    program_name = 'http_mock'
    env = Environment(stderr=stderr, program_name=program_name)

    env.log_error('error')
    assert stderr.getvalue() == f'\n{program_name}: error: error\n\n'

    env.log_error('warning', level='warning')
    assert stderr.getvalue() == (f'\n{program_name}: error: error\n\n'
                                 f'\n{program_name}: warning: warning\n\n')


# Generated at 2022-06-21 13:44:13.256661
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    """Unit tests for method __repr__ of class Environment"""

    if os.path.isfile(os.path.join(
            os.path.expanduser('~'), '.config', 'httpie', 'config.json')):
        httpie_config_file_exist = True
    else:
        httpie_config_file_exist = False

    if os.path.isfile(os.path.join(
            os.path.expanduser('~'), '.config', 'httpie', 'netrc')):
        httpie_netrc_file_exist = True
    else:
        httpie_netrc_file_exist = False

    if sys.stdin.isatty():
        stdin_isatty = True
    else:
        stdin_isatty = False


# Generated at 2022-06-21 13:44:20.513622
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    stream = io.StringIO()
    env.stderr = stream
    try:
        env.log_error(msg="test error")
        env.log_error(msg="test warning", level="warning")
    finally:
        env.stderr = sys.stderr
    assert "warning" in stream.getvalue()
    assert "error" in stream.getvalue()
    assert stream.getvalue().endswith('\n')


env = Environment()

# Generated at 2022-06-21 13:44:32.669636
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from httpie import ExitStatus
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

    fake_stdin = StringIO()
    fake_stdout = StringIO()
    fake_stderr = StringIO()

# Generated at 2022-06-21 13:44:44.565396
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert isinstance(env, Environment)
    assert env.is_windows == False
    assert isinstance(env.config_dir, Path)
    assert isinstance(env.stdin, IO)
    assert isinstance(env.stdin_isatty, bool)
    assert isinstance(env.stdin_encoding, str)
    assert isinstance(env.stdout, IO)
    assert isinstance(env.stdout_isatty, bool)
    assert isinstance(env.stdout_encoding, str)
    assert isinstance(env.stderr, IO)
    assert isinstance(env.stderr_isatty, bool)
    assert isinstance(env.colors, int)
    assert isinstance(env.program_name, str)


# Generated at 2022-06-21 13:44:50.445961
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import StringIO
    env = Environment(stdout=StringIO(), stderr=StringIO())
    env.log_error("Error_message")
    assert env.stderr.getvalue() == "http: error: Error_message\n\n"
    env.log_error("Warning_message", level="warning")
    assert env.stderr.getvalue()[-22:] == "http: warning: Warning_message\n\n"


# Generated at 2022-06-21 13:45:01.475833
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(devnull='with-devnull', stdin=None, stdin_encoding='utf-8')
    assert 'stdin=None' in str(env)
    assert 'devnull=with-devnull' in str(env)
    assert 'stdin_encoding=utf-8' in str(env)
    assert 'stdin' in str(env)
    assert 'stdout' in str(env)
    assert 'stderr' in str(env)
    assert 'config' in str(env)
    assert 'config_dir' in str(env)
    assert 'is_windows' in str(env)
    assert 'program_name=http' in str(env)
    assert 'colors=256' in str(env)

# Generated at 2022-06-21 13:45:03.690138
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    print(Environment())
    Environment().__repr__()



if __name__ == "__main__":
    test_Environment___repr__()

# Generated at 2022-06-21 13:45:13.339243
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(devnull = 'devnull_value')

# Generated at 2022-06-21 13:45:39.453127
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from . import main
    from .output.streams import Streams as _Streams

    class Streams(_Streams):
        def __init__(self, *args, **kwargs):
            self.err = []
            super(Streams, self).__init__(*args, **kwargs)

        def write_stderr(self, msg):
            self.err.append(msg)

    args = main.Parser().parse_args(['--verbose','--form','key=value','httpbin.org'])

# Generated at 2022-06-21 13:45:41.108667
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env
    assert isinstance(env, Environment)

# Generated at 2022-06-21 13:45:46.410250
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import StringIO
    from httpie import ExitStatus

    output = StringIO.StringIO()

    env = Environment(stderr=output)
    env.log_error('Oops')


# Generated at 2022-06-21 13:45:49.250201
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    myenv = Environment()
    assert myenv.log_error("message", level="error") is None
    assert myenv.log_error("message", level="warning") is None
    return None



# Generated at 2022-06-21 13:45:50.362598
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    environment = Environment()
    assert '<Environment' in repr(environment)

# Generated at 2022-06-21 13:45:59.527029
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment(
        is_windows=False,
        program_name='http',
        config_dir=DEFAULT_CONFIG_DIR,
        devnull=open(os.devnull, 'w+'),
        stdin=sys.stdin,
        stdin_isatty=False,
        stdin_encoding='utf8',
        stdout=sys.stdout,
        stdout_isatty=False,
        stdout_encoding='utf8',
        stderr=sys.stderr,
        stderr_isatty=False
        )

# Generated at 2022-06-21 13:46:01.876791
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    environment = Environment()
    print(repr(environment))

test_Environment___repr__()

# Generated at 2022-06-21 13:46:13.400345
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.config import Config
    from httpie.utils import repr_dict
    from httpie.core.environment import Environment

    from pytest import raises

    # Instantiate an environment object

# Generated at 2022-06-21 13:46:14.573534
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error('test')


# Generated at 2022-06-21 13:46:20.654105
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    err_msg = 'This is an error log'
    warn_msg = 'This is a warning log'
    env = Environment()
    env.log_error(err_msg)
    env.log_error(warn_msg, level='warning')
    assert env._orig_stderr.getvalue().startswith(f'\n{env.program_name}: error: ')
    assert env._orig_stderr.getvalue().endswith(f'\n\n{env.program_name}: warning: {warn_msg}\n\n')

# Generated at 2022-06-21 13:47:03.034807
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    import sys
    env = Environment()
    old_stderr = sys.stderr
    sys.stderr = io.StringIO()
    try:
        env.log_error('error message')
        env.log_error(EnvironmentError('error message'), level='warning')

        stderr = sys.stderr.getvalue()
        assert stderr == '''\

http: error: error message

http: warning: error message

'''
    finally:
        sys.stderr = old_stderr


env = Environment()

# Generated at 2022-06-21 13:47:10.823604
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import StringIO

    def assert_in(needle, haystack):
        assert needle in haystack, f'{needle} not in {haystack}'

    environment = Environment()
    for level in ['error', 'warning']:
        for msg in ['test error', 'test error msg']:
            output = StringIO()
            environment.stderr = output
            environment.log_error(msg, level=level)
            assert_in(level, output.getvalue())
            assert_in(msg, output.getvalue())
            output.close()

# Generated at 2022-06-21 13:47:20.396675
# Unit test for method __str__ of class Environment

# Generated at 2022-06-21 13:47:31.603638
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    e1 = Environment()

# Generated at 2022-06-21 13:47:43.377242
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    # ----------
    env = Environment()

# Generated at 2022-06-21 13:47:52.963665
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin = 1, stdout = 2, stderr = 3, stdin_isatty = True, stdout_isatty = True, stderr_isatty = True, stdin_encoding = 'abc', stdout_encoding = 'def', stderr_encoding = 'hij', is_windows = False)

# Generated at 2022-06-21 13:48:04.452883
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    devnull = open('/dev/null', 'w+')
    env = Environment(stdin=devnull, stdout=devnull, stderr=devnull, config_dir='./')
    assert str(env.config) == '<Config {\'directory\': \'.\'}>'
    assert repr(env) == '<Environment {\'is_windows\': False, \'config_dir\': \'.\', \'stdin_isatty\': False, \'stdin_encoding\': None, \'stdout_isatty\': False, \'stdout_encoding\': None, \'stderr_isatty\': False, \'colors\': 256, \'program_name\': \'http\', \'config\': <Config {\'directory\': \'.\'}>}>'

environment = Environment()

# Generated at 2022-06-21 13:48:16.145008
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    import sys
    import os
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_CONFIG_DIR, Config, ConfigFileError
    from httpie.utils import repr_dict
    env = Environment()
    if is_windows:
        import colorama.initialise
        env.stdout = colorama.initialise.wrap_stream(
            env.stdout, convert=None, strip=None,
            autoreset=True, wrap=True
        )
        env.stderr = colorama.initialise.wrap_stream(
            env.stderr, convert=None, strip=None,
            autoreset=True, wrap=True
        )
        del colorama
    env.stdin = sys.stdin
    env.stdin_encoding = env.stdin.encoding

# Generated at 2022-06-21 13:48:27.377203
# Unit test for constructor of class Environment
def test_Environment():

    e1 = Environment()

    assert e1.is_windows == is_windows
    assert e1.stdout.name == '<stdout>'
    assert e1.stdin.name == '<stdin>'
    assert e1.stderr.name == '<stderr>'
    assert e1.program_name == 'http'


# Generated at 2022-06-21 13:48:34.302935
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        is_windows=True,
        config_dir='/config/directory',
        stdin=None,
        stdin_encoding='utf-16',
        stdout=open('/tmp/stdout', 'wb'),
        stdout_encoding='utf-8',
        stderr=open('/tmp/stderr', 'wb'),
        stderr_encoding='utf-8',
        colors=256,
        program_name='httpie'
    )
    assert env.is_windows == True
    assert str(env.config_dir) == '/config/directory'
    assert env.stdin == None
    assert env.stdin_encoding == 'utf-16'
    assert str(env.stdout) == '/tmp/stdout'
    assert env.stdout_encoding