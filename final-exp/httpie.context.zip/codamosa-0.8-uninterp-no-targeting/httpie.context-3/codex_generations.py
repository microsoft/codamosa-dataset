

# Generated at 2022-06-21 13:39:55.372694
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error('log_error function works')
    assert True

# Generated at 2022-06-21 13:39:58.613358
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.stdin is sys.stdin
    assert env.stdout is sys.stdout
    assert env.stderr is sys.stderr
    assert env.stderr is sys.stderr

# Generated at 2022-06-21 13:40:08.207324
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    import unittest

    class TestEnvironment(unittest.TestCase):

        # Tests if the method log_error writes the correct message
        def test_log_error(self):
            stderr = io.StringIO()
            env = Environment(
                stderr=stderr
            )
            env.log_error(
                msg='Error: Problem with Config File',
                level='warning'
            )
            self.assertEqual(
                stderr.getvalue(),
                '\nhttp: warning: Error: Problem with Config File\n\n'
            )
    
    unittest.main()


env = Environment()

# Generated at 2022-06-21 13:40:20.458637
# Unit test for method __str__ of class Environment

# Generated at 2022-06-21 13:40:31.474606
# Unit test for constructor of class Environment
def test_Environment():
    test = Environment()
    assert isinstance(test, Environment)
    assert repr(test) == '<Environment {colors=256, config=<Config {}, config_dir=<Path {~/.config/httpie}>, is_windows=False, program_name=http, stderr=<open file \'<stderr>\'>, stderr_encoding=None, stderr_isatty=True, stdin=<open file \'<stdin>\'>, stdin_encoding=None, stdin_isatty=True, stdout=<open file \'<stdout>\'>, stdout_encoding=UTF-8, stdout_isatty=True}>'

# Generated at 2022-06-21 13:40:36.993546
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env._orig_stderr = io.StringIO()
    env.program_name = 'http'
    env.log_error('msg')
    assert str(env._orig_stderr.getvalue()) == "http: error: msg"

# Generated at 2022-06-21 13:40:39.787211
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(colors=128, program_name='http')
    assert env.colors == 128
    assert env.program_name == 'http'


# Generated at 2022-06-21 13:40:50.962587
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(stdin_encoding='stdin_encoding',
                      stdout_encoding='stdout_encoding')
    assert env.__str__() == '''{colors: 256, config: None, is_windows: False, stdin: <httpie.clipboard.Clipboard object at 0x7fb6c24d6ba8>, stdin_encoding: 'stdin_encoding', stdin_isatty: False, stdout: <httpie.clipboard.Clipboard object at 0x7fb6c24d6ba8>, stdout_encoding: 'stdout_encoding', stdout_isatty: False, stderr: <_io.TextIOWrapper name=2 mode='w' encoding='utf-8'>, stderr_isatty: True}'''

#

# Generated at 2022-06-21 13:40:57.249560
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    msg = "msg"
    env.log_error(msg)
    assert env.stderr.getvalue() == "http: error: msg\n\n"
    env.log_error(msg, level='warning')
    assert env.stderr.getvalue() == "http: error: msg\n\nhttp: warning: msg\n\n"



# Generated at 2022-06-21 13:40:58.722285
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    assert repr(Environment()) == '<Environment {}>'


env = Environment()

# Generated at 2022-06-21 13:41:05.008986
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    assert repr(env) == '<Environment {}>'


env = Environment()

# Generated at 2022-06-21 13:41:11.095503
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    class myEnv(Environment):
        def __init__(self):
            super().__init__()
            self.is_windows = True
            self.program_name = "httpie"
            self.stdin = None
            self.stdin_isatty = False
            self.stdin_encoding = False
            self.stdout = True
            self.stdout_isatty = False
            self.stdout_encoding = False
            self.stderr = True
            self.stderr_isatty = False
            self.stderr_encoding = False
    env = myEnv()

# Generated at 2022-06-21 13:41:19.390920
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty() if sys.stdin else False
    assert env.stdin_encoding == 'cp950' if is_windows else 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stdout_encoding == 'cp950' if is_windows else 'utf8'
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == True
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env

# Generated at 2022-06-21 13:41:21.326058
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment(stderr = os.devnull)
    env.log_error('This is a error')

# Generated at 2022-06-21 13:41:32.118982
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    class A:
        def __init__(self):
            self.x = 1
    a = A()

# Generated at 2022-06-21 13:41:38.377610
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():

    assert str(Environment()) == "\
<Environment colors=256 config=None devnull=None is_windows=False program_name=http stderr_encoding=None stderr_isatty=True stderr=<_io.TextIOWrapper name='<stderr>' mode='w' encoding='utf-8'> stdin_encoding=None stdin_isatty=True stdin=<_io.TextIOWrapper name='<stdin>' mode='r' encoding='utf-8'> stdout_encoding=None stdout_isatty=True stdout=<_io.TextIOWrapper name='<stdout>' mode='w' encoding='utf-8'>>"

# Generated at 2022-06-21 13:41:45.788886
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from httpie.constants import IS_WINDOWS

    env = Environment(
        colors=234,
        config_dir=123,
        is_windows=IS_WINDOWS,
        program_name='PROGRAM NAME',
        stdin=456,
        stdin_encoding='STDIN ENCODING',
        stdin_isatty='STDIN ISATTY',
        stdout=789,
        stdout_encoding='STDOUT ENCODING',
        stdout_isatty='STDOUT ISATTY',
        stderr=0,
        stderr_isatty='STDERR ISATTY',
    )
    # print(str(env))

# Generated at 2022-06-21 13:41:55.835046
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()

    # assert env.__str__() == "<Environment {'is_windows': False, 'config': <Config {}>, 'config_dir': PosixPath('/home/user/.config/httpie'), 'stdin': None, 'stdin_isatty': False, 'stdin_encoding': None, 'stdout': <_io.TextIOWrapper encoding='UTF-8'>, 'stdout_isatty': True, 'stdout_encoding': 'UTF-8', 'stderr': <_io.TextIOWrapper encoding='UTF-8'>, 'stderr_isatty': True, 'colors': 256, 'program_name': 'http'}>"

# Generated at 2022-06-21 13:42:07.926406
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    from httpie.context import Environment
    from httpie.config import __config__
    env = Environment()

# Generated at 2022-06-21 13:42:19.659221
# Unit test for method __repr__ of class Environment

# Generated at 2022-06-21 13:42:34.057082
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    assert str(Environment(config_dir='c:\test')) == '{config_dir=\'c:\\test\', colors=256, is_windows=True, program_name=\'http\', stderr=<_io.TextIOWrapper encoding=\'utf-8\'>, stderr_isatty=False, stdin=<_io.TextIOWrapper encoding=\'cp936\'>, stdin_isatty=True, stdin_encoding=\'cp936\', stdout=<_io.TextIOWrapper encoding=\'utf-8\'>, stdout_encoding=\'utf-8\', stdout_isatty=True}'

# Generated at 2022-06-21 13:42:45.661082
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    template = '''
{{
    "colors": {colors},
    "config": {config},
    "config_dir": "{config_dir}",
    "is_windows": {is_windows},
    "program_name": "{program_name}",
    "stdin": {stdin},
    "stdin_encoding": "{stdin_encoding}",
    "stdin_isatty": {stdin_isatty},
    "stdout": {stdout},
    "stdout_encoding": "{stdout_encoding}",
    "stdout_isatty": {stdout_isatty}
}}
'''.strip()
    config_dir = '.'

    def type_str(o):
        if isinstance(o, str):
            return repr(o)

# Generated at 2022-06-21 13:42:56.295599
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    def assert_str(name, value, attr_name=None):
        attr_name = attr_name or name
        assert f'{name}: {value!r}' in str(env)
        assert (str(getattr(env, attr_name)) ==
                str(getattr(env_defaults, attr_name)))
    env_defaults = Environment()
    env = Environment(foo='bar', baz=object())
    assert_str('foo', 'bar')
    assert_str('baz', env.baz)

    # Modified attribute.
    env.stdin = object()
    assert_str('stdin', env.stdin, 'stdin')

    # Unmodified attribute.
    assert_str('is_windows', env.is_windows)

# Generated at 2022-06-21 13:43:03.383324
# Unit test for constructor of class Environment
def test_Environment():
    import io
    import sys
    myenv = Environment(devnull=io.StringIO(), stdin=io.StringIO(), stdout=io.StringIO(), stderr=io.StringIO(), program_name='http-test')
    myenv.stdin.write('Hola\n')
    myenv.stdin.seek(0)
    sys.stdout.write(f'_{myenv.stdin.readline()}_')

# Generated at 2022-06-21 13:43:12.797479
# Unit test for constructor of class Environment
def test_Environment():
    from io import StringIO
    from pathlib import Path
    from httpie.core import env
    stdin = StringIO("test\n")
    stdout = StringIO("test\n")
    stderr = StringIO("test\n")
    devnull = StringIO("test\n")
    stdin_encoding = None
    stdout_encoding = None
    stdin_isatty = stdin.isatty()
    stdout_isatty = stdout.isatty()
    stderr_isatty = stderr.isatty()
    colors = env.colors
    config_dir = Path(env.config_dir)
    program_name = str(env.program_name)

# Generated at 2022-06-21 13:43:16.232306
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    print(type(env))
    print(env)
    print(repr(env))

if __name__ == '__main__':
    test_Environment___repr__()

# Generated at 2022-06-21 13:43:24.852795
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.program_name = 'Test'
    # Test with stderr
    env.log_error('Test')
    written = env._orig_stderr.getvalue().decode()
    assert written == '\nTest: error: Test\n\n'
    # Test with stdout
    env.stderr = env.stdout
    env.log_error('Test')
    written = env.stdout.getvalue().decode()
    assert written == '\nTest: error: Test\n\n'

# Generated at 2022-06-21 13:43:36.568711
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    # the first test is to check if the global configuration file exit
    if os.path.exists(Path.home() / '.httpie/config.json') == True:
        print('The global configuration file exist, the test is passed')
    else:
        print('The global configuration file not exist, the test is failed')
    # the second test is to check if the program name is right
    if env.program_name == 'http':
        print('The program name is right, the test is passed')
    else:
        print('The program name is wrong, the test is failed')
    # the third test is to check if the stdin_isatty is right
    if env.stdin_isatty == True:
        print('The stdin_isatty is right, the test is passed')

# Generated at 2022-06-21 13:43:37.180983
# Unit test for constructor of class Environment
def test_Environment():
    Environment()

# Generated at 2022-06-21 13:43:45.459991
# Unit test for method __repr__ of class Environment

# Generated at 2022-06-21 13:43:52.879134
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    assert repr(Environment()) == '<Environment {}>'
    assert repr(Environment(config_dir='/an/other/place')) == "<Environment {'config_dir': PosixPath('/an/other/place')}>"

# Generated at 2022-06-21 13:44:03.309583
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(
        colors = 256,
        config_dir = DEFAULT_CONFIG_DIR,
        is_windows = is_windows,
        program_name = 'http',
        stderr_isatty = stderr_isatty,
        stderr = stderr,
        stdin = stdin,
        stdin_encoding = 'utf8',
        stdin_isatty = stdin_isatty,
        stdout = stdout,
        stdout_encoding = 'utf8',
        stdout_isatty = stdout_isatty,
    )
    str_env = env.__str__()

# Generated at 2022-06-21 13:44:07.025277
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin_encoding='utf8', stdout_encoding='utf8')
    assert env.stdin_encoding == 'utf8'
    assert env.stdout_encoding == 'utf8'

# test Environment.stdout

# Generated at 2022-06-21 13:44:19.408395
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name='http', config_dir='/dev', stdin=None, stdin_isatty=False, stdin_encoding='utf8',
                      stdout=None, stdout_isatty=False, stdout_encoding='utf8', stderr=None, stderr_isatty=False)
    assert env.program_name == 'http'
    assert env.config_dir == Path('/dev')
    assert env.stdin is None
    assert env.stdin_isatty is False
    assert env.stdin_encoding=='utf8'
    assert env.stdout is None
    assert env.stdout_isatty is False
    assert env.stdout_encoding=='utf8'
    assert env.stderr is None
    assert env.stder

# Generated at 2022-06-21 13:44:25.673815
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import sys, tempfile
    from io import StringIO

    env = Environment(stderr=StringIO())
    env.program_name = 'httpie'
    env.log_error('error message')
    assert env.stderr.getvalue() == '\nhttpie: error: error message\n\n'


# Generated at 2022-06-21 13:44:26.275072
# Unit test for constructor of class Environment
def test_Environment():
    Environment()

# Generated at 2022-06-21 13:44:37.207675
# Unit test for method __str__ of class Environment

# Generated at 2022-06-21 13:44:39.369221
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    assert eval(repr(Environment())) == Environment()


# Generated at 2022-06-21 13:44:49.919752
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    print(env)
    env = Environment(stdin='xxx')
    print(env)
    env = Environment(stdin='xxx', stdout='yyy', stderr='zzz')
    print(env)
    env = Environment(stdin='xxx', stdout='yyy', stderr='zzz')
    print(env)
    env = Environment(stdin_isatty=False, stdout_isatty=True, stderr_isatty=False)
    print(env)
    env = Environment(stdin_isatty=False, stdout_isatty=True, stderr_isatty=False)
    print(env)

# Generated at 2022-06-21 13:44:53.206466
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    env.stdout = 'ss'
    assert env.stdout == 'ss'
    env = Environment(stdout='sss')
    assert env.stdout == 'sss'

# Generated at 2022-06-21 13:45:07.871035
# Unit test for method __str__ of class Environment

# Generated at 2022-06-21 13:45:16.072006
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    from unittest.mock import Mock, MagicMock
    from httpie.utils import Path
    from httpie.config import Config
    from httpie.environment import Environment

    # Mocked Attributes
    is_windows = False
    config_dir = Path('/config_dir')
    stdin = Mock()
    stdin_isatty = False
    stdin_encoding = None
    stdout = Mock()
    stdout_isatty = False
    stdout_encoding = None
    stderr = Mock()
    stderr_isatty = False
    colors = 256
    program_name = 'http'

    # Mocked Attributes, properties
    _config = Config(directory=config_dir)
    _devnull = Mock()
    _orig_stderr = stderr


# Generated at 2022-06-21 13:45:20.331007
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    log_error = Environment().log_error
    level_error = 'error'
    level_warning = 'warning'
    with mock.patch('httpie.context.sys.stderr.write') as stdout:
        s = 'error_message'
        log_error(s)
        assert stdout.call_count == 1
        assert (level_error, s) in str(stdout.call_args_list)

        s = 'warning_message'
        log_error(s, level=level_warning)
        assert stdout.call_count == 2
        assert (level_warning, s) in str(stdout.call_args_list)


env = Environment()

# Generated at 2022-06-21 13:45:31.947868
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    import sys
    import tempfile
    import pathlib

    stdin,stdout,stderr = sys.stdin,sys.stdout,sys.stderr
    dummy_stdin = tempfile.TemporaryFile()
    dummy_stdout = tempfile.TemporaryFile()
    dummy_stderr = tempfile.TemporaryFile()


    # test case 1
    env = Environment()
    sys.stdin,sys.stderr,sys.stdout = dummy_stdin,dummy_stderr,dummy_stdout

# Generated at 2022-06-21 13:45:36.559893
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    res = env.log_error('This is an error!')
    assert res is None
    assert env._orig_stderr.write==True
    assert 'This is an error!' in env._orig_stderr.write
    assert 'httpie: error' in env._orig_stderr.write

test_Environment_log_error()

# Generated at 2022-06-21 13:45:39.218767
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.config_dir = ""
    env.log_error("TEST")
    assert env.stderr.getvalue() == "\nhttp: error: TEST\n\n"

# Generated at 2022-06-21 13:45:49.839708
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()

# Generated at 2022-06-21 13:45:54.736466
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    import re
    env = Environment()
    str_ = str(env)
    print(str_)
    print("===================")
    print(repr(env))
    assert re.match("<Environment {.*}>", repr(env))

if __name__ == '__main__':
    test_Environment___str__()

# Generated at 2022-06-21 13:45:56.004692
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error(msg = "Test message", level = "error")
    
test_Environment_log_error()

# Generated at 2022-06-21 13:46:01.564025
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from httpie import output

    class MockStream:
        def __init__(self):
            self.stream = bytearray()
        def write(self, val):
            self.stream.extend(val.encode('utf-8'))

    msg = 'test message'
    s = MockStream()
    output.stream = s
    e = Environment(config_dir=None)
    e.log_error(msg, level='warning')
    assert b'warning' in s.stream
    e.log_error(msg, level='error')
    assert b'error' in s.stream
    assert not e.config.config_dir

# Generated at 2022-06-21 13:46:08.736563
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error("Hello World!")
    env.log_error("Hello World!", level="warning")
    env.log_error("Hello World!", level="error")


# Generated at 2022-06-21 13:46:18.722891
# Unit test for method __str__ of class Environment

# Generated at 2022-06-21 13:46:25.158208
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    class MyEnv(Environment):
        stdout = BytesIO()
        stdin = None
        stderr = BytesIO()
        program_name = 'test'
    myenv = MyEnv()
    myenv.log_error("test_log_error")
    assert myenv.stderr.getvalue().decode("utf-8") == '\ntest: error: test_log_error\n\n'


# Generated at 2022-06-21 13:46:30.346160
# Unit test for method __repr__ of class Environment

# Generated at 2022-06-21 13:46:41.570528
# Unit test for constructor of class Environment
def test_Environment():
    # returns the actual context in which the program is running
    env = Environment()
    print('\n', env)
    assert env
    # python -m httpie.core.environment
    # <Environment {
    # 'is_windows': False,
    # 'config_dir': '$HOME.httpie',
    # 'stderr_isatty': True,
    # 'colors': 256,
    # 'stdin_encoding': 'utf8',
    # 'stdin': <_io.TextIOWrapper name=5 mode='r' encoding='UTF-8'>,
    # 'config': <httpie._compat.Config filename='$HOME.httpie'>,
    # 'stdin_isatty': True,
    # 'program_name': 'http',
    # 'stdout_isatty':

# Generated at 2022-06-21 13:46:53.470224
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    # Prepare and test
    result = env_name.__repr__()
    # Verify

# Generated at 2022-06-21 13:46:58.728304
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    # GIVEN
    class FakeStdErr:
        def write(self, msg):
            self.msg = msg

    stderr = FakeStdErr()
    env = Environment(stderr=stderr)

    # WHEN
    env.log_error("test message", level="warning")

    # THEN
    assert env._orig_stderr is stderr
    assert stderr.msg.strip() == "http: warning: test message"

# Generated at 2022-06-21 13:47:05.813362
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from httpie import ExitStatus
    from httpie.config import Config
    from httpie.compat import is_windows
    from httpie.core import main
    import os
    import sys
    import os.path
    import tempfile
    import pytest
    import httpie.compat

    def create_temp_fds():
        """
        Creates temporary file and its file handler
        to be used as input and output streams

        :return: (input_stream, output_stream)
        """
        fd, temp_file = tempfile.mkstemp()
        if is_windows:
            import msvcrt
            msvcrt.setmode(fd, os.O_BINARY)
        return os.fdopen(fd, 'w+b'), temp_file


# Generated at 2022-06-21 13:47:08.189184
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    e = Environment()
    assert str(e) == str(e.__repr__())


# Generated at 2022-06-21 13:47:12.025862
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.program_name = 'name'
    s = io.StringIO()
    env.stderr = s
    env.log_error('Error')
    assert s.getvalue() == '\nname: error: Error\n\n'

# Generated at 2022-06-21 13:47:28.622582
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    res = env.__str__()  

# Generated at 2022-06-21 13:47:34.111312
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()

# Generated at 2022-06-21 13:47:35.532981
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    assert str(env).startswith('{') == True
    assert str(env).endswith('}') == True
    assert eval(str(env)).get('config') == env.config



# Generated at 2022-06-21 13:47:40.083381
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().config_dir in os.path.expanduser('~')
    assert Environment().stdin_isatty == True
    assert Environment().stdout_isatty == True
    assert Environment().stderr_isatty == True


# Generated at 2022-06-21 13:47:49.635482
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment(is_windows = True, config_dir = DEFAULT_CONFIG_DIR + '/config_dir', stdin = sys.stdin, stdout = sys.stdout, stderr = sys.stderr, colors = 256, program_name = 'http_test', stdin_isatty = True, stdin_encoding = 'utf8', stdout_isatty = True, stdout_encoding = 'utf8', stderr_isatty = True)
    print('test_Environment')
    print('is_windows', e.is_windows)
    print('config_dir', e.config_dir)
    print('stdin', e.stdin)
    print('stdout', e.stdout)
    print('stderr', e.stderr)

# Generated at 2022-06-21 13:47:52.908071
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    class A(Environment):
        pass
    obj = A()
    assert isinstance(repr(obj), str)


# Generated at 2022-06-21 13:48:04.412364
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()

# Generated at 2022-06-21 13:48:07.607172
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().config_dir == DEFAULT_CONFIG_DIR
    assert Environment().stdin_isatty == sys.stdin.isatty()
    assert Environment().stdout_isatty == sys.stdout.isatty()
    assert Environment().stderr_isatty == sys.stderr.isatty()

# Generated at 2022-06-21 13:48:09.899702
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env= Environment()
    env_str=env.__repr__()
    print(env_str)


# Generated at 2022-06-21 13:48:20.980241
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    osName = os.name
    stdin = sys.stdin
    stdout = sys.stdout
    stderr = sys.stderr
    config_dir = os.getcwd()
    env = Environment(os_name=osName, stdin=stdin,
                      stdout=stdout, stderr=stderr,
                      config_dir=config_dir)
    stdin_encoding = env.stdin.encoding
    stdout_encoding = env.stdout.encoding
    stderr_encoding = env.stderr.encoding
    stdin_isatty = sys.stdin.isatty()
    stdout_isatty = sys.stdout.isatty()
    stderr_isatty = sys.stderr.isatty()
    program

# Generated at 2022-06-21 13:48:30.591306
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    e = Environment()
    assert repr(e) == '<Environment {}>'



# Generated at 2022-06-21 13:48:40.374274
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    stdout_buffer = io.StringIO()
    stderr_buffer = io.StringIO()
    env = Environment(stdout=stdout_buffer, stderr=stderr_buffer)
    env.log_error('error_message', level='error')
    env.log_error('warning_message', level='warning')

    assert 'http' == env.program_name
    assert len(stdout_buffer.getvalue().strip()) == 0
    assert 'warning' in stderr_buffer.getvalue().strip()
    assert 'error' in stderr_buffer.getvalue().strip()


environment = Environment()

# Generated at 2022-06-21 13:48:50.583009
# Unit test for constructor of class Environment

# Generated at 2022-06-21 13:48:59.315223
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from httpie.config import Paths
    import os
    import stat
    import tempfile
    import datetime

    Paths.HOMEDIR = '/home/'
    dir_temp = tempfile.mkdtemp()
    os.chown(dir_temp, 10000, 20000)
    file_temp = tempfile.NamedTemporaryFile(dir=dir_temp)
    os.chown(file_temp.name, 30000, 40000)
    os.utime(file_temp.name, (datetime.datetime.utcnow().timestamp(), datetime.datetime.utcnow().timestamp()))
    os.chmod(file_temp.name, stat.S_IRWXU | stat.S_IRWXG | stat.S_IRWXO)
    file_temp.close()

# Generated at 2022-06-21 13:49:05.030576
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    class MyStderr:
        def __init__(self):
            self.log = ''

        def write(self, msg):
            self.log += msg

    e = Environment()
    e._orig_stderr = MyStderr()
    e.log_error('some message')
    assert e._orig_stderr.log == '\nhttp: error: some message\n\n'


environ = Environment()

# Generated at 2022-06-21 13:49:12.618076
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    environment = Environment()
    assert '<Environment {' + \
           "'config': <Config {}>, 'is_windows': " + \
           str(environment.is_windows) + \
           ', \'config_dir\': Path(\'' + str(environment.config_dir) + '\'),' \
            " 'colors': " + str(environment.colors) + \
            ', \'program_name\': ' + str(environment.program_name) + \
            '}>' == repr(environment)

# Generated at 2022-06-21 13:49:14.486847
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
	c = Environment()
	assert c.__repr__() is not None


# Generated at 2022-06-21 13:49:21.958884
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().devnull.mode == 'w+'
    assert Environment().devnull.name == os.devnull
    assert Environment().config_dir == DEFAULT_CONFIG_DIR
    assert Environment().stdin == sys.stdin
    assert Environment().stdin_isatty == sys.stdin.isatty()
    assert Environment().stdin_encoding == 'utf8'
    assert Environment().stdout == sys.stdout
    assert Environment().stdout_isatty == sys.stdout.isatty()
    assert Environment().stdout_encoding == 'utf8'
    assert Environment().stderr == sys.stderr
    assert Environment().stderr_isatty == sys.stderr.isatty()
    assert Environment().program_name == 'http'
    assert Environment().colors == 256

   

# Generated at 2022-06-21 13:49:33.228381
# Unit test for method __repr__ of class Environment
def test_Environment___repr__(): 
    assert Environment(is_windows=True, stdin=None, program_name=None).__repr__() == "<Environment {'colors': 256, 'is_windows': True, 'program_name': None, 'stdin': None, 'stdin_encoding': None, 'stdin_isatty': False, 'stdout': <colorama.ansitowin32.StreamWrapper object at 0x7f1af4a4a898>, 'stdout_encoding': 'utf8', 'stdout_isatty': True, 'stderr': <colorama.ansitowin32.StreamWrapper object at 0x7f1af4a4a240>, 'stderr_isatty': True, 'config': <httpie.config.Config object at 0x7f1af49f0240>}>"

# Generated at 2022-06-21 13:49:36.268210
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    assert isinstance(env.__str__(), str)
    print(env.__str__())
