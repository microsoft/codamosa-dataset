

# Generated at 2022-06-21 13:40:03.829147
# Unit test for constructor of class Environment
def test_Environment():
    class DEFAULT_CONFIG_DIR(Exception):
        pass
    class DEFAULT_CONFIG_DIR(Environment):
        def __init__(self):
            self.is_windows = 'is_windows'
            self.config_dir = 'config_dir'
            self.stdin = 'stdin'
            self.stdin_isatty = 'stdin_isatty'
            self.stdin_encoding = 'stdin_encoding'
            self.stdout = 'stdout'
            self.stdout_isatty = 'stdout_isatty'
            self.stdout_encoding = 'stdout_encoding'
            self.stderr = 'stderr'
            self.stderr_isatty = 'stderr_isatty'

# Generated at 2022-06-21 13:40:12.576303
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    import io
    import tempfile
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.utils import is_windows

    program_name = 'http'
    config_dir = Path(tempfile.mktemp())
    colors = 256
    if not is_windows:
        if curses:
            try:
                curses.setupterm()
                colors = curses.tigetnum('colors')
            except curses.error:
                pass

    default_stdin = sys.stdin if sys.stdin.closed else sys.stdin
    with tempfile.TemporaryFile('w+') as in_file:
        if is_windows:
            import colorama.initialise
            # noinspection PyUnresolvedReferences

# Generated at 2022-06-21 13:40:14.192333
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    print(env)

test_Environment()

# Generated at 2022-06-21 13:40:26.628776
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    import sys
    import os
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_CONFIG_DIR, ConfigFileError
    env = Environment()
    # replace the config file
    config_dir_bak = env.config_dir
    env.__dict__['config_dir'] = '/tmp/httpie/'
    env._config = None
    env._config = Config(directory=env.config_dir)
    env._config.new()
    env.config
    assert env.config
    assert str(env.config).startswith('<Config')
    env.__dict__['is_windows'] = is_windows
    env.__dict__['stdin'] = sys.stdin  # `None` when closed fd (#791)

# Generated at 2022-06-21 13:40:35.957034
# Unit test for method __repr__ of class Environment

# Generated at 2022-06-21 13:40:45.184043
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    assert repr(env) == '<Environment {}>'
    assert env._orig_stderr == sys.stderr

    sys.stderr = io.StringIO()
    env.log_error('test')
    assert sys.stderr.getvalue() == '\nhttp: error: test\n\n'
    sys.stderr.close()

    sys.stderr = io.StringIO()
    env.log_error('test', level='warning')
    assert sys.stderr.getvalue() == '\nhttp: warning: test\n\n'
    sys.stderr.close()

# Generated at 2022-06-21 13:40:48.549477
# Unit test for constructor of class Environment
def test_Environment():
    # Test that all attributes of class Environment exist
    env = Environment(devnull=None, **Environment.__dict__)
    print(env)
    assert env is not None

test_Environment()

# Generated at 2022-06-21 13:40:56.124291
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    e = Environment()
    e.stdin = None
    e.stdout = None
    e.stderr = None
    assert str(e) == '''{'config': <Config config_dir='config', 'httpie'>, 'colors': 256, 'devnull': None, 'is_windows': False, 'program_name': 'http', 'stderr': None, 'stderr_encoding': None, 'stderr_isatty': None, 'stdin': None, 'stdin_encoding': None, 'stdin_isatty': None, 'stdout': None, 'stdout_encoding': None, 'stdout_isatty': None}'''

# Generated at 2022-06-21 13:41:06.501313
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    import sys
    from httpie.compat import is_windows
    stderr = io.StringIO()
    env = Environment(stderr=stderr)
    env.log_error('Test log error')
    if is_windows:
        # noinspection PyUnresolvedReferences
        from colorama import AnsiToWin32
        # noinspection PyUnresolvedReferences
        stderr.seek(0)
        output = AnsiToWin32(stderr).read()
    else:
        output = stderr.getvalue()
    sys.stderr.write(output)
    assert output == '\nhttp: error: Test log error\n\n'



# Generated at 2022-06-21 13:41:15.993052
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment()
    assert e.is_windows == True
    assert str(e.config_dir) == "C:\\Users\\LENOVO\\.config\\httpie"
    assert e.stdin.isatty()
    assert e.stdin_isatty == True
    assert e.stdin_encoding == "utf8"
    assert e.stdout.isatty()
    assert e.stdout_isatty == True
    assert e.stdout_encoding == "utf8"
    assert e.stderr.isatty()
    assert e.stderr_isatty == True
    assert e.program_name == "http"
    assert e.config == {}
    assert e.devnull == None


env = Environment()

# Generated at 2022-06-21 13:41:29.281361
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    assert 'Environment(is_windows=True, colors=256, program_name=http, stdin=<stdin>, stdin_isatty=True, stdin_encoding=utf8, stdout=<colorama.initialise.AnsiToWin32 object at 0x02D0F170>, stdout_isatty=True, stdout_encoding=utf8, stderr=<colorama.initialise.AnsiToWin32 object at 0x02D0F170>, stderr_isatty=True, config_dir=C:\\Users\\Nghia Tran\\AppData\\Roaming\\httpie)' == str(Environment())



# Generated at 2022-06-21 13:41:31.646318
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    Environment().log_error("python")
    Environment(program_name="httpie").log_error("python")


# Generated at 2022-06-21 13:41:35.380862
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    config_dir = Path("test")
    stdin = sys.stdin
    stdout = sys.stdout
    stderr = sys.stderr
    env = Environment(config_dir=config_dir, stdin=stdin, stdout=stdout, stderr=stderr)

# Generated at 2022-06-21 13:41:41.092670
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import StringIO
    env = Environment(
        stdout=StringIO(), stderr=StringIO(), program_name='http')
    env.log_error('msg', level='error')
    env.log_error('msg', level='warning')
    env.log_error('msg')
    assert env.stderr.getvalue() == """
http: error: msg

http: warning: msg

http: error: msg

"""

# Generated at 2022-06-21 13:41:53.864041
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    actual = repr_dict(Environment().__str__())

# Generated at 2022-06-21 13:42:00.930527
# Unit test for method __str__ of class Environment

# Generated at 2022-06-21 13:42:12.407215
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding is None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding is None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.program_name == 'http'

# Generated at 2022-06-21 13:42:22.672820
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from httpie import __version__
    from httpie.core import env

    from httpie.compat import is_windows

    env.program_name = 'http'
    env.is_windows = is_windows
    env.stdin_encoding = None
    env.stderr_isatty = True
    env.stdin_isatty = True
    env.stdout_isatty = True
    env.colors = 256

    os.environ['PWD'] = 'tmp' # os.getcwd()
    env.config_dir = os.path.join(os.getenv('PWD'), '.httpie')

    env.version = __version__

# Generated at 2022-06-21 13:42:34.620722
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256


# Generated at 2022-06-21 13:42:37.583735
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    """
    This method tests the method log_error of class Environment
    """
    # Get the current directory
    env = Environment()
    env.log_error("Error")

# Generated at 2022-06-21 13:42:57.156362
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    def is_equal_to_the_expected_str(environment,expected_str):
        return str(environment) == expected_str
    # Case 1
    env = Environment(devnull=None, is_windows=True, config_dir=DEFAULT_CONFIG_DIR, stdin=None, stdin_isatty=False, stdin_encoding=None, stdout=sys.stdout, stdout_isatty=True, stdout_encoding='utf8', stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http')

# Generated at 2022-06-21 13:42:57.811485
# Unit test for constructor of class Environment
def test_Environment():
    Environment()


# Generated at 2022-06-21 13:43:09.123359
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    strto = '<Environment {'
    strto = strto + '"stdin": None, '
    strto = strto + '"stdin_isatty": False, '
    strto = strto + '"stdin_encoding": null, '
    strto = strto + '"stdout": <_io.TextIOWrapper name=7encoding='
    strto = strto + '"utf-8">, "stdout_isatty": True, '
    strto = strto + '"stdout_encoding": "utf8", "stderr": '
    strto = strto + '<_io.TextIOWrapper name=8encoding="utf-8">, '

# Generated at 2022-06-21 13:43:20.594963
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdin_isatty=False, stdin_encoding=None, stdout=sys.stdout,
                      stdout_isatty=sys.stdout.isatty(), stdout_encoding=None)
    assert env.stdin is None
    assert env.stdin_isatty is False
    assert env.stdin_encoding is None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty is True
    assert env.stdout_encoding is None
    assert env.config_dir == "/Users/zhiwzhou/.httpie"
    assert env.program_name == "http"
    assert env.stderr == sys.stderr
    assert env.is_windows == False
    assert env.colors == 256




# Generated at 2022-06-21 13:43:32.608555
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    #arrange
    type(env).config_dir = DEFAULT_CONFIG_DIR
    type(env).stdin = sys.stdin  # `None` when closed fd (#791)
    type(env).stdin_isatty = stdin.isatty() if stdin else False
    type(env).stdin_encoding = None
    type(env).stdout = sys.stdout
    type(env).stdout_isatty = stdout.isatty()
    type(env).stdout_encoding = None
    type(env).stderr = sys.stderr
    type(env).stderr_isatty = stderr.isatty()
    type(env).colors = 256
    type(env).program_name = 'http'
    type(env).devnull

# Generated at 2022-06-21 13:43:42.884444
# Unit test for constructor of class Environment
def test_Environment():
    from httpie.compat import is_windows


# Generated at 2022-06-21 13:43:52.931517
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment(**{
        'stdin': open('tests/data/input/http'),
        'config_dir': Path('./temp/config_dir'),
        'program_name': 'http',
        'stderr': open('tests/data/log_error.txt', mode='w+'),
    })
    env.log_error('test', level='error')
    env.stderr.close()
    with open('tests/data/log_error.txt', mode='r') as file:
        content = file.read()
    assert content == '\nhttp: error: test\n\n'

# Generated at 2022-06-21 13:43:59.838394
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    default_stdout_stream = sys.stdout
    default_stderr_stream = sys.stderr
    example_message = 'The quick brown fox jumps over the lazy dog.'
    # sys.stdout and sys.stderr are file-like object, so
    # we can redirect them to a StringIO object to catch
    # the output without printing it to a real console
    sys.stdout = StringIO()
    sys.stderr = StringIO()
    # redirect program-name
    env = Environment()
    env.program_name = "PROGRAM_NAME"
    # print to default stdout and stderr
    env.log_error(example_message, level='error')
    env.log_error(example_message, level='warning')
    # check captured messages
    assert sys.stdout.getvalue

# Generated at 2022-06-21 13:44:04.570151
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        config_dir='~/.httpie',
        stdin=sys.stdin,
        stdout=sys.stdout,
        stderr=sys.stderr,
    )
    assert env.config_dir == Path('~/.httpie').expanduser()

if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-21 13:44:06.393653
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(a='b')
    assert 'a' in env.__dict__


env = Environment()

# Generated at 2022-06-21 13:44:34.941390
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    import pprint

    # 导入类 Environment
    from httpie.context import Environment

    # 创建类 Environment
    env = Environment()

    # 执行函数 __str__
    print(env.__str__())
    print('-'*30)

    # 创建类 Environment,并且输入一个初始化环境参数
    env = Environment(is_windows=True,stdout_isatty=False,colors=20,program_name='httpie')

    # 转换为字符串
    str__class_str = env.__str__()

    # 转换为字典

# Generated at 2022-06-21 13:44:42.313665
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=False, config_dir=Path('./httpie'), stdin=None, stdin_isatty=True, stdin_encoding=None, stdout=sys.stdout, stdout_isatty=True, stdout_encoding=None, stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http', stdout_encoding=None)
    print(env)

# Generated at 2022-06-21 13:44:45.126029
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdout='Test stdout', stdin='Test stdin')
    assert env.stdout == 'Test stdout'
    assert env.stdin == 'Test stdin'

# Generated at 2022-06-21 13:44:47.258922
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    e = Environment()
    assert 'Environment' in str(e)
    assert ': False' in str(e)
    assert ': True' in str(e)


# Generated at 2022-06-21 13:44:53.615790
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    # The initial STDERR stream of the process
    stream = sys.stderr

    # Create an environment with a stream which will be used for logging
    env = Environment(stderr=io.StringIO())

    msg = 'The user or password is incorrect.'

    # Call the method
    for level in ['error', 'warning']:
        env.log_error(msg, level)

        # Check if the message is written into the stream with the level
        assert env.stderr.getvalue().strip() == f'\n{env.program_name}: {level}: {msg}\n\n'

    # Set the default STDERR stream
    sys.stderr = stream

# Generated at 2022-06-21 13:45:05.024994
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    e = Environment(
        is_windows=1,
        config_dir=1,
        stdin=1,
        stdin_isatty=1,
        stdin_encoding=1,
        stdout=1,
        stdout_isatty=1,
        stdout_encoding=1,
        stderr=1,
        stderr_isatty=1,
        colors=1,
        program_name=1,
        devnull=1,
        config=1,
        _orig_stderr=1,
        _devnull=1,
    )

# Generated at 2022-06-21 13:45:14.392860
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from pytest import raises
    from httpie.input import SEP_CREDENTIALS
    
    env = Environment()

    # NOTE: these tests use the `env` object created by the fixture
    # and check that its `__str__` method returns the correct values.
    # The reason for all this testing is that, given that `__str__`
    # only returns the values of the environment, we use this method
    # to verify the correctness of the fixture itself.
    # If a test fails, it means that the fixture is likely broken.
    # For this reason, it is important to test `__str__`.

    assert env._orig_stderr is env.stderr
    assert env._devnull is None

    assert env.is_windows is is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR


# Generated at 2022-06-21 13:45:15.964951
# Unit test for method log_error of class Environment
def test_Environment_log_error():
  env = Environment()
  assert env.log_error("test") == "Error: test"

# Generated at 2022-06-21 13:45:27.611083
# Unit test for constructor of class Environment
def test_Environment():
    # Test init of Environment is ok
    env = Environment()
    assert env.stderr_isatty
    assert env.stdout_isatty
    assert env.stdin_isatty
    assert env.stdin_encoding is None
    assert env.stdout_encoding is None
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env.stderr == sys.stderr
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.is_windows == is_windows
    from httpie.config import DEFAULT_CONFIG_DIR
    assert env.config_dir == Path(DEFAULT_CONFIG_DIR)
    assert env._devnull == None

    # Test init of Environment with devnull and kw

# Generated at 2022-06-21 13:45:28.988752
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
     env = Environment()
     print(env)


# Generated at 2022-06-21 13:46:08.735739
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from tempfile import TemporaryFile
    from httpie.context import Environment
    env = Environment()
    tmp_file = TemporaryFile("w+")
    env.stderr = tmp_file
    env.log_error("asdf")
    tmp_file.seek(0)
    assert tmp_file.read() == "\nhttp: error: asdf\n\n"
    tmp_file.close()

# Generated at 2022-06-21 13:46:15.858136
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import sys
    import io
    import httpie.core as hc
    sys.stderr = io.StringIO()
    env = hc.Environment()
    env.log_error('msg', level='warning')
    assert sys.stderr.getvalue() == '\nhttp: warning: msg\n\n'
    sys.stderr = io.StringIO()
    env.log_error('msg')
    assert sys.stderr.getvalue() == '\nhttp: error: msg\n\n'


env = Environment()

# Generated at 2022-06-21 13:46:22.352621
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None)
    assert env.is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin is sys.stdin
    assert env.stdin_isatty
    assert env.stdin_encoding is None
    assert env.stdout is sys.stdout
    assert env.stdout_isatty
    assert env.stdout_encoding is None
    assert env.stderr is sys.stderr
    assert env.stderr_isatty
    assert env.colors == 256
    assert env.program_name == 'http'

# Generated at 2022-06-21 13:46:34.096021
# Unit test for constructor of class Environment
def test_Environment():
    env: Environment = Environment()
    assert env.stdin == sys.stdin
    assert env.stdin_isatty
    assert env.stdin_encoding == 'utf-8'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty
    assert env.stdout_encoding == 'utf-8'
    assert env.stderr == sys.stderr
    assert env.stderr_isatty
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr
    assert env.devnull is None
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR

# Generated at 2022-06-21 13:46:35.172670
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    assert str(Environment()) == '{}'

# Generated at 2022-06-21 13:46:44.359485
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    repr_env = repr(env)

# Generated at 2022-06-21 13:46:55.877995
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from httpie.utils import isatty_stdout
    import os
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdirname:
        env = Environment(
            stdin=os.fdopen(os.open(os.path.devnull, os.O_RDONLY), 'r'),
            stdout=os.fdopen(os.open(os.path.devnull, os.O_WRONLY), 'w'),
            stderr=os.fdopen(os.open(os.path.devnull, os.O_WRONLY), 'w'),
            config_dir=Path(tmpdirname)
        )

# Generated at 2022-06-21 13:47:05.772363
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    env_str = str(env)

# Generated at 2022-06-21 13:47:16.570853
# Unit test for constructor of class Environment
def test_Environment():
    # httpie.core.Environment.is_windows : bool
    assert Environment().is_windows == is_windows

    # httpie.core.Environment.config_dir : Path
    assert Environment().config_dir == DEFAULT_CONFIG_DIR

    # httpie.core.Environment.stdin : Optional[IO]
    temp = sys.stdin
    sys.stdin = None
    assert Environment().stdin_isatty == False
    sys.stdin = temp

    # httpie.core.Environment.stdin_isatty : bool
    assert Environment().stdin_isatty == sys.stdin.isatty() if sys.stdin else False

    # httpie.core.Environment.stdin_encoding : str
    temp = sys.stdin
    sys.stdin = None
    env = Environment()

# Generated at 2022-06-21 13:47:28.018237
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    (env_1, expected_1) = (Environment(), '<Environment {}>')
    env_2 = Environment(is_windows=True)
    expected_2 = '<Environment {config: None, colors: 256, is_windows: True, program_name: \'http\', stderr: <_io.TextIOWrapper name=2 encoding=\'cp1252\'>, stderr_encoding: None, stderr_isatty: True, stdin: <_io.TextIOWrapper name=0 encoding=\'cp1252\'>, stdin_encoding: None, stdin_isatty: True, stdout: <colorama.ansitowin32.StreamWrapper object at 0x000001A57A3921D0>, stdout_encoding: None, stdout_isatty: True}>'


# Generated at 2022-06-21 13:48:00.824742
# Unit test for constructor of class Environment
def test_Environment():
    # test constructor of class Environment
    env = Environment()
    assert isinstance(env, Environment)

# Generated at 2022-06-21 13:48:06.509567
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(is_windows=True, devnull=None)
    assert env.is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty
    assert env.stdin_encoding is None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty
    assert env.program_name == 'http'
    assert env._devnull is None

# Generated at 2022-06-21 13:48:09.899804
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(foo='bar')
    assert str(env) == "foo='bar'"
    assert repr(env) == "<Environment foo='bar'>"


# Generated at 2022-06-21 13:48:16.245294
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    print(Environment())


"""
The current environment.

This is often unobvious to set in the test suite, so for now we just define
it to be an instance of `Environment` which is used in the test suite as well.
"""
environment = Environment()


"""
The interpreter’s default environment.
"""
default_environment = Environment()

if __name__ == '__main__':
    print(environment)

# Generated at 2022-06-21 13:48:21.662856
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    from httpie.core import main

    main.stdout = open('/dev/null', 'w')
    main.stderr = open('/dev/null', 'w')
    env = main.Environment(stdin=sys.stdin,
                           stdout=sys.stdout,
                           stderr=sys.stderr,
                           program_name='http',
                           devnull=open('/dev/null', 'w+'),
                           config_dir='/dev/null',
                           config='/dev/null')


# Generated at 2022-06-21 13:48:24.903383
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from httpie.environment import Environment
    ex = Environment(stdout_encoding='utf-8',stderr_encoding='utf-8')
    print(ex.__str__())

# Generated at 2022-06-21 13:48:27.517644
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(foo=1, bar=2)
    assert str(env) == "foo=1, bar=2"


# Generated at 2022-06-21 13:48:33.792306
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    actual = Environment(config=Config(directory=Config.DEFAULT_CONFIG_DIR))
    expected = """<Environment {'config': {}, 'colors': 256, 'colors12': 12, 'is_windows': False, 'program_name': 'http', 'stdin': <stdin>, 'stdin_encoding': 'utf8', 'stdin_isatty': True, 'stdout': <stdout>, 'stdout_encoding': 'gb18030', 'stdout_isatty': True, 'stderr': <stderr>, 'stderr_isatty': True, 'config_dir': /home/fei/.config/httpie}>"""
    assert repr(actual) == expected

# Generated at 2022-06-21 13:48:43.642827
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    env.stdin = None
    assert repr(env) == '<Environment {\'config\': <Config {}>, \'is_windows\': False, \'config_dir\': Path(\'C:\\\\Users\\\\Administrator\\\\AppData\\\\Roaming\\\\httpie\'), \'stdin\': None, \'stdin_isatty\': False, \'stdin_encoding\': None, \'stdout\': <sys.stdout>, \'stdout_isatty\': True, \'stdout_encoding\': \'utf8\', \'stderr\': <sys.stderr>, \'stderr_isatty\': True, \'colors\': 256, \'program_name\': \'http\'}>'

# Generated at 2022-06-21 13:48:54.386183
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    import sys
    import httpie.core
    env = Environment(
        stdin=sys.stdin,
        stdout=sys.stdout,
        stderr=sys.stderr,
    )