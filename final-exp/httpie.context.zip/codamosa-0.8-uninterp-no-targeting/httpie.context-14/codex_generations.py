

# Generated at 2022-06-21 13:39:57.195573
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    assert repr(Environment()) == '<Environment {}>'


# Generated at 2022-06-21 13:40:08.294533
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    import httpie.auth

# Generated at 2022-06-21 13:40:20.555623
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from unittest.mock import MagicMock
    mock_stdin = MagicMock()
    mock_stdout = MagicMock()
    mock_stderr = MagicMock()

    env = Environment(
        stdin=mock_stdin,
        stdout=mock_stdout,
        stderr=mock_stderr,
        colors=256,
        stdin_isatty=True,
        stdout_isatty=True,
        stderr_isatty=True,
        stdin_encoding='utf8',
        stdout_encoding='utf8',
        program_name='httpie',
        config_dir='/root/.config/httpie',
    )
    config = MagicMock()
    env._config = config
    assert str(env) == str

# Generated at 2022-06-21 13:40:22.949297
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error("This is an error message", level = 'error')

# Generated at 2022-06-21 13:40:24.576278
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment(program_name= 'foo')
    assert env.log_error('Error bar') == None

# Generated at 2022-06-21 13:40:28.841574
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error("Hello World")
    assert env._orig_stderr.getvalue() == '\nhttp: error: Hello World\n\n'


env = Environment()

# Generated at 2022-06-21 13:40:34.902049
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()

# Generated at 2022-06-21 13:40:40.205803
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment(stdin=None, is_windows=True, stdin_isatty=True, program_name="http")
    assert str(env) == "{is_windows: True, program_name: 'http', stdin: None, stdin_isatty: True}"


# Generated at 2022-06-21 13:40:43.865414
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    assert repr_dict(type(env).__dict__) == str(env)
    env = Environment(foo='bar')
    assert repr_dict(type(env).__dict__, foo='bar') == str(env)

# Generated at 2022-06-21 13:40:54.079129
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import StringIO
    from httpie.utils import get_colors
    from httpie.core import Environment
    from httpie.config import DEFAULT_CONFIG_DIR

# Generated at 2022-06-21 13:41:09.760487
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert is_windows == env.is_windows
    assert DEFAULT_CONFIG_DIR == env.config_dir
    assert sys.stdin == env.stdin
    assert sys.stdin.isatty() == env.stdin_isatty
    assert sys.stdin.encoding == env.stdin_encoding
    assert sys.stdout == env.stdout
    assert sys.stdout.isatty() == env.stdout_isatty
    assert sys.stdout.encoding == env.stdout_encoding
    assert sys.stderr == env.stderr
    assert sys.stderr.isatty() == env.stderr_isatty

# Generated at 2022-06-21 13:41:16.308396
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import sys
    from pathlib import Path
    from io import StringIO
    from contextlib import redirect_stderr

    error_msg = "this is a warning error"
    env = Environment(program_name='http',
                      stderr=StringIO(),
                      config_dir = Path('asdfasdf'))
    # The test will fail if we don't provide config_dir with an invalid path
    with redirect_stderr(sys.stderr):
        env.log_error(error_msg, level='warning')




# Generated at 2022-06-21 13:41:22.872945
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin
    assert env.stdin_isatty
    assert env.stdout
    assert env.stdout_isatty
    assert env.stderr
    assert env.stderr_isatty
    assert env.program_name == 'http'

if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-21 13:41:27.834347
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    assert 'stdin' in repr(Environment(stdin=sys.stdin))
    assert 'stdin' not in repr(Environment(stdin=None))
    assert 'stderr' in repr(Environment(stderr=sys.stderr))
    assert 'stderr' not in repr(Environment(stderr=None))
    assert 'config' in repr(Environment())
    assert 'config' not in repr(Environment(config_dir='test'))

# Generated at 2022-06-21 13:41:36.658645
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    # type: () -> None
    env = Environment()

# Generated at 2022-06-21 13:41:44.986736
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    environment = Environment()

# Generated at 2022-06-21 13:41:56.204975
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment(devnull=False, is_windows=1, config_dir=Path("/"), stdin=2, stdin_isatty=True, stdin_encoding=None, stdout=3, stdout_isatty=True, stdout_encoding=None, stderr=4, stderr_isatty=True, colors=256, program_name='http')

# Generated at 2022-06-21 13:41:59.130469
# Unit test for constructor of class Environment
def test_Environment():
    # If no kwargs, it represents the actual environment.
    env = Environment()
    print(repr(env))


if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-21 13:42:02.632268
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment(stderr=StringIO())
    env.log_error('A Very Good Message')
    assert 'A Very Good Message' in env.stderr.getvalue()



# Generated at 2022-06-21 13:42:14.257165
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()

# Generated at 2022-06-21 13:42:24.538738
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error("This is an error")
    env.log_error("This is a warning", level='warning')

# Generated at 2022-06-21 13:42:35.694059
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment(stderr=StringIO())
    error_msg = 'error message'
    warning_msg = 'warning message'

    env.log_error(error_msg)
    env.log_error(warning_msg, level='warning')

    # Testing log_error of type error
    assert env.stderr.getvalue() == (
    '\nhttp: error: {}\n\n'.format(error_msg)
    )

    # Testing log_error of type warning
    assert env.stderr.getvalue() == (
    '\nhttp: error: {}\n\n'.format(error_msg)
    + '\nhttp: warning: {}\n\n'.format(warning_msg)
    )

# Generated at 2022-06-21 13:42:47.309318
# Unit test for constructor of class Environment
def test_Environment():
    import sys
    import os

# Generated at 2022-06-21 13:42:57.764879
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(
        config=Config(directory=DEFAULT_CONFIG_DIR)
    )

# Generated at 2022-06-21 13:43:09.124228
# Unit test for constructor of class Environment
def test_Environment():
    DEVNULL = open(os.devnull, 'w+')
    config_dir = os.path.dirname(os.path.realpath(__file__)) + '/../../../examples'
    config_dir_2 = os.path.dirname(os.path.realpath(__file__)) + '/config'
    config_dir_3 = os.path.dirname(os.path.realpath(__file__)) + '/../../../../examples'
    stdin = open('README.md', 'r')
    stdout = open('README.md', 'w')
    stderr = open('README.md', 'w')
    is_windows = False
    # Initialization with all parameters

# Generated at 2022-06-21 13:43:20.191722
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    import sys
    import os
    from pathlib import Path
    default = {'is_windows': is_windows, 'config_dir': Path(DEFAULT_CONFIG_DIR), 'stdin': sys.stdin, 'stdin_isatty': sys.stdin.isatty() if sys.stdin else False, 'stdin_encoding': None, 'stdout': sys.stdout, 'stdout_isatty': sys.stdout.isatty(), 'stdout_encoding': None, 'stderr': sys.stderr, 'stderr_isatty': sys.stderr.isatty(), 'colors': 256, 'program_name': 'http'}
    e = Environment(**default)
    print(e)



# Generated at 2022-06-21 13:43:32.242638
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    env.stdin = None
    actual = str(env)

# Generated at 2022-06-21 13:43:34.586923
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error('Hello!')
    env.log_error('Hello!', level='warning')


# Generated at 2022-06-21 13:43:42.088628
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import sys, io
    assert sys.stderr == sys.__stderr__
    #  sys.__getattribute__(sys, 'stdout') == sys.stdout
    sys.stderr = io.StringIO()
    print(sys.stderr)
    # assert(sys.stderr == io.StringIO())
    env = Environment()
    env.log_error('test_error')
    assert(sys.stderr.getvalue() == '\nhttp: error: test_error\n\n')
    return




# Generated at 2022-06-21 13:43:54.401120
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    #sys.stdout = StringIO()
    env = Environment()
    print(env.__repr__())

# Generated at 2022-06-21 13:44:23.319128
# Unit test for method __str__ of class Environment

# Generated at 2022-06-21 13:44:35.132845
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    environ = Environment()

# Generated at 2022-06-21 13:44:38.725363
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        stdin=123,
        stdin_isatty=True,
        stdin_encoding='latin',
        stdout=123,
        stdout_isatty=True,
        stdout_encoding='utf',
        stderr=123,
        stderr_isatty=False,
        program_name='test',
        devnull=123,
        is_windows=True,
        config_dir='/test',
        colors=10,
    )
    assert env.stdin == 123
    assert env.stdin_isatty == True
    assert env.stdin_encoding == 'latin'
    assert env.stdout == 123
    assert env.stdout_isatty == True
    assert env.stdout_encoding == 'utf'

# Generated at 2022-06-21 13:44:49.585862
# Unit test for method __str__ of class Environment

# Generated at 2022-06-21 13:45:01.873994
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    env.stdin_encoding = None
    assert env.stdin_encoding == None
    env.stdout_encoding = None
    assert env.stdout_encoding == None
    env.stderr_encoding = None
    assert env.stderr_encoding == None
    env.config_dir = None
    assert env.config_dir == None
    env.is_windows = None
    assert env.is_windows == None
    env.stdin = None
    assert env.stdin == None
    env.stdin_isatty = None
    assert env.stdin_isatty == None
    env.stdout = None
    assert env.stdout == None
    env.stdout_isatty = None
    assert env.stdout_isatty == None


# Generated at 2022-06-21 13:45:03.004434
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error('test message', level='warning')

# Generated at 2022-06-21 13:45:04.388546
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    environment = Environment()
    environment.log_error("Hello World!")

# Generated at 2022-06-21 13:45:13.259391
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    import sys
    if sys.stdout.isatty():
        env = Environment(stdout_isatty=True)
    else:
        env = Environment(stdout_isatty=False)
    old_stdout = sys.stdout
    old_stderr = sys.stderr
    sys.stdout = io.StringIO()
    sys.stderr = io.StringIO()
    env.log_error('Hello World!', level='error')
    result = sys.stderr.getvalue()
    sys.stdout = old_stdout
    sys.stderr = old_stderr
    assert result == '\nhttp: error: Hello World!\n\n'


env = Environment()

# Generated at 2022-06-21 13:45:14.884198
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    assert repr(env) == '<Environment {}>'

# Generated at 2022-06-21 13:45:26.539265
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    defaults = dict(type(Environment).__dict__)
    actual = dict(defaults)
    actual['config'] = Environment().config

# Generated at 2022-06-21 13:46:02.268937
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    environ = Environment(config_dir='test')

# Generated at 2022-06-21 13:46:04.500671
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    assert str(env) == str(env.__repr__())


# Generated at 2022-06-21 13:46:15.543979
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    actual = Environment()

# Generated at 2022-06-21 13:46:18.321471
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    assert str(env).startswith('<Environment ')
    assert str(env).endswith('>')
    assert str(env).count('\n') == 1


# Generated at 2022-06-21 13:46:24.515925
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    import os
    import sys
    IP = '127.0.0.1'
    PORT = '5000'
    UPDATE_SETTING = {
        'config_dir': '',
        'stdin': os.pipe(),
        'stdin_encoding': None,
        'stdin_isatty': False,
        'stdout': os.pipe(),
        'stdout_encoding': None,
        'stdout_isatty': False,
        'stderr': sys.stdout,
        'stderr_isatty': True,
        'is_windows': False,
        'colors': 256,
        'program_name': 'http',
    }
    ENV = Environment(**UPDATE_SETTING)

# Generated at 2022-06-21 13:46:30.249433
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(stdin_encoding = "UTF-8", stdout_encoding = "UTF-8", stderr = "STDOUT")
    assert environment.stdin_encoding == "UTF-8"
    assert environment.stdout_encoding == "UTF-8"
    assert environment.stderr == "STDOUT"


# Generated at 2022-06-21 13:46:32.671606
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    s = str(env)
    assert type(s) == str



# Generated at 2022-06-21 13:46:35.523300
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment(devnull=None, program_name="http", stderr=sys.stderr)
    env.log_error('test', level='warning')


# Generated at 2022-06-21 13:46:37.712002
# Unit test for constructor of class Environment
def test_Environment():
    assert not all(hasattr(Environment, attr) for attr in dict.keys())


# Unit test ProgramName

# Generated at 2022-06-21 13:46:40.378227
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdout_isatty=False)
    assert type(env).__name__ == "Environment"
    assert env.stdout_isatty == False


# Generated at 2022-06-21 13:47:49.409555
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    env.config_dir = Path('/foo/bar')
    env.stdin = sys.stdin
    env.stdin_isatty = True
    env.stdin_encoding = 'encoding'
    env.stdout = sys.stdout
    env.stdout_isatty = True
    env.stdout_encoding = 'encoding'
    env.stderr = sys.stderr
    env.stderr_isatty = True
    env.program_name = 'http'
    env.colors = 256

# Generated at 2022-06-21 13:47:53.091781
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    assert str(Environment(**{"var1":"value1", "var2":"value2"})) == "{'var1': 'value1', 'var2': 'value2'}"

# Generated at 2022-06-21 13:47:55.993331
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment(directories = '')
    print(env.__repr__())

test_Environment___repr__()

# Generated at 2022-06-21 13:48:02.637907
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import StringIO
    string_stream = StringIO()
    string_stream.isatty = lambda: True
    string_stream.encoding = 'utf8'
    env = Environment(stderr=string_stream)
    msg = 'This is a test string'
    env.log_error(msg)
    assert string_stream.getvalue() == f'{env.program_name}: error: {msg}\n'

# Generated at 2022-06-21 13:48:09.465006
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import StringIO
    import sys
    import os

    original_stderr = sys.stderr
    try:
        sys.stderr = StringIO()
        env = Environment()
        assert '\n' not in env._orig_stderr.getvalue()

        # Common error
        env.log_error("Invalid data.")
        assert sys.stderr.getvalue() == "\nhttp: error: Invalid data.\n\n"

        # Warning error
        env.log_error("Invalid data.", level='warning')
        assert sys.stderr.getvalue() == "\nhttp: error: Invalid data.\n\n\nhttp: warning: Invalid data.\n\n"
    finally:
        sys.stderr = original_stderr



# Generated at 2022-06-21 13:48:13.306608
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=2, stdout=1, stderr=None)
    assert env.devnull == 2
    assert env.stdout == 1
    assert env.stderr == None


# Generated at 2022-06-21 13:48:16.891236
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    import tempfile
    from subprocess import PIPE

    env = Environment(stderr=PIPE)
    env.config_dir = tempfile.TemporaryDirectory().name
    assert 'TemporaryDirectory' in env.__repr__()

# Generated at 2022-06-21 13:48:25.087696
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    # arrange
    import io, sys
    output_stream = io.StringIO()
    input_stream = io.StringIO()
    with contextlib.redirect_stdout(output_stream):
        with contextlib.redirect_stdin(input_stream):
            env = Environment()
            expected_output = f"\n{env.program_name}: warning: This is a warning.\n\n"
            # act
            env.log_error("This is a warning.", level='warning')
            # assert
            assert expected_output == output_stream.getvalue()



# Generated at 2022-06-21 13:48:31.774909
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    class Test:
        @staticmethod
        def assert_in(item1, item2):
            assert item1 in item2
    try:
        stderr = sys.stderr
        sys.stderr = io.StringIO()
        e = Environment()
        e.log_error("Test Error")
        Test.assert_in("error", sys.stderr.getvalue())
        Test.assert_in("Test Error", sys.stderr.getvalue())
    finally:
        sys.stderr = stderr
test_Environment_log_error()

# Generated at 2022-06-21 13:48:42.586510
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment.__new__(Environment)
    env.is_windows = False
    env.config_dir = Path('.config')
    env.stdin = sys.stdin
    env.stdin_isatty = True
    env.stdin_encoding = 'utf8'
    env.stdout = sys.stdout
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'
    env.stderr = sys.stderr
    env.stderr_isatty = True
    env.colors = 256
    env.program_name = 'http'
    env._orig_stderr = sys.stderr
    env._devnull = None
    env._config = None