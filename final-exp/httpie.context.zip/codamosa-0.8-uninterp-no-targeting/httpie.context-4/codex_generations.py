

# Generated at 2022-06-21 13:40:03.273499
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    os.environ['HTTPIE_DEV_STDERR'] = "tmp_stderr"
    tmp_stderr = open('tmp_stderr', 'w')
    error = Environment(stderr=tmp_stderr)
    error.log_error('testcase', 'warning')
    assert open('tmp_stderr').read() == '\nhttp: warning: testcase\n\n'
    tmp_stderr.close()
    os.remove('tmp_stderr')

# Generated at 2022-06-21 13:40:08.379127
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name='http', devnull='devnull')
    assert env.program_name == 'http'
    assert env.devnull is None
    assert env.stdin is sys.stdin
    assert env.stdout is sys.stdout
    assert env.stderr is sys.stderr


# Generated at 2022-06-21 13:40:10.036911
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    print(env)


# Generated at 2022-06-21 13:40:22.698661
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import StringIO
    from unittest.mock import patch
    from httpie.environment import Environment
    from contextlib import redirect_stderr
    level = 'error'
    env = Environment(stderr=StringIO())
    env.log_error('message')
    error_stream = env._orig_stderr
    assert f'\n{env.program_name}: {level}: message\n\n' in error_stream.getvalue()
    # now let's try level == 'warning'
    level = 'warning'
    env = Environment(stderr=StringIO())
    env.log_error('message', level=level)
    error_stream = env._orig_stderr
    assert f'\n{env.program_name}: {level}: message\n\n' in error_stream.get

# Generated at 2022-06-21 13:40:29.162823
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    env = Environment()
    env._orig_stderr = io.StringIO()
    env.program_name = 'httpie-test'
    env.log_error(msg='Unable to read config file', level='error')
    assert env._orig_stderr.getvalue() == '\nhttpie-test: error: Unable to read config file\n\n'


env = Environment()

# Generated at 2022-06-21 13:40:37.372045
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        config_dir=Path('config_dir'),
        stdin=object(),
        stdin_isatty=False,
        stdin_encoding=None,
        stdout=object(),
        stdout_isatty=False,
        stdout_encoding=None,
        stderr=object(),
        stderr_isatty=False,
    )


if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-21 13:40:43.319061
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    import sys
    import os
    from pathlib import Path
    from typing import IO, Optional


    try:
        import curses
    except ImportError:
        curses = None  # Compiled w/o curses

    from httpie.compat import is_windows
    from httpie.config import DEFAULT_CONFIG_DIR, Config, ConfigFileError

    from httpie.utils import repr_dict


    class Environment:
        """
        Information about the execution context
        (standard streams, config directory, etc).

        By default, it represents the actual environment.
        All of the attributes can be overwritten though, which
        is used by the test suite to simulate various scenarios.

        """
        is_windows: bool = is_windows
        config_dir: Path = DEFAULT_CONFIG_DIR

# Generated at 2022-06-21 13:40:53.664995
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    if sys.stdout.isatty():
        colors = 256
        if curses:
            try:
                curses.setupterm()
                colors = curses.tigetnum('colors')
            except curses.error:
                pass
    else:
        colors = 0

    env = Environment()
    t_config = str(env.config)
    output_data = env.__repr__()
    ans = "{"
    for key, value in env.__dict__.items():
        if not key.startswith('_'):
            if isinstance(value, str):
                ans += "'" + key + "'" + ": " + "'" + value + "'" + ", "
            else:
                ans += "'" + key + "'" + ": " + str(value) + ", "

# Generated at 2022-06-21 13:41:05.673655
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    env.config_dir = DEFAULT_CONFIG_DIR
    env.stdin = sys.stdin
    env.stdin_isatty = False
    env.stdin_encoding = 'utf8'
    env.stdout = sys.stdout
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'
    env.stderr = sys.stderr
    env.stderr_isatty = False
    env.colors = 256
    env.program_name = 'http'

# Generated at 2022-06-21 13:41:15.623107
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    # Test method __repr__ of class Environment
    env = Environment()

# Generated at 2022-06-21 13:41:22.614219
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().__dict__ == Environment(None, None).__dict__

if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-21 13:41:30.925826
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull="/dev/null", is_windows=False, stdin=sys.stdin,
                      stdout=sys.stdout, stdout_isatty=sys.stdout.isatty(),
                      stdout_encoding="utf8", stderr=sys.stderr,
                      stderr_isatty=sys.stderr.isatty(),
                      program_name = 'http')
    assert env.devnull == "/dev/null"
    assert env.is_windows == False
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == "utf8"
    assert env.stderr == sys.stderr

# Generated at 2022-06-21 13:41:31.865270
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    pass


# Generated at 2022-06-21 13:41:35.485490
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    err_msg = "log_error test"
    env.log_error(err_msg)
    expected = f'\n{env.program_name}: error: {err_msg}\n\n'
    assert expected == env._orig_stderr.getvalue().strip()
    

env = Environment()

# Generated at 2022-06-21 13:41:38.381297
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error("testing log_error")
    env.log_error("testing log_error", level='warning')



# Generated at 2022-06-21 13:41:43.020931
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    output = repr(Environment())

# Generated at 2022-06-21 13:41:54.465907
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    actual = Environment().__repr__()

# Generated at 2022-06-21 13:42:06.675401
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name="httpc", colors=256)
    assert env.program_name == "httpc"
    assert env.colors == 256
    assert hasattr(env, 'is_windows')
    assert hasattr(env, 'config_dir')
    assert hasattr(env, 'stdin')
    assert hasattr(env, 'stdin_isatty')
    assert hasattr(env, 'stdin_encoding')
    assert hasattr(env, 'stdout')
    assert hasattr(env, 'stdout_isatty')
    assert hasattr(env, 'stdout_encoding')
    assert hasattr(env, 'stderr')
    assert hasattr(env, 'stderr_isatty')
    assert hasattr(env, 'config')

# Generated at 2022-06-21 13:42:11.747785
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()

# Generated at 2022-06-21 13:42:14.109888
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    # Test the constructor of class Environment
    assert type(env).__name__ == 'Environment'


# Generated at 2022-06-21 13:42:29.841946
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()

# Generated at 2022-06-21 13:42:37.092315
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    class TestEnviron(Environment):
        stderr = StringIO()
    environ = TestEnviron()
    environ.log_error('This is an error, not a warning.')
    assert 'error: This is an error, not a warning.' in environ.stderr.getvalue()
    environ.stderr = StringIO()
    environ.log_error('I am a warning.', level='warning')
    assert 'warning: I am a warning.' in environ.stderr.getvalue()

# Generated at 2022-06-21 13:42:38.604093
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(test="test")
    assert env.test == 'test'

# Generated at 2022-06-21 13:42:43.477351
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env._orig_stderr = io.StringIO()
    env.log_error('test')
    env._orig_stderr.seek(0)
    assert env._orig_stderr.read().split() == ['http:', 'error:', 'test']

# Generated at 2022-06-21 13:42:45.808130
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    call(['pytest', '-vv', '--cov', 'httpie_log_error.py']) 


# Generated at 2022-06-21 13:42:56.774982
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows == is_windows
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == stdin.isatty()
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == stdout.isatty()
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == stderr.isatty()
    assert environment.program_name == 'http'

# Generated at 2022-06-21 13:43:08.478067
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    my_env = Environment()
    my_env.stdin = open('/dev/stdin', 'r+')
    my_env.stdin_encoding = 'utf-8'
    my_env.stdout = open('/dev/stdout', 'w+')
    my_env.stdout_encoding = 'utf-8'
    my_env.stderr = open('/dev/stderr', 'w+')
    my_env.program_name = 'New Program Name'


# Generated at 2022-06-21 13:43:13.706158
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    from httpie.environment import Environment
    from httpie.compat import is_windows
    if is_windows:
        env = Environment(stdin=None, stdout=None, stderr=None, config_dir='samplepath')
        exp = "<Environment {'colors': 256, 'config': <Config 'samplepath/config.json'>, 'is_windows': True, 'program_name': 'http', 'stdin': None, 'stdin_encoding': None, 'stdin_isatty': False, 'stdout': None, 'stdout_encoding': 'utf8', 'stdout_isatty': False, 'stderr': None, 'stderr_isatty': False}>"

# Generated at 2022-06-21 13:43:22.780765
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import sys;
    import io;
    old_stderr = sys.stderr
    try:
        sys.stderr = io.StringIO()
        env = Environment()
        env.log_error('Oi oi oi, oi oi oi oi oi')
        assert(sys.stderr.getvalue() == '\nhttp: error: Oi oi oi, oi oi oi oi oi\n\n')
    finally:
        sys.stderr = old_stderr

environ = Environment()

# Generated at 2022-06-21 13:43:26.993443
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    e = Environment(stdin_isatty=False, stdout_isatty=True, stderr_isatty=False, colors=256, program_name="httpc")
    print(e)


# Generated at 2022-06-21 13:43:39.046368
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name='http', config_dir='/home/.httpie/')
    assert env.program_name == 'http'
    assert env.config_dir == '/home/.httpie/'
    assert env.config_dir.is_absolute()

# Generated at 2022-06-21 13:43:43.210249
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdout=None, stdout_isatty=True, stdout_encoding='A', stderr=None)
    assert env.stdout == None
    assert env.stdout_isatty == True
    assert env.stdout_encoding == 'A'
    assert env.stderr == None

# Generated at 2022-06-21 13:43:45.891218
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdout=env.stdout)
    assert env.stdout == env.stdout

# Generated at 2022-06-21 13:43:57.201267
# Unit test for method __str__ of class Environment

# Generated at 2022-06-21 13:44:06.348942
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    environment = Environment()

# Generated at 2022-06-21 13:44:16.244613
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    with patch.object(env, '_orig_stderr') as _orig_stderr:
        env.log_error(msg='Unit test for function log_error', level='error')
        _orig_stderr.write.assert_called_with(
            '\nhttp: error: Unit test for function log_error\n\n')

        env.log_error(msg='Unit test for function log_error', level='warning')
        _orig_stderr.write.assert_called_with(
            '\nhttp: warning: Unit test for function log_error\n\n')

# Generated at 2022-06-21 13:44:24.117403
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    e = Environment(is_windows=True, stdin_isatty=True)
    assert repr(e) == '<Environment'
    e.is_windows
    e.stdin_isatty
    assert repr(e) == '<Environment'
    e.__class__.is_windows = True
    e.__class__.stdin_isatty = True
    assert repr(e) == '<Environment'
    e.stdin_encoding = 'utf8'
    e.stdout_encoding = 'utf8'
    assert repr(e) == '<Environment'
    e.__class__.stdin_encoding = 'utf8'
    e.__class__.stdout_encoding = 'utf8'
    assert repr(e) == '<Environment'
    e.__class__.std

# Generated at 2022-06-21 13:44:29.130464
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    sys.stderr = open('error.txt', 'w')
    Environment().log_error('error')
    with open('error.txt','r') as f:
        error = f.read()
    assert error == '\nhttp: error: error\n\n'


# Generated at 2022-06-21 13:44:40.718126
# Unit test for constructor of class Environment
def test_Environment():
    with open(os.devnull, 'w+') as devnull:
        env = Environment(
            devnull=devnull,
            stdin=devnull,
            stdin_isatty=False,
            stdin_encoding=None,
            stdout=devnull,
            stdout_isatty=False,
            stdout_encoding=None,
            stderr=devnull,
            stderr_isatty=False,
            colors=0,
            program_name='program_name'
        )
    assert env.devnull is devnull
    assert env.stdin is devnull
    assert not env.stdin_isatty
    assert env.stdin_encoding is None
    assert env.stdout is devnull
    assert not env.stdout_isatty
    assert env

# Generated at 2022-06-21 13:44:50.882757
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    environment = Environment()

# Generated at 2022-06-21 13:45:12.779562
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()

    tmpfile = open("tmpfile", "w+")
    try:
        env.stderr = tmpfile
        env.log_error("Testing: log_error", "warning")
        tmpfile.seek(0)
        assert tmpfile.read() == '''
http: warning: Testing: log_error

'''
    finally:
        tmpfile.close()
        os.remove("tmpfile")

# Generated at 2022-06-21 13:45:24.355576
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    e = Environment(
        is_windows=False,
        config_dir=Path("test/httpie"),
        stdin=sys.stdin,
        stdin_isatty=sys.stdin.isatty(),
        stdin_encoding=None,
        stdout=sys.stdout,
        stdout_isatty=sys.stdout.isatty(),
        stdout_encoding=None,
        stderr=sys.stderr,
        stderr_isatty=sys.stderr.isatty(),
        colors=curses.tigetnum('colors')
    )

# Generated at 2022-06-21 13:45:31.173409
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env=Environment()
    #env.__dict__
    assert env.__dict__.get("_config") is None
    assert env.__dict__.get("_devnull") is None
    assert env.__dict__.get("stdin_encoding") == 'utf8'
    assert env.__dict__.get("stdout_encoding") == 'utf8'
    assert env.__dict__.get("_orig_stderr") is None
test_Environment___str__()

# Generated at 2022-06-21 13:45:39.926645
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    instance = Environment()
    assert str(instance) == str(str_expected)
    

# Generated at 2022-06-21 13:45:50.579818
# Unit test for constructor of class Environment
def test_Environment():
    env=Environment()
    assert env.is_windows == False
    assert env.colors == 256
    assert env.config_dir == Path('~/.httpie').expanduser()
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.program_name == 'http'
    assert env.stdin_encoding == 'utf8'
    assert env.stdout_encoding == 'utf8'


test_Environment()

# Generated at 2022-06-21 13:45:52.963431
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error(msg='a')
    env.log_error(msg='a', level='warning')

# Generated at 2022-06-21 13:45:59.271087
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    assert str(env) == '{\'colors\': 256, \'stdin_isatty\': True, \'stdin\': <_io.TextIOWrapper name=\'<stdin>\' mode=\'r\' encoding=\'cp936\'>, \'stdin_encoding\': \'cp936\', \'stdout_isatty\': True, \'stdout\': <_io.TextIOWrapper name=\'<stdout>\' mode=\'w\' encoding=\'cp936\'>, \'stderr_isatty\': True}'

# Generated at 2022-06-21 13:46:11.242862
# Unit test for method __str__ of class Environment

# Generated at 2022-06-21 13:46:13.898858
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    msg = 'hello world!'
    env.log_error(msg, level='error')
    env.log_error(msg, level='warning')



# Generated at 2022-06-21 13:46:21.600335
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    print(env)

# Generated at 2022-06-21 13:46:38.155843
# Unit test for constructor of class Environment
def test_Environment():
    if __name__ == '__main__':
        test_Environment()

# Generated at 2022-06-21 13:46:45.570558
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()

# Generated at 2022-06-21 13:46:56.899875
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from httpie.compat import isatty
    stdin, stdin_isatty = None, False
    stdout, stdout_isatty = None, False
    stderr, stderr_isatty = None, False
    if isatty(sys.stdin.fileno()):
        stdin = sys.stdin
        stdin_isatty = True
    if isatty(sys.stdout.fileno()):
        stdout = sys.stdout
        stdout_isatty = True
    if isatty(sys.stderr.fileno()):
        stderr = sys.stderr
        stderr_isatty = True

# Generated at 2022-06-21 13:46:59.753473
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    e = Environment()
    print(e)
    print(e.__repr__())


if __name__ == "__main__":
    test_Environment___repr__()

# Generated at 2022-06-21 13:47:10.046161
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    # We can't import the module directly because "httpie" is 
    # not the name of this file, but the name of the top-level module.
    from importlib import import_module
    httpie_module = import_module('httpie')
    env = httpie_module.Environment()

# Generated at 2022-06-21 13:47:11.478268
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    from httpie.environment import Environment
    assert repr(Environment()) == '<Environment {}>'

# Generated at 2022-06-21 13:47:20.936227
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    """
    >>> e = Environment()
    >>> print(e)
    {'is_windows': <class 'bool'>, 'config_dir': <class 'pathlib.PosixPath'>, 'stdin': <class '_io.TextIOWrapper'>, 'stdin_isatty': True, 'stdin_encoding': 'UTF-8', 'stdout': <class '_io.TextIOWrapper'>, 'stdout_isatty': True, 'stdout_encoding': 'UTF-8', 'stderr': <class '_io.TextIOWrapper'>, 'stderr_isatty': True, 'colors': 256, 'program_name': 'http', 'config': <httpie.config.Config object at 0x7f4d8cebd7b8>}
    """
    pass

# Generated at 2022-06-21 13:47:28.020380
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment(is_windows=False)
    assert e.is_windows == False
    assert e.config_dir == Path(DEFAULT_CONFIG_DIR)
    assert e.stdin == sys.stdin
    assert e.stdout == sys.stdout
    assert e.stderr == sys.stderr
    assert e.stderr_isatty == True
    assert e.stdout_isatty == True
    assert e.stdin_isatty == True



# Generated at 2022-06-21 13:47:33.331942
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    a = Environment()
    print(repr(a))
    Environment.is_windows = False
    print(repr(a))
    
    
    
import argparse
from httpie.core import main as core_main
from httpie.output.streams import Streams
from httpie.output.writers import get_preferred_writer
from httpie.status import ExitStatus



# Generated at 2022-06-21 13:47:44.988229
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(devnull=None,
                      is_windows=False,
                      config_dir='path/to/config_dir',
                      stdin='path/to/stdin',
                      stdin_isatty=True,
                      stdin_encoding='utf8',
                      stdout='path/to/stdout',
                      stdout_isatty=True,
                      stdout_encoding='utf8',
                      stderr='path/to/stderr',
                      stderr_isatty=True,
                      colors=256,
                      program_name='http')

# Generated at 2022-06-21 13:48:06.776477
# Unit test for constructor of class Environment
def test_Environment():
    class Env(Environment):
        pass
    env = Env()
    assert env
    assert env.stdin
    assert env.stdin_isatty
    assert env.stdout_isatty
    assert env.stderr_isatty
    assert env.config
    assert env.devnull
    assert env._orig_stderr
    assert env.config_dir
    assert env.devnull
    assert env._devnull
    assert env.stdin_encoding
    assert env.stdout_encoding
    assert env.program_name



# Generated at 2022-06-21 13:48:18.010529
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(is_windows=True)

    assert env.is_windows == True
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'

# Generated at 2022-06-21 13:48:29.198304
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    import sys
    from httpie.utils import stderr_isatty

    stdout = io.StringIO()
    stderr = io.StringIO()
    env = Environment(stdout=stdout,
                      stderr=stderr,
                      stderr_isatty=stderr_isatty(),
                      program_name='http', )
    env.log_error('error')
    expected = "\nhttp: error: error\n\n"
    assert stderr.getvalue() == expected
    # reset stdout and stderr
    stdout = io.StringIO()
    stderr = io.StringIO()

# Generated at 2022-06-21 13:48:33.337355
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert isinstance(env, Environment)
    # print(env.config_dir)
    # print(env.stdin_isatty)
    # print(env.stdout_isatty)
    # print(env.stderr_isatty)
    # print(env.colors)
    # print(env.stdin_encoding)
    # print(env.stdout_encoding)
    # print(env.__dict__)

# Generated at 2022-06-21 13:48:44.484542
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from unittest.mock import Mock

    _stderr = "{program_name}: {level}: {msg}"

    for program_name in ['http', 'https', 'http-http']:
        for level in ['error', 'warning']:
            for msg in ['BadRequest', 'InternalServerError', 'NotFound']:
                message = _stderr.format(program_name=program_name, level=level, msg=msg)
                _stderr = Mock()
                env = Environment(program_name=program_name, stderr=_stderr)
                env.log_error(msg=msg, level=level)
                _stderr.write.assert_called_once_with(f'\n{message}\n\n')
                _stderr.reset_mock()

# Generated at 2022-06-21 13:48:54.876938
# Unit test for method __repr__ of class Environment

# Generated at 2022-06-21 13:49:00.628329
# Unit test for method __str__ of class Environment
def test_Environment___str__():

    e = Environment(
        is_windows = True,
        config_dir = DEFAULT_CONFIG_DIR,
        stdin = None,
        stdin_isatty = False,
        stdin_encoding = None,
        stdout = sys.stdout,
        stdout_isatty = sys.stdout.isatty(),
        stdout_encoding = getattr(
            sys.stdout, 'encoding', None) or 'utf8',
        stderr = sys.stderr,
        stderr_isatty = sys.stderr.isatty(),
        colors = 256,
        program_name = 'http')
    str(e)



# Generated at 2022-06-21 13:49:11.486160
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdout=None, stderr=None, stdin=None,
                    stdin_isatty=None, stdin_encoding=None,
                    stdout_isatty=None, stdout_encoding=None,
                    stderr_isatty=None, colors=None, program_name=None,
                    devnull=None, config_dir=None, is_windows=False)
    assert env.stdout == None
    assert env.stderr == None
    assert env.stdin == None
    assert env.stdin_isatty == None
    assert env.stdin_encoding == None
    assert env.stdout_isatty == None
    assert env.stdout_encoding == None
    assert env.stderr_isatty == None
    assert env.colors

# Generated at 2022-06-21 13:49:14.647957
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(foo='bar')
    assert env.foo == 'bar'

# test_config_dir will test the default value of config_dir, which is DEFAULT_CONFIG_DIR

# Generated at 2022-06-21 13:49:20.779347
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    from httpie import __version__
    env = Environment()
    result = repr(env)