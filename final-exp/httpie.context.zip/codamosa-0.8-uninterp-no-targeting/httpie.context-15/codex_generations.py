

# Generated at 2022-06-21 13:40:06.502251
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        config_dir=Path('.'),
        stdin=None,
        stdin_isatty=False,
        stdin_encoding='utf8',
        stdout=None,
        stdout_isatty=False,
        stdout_encoding='utf8',
        stderr=None,
        stderr_isatty=False,
        colors=256,
        program_name='http',
    )
    assert env.config_dir == Path('.')
    assert env.stdin == None
    assert env.stdin_isatty == False
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == None
    assert env.stdout_isatty == False
    assert env.stdout_encoding == 'utf8'
   

# Generated at 2022-06-21 13:40:09.807925
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name="httpie",stdout=sys.stderr,stdin=sys.stdout,stdin_encoding="ascii",stdout_encoding="ascii",stderr_encoding="ascii")
    print(env)

# Generated at 2022-06-21 13:40:16.074998
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr)
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert type(env) == Environment

if __name__ == "__main__":
    test_Environment()

# Generated at 2022-06-21 13:40:19.658934
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    with open(__file__, 'rt') as f:
        env = Environment(stdin=f)
    repr(env) == repr(env.__dict__)

# Generated at 2022-06-21 13:40:30.942864
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment(is_windows=False, devnull=None, config_dir=Path('~/.config/httpie'), stdin=None, stdin_isatty=False, stdin_encoding=None, stdout=sys.stdout, stdout_isatty=True, stdout_encoding=None, stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http')


# Generated at 2022-06-21 13:40:43.814610
# Unit test for method __str__ of class Environment

# Generated at 2022-06-21 13:40:47.362364
# Unit test for constructor of class Environment
def test_Environment():
    # Given
    temp_dict = {'config_dir': '.httpie'}
    # When
    env = Environment(**temp_dict)
    # Then
    assert env.config_dir == '.httpie'



# Generated at 2022-06-21 13:40:49.917382
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    print(Environment())
    print(Environment(colors=8))


if __name__ == '__main__':
    test_Environment___repr__()

# Generated at 2022-06-21 13:40:57.310370
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import StringIO
    from unittest import TestCase
    from httpie.utils import make_sessions_streams_context

    class CustomTestCase(TestCase):
        def __init__(self, *args, **kwargs):
            self.saved_stderr = sys.stderr
            super().__init__(*args, **kwargs)
        @classmethod
        def setUpClass(self):
            self.env = Environment()
            self.stderr = StringIO()
            self.env.stderr = self.stderr
        @classmethod
        def tearDownClass(self):
            self.env.stderr = self.saved_stderr
            # ensure the stream is closed and the data is processed
            if self.stderr:
                self.stderr.close

# Generated at 2022-06-21 13:41:02.880453
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding is None
    assert env.stdout == sys.stdout
    asse

# Generated at 2022-06-21 13:41:17.200140
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(is_windows = True, config_dir = "C:\Program Files (x86)\HTTpie", stdin = None, stdin_isatty = False, stdin_encoding = None, stdout = sys.stdout, stdout_isatty = True, stdout_encoding = "ANSI_X3.4-1968", stderr = sys.stderr, stderr_isatty = True, colors = 256, program_name = "http")
    d = {}
    d['is_windows'] = env.is_windows
    d['config_dir'] = env.config_dir
    d['stdin'] = env.stdin
    d['stdin_isatty'] = env.stdin_isatty
    d['stdin_encoding'] = env.stdin_encoding


# Generated at 2022-06-21 13:41:18.361660
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    environment = Environment()
    assert str(environment)

# Generated at 2022-06-21 13:41:24.517130
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    sio = io.StringIO()
    env = Environment(stderr=sio, program_name='test')
    env.log_error('ERROR!', level='error')
    env.log_error('WARNING!', level='warning')
    assert 'test: error: ERROR!' in sio.getvalue()
    assert 'test: warning: WARNING!' in sio.getvalue()


# Default environment.
env = Environment()

# Generated at 2022-06-21 13:41:32.475741
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    from pytest import raises

    e = Environment(colors=256)
    assert e.__repr__() == f"<{type(e).__name__} <Environment " \
                           "{'colors': 256, 'config': <Config {}, " \
                           "'program_name': 'http', 'stderr_isatty': " \
                           "True, 'stdout_isatty': True}>>"

    e.__dict__['colors'] = None

    with raises(AssertionError):
        e.__repr__()

# Generated at 2022-06-21 13:41:39.200817
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    stdout_encoding = sys.stdout.encoding

# Generated at 2022-06-21 13:41:48.397568
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from httpie.context import Environment
    env = Environment(stdin=None, stdin_isatty=False, stdin_encoding='utf8', stdout=None, stdout_isatty=False, stdout_encoding='utf8')
    if not hasattr(env, '_orig_stderr'):
        env._orig_stderr = None
    if not hasattr(env, '_devnull'):
        env._devnull = None
    if not hasattr(env, '_config'):
        env._config = None
    print(env.__str__())
test_Environment___str__()

# Generated at 2022-06-21 13:41:50.417245
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    environment = Environment()
    result = environment.__repr__()
    assert isinstance(result, str)

# Generated at 2022-06-21 13:41:57.336393
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(foo='bar', colors=8)
    assert env.foo == 'bar'
    assert env.colors == 8
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert env.program_name == 'http'
    assert env.stdout_encoding == sys.stdout.encoding
    assert env.stderr_encoding == sys.stderr.encoding

# Generated at 2022-06-21 13:42:09.211243
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    """
    Method __str__ of class Environment in module httpie.context
    return str of self.__dict__
    """
    def get_Environment(Environment):
        Environment.__init__(Environment, 1, 2, 3, 4)
        return str(Environment)


# Generated at 2022-06-21 13:42:16.887013
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(is_windows=True, config_dir='/etc', colors=256, program_name='http')
    print(env)
    print(env.config)
    print(env._orig_stderr)
    print(env.devnull)
    print(env.devnull.getvalue())
    print(env.log_error('log message'))

if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-21 13:42:26.799248
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    # create instance of Environment
    env = Environment()
    #unit test for method log_error of class Environment
    env.log_error(msg = 'error', level='error')
    #expected output 'http: error: error'
    env.log_error(msg='warning', level='warning')
    #expected output 'http: warning: warning'

# Generated at 2022-06-21 13:42:30.040209
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    assert repr(Environment()) == '<Environment {}>'
    assert repr(Environment(foo='bar')) == '<Environment {\'foo\': \'bar\'}>'

# Generated at 2022-06-21 13:42:41.338427
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    environment = Environment()

    # test default values
    assert environment.is_windows == is_windows
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == (sys.stdin.isatty() if sys.stdin else False)
    assert environment.stdin_encoding == None
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == sys.stdout.isatty()
    assert environment.stdout_encoding == None
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == sys.stderr.isatty()
    assert environment.colors == 256
    assert environment.program_name == 'http'

    #

# Generated at 2022-06-21 13:42:53.225461
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(
        stdin=None,
        stdin_isatty=False,
        stdin_encoding='utf8',
        stdout='<_io.TextIOWrapper name=42 mode=w>',
        stdout_isatty=True,
        stdout_encoding='utf8',
        stderr='<_io.TextIOWrapper name=43 mode=w>',
        stderr_isatty=True,
        colors=256,
        program_name='http',
        config_dir='/home/user/.config/httpie',
    )

# Generated at 2022-06-21 13:42:57.031508
# Unit test for constructor of class Environment
def test_Environment():
    stdin = None
    stdout = sys.stdout
    stderr = sys.stderr

    env = Environment(stdin, stdout, stderr)
    assert (env.stdin, env.stdout, env.stderr) == (stdin, stdout, stderr)

# Generated at 2022-06-21 13:43:08.571444
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.devnull is None
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == getattr(sys.stdin, 'encoding', None) or 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == getattr(sys.stdout, 'encoding', None) or 'utf8'
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stder

# Generated at 2022-06-21 13:43:20.191882
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()

# Generated at 2022-06-21 13:43:22.181780
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env1 = Environment()
    env1.log_error('I am error')


# Generated at 2022-06-21 13:43:34.089276
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    # Case 1: devnull equals to None, is_windows equals to True, stdin is None,
    #         stdin_encoding is None, stdout_encoding is None, colors equals to 256
    env = Environment(devnull=None, is_windows=True, stdin=None, stdin_encoding=None, stdout_encoding=None, colors=256)

# Generated at 2022-06-21 13:43:43.840380
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()

# Generated at 2022-06-21 13:44:02.967299
# Unit test for constructor of class Environment
def test_Environment():
    from io import StringIO
    from httpie import ExitStatus

    env = Environment(
        program_name='httpie_test',
        stdin=StringIO('-\n'),
        stdin_encoding='utf8',
        stdout=StringIO(),
        stdout_encoding='utf8',
        stderr=StringIO(),
        stderr_isatty=True,
        colors=256,
        config_dir='config_dir',
        devnull='devnull'
    )
    assert env.program_name == 'httpie_test'
    assert env.stdin.read() == '-\n'
    assert env.stdin_encoding == 'utf8'
    assert env.stdout.write('httpie') == 6
    assert env.stdout_encoding == 'utf8'
   

# Generated at 2022-06-21 13:44:14.273314
# Unit test for constructor of class Environment

# Generated at 2022-06-21 13:44:23.553216
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    from httpie.utils import console


# Generated at 2022-06-21 13:44:30.936862
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    out = StringIO()
    env = Environment(stderr=out)

    # Make sure it logs errors to STDERR
    msg = 'This is a test error message'
    env.log_error(msg)
    assert msg in out.getvalue()
    out.truncate(0)

    # Warnings are also logged to STDERR
    msg = 'This is a test warning message'
    env.log_error(msg, level='warning')
    assert msg in out.getvalue()

# Generated at 2022-06-21 13:44:32.029146
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    e = Environment()
    print(repr(e))

# Generated at 2022-06-21 13:44:38.222305
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment(stdout=None, stderr=None)
    msg = 'Testing logs'
    env.log_error(msg)
    assert msg in env.stderr.getvalue()
    assert env.stderr.getvalue().startswith('\nhttp')
    assert env.stderr.getvalue().endswith('\n\n')

env: Environment = Environment()

# Generated at 2022-06-21 13:44:43.307921
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    class DummyStderr:
        def write(self, text):
            print(text)
    env = Environment(stderr=DummyStderr())
    env.log_error("dummy error")
    env.log_error("dummy warning", level='warning')



# Generated at 2022-06-21 13:44:52.304127
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    input_ = {
        'is_windows': is_windows,
        'config_dir': DEFAULT_CONFIG_DIR,
        'stdin': None,
        'stdin_isatty': False,
        'stdin_encoding': 'utf8',
        'stdout': sys.stdout,
        'stdout_isatty': sys.stdout.isatty(),
        'stdout_encoding': 'utf8',
        'stderr': sys.stderr,
        'stderr_isatty': sys.stderr.isatty(),
        'stderr_encoding': 'utf8',
        'colors': 256,
        'program_name': 'http'
    }
    expected_output = repr(input_)

# Generated at 2022-06-21 13:45:01.271829
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from httpie.context import Environment

    # The 2nd argument of the log_error method is in-place for future development
    env = Environment()
    env.log_error(msg='This is a test log', level='error')
    env.log_error(msg='This is a test log', level='warning')

    error_result = str(env)
    error_result = error_result.replace(' ', '')
    assert error_result.startswith('<Environment{') == True
    assert error_result.endswith('}>') == True



# Generated at 2022-06-21 13:45:11.010133
# Unit test for method __repr__ of class Environment

# Generated at 2022-06-21 13:45:36.374468
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from .testsuite import env_override

# Generated at 2022-06-21 13:45:42.871037
# Unit test for constructor of class Environment
def test_Environment():
    stream = Stream()
    env = Environment(
        is_windows=True,
        config_dir=Path('C:/httpie'),
        stdin=stream,
        stdout=sys.stderr,
        stderr=sys.stdout,
        program_name='httpie-test'
    )
    assert env.is_windows, 'is_windows is not True'
    assert env.config_dir, 'config_dir is not set'
    assert env.stdin.__class__ == stream.__class__, 'stdin is not stream'
    assert env.stdout.__class__ == sys.stderr.__class__, 'stdout is not stderr'
    assert env.stderr.__class__ == sys.stdout.__class__, 'stderr is not stdout'

# Generated at 2022-06-21 13:45:47.263782
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import StringIO
    env = Environment()
    env.program_name = 'httpie'
    env.stderr = StringIO()
    env.log_error("error message")
    assert env.stderr.getvalue() == '\nhttpie: error: error message\n\n'

# Generated at 2022-06-21 13:45:55.169585
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    test_env = Environment(devnull=None, is_windows=True, config_dir="test", stdin=None, stdin_isatty=False, stdin_encoding=None, stdout=None, stdout_isatty=False, stdout_encoding=None, stderr=None, stderr_isatty=False, colors=256, program_name="test")
    test_output = test_env.__str__()
    assert "is_windows" in test_output


# Generated at 2022-06-21 13:46:02.016173
# Unit test for constructor of class Environment
def test_Environment():
    import tempfile
    import shutil

    config_dir = tempfile.mkdtemp(suffix='.httpie')
    config_path = str(config_dir) + '\\config.json'

# Generated at 2022-06-21 13:46:07.192997
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment(stdout=StringIO(),
                      stderr=StringIO(),
                      program_name='http')
    env.log_error('some error')
    assert env.stderr.getvalue() == '\nhttp: error: some error\n\n'


# Generated at 2022-06-21 13:46:08.399444
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    assert str(Environment(devnull=None))

# Generated at 2022-06-21 13:46:18.470819
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    import json
    import io

    temp_stdout = io.StringIO()
    test = Environment(
        devnull='test',
        stdin=io.TextIOWrapper(io.BytesIO(b'test'), 'utf8'),
        stdout=io.TextIOWrapper(io.BytesIO(b'test'), 'utf8'),
        stderr=temp_stdout,
        colors=256,
        program_name='http',
    )
    out = json.loads(str(test))
    assert out['devnull'] == 'test'
    assert out['stdin'] == '<_io.TextIOWrapper name=\'<stdin>\' mode=\'r\' encoding=\'utf8\'>'
    assert out['stdin_isatty'] is False

# Generated at 2022-06-21 13:46:24.568474
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    stdout_encoding = sys.stdout.encoding
    default_dir = os.path.expanduser("~")+"/.httpie"
    env = Environment(devnull=None, is_windows=is_windows,config_dir=default_dir,stdin=sys.stdin,stdin_isatty=sys.stdin.isatty(),stdin_encoding=None,stdout=sys.stdout,stdout_isatty=sys.stdout.isatty(),stdout_encoding=None,stderr=sys.stderr,stderr_isatty=sys.stderr.isatty(),colors=256,program_name='http')

# Generated at 2022-06-21 13:46:28.530816
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error('Error', level='error')
    #env.log_error('Warning', level='warning')
    #env.log_error('Warning', level='warning')

# Generated at 2022-06-21 13:47:01.464793
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    assert repr(env) == '<Environment {...}>'
    env = Environment(devnull='devnull')
    assert repr(env) == '<Environment {...}>'

# Generated at 2022-06-21 13:47:04.684878
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    # httpie/core.py
    env = Environment()
    assert '<Environment' in str(env)
    assert 'stdin_isatty' in str(env)
    assert 'stdout_isatty' in str(env)

# Generated at 2022-06-21 13:47:15.374780
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    e = Environment(stdin_encoding='utf8', stdout_encoding='utf8')
    if e.is_windows:
        e.stderr = e.stdout

# Generated at 2022-06-21 13:47:21.985894
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert isinstance(env, Environment)
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.program_name == 'http'
    assert env.stdin_encoding == None
    assert env.stdout_encoding == None

# Generated at 2022-06-21 13:47:23.886905
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    assert 'Environment' in repr(env)  # Sanity check



# Generated at 2022-06-21 13:47:35.173031
# Unit test for constructor of class Environment
def test_Environment():
    """
    test cases for Environment class
    """
    env = Environment()
    assert env.stdin_encoding is None
    assert env.stdin_isatty is True
    assert env.stdout_encoding is None
    assert env.stdout_isatty is True
    assert env.stderr_isatty is True
    assert env.program_name == 'http'
    foo = Environment(stdin_encoding='bar',
                      stdin_isatty=True,
                      stdout_encoding='bar',
                      stdout_isatty=True,
                      stderr_isatty=True,
                      program_name='foo')
    assert foo.stdin_encoding == 'bar'
    assert foo.stdin_isatty is True

# Generated at 2022-06-21 13:47:46.221771
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()


# Generated at 2022-06-21 13:47:52.687889
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    str(Environment())

    import io
    import contextlib
    from httpie.input import SEP_CREDENTIALS

    @contextlib.contextmanager
    def dummy_std_streams():
        old_stdin, old_stdout, old_stderr = sys.stdin, sys.stdout, sys.stderr
        sys.stdin = io.StringIO('')
        sys.stdout = io.StringIO('')
        sys.stderr = io.StringIO('')
        yield
        sys.stdin, sys.stdout, sys.stderr = (
            old_stdin, old_stdout, old_stderr
        )

    import curses
    try:
        curses.setupterm()
    except curses.error:
        pass


# Generated at 2022-06-21 13:48:04.289825
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(program_name='http', colors=256, is_windows='True', stderr_isatty=True, stdout=sys.stdout,
                      stderr=sys.stderr, stdout_encoding='utf8', stderr_isatty=True, config_dir='default_config_dir',
                      stdin=sys.stdin, stdin_encoding='utf8', stdin_isatty=True, stdout_isatty=True)

# Generated at 2022-06-21 13:48:06.045864
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    environment = Environment()
    assert repr(environment) == '<Environment {\'config\': <Config loaded="True">}>'

# Generated at 2022-06-21 13:48:45.184334
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env._orig_stderr=open("data/actual_stream_stderr","w+")
    env.log_error("test_msg")
    env._orig_stderr.close()
    data = open("data/expected_stream_stderr","r")
    expected_output_stderr=data.read()
    data.close()
    data = open("data/actual_stream_stderr","r")
    actual_output_stderr=data.read()
    data.close()
    assert expected_output_stderr==actual_output_stderr
    os.remove("data/actual_stream_stderr")

# Generated at 2022-06-21 13:48:51.068582
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.program_name = 'http';
    env._orig_stderr.truncate(0)
    env._orig_stderr.seek(0, 1)
    env.log_error("Error message", level='error')
    env._orig_stderr.seek(0)
    assert env._orig_stderr.read() == '\nhttp: error: Error message\n\n'

# Generated at 2022-06-21 13:48:59.574015
# Unit test for constructor of class Environment
def test_Environment():
    import io

    fake_devnull = io.StringIO()

    env = Environment(
        devnull=fake_devnull,
        stdin=io.StringIO('test'),
        stdin_isatty=False,
        stdin_encoding='ascii',
        stdout=io.StringIO(),
        stdout_isatty=False,
        stdout_encoding='ascii',
        stderr=io.StringIO(),
        stderr_isatty=False,
        colors=10,
        program_name='test'
    )
    assert env.devnull == fake_devnull
    assert env.stdin.getvalue() == 'test'
    assert env.stdin_isatty == False
    assert env.stdin_encoding == 'ascii'
    assert env

# Generated at 2022-06-21 13:49:04.919783
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=None, config_dir=None, stdin=None, stdin_isatty=None,
                      stdin_encoding=None, stdout=None, stdout_isatty=None, stdout_encoding=None,
                      stderr=None, stderr_isatty=None, colors=None, program_name=None)
    print(env)

# Generated at 2022-06-21 13:49:08.274399
# Unit test for constructor of class Environment
def test_Environment():
    env=Environment()
    assert isinstance(env, Environment)
    print(env)
    assert isinstance(env.devnull, IO)


# Generated at 2022-06-21 13:49:18.107664
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    from io import StringIO
    from httpie.context import Environment

    env = Environment()
    env_str = env.__repr__()
    output = str(env_str)

# Generated at 2022-06-21 13:49:29.153886
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(config_dir='/dev/null')
    assert env.config_dir.__eq__('/dev/null')
    assert env.stdin.__eq__(sys.stdin)
    assert env.stdin_isatty.__eq__(sys.stdin.isatty())
    assert env.stdout.__eq__(sys.stdout)
    assert env.stdout_isatty.__eq__(sys.stdout.isatty())
    assert env.stderr.__eq__(sys.stderr)
    assert env.stderr_isatty.__eq__(sys.stderr.isatty())
    assert env.program_name.__eq__('http')
    

# Generated at 2022-06-21 13:49:30.882747
# Unit test for constructor of class Environment

# Generated at 2022-06-21 13:49:33.146770
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    r = repr(env)
    assert type(r) == str


# Generated at 2022-06-21 13:49:42.415912
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == False
    assert env.config_dir == Path(os.path.expanduser('~/.httpie'))
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert env.stdin_isatty == True
    assert env.stdout_isatty == True
    assert env.stderr_isatty == True
    assert env.stdin_encoding == 'UTF-8'
    assert env.stdout_encoding == 'UTF-8'
    assert env.program_name == 'http'
    assert env.colors == 256
    assert env.config.format == 'pretty'
    assert env.config.style == 'colors'