

# Generated at 2022-06-21 13:40:01.216766
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import StringIO
    from contextlib import redirect_stderr
    error_msg = 'an error occurred'
    program_name = 'httpie'
    stderr_file = StringIO()

    with redirect_stderr(stderr_file):
        E = Environment()
        E.program_name = program_name
        E.log_error(error_msg)

    assert(stderr_file.getvalue() == f'\n{program_name}: error: {error_msg}\n\n')

environ = Environment()

# Generated at 2022-06-21 13:40:11.273169
# Unit test for method __str__ of class Environment

# Generated at 2022-06-21 13:40:18.641773
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    sys.stderr = io.StringIO()
    env.log_error("test")
    assert sys.stderr.getvalue() == "\nhttp: error: test\n\n"
    env.log_error("test", level='warning')
    assert sys.stderr.getvalue() == "\nhttp: error: test\n\n\nhttp: warning: test\n\n"

# Generated at 2022-06-21 13:40:30.296370
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.stdout_encoding == 'utf8'
    assert env.stdin_encoding == 'utf8'
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert env.stdin_isatty == env.stdin.isatty()
    assert env.stdout_isatty == env.stdout.isatty()
    assert env.stderr_isatty == env.stderr.isatty()
    assert env.colors == 256
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.program_name == 'http'
    assert env._orig_stderr == sys

# Generated at 2022-06-21 13:40:43.053311
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    import io
    import os
    import sys
    import types
    import unittest
    from unittest import mock

    from httpie import __version__ as httpie_version
    from httpie.context import Environment
    from httpie.core import main
    from httpie.core import main_default_args
    from httpie.core import main_default_kwargs
    from httpie.plugins import default_plugins
    from httpie.plugins import plugin_manager

    class TestCase(unittest.TestCase):

        @property
        def stdin(self):
            return self._stdin

        @stdin.setter
        def stdin(self, value):
            self._stdin = value

        @property
        def stdout(self):
            return self._stdout


# Generated at 2022-06-21 13:40:51.787780
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env=Environment()
    assert str(env)=='{\'is_windows\': False, \'config_dir\': PosixPath(\'~\'.expanduser()/\'httpie\'), \'stdin\': <stdin>, \'stdin_isatty\': True, \'stdin_encoding\': \'UTF-8\', \'stdout\': <stdout>, \'stdout_isatty\': True, \'stdout_encoding\': \'UTF-8\', \'stderr\': <stderr>, \'stderr_isatty\': True, \'colors\': 256, \'program_name\': \'http\'}'

# Generated at 2022-06-21 13:41:03.884698
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    # Create dummy environment object
    dummy_env = Environment()

    # Stringify the dummy environment
    dummy_env_as_string = str(dummy_env)


# Generated at 2022-06-21 13:41:06.104117
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    Environment()
    Environment(stdout_encoding = 'stdout_encoding')

# Generated at 2022-06-21 13:41:15.993027
# Unit test for constructor of class Environment
def test_Environment():
    sys.stdin = stdin = object()
    sys.stdout = stdout = object()
    sys.stderr = stderr = object()
    env = Environment(
        is_windows=True,
        config_dir='foo',
        stdin=stdin,
        stdin_isatty=True,
        stdin_encoding='utf8',
        stdout=stdout,
        stdout_isatty=False,
        stdout_encoding='latin1',
        stderr=stderr,
        stderr_isatty=True,
        colors=16,
        program_name='foo'
    )

# Generated at 2022-06-21 13:41:27.172303
# Unit test for constructor of class Environment
def test_Environment():
    # Generate an environment instance
    env = Environment()

    # Test if stdin is a tty
    assert env.stdin_isatty == True

    # Test if stdout is a tty
    assert env.stdout_isatty == True

    # Test if stderr is a tty
    assert env.stderr_isatty == True

    # Test if stdin encoding is utf-8
    assert env.stdin_encoding == 'utf-8'

    # Test if stderr encoding is utf-8
    assert env.stderr_encoding == 'utf-8'

    # Test if stdout encoding is utf-8
    assert env.stdout_encoding == 'utf-8'

    # Test the color number of the environment
    assert env.colors == 256

    # Test

# Generated at 2022-06-21 13:41:33.767039
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    env.stdin_encoding
    env.stdout_encoding
    str(env)



# Generated at 2022-06-21 13:41:36.708694
# Unit test for constructor of class Environment
def test_Environment():
    # test for construction of Environment instance
    environment_instance = Environment()
    print(environment_instance)


# Test code for main execution
if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-21 13:41:37.631131
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    en = Environment()
    print(en)
    assert True

# Generated at 2022-06-21 13:41:45.483693
# Unit test for method __repr__ of class Environment

# Generated at 2022-06-21 13:41:56.605400
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    env.stdin = None

# Generated at 2022-06-21 13:42:08.426068
# Unit test for constructor of class Environment
def test_Environment():
    # If keyword arguments to overwrite
    # any of the class attributes for this instance
    # then assert all(hasattr(type(self), attr) for attr in kwargs.keys())
    # assert all(hasattr(type(self), attr) for attr in mat)

    class A:
        a = 1
        b = 2
        c = 3
        def __init__(self, **kwargs):
            assert all(hasattr(type(self), attr) for attr in kwargs.keys())
            self.__dict__.update(**kwargs)

    A(a=1, c=3)
    A(a=1, b=2)
    A(a=1, c=2)
    A(b=1, c=2)

# Generated at 2022-06-21 13:42:11.607074
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows

    env = Environment(devnull='/tmp/1')
    assert env.devnull.name == '/tmp/1'



# Generated at 2022-06-21 13:42:22.231290
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    import os
    import pathlib
    from io import BytesIO
    from httpie.utils import get_windows_console_encoding
    env = Environment(config_dir=pathlib.Path(os.getenv("HOME")+'/.config/httpie'))

# Generated at 2022-06-21 13:42:33.991606
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(stdin_encoding='utf8', stdout_encoding='utf8')

# Generated at 2022-06-21 13:42:41.508735
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    assert str(env) == "{'stdin': <_io.TextIOWrapper name='<stdin>' mode='r' encoding='cp936'>, 'stdout': <_io.TextIOWrapper name='<stdout>' mode='w' encoding='cp936'>, 'stderr': <_io.TextIOWrapper name='<stderr>' mode='w' encoding='cp936'>, '_devnull': None}"


# Generated at 2022-06-21 13:42:58.556748
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(colors = 257)
    assert str(env) == "{\'config\': <Config uninitialized>, \'colors\': 257, \'program_name\': \'http\', \'stdin\': <stdin>, \'stdin_isatty\': True, \'stdout\': <stdout>, \'stdout_isatty\': True, \'stderr\': <stderr>, \'stderr_isatty\': True, \'stdin_encoding\': None, \'stdout_encoding\': None, \'is_windows\': False, \'config_dir\': PosixPath(\'/home/sakshi/.config/httpie\')}"


# Generated at 2022-06-21 13:43:09.773102
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty() if sys.stdin else False
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'


# Generated at 2022-06-21 13:43:16.734187
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(
        config_dir=DEFAULT_CONFIG_DIR,
        stdin=sys.stdin,
        stdin_isatty=sys.stdin.isatty(),
        stdin_encoding=None,
        stdout=sys.stdout,
        stdout_isatty=sys.stdout.isatty(),
        stdout_encoding=None,
        stderr=sys.stderr,
        stderr_isatty=sys.stderr.isatty(),
        colors=256,
        program_name='http'
    )
    print(env)
    print(type(env))
    print(env)
    print(env.__dict__)
    curdir=os.path.dirname(os.path.abspath(__file__))


# Generated at 2022-06-21 13:43:28.873960
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    environment = Environment()

# Generated at 2022-06-21 13:43:39.986303
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    import datetime
    env = Environment(name = "Environment", \
        is_windows = False, \
        config_dir = "", \
        stdin = datetime.datetime.now(), \
        stdin_isatty = True, \
        stdout = datetime.datetime.now(), \
        stdout_isatty = True, \
        stderr = datetime.datetime.now(), \
        stderr_isatty = True, \
        colors = 256, \
        program_name = "http")

# Generated at 2022-06-21 13:43:41.875010
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    output = StringIO()
    stderr = env = Environment(stderr=output)
    env.log_error("This is Error Message")
    assert output.getvalue() == '\nhttp: error: This is Error Message\n\n'
    output.close()

# Generated at 2022-06-21 13:43:44.642558
# Unit test for constructor of class Environment
def test_Environment():
    Env = Environment(devnull = "This is devnull")
    print(Env.devnull)

if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-21 13:43:56.546425
# Unit test for method __repr__ of class Environment

# Generated at 2022-06-21 13:44:03.438458
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    import sys

    stdin, stdout, stderr = sys.stdin, sys.stdout, sys.stderr

# Generated at 2022-06-21 13:44:04.791925
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    assert type(str(env)) == str

# Generated at 2022-06-21 13:44:15.371426
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    print(repr(env))


# Generated at 2022-06-21 13:44:23.514548
# Unit test for constructor of class Environment
def test_Environment():
    env=Environment()
    print("输出环境：",env)
    env.stderr="test"
    print("输出环境：", env)
    #env.stderr = sys.stderr
    #print("输出环境：", env)
    print("输出环境：", env.config)
    print("输出环境：", env.config)
    env.config_dir="/test"
    print("输出环境：", env.config)

if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-21 13:44:35.288376
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    import io

    stdin = io.StringIO()
    stdout = io.StringIO()
    stderr = io.StringIO()
    env = Environment(
        stdin=stdin,
        stdin_isatty=False,
        stdout=stdout,
        stdout_isatty=False,
        stderr=stderr,
        stderr_isatty=False,
        colors=0,
        config_dir=None,
        program_name='http-run'
    )

    actual = str(env)

# Generated at 2022-06-21 13:44:40.856199
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from httpie.utils import stderr
    from contextlib import redirect_stderr
    from httpie.core import fatal
    env = Environment()
    stderr=sys.stderr
    with redirect_stderr(stderr):
        env.log_error('test error','error')
        env.log_error('test warning','warning')

# Generated at 2022-06-21 13:44:50.957663
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment(
        config_dir='/config_dir',
        stdin='stdin',
        stdin_isatty=False,
        stdin_encoding=None,
        stderr='stderr',
        stderr_isatty=False,
        stderr_encoding=None,
        stdout='stdout',
        stdout_isatty=False,
        stdout_encoding=None,
        is_windows=False,
        program_name='program_name',
        colors=256,
        logger_format='logger_format',
        devnull='devnull',
    )

# Generated at 2022-06-21 13:45:02.828576
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(program_name='http', stdin_isatty=True, stdin_encoding='utf8', stdout_isatty=True, stdout_encoding='utf8', stderr_isatty=True, colors=256, config_dir='/root/.config/httpie', is_windows=False)
    assert env.__str__() == "{'config_dir': PosixPath('/root/.config/httpie'), 'colors': 256, 'is_windows': False, 'stdin_encoding': 'utf8', 'program_name': 'http', 'stdin_isatty': True, 'stdout_isatty': True, 'stdout_encoding': 'utf8', 'stderr_isatty': True, 'config': <Config /root/.config/httpie/config.json>}"

# Generated at 2022-06-21 13:45:12.619768
# Unit test for constructor of class Environment
def test_Environment():
    import sys
    env = Environment()
    assert env.is_windows == sys.platform.startswith('win')
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.stdin_encoding is None
    assert env.stdout_encoding is None
    assert env.stderr_encoding is None
    assert env.program_name == 'http'
    assert env._devnull is None

    import os

# Generated at 2022-06-21 13:45:16.003895
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    testError = "This is a test error."
    env.log_error(testError, "warning")
    assert testError in env.stderr

env = Environment()



# Generated at 2022-06-21 13:45:26.778820
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    assert str(env) == '<Environment {}>'
    env = Environment(stdin=None)
    assert str(env) == '<Environment {stdin: None}>'
    env = Environment(stdin=None, stdin_isatty=False)
    assert str(env) == '<Environment {stdin: None, stdin_isatty: False}>'
    env = Environment(stdin=sys.stdin, stdin_isatty=False)
    assert str(env) == '<Environment {stdin: <_io.TextIOWrapper ' \
        'name=\'<stdin>\' encoding=\'UTF-8\'>, stdin_isatty: False}>'



# Generated at 2022-06-21 13:45:31.225501
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment(
        stderr = io.StringIO()
    )
    env.log_error('Unit test for log_error')
    stderr_str = env.stderr.getvalue()
    assert stderr_str == '\nhttp: error: Unit test for log_error\n\n'

# Generated at 2022-06-21 13:45:58.979601
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    # setUp
    stdin = sys.stdin
    stdout = sys.stdout
    stderr = sys.stderr
    config_dir = DEFAULT_CONFIG_DIR

# Generated at 2022-06-21 13:46:10.922983
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment(config_dir='/path/to/config', stdin=sys.stdin)

# Generated at 2022-06-21 13:46:20.351657
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    e = Environment()

# Generated at 2022-06-21 13:46:25.271093
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from httpie.utils import strip_ansi

    env = Environment()
    assert str(env) == strip_ansi(env.__str__())
    env.foo = 'bar'
    assert str(env) == strip_ansi(env.__str__())

# Generated at 2022-06-21 13:46:37.661662
# Unit test for constructor of class Environment
def test_Environment():
    # Initialize the environment, setting stdout_isatty to True
    env = Environment(stdout_isatty=True)
    if env.stdout_isatty:
        print("Stdout is a real terminal")
    else:
        print("Stdout is not a real terminal")

    if env.stderr_isatty:
        print("Stderr is a real terminal")
    else:
        print("Stderr is not a real terminal")

    if env.stdin_isatty:
        print("Stdin is a real terminal")
    else:
        print("Stdin is not a real terminal")

    print(f"Colors: {env.colors}")


    # print(repr(env))

if __name__ == "__main__":
    test_Environment()

# Generated at 2022-06-21 13:46:47.322760
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
                is_windows=True,
                stdin=None,
                stdin_isatty=False,
                stdin_encoding=None,
                stdout=None,
                stdout_isatty=False,
                stdout_encoding=None,
                stderr=None,
                stderr_isatty=False,
                colors=16,
                program_name='program_name',
                devnull=None
            )
    assert env.is_windows
    assert env.stdin == None
    assert env.stdin_isatty == False
    assert env.stdin_encoding == None
    assert env.stdout == None
    assert env.stdout_isatty == False
    assert env.stdout_encoding == None

# Generated at 2022-06-21 13:46:57.813776
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    environment = Environment()
    assert isinstance(environment, Environment)
    assert environment.is_windows == is_windows
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin is sys.stdin
    assert environment.stdin_isatty == sys.stdin.isatty()
    assert environment.stdin_encoding is None
    assert environment.stdout is sys.stdout
    assert environment.stdout_isatty == sys.stdout.isatty()
    assert environment.stdout_encoding is None
    assert environment.stderr is sys.stderr
    assert environment.stderr_isatty == sys.stderr.isatty()
    assert environment.colors == 256
    assert environment.program_name == 'http'

# Generated at 2022-06-21 13:47:07.945654
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding is None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding is None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'

    env2 = Environment(stdin='stdin_attr')

# Generated at 2022-06-21 13:47:09.799400
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    print(Environment())
    print(Environment(stdout_encoding="utf-8"))
    assert 1==1

# Generated at 2022-06-21 13:47:18.264996
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from httpie.compat import BytesIO, is_windows

    # On POSIX systems, the stderr stream is unbuffered. But we want to
    # have it buffered so that the test could pass regardless of the buffering
    # mode. For this reason, we wrap the input stream into our own buffer.
    if not is_windows:
        sys.stderr = BytesIO()

    try:
        env = Environment()
        env.log_error('test')
        assert sys.stderr.getvalue().startswith(b'\nhttp: error: test\n\n')
    finally:
        sys.stderr = sys.__stderr__

# Generated at 2022-06-21 13:47:44.224366
# Unit test for constructor of class Environment
def test_Environment():
    import io

    def test_stdin():
        return io.StringIO("My input")

    assert Environment(stdin=test_stdin()).stdin.read() == "My input"

    def test_stdout():
        return io.StringIO("My output")

    assert Environment(stdout=test_stdout()).stdout.getvalue() == "My output"

    def test_stderr():
        return io.StringIO("My error")

    assert Environment(stderr=test_stderr()).stderr.getvalue() == "My error"

# Generated at 2022-06-21 13:47:51.680276
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from httpie.context import Environment
    env = Environment()
    env.stdin = "sys.stdin"
    env.stdin_encoding = "stdin_encoding"
    env.stdout = "sys.stdout"
    env.stdout_encoding = "stdout_encoding"
    env.stderr = "sys.stderr"
    env.stderr_isatty = True
    env.config_dir = "config_dir"
    env.program_name = "http"
    env.colors = 256

# Generated at 2022-06-21 13:48:03.823511
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()

# Generated at 2022-06-21 13:48:10.130052
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == env.stdin.isatty()
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == env.stdout.isatty()
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == env.stderr.isatty()
    assert env.colors == 256
    # get the stdin_encoding of the stdin
    if env.stdin is not None:
        assert env.stdin_encoding == getattr(env.stdin, 'encoding', None) \
                                    

# Generated at 2022-06-21 13:48:21.195353
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    import io
    import tempfile

    # Test for write to a named pipe
    # Create a named pipe
    fd, named_pipe = tempfile.mkstemp(suffix='.fifo')

    # Open the named pipe
    with io.open(named_pipe, 'wb', buffering=0) as named_pipe_w:
        # Read from the named pipe
        with io.open(named_pipe, 'rb', buffering=0) as named_pipe_r:

            # Test for write to a named pipe
            # Create a named pipe
            fd2, named_pipe2 = tempfile.mkstemp(suffix='.fifo')

            # Open the named pipe

# Generated at 2022-06-21 13:48:29.200666
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    environment = Environment()
    environment.program_name = 'httpie_name'
    old_stderr = sys.stderr
    sys.stderr = io.StringIO()
    environment.log_error('Error message to print')
    output = sys.stderr.getvalue()
    sys.stderr.close()
    sys.stderr = old_stderr
    assert output == '\nhttpie_name: error: Error message to print\n\n'
    return True


# Generated at 2022-06-21 13:48:32.053640
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    class MyClass:
        x = 1
        y = 2
        z = 3
    my_instance = MyClass()
    my_instance.w = 4
    print (my_instance.__dict__)
    print (my_instance.__dict__)


# Generated at 2022-06-21 13:48:33.616434
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    assert type(Environment().__repr__()) is str
    # assert Environment().__repr__() is str

# Generated at 2022-06-21 13:48:44.790657
# Unit test for method __repr__ of class Environment

# Generated at 2022-06-21 13:48:55.192154
# Unit test for constructor of class Environment
def test_Environment():
    # When keyword argument is passed
    env = Environment(program_name="httpc")
    assert env.program_name == "httpc"
    assert env.program_name != "http"
    assert env.stdout_isatty != False
    assert env.stderr == sys.stderr
    assert env.stderr == "httpc: error: "
    # Only class attributes could be overwritten
    assert env.__dict__.keys() == {"program_name", "stdout_isatty", "stderr"}
    #  When keyword argument is not passed
    env = Environment()
    assert env.program_name != "httpc"
    assert env.program_name == "http"
    assert env.stdout_isatty != True
    assert env.stderr == sys.stderr

# Generated at 2022-06-21 13:49:42.139115
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from StringIO import StringIO
    import os
    import httpie.core
    env = httpie.core.Environment()
    original_stderr = env.stderr
    env.stderr = StringIO()
    env.log_error("This is a test")
    env.stderr.seek(0)
    output = env.stderr.read()
    assert output == "\nhttp: error: This is a test\n\n"
    env.stderr = original_stderr


# Generated at 2022-06-21 13:49:44.994089
# Unit test for constructor of class Environment
def test_Environment():
    import tempfile
    with tempfile.NamedTemporaryFile() as devnull:
        env = Environment(devnull=devnull)
        assert env.devnull == devnull

# Generated at 2022-06-21 13:49:54.976751
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import StringIO
    from sys import stdout
    from tempfile import TemporaryFile
    from types import SimpleNamespace as ns
    from unittest.mock import patch

    ensure_str = lambda x: x if isinstance(x, str) else x.decode()

    with patch('httpie.environment.sys.stderr', new=StringIO()) as mock_stderr, \
            patch('httpie.environment.sys.stdout', new=StringIO()) as mock_stdout:
        e = Environment(program_name='test')
        e.log_error('foo')

        assert ensure_str(mock_stderr.getvalue()) == '\ntest: error: foo\n\n'
        assert ensure_str(mock_stdout.getvalue()) == ''
