

# Generated at 2022-06-21 13:39:58.865872
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    print(env)
    assert str(env) == repr(env)



# Generated at 2022-06-21 13:40:01.120953
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment(devnull=True, config=True)
    assert repr(env) == "<Environment {devnull: True, config: True}>"

# Generated at 2022-06-21 13:40:10.419910
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert isinstance(env, Environment)
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env.config == Config(directory=DEFAULT_CONFIG_DIR)
    # Test __str__
    str_env = str(env)
    assert 'config_dir=\'' in str_env
    assert 'config=' in str_env
    assert 'stderr_isatty=\'' in str_env

# Generated at 2022-06-21 13:40:23.048874
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from io import StringIO
    env = Environment(stdin=StringIO('stdin'))

# Generated at 2022-06-21 13:40:28.285513
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(is_windows = True,
                      config_dir = Path('E:/config'),
                      stdin = 1,
                      stdin_isatty = False,
                      stdin_encoding = 1,
                      stdout = 2,
                      stdout_isatty = False,
                      stdout_encoding = 2,
                      stderr = 3,
                      stderr_isatty = False,
                      colors = 0,
                      program_name = 'http',
                      _orig_stderr = 4,
                      devnull = 5
                      )
    env.config_dir = Path('/usr/local/etc/httpie')

# Generated at 2022-06-21 13:40:40.251580
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import BytesIO
    from httpie import ExitStatus
    from httpie.context import Environment, ExitStatus
    from httpie.cli import parse_error
    from httpie.compat import is_windows
    from httpie.utils import ErrorString

    #pip install colorama
    import colorama
    if is_windows:
        colorama.init()

    standard_err = BytesIO()
    expected_stderr = b'\nhttp: error: Downloading http://httpbin.org/status/418 failed: Invalid status code \'418\'\n\n'
    env = Environment(stdout=BytesIO(),
                      stderr=standard_err)
    status = ExitStatus.OK

# Generated at 2022-06-21 13:40:51.271565
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    try:
        myenv = Environment(program_name='my_prog_name', is_windows=False, colors=256,
                            config_dir=Path('/home/toto/httpie'),
                            stdin=sys.stdin, stdin_isatty=True, stdin_encoding='utf8',
                            stdout=sys.stdout, stdout_isatty=True, stdout_encoding='utf8',
                            stderr=sys.stderr, stderr_isatty=True, stderr_encoding='utf8')
    except Exception as inst:
        print("Type of exception: " + str(type(inst)))
        print("Argument(s) of exception: " + str(inst.args))

# Generated at 2022-06-21 13:41:03.362142
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    env.config = Config()
    env.config.is_new = False
    env.config.load = lambda *_: None

# Generated at 2022-06-21 13:41:13.901039
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from httpie.context import Environment
    from httpie.compat import is_windows
    env = Environment()
    print(env)
    assert env.__str__() == '<Environment {}>'
    env.stdin = sys.stdin
    env.stdin_isatty = False
    env.stdin_encoding = ' utf8'
    env.stdout = sys.stdout
    env.stdout_isatty = False
    env.stdout_encoding = ' utf8'
    env.stderr = sys.stdout
    env.stderr_isatty = False
    env.stderr_encoding = ' utf8'
    env.program_name = 'http'
    env.is_windows = True
    env.colors = 256
    print(env)

# Generated at 2022-06-21 13:41:18.816401
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import StringIO
    env = Environment()
    env.stderr = StringIO()
    env.log_error("TEST ERROR MESSAGE")
    env.stderr.seek(0)
    assert env.stderr.read() == "\nhttp: error: TEST ERROR MESSAGE\n\n"

# Generated at 2022-06-21 13:41:28.136250
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    try:
        e = Environment()
        e
    except TypeError:
        pass
    # Variable Environment.colors must be immutable

# Generated at 2022-06-21 13:41:36.808614
# Unit test for constructor of class Environment
def test_Environment():
    import io
    import tempfile

    stdin = io.StringIO('stdin')
    stdout = io.StringIO()
    stderr = io.StringIO()

    env = Environment(
        devnull=tempfile.TemporaryFile(),
        stdin=stdin,
        stdin_isatty=False,
        stdout=stdout,
        stdout_isatty=False,
        stderr=stderr,
        stderr_isatty=False,
        colors=128,
        program_name='http-test'
    )

    assert env.stdin is stdin
    assert env.stdin_isatty is False
    assert env.stdin_encoding == 'utf-8'
    assert env.stdout is stdout
    assert env.stdout_isatty

# Generated at 2022-06-21 13:41:44.594887
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    assert str(env) == "{'config': None, 'stdin': <_io.TextIOWrapper name='<stdin>' mode='r' encoding='UTF-8'>, 'stdin_isatty': False, 'stdin_encoding': 'utf8', 'stdout': <_io.TextIOWrapper name='<stdout>' mode='w' encoding='utf8'>, 'stdout_isatty': False, 'stdout_encoding': 'utf8', 'stderr': <_io.TextIOWrapper name='<stderr>' mode='w' encoding='UTF-8'>, 'stderr_isatty': False, 'colors': 256, 'program_name': 'http'}"

# Generated at 2022-06-21 13:41:46.773013
# Unit test for constructor of class Environment
def test_Environment():
    if __name__ == "__main__":
        import doctest
        doctest.testmod()

# Generated at 2022-06-21 13:41:54.927749
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    import platform

    # GENERATE EXPECTED RESULT
    env = Environment()

    defaults = dict(type(env).__dict__)
    actual = dict(defaults)
    actual.update(env.__dict__)
    actual['config'] = env.config
    expected_result = repr_dict({
        key: value for key, value in actual.items() if not key.startswith('_')
    })

    # RUN FUNCTION UNDER TEST
    actual_result = str(env)

    # VERIFY
    assert actual_result == expected_result



# Generated at 2022-06-21 13:41:59.026864
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    print(str(Environment()))
    print(Environment())
    print(Environment(stdout=None, stdout_isatty=False, stdout_encoding="utf8"))
    print(Environment(stdout=None, stdout_encoding="utf8"))

# Generated at 2022-06-21 13:42:11.045730
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from faker import Faker
    faker = Faker()

# Generated at 2022-06-21 13:42:14.928605
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    msg = 'TEST _log_error'
    env._log_error(msg, level='error')
    assert ('http: error: %s'%(msg)) in env._orig_stderr.getvalue()
test_Environment_log_error()

# Generated at 2022-06-21 13:42:20.623904
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    from httpie.compat import terminal_supports_colors
    env = Environment()
    env.program_name = 'Test'
    env.stdout_isatty = True
    env.stderr_isatty = True
    env.colors = 255
    env.is_windows = True
    env.config_dir = 'abc'
    env.devnull = 'ba'
    env._config = 'acb'
    env._orig_stderr = 'abc'
    env.stdin = 'abc'
    env.stdin_isatty = True
    env.stdin_encoding = 'abc'
    env.stdout = 'abc'
    env.stdout_encoding = 'abc'
    env.stderr = 'abc'
    print(env)
    assert env.__

# Generated at 2022-06-21 13:42:33.118208
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    # Importing necessary packages
    import sys
    import os
    import shutil
    from pathlib import Path
    from io import StringIO
    import pytest
    from tempfile import TemporaryDirectory

    # Creates a temporary directory
    with TemporaryDirectory() as tmpdirname:

        # Copies the content of the config directory to the temporary directory
        dir_util.copy_tree(DEFAULT_CONFIG_DIR, tmpdirname)

        # Creates an environment object with a temporary config directory
        env = Environment(config_dir=tmpdirname)

        # Logs an error the message "Test 1"
        env.log_error("Test 1")

        # Read the content of stderr
        content = env._orig_stderr.read()

        # Compares the content with the expected output

# Generated at 2022-06-21 13:42:48.752563
# Unit test for method __str__ of class Environment
def test_Environment___str__():  # noqa
    from httpie import __version__
    from httpie.config import DEFAULT_CONFIG
    from httpie.core import is_windows
    from httpie.compat import is_py36
    from httpie.compat import is_pypy
    env = Environment()
    # the first line is a fixed title
    assert str(env).startswith('<Environment ')
    # check the version value
    assert f'"version": "{__version__}"' in str(env)
    # check the config attribute value
    assert '"config": {' in str(env)
    # check the is_windows value
    assert f'"is_windows": {is_windows}' in str(env)
    # check the colors value
    assert f'"colors": {env.colors}' in str(env)
   

# Generated at 2022-06-21 13:42:58.786886
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(stdin_encoding='utf8', stdout_encoding='utf8')

# Generated at 2022-06-21 13:43:09.945194
# Unit test for constructor of class Environment
def test_Environment():
    # 创建对象environment，默认值是正确的
    environment = Environment(devnull=object(), charset=None)
    assert environment.is_windows == is_windows
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == (sys.stdin.isatty())
    assert environment.stdin_encoding == None
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == (sys.stdout.isatty())
    assert environment.stdout_encoding == None
    assert environment.stderr == sys.stderr

# Generated at 2022-06-21 13:43:21.294239
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from pprint import pprint
    from httpie.compat import is_windows
    if is_windows:
        import colorama.initialise
        colorama.initialise.init()
        del colorama

    def get_default_env():
        default_env = Environment()
        default_env.stderr = sys.stderr
        default_env.stderr_isatty = sys.stderr.isatty()
        default_env.stderr_encoding = getattr(
            default_env.stderr, 'encoding', None) or 'utf8'
        default_env.stdout = sys.stdout
        default_env.stdout_isatty = sys.stdout.isatty()

# Generated at 2022-06-21 13:43:32.053620
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr)
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.stdin_encoding == sys.stdin.encoding
    assert env.stdout_encoding == sys.stdout.encoding

# Generated at 2022-06-21 13:43:42.457082
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    # When
    result = Environment(
        stdin='<stdin>',
        stdin_encoding='<stdin-encoding>',
        stdin_isatty=True,
        stdout='<stdout>',
        stdout_encoding='<stdout-encoding>',
        stdout_isatty=True,
        stderr='<stderr>',
        stderr_isatty=True,
        stderr_isatty = True,
        config_dir = "test_config_dir"
    ).__str__()

    # Then

# Generated at 2022-06-21 13:43:47.972124
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import StringIO
    from assertpy import assert_that

    env = Environment(stderr=StringIO())
    env.log_error("test")
    assert_that(env.stderr.getvalue()).is_equal_to("\nhttp: error: test\n\n")


# Generated at 2022-06-21 13:43:49.814952
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    print(env)
    sys.stdout.flush()

# Generated at 2022-06-21 13:43:55.258612
# Unit test for constructor of class Environment
def test_Environment():
    env1 = Environment()
    env2 = Environment(is_windows=True, config_dir=Path('/xyz'))
    assert not env1.is_windows
    assert env2.is_windows
    assert env1.config_dir == Path('/home/mukund/.config/httpie')
    assert env2.config_dir == Path('/xyz')

# Generated at 2022-06-21 13:43:57.960703
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(program_name='http')
    env_dict = dict(env.__dict__)
    env_dict.pop('config', None)
    assert str(env) == repr_dict(env_dict)

# Generated at 2022-06-21 13:44:18.799155
# Unit test for constructor of class Environment
def test_Environment():
    sys.stdin = sys.stdout = sys.stderr = None
    expected = {
        'is_windows': False,
        'config_dir': Path(DEFAULT_CONFIG_DIR),
        'stdin': None,
        'stdin_isatty': False,
        'stdin_encoding': 'utf8',
        'stdout': sys.stdout,
        'stdout_isatty': False,
        'stdout_encoding': 'utf8',
        'stderr': sys.stderr,
        'stderr_isatty': False,
        'colors': 256,
        'program_name': 'http'
    }
    assert Environment().__dict__ == expected
    assert Environment(is_windows=True).__dict__ == expected



# Generated at 2022-06-21 13:44:30.744501
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull='/dev/null', stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr, is_windows=True)

# Generated at 2022-06-21 13:44:42.473388
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from pathlib import Path
    env = Environment(stdout_encoding='utf8')
    stdout_encoding = env.stdout_encoding
    assert stdout_encoding == 'utf8'
    # httpie/compat.py:45
    # is_windows = sys.platform == 'win32'
    # httpie/compat.py:46
    # is_windows = False
    stdout_encoding = env.stdout_encoding
    env = Environment(stdout_encoding=None)
    # httpie/config.py:18
    # DEFAULT_CONFIG_DIR = Path(os.path.expanduser('~/.config/httpie'))
    config_dir = env.config_dir
    env = Environment(config_dir=Path('~/.config/httpie'))
    std

# Generated at 2022-06-21 13:44:49.837022
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    stderr = io.StringIO()
    env = Environment(program_name='test_httpie', stderr=stderr)
    env.log_error('error-msg')
    assert stderr.getvalue() == '\ntest_httpie: error: error-msg\n\n'
    stderr.truncate(0)
    stderr.seek(0)
    env.log_error('warning-msg', level='warning')
    assert stderr.getvalue() == '\ntest_httpie: warning: warning-msg\n\n'

# Generated at 2022-06-21 13:45:01.921168
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(devnull='devnull')

# Generated at 2022-06-21 13:45:04.087784
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()

    msg = repr(env)

    assert msg.startswith('<')
    assert msg.endswith('>')

# Generated at 2022-06-21 13:45:13.649138
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    import pytest
    e = Environment()

# Generated at 2022-06-21 13:45:25.417347
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin = sys.stdin,
                        stdout = sys.stdout,
                        stderr = sys.stderr,
                        config_dir = Path(DEFAULT_CONFIG_DIR),
                        stdin_encoding = None,
                        stdout_encoding = None,
                        stderr_isatty = False)
    assert env.stdin == sys.stdin and env.stdout == sys.stdout and env.stderr == sys.stderr
    assert env.stdin_isatty and env.stdout_isatty and not env.stderr_isatty
    assert env.stdin_encoding == 'UTF-8' and env.stdout_encoding == 'UTF-8'

    assert env.config_dir == Path(DEFAULT_CONFIG_DIR)
   

# Generated at 2022-06-21 13:45:29.134364
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    assert 'Environment' == type(env).__name__
    assert 'Environment' == env.__str__().split(' ')[0]
    assert 'http' == env.__str__().split(' ')[1]

# Generated at 2022-06-21 13:45:33.116599
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    e = Environment()
    e.stderr = io.StringIO()
    e.log_error('some_error_msg')
    e.stderr.write('some_error_msg')
    assert e.stderr.getvalue() == 'some_error_msg'

# Generated at 2022-06-21 13:45:51.329200
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(colors = 256, is_windows = False, config_dir = '.', stdin = sys.stdin, stdin_isatty = True, stdin_encoding = 'utf8', stdout = sys.stdout, stdout_isatty = True, stdout_encoding = 'utf8', stderr = sys.stderr, stderr_isatty = True, program_name = 'http')
    assert env.is_windows == False
    assert env.config_dir == '.'
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == True
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stdout_enc

# Generated at 2022-06-21 13:46:00.029771
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    class Env(Environment):
        def __init__(self, **kwargs):
            super(Env, self).__init__()
            self.__dict__.update(**kwargs)

    env = Env()
    assert 'stdin={stdin}' in str(env)
    assert 'stdin_isatty=True' in str(env)
    assert 'stdout={stdout}' in str(env)
    assert 'stdout_isatty=True' in str(env)
    assert 'stderr={stderr}' in str(env)
    assert 'stderr_isatty=True' in str(env)
    assert 'colors=256' in str(env)
    assert 'program_name=http' in str(env)
    assert 'config=<Config' in str

# Generated at 2022-06-21 13:46:11.787403
# Unit test for method __str__ of class Environment

# Generated at 2022-06-21 13:46:20.988064
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import StringIO
    from httpie.context import Environment
    from httpie.compat import is_py26

    # Python 2.6 doesn't have getvalue() method for io.StringIO
    # so we have to use io.BytesIO
    if not is_py26:
        from io import BytesIO
        stdout = BytesIO()
    else:
        from cStringIO import StringIO
        stdout = StringIO()

    env = Environment(stdout=stdout, stderr=stdout)
    msg = 'test'

    # test error message
    env.log_error(msg)
    assert msg in stdout.getvalue()

    # test warning message
    stdout.truncate(0)
    env.log_error(msg, level='warning')
    assert msg in stdout.get

# Generated at 2022-06-21 13:46:33.945003
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    from httpie.core import Environment
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.utils import repr_dict
    from httpie.config import Config
    #For test
    import sys 
    env = Environment(devnull='b')
    env.stdin = sys.stdin
    env.stdin.encoding = 'utf8'
    env.stdin.isatty = False
    env.stdout = sys.stdout
    env.stdout.encoding = 'utf8'
    env.stdout.isatty = True
    env.stderr = sys.stderr
    env.stderr.encoding = 'utf8'
    env.stderr.isatty = True
    env.colors = 256
    env.program_name = 'http'


# Generated at 2022-06-21 13:46:38.624231
# Unit test for constructor of class Environment
def test_Environment():
    new_stdout = sys.stdout
    new_program_name = "http"
    environment = Environment(stdout = new_stdout, program_name = new_program_name)
    assert environment.stdout == new_stdout
    assert environment.program_name == new_program_name

# Generated at 2022-06-21 13:46:49.343750
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    environment = Environment()

# Generated at 2022-06-21 13:46:58.910294
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.stdin_encoding is None
    assert env.stdout_encoding is None
    assert env.stderr_encoding is None
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env.devnull is None
    assert env._devnull is None

# Generated at 2022-06-21 13:47:03.838446
# Unit test for constructor of class Environment
def test_Environment():
    import sys
    import tempfile
    args = ['program_name', 'config_dir']
    values = ['http', tempfile.NamedTemporaryFile()]
    env = Environment(*values, **dict(zip(args, values)))
    for arg, value in zip(args, values):
        assert getattr(env, arg) == value
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr

# Generated at 2022-06-21 13:47:08.823207
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    assert str(Environment(devnull=open('/dev/null', 'w+'), config_dir=Path('./'))) == '<Environment {\'config_dir\': PosixPath("./"), \'devnull\': <_io.TextIOWrapper name=/dev/null mode=w+ encoding=ANSI_X3.4-1968>}>'

# Generated at 2022-06-21 13:47:18.895954
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    print(Environment(stdout_encoding=None))

if __name__ == '__main__':
    test_Environment___str__()

# Generated at 2022-06-21 13:47:19.746874
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    Environment()


# Generated at 2022-06-21 13:47:27.614266
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(
        stdin=None,
        stdin_isatty=None,
        stdout=None,
        stdout_isatty=None,
        stderr=None,
        stderr_isatty=None,
        colors=None,
        program_name=None,
        # _orig_stderr=None,
        _devnull=None,
        config_dir=None,
        # _config=None
    )
    print(str(env))

# Generated at 2022-06-21 13:47:39.296986
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    env.stdin = 'stdin'
    env.stdout = 'stdout'
    env.stderr = 'stderr'
    env.stdin_encoding = 'stdin_encoding'
    env.stdout_encoding = 'stdout_encoding'
    env.program_name = 'program_name'
    env.is_windows = True
    env.config_dir = 'config_dir'
    assert env.stdin == 'stdin'
    assert env.stdout == 'stdout'
    assert env.stderr == 'stderr'
    assert env.stdin_encoding == 'stdin_encoding'
    assert env.stdout_encoding == 'stdout_encoding'
    assert env.program_name == 'program_name'
   

# Generated at 2022-06-21 13:47:49.031826
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(config_dir='/some/path')

# Generated at 2022-06-21 13:47:59.958891
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(program_name="http",stdin_isatty=False,stdout_isatty=True,stderr_isatty=False,colors=256,stdin_encoding="utf8",stdout_encoding="utf8",is_windows=False)
    assert str(env) == "{'is_windows': False, 'stdin_isatty': False, 'stdout_isatty': True, 'stderr_isatty': False, 'colors': 256, 'stdin_encoding': 'utf8', 'stdout_encoding': 'utf8', 'config': {}}"


# Generated at 2022-06-21 13:48:02.926863
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.stdin is sys.stdin
    assert env.stdout is sys.stdout
    assert env.stderr is sys.stderr


# Generated at 2022-06-21 13:48:08.049960
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from httpie.utils import StdoutBytesIO
    sut = Environment()
    strm = StdoutBytesIO()
    sut._orig_stderr = strm
    sut.program_name = 'http'
    sut.log_error('error-message')
    assert strm.getvalue() == b'\nhttp: error: error-message\n\n'


# Generated at 2022-06-21 13:48:18.452779
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
   env = Environment()
   assert env.__repr__() == '<Environment {' \
                            '"config": None, ' \
                            '"stderr": <_io.TextIOWrapper name=2 mode=w encoding=UTF-8>, ' \
                            '"stderr_isatty": True, ' \
                            '"stdin": <_io.TextIOWrapper name=0 mode=r encoding=UTF-8>, ' \
                            '"stdin_isatty": True, ' \
                            '"stdout": <_io.TextIOWrapper name=1 mode=w encoding=UTF-8>, ' \
                            '"stdout_isatty": True}>'

# Generated at 2022-06-21 13:48:29.475958
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    import io
    import os
    import sys
    from httpie.context import Environment
    from contextlib import redirect_stdout

    env = Environment()
    sys.stdout = io.StringIO()
    print(repr(env))
    print(repr(env))
    output = sys.stdout.getvalue()
    print(output.strip())
    with redirect_stdout(env.devnull):
        print(repr(env))
        print(repr(env))
    output = sys.stdout.getvalue()
    print(output.strip())
    sys.stdout.close()
    sys.stdout = sys.__stdout__

# Generated at 2022-06-21 13:48:39.864643
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()

    assert repr(env) == '<Environment {}>'

test_Environment___repr__()

# Generated at 2022-06-21 13:48:41.297277
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    if not isinstance(Environment().__repr__(), str):
        raise Exception('function __repr__ did not return expected value')



# Generated at 2022-06-21 13:48:49.024545
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    r = repr(Environment())
    assert isinstance(r, str)
    assert r.startswith('<Environment ')
    assert r.endswith('}>')

    all_keys_found = True
    for k in ['program_name', 'is_windows', 'config_dir', 'stdin', 'stdin_isatty', 'stdin_encoding', 'stdout', 'stdout_isatty', 'stdout_encoding', 'stderr', 'stderr_isatty']:
        if k not in r:
            all_keys_found = False
    assert all_keys_found

# Generated at 2022-06-21 13:48:58.469925
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    with open('environment_test_file.py', 'w+') as test_file:
        test_file.write('from environment_test_file_0 import *')
        # If the above command was executed, the following line would be invalid.
        # environment_test_file_0.py has not been generated yet. So this code is commented out
        #from environment_test_file_0 import *
        test_file.write('from environment_test_file_1 import *')

    env = Environment()
    # The following two lines are commented out due to the format of the file
    #print(Environment.DEFAULT_CONFIG_DIR)
    #print(env.DEFAULT_CONFIG_DIR)
    assert env.DEFAULT_CONFIG_DIR == Environment.DEFAULT_CONFIG_DIR
    assert env.stdin == sys.std

# Generated at 2022-06-21 13:49:09.060499
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment(
        is_windows=True,
        config_dir='/Users/joe/storage/config',
        stdin=sys.stdin,
        stdin_isatty=sys.stdin.isatty(),
        stdin_encoding=None,
        stdout=sys.stdout,
        stdout_isatty=sys.stdout.isatty(),
        stdout_encoding=None,
        stderr=sys.stderr,
        stderr_isatty=sys.stderr.isatty(),
        colors=256,
        program_name='http'
    )


# Generated at 2022-06-21 13:49:13.756248
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(is_windows=False, colors=256, program_name='http')
    assert env.is_windows == False
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env.config == Config(directory=DEFAULCONFIGDIR)

# Generated at 2022-06-21 13:49:21.513587
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        config_dir='some_path',
        stdin='input_stream_obj',
        stdin_isatty='stdin_isatty_bool',
        stdin_encoding='input_encoding',
        stdout='stdout_stream_obj',
        stdout_isatty='stdout_isatty_bool',
        stdout_encoding='stdout_encoding',
        stderr='stderr_stream_obj',
        stderr_isatty='stderr_isatty_bool',
        colors='colors',
        program_name='name_of_program'
    )
    assert isinstance(env, Environment)
    assert env.config_dir == 'some_path'
    assert env.stdin == 'input_stream_obj'

# Generated at 2022-06-21 13:49:24.742609
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(foo='bar', baz='spam')
    assert 'foo' in repr(env)
    assert 'baz' in repr(env)
    assert 'spam' in repr(env)

# Generated at 2022-06-21 13:49:28.987099
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
  env = Environment(
        stdin_encoding = 'utf-8',
        stdout_encoding = 'utf-8',
        colors=256,
        devnull = None,
        program_name = 'http',
        is_windows = is_windows)
  assert env.__repr__() is not None

# Generated at 2022-06-21 13:49:31.347201
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    print(env)


if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-21 13:49:55.801148
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert isinstance(env, Environment)
    assert env.config_dir == Path.home().joinpath('.config/httpie')
    assert env.stdin is sys.stdin
    assert env.stdout is sys.stdout
    assert env.stderr is sys.stderr
    assert env.stdin_encoding == 'utf8'
    assert env.stdout_encoding == 'utf8'
    assert env.stderr_encoding is None
    assert env.is_windows is True
    assert env.stdin_isatty is True
    assert env.stdout_isatty is True
    assert env.stderr_isatty is True
