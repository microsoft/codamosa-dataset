

# Generated at 2022-06-21 13:40:04.350082
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    import sys
    from httpie.environment import Environment
    from io import StringIO
    from unittest.mock import patch

    # mock stdout and stderr, so that testing will work in IDE
    with patch.object(sys, '__stdout__', new_callable=StringIO):
        with patch.object(sys, '__stderr__', new_callable=StringIO):
            env = Environment()
            assert env.__repr__() == '<Environment {}>'
            env.is_windows = True
            assert env.__repr__() == '<Environment {}>'

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-21 13:40:08.503463
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    assert env.__str__() == '{\'colors\': 256, \'config_dir\': Path(\'%s\'), \'config\': <httpie.config.Config .httpie>}' %env.config_dir


# Generated at 2022-06-21 13:40:10.943375
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment(a=1).a == 1
    assert Environment(a_class_does_not_exist=1)


# Generated at 2022-06-21 13:40:23.558514
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        stdin=None,
        stdin_isatty=False,
        stdin_encoding=None,
        stdout=sys.stdout,
        stdout_isatty=sys.stdout.isatty(),
        stdout_encoding=None,
        stderr=sys.stderr,
        stderr_isatty=sys.stderr.isatty(),
        colors=256,
        program_name='httpie',
        _config=None,
        _orig_stderr=sys.stderr,
        _devnull=None,
        is_windows=False,
        config_dir=Path('/usr/local/etc/httpie'),
    )


# Generated at 2022-06-21 13:40:28.855845
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    import os
    default_stdin = sys.stdin
    default_stdout = sys.stdout
    default_stderr = sys.stderr


# Generated at 2022-06-21 13:40:41.329864
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    environment = Environment(
        is_windows = True,
        config_dir = './config',
        stdin = sys.stdin,
        stdin_isatty = True,
        stdin_encoding = 'utf-8',
        stdout = sys.stdout,
        stdout_isatty = True,
        stdout_encoding = 'utf-8',
        stderr = sys.stderr,
        stderr_isatty = True,
        colors = 256,
        program_name = 'http',
        config = Config('/config')
    )
    assert isinstance(environment, Environment)

# Generated at 2022-06-21 13:40:42.948842
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    assert '<Environment' in str(Environment())


# Generated at 2022-06-21 13:40:53.357618
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    stdin = sys.stdin
    stdout = sys.stdout
    stderr = sys.stderr
    config_dir = '/Users/x/y'
    env = Environment(
        stdin=stdin, stdout=stdout, stderr=stderr, config_dir=config_dir
    )

# Generated at 2022-06-21 13:41:05.477541
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    from httpie import __version__
    from httpie.output.streams import DefaultStreams

    # Default value for *_encoding is None. This can
    # only happen in Production. In tests there is
    # always encoding in stdin, stdout or stderr
    env = Environment()
    assert env.stdin_encoding is None
    assert env.stdout_encoding is None
    assert env._orig_stderr == sys.stderr

    # Here we test without setting streams, thus they
    # remain unchanged - sys.stdin, sys.stdout, sys.stderr
    env = Environment(
        colors = 256,
        program_name = "http",
        is_windows = False
    )
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout


# Generated at 2022-06-21 13:41:06.877859
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    print(env)


# Generated at 2022-06-21 13:41:15.049070
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.stderr = io.StringIO()
    env.log_error('test', level='error')
    assert env.stderr.getvalue() == '\nhttp: error: test\n\n'



# Generated at 2022-06-21 13:41:26.078356
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    def test(env: Environment, expected: str):
        assert str(env) == expected

    env = Environment()


# Generated at 2022-06-21 13:41:28.461248
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    class MyEnv(Environment):
        pass

    env=MyEnv()
    assert repr(env) == '<MyEnv {}>'


# Generated at 2022-06-21 13:41:31.330801
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment(stdin_encoding='cp1252').stdin_encoding == 'cp1252'
    assert Environment().stdin_encoding == 'utf8'

# Generated at 2022-06-21 13:41:35.057258
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=False)
    assert env.stdin_encoding == 'utf8'
    assert env.stdout_encoding == 'utf8'
    config = env.config
    assert config.directory == DEFAULT_CONFIG_DIR
    assert env.devnull is False

# Generated at 2022-06-21 13:41:39.336567
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    sys.stderr = StringIO()
    env = Environment()
    env.log_error('Unexpected error')
    sys.stderr.seek(0)
    assert sys.stderr.read() == '\nhttp: error: Unexpected error\n\n'


# Generated at 2022-06-21 13:41:47.842719
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    # If there is a problem in the development of log_error, we expect to
    # write the script.
    
    with open('test_log_error.txt', 'w') as f:
        output = sys.stdout
        sys.stdout = f
        env = Environment()
        msg = "error in log_error"
        env.log_error(msg)
        assert "http: error: error in log_error" in output.read()
        sys.stdout = output


if __name__ == "__main__":
    test_Environment_log_error()

# Generated at 2022-06-21 13:41:57.683131
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(
        config_dir='/home/configs',
        stdin=None,
        stdin_isatty=True,
        stdin_encoding='utf8',
        stdout=None,
        stdout_isatty=True,
        stdout_encoding='utf8',
        stderr=None,
        stderr_isatty=True,
        colors=256,
        program_name='http'
    )
    str_env=str(env)
    assert type(str_env) is str
    assert 'config_dir' in str_env
    assert 'stdin' in str_env
    assert 'stdin_isatty' in str_env
    assert 'stdin_encoding' in str_env
    assert 'stdout' in str_env

# Generated at 2022-06-21 13:42:09.716515
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(is_windows=True, colors=256)
    assert str(env) == '''{'colors': 256, 'is_windows': True, 'program_name': 'http', 'config_dir': PosixPath('~/.config/httpie'), 'stdin': <stdin>, 'stdin_isatty': True, 'stdout': <stdout>, 'stdout_isatty': True, 'stderr': <stderr>, 'stderr_isatty': True, 'config': <Config (1.0.3)>}'''

    env = Environment(is_windows=False, colors=256)

# Generated at 2022-06-21 13:42:20.933074
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    test_Environment_log_error.tmp_file_path = '~/TempFileFor_test_Environment_log_error.txt'
    tmp_file_path = os.path.expanduser(test_Environment_log_error.tmp_file_path)

    tmp_file_path_open = open(tmp_file_path, 'w')
    tmp_file_path_open.write('0')

    env = Environment(stdout=None, stderr=None, program_name='http')
    env.stderr = tmp_file_path_open

    env.log_error('test 1')
    env.log_error('test 2', level='warning')

    tmp_file_path_open.close()

    with open(tmp_file_path, 'r') as file:
        data = file.read()


# Generated at 2022-06-21 13:42:32.044976
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from tempfile import TemporaryDirectory
    env=Environment(config_dir=TemporaryDirectory().name)
    assert str(env).startswith('<Environment ') and str(env).endswith('>')
    assert 'config_dir' in str(env) and 'config' in str(env)

# Generated at 2022-06-21 13:42:39.840442
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    actual_stdout = sys.stdout
    try:
        sys.stdout = open('stdout.txt', 'w+')
        env = Environment()
        env.program_name = 'http'
        env.log_error('This is a test')
    finally:
        sys.stdout.close()
        sys.stdout = actual_stdout
    with open('stdout.txt', 'r') as fp:
        assert fp.read() == '\nhttp: error: This is a test\n\n'



# Generated at 2022-06-21 13:42:40.977604
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    print(Environment())



# Generated at 2022-06-21 13:42:49.502689
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    print('{0.is_windows} {0.config_dir}'.format(env))
    print('{0.stdin} {0.stdin_isatty} {0.stdin_encoding}'.format(env))
    print('{0.stdout} {0.stdout_isatty} {0.stdout_encoding}'.format(env))
    print('{0.stderr} {0.stderr_isatty}'.format(env))

if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-21 13:42:59.311817
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()

# Generated at 2022-06-21 13:43:10.305650
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment(program_name="test name",config_dir="test dir")

# Generated at 2022-06-21 13:43:22.080858
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    # creating an instance of Environment
    env = Environment()
    # assertEqual:
    # assert env.__str__() == '{"colors": 256, "config_dir": "/home/marek/.config/httpie", "config": <httpie.config.Config config_dir="/home/marek/.config/httpie">, "is_windows": 0, "program_name": "http", "stdin": <_io.TextIOWrapper name=0 encoding="utf8">, "stdin_encoding": "utf8", "stdin_isatty": 1, "stdout": <_io.TextIOWrapper name=27 encoding="utf8">, "stdout_encoding": "utf8", "stdout_isatty": 1, "stderr": <_io.TextIOWrapper name=28 encoding="

# Generated at 2022-06-21 13:43:25.238224
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error(msg="Testing the error message")
    env.log_error(msg="Testing the warning message", level="warning")

# Generated at 2022-06-21 13:43:36.920881
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from httpie import ExitStatus
    from httpie.cli import get_exit_status

    class Env(Environment):
        def __init__(self):
            self.stdin_isatty = None
            self.stdout_isatty = None
            self.stderr_isatty = None

    ex_exit_status = ExitStatus(get_exit_status(0, 0, None))
    ex_exit_status.options = "test_options"

    env = Env()
    env.exit_status = ex_exit_status
    env.stdin = "test_stdin"
    env.stdout = "test_stdout"
    env.stderr = "test_stderr"
    env.config_dir = "test_config_dir"

# Generated at 2022-06-21 13:43:45.363812
# Unit test for method __str__ of class Environment

# Generated at 2022-06-21 13:44:05.040029
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    import io
    import random
    import string

    stdout = io.StringIO()
    stderr = io.StringIO()
    stdin = io.StringIO()
    dir = ''.join(random.choices(string.ascii_uppercase + string.digits, k=10))

# Generated at 2022-06-21 13:44:14.271427
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    import sys
    s = io.StringIO()
    env = Environment(devnull=None)
    env._orig_stderr = s
    env.log_error('test error', level='error')
    assert s.getvalue() == '\nhttp: error: test error\n\n'
    s = io.StringIO()
    env = Environment(devnull=None)
    env._orig_stderr = s
    env.log_error('test warning', level='warning')
    assert s.getvalue() == '\nhttp: warning: test warning\n\n'

# Generated at 2022-06-21 13:44:15.797118
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    dir1 = Path.cwd()
    env1 = Environment(config_dir=dir1)

    dir2 = Path.home()
    env2 = Environment(config_dir=dir2)

    assert str(env1) != str(env2)

# Generated at 2022-06-21 13:44:20.307277
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    env_repr = env.__repr__()
    print(f'env_repr={env_repr}')
    print(f'env={env}')
    assert str(env_repr) == env.__str__()
    assert str(env_repr) == str(env)

# Generated at 2022-06-21 13:44:28.715505
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.program_name == 'http'
    assert environment.stderr_isatty is True
    assert environment.stdout_isatty is True
    assert environment.stdin_isatty is False
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.is_windows is False
    assert environment.stdout_encoding == 'utf8'
    assert environment.stdin_encoding == None
    assert environment.stderr_encoding == None



# Generated at 2022-06-21 13:44:38.542586
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().is_windows == True
    assert Environment().config_dir == DEFAULT_CONFIG_DIR
    #assert Environment().stdin == sys.stdin
    assert Environment().stdin_isatty == False
    assert Environment().stdin_encoding == None
    assert Environment().stdout == sys.stdout
    assert Environment().stdout_isatty == True
    assert Environment().stdout_encoding == 'utf8'
    assert Environment().stderr == sys.stderr
    assert Environment().stderr_isatty == True
    assert Environment().colors == 256
    assert Environment().program_name == 'http'
    
    
    


import pytest


# Generated at 2022-06-21 13:44:40.506255
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    assert str(env) == 'Environment'

# Generated at 2022-06-21 13:44:47.866507
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    # we only need to test if we can find the expected text to be printed
    # we do not need to test the result of the method
    # since we do not have enough information about the caller,
    # we only can test the error level to be at least 'error'
    try:
        env.log_error("test_error_log")
        assert len(env._orig_stderr.getvalue()) > 0
    except Exception as e:
        print(e)
        assert False, f"unexpected error: {e}"

# Generated at 2022-06-21 13:44:53.326223
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    saved_stderr = env.stderr
    env.stderr = io.StringIO()
    env.log_error("an error message")
    assert env.stderr.getvalue() == '\nhttp: error: an error message\n\n'
    env.stderr = io.StringIO()
    env.log_error("a warning message", level='warning')
    assert env.stderr.getvalue() == '\nhttp: warning: a warning message\n\n'
    env.stderr = saved_stderr

# Generated at 2022-06-21 13:45:01.320700
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None,**kwargs)
    print(kwargs)
    print(env)
    print(repr(env))
    return env

# Create and run the unit test for Environment class
if __name__ == '__main__':
    # Set the environment
    kwargs = {
        'is_windows':True,
        'stdout': sys.stdout,
        'stderr': sys.stderr
    }

    env = test_Environment()

# Generated at 2022-06-21 13:45:17.811896
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment(program_name = 'httpie', devnull = "devnull",
                      config_dir = r"C:\Users\Administrator\AppData\Roaming\httpie",
                      stdin = sys.stdin, stdin_isatty = True, stdin_encoding = "utf8",
                      stdout = sys.stdout, stdout_isatty = True, stdout_encoding = "utf8",
                      stderr = sys.stderr, stderr_isatty = True, colors = 256)
    assert env.__repr__() == '<Environment {' \
                             '"config_dir": "C:\\Users\\Administrator\\AppData\\Roaming\\httpie", ' \
                             '"colors": 256, ' \
                             '"devnull": "devnull", ' \
                            

# Generated at 2022-06-21 13:45:29.037003
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from io import StringIO
    env = Environment(
        stdin = StringIO(),
        stdout = StringIO(),
        stderr = StringIO(),
        config_dir = "test",
        devnull = "test",
    )

# Generated at 2022-06-21 13:45:31.683998
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env._orig_stderr = BytesIO()
    env.log_error('invalid ascii: \x7f', level='warning')
    assert env._orig_stderr.getvalue().decode('utf8').endswith('\n')


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 13:45:40.271484
# Unit test for constructor of class Environment
def test_Environment():
    import requests
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.utils import Version

    httpie_version = Version('2.3.0')
    requests_version = Version('2.19.1')
    environment = Environment()

    assert environment.is_windows == is_windows
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == sys.stdin.isatty()
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == sys.stdout.isatty()
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == sys.stderr.isatty()

    assert environment.std

# Generated at 2022-06-21 13:45:50.741637
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    def _test(actual, expected):
        env = Environment(**actual)
        assert str(env) == expected

    actual = {
        'stdin': object(),
        'stdin_isatty': object(),
        'stdin_encoding': object(),
        'stdout': object(),
        'stdout_isatty': object(),
        'stdout_encoding': object(),
        'stderr': object(),
        'stderr_isatty': object(),
        'config_dir': DEFAULT_CONFIG_DIR.joinpath('fake'),
        'is_windows': is_windows,
        'program_name': 'http',
        '_config': object(),
        '_devnull': object(),
        'colors': 256
    }

# Generated at 2022-06-21 13:45:59.809835
# Unit test for method __str__ of class Environment

# Generated at 2022-06-21 13:46:01.971040
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error('test', level="warning")

test_Environment_log_error()

# Generated at 2022-06-21 13:46:04.611834
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error('This is a error.' + '\nThis is a warning.')


# Generated at 2022-06-21 13:46:15.632110
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    import tempfile

    assert Path(tempfile.gettempdir()).exists()
    config_dir = tempfile.gettempdir()
    assert type(config_dir) == str

    fd = io.StringIO('\n')
    stdout = io.TextIOWrapper(fd)

    fd2 = io.StringIO('\n')
    stderr = io.TextIOWrapper(fd2)

    env = Environment(devnull='\n', stdout=stdout, stderr=stderr, config_dir=config_dir)

    assert type(env.config) == Config
    assert env.stdout == stdout
    assert env.stderr == stderr
    assert env.devnull == '\n'
    assert env.is_windows == is_windows


# Generated at 2022-06-21 13:46:16.232043
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    Environment()

# Generated at 2022-06-21 13:46:29.025804
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error("this is a error message")
    env.log_error("this is a warning message", level = 'warning')

# Generated at 2022-06-21 13:46:32.730860
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    from io import StringIO

    env = Environment(stdout=StringIO())
    assert '<Environment' in repr(env)
    assert 'stdout=<io.StringIO' in repr(env)

# Generated at 2022-06-21 13:46:40.761424
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin = 'test')
    assert env.stdin == 'test'
    assert env.stdin_isatty == False
    assert env.stdin_encoding is None
    assert env.stdout == 'test'
    assert env.stdout_isatty == False
    assert env.stdout_encoding is None
    assert env.stderr == 'test'
    assert env.stderr_isatty == False
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env.is_windows == False

# Generated at 2022-06-21 13:46:52.429474
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    import sys
    import os
    from httpie.config import Config
    from httpie.utils import Version
    from httpie import __version__
    from httpie.core import main
    from httpie.core import program
    program.program_name='httpie'
    environment = Environment(config_dir=os.path.join(os.getcwd() + "/.httpie"))
    environment.config = Config()
    os.environ['OS'] = 'Windows'
    assert isinstance(environment.config, Config)
    assert isinstance(environment.program_name, str)
    assert isinstance(environment.config_dir, str)
    assert isinstance(environment.is_windows, bool)
    assert isinstance(environment.stdin, sys.stdin.__class__)

# Generated at 2022-06-21 13:47:00.801911
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    try:
        from termcolor import colored
    except ImportError:
        from httpie.compat import colored

    if str(type(sys.stdout)) == "<class 'http.client.HTTPResponse'>":
        return
    # if sys.stdout.isatty():
    #     print(colored('真像控制台字符输入输出', 'red', 'on_grey', attrs=['underline', 'blink']))
    # else:
    #     print('假的控制台输入输出，输出到文件')
    e = Environment()
    # print(e)



# Generated at 2022-06-21 13:47:06.243093
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import StringIO
    from httpie.context import Environment
    from httpie.utils import strip_ansi

    stderr = StringIO()
    env = Environment(stderr = stderr)
    try:
        env.log_error("This is Error")
        env.log_error("This is Warning", level = 'warning')
        env.log_error("This is Error Again")
        assert strip_ansi(stderr.getvalue()) == "http: error: This is Error\nhttp: warning: This is Warning\nhttp: error: This is Error Again"
    except Exception as e:
        print(e)


# Generated at 2022-06-21 13:47:16.976285
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    env.stdin = ''
    env.stdin_isatty = True
    env.stdin_encoding = 'utf-8'
    env.stdout = sys.stdout
    env.stdout_encoding = 'utf-8'
    env.stdout_isatty = True
    env.stderr = sys.stderr
    env.stderr_isatty = True
    env.devnull = ''
    env.is_windows = True
    env.config_dir = DEFAULT_CONFIG_DIR
    env.program_name = 'http'

# Generated at 2022-06-21 13:47:28.494137
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    environment = Environment()

# Generated at 2022-06-21 13:47:40.340110
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(is_windows=True, config_dir=DEFAULT_CONFIG_DIR, stdin=sys.stdin, stdin_isatty=False, stdin_encoding=None, stdout=sys.stdout, stdout_isatty=False,
                       stdout_encoding=None, stderr=sys.stderr, stderr_isatty=False, colors=256, program_name= 'http', _orig_stderr=sys.stderr, _devnull=None)
    assert env.is_windows == True
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == False
    assert env.stdin_encoding == None
    assert env.stdout == sys.std

# Generated at 2022-06-21 13:47:49.772447
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.utils import repr_dict

    defaults = dict(is_windows=is_windows, config_dir=DEFAULT_CONFIG_DIR)
    defaults['stdin'] = sys.stdin
    defaults['stdin_isatty'] = sys.stdin.isatty()
    defaults['stdin_encoding'] = 'utf8'
    defaults['stdout'] = sys.stdout
    defaults['stdout_isatty'] = sys.stdout.isatty()
    defaults['stdout_encoding'] = 'utf8'
    defaults['stderr'] = sys.stderr
    defaults['stderr_isatty'] = sys.stderr.isatty()
    defaults

# Generated at 2022-06-21 13:48:03.592654
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.program_name = 'http'
    class StdErr():
        buf = ''
        def isatty(self):
            pass
        def write(self, text):
            StdErr.buf += text
        def flush(self):
            pass
    env.stderr = StdErr()
    env.log_error('msg')
    assert StdErr.buf == '\nhttp: error: msg\n\n'
    StdErr.buf = ''
    env._orig_stderr = env.stderr
    env.log_error('msg2', level='warning')
    assert StdErr.buf == '\nhttp: warning: msg2\n\n'


# Generated at 2022-06-21 13:48:10.010949
# Unit test for constructor of class Environment
def test_Environment():
    # Streams are setup during initialisation
    stdin = open(os.devnull, 'r')
    stdin_encoding = 'utf-8'
    stdout = open(os.devnull, 'w')
    stdout_encoding = 'utf-8'
    stderr = open(os.devnull, 'w')

    env = Environment(stdin=stdin, stdin_encoding=stdin_encoding, stdout=stdout, stdout_encoding=stdout_encoding, stderr=stderr)

    assert env.stdin == stdin
    assert env.stdin_encoding == stdin_encoding
    assert env.stdout == stdout
    assert env.stdout_encoding == stdout_encoding
    assert env.stderr == stderr

# Generated at 2022-06-21 13:48:21.067137
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    import sys
    import os
    from pathlib import Path
    from typing import IO, Optional

    from httpie.compat import is_windows
    from httpie.config import DEFAULT_CONFIG_DIR, Config, ConfigFileError

    from httpie.utils import repr_dict


    try:
        import curses
    except ImportError:
        curses = None  # Compiled w/o curses

    from httpie.compat import is_windows
    from httpie.config import DEFAULT_CONFIG_DIR, Config, ConfigFileError

    from httpie.utils import repr_dict



# Generated at 2022-06-21 13:48:31.513065
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import sys
    # test log_warning
    try:
        raise ValueError('test')
    except ValueError as e:
        env = Environment(stderr=sys.stdout)
        env.log_error(e, level='warning')
        output = sys.stdout.getvalue()
        sys.stdout.truncate(0)
        sys.stdout.seek(0)
        assert 'http: warning: test' in output
        assert 'Traceback (most recent call last)' not in output
        assert 'ValueError: test' not in output
    # test log_error
    try:
        raise ValueError('test')
    except ValueError as e:
        env = Environment(stderr=sys.stdout)
        env.log_error(e)
        output = sys.stdout.getvalue()

# Generated at 2022-06-21 13:48:41.688245
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(color=8, is_windows=False, terminal_width=100)
    assert str(env) == '{color: 8, colors: 256, is_windows: False, ' \
                       'program_name: http, stdin: <_io.TextIOWrapper ' \
                       'name=<stdin> mode=<stdin> encoding=utf8>, ' \
                       'stdin_isatty: True, stdout: <_io.TextIOWrapper ' \
                       'name=<stdout> mode=<stdout> encoding=utf8>, ' \
                       'stdout_isatty: True, terminal_width: 100}'


if __name__ == '__main__':
    print(test_Environment___str__())

# Generated at 2022-06-21 13:48:44.745277
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    stdout_encoding = sys.stdout.encoding
    env = Environment()
    assert str(env).find(f'"stdout_encoding": "{stdout_encoding}"') != -1


# Generated at 2022-06-21 13:48:55.112571
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    env_str = str(env)
    assert isinstance(env_str, str)

# Generated at 2022-06-21 13:48:55.797961
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    pass


# Generated at 2022-06-21 13:49:04.844703
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from io import StringIO

    env = Environment(config_dir='some_dir',
                      stdin=StringIO(),
                      stdout=StringIO(),
                      stderr=StringIO(),
                      config={'http': {'default_options': [('--form',)]},
                              'colors': {'http_error': 'on'}})
    result = str(env)

# Generated at 2022-06-21 13:49:15.846861
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull='/dev/null')
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    from io import StringIO
    from httpie.compat import is_windows
    assert env.stdin_encoding == 'utf8'

# Generated at 2022-06-21 13:49:39.304791
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()

# Generated at 2022-06-21 13:49:50.762964
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    from pathlib import Path
    from io import TextIOWrapper
    from httpie.config import DEFAULT_CONFIG_DIR

    stdin = sys.stdin
    stdout = sys.stdout
    stderr = sys.stderr

    default_env = Environment()
    assert default_env.is_windows is False
    assert default_env.config_dir == DEFAULT_CONFIG_DIR
    assert default_env.stdin == stdin
    assert default_env.stdin_isatty is True
    assert default_env.stdin_encoding is None
    assert default_env.stdout == stdout
    assert default_env.stdout_isatty is True
    assert default_env.stdout_encoding is None
    assert default_env.stderr == stderr
    assert default_