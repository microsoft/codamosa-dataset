

# Generated at 2022-06-21 13:39:55.937611
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    assert Environment().__repr__() == '<Environment {}>'

# Generated at 2022-06-21 13:40:07.119091
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    # Test with default values
    e = Environment()

# Generated at 2022-06-21 13:40:13.722623
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import sys
    from httpie.core import main
    from httpie.exitstatus import ExitStatus
    from httpie import __version__

    old_env = Environment()
    new_env = Environment(
        program_name='httpie_test',
        stderr=sys.stderr,
        stdout=sys.stdout
    )
    new_env.log_error("Fatal Error in item test")



# Generated at 2022-06-21 13:40:16.960155
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    print(env)
    print(env.__str__())
    print(env.__repr__())


# Generated at 2022-06-21 13:40:19.819897
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    assert repr(Environment()) == '<Environment {}>'
    assert repr(
        Environment(
            config_dir='test/test_dir',
            stdin=sys.stdin,
            stdin_isatty=False,
            stdin_encoding='utf8',
            stdout=sys.stdout,
            stdout_isatty=True,
            stdout_encoding='utf8',
            stderr=sys.stderr,
            stderr_isatty=True,
            colors=256,
            program_name='http',
        )
    ) == '<Environment {}>'


# Generated at 2022-06-21 13:40:31.071994
# Unit test for constructor of class Environment
def test_Environment():
    from httpie.utils import get_encoding_from_env
    env = Environment()
    assert is_windows == env.is_windows
    assert sys.stdin == env.stdin
    assert sys.stdin.isatty() == env.stdin_isatty
    assert get_encoding_from_env() == env.stdin_encoding
    assert sys.stdout == env.stdout
    assert sys.stdout.isatty() == env.stdout_isatty
    assert get_encoding_from_env() == env.stdout_encoding
    assert sys.stderr == env.stderr
    assert sys.stderr.isatty() == env.stderr_isatty
    assert not env.config_dir.is_absolute()

# Generated at 2022-06-21 13:40:37.371850
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import io
    env = Environment()
    env.stderr = io.StringIO()  # pylint: disable=no-member
    env.log_error("error")
    assert env.stderr.getvalue() == "\nhttp: error: error\n\n"


# Generated at 2022-06-21 13:40:43.763898
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env=Environment()
    stderr=env.stderr
    stdout=env.stdout
    env.log_error("message")
    # if the message is logged correctly, the stderr stream is not equal the stdout stream
    assert not stderr == stdout

if __name__ == "__main__":
    # test for method log_error of class Environment
    test_Environment_log_error()

# Generated at 2022-06-21 13:40:53.964909
# Unit test for method __repr__ of class Environment

# Generated at 2022-06-21 13:40:57.819458
# Unit test for constructor of class Environment
def test_Environment():
    """

    :return:
    """
    environ = Environment()

    print(environ.colors)
    assert environ.colors == 256

if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-21 13:41:13.239494
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env=Environment()

# Generated at 2022-06-21 13:41:24.432089
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    from httpie.config import Config
    from httpie.environment import Environment
    env = Environment(is_windows=False, config_dir=Config().directory, stdin=sys.stdin,
                      stdin_isatty=sys.stdin.isatty(), stdin_encoding=sys.stdin.encoding if sys.stdin.isatty() else 'utf8',
                      stdout=sys.stdout, stdout_isatty=sys.stdout.isatty(), stdout_encoding=sys.stdout.encoding,
                      stderr=sys.stderr, stderr_isatty=sys.stderr.isatty(), colors=256, program_name='http')
    print(env)

if __name__ == '__main__':
    test_Environment___repr__()

# Generated at 2022-06-21 13:41:34.684667
# Unit test for constructor of class Environment
def test_Environment():
    env=Environment()
    assert env.is_windows==is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty==env.stdin.isatty()
    assert env.stdout==sys.stdout
    assert env.stdout_isatty==env.stdout.isatty()
    assert env.stderr==sys.stderr
    assert env.stderr_isatty==env.stderr.isatty()
    assert env.colors==256
    assert env.program_name=='http'
    assert env.stdin_encoding=='utf8'
    assert env.stdout_encoding=='utf8'

# Generated at 2022-06-21 13:41:43.292404
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import StringIO
    env = Environment()
    env.stderr = StringIO.StringIO()
    env.program_name = 'http'
    env._orig_stderr = StringIO.StringIO()

    env.log_error('message')
    assert env.stderr.getvalue() == '\nhttp: error: message\n\n'
    assert not env._orig_stderr.getvalue()

    env.log_error('message', 'warning')
    assert env.stderr.getvalue() == '\nhttp: error: message\n\n\nhttp: warning: message\n\n'
    assert env._orig_stderr.getvalue() == '\nhttp: warning: message\n\n'

# Generated at 2022-06-21 13:41:44.245469
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    print(env)

# Generated at 2022-06-21 13:41:51.672641
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    class MockFile(object):
        def __init__(self):
            self.content = []
        def write(self,value):
            self.content.append(value)
        def flush(self):
            return
        def readlines(self):
            return self.content
    item = MockFile()
    env = Environment(stderr=item)
    env.log_error('ERROR')
    assert(item.content == ['\nhttp: error: ERROR\n\n'])

# Generated at 2022-06-21 13:41:59.786443
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment(program_name='test')
    assert e.program_name == 'test'
    assert e.config_dir == Path("~/.httpie").expanduser()
    assert e.stdin is not None
    assert e.stdout is not None
    assert e.stderr is not None
    assert e.stderr_isatty is True
    assert e.stderr_encoding == 'UTF-8'
    assert e.stdin_encoding == 'UTF-8'
    assert e.stdout_encoding == 'UTF-8'
    assert e.colors == 8
    assert e._devnull is None
    assert e._config is None
    assert e._orig_stderr is not None

# Generated at 2022-06-21 13:42:04.716343
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(
        stdin = sys.stdin,
        stdout = sys.stdout,
        stderr = sys.stderr,
        config_dir = DEFAULT_CONFIG_DIR,
        program_name = 'http'
    )
    print(environment)

# Generated at 2022-06-21 13:42:16.887028
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(devnull=None,\
                      is_windows=False,\
                      config_dir=Path('/home/xyz/.config/httpie'),\
                      stdin=sys.stdin,\
                      stdin_isatty=False,\
                      stdin_encoding=None,\
                      stdout=sys.stdout,\
                      stdout_isatty=True,\
                      stdout_encoding=None,\
                      stderr=sys.stderr,\
                      stderr_isatty=True,\
                      colors=256,\
                      program_name='http')

# Generated at 2022-06-21 13:42:18.186504
# Unit test for constructor of class Environment
def test_Environment():
    assert len(Environment().__dict__) == len(Environment.__dict__)

# Generated at 2022-06-21 13:42:36.453362
# Unit test for constructor of class Environment
def test_Environment():
    from httpie.compat import isatty
    from httpie.utils import Version
    from httpie.compat import stdout, stdin
    env = Environment(stdin=stdin, stdout=stdout, devnull='devnull')
    env.colors = 256
    env.is_windows = is_windows
    assert env.stdin is stdin
    assert env.stdout is stdout
    assert env.stderr is stdout
    assert env.stdin_isatty is isatty(stdin)
    assert env.stdout_isatty is isatty(stdout)
    assert env.stderr_isatty is isatty(stdout)
    assert env.program_name is 'http'
    assert isinstance(env.config_dir, Path)
    assert env.stdin

# Generated at 2022-06-21 13:42:48.099363
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    import httpie.cli
    env = httpie.cli.Environment()
    env.stdin = None
    env.stdin_isatty = False
    env.stdin_encoding = None
    env.stdout = sys.stdout
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'
    env.stderr = sys.stderr
    env.stderr_isatty = True

# Generated at 2022-06-21 13:42:51.836302
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment(a=1, b=2, c=3)
    assert repr(env) == "<Environment {'a': 1, 'b': 2, 'c': 3}>"


# Generated at 2022-06-21 13:43:00.457200
# Unit test for method __str__ of class Environment

# Generated at 2022-06-21 13:43:10.379807
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.stdin == sys.stdin
    assert env.is_windows == is_windows
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.istty()
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.istty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr
    assert env._devnull is None

# Generated at 2022-06-21 13:43:13.818955
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment(stdin_encoding='utf8', stdout_encoding='utf8', stderr=sys.stdout, program_name="test")  # stdout=sys.stdout)
    env.log_error('test_msg')

# Generated at 2022-06-21 13:43:19.245522
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from unittest.mock import Mock

    stderr = Mock()
    env = Environment(_orig_stderr=stderr)
    env.log_error('Error message')
    stderr.write.assert_called_with('\nhttp: error: Error message\n\n')



# Generated at 2022-06-21 13:43:23.045538
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env= Environment()
    env.config_dir= "httpie"
    msg= "Something went wrong"
    env.log_error(msg, level='error')

if __name__ == '__main__':
    test_Environment_log_error()

# Generated at 2022-06-21 13:43:24.672230
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    print(environment)
    print(environment.config)

# Generated at 2022-06-21 13:43:32.005127
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    # noinspection PyUnresolvedReferences
    from httpie.core import main
    del sys.stderr
    sys.stderr = StringIO()
    try:
        main(args=['--help'])
    except SystemExit:
        pass
    sys.stderr.seek(0)
    assert 'error: ' in sys.stderr.read()


# Global environment object.
# It's only accessed by the `env` property of t

# Generated at 2022-06-21 13:43:36.723288
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    print(Environment())

# Generated at 2022-06-21 13:43:43.999280
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.program_name == 'http'

# Generated at 2022-06-21 13:43:55.358189
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert hasattr(env, 'is_windows')
    assert hasattr(env, 'colors')
    assert hasattr(env, 'stderr')
    assert hasattr(env, 'stdin_encoding')
    assert hasattr(env, 'stdout')
    assert hasattr(env, 'stdout_encoding')
    assert hasattr(env, 'stderr')
    assert hasattr(env, 'stderr_isatty')
    assert hasattr(env, 'colors')
    assert hasattr(env, 'program_name')
    assert hasattr(env, 'config_dir')
    assert hasattr(env, 'config')
    assert hasattr(env, '_config')

# Generated at 2022-06-21 13:44:05.111932
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    from httpie import ExitStatus
    from httpie.context import Environment
    args=['http', 'http://httpbin.org/headers']
    env = Environment(devnull=False, exit_status=ExitStatus.OK, config_dir=DEFAULT_CONFIG_DIR)
    env.program_name = 'http'
    env.stdout = sys.stdout
    env.stderr = sys.stderr
    env.stdin = sys.stdin
    env.stdout_isatty = sys.stdout.isatty()
    env.stderr_isatty = sys.stderr.isatty()
    env.stdin_isatty = sys.stdin.isatty()
    env.stdout_encoding = 'utf8'

# Generated at 2022-06-21 13:44:07.410171
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error('error message')
    env.log_error('warning message', level = 'warning')

# Generated at 2022-06-21 13:44:19.723687
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    from httpie.core import Environment
    from httpie.core import DEFAULT_CONFIG_DIR
    from os import devnull
    from pathlib import Path

# Generated at 2022-06-21 13:44:22.941712
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert isinstance(env, Environment)
    env.config_dir = Path("/home/")
    assert env.config_dir == Path("/home/")

# Generated at 2022-06-21 13:44:27.471952
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    '''
    Function to test __str__ method of class Environment
    '''

    env = Environment(devnull=None, **dict())
    assert all(hasattr(env, attr) for attr in dict().keys())


# Generated at 2022-06-21 13:44:39.079497
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    import sys
    import os
    import time
    import datetime
    import platform
    import curses
    from pathlib import Path
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie import __version__
    from httpie.utils import __repr_dict
    # Set Environment
    Environment.is_windows=is_windows
    Environment.config_dir=DEFAULT_CONFIG_DIR
    Environment.stdin=sys.stdin
    Environment.stdin_isatty=sys.stdin.isatty()
    Environment.stdin_encoding='utf8'
    Environment.stdout=sys.stdout
    Environment.stdout_isatty=sys.stdout.isatty()
    Environment.stdout_encoding='utf8'

# Generated at 2022-06-21 13:44:49.671840
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    result = str(env)

# Generated at 2022-06-21 13:45:05.251248
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()

# Generated at 2022-06-21 13:45:07.352846
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    e = Environment(stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr)
    print(e)

# Generated at 2022-06-21 13:45:15.853847
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    import pprint

# Generated at 2022-06-21 13:45:27.459792
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    import pytest
    env = Environment()
    env.config_dir = 'mock_config_dir'
    env.is_windows = 'mock_is_windows'
    env.stdin = 'mock_stdin'
    env.stdout = 'mock_stdout'
    env.stderr = 'mock_stderr'
    env.colors = 'mock_colors'
    env.program_name = 'mock_program_name'
    env.stdin_encoding = 'mock_stdin_encoding'
    env.stdout_encoding = 'mock_stdout_encoding'
    env.config = 'mock_config'
    env._devnull = 'mock_devnull'

# Generated at 2022-06-21 13:45:34.481098
# Unit test for constructor of class Environment
def test_Environment():
    stdin = sys.stdin
    devnull = os.devnull
    env = Environment(
        stdin=stdin,
        stdout=sys.stdout,
        stderr=sys.stderr,
        program_name='http',
        devnull=devnull)
    assert env.stdin == stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert env.program_name == 'http'
    assert env.devnull == devnull


environ = Environment()

# Generated at 2022-06-21 13:45:41.953583
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows == is_windows
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin == sys.stdin
    assert environment.stdout == sys.stdout
    assert environment.stderr == sys.stderr
    assert environment.devnull is None
    assert environment._devnull is None
    assert environment._config is None
    devnull = open(os.devnull, 'w+')
    environment = Environment(devnull=devnull, stderr=devnull)
    assert environment._devnull is devnull
    assert environment.stderr is devnull
    assert not environment.config_dir.exists()
    assert environment.config is not None
    assert environment.config_dir.exists()
    assert environment._config is not None

# Generated at 2022-06-21 13:45:45.125349
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    environment = Environment()
    environment.log_error('This is a test informative message.')
    environment.log_error('This is a test error message.', level='warning')

# Generated at 2022-06-21 13:45:52.951525
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.stderr is sys.stderr
    assert env.stderr_isatty is True
    assert env.stderr_encoding is None
    assert env.stdin is sys.stdin
    assert env.stdin_isatty is True
    assert env.stdout_encoding is not 'utf8'
    assert env.stdout_encoding is 'utf8'
    assert env.stdin_encoding is 'utf8'
    assert env.stdout is sys.stdout
    assert env._orig_stderr is sys.stderr
    assert env.program_name is 'http'
    assert env.stdout_isatty is True
    assert env.colors is 256

# Generated at 2022-06-21 13:45:58.682814
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import StringIO
    stderr = StringIO()
    env = Environment(stderr=stderr)
    env.log_error("hello")
    assert stderr.getvalue() == "\nhttp: error: hello\n\n"

    stderr = StringIO()
    env = Environment(stderr=stderr)
    env.log_error("hello", level='warning')
    assert stderr.getvalue() == "\nhttp: warning: hello\n\n"

# Generated at 2022-06-21 13:46:10.540376
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    assert repr(env) == '<Environment {\'stdin_encoding\': None, \'stdout_isatty\': True, \'stdin_isatty\': False, \'program_name\': \'http\', \'stderr_isatty\': True, \'config_dir\': PosixPath(\'~/.config/httpie\'), \'colors\': 256, \'is_windows\': False, \'stdout\': <httpie.output.WritingStreamWrapper object at 0x7faafc03dac0>, \'stderr\': <httpie.output.WritingStreamWrapper object at 0x7faafc03da30>, \'stdin\': <_io.TextIOWrapper name=7 encoding=\'ANSI_X3.4-1968\'>}>'

# Generated at 2022-06-21 13:46:20.679846
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env1 = Environment()
    env1.log_error(msg="test")



# Generated at 2022-06-21 13:46:23.943425
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    assert repr(Environment()) == '<Environment {}>'
    assert repr(Environment(stdin=None)) == '<Environment {stdin=None}>'



# Generated at 2022-06-21 13:46:27.759419
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    stream = io.StringIO()
    environment = Environment(stderr=stream)
    msg = "test_message"
    environment.log_error(msg)
    assert msg in stream.getvalue()


# Generated at 2022-06-21 13:46:39.697255
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    assert env.__repr__() == \
        '<Environment {' \
        '"stdin_encoding": null, ' \
        '"stdout_encoding": null, ' \
        '"config_dir": "/home/www/.config/httpie", ' \
        '"stdin_isatty": true, ' \
        '"colors": 256, ' \
        '"stderr_isatty": true, ' \
        '"program_name": "http", ' \
        '"config": {}, ' \
        '"is_windows": false, ' \
        '"stdin": <_io.TextIOWrapper name=2 mode="r" encoding="UTF-8">, ' \
        '"stdout_isatty": true, ' \
       

# Generated at 2022-06-21 13:46:44.369785
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from httpie.context import Environment
    from io import StringIO

    stream = StringIO()

    env = Environment(stderr=stream)
    env.log_error('msg')
    # print(stream.getvalue())
    assert stream.getvalue() == '\nhttp: error: msg\n\n'



# Generated at 2022-06-21 13:46:45.885413
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    assert repr(Environment()) == '<Environment colors=256 is_windows=False>'

# Generated at 2022-06-21 13:46:56.980245
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from httpie.environment import Environment
    from httpie.input import Input

    # test environment not include default
    Environment.defaults = {'test_default': 'text'}
    e = Environment()
    print('test_default not included in __str__', e)
    assert 'test_default not included in __str__' in str(e)
    del Environment.defaults

    # test_default
    e = Environment(test_default='test')
    assert 'test_default' in str(e)
    assert 'test' in str(e)

    # input
    e = Environment(input=Input(['--test']))
    assert 'input' in str(e)
    assert '--test' in str(e)

    # config
    e = Environment(config=None)
    assert 'config' in str(e)

# Generated at 2022-06-21 13:47:07.501634
# Unit test for method __repr__ of class Environment

# Generated at 2022-06-21 13:47:08.871827
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    assert str(env) == "''"

# Generated at 2022-06-21 13:47:18.814451
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from tempfile import TemporaryDirectory
    env = Environment(config_dir=TemporaryDirectory())
    expected =  '<Environment {\n'
    expected += '  "config": Config(is_new=True, directory=Path(".../tmp")),\n'
    expected += '  "colors": 256,\n'
    expected += '  "config_dir": Path(".../tmp"),\n'
    expected += '  "is_windows": False,\n'
    expected += '  "stderr_encoding": None,\n'
    expected += '  "stdin": <_io.TextIOWrapper name=0 mode=r encoding=utf-8>,\n'
    expected += '  "stdin_encoding": "utf8",\n'

# Generated at 2022-06-21 13:47:36.953591
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    assert repr(env).startswith(f'<{type(env).__name__}')



# Generated at 2022-06-21 13:47:47.720935
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    # Test for method Environment.__str__(self)
    # Test for method Environment.__str__(self)
    from httpie.input import SEP_CREDENTIALS, SEP_GROUP, SEP_HEADERS
    from httpie.plugins import plugin_manager
    from httpie._compat import urlunparse
    from httpie.config import Unset
    import sys
    plugin_manager.load_installed_plugins()
    env = Environment()

# Generated at 2022-06-21 13:48:01.063844
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    environment = Environment(is_windows=True, stdout_isatty=True, stdin_isatty=True, config_dir=DEFAULT_CONFIG_DIR, stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr, program_name='http', devnull=open(os.devnull, 'w+'), stdout_encoding='utf8', stderr_isatty=True, stdin_encoding='utf8')

# Generated at 2022-06-21 13:48:05.506990
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    print(env)
    sys.stdout.flush()
    env = Environment(stdin = sys.stdin, stdout = sys.stdout, stderr = sys.stdout)
    print(env)
    sys.stdout.flush()

# Unit tests for class Environment
if __name__ == "__main__":
    test_Environment()

# Generated at 2022-06-21 13:48:13.358404
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    assert Environment().__repr__() == '<Environment {config: {}, colors: 256, devnull: None, is_windows: False, program_name: http, config_dir: ~/.config/httpie, stderr: <stderr>, stdin: <stdin>, stdout: <stdout>, stdout_encoding: utf8, stdin_encoding: utf8, stdin_isatty: True, stdout_isatty: True, stderr_isatty: True}>'

# Generated at 2022-06-21 13:48:24.542754
# Unit test for constructor of class Environment
def test_Environment():
    environ = Environment()

# Generated at 2022-06-21 13:48:33.075429
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()

# Generated at 2022-06-21 13:48:39.859613
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import StringIO
    from httpie.utils import make_environment

    stream = StringIO()
    env = make_environment(stdout=stream, stderr=stream)
    env.program_name = "my-program"
    env.log_error("exception msg")
    actual = stream.getvalue()
    expected = '\nmy-program: error: exception msg\n\n'
    assert actual == expected

# Generated at 2022-06-21 13:48:49.852904
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    e = Environment()

# Generated at 2022-06-21 13:48:56.312925
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    """
    Method: log_error()
    Description: If a config file is in wrong format, then this method will log the error on stderr
                 Default value for level is 'error' for error
    Input      : Error message
    Output     : Error message on Stderr
    """
    env = Environment()
    err = 'abc'
    expected_output = 'http: error: abc'
    test_output = env.log_error(err, level='error')

    assert test_output == expected_output

# Generated at 2022-06-21 13:49:37.886596
# Unit test for constructor of class Environment
def test_Environment():
    from httpie.utils import StdStreamsMock

    env = Environment(
        colors=5,
        config_dir="/Users/peter/.httpie",
        stdin=StdStreamsMock(),
        stderr=StdStreamsMock(),
        stdout=StdStreamsMock(),
    )
    assert env.colors == 5
    assert env.config_dir == "/Users/peter/.httpie"
    assert env.stdin is not None
    assert env.stderr is not None
    assert env.stdout is not None

# Generated at 2022-06-21 13:49:41.230709
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import StringIO
    env = Environment(
        stderr=StringIO(),
        program_name='prog'
    )
    env.log_error('error')
    assert env.stderr.getvalue() == '\nprog: error: error\n\n'


# Generated at 2022-06-21 13:49:52.475189
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    env.stdout_encoding = 'utf8'
    env.stdin_encoding = 'utf8'