

# Generated at 2022-06-21 13:39:58.706661
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error("test")
    # Test raise Exception
    try:
        env.log_error("test", level='test')
    except AssertionError:
        # Test passed
        pass
    else:
        raise Exception("Test failed")


# Generated at 2022-06-21 13:40:09.578558
# Unit test for method __repr__ of class Environment

# Generated at 2022-06-21 13:40:22.186642
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    environment = Environment(
        program_name='http',
        is_windows=True,
        config_dir='/Users/cy/.httpie/',
        stdin=None,
        stdin_isatty=False,
        stdin_encoding='utf8',
        stdout=open('/dev/stdout', 'wb+'),
        stdout_isatty=True,
        stdout_encoding='utf8',
        stderr=open('/dev/stderr', 'wb+'),
        stderr_isatty=True,
        colors=256,
        _config='<httpie.config.Config>',
        _devnull='<open file \'<fdopen>\', mode \'w+\' at 0x7f3067c3a190>'
    )

# Generated at 2022-06-21 13:40:25.736768
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()

# Generated at 2022-06-21 13:40:28.886338
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment(program_name='hello', devnull=1234).program_name == 'hello'

# Generated at 2022-06-21 13:40:41.431404
# Unit test for method __repr__ of class Environment

# Generated at 2022-06-21 13:40:51.964210
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import StringIO
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    env = Environment(
        stdout=StringIO(),
        stderr=StringIO(),
    )
    env.log_error("test_error")
    assert env.stderr.getvalue().rstrip() == f'http: error: test_error'
    env.log_error("test_error", level='warning')
    assert env.stderr.getvalue().rstrip() == f'http: warning: test_error'


# Invoke unit tests with: python -c "import test; test.test_Environment_log_error()"
if __name__ == '__main__':
    import pytest
    pytest.main()

# Generated at 2022-06-21 13:41:03.935376
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    import pytest
    arg1 = Environment()

# Generated at 2022-06-21 13:41:07.522775
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    e = Environment()
    assert repr(e) is not None
    assert not repr(e).startswith('<')
    assert not repr(e).endswith('>')
# Testing for method __repr__ of class Environment ends

# Generated at 2022-06-21 13:41:17.135107
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    import string
    import random
    import tempfile

    env = Environment()
    # checking for an assertion error
    try:
        with tempfile.TemporaryDirectory() as temp_dir1:
            env.config_dir = Path(temp_dir1)
            print(env.__repr__())
    except AssertionError:
        pass

    env.is_windows = True
    env.stdin = sys.stdout
    env.stdin_isatty = False
    # stdin_encoding should be already defined in the class
    env.stdout = sys.stdin
    env.stdout_isatty = True
    env.stderr = sys.stderr
    env.stderr_isatty = True
    env.colors = 8

# Generated at 2022-06-21 13:41:33.484213
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    env_repr = repr_dict({'config_dir': DEFAULT_CONFIG_DIR, 'is_windows': is_windows, 'program_name': 'http', 'stdin_isatty': True, 'stdout_isatty': True, 'stdin_encoding': 'utf8', 'stdout_encoding': 'utf8', 'stderr_isatty': True, 'stderr_encoding': 'utf8', 'colors': 256, 'config': Config(directory=DEFAULT_CONFIG_DIR)})
    assert env.__repr__() == '<Environment ' + env_repr + '>'


# Generated at 2022-06-21 13:41:34.623578
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    assert eval(repr(env)) == env


# Generated at 2022-06-21 13:41:43.794310
# Unit test for constructor of class Environment
def test_Environment():
    """

    :return:
    """
    env = Environment()
    print(env)
    # 输出信息

# Generated at 2022-06-21 13:41:55.108056
# Unit test for constructor of class Environment
def test_Environment():
    assert str(Environment()) == str(Environment(colors=256, stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr, config_dir=Path(r'C:\Users\cglen\AppData\Roaming\httpie'), program_name='http'))

# Generated at 2022-06-21 13:42:07.401475
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    
    # assert devnull is opened
    assert os.path.exists(os.devnull)
    # test_case1: devnull is not open, and level is error
    env.devnull = None
    env.log_error('test1', 'error')
    assert os.path.exists(os.devnull)
    # test_case2: devnull is not open, and level is warning
    env.devnull = None
    env.log_error('test2', 'warning')
    assert os.path.exists(os.devnull)
    # test_case3: devnull is open, and level is error
    env.devnull = True
    env.log_error('test3', 'error')
    assert os.path.exists(os.devnull)
    # test_

# Generated at 2022-06-21 13:42:19.193156
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    test_env = Environment()

# Generated at 2022-06-21 13:42:25.060061
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    stdout, sys.stdout = sys.stdout, io.StringIO()
    try:
        env = Environment(config_dir='/path/to/config', stdout='stdout')
        env.log_error('error', level='error')
        assert sys.stdout.getvalue() == '\nhttp: error: error\n\n'
        sys.stdout.seek(0)
        sys.stdout.truncate(0)
        env.log_error('warning', level='warning')
        assert sys.stdout.getvalue() == '\nhttp: warning: warning\n\n'
    finally:
        sys.stdout = stdout

# Variable that stores the actual environment
# for the duration of the current process.
env = Environment()

# Generated at 2022-06-21 13:42:28.351179
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error('test_error', level='error')
    env.log_error('test_warning', level='warning')


# Generated at 2022-06-21 13:42:32.886285
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    # Create an instance of Environment
    env = Environment()
    # Test level attribute is set to error
    msg = 'test'
    assert env.log_error(msg) is None
    # Test level attribute is set to warning
    msg = 'test'
    assert env.log_error(msg, level='warning') is None

# Generated at 2022-06-21 13:42:37.299281
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    assert \
        repr(Environment(is_windows=True, colors=16)) == \
        '<Environment {' \
        '"colors": 16, ' \
        '"is_windows": true, ' \
        '"program_name": "http"}>'

# Generated at 2022-06-21 13:42:49.241509
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error(msg="Error Message")
    env.log_error(msg="Warning Message", level="warning")

# Generated at 2022-06-21 13:42:52.514295
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error('Error')
    env = Environment(stderr = sys.stdout)
    env.log_error('Error')

# Generated at 2022-06-21 13:42:53.854002
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    environment = Environment()
    #test for get the environment
    assert environment.__str__()

# Generated at 2022-06-21 13:43:00.003299
# Unit test for constructor of class Environment
def test_Environment():
    import io
    import os

    env = Environment(
        devnull=io.StringIO(),
        is_windows=os.name == 'nt',
        config_dir=os.path.join('src', 'httpie'),
        stdin=io.StringIO(),
        stdin_isatty=False,
        stdout=io.StringIO(),
        stdout_isatty=False,
        stderr=io.StringIO(),
        stderr_isatty=False,
        program_name='Test'
    )

    print(env)

test_Environment()

# Generated at 2022-06-21 13:43:10.758908
# Unit test for method __repr__ of class Environment

# Generated at 2022-06-21 13:43:12.211694
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error('the input could not be interpreted as JSON',level='error')



# Generated at 2022-06-21 13:43:16.518200
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    actual = StringIO()
    expected = 'http: error: some message'
    env = Environment(stderr=actual)
    env.log_error('some message', level='error')
    actual.seek(0)
    assert actual.read().strip() == expected

# Generated at 2022-06-21 13:43:20.846910
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    out = io.StringIO()
    env = Environment(stderr=out)
    env.log_error('msg', 'warning')
    assert out.getvalue().strip() == '\nhttp: warning: msg'

env = Environment()

# Generated at 2022-06-21 13:43:32.861462
# Unit test for constructor of class Environment
def test_Environment():
    test_env = Environment(stdin=sys.stdin)

# Generated at 2022-06-21 13:43:42.130611
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.devnull
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env._orig_stderr == sys.stderr
    assert env.program_name == 'http'
    assert env.stdin == sys.stdin
    assert env.stdin_isatty
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout_encoding == 'utf8'
    assert env.stderr == sys.stderr
    assert env.stderr_isatty
    assert env._devnull
    assert env.stdout_encoding == 'utf8'

# Generated at 2022-06-21 13:44:04.337441
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    e = Environment()

# Generated at 2022-06-21 13:44:16.597015
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    import sys
    import tempfile
    from httpie.config import Config, ConfigFileError

    # Create a temporary directory
    temp_dir = tempfile.TemporaryDirectory()
    temp_dir_path = temp_dir.name

    # Set the temporary directory as the configuration directory
    config_dir = Path(temp_dir_path)
    env = Environment(config_dir = config_dir)

    # Test if an exception is raised when the configuration file does not exist
    config = env.config
    assert config.is_new()
    config_dir = str(config_dir)
    config_dir = config_dir[-11:]
    result = str(env)

# Generated at 2022-06-21 13:44:24.259044
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()

# Generated at 2022-06-21 13:44:26.072429
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    assert str(env) != {}



# Generated at 2022-06-21 13:44:36.963610
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    import sys
    import os
    import inspect
    from pathlib import Path
    from typing import IO, Optional


    assert all(hasattr({'a': 'b'}, attr) for attr in {'a'}.keys())

    try:
        import curses
    except ImportError:
        curses = None  # Compiled w/o curses
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_CONFIG_DIR, Config, ConfigFileError

    from httpie.utils import repr_dict


    class Environment:
        """
        Information about the execution context
        (standard streams, config directory, etc).

        By default, it represents the actual environment.
        All of the attributes can be overwritten though, which
        is used by the test suite to simulate various scenarios.

        """
        is_windows

# Generated at 2022-06-21 13:44:40.103741
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    e = Environment(a=1, b=2)
    assert str(e) == "{'a': 1, 'b': 2}"



# Generated at 2022-06-21 13:44:41.675079
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    assert repr(Environment()) == '<Environment {}>'



# Generated at 2022-06-21 13:44:51.396879
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from httpie.utils import get_version
    from httpie.environment import DEFAULT_CONFIG_DIR
    class test:
        is_windows = False
        stdin = sys.stdin
        stdin_isatty = sys.stdin.isatty()
        stdin_encoding = sys.stdin.encoding
        stdout = sys.stdout
        stdout_isatty = sys.stdout.isatty()
        stdout_encoding = sys.stdout.encoding
        stderr = sys.stderr
        stderr_isatty = sys.stderr.isatty()
        colors = 256
        program_name = 'http'
        _orig_stderr = sys.stderr
        config_dir = DEFAULT_CONFIG_DIR

# Generated at 2022-06-21 13:45:03.263479
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    import sys
    import os
    from pathlib import Path
    from environment import Environment
    from inputoutput import StringIO
    import shutil
    from sympy import Eq, Symbol
    # we will write this file for unit testing
    data_dir = "tmp_httpies_test_config.json"
    # files don't exist at this moment
    # so config is new
    # 
    # variable storing value of symbol 'x'
    x = 25
    # variable storing path of file 'tmp_httpies_test_config.json'
    path = str(Path(data_dir).absolute())
    # variable storing value of expression Eq(5,5)
    y = Eq(5, 5)
    # variable storing name of program 'httpie'
    program_name = "httpie"
    # variable storing integer 7


# Generated at 2022-06-21 13:45:04.652298
# Unit test for method __str__ of class Environment
def test_Environment___str__():
  environment = Environment()
  assert isinstance(str(environment), str)


# Generated at 2022-06-21 13:45:29.612062
# Unit test for method __repr__ of class Environment

# Generated at 2022-06-21 13:45:33.102744
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.stderr = StringIO()
    env.log_error('test', level='error')
    assert env.stderr.getvalue() == '\nhttp: error: test\n\n'

# Generated at 2022-06-21 13:45:41.217279
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdout='', stderr='')
    assert env.stdout == ''
    assert env.stderr == ''

    env = Environment(stdout_isatty=True, stderr_isatty=True)
    assert env.stdout_isatty == True
    assert env.stderr_isatty == True

    env = Environment(stdout_encoding='ascii', stderr_encoding='ascii')
    assert env.stdout_encoding == 'ascii'
    assert env.stderr_encoding == 'ascii'

    env = Environment(colors=256)
    assert env.colors == 256

    env = Environment(program_name="test")
    assert env.program_name == 'test'


# Generated at 2022-06-21 13:45:51.137014
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():

    environment = Environment(devnull='/dev/null',
                              is_windows='True',
                              config_dir='/home/config',
                              stdin='None',
                              stdin_isatty='False',
                              stdin_encoding='utf8',
                              stdout='None',
                              stdout_isatty='False',
                              stdout_encoding='utf8',
                              stderr='None',
                              stderr_isatty='False',
                              colors='256',
                              program_name='http',
                              _orig_stderr='None',
                              _devnull='None',
                              _config='None')


# Generated at 2022-06-21 13:45:59.964371
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    import httpie.core
    env = httpie.core.Environment()

# Generated at 2022-06-21 13:46:11.690631
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    import sys
    import os
    from pathlib import Path
    from typing import IO, Optional

    e = Environment()

# Generated at 2022-06-21 13:46:20.918934
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    assert str(Environment()) == "{'config_dir': '/Users/zhengyaoxin/.httpie', 'stdin': <_io.TextIOWrapper name='<stdin>' mode='r' encoding='UTF-8'>, 'stdin_isatty': True, 'stdin_encoding': 'UTF-8', 'stdout': <_io.TextIOWrapper name='<stdout>' mode='w' encoding='UTF-8'>, 'stdout_isatty': True, 'stdout_encoding': 'UTF-8', 'stderr': <_io.TextIOWrapper name='<stderr>' mode='w' encoding='UTF-8'>, 'stderr_isatty': True, 'colors': 256, 'program_name': 'http', 'config': {}}"

env = Environment

# Generated at 2022-06-21 13:46:33.839720
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()

# Generated at 2022-06-21 13:46:43.532376
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment(devnull=None, config_dir=Path('./httpie'), stdin=sys.stdin,
        stdout=sys.stdout, stderr=sys.stdout, stdin_encoding='utf8', stdout_encoding='utf8',
        stderr_encoding='utf8', colors=256, program_name='http')

# Generated at 2022-06-21 13:46:49.456643
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(config_dir='config', program_name='http')
    assert env.config_dir == 'config'
    assert env.program_name == 'http'
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == stdin.isatty()


# test_Environment()

# Generated at 2022-06-21 13:47:29.243412
# Unit test for method __repr__ of class Environment

# Generated at 2022-06-21 13:47:35.352020
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    assert str(env) == '{\'is_windows\': False, \'config_dir\': '\
    'PosixPath(\'/Users/zhangchun/.httpie\'), \'stdin\': <_io.TextIOWrapper '\
    'encoding=\'UTF-8\'>}'


if __name__ == '__main__':
    test_Environment___str__()

# Generated at 2022-06-21 13:47:46.258987
# Unit test for constructor of class Environment
def test_Environment():
    assert repr(Environment()) == '<Environment {' \
                                  '"stderr": <httpie.compat.StdioStream object at 0x7f0c92b42e50>, ' \
                                  '"config_dir": "CONFDIR", ' \
                                  '"colors": 256, ' \
                                  '"stderr_isatty": True, ' \
                                  '"stdin": <httpie.compat.StdioStream object at 0x7f0c92b42e10>, ' \
                                  '"stdin_encoding": "utf8", ' \
                                  '"stdout": <httpie.compat.StdioStream object at 0x7f0c92b42e90>, ' \
                                  '"stdout_isatty": True, ' \
                

# Generated at 2022-06-21 13:47:47.565057
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    print(env)


# Generated at 2022-06-21 13:47:49.670446
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.log_error(msg="test msg", level='error')
    env.log_error(msg="test msg", level='warning')

# Generated at 2022-06-21 13:47:55.206839
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    rv = env.__repr__()
    assert rv in ['<Environment {...}>', '<Environment {\'config\': {...}}>'], \
        f"Unexpected value: {rv}"


# Generated at 2022-06-21 13:47:58.123878
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    msg = "error foo"
    level = 'warnin'
    out = env.log_error(msg, level)



# Generated at 2022-06-21 13:48:01.289130
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(is_windows=False, config_dir=DEFAULT_CONFIG_DIR, stdout_isatty=True)
    print(env)
    assert 1 == 0

# Generated at 2022-06-21 13:48:08.768392
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    stdin=sys.stdin
    stdout=sys.stdout
    stderr=sys.stderr
    env = Environment(stdin=stdin, stdout=stdout, stderr=stderr, config_dir='~/.config/httpie/')

# Generated at 2022-06-21 13:48:11.624898
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    assert str(env).startswith('<Environment {') 
    assert str(env).endswith('}>')


# Generated at 2022-06-21 13:48:42.978076
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    import io
    stdout = io.StringIO()
    env = Environment(stdout=stdout)
    print(env)

# Generated at 2022-06-21 13:48:53.700603
# Unit test for method __str__ of class Environment

# Generated at 2022-06-21 13:48:55.889195
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment(a = 1, b = 2)
    assert (repr(env) == "<Environment {'a': 1, 'b': 2}>")


# Generated at 2022-06-21 13:48:56.869175
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    environment = Environment()
    str(environment)

# Generated at 2022-06-21 13:48:58.909557
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name = 'httpie', config_dir = DEFAULT_CONFIG_DIR)
    assert env.program_name == 'httpie'
    assert env.config_dir == DEFAULT_CONFIG_DIR

# Generated at 2022-06-21 13:49:02.650859
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.config_dir == Path(DEFAULT_CONFIG_DIR)
    assert env.stdin is sys.stdin
    assert env.stdout is sys.stdout
    assert env.stderr is sys.stderr

# Generated at 2022-06-21 13:49:03.945427
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    assert '<Environment' in str(env)

# Generated at 2022-06-21 13:49:06.165815
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    assert repr(env) == '<Environment {program_name: http}>'


# Generated at 2022-06-21 13:49:16.389085
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name='http', colors=222)

# Generated at 2022-06-21 13:49:21.402914
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=is_windows, config_dir=DEFAULT_CONFIG_DIR,
        stdin=sys.stdin, stdin_isatty=sys.stdin.isatty() if sys.stdin else False, stdin_encoding=sys.stdin.encoding if sys.stdin else None, stdout=sys.stdout,
        stdout_isatty=sys.stdout.isatty(), stdout_encoding=sys.stdout.encoding, stderr=sys.stderr, stderr_isatty=sys.stderr.isatty(), colors=256, program_name='http')