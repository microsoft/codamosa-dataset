

# Generated at 2022-06-21 13:40:06.867818
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    print(env)
    # The output should like this:
    #
    # <Environment
    # {'is_windows': False,
    #  'config_dir': PosixPath('/home/python/.config/httpie'),
    #  'stdin': <_io.TextIOWrapper name='<stdin>' mode='r' encoding='UTF-8'>,
    #  'stdin_isatty': False,
    #  'stdin_encoding': 'UTF-8',
    #  'stdout': <_io.TextIOWrapper name='<stdout>' mode='w' encoding='UTF-8'>,
    #  'stdout_isatty': True,
    #  'stdout_encoding': 'UTF-8',
    #  'stder

# Generated at 2022-06-21 13:40:15.742778
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull = None, is_windows = False, config_dir = '/home/user/.config/httpie', 
        stdin = sys.stdin, stdin_isatty = False, stdin_encoding = None,
        stdout = sys.stdout, stdout_isatty = True, stdout_encoding = None,
        stderr = sys.stderr, stderr_isatty = True, colors = 256, program_name = 'http')
    print(env)
    print(repr(env))

test_Environment()

# Generated at 2022-06-21 13:40:18.002427
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    assert "config=<Config {}>," in repr(Environment())


# Generated at 2022-06-21 13:40:29.818396
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from httpie.cli.constants import DEFAULT_OPTIONS_PRESET_NAME
    from httpie.cli.environment import Environment
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.output.streams import write

    write(Environment())
    write(Environment(colors=256))
    write(Environment(program_name='http'))
    write(Environment(config_dir=DEFAULT_CONFIG_DIR))
    write(Environment(options_preset_name=DEFAULT_OPTIONS_PRESET_NAME))
    write(Environment(options_preset_name='DEFAULT_OPTIONS_PRESET_NAME'))
    write(Environment())
    write(Environment(colors=256))
    write(Environment(program_name='http'))

# Generated at 2022-06-21 13:40:42.648878
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    class StdStreamMock:
        def write(self, msg):
            self.content = msg

    class DevnullMock:
        def write(self, msg):
            self.content = msg

    stdin, stdout, stderr = StdStreamMock(), StdStreamMock(), StdStreamMock()
    env = Environment(stdin=stdin, stdout=stdout, stderr=stderr)
    env.log_error('test')
    assert stdout.content == None
    assert stderr.content == f'\nhttp: error: test\n\n'

    env.log_error('test', 'warning')
    assert stdout.content == None
    assert stderr.content == f'\nhttp: warning: test\n\n'


# Generated at 2022-06-21 13:40:48.420900
# Unit test for constructor of class Environment
def test_Environment():
    # Create Environment object.
    env = Environment(
        devnull = 'devnull',
        stdin_encoding = 'utf8',
        stdout_encoding = 'utf8',
        config_dir = Path.cwd()
    )
    # Assert all attributes.
    assert env.is_windows == is_windows
    assert env.config_dir == Path.cwd()
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == False
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stdout_encoding == 'utf8'
    assert env.stderr == sys.stderr
    assert env.stderr_isatty

# Generated at 2022-06-21 13:40:52.349214
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr)
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr

# Generated at 2022-06-21 13:41:04.198564
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(config_dir='/home/foo', echo=False)
    assert env.is_windows == False
    assert env.config_dir == '/home/foo'
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == True
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == True
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr
    assert env._devnull == None
    assert env.config != None


# Generated at 2022-06-21 13:41:08.225365
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from io import StringIO
    env = Environment(
        stderr=StringIO(),
        program_name='something',
    )
    env.log_error('test')
    assert env.stderr.getvalue() == '\nsomething: error: test\n\n'

# Generated at 2022-06-21 13:41:12.897690
# Unit test for constructor of class Environment
def test_Environment():
    _env = Environment()
    assert _env.is_windows == True
    assert _env.config_dir != None
    assert _env.stdin != None
    assert _env.stdout != None
    assert _env.stderr != None
    assert _env.colors == 256
    assert _env.program_name == 'http'


# Generated at 2022-06-21 13:41:18.763623
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    assert str(env) != '<Environment {}>'

# Generated at 2022-06-21 13:41:20.068488
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    assert repr(Environment()) == '<Environment {}>'

# Generated at 2022-06-21 13:41:31.064947
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    e=Environment(program_name='http')
    list_of_attr=['is_windows', 'config_dir', 'stdin', 'stdin_isatty', 'stdin_encoding', 'stdout',
        'stdout_isatty', 'stdout_encoding', 'stderr', 'stderr_isatty', 'colors', 'program_name']
    list_of_type=['bool', 'Path', 'IO', 'bool', 'str', 'IO', 'bool', 'str', 'IO', 'bool', 'int', 'str']
    assert all([hasattr(e, a) for a in list_of_attr])
    assert all([type(getattr(e, a)).__name__==b for a, b in zip(list_of_attr, list_of_type)])

#

# Generated at 2022-06-21 13:41:40.879003
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()

# Generated at 2022-06-21 13:41:45.808187
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    # Example using a configuration file for attribute config
    # config_dir = '~/.config/httpie/httpie.json'
    # Try to access the configuration file.
    # Try to load the file content into attribute config
    # If there is an exception, msg is assigned to attribute config
    # expected = '<Environment config: %s>' % msg
    # assert expected == str(Environment(config_dir=config_dir))

    # Example without configuration file for attribute config
    # expected = '<Environment config: .>'
    # assert expected == str(Environment())

    pass

# Generated at 2022-06-21 13:41:56.799629
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env is not None
    assert env.is_windows is is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == (sys.stdin.isatty() if sys.stdin else False)
    assert env.stdin_encoding == (
        getattr(sys.stdin, 'encoding', None) or 'utf8'
    )
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == (
        getattr(sys.stdout, 'encoding', None) or 'utf8'
    )
    assert env.stderr == sys.st

# Generated at 2022-06-21 13:42:08.651953
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        config_dir = Path('C:\\ProgramData\\httpie'),
        stdin = None,
        stdout = sys.stdout,
        stderr = sys.stderr,
        program_name = 'http',
    )

    # expected result

# Generated at 2022-06-21 13:42:20.268979
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    stdin = sys.stdin
    stdout = sys.stdout
    stderr = sys.stderr

    class env(Environment):
        pass
    env = env(
        stdin=stdin,
        stdout=stdout,
        stderr=stderr
    )
    stdin_isatty = stdin.isatty() if stdin else False
    stdout_isatty = stdout.isatty()
    stderr_isatty = stderr.isatty()

    if not is_windows:
        if curses:
            try:
                curses.setupterm()
                colors = curses.tigetnum('colors')
            except curses.error:
                pass
    else:
        import colorama.initialise
        stdout = colorama.initialise.wrap

# Generated at 2022-06-21 13:42:26.420468
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    import sys
    env = Environment(
        is_windows="True",
        config_dir=DEFAULT_CONFIG_DIR,
        stdin= sys.stdin,
        stdout=sys.stdout,
        stderr=sys.stderr,
        program_name="http"
    )
    env.test()

# Generated at 2022-06-21 13:42:37.976950
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()

# Generated at 2022-06-21 13:42:53.810731
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()

# Generated at 2022-06-21 13:42:55.123141
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()
    print(env)

test_Environment___repr__()

# Generated at 2022-06-21 13:43:02.121354
# Unit test for constructor of class Environment
def test_Environment():
    stdout = open("stdout.txt", "w")
    stdin = open("stdin.txt")
    stderr = open("stderr.txt", "w")
    devnull = open("devnull.txt", "w+")
    env = Environment(devnull=devnull,
                      stdout=stdout,
                      stdin=stdin,
                      stderr=stderr)
    assert devnull == env.devnull, "The value of devnull is wrong"
    assert stdout == env.stdout, "The value of stdout is wrong"
    assert stdin == env.stdin, "The value of stdin is wrong"
    assert stderr == env.stderr, "The value of stderr is wrong"
# End of unit test


# Generated at 2022-06-21 13:43:11.998184
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    """Test method __repr__ of class _Environment."""
    # Create a environment
    environment = Environment()
    # Unit test

# Generated at 2022-06-21 13:43:24.331627
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    from contextlib import redirect_stdout, redirect_stderr
    from io import StringIO
    from tempfile import TemporaryDirectory
    from unittest.mock import patch
    s = StringIO()
    env = Environment()
    with redirect_stdout(s), redirect_stderr(s):
        env.log_error('This is the error message', level='error')
        env.log_error('This is the warning message', level='warning')
    assert s.getvalue() == 'http: error: This is the error message\n\nhttp: warning: This is the warning message\n\n'
    s = StringIO()

# Generated at 2022-06-21 13:43:26.995707
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull='devnull')
    assert env.devnull == 'devnull'
    env = Environment()
    assert env.devnull is None

# Generated at 2022-06-21 13:43:36.667852
# Unit test for constructor of class Environment
def test_Environment():
    class Class(Environment):
        def __init__(self, devnull=None, **kwargs):
            self.devnull = devnull
            super(Class, self).__init__(**kwargs)

    defaults = dict(type(Class).__dict__)
    actual = dict(defaults)
    actual.update(Class(arg='value', devnull='/dev/null'))
    actual.pop('_devnull')
    actual.pop('_orig_stderr')
    actual['config'] = actual['config']
    assert str(actual) == "{'arg': 'value', 'config': <httpie.config.Config None>}"


# Generated at 2022-06-21 13:43:45.181495
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment()

# Generated at 2022-06-21 13:43:56.893836
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    

# Generated at 2022-06-21 13:44:06.151302
# Unit test for constructor of class Environment
def test_Environment():
    import io
    import tempfile
    from httpie import ExitStatus, exit_status
    from httpie.compat import is_windows
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.plugins import plugin_manager

    env = Environment(
        stdin=io.StringIO(),
        stdout=io.StringIO(),
        stderr=io.StringIO()
    )

    # Test when stdin is closed fd
    env = Environment(
        stdin=None,
        stdout=io.StringIO(),
        stderr=io.StringIO()
    )

    # Test when stderr is None
    env = Environment(
        stdin=io.StringIO(),
        stdout=io.StringIO(),
        stderr=None
    )



# Generated at 2022-06-21 13:44:15.885661
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    res = env.log_error('msg',level='error')
    assert res is None
    assert env._orig_stderr == sys.stderr


# Generated at 2022-06-21 13:44:23.921499
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    """
    Environment.__repr__()
    """
    import os,sys
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.environment import Environment
    default_config_dir = DEFAULT_CONFIG_DIR
    devnull = None
    is_windows = is_windows
    program_name = 'http'
    if not is_windows:
        if curses:
            try:
                curses.setupterm()
                colors = curses.tigetnum('colors')
            except curses.error:
                pass
    else:
        # noinspection PyUnresolvedReferences
        import colorama.initialise

# Generated at 2022-06-21 13:44:31.614816
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    assert repr(Environment()) == "<Environment {'is_windows': False, 'config_dir': PosixPath('/Users/yizhouwang/.config/httpie'), 'stdin_isatty': True, 'stdin_encoding': 'utf-8', 'stdout_isatty': True, 'stdout_encoding': 'utf-8', 'stderr_isatty': True, 'colors': 256, 'program_name': 'http', 'config': <Config <No section>>}>"

# Generated at 2022-06-21 13:44:43.487154
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    environment = Environment()
    assert type(environment.__str__()) == str

# Generated at 2022-06-21 13:44:44.504042
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
	assert repr(Environment()) == '<Environment {}>'

# Generated at 2022-06-21 13:44:52.747203
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.utils import repr_dict
    import sys
    import os
    from pathlib import Path

    assert repr_dict({
        'key1': 'value1',
        'key2': 'value2',
        'key3': 'value3',
    }) == '{\n    "key1": "value1",\n    "key2": "value2",\n    "key3": "value3"\n}'
    exception = None
    try:
        eval(test_Environment___repr__.__func__.__code__)
    except Exception as e:
        exception = e
    if exception is not None:
        raise exception



# Generated at 2022-06-21 13:44:59.538360
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    # redirect stderr to /dev/null to avoid printing to screen
    sys.stderr = open(os.devnull, 'w+')

    env = Environment()
    try:
        env.log_error('test_error', level='error')
        env.log_error('test_warning', level='warning')
    except:
        sys.stderr = sys.__stderr__
        raise


# Generated at 2022-06-21 13:45:03.737398
# Unit test for constructor of class Environment
def test_Environment():
    # 在此处为Environment类构造对象
    # 此时会执行Environment类的__init__()内部函数
    env = Environment()


test_Environment()

# Generated at 2022-06-21 13:45:07.636698
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        config_dir='/home/test_config_dir',
        stdin='stdin',
        stdout='stdout',
        stderr='stderr',
        colors=50,
        program_name='httpie'
    )
    assert env.config_dir == '/home/test_config_dir'
    assert env.stdin == 'stdin'
    assert env.stdout == 'stdout'
    assert env.stderr == 'stderr'
    assert env.colors == 50
    assert env.program_name == 'httpie'

# Generated at 2022-06-21 13:45:09.444929
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    env.program_name = 'http'
    env.log_error('Test')

# Generated at 2022-06-21 13:45:35.465278
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin_encoding = "utf8", config_dir = '/home/sean/httpie')

# Generated at 2022-06-21 13:45:40.338564
# Unit test for constructor of class Environment
def test_Environment():
    import pytest
    env = Environment()
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    env = Environment(stdout='stdout')
    assert env.stdout == 'stdout'
    env = Environment(stderr='stderr')
    assert env.stderr == 'stderr'
    with pytest.raises(AssertionError):
        Environment(unknown_var='value')

# Generated at 2022-06-21 13:45:46.276931
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    str = ''
    def fake_write(self, text: str):
        global str
        str = str + text

    environ = Environment()
    environ.stderr.write = fake_write
    environ.log_error(msg='hi', level='error')
    assert str == '\nhttp: error: hi\n\n'

# Generated at 2022-06-21 13:45:48.997641
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    e = Environment(stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr)
    print(e)

test_Environment___repr__()

# Generated at 2022-06-21 13:45:54.908837
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(a=1, b=2, c=3)
    assert env.a == 1
    assert env.b == 2
    assert env.c == 3

    import sys
    new_env = Environment(stdin=sys.stdin, stdout=sys.stderr)
    assert new_env.stdin == sys.stdin
    assert new_env.stdout == sys.stderr


# Generated at 2022-06-21 13:46:01.882698
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty() if sys.stdin else False
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.program_name == 'http'
    assert env.stdin_encoding == env.stdout_encoding == env.stderr_encoding == 'utf8'
    assert env._orig_stderr == sys

# Generated at 2022-06-21 13:46:13.405584
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    env = Environment(
        stdin=1,
        stdin_isatty=True,
        stdin_encoding='utf8',
        stdout=2,
        stdout_isatty=True,
        stdout_encoding='utf8',
        stderr=3,
        stderr_isatty=True,
        colors=256,
        program_name='http',
        devnull=4,
        config_dir=DEFAULT_CONFIG_DIR
    )

# Generated at 2022-06-21 13:46:22.032910
# Unit test for constructor of class Environment
def test_Environment():
    from httpie.config import Config
    from httpie.context import Environment
    from httpie import ExitStatus
    from httpie.exit import log
    from httpie.output.streams import UnsupportedOutputStreamError
    from tempfile import TemporaryDirectory
    from unittest.mock import patch


    # Case 1 : test environment with the required arguments
    # stdin, stdout, stderr, devnull and is_windows
    env = Environment(
        stdin = sys.stdin,
        stdout = sys.stdout,
        stderr = sys.stderr,
        devnull = None,
        is_windows = True,
        config_dir = TemporaryDirectory()
    )
    assert env.stdin is sys.stdin
    assert env.stdout is sys.stdout

# Generated at 2022-06-21 13:46:34.632019
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment()
    importing_env = Environment(stdout=None)
    env._orig_stderr = StringIO()
    importing_env._orig_stderr = StringIO()
    env.log_error('Error : Something went wrong')
    importing_env.log_error('Error : Something went wrong')
    env.log_error('Warning : Something went wrong', level='warning')
    importing_env.log_error('Warning : Something went wrong', level='warning')
    assert env._orig_stderr.getvalue() == '\nhttp: error: Error : Something went wrong\n\n\nhttp: warning: Warning : Something went wrong\n\n'

# Generated at 2022-06-21 13:46:43.565087
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    from httpie import ExitStatus
    from httpie.core import Environment

    env = Environment()
    assert "{" in str(env)

# Generated at 2022-06-21 13:47:17.338352
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    ostr = str(env)
    assert isinstance(ostr, str)



# Generated at 2022-06-21 13:47:19.024747
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    a = Environment()
    assert type(a).__name__ in str(a)


# Generated at 2022-06-21 13:47:24.286460
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    os.environ["HTTPIE_ENV"] = "1"
    env = Environment()
    try:
        env.log_error("hello_world")
    except:
        print("Please re-run tests from the project root directory")
    os.environ["HTTPIE_ENV"] = "0"

# Generated at 2022-06-21 13:47:35.224981
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=sys.stdin, program_name='http')
    assert env.devnull == sys.stdin
    assert env.program_name == 'http'
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty
    assert env.stdout_encoding == 'utf8'
    assert env.stderr == sys.stderr
    assert env.stderr_isatty
    assert env.colors == 256

if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-21 13:47:46.260143
# Unit test for method __str__ of class Environment
def test_Environment___str__():

    class MockStdin:

        encoding = 'xyz'

    class MockStdout:

        encoding = 'xyz'

    class MockStderr:

        encoding = 'xyz'

    e = Environment(
        devnull=None,
        is_windows=True,
        config_dir='/path/to/httpie',
        stdin=MockStdin(),
        stdin_isatty=True,
        stdin_encoding=None,
        stdout=MockStdout(),
        stdout_isatty=True,
        stdout_encoding=None,
        stderr=MockStderr(),
        stderr_isatty=True,
        colors=256,
        program_name='http',
    )


# Generated at 2022-06-21 13:47:48.237756
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    print(env)
    env = Environment(stdout = sys.stderr)
    print(env)

# Generated at 2022-06-21 13:48:01.288973
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment(
        is_windows=True,
        config_dir=pathlib.Path("./test_utils/config"),
        stdin=sys.stdin,
        stdin_isatty=True,
        stdin_encoding=None,
        stdout=sys.stdout,
        stdout_isatty=True,
        stdout_encoding=None,
        stderr=sys.stderr,
        stderr_isatty=True,
        colors=256,
        program_name="http"
    )

# Generated at 2022-06-21 13:48:11.893201
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    stdin_encoding_inherited_from_stdin = 'ascii'
    stdout_encoding_inherited_from_stdout = 'utf-8'
    env = Environment(
        config_dir=Path('here'), devnull=True,
        colors=8, program_name='httpie',
        stdin_encoding=None,
        stdout_encoding=None,
    )
    env.stdin = sys.stdin
    env.stdin.encoding = stdin_encoding_inherited_from_stdin
    env.stdout = sys.stdout
    env.stdout.encoding = stdout_encoding_inherited_from_stdout

# Generated at 2022-06-21 13:48:23.452471
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    a = Environment()

# Generated at 2022-06-21 13:48:28.879807
# Unit test for method log_error of class Environment
def test_Environment_log_error():
    env = Environment(program_name='http', stderr=StringIO())
    env.log_error('Some error', level='error')
    env.log_error('Some warning', level='warning')
    assert env.stderr.getvalue() == '\nhttp: error: Some error\n\n\nhttp: warning: Some warning\n\n'

# Generated at 2022-06-21 13:49:46.070922
# Unit test for method __str__ of class Environment
def test_Environment___str__():
    env = Environment()
    assert repr(env).startswith('<Environment {')
    assert repr(env).endswith('}>')
    env = Environment(devnull='/dev/null')
    assert repr(env).startswith('<Environment {')
    assert repr(env).endswith(', \'devnull\': \'/dev/null\'}>')


# Generated at 2022-06-21 13:49:55.622894
# Unit test for method __repr__ of class Environment
def test_Environment___repr__():
    from httpie import Environment, DEFAULT_CONFIG_DIR
    import os
    os.environ["color"] = '256'