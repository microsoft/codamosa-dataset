

# Generated at 2022-06-11 23:22:40.292598
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment()
    assert e.program_name == 'pyhttpie'
    assert e.stderr_isatty == True
    assert e.stderr == sys.stderr
    assert e.is_windows == False
    assert e.colors == None
    assert e._orig_stderr == sys.stderr

# Generated at 2022-06-11 23:22:41.747230
# Unit test for constructor of class Environment
def test_Environment():
    env_variable = Environment(stdout="python")
    print(env_variable)
    assert env_variable.stdout == "python"

# Generated at 2022-06-11 23:22:50.574508
# Unit test for constructor of class Environment
def test_Environment():
    import sys
    from httpie.config import DEFAULT_CONFIG_DIR

    instance = Environment()

    d = dict(type(instance).__dict__)
    d.update(instance.__dict__)
    d['config'] = instance.config

    assert d == {'config_dir': DEFAULT_CONFIG_DIR,
                 'stdin': sys.stdin,
                 'stdin_isatty': False,
                 'stdin_encoding': None,
                 'stdout': sys.stdout,
                 'stdout_isatty': False,
                 'stdout_encoding': None,
                 'stderr': sys.stderr,
                 'stderr_isatty': False,
                 'colors': 256,
                 'program_name': 'http'}



# Generated at 2022-06-11 23:22:59.980925
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin = sys.stdin, stdout = sys.stdout, stderr = sys.stderr,
                      colors = 4, program_name = 'TEST', config_dir = 'TEST_DIR')
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert env.colors == 4
    assert env.program_name == 'TEST'
    assert env.config_dir == 'TEST_DIR'
    with pytest.raises(AssertionError):
        env = Environment(stdin = sys.stdin, stdout = sys.stdout, stderr = sys.stderr,
                          colors = 4, config_dir = 'TEST_DIR')


# Generated at 2022-06-11 23:23:04.561571
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == True
    assert env.stderr_encoding == 'utf8'
    env.stderr_encoding = 'ascii'
    assert env.stderr_encoding == 'ascii'


# Generated at 2022-06-11 23:23:14.923496
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert env.stdin == sys.stdin
    print(env)

# Generated at 2022-06-11 23:23:19.272332
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment(program_name='custom') == \
        '''\
{
    "config": null,
    "colors": 256,
    "config_dir": "~/.config/httpie",
    "is_windows": false,
    "program_name": "custom",
    "stderr": <stderr>,
    "stderr_isatty": true,
    "stdin": <stdin>,
    "stdin_isatty": true,
    "stdout": <stdout>,
    "stdout_isatty": true
}'''

# Generated at 2022-06-11 23:23:31.006478
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin = sys.stdin, stdout = sys.stdout)
    if env.is_windows :
        assert env.config_dir == 'C:\\Users\\i318484\\AppData\\Roaming\\httpie'
    else :
        assert env.config_dir == '/home/i318484/.config/httpie'
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.program_name == 'http'

# Generated at 2022-06-11 23:23:38.631456
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None,is_windows=True,config_dir=DEFAULT_CONFIG_DIR,stdin=sys.stdin,stdin_isatty=True,
                      stdin_encoding="utf8",stdout=sys.stdout,stdout_isatty=True,stdout_encoding="utf8",stderr=sys.stderr,
                      stderr_isatty=True,colors=256,program_name="http")
    assert env.is_windows == True
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == True
    assert env.stdin_encoding == "utf8"
    assert env.stdout == sys.stdout
    assert env.std

# Generated at 2022-06-11 23:23:42.177992
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert 'stdin' in str(env)
    assert '<Environment' in repr(env)
    assert isinstance(env.config, Config)

# Generated at 2022-06-11 23:23:52.487626
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert isinstance(environment, Environment)


# Generated at 2022-06-11 23:24:00.960344
# Unit test for constructor of class Environment

# Generated at 2022-06-11 23:24:10.394885
# Unit test for constructor of class Environment
def test_Environment():
    from httpie.plugins import plugin_manager as pm
    from httpie.context import Environment
    from pygments import formatters
    env = Environment(stdin_encoding='utf8', stdout_encoding='cp950', program_name='httpie1.0'
                      , is_windows=False, plugin_manager=pm, color_formatter=formatters.TerminalFormatter)
    assert env.stdin_encoding == 'utf8'
    assert env.stdout_encoding == 'cp950'
    assert env.program_name == 'httpie1.0'
    assert env.is_windows == False

# Generated at 2022-06-11 23:24:19.772446
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(is_windows = False, devnull=1, config_dir = '/home/user/.httpie', stdin = 1, stdin_isatty = False, stdin_encoding = 'ascii', stdout = 1, stdout_isatty = False, stdout_encoding = 'utf8', stderr = 1, stderr_isatty = False, colors = 256, program_name = 'http')
    env.config_dir = '/home/user/.httpie'
    env.stdin = 1
    env.stdin_isatty = False
    env.stdin_encoding = 'ascii'
    env.stdout = 1
    env.stdout_isatty = False
    env.stdout_encoding = 'utf8'
    env.stderr = 1


# Generated at 2022-06-11 23:24:30.470595
# Unit test for constructor of class Environment
def test_Environment():
    import sys
    import sysconfig
    env = Environment()
    assert env.is_windows == sys.platform.startswith('win')
    assert env.config_dir == Path(sysconfig.get_path('data')).resolve()
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'


# Generated at 2022-06-11 23:24:35.844819
# Unit test for constructor of class Environment
def test_Environment():
    import io
    from unittest.mock import Mock
    stdout1 = io.StringIO()
    env1 = Environment()
    env1.stdout = stdout1
    assert stdout1 == sys.stdout
    stdout2 = Mock()
    env2 = Environment(stdout=stdout2)
    assert env1 != env2
    assert env2.stdout == stdout2

# Generated at 2022-06-11 23:24:44.274618
# Unit test for constructor of class Environment
def test_Environment():
    # Testing creation of an actual Environment
    assert Environment()

    # Testing an empty Environment
    assert Environment(
        is_windows=False,
        config_dir=Path.cwd(),
        stdin=None,
        stdin_isatty=False,
        stdin_encoding=None,
        stdout=sys.stdout,
        stdout_isatty=0,
        stdout_encoding="utf-8",
        stderr=sys.stderr,
        stderr_isatty=0,
        colors=256,
        program_name="http",
        config=Config()
    )


# Generated at 2022-06-11 23:24:48.501745
# Unit test for constructor of class Environment
def test_Environment():
    obj_env = Environment(is_windows=True, stdin=sys.stdin, stdin_isatty=True,
                          stdout=sys.stdout, stdout_isatty=True,
                          stderr=sys.stderr, stderr_isatty=True,
                          config_dir=DEFAULT_CONFIG_DIR, colors=256,
                          program_name="http")

    assert obj_env.is_windows == True
    assert obj_env.stdin == sys.stdin
    assert obj_env.stdin_isatty == True
    assert obj_env.stdout == sys.stdout
    assert obj_env.stdout_isatty == True
    assert obj_env.stderr == sys.stderr
    assert obj_env.stderr_is

# Generated at 2022-06-11 23:24:52.176788
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(is_windows=True, stderr="\n")
    assert env.is_windows
    assert env.stderr == "\n"
    assert env.colors == 0

    env = Environment()
    assert not env.is_windows
    assert env.stderr == sys.stderr
    assert env.colors == 256

# Generated at 2022-06-11 23:24:57.300766
# Unit test for constructor of class Environment
def test_Environment():
    os.environ['HTTPIE_CONFIG_DIR'] = str(Path(__file__).parent.joinpath('test_config/'))
    environment = Environment()
    assert isinstance(environment, Environment)

# Generated at 2022-06-11 23:25:25.998673
# Unit test for constructor of class Environment
def test_Environment():
    '''
    :return:
    '''
    env = Environment()
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == ''
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == True
    assert env.is_windows == False
    assert env.program_name == 'http'
    assert env.colors == 256
    assert env.stdout_encoding == ''


# Generated at 2022-06-11 23:25:30.611254
# Unit test for constructor of class Environment
def test_Environment():
    # Unit test for constructor of class Environment
    def test_stdout_isatty(self):
        env = Environment(stdout_isatty=False)
        assert not env.stdout_isatty

    def test_stdin_isatty(self):
        env = Environment(stdin_isatty=False)
        assert not env.stdin_isatty

    test_stdout_isatty()
    test_stdin_isatty()

# Generated at 2022-06-11 23:25:40.121567
# Unit test for constructor of class Environment
def test_Environment():
    from io import StringIO
    from httpie import cli
    from httpie.environment import Environment
    from httpie.config import Config
    from httpie.utils import repr_dict
    STDIN = StringIO("Hello stdin!")
    STDOUT = StringIO("Hello stdout!")
    STDERR = StringIO("Hello stderr!")
    ENV = Environment(devnull=STDOUT,
                      stdin=STDIN,
                      stdout=STDOUT,
                      stderr=STDERR,
                      program_name='httpie',
                      colors=24,
                      stdin_isatty=True,
                      stdout_isatty=False,
                      stderr_isatty=True,
                      config_dir=Config.get_config_dir(None))
    assert ENV.devnull==STDOUT
    assert ENV

# Generated at 2022-06-11 23:25:50.269175
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None)

# Generated at 2022-06-11 23:25:57.439637
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin="this is a test", stdin_isatty="false", stdin_encoding="utf8",\
                      stdout="httpie", stdout_isatty="true", stdout_encoding="utf8",\
                      stderr="error", stderr_isatty="false", stderr_encoding="utf8",\
                      colors="256", program_name="http")
    assert env.stdin == "this is a test"
    assert env.stdin_isatty == "false"
    assert env.stdin_encoding == "utf8"
    assert env.stdout == "httpie"
    assert env.stdout_isatty == "true"
    assert env.stdout_encoding == "utf8"
    assert env.stderr == "error"


# Generated at 2022-06-11 23:26:07.655998
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == '~/.httpie'
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == True
    assert env.stdin_encoding == 'UTF-8'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stdout_encoding == 'UTF-8'
    assert env.stderr == sys.stderr
    assert env.program_name == 'http'

# Generated at 2022-06-11 23:26:18.297638
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert isinstance(environment.stdin, IOBase)
    assert isinstance(environment.stdout, IOBase)
    assert isinstance(environment.stderr, IOBase)
    assert isinstance(environment.is_windows, bool)
    assert isinstance(environment.config_dir, Path)
    assert isinstance(environment.stdin_encoding, str)
    assert isinstance(environment.stdout_encoding, str)
    assert isinstance(environment.colors, int)
    assert isinstance(environment.program_name, str)
    assert environment.stdin_encoding == 'utf8'
    assert environment.stdout_encoding == 'utf8'
    assert isinstance(environment.config, Config)
    assert isinstance(environment.devnull, IOBase)
    assert environment

# Generated at 2022-06-11 23:26:27.814846
# Unit test for constructor of class Environment
def test_Environment():
	en = Environment(stdin  = sys.stdin,
			stdout = sys.stdout,
			stderr = sys.stderr,
			config_dir = DEFAULT_CONFIG_DIR,
			is_windows = is_windows,
			stdin_isatty = sys.stdin.isatty() if sys.stdin else False,
			stdout_isatty = sys.stdout.isatty(),
			stderr_isatty = sys.stderr.isatty(),
			colors = 256,
			program_name = 'http')
	print(en.is_windows)
	print(en.config_dir)
	print(en.stdin)

# Generated at 2022-06-11 23:26:38.309326
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty() if sys.stdin else False
    assert env.stdin_encoding is None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding is None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()

# Generated at 2022-06-11 23:26:45.402084
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull = '/dev/null')
    print(env)
    # assert env.stdout == '/dev/null'
    # assert env.stderr == '/dev/null'


env = Environment()

if curses and (env.is_windows or env.stdout_encoding == 'cp437'):
    curses.setupterm()
    if curses.tigetstr('colors') is not None:
        env.colors = curses.tigetnum('colors')
    else:
        # assume 8 colors
        env.colors = 256

# Generated at 2022-06-11 23:27:22.285785
# Unit test for constructor of class Environment
def test_Environment():
    stdout = sys.stdout
    stderr = sys.stderr

# Generated at 2022-06-11 23:27:24.619728
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        colors = 256,
        stdout_isatty = True
    )
    assert env.colors == 256
    assert env.stdout_isatty == True


# Generated at 2022-06-11 23:27:33.670043
# Unit test for constructor of class Environment
def test_Environment():
    en = Environment()
    assert 'Environment' in str(en)
    assert 'Environment' in repr(en)
    assert en.stdin == sys.stdin
    assert en.stdout == sys.stdout
    assert en.stderr == sys.stderr
    assert en.colorama
    assert en.config_dir == DEFAULT_CONFIG_DIR
    assert en.program_name == 'http'
    assert en.colors == 256

    en = Environment(stdin=open(os.devnull), stdout=open(os.devnull))
    assert en.stdin.isatty() == True
    assert en.stdout.isatty() == True

# Generated at 2022-06-11 23:27:43.373863
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    print('env: ', env)
    print('env.stdin: ', env.stdin)
    print('env.stdin_isatty: ', env.stdin_isatty)
    print('env.stdin_encoding: ', env.stdin_encoding)
    print('env.stdout: ', env.stdout)
    print('env.stdout_encoding: ', env.stdout_encoding)
    print('env.stdout_isatty: ', env.stdout_isatty)
    print('env.stderr: ', env.stderr)
    print('env.stderr_isatty: ', env.stderr_isatty)
    print('env.colors: ', env.colors)

# Generated at 2022-06-11 23:27:51.161499
# Unit test for constructor of class Environment
def test_Environment():
    try:
        print("Now test the __init__ function of class Environment")

        env = Environment(devnull = os.devnull, is_windows = is_windows, program_name = 'http')
        print(env.devnull)
        print(env.is_windows)
        print(env.program_name)

        env.devnull = None
        print(env.devnull)

        #test the output of __str__() and __repr__()
        print(env)
        print(repr(env))

    except Exception as e:
        print(e)


if __name__ == "__main__":

    test_Environment()

# Generated at 2022-06-11 23:27:53.877609
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment()
    assert(e.config.default_options['timeout'] == 60)

if __name__ == "__main__":
    test_Environment()

# Generated at 2022-06-11 23:28:03.791039
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == (sys.stdin.isatty() if sys.stdin else False)
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    #assert env.colors == 256
    assert env.program_name == 'http'
    #assert env._orig_

# Generated at 2022-06-11 23:28:14.366997
# Unit test for constructor of class Environment

# Generated at 2022-06-11 23:28:16.123954
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.config_dir == Path(DEFAULT_CONFIG_DIR)

# Generated at 2022-06-11 23:28:26.756754
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert isinstance(env, Environment), type(env)
    assert env.is_windows == is_windows
    assert env.config_dir == Path(DEFAULT_CONFIG_DIR)
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == 'utf8'
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_

# Generated at 2022-06-11 23:29:31.704765
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull='/dev/null', is_windows='is_windows', config_dir='/etc/httpie', stdin='sys.stdin', stdin_isatty='True', stdin_encoding='stdin_encoding', stdout='sys.stdout', stdout_isatty='False', stdout_encoding='stdout_encoding', stderr='sys.stderr', stderr_isatty='False', colors='100', program_name='http')

    assert env.devnull.read() == 'devnull'
    env.devnull = env.config_dir
    assert env.devnull == '/etc/httpie'

    assert env.is_windows == 'is_windows'

    assert env.config_dir == '/etc/httpie'

# Generated at 2022-06-11 23:29:41.559255
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == False
    assert env.config_dir.samefile(Path(DEFAULT_CONFIG_DIR))
    assert env._stdin == None
    assert env._stdin_isatty == False
    assert env._stdin_encoding == None
    assert env._stdout.samefile(sys.stdout)
    assert env._stdout_isatty == False
    assert env._stdout_encoding == None
    assert env._stderr.samefile(sys.stderr)
    assert env._stderr_isatty == False
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr.samefile(sys.stderr)
    assert env._devnull == None
    assert env._

# Generated at 2022-06-11 23:29:50.105328
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(config_dir='foo')
    assert env.config_dir == 'foo'
    env.config_dir = 'bar'
    assert env.config_dir == 'bar'

# Generated at 2022-06-11 23:30:00.215600
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(config_dir='config_dir')
    assert env.config_dir == 'config_dir'
    assert env.is_windows == False
    if env.stdin is not None:
        assert env.stdin_isatty == env.stdin.isatty()
    if env.stdin is None:
        assert env.stdin_encoding is None
    else:
        assert env.stdout_encoding is None or env.stdout_encoding is not None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == env.stdout.isatty()
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == env.stderr.isatty()

# Generated at 2022-06-11 23:30:02.439940
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.stdin_isatty is True


# Generated at 2022-06-11 23:30:11.716968
# Unit test for constructor of class Environment
def test_Environment():
    # Environment.stdin =  sys.stdin
    # Environment.stdin_isatty = True
    a = Environment()
    assert a.stdin_isatty == True
    assert a.stdin != None
    assert a.stdin_encoding != None
    assert a.stdout != None
    assert a.stdout_isatty == True
    assert a.stdout_encoding != None
    assert a.stderr != None
    assert a.stderr_isatty == True
    assert a.stderr != None
    assert a.colors == 256
    assert a.program_name == 'http'

    # Test __str__
    assert str(a) != None
    assert str(a) == '<Environment {}>'

# Generated at 2022-06-11 23:30:15.493343
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(a=42, b=None)
    assert env.a == 42
    assert env.b is None
    assert repr(env) == "<Environment {'a': 42, 'b': None}>"
    assert str(env) == "{'a': 42, 'b': None}"

# Generated at 2022-06-11 23:30:26.177199
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdout = sys.stdout, stdin = sys.stdin, stderr=sys.stderr,
        stdin_encoding = 'utf8', stdin_isatty = True, stdout_encoding = 'utf8',
        stdout_isatty = True, stderr_isatty = True, is_windows = True,
        config_dir = DEFAULT_CONFIG_DIR)
    print(env)

# Generated at 2022-06-11 23:30:36.244507
# Unit test for constructor of class Environment

# Generated at 2022-06-11 23:30:42.888362
# Unit test for constructor of class Environment
def test_Environment():
    assert repr(Environment()) == repr_dict({
        'colors': 256,
        'config': Environment().config,
        'config_dir': Environment().config_dir,
        'is_windows': Environment().is_windows,
        'program_name': 'http',
        'stderr': sys.stderr,
        'stderr_isatty': sys.stderr.isatty(),
        'stdin': sys.stdin,
        'stdin_isatty': sys.stdin.isatty(),
        'stdout': sys.stdout,
        'stdout_isatty': sys.stdout.isatty(),
    })
