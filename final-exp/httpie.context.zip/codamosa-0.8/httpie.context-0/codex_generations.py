

# Generated at 2022-06-11 23:22:43.339548
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(is_windows=False, config_dir='C:/Users/User/AppData/Local', stdin=sys.stdin, stdin_isatty=True,
                      stdin_encoding='UTF-8', stdout=sys.stdout, stdout_isatty=True, stdout_encoding='UTF-8', stderr=sys.stderr,
                      stderr_isatty=True, colors=256, program_name='http')
    print(env)



# Generated at 2022-06-11 23:22:52.059708
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == (sys.stdin.isatty() if sys.stdin else False)
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.program_name == 'http'
    assert env.colors == 256

# Generated at 2022-06-11 23:23:00.066240
# Unit test for constructor of class Environment
def test_Environment():
    stdin = 'stdin'
    stdout = 'stdout'
    stderr = 'stderr'
    config_dir = 'config_dir'
    program_name = 'program_name'
    environment = Environment(stdin=stdin, stdout=stdout, stderr=stderr, config_dir=config_dir, program_name=program_name)
    print(environment.stdin)
    print(environment.stdout)
    print(environment.stderr)
    print(environment.config_dir)
    print(environment.program_name)

if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-11 23:23:02.537814
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(colors=16, program_name='httpie')
    assert env.colors == 16
    assert env.program_name == 'httpie'



# Generated at 2022-06-11 23:23:06.252621
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdout_encoding = "utf8")
    assert all(hasattr(env, attr) for attr in ['stdout_encoding'])
    assert isinstance(env, Environment)
    assert env.stdout_encoding == 'utf8'
    assert not isinstance(env, object)


# Generated at 2022-06-11 23:23:16.080540
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert str(env) == '''<Environment {'colors': 256, 'config': None, 'config_dir': PosixPath('~/.config/httpie'),
 'is_windows': False, 'program_name': 'http', 'stderr': <stderr: 'UTF-8'>, 'stderr_encoding': 'utf-8', 'stderr_isatty': True,
 'stdin': <stdin: 'UTF-8'>, 'stdin_encoding': 'utf-8', 'stdin_isatty': True, 'stdout': <stdout: 'UTF-8'>, 'stdout_encoding': 'utf-8',
 'stdout_isatty': True}>'''


# Generated at 2022-06-11 23:23:20.195940
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin_encoding=None)
    assert env.stdin_encoding == 'utf8'
    env = Environment(stdin_encoding='abc')
    assert env.stdin_encoding == 'abc'
    env = Environment()
    assert env.stdin_encoding == 'utf8'

# Generated at 2022-06-11 23:23:23.794575
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=1)
    assert getattr(env, "stdin") == 1
    env = Environment(stdin_encoding=1)
    assert getattr(env, "stdin_encoding") == 1

# Generated at 2022-06-11 23:23:33.308478
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == Path.home().joinpath('.config', 'http')
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.program_name == 'http'

# Generated at 2022-06-11 23:23:39.586699
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    env.colors = 256
    env.stdout = sys.stdout
    print(env)
    # <Environment {'config_dir': PosixPath('/root/.config/httpie'), 'devnull': None, 'is_windows': False, 'program_name': 'http', 'stderr': <httpie.utils.StdoutBytesIO object at 0x7f39fae92460>, 'stdin': <httpie.utils.StdoutBytesIO object at 0x7f39fae92460>, 'stdin_encoding': 'utf8', 'stdin_isatty': False, 'stdout': <httpie.utils.StdoutBytesIO object at 0x7f39fae92460>, 'stdout_encoding': 'utf-8', 'stdout_isatty

# Generated at 2022-06-11 23:23:49.274254
# Unit test for constructor of class Environment
def test_Environment():
    assert not isinstance(Environment()._devnull, None)

# Generated at 2022-06-11 23:23:53.743751
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr


# Generated at 2022-06-11 23:24:01.405767
# Unit test for constructor of class Environment
def test_Environment():
    class DummyEnvironment(Environment):
        def __init__(self, devnull=None, **kwargs):
            super(DummyEnvironment, self).__init__(
                devnull,
                **kwargs)

    env = DummyEnvironment()
    if not hasattr(env, 'is_windows'):
        print("There is not a is_windows attribute for class DummyEnvironment.")
    else:
        print("There is a is_windows attribute for class DummyEnvironment.")
    if not hasattr(env, 'config_dir'):
        print("There is not a config_dir attribute for class DummyEnvironment.")
    else:
        print("There is a config_dir attribute for class DummyEnvironment.")
    if not hasattr(env, 'stdin'):
        print("There is not a stdin attribute for class DummyEnvironment.")


# Generated at 2022-06-11 23:24:14.153377
# Unit test for constructor of class Environment
def test_Environment():
    import io
    import tempfile

    out_fd, out_path = tempfile.mkstemp()
    err_fd, err_path = tempfile.mkstemp()
    env = Environment(
        stdin=None,
        stdout=io.open(out_path, 'wt'),
        stderr=io.open(err_path, 'wt'),
        config_dir=tempfile.TemporaryDirectory()
    )
    env.log_error('test', level='warning')
    try:
        raise ConfigFileError('test')
    except ConfigFileError as e:
        env.log_error(e)
    finally:
        os.close(out_fd)
        os.close(err_fd)
        os.unlink(out_path)
        os.unlink(err_path)

#

# Generated at 2022-06-11 23:24:24.178242
# Unit test for constructor of class Environment
def test_Environment():
    import random

    import sys

    import pytest

    sys.stderr = open('stdout.txt', "w")
    sys.stdout = open('stderr.txt', "w")

    for i in range(1000):
        env = Environment()
        env.stdin = i
        env.stdin_isatty = i
        env.stdin_encoding = i
        env.stdout = i
        env.stdout_isatty = i
        env.stdout_encoding = i
        env.stderr = i
        env.stderr_isatty = i
        env.colors = i
        env.program_name = i
        env._orig_stderr = i
        env._devnull = i

        assert env.stdin is i
        assert env.stdin

# Generated at 2022-06-11 23:24:30.730876
# Unit test for constructor of class Environment
def test_Environment():
    try:
        import colorama
        colorama.initialise.wrap_stream
    except ImportError:
        colorama = None

    cwd = os.getcwd()
    assert cwd
    pwd = os.path.join(cwd, '.httpie')
    assert os.path.isfile(pwd)
    en = Environment(**{'config_dir': pwd, 'colors': 256})
    assert isinstance(en, Environment)

# Generated at 2022-06-11 23:24:35.346082
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert env.devnull is None
    assert env.program_name == 'http'
    assert env.config_dir == DEFAULT_CONFIG_DIR


# Generated at 2022-06-11 23:24:41.393719
# Unit test for constructor of class Environment
def test_Environment():
    """
    默认操作系统为Windows
    若实际情况不是Windows，则认为输入参数不正确
    :return:
    """
    if is_windows:
        env = Environment()
        import colorama
    else:
        assert False, "Wrong argument!!!"

# Generated at 2022-06-11 23:24:50.017143
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        is_windows=1,
        config_dir='test_config_dir',
        stdin='test_stdin',
        stdin_isatty=1,
        stdin_encoding='test_stdin_encoding',
        stdout='test_stdout',
        stdout_isatty=1,
        stdout_encoding='test_stdout_encoding',
        stderr='test_stderr',
        stderr_isatty=1,
        colors=1,
        program_name='test_program_name',
        devnull='test_devnull',
    )
    assert isinstance(env, Environment)



# Generated at 2022-06-11 23:24:50.830913
# Unit test for constructor of class Environment
def test_Environment():
    assert str(Environment())
    assert str(Environment(foo='bar'))


# Generated at 2022-06-11 23:25:14.082205
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment(**{
        'is_windows': False,
        'config_dir': Path('/'),
        'stdin': sys.stdin,
        'stdout': sys.stdout,
        'stderr': sys.stderr,
        'program_name': 'http',
    })
    print(e)
    print('\n', e.config)
    print('\n', e.devnull)
    print('\n', e.log_error)

if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-11 23:25:24.350434
# Unit test for constructor of class Environment
def test_Environment():
    assert(hasattr(Environment, 'is_windows'))
    assert(hasattr(Environment, 'config_dir'))
    assert(hasattr(Environment, 'stdin'))
    assert(hasattr(Environment, 'stdin_isatty'))
    assert(hasattr(Environment, 'stdin_encoding'))
    assert(hasattr(Environment, 'stdout'))
    assert(hasattr(Environment, 'stdout_isatty'))
    assert(hasattr(Environment, 'stdout_encoding'))
    assert(hasattr(Environment, 'stderr'))
    assert(hasattr(Environment, 'stderr_isatty'))
    assert(hasattr(Environment, '_orig_stderr'))
    assert(hasattr(Environment, '_devnull'))

# Generated at 2022-06-11 23:25:28.098320
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdout='1', stderr='2', colors='256', program_name='http')
    assert env.stdout == '1'
    assert env.stderr == '2'
    assert env.colors == '256'
    assert env.program_name == 'http'

# Generated at 2022-06-11 23:25:36.818768
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name='http1.1', colors=4)
    print('env.program_name:', env.program_name)
    print('env.colors:', env.colors)
    print('env.is_windows:', env.is_windows)
    print('env.config_dir:', env.config_dir)
    print('env.stdin:', env.stdin)
    print('env.stdin_isatty:', env.stdin_isatty)
    print('env.stdin_encoding:', env.stdin_encoding)
    print('env.stdout:', env.stdout)
    print('env.stdout_isatty:', env.stdout_isatty)

# Generated at 2022-06-11 23:25:39.158788
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment(is_windows=True, config_dir="W:\\")
    print(repr(e))



# Generated at 2022-06-11 23:25:41.382379
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env._orig_stderr is sys.stderr


# Generated at 2022-06-11 23:25:51.664831
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty() if sys.stdin else False
    assert env.stdin_encoding == (getattr(sys.stdin, 'encoding', None) or 'utf8')
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == (getattr(sys.stdout, 'encoding', None) or 'utf8')
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stder

# Generated at 2022-06-11 23:25:56.636856
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment(stdout=object()).stdout is not sys.stdout
    assert Environment().stdout is sys.stdout
    assert Environment().stdout_isatty is sys.stdout.isatty()

    env = Environment()
    assert env.stdin == sys.stdin
    assert env.stdin_isatty is sys.stdin.isatty()

    assert env.stderr == sys.stderr
    assert env.stderr_isatty is sys.stderr.isatty()

test_Environment()

# Generated at 2022-06-11 23:26:06.859491
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull='test', program_name='test')
    assert env.devnull == 'test'
    assert env.program_name == 'test'
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin  # `None` when closed fd (#791)
    assert env.stdin_isatty == (sys.stdin.isatty() if sys.stdin else False)
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.st

# Generated at 2022-06-11 23:26:17.457095
# Unit test for constructor of class Environment
def test_Environment():
    from httpie.compat import isatty
    from httpie.config import DEFAULT_CONFIG_DIR, Config
    import sys
    from httpie.utils import repr_dict

    # Set the default
    env = Environment()
    # Test whether is_windows, config_dir, stdin, stdin_encoding, stdin_isatty, stdout,
    # stdout_encoding, stdout_isatty, stderr, stderr_isatty and colors are set
    # Test whether they are equal to their default values
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_encoding == None

# Generated at 2022-06-11 23:26:59.679170
# Unit test for constructor of class Environment
def test_Environment():
    import io

    # We are using mock to patch the inputs of the Environment class
    env = Environment(
        devnull=io.StringIO(),
        config_dir=Path('/config/dir'),
        stdin=io.StringIO(),
        stdin_isatty=True,
        stdin_encoding='utf8',
        stdout=io.StringIO(),
        stdout_isatty=True,
        stdout_encoding='utf8',
        stderr=io.StringIO(),
        stderr_isatty=True,
        is_windows=False,
        colors=256,
        program_name='http'
    )

    assert env.is_windows == False
    assert str(env.config_dir) == '/config/dir'
    assert env.stdin.__class__ == io

# Generated at 2022-06-11 23:27:10.681482
# Unit test for constructor of class Environment
def test_Environment():
    from httpie.utils import is_bytes, is_unicode

    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin  # `None` when closed fd (#791)
    assert env.stdin.isatty() == env.stdin_isatty
    assert is_bytes(env.stdin_encoding)
    assert env.stdout == sys.stdout
    assert env.stdout.isatty() == env.stdout_isatty
    assert is_unicode(env.stdout_encoding)
    assert env.stderr == sys.stderr
    assert env.stderr.isatty() == env.stderr_isatty

# Generated at 2022-06-11 23:27:11.526686
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment(colors=5)



# Generated at 2022-06-11 23:27:21.060179
# Unit test for constructor of class Environment
def test_Environment():
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.utils import is_windows

    class Environment:
        def __init__(self, devnull=None, **kwargs):
            """
            Use keyword arguments to overwrite
            any of the class attributes for this instance.

            """
            assert all(hasattr(type(self), attr) for attr in kwargs.keys())
            self.__dict__.update(**kwargs)

            # The original STDERR unaffected by --quiet’ing.
            self._orig_stderr = self.stderr
            self._devnull = devnull

            # Keyword arguments > stream.encoding > default utf8

# Generated at 2022-06-11 23:27:25.094559
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == True
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == True

# Generated at 2022-06-11 23:27:36.183534
# Unit test for constructor of class Environment
def test_Environment():
    # Test case: default Environment
    env = Environment()
    assert env.program_name == 'http'
    assert env.stdin_isatty == sys.stdin.isatty()
    # assert env.stdin == sys.stdin
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == 'utf8'
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()

    # Test case: overwrite Environment
    sys.stdin = None
    sys.stdout = 'stdout'
    sys.stderr = 'stderr'

# Generated at 2022-06-11 23:27:37.800879
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=sys.stdin)
    assert env.stdin == sys.stdin

# Generated at 2022-06-11 23:27:48.180438
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    """
    Get the information when no command lines are input,
    is_windows: true or false
    config_dir: the default OS, maybe C:/User/username/httpie
    stdin: the file of command, the output is <IO>,
    stdin_isatty: ture or false
    stdin_encoding: the encoding of stdin
    stdout: the output or file, the output is <IO>,
    stdout_isatty: true or false
    stdout_encoding: the encoding of stdout
    stderr: the error(output or file), the output is <IO>,
    stderr_isatty: true or false
    colors: the number of colors, maybe 256
    program_name: always http
    """
    assert env.is_windows==True
    assert env

# Generated at 2022-06-11 23:27:51.521185
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    print(env)
    print(env.config)
    print(env.devnull)
    env.devnull = 'hello'
    print(env.devnull)

# Generated at 2022-06-11 23:28:01.515112
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr)
    env_str = str(env)

# Generated at 2022-06-11 23:28:39.822665
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name='http', devnull=None, is_windows=True)
    assert env._orig_stderr.write
    assert env.program_name == 'http'
    assert env.is_windows
    assert env._devnull is None
    assert isinstance(env.config, Config)
    assert env.config.directory == DEFAULT_CONFIG_DIR

# Generated at 2022-06-11 23:28:41.974152
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert isinstance(env, Environment)

# Generated at 2022-06-11 23:28:53.425213
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(config_dir='/tmp/.httpie')

# Generated at 2022-06-11 23:29:01.174763
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding is None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding is None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    if not is_windows:
        if curses:
            assert env.colors == 256
        else:
            assert env.colors == 256

# Generated at 2022-06-11 23:29:06.311995
# Unit test for constructor of class Environment
def test_Environment():
    from httpie.config import Config
    environ = Environment()
    assert environ.colors == 256
    assert environ.__dict__['stdout'] == sys.stdout
    assert environ.__dict__['stderr'] == sys.stderr
    assert environ.config_dir == environ.config.directory

# Generated at 2022-06-11 23:29:15.785433
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows()
    assert env.config_dir == Path.home().joinpath('.config', 'httpie')
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == False
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == False
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == False
    assert env.program_name == 'http'
    assert env.config == Config(directory=DEFAULT_CONFIG_DIR)

# Generated at 2022-06-11 23:29:18.338324
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment()


if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-11 23:29:24.731848
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull = 'devnull')
    assert env.stdout_isatty == True
    assert env.stdout == sys.stdout
    assert env.stdin == None
    assert env.stdin_isatty == False
    assert env.stdin_encoding == None
    assert env.stderr == 'devnull'
    assert env.config == None

    env = Environment(devnull = 'devnull', stdout='stdout')
    assert env.stdout == 'stdout'


if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-11 23:29:25.829105
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment(devnull='/dev/null').devnull == '/dev/null'

# Generated at 2022-06-11 23:29:30.596426
# Unit test for constructor of class Environment
def test_Environment():
    stdout_encoding = 'fake_stdout_encoding'
    stdin_encoding = 'fake_stdin_encoding'
    e = Environment(
        stdout_encoding=stdout_encoding,
        stdin_encoding=stdin_encoding
    )
    assert e.stdout_encoding == stdout_encoding
    assert e.stdin_encoding == stdin_encoding

# Generated at 2022-06-11 23:30:52.561062
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        is_windows=True,
        config_dir=DEFAULT_CONFIG_DIR,
        stdin=None,
        stdout=sys.stdout,
        stderr=sys.stderr,
        program_name='http',
    )

# Generated at 2022-06-11 23:30:54.077429
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment.colors == 256
    assert Environment.config_dir == DEFAULT_CONFIG_DIR



# Generated at 2022-06-11 23:30:55.899008
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    print(env.__str__())
    print(env.__repr__())



# Generated at 2022-06-11 23:31:00.990994
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment(devnull=5, is_windows=True, config_dir='/tmp', stdin=object, stdin_isatty=False, stdin_encoding='utf-8', stdout=object, stdout_isatty=True, stdout_encoding='utf-8', stderr=object, stderr_isatty=True, colors=8, program_name='http')
    print(e)

# Generated at 2022-06-11 23:31:03.366291
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name='http', config_dir='/config/dir')
    assert env.program_name == 'http'
    assert env.config_dir == '/config/dir'

# Generated at 2022-06-11 23:31:05.004754
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None)
    assert env.stdin is None


env = Environment()

# Generated at 2022-06-11 23:31:15.805076
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    #  测试__init__函数
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.program_name == 'http'
    #  测试__str__函数

# Generated at 2022-06-11 23:31:20.869246
# Unit test for constructor of class Environment
def test_Environment():

    # Initialize
    env = Environment()
    
    # Verify that env.config_dir is DEFAULT_CONFIG_DIR
    assert env.config_dir == DEFAULT_CONFIG_DIR

    # Verify thta env.stderr == sys.stderr
    assert env.stderr == sys.stderr

    # Verify that env.stdout_isatty is True
    assert env.stdout_isatty



# Generated at 2022-06-11 23:31:31.864240
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.colors == 256
    assert env.config_dir == Path('C:/Users/user_name/AppData/Roaming/httpie')
    if not is_windows:
        if curses:
            try:
                curses.setupterm()
                colors = curses.tigetnum('colors')
            except curses.error:
                pass
    else:
        # noinspection PyUnresolvedReferences
        import colorama.initialise
        stdout = colorama.initialise.wrap_stream(
            env.stdout, convert=None, strip=None,
            autoreset=True, wrap=True
        )

# Generated at 2022-06-11 23:31:37.630304
# Unit test for constructor of class Environment
def test_Environment():
    from httpie.core import Environment
    env = Environment(stdout = sys.stdout, stdout_encoding = sys.stdout.encoding)
    assert env.stdout == sys.stdout
    assert env.stdout_encoding == sys.stdout.encoding
    assert env.stdin == sys.stdin
    assert env.stdin_encoding == sys.stdin.encoding
    assert env.stderr == sys.stderr
    assert env.stderr_isatty
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.is_windows == is_windows
    assert env.program_name == 'http'