

# Generated at 2022-06-11 23:22:45.430468
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull='', program_name='abc', stdin_encoding='utf8', stdout_encoding='utf8', stderr_isatty=False)
    assert env.devnull == ''
    assert env.program_name == 'abc'
    assert env.stdin_encoding == 'utf8'
    assert env.stdout_encoding == 'utf8'
    assert env.stderr_isatty == False
    env.devnull = 'no'
    assert env.devnull == 'no'

# Generated at 2022-06-11 23:22:52.542210
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == True
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == True
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stdout_encoding == 'utf8'
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == True
    assert env.colors == 256
    assert env.program_name == 'http'

# Generated at 2022-06-11 23:22:54.469829
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdout_encoding='utf8')
    assert env.stdout_encoding == 'utf8'
    assert env.stdout is sys.stdout


# Generated at 2022-06-11 23:23:04.792114
# Unit test for constructor of class Environment
def test_Environment():
    # Test case:
    # Check if the test is pass or not by the assert statement.
    # When the assert statement is not satisfied, it will raise an error.

    # Test 1: 
    environ = Environment(devnull=2)
    assert environ.devnull == 2
    assert environ.stdin == sys.stdin
    assert environ.stdin_encoding is None
    assert environ.stdin_isatty == sys.stdin.isatty()
    assert environ.stdout == sys.stdout
    assert environ.stdout_encoding is None
    assert environ.stdout_isatty == sys.stdout.isatty()
    assert environ.stderr == sys.stderr

# Generated at 2022-06-11 23:23:09.400554
# Unit test for constructor of class Environment
def test_Environment():
    e1 = Environment()
    # isatty() is not part of stdout by default
    assert not hasattr(e1.stdout, 'isatty')
    new_env = Environment(stdout = sys.stdout)
    # isatty() is part of stdout
    assert hasattr(new_env.stdout, 'isatty')


# Generated at 2022-06-11 23:23:18.172596
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'

# Generated at 2022-06-11 23:23:20.340806
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert isinstance(env, Environment)
    assert isinstance(env.stdin, IO)


# Generated at 2022-06-11 23:23:32.175353
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdout=sys.stdout, stdout_isatty=True, stdout_encoding='utf-8', stderr=sys.stderr, stderr_isatty=True, colors=257, program_name='http', config_dir=Path('/Users/<username>/.config/httpie'), stdin=None, stdin_isatty=False, stdin_encoding=None, is_windows=False, devnull=None)

# Generated at 2022-06-11 23:23:33.890321
# Unit test for constructor of class Environment
def test_Environment():
    assert not Environment().is_windows

if __name__ == "__main__":
    Environment()

# Generated at 2022-06-11 23:23:41.033345
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(config_dir='/home/httpie/.config/httpie', 
                    stdin=(sys.stdin), stdin_isatty=(sys.stdin.isatty()), stdin_encoding='None')
    print(env)
    env.devnull = (None)
    print(env)
    assert(env.config != None)


# Generated at 2022-06-11 23:24:00.247237
# Unit test for constructor of class Environment
def test_Environment():
    """
    Test environment construction.
    """
    assert Environment()
    assert Environment(is_windows=False)
    assert Environment(config_dir=DEFAULT_CONFIG_DIR)
    assert Environment(stdin=sys.stdin)
    assert Environment(stdin_isatty=sys.stdin.isatty())
    assert Environment(stdin_encoding=None)
    assert Environment(stdout=sys.stdout)
    assert Environment(stdout_isatty=sys.stdout.isatty())
    assert Environment(stdout_encoding=None)
    assert Environment(stderr=sys.stderr)
    assert Environment(stderr_isatty=sys.stderr.isatty())
    assert Environment(colors=256)
    assert Environment(program_name='http')
   

# Generated at 2022-06-11 23:24:10.240925
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().is_windows == False
    assert Environment().colors == 256
    assert Environment().config_dir == Path('/home/c/.config/httpie')
    assert Environment().stdin_isatty == True
    assert Environment().stdin_encoding == 'utf8'
    assert Environment().stdout_isatty == True
    assert Environment().stdout_encoding == 'utf8'
    assert Environment().stderr_isatty == True
    assert Environment().program_name == 'http'
    assert Environment().config  # default is None, so it is assert
    assert Environment().devnull  # default is None, so it is assert

# Generated at 2022-06-11 23:24:19.711911
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        is_windows=False,
        config_dir='test_config_dir',
        stdin='test_stdin',
        stdin_isatty=True,
        stdin_encoding='test_stdin_encoding',
        stdout='test_stdout',
        stdout_isatty=True,
        stdout_encoding='test_stdout_encoding',
        stderr='test_stderr',
        stderr_isatty=True,
        colors=128,
        program_name='test_program_name',
        devnull='test_devnull'
    )

    assert not env.is_windows
    assert env.config_dir == 'test_config_dir'
    assert env.stdin == 'test_stdin'
    assert env.std

# Generated at 2022-06-11 23:24:24.376143
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        config_dir=Path('/tmp'),
        stdin=None,
        stdout=None,
        stderr=None
    )
    assert env.config_dir == Path('/tmp')
    assert env.stdin == None
    assert env.stdout == None
    assert env.stderr == None

# Generated at 2022-06-11 23:24:32.730200
# Unit test for constructor of class Environment
def test_Environment():
    env=Environment()
    assert isinstance(env,Environment)
    assert env.is_windows==is_windows
    assert env.config_dir==DEFAULT_CONFIG_DIR
    assert env.stdin==sys.stdin
    assert env.stdin_isatty==sys.stdin.isatty()
    assert env.stdout==sys.stdout
    assert env.stdout_isatty==sys.stdout.isatty()
    assert env.stderr==sys.stderr
    assert env.stderr_isatty==sys.stderr.isatty()

# Generated at 2022-06-11 23:24:43.128364
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None,**{"config_dir": DEFAULT_CONFIG_DIR,
                          "stdin": sys.stdin,
                          "stdin_isatty": sys.stdin.isatty(),
                          "stdin_encoding": None,
                          "stdout": sys.stdout,
                          "stdout_isatty": sys.stdout.isatty(),
                          "stdout_encoding": None,
                          "stderr": sys.stderr,
                          "stderr_isatty": sys.stderr.isatty(),
                          "colors": 256,
                          "program_name": 'http'})
# print(env.__dict__)


# Generated at 2022-06-11 23:24:52.277558
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull='dd')

# Generated at 2022-06-11 23:25:01.932831
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert isinstance(env.stdin, IO)
    assert env.stdin_isatty == sys.stdin.isatty()
    assert isinstance(env.stdout, IO)
    assert env.stdout_isatty == sys.stdout.isatty()
    assert isinstance(env.stderr, IO)
    assert env.stderr_isatty == sys.stderr.isatty()
    assert isinstance(env.program_name, str)
    assert isinstance(env.devnull, IO)

# Generated at 2022-06-11 23:25:06.550858
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdout='new_stdout', stderr='new_stderr')
    assert env.stdout == 'new_stdout'
    assert env.stderr == 'new_stderr'
    assert env.stdout_encoding == None
    assert env.stdin == sys.stdin
    assert env.stdin_encoding == None

# Generated at 2022-06-11 23:25:11.758262
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=sys.stdout)
    assert env.stdin is sys.stdin
    assert env.stdin_encoding is not None
    assert env.stdout is sys.stdout
    assert env.stdout_encoding is not None
    assert env.stderr is sys.stderr
    assert env.stderr_encoding is not None

    assert env.devnull is sys.stdout



# Generated at 2022-06-11 23:25:36.134611
# Unit test for constructor of class Environment
def test_Environment():
    stdout = sys.stdout
    stdout_encoding = 'utf8'
    env = Environment(stdout=stdout, stdout_encoding=stdout_encoding)
    env_dict = env.__dict__
    assert env_dict['stdout'] == stdout
    assert env_dict['stdout_encoding'] == stdout_encoding


# Generated at 2022-06-11 23:25:44.242477
# Unit test for constructor of class Environment
def test_Environment():
    config_dir = Path(os.path.expanduser("~/.httpie/"))
    stdin = sys.stdin
    stdout = sys.stdout
    stderr = sys.stderr
    env = Environment(is_windows = is_windows, config_dir = config_dir, stdin=stdin, stdout=stdout, stderr=stderr )
    assert env.is_windows == is_windows
    assert env.config_dir == config_dir
    assert env.stdin == stdin
    assert env.stdout == stdout
    assert env.stderr == stderr



# Generated at 2022-06-11 23:25:46.472645
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(stdout_isatty=False)
    assert environment.stdout_isatty == False


# Generated at 2022-06-11 23:25:50.182433
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(ProgramName='httpx')
    assert env.program_name == 'httpx'
    assert repr(env) == "<Environment {'config_dir': '~\\httpie', 'is_windows': False, 'colors': 256, 'program_name': 'httpx'}>"

# Generated at 2022-06-11 23:25:57.400792
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert isinstance(env, Environment)

if __name__ == '__main__':
    env = Environment()
    assert env.is_windows
    assert isinstance(env.config_dir, Path)
    assert isinstance(env.stdin, IO)
    assert env.stdin_isatty
    assert env.stdin_encoding
    assert isinstance(env.stdout_isatty, bool)
    assert env.stdout_encoding
    assert isinstance(env.stderr_isatty, bool)
    assert env.colors
    assert env.program_name == 'http'
    assert isinstance(env.config, Config)
    assert isinstance(env.devnull, IO)
    assert isinstance(env._devnull, IO)

# Generated at 2022-06-11 23:26:02.718466
# Unit test for constructor of class Environment
def test_Environment():
    from io import StringIO
    s = StringIO(u'\u51a4')
    s.encoding = 'utf8'
    env = Environment(stdin=s)
    assert env.stdin_encoding == 'utf8'
    env = Environment(stdout=env.stdout)
    assert env.stdout_encoding == 'utf8'

# Generated at 2022-06-11 23:26:07.799477
# Unit test for constructor of class Environment
def test_Environment():
	env = Environment()
	assert env.is_windows == False
	assert env.config_dir != None
	assert env.stdin != None
	assert env.stdin_isatty == False
	assert env.stdout != None
	assert env.stdout_isatty == True
	assert env.stderr != None
	assert env.stderr_isatty == True

# Generated at 2022-06-11 23:26:18.379532
# Unit test for constructor of class Environment
def test_Environment():
    import sys
    from pathlib import Path
    
    # Standard streams
    stdin = sys.stdin
    stdin_encoding = stdin.encoding
    stdout = sys.stdout
    stdout_encoding = stdout.encoding
    stderr = sys.stderr
    stderr_encoding = stderr.encoding
    # Default config directory
    config_dir = Path.home().home() / '.config' / 'httpie'


# Generated at 2022-06-11 23:26:20.934395
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name='test')
    assert env.program_name == 'test'
    env = Environment()
    assert env.program_name == 'http'

# Generated at 2022-06-11 23:26:26.561554
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(is_windows=False, config_dir='/some/path')
    assert env.is_windows == False
    assert env.config_dir == '/some/path'
    assert env.stdout_isatty == True
    assert env.stderr_isatty == True
    assert env.stdout_encoding == ''
    assert env.colors == 0
    assert env.program_name == 'http'
#
#
#

# Generated at 2022-06-11 23:26:52.918524
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        stdin=object(),
        stderr=object(),
        stdout=object(),
        config_dir=Path('/foo/bar')
    )
    assert env.stdin is not sys.stdin
    assert env.stderr is not sys.stderr
    assert env.stdout is not sys.stdout
    assert env.config_dir == Path('/foo/bar')


env = Environment()  # type: Environment

# Generated at 2022-06-11 23:26:56.530049
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert not env.is_windows
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert env.colors == 256
    assert env.program_name == 'http'

# Generated at 2022-06-11 23:27:07.742567
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(is_windows=True, stdin=None, stdout=None, stderr=None, config_dir=Path('/etc/httpie'), program_name='httpie')
    assert env.is_windows
    assert env.program_name == 'httpie'
    assert env.config_dir == '/etc/httpie'
    assert env.stdin is None
    assert env.stderr is None
    assert env.stdout is None
    assert env.stdin_isatty is False
    assert env.stderr_isatty is False
    assert env.stdout_isatty is False
    assert env.stdin_encoding == 'utf8'
    assert env.stderr_encoding == 'utf8'
    assert env.stdout_encoding == 'utf8'

# Generated at 2022-06-11 23:27:17.198179
# Unit test for constructor of class Environment
def test_Environment():
    from io import StringIO
    from httpie.compat import is_windows
    out = StringIO()
    e = Environment(
        devnull=out,
        program_name='un',
        config_dir='/cnf',
        stderr=out,
        stdout=out,
        stdin=out,
        is_windows=is_windows
    )
    assert e.program_name == 'un'
    assert e.config_dir == '/cnf'
    assert e.stderr == out
    assert e.stdout == out
    assert e.stdin == out
    assert e.devnull == out
    assert e.is_windows == is_windows

    assert e.stdin_encoding == 'utf8'
    assert e.stdout_encoding == 'utf8'

# Generated at 2022-06-11 23:27:25.156673
# Unit test for constructor of class Environment
def test_Environment():
    # Calling env.__init__ with no arguments
    env = Environment()
    assert env.is_windows == is_windows
    assert env.stdin == sys.stdin
    assert env.stdin_isatty
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty
    assert env.stdout_encoding == 'utf8'
    assert env.stderr == sys.stderr
    assert env.stderr_isatty
    assert env._orig_stderr == sys.stderr
    assert env.program_name == 'http'

    # Calling env.__init__ with arguments

# Generated at 2022-06-11 23:27:33.541138
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()

    # test __init__()
    env2 = Environment(is_windows=True, stderr=sys.stderr)
    assert env2.stderr == sys.stderr
    assert env2.is_windows == True

    # test __str__()
    print(env)

    # test __repr__()
    print(env)

    # test config
    config = env.config
    assert config

    # test devnull
    devnull = env.devnull
    assert devnull

    # test log_error()
    env.log_error(f'Hello world!')

# Generated at 2022-06-11 23:27:43.187273
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull = "devnull", is_windows = "is_windows", config_dir = "config_dir", stdin = "stdin", stdin_isatty = "stdin_isatty", stdin_encoding = "stdin_encoding", stdout = "stdout", stdout_isatty = "stdout_isatty", stdout_encoding = "stdout_encoding", stderr = "stderr", stderr_isatty = "stderr_isatty", colors = "colors", program_name = "program_name")

    assert env.is_windows == "is_windows"
    assert env.config_dir == "config_dir"
    assert env.stdin == "stdin"

# Generated at 2022-06-11 23:27:50.060701
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.stdin is not None
    assert env.stdout is not None
    assert env.stderr is not None

    env = Environment(
        stdin = None,
        stdout = None,
        stderr = None,
        config_dir = Path('.')
    )
    assert env.stdin is None
    assert env.stdout is None
    assert env.stderr is None
    assert env.config_dir == Path('.')


# Generated at 2022-06-11 23:27:54.743228
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin_encoding=None, stdout_encoding=None, stderr_encoding=None)
    assert env.stdin_encoding == "utf8"
    assert env.stdout_encoding == "utf8"
    assert env.stderr_encoding == None

# Generated at 2022-06-11 23:27:56.001005
# Unit test for constructor of class Environment
def test_Environment():
    # Check if instance is created
    assert Environment()



# Generated at 2022-06-11 23:28:20.685683
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment(devnull='a', stdin='a', stdin_isatty='a', stdin_encoding='a', stdout='a', stdout_isatty='a', stdout_encoding='a', stderr='a', stderr_isatty='a', colors='a', program_name='a', config_dir='a')
    assert e.devnull == 'a'
    assert e.stdin == 'a'
    assert e.stdin_isatty == 'a'
    assert e.stdin_encoding == 'a'
    assert e.stdout == 'a'
    assert e.stdout_isatty == 'a'
    assert e.stdout_encoding == 'a'
    assert e.stderr == 'a'
    assert e.stderr_is

# Generated at 2022-06-11 23:28:29.127733
# Unit test for constructor of class Environment
def test_Environment():
    import io
    stdin = io.BytesIO(b'Hello World!')
    env = Environment(
        config_dir='a',
        stdin=stdin,
        stdout=io.BytesIO(),
        stderr=io.BytesIO(),
        program_name='b',
        colors=1,
        stdin_encoding='c',
        stdout_encoding='d',
    )
    assert env.config_dir == 'a'
    assert env.stdin == stdin
    assert env.stdout
    assert env.stderr
    assert env.program_name == 'b'
    assert env.colors == 1
    assert env.stdin_encoding == 'c'
    assert env.stdout_encoding == 'd'
    assert not env.is_windows

# Generated at 2022-06-11 23:28:38.946827
# Unit test for constructor of class Environment
def test_Environment():
    # Test default values
    e = Environment()
    assert e.is_windows == is_windows
    assert e.config_dir == DEFAULT_CONFIG_DIR
    assert e.stdin is sys.stdin
    assert e.stdin_isatty == sys.stdin.isatty()
    assert e.stdin_encoding is None
    assert e.stdout is sys.stdout
    assert e.stdout_isatty == sys.stdout.isatty()
    assert e.stdout_encoding is None
    assert e.stderr is sys.stderr
    assert e.stderr_isatty == sys.stderr.isatty()
    assert e._orig_stderr is sys.stderr
    assert e.program_name == 'http'
    assert e._

# Generated at 2022-06-11 23:28:51.034298
# Unit test for constructor of class Environment
def test_Environment():
    from httpie.config import Config
    from httpie.context import Environment
    myEnv = Environment(devnull="my devnull", is_windows=True, config_dir="my config_dir",
    stdin="my stdin", stdin_isatty=True, stdin_encoding="my stdin_encoding",stdout="my stdout",
    stdout_isatty=True, stdout_encoding="my stdout_encoding", stderr="my stderr", stderr_isatty=True,
    colors=10, program_name="my httpie")

    #devnull
    assert myEnv._devnull == "my devnull"
    myEnv.devnull = "new my devnull"
    assert myEnv._devnull == "new my devnull"
    #config_dir

# Generated at 2022-06-11 23:28:57.722308
# Unit test for constructor of class Environment
def test_Environment():
    from tempfile import TemporaryFile
    import sys
    import locale
    
    tfile = TemporaryFile(mode='w+', encoding=locale.getpreferredencoding())
    tfile.file = sys.stdout
    tfile.isatty = lambda : True
    test_env = Environment(stdout=tfile, stdin=tfile)
    sys.stdout.write('test_environment:')
    sys.stdout.write(str(test_env))
    sys.stdout.write('\n')

# Generated at 2022-06-11 23:29:08.341561
# Unit test for constructor of class Environment
def test_Environment():
    from io import StringIO
    env = Environment()
    assert env.is_windows == False
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == (os.name == 'posix' or 'TERM' in os.environ)
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == (os.name == 'posix' or 'TERM' in os.environ)
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == (os.name == 'posix' or 'TERM' in os.environ)
   

# Generated at 2022-06-11 23:29:13.614227
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment(colors=8, program_name='httpie',
                    stdin_encoding='utf8', stdout_encoding='utf8')
    assert e.colors == 8
    assert e.program_name == 'httpie'
    assert e.stdin_encoding == 'utf8'
    assert e.stdout_encoding == 'utf8'

# Generated at 2022-06-11 23:29:21.702393
# Unit test for constructor of class Environment
def test_Environment():
    import sys

    temp = Environment(
        is_windows=True,
        config_dir=Path("/home/test"),
    )
    assert temp

    temp = Environment(
        is_windows=True,
        stdin=sys.stdin,
        stdout=sys.stdout,
        stderr=sys.stderr,
        config_dir=Path("/home/test"),
        program_name="test",
    )
    assert temp

    print(temp)
    assert repr(temp)

if __name__ == "__main__":
    test_Environment()

# Generated at 2022-06-11 23:29:28.380009
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment(stdout=sys.stderr, stderr=sys.stdout)

# Generated at 2022-06-11 23:29:38.859789
# Unit test for constructor of class Environment
def test_Environment():
    import io
    import tempfile

    temp_dir = tempfile.mkdtemp()
    temp_config = f'{temp_dir}/config'

    # Case 1: no keyword arguments passed
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding is None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding is None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys

# Generated at 2022-06-11 23:30:21.177373
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None)
    assert env.stdin is None
    assert env.stdin_isatty is False

# Generated at 2022-06-11 23:30:30.652024
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().is_windows == is_windows
    assert Environment().config_dir == DEFAULT_CONFIG_DIR
    assert Environment().stdin is sys.stdin
    assert Environment().stdin_isatty == sys.stdin.isatty()
    assert Environment().stdout is sys.stdout
    assert Environment().stdout_isatty == sys.stdout.isatty()
    assert Environment().stderr is sys.stderr
    assert Environment().stderr_isatty == sys.stderr.isatty()
    assert Environment().colors == 256
    assert Environment().program_name == 'http'

# Generated at 2022-06-11 23:30:39.340420
# Unit test for constructor of class Environment
def test_Environment():
    import sys
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.program_name == 'http'
    assert not env.config

    env_ = Environment(program_name='httpie')
    assert env_.program_name == 'httpie'
    assert not env_.config

# Generated at 2022-06-11 23:30:46.095516
# Unit test for constructor of class Environment
def test_Environment():
    import sys
    import os

    sys.stdin.close()
    test=Environment(**{
        'stdin':None,
        'stdin_isatty':False,
        'stdin_encoding':None,
        'stdout':sys.stdout,
        'stdout_isatty':True,
        'stdout_encoding':None,
        'stderr':sys.stderr,
        'stderr_isatty':True,
        'stderr_encoding':None,
        'colors':256,
        'program_name':'http',
        'devnull':None
    })
    test._orig_stderr=sys.stderr
    assert test.stdin is None
    assert test.stdin_isatty is False
    assert test.stdin

# Generated at 2022-06-11 23:30:48.152440
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    env = Environment(config_dir = "Test")
    print(env)

# Generated at 2022-06-11 23:30:51.638056
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.stdin_encoding is None
    assert env.stdout_encoding is None
    assert env.is_windows is False
    with open (os.devnull, 'w') as f:
        env = Environment(devnull=f)
        assert str(env) is not None

# Generated at 2022-06-11 23:31:00.250962
# Unit test for constructor of class Environment
def test_Environment():
    _ = Environment()
    assert _.is_windows == is_windows
    assert _.config_dir == DEFAULT_CONFIG_DIR
    assert _.stdin is sys.stdin
    assert _.stdin_isatty == sys.stdin.isatty()
    assert _.stdin_encoding == sys.stdin.encoding
    assert _.stdout is sys.stdout
    assert _.stdout_isatty == sys.stdout.isatty()
    assert _.stdout_encoding == sys.stdout.encoding
    assert _.stderr is sys.stderr
    assert _.stderr_isatty == sys.stderr.isatty()
    assert _.program_name == 'http'

# Generated at 2022-06-11 23:31:09.992318
# Unit test for constructor of class Environment

# Generated at 2022-06-11 23:31:11.703216
# Unit test for constructor of class Environment
def test_Environment():
    assert isinstance(Environment(), Environment)
# End of Unit test for constructor of class Environment


# Generated at 2022-06-11 23:31:15.741574
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.__dict__ == type(env).__dict__
    env2 = Environment(colors=1)
    assert env2.__dict__ == type(env).__dict__
    assert env2.colors == 1