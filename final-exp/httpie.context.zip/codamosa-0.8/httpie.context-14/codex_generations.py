

# Generated at 2022-06-11 23:22:48.332195
# Unit test for constructor of class Environment
def test_Environment():
    assert isinstance(Environment().is_windows, bool)
    assert isinstance(Environment(is_windows=False).is_windows, bool)
    assert isinstance(Environment().config_dir, Path)
    assert isinstance(Environment(config_dir=Path('.')).config_dir, Path)
    assert isinstance(Environment().stdin, Optional[IO])
    assert isinstance(Environment(stdin=sys.stdin).stdin, Optional[IO])
    assert isinstance(Environment().stdin_isatty, bool)
    assert isinstance(Environment(stdin_isatty=False).stdin_isatty, bool)
    assert isinstance(Environment().stdin_encoding, str) or \
        isinstance(Environment().stdin_encoding, None.__class__)

# Generated at 2022-06-11 23:22:52.794537
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(is_windows=True, colors=None, devnull=None)
    assert env.is_windows == True
    assert env.colors == None
    assert env.devnull == None
    env = Environment(is_windows=False, colors=256, devnull='testdevnull')
    assert env.is_windows == False
    assert env.colors == 256
    assert env.devnull == 'testdevnull'

test_Environment()

# Generated at 2022-06-11 23:22:53.856519
# Unit test for constructor of class Environment
def test_Environment():
    obj = Environment()
    assert isinstance(obj, Environment)


# Generated at 2022-06-11 23:23:04.158706
# Unit test for constructor of class Environment
def test_Environment():
    def test_class():
        assert Environment().__class__.__name__ == "Environment"


# Generated at 2022-06-11 23:23:08.245331
# Unit test for constructor of class Environment
def test_Environment():
    #test for
    # is_windows, config_dir, stdin, stdin_isatty, stdin_encoding
    # stdout, stdout_isatty, stdout_encoding
    # stderr, stderr_isatty
    assert Environment.__init__(Environment)


# Generated at 2022-06-11 23:23:10.533200
# Unit test for constructor of class Environment
def test_Environment():
    try:
        a = Environment()
        assert a
    except:
        assert False

if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-11 23:23:20.148294
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment(
        stdin='<stdin>',
        stdout='<stdout>',
        stderr='<stderr>',
    ) == '''\
<Environment
    colors=256,
    config=None,
    config_dir=<Path(...)>,
    is_windows=False,
    program_name='http',
    stderr='<stderr>',
    stderr_isatty=False,
    stdin='<stdin>',
    stdin_encoding=None,
    stdin_isatty=False,
    stdout='<stdout>',
    stdout_encoding=None,
    stdout_isatty=False>'''

# Generated at 2022-06-11 23:23:22.978537
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdout_isatty = True)
    assert env.stdout_isatty == True
    assert env.stdin == sys.stdin


# Generated at 2022-06-11 23:23:25.223860
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env # test that checking env is not null

# Unit test to test that environment variables are the same

# Generated at 2022-06-11 23:23:36.048130
# Unit test for constructor of class Environment

# Generated at 2022-06-11 23:23:51.946886
# Unit test for constructor of class Environment
def test_Environment():
    import pytest
    try:
        from io import StringIO
        from httpie.config import Config
        from httpie.compat import is_windows
        from httpie.utils import repr_dict
    except ImportError:
        pytest.skip("Skipping because httpie is not installed")
    env = Environment()
    assert env.stdout_isatty is True
    assert env.stderr_isatty is True
    assert env.stdin_encoding is 'UTF-8'
    assert env.program_name is 'http'
    assert env.stderr_encoding is 'UTF-8'
    assert env.stdout_encoding is 'UTF-8'
    assert isinstance(env.config, Config)
    assert env.is_windows is False
    assert env.stdin.closed is False
   

# Generated at 2022-06-11 23:23:59.800443
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert env.program_name == 'http'
    if not is_windows:
        if curses:
            try:
                curses.setupterm()
                colors = curses.tigetnum('colors')
                assert env.colors == colors
            except curses.error:
                pass
    else:
        assert env.colors == 256

# Generated at 2022-06-11 23:24:00.920416
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    print(env)

# Generated at 2022-06-11 23:24:09.160942
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin = sys.stdin, stdout = sys.stdout, stderr = sys.stderr, devnull = 'hello', program_name = 'httpie')
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert env.devnull == 'hello'
    assert env.program_name == 'httpie'


print('Testing Environment ...')
test_Environment()

# Generated at 2022-06-11 23:24:19.001197
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=object(), stdout=object(), program_name='httpie')

# Generated at 2022-06-11 23:24:30.470414
# Unit test for constructor of class Environment
def test_Environment():
    cwd = os.getcwd()
    assert cwd.startswith('/Users/ljm')
    env = Environment(devnull=None, stdout=None, stderr=None, stdin=None,
                      stdout_encoding=None, stdin_encoding=None)
    assert env
    assert env.is_windows == is_windows
    assert env.config_dir == str(Path.home()) + '/.httpie'
    assert env.stdin is None
    assert env.stdin_isatty is False
    assert env.stdin_encoding is None
    assert env.stdout is None
    assert env.stdout_isatty is False
    assert env.stdout_encoding is None
    assert env.stderr is None
    assert env.stderr_isatty

# Generated at 2022-06-11 23:24:40.908946
# Unit test for constructor of class Environment
def test_Environment():
    import sys
    from httpie.config import Config
    from pathlib import Path
    from typing import IO, Optional
    from httpie import __version__ as version

    #get current environment
    environment = Environment()
    assert isinstance(environment, Environment)
    #check whether the constructor is working.
    # check default value.
    assert environment.is_windows == is_windows
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == sys.stdin.isatty()
    assert environment.stdin_encoding is None
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == sys.stdout.isatty()
    assert environment.stdout_encoding is None
    assert environment

# Generated at 2022-06-11 23:24:50.566936
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name='http', colors=256)
    assert env.program_name == 'http'
    assert env.colors == 256

# Generated at 2022-06-11 23:25:01.118310
# Unit test for constructor of class Environment
def test_Environment():
    import sys
    import os
    from pathlib import Path
    from typing import IO, Optional
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_CONFIG_DIR, Config, ConfigFileError

    Streams = [('stdin', sys.stdin), ('stdout', sys.stdout), ('stderr', sys.stderr)]
    Config_dir = Path(DEFAULT_CONFIG_DIR)
    if is_windows:
        # noinspection PyUnresolvedReferences
        import colorama.initialise
        Streams[1] = ('stdout', colorama.initialise.wrap_stream(
            Streams[1], convert=None, strip=None,
            autoreset=True, wrap=True
        ))

# Generated at 2022-06-11 23:25:11.090554
# Unit test for constructor of class Environment
def test_Environment():
    import os
    import sys
    orig_stdout = sys.stdout

    class MockStream(object):
        def __init__(self, encoding=None):
            self.encoding = encoding

        def isatty(self):
            return False

        class MockStream(object):
            def __init__(self, encoding=None):
                self.encoding = encoding

            def isatty(self):
                return False

        num_case = 1
        # Case 1: no --devnull, no --isatty, no --encoding
        environ_1 = Environment()
        assert isinstance(environ_1, Environment)
        assert environ_1.program_name == 'http'
        assert environ_1.config_dir == os.path.join(os.path.expanduser("~"), ".httpie")

# Generated at 2022-06-11 23:25:28.061249
# Unit test for constructor of class Environment
def test_Environment():
    class _Environment(Environment):
        test_attr = 1
        test_attr2 = 2

    env = _Environment(
        devnull=True,
        test_attr=2,
        stdin=None,
        stdout=sys.stdout,
        stderr=sys.stderr,
        test_attr2=3,
    )
    print(env)
    assert env.test_attr == 2
    assert env.test_attr2 == 3

# Generated at 2022-06-11 23:25:36.819765
# Unit test for constructor of class Environment
def test_Environment():
    e1 = Environment(is_windows=True,stdin='a',stdin_isatty=True,stdin_encoding='utf8',stdout=sys.stdout,
    stdout_isatty=True,stdout_encoding=None,stderr=sys.stderr,stderr_isatty=True,colors=256,program_name='http')
    assert e1.is_windows
    assert e1.stdin == 'a'
    assert e1.stdin_isatty == True
    assert e1.stdin_encoding == 'utf8'
    assert e1.stdout_isatty == True
    assert e1.stdout_encoding == None
    assert e1.stderr_isatty == True
    assert e1.program_name == 'http'

# Generated at 2022-06-11 23:25:46.953766
# Unit test for constructor of class Environment
def test_Environment():
    # Unit test for environment default
    default_env = Environment()
    assert default_env.is_windows == is_windows
    assert default_env.config_dir == DEFAULT_CONFIG_DIR
    assert default_env.stdin == sys.stdin
    assert default_env.stdin_isatty == sys.stdin.isatty()
    assert default_env.stdout == sys.stdout
    assert default_env.stdout_isatty == sys.stdout.isatty()
    assert default_env.stderr == sys.stderr
    assert default_env.stderr_isatty == sys.stderr.isatty()
    assert default_env.colors == 256
    assert default_env.program_name == 'http'

    # Unit test for environment custom
    custom_

# Generated at 2022-06-11 23:25:53.664852
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert is_windows == env.is_windows
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.program_name == 'http'

# Generated at 2022-06-11 23:26:03.453699
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert isinstance(env.is_windows, bool)
    assert isinstance(env.config_dir, Path)
    assert isinstance(env.stdin, Optional[IO])
    assert isinstance(env.stdin_isatty, bool)
    assert isinstance(env.stdin_encoding, str)
    assert isinstance(env.stdout, IO)
    assert isinstance(env.stdout_isatty, bool)
    assert isinstance(env.stdout_encoding, str)
    assert isinstance(env.stderr, IO)
    assert isinstance(env.stderr_isatty, bool)
    assert isinstance(env.colors, int)
    assert isinstance(env.program_name, str)
    assert isinstance(env._config, Config)


# Generated at 2022-06-11 23:26:04.992186
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().is_windows is True
    assert Environment(
        is_windows = None
    ).is_windows is False

# Generated at 2022-06-11 23:26:15.485079
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(is_windows=False, stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr)
    assert environment.is_windows == False
    assert environment.stdin == sys.stdin
    assert environment.stdout == sys.stdout
    assert environment.stderr == sys.stderr

# Generated at 2022-06-11 23:26:21.594204
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.stderr_isatty == sys.stderr.isatty()
    assert environment.stdin == sys.stdin
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == sys.stdout.isatty()
    assert environment.stderr == sys.stderr
    assert environment._orig_stderr == sys.stderr
    assert environment._devnull == None


# Generated at 2022-06-11 23:26:31.551926
# Unit test for constructor of class Environment
def test_Environment():
    environ = Environment(
        is_windows=True,
        config_dir='/root/.config/httpie',
        stdin='stdin',
        stdin_isatty='True',
        stdout='stdout',
        stdout_isatty='False',
        stderr='stderr',
        stderr_isatty='False',
        colors='8',
        program_name='httpie',
        devnull='devnull'
    )
    assert environ.is_windows == True
    assert environ.config_dir == Path('/root/.config/httpie')
    assert environ.stdin == 'stdin'
    assert environ.stdin_isatty == True
    assert environ.stdout == 'stdout'
    assert environ.stdout_isatty == False

# Generated at 2022-06-11 23:26:33.018701
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    print(str(environment))
    print(repr(environment))

# Generated at 2022-06-11 23:26:53.382318
# Unit test for constructor of class Environment
def test_Environment():
    os.environ['HTTPIE_CONFIG_DIR'] = '~/.httpie'
    env = Environment(
        config_dir = '~/.httpie',
        stdin_isatty = True,
        stdout_isatty = True,
        stderr_isatty = True,
        colors = 256,
        program_name = 'http'
    )
    assert env.config_dir == '~/.httpie'
    assert env.stdin_isatty == True
    assert env.stdout_isatty == True
    assert env.stderr_isatty == True
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env.config.directory == '~/.httpie'

if __name__ == '__main__':
    test_Environment

# Generated at 2022-06-11 23:26:54.935866
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().is_windows == is_windows
    assert Environment(is_windows=False).is_windows is False



# Generated at 2022-06-11 23:27:00.588071
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    # stdout_isatty = False
    assert env.stdin_isatty == False
    assert env.stdin_encoding == False

    assert env.is_windows is True
    assert env.config_dir == DEFAULT_CONFIG_DIR

# Generated at 2022-06-11 23:27:03.753625
# Unit test for constructor of class Environment
def test_Environment():
    Environment(program_name='httpie', config_dir=Path('.'))
    assert sys.stdin.isatty() == False
    assert sys.stdout.isatty() == True



# Generated at 2022-06-11 23:27:14.077817
# Unit test for constructor of class Environment
def test_Environment():
    # Create an instance of class Environment
    env = Environment(is_windows=True, config_dir=DEFAULT_CONFIG_DIR, stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr, program_name='http')
    assert env.is_windows == True
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert env.program_name == 'http'

    # Try to overwrite the value of env.stdout and then check it
    new_env = Environment(stdout=sys.stderr)
    assert new_env.stdout == sys.stderr



# Generated at 2022-06-11 23:27:17.600238
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment( 
        is_windows = True,
        config_dir = '/home/hong/config',
        stdin = sys.stdin,
        stdin_isatty = False,
        stdin_encoding = 'utf-8',
        stdout = sys.stdout,
        stdout_isatty = False, 
        stdout_encoding = 'utf-8',
        stderr = sys.stderr,
        stderr_isatty = False,
        colors = 256,
        program_name = 'http')
    print(env)

# Generated at 2022-06-11 23:27:20.113617
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull = b'hello', is_windows = False)
    assert env.devnull == b'hello'
    assert env.is_windows == False

# Generated at 2022-06-11 23:27:26.211927
# Unit test for constructor of class Environment
def test_Environment():
    if is_windows:
        # noinspection PyUnresolvedReferences
        import colorama.initialise
        stdout = colorama.initialise.wrap_stream(
            sys.stdout, convert=None, strip=None,
            autoreset=True, wrap=True
        )
        stderr = colorama.initialise.wrap_stream(
            sys.stderr, convert=None, strip=None,
            autoreset=True, wrap=True
        )
        del colorama

    env = Environment(
        stdin=sys.stdin,
        stdout=sys.stdout,
        stderr=sys.stderr,
        program_name='http'
    )
    assert env
    print(env)

# Generated at 2022-06-11 23:27:29.401105
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR


from httpie.downloads import Downloader, DownloadManager



# Generated at 2022-06-11 23:27:40.189168
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=1, program_name='httpie')
    assert env.devnull == 1
    assert env.program_name == 'httpie'
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == (sys.stdin.isatty() if sys.stdin else False)
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()


# Generated at 2022-06-11 23:27:59.720371
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.stdin_encoding == (sys.stdin.encoding or 'utf8')
    assert env.stdout_encoding == (sys.stdout.encoding or 'utf8')
    assert env.stderr_encoding == (sys.stderr.encoding or 'utf8')

# Generated at 2022-06-11 23:28:10.291562
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.config_dir == DEFAULT_CONFIG_DIR
    if sys.stdin.isatty():
        assert env.stdin_isatty is True
    if sys.stdout.isatty():
        assert env.stdout_isatty is True
    if sys.stderr.isatty():
        assert env.stderr_isatty is True
    assert env.stdout_encoding is not None
    assert env.stderr_encoding is not None

    if sys.stdin.isatty():
        assert env.stdin_encoding is not None
    else:
        assert env.stdin_encoding is None
    env.stdin_isatty = False
    assert env.stdin_isatty is False


# Generated at 2022-06-11 23:28:14.544453
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment()
    print(Environment.__doc__)
    print(Environment.__dict__['stdout'])
    print(Environment.__dict__['stdout_isatty'])
    print(Environment.__dict__['stderr_isatty'])


# Generated at 2022-06-11 23:28:24.554173
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'



# Generated at 2022-06-11 23:28:25.888192
# Unit test for constructor of class Environment
def test_Environment():
    # Test for creation of object for class Environment
    env = Environment()


# Test for method __str__ of class Environment

# Generated at 2022-06-11 23:28:35.442077
# Unit test for constructor of class Environment
def test_Environment():
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.utils import VERSION

    import sys

    import os
    import curses
    e = Environment()
    assert e.is_windows == is_windows
    assert e.config_dir == DEFAULT_CONFIG_DIR
    assert e.stdin == sys.stdin
    assert e.stdout == sys.stdout
    assert e.stderr == sys.stderr
    if not is_windows:
        if curses:
            try:
                curses.setupterm()
                colors = curses.tigetnum('colors')
                assert e.colors == colors
            except curses.error:
                pass
    else:
        from colorama import AnsiToWin32

# Generated at 2022-06-11 23:28:40.227080
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin='stdin', stdout='stdout', stderr='stderr')
    assert env.stdin == 'stdin'
    assert env.stdout == 'stdout'
    assert env.stderr == 'stderr'
    assert env.devnull != 'stdin'
    assert env.devnull != 'stdout'
    assert env.devnull != 'stderr'

# Check log_error function of class Environment

# Generated at 2022-06-11 23:28:52.057781
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        is_windows = False,
        config_dir = 'test'
    )
    assert env.is_windows == False
    assert env.config_dir == Path('test')
    assert env.stdin == None
    assert env.stdin_isatty == False
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == True
    assert env.colors == 0
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr
    assert env._devnull == None

# Generated at 2022-06-11 23:29:00.602899
# Unit test for constructor of class Environment
def test_Environment():
    # Test default
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert env._orig_stderr == sys.stderr  # pylint: disable=protected-access
    assert env._devnull is None  # pylint: disable=protected-access
    assert env.colors == 256
    assert env.program_name == 'http'

# Generated at 2022-06-11 23:29:01.181178
# Unit test for constructor of class Environment
def test_Environment():
    pass

# Generated at 2022-06-11 23:29:21.939300
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment(config_dir=None)
    assert e.stdin is sys.stdin
    assert e.stdin_isatty is sys.stdin.isatty()
    assert e.stdin_encoding is None
    assert e.stdout is sys.stdout
    assert e.stdout_isatty is sys.stdout.isatty()
    assert e.stdout_encoding is None
    assert e.stderr is sys.stderr
    assert e.stderr_isatty is sys.stderr.isatty()
    assert e.program_name == 'http'
    assert e._orig_stderr is sys.stderr
    assert e._config is None
    assert e._devnull is None
    assert e.colors == 256
    assert e.config_

# Generated at 2022-06-11 23:29:27.130960
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr

    env = Environment(stdin=sys.stdout, stdout=sys.stdin,
                      stderr=sys.stdout)
    assert env.stdin == sys.stdout
    assert env.stdout == sys.stdin
    assert env.stderr == sys.stdout

# Generated at 2022-06-11 23:29:28.409918
# Unit test for constructor of class Environment
def test_Environment():
    Environment(devnull = None, **kwargs)


# Generated at 2022-06-11 23:29:29.366565
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env is not None

# Generated at 2022-06-11 23:29:39.740520
# Unit test for constructor of class Environment
def test_Environment():
    d=Environment()
    d.stdin_isatty=True
    d.stdout_encoding='abc'
    d.stderr_isatty=False
    d.program_name='def'
    a=Environment(stdin_isatty=True, stdout_encoding='abc',
        stderr_isatty=False, program_name='def')
    assert a.__str__()==d.__str__()
    a.stdin_isatty=False
    assert a.stdin_isatty!=d.stdin_isatty
    a.stdout_encoding='abc'
    assert a.stdout_encoding==d.stdout_encoding
    a.stderr_isatty=True

# Generated at 2022-06-11 23:29:44.919396
# Unit test for constructor of class Environment
def test_Environment():
    enc = 'utf8'
    env = Environment(
        stdin_encoding=enc,
        stdout_encoding=enc,
        config_dir=DEFAULT_CONFIG_DIR,
        program_name='http'
    )
    assert env.stdin_encoding is enc
    assert env.stdout_encoding is enc
    assert env.config_dir is DEFAULT_CONFIG_DIR
    assert env.program_name == 'http'

# Generated at 2022-06-11 23:29:54.094222
# Unit test for constructor of class Environment
def test_Environment():
    Environment()
    Environment(DEV_NULL='/dev/null')
    Environment(is_windows=True)
    Environment(config_dir='/dev/httpie')
    Environment(stdin=sys.stdin)
    Environment(stdin_isatty=sys.stdin.isatty())
    Environment(stdin_encoding='utf8')
    Environment(stdout=sys.stdout)
    Environment(stdout_isatty=sys.stdout.isatty())
    Environment(stdout_encoding='utf8')
    Environment(stdout=sys.stderr)
    Environment(stdout_isatty=sys.stderr.isatty())
    Environment(stdout_encoding='utf8')
    Environment(stderr=sys.stderr)

# Generated at 2022-06-11 23:30:04.677392
# Unit test for constructor of class Environment
def test_Environment():
  from httpie.compat import is_windows
  from httpie.config import Config, ConfigFileError
  from httpie.utils import repr_dict
  from httpie.core import env
  from httpie import ExitStatus

  e = Environment(devnull=None)
  assert e.is_windows == is_windows
  assert e.config_dir == env.config_dir
  assert e.stdin == sys.stdin
  assert e.stdin_isatty == sys.stdin.isatty() if sys.stdin else False
  assert e.stdin_encoding == None
  assert e.stdout == sys.stdout
  assert e.stdout_isatty == sys.stdout.isatty()
  assert e.stdout_encoding == None
  assert e.stderr == sys.stder

# Generated at 2022-06-11 23:30:09.813803
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.config.directory == DEFAULT_CONFIG_DIR
    assert env.stdin_isatty
    assert env.stderr_isatty
    assert env.stdout_isatty
    assert env.stdout_encoding
    assert env.stdin_encoding
    assert env.colors != 256
    assert env.program_name == 'http'
    

# Generated at 2022-06-11 23:30:16.472320
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        stdin=open('httpie/core.py', 'r'),
        stdin_isatty=False,
        stdin_encoding='utf-8',
        stdout=open('out.txt', 'w'),
        stdout_isatty=False,
        stdout_encoding='utf-8',
        stderr=open('err.txt', 'w'),
        stderr_isatty=False,
        colors=256,
        program_name='http'
    )
    # test is_windows
    assert (env.is_windows == is_windows)

    # test config_dir
    assert (env.config_dir == Path(DEFAULT_CONFIG_DIR))

    # test stdin
    assert (env.stdin == sys.stdin)

    # test std

# Generated at 2022-06-11 23:30:43.526127
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin = None, stdout = sys.stderr,
                      stderr=sys.stdout, is_windows = False,
                      config_dir = '/home/httpie/.httpie', program_name = 'httpie')
    env.stdin = sys.stdin
    assert env.stdin_encoding is None
    assert env.stdout_encoding is None
    assert env.is_windows == False
    assert env.stderr_isatty == True
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stderr
    assert env.stderr == sys.stdout
    assert env.config_dir == '/home/httpie/.httpie'
    assert env.program_name == 'httpie'


# Generated at 2022-06-11 23:30:53.267820
# Unit test for constructor of class Environment
def test_Environment():

    e1 = Environment()
    # for checking the program name
    assert e1.program_name == 'http'
    # for checking whether is it windows
    assert e1.is_windows == False
    # for checking colorama
    assert e1.stdout == e1._orig_stderr
    assert e1.stderr == e1._orig_stderr
    # for checking color number
    assert e1.colors == 256

    e2 = Environment(program_name = 'http2', is_windows = True, stdout = 'stdout', stderr = 'stderr', colors = 1)
    # for checking program name
    assert e2.program_name == 'http2'
    # for checking whether it is windows
    assert e2.is_windows == True
    # for checking colorama
    assert e

# Generated at 2022-06-11 23:31:02.386853
# Unit test for constructor of class Environment
def test_Environment():
    from httpie.config import Config
    from httpie.context import Environment
    from pathlib import Path
    # import sys

    configDir = Path('C:\\Users\\User\\.config\\httpie')
    stdin = sys.stdin
    stdinIsatty = sys.stdin.isatty()
    stdinEncoding = sys.stdin.encoding
    stdout = sys.stdout
    stdoutIsatty = sys.stdout.isatty()
    stdoutEncoding = sys.stdout.encoding
    stderr = sys.stderr
    stderrIsatty = sys.stderr.isatty()
    colors = curses.tigetnum('colors')
    programName = 'http'

    # Normal case
    env = Environment()

# Generated at 2022-06-11 23:31:04.282405
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=4, stdout=4, stderr=4)
    print(env)
    print(repr(env))

# Generated at 2022-06-11 23:31:07.586684
# Unit test for constructor of class Environment
def test_Environment():
    # Create an object of class Environment and test its constructor
    env = Environment(stdin=sys.stdin)
    assert env.stdin is sys.stdin
    assert env.stdout is sys.stdout
    assert env.stderr is sys.stderr


# Generated at 2022-06-11 23:31:15.957569
# Unit test for constructor of class Environment
def test_Environment():
    env=Environment()
    assert env.is_windows == is_windows
    assert env.config == {
        'colors': {
            'body': 'off',
            'headers': 'off',
            'error': 'on',
            'verbose': 'magenta'
        }
    }
    assert env.config == {'colors': {'body': 'off', 'headers': 'off', 'error': 'on', 'verbose': 'magenta'}}
    assert env.colors == 256


if __name__ == "__main__":
    test_Environment()

# Generated at 2022-06-11 23:31:23.889501
# Unit test for constructor of class Environment
def test_Environment():
    from httpie.utils import StdStreamEncodingError

    class FakeStdin:
        def isatty(self):
            return False

    fake_stdin = FakeStdin()

    env = Environment(stdin=fake_stdin)
    assert env.stdin_isatty is False
    assert env.stdin_encoding is None
    assert env.stdout_isatty is True
    assert env.stdout_encoding == 'utf8'
    assert isinstance(env.config, Config)

    class FakeStdout:
        def isatty(self):
            return False
        encoding = 'fake'

    fake_stdout = FakeStdout()
    env = Environment(stdout=fake_stdout)
    assert env.stdout_isatty is False
    assert env.stdout_enc

# Generated at 2022-06-11 23:31:33.581776
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None)
    assert env.stdin_isatty == False
    assert env.stdout_isatty == True
    assert env.stderr_isatty == True
    assert env.stdin_encoding == None
    assert env.stdout_encoding == 'utf8'
    assert env.stdin == None
    if not is_windows:
        if curses:
            try:
                curses.setupterm()
                colors = curses.tigetnum('colors')
            except curses.error:
                pass
    else:
        assert env.stdout_isatty == True
        assert env.stderr_isatty == True

# Generated at 2022-06-11 23:31:43.338834
# Unit test for constructor of class Environment
def test_Environment():
    obj = Environment()
    assert obj.is_windows is False
    assert obj.config_dir == Path(DEFAULT_CONFIG_DIR)
    assert obj.stdin is sys.stdin
    assert obj.stdin_isatty is True
    assert obj.stdin_encoding is None
    assert obj.stdout is sys.stdout
    assert obj.stdout_isatty is True
    assert obj.stdout_encoding is None
    assert obj.stderr is sys.stderr
    assert obj.stderr_isatty is True
    assert obj.colors == 256
    assert obj.program_name == 'http'
    assert obj.devnull is None
    assert obj.config is not None



# Generated at 2022-06-11 23:31:50.347974
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().config_dir == DEFAULT_CONFIG_DIR
    assert Environment(config_dir=Path('~/.foo')).config_dir == Path('~/.foo')