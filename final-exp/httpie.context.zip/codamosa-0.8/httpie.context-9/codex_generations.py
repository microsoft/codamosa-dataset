

# Generated at 2022-06-11 23:22:52.204001
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdin_isatty=None, stdin_encoding=None, stdout=None, stdout_isatty=None, stdout_encoding=None, stderr=None, stderr_isatty=None, stderr_encoding=None, is_windows=None, config_dir=None, colors=None, program_name=None)
    assert env.stdin is None
    assert env.stdin_isatty is None
    assert env.stdin_encoding is None
    assert env.stdout is None
    assert env.stdout_isatty is None
    assert env.stdout_encoding is None
    assert env.stderr is None
    assert env.stderr_isatty is None
    assert env.stderr_encoding

# Generated at 2022-06-11 23:22:56.923323
# Unit test for constructor of class Environment
def test_Environment():
    stdin_encoding = 'stdin_encoding'
    stdout_encoding = 'stdout_encoding'
    env = Environment(stdout_encoding=stdout_encoding, stdin_encoding=stdin_encoding)

    assert env.stdin_encoding == stdin_encoding
    assert env.stdout_encoding == stdout_encoding


# Generated at 2022-06-11 23:23:05.926094
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=False, config_dir=DEFAULT_CONFIG_DIR,
                      stdin=sys.stdin, stdin_isatty=True, stdin_encoding=None, stdout=sys.stdout,
                      stdout_isatty=True, stdout_encoding=None, stderr=sys.stderr, stderr_isatty=True,
                      colors=256, program_name='http', _config=None)
    print(env)
    print(env.devnull)
    print(env.config)
    env.log_error('-v, --verbose')

if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-11 23:23:15.975729
# Unit test for constructor of class Environment
def test_Environment():
    class TestEnvironment(Environment):
        pass
    import sys, platform
    stdin = sys.stdin
    stdout = sys.stdout
    stderr = sys.stderr
    config_dir = DEFAULT_CONFIG_DIR
    is_win = platform.system() == 'Windows'
    # all is default
    env1 = TestEnvironment()
    assert env1.stdin == stdin
    assert env1.stdout == stdout
    assert env1.stderr == stderr
    assert env1.config_dir == config_dir
    # overwrite config_dir
    env2 = TestEnvironment(config_dir='./config')
    assert env2.config_dir == './config'
    # overwrite all

# Generated at 2022-06-11 23:23:17.391757
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    print(env)


# Generated at 2022-06-11 23:23:27.995695
# Unit test for constructor of class Environment
def test_Environment():
    stdin = sys.stdin
    stdout = sys.stdout
    stderr = sys.stderr
    config_dir = "test_dir"
    env = Environment(stdin=stdin, stdout=stdout, stderr=stderr, config_dir=config_dir)

    assert env.is_windows == is_windows
    assert env.config_dir == config_dir
    assert env.stdin == stdin
    assert env.stdin_isatty == stdin.isatty() if stdin else False
    assert env.stdin_encoding == None
    assert env.stdout == stdout
    assert env.stdout_isatty == stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == stderr

# Generated at 2022-06-11 23:23:30.829670
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    print(env)

if __name__ == "__main__":
    test_Environment()

# Generated at 2022-06-11 23:23:32.268977
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env


# Test for class ConfigFileError

# Generated at 2022-06-11 23:23:39.218898
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment(program_name='测试')
    assert len(e.__dict__) == 18
    assert e.__dict__['program_name'] == '测试'
    assert e.config_dir == Path(DEFAULT_CONFIG_DIR)
    assert e.stdin is sys.stdin
    assert e.stdin_isatty is True
    assert e.stdin_encoding == 'utf8'
    assert e.stdout is sys.stdout
    assert e.stdout_isatty is True
    assert e.stdout_encoding == 'utf8'
    assert e.stderr is sys.stderr
    assert e.stderr_isatty is True
    assert e.colors is 256
    assert e.program_name == '测试'

# Generated at 2022-06-11 23:23:49.693247
# Unit test for constructor of class Environment
def test_Environment():
    '''Test Environment.py'''
    env = Environment(**{'devnull': None, 'is_windows': False, 'config_dir': DEFAULT_CONFIG_DIR, 'stdin': sys.stdin, 'stdin_isatty': True, 'stdin_encoding': 'utf8', 'stdout': sys.stdout, 'stdout_isatty': True, 'stdout_encoding': 'utf8', 'stderr': sys.stderr, 'stderr_isatty': True, 'colors': 256, 'program_name': 'http', '_orig_stderr': sys.stderr, '_devnull': None, '_config': None})
    assert isinstance(env, Environment)
    assert env.is_windows == False
    assert env.config_dir == DEFAULT_CON

# Generated at 2022-06-11 23:24:02.651775
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    env.program_name = 'test'
    assert str(env) == "{'colors': 256, 'config': ~/.httpie, 'program_name': 'test', 'stderr': <_io.TextIOWrapper name='<stderr>' mode='w' encoding='UTF-8'>, 'stderr_isatty': True, 'stdin': <_io.TextIOWrapper name='<stdin>' mode='r' encoding='UTF-8'>, 'stdin_encoding': 'utf8', 'stdin_isatty': True, 'stdout': <_io.TextIOWrapper name='<stdout>' mode='w' encoding='UTF-8'>, 'stdout_encoding': 'utf8', 'stdout_isatty': True}"

# Generated at 2022-06-11 23:24:15.248473
# Unit test for constructor of class Environment
def test_Environment():
    import io
    import tempfile
    fobj = io.BytesIO()
    temp = tempfile.NamedTemporaryFile()
    env = Environment(devnull=fobj,
                      program_name='http',
                      colors=256,
                      stdin=sys.stdin,
                      stdin_encoding='utf-8',
                      stdout=sys.stdout,
                      stdout_encoding='utf-8',
                      stderr=sys.stderr,
                      is_windows=False,
                      config_dir=DEFAULT_CONFIG_DIR)

# Generated at 2022-06-11 23:24:24.601412
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name='httpie', stdout_encoding='test_stdout_encoding',
        stdin_encoding='test_stdin_encoding', stderr_encoding='test_stderr_encoding', config_dir='test_config_dir')
    assert env.program_name == 'httpie'
    assert env.stdout_encoding == 'test_stdout_encoding'
    assert env.stdin_encoding == 'test_stdin_encoding'
    assert env.stderr_encoding == 'test_stderr_encoding'
    assert env.config_dir == 'test_config_dir'
    assert env.config_dir == DEFAULT_CONFIG_DIR

test_Environment()

# Generated at 2022-06-11 23:24:31.177248
# Unit test for constructor of class Environment
def test_Environment():
    import re
    env = Environment()
    assert str(env).startswith("<Environment {")
    assert str(env).endswith("'>")
    assert re.search("program_name: 'http'",str(env)),str(env)
    #assert re.match("<Environment: ",str(env)),str(env)
    #assert re.search(" program_name: 'http'$",str(env)),str(env)

# Generated at 2022-06-11 23:24:41.731040
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name='httpie')
    assert env.program_name == 'httpie'
    assert env.stderr == sys.stderr
    assert env.config is not None
    assert env.config.directory == DEFAULT_CONFIG_DIR
    assert env.config_dir == DEFAULT_CONFIG_DIR
    from io import StringIO
    from pathlib import Path
    new_env = Environment(
        stderr=StringIO(),
        config_dir = Path('/tmp'),
        program_name='httpie',
    )
    assert new_env.program_name == 'httpie'
    assert new_env.stderr != sys.stderr
    assert new_env.config is not None
    assert new_env.config.directory == Path('/tmp')

# Generated at 2022-06-11 23:24:42.640663
# Unit test for constructor of class Environment
def test_Environment():
    assert repr(Environment()) == repr(Environment(None))

# Generated at 2022-06-11 23:24:46.954078
# Unit test for constructor of class Environment
def test_Environment():
    env=Environment(is_windows=True, stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr, config_dir=DEFAULT_CONFIG_DIR, program_name='http')
    print(env)
#test_Environment()

# Generated at 2022-06-11 23:24:54.415315
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin.isatty() == sys.stdin.isatty()
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout.isatty() == sys.stdout.isatty()
    assert env.stdout_encoding == 'utf8'
    assert env.stderr == sys.stderr
    assert env.stderr.isatty() == sys.stderr.isatty()
    assert env.program_name == 'http'
    assert env.config is None
    assert env._config is None
   

# Generated at 2022-06-11 23:24:56.212919
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        is_windows=False
    )
    assert env.is_windows == False

#Unit test for __init__ of class Environment

# Generated at 2022-06-11 23:25:03.983438
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._devnull is None
    assert env._orig_stderr == sys.stderr


# Generated at 2022-06-11 23:25:17.439896
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name="httpie", config_dir="./config_dir")
    assert env.program_name == "httpie"
    assert env.config_dir == "./config_dir"

# Generated at 2022-06-11 23:25:26.678972
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=False, config_dir='/Users/Artjom/Desktop/.httpie', stdin=sys.stdin, stdin_isatty=sys.stdin.isatty(), stdin_encoding=None, stdout=sys.stdout, stdout_isatty=sys.stdout.isatty(), stdout_encoding=None, stderr=sys.stderr, stderr_isatty=sys.stderr.isatty(), colors=256, program_name='http')
    print(env)
    print(env._orig_stderr)
    print(env._devnull)
    print(env.config_dir)
    print(env.stdin)
    print(env.stdin_isatty)

# Generated at 2022-06-11 23:25:29.177093
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(is_windows=False, config_dir='/Users/dummy')
    assert env.is_windows is False
    assert env.config_dir == Path('/Users/dummy')

# Generated at 2022-06-11 23:25:38.363180
# Unit test for constructor of class Environment
def test_Environment():
    class MyEnv(Environment):
        is_windows = True
        config_dir = '/path/to/dir'
        stdin = '<stdin>'
        stdin_isatty = False
        stdin_encoding = 'utf8'
        stdout = '<stdout>'
        stdout_isatty = False
        stdout_encoding = 'utf8'
        stderr = '<stderr>'
        stderr_isatty = False
        colors = 32
        program_name = 'httpie-test'

    env = MyEnv(devnull='devnull')
    assert env.devnull == 'devnull'
    assert env.config_dir == '/path/to/dir'
    assert env.stdin == '<stdin>'
    assert env.stdin_

# Generated at 2022-06-11 23:25:39.371090
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert True

# Generated at 2022-06-11 23:25:48.442453
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == env.stdin.isatty()
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == env.stdout.isatty()
    assert env.stdout_encoding == sys.stdout.encoding
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == env.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'

# Generated at 2022-06-11 23:25:53.073608
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert env.is_windows == is_windows
    
    with pytest.raises(AssertionError):
        Environment(devnull=1)

# Generated at 2022-06-11 23:25:56.418800
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()

    assert(env.config_dir == DEFAULT_CONFIG_DIR)
    assert(env.stdin == sys.stdin)
    assert(env.stdout == sys.stdout)
    assert(env.stderr == sys.stderr)
    assert(env.colors == 256)

# Generated at 2022-06-11 23:26:00.602764
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name='http', colors=5, stdout_encoding='utf8')
    assert env.program_name == 'http'
    assert env.colors == 5
    assert env.stdout_encoding == 'utf8'
    assert env.stdin.readline() == '\n'

# Generated at 2022-06-11 23:26:04.907394
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=open("error.txt", "w+"),
                      stdout=open("output.txt", "w+"),
                      stderr=open("output.txt", "w+"))
    print(env)

if __name__ == "__main__":
    test_Environment()

# Generated at 2022-06-11 23:26:34.112611
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        is_windows=False,
        config_dir='My Config Dir',
        stdin='Standard Input',
        stdin_isatty=True,
        stdin_encoding='stdin encoding',
        stdout='Standard Output',
        stdout_isatty=False,
        stdout_encoding='stdout encoding',
        stderr='Standard Error',
        stderr_isatty=False,
        colors=255,
        program_name='My HTTPie'
    )
    assert env.is_windows is False
    assert env.config_dir == 'My Config Dir'
    assert env.stdin == 'Standard Input'
    assert env.stdin_isatty is True
    assert env.stdin_encoding == 'stdin encoding'

# Generated at 2022-06-11 23:26:41.269114
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdout='stdout', stderr='stderr', stdin='stdin')
    #
    assert env.is_windows is False
    assert env.config_dir == os.path.join(os.environ['HOME'], '.config', 'httpie')
    assert env.stdin == 'stdin'
    assert env.stdin_isatty is False
    assert env.stdin_encoding is None
    assert env.stdout == 'stdout'
    assert env.stdout_isatty is False
    assert env.stdout_encoding is None
    assert env.stderr == 'stderr'
    assert env.stderr_isatty is False
    assert env.colors is 256
    assert env.program_name == 'http'
    assert env._orig_st

# Generated at 2022-06-11 23:26:43.140872
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    print('\n'.join(str(env).splitlines()))



# Generated at 2022-06-11 23:26:45.092317
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert isinstance(env, Environment)
    assert env.stdin == sys.stdin


# Generated at 2022-06-11 23:26:48.255157
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin = sys.stdin, stdout = sys.stdout, stderr = sys.stdout)
    print(env)


# Generated at 2022-06-11 23:26:53.738110
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment()
    assert e.is_windows == is_windows
    assert e.config_dir == DEFAULT_CONFIG_DIR
    assert e.stdin == sys.stdin
    assert e.stdout == sys.stdout
    assert e.stderr == sys.stderr
    assert e.stderr is not e.stdout and e.stdout is not e.stdin


# Generated at 2022-06-11 23:27:03.941673
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert is_windows == env.is_windows
    assert DEFAULT_CONFIG_DIR == env.config_dir
    assert sys.stdin == env.stdin
    assert sys.stdin.isatty() == env.stdin_isatty
    assert 'utf8' == env.stdin_encoding
    assert sys.stdout == env.stdout
    assert sys.stdout.isatty() == env.stdout_isatty
    assert 'utf8' == env.stdout_encoding
    assert sys.stderr == env.stderr
    assert sys.stderr.isatty() == env.stderr_isatty
    assert None == env._orig_stderr

# Generated at 2022-06-11 23:27:08.416224
# Unit test for constructor of class Environment
def test_Environment():
    assert repr(Environment()) == '<Environment {\'is_windows\': False, \'stdin_encoding\': \'utf8\', \'stdout_encoding\': \'utf8\', \'program_name\': \'http\'}>'

# Generated at 2022-06-11 23:27:17.800367
# Unit test for constructor of class Environment

# Generated at 2022-06-11 23:27:22.787540
# Unit test for constructor of class Environment
def test_Environment():
    # Null stdin and all other None
    _env = Environment(stdin=None, stdin_encoding=None,devnull=None)
    assert _env.stdin is sys.stdin
    assert _env.stdin is not None
    assert _env.stdin_encoding is None
    assert _env.stdout is sys.stdout
    assert _env.stdout_isatty is sys.stdout.isatty()
    assert _env.stdout_encoding is None
    assert _env.stderr is sys.stderr
    assert _env.stderr_isatty is sys.stderr.isatty()
    assert _env.colors == 256
    assert _env.program_name == 'http'
    assert _env._orig_stderr is sys.stderr


# Generated at 2022-06-11 23:28:10.973152
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment()
    assert e.is_windows == is_windows
    assert e.config_dir == DEFAULT_CONFIG_DIR
    assert e.stdin == sys.stdin
    assert e.stdin_isatty == sys.stdin.isatty() if sys.stdin else False
    assert e.stdin_encoding == None
    assert e.stdout == sys.stdout
    assert e.stdout_isatty == sys.stdout.isatty()
    assert e.stderr == sys.stderr
    assert e.stderr_isatty == sys.stderr.isatty()
    assert e.colors == 256
    assert e.program_name == 'http'
    assert e.devnull == None
    assert e._orig_stderr == sys.st

# Generated at 2022-06-11 23:28:20.442223
# Unit test for constructor of class Environment
def test_Environment():
    class A:
        def __init__(self):
            self.stdin = open("input.txt", "r")
            self.stdin_encoding = "utf8"
            self.stdout_encoding = "utf8"
            self.stdout = open("output.txt", "w")
            self.stderr = open("error.txt", "w")
            self.config_dir = DEFAULT_CONFIG_DIR


    a1 = A()
    a2 = A()
    assert a1 == a2

    b1 = A()
    b1.stdout = sys.stdout
    b2 = A()
    b2.stdout = sys.stdout
    assert b1 == b2

# Generated at 2022-06-11 23:28:28.996310
# Unit test for constructor of class Environment
def test_Environment():
    testen = Environment()
    assert testen.is_windows == is_windows
    assert testen.config_dir == DEFAULT_CONFIG_DIR
    assert testen.stdin is sys.stdin
    assert testen.stdin_isatty == sys.stdin.isatty()
    assert testen.stdout is sys.stdout
    assert testen.stdout_isatty == sys.stdout.isatty()
    assert testen.stderr is sys.stderr
    assert testen.stderr_isatty == sys.stderr.isatty()
    assert testen.colors == 256
    assert testen.program_name == 'http'
    testen = Environment(is_windows=True, colors=16, program_name='SecondTest')

# Generated at 2022-06-11 23:28:38.845157
# Unit test for constructor of class Environment
def test_Environment():
    from io import TextIOWrapper
    from httpie.utils import BINARY_SUPPRESSED_NOTICE
    stdout = TextIOWrapper(open(1, 'wb', buffering=0), encoding='utf8')
    stderr = TextIOWrapper(open(2, 'wb', buffering=0), encoding='utf8')
    env = Environment(config_dir=Path('/etc/httpie'), stdin=stdout, stdout=stdout, stderr=stderr)
    assert env.config_dir == Path('/etc/httpie')
    assert env.stdin is stdout
    assert env.stdout is stdout
    assert env.stderr is stderr

# Generated at 2022-06-11 23:28:47.988358
# Unit test for constructor of class Environment
def test_Environment():
    assert str(Environment()) == """\
{'colors': 256, 'is_windows': False, 'program_name': 'http', 'config': <httpie.config.Config {'dir': '.httpie'}>}""" # noqa: E501
    assert str(Environment(is_windows=True)) == """\
{'colors': 256, 'is_windows': True, 'program_name': 'http', 'config': <httpie.config.Config {'dir': '.httpie'}>}""" # noqa: E501

environ = Environment()

# Generated at 2022-06-11 23:28:57.989556
# Unit test for constructor of class Environment
def test_Environment():
    # Init with default values
    env = Environment()
    assert is_windows == env.is_windows
    assert DEFAULT_CONFIG_DIR == env.config_dir
    assert sys.stdin == env.stdin
    assert env.stdin.isatty() == env.stdin_isatty
    assert sys.stdout == env.stdout
    assert env.stdout.isatty() == env.stdout_isatty
    assert sys.stderr == env.stderr
    assert env.stderr.isatty() == env.stderr_isatty
    assert False == env.colors # 256 == env.colors
    assert 'http' == env.program_name
    assert str == type(str(env))

    # Init with non default values

# Generated at 2022-06-11 23:29:08.672568
# Unit test for constructor of class Environment
def test_Environment():
    #1
    e = Environment()
    assert e.is_windows == False
    assert str(e.config_dir) == '/Users/junzheng/.config/httpie'
    assert e.stdout_isatty == True
    assert e.stderr_isatty == True
    assert e.colors == 256
    assert e.program_name == 'http'
    assert str(e.devnull) == "<_io.TextIOWrapper name='/dev/null' mode='w+' encoding='UTF-8'>"
    #2
    e = Environment(devnull=True)
    try:
        e.devnull = False
    except:
        assert True
    else:
        assert False
    #3
    try:
        e.devnull = 1.1
    except:
        assert True

# Generated at 2022-06-11 23:29:15.601815
# Unit test for constructor of class Environment
def test_Environment():
    # Case 1: correct arguments of Environment
    env = Environment(is_windows = False,
                      config_dir = 'D:\\PycharmProjects\\httpie\\_env\\config_dir',
                      stdin = sys.stdin,
                      stdout = sys.stdout,
                      stderr = sys.stdout,
                      program_name = 'http',
                      _orig_stderr = sys.stdout)
    print(env.__str__())

test_Environment()

# Generated at 2022-06-11 23:29:21.086154
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=b'This is the stdin', stdout=b'This is the stdout', stderr=b'This is the stderr')
    assert env.stdin == b'This is the stdin'
    assert env.stdout == b'This is the stdout'
    assert env.stderr == b'This is the stderr'

# Generated at 2022-06-11 23:29:24.492687
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr

# Generated at 2022-06-11 23:30:44.182156
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdout_encoding='utf8', stdin_isatty=False)
    assert env.stdout_encoding is 'utf8'
    assert env.stdin_isatty is False

# Generated at 2022-06-11 23:30:47.456697
# Unit test for constructor of class Environment
def test_Environment():
    from httpie.core import Environment
    env = Environment()
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stdout_encoding == sys.stdout.encoding

# Generated at 2022-06-11 23:30:49.600243
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(config_dir=Path('new_config_dir'))
    assert env.config_dir == Path('new_config_dir')



# Generated at 2022-06-11 23:30:58.425448
# Unit test for constructor of class Environment
def test_Environment():
    import subprocess
    import sys
    import os
    from pathlib import Path
    from typing import IO, Optional

    try:
        import curses
    except ImportError:
        curses = None  # Compiled w/o curses

    from httpie.compat import is_windows
    from httpie.config import DEFAULT_CONFIG_DIR, Config, ConfigFileError

    from httpie.utils import repr_dict


    class Environment:
        """
        Information about the execution context
        (standard streams, config directory, etc).

        By default, it represents the actual environment.
        All of the attributes can be overwritten though, which
        is used by the test suite to simulate various scenarios.

        """
        is_windows: bool = is_windows
        config_dir: Path = DEFAULT_CONFIG_DIR

# Generated at 2022-06-11 23:31:04.205646
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin is sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding is None
    assert env.stdout is sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding is None

# Generated at 2022-06-11 23:31:14.338507
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(
        stdin_encoding='stdin_encoding',
        stdout_encoding='stdout_encoding'
    )
    assert environment.stdin_encoding == 'stdin_encoding'
    assert environment.stdout_encoding == 'stdout_encoding'

# Generated at 2022-06-11 23:31:23.301280
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull='/dev/null', stdin='stdin', stdin_isatty='True',
        stdin_encoding='utf8', stdout='stdout', stdout_isatty='True',
         stdout_encoding='utf8', stderr='stderr', stderr_isatty='True')

# Generated at 2022-06-11 23:31:26.129203
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(os, program_name='my_http')
    assert env

if __name__ == "__main__":
    test_Environment()

# Generated at 2022-06-11 23:31:35.831496
# Unit test for constructor of class Environment
def test_Environment():
    from tempfile import TemporaryFile
    from httpie.core import main
    from httpie.utils import strip_ansi

    stdout = TemporaryFile('w+')
    stdin = TemporaryFile('w+')
    stderr = TemporaryFile('w+')
    devnull = TemporaryFile('w+')
    env = Environment(devnull, stdout=stdout, stdin=stdin, stderr=stderr,
                      program_name='httpie-test')

    assert env.devnull == devnull
    assert env.stdout == stdout
    assert env.stdin == stdin
    assert env.stderr == stderr
    assert env.program_name == 'httpie-test'
    
    env.log_error('hello world')
    stderr.seek(0)
    assert strip_ans

# Generated at 2022-06-11 23:31:46.502533
# Unit test for constructor of class Environment
def test_Environment():
    import io
    import tempfile
    import unittest

    # pytest is needed to get a temporary test directory
    from pytest import tmpdir
    from unittest.mock import patch, mock_open
    from httpie.environment import Environment

    class MockConfig(Config):
        def __init__(self, directory: Path, *args, **kwargs):
            pass

    class MockStdIO(object):
        def __init__(self, return_value):
            self.encoding_return_value = return_value

        def encoding(self):
            return self.encoding_return_value

        def isatty(self):
            return True

    class TestEnvironment(unittest.TestCase):
        def setUp(self):
            self.test_dir = tmpdir.mkdir('.httpie').strpath