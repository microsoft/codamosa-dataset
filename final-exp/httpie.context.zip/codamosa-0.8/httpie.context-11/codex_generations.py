

# Generated at 2022-06-11 23:22:49.657860
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()

    assert env.is_windows is True
    assert env.stdin is sys.stdin
    assert env.stdin_isatty is sys.stdin.isatty()
    assert env.stdin_encoding is None
    assert env.stdout is sys.stdout
    assert env.stdout_isatty is sys.stdout.isatty()
    assert env.stdout_encoding is None
    assert env.stderr is sys.stderr
    assert env.stderr_isatty is sys.stderr.isatty()

# Generated at 2022-06-11 23:22:59.044543
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(devnull = 'some_devnull')
    environment.stdout_encoding = 'some_stdout_encoding'


# Generated at 2022-06-11 23:23:03.641388
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        stdout_encoding='utf8',
        stdin_encoding='gbk',
        program_name='http2'
    )
    assert env.stdout_encoding == 'utf8'
    assert env.stdin_encoding == 'gbk'
    assert env.program_name == 'http2'


# Unit testing for properties of class Environment

# Generated at 2022-06-11 23:23:05.861492
# Unit test for constructor of class Environment
def test_Environment():
    import sys
    import httpie.config
    env = Environment()
    assert env
    asse

# Generated at 2022-06-11 23:23:07.357827
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment()
    assert e
    print(e)

# Test for method log_error of class Environment

# Generated at 2022-06-11 23:23:14.768921
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name="hello")
    assert env.stdin.name == "<stdin>"
    assert env.stdout.name == "<stdout>"
    assert env.stderr.name == "<stderr>"
    assert env.stdin_isatty
    assert env.stdout_isatty
    assert env.stderr_isatty
    assert env.colors == 256
    assert env.program_name == "hello"
    assert env.stdin_encoding == "UTF-8"
    assert env.stdout_encoding == "UTF-8"

# Generated at 2022-06-11 23:23:19.387334
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert is_windows == env.is_windows
    assert DEFAULT_CONFIG_DIR == env.config_dir
    assert sys.stdin == env.stdin
    assert env.stdin_isatty
    assert env.stdout_isatty
    assert env.stderr_isatty
    assert 256 == env.colors
    assert 'http' == env.program_name
    assert env.stdin_encoding == 'utf8'
    assert env.stdout_encoding == 'utf8'
    # Check if property is available
    assert hasattr(env, 'config')

# Generated at 2022-06-11 23:23:24.238012
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    print(env.config_dir)
    print(env.stdin_isatty)
    print(env.stdin_encoding)
    print(env.stdout_isatty)
    print(env.stdout_encoding)
    print(env.stderr_isatty)

# Generated at 2022-06-11 23:23:35.353587
# Unit test for constructor of class Environment
def test_Environment():
    import io
    import sys
    import os
    import tempfile
    
    # create new file
    f = tempfile.mkstemp()
    # open file
    temp_stdin = io.open(f[1], 'w+', encoding='utf8')
    # close file
    os.close(f[0])
    # delete file
    os.remove(f[1])
    # change stdin
    sys.stdin = temp_stdin

    # create new file
    f = tempfile.mkstemp()
    # open file
    temp_stdout = io.open(f[1], 'w+', encoding='utf8')
    # close file
    os.close(f[0])
    # delete file
    os.remove(f[1])
    # change stdout
    sys.stdout

# Generated at 2022-06-11 23:23:38.987065
# Unit test for constructor of class Environment
def test_Environment():
    print('test_Environment')
    env = Environment(config_dir='test_config_dir')
    print(env.config_dir)

if __name__ == "__main__":
    test_Environment()

# Generated at 2022-06-11 23:23:51.227236
# Unit test for constructor of class Environment
def test_Environment():
    default_config_dir = "default config dir"
    default_stdin = "default stdin"
    default_stdout = "default stdout"
    default_stderr = "default stderr"
    default_program_name = "default program name"
    default_colors = "default colors"
    is_windows = "is windows"
    stdin_isatty = "stdin isatty"
    stdin_encoding = "stdin encoding"
    stdout_isatty = "stdout isatty"
    stdout_encoding = "stdout encoding"
    stderr_isatty = "stderr isatty"
    devnull = "devnull"

# Generated at 2022-06-11 23:24:00.719569
# Unit test for constructor of class Environment

# Generated at 2022-06-11 23:24:13.495519
# Unit test for constructor of class Environment

# Generated at 2022-06-11 23:24:20.751061
# Unit test for constructor of class Environment

# Generated at 2022-06-11 23:24:24.176724
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull = 'null')
    print(env)
    print(env._orig_stderr)
    print(env._devnull)

if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-11 23:24:29.266225
# Unit test for constructor of class Environment
def test_Environment():
    stdin = sys.stdin
    devnull = open(os.devnull, 'w+')
    env = Environment(stdin=stdin, devnull=devnull, colors=128)
    assert env.stdin is stdin
    assert env.devnull is devnull
    assert env.colors == 128


# Generated at 2022-06-11 23:24:32.935387
# Unit test for constructor of class Environment
def test_Environment():
    actual = Environment(program_name='httpie', stdin=None)
    assert actual.program_name == 'httpie'
    assert actual.stdin is None


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 23:24:43.670868
# Unit test for constructor of class Environment
def test_Environment():
    def is_file_object(obj):
        return isinstance(obj, io.IOBase)

    def is_path_object(obj):
        return type(obj) == Path

    env = Environment()
    assert is_path_object(env.config_dir)
    assert is_file_object(env.stdin)
    assert is_file_object(env.stdout)
    assert is_file_object(env.stderr)
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr_isatty == sys.stderr.isatty()
    assert type(env.stdin_encoding) == str

# Generated at 2022-06-11 23:24:52.438498
# Unit test for constructor of class Environment
def test_Environment():
    class A:
        f1 = '1'
        f2 = '2'

    class B(A):
        def __init__(self, **kwargs):
            super(B, self).__init__()
            self.__dict__.update(**kwargs)

    instance = B(f2='3', f3='4', f4='4')
    print(instance.__dict__)
    assert instance.f1 == '1'
    assert instance.f2 == '3'
    print(instance)


    env = Environment(f1='a')
    print(env)
    # print(env.__dict__)
    # print(Environment.__dict__)
    # print(filter(lambda x: not x.startswith('_'), Environment.__dict__))

# Generated at 2022-06-11 23:24:57.686966
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(config_dir=1, stderr=2, cli_options=3)
    assert env.config_dir == 1
    assert env.stderr == 2
    assert env.cli_options == 3


environment = Environment()

# Generated at 2022-06-11 23:25:14.421855
# Unit test for constructor of class Environment
def test_Environment():
    # Case 1
    env = Environment()

    assert env.is_windows == is_windows
    assert env.config_dir.__str__().__contains__('httpie')
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == (sys.stdin.encoding if sys.stdin else None)
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == (sys.stdout.encoding if sys.stdout else None)
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty

# Generated at 2022-06-11 23:25:24.498770
# Unit test for constructor of class Environment
def test_Environment():
    environ = Environment()
    assert type(environ) == Environment
    assert environ.is_windows == is_windows
    assert environ.config_dir == DEFAULT_CONFIG_DIR
    assert environ.stdin == sys.stdin
    assert environ.stdin_isatty == (environ.stdin.isatty() if environ.stdin else False)
    assert environ.stdout == sys.stdout
    assert environ.stdout_isatty == sys.stdout.isatty()
    assert environ.stderr == sys.stderr
    assert environ.stderr_isatty == sys.stderr.isatty()
    assert environ.colors == (curses.tigetnum('colors') if curses else 0)
    assert environ.program

# Generated at 2022-06-11 23:25:28.796642
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        stdin='test_stdin',
        stdout='test_stdout',
        stderr='test_stderr'
    )
    assert env.stdin == 'test_stdin'
    assert env.stdout == 'test_stdout'
    assert env.stderr == 'test_stderr'


# Generated at 2022-06-11 23:25:30.182435
# Unit test for constructor of class Environment
def test_Environment():
    environ = Environment()


if __name__ == "__main__":
    test_Environment()

# Generated at 2022-06-11 23:25:37.680986
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        is_windows=False,
        config_dir='/tmp',
        stdin=None,
        stdout=sys.stdout,
        stderr=sys.stderr,
        colors=256,
        program_name='http'
    )
    assert env.is_windows == False
    assert env.config_dir == '/tmp'
    assert env.stdin == None
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert env.colors == 256
    assert env.program_name == 'http'

test_Environment()

# Generated at 2022-06-11 23:25:44.089007
# Unit test for constructor of class Environment
def test_Environment():
    class CustomEnv(Environment):
        pass

    env = CustomEnv(is_windows=False, stdin=io.BytesIO(), stdout=io.BytesIO(), tmp_dir='/tmp', program_name=__name__)
    assert env.is_windows == False
    assert isinstance(env.stdin, io.BytesIO)
    assert isinstance(env.stdout, io.BytesIO)
    assert env.tmp_dir == '/tmp'
    assert env.program_name == __name__

# Generated at 2022-06-11 23:25:49.836067
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert not env.stdin_isatty
    assert not env.stdout_isatty
    assert not env.stderr_isatty

    assert env.stdin_encoding == 'utf-8'
    assert env.stdout_encoding == 'utf-8'
    assert env.stderr_encoding == 'utf-8'

    assert isinstance(env.config_dir, Path)

# Generated at 2022-06-11 23:25:57.252313
# Unit test for constructor of class Environment
def test_Environment():
    class DevNull:
        def write(self, b):
            pass

    env = Environment(devnull=DevNull(), stdin=None)
    assert not env.is_windows
    devnull = env.devnull
    assert str(devnull) == '<DevNull object at 0x7f42a6005588>'
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin is None
    assert env.stdin_isatty == False
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env

# Generated at 2022-06-11 23:26:01.450939
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    print(env)
    env = Environment(devnull = sys.stdout)
    print(env)
    env = Environment(demo = True)
    print(env)
    env = Environment(devnull = sys.stdout, demo = True)
    print(env)


# Generated at 2022-06-11 23:26:12.033011
# Unit test for constructor of class Environment
def test_Environment():
    #test Environment(devnull=None, **kwargs)
    #test instance is created and attributes can be overwritten
    kwargs = {'stdin': sys.stdin, 'stdin_isatty': sys.stdin.isatty()}
    env = Environment(**kwargs)
    assert isinstance(env, Environment) and \
        env.stdin == sys.stdin and env.stdin_isatty == sys.stdin.isatty()
    #test assert all(hasattr(type(self), attr) for attr in kwargs.keys())
    try:
        env = Environment(**{'hello': 'world'})
    except AssertionError:
        assert True
    else:
        assert False
    #test Environment.__str__()

# Generated at 2022-06-11 23:26:31.036616
# Unit test for constructor of class Environment
def test_Environment():
    DEVNULL = open(os.devnull, 'w+')
    env = Environment(
        program_name='haha',
        config_dir=Path('/etc'),
        stdin=DEVNULL,
        stdout=DEVNULL,
        stderr=DEVNULL,
        devnull=DEVNULL
    )
    assert env.config_dir == Path('/etc')
    assert env.stdin == DEVNULL
    assert env.stdin_isatty == False
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == DEVNULL
    assert env.stdout_isatty == False
    assert env.stdout_encoding == 'utf8'
    assert env.stderr == DEVNULL
    assert env.stderr_isatty == False
    assert env

# Generated at 2022-06-11 23:26:40.515529
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(is_windows=False, config_dir="test",
                      devnull="devnull", stdin="stdin",
                      stdin_isatty="true", stdin_encoding="utf8",
                      stdout="stdout", stdout_isatty="false",
                      stdout_encoding="utf8", stderr="stderr",
                      stderr_isatty="true", colors="256", program_name="http")
    assert env.is_windows == False
    assert env.config_dir == "test"
    assert env.devnull == "devnull"
    assert env.stdin == "stdin"
    assert env.stdin_isatty == "true"
    assert env.stdin_encoding == "utf8"
    assert env.stdout == "stdout"
   

# Generated at 2022-06-11 23:26:51.034907
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin = 1)
    print("stdin is ", env.stdin)
    print("stdin_isatty is ", env.stdin_isatty)
    print("stdin_encoding is ", env.stdin_encoding)
    print("stdout is ", env.stdout)
    print("stdout_isatty is ", env.stdout_isatty)
    print("stdout_encoding is ", env.stdout_encoding)
    print("config_dir is  ", env.config_dir)
    print("is_windows is ", env.is_windows)
    print("program_name is ", env.program_name)
    print("stderr is ", env.stderr)

# Generated at 2022-06-11 23:26:59.041903
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment()
    e.stdout_isatty = False
    e.stderr_isatty = False
    e.stdin_isatty = False
    e.config_dir = Path('./')
    assert str(e) == '<httpie.context.Environment config={}, is_windows=False, ' \
                     'program_name=http, stdin=<_io.TextIOWrapper name=7 encoding=UTF-8>, ' \
                     'stdin_isatty=False, stdout=<_io.TextIOWrapper name=1 encoding=UTF-8>, ' \
                     'stdout_isatty=False, stderr=<_io.TextIOWrapper name=2 encoding=UTF-8>, ' \
                     'stderr_isatty=False>'

# Generated at 2022-06-11 23:27:08.550908
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        debug=True,
        is_windows=False,
        config_dir='/etc/httpie/',
        stdin=None,
        stdin_isatty=False,
        stdin_encoding=None,
        stdout=None,
        stdout_isatty=False,
        stdout_encoding=None,
        stderr=None,
        stderr_isatty=False,
        colors=256,
        devnull=None,
        program_name='http',
        _orig_stderr=None,
        _config=None
    )
    assert env == Environment()


env = Environment()

# Generated at 2022-06-11 23:27:10.880411
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdout=True, stderr=True)
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr

# Generated at 2022-06-11 23:27:19.783520
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows == is_windows
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == sys.stdin.isatty()
    assert environment.stdin_encoding == None
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == sys.stdout.isatty()
    assert environment.stdout_encoding == None
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == sys.stderr.isatty()
    assert environment.colors == 256
    assert environment.program_name == 'http'

# Generated at 2022-06-11 23:27:26.932521
# Unit test for constructor of class Environment
def test_Environment():
    #is_windows should be True if it's running on windows
    if is_windows:
        assert (Environment().is_windows == is_windows)
    else:
        assert (Environment().is_windows == is_windows)
    f = open(os.devnull, "w+")
    assert (Environment(devnull=f).devnull == f)
    f.close()
    assert (Environment()._devnull == None)
    assert (Environment()._orig_stderr == sys.stderr)
    assert (Environment().colors == 256)
    assert (Environment().program_name == 'http')
    assert (Environment().stdin == sys.stdin)
    assert (Environment().stdin_isatty == sys.stdin.isatty())

# Generated at 2022-06-11 23:27:31.221688
# Unit test for constructor of class Environment
def test_Environment():
    sys.stdout = open('temp_httpie_test1.txt','w')
    sys.stdin = open('temp_httpie_test2.txt','r')
    sys.stderr = open('temp_httpie_test3.txt','w')
    print(Environment())


# Generated at 2022-06-11 23:27:41.780000
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin is sys.stdin
    assert env.stdin_isatty is (sys.stdin is not None and sys.stdin.isatty())
    assert env.stdin_encoding is None
    assert env.stdout is sys.stdout
    assert env.stdout_isatty is sys.stdout.isatty()
    assert env.stdout_encoding is None
    assert env.stderr is sys.stderr
    assert env.stderr_isatty is sys.stderr.isatty()
    assert env._orig_stderr is sys.stderr
    assert env._devnull is None

# Generated at 2022-06-11 23:28:08.220640
# Unit test for constructor of class Environment
def test_Environment():
    class MyEnv(Environment):
        pass

    env = MyEnv(devnull=True)
    assert env.devnull
    assert env.is_windows
    assert env.config_dir
    assert env.stdin
    assert env.stdin_isatty
    assert env.stdin_encoding
    assert env.stdout
    assert env.stdout_isatty
    assert env.stdout_encoding
    assert env.stderr
    assert env.stderr_isatty
    assert env.colors
    assert env.program_name



# Generated at 2022-06-11 23:28:15.598517
# Unit test for constructor of class Environment
def test_Environment():
    """
    >>> e = Environment(config_dir=DEFAULT_CONFIG_DIR)
    >>> e.config_dir == DEFAULT_CONFIG_DIR
    True
    >>> e.stdin == sys.stdin
    True
    >>> e.stderr == sys.stderr
    True
    >>> e.stdout == sys.stdout
    True
    >>> e.stderr_isatty and e.stdout_isatty
    True
    """

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 23:28:20.665208
# Unit test for constructor of class Environment
def test_Environment():
    """
    There are four cases:

        1. Attributes defined in the class and arguments passed to the
           constructor (w/o overwriting)
        2. Attributes defined in the class, arguments passed to the constructor
           and overwriting some of them
        3. Attributes, class and arguments with default values
        4. Attributes, class and arguments without default values

    """

    # 1. Attributes defined in the class and arguments passed to the
    # constructor (w/o overwriting)

# Generated at 2022-06-11 23:28:28.695843
# Unit test for constructor of class Environment
def test_Environment():
    env=Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.program_name == 'http'
    #assert env.colors == 256

# Generated at 2022-06-11 23:28:38.594812
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.stdin == sys.stdin # 这个我们可以模拟出来
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert env.stdin_encoding is None
    assert env.stdout_encoding is None
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.program_name == 'http'
    assert env.is_windows == is_windows

# Generated at 2022-06-11 23:28:50.980811
# Unit test for constructor of class Environment
def test_Environment():
    import sys
    import os
    import tempfile
    from pathlib import Path
    from typing import Optional
    from httpie import environment
    import httpie.config
    from httpie.cli.colors import httpie_colors
    from httpie.exitstatus import ExitStatus

    assert isinstance(environment, environment.Environment)
    assert environment.is_windows == False
    assert isinstance(environment.config_dir, Path)
    assert environment.config_dir == httpie.config.DEFAULT_CONFIG_DIR
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == sys.stdin.isatty()
    assert environment.stdin_encoding == None
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == sys.stdout.isat

# Generated at 2022-06-11 23:28:58.580929
# Unit test for constructor of class Environment
def test_Environment():
    # Simulate a file descriptor that was closed
    # (e.g. `http http://httpbin.org < /dev/null`)
    env = Environment(stdin=None)
    assert env.stdin_isatty is False
    env = Environment(stdin=io.StringIO(''))
    assert env.stdin_isatty is False
    assert env.stdin_encoding == 'utf-8'
    env = Environment(stdin=io.StringIO('', encoding='iso-8859-2'))
    assert env.stdin_encoding == 'iso-8859-2'



# Generated at 2022-06-11 23:29:09.293252
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.stderr == sys.stderr
    assert env.stdout == sys.stdout
    assert env.stdin == sys.stdin
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.is_windows == is_windows

# Generated at 2022-06-11 23:29:20.446591
# Unit test for constructor of class Environment
def test_Environment():
    import io
    stdin = io.StringIO('in')
    stdout = io.StringIO()
    stderr = io.StringIO()

    env = Environment(
        config_dir='~/.config',
        config_file='not-existing-file',
        stdin=stdin,
        stdout=stdout,
        stderr=stderr,
        colors=8,
        program_name='some-program'
    )

    assert env.config_dir == Path('~/.config').expanduser()
    assert env.config_file == 'not-existing-file'
    assert env.stdin == stdin
    assert env.stdout == stdout
    assert env.stderr == stderr

    assert env.stderr_isatty
    assert not env.stdout_isat

# Generated at 2022-06-11 23:29:26.062301
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    print(env.stderr_isatty)
    #print(env.config)
    print(env.stdin_isatty)
    print(env.stdin_encoding)
    print(env.stdout_encoding)
    print(env.colors)
    print(env.program_name)
    print(env.stdout_isatty)
    env.log_error('Hello')
    env.devnull = open('/dev/null', 'w')
    print(env.devnull)

# Generated at 2022-06-11 23:29:49.375792
# Unit test for constructor of class Environment
def test_Environment():
    from httpie.config import Config
    import tempfile
    config_directory = tempfile.TemporaryDirectory().name + "/"
    test_env = Environment(config_dir=config_directory)
    test_env._devnull = None
    assert test_env.config_dir == config_directory
    assert test_env._devnull is None
    assert isinstance(test_env.config, Config)
    assert test_env.config.directory == config_directory
    assert test_env.is_windows != is_windows

# Generated at 2022-06-11 23:29:59.162356
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty() if sys.stdin else False
    assert env.stdin_encoding is None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding is None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'

# Generated at 2022-06-11 23:30:09.621971
# Unit test for constructor of class Environment
def test_Environment():
    import io
    import sys
    stdin = io.BytesIO(b'Hello\n')
    stdin.isatty = lambda: True
    env = Environment(stdin=stdin, stdin_encoding='ascii')
    assert env.stdin_encoding == 'ascii'
    assert env.stdout_encoding == sys.stdout.encoding
    if sys.stdout.encoding is None:
        assert env.stdout_encoding == 'utf8'
    else:
        assert env.stdout_encoding == sys.stdout.encoding
    assert env.stderr_encoding == sys.stderr.encoding
    if sys.stderr.encoding is None:
        assert env.stderr_encoding == 'utf8'
    else:
        assert env

# Generated at 2022-06-11 23:30:16.392096
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    print("\nTest Environment():")
    print("\nenv: ",end='');print(env)
    print("\nenv.is_windows: ",end='');print(env.is_windows)
    print("\nenv.config_dir: ",end='');print(env.config_dir)
    print("\nenv.stdin: ",end='');print(env.stdin)
    print("\nenv.stdin_encoding: ",end='');print(env.stdin_encoding)
    print("\nenv.stdout: ",end='');print(env.stdout)
    print("\nenv.stdout_encoding: ",end='');print(env.stdout_encoding)

# Generated at 2022-06-11 23:30:27.017232
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    defaults = dict(env.__dict__)

    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin.readable()
    assert env.stdin_isatty
    assert env.stdin_encoding
    assert env.stdout.writable()
    assert env.stdout_isatty
    assert env.stdout_encoding
    assert env.stderr.writable()
    assert env.stderr_isatty
    assert env.colors
    assert env.program_name == 'http'

    env2 = Environment(config_dir='/my-config')
    assert env2.config_dir == '/my-config'
    assert env2.stdin == defaults['stdin']
    assert env2.stdin_isatty

# Generated at 2022-06-11 23:30:29.814415
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(key_for_test="test_value")
    assert env.key_for_test == "test_value"

# Generated at 2022-06-11 23:30:32.903904
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdout=None)
    assert env.stdout_isatty is False
    assert 'stdout_isatty' in str(env)
    assert 'stdout' not in str(env)



# Generated at 2022-06-11 23:30:35.280659
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert not env.stdin == None
    assert not env.stdout == None
    assert not env.stderr == None


# Generated at 2022-06-11 23:30:38.021155
# Unit test for constructor of class Environment
def test_Environment():
    """
    Check if Setting attributes using constructor works
    """
    env = Environment(stdout = 'hello', stderr = 'hi')
    assert env.stdout == 'hello'
    assert env.stderr == 'hi'

# Generated at 2022-06-11 23:30:45.232775
# Unit test for constructor of class Environment
def test_Environment():
    env=Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == (sys.stdin.isatty() if sys.stdin else False)
    assert env.stdin_encoding == (getattr(sys.stdin, 'encoding', None) or 'utf8')
    assert env.stdout == sys.stdout
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout_encoding == (getattr(sys.stdout, 'encoding', None) or 'utf8')
    assert env.stderr == sys.stderr

# Generated at 2022-06-11 23:31:06.379576
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment()
    assert e.config_dir == DEFAULT_CONFIG_DIR
    assert e.stdin == sys.stdin
    assert e.stdout == sys.stdout
    assert e.stderr == sys.stderr


# Generated at 2022-06-11 23:31:08.497878
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdout_encoding='stdout_encoding')
    assert 'stdout_encoding' in str(env)

# Generated at 2022-06-11 23:31:19.394868
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    # test __init__
    assert env.is_windows is False
    assert env.config_dir == Path('~/.httpie')
    assert env.stdin == sys.stdin
    assert not env.stdin_isatty
    assert env.stdin_encoding is None
    assert env.stdout == sys.stdout
    assert not env.stdout_isatty
    assert env.stdout_encoding is None
    assert env.stderr == sys.stderr
    assert not env.stderr_isatty
    assert env.colors == 256
    assert env.program_name == 'http'
    # test __str__

# Generated at 2022-06-11 23:31:29.000812
# Unit test for constructor of class Environment
def test_Environment():
    import io
    # test for stdin
    stdin = io.StringIO()
    stdin.write('def')
    env = Environment(stdin=stdin)
    assert env.stdin == stdin
    assert env.stdin.getvalue() == 'def'
    assert env.stdin_isatty == False

    # test for stdout
    stdout = io.StringIO()
    env = Environment(stdout=stdout)
    assert env.stdout == stdout
    assert env.stdout_isatty == False

    # test for stderr
    stderr = io.StringIO()
    env = Environment(stderr=stderr)
    assert env.stderr == stderr
    assert env.stderr_isatty == False

    # test for program_name


# Generated at 2022-06-11 23:31:37.347535
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin = sys.stdin ,stdout = sys.stdout ,stderr = sys.stderr ,program_name = 'httpie')
    assert env.stdin == sys.stdin
    assert env.stdin_encoding == sys.stdin.encoding
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout == sys.stdout
    assert env.stdout_encoding == sys.stdout.encoding
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.config_dir == DEFAULT_CONFIG_DIR

# Generated at 2022-06-11 23:31:46.643257
# Unit test for constructor of class Environment
def test_Environment():
    # Syntax: Environment(devnull=None, **kwargs)
    print(Environment())
    print(Environment(
        is_windows=True,
        config_dir=Path(r'C:\ProgramData\httpie'),
        stdin=sys.stdout,
        stdin_isatty=True,
        stdin_encoding='utf8',
        stdout=sys.stdout,
        stdout_isatty=True,
        stdout_encoding='utf8',
        stderr=sys.stderr,
        stderr_isatty=True,
        colors=256,
        program_name='http'
    ))

if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-11 23:31:51.309706
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().stdin == sys.stdin
    assert Environment().stdout == sys.stdout
    assert Environment().stderr == sys.stderr
    assert Environment(devnull='/dev/null').devnull == '/dev/null'
    assert Environment(stdin='stdin').stdin == 'stdin'
    assert Environment(stdout='stdin').stdout == 'stdin'
    assert Environment(stderr='stdin').stderr == 'stdin'

# Generated at 2022-06-11 23:32:00.141915
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        devnull=os.devnull,
        is_windows=True,
        config_dir='./',
        stdin=None,
        stdin_isatty=False,
        stdin_encoding=None,
        stdout=None,
        stdout_isatty=False,
        stdout_encoding=None,
        stderr=None,
        stderr_isatty=False,
        colors=256,
        program_name="http"
    )
    assert os == env.devnull
    assert env.is_windows
    assert './' == env.config_dir
    assert None == env.stdin
    assert not env.stdin_isatty
    assert None == env.stdin_encoding
    assert None == env.stdout

# Generated at 2022-06-11 23:32:03.362183
# Unit test for constructor of class Environment
def test_Environment():
  env = Environment()
  assert type(env) == Environment
  assert type(env.config_dir) == Path
  assert env.config_dir == Path.home().joinpath(".config/httpie")

if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-11 23:32:12.811543
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.stdout_isatty
    assert env.stderr_isatty
    assert env.stdin_isatty
    env = Environment(stdin=open(os.devnull), stdout=open(os.devnull, "w"), stderr=open(os.devnull, "w"))
    assert not env.stdout_isatty
    assert not env.stderr_isatty
    assert not env.stdin_isatty
    env = Environment(stdin=open(os.devnull), stdout=open(os.devnull, "w"), stderr=open(os.devnull, "w"), colors=16)
    assert env.colors == 16
    assert env.config_dir == Path.home() / ".httpie"