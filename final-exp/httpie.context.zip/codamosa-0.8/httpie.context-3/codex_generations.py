

# Generated at 2022-06-11 23:22:47.838747
# Unit test for constructor of class Environment
def test_Environment():
    # Prints python version and installation path
    #print("Output for this version of python:", sys.version)
    #print("Path for this installation:", sys.prefix)
    #print("Configuration directory path:", DEFAULT_CONFIG_DIR)
    assert DEFAULT_CONFIG_DIR == os.path.join(os.path.expanduser("~"), ".config", "httpie")
    #print("Standard input:", sys.stdin)
    #print("Standard input is tty:", sys.stdin.isatty())
    #print("Standard output:", sys.stdout)
    #print("Standard output is tty:", sys.stdout.isatty())
    #print("Standard error:", sys.stderr)
    #print("Standard error is tty:", sys.stderr.isatty

# Generated at 2022-06-11 23:22:53.574200
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows is is_windows
    assert env.config_dir is DEFAULT_CONFIG_DIR
    assert env.stdin is sys.stdin
    assert env.stdin_isatty is sys.stdin.isatty()
    assert env.stdout is sys.stdout
    assert env.stdout_isatty is sys.stdout.isatty()
    assert env.stderr is sys.stderr
    assert env.stderr_isatty is sys.stderr.isatty()

# Generated at 2022-06-11 23:22:58.757009
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment()
    assert hasattr(e, 'is_windows')
    assert hasattr(e, 'config_dir')
    assert hasattr(e, 'stdin')
    assert hasattr(e, 'stdout')
    assert hasattr(e, 'stderr')
    assert hasattr(e, 'program_name')

# Generated at 2022-06-11 23:23:05.606456
# Unit test for constructor of class Environment
def test_Environment():
    ans = Environment()
    class_type = type(ans)
    Class_field = class_type.__dict__
    for i in Class_field:
        if i == 'stderr':
            assert ans.__dict__[i] == sys.stderr
        elif i == 'stdout':
            assert ans.__dict__[i] == sys.stdout
        elif i == 'stdin':
            assert ans.__dict__[i] == sys.stdin
        else:
            assert ans.__dict__[i] == Class_field[i]


# Generated at 2022-06-11 23:23:09.100442
# Unit test for constructor of class Environment
def test_Environment():
    try:
        Environment(devnull=sys.stderr)
        Environment(devnull=sys.stdout)
        
        Environment.stdin =None
        Environment(devnull=sys.stderr)
        Environment(devnull=sys.stdout)
    except Exception:
        assert False

test_Environment()

# Generated at 2022-06-11 23:23:16.644627
# Unit test for constructor of class Environment
def test_Environment():
    # 测试构造器的一些情况
    # 1
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR

    # 2
    from io import StringIO
    stdin = StringIO("123")
    env = Environment(stdin=stdin)
    assert env.stdin == stdin
    assert env.stdin_encoding is None
    assert env.stdin_isatty is False


# Generated at 2022-06-11 23:23:27.088481
# Unit test for constructor of class Environment
def test_Environment():
    ee = Environment()
    assert ee.is_windows == is_windows
    assert ee.config_dir == DEFAULT_CONFIG_DIR
    assert ee.stderr == sys.stderr
    assert ee.stderr_isatty == ee.stderr.isatty()
    assert ee.stderr_encoding is None
    assert ee.stdin == sys.stdin
    assert ee.stdin_isatty == ee.stdin.isatty()
    assert ee.stdin_encoding is None
    assert ee.stdout == sys.stdout
    assert ee.stdout_isatty == ee.stdout.isatty()
    assert ee.stdout_encoding is None

# Generated at 2022-06-11 23:23:32.492923
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stderr='')
    ok_(env.stderr_isatty)

    class MockIO:
        isatty = False

    env = Environment(stderr=MockIO())
    ok_(not env.stderr_isatty)


# Generated at 2022-06-11 23:23:36.597184
# Unit test for constructor of class Environment
def test_Environment():
    class MyEnvironment(Environment):
        """This class is used to test the constructor of class environment"""
        name = 'My Environment'

    e = MyEnvironment(is_windows=True, config_dir=Path('config'), colors=444)
    assert e.is_windows == True
    assert str(e.config_dir) == 'config'
    assert e.colors == 444


# Generated at 2022-06-11 23:23:47.990167
# Unit test for constructor of class Environment
def test_Environment():
    # This file used to be called 'environment', but that's a keyword
    # in Python 3, so it's changed to 'environ'.
    env = Environment(devnull = 'dummy', program_name = 'http')

# Generated at 2022-06-11 23:24:07.449977
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name='http')

# Generated at 2022-06-11 23:24:17.967002
# Unit test for constructor of class Environment
def test_Environment():
    # Given
    config_dir = DEFAULT_CONFIG_DIR
    stdin = sys.stdin
    stdout = sys.stdout
    stderr = sys.stderr
    colors = 256
    program_name = 'http'
    if not is_windows:
        if curses:
            try:
                curses.setupterm()
                colors = curses.tigetnum('colors')
            except curses.error:
                pass
    else:
        # noinspection PyUnresolvedReferences
        import colorama.initialise
        stdout = colorama.initialise.wrap_stream(
            stdout, convert=None, strip=None,
            autoreset=True, wrap=True
        )

# Generated at 2022-06-11 23:24:20.346526
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    env = Environment(stdin_isatty=False)
    assert str(env)



# Generated at 2022-06-11 23:24:31.259273
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin is not None
    assert env.stdout is sys.stdout
    assert env.stderr is sys.stderr
    assert env.stdin_isatty is True
    assert env.stdout_isatty is True
    assert env.stderr_isatty is True
    assert env.stdin_encoding == 'ANSI_X3.4-1968'
    assert env.stdout_encoding == 'ANSI_X3.4-1968'
    assert env.program_name == 'http'
    assert env.colors == 256
    assert env.devnull is None
    assert env.config is not None
    assert env.config_dir == DEFAULT_CONFIG_DIR


################################

# Generated at 2022-06-11 23:24:41.825602
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()

# Generated at 2022-06-11 23:24:51.339277
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull = os.devnull)
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin != None 
    assert env.stdin_isatty 
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty
    assert env.colors == 256
    assert env.program_name == 'http'

# Generated at 2022-06-11 23:24:56.270880
# Unit test for constructor of class Environment
def test_Environment():
    # should create an environment
    env = Environment()
    assert env is not None
    # should create an environment with custom options
    env = Environment(devnull='test')
    assert env is not None

# Generated at 2022-06-11 23:25:02.518203
# Unit test for constructor of class Environment
def test_Environment():
    config_dir = Path("./test_data/test_example_file.json")
    env = Environment(config_dir=config_dir)
    config = env.config
    assert isinstance(config, Config)
    assert config.directory == "./test_data"
    assert config.config_path.name == "test_example_file.json"
    assert config.config_base_path.name == "test_example_file"
    assert config.config_base_path.parent == "./test_data"


if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-11 23:25:11.495917
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        devnull="devnull_file",
        is_windows=True,
        config_dir="non-default_config_dir",
        stdin="stdin_file",
        stdin_isatty=True,
        stdin_encoding="stdin_encoding",
        stdout="stdout_file",
        stdout_isatty=True,
        stdout_encoding="stdout_encoding",
        stderr="stderr_file",
        stderr_isatty=True,
        colors=16,
        program_name="program_name"
    )
    env.log_error("log_error_msg", level="warning")
    print(env)
    env.devnull = "devnull_file2"

# Generated at 2022-06-11 23:25:13.024833
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment()

# Generated at 2022-06-11 23:25:30.364206
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(is_windows=False,
                      config_dir=DEFAULT_CONFIG_DIR,
                      stdin=sys.stdin,
                      stdin_isatty=bool(sys.stdin.isatty()),
                      stdout=sys.stdout,
                      stdout_isatty=bool(sys.stdout.isatty()),
                      stderr=sys.stderr,
                      stderr_isatty=bool(sys.stderr.isatty()))
    assert env.is_windows == False
    assert env.config_dir == Path(DEFAULT_CONFIG_DIR)
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == bool(sys.stdin.isatty())
    assert env.stdout == sys.stdout


# Generated at 2022-06-11 23:25:32.262964
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment()
    e.stdout = ''
    assert e.stdout == ''
    assert e.colors == 256


# Generated at 2022-06-11 23:25:41.803206
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        devnull='devnull',
        config_dir = 'config_dir',
        stdin = 'stdin',
        stdin_isatty = True,
        stdin_encoding = 'stdin_encoding',
        stdout = 'stdout',
        stdout_isatty = False,
        stdout_encoding = 'stdout_encoding',
        stderr = 'stderr',
        stderr_isatty = True,
        colors = 10,
        program_name = 'program_name',
        _config = '_config',
        _orig_stderr = '_orig_stderr',
    )
    env.devnull = 'devnull_new'

    assert env.devnull == 'devnull_new', 'devnull'
    assert env._

# Generated at 2022-06-11 23:25:43.384732
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment(is_windows=1)
    assert Environment(devnull=None)



# Generated at 2022-06-11 23:25:49.221881
# Unit test for constructor of class Environment
def test_Environment():
    import io
    from httpie.core import env
    env.stdin = io.StringIO("hello world!\n")
    env.stdin_isatty()
    env.stdout = io.StringIO("hello world!\n")
    env.stdout_isatty()
    print("Environment created, ", env)

if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-11 23:25:53.512609
# Unit test for constructor of class Environment
def test_Environment():
    temp_variable = sys.stderr
    sys.stderr = open(os.devnull, 'w+')
    try:
        assert Environment(config_dir=Path('/usr/local/bin'))
    finally:
        sys.stderr.close()
        sys.stderr = temp_variable
    

# Generated at 2022-06-11 23:25:54.931093
# Unit test for constructor of class Environment
def test_Environment():
    env=Environment()    
    assert type(env).__dict__
    assert repr(env)
    assert str(env)

# Generated at 2022-06-11 23:26:04.867057
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdin_encoding='utf8', stdin_isatty=True,
                      stdout=sys.stdout, stdout_isatty=True,
                      stdout_encoding=sys.__stdout__.encoding,
                      stderr=sys.stderr, stderr_encoding=sys.__stderr__.encoding,
                      stderr_isatty=sys.stdout.isatty(),
                      config_dir='/home/yh/.httpie',
                      program_name='http')
    assert env.stdin is None
    assert env.stdin_encoding == 'utf8'
    assert env.stdin_isatty
    assert env.stdout is sys.stdout
    assert env.stdout_isatty
    assert env

# Generated at 2022-06-11 23:26:13.359868
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        colors=256,
        config_dir='/usr/local/share/httpie',
        program_name='httpie',
        stderr=sys.stderr,
        stdin=sys.stdin,
        stdout=sys.stdout,
    )

    assert env.colors == 256
    assert env.config_dir == '/usr/local/share/httpie'
    assert env.program_name == 'httpie'
    assert env.stderr == sys.stderr
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout


# Generated at 2022-06-11 23:26:15.902022
# Unit test for constructor of class Environment
def test_Environment():
    environment1 = Environment()
    print(environment1)
    environment2 = Environment(program_name = 'HTTPie')
    print(environment2)

test_Environment()

# Generated at 2022-06-11 23:26:30.154769
# Unit test for constructor of class Environment
def test_Environment():
    if not is_windows:
        if curses:
            assert Environment().colors == curses.tigetnum('colors')
    else:
        from colorama import AnsiToWin32

        assert isinstance(Environment().stdout, AnsiToWin32)
        assert isinstance(Environment().stderr, AnsiToWin32)


environ = Environment()

# Generated at 2022-06-11 23:26:36.546013
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    env1 = Environment(stdin=None, stdin_isatty=None, stdin_encoding=None,
                       stdout=None, stdout_isatty=None, stdout_encoding=None,
                       stderr=None, stderr_isatty=None, colors=None,
                       program_name=None, is_windows=None, config_dir=None,
                       _orig_stderr=None, _devnull=None, _config=None,
                       )

# Generated at 2022-06-11 23:26:40.762471
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        devnull='/dev/null',
        colors=256,
        stdin='stdin',
        program_name='http'
    )
    assert env.devnull == '/dev/null'
    assert env.colors == 256
    assert env.stdin == 'stdin'
    assert env.program_name == 'http'



# Generated at 2022-06-11 23:26:51.279042
# Unit test for constructor of class Environment
def test_Environment():
    parent_dir='/Users/jhoareau/Documents/workspace/tests'
    cmd_line=['http', 'www.google.com']
    env = Environment(parent_dir, program_name='http')

    from httpie.config import Config
    from httpie.context import Environment
    from httpie.compat import is_windows
    import os

    env = Environment()

    devnull = open(os.devnull, 'w+')
    assert devnull == env.devnull

    assert '/Users/jhoareau/Documents/workspace/tests' == env.config_dir
    assert not env.stdin
    assert not env.stdin_isatty
    assert None == env.stdin_encoding
    assert sys.stdout == env.stdout
    assert True == env.stdout_isatty

# Generated at 2022-06-11 23:26:54.680488
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin = 'a', stdout = 'b', stderr = 'c')
    assert env.stdin == 'a'
    assert env.stdout == 'b'
    assert env.stderr == 'c'

# Generated at 2022-06-11 23:27:01.112924
# Unit test for constructor of class Environment
def test_Environment():
    import io
    import tempfile
    with tempfile.TemporaryDirectory() as temp_dir:
        with io.StringIO() as stdout, io.StringIO() as stderr:
            env = Environment(
                config_dir=Path(temp_dir),
                stdout=stdout,
                stderr=stderr
            )
        assert env.config_dir == Path(temp_dir)
        assert env.stdout == stdout
        assert env.stderr == stderr

test_Environment()

# Generated at 2022-06-11 23:27:12.032965
# Unit test for constructor of class Environment
def test_Environment():
    import sys
    env = Environment(stdin=None, stdout=sys.stdout, stderr=sys.stderr)
    # 打印当前程序运行的系统名称
    print(env.is_windows)
    # 打印当前程序运行的系统名称
    print(env.stdin)
    # 打印当前程序运行的系统名称
    print(env.stdin_isatty)
    # 打印当前程序运行的系统名称
    print

# Generated at 2022-06-11 23:27:14.202390
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name='httpie')

# Generated at 2022-06-11 23:27:16.687825
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    r = repr(env)
    assert len(r) > 0

test_Environment()

env = Environment()

# Generated at 2022-06-11 23:27:17.581641
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment()
    print(e)

# Generated at 2022-06-11 23:27:31.898510
# Unit test for constructor of class Environment
def test_Environment():
    import io
    output = io.StringIO()
    env = Environment(
        stdin_isatty=False,
        stdout_isatty=False,
        stderr_isatty=False,
    )
    assert env.stdin_isatty == False
    assert env.stdout_isatty == False
    assert env.stderr_isatty == False


# Generated at 2022-06-11 23:27:35.109552
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(a=1, b=2)
    assert env.a == 1
    assert env.b == 2
    assert 'c' not in env.__dict__

# Generated at 2022-06-11 23:27:44.060082
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.program_name == 'http'
    assert not env.colors
    assert env.config
    assert not env.config.is_new()


# Generated at 2022-06-11 23:27:49.957618
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=open(os.devnull, 'r'))
    assert env.stdin_isatty == False
    assert env.stderr_isatty == True
    assert env.stdout_isatty == True
    assert env.stdin_encoding == 'utf8'
    assert env.stdout_encoding == 'utf8'
    assert env.stdin.buffer == None

# Generated at 2022-06-11 23:27:58.104729
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env == Environment(
        is_windows=env.is_windows,
        config_dir=env.config_dir,
        stdin_isatty=env.stdin_isatty,
        stdin_encoding=env.stdin_encoding,
        stdout_isatty=env.stdout_isatty,
        stdout_encoding=env.stdout_encoding,
        stderr_isatty=env.stderr_isatty,
        colors=env.colors,
        program_name=env.program_name
    )

# Generated at 2022-06-11 23:28:08.790399
# Unit test for constructor of class Environment
def test_Environment():
    environ = Environment()
    assert environ.is_windows == False
    assert environ.config_dir == Path("/Users/eapen/.config/httpie")
    assert environ.stdin.buffer.raw._name == 9
    assert environ.stdin_isatty == True
    assert environ.stdin_encoding == "UTF-8"
    assert environ.stdout.buffer.raw._name == 1
    assert environ.stdout_isatty == True
    assert environ.stdout_encoding == "UTF-8"
    assert environ.stderr.buffer.raw._name == 2
    assert environ.stderr_isatty == True
    assert environ.stderr_encoding == "UTF-8"
    assert environ.colors == 256
    assert en

# Generated at 2022-06-11 23:28:12.662783
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin='s', stdout='o', stderr='e')
    assert env.stdin == 's'
    assert env.stdout == 'o'
    assert env.stderr == 'e'
    assert env.config_dir == DEFAULT_CONFIG_DIR

# Generated at 2022-06-11 23:28:14.587804
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    env.config_dir = DEFAULT_CONFIG_DIR
    assert isinstance(env, Environment)

# Generated at 2022-06-11 23:28:25.601976
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()

    print(f"type(env.config_dir): {type(env.config_dir)}")
    print(f"env.config_dir: {env.config_dir}")
    print(f"type(env.config): {type(env.config)}")
    print(f"env.config: {env.config}")
    print(f"type(env.stdin): {type(env.stdin)}")
    print(f"env.stdin: {env.stdin}")
    print(f"type(env.stdin_isatty): {type(env.stdin_isatty)}")
    print(f"env.stdin_isatty: {env.stdin_isatty}")

# Generated at 2022-06-11 23:28:35.193822
# Unit test for constructor of class Environment
def test_Environment():
    import sys
    import os
    from pathlib import Path
    from typing import IO
    import httpie.config

    e = Environment(devnull=None, is_windows=False, config_dir=Path('/root/.config/httpie'), stdin=sys.stdin,
                    stdin_isatty=False, stdout=sys.stdout, stdout_isatty=True, stderr=sys.stderr,
                    stderr_isatty=True, colors=256, program_name='http')
    
    assert e.is_windows == False
    assert e.config_dir == Path('/root/.config/httpie')
    assert e.stdin == sys.stdin
    assert e.stdin_isatty == False
    assert e.stdout == sys.stdout

# Generated at 2022-06-11 23:28:46.251971
# Unit test for constructor of class Environment
def test_Environment():
    from httpie.core import main
    if __name__ == '__main__':
        main()

# Generated at 2022-06-11 23:28:57.157793
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment()
    assert e.stdin.isatty() == True
    assert e.stdout.isatty() == True
    assert e.stderr.isatty() == True
    assert e.stdout_encoding == 'utf8'
    assert e.stdin_encoding == 'utf8'
    assert e.is_windows == True
    assert e.colors == 256
    assert e.program_name == 'http'
    assert e.config_dir == Path('/Users/moawia/.config/httpie')
    def test_Environment_repr():
        e = Environment()

# Generated at 2022-06-11 23:29:07.725597
# Unit test for constructor of class Environment
def test_Environment():
    en = Environment(
        is_windows=False,
        program_name='http',
        config_dir='/home/user/.httpie',
        stdin=None,
        stdin_isatty=False,
        stdin_encoding='utf8',
        stdout=sys.stdout,
        stdout_isatty=sys.stdout.isatty(),
        stdout_encoding='utf8',
        stderr=sys.stderr,
        stderr_isatty=sys.stderr.isatty(),
        colors=128,
        devnull='devnull'
    )
    assert en.is_windows == False
    assert en.program_name == 'http'
    assert en.config_dir == Path('/home/user/.httpie')
    assert en.std

# Generated at 2022-06-11 23:29:18.969453
# Unit test for constructor of class Environment
def test_Environment():
    try:
        sys.stdin.read()
        sys.stdin.isatty()
    except ValueError:
        sys.stdin = None

    env_kwargs = {
        'config_dir': Path(__file__).parent,
        'stdin': sys.stdin,
        'stdin_isatty': sys.stdin and sys.stdin.isatty(),
        'stdout': sys.stdout,
        'stdout_isatty': sys.stdout.isatty(),
        'stderr': sys.stdout,
        'stderr_isatty': sys.stderr.isatty(),
        'program_name': 'http',
        'colors': 256,
    }
    env = Environment(**env_kwargs)
    assert env.config_dir

# Generated at 2022-06-11 23:29:24.299554
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin = sys.stdin, stdout = sys.stdout, stderr = sys.stderr)

    assert env.is_windows == is_windows
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert env.progream_name == 'http'



if __name__ == "__main__":
    test_Environment()

# Generated at 2022-06-11 23:29:25.393743
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment(colors = 256)
    assert e.colors == 256

# Generated at 2022-06-11 23:29:26.735180
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    print(env)

#test_Environment()

# Generated at 2022-06-11 23:29:28.367560
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(devnull = "devnull")
    assert environment.devnull == "devnull"


# Generated at 2022-06-11 23:29:37.836556
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        devnull = 'devnull',
        is_windows = False,
        config_dir = "123",
        stdin = 1,
        stdout = 2,
        stderr = 3,
        colors = 4,
        program_name = "abc"
    )
    env.log_error("abc", level="warning")
    print(env._orig_stderr.write("abc"))
    print(env.stdin)
    print(env.stdout)
    print(env.stderr)
    print(env.config)
    print(env.devnull)
    print(env)
    print(env.__dict__)

env = Environment()

# Generated at 2022-06-11 23:29:40.866991
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin_encoding = 'ascii')
    assert not env.stdin_isatty
    assert env.stdin_encoding == 'ascii'
    assert env.stdout_isatty
    assert env.stdout_encoding == 'utf8'

# Generated at 2022-06-11 23:30:06.225289
# Unit test for constructor of class Environment
def test_Environment():
    import httpie
    from httpie.compat import is_windows
    from httpie.config import Config, ConfigFileError
    from httpie import ExitStatus
    from httpie.utils import repr_dict
    from httpie import __version__

    # Test the constructor of class Environment
    environment = Environment()
    assert environment.is_windows == is_windows
    assert str(environment.config_dir).endswith('.httpie')
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == sys.stdin.isatty()
    assert env

# Generated at 2022-06-11 23:30:14.787171
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows is False
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert isinstance(environment.stdin, IO)
    assert environment.stdin_isatty is True
    assert isinstance(environment.stdout, IO)
    assert environment.stdout_isatty is True
    assert isinstance(environment.stderr, IO)
    assert environment.stderr_isatty is True
    assert environment.colors == 256
    assert environment.program_name == 'http'
    assert str(environment) == "{'colors': 256, 'config': None, 'is_windows': False, 'program_name': 'http', 'stderr_isatty': True, 'stdin_isatty': True, 'stdout_isatty': True}"


# Generated at 2022-06-11 23:30:25.441426
# Unit test for constructor of class Environment
def test_Environment():
    # Initialize variables
    devnull = None
    stdin = None
    stdout = sys.stdout
    stderr = sys.stderr
    stdin_encoding = None
    stdout_encoding = None
    stderr_encoding = None
    stdin_isatty = True
    stdout_isatty = True
    stderr_isatty = True
    is_windows = False
    config_dir = DEFAULT_CONFIG_DIR
    program_name = "http"
    colors = 256
    # Create a new Environment object

# Generated at 2022-06-11 23:30:30.608690
# Unit test for constructor of class Environment
def test_Environment():
    assert isinstance(Environment(), Environment)
    assert isinstance(Environment(
        stdin_isatty=False,
        stdout_isatty=False,
        stderr_isatty=False
    ), Environment)
    assert isinstance(Environment(
        config_dir=None
    ), Environment)

# Generated at 2022-06-11 23:30:39.299080
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        stdin = 1,
        stdin_isatty = False,
        stdin_encoding = "utf8",
        stdout = 2,
        stdout_isatty = False,
        stdout_encoding = "utf8",
        stderr = 3,
        stderr_isatty = False,
        colors = 256,
        is_windows = False,
        config_dir = "/home/vitharme/.config/httpie/config.json",
        program_name = "http",
        devnull = "devnull"
    )
    assert env.stdin == 1
    assert env.stdin_isatty == False
    assert env.stdin_encoding == "utf8"
    assert env.stdout == 2
    assert env.stdout_isat

# Generated at 2022-06-11 23:30:46.051742
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    class TestEnv(Environment):
        @property
        def config(self):
            return self._config
        _config=None
    test = TestEnv()
    assert test.config_dir == DEFAULT_CONFIG_DIR
    assert test.stdin == sys.stdin
    assert test.stderr == sys.stderr
    assert test.stdout == sys.stdout
    assert test.config_dir == DEFAULT_CONFIG_DIR
    assert test.stdin_isatty == sys.stdin.isatty()
    assert test.stderr_isatty == sys.stderr.isatty()
    assert test.stdout_isatty == sys.stdout.isatty()
    assert test.colors == 256

# Generated at 2022-06-11 23:30:47.456783
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=True)
    assert env.devnull == True

# Generated at 2022-06-11 23:30:56.498679
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        is_windows=False,
        config_dir='~/.config',
        stdin=sys.stdin,
        stdin_isatty=sys.stdin.isatty(),
        stdin_encoding=None,
        stdout=sys.stdout,
        stdout_isatty=sys.stdout.isatty(),
        stdout_encoding=None,
        stderr=sys.stderr,
        stderr_isatty=sys.stderr.isatty(),
        colors=256,
        program_name='http'
    )
    assert env.is_windows == False
    assert env.config_dir == Path('~/.config')
    assert env.stdin == sys.stdin

# Generated at 2022-06-11 23:31:05.537367
# Unit test for constructor of class Environment
def test_Environment():
    """Unit test for constructor of class Environment
    """
    # Normal case
    env = Environment(stdin=sys.stdin, stdin_isatty=sys.stdin.isatty(), stdin_encoding=sys.stdin.encoding)
    assert env.__dict__['stdin'] == sys.stdin and env.__dict__['stdin_isatty'] == sys.stdin.isatty() \
           and env.__dict__['stdin_encoding'] == sys.stdin.encoding
    print('test case 1, [Environment] constructor test pass')
    # Exception case
    try:
        env = Environment(a=3)
    except:
        print('test case 2, [Environment] constructor test pass')
    else:
        raise Exception('test case 2, [Environment] constructor test fail')

# Generated at 2022-06-11 23:31:16.406262
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull='null')
    assert env.devnull == 'null'
    assert env.is_windows == False
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == True
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stdout_encoding == 'utf8'
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == True
    assert env.program_name == 'http'
    assert env.colors == 256
    assert env.config == Config(directory=DEFAULT_CONFIG_DIR)
    assert env

# Generated at 2022-06-11 23:32:07.057700
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdout=sys.stdout, stderr=sys.stderr)
    assert env.stdin_isatty == False, "stdin should be false"
    assert env.stdin_encoding == None, "stdin encoding is None"
    assert env.stdout_isatty == True, "stdout should be True"
    assert env.stdout_encoding == "utf-8", "stdout encoding should be utf-8"
    assert env.stderr_isatty == True, "stderr should be True"
    assert env.stderr == sys.stderr, "sys.stderr is used"
    assert env.stderr is sys.stderr, "sys.stderr is used"
    assert env.stderr_encoding

# Generated at 2022-06-11 23:32:14.627787
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None,
                      is_windows="is_windows",
                      config_dir="config_dir",
                      stdin="stdin",
                      stdout="stdout",
                      stderr="stderr",
                      colors="colors",
                      program_name="program_name",
                      _orig_stderr="_orig_stderr",
                      _devnull="_devnull")

    assert env.is_windows ==  "is_windows"
    assert env.config_dir == "config_dir"
    assert env.stdin == "stdin"
    assert env.stdout == "stdout"
    assert env.stderr == "stderr"
    assert env.colors == "colors"
    assert env.program_name == "program_name"
    assert env._orig_

# Generated at 2022-06-11 23:32:19.744150
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows == is_windows
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin == sys.stdin
    assert environment.stdout == sys.stdout
    assert environment.stderr == sys.stderr
    assert environment.program_name == "http"

# Generated at 2022-06-11 23:32:21.238157
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(is_windows=True, program_name='http')
    print(env)

# Generated at 2022-06-11 23:32:25.681451
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdout=None, stderr=None, devnull=None, program_name='httpie')
    assert env.stdin is None
    assert env.stdout is None
    assert env.stderr is None
    assert env.program_name == 'httpie'
    assert env.devnull is None

# Generated at 2022-06-11 23:32:31.313193
# Unit test for constructor of class Environment
def test_Environment():
    environ = Environment()
    assert hasattr(environ, 'is_windows') == True
    assert hasattr(environ, 'config_dir') == True
    assert hasattr(environ, 'stdin') == True
    assert hasattr(environ, 'stdout') == True
    assert hasattr(environ, 'stderr') == True
    assert hasattr(environ, '_orig_stderr') == True
    assert hasattr(environ, 'colors') == True
    assert hasattr(environ, 'program_name') == True