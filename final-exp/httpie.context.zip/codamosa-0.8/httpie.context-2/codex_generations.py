

# Generated at 2022-06-11 23:22:49.108950
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    # | GIVEN |
    assert environment.is_windows == False
    assert environment.config_dir == Path.home().joinpath(".config/httpie")
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == False
    assert environment.stdin_encoding == None
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == True
    assert environment.stdout_encoding == None
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == True
    assert environment.colors == 16
    assert environment.program_name == "http"

# Generated at 2022-06-11 23:22:50.242265
# Unit test for constructor of class Environment
def test_Environment():
    assert 'stdin_encoding' in str(Environment())


# Generated at 2022-06-11 23:22:52.167211
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr)
    print(env)


# Generated at 2022-06-11 23:23:01.996517
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment()
    assert e.stdin_isatty
    assert e.stdout_isatty
    assert e.stderr_isatty
    assert e.stdin_encoding
    assert e.stdout_encoding
    e = Environment(is_windows=True)
    assert e.is_windows
    e = Environment(stdin_isatty=True, stdout_isatty=True, stderr_isatty=True,
                    stdin_encoding='utf-8', stdout_encoding='utf-8', config_dir=None)
    assert e.stdin_isatty
    assert e.stdout_isatty
    assert e.stderr_isatty
    assert e.stdin_encoding
    assert e.stdout_encoding
    assert e

# Generated at 2022-06-11 23:23:04.400041
# Unit test for constructor of class Environment
def test_Environment():
    # pylint: disable=W0212
    assert Environment().__dict__ == Environment.__dict__
    assert Environment(colors=0).colors == 0

# Generated at 2022-06-11 23:23:14.684859
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert str(env) == '{config: <Config default>, colors: 256, is_windows: False, program_name: \'http\', stderr: <_io.TextIOWrapper name=\'<stderr>\' encoding=\'UTF-8\'>, stderr_encoding: None, stderr_isatty: True, stdin: <_io.TextIOWrapper name=\'<stdin>\' encoding=\'UTF-8\'>, stdin_encoding: \'cp936\', stdin_isatty: True, stdout: <_io.TextIOWrapper name=\'<stdout>\' encoding=\'UTF-8\'>, stdout_encoding: \'cp936\', stdout_isatty: True}'
    # Unit test for config property
    assert env

# Generated at 2022-06-11 23:23:15.876459
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env
    pass

# Generated at 2022-06-11 23:23:26.299634
# Unit test for constructor of class Environment
def test_Environment():
    import sys

    env = Environment()
    #env.__init__()

    # httpie.config.DEFAULT_CONFIG_DIR
    print(env.config_dir) # C:\Users\Administrator\.config\httpie

    # sys.stdin
    print(env.stdin) # <_io.TextIOWrapper name='<stdin>' mode='r' encoding='cp936'>

    # sys.stdin.isatty()
    print(env.stdin_isatty) # False

    import locale
    env.stdin_encoding = locale.getpreferredencoding()
    print(env.stdin_encoding) # cp936

    # sys.stdout
    print(env.stdout) # <_io.TextIOWrapper name='<stdout>' mode='w

# Generated at 2022-06-11 23:23:30.944819
# Unit test for constructor of class Environment
def test_Environment():
    stdin = stdout = stderr = None
    env = Environment(stdin, stdout, stderr)
    assert env.stdin is stdin
    assert env.stdout is stdout
    assert env.stderr is stderr

# Generated at 2022-06-11 23:23:33.496736
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.stdout_encoding == 'utf8'
    assert env.stdin_encoding == 'utf8'


# Generated at 2022-06-11 23:23:44.991250
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment(program_name='http', config_dir='~/dir')
    print(e)

# Generated at 2022-06-11 23:23:50.591021
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    # Standard streams
    assert env.stdin is sys.stdin
    assert env.stdout is sys.stdout
    assert env.stderr is sys.stderr
    # Attributes
    assert env.is_windows is is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin_isatty is True
    assert env.stdout_isatty is True
    assert env.stderr_isatty is True
    assert env.program_name == 'http'



# Generated at 2022-06-11 23:23:56.719575
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        is_windows=True,
        config_dir='/some/directory',
        stderr=sys.stderr,
        stdout_encoding='utf-8',
    )
    assert env.config_dir == Path('/some/directory')
    assert env.stderr == sys.stderr
    assert env.stdout_encoding == 'utf-8'

# Generated at 2022-06-11 23:24:07.659597
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert isinstance(env.config_dir, Path)
    assert env.stdin == sys.stdin
    assert env.stdin_isatty
    assert env.stdin_encoding and isinstance(env.stdin_encoding, str)
    assert env.stdout == sys.stdout
    assert env.stdout_isatty
    assert env.stdout_encoding and isinstance(env.stdout_encoding, str)
    assert env.stderr == sys.stderr
    assert env.stderr_isatty
    assert env.colors == 256
    assert env.program_name == 'http'

    assert isinstance(env.devnull, IO)
    assert env._orig_stderr == sys.st

# Generated at 2022-06-11 23:24:13.868291
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == True
    assert env.config_dir == Path('.httpie')
    assert env.stdin == sys.stdin
    assert env.stdout_isatty == True
    assert env.stderr_isatty == False
    assert env.colors == 256
    assert env.program_name == 'http'

# Generated at 2022-06-11 23:24:16.110241
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert isinstance(env, Environment)
    assert env.config_dir == '.httpie'
    assert isinstance(env.config, Config)

# Generated at 2022-06-11 23:24:19.235241
# Unit test for constructor of class Environment
def test_Environment():
    print("Unit test for constructor of class Environment")
    env = Environment()
    print(type(env))
    print(env)
    # env.config_dir = "/Users/mike/.httpie"
    print(env.config_dir)
    print(env.config)
    print(env.devnull)

# Generated at 2022-06-11 23:24:30.519728
# Unit test for constructor of class Environment
def test_Environment():
    import io
    import os.path
    import tempfile
    env = Environment()
    if 'httpie' in sys.modules:
        assert env.program_name == 'http'
    else:
        assert env.program_name == 'https'
    assert env.stdin_encoding == 'utf8'
    assert env.stdout_encoding == 'utf8'
    assert env.config == Config(directory=Path(os.path.expanduser('~/.config/httpie')))
    assert env.devnull is None
    assert env._devnull is None

    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        env.config_dir = temp_path
        assert env.config_dir == temp_path
        assert env.config.directory == temp_path

# Generated at 2022-06-11 23:24:37.900170
# Unit test for constructor of class Environment
def test_Environment():
    """
    This is a unit test for the class Environment.
    """
    env = Environment()
    print(env.stdin_isatty)
    print(env.stdout_isatty)
    print(env.stderr_isatty)
    print(env.stdin)
    print(env.stdout)
    print(env.stderr)
    print(env.stdin_encoding)
    print(env.stdout_encoding)
    print(env.config_dir)
    print(env.is_windows)
    print(env.colors)

# Generated at 2022-06-11 23:24:42.409464
# Unit test for constructor of class Environment
def test_Environment():
    """
    >>> class Ut(Environment): pass
    >>> e = Ut(stderr='')
    >>> e.stderr
    ''

    """

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 23:25:04.750730
# Unit test for constructor of class Environment
def test_Environment():
    # environment should be a instance of class Environment
    environment = Environment()
    assert isinstance(environment, Environment)
    # environment should have 21 attributes
    assert len(environment.__dict__.keys()) == 21
    # environment.stdin should be sys.stdin
    assert environment.stdin == sys.stdin
    # environment.stdin_isatty should be same as sys.stdin.isatty
    assert environment.stdin_isatty == sys.stdin.isatty()
    # environment.stdout should be sys.stdout
    assert environment.stdout == sys.stdout
    # environment.stdout_isatty should be same as sys.stdout.isatty
    assert environment.stdout_isatty == sys.stdout.isatty()
    # environment.stderr should be sys.

# Generated at 2022-06-11 23:25:13.098658
# Unit test for constructor of class Environment
def test_Environment():
    assert str(Environment()) == str(Environment(int=3))
    assert str(Environment()) != str(Environment(int=3, str='test'))
    assert Environment().int != 3 and Environment().str != 'test'
    assert Environment().int == None and Environment().str == None

    assert Environment(int=5).int == 5 and Environment(int=1).int == 1
    assert Environment(str='test').str == 'test' and Environment(str='string').str == 'string'

    env = Environment(int=5, str='test')
    assert env.int == 5 and env.str == 'test'

    assert Environment().is_windows == False
    assert Environment().config_dir == '.httpie'
    assert Environment().stdin != None and Environment().stdin == sys.stdin and Environment().stdin_isatty == sys.std

# Generated at 2022-06-11 23:25:15.108378
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.stdout_isatty is True
    assert env.colors == 256

# Generated at 2022-06-11 23:25:18.265284
# Unit test for constructor of class Environment
def test_Environment():
    import tempfile
    devnull = tempfile.TemporaryFile()
    env = Environment(devnull=devnull)
    assert env.devnull.fileno()

env = Environment()

# Generated at 2022-06-11 23:25:27.430051
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.config_dir == Path(DEFAULT_CONFIG_DIR)
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == "http"
    assert env.is_windows == is_windows

# Generated at 2022-06-11 23:25:35.283894
# Unit test for constructor of class Environment
def test_Environment():
    import os
    import pathlib

    env = Environment(
        is_windows=True,
        config_dir=pathlib.Path('/abc/def'),
        stdin=open('/tmp/stdin', 'r'),
        stdout=open('/tmp/stdout', 'r'),
        stderr=open('/tmp/stderr', 'r'),
    )
    assert env.is_windows == True
    assert env.config_dir == pathlib.Path('/abc/def')
    assert env.stdin == open('/tmp/stdin', 'r')
    assert env.stdout == open('/tmp/stdout', 'r')
    assert env.stderr == open('/tmp/stderr', 'r')

# Generated at 2022-06-11 23:25:45.488925
# Unit test for constructor of class Environment
def test_Environment():

    # Note: __init__ is defined
    print('Unit test for Environment')
    assert hasattr(Environment, '__init__')

    # Note: stdin, stdout, stderr assigned
    environment = Environment()
    assert environment.stdin == sys.stdin
    assert environment.stdout == sys.stdout
    assert environment.stderr == sys.stderr

    # Note: stdin_isatty and stdout_isatty correct
    environment = Environment()
    assert environment.stdin_isatty == sys.stdin.isatty()
    assert environment.stdout_isatty == sys.stdout.isatty()
    assert environment.stderr_isatty == sys.stderr.isatty()

    # Note: colors assigned
    environment = Environment()

# Generated at 2022-06-11 23:25:54.801287
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty() if sys.stdin else False
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'

# Generated at 2022-06-11 23:25:55.986534
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull='xx')
    assert env.devnull == 'xx'

# Generated at 2022-06-11 23:26:02.024000
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    stdin = sys.stdin
    stdout = sys.stdout
    stderr = sys.stderr
    env = Environment(is_windows = False, stdin = sys.stdin, stdout = sys.stdout, stderr = sys.stderr)
    assert env.is_windows == False
    assert env.stdin == stdin
    assert env.stdout == stdout
    assert env.stderr == stderr

# Generated at 2022-06-11 23:26:13.458141
# Unit test for constructor of class Environment
def test_Environment():
    if __name__ == '__main__':
        import doctest
        doctest.testmod()

# Generated at 2022-06-11 23:26:21.882147
# Unit test for constructor of class Environment

# Generated at 2022-06-11 23:26:28.373422
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    # test attributes: is_windows, config_dir, stdin,
    # stdout, stderr, program_name and colors.
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert env.program_name == 'http'
    assert env.colors == 256


# Generated at 2022-06-11 23:26:32.129690
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name='http')
    print(env.program_name)
    print(env.config_dir)
    assert env.program_name=='http'
    assert env.config_dir==DEFAULT_CONFIG_DIR

# Generated at 2022-06-11 23:26:33.438124
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env



# Generated at 2022-06-11 23:26:40.763198
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.program_name == 'http'
    assert env.devnull is None

# Generated at 2022-06-11 23:26:51.326671
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows is is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin is sys.stdin
    assert env.stdin_isatty is False
    assert env.stdout is sys.stdout
    assert env.stdout_isatty is True
    assert env.stderr is sys.stderr
    assert env.stderr_isatty is True
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env.devnull is None


# Generated at 2022-06-11 23:26:59.172685
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert isinstance(env.is_windows, bool)
    assert isinstance(env.config_dir, Path)
    assert isinstance(env.stdin, IO)
    assert isinstance(env.stdin_isatty, bool)
    assert isinstance(env.stdin_encoding, str)
    assert isinstance(env.stdout, IO)
    assert isinstance(env.stdout_isatty, bool)
    assert isinstance(env.stdout_encoding, str)
    assert isinstance(env.stderr, IO)
    assert isinstance(env.stderr_isatty, bool)
    assert isinstance(env.colors, int)
    assert isinstance(env.program_name, str)

# Generated at 2022-06-11 23:27:00.459032
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    repr(env)
    

# Generated at 2022-06-11 23:27:10.038326
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert is_windows == env.is_windows
    assert DEFAULT_CONFIG_DIR == env.config_dir
    assert sys.stdin == env.stdin
    assert env.stdin_isatty
    assert None == env.stdin_encoding
    assert sys.stdout == env.stdout
    assert env.stdout_isatty
    assert None == env.stdout_encoding
    assert sys.stderr == env.stderr
    assert env.stderr_isatty
    assert 'http' == env.program_name
    assert 256 == env.colors
    assert type(env.config) is Config

# Generated at 2022-06-11 23:27:38.561109
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=1, is_windows=True,
                      stdin=None, stdin_isatty=False, stdin_encoding='utf8',
                      stdout=sys.stdout, stdout_isatty=False, stdout_encoding='utf8',
                      stderr=sys.stderr, stderr_isatty=False,
                      colors=256, program_name='http')
    assert repr(env) == '<Environment {' \
                        '"config_dir": "~/.config/httpie", ' \
                        '"colors": 256, ' \
                        '"is_windows": True, ' \
                        '"program_name": "http", ' \
                        '"stderr": <stream>, ' \
                        '"stderr_isatty": False, '

# Generated at 2022-06-11 23:27:40.431229
# Unit test for constructor of class Environment
def test_Environment():
    print(Environment().__dict__)
    print(Environment(devnull=None, x=1, y=2).__dict__)



# Generated at 2022-06-11 23:27:50.314432
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().stdout_encoding == 'utf8'
    assert Environment(stdout_encoding='utf16').stdout_encoding == 'utf16'
    assert Environment(stdout_encoding=None).stdout_encoding == 'utf8'
    assert Environment(stdin_encoding='ascii').stdin_encoding == 'ascii'
    assert Environment().stdin == sys.stdin
    with open('/tmp/blah', 'w') as f:
        assert Environment(stdin=f).stdin == f
    assert Environment().config_dir == DEFAULT_CONFIG_DIR
    assert Environment(config_dir='/tmp').config_dir == Path('/tmp')
    assert Environment(colors=256).colors == 256
    assert Environment(program_name='http').program_name == 'http'

# Generated at 2022-06-11 23:27:53.744702
# Unit test for constructor of class Environment
def test_Environment():
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdir:
        assert isinstance(Environment(config_dir=tmpdir), Environment)

if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-11 23:28:00.032592
# Unit test for constructor of class Environment
def test_Environment():
    import io
    import os
    test_stream = io.StringIO()
    class TestEnv(Environment):
        stdout = test_stream
        stdout_isatty = True
    env = TestEnv(program_name='program_name')
    assert env.stdout == test_stream
    assert env.stdout_isatty == True
    assert env.program_name == 'program_name'
    assert env.devnull is not None
    os.remove(env.devnull.name)

# Generated at 2022-06-11 23:28:05.449216
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=True, config_dir='dir', stdin='in',
                      stdout='out', stderr='err')

    assert env.is_windows is True
    assert env.config_dir is 'dir'
    assert env.stdin is 'in'
    assert env.stdout is 'out'
    assert env.stderr is 'err'

# Generated at 2022-06-11 23:28:08.653646
# Unit test for constructor of class Environment
def test_Environment():
    print(Environment(devnull=os.devnull, is_windows=True, stdin_isatty=True))

if __name__ == "__main__":
    test_Environment()

# Generated at 2022-06-11 23:28:18.368688
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().is_windows is True
    assert Environment().config_dir == DEFAULT_CONFIG_DIR
    assert Environment().stdin == sys.stdin
    assert Environment().stdout == sys.stdout
    assert Environment().stderr == sys.stderr
    assert Environment().program_name == 'http'
    assert Environment().colors == 256
    assert Environment(is_windows=False).is_windows is False
    assert Environment(config_dir='/home/user/.config/httpie/config/dir').config_dir == '/home/user/.config/httpie/config/dir'
    assert Environment(stdin=sys.stderr).stdin == sys.stderr
    assert Environment(stdout=sys.stdin).stdout == sys.stdin
    assert Environment(stderr=sys.stdin).stder

# Generated at 2022-06-11 23:28:24.701303
# Unit test for constructor of class Environment
def test_Environment():
    stdin = sys.stdin
    stdout = sys.stdout
    stderr = sys.stderr
    env = Environment(stdin = stdin, stdout = stdout, stderr = stderr)
    assert env.stdin is stdin
    assert env.stdout is stdout
    assert env.stderr is stderr


# Generated at 2022-06-11 23:28:34.118118
# Unit test for constructor of class Environment
def test_Environment():
    import sys
    env = Environment(**dict(
        devnull=None,
        is_windows = is_windows,
        config_dir = DEFAULT_CONFIG_DIR,
        stdin = sys.stdin,
        stdin_isatty = stdin.isatty() if stdin else False,
        stdin_encoding = None,
        stdout = sys.stdout,
        stdout_isatty = stdout.isatty(),
        stdout_encoding = None,
        stderr = sys.stderr,
        stderr_isatty = stderr.isatty(),
        colors = 256,
        program_name = 'http',
    ))

# Generated at 2022-06-11 23:28:52.908448
# Unit test for constructor of class Environment
def test_Environment():
    env=Environment()
    assert env.is_windows==False
    assert env.config_dir==Path(DEFAULT_CONFIG_DIR)

# Generated at 2022-06-11 23:28:58.140694
# Unit test for constructor of class Environment
def test_Environment():
    #https://github.com/jakubroztocil/httpie-pytest-plugin/blob/master/httpie_pytest/environment.py#L46
    env = Environment()
    assert env.stdin is sys.stdin
    assert env.stdout is sys.stdout
    assert env.stderr is sys.stderr
    assert env.program_name == 'http'

# Generated at 2022-06-11 23:29:05.164096
# Unit test for constructor of class Environment
def test_Environment():
    conf_dir = Path('conf_dir')
    stdin = sys.stdin
    stdout = sys.stdout
    stderr = sys.stderr
    environment = Environment(
        config_dir=conf_dir,
        stdin=stdin,
        stdout=stdout,
        stderr=stderr
    )
    assert environment.config_dir == conf_dir
    assert environment.stdin == stdin
    assert environment.stdout == stdout
    assert environment.stderr == stderr

# Generated at 2022-06-11 23:29:14.923316
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(config_dir='./test/test_env.py', stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr)
    assert env.config_dir == './test/test_env.py'
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert env.stdin_encoding == 'utf8'
    assert env.stdout_encoding == 'utf8'
    assert env.stderr_encoding == 'utf8'
    assert env.is_windows == False
    assert env.colors == 256

# Generated at 2022-06-11 23:29:23.181184
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=open("/dev/null", "r"), stdin_isatty=False, 
                    stdout=open("/dev/null", "r"), stdout_isatty=False,
                    stderr=open("/dev/null", "r"), stderr_isatty=False,
                    stdin_encoding="utf8", stdout_encoding=None,
                    stderr_encoding=None, is_windows=False, config_dir=DEFAULT_CONFIG_DIR,
                    colors=256, program_name="http", devnull=None)


# Test the property @devnull of class Environment

# Generated at 2022-06-11 23:29:27.587329
# Unit test for constructor of class Environment
def test_Environment():
    testEnv = Environment(stdin=None)
    assert testEnv.stdin == None
    assert testEnv.stdin_encoding == None
    assert testEnv.stdout == sys.stdout
    assert testEnv.stdout_encoding == 'utf8'
    assert testEnv.stderr == sys.stderr
    assert testEnv.stderr_encoding == None
    assert testEnv.colors == 256

# Generated at 2022-06-11 23:29:37.454468
# Unit test for constructor of class Environment
def test_Environment():
    print("Start")
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding is None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding is None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    print("End")



# Generated at 2022-06-11 23:29:40.545053
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.config_dir
    assert env.stdin
    assert env.stdout
    assert env.stderr
    assert env.stderr_isatty
    assert env.stdout_isatty
    assert env.stdin_isatty

# Generated at 2022-06-11 23:29:49.786301
# Unit test for constructor of class Environment
def test_Environment():
    from httpie.client import Environment
    env = Environment(stdout_isatty=False, stdin_isatty=False)
    assert not env.stdout_isatty
    assert not env.stdin_isatty



"""
Configuration file.

The config file is JSON formatted. This allows us to support features
that would be difficult to implement in INI format.

The configuration file is optional. If none is found, the configuration
is taken from the defaults.

"""
import json
import os
from pathlib import Path
import sys
from typing import Any, Dict, Optional, Union

from httpie import __version__
from httpie.compat import is_windows
from httpie.config import DEFAULT_CONFIG_DIR, DEFAULTS


# Generated at 2022-06-11 23:29:59.523072
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.colors == 256
    assert env.is_windows == is_windows
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == stdin.isatty() if stdin else False
    assert env.stdin_encoding==getattr(env.stdin, 'encoding', None) or 'utf8'
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding==getattr(sys.stdout, 'encoding', None) or 'utf8'
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.program_name == 'http'

# Generated at 2022-06-11 23:30:22.000070
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(colors=8)
    assert env.colors == 8
    assert env.program_name == 'http'
    assert env.is_windows
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stdout_isatty
    assert env.stderr == sys.stderr
    assert env.stderr_isatty


# Generated at 2022-06-11 23:30:30.985047
# Unit test for constructor of class Environment
def test_Environment():
    # Test case: Missing standard input
    sys.stdin = None
    env = Environment()
    assert not env.stdin
    assert env.stdin_isatty == False
    assert env.stdin_encoding is None
    sys.stdin = sys.__stdin__

    # Test case: Missing standard output
    sys.stdout = None
    env = Environment()
    assert not env.stdout
    assert env.stdout_isatty == False
    assert env.stdout_encoding is None
    sys.stdout = sys.__stdout__

    # Test case: Missing standard error
    sys.stderr = None
    env = Environment()
    assert not env.stderr
    assert env.stderr_isatty == False
    assert env.stderr_encoding is None
   

# Generated at 2022-06-11 23:30:34.702256
# Unit test for constructor of class Environment
def test_Environment():
    import sys
    env = Environment(program_name='httpie', stdout=sys.stdout, stderr=sys.stderr, stdin=sys.stdin)
    print(env)

if __name__ == '__main__':
    print('testing Environment')
    test_Environment()

# Generated at 2022-06-11 23:30:37.002254
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        program_name = 'httpie',
        stdout_encoding = 'utf-8',
        stdin_isatty = True,
        config_dir = '/home/lun/.config/httpie'
    )
    print(env)

# Generated at 2022-06-11 23:30:38.488529
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    print('env.__dict__:', env.__dict__)


# Generated at 2022-06-11 23:30:43.755063
# Unit test for constructor of class Environment
def test_Environment():
    from httpie.config import DEFAULT_CONFIG_DIR
    if os.name=='nt':
        import colorama.initialise
        colorama.initialise.init()

    e = Environment(devnull='123')
    assert e.devnull == '123'
    assert e.config_dir == DEFAULT_CONFIG_DIR
    assert e.stdin == sys.stdin
    assert e.stdout == sys.stdout
    assert e.stderr == sys.stderr
    assert e.is_windows == is_windows

# Generated at 2022-06-11 23:30:53.304089
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        devnull=None,
        is_windows=True,
        colors=256,
        config_dir=DEFAULT_CONFIG_DIR,
        program_name='http',
        stdin=None,
        stderr=sys.__stderr__,
        stdout=sys.__stdout__,
        stderr_isatty=True,
    )
    env.stdout_encoding = None
    env.stdin_isatty = False
    env.stdin_encoding = None
    env.stderr = sys.__stderr__
    env.stdout_isatty = True
    env.program_name = 'http'
    env.colors = 256
    env.is_windows = True
    env.config_dir = DEFAULT_CONFIG_

# Generated at 2022-06-11 23:31:02.426837
# Unit test for constructor of class Environment
def test_Environment():
    def stdout_write_test(test, stdout):
        stdout.write(test.encode())
        stdout.flush()
        return

    def stdout_writelines_test(test, stdout):
        stdout.writelines([test.encode()])
        stdout.flush()
        return

    def stdout_encoding_test(test, stdout):
        stdout.encoding = test.encode()
        stdout.flush()
        return

    new_writelines = stdout_writelines_test
    new_write = stdout_write_test
    new_encoding = stdout_encoding_test

    e = Environment()
    # is_windows
    assert e.is_windows == is_windows
    # config_dir
    assert e.config_dir == DEFAULT_CONFIG

# Generated at 2022-06-11 23:31:12.230679
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == Path(DEFAULT_CONFIG_DIR)
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.config == Config(directory=DEFAULT_CONFIG_DIR)


# Generated at 2022-06-11 23:31:22.063211
# Unit test for constructor of class Environment
def test_Environment():
    import sys
    import os
    import random
    assert is_windows
    random_id = random.randint(1, 100)

# Generated at 2022-06-11 23:31:48.677719
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin_encoding="utf8")
    assert env.is_windows == False
    assert env.colors == 256
    assert env.config_dir == Path(os.path.expanduser("~/.config/httpie"))
    assert env.stdin == sys.stdin  # `None` when closed fd (#791)
    assert env.stdin_isatty == True
    assert env.stdin_encoding == "utf8"
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stdout_encoding == "utf8"
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == True
    assert env.program_name == "http"



# Generated at 2022-06-11 23:31:54.606386
# Unit test for constructor of class Environment
def test_Environment():
    if __name__ == '__main__':
        print('start test_Environment')
        env = Environment(program_name = 'http')
        env.config_dir = DEFAULT_CONFIG_DIR
        assert env.config_dir == DEFAULT_CONFIG_DIR
        assert env.stdin.isatty()
        assert env.stdout.isatty()
        assert env.stderr.isatty()
        print('end test_Environment')

# Generated at 2022-06-11 23:32:02.446978
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty
    assert env.stdout == sys.stdout
    assert env.stdout_isatty
    assert env.stderr == sys.stderr
    assert env.stderr_isatty
    assert env.colors == 256
    assert env.program_name == 'http'

# Generated at 2022-06-11 23:32:04.857754
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None)
    assert not env.is_windows
    assert env.devnull is None
    assert env.stdout_encoding == 'utf8'

# Generated at 2022-06-11 23:32:12.393553
# Unit test for constructor of class Environment
def test_Environment():
    class Test:
        pass
    m = dict(
        is_windows = True,
        config_dir = Path(),
        stdin_isatty= False,
        stdin_encoding= 'utf-8',
        stdout_isatty= False,
        stdout_encoding= 'utf-8',
        stderr_isatty= False,
        colors = 256,
        program_name = 'http',
    )
    u = Environment(**m)
    for key in m :
        assert getattr(u, key) == m[key]



# Generated at 2022-06-11 23:32:13.828359
# Unit test for constructor of class Environment
def test_Environment():
    assert not Environment(devnull='/dev/null').devnull.closed


# Generated at 2022-06-11 23:32:24.166777
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()

    assert env.stderr == '<colorama._wrap_stream object at 0x7fd6dad4c908>'
    assert env.stderr_isatty == False
    assert env.stderr_encoding == 'UTF-8'
    assert env.stdout == '<colorama._wrap_stream object at 0x7fd6dad4c908>'
    assert env.stdout_isatty == False
    assert env.stdout_encoding == 'UTF-8'
    assert env.stdin is None
    assert env.stdin_isatty == False
    assert env.stdin_encoding == 'utf8'
    assert env.config_dir == '/home'
    assert env.program_name == 'http'
    assert env.is_windows == False
   

# Generated at 2022-06-11 23:32:30.550224
# Unit test for constructor of class Environment
def test_Environment():
    environ = Environment(devnull=True, stdin=sys.stdin)
    assert environ.devnull == True
    assert environ.stdin == sys.stdin
    assert environ.config_dir == DEFAULT_CONFIG_DIR
    assert environ.stdin_isatty == False
    assert environ.stdin_encoding == 'utf-8'
    assert environ.stdout_isatty == True
    assert environ.stdout_encoding == 'utf-8'
    assert environ.stderr_isatty == True
    assert environ.colors == 256

# Generated at 2022-06-11 23:32:40.117725
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows is True
    assert env.config_dir == Path(os.path.expanduser('~/.httpie/'))
    assert env.stdin == sys.stdin
    assert env.stdin_isatty is True
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty is True 
    #assert env.stdout_encoding == 'utf8'
    assert env.stderr == sys.stderr
    assert env.stderr_isatty is True
    assert env.program_name == 'http'
    assert env.colors == 256
    assert env.devnull is None
    assert env._orig_stderr is sys.stderr
   