

# Generated at 2022-06-11 23:22:44.067388
# Unit test for constructor of class Environment
def test_Environment():
    import io
    buf = io.StringIO()
    buf.write('test')
    buf.seek(0)
    a = Environment(stdin=buf)
    assert buf.encoding == a.stdin_encoding
    assert buf.isatty() == a.stdin_isatty
    assert buf is a.stdin

# Generated at 2022-06-11 23:22:52.796543
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=9, foo='bar')
    assert env.stdin == 9
    assert env.foo == 'bar'
    assert env.config_dir == Path(os.path.expanduser('~/.httpie'))
    assert env.is_windows == (os.name == 'nt')

# Generated at 2022-06-11 23:22:57.275306
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        colors=24,
        stdin_encoding='1234',
        stdout_encoding='5678',
        _config=True
    )
    assert env.colors == 24
    assert env.stdin_encoding == '1234'
    assert env.stdout_encoding == '5678'
    assert env._config
    assert env.config

# Generated at 2022-06-11 23:22:58.999965
# Unit test for constructor of class Environment
def test_Environment():
    assert isinstance(Environment(), Environment)

# Generated at 2022-06-11 23:23:05.786005
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == Environment.is_windows
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == env.stdin.isatty()
    assert env.stdin_encoding == sys.stdin.encoding or 'utf8'
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert env.colors == Environment.colors
    assert env.config_dir==DEFAULT_CONFIG_DIR
    assert env.program_name == 'http'

test_Environment()

# Generated at 2022-06-11 23:23:14.118968
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin='mock stdin', stdout='mock stdout', stderr='mock stderr')

    assert env.stdin == 'mock stdin', 'stdin'
    assert env.stdout == 'mock stdout', 'stdout'
    assert env.stderr == 'mock stderr', 'stderr'

    assert env.stdin_isatty is False, 'stdin_isatty'
    assert env.stdout_isatty is False, 'stdout_isatty'
    assert env.stderr_isatty is False, 'stderr_isatty'


# Generated at 2022-06-11 23:23:24.631048
# Unit test for constructor of class Environment
def test_Environment():
    a = Environment(devnull= "0", is_windows = True, config_dir = "D:/Software/httpie-1.0.3-py3.6.exe",
                    stdin = "1", stdin_isatty = True, stdin_encoding = 'utf8',
                    stdout = "1", stdout_isatty = True, stdout_encoding = 'utf8',
                    stderr = "1", stderr_isatty = True, colors = 256,
                    program_name = "http", _orig_stderr = "1", _devnull = "1", _config = "1")
    c = Environment()
    a_dict = a.__dict__
    c_dict = c.__dict__
    print(type(a_dict["config_dir"]))

# Generated at 2022-06-11 23:23:26.935254
# Unit test for constructor of class Environment
def test_Environment():
    assert(Environment().stdout_isatty == True)

if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-11 23:23:33.496661
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull='null',
                      stdout_isatty=True,
                      stdout_encoding='utf-8',
                      stdin_encoding='utf-8')
    assert env.devnull == 'null'
    assert env.stdout_isatty
    assert env.stdout_encoding == 'utf-8'
    assert env.stdin_encoding == 'utf-8'

# Generated at 2022-06-11 23:23:43.416192
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert isinstance(env.config_dir, Path)
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == sys.stdin.encoding
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == sys.stdout.encoding
    assert env.stderr == sys.stderr

# Generated at 2022-06-11 23:23:58.618959
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdin_encoding="utf8", stdin_isatty=False, stdout=None, stdout_isatty=False,
                      stdout_encoding="utf8", stderr=None, stderr_isatty=False, devnull=None, colors=256,
                      program_name="http")

# Generated at 2022-06-11 23:24:09.160494
# Unit test for constructor of class Environment
def test_Environment():
    # import numpy as np
    # import pandas as pd

    env = Environment(
        config_dir = '/home/daniel/Documents/Python/httpie',
        stdin = sys.stdin,
        stdin_isatty = sys.stdin.isatty(),
        stdin_encoding = None,
        stdout = sys.stdout,
        stdout_isatty = sys.stdout.isatty(),
        stdout_encoding = None,
        stderr = sys.stderr,
        stderr_isatty = sys.stderr.isatty(),
        colors = 256,
        program_name = 'http',
    )

# Generated at 2022-06-11 23:24:09.788678
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()

# Generated at 2022-06-11 23:24:17.747472
# Unit test for constructor of class Environment
def test_Environment():
    default_env = Environment()

    assert default_env.stdin_isatty
    assert default_env.stdout_isatty
    assert default_env.stderr_isatty
    assert default_env.stdout_encoding == 'utf8'
    assert default_env.config_dir == DEFAULT_CONFIG_DIR
    assert default_env.program_name == 'http'
    assert default_env.colors == 256
    assert default_env.config.is_new()

    assert len(default_env.__dict__) == 10
    assert len(default_env.__str__()) == 98

# Generated at 2022-06-11 23:24:23.007253
# Unit test for constructor of class Environment
def test_Environment():
    from io import StringIO

    env = Environment(
        stdin=StringIO(),
        stdout=StringIO(),
        stderr=StringIO(),
        config_dir='foobar',
    )

    assert env.stdin
    assert env.stdout
    assert env.stderr
    assert env.config_dir == 'foobar'

# Generated at 2022-06-11 23:24:33.572682
# Unit test for constructor of class Environment
def test_Environment():
    environm = Environment()
    assert isinstance(environm.stdin, file), 'stdin must be a file'
    assert environm.stdin_isatty == sys.stdin.isatty(), 'stdin_isatty must be same as stdin'
    assert environm.stdin_encoding == sys.stdin.encoding, 'stdin_encoding must be same as stdin'

    assert isinstance(environm.stdout, file), 'stdout must be a file'
    assert environm.stdout_isatty == sys.stdout.isatty(), 'stdout_isatty must be same as stdout'
    assert environm.stdout_encoding == sys.stdout.encoding, 'stdout_encoding must be same as stdout'


# Generated at 2022-06-11 23:24:44.731221
# Unit test for constructor of class Environment
def test_Environment():
    env=Environment(
        stdin=None,
        stdin_isatty=True,
        stdin_encoding='utf8',
        stdout=None,
        stdout_isatty=True,
        stdout_encoding='utf8',
        stderr=None,
        stderr_isatty=True,
        colors=256,
        program_name='http'
    )
    assert env.is_windows==is_windows
    assert env.stdin==sys.stdin
    assert env.stdin_isatty==True
    assert env.stdin_encoding=='utf8'
    assert env.stdout==sys.stdout
    assert env.stdout_isatty==True
    assert env.stdout_encoding=='utf8'
    assert env.stder

# Generated at 2022-06-11 23:24:49.857832
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(option1='1', option2='2')
    assert env.option1 == '1'
    assert env.option2 == '2'
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert isinstance(env, Environment)
    assert env.stdin.isatty() == sys.stdin.isatty()

# Generated at 2022-06-11 23:24:56.608013
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == False
    assert env.config_dir == Path(DEFAULT_CONFIG_DIR)
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding ==  None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding ==  None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr == env.stder

# Generated at 2022-06-11 23:24:58.422196
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(config_dir=Path('/tmp'))
    assert env.config_dir == Path('/tmp')

# Generated at 2022-06-11 23:25:09.094118
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name="http", stdin=None, stdout=None, stderr=None, config_dir=Path(".httpie"))
    assert env.is_windows == is_windows
    assert env.config_dir == Path(".httpie")
    assert env.stdin_isatty == False
    assert env.stdout_isatty == False
    assert env.stderr_isatty == False
    assert env.colors == 256
    assert env.program_name == "http"


# Generated at 2022-06-11 23:25:13.490604
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None,
                      stdin_isatty=False,
                      stdin_encoding=None,
                      stdout=sys.stdout,
                      stdout_isatty=True,
                      stdout_encoding=None,
                      stderr=sys.stderr,
                      stderr_isatty=True,
                      colors=256,
                      program_name='http')
    print(env)

# Generated at 2022-06-11 23:25:15.108589
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(colors=18)
    assert env.colors == 18


# Generated at 2022-06-11 23:25:18.623399
# Unit test for constructor of class Environment
def test_Environment():
  env = Environment()

  print(env.is_windows)
  assert env.is_windows == False


  print(env.config_dir)
  assert env.config_dir == Path.home() / '.config' / 'httpie'


  print(env.stdin)
  assert env.stdin != None


  print(env.stdin_isatty)
  assert env.stdin_isatty == True


  print(env.stdout)
  assert env.stdout == sys.stdout


  print(env.stdout_isatty)
  assert env.stdout_isatty == True


  print(env.stdout_encoding)
  assert env.stdout_encoding != None


  print(env.stderr)
  assert env.stderr == sys

# Generated at 2022-06-11 23:25:27.430615
# Unit test for constructor of class Environment
def test_Environment(): 
    env = Environment(stdout=sys.stdout,stdout_isatty=sys.stdout.isatty(),stdout_encoding='utf8',stderr=sys.stderr,stderr_isatty=sys.stderr.isatty(),config_dir='/Users/zeminlu/.config/httpie')
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == 'utf8'
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.config_dir == '/Users/zeminlu/.config/httpie'

# Generated at 2022-06-11 23:25:34.276319
# Unit test for constructor of class Environment
def test_Environment():

    env = Environment(stdin=sys.stdin)

    # Checking environment attributes
    assert env.stdin is sys.stdin
    assert env.stdin_isatty
    # assert env.stdin_encoding == 'UTF-8'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty
    # assert env.stdout_encoding == 'UTF-8'
    assert env.stderr == sys.stderr
    assert env.stderr_isatty
    assert env.colors == 256
    assert env._devnull is None
    assert env.program_name == 'http'



# Generated at 2022-06-11 23:25:44.194694
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin is sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding is None
    assert env.stdout is sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding is None
    assert env.stderr is sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    env.config_dir = 'new_config_dir'

# Generated at 2022-06-11 23:25:49.612046
# Unit test for constructor of class Environment
def test_Environment():
    import tempfile
    with tempfile.TemporaryDirectory() as config_dir:
        env = Environment(
                stdout=open(os.devnull, 'w+'),
                stderr=open(os.devnull, 'w+'),
                config_dir=config_dir
            )
        print(env)

if __name__ == '__main__':
    test_Environme

# Generated at 2022-06-11 23:25:53.854865
# Unit test for constructor of class Environment
def test_Environment():
	env = Environment()
	print(env)
	assert env.stdin.isatty()
	env = Environment(colors=8)
	assert env.colors == 8
	assert env.stdin.isatty()
	assert env.stdout.isatty()
	assert env.stderr.isatty()

# Generated at 2022-06-11 23:26:03.700005
# Unit test for constructor of class Environment
def test_Environment():
    actual = Environment(devnull=None, program_name='http', stdin=object(), stdin_isatty=False, stdin_encoding='utf8', stdout=object(), stdout_isatty=False, stdout_encoding='utf8', stderr=object(), stderr_isatty=False, colors=256, program_name='http', config_dir='/home/lcl/.config/httpie')

# Generated at 2022-06-11 23:26:18.872599
# Unit test for constructor of class Environment
def test_Environment():
    sys.stdout = sys.__stdout__
    sys.stderr = sys.__stderr__
    from httpie.config import CONFIG_DIR
    import sys
    import os
    os.environ['HOME'] = '/home/'

# Generated at 2022-06-11 23:26:28.327408
# Unit test for constructor of class Environment
def test_Environment():
    environ = Environment()
    assert environ.is_windows == is_windows
    assert environ.config_dir == DEFAULT_CONFIG_DIR
    assert environ.stdin == sys.stdin
    assert environ.stdin_isatty == sys.stdin.isatty()
    assert environ.stdout == sys.stdout
    assert environ.stdout_isatty == sys.stdout.isatty()
    assert environ.stderr == sys.stderr
    assert environ.stderr_isatty == sys.stderr.isatty()
    assert environ.colors == 256
    assert environ.program_name == 'http'
    assert environ._orig_stderr == sys.stderr
    assert environ._devnull is None

# Generated at 2022-06-11 23:26:33.873608
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(is_windows=True, program_name='httpie')
    assert env.is_windows is True
    assert env.program_name == 'httpie'
    assert env.devnull is None
    assert 'devnull' not in env.__dict__
    assert '_orig_stderr' not in env.__dict__



# Generated at 2022-06-11 23:26:40.834674
# Unit test for constructor of class Environment

# Generated at 2022-06-11 23:26:43.092328
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdout=object())
    assert env.__dict__


if __name__ == "__main__":
    test_Environment()

# Generated at 2022-06-11 23:26:49.270442
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == getattr(sys.stdout, 'encoding', None)

# Testcase for constructor of class Environment

# Generated at 2022-06-11 23:26:58.049828
# Unit test for constructor of class Environment
def test_Environment():
    import sys
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.utils import repr_dict
    from httpie.config import Config
    from httpie import __version__
    from httpie.output.streams import STDOUT_ENCODING

    env = Environment()
    assert is_windows == env.is_windows
    assert DEFAULT_CONFIG_DIR == env.config_dir
    assert sys.stdin == env.stdin
    assert sys.stdout == env.stdout
    assert sys.stderr == env.stderr
    assert "stdin" in repr(env)
    assert "stdout" in repr(env)
    assert "stderr" in repr(env)
    assert "httpie" in repr(env)
   

# Generated at 2022-06-11 23:27:08.371497
# Unit test for constructor of class Environment
def test_Environment():
    environ = Environment()
    assert environ.program_name == 'http'
    # Ignore the actual colors of current device.
    assert environ.colors == 256
    assert environ.stderr_isatty() == sys.stderr.isatty()
    assert environ.stdout_isatty() == sys.stdout.isatty()
    assert environ.stdin_isatty() == sys.stdin.isatty()
    assert environ.stderr_encoding == sys.stderr.encoding
    assert environ.stdout_encoding == sys.stdout.encoding
    assert environ.stdin_encoding == sys.stdin.encoding

    assert environ == Environment()

# Generated at 2022-06-11 23:27:17.752434
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert repr(env.colors) == '256'
    assert repr(env.program_name) == "'http'"
    assert env.is_windows == is_windows


# Generated at 2022-06-11 23:27:23.258980
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    print("\nThis is the test output for class Environment")
    print("Is there a colour terminal? ", env.stdout_isatty)
    print("The name of this program is ", env.program_name)
    print("The default configuration directory is ", env.config_dir)
    print("The encoding of stdin is ", env.stdin_encoding)
    print("The encoding of stdout is ", env.stdout_encoding)
    print("\n")


# Generated at 2022-06-11 23:27:38.051216
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin_encoding='stdin', stdout_encoding='stdout')
    assert env.stdin_encoding == 'stdin'
    assert env.stdout_encoding == 'stdout'

    env = Environment()
    assert env.stdin_encoding == 'utf8'
    assert env.stdout_encoding == 'utf8'


# Generated at 2022-06-11 23:27:48.412537
# Unit test for constructor of class Environment
def test_Environment():
    stdout = open('/tmp/stdout.txt', 'w+')
    stdout.write('stdout')
    stdout.close()
    stdout = open('/tmp/stdout.txt', 'r', encoding='utf8')
    stderr = open('/tmp/stderr.txt', 'w+')
    stderr.write('stderr')
    stderr.close()
    stderr = open('/tmp/stderr.txt', 'r', encoding='utf8')
    stdin = open('/tmp/stdin.txt', 'w+')
    stdin.write('stdin')
    stdin.close()
    stdin = open('/tmp/stdin.txt', 'r', encoding='utf8')

    env = Environment(stdin, stdout, stderr)

# Generated at 2022-06-11 23:27:55.047016
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None)
    assert env.stdin_isatty == False
    assert env.stdin == None
    assert env.stdin_encoding == "utf8"
    assert env.stdout_isatty == True
    assert env.stdout == sys.stdout
    assert env.stdout_encoding == "utf8"
    assert env.stderr_isatty == True
    assert env.stderr == sys.stderr



# Generated at 2022-06-11 23:27:57.160475
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=1, program_name='xxx')
    assert env.devnull == 1
    assert env.program_name == 'xxx'

# Generated at 2022-06-11 23:28:05.703373
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull = open(os.devnull, 'w+'), \
        is_windows = False, config_dir = DEFAULT_CONFIG_DIR,\
        stdin = open(os.devnull, 'r'), stdin_isatty = False, stdin_encoding = "utf8",\
        stdout = open(os.devnull, 'w+'), stdout_isatty = False, stdout_encoding = "utf8",\
        stderr = open(os.devnull, 'w+'), stderr_isatty = False,\
        colors = 256, program_name = "http")
    return env


# Generated at 2022-06-11 23:28:16.254982
# Unit test for constructor of class Environment
def test_Environment():
    # Test for all attributes
    e = Environment(is_windows=False, config_dir=None,
                   stdin=None, stdin_isatty=None, stdin_encoding=None,
                   stdout=None, stdout_isatty=None, stdout_encoding=None,
                   stderr=None, stderr_isatty=None, colors=None, program_name=None,
                   devnull=None)
    assert not e.is_windows
    assert e.config_dir is None
    assert e.stdin is None
    assert e.stdin_isatty is None
    assert e.stdin_encoding is None
    assert e.stdout is None
    assert e.stdout_isatty is None
    assert e.stdout_encoding is None

# Generated at 2022-06-11 23:28:25.094558
# Unit test for constructor of class Environment
def test_Environment():

    env = Environment()
    env.is_windows = False
    assert not env.is_windows
    assert env.config_dir == Path(DEFAULT_CONFIG_DIR)
    assert env.stdin is sys.stdin
    assert env.stdin_isatty
    assert env.stdin_encoding is None
    assert env.stdout is sys.stdout
    assert env.stdout_isatty
    assert env.stdout_encoding is None
    assert env.stderr is sys.stderr
    assert env.stderr_isatty
    assert env.colors == 256

# Generated at 2022-06-11 23:28:34.625768
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    actual_data = str(environment)

# Generated at 2022-06-11 23:28:37.541767
# Unit test for constructor of class Environment
def test_Environment():
    if sys.stdin.isatty():
        assert stdin == sys.stdin
    else:
        assert stdin == sys.stdin

    assert stdout == sys.stdout
    assert stderr == sys.stderr

    assert stdin_encoding == sys.stdin.encoding
    assert stdout_encoding == sys.stdout.encoding
    assert stderr_encoding == sys.stderr.encoding


# Use a global instance of the Environment class.
env = Environment()

# Generated at 2022-06-11 23:28:49.556583
# Unit test for constructor of class Environment
def test_Environment():
    from httpie.config import Config
    class Foo(Environment):
        colors = 88
        config_dir = Path('/tmp/config')
        stdin = sys.stdin
        stdin_isatty = stdin.isatty()
        stdin_encoding = 'utf-8'
        stdout = sys.stdout
        stdout_isatty = stdout.isatty()
        stdout_encoding = None
        stderr = sys.stderr
        stderr_isatty = stderr.isatty()
        program_name = 'httpie'
        config_dir = Path('/tmp/config')

    # class Environment
    # default attribute
    test_Environment = Environment()
    assert test_Environment.is_windows == is_windows
    assert test_Environment.config_dir

# Generated at 2022-06-11 23:29:00.646464
# Unit test for constructor of class Environment
def test_Environment():
    class Env(Environment):
        pass
    env=Env()
    assert isinstance(env, Environment)
    assert env.is_windows == is_windows


# Generated at 2022-06-11 23:29:03.979888
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdout_isatty=True)
    assert env.__dict__
    assert env._orig_stderr == sys.stderr
    assert env._devnull is None


# Generated at 2022-06-11 23:29:14.759794
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull='1', config_dir='2', stdin='3', stdin_isatty='4', stdin_encoding='5', stdout='6', stdout_isatty='7', stdout_encoding='8', stderr='9', stderr_isatty='10', colors='11', program_name='12')
    assert isinstance(env, object)
    assert env.is_windows == is_windows
    assert env.config_dir == '2'
    assert env.stdin == '3'
    assert env.stdin_isatty == True
    assert env.stdin_encoding == '5'
    assert env.stdout == '6'
    assert env.stdout_isatty == True
    assert env.stdout_encoding == '8'

# Generated at 2022-06-11 23:29:18.052363
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment.stdin.encoding
    assert Environment.stdout_encoding
    assert len(Environment.__dict__)  # The number of class attributes


# Generated at 2022-06-11 23:29:26.468324
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == Environment.is_windows
    assert env.stdin == Environment.stdin
    assert env.stdin_encoding == Environment.stdin_encoding
    assert env.stdout == Environment.stdout
    assert env.stdin_isatty == Environment.stdin_isatty
    assert env.stdout_isatty == Environment.stdout_isatty
    assert env.stderr == Environment.stderr
    assert env.stderr_isatty == Environment.stderr_isatty
    assert env.colors == Environment.colors
    assert env.program_name == Environment.program_name
    assert env._orig_stderr == Environment._orig_stderr
    assert env._devnull == Environment._devnull
    assert env.config

# Generated at 2022-06-11 23:29:36.965950
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert str(env.config_dir) == str(DEFAULT_CONFIG_DIR)
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'

# Generated at 2022-06-11 23:29:43.933414
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert isinstance(env, Environment)
    assert isinstance(env.config, Config)
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == 'utf8'
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()

# Generated at 2022-06-11 23:29:46.664192
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name='httpie-test', stdout_isatty=True)
    assert env.program_name == 'httpie-test'
    assert env.stdout_isatty == True

# Generated at 2022-06-11 23:29:55.834202
# Unit test for constructor of class Environment
def test_Environment():
    from io import BytesIO
    import sys
    import os
    from pathlib import Path
    path = Path(__file__)
    dir = path.parent.parent
    os.chdir(dir)
    env = Environment(stdin=BytesIO(b'cmd line\n'), stdout=BytesIO(), stderr=BytesIO(), devnull=BytesIO())
    assert env.stdin.readline() == b'cmd line\n'
    assert env.devnull.mode == 'w+'
    assert env.config_dir == dir / 'httpie'
    assert env.stdout.mode == 'w'
    assert env.stderr.mode == 'w'
    assert env.program_name == 'http'
    env.stdin.close()
    assert env.stdin_isatty == False
   

# Generated at 2022-06-11 23:30:06.185743
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()

# Generated at 2022-06-11 23:30:26.918444
# Unit test for constructor of class Environment
def test_Environment():
    """
    >>> from httpie.core import Environment
    >>> env = Environment(devnull='devnull', colors=256)
    >>> env.devnull
    'devnull'
    >>> env.colors
    256
    """
    pass

# Generated at 2022-06-11 23:30:32.606895
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name='http', devnull=None, config_dir=None, stdin=None, stdout=None, stderr=None)
    assert env.program_name == 'http'
    assert env.devnull == None
    assert env.config_dir == None
    assert env.stdin == None
    assert env.stdout == None
    assert env.stderr == None

# Generated at 2022-06-11 23:30:37.233118
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull ='path/to/devnull', \
                      stdout ='/dev/null', stdout_isatty =False, stdout_encoding='utf8',\
                      stderr ='/dev/null', stderr_isatty =False, \
                      )
    env.devnull = 'path/to/devnull_2'
    print(env)
    return env

# Generated at 2022-06-11 23:30:44.703881
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        stdin=None,
        stdin_isatty=True,
        stdin_encoding='utf8',
        stdout=sys.stdout,
        stdout_isatty=True,
        stdout_encoding='utf8',
        stderr=sys.stderr,
        stderr_isatty=True,
        colors=32,
        program_name='http',
        stdin_isatty=True,
    )
    print(env)
    assert isinstance(env, Environment)
    assert env.is_windows is False
    assert env.config_dir == Path.home() / '.config' / 'httpie'
    assert env.stdin is None
    assert env.stdout == sys.stdout
    assert env.stderr == sys.st

# Generated at 2022-06-11 23:30:53.663800
# Unit test for constructor of class Environment

# Generated at 2022-06-11 23:31:01.836961
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == False
    assert env.config_dir == Path(os.path.expanduser('~/.httpie'))
    assert env.stdin == sys.stdin
    assert env.stdin_isatty
    assert env.stdin_encoding == 'utf-8'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty
    assert env.stdout_encoding == 'utf-8'
    assert env.stderr == sys.stderr
    assert env.stderr_isatty
    assert env.program_name == 'http'
    assert env.colors == 256

# Generated at 2022-06-11 23:31:07.093480
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(is_windows = False, config_dir = DEFAULT_CONFIG_DIR, stdin = sys.stdin, stdout = sys.stdout, stderr = sys.stderr)
    assert env.is_windows == False
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr

# Generated at 2022-06-11 23:31:16.997381
# Unit test for constructor of class Environment
def test_Environment():
    import sys
    import httpie

    env = Environment(
        is_windows=httpie.__version__,
        config_dir=httpie.__name__,
        stdin=sys.stdin,
        stdin_isatty=sys.stdin.isatty(),
        stdin_encoding=None,
        stdout=sys.stdout,
        stdout_isatty=sys.stdout.isatty(),
        stdout_encoding=None,
        stderr=sys.stderr,
        stderr_isatty=sys.stderr.isatty(),
        program_name=httpie.__license__
    )
    print(env)
    return env

# Generated at 2022-06-11 23:31:24.266521
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        is_windows=True,
        config_dir=".httpie",
        stdin=None,
        stdin_isatty=False,
        stdin_encoding="utf8",
        stdout=sys.stdout,
        stdout_isatty=True,
        stdout_encoding="utf8",
        stderr=sys.stderr,
        stderr_isatty=True,
        colors=256,
        program_name="http"
    )
    assert env.is_windows == True
    assert env.config_dir == ".httpie"
    assert env.stdin == None
    assert env.stdin_isatty == False
    assert env.stdin_encoding == "utf8"
    assert env.stdout == sys.stdout
   

# Generated at 2022-06-11 23:31:35.055997
# Unit test for constructor of class Environment
def test_Environment():
    # Test 1
    env = Environment()
    actual = dict(env.__dict__)
    expected = dict(
        is_windows = is_windows,
        config_dir = DEFAULT_CONFIG_DIR,
        stdin = sys.stdin,
        stdout = sys.stdout,
        stderr = sys.stderr
    )
    assert expected == actual
    # Test 2
    env = Environment(
        is_windows = True,
        config_dir = DEFAULT_CONFIG_DIR,
        stdin = "sys.stdin",
        stdout = "sys.stdout",
        stderr = "sys.stderr"
    )
    actual = dict(env.__dict__)

# Generated at 2022-06-11 23:32:18.315899
# Unit test for constructor of class Environment
def test_Environment():
    env1 = Environment(stdin=17)
    assert env1.stdin == 17

    env2 = Environment(stdin=17, stdout=42)
    assert env2.stdin == 17
    assert env2.stdout == 42

    s = str(env2)
    assert s.find('stdin=17') > 0
    assert s.find('stdout=42') > 0



# Generated at 2022-06-11 23:32:18.936074
# Unit test for constructor of class Environment
def test_Environment():
    pass

# Generated at 2022-06-11 23:32:28.259091
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout_encoding == 'utf8'
    assert env.stderr == sys.stderr

    # function __str__()

# Generated at 2022-06-11 23:32:34.648064
# Unit test for constructor of class Environment
def test_Environment():
    # 测试**kwargs
    
    #创建一个可以进行测试的环境变量
    env = Environment()
    print(env)
    print(env.__dict__)

    # env = Environment(stdin='test1')
    # print(env)
    # print(env.__dict__)

    # env = Environment(test1=111)
    # print(env)
    # print(env.__dict__)

if __name__ == "__main__":
    test_Environment()