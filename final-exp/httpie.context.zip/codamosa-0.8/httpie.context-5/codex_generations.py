

# Generated at 2022-06-11 23:22:51.133605
# Unit test for constructor of class Environment
def test_Environment():
    import sys
    import os
    import platform
    env_l = Environment()
    env_r = Environment(
    is_windows = False,
    config_dir = 'C:\\Users\\Doma\\Desktop\\cmd.txt',
    stdin = sys.stdin,
    stdin_isatty = True,
    stdin_encoding = 'GBK',
    stdout = sys.stdout,
    stdout_isatty = True,
    stdout_encoding = 'GBK',
    stderr = sys.stderr,
    stderr_isatty = True,
    colors = 256,
    program_name = 'http',
    )
    assert env_l == env_r
    print('Pass Test2')

# Generated at 2022-06-11 23:22:53.928247
# Unit test for constructor of class Environment
def test_Environment():
    logger = Environment(a = 1, b = 2)
    print(logger)
    logger.log_error("The connection to the server could not be established. Please try again.")
    print(logger)
    
# test the constructor of class Environment
test_Environment()

# Generated at 2022-06-11 23:23:04.239443
# Unit test for constructor of class Environment
def test_Environment():
    def test_Environment():
    # Test constructor of class Environment
        instance = Environment()
        assert instance.__dict__['is_windows'] ==is_windows
        assert instance.__dict__['stdin'] == sys.stdin
        assert instance.__dict__['stdin_isatty'] == stdin.isatty()
        assert instance.__dict__['stdin_encoding'] == None
        assert instance.__dict__['stdout'] == sys.stdout
        assert instance.__dict__['stdout_isatty'] == stdout.isatty()
        assert instance.__dict__['stdout_encoding'] == None
        assert instance.__dict__['stderr'] == sys.stderr
        assert instance.__dict__['stderr_isatty'] == stderr.isatty()


# Generated at 2022-06-11 23:23:14.512415
# Unit test for constructor of class Environment
def test_Environment():
    """
    >>> # The default global environment instance
    >>> env = Environment()
    >>> isinstance(env, Environment)
    True
    """
    pass


env = Environment()

# Generated at 2022-06-11 23:23:17.684016
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment(stdin = sys.stdin, stdout = sys.stdout, config_dir = sys.stdout)

if __name__ == "__main__":
    test_Environment()

# Generated at 2022-06-11 23:23:28.392342
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows == is_windows
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin is sys.stdin
    assert environment.stdin_isatty is sys.stdin.isatty()
    assert environment.stdin_encoding is None
    assert environment.stdout is sys.stdout
    assert environment.stdout_isatty is sys.stdout.isatty()
    assert environment.stdout_encoding is None
    assert environment.stderr is sys.stderr
    assert environment.stderr_isatty is sys.stderr.isatty()
    assert environment.colors == 256
    assert environment.program_name == 'http'
    assert environment._orig_stderr is sys.stderr
   

# Generated at 2022-06-11 23:23:33.498460
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdout_encoding = 'utf8', stdin_encoding = 'utf8')
    env.config_dir = Path('/home/huangdabin/')
    assert env.config.directory == Path('/home/huangdabin/')
    print(env.config.directory)

# Generated at 2022-06-11 23:23:35.836415
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    print(env)
    assert env != None

# Generated at 2022-06-11 23:23:42.816781
# Unit test for constructor of class Environment
def test_Environment():
    env: Environment = Environment(
        config_dir="/home/zhangyanwei/code/httpie",
        stdout=StringIO(),
        stdin=StringIO(),
        stderr=StringIO(),
    )
    env.stderr.write('error')
    env.log_error('error')

if __name__ == "__main__":
    from io import StringIO
    test_Environment()

# Generated at 2022-06-11 23:23:46.469160
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    # print(env)
    # print(list(env))
    # print(env.stdout)
    # # print(env.stdout.encoding)
    # print(env.stderr)


# Generated at 2022-06-11 23:23:58.736111
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        is_windows=False,
        stdin_isatty=True,
        stdout_isatty=True,
        stderr_isatty=True,
        colors=256,
        program_name='http'
    )
    assert env.is_windows == False
    assert env.stdin_isatty == True
    assert env.stdout_isatty == True
    assert env.stderr_isatty == True
    assert env.colors == 256
    assert env.program_name == 'http'

# Generated at 2022-06-11 23:24:08.384991
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull='devnull', config_dir='config_dir', stdin='stdin', stdout='stdout', stderr='stderr', program_name='program_name')
    assert env.devnull == 'devnull', 'devnull'
    assert env.config_dir == 'config_dir', 'config_dir'
    assert env.stdin == 'stdin', 'stdin'
    assert env.stdout == 'stdout', 'stdout'
    assert env.stderr == 'stderr', 'stderr'
    assert env.program_name == 'program_name', 'program_name'

# Generated at 2022-06-11 23:24:17.671417
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().stdin == sys.stdin
    assert Environment().stdin_isatty == sys.stdin.isatty()
    assert Environment().stdin_encoding == sys.stdin.encoding
    assert Environment().stdout == sys.stdout
    assert Environment().stdout_isatty == sys.stdout.isatty()
    assert Environment().stdout_encoding == sys.stdout.encoding
    assert Environment().stderr_isatty == sys.stderr.isatty()
    assert Environment().stderr_encoding == sys.stderr.encoding
    assert Environment().program_name == 'http'
    assert Environment().config_dir == DEFAULT_CONFIG_DIR

# Generated at 2022-06-11 23:24:22.856150
# Unit test for constructor of class Environment
def test_Environment():
    # to set environment values
    stdin_encoding = 'stdin_encoding'
    stdout_encoding = 'stdout_encoding'
    stderr_encoding = 'stderr_encoding'
    stdin = sys.stdin
    stdout = sys.stdout
    stderr = sys.stderr
    stdin_isatty = stdin.isatty()
    stdout_isatty = stdout.isatty()
    stderr_isatty = stderr.isatty()
    colors = 256
    program_name = 'program_name'
    if not is_windows:
        if curses:
            try:
                curses.setupterm()
                colors = curses.tigetnum('colors')
            except curses.error:
                pass

# Generated at 2022-06-11 23:24:33.444031
# Unit test for constructor of class Environment
def test_Environment():
    import os
    import sys
    import tempfile
    from pathlib import Path
    from typing import IO

    # Initialization
    devnull = tempfile.TemporaryFile()
    env = Environment(devnull=devnull)
    assert isinstance(env, Environment)

    # Test Cases
    assert isinstance(env.is_windows, bool)
    assert isinstance(env.config_dir, Path)
    assert isinstance(env.stdin, IO)
    assert isinstance(env.stdin_encoding, str)
    assert isinstance(env.stdin_isatty, bool)
    assert isinstance(env.stdout, IO)
    assert isinstance(env.stdout_encoding, str)
    assert isinstance(env.stdout_isatty, bool)

# Generated at 2022-06-11 23:24:44.232981
# Unit test for constructor of class Environment
def test_Environment():  
    e = Environment(devnull = 'fd', program_name = 'httpie', colors = 256, stdout = sys.stdout, stdout_encoding='utf-8',
                    stdout_isatty=True, stderr = sys.stderr, stderr_isatty=True,
                    config_dir = '.httpie', stdin = sys.stdin, stdin_isatty = True)
    assert e.is_windows is False
    assert e.config_dir == '.httpie'
    assert e.stdin == sys.stdin and e.stdin_isatty == True
    assert e.stdout == sys.stdout and e.stdout_encoding == 'utf-8' and e.stdout_isatty is True
    assert e.stderr == sys.stderr and e

# Generated at 2022-06-11 23:24:53.033394
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        config_dir='C:/users/Rona',
        stdin='stdin',
        stdin_isatty=True,
        stdin_encoding='utf8',
        stdout='stdout',
        stdout_isatty=True,
        stdout_encoding='utf8',
        stderr='stderr',
        stderr_isatty=True,
        colors=256,
        program_name='http',
        is_windows=True
    )
    assert env.config_dir == 'C:/users/Rona'
    assert env.stdin == 'stdin'
    assert env.stdin_isatty is True
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == 'stdout'
    assert env.std

# Generated at 2022-06-11 23:25:03.080925
# Unit test for constructor of class Environment
def test_Environment():
    kwargs = dict(
        stdin=io.BytesIO(b"stdin"),
        stdin_isatty=False,
        stdin_encoding=None,
        stdout=io.BytesIO(b"stdout"),
        stdout_isatty=False,
        stdout_encoding=None,
        stderr=io.BytesIO(b"stderr"),
        stderr_isatty=False,
        devnull=io.BytesIO(b"devnull"),
        config_dir=Path("/home/peter/"),
        program_name="http"
    )
    environ = Environment(**kwargs)

    assert environ.stdin == io.BytesIO(b"stdin")
    assert environ.stdin_isatty == False

# Generated at 2022-06-11 23:25:11.867879
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()

    assert is_windows == env.is_windows
    assert DEFAULT_CONFIG_DIR == env.config_dir
    sys.stdin == env.stdin
    assert sys.stdout == env.stdout
    assert sys.stderr == env.stderr
    assert 'http' == env.program_name
    assert 256 == env.colors

# Generated at 2022-06-11 23:25:18.613806
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(a=1, b='foo', c=None)
    assert env.a == 1
    assert env.b == 'foo'
    assert env.c is None
    assert hasattr(env, 'stdin')
    assert hasattr(env, 'stdout')
    assert hasattr(env, 'stderr')
    assert hasattr(env, 'program_name')



# Generated at 2022-06-11 23:25:31.557747
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(color=256, is_windows=False, stdin=None, stdout=sys.stdout, program_name='http')
    assert env.color == 256
    assert env.stderr == '<_io.TextIOWrapper name=2 mode=\'w\' encoding=\'UTF-8\'>'
    print('success')

# Generated at 2022-06-11 23:25:41.021354
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        stdin=None,
        stdout=sys.stdout,
        stderr=sys.stderr
    )
    assert env.is_windows == Environment.is_windows
    assert env.stdin == Environment.stdin
    assert env.stdin_isatty == Environment.stdin_isatty
    assert env.stdin_encoding == Environment.stdin_encoding
    assert env.stdout == Environment.stdout
    assert env.stdout_isatty == Environment.stdout_isatty
    assert env.stdout_encoding == Environment.stdout_encoding
    assert env.stderr == Environment.stderr
    assert env.stderr_isatty == Environment.stderr_isatty
    assert env.colors == Environment.colors


# Generated at 2022-06-11 23:25:51.324967
# Unit test for constructor of class Environment
def test_Environment():
    stdin_isatty = True
    config_dir = '/root/.httpie'
    stdin_encoding = 'latin1'
    stdout_isatty = True
    stdout_encoding = 'ascii'
    stderr_isatty = True

    sys.stdin = open(os.devnull, 'r')
    sys.stdout = open(os.devnull, 'w')
    sys.stderr = open(os.devnull, 'w')

    config = Config(directory=config_dir)

    try:
        config.load()
    except ConfigFileError as e:
        pass

    env = Environment()

    assert env.is_windows == False
    assert env.config_dir == config_dir
    assert env.stdin_isatty == stdin_isat

# Generated at 2022-06-11 23:25:54.291505
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None,config_dir="D:/env_test",stderr=None)
    print(env.stdin)
    print(env.config_dir)
    print(env.stderr)


# Generated at 2022-06-11 23:25:56.906310
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment(
        stdout=123,
        stdout_encoding='foo',
    )
    assert e.stdout == 123
    assert e.stdout_encoding == 'foo'

# Generated at 2022-06-11 23:26:07.099963
# Unit test for constructor of class Environment
def test_Environment():
    import sys
    import os.path
    import shutil
    import tempfile

    if not os.path.exists(DEFAULT_CONFIG_DIR):
        os.makedirs(DEFAULT_CONFIG_DIR)

    class TempEnv():
        def __init__(self):
            assert isinstance(Environment().config.dir, Path)
            assert isinstance(Environment().config.path, Path)
            assert isinstance(Environment().config.dir, Path)
            assert isinstance(Environment().config.path, Path)
            assert isinstance(Environment().stdin, IO)
            assert isinstance(Environment().stdin_isatty, bool)
            assert isinstance(Environment().stdin_encoding, str)
            assert isinstance(Environment().stdout, IO)

# Generated at 2022-06-11 23:26:17.649613
# Unit test for constructor of class Environment
def test_Environment():
    # default value
    env = Environment()
    assert isinstance(env, Environment)
    # overwrite config_dir
    env = Environment(config_dir='/usr')
    assert env.config_dir == '/usr'
    # overwrite stdin
    env = Environment(stdin=sys.stdin)
    assert env.stdin == sys.stdin
    # overwrite stdin_isatty
    env = Environment(stdin_isatty=False)
    assert env.stdin_isatty == False
    # overwrite stdin_encoding
    env = Environment(stdin_encoding='utf8')
    assert env.stdin_encoding == 'utf8'
    # overwrite stdout
    env = Environment(stdout=sys.stdout)
    assert env.stdout == sys.stdout
    # overwrite stdout

# Generated at 2022-06-11 23:26:23.557884
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name='http', config_dir="/home/ubuntu/config", is_windows=True, stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr, colors = 256)
    assert env.program_name == 'http'
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.config_dir == Path("/home/ubuntu/config")


# Generated at 2022-06-11 23:26:33.825043
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == True
    assert str(env.config_dir) == "C:\\Users\\Administrator\\.httpie"
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == True
    assert env.stdin_encoding == "utf8"
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == True
    assert env.colors == 256
    assert env.program_name == "http"
    try:
        assert 'colorama' in env.__dict__
        assert 'AnsiToWin32' in env.__dict__
        #assert env.stdout == env.stdout.wrapped
    except:
        pass
   

# Generated at 2022-06-11 23:26:38.640340
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    env.config_dir = DEFAULT_CONFIG_DIR
    env.stdin = ''
    env.stdout = ''
    env.stderr = ''
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin != ''
    assert env.stdout != ''
    assert env.stderr != ''

# Generated at 2022-06-11 23:26:57.424003
# Unit test for constructor of class Environment
def test_Environment():
    defaults = type(Environment()).__dict__
    env = Environment()
    assert isinstance(env, Environment)
    assert env.is_windows == defaults['is_windows']
    assert env.config_dir == defaults['config_dir']
    assert env.stdin == defaults['stdin']
    assert env.stdin_isatty == defaults['stdin_isatty']
    assert env.stdin_encoding == defaults['stdin_encoding']
    assert env.stdout == defaults['stdout']
    assert env.stdout_isatty == defaults['stdout_isatty']
    assert env.stdout_encoding == defaults['stdout_encoding']
    assert env.stderr == defaults['stderr']

# Generated at 2022-06-11 23:26:59.100882
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert isinstance(environment, Environment)


# Generated at 2022-06-11 23:27:07.890170
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == env.stdin_encoding
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256

# Generated at 2022-06-11 23:27:17.325544
# Unit test for constructor of class Environment
def test_Environment():
    defaults = {
        "is_windows": is_windows,
        "config_dir": Path(DEFAULT_CONFIG_DIR),
        "stdin": sys.stdin,
        "stdin_isatty": sys.stdin.isatty(),
        "stdout": sys.stdout,
        "stdout_isatty": sys.stdout.isatty(),
        "stderr": sys.stderr,
        "stderr_isatty": sys.stderr.isatty(),
        "colors": 256,
        "program_name": 'http',
    }



# Generated at 2022-06-11 23:27:25.240919
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()

    assert env.is_windows == is_windows
    if not is_windows:
        # Python 3.9
        if hasattr(env.stdin, 'buffer'):
            stdin = env.stdin.buffer
        else:  # Python 3.8
            stdin = env.stdin
        assert stdin is sys.stdin

    assert env.stdin_isatty is sys.stdin.isatty()
    assert env.stdin_encoding == 'utf8'
    assert env.stdout is sys.stdout
    assert env.stdout_isatty is sys.stdout.isatty()
    assert env.stdout_encoding == 'utf8'
    assert env.stderr is sys.stderr
    assert env.stderr_isatty is sys

# Generated at 2022-06-11 23:27:36.343810
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    env.is_windows = False
    assert env.is_windows == False
    env.config_dir = DEFAULT_CONFIG_DIR
    assert env.config_dir == DEFAULT_CONFIG_DIR
    env.stdin = sys.stdin
    assert env.stdin == sys.stdin
    env.stdin_isatty = True
    assert env.stdin_isatty == True
    env.stdin_encoding = None
    assert env.stdin_encoding == None
    env.stdout = sys.stdout
    assert env.stdout == sys.stdout
    env.stdout_isatty = True
    assert env.stdout_isatty == True
    env.stdout_encoding = None
    assert env.stdout_encoding == None
   

# Generated at 2022-06-11 23:27:43.617542
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(
        stdin=sys.stdin,
        stdout=sys.stdout,
        stderr=sys.stderr,
        devnull=None,
        config_dir=DEFAULT_CONFIG_DIR,
        is_windows=False,
        program_name='http',
        stdin_isatty=False,
        stdout_isatty=False,
        stderr_isatty=False,
        colors=256,
        stdin_encoding=None,
        stdout_encoding=None,
        stderr_encoding=None
    )
    print(environment)

# Generated at 2022-06-11 23:27:52.298502
# Unit test for constructor of class Environment
def test_Environment():
    from unittest.mock import Mock
    stdin_encoding = 'stdin_encoding'
    stdin = Mock(
        name='stdin',
        spec=sys.stdin,
        isatty=Mock(return_value=True),
        encoding=stdin_encoding,
    )
    stdout_encoding = 'stdout_encoding'
    stdout = Mock(
        name='stdout',
        spec=sys.stdout,
        isatty=Mock(return_value=False),
        encoding=stdout_encoding,
    )
    stderr = Mock(
        name='stderr',
        spec=sys.stderr,
        isatty=Mock(return_value=True),
    )
    devnull = Mock(name='devnull')


# Generated at 2022-06-11 23:28:02.022303
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding is None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding is None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()

# Generated at 2022-06-11 23:28:05.170018
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name='http')
    assert env.program_name == 'http'
    assert env.stderr_isatty == True
    assert env.stdin_encoding == 'utf8'

# Generated at 2022-06-11 23:28:19.129002
# Unit test for constructor of class Environment
def test_Environment():
    import io
    from pathlib import Path
    io.StringIO()
    environment = Environment(config_dir = Path('.'))
    assert environment.config_dir == Path('.'), 'Environment config_dir is not valid'
    assert environment.stdin.closed(), 'Environment stdin is not closed'
    assert environment.stdout.closed(), 'Environment stdout is not closed'



# Generated at 2022-06-11 23:28:25.012964
# Unit test for constructor of class Environment
def test_Environment():
    # 'stdin' is not in the class vars of Environment
    environment = Environment()
    environment = Environment(stdin=sys.stdin)
    print(environment)
    # environment = Environment(stdin = sys.stdout) # TypeError: __init__() got an unexpected keyword argument 'stdin'
    # print(environment)

# Generated at 2022-06-11 23:28:29.421369
# Unit test for constructor of class Environment
def test_Environment():
    # Test:
    #   Environment(devnull=None, **kwargs)
    assert Environment(is_windows=True).is_windows == True
    assert Environment(is_windows=False).is_windows == False
    assert Environment(is_windows=True).config_dir == DEFAULT_CONFIG_DIR
    assert Environment(config_dir="/test/test").config_dir == "/test/test"

# Generated at 2022-06-11 23:28:33.686356
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    env.stdin = sys.stdin
    env.stdout = sys.stdout
    env.stderr = sys.stderr
    test_value = env.config_dir

    assert str(env.config_dir) == test_value

# Generated at 2022-06-11 23:28:39.505790
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        stdin = 'stdin',
        stdout = 'stdout',
        stderr = 'stderr',
        program_name = 'http',
        config_dir = 'config_dir',
        devnull = 'devnull'
    )
    print(env)
    print(env.stdin, env.stdout, env.stderr)
    print(env.stdin_isatty, env.stdout_isatty, env.stderr_isatty)
    print(env.stdin_encoding, env.stdout_encoding)
    print(env.colors)
    print(env.program_name)
    print(env.config)
    print(env.devnull)
    print(env._orig_stderr)

# Generated at 2022-06-11 23:28:51.311483
# Unit test for constructor of class Environment
def test_Environment():
    import curses

    import httpie.config

    env = Environment(config_dir = '/Users/nathan/',
        stdin = sys.stdin,
        stdout = sys.stdout,
        stderr = sys.stderr,
        program_name = 'http')

    assert env.is_windows is False
    assert env.config_dir == '/Users/nathan/'
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert env.program_name == 'http'

    # Test the case of stdin = None
    env = Environment(stdin = None,
        stdout = sys.stdout,
        stderr = sys.stderr)

    assert env.stdin == None
   

# Generated at 2022-06-11 23:28:57.481774
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment()
    assert isinstance(e, Environment)
    assert e.is_windows == is_windows
    assert e.config_dir == DEFAULT_CONFIG_DIR
    assert e.stdin == sys.stdin
    assert e.stdout == sys.stdout
    assert e.stderr == sys.stderr


if __name__ == '__main__':
    # Unit test for init of class Environment
    test_Environment()
    print('Done!')

# Generated at 2022-06-11 23:29:08.012064
# Unit test for constructor of class Environment
def test_Environment():
    import io
    from typing import Optional

    from contextlib import contextmanager, redirect_stdout

    @contextmanager
    def open_stdout_file():
        handle, name = tempfile.mkstemp(suffix='.stdout')
        with open(name, mode='w') as file:
            yield file

    @contextmanager
    def open_stdin_file():
        handle, name = tempfile.mkstemp()
        with open(name, mode='w') as file:
            yield file

    @contextmanager
    def open_stdin_io():
        with io.StringIO() as buffer:
            yield buffer

    @contextmanager
    def open_stdout_io():
        with io.StringIO() as buffer:
            yield buffer


# Generated at 2022-06-11 23:29:12.677679
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    env.stdout = None
    env.stdout_isatty = False
    env.colors = 128
    env.devnull = True
    assert env.stdout is None
    assert env.stdout_isatty == False
    assert env.colors == 128
    assert env.devnull is True

# Generated at 2022-06-11 23:29:13.867117
# Unit test for constructor of class Environment
def test_Environment():
    a = Environment()
    assert a is not None

# Generated at 2022-06-11 23:29:37.920383
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin  # `None` when closed fd (#791)
    assert env.stdin_isatty == env.stdin.isatty()
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == env.stdout.isatty()
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == env.stderr.isatty()
    assert env.colors is not None
    assert env.program_name == 'http'

    env = Environment(devnull=True)
    assert env.is_windows == is_windows

# Generated at 2022-06-11 23:29:44.441498
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()

# Generated at 2022-06-11 23:29:48.353403
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    print(env)
    print(env.config)
    print(env._orig_stderr)
    print(env.devnull)
    print(env._devnull)
    # test function log_error()
    env.log_error(msg="test_log", level='warning')

test_Environment()

# Generated at 2022-06-11 23:29:53.024919
# Unit test for constructor of class Environment
def test_Environment():
    f1 = open('data.txt','w')
    f2 = open('data.txt','r')
    f3 = open('data.txt','w')
    env = Environment(stdin=f2,stdout=f3,stderr=f3)
    print(env)
    f1.close()
    f2.close()
    f3.close()


# Generated at 2022-06-11 23:29:57.813266
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull = 1, is_windows = False, config_dir = '/root')
    if env.is_windows:
        assert env.config_dir == '/root'
        assert env.devnull == 1
    else:
        assert env.config_dir == '/root'
        assert env.devnull == 1


# Generated at 2022-06-11 23:30:00.318667
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin_encoding=1)
    assert env.stdin_encoding == 1
    assert env.is_windows



# Generated at 2022-06-11 23:30:10.618872
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=is_windows)
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin

    if hasattr(sys.stdin, 'isatty'):
        assert env.stdin_isatty == sys.stdin.isatty()
    else:
        # For example, stdin is a StringIO when running unittests
        assert env.stdin_isatty is False

    assert env.stdin_encoding is None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding is None
    assert env.stderr == sys.st

# Generated at 2022-06-11 23:30:14.241491
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=0, stdin=0, stdout=0, stderr=0, stdin_encoding='utf8')
    assert env.devnull is 0
    assert env.stdin is 0
    assert env.stdout is 0
    assert env.stderr is 0
    assert env.stdin_encoding is 'utf8'

# Generated at 2022-06-11 23:30:21.206304
# Unit test for constructor of class Environment
def test_Environment():
    print(Environment(devnull=None, is_windows=True, config_dir=Path('C:/Users/mahesh/AppData/Local/HTTPie/default'), stdin=sys.stdin, stdin_isatty=True, stdin_encoding=None, stdout=sys.stdout, stdout_isatty=True, stdout_encoding=None, stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http', _orig_stderr=sys.stderr, _devnull=None))

# Generated at 2022-06-11 23:30:25.443603
# Unit test for constructor of class Environment
def test_Environment():
    environ = Environment(stdin=open(os.path.devnull,'r'))
    assert environ.stdin.name == os.path.devnull
    assert environ.stdin_encoding == 'utf-8'

# Generated at 2022-06-11 23:30:42.805919
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().stdin.read() == sys.stdin.read()
    assert Environment().stdout.read() == sys.stdout.read()
    assert Environment().stderr.read() == sys.stderr.read()

# Generated at 2022-06-11 23:30:52.971254
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=2)
    assert env.is_windows == is_windows
    assert env.devnull == 2
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == env.stdin.isatty()
    assert env.stdin_encoding == getattr(env.stdin, 'encoding', None)

    assert env.stdout == sys.stdout
    assert env.stdout_isatty == env.stdout.isatty()
    assert env.stdout_encoding == getattr(env.stdout, 'encoding', None)

    assert env.stderr == sys.stderr
    assert env.stderr_isatty == env.stderr.isatty

# Generated at 2022-06-11 23:31:02.038067
# Unit test for constructor of class Environment
def test_Environment():
    import builtins
    e = Environment(devnull='test_devnull',
        stdin=False,
        stdin_isatty=None,
        stdin_encoding=None,
        stdout=None,
        stdout_isatty=None,
        stdout_encoding='utf8',
        stderr=False,
        stderr_isatty=None,
        program_name='test_program_name',
        config_dir='test_config_dir',
        _orig_stderr=None,
        _devnull=None,
        _config='test_config',
        is_windows='test_is_windows',
        colors='test_colors'
        )
    # Check if all of the overwritten attributes are changed
    assert e.devnull == 'test_devnull'


# Generated at 2022-06-11 23:31:04.242125
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    print(env)
    d = dict(a=1, b=2, c=3)
    env = Environment(**d)
    print(env)

# Generated at 2022-06-11 23:31:13.347147
# Unit test for constructor of class Environment
def test_Environment():
    try:
        env = Environment(
            config_dir=Path("this/directory/is/not/exist/"),
            stdin=None,
            stdin_isatty=False,
            stdin_encoding=None,
            stdout=sys.stdout,
            stdout_isatty=True,
            stdout_encoding=None,
            stderr=sys.stderr,
            stderr_isatty=True,
            colors=256,
            program_name='http',
            devnull=None,
          )
        print(env)
    except Exception as e:
        print(e)

if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-11 23:31:14.897130
# Unit test for constructor of class Environment
def test_Environment():
    _ = Environment()

if __name__ == "__main__":
    test_Environment()

# Generated at 2022-06-11 23:31:23.615605
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows == is_windows
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == sys.stdin.isatty() if sys.stdin else False
    assert environment.stdin_encoding == None
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == sys.stdout.isatty()
    assert environment.stdout_encoding == None
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == sys.stderr.isatty()
    assert environment.colors == 256
    assert environment.program_name == 'http'
    assert environment.stdin == sys.std

# Generated at 2022-06-11 23:31:27.719992
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        devnull=None,
        program_name='http',
        config_dir=DEFAULT_CONFIG_DIR
    )
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.program_name == 'http'

# Generated at 2022-06-11 23:31:29.878713
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.stdin
    assert env.stdout
    assert env.stderr

# Generated at 2022-06-11 23:31:37.746544
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.stdin.encoding == 'utf8'
    assert env.stdout.encoding == 'utf8'
    assert env.stderr.encoding == 'utf8'
    assert env.colors == 256
    assert env.program_name == 'http'


# Generated at 2022-06-11 23:32:15.782693
# Unit test for constructor of class Environment
def test_Environment():
    env=Environment(stdin=None, stdin_isatty=False, stdin_encoding=None, stdout_isatty=True, stdout_encoding=None, stderr_isatty=True, config_dir='/home/xuji/.httpie')
    print(env)

if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-11 23:32:18.602497
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert not isinstance(env, Environment)

if __name__ == "__main__":
    test_Environment()

# Generated at 2022-06-11 23:32:27.368684
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(program_name='httpie', stdout=sys.stdout, stderr=sys.stderr, stdin=sys.stdin, config_dir='config_dir', stdin_encoding='stdin_encoding', stdout_encoding='stdout_encoding', stderr_encoding='stderr_encoding')
    print(environment.program_name)
    print(environment.stdin)
    print(environment.stdout)
    print(environment.stderr)
    print(environment.config_dir)
    print(environment.stdin_encoding)
    print(environment.stdout_encoding)
    print(environment.stderr_encoding)

ENV = Environment()

# Generated at 2022-06-11 23:32:36.362847
# Unit test for constructor of class Environment