

# Generated at 2022-06-11 23:22:51.062547
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows != None
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin.isatty() == env.stdin_isatty
    assert env.stdout.isatty() == env.stdout_isatty
    assert env.stderr.isatty() == env.stderr_isatty
    assert env.colors == 256
    assert env.program_name == 'http'

    if is_windows:
        assert env.stdin_encoding == 'utf8'
        assert env.stdout_encoding == 'utf8'
        assert env.stderr_encoding == 'utf8'
    else:
        assert env.stdin_encoding == None
        assert env.stdout_encoding == None


# Generated at 2022-06-11 23:23:00.624606
# Unit test for constructor of class Environment
def test_Environment():

    env = Environment(devnull=True, **{
        'config_dir': DEFAULT_CONFIG_DIR,
        'stdin': sys.stdin,
        'stdin_isatty': sys.stdin.isatty(), 
        'stdin_encoding': None, 
        'stdout': sys.stdout,
        'stdout_isatty': sys.stdout.isatty(), 
        'stdout_encoding': None,
        'stderr': sys.stderr,
        'stderr_isatty': sys.stderr.isatty(), 
        'colors': 256,
        'program_name': 'http'
    })

    env.devnull = True
    assert isinstance(env._devnull, IO)

    env._config = None

# Generated at 2022-06-11 23:23:06.253950
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(foo='bar')
    assert env.foo == 'bar'
    assert env.stdin is sys.stdin
    assert env.stdout is sys.stdout
    assert env.stderr is sys.stderr
    env = Environment(foo='bar', stdin=None, stdout=None, stderr=None)
    assert env.foo == 'bar'
    assert env.stdin is None
    assert env.stdout is None
    assert env.stderr is None


# Generated at 2022-06-11 23:23:16.492751
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=open(os.devnull, 'w+'), colors=256, program_name='http')
    assert env.devnull == open(os.devnull, 'w+')
    assert env.colors == 256
    assert env.program_name == 'http'
    # Testing when the config directory is new
    assert env.config.is_new() == True
    # Testing when the config directory is not new
    env.config_dir = Path(__file__).parent
    assert env.config.is_new() == False
    # Testing the repr_dict method
    dict_actual = {"colors": 256, "program_name": "http", "config": env.config}

# Generated at 2022-06-11 23:23:19.421131
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name='http', stdout_encoding='a')
    assert env.stdout_encoding == 'a'
    assert env.program_name == 'http'


environ = Environment()

# Generated at 2022-06-11 23:23:22.629476
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdout=None, stderr=None)
    assert env.stdin is None
    assert env.stdout is None
    assert env.stderr is None

# Generated at 2022-06-11 23:23:34.062613
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment.devnull is None
    assert Environment.stdin == sys.__stdin__
    assert Environment.stdout == sys.__stdout__
    assert Environment.stderr == sys.__stderr__
    assert Environment().stdout == sys.__stdout__
    assert Environment(stdout=sys.__stderr__).stdout == sys.__stderr__
    assert isinstance(Environment().config, Config)

# Generated at 2022-06-11 23:23:34.930818
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment()

# Generated at 2022-06-11 23:23:46.990401
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        stdin=object(),
        stdin_isatty=False,
        stdin_encoding='iso8859-1',
        stdout=object(),
        stdout_isatty=False,
        stdout_encoding='iso8859-1',
        stderr=object(),
        stderr_isatty=False,
        program_name='httpie',
        devnull=object(),
        config_dir=object(),
    )
    assert env.stdin
    assert not env.stdin_isatty
    assert env.stdin_encoding == 'iso8859-1'
    assert env.stdout
    assert not env.stdout_isatty
    assert env.stdout_encoding == 'iso8859-1'
    assert env.stderr


# Generated at 2022-06-11 23:23:49.194021
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment.is_windows == is_windows
    print("Environment constructor passed!")

test_Environment()

# Generated at 2022-06-11 23:24:10.701538
# Unit test for constructor of class Environment
def test_Environment():

    my_env = Environment(devnull="this is a devnull", is_windows=False, config_dir="this is my config dir", stdin="this is stdin", stdin_isatty=False, stdin_encoding="this is my encoding", stdout="this is my stdout", stdout_isatty=False, stdout_encoding="this is my stdout encoding", stderr="this is my stderr", stderr_isatty=False, colors=123, program_name="this is my program name")

    assert my_env.devnull == "this is a devnull"
    assert my_env.is_windows == False
    assert my_env.config_dir == "this is my config dir"
    assert my_env.stdin == "this is stdin"
    assert my_env.stdin_

# Generated at 2022-06-11 23:24:16.938625
# Unit test for constructor of class Environment
def test_Environment():
    import sys
    from httpie.environment import Environment
    stderr = sys.stderr
    env = Environment(stderr=stderr)
    assert env.stderr == stderr

from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
if __name__ == '__main__':
    env = Environment()
    env.log_error(BINARY_SUPPRESSED_NOTICE)

# Generated at 2022-06-11 23:24:27.758993
# Unit test for constructor of class Environment
def test_Environment():
    """
    Unit test for constructor of class Environment
    """
    a = Environment()
    print(a)
    b = Environment(is_windows=False)
    print(b)
    c = Environment(is_windows=False, config_dir=False)
    print(c)
    d = Environment(is_windows=False, config_dir=False, stdin=False)
    print(d)
    e = Environment(is_windows=False, config_dir=False, stdin=False, stdin_isatty=False)
    print(e)
    f = Environment(is_windows=False, config_dir=False, stdin=False, stdin_isatty=False, stdin_encoding=False)
    print(f)

# Generated at 2022-06-11 23:24:38.163707
# Unit test for constructor of class Environment
def test_Environment():
    class A:
        pass
    a = A()
    a.stdin_encoding = 'stdin_encoding'
    a.stdout_encoding = 'stdout_encoding'
    a.stdin_isatty = 'stdin_isatty'
    a.stdout_isatty = 'stdout_isatty'
    a.stderr_isatty = 'stderr_isatty'
    a.include_null_header = 'include_null_header'
    a.colors = 'colors'
    a.program_name = 'program_name'
    a.is_windows = 'is_windows'
    a.config_dir = 'config_dir'
    a.stdin = 'stdin'
    a.stdout = 'stdout'

# Generated at 2022-06-11 23:24:48.968246
# Unit test for constructor of class Environment
def test_Environment():
    config_dir = Path(r'D:\Programmes\Python\httpie')
    stdin = sys.stdin
    stdin_isatty = stdin.isatty()
    stdin_encoding = getattr(stdin, 'encoding', None) or 'utf8'
    stdout = sys.stdout
    stdout_isatty = stdout.isatty()
    stdout_encoding = getattr(stdout, 'encoding', None) or 'utf8'
    stderr = sys.stderr
    stderr_isatty = stderr.isatty()

    actual_stdout = stdout
    # global is_windows
    # if is_windows:
    #     import colorama.initialise
    #     stdout = colorama.initialise.wrap_stream(

# Generated at 2022-06-11 23:24:56.052716
# Unit test for constructor of class Environment
def test_Environment():
    from io import StringIO
    from pathlib import Path
    env = Environment()
    assert is_windows == env.is_windows
    assert DEFAULT_CONFIG_DIR == env.config_dir
    assert sys.stdin == env.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert str('utf8') == env.stdin_encoding
    assert sys.stdout == env.stdout
    if is_windows:
        import colorama.initialise
        assert env.stdout_isatty == colorama.initialise.wrap_stream(sys.stdout, convert=None, strip=None, autoreset=True, wrap=True).isatty()
    else:
        assert env.stdout_isatty == sys.stdout.isatty()
   

# Generated at 2022-06-11 23:25:04.122998
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()

# Generated at 2022-06-11 23:25:12.648825
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        is_windows=True,
        stdin = sys.stdin,
        stdin_encoding = sys.stdin.encoding,
        stdout = sys.stdout,
        stdout_encoding = sys.stdout.encoding,
        stderr = sys.stderr,
        colors=256,
        program_name='http'
    )

# Generated at 2022-06-11 23:25:23.128755
# Unit test for constructor of class Environment
def test_Environment():
    # list all default attributes
    default_atrs = [
        'is_windows',
        'config_dir',
        'stdin',
        'stdin_isatty',
        'stdin_encoding',
        'stdout',
        'stdout_isatty',
        'stdout_encoding',
        'stderr',
        'stderr_isatty',
        'colors',
        'program_name',
    ]
    # environment class without initialization
    env = Environment()
    # check standard attributes
    for attr in default_atrs:
        assert hasattr(env, attr)
    # test an attribute has right value
    assert env.is_windows is True
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin is sys.std

# Generated at 2022-06-11 23:25:31.057514
# Unit test for constructor of class Environment
def test_Environment():
    if not is_windows:
        if curses:
            try:
                curses.setupterm()
                colors = curses.tigetnum('colors')
            except curses.error:
                pass
    else:
        # noinspection PyUnresolvedReferences
        import colorama.initialise
        stdout = colorama.initialise.wrap_stream(
            stdout, convert=None, strip=None,
            autoreset=True, wrap=True
        )
        stderr = colorama.initialise.wrap_stream(
            stderr, convert=None, strip=None,
            autoreset=True, wrap=True
        )
        del colorama
    assert  Environment().stdout_isatty is True
    assert  Environment().stderr_isatty is True

# Generated at 2022-06-11 23:25:57.645873
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    env1 = Environment(devnull=None, is_windows=True, config_dir=Path('.'), stdin=None, stdin_isatty=True, stdin_encoding=None, stdout=None, stdout_isatty=True, stdout_encoding=None, stderr=None, stderr_isatty=True, colors=256, program_name='http', _orig_stderr=None, _devnull=None)
    assert isinstance(env.config_dir, Path)
    assert isinstance(env.stdin, Optional[IO])
    assert isinstance(env.stdin_isatty, bool)
    assert isinstance(env.stdin_encoding, str)
    assert isinstance(env.stdout, IO)

# Generated at 2022-06-11 23:26:07.147333
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == env.stdin.isatty()
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == env.stdout.isatty()
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == env.stderr.isatty()
    assert env.program_name == 'http'
    assert env.config == Config(directory = DEFAULT_CONFIG_DIR)
    assert env.config.is_new() == False

# Generated at 2022-06-11 23:26:08.925109
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdout=None)
    assert env.stdout is None


# Generated at 2022-06-11 23:26:19.382430
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment( is_windows = True,
                               config_dir = 'C:\\Users\\',
                               stdin = None,
                               stdin_isatty = False,
                               stdin_encoding = None,
                               stdout = sys.stdout,
                               stdout_isatty = True,
                               stdout_encoding = None,
                               stderr = sys.stderr,
                               stderr_isatty = True,
                               colors = True,
                               program_name = 'http')
    assert(environment.is_windows == True)
    assert(environment.config_dir == 'C:\\Users\\')
    assert(environment.stdin == None)
    assert(environment.stdin_isatty == False)

# Generated at 2022-06-11 23:26:26.307823
# Unit test for constructor of class Environment
def test_Environment():
    assert repr(Environment()) == repr(Environment.default())
    env = Environment(stdin=None, stdin_isatty=False, stdin_encoding='utf8',
                      stdout=sys.stdout, stdout_isatty=True, stdout_encoding=None,
                      stderr=sys.stderr, stderr_isatty=True,
                      is_windows=True,
                      config_dir='/home/blah/.config/httpie',
                      program_name='httpie')
    assert repr(env) == repr(Environment())

# Generated at 2022-06-11 23:26:36.758320
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name='http', colors=256, config_dir='/home/httpie', stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr)
    assert str(env) == "'program_name': 'http', 'is_windows': False, 'config_dir': '/home/httpie', 'stdin': <class '_io.TextIOWrapper'>\n", "Wrong implementation of __str__"
    env.__dict__.update(**{'program_name': 'http', 'is_windows': False, 'config_dir':'/home/httpie', 'stdin': sys.stdin, 'stdout': sys.stdout, 'stderr': sys.stderr})

# Generated at 2022-06-11 23:26:43.307082
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    if is_windows:
        assert env.colors == 256
        assert env.program_name == 'http'

# Generated at 2022-06-11 23:26:53.936559
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(is_windows='True',
                              config_dir=DEFAULT_CONFIG_DIR,
                              stdin=sys.stdin,
                              stdin_isatty=True,
                              stdin_encoding='utf8',
                              stdout=sys.stdout,
                              stdout_isatty=True,
                              stdout_encoding='utf8',
                              stderr=sys.stderr,
                              stderr_isatty=True,
                              colors=256,
                              program_name='http')


# Generated at 2022-06-11 23:26:59.234173
# Unit test for constructor of class Environment
def test_Environment():
    env_new = Environment(devnull='New devnull', stdout='New stdout')
    env_empty = Environment()
    env_default = Environment(stdout='Default stdout')
    assert env_new.devnull is env_empty.devnull is 'New devnull'
    assert env_default.stdout is 'Default stdout'
    assert env_empty.stdout is not 'New stdout'

# Generated at 2022-06-11 23:27:10.215247
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull="devnull", stdin="stdin", stdin_encoding="stdin_encoding",
                      stdout="stdout", stdout_encoding="stdout_encoding", stderr="stderr",
                      is_windows=True)
    # print("devnull: ", env.devnull)
    # print("stdin: ", env.stdin)
    # print("stdin_encoding: ", env.stdin_encoding)
    # print("stdout: ", env.stdout)
    # print("stdout_encoding: ", env.stdout_encoding)
    # print("stderr: ", env.stderr)
    # print("is_windows: ", env.is_windows)
    # print("config_dir: ", env.config_dir)
    # print

# Generated at 2022-06-11 23:27:52.162462
# Unit test for constructor of class Environment
def test_Environment():
    # testing constructor of Environment
    e = Environment(stdin=True, stderr=False)
    assert e.stdin == True
    assert e.stderr == False
    assert e._orig_stderr == sys.stderr
    assert e._devnull == None
    assert e.config_dir == DEFAULT_CONFIG_DIR
    assert e.stdin_isatty == True
    assert e.stdout_isatty == True
    assert e.stderr_isatty == False


# Generated at 2022-06-11 23:28:01.896679
# Unit test for constructor of class Environment
def test_Environment():
    test = Environment()
    assert test.is_windows == is_windows  # Test is_windows
    assert test.config_dir == DEFAULT_CONFIG_DIR  # Test config_dir
    assert test.stdin == sys.stdin  # Test stdin
    assert test.stdin_isatty == sys.stdin.isatty()  # Test stdin_isatty
    assert test.stdin_encoding == None  # Test stdin_encoding
    assert test.stdout == sys.stdout  # Test stdout
    assert test.stdout_isatty == sys.stdout.isatty()  # Test stdout_isatty
    assert test.stdout_encoding == None  # Test stdout_encoding
    assert test.stderr == sys.stderr  # Test stderr

# Generated at 2022-06-11 23:28:12.417240
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == (sys.stdin.isatty() if sys.stdin else False)
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256

# Generated at 2022-06-11 23:28:23.547480
# Unit test for constructor of class Environment
def test_Environment():

    env = Environment(
        is_windows = False,
        config_dir = Path(),
        stdin = None,
        stdin_isatty = False,
        stdin_encoding = None,
        stdout = sys.stdout,
        stdout_isatty = sys.stdout.isatty(),
        stdout_encoding = None,
        stderr = sys.stderr,
        stderr_isatty = sys.stderr.isatty(),
        colors = 0,
        program_name = 'http'
    )

    assert env != None
    assert env.is_windows == False
    assert env.config_dir == Path()
    assert env.stdin == None
    assert env.stdin_isatty == False
    assert env.stdin_encoding == None


# Generated at 2022-06-11 23:28:29.248248
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert hasattr(env, 'stdin')
    assert hasattr(env, 'stdin_isatty')
    assert hasattr(env, 'stdout')
    assert hasattr(env, 'stdout_isatty')
    assert hasattr(env, 'stderr')
    assert hasattr(env, 'stderr_isatty')
    assert hasattr(env, 'colors')
    assert hasattr(env, 'config_dir')
    assert hasattr(env, 'program_name')
    assert hasattr(env, 'config_dir')


# Generated at 2022-06-11 23:28:32.041422
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows

    env = Environment(is_windows=not env.is_windows)
    assert env.is_windows != is_windows

# Generated at 2022-06-11 23:28:39.387070
# Unit test for constructor of class Environment
def test_Environment():
    assert str(Environment()) == '{\'config\': <Config {\'directory\': Path(\'/Users/wmy/.httpie\')}>, \'is_windows\': False, \'program_name\': \'http\', \'config_dir\': Path(\'/Users/wmy/.httpie\'), \'colors\': 256, \'stdout_isatty\': True, \'stderr_isatty\': True, \'stdin_isatty\': True, \'stdout_encoding\': \'UTF-8\', \'stdin_encoding\': \'UTF-8\', \'stderr_encoding\': \'UTF-8\'}'

# Generated at 2022-06-11 23:28:48.125767
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.colors == 256
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin_encoding == 'utf8'
    assert env.stdout_encoding == 'utf8'
    assert env.stderr_encoding == 'utf8'
    if not is_windows:
        assert env.stdin_isatty == True
        assert env.stdout_isatty == True
        assert env.stderr_isatty == True



# Generated at 2022-06-11 23:28:58.103843
# Unit test for constructor of class Environment
def test_Environment():
    test_stdin = sys.stdin
    test_stdout = sys.stdout
    test_stderr = sys.stderr
    test_devnull = 'test_devnull'
    test_colors = 16
    test_program_name = 'test_http'
    test_is_windows = True
    test_config_dir = 'test_config_dir'

    test_kwargs = {'stdin': test_stdin, 'stdout': test_stdout, 'stderr': test_stderr,
                   'devnull': test_devnull, 'colors': test_colors, 'program_name': test_program_name,
                   'is_windows': test_is_windows, 'config_dir': test_config_dir}

    result = Environment(**test_kwargs)
    expected

# Generated at 2022-06-11 23:29:08.718045
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == (getattr(sys.stdout,'encoding','utf8'))
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.program_name == 'http'

# Generated at 2022-06-11 23:30:25.168480
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdout=sys.stderr, stderr=sys.stdout)
    assert env.stdout is sys.stderr
    assert env.stderr is sys.stdout

# Generated at 2022-06-11 23:30:34.187048
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty() if env.stdin else False
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'

# Generated at 2022-06-11 23:30:42.368662
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment()
    assert e.is_windows is True or False
    assert isinstance(e.config_dir, Path)
    assert e.stdin is sys.stdin
    assert e.stdin_isatty is True or False
    assert isinstance(e.stdin_encoding, str)
    assert e.stdout is sys.stdout
    assert e.stdout_isatty is True or False
    assert isinstance(e.stdout_encoding, str)
    assert e.stderr is sys.stderr
    assert e.stderr_isatty is True or False
    assert isinstance(e.program_name, str)
    assert e.colors == 256 or True or False

# Generated at 2022-06-11 23:30:50.943229
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == (
        256 if curses and not is_windows else 0
    )


# Generated at 2022-06-11 23:30:53.159529
# Unit test for constructor of class Environment
def test_Environment():
    my_env = Environment(stdin_isatty=False,
                        stdout_isatty=False)
    assert my_env.stdin_isatty



# Generated at 2022-06-11 23:31:02.236024
# Unit test for constructor of class Environment
def test_Environment():
    from httpie.output.streams import StdoutBytesIO
    from test import mock

    class FakeStream:
        def isatty(self):
            return True
        def write(self, data):
            pass

    with mock.patch('sys.stdout', new=FakeStream()):
        with mock.patch('sys.stderr', new=FakeStream()):
            with mock.patch('sys.stdin', new=FakeStream()):
                try:
                    curses_setupterm = curses.setupterm
                    curses_tigetnum = curses.tigetnum
                except curses.error:
                    pass
                else:
                    with mock.patch('curses.setupterm', return_value=0):
                        with mock.patch('curses.tigetnum', return_value=0):
                            print(Environment())


# Generated at 2022-06-11 23:31:11.985233
# Unit test for constructor of class Environment
def test_Environment():
    #__init__
    env = Environment(devnull=0, is_windows=True)
    #str, repr
    s_repr = str(env)
    assert type(s_repr) == "<class 'str'>"
    s_repr = repr(env)
    assert type(s_repr) == "<class 'str'>"
    #config
    config = env.config
    assert type(config) == Config
    #devnull
    devnull = env.devnull
    assert type(devnull) == _io.BufferedWriter
    #devnull = env.devnull
    #assert type(devnull) == BufferedWriter
    #devnull
    env.devnull = 0
    assert type(env.devnull) == int
    #log_error
    env.log_error("error")
   

# Generated at 2022-06-11 23:31:21.838194
# Unit test for constructor of class Environment
def test_Environment():
    import io
    import tempfile
    with tempfile.TemporaryDirectory() as dirname:
        devnull_fp = open(os.devnull, 'w+')
        env = Environment(
            program_name='httpie_test',
            is_windows=False,
            config_dir=Path(dirname),
            stdin=io.StringIO(),
            stdin_isatty=True,
            stdin_encoding='utf8',
            stdout=sys.stdout,
            stdout_isatty=True,
            stdout_encoding='utf8',
            stderr=sys.stderr,
            stderr_isatty=True,
            colors=256,
            devnull=devnull_fp,
        )
        assert env.program_name == 'httpie_test'


# Generated at 2022-06-11 23:31:31.393805
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(is_windows=True, config_dir='/data/config')
    assert env.is_windows
    assert env.config_dir == '/data/config'
    assert env.stdin is None
    assert env.stdin_isatty is False
    assert env.stdin_encoding == 'utf8'
    assert env.stdout is not None
    assert env.stdout_isatty is True
    assert env.stdout_encoding == 'utf8'
    assert env.stderr is not None
    assert env.stderr_isatty is True
    assert env.colors == 256
    assert env.program_name == 'http'

# Generated at 2022-06-11 23:31:34.597952
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name='http')
    assert env.program_name == 'http'
    assert env.stderr == sys.stderr
    assert env.stdout == sys.stdout
    assert env.stdin == sys.stdin
