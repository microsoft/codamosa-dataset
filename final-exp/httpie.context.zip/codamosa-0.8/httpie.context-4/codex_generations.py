

# Generated at 2022-06-11 23:22:46.681159
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment.stdin is sys.stdin
    assert Environment.stdout is sys.stdout
    assert Environment.stderr is sys.stderr
    new_env = Environment(stdout=io.TextIOWrapper(io.BytesIO()))
    assert new_env.stdout is not sys.stdout


environment = Environment()

# Generated at 2022-06-11 23:22:51.168872
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name = 'http', devnull = None, is_windows = False, config_dir = DEFAULT_CONFIG_DIR, stdin = sys.stdin, stdin_isatty = False, stdout = sys.stdout, stdout_isatty = False, stderr = sys.stderr, stderr_isatty = False, colors = 256)
    print(env)

# Generated at 2022-06-11 23:23:00.758710
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert is_windows == env.is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == 'utf8'
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr == sys

# Generated at 2022-06-11 23:23:08.062012
# Unit test for constructor of class Environment
def test_Environment():
    import sys
    import os
    env = Environment(stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr)
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.stdin_encoding is None
    assert env.stdout_encoding is None
    assert env.stderr_encoding is None
    env.config_dir = os.getcwd()
    assert env.config

# Generated at 2022-06-11 23:23:18.529642
# Unit test for constructor of class Environment
def test_Environment():
    # Testing the default value of the class attributes
    actual_default_value = Environment(devnull=None)
    assert actual_default_value.is_windows == is_windows
    assert actual_default_value.stdin == sys.stdin
    assert actual_default_value.stdout == sys.stdout
    assert actual_default_value.stderr == sys.stderr

    # Testing the overwritten value of the class attributes
    actual_overwritten_value = Environment(devnull=None, is_windows=False, stdin=None, stdout=None, stderr=None)
    assert actual_overwritten_value.is_windows == False
    assert actual_overwritten_value.stdin == None
    assert actual_overwritten_value.stdout == None
    assert actual_overwritten_value.stderr == None

# Generated at 2022-06-11 23:23:27.579503
# Unit test for constructor of class Environment
def test_Environment():
    import sys
    import os
    from pathlib import Path
    from typing import IO
    env = Environment()

    assert env.is_windows
    assert env.config_dir
    assert env.stdin
    assert env.stdin_isatty
    assert env.stdin_encoding
    assert env.stdout
    assert env.stdout_isatty
    assert env.stdout_encoding
    assert env.stderr
    assert env.stderr_isatty
    assert env.colors
    assert env.program_name
    assert env._orig_stderr
    assert env._devnull
    
    


env = Environment()

# Generated at 2022-06-11 23:23:37.388534
# Unit test for constructor of class Environment
def test_Environment():
    #add by hxh
    def isatty_true():
        return True
    def isatty_false():
        return False
    #add over
    environ = Environment()
    assert environ.stdin == sys.stdin
    assert environ.stdin_encoding == 'utf8'
    assert environ.stdout == sys.stdout
    assert environ.stdout_encoding == 'utf8'
    assert environ.stderr == sys.stderr
    assert environ.program_name == 'http'
    assert environ.stdin_isatty == sys.stdin.isatty()
    assert environ.stdout_isatty == sys.stdout.isatty()
    assert environ.stderr_isatty == sys.stderr.isatty()

# Generated at 2022-06-11 23:23:46.093631
# Unit test for constructor of class Environment
def test_Environment():
    print("Testing Environment class")
    # TODO: add assertion here
    env = Environment(devnull=None, is_windows=True, config_dir=".httpie", stdin=sys.stdin, stdin_isatty=False, stdin_encoding="utf8", stdout=sys.stdout, stdout_isatty=False, stdout_encoding="utf8", stderr=sys.stderr, stderr_isatty=False, colors=256, program_name="http")


if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-11 23:23:48.099410
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert isinstance(env, Environment)

# Generated at 2022-06-11 23:23:58.579940
# Unit test for constructor of class Environment
def test_Environment():
    import os
    env = Environment(
        devnull = 1,
        is_windows = 2,
        config_dir = 3,
        stdin = 4,
        stdin_isatty = 5,
        stdin_encoding = 6,
        stdout = 7,
        stdout_isatty = 8,
        stdout_encoding = 9,
        stderr = 10,
        stderr_isatty = 11,
        colors = 12,
        program_name = 13,
    )
    assert env.devnull == 1
    assert env.is_windows == 2
    assert env.config_dir == 3
    assert env.stdin == 4
    assert env.stdin_isatty == 5
    assert env.stdin_encoding == 6
    assert env.stdout == 7
   

# Generated at 2022-06-11 23:24:15.752581
# Unit test for constructor of class Environment
def test_Environment():
    # case 1: default
    default_value = {
        'is_windows': False,
        'config_dir': '/home/howard/.config/httpie',
        'stdin': sys.stdin,
        'stdin_isatty': True,
        'stdin_encoding': 'utf8',
        'stdout': sys.stdout,
        'stdout_isatty': True,
        'stdout_encoding': 'utf8',
        'stderr': sys.stderr,
        'stderr_isatty': True,
        'colors': None
    }
    default_env = Environment()
    for k, v in default_env.__dict__.items():
        assert v == default_value[k]
        
    # case 2: overwrite valid attribute

# Generated at 2022-06-11 23:24:17.414116
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin = sys.stdin, stdout = sys.stdout, stderr = sys.stderr)
    print(env)

# Generated at 2022-06-11 23:24:23.446012
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment()
    e = Environment(stdin=open("文件名.md", "r", encoding='utf-8'), config_dir='./config_dir')
    assert os.path.exists("文件名.md")
    assert e.config_dir == "./config_dir"
    os.remove("文件名.md")

# Generated at 2022-06-11 23:24:33.935553
# Unit test for constructor of class Environment
def test_Environment():
    import io
    import tempfile
    import random
    integer = random.randint(0,100)
    temp = tempfile.TemporaryFile()
    env = Environment(is_windows=bool(integer%2), config_dir=temp, stdin=io.StringIO("abcde"), stdin_isatty=bool(integer%2), stdin_encoding="utf-8", stdout=io.StringIO("fghij"), stdout_isatty=bool(integer%2), stdout_encoding="utf-8", stderr=io.StringIO("klmno"), stderr_isatty=bool(integer%2), colors=integer, program_name="why")
    assert env.is_windows==(integer%2)
    assert env.config_dir==temp
    assert env.stdin.getvalue()

# Generated at 2022-06-11 23:24:43.673597
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        stdin = False,
        stdout = True,
        stderr = False,
        config_dir = Path('/config')
    )
    assert env.stdin == False
    assert env.stdin_encoding == None
    assert env.stdin_isatty == False
    assert env.stdout == True
    assert env.stdout_encoding == None
    assert env.stdout_isatty == True
    assert env.stderr == False
    assert env.stderr_isatty == False
    assert env.config_dir == Path('/config')
    assert env.program_name == 'http'
    assert env.is_windows == False

# Generated at 2022-06-11 23:24:50.957822
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name='http')
    print(sys.stdout.isatty())
    print(sys.stderr.isatty())
    print(env)
#     <Environment
#         stdin_isatty=False,
#         stdout_isatty=True,
#         stderr_isatty=True,
#         colors=256,
#         program_name=http,
#         config=<Config
#             directory=C:\Users\Lore\AppData\Roaming\httpie\,
#             config=None
#         >
#     >

# Generated at 2022-06-11 23:25:01.876501
# Unit test for constructor of class Environment
def test_Environment():

  #default value test
  env = Environment()
  assert env.is_windows == is_windows
  assert env.config_dir == DEFAULT_CONFIG_DIR
  assert env.stdin  == sys.stdin
  assert env.stdin_isatty == env.stdin.isatty()
  assert env.stdin_encoding == None
  assert env.stdout == sys.stdout
  assert env.stdout_isatty == env.stdout.isatty()
  assert env.stdout_encoding == None
  assert env.stderr == sys.stderr
  assert env.stderr_isatty == env.stderr.isatty()
  assert env.colors == 256
  assert env.program_name == 'http'

# Generated at 2022-06-11 23:25:11.254071
# Unit test for constructor of class Environment
def test_Environment():
    # Default value
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == env.stdin.isatty() if env.stdin else False
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == env.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == env.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig

# Generated at 2022-06-11 23:25:14.069715
# Unit test for constructor of class Environment
def test_Environment():
    assert repr(Environment(foo='bar')) == "<Environment {'foo': 'bar'}>"


# Generated at 2022-06-11 23:25:16.688430
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    print(env)
    print(env.__dict__)


# Generated at 2022-06-11 23:25:33.806436
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(is_windows=False, colors=256,
                      program_name='curl', stdin=None,
                      stdout=sys.stdout, stderr=sys.stderr,_orig_stderr=sys.stderr)
    assert env.is_windows == False
    assert env.colors == 256
    assert env.program_name == 'curl'
    assert env.stdin is None
    assert env.stdout is sys.stdout
    assert env.stderr is sys.stderr
    assert env._orig_stderr is sys.stderr
    assert env._devnull is None
    assert env._config is None

# Generated at 2022-06-11 23:25:43.163661
# Unit test for constructor of class Environment
def test_Environment():
    # Test that the STDIN, STDOUT, and STDERR are set up during the creation of
    # an Environment object
    env = Environment()
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr

    # Test that the devnull attribute is initialized to None
    assert env._devnull is None

    # Test that the colors attribute is initialized to 256
    assert env.colors == 256

    # Test that the _orig_stderr attribute is initialized to the instance's
    # stderr attribute
    assert env._orig_stderr == sys.stderr

    # Test that the program_name attribute is initialized to 'http'
    assert env.program_name == 'http'

    # Test that the is_windows attribute is initialized to the value

# Generated at 2022-06-11 23:25:53.550448
# Unit test for constructor of class Environment
def test_Environment():
	env = Environment()
	assert env.stdin is sys.stdin
	assert env.stdin_isatty
	assert env.stdin_encoding == sys.stdin.encoding
	assert env.stdout is sys.stdout
	assert env.stdout_isatty
	assert env.stdout_encoding == sys.stdout.encoding
	assert env.stderr is sys.stderr
	assert env.stderr_isatty
	assert env.colors
	assert env.program_name is 'http'
	assert env.is_windows == is_windows
	assert env.devnull is None 
	assert env._devnull is None 
	assert env._orig_stderr is sys.stderr
	assert env.config_dir == DEFAULT_CONFIG_DIR

# Generated at 2022-06-11 23:26:03.294795
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull='a', is_windows=True, config_dir=Path('./httpie'))

# Generated at 2022-06-11 23:26:13.560485
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=os.devnull, stdout='DEBUG', stderr='DEBUG')
    assert isinstance(env, Environment)

# Generated at 2022-06-11 23:26:23.515126
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment(is_windows = False,
                    config_dir = "/Users/felixchen/.httpie",
                    stdin = sys.stdin,
                    stdin_isatty = sys.stdin.isatty(),
                    stdin_encoding = "UTF-8",
                    stdout = sys.stdout,
                    stdout_isatty = sys.stdout.isatty(),
                    stdout_encoding = "UTF-8",
                    stderr = sys.stderr,
                    stderr_isatty = sys.stderr.isatty(),
                    colors = 1,
                    program_name = "httpie")
    print(e.is_windows)
    print(e.config_dir)
    print(e.stdin)

# Generated at 2022-06-11 23:26:33.778642
# Unit test for constructor of class Environment
def test_Environment():
    env1 = Environment()
    assert env1.program_name == 'http' and env1.is_windows == False
    if not env1.is_windows:
        assert env1.colors == 256
        assert env1.stdin_encoding == 'utf8' and env1.stdout_encoding == 'utf8'
    else:
        assert env1.colors == None
        assert env1.stdin_encoding == 'utf8'
        assert env1.stdout_encoding == 'utf8'
    assert env1.config_dir == Path('~/.httpie').expanduser()

    env2 = Environment(program_name='test_prog', is_windows=True, colors=1)
    assert env2.colors == 1

# Generated at 2022-06-11 23:26:34.394630
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()

# Generated at 2022-06-11 23:26:42.384913
# Unit test for constructor of class Environment
def test_Environment():
    """ Case 1:
        stdin: sys.stdin
        stdin_encoding: None
        stdin_isatty: sys.stdin.isatty()
        stdout: sys.stdout
        stdout_encoding: None
        stdout_isatty: sys.stdout.isatty()
        stderr: sys.stderr
        stderr_isatty: sys.stderr.isatty()
        colors: 256
        program_name: 'http'
        config_dir: <package-directory>/docs/
    """
    sys.stdin.name = "stdin"
    sys.stdin.encoding = "utf8"
    sys.stdout.encoding = "utf8"
    sys.stderr.encoding = "utf8"
    environ

# Generated at 2022-06-11 23:26:52.867334
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment()
    assert Environment(devnull=1)
    assert Environment(**{'is_windows':True})
    assert Environment(**{'config_dir':Path('./config_dir')})
    assert Environment(**{'stdin':sys.stdin})
    assert Environment(**{'stdin_encoding':None})
    assert Environment(**{'stdout':sys.stdout})
    assert Environment(**{'stdout_encoding':None})
    assert Environment(**{'stderr':sys.stderr})
    assert Environment(**{'stderr_isatty':True})
    assert Environment(**{'colors':256})
    assert Environment(**{'program_name':'http'})

    # stdin is None

# Generated at 2022-06-11 23:27:13.235535
# Unit test for constructor of class Environment
def test_Environment():
    assert str(Environment(stdin_isatty=True, stdout_isatty=True)) == \
        "{'is_windows': False, 'config_dir': PosixPath('/home/httpie/.config/httpie'), 'stdin_isatty': True, 'stdin_encoding': 'utf8', 'stdout_isatty': True, 'stdout_encoding': 'utf8', 'stderr_isatty': True, 'colors': 256, 'program_name': 'http'}"
    assert type(Environment(stdin_isatty=True, stdout_isatty=True)) is Environment

# Generated at 2022-06-11 23:27:22.575972
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert env.colors == 256
    assert env.program_name == 'http'
    env = Environment(stdin=None, stdout=None, stderr=None, colors=16)
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin is None
    assert env.stdout is None
    assert env.stderr is None
    assert env.colors == 16
    assert env.program_name == 'http'

# Generated at 2022-06-11 23:27:30.837614
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env is not None
    assert env.is_windows is False
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty is True
    assert env.stdin_encoding == "utf8"
    assert env.stdout == sys.stdout
    assert env.stdout_isatty is True
    assert env.stdout_encoding == "utf8"
    assert env.stderr == sys.stderr
    assert env.stderr_isatty is True
    assert env.colors == 256
    assert env.program_name == 'http'

# Generated at 2022-06-11 23:27:41.478539
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(is_windows=True, config=None, config_dir=None, stdin=None, stdin_isatty=False, stdin_encoding=None, stdout=sys.stdout, stdout_isatty=True, stdout_encoding=None, stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http')
    assert env.is_windows == True
    assert env.config_dir == None
    assert env.stdin == None
    assert env.stdin_isatty == False
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stdout_encoding == None
    assert env.stderr == sys

# Generated at 2022-06-11 23:27:51.013406
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment();
    assert type(env).__name__ == "Environment"
    assert type(env.is_windows)==bool
    assert type(env.config_dir)==Path
    assert type(env.stdin) == IO
    assert type(env.stdin_isatty) == bool
    assert type(env.stdin_encoding) == str
    assert type(env.stdout) == IO
    assert type(env.stdout_isatty) == bool
    assert type(env.stdout_encoding) == str
    assert type(env.stderr) == IO
    assert type(env.stderr_isatty) == bool
    assert type(env.colors) == int
    assert type(env.program_name) == str
    assert type(env.stdin) == IO


# Generated at 2022-06-11 23:27:52.506208
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull = 1)
    assert env._devnull == 1

# Generated at 2022-06-11 23:28:02.225102
# Unit test for constructor of class Environment
def test_Environment():
    stdin = sys.stdin
    stdout = sys.stdout
    stderr = sys.stderr
    devnull = open(os.devnull, 'w+')
    is_windows = is_windows
    config_dir = DEFAULT_CONFIG_DIR
    stdin_isatty = stdin.isatty() if stdin else False
    stdin_encoding = None
    stdout_isatty = stdout.isatty()
    stdout_encoding = None
    stderr_isatty = stderr.isatty()
    colors = 256
    program_name = 'http'

# Generated at 2022-06-11 23:28:12.829669
# Unit test for constructor of class Environment
def test_Environment():
    _stdin = sys.stdin
    _stdout = sys.stdout
    _stderr = sys.stderr
    _program_name = 'http'
    assert Environment().stdin == _stdin
    assert Environment().stdout == _stdout
    assert Environment().stderr == _stderr
    assert Environment().program_name == _program_name
    assert Environment(
        stdin=3,
        stdout=4,
        stderr=5,
        program_name='httpie'
    ).stdin == 3
    assert Environment(
        stdin=3,
        stdout=4,
        stderr=5,
        program_name='httpie'
    ).stdout == 4

# Generated at 2022-06-11 23:28:23.899919
# Unit test for constructor of class Environment
def test_Environment():
    # We should be able to create an instance of Environment
    # without any constructor arguments.
    env = Environment()
    assert env is not None

    # We should be able to create an instance of Environment
    # and overwrite the config_dir.
    env = Environment(config_dir='/tmp')
    assert env.config_dir == Path('/tmp')

    # We should be able to create an instance of Environment
    # and overwrite the stdin.
    env = Environment(stdin=open('/dev/null', 'w'))
    assert env.stdin is not None
    env.stdin.close()
    del env

    # We should be able to create an instance of Environment
    # and overwrite the stdout.
    env = Environment(stdout=open('/dev/null', 'w'))

# Generated at 2022-06-11 23:28:24.753566
# Unit test for constructor of class Environment
def test_Environment():
    Environment()

# Generated at 2022-06-11 23:28:37.991127
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name='http', config_dir='DEFAULT_CONFIG_DIR')
    assert env.program_name == 'http'
    assert env.config_dir == 'DEFAULT_CONFIG_DIR'


# Generated at 2022-06-11 23:28:50.199347
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(is_windows=False, config_dir="/home", stdin=None, stdout=sys.stdout, stderr=sys.stderr, program_name='http')
    env._orig_stderr = sys.stderr
    env._devnull = None

    # Test getter
    assert env.is_windows == False
    assert env.config_dir == Path("/home")
    assert env.stdin == None
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr
    assert env._devnull == None

    # Test setter
    env.devnull = "none"
    assert env.devnull == "none"

# Generated at 2022-06-11 23:28:59.677730
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.__dict__ == {'is_windows': is_windows, 'config_dir': DEFAULT_CONFIG_DIR, 'stdin': sys.stdin, 'stdin_isatty': bool, 'stdin_encoding': None, 'stdout': sys.stdout, 'stdout_isatty': bool, 'stdout_encoding': None, 'stderr': sys.stderr, 'stderr_isatty': bool, 'colors': 256, 'program_name': 'http', '_orig_stderr': sys.stderr, '_devnull': None}
    env = Environment(stdin_encoding = "utf8", stdout_encoding="utf8", program_name="httpie")

# Generated at 2022-06-11 23:29:02.485314
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.devnull == None

"""
Test function
"""

# Generated at 2022-06-11 23:29:13.096431
# Unit test for constructor of class Environment

# Generated at 2022-06-11 23:29:15.644152
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(colors=10)
    assert env.colors == 10
    assert env.__class__.__dict__ == Environment.__dict__

# Generated at 2022-06-11 23:29:17.760235
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    print(env.stderr)


# Generated at 2022-06-11 23:29:25.745843
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert hasattr(env, 'is_windows')
    assert hasattr(env, 'config_dir')
    assert hasattr(env, 'stdin')
    assert hasattr(env, 'stdin_isatty')
    assert hasattr(env, 'stdin_encoding')
    assert hasattr(env, 'stdout')
    assert hasattr(env, 'stdout_isatty')
    assert hasattr(env, 'stdout_encoding')
    assert hasattr(env, 'stderr')
    assert hasattr(env, 'stderr_isatty')
    assert hasattr(env, 'colors')
    assert hasattr(env, 'program_name')


# Generated at 2022-06-11 23:29:27.835863
# Unit test for constructor of class Environment
def test_Environment():
    print('Test for class Environment:')
    env = Environment()
    print(env)
    print('\n--------------------\n')

# Generated at 2022-06-11 23:29:29.150031
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    print(env)

# Generated at 2022-06-11 23:29:56.188909
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin = None, stdout = None, stderr = None,colors = 12, config_dir = DEFAULT_CONFIG_DIR,is_windows = False,program_name = 'http')
    assert env.stdin is sys.stderr
    assert env.stdout is sys.stdout
    assert env.stderr is sys.stderr
    assert env.colors < 256
    assert env.program_name == 'http'

# Generated at 2022-06-11 23:30:00.216013
# Unit test for constructor of class Environment
def test_Environment():
    # Create an instance of Environment
    env = Environment()
    # Check default value of stdin_encoding
    assert env.stdin_encoding == 'utf8'

    # Check default value of stdout_encoding
    assert env.stdout_encoding == 'utf8'

# Generated at 2022-06-11 23:30:10.400240
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull = sys.stdin, is_windows = True, \
                      config_dir = DEFAULT_CONFIG_DIR, \
                      stdin = os.devnull, stdin_isatty = False, \
                      stdin_encoding = None, stdout = sys.stdout, \
                      stdout_isatty = True, stdout_encoding = None, \
                      stderr = sys.stderr, stderr_isatty = False, \
                      colors = 256, program_name = 'http')

# Generated at 2022-06-11 23:30:16.656805
# Unit test for constructor of class Environment

# Generated at 2022-06-11 23:30:27.323052
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()

    assert env.is_windows is False
    assert env.config_dir == Path("~/.config/httpie")
    assert env.stdin == sys.stdin
    assert env.stdin_isatty is False
    assert env.stdin_encoding == "utf8"
    assert env.stdout == sys.stdout
    assert env.stdout_isatty is False
    assert env.stdout_encoding == "utf8"
    assert env.stderr == sys.stderr
    assert env.stderr_isatty is False
    assert env.colors == 256
    assert env.program_name == "http"
    assert env._orig_stderr == sys.stderr
    assert env._devnull == None
    assert env.config == None

# Generated at 2022-06-11 23:30:31.090039
# Unit test for constructor of class Environment
def test_Environment():
    print('--------Environment--------')
    env=Environment()
    print(env)
    print(env.config_dir)
    print(env.stdin)

if __name__ == "__main__":
    test_Environment()

# Generated at 2022-06-11 23:30:33.447139
# Unit test for constructor of class Environment
def test_Environment():
    myenv = Environment()
    assert myenv.is_windows == False
    assert myenv.colors == 256
    assert myenv.stdout.fileno() == 1

# Generated at 2022-06-11 23:30:35.020141
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().program_name == 'http'
    assert Environment(program_name='test').program_name == 'test'

# Generated at 2022-06-11 23:30:42.956320
# Unit test for constructor of class Environment
def test_Environment():
    # 将配置改到指定目录，避免测试时读取错误
    config_dir = str(Path(__file__).parent / 'test/env/config')

# Generated at 2022-06-11 23:30:53.046981
# Unit test for constructor of class Environment
def test_Environment():

    env = Environment(stdout=sys.stdout,
                      stdin=sys.stdin,
                      stderr=sys.stderr,
                      program_name="hello",
                      config_dir=DEFAULT_CONFIG_DIR)

    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdout == sys.stdout
    assert env.stdin == sys.stdin
    assert env.stderr == sys.stderr
    assert env.program_name == "hello"

    stdout_devnull = open(os.devnull, 'w+')
    stderr_devnull = open(os.devnull, 'w+')

    env.devnull = stdout_devnull
    assert env.devnull == stdout_devnull


# Generated at 2022-06-11 23:31:22.084823
# Unit test for constructor of class Environment
def test_Environment():
    import tempfile
    with tempfile.TemporaryDirectory() as temp_dir:
        new_config_dir = Path(temp_dir).joinpath('.config')
        # Use keyword arguments to overwrite class attributes for this instance.
        env = Environment(
            stdin=None,
            stdin_isatty=True,
            stdin_encoding="utf8",
            stdout=os.devnull,
            stdout_isatty=False,
            stdout_encoding="utf8",
            stderr=os.devnull,
            stderr_isatty=False,
            colors=32,
            program_name="http",
            config_dir=new_config_dir
        )
        assert env.stdin is None
        assert env.stdin_isatty is True
        assert env.std

# Generated at 2022-06-11 23:31:26.177085
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment()._orig_stderr == sys.stderr

    stdin = sys.stdin
    stdout = sys.stdout
    stderr = sys.stderr

    assert Environment(stdin=stdin, stdout=stdout, stderr=stderr)

# Generated at 2022-06-11 23:31:35.861988
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()

    # test stdin attr
    assert env.stdin == sys.stdin
    print(type(env.stdin))
    assert type(env.stdin) == file

    # test is_windows attr
    assert type(env.is_windows) == bool

    # test stdout attr
    assert env.stdout == sys.stdout
    assert type(env.stdout) == file

    # test stderr attr
    assert env.stderr == sys.stderr
    assert type(env.stderr) == file

    # test stdout_encoding attr
    print(env.stdout_encoding)
    assert type(env.stdout_encoding) == str
    env.stdout_encoding = 'utf-8'

# Generated at 2022-06-11 23:31:41.548360
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        foo=1,
        bar=2,
        config_dir='/tmp/'
    )
    assert env.foo == 1
    assert env.config_dir == '/tmp/'
    assert env.config_dir.is_dir()
    assert len(env.config_dir.ls()) == 0



# Generated at 2022-06-11 23:31:49.496036
# Unit test for constructor of class Environment
def test_Environment():
    import io
    import sys
    import os
    from io import StringIO
    from pathlib import Path
    from pathlib import PosixPath
    import atexit
    import os

    os.chdir('/')

    env = Environment(stdin=StringIO('This is write_stdin_to_stdout'),
                      stdin_isatty=False,
                      stdout=StringIO('This is write_stdin_to_stdout'),
                      stdout_isatty=False,
                      stderr=StringIO('This is write_stdin_to_stdout'),
                      stderr_isatty=False,
                      config_dir=PosixPath('/tmp/project/httpie/README.md'),
                      is_windows=False,
                      program_name='http'
                      )

    sys.stdin

# Generated at 2022-06-11 23:31:57.978842
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment()
    assert str(e) == "{'config_dir': '.httpie', 'colors': 256, 'is_windows': False, 'program_name': 'http', 'stderr': <_io.TextIOWrapper name='<stderr>' mode='w' encoding='cp1252'>, 'stderr_encoding': None, 'stdin': <_io.TextIOWrapper name='<stdin>' mode='r' encoding='cp1252'>, 'stdin_encoding': 'cp1252', 'stdout': <_io.TextIOWrapper name='<stdout>' mode='w' encoding='cp1252'>, 'stdout_encoding': 'cp1252'}"




# Generated at 2022-06-11 23:32:06.984536
# Unit test for constructor of class Environment

# Generated at 2022-06-11 23:32:09.162069
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name='http', stdout=stdout)
    print(env)

# Generated at 2022-06-11 23:32:18.057663
# Unit test for constructor of class Environment
def test_Environment():
	# Use keyword arguments to overwrite any of the class attributes for this instance.
	stdin = sys.stdin  # `None` when closed fd (#791)
	stdin_isatty = stdin.isatty() if stdin else False
	stdin_encoding = sys.stdin.encoding
	stdout = sys.stdout
	stdout_isatty = stdout.isatty()
	stdout_encoding = getattr(stdout,'encoding',None) or 'utf8'
	stderr = sys.stderr
	stderr_isatty = stderr.isatty()
	#print(env)

# Generated at 2022-06-11 23:32:23.786087
# Unit test for constructor of class Environment
def test_Environment():
    """
    The constructor of class Environment can receive keyword arguments to 
    overwrite any of the class attributes for this instance.

    """
    env = Environment(colors=10, stdin_isatty=False, stdout_isatty=False)
    assert isinstance(env, Environment)
    assert env.colors == 10
    assert env.stdin_isatty == False
    assert env.stdout_isatty == False