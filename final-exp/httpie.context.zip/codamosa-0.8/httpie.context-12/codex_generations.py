

# Generated at 2022-06-11 23:22:46.154014
# Unit test for constructor of class Environment
def test_Environment():
    stdin = sys.stdin
    stdout = sys.stdout
    stderr = sys.stderr

    test_env = Environment(
        stdin=stdin,
        stdout=stdout,
        stderr=stderr
    )
    assert test_env.stdin == stdin
    assert test_env.stdout == stdout
    assert test_env.stderr == stderr
    assert test_env.config_dir == DEFAULT_CONFIG_DIR

# Generated at 2022-06-11 23:22:49.769027
# Unit test for constructor of class Environment
def test_Environment():
    print("\n[test_Environment]")
    env = Environment()
    print(env)

    #env1 = Environment(pwd=os.getcwd(), program_name="http")
    #print("\n", env1)

if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-11 23:22:59.178088
# Unit test for constructor of class Environment
def test_Environment():
    import sys
    sys.setrecursionlimit(100)

    env = Environment()
    print(env.is_windows)
    print(env.config_dir)
    print(env.stdin)
    print(env.stdin_isatty)
    print(env.stdin_encoding)
    print(env.stdout)
    print(env.stdout_isatty)
    print(env.stdout_encoding)
    print(env.stderr)
    print(env.stderr_isatty)
    print(env.colors)
    print(env.program_name)


# Generated at 2022-06-11 23:23:06.918521
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding is None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding is None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()

    env = Environment(is_windows=False, stderr=None)
    assert env.is_windows == False
    assert env.stderr is None

# Generated at 2022-06-11 23:23:15.061708
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stderr = "STDERR")
    assert env.stderr == "STDERR"
    assert env.stdout_encoding == "utf8"
    assert env.stdin_encoding == "utf8"
    assert env.stdin_isatty == False
    assert env.stdout_isatty == True
    assert env.stderr_isatty == True
    assert env.is_windows == False
    assert env.config_dir == Path("/root/.config/httpie")
    assert env.stdin == sys.stdin
    assert env.program_name == "http"
    print(env)

# Generated at 2022-06-11 23:23:20.265335
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()

# Generated at 2022-06-11 23:23:26.398459
# Unit test for constructor of class Environment
def test_Environment():
    print(sys.stdin)
    print(sys.stdout)
    print(sys.stderr)
    print()

    env = Environment(
        devnull=None,
        program_name = 'httpie'
    )

    print(env)
    print(env.config)
    env.devnull = None
    print(env.devnull)

if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-11 23:23:31.479062
# Unit test for constructor of class Environment
def test_Environment():
    a = Environment(1, 2, 3, 4)
    assert a.stdin == 1
    assert a.stdout == 2
    assert a.stderr == 3
    assert a.config_dir == 4
    assert a.is_windows is False


# Generated at 2022-06-11 23:23:38.847945
# Unit test for constructor of class Environment
def test_Environment():
    try:
        _ = Environment.__dict__
        env = Environment(is_windows=False)
        assert env.is_windows == False
        assert env.config_dir == DEFAULT_CONFIG_DIR
        assert env.stdin == sys.stdin
        assert env.stdin_isatty == sys.stdin.isatty() if sys.stdin else False
        assert env.stdout == sys.stdout
        assert env.stdout_isatty == sys.stdout.isatty()
        assert env.stderr == sys.stderr
        assert env.stderr_isatty == sys.stderr.isatty()
        assert env.program_name == 'http'
    except Exception as exc:
        print(exc)
        assert False


# Generated at 2022-06-11 23:23:47.033533
# Unit test for constructor of class Environment
def test_Environment():
    """ Unit test for constructor of class Environment """
    env = Environment(devnull=None)
    assert env.is_windows == True
    assert env.stdin == None
    assert env.stdin_isatty == False
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == True

# Generated at 2022-06-11 23:23:58.600211
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin_isatty == sys.stdin.isatty()

test_Environment()

# Generated at 2022-06-11 23:24:08.693485
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment()
    assert isinstance(e.config, Config)
    assert e.config.is_new()
    assert e.stdout_encoding == "utf8"

# main(postman)
# -*- coding: utf-8 -*-
# import sys

import sys
import os
from pathlib import Path
from typing import IO, Optional


try:
    import curses
except ImportError:
    curses = None  # Compiled w/o curses

from httpie.compat import is_windows
from httpie.config import DEFAULT_CONFIG_DIR, Config, ConfigFileError

from httpie.utils import repr_dict



# Generated at 2022-06-11 23:24:18.729472
# Unit test for constructor of class Environment
def test_Environment():
    from httpie.core import env
    env.config_dir = 'DEFAULT_CONFIG_DIR'
    env.stdin = 'sys.stdin'
    env.stdin_isatty = 'sys.stdout'
    env.stdout_encoding = 'stdout_encoding'
    env.stderr = 'sys.stderr'
    env.stderr_isatty = 'stderr_isatty'
    env.colors = '256'
    env.program_name = 'program_name'
    env._devnull = 'devnull'
    env.is_windows = 'FALSE'
    env._orig_stderr = '_orig_stderr'
    env.config = 'config'
    env.devnull = 'devnull_set'
    env._config

# Generated at 2022-06-11 23:24:20.872314
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    print(repr(environment))
    assert True

# Generated at 2022-06-11 23:24:31.663964
# Unit test for constructor of class Environment

# Generated at 2022-06-11 23:24:32.971023
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=sys.stdout)
    print(env.stdin)

# Generated at 2022-06-11 23:24:43.712716
# Unit test for constructor of class Environment
def test_Environment():
    from pprint import pprint
    from httpie.config import DEFAULT_CONFIG_DIR
    def get_default_env():
        return Environment(
            is_windows=True,
            stdin=None,
            stdin_isatty=None,
            stdin_encoding=None,
            stdout=sys.stdout,
            stdout_isatty=sys.stdout.isatty(),
            stdout_encoding=sys.stdout.encoding,
            stderr=sys.stderr,
            stderr_isatty=sys.stderr.isatty(),
            colors=256,
            program_name='httpie',
            config_dir=DEFAULT_CONFIG_DIR,
        )
    def test_basic():
        env = Environment()

# Generated at 2022-06-11 23:24:45.441083
# Unit test for constructor of class Environment
def test_Environment():
    devnull = open(os.devnull, 'w+')
    env = Environment(devnull=devnull)
    env_dict = dict(env.__dict__)
    assert 'devnull' in env_dict
    del env_dict['devnull']
    assert env_dict == Environment.__dict__
    devnull.close()

# Generated at 2022-06-11 23:24:53.418873
# Unit test for constructor of class Environment
def test_Environment():
    def override_attrs(**attrs):
        """
        Override selected attributes on the instance and
        return a new instance with the remaining attributes
        set to their default values.

        """
        env = Environment(**attrs)
        defaults = dict(type(env).__dict__)
        defaults.update(**attrs)
        return Environment(**defaults)

    env = override_attrs(
        is_windows=True,
        config_dir='my-config',
        stdin=b'hello',
        stdout=u'world',
        stderr=b'foo',
        program_name='http-alt',
        colors=42
    )

# Generated at 2022-06-11 23:25:00.165354
# Unit test for constructor of class Environment
def test_Environment():
    actual = dict(
        is_windows=True,
        stdout_encoding='utf8',
        config_dir='/some/path',
        stdin=sys.stdin,
        stdout=sys.stdout,
        stderr=sys.stderr,
        program_name='http',
        devnull=None,
    )
    instance = Environment(**actual)
    assert instance.__dict__ == actual

# Generated at 2022-06-11 23:25:27.880414
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == Path(DEFAULT_CONFIG_DIR)
    assert env.stdin is sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout is sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr is sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'

# Generated at 2022-06-11 23:25:36.601542
# Unit test for constructor of class Environment
def test_Environment():
    def get_env_attr(env, attr):
        return getattr(env, attr)
    env = Environment()
    assert get_env_attr(env, "is_windows") == is_windows
    assert get_env_attr(env, "config_dir") == DEFAULT_CONFIG_DIR
    assert get_env_attr(env, "stdin") == sys.stdin
    assert get_env_attr(env, "stdin_isatty") == sys.stdin.isatty()
    assert get_env_attr(env, "stdin_encoding") is None
    assert get_env_attr(env, "stdout") == sys.stdout
    assert get_env_attr(env, "stdout_isatty") == sys.stdout.isatty()
    assert get_env_

# Generated at 2022-06-11 23:25:45.626750
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.program_name == 'http'

# Generated at 2022-06-11 23:25:47.654534
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdout="def")
    assert env.stdout == "def"
    assert env.stderr == env.stderr

# Generated at 2022-06-11 23:25:56.237484
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull="This is a devnull", stdin="This is a stdin",
                    stdin_encoding="This is a stdin_encoding", stdout="This is a stdout",
                    stdout_encoding="This is a stdout_encoding", stderr="This is a stderr",
                    is_windows=True, config_dir="This is a config_dir",
                    stdin_isatty=True, stdout_isatty=True, stderr_isatty=True,
                    colors=256, program_name="This is a program_name")

    print(env.is_windows)
    print(env.config_dir)
    print(env.stdin)
    print(env.stdin_isatty)
    print(env.stdin_encoding)
   

# Generated at 2022-06-11 23:26:06.418446
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull = "", program_name = "http", is_windows = True, config_dir = True)

# Generated at 2022-06-11 23:26:08.973116
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=1, program_name=2)
    assert env.devnull == 1
    assert env.program_name == 2


# Generated at 2022-06-11 23:26:14.687607
# Unit test for constructor of class Environment
def test_Environment():
    actual = Environment()
    defaults = dict(type(actual).__dict__)
    actual_ = dict(defaults)
    actual_.update(actual.__dict__)
    actual_['config'] = actual.config
    assert len(defaults) == len(actual_)
    for key in defaults.keys():
        assert key in actual_.keys()
        assert defaults[key] == actual_[key]

# Generated at 2022-06-11 23:26:24.603588
# Unit test for constructor of class Environment
def test_Environment():
    # Environment instance with properties unset
    env = Environment()

    # Attributes defined in __init__
    assert hasattr(env, 'is_windows')
    assert hasattr(env, 'config_dir')
    assert hasattr(env, 'stdin')
    assert hasattr(env, 'stdin_isatty')
    assert hasattr(env, 'stdin_encoding')
    assert hasattr(env, 'stdout')
    assert hasattr(env, 'stdout_isatty')
    assert hasattr(env, 'stdout_encoding')
    assert hasattr(env, 'stderr')
    assert hasattr(env, 'stderr_isatty')
    assert hasattr(env, 'colors')
    assert hasattr(env, 'program_name')

    # Attributes defined elsewhere

# Generated at 2022-06-11 23:26:34.929777
# Unit test for constructor of class Environment

# Generated at 2022-06-11 23:27:14.351871
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().stdin==sys.stdin
    assert Environment().stdout==sys.stdout
    assert Environment().stderr==sys.stderr
    assert Environment().stdin_isatty==sys.stdin.isatty()

# Generated at 2022-06-11 23:27:23.560341
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(test="test")
    assert env.is_windows == is_windows
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.devnull == None
    assert env.stdin_encoding == None
    assert env.stdout_encoding == None
    assert env._

# Generated at 2022-06-11 23:27:33.834567
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding is None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding is None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()

# Generated at 2022-06-11 23:27:43.482719
# Unit test for constructor of class Environment
def test_Environment():
    # Set environment value
    env = Environment(config_dir='/home/user65/httpie/')
    assert env.config_dir == Path('/home/user65/httpie/')
    assert env.devnull is None
    assert env.is_windows == True
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == True
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stdout_encoding == 'utf8'
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == True
    assert env.colors == 256
    assert env.program_name == 'http'

# Generated at 2022-06-11 23:27:52.234787
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
            is_windows=True, 
            config_dir=Path('..'), 
            stdin='sys.stdin', 
            stdout=sys.stdout, 
            stderr=sys.stderr, 
            program_name='httpie'
    )
    assert env.is_windows == True
    assert env.config_dir == Path('..')
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert env.program_name == 'httpie'
    print(env)
    print(env.config)
    print(env.devnull)
    with open('output_test.txt', 'w') as f:
        env.devnull = f

# Generated at 2022-06-11 23:28:01.980949
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(is_windows=False)
    assert env.is_windows == False
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env.config == env.config

# Unit

# Generated at 2022-06-11 23:28:12.500821
# Unit test for constructor of class Environment
def test_Environment():
    import sys
    environ = Environment(program_name='httpie', stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr)
    assert environ.program_name == 'httpie'
    assert environ.is_windows == sys.platform.startswith('win')
    assert environ.stdin == sys.stdin
    assert environ.stdout == sys.stdout
    assert environ.stderr == sys.stderr
    assert environ.devnull == None
    # do not have to test _orig_stdeer, _config, and config_dir, because they refer to other classes
    assert environ.stdin_isatty == True
    assert environ.stdin_encoding == 'UTF-8'
    assert environ.stdout_isat

# Generated at 2022-06-11 23:28:23.598389
# Unit test for constructor of class Environment
def test_Environment():
    from io import StringIO
    from httpie.environment import Environment
    import tempfile
    import os

    stdin = StringIO('test')
    stdout = StringIO()
    stderr = StringIO()

    assert stdin is Environment(stdin=stdin).stdin
    assert stdout is Environment(stdout=stdout).stdout
    assert stderr is Environment(stderr=stderr).stderr

    config_dir = tempfile.mkdtemp()
    assert config_dir is Environment(config_dir=config_dir).config_dir

    # Test each default attributes of Environment
    env = Environment()
    assert is_windows == env.is_windows
    assert DEFAULT_CONFIG_DIR == env.config_dir
    assert sys.stdin == env.stdin

# Generated at 2022-06-11 23:28:30.330046
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(colors=2)
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin is None
    assert env.stdin_encoding is None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == env.stdout.isatty()
    assert env.stdout_encoding == getattr(env.stdout, 'encoding', None) or 'utf8'
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == env.stderr.isatty()
    assert env.colors == 2
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr

# Generated at 2022-06-11 23:28:38.595243
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        is_windows=False,
        config_dir=DEFAULT_CONFIG_DIR,
        stdin=sys.stdin,
        stdin_isatty=sys.stdin.isatty() if sys.stdin else False,
        stdin_encoding=None,
        stdout=sys.stdout,
        stdout_isatty=sys.stdout.isatty(),
        stdout_encoding=None,
        stderr=sys.stderr,
        stderr_isatty=sys.stderr.isatty(),
        colors = 256,
        program_name='http'
    )
    print(env)

# Generated at 2022-06-11 23:29:52.517439
# Unit test for constructor of class Environment
def test_Environment():
    Environment()

# Generated at 2022-06-11 23:30:03.379491
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding is None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding is None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()

# Generated at 2022-06-11 23:30:07.908226
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(
        config_dir = "~/.config/httpie",
        stdin = sys.stdin,
        stdout = sys.stdout,
        stderr = sys.stderr,
    )

    print(environment)
    print(repr(environment))

if __name__ == "__main__":
    test_Environment()

# Generated at 2022-06-11 23:30:15.674833
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name = "Hello",color = None)
    assert env.program_name == "Hello"
    assert env.color == None
    env = Environment()
    if is_windows:
        assert env.devnull == None
        assert env.is_windows == True
        assert env.config_dir == str(DEFAULT_CONFIG_DIR)
        assert env.stdin == sys.stdin
        assert env.stdin_isatty == sys.stdin.isatty()
        assert env.stdin_encoding == "utf8"
        assert env.stdout == sys.stdout
        assert env.stdout_isatty == sys.stdout.isatty()
        assert env.stdout_encoding == "utf8"
        assert env.stderr == sys.stderr
       

# Generated at 2022-06-11 23:30:19.268160
# Unit test for constructor of class Environment
def test_Environment():
    from io import StringIO
    env = Environment(devnull=StringIO(), config_dir='my_config_dir')
    my_dict = dict(devnull=StringIO(), config_dir='my_config_dir')
    assert env.__dict__ == my_dict

test_Environment()

# Generated at 2022-06-11 23:30:21.856857
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment(devnull='devnull',program_name='http')
    print(e)

if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-11 23:30:30.669296
# Unit test for constructor of class Environment
def test_Environment():
    Environment()
    assert Environment().devnull == sys.stdin and Environment().devnull == sys.stdout and Environment().devnull == sys.stderr
    assert Environment().program_name == 'http'
    assert Environment().config_dir == DEFAULT_CONFIG_DIR
    assert Environment().is_windows == is_windows
    assert Environment().stderr_isatty == sys.stderr.isatty()
    assert Environment().stdout_isatty == sys.stdout.isatty()
    assert Environment().stdin_isatty == sys.stdin.isatty()
    assert Environment().stdin == sys.stdin
    assert Environment().stdout == sys.stdout
    assert Environment().stderr == sys.stderr


# Generated at 2022-06-11 23:30:39.340861
# Unit test for constructor of class Environment
def test_Environment():
    d = {
        'is_windows': False,
        'config_dir': DEFAULT_CONFIG_DIR,
        'stdin': sys.stdin,
        'stdin_isatty': sys.stdin.isatty(),
        'stdin_encoding': None,
        'stdout': sys.stdout,
        'stdout_isatty': sys.stdout.isatty(),
        'stdout_encoding': None,
        'stderr': sys.stderr,
        'stderr_isatty': sys.stderr.isatty(),
        'colors': 256,
        'program_name': 'http'
    }
    environment = Environment(**d)
    assert environment.__str__() == str(d)

# Generated at 2022-06-11 23:30:44.542203
# Unit test for constructor of class Environment
def test_Environment():
    import io
    env = Environment(stdin=io.BytesIO(), stdout=io.BytesIO(), stderr=io.BytesIO())
    assert env.stdin_encoding is None
    assert env.stdout_encoding is None
    assert env.stderr_isatty is False
    assert repr(env).startswith('<Environment')

# Generated at 2022-06-11 23:30:48.605215
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    r = repr(env)
    assert 'http' in r
    assert 'config_dir' in r
    assert 'stdin_isatty' in r
    assert 'stdin_encoding' in r
    assert 'stderr_isatty' in r


# Generated at 2022-06-11 23:32:14.293179
# Unit test for constructor of class Environment
def test_Environment():
    import io
    import pytest
    # Constructor of class Environment takes a mapping

# Generated at 2022-06-11 23:32:24.535021
# Unit test for constructor of class Environment
def test_Environment():
    class Env(Environment):
        pass

    class Foo:
        pass

    env = Env(
        is_windows=False,
        config_dir='./config', 
        stdin=Foo(),
        stdin_isatty=False,
        stdin_encoding='utf8',
        stdout=Foo(),
        stdout_isatty=False,
        stdout_encoding='utf8',
        stderr=Foo(),
        stderr_isatty=False,
        colors=256,
        program_name='http'
    )
    assert env.is_windows == False
    assert env.config_dir == './config'
    assert env.stdin_isatty == False
    assert env.stdin_encoding == 'utf8'
    assert env.std

# Generated at 2022-06-11 23:32:32.943832
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == False
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == False
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stdout_encoding == 'UTF-8'
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == True
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr
    assert env._devnull == None
    assert env.config != None
    assert isinstance(env.config, Config)
    assert env._