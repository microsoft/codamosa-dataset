

# Generated at 2022-06-11 23:22:42.483899
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.stdout_isatty == True
    env.stdout = open("test.txt", "w")
    env.stdout_isatty = False
    assert env.stdout_isatty == False

# Generated at 2022-06-11 23:22:46.677611
# Unit test for constructor of class Environment
def test_Environment():
    environ = Environment(stdin_encoding='stdin_encoding',
                          stdout_encoding='stdout_encoding')
    assert environ.stdin_encoding == 'stdin_encoding'
    assert environ.stdout_encoding == 'stdout_encoding'
    assert not environ._config

# Generated at 2022-06-11 23:22:54.661946
# Unit test for constructor of class Environment
def test_Environment():
    import sys
    import os
    from pathlib import Path
    # Check if standard directories exists
    assert(sys.stdin == Environment().stdin)
    assert(sys.stdout == Environment().stdout)
    assert(sys.stderr == Environment().stderr)
    # Check if Environment.config_dir is equal to the home directory
    assert(Environment().config_dir == Path.home())
    # Check if Environment.stdin_isatty is equal to the stdin isatty
    assert(Environment().stdin_isatty == sys.stdin.isatty())
    # Check if Environment.stdout_isatty is equal to the stdout isatty
    assert(Environment().stdout_isatty == sys.stdout.isatty())
    # Check if Environment.stderr_isatty is

# Generated at 2022-06-11 23:23:04.979723
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.stdin_isatty == True  # type: ignore
    assert environment.stdout_isatty == True  # type: ignore
    assert environment.stderr_isatty == True  # type: ignore
    assert environment.is_windows == True  # type: ignore
    assert environment.config_dir == DEFAULT_CONFIG_DIR  # type: ignore
    assert environment.stdin == sys.stdin  # type: ignore
    assert environment.stdout == sys.stdout  # type: ignore
    assert environment.stderr == sys.stderr  # type: ignore
    assert environment.colors == 256  # type: ignore
    assert environment.program_name == 'http'  # type: ignore
    assert environment.stdin_encoding == sys.stdin.encoding 

# Generated at 2022-06-11 23:23:15.013828
# Unit test for constructor of class Environment
def test_Environment():
    class X:
        def __init__(self, name, value):
            self.name = name
            self.value = value

        def __repr__(self):
            return f'<{self.name}:{self.value}>'

    env = Environment(devnull=X('devnull', 1))
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert env.program_name == 'http'

    env = Environment(stdin=X('stdin', 1), stdout=X('stdout', 2))
    assert env.stdin == X('stdin', 1)
    assert env.stdout == X('stdout', 2)
    assert env.stderr == sys.stderr
    assert env

# Generated at 2022-06-11 23:23:25.521534
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert env.stdin == sys.stdin
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.program_name == 'http'
    if not is_windows:
        if curses:
            try:
                curses.setupterm()
                env.colors = curses.tigetnum('colors')
            except curses.error:
                pass

# Generated at 2022-06-11 23:23:35.392314
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None,
                      stdout_encoding='utf8',
                      stdin_isatty=True,
                      stderr="/dev/null")
    assert env.stdout_encoding == 'utf8'
    assert env.stdin is None
    assert env.stdin_isatty == True
    assert env.stderr.name == "/dev/null"
    assert env.stdout == sys.stdout
    assert env.__dict__['_Environment__dict__']['stdout'] == sys.stdout
    assert env._orig_stderr.name != "/dev/null"
    assert env._devnull.name == "/dev/null"
    print(env)

# Generated at 2022-06-11 23:23:42.815210
# Unit test for constructor of class Environment
def test_Environment():
    for attr in [
        'is_windows', 'config_dir', 'stdin', 'stdin', 'stdin_isatty',
        'stdin_encoding', 'stdout', 'stdout_isatty', 'stdout', 'stderr_isatty',
        'colors', 'program_name'
    ]:
        with pytest.raises(AssertionError):
            Environment(attr='test')

# Generated at 2022-06-11 23:23:50.909408
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.program_name == 'http', "program_name is not http"
    assert environment.colors == 256, "colors is not 256"
    assert environment.stdin_isatty == True, "stdin is not true"
    assert environment.stdout == sys.stdout, "stdout is not sys.stdout"
    assert environment.stderr == sys.stderr, "stderr is not sys.stderr"
    assert environment.stdin_encoding == 'utf8', "stdin encoding is not utf8"
    assert environment.stdout_encoding == 'utf8', "stdout encoding is not utf8"
    assert environment.stderr_isatty == True, "stderr is not true"

# Generated at 2022-06-11 23:24:00.519199
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()

    # Streams
    assert environment.stderr == sys.stderr
    assert environment.stdout == sys.stdout
    assert environment.stdin == sys.stdin

    # Colors
    assert environment.colors == 256

    # Program name
    assert environment.program_name == 'http'

    # Config directory

    # Keyword arguments > stream.encoding > default utf8
    if environment.stdin and environment.stdin_encoding is None:
        environment.stdin_encoding = getattr(
            environment.stdin, 'encoding', None) or 'utf8'
        assert isinstance(environment.stdin_encoding, str)
        assert environment.stdin_encoding == 'utf8'

# Generated at 2022-06-11 23:24:07.449003
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment(a='a', b=True) == {
        'a': 'a',
        'b': True
    }



# Generated at 2022-06-11 23:24:16.425669
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        stdin=None,
        stdin_isatty=False,
        stdin_encoding='utf8',
        stdout=None,
        stdout_isatty=False,
        stdout_encoding='utf8',
        stderr=None,
        stderr_isatty=False,
        is_windows=False,
        config_dir='config',
        colors=256,
        program_name='http',
        devnull=None,
        _config=None,
        _devnull=None,
        _orig_stderr=None
    )
    env.repr()

# Generated at 2022-06-11 23:24:18.422282
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name='httpie', devnull='1234')
    assert env.program_name == 'httpie'
    assert env.devnull == '1234'

# Generated at 2022-06-11 23:24:30.123970
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.stdin == None
    assert env.stdin_isatty == False
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == True
    env = Environment(stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr)
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr == sys.stderr
    assert env.stder

# Generated at 2022-06-11 23:24:39.470380
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert is_windows == env.is_windows
    assert sys.stdin == env.stdin
    assert sys.stdout == env.stdout
    assert sys.stderr == env.stderr
    assert sys.stdin.isatty() == env.stdin_isatty
    assert sys.stdout.isatty() == env.stdout_isatty
    assert sys.stderr.isatty() == env.stderr_isatty
    assert env.program_name == 'http'
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin_encoding == 'utf8'
    assert env.stdout_encoding == 'utf8'

# Generated at 2022-06-11 23:24:46.308249
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    print(env)
    print(env.stdout)
    print(env.stdout_isatty)
    print(env.stdout_encoding)

    print(env.stdin_encoding)

    print(env.stderr)
    print(env.stderr_isatty)
    print(env.stderr_encoding)

    print(env.colors)
    print(env.program_name)



# Generated at 2022-06-11 23:24:49.168721
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdout='test stdout')
    assert env.stdout == 'test stdout'
    assert env.stderr == sys.stderr

if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-11 23:24:55.431138
# Unit test for constructor of class Environment
def test_Environment():
    config_dir = Path('config_dir')
    stdin = sys.stdin
    stdout = sys.stdout
    stderr = sys.stderr
    program_name = 'http'
    environ = Environment(config_dir=config_dir, stdin=stdin, stdout=stdout, stderr=stderr, program_name=program_name)
    assert environ.config_dir == config_dir
    assert environ.stdin == stdin
    assert environ.stdout == stdout
    assert environ.stderr == stderr
    assert environ.program_name == program_name

if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-11 23:24:58.647562
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=3, stdout=4, stderr = 5)
    assert env.is_windows == Environment.is_windows
    assert env.config_dir == Environment.config_dir
    assert env.stdin == 3
    assert env.stdout == 4
    assert env.stderr == 5

    # Test __str__ and __repr__
    assert repr(env) == '<Environment {}>'
    assert repr(env) == repr(env)


# Test for the function test_Environment()

# Generated at 2022-06-11 23:25:03.835862
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull='asdf', program_name='asdf')
    env.devnull = None
    assert repr(env)=='<Environment devnull=None,\nprogram_name=asdf,\nstdin_encoding=None,\nstdin_isatty=False,\nstdout_encoding=None,\nstdout_isatty=False,\nstderr_encoding=None,\nstderr_isatty=False,\ncolors=256>'
    pass

# Generated at 2022-06-11 23:25:20.951225
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        config_dir=Path('/config-dir'),
        stdout=object(),
        stdout_encoding='cp65001',
        colors=256,
        devnull=None,
        program_name='httpie'
    )
    assert env.config_dir == Path('/config-dir')
    assert env.stdout == object()
    assert env.stdout_encoding == 'cp65001'
    assert env.colors == 256
    assert env._devnull == None
    assert env.program_name == 'httpie'

# Generated at 2022-06-11 23:25:24.094111
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdout=sys.stdout, colors=256, devnull=None, is_windows=True, config_dir=DEFAULT_CONFIG_DIR)
    print(repr(env))
test_Environment()

env = Environment()

# Generated at 2022-06-11 23:25:27.236931
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=1, program_name='hello')
    assert env._orig_stderr == sys.stderr
    assert env._devnull is 1
    assert env.program_name == 'hello'



# Generated at 2022-06-11 23:25:29.062968
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=sys.stdin, is_windows=True)
    assert isinstance(env,Environment)


# Generated at 2022-06-11 23:25:31.454273
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr


# Generated at 2022-06-11 23:25:40.203673
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment()
    assert e.is_windows == is_windows
    assert e.config_dir == DEFAULT_CONFIG_DIR
    assert e.stdin == sys.stdin
    assert e.stdin_isatty == sys.stdin.isatty()
    assert e.stdout == sys.stdout
    assert e.stdout_isatty == sys.stdout.isatty()
    assert e.stderr == sys.stderr
    assert e.stderr_isatty == sys.stderr.isatty()
    assert e.colors == 256
    assert e.program_name == 'http'


if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-11 23:25:44.486287
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin_encoding='ascii', stdout_encoding='ascii')
    print(repr(env))
    assert env.stdin_encoding == 'ascii'
    assert env.stdout_encoding == 'ascii'



# Generated at 2022-06-11 23:25:54.149056
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(is_windows=1, 
                      config_dir='/home/test', 
                      stdin='test.txt', 
                      stdin_isatty=1, 
                      stdin_encoding='UTF-8', 
                      stdout='stdout.txt', 
                      stdout_isatty=1, 
                      stdout_encoding='UTF-8', 
                      stderr='stderr.txt', 
                      stderr_isatty=0, 
                      colors=256, 
                      program_name='test', 
                      _devnull=0)

# Generated at 2022-06-11 23:26:04.034271
# Unit test for constructor of class Environment
def test_Environment():
    # noinspection PyUnusedLocal
    def dummy():
        pass

    env = Environment(
        is_windows=False,
        config_dir=DEFAULT_CONFIG_DIR,
        stdin=dummy,
        stdin_isatty=False,
        stdin_encoding=None,
        stdout=dummy,
        stdout_isatty=False,
        stdout_encoding=None,
        stderr=dummy,
        stderr_isatty=False,
        colors=255,
        program_name=dummy,
        _config=None,
        _devnull=dummy,
        _orig_stderr=dummy
    )
    assert env._devnull is dummy
    assert env._orig_stderr is dummy
    assert env.colors == 255

# Generated at 2022-06-11 23:26:12.768226
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    stdin = sys.stdin
    stdout = sys.stdout
    stderr = sys.stderr
    assert env.stdin is stdin
    assert env.stdin_isatty is stdin.isatty() if stdin else False
    assert env.stdin_encoding is None
    assert env.stdout is stdout
    assert env.stdout_isatty is stdout.isatty()
    assert env.stdout_encoding is None
    assert env.stderr is stderr
    assert env.stderr_isatty is stderr.isatty()

# Generated at 2022-06-11 23:26:34.019364
# Unit test for constructor of class Environment
def test_Environment():
    print(repr_dict({"asdf" : 1, "asdf" : "asdf"}))
    env = Environment(config_dir="")
    print(env)

test_Environment()

# Generated at 2022-06-11 23:26:39.119241
# Unit test for constructor of class Environment
def test_Environment():
    # Create an instance of class Environment
    env = Environment()
    # Check the instance of class Environment
    if env is None:
        print("Instance of class Environment could not be created.")

    # Check the creation of a configuration directory
    p = Path(env.config_dir)
    if p.exists() is False:
        print("Creation of a configuration directory has been failed.")



# Generated at 2022-06-11 23:26:46.728717
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin_encoding='utf-8')
    assert not env.stdin_isatty
    if env.stdin:
        assert env.stdin.isatty()
    assert env.stdout_isatty
    assert env.stdout.isatty()
    assert env.stderr_isatty
    assert env.stderr.isatty()
    assert env.stdin_encoding == 'utf-8'
    assert env.stdout_encoding != 'utf-8'
    assert env.stderr_encoding != 'utf-8'

# Generated at 2022-06-11 23:26:51.826811
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(is_windows=True)
    assert env.is_windows==True
    assert env.stdin_isatty==True
    env = Environment(is_windows=False,stdin=None)
    assert env.is_windows==False
    assert env.stdin_isatty==False
    assert env.stdin==None

# Generated at 2022-06-11 23:26:57.192693
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        devnull=None,
        is_windows=True,
        config_dir=DEFAULT_CONFIG_DIR,
    )
    assert repr(env) == '<Enviroment {"config": <Config ...>, "is_windows": True, "config_dir": ...}>'
    assert str(env) == '<Enviroment {"config": <Config ...>, "is_windows": True, "config_dir": ...}>'



# Generated at 2022-06-11 23:26:58.436876
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment()

# Generated at 2022-06-11 23:27:09.461601
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=True, config_dir=Path("configDir"), stdin=sys.stdin,
                      stdin_isatty=sys.stdin.isatty(), stdin_encoding=None, stdout=sys.stdout,
                      stdout_isatty=sys.stdout.isatty(), stdout_encoding=None, stderr=sys.stderr,
                      stderr_isatty=sys.stderr.isatty(), colors=256, program_name='http')
    assert env._devnull is None
    assert env.is_windows is True
    assert env.config_dir == Path('configDir')
    assert env.stdin == sys.stdin
    assert env.stdin_isatty is True
    assert env.stdin_

# Generated at 2022-06-11 23:27:19.072309
# Unit test for constructor of class Environment

# Generated at 2022-06-11 23:27:26.047420
# Unit test for constructor of class Environment
def test_Environment():
    class Mock(object):
        def __init__(self, **kwargs):
            self.__dict__ = kwargs

    def assertInit(expected, **kwargs):
        actual = Environment(**kwargs)
        for key, value in expected.items():
            assert getattr(actual, key) == value

    def assertNotInit(expected, **kwargs):
        actual = Environment(**kwargs)
        for key, value in expected.items():
            assert getattr(actual, key) != value


# Generated at 2022-06-11 23:27:30.757182
# Unit test for constructor of class Environment
def test_Environment():
    assert str(Environment()) == '''\
{'colors': 256,
 'config': <Config {'colors': 'auto', 'default_options': []}>,
 'is_windows': False,
 'program_name': 'http',
 'stderr': <_io.TextIOWrapper encoding='UTF-8'>}'''

# Generated at 2022-06-11 23:27:54.352668
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(config_dir='abc', stdout_encoding='def', stdin=None)
    assert env.config_dir == 'abc'
    assert env.stdout_encoding == 'def'
    assert env.stdin == None

    print (env.devnull)


# Generated at 2022-06-11 23:28:02.733124
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert isinstance(env, Environment), "Should be an instance"
    assert env.program_name == 'http'
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert env.stdin_encoding == 'utf8'
    assert env.stdout_encoding == 'utf8'
    assert env.stderr_encoding is None


if __name__ == '__main__':
    # Unit test for class Environment
    print(test_Environment.__doc__)
    test_Environment()
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 23:28:13.354415
# Unit test for constructor of class Environment
def test_Environment():
    from httpie.output.streams import get_binary_stderr
    env = Environment(
        devnull=get_binary_stderr(),
        is_windows=True,
        config_dir=DEFAULT_CONFIG_DIR,
        stdin=sys.stdin,
        stdin_isatty=False,
        stdin_encoding='utf8',
        stdout=sys.stdout,
        stdout_isatty=True,
        stdout_encoding='utf8',
        stderr=sys.stderr,
        stderr_isatty=True,
        program_name='httpie'
    )
    assert env.is_windows == True
    assert env.stderr == sys.stderr
    assert env.stderr_encoding == None

# Unit

# Generated at 2022-06-11 23:28:15.103800
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull = 'This is a test')
    print(env)
    print(env.devnull)

# Generated at 2022-06-11 23:28:20.670389
# Unit test for constructor of class Environment
def test_Environment():
    global env
    env = Environment(config_dir = [DEFAULT_CONFIG_DIR])
    assert isinstance(env, Environment)

# Test for Internal Variables
test_Environment()
env1 = Environment(config_dir = [DEFAULT_CONFIG_DIR])
config = env1.config
print("config: ", config)

# Test the main function


# Generated at 2022-06-11 23:28:29.127030
# Unit test for constructor of class Environment
def test_Environment():
    """
    test_Environment: verify the constructor is created and attributes are set
    """
    a = Environment()
    assert a.is_windows == True
    assert a.config_dir == DEFAULT_CONFIG_DIR
    assert a.stdin == sys.stdin
    assert a.stdin_isatty == True
    assert a.stdin_encoding == None
    assert a.stdout == sys.stdout
    assert a.stdout_isatty == True
    assert a.stdout_encoding == None
    assert a.stderr == sys.stderr
    assert a.stderr_isatty == True
    assert a.colors == 256
    assert a.program_name == 'http'
    assert a.config == None
    assert a.devnull == None
    assert a._orig_

# Generated at 2022-06-11 23:28:38.946336
# Unit test for constructor of class Environment
def test_Environment():
    # if you don't have httpie installed, no worries. Comment and move on
    import httpie
    stdin= httpie.__file__
    f=open(stdin,'r')
    stdout=f.read()
    f.close()
    stdin_isatty= f.isatty()
    stdout_isatty=f.isatty()
    stderr=None
    config_dir= None
    is_windows=False

    if is_windows:
        colors=8
    else:
        colors=256


# Generated at 2022-06-11 23:28:51.024147
# Unit test for constructor of class Environment
def test_Environment():
    # Test object instantiation
    e = Environment()
    assert type(e) is Environment

# Generated at 2022-06-11 23:28:55.940097
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull='',
                      config_dir='',
                      stdout='',
                      stderr='')
    print(env.config)
    print(env)
    print(env.devnull)
    print(env.log_error('hello'))

if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-11 23:28:59.299555
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    print(env.stdin, env.stdout, env.stderr)
    env = Environment(stdin="1", stdout="2", stderr="3")
    print(env.stdin, env.stdout, env.stderr)



# Generated at 2022-06-11 23:29:43.037226
# Unit test for constructor of class Environment
def test_Environment():
    import sys
    import os
    from pathlib import Path
    from typing import IO, Optional
    import pytest
    from httpie import compat
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_CONFIG_DIR, Config, ConfigFileError
    from httpie.utils import repr_dict

    try:
        import curses
    except ImportError:
        curses = None  # Compiled w/o curses
    is_windows = is_windows
    config_dir: Path = DEFAULT_CONFIG_DIR
    stdin: Optional[IO] = sys.stdin  # `None` when closed fd (#791)
    stdin_isatty: bool = stdin.isatty() if stdin else False
    stdin_encoding: str = None

# Generated at 2022-06-11 23:29:48.205675
# Unit test for constructor of class Environment
def test_Environment():
    env=Environment(stdin=None,stdout=sys.stdout,stderr=sys.stderr,program_name='test',colors=256,is_windows=False,config_dir='config_dir')
    assert env.is_windows==False
    assert env.stdin is None
    assert env.program_name=='test'
    assert env.colors==256
    assert env.config_dir=='config_dir'


# Generated at 2022-06-11 23:29:51.929331
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment(devnull= '???', stdin=1, stdout=2, stderr=3, is_windows=True)
    assert e.stdin == 1
    assert e.stdout == 2
    assert e.stderr == 3
    assert e.devnull == '???'

# Generated at 2022-06-11 23:29:55.272290
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        is_windows=True,
        stdin_encoding="gb2312"
    )

    assert env.is_windows == True
    assert env.stdin_encoding=="gb2312"
    

# Generated at 2022-06-11 23:30:05.396514
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    try:
        assert env.is_windows == is_windows
        assert env.config_dir == DEFAULT_CONFIG_DIR
        assert env.stdin == sys.stdin
        assert env.stdin_isatty == sys.stdin.isatty()
        assert env.stdout == sys.stdout
        assert env.stdout_isatty == sys.stdout.isatty()
        assert env.stderr == sys.stderr
        assert env.stderr_isatty == sys.stderr.isatty()
        assert env.program_name == 'http'
    finally:
        env.stdin = None
        env.stdout = None
        env.stderr = None
        env.devnull = None

# Generated at 2022-06-11 23:30:13.674107
# Unit test for constructor of class Environment
def test_Environment():
    assert str(Environment(stdin=None)) == '''\
{
    "program_name": "http",
    "stdin": None,
    "stdin_isatty": False,
    "stdout_isatty": True,
    "stderr_isatty": True
}'''

    assert str(Environment(devnull=2)) == '''\
{
    "program_name": "http",
    "stdin": <_io.TextIOWrapper name='<stdin>' mode='r' encoding='UTF-8'>,
    "stdin_isatty": True,
    "stdout_isatty": True,
    "stderr_isatty": True
}'''


# Generated at 2022-06-11 23:30:18.909109
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=1, stdout=2)
    assert env.stdin == 1
    assert env.stdout == 2
    assert env.stderr == sys.stderr
    assert env.is_windows == is_windows
    # assert env.stderr_isatty == env.__dict__[stderr].isatty()

# Generated at 2022-06-11 23:30:29.126780
# Unit test for constructor of class Environment
def test_Environment():
    def assert_env(env, **kwargs):
        assert env.config_dir == Config(directory=env.config_dir).directory
        assert env.colors == kwargs.pop('colors', 256)
        assert env.program_name == kwargs.pop('program_name', 'http')
        assert env.stdin.isatty() == kwargs.pop('stdin_isatty', sys.stdin.isatty())
        assert env.stdout.isatty() == kwargs.pop('stdout_isatty', sys.stdout.isatty())
        assert env.stderr.isatty() == kwargs.pop('stderr_isatty', sys.stderr.isatty())
        assert kwargs == {}

    env = Environment()
    assert env

# Generated at 2022-06-11 23:30:38.137892
# Unit test for constructor of class Environment
def test_Environment():
    # First, check that all of the data members were created
    env = Environment()
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'

    # Next, check that kwargs override the data members with Environment

# Generated at 2022-06-11 23:30:39.921164
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert isinstance(env, Environment)

if __name__ == "__main__":
    test_Environment()

# Generated at 2022-06-11 23:32:01.845238
# Unit test for constructor of class Environment
def test_Environment():
    """ Unit test for constructor of class Environment """
    # httpie\httpie\input.py
    env = Environment(stdin=sys.stdin, stdin_isatty=True, stdin_encoding='utf8', stdout=sys.stdout, stdout_isatty=True, stdout_encoding='utf8', stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http')

# Generated at 2022-06-11 23:32:10.766983
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    env_dict = Environment.__dict__.copy()
    env_dict.pop("__dict__")
    env_dict.pop("__weakref__")
    env_dict.pop("__doc__")
    env_dict.pop("__module__")
    for k,v in env_dict.items():
        print(k, v)
    print("-------------------------")
    for k,v in env.__dict__.items():
        print(k, v)
    print("-------------------------")
    for k,v in env_dict.items():
        print(k, env.__dict__[k])


if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-11 23:32:13.974397
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        program_name = 'http',
        stdin = sys.stdin,
        stdout = sys.stdout,
        stderr = sys.stderr
    )
    print('~'*10)
    print(env)

# Generated at 2022-06-11 23:32:16.737476
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(config_dir='test_config_dir', is_windows=False)
    assert env.config_dir == 'test_config_dir'
    assert env.is_windows == False

# Generated at 2022-06-11 23:32:26.922707
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        stdout = sys.stdout,
        stdout_isatty = sys.stdout.isatty(),
        stderr = sys.stderr,
        stderr_isatty = sys.stderr.isatty(),
        stdin = sys.stdin,
        stdin_isatty = sys.stdin.isatty(),
        stdin_encoding = sys.stdin.encoding,
        stdout_encoding = sys.stdout.encoding
    )
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
   

# Generated at 2022-06-11 23:32:35.714340
# Unit test for constructor of class Environment
def test_Environment():
    if __name__ == '__main__':
        sys.stdout.write('Testing Environment Class')
        assert Environment.config_dir == Path.home() / '.httpie'
        assert Environment.stdin == sys.stdin 
        assert Environment.stdout == sys.stdout
        assert Environment.stderr == sys.stderr
        assert Environment.program_name == 'http'
        assert Environment._orig_stderr == sys.stderr
        assert Environment._devnull == None
        assert Environment.stdin_encoding == sys.stdin.encoding
        assert Environment.stdout_encoding == sys.stdout.encoding
        assert Environment.is_windows == sys.platform.startswith('win32')

    else:
        raise Exception('Unit tests should be run from main module.')
