

# Generated at 2022-06-11 23:22:47.205875
# Unit test for constructor of class Environment
def test_Environment():
    # Default environment
    Environment().__str__()
    # Overwrite an attribute
    Environment(program_name='curl').__str__()
    # Fail if the attribute is not known
    try:
        Environment(unknown='unknown').__str__()
    except:
        pass
    else:
        assert False

# Generated at 2022-06-11 23:22:50.435750
# Unit test for constructor of class Environment
def test_Environment():
    import sys
    env = Environment()
    env.is_windows = sys.platform == 'win32'
    env.stdin = sys.stdin
    env.stdout = sys.stdout
    env.stderr = sys.stderr
    print(env)

# Generated at 2022-06-11 23:22:54.123858
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdout=sys.stderr, stdout_encoding='utf8', config_dir=DEFAULT_CONFIG_DIR.joinpath('httpie'))
    assert env.stdout == sys.stderr
    assert env.stdout_encoding == 'utf8'
    assert env.config_dir == DEFAULT_CONFIG_DIR.joinpath('httpie')

# Generated at 2022-06-11 23:23:01.536414
# Unit test for constructor of class Environment
def test_Environment():
    import io
    data = {}
    data['stdin'] = io.StringIO()
    data['stdout'] = io.StringIO()
    data['stderr'] = io.StringIO()
    data['program_name'] = 'httpie'
    newEnv = Environment(**data)
    assert newEnv.stdin == data['stdin']
    assert newEnv.stdout == data['stdout']
    assert newEnv.stderr == data['stderr']
    assert newEnv.program_name == 'httpie'

# Generated at 2022-06-11 23:23:08.380842
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull="test devnull=opend file")
    assert env.devnull == "test devnull=opend file"

    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == (sys.stdin.isatty() if sys.stdin else False)
    assert env.stdin_encoding == (sys.stdin.encoding if sys.stdin else None)
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == (sys.stdout.encoding if sys.stdout else None)

# Generated at 2022-06-11 23:23:18.938134
# Unit test for constructor of class Environment
def test_Environment():

    # Test the constructor of class Environment
    env = Environment(**{
        'devnull': None,
        'is_windows': False,
        'config_dir': Path(''),
        'stdin': sys.stdin,
        'stdin_isatty': sys.stdin.isatty(),
        'stdin_encoding': None,
        'stdout': sys.stdout,
        'stdout_isatty': sys.stdout.isatty(),
        'stdout_encoding': None,
        'stderr': sys.stderr,
        'stderr_isatty': sys.stderr.isatty(),
        'colors': 256,
        'program_name': 'http',
    })

    # Test properties and methods of class Environment

# Generated at 2022-06-11 23:23:28.050364
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment(stdout=None, is_windows=False, config_dir=Path("test"))
    assert "stdout=None" in repr(e)
    assert "is_windows=False" in repr(e)
    assert "config_dir=PosixPath('test')" in repr(e)
    assert e.config_dir == Path("test")
    assert e.colors == 256
    assert not e.stdout_isatty
    assert not e.stderr_isatty
    assert e.stdout_encoding == 'utf8'
    assert e.stdout is None

if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-11 23:23:35.868762
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env is not None
    assert env.is_windows is is_windows
    assert env.stdin is sys.stdin
    assert env.stdin_encoding is None
    assert env.stdout is sys.stdout
    assert env.stdout_encoding is None
    assert env.stderr is sys.stderr
    assert env.stderr_isatty is sys.stderr.isatty()
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.program_name == 'http'

# Generated at 2022-06-11 23:23:47.689116
# Unit test for constructor of class Environment
def test_Environment():
    Env = Environment
    env = Env()
    assert env.is_windows == Env.is_windows
    assert env.config_dir == Env.config_dir
    assert env.stdin == Env.stdin
    assert env.stdin_isatty == Env.stdin_isatty
    assert env.stdout == Env.stdout
    assert env.stdout_isatty == Env.stdout_isatty
    assert env.stderr == Env.stderr
    assert env.stderr_isatty == Env.stderr_isatty
    assert env.colors == Env.colors
    assert env.program_name == Env.program_name
    assert env._orig_stderr == env.stderr
    assert env._devnull

# Generated at 2022-06-11 23:23:49.351574
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    stdout = env.stdout
    fs = env.config_dir



# Generated at 2022-06-11 23:23:59.250919
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(is_windows=True)
    assert env.is_windows
    assert env.stdout_isatty
    assert env.stderr_isatty
    assert env.stdin.read() == ''
    assert env.stdout.read() == ''
    assert env.stderr.read() == ''
    assert env.config_dir == DEFAULT_CONFIG_DIR



#env = Environment()
#print(env.__str__())

# Generated at 2022-06-11 23:24:11.101045
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name='http', stdin=None, stdin_isatty='False', stdin_encoding=None, stdout=sys.stdout, stdout_isatty=sys.stdout.isatty(), stdout_encoding=None, stderr=sys.stderr, stderr_isatty=sys.stderr.isatty())
    assert env.program_name == 'http'
    assert env.stdin == None
    assert env.stdin_isatty == 'False'
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stder

# Generated at 2022-06-11 23:24:13.817662
# Unit test for constructor of class Environment
def test_Environment():
    logger = Environment()
    logger.log_error("test message")
    assert(logger.program_name == "http")

# Generated at 2022-06-11 23:24:21.095617
# Unit test for constructor of class Environment
def test_Environment():
    tmp_stdin = sys.stdin
    tmp_stdout = sys.stdout
    tmp_stderr = sys.stderr
    env = Environment()
    # Check to see if we can write to the attribute
    assert env.stdin is sys.stdin
    assert env.stdout is sys.stdout
    assert env.stderr is sys.stderr
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.is_windows == is_windows
    assert env.program_name == 'http'
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr_isatty == sys.stderr.isatty()

# Generated at 2022-06-11 23:24:28.599689
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        devnull = open(os.devnull, 'w+'),
        is_windows = False,
        config_dir = DEFAULT_CONFIG_DIR,
        stdin = sys.stdin,
        stdin_encoding = 'utf8',
        stdout = sys.stdout,
        stdout_encoding = 'utf8',
        stderr = sys.stderr,
        program_name = 'http'
    )
    assert repr(env)

if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-11 23:24:39.427183
# Unit test for constructor of class Environment
def test_Environment():
    # Environment() 
    #开始新建一个实例，调用类的__init__函数
    env = Environment(foo='bar')
    # 给对象新加属性 
    env.foo = 'foo' 
    # print('env.foo = {}'.format(env.foo))

    # 对象的__dict__属性返回一个字典，它的键是类的属性，值是实例的值，
    # 这个字典可以直接修改，

# Generated at 2022-06-11 23:24:49.657372
# Unit test for constructor of class Environment
def test_Environment():
    stdin = sys.stdin
    stdout = sys.stdout
    stderr = sys.stderr
    env = Environment()
    assert env.stdin == stdin
    assert env.stdout == stdout
    assert env.stderr == stderr
    assert env.stdin_isatty == stdin.isatty()
    assert env.stdout_isatty == stdout.isatty()
    assert env.stderr_isatty == stderr.isatty()
    assert env.stdin_encoding is None
    assert env.stdout_encoding is None
    assert env.colors == 256
    assert env.program_name == 'http'

# Generated at 2022-06-11 23:24:56.477245
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding is None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding is None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.program_name == 'http'
    assert env.colors == 256

# Generated at 2022-06-11 23:25:04.327625
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert env.stdin_isatty is True or env.stdin_isatty is False
    assert env.stdout_isatty is True or env.stdout_isatty is False
    assert env.stderr_isatty is True or env.stderr_isatty is False
    env = Environment(stdin=None, stdout=None, stderr=None)
    assert env.stdin is None
    assert env.stdout is None
    assert env.stderr is None
    assert env.stdin_isatty is False
    assert env.stdout_isatty is False
    assert env.st

# Generated at 2022-06-11 23:25:12.772155
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().is_windows == is_windows
    assert Environment().config_dir == DEFAULT_CONFIG_DIR
    assert Environment().stdin == sys.stdin
    assert Environment().stdin_isatty == sys.stdin.isatty()
    assert Environment().stdin_encoding is None
    assert Environment().stdout == sys.stdout
    assert Environment().stdout_isatty == sys.stdout.isatty()
    assert Environment().stdout_encoding is None
    assert Environment().stderr == sys.stderr
    assert Environment().stderr_isatty == sys.stderr.isatty()
    assert Environment().colors == 256
    assert Environment().program_name == 'http'
    try:
        curses.setupterm()
    except curses.error:
        pass

# Generated at 2022-06-11 23:25:31.505313
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(is_windows=True)
    assert env.is_windows == True
    env.is_windows = False
    assert env.is_windows == False

    env = Environment()
    assert env.is_windows == is_windows

    assert env.config_dir == DEFAULT_CONFIG_DIR
    env.config_dir = 'path/to/config'
    assert env.config_dir == 'path/to/config'

    assert env.stdin == sys.stdin
    env.stdin = 'http'
    assert env.stdin == 'http'

    assert env.stdin_isatty == sys.stdin.isatty()
    env.stdin_isatty = False
    assert env.stdin_isatty == False

    assert env.stdin_encoding == sys.stdin

# Generated at 2022-06-11 23:25:34.612693
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name='http', devnull='/dev/null')
    env.program_name
    assert env.program_name == 'http'
    assert env.devnull == '/dev/null'


# Generated at 2022-06-11 23:25:41.182578
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        stdin=io.StringIO(),
        stdout=io.StringIO(),
        stderr=io.StringIO(),
        config_dir='.'
    )
    assert env.stdin.__class__.__name__ == 'StringIO'
    assert env.stdout.__class__.__name__ == 'StringIO'
    assert env.stderr.__class__.__name__ == 'StringIO'
    assert env.config_dir == '.'

test_Environment()

# Generated at 2022-06-11 23:25:44.438203
# Unit test for constructor of class Environment
def test_Environment():
    env=Environment()
    assert env.stderr_isatty == True
    assert env.stdin.isatty() == false
    assert env.stdout.isatty() == true

# Generated at 2022-06-11 23:25:48.400430
# Unit test for constructor of class Environment
def test_Environment():
    # print("[test_Environment] start")
    # env = Environment(stdin_encoding=None, stdout_encoding=None)
    # print(env)
    # print("[test_Environment] end")
    pass

if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-11 23:25:50.400919
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment() 
    env.program_name = 'foo'
    assert env.program_name == 'foo'

# Generated at 2022-06-11 23:25:52.218419
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(key='value')
    assert env.key == 'value'



# Generated at 2022-06-11 23:26:01.549502
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull="test",
                      is_windows=False,
                      config_dir='test_config_dir',
                      stdin="test",
                      stdin_isatty=False,
                      stdin_encoding='EUC-KR',
                      stdout="test",
                      stdout_isatty=False,
                      stdout_encoding='EUC-KR',
                      stderr="test",
                      stderr_isatty=False,
                      colors=256,
                      program_name='test_program_name',
                      _config="test")

    print(env.devnull)
    print(env.is_windows)
    print(env.config_dir)
    print(env.stdin)
    print(env.stdin_isatty)

# Generated at 2022-06-11 23:26:10.010273
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()

# Generated at 2022-06-11 23:26:17.992561
# Unit test for constructor of class Environment
def test_Environment():
    try:
        env = Environment(stdin='stdin', stdin_isatty='stdin_isatty', stdin_encoding='stdin_encoding',
                          stdout='stdout', stdout_isatty='stdout_isatty', stdout_encoding='stdout_encoding',
                          stderr='stderr', stderr_isatty='stderr_isatty',
                          colors='colors', program_name='program_name')
        print(repr(env))
    except Exception as e:
        print(e)


# Generated at 2022-06-11 23:26:37.959633
# Unit test for constructor of class Environment
def test_Environment():
    print('Test for Environment')
    print('is_windows:')
    print(Environment().is_windows)
    print('config_dir:')
    print(Environment().config_dir)
    print('stdin:')
    print(Environment().stdin)
    print('stdin_encoding:')
    print(Environment().stdin_encoding)
    print('stdout:')
    print(Environment().stdout)
    print('stdout_encoding:')
    print(Environment().stdout_encoding)
    print('stderr:')
    print(Environment().stderr)
    print('colors:')
    print(Environment().colors)
    print('program_name:')
    print(Environment().program_name)

# Generated at 2022-06-11 23:26:42.905122
# Unit test for constructor of class Environment
def test_Environment():
    ENV = Environment()
    assert ENV.is_windows == True
    assert ENV.stdout_isatty == True
    assert ENV.stdout_encoding == 'UTF-8'
    assert ENV.stderr_isatty == True
    print(ENV._orig_stderr)



# Generated at 2022-06-11 23:26:53.485732
# Unit test for constructor of class Environment
def test_Environment():
    import io
    import pytest
    from httpie.config import Config
    from httpie.environment import Environment
    class DummyStdin(io.IOBase):
        pass
    dummy_stdin = DummyStdin()
    dummy_stdout = io.StringIO()
    dummy_stderr = io.StringIO()
    dummy_devnull = io.StringIO()

# Generated at 2022-06-11 23:26:55.674193
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull = 1, is_windows = False)
    assert env.devnull == 1
    assert env.is_windows == False

# Generated at 2022-06-11 23:27:06.950350
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name='http-test')
    assert env.program_name == 'http-test'
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty() if sys.stdin else False
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256


# Generated at 2022-06-11 23:27:15.877571
# Unit test for constructor of class Environment
def test_Environment():
    """Unit test for constructor of class Environment."""

    def test():
        env = Environment()
        assert env.is_windows == is_windows
        assert env.config_dir == DEFAULT_CONFIG_DIR
        assert env.stdin is sys.stdin
        assert env.stdin_isatty == env.stdin.isatty()
        assert env.stdin_encoding == None
        assert env.stdout is sys.stdout
        assert env.stdout_isatty == env.stdout.isatty()
        assert env.stdout_encoding == None
        assert env.stderr is sys.stderr
        assert env.stderr_isatty == env.stderr.isatty()

    test()



# Generated at 2022-06-11 23:27:23.804830
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment()
    assert e.is_windows == is_windows
    assert e.config_dir == DEFAULT_CONFIG_DIR
    assert e.stdin_isatty == sys.stdin.isatty() if sys.stdin else False
    assert e.stdin_encoding is None
    assert e.stdout == sys.stdout
    assert e.stdout_isatty == sys.stdout.isatty()
    assert e.stdout_encoding is None
    assert e.stderr == sys.stderr
    assert e.stderr_isatty == sys.stderr.isatty()
    assert e.colors == 256
    assert e.program_name == 'http'



# Generated at 2022-06-11 23:27:34.152007
# Unit test for constructor of class Environment
def test_Environment():
    environment=Environment()
    assert environment.is_windows == is_windows
    assert environment.colors == 16
    assert environment.stdout_isatty == sys.stdout.isatty()
    assert environment.stdin_isatty == sys.stdin.isatty()
    assert environment.stdout_encoding == 'utf8'
    assert environment.stderr_isatty == sys.stderr.isatty()

    if curses != None:
        # noinspection PyUnresolvedReferences
        import colorama.initialise
        # noinspection PyUnresolvedReferences
        from colorama import AnsiToWin32
        colorama.initialise.wrap_stream(
            sys.stderr, convert=None, strip=None,
            autoreset=True, wrap=True
        )
        environment

# Generated at 2022-06-11 23:27:42.404139
# Unit test for constructor of class Environment
def test_Environment():
    class TempFileStdin:
        name = '<stdin>'
        mode = ''
        def __init__(self):
            self.fp = open("tempfile.txt", "w+")
        def read(self, i):
            return self.fp.read(i)
        def readline(self):
            return self.fp.readline()
    d = Environment(stdin=TempFileStdin(),
                    stdout=open("tempfile.txt", "w+"),
                    stderr=open("tempfile.txt", "w+"),
                    devnull=open("tempfile.txt", "w+"),
                    colors=256,
                    program_name='http')

# Generated at 2022-06-11 23:27:44.017804
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().program_name == 'http'

# Generated at 2022-06-11 23:28:15.062620
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env
    assert env.is_windows is is_windows
    assert env.config_dir is DEFAULT_CONFIG_DIR
    assert env.stdin is sys.stdin
    assert env.stdin_isatty is sys.stdin.isatty()
    assert env.stdin_encoding is None
    assert env.stdout is sys.stdout
    assert env.stdout_isatty is sys.stdout.isatty()
    assert env.stdout_encoding is None
    assert env.stderr is sys.stderr
    assert env.stderr_isatty is sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env.__str__()

# Generated at 2022-06-11 23:28:18.573828
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name='http', stdin='test')
    m = env.program_name
    assert m == 'http'
    # stdin expects to be 'test'
    m = env.stdin_isatty
    assert m is not True

# Generated at 2022-06-11 23:28:27.515385
# Unit test for constructor of class Environment
def test_Environment():
    """
    >>> from pyperclip import copy
    >>> copy(repr(Environment()))
    >>> copy(repr(Environment(stdin=None)))
    >>> copy(repr(Environment(stdin_isatty=False)))
    >>> copy(repr(Environment(stdin_isatty=False, stdin_encoding=None)))
    >>> copy(repr(Environment(stdin_isatty=False, stdin_encoding=None, stdout=None)))
    >>> copy(repr(Environment(stdin_isatty=False, stdin_encoding=None, stdout=None, config_dir=None)))
    """
    pass

# Generated at 2022-06-11 23:28:37.214269
# Unit test for constructor of class Environment
def test_Environment():
    environ = Environment(
        is_windows=True,
        config_dir=DEFAULT_CONFIG_DIR,
        stdin=sys.stdin,
        stdin_encoding='utf8',
        stdout=sys.stdout,
        stdout_encoding='utf8',
        stderr=sys.stderr,
        stderr_encoding='utf8',
        colors=256,
        program_name='kunal'
    )
    interm = {}
    for key,value in environ.__dict__.items():
        if (key == '_devnull' or key == '_orig_stderr'):
            continue
        interm[key] = value

# Generated at 2022-06-11 23:28:38.068650
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment(devnull=1)

# Generated at 2022-06-11 23:28:45.823927
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdout=None, stderr=None)
    assert env.stdin == None
    assert env.stdin_isatty == False
    assert env.stdin_encoding == None
    assert env.stdout == None
    assert env.stdout_isatty == False
    assert env.stdout_encoding == None
    assert env.stderr == None
    assert env.stderr_isatty == False


# Generated at 2022-06-11 23:28:55.272378
# Unit test for constructor of class Environment
def test_Environment():
    d = {"config_dir":Path("a", "b", "c"),"stdin":sys.stdin,"stdin_isatty":sys.stdin.isatty(),"stdin_encoding":sys.stdin.encoding,
    "stdout":sys.stdout,"stdout_isatty":sys.stdout.isatty(),"stdout_encoding":sys.stdout.encoding,"stderr":sys.stderr,
    "stderr_isatty":sys.stderr.isatty(),"colors":256,"program_name":"http"}
    e = Environment(**d)
    assert e.__dict__ == d

# Generated at 2022-06-11 23:28:57.641080
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    print(env.__dict__)
    print(env.__str__())
    print(str(env))
    print(repr(env))

# Generated at 2022-06-11 23:28:59.191963
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name='test')
    assert env.program_name == 'test'

test_Environment()

# Generated at 2022-06-11 23:29:04.554047
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.stdout == sys.stdout
    assert env.is_windows == is_windows
    assert env.stderr == sys.stderr
    assert env.stdin_isatty == sys.stdin.isatty()
    env = Environment(stdout=sys.stderr)
    assert env.stdout == sys.stderr

# Generated at 2022-06-11 23:29:56.233203
# Unit test for constructor of class Environment
def test_Environment():
    #test for overwriting
    env = Environment(stdin="test.txt")
    assert env.stdin == "test.txt"
    # test for init with no overwriting
    env = Environment()
    assert env.stdin == sys.stdin
    # test for __str__

# Generated at 2022-06-11 23:29:57.197069
# Unit test for constructor of class Environment
def test_Environment():
    environment: Environment = Environment()
    print(environment)

# Generated at 2022-06-11 23:30:07.356127
# Unit test for constructor of class Environment
def test_Environment():
    """
    测试Environment类的构造函数
    :return:
    """

    env = Environment(is_windows=False)

    assert env.is_windows == False
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == False
    assert env.stdin_encoding == "utf-8"
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stdout_encoding == "cp936"
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == True
    assert env.colors == 256

# Generated at 2022-06-11 23:30:11.716762
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment(colors=256, stdout=sys.stdout)
    assert e.colors == 256
    assert e.stdout == sys.stdout
    assert e.stdout_isatty
    assert e.stdout_encoding
    assert e.stderr_encoding

# Generated at 2022-06-11 23:30:21.660286
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    # assert type(env) == Environment
    assert env.is_windows == False
    config_dir = Path('.config/httpie')
    assert env.config_dir == config_dir
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'

# Generated at 2022-06-11 23:30:28.616760
# Unit test for constructor of class Environment
def test_Environment():
    class TestEnv(Environment):
        pass
    try:
        os.mkdir('./test_config')
    except FileExistsError:
        pass
    env = TestEnv(config_dir='./test_config')
    assert env.config_dir == './test_config'
    config = env.config
    print(repr(config))
    assert config.get('all', 'default_options') == []
    assert config.get('all', 'max_history_items') == '100'

# Generated at 2022-06-11 23:30:36.284348
# Unit test for constructor of class Environment
def test_Environment():
    global env
    env = Environment(
        config_dir = '/Users/YiqingFeng/Desktop',
        stdin = sys.stdin,
        stdin_isatty = True,
        stdin_encoding = None,
        stdout = sys.stdout,
        stdout_isatty = True,
        stdout_encoding = None,
        stderr = sys.stderr,
        stderr_isatty = True,
        colors = 2,
        program_name = 'http',
        devnull = None,
    )
    print(env)
    # assert 2 > 3

# Generated at 2022-06-11 23:30:42.369876
# Unit test for constructor of class Environment
def test_Environment():
    env_1 = Environment(is_windows=not is_windows)
    assert not env_1.is_windows

    env_2 = Environment(stdout_isatty=not env_1.stdout_isatty)
    assert not env_2.stdout_isatty

    try:
        env_3 = Environment(stdin=False)
        assert env_3.stdin is None
    except AttributeError:
        pass
    except:
        raise

    env_4 = Environment(stderr=False)
    assert env_4.stderr is None


# Generated at 2022-06-11 23:30:52.560185
# Unit test for constructor of class Environment
def test_Environment():
    import io
    import tempfile
    import os
    from pathlib import Path
    def get_isatty(stream):
        return stream.isatty()
    def get_encoding(stream):
        return getattr(stream, 'encoding', None) or 'utf8'
    stdin = open(os.devnull, 'r')
    stdout = tempfile.TemporaryFile(mode='w+')
    stderr = tempfile.TemporaryFile(mode='w+')
    devnull = open(os.devnull, 'w+')
    config_dir = Path(tempfile.TemporaryDirectory().name)

# Generated at 2022-06-11 23:31:01.677278
# Unit test for constructor of class Environment
def test_Environment():
	env = Environment()

# Generated at 2022-06-11 23:32:32.772491
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        program_name='http',
        stdin_encoding='utf8',
        stdout_encoding='utf8',
    )
    assert env.program_name == 'http'
    assert env.stdin_encoding == 'utf8'
    assert env.stdout_encoding == 'utf8'

# Generated at 2022-06-11 23:32:35.956492
# Unit test for constructor of class Environment
def test_Environment():
    stream = open('a.txt', 'w+')
    environment = Environment(stdin=stream, devnull="null")
    assert environment.stdin == stream
    assert environment.devnull == "null"