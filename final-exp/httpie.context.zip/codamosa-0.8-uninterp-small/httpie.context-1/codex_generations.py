

# Generated at 2022-06-25 18:15:29.777528
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    environment_1 = Environment()
    print(environment_0)
    print(environment_1)


# Generated at 2022-06-25 18:15:35.091167
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    environment_1 = Environment()
    assert environment_0.stdin == sys.stdin
    assert environment_0.stdout == sys.stdout
    assert environment_0.stderr == sys.stderr
    assert environment_0.stdin_isatty
    assert environment_0.stdout_isatty
    assert environment_0.stderr_isatty


# Generated at 2022-06-25 18:15:44.111943
# Unit test for constructor of class Environment
def test_Environment():
    # test construction of a environment instance
    environment_0 = Environment()
    del environment_0
    # test construction of a environment instance with keyword arguments
    environment_1 = Environment(dir='1', stdin='2', stdin_isatty=True, stdin_encoding='3', stdout='4', stdout_isatty=True, stdout_encoding='5', stderr='6', stderr_isatty=True, colors=128, program_name='7')
    del environment_1

# Generated at 2022-06-25 18:15:50.716841
# Unit test for constructor of class Environment
def test_Environment():
    test_devnull = open(os.devnull, 'w+')
    test_stdin = open(os.devnull, 'r')
    test_stdout = open(os.devnull, 'w+')
    test_stderr = open(os.devnull, 'w+')
    test_isatty_stdin = test_stdin.isatty()
    test_isatty_stdout = test_stdout.isatty()
    test_isatty_stderr = test_stderr.isatty()
    test_stdin_encoding = test_stdin.encoding or 'utf8'
    test_stdout_encoding = test_stdout.encoding or 'utf8'
    test_program_name = 'http'

# Generated at 2022-06-25 18:15:52.803590
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().__str__().__len__() > 0


# Generated at 2022-06-25 18:15:56.403340
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert(environment_0.stdout.write("Hello, world!"))
    assert(environment_0.stdin.readline() == 'Hello, world!\n')
    assert(environment_0.stderr.write("Hello, world!"))

# Generated at 2022-06-25 18:16:00.048436
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(is_windows=False, config_dir=Path('./test'))
    assert environment_1.is_windows == False
    assert environment_1.config_dir == Path('./test')
    assert environment_1.stdout_isatty == True
    assert environment_1.stderr_isatty == True
    assert environment_1.colors == 256


# Generated at 2022-06-25 18:16:12.061005
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment(devnull=sys.stdout)
    assert environment_0.devnull == sys.stdout
    assert environment_0.is_windows == True
    assert environment_0.config_dir == DEFAULT_CONFIG_DIR
    assert environment_0.stdin == sys.stdin
    assert environment_0.stdin_isatty == True
    assert environment_0.stdin_encoding == 'utf8'
    assert environment_0.stdout == sys.stdout
    assert environment_0.stdout_encoding == 'utf8'
    assert environment_0.stderr == sys.stderr
    assert environment_0.stderr_isatty == True
    assert environment_0.colors == 256
    assert environment_0.program_name == 'http'
    assert environment_0

# Generated at 2022-06-25 18:16:20.008753
# Unit test for constructor of class Environment
def test_Environment():
    config = Config(directory= DEFAULT_CONFIG_DIR)

# Generated at 2022-06-25 18:16:24.816967
# Unit test for constructor of class Environment
def test_Environment():
    # test when args is none
    try:
        test_case_0()
    except TypeError:
        print("Parameter ERROR!")


if __name__ == "__main__":
    test_Environment()

# Generated at 2022-06-25 18:16:31.793619
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(is_windows=True, config_dir=DEFAULT_CONFIG_DIR)
    env = Environment(stdin=sys.stdin, devnull=os.devnull)
    env = Environment(devnull=os.devnull)
    assert env.devnull == open(os.devnull, 'w+')
    assert env.stdin == sys.stdin
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.is_windows == True

# Generated at 2022-06-25 18:16:33.590359
# Unit test for constructor of class Environment
def test_Environment():
    general_test_environment = Environment()
    assert isinstance(general_test_environment, Environment)

# Generated at 2022-06-25 18:16:45.338108
# Unit test for constructor of class Environment
def test_Environment():
    # Unit test for constructor of class Environment
    # Initialization of environment object
    environment_0 = Environment()

    # Access attributes of environment object
    print(environment_0.is_windows)
    print(environment_0.config_dir)
    print(environment_0.stdin)
    print(environment_0.stdin_isatty)
    print(environment_0.stdin_encoding)
    print(environment_0.stdout)
    print(environment_0.stdout_isatty)
    print(environment_0.stdout_encoding)
    print(environment_0.stderr)
    print(environment_0.stderr_isatty)
    print(environment_0.colors)
    print(environment_0.program_name)

# Generated at 2022-06-25 18:16:54.657154
# Unit test for constructor of class Environment
def test_Environment():
    # testing constructor
    environment_1 = Environment()
    assert environment_1.is_windows == True
    assert environment_1.stdin.fileno() == 0
    assert environment_1.stdout.fileno() == 1
    assert environment_1.stderr.fileno() == 2

    # testing overwriting variable program_name
    environment_1.program_name = 'httpie'
    assert environment_1.program_name == 'httpie'

    # testing overwriting variable is_windows
    environment_1.is_windows = False
    assert environment_1.is_windows == False

    # testing overwriting variable stdin
    environment_1.stdin = sys.stdout
    assert environment_1.stdin.fileno() == 1

    # testing overwriting variable stdout
    environment_1.std

# Generated at 2022-06-25 18:16:57.007507
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()

test_Environment()

# Generated at 2022-06-25 18:17:01.635614
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert isinstance(environment, Environment)
    assert callable(environment.config)
    assert callable(environment.log_error)
    assert hasattr(environment, 'devnull')
    assert callable(environment.__repr__)
    assert callable(environment.__str__)


# Generated at 2022-06-25 18:17:12.055683
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(
        devnull=None,
        is_windows=False,
        config_dir=Path('/Users/chenzhihao/.config/httpie'),
        stdin=sys.stdin,
        stdin_isatty=True,
        stdin_encoding=None,
        stdout=sys.stdout,
        stdout_isatty=True,
        stdout_encoding=None,
        stderr=sys.stderr,
        stderr_isatty=True,
        colors=256,
        program_name='http'
    )


# Generated at 2022-06-25 18:17:13.722839
# Unit test for constructor of class Environment
def test_Environment():
    try:
        environment_0 = Environment()
        assert True
    except:
        assert False


# Generated at 2022-06-25 18:17:15.691102
# Unit test for constructor of class Environment
def test_Environment():
    # Test Environment.is_windows == is_windows()
    assert Environment().is_windows == is_windows()


# Generated at 2022-06-25 18:17:25.013061
# Unit test for constructor of class Environment
def test_Environment():
    # stdin_isatty
    if environment_0.stdin is None:
        assert not environment_0.stdin_isatty
    else:
        assert environment_0.stdin_isatty
    # stdout_isatty
    if environment_0.stdout is None:
        assert not environment_0.stdout_isatty
    else:
        assert environment_0.stdout_isatty
    # stderr_isatty
    if environment_0.stderr is None:
        assert not environment_0.stderr_isatty
    else:
        assert environment_0.stderr_isatty

    assert environment_0.is_windows == is_windows
    assert environment_0.config_dir == DEFAULT_CONFIG_DIR
    assert environment_0.std

# Generated at 2022-06-25 18:17:41.190440
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()
    assert environment_1.is_windows == is_windows
    assert environment_1.config_dir == DEFAULT_CONFIG_DIR
    assert environment_1.stdin == sys.stdin
    assert environment_1.stdin_isatty == (
        sys.stdin.isatty() if sys.stdin else False)
    assert environment_1.stdin_encoding == None
    assert environment_1.stdout == sys.stdout
    assert environment_1.stdout_isatty == sys.stdout.isatty()
    assert environment_1.stdout_encoding == None
    assert environment_1.stderr == sys.stderr
    assert environment_1.stderr_isatty == sys.stderr.isatty()
    assert environment_1

# Generated at 2022-06-25 18:17:43.115660
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()

if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-25 18:17:52.313868
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().is_windows == is_windows
    assert Environment().config_dir == DEFAULT_CONFIG_DIR
    assert Environment().stdin == sys.stdin
    assert Environment().stdin_isatty == sys.stdin.isatty() if sys.stdin else False
    assert Environment().stdin_encoding is None
    assert Environment().stdout == sys.stdout
    assert Environment().stdout_isatty == sys.stdout.isatty()
    assert Environment().stdout_encoding is None
    assert Environment().stderr == sys.stderr
    assert Environment().stderr_isatty == sys.stderr.isatty()
    assert Environment().colors == 256
    assert Environment().program_name == 'http'
    return Environment()


# Generated at 2022-06-25 18:18:00.234656
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()

# Generated at 2022-06-25 18:18:05.265721
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_encoding == 'utf8'
    assert env.stdout_encoding == 'utf8'

# Generated at 2022-06-25 18:18:12.799102
# Unit test for constructor of class Environment
def test_Environment():
    class mock_sys:
        stdin = 'stdin'
        stdout = 'stdout'
        stderr = 'stderr'

    class mock_os:
        def devnull(self):
            pass

    with mock.patch('httpie.environment.sys', mock_sys),\
        mock.patch('httpie.environment.os', mock_os):
        environment = Environment()
        assert environment.stdin == 'stdin'
        assert environment.stdout == 'stdout'
        assert environment.stderr == 'stderr'



# Generated at 2022-06-25 18:18:23.708800
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    environment_1 = Environment(**{})
    environment_2 = Environment(is_windows=False, **{})
    environment_3 = Environment(is_windows=False, stdin=None, **{})
    environment_4 = Environment(is_windows=False, stdin=None, stdin_encoding=None, **{})
    environment_5 = Environment(is_windows=False, stdin=None, stdin_encoding=None, stdin_isatty=False, **{})
    environment_6 = Environment(is_windows=False, stdin=None, stdin_encoding=None, stdin_isatty=False, stdout=sys.stdout, **{})

# Generated at 2022-06-25 18:18:31.869115
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    environment_1 = Environment(devnull='', is_windows=False, config_dir=Path('/home/beingsimple/Downloads/all-httpiejuice-dev'), stdin=None, stdin_isatty=False, stdin_encoding='utf8', stdout=sys.stdout, stdout_isatty=True, stdout_encoding='utf8', stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='httpjuice')
    assert environment_0 is not None
    assert environment_1 is not None


# Generated at 2022-06-25 18:18:43.114632
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.is_windows == is_windows
    assert environment_0.config_dir == DEFAULT_CONFIG_DIR
    assert environment_0.stdin == sys.stdin
    assert environment_0.stdin_isatty == (sys.stdin.isatty() if sys.stdin else False)
    assert environment_0.stdout == sys.stdout
    assert environment_0.stdout_isatty == sys.stdout.isatty()
    assert environment_0.stderr == sys.stderr
    assert environment_0.stderr_isatty == sys.stderr.isatty()
    assert environment_0.colors == (256 if is_windows else 1)
    assert environment_0.program_name == 'http'


#

# Generated at 2022-06-25 18:18:44.059867
# Unit test for constructor of class Environment
def test_Environment():
    assert isinstance(Environment(), Environment)


# Generated at 2022-06-25 18:18:57.813298
# Unit test for constructor of class Environment
def test_Environment():
    # Test case with no arguments given (default behavior)
    test_case_0()
    # Test case with given arguments
    test_case_1()


# Generated at 2022-06-25 18:19:03.566533
# Unit test for constructor of class Environment
def test_Environment():
    # default
    environment_0 = Environment()
    assert environment_0.is_windows == True
    assert environment_0.config_dir == Path(os.path.expanduser('~'))
    assert environment_0.stdin == sys.stdin
    assert environment_0.stdout == sys.stdout
    assert environment_0.stderr == sys.stderr
    assert environment_0.stderr_isatty == True
    assert environment_0.colors == 256
    assert environment_0.program_name == 'http'
    assert environment_0.stdin.encoding == 'ANSI_X3.4-1968'
    assert environment_0.stdout.encoding == 'ANSI_X3.4-1968'

# Generated at 2022-06-25 18:19:05.823245
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert (isinstance(environment_0, Environment))


# Generated at 2022-06-25 18:19:07.894970
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().config_dir.exists()
    assert Environment().stdin is not None


# Generated at 2022-06-25 18:19:17.204523
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin  # `None` when closed fd (#791)
    assert env.stdin_isatty == env.stdin.isatty() if env.stdin else False
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == env.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == env.stderr.isatty()
    assert env.program_name == 'http'

# Generated at 2022-06-25 18:19:28.276265
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()
    assert isinstance(environment_1.is_windows, bool)
    assert isinstance(environment_1.config_dir, Path)
    assert environment_1.stdin is not None
    assert isinstance(environment_1.stdin_isatty, bool)
    assert environment_1.stdin_encoding is not None
    assert environment_1.stdout is not None
    assert isinstance(environment_1.stdout_isatty, bool)
    assert environment_1.stdout_encoding is not None
    assert environment_1.stderr is not None
    assert isinstance(environment_1.stderr_isatty, bool)
    assert isinstance(environment_1.colors, int)
    assert isinstance(environment_1.program_name, str)

# Generated at 2022-06-25 18:19:37.103993
# Unit test for constructor of class Environment
def test_Environment():
    """
    Unit test for constructor of class Environment
    """
    e = Environment()
    assert type(e) == Environment
    assert type(e.is_windows) == bool
    assert type(e.config_dir) == Path
    assert type(e.stdin) == sys.stdin
    assert type(e.stdin_isatty) == bool
    assert type(e.stdin_encoding) == str
    assert type(e.stdout) == sys.stdout
    assert type(e.stdout_isatty) == bool
    assert type(e.stdout_encoding) == str
    assert type(e.stderr) == sys.stderr
    assert type(e.stderr_isatty) == bool
    assert type(e.colors) == int

# Generated at 2022-06-25 18:19:41.012386
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(devnull='1',is_windows=True,config_dir='1',stdin='1',stdin_isatty=True,stdin_encoding='1',stdout='1',stdout_isatty=True,stdout_encoding='1',stderr='1',stderr_isatty=True,colors=256,program_name='1')


# Generated at 2022-06-25 18:19:47.200502
# Unit test for constructor of class Environment
def test_Environment():
    env=Environment()
    env.colors
    env.config
    env.config_dir
    env.is_windows
    env.program_name
    env.stderr
    env.stderr_isatty
    env.stdin
    env.stdin_encoding
    env.stdin_isatty
    env.stdout
    env.stdout_encoding
    env.stdout_isatty

# Generated at 2022-06-25 18:19:54.881288
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(devnull = 'hello.txt')
    if environment_1.devnull == 'hello.txt':
        print('If resource path exists, open the file, otherwise, raise IOError.')
    else:
        print('If resource path exists, open the file, otherwise, raise OSError.')

    print(environment_1.devnull)
    print(environment_1.stdin_encoding)
    print(environment_1.stdout_encoding)
    print(environment_1.stderr_encoding)
    print(environment_1.is_windows)


# Generated at 2022-06-25 18:20:20.009706
# Unit test for constructor of class Environment
def test_Environment():
    # Environment.is_windows = False
    assert Environment.is_windows == False
    # Environment.config_dir = DEFAULT_CONFIG_DIR
    assert Environment.config_dir == DEFAULT_CONFIG_DIR
    # Environment.stdin = sys.stdin
    assert Environment.stdin == sys.stdin
    # Environment.stdin_isatty = stdin.isatty() if stdin else False
    assert Environment.stdin_isatty == (sys.stdin.isatty() if sys.stdin else False)
    # Environment.stdin_encoding = None
    assert Environment.stdin_encoding == None
    # Environment.stdout = sys.stdout
    assert Environment.stdout == sys.stdout
    # Environment.stdout_isatty = stdout.isatty()

# Generated at 2022-06-25 18:20:21.523139
# Unit test for constructor of class Environment
def test_Environment():
    my_environment = Environment(devnull= "Testing")
    assert my_environment.devnull == "Testing"

# Generated at 2022-06-25 18:20:25.937651
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment()
    ret_str = e.__str__()
    ret_repr = e.__repr__()


# Generated at 2022-06-25 18:20:30.006333
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().stdin_isatty == sys.stdin.isatty()
    assert Environment().stdout_isatty == sys.stdout.isatty()
    assert Environment().stderr_isatty == sys.stderr.isatty()


# Generated at 2022-06-25 18:20:36.627698
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr, is_windows=False, config_dir='.config', stdin_isatty=True, stdout_isatty=True, stderr_isatty=True, stdin_encoding=None, stdout_encoding=None, stderr_encoding=None, colors=256, program_name='http', _orig_stderr=sys.stderr, _devnull=None, _config=None)
    assert environment_1.stdin == sys.stdin
    assert environment_1.stdout == sys.stdout
    assert environment_1.stderr == sys.stderr
    assert environment_1.is_windows == False

# Generated at 2022-06-25 18:20:45.968894
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()
    assert environment_1.is_windows == is_windows
    assert environment_1.config_dir == DEFAULT_CONFIG_DIR
    assert environment_1.stdin == sys.stdin
    assert environment_1.stdin_isatty == (environment_1.stdin is not None and environment_1.stdin.isatty())
    assert environment_1.stdin_encoding == None
    actual_stdout = environment_1.stdout
    if is_windows:
        import colorama.initialise
        if isinstance(environment_1.stdout, colorama.initialise.AnsiToWin32):
            actual_stdout = environment_1.stdout.wrapped
    assert environment_1.stdout_encoding == getattr(actual_stdout, 'encoding', None)

# Generated at 2022-06-25 18:20:55.382637
# Unit test for constructor of class Environment
def test_Environment():
    a = Environment()
    assert(a.is_windows == is_windows)
    assert(a.config_dir == DEFAULT_CONFIG_DIR)
    assert(a.stdin == sys.stdin)
    assert(a.stdin_isatty == sys.stdin.isatty())
    assert(a.stdout == sys.stdout)
    assert(a.stdout_isatty == sys.stdout.isatty())
    assert(a.stderr == sys.stderr)
    assert(a.stderr_isatty == sys.stderr.isatty())
    assert(a._devnull is None)
    assert(a.program_name == 'http')



# Generated at 2022-06-25 18:21:06.578068
# Unit test for constructor of class Environment
def test_Environment():
    if is_windows:
        import colorama
        colorama = colorama
        c = Environment()
        assert c.is_windows
        assert c.config_dir == os.path.expanduser("~/.httpie")
        assert c.stdin == sys.stdin
        assert c.stdin_isatty
        assert c.stdin_encoding == "utf8"
        assert c.stdout == sys.stdout
        assert c.stdout_isatty
        assert c.stdout_encoding == "utf8"
        assert c.stderr == sys.stderr
        assert c.stderr_isatty
        assert c.program_name == 'http'
        assert c.colors == 256
    else:
        c = Environment()
        assert not c.is_windows

# Generated at 2022-06-25 18:21:13.385388
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert isinstance(environment, Environment)
    assert environment.is_windows == False
    assert isinstance(environment.config_dir, Path)
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert isinstance(environment.stdin, IO)
    assert environment.stdin_isatty == True
    assert environment.stdin_encoding == 'cp1252'
    assert isinstance(environment.stdout, IO)
    assert environment.stdout_isatty == True
    assert environment.stdout_encoding == 'cp1252'
    assert isinstance(environment.stderr, IO)
    assert environment.stderr_isatty == True
    assert environment.colors == 256
    assert environment.program_name == 'http'

# Generated at 2022-06-25 18:21:14.510048
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()


# Generated at 2022-06-25 18:21:50.366105
# Unit test for constructor of class Environment
def test_Environment():
    env_1 = Environment(program_name='foo', colors="256")
    assert env_1.program_name == 'foo'
    assert env_1.colors == "256"
    env_2 = Environment(program_name='bar', colors="256")
    assert env_2.program_name == 'bar'
    assert env_2.colors == "256"



# Generated at 2022-06-25 18:21:57.700898
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    environment_1 = Environment(stdin = sys.stdin, stdout = sys.stdout, stderr = sys.stderr, config_dir = DEFAULT_CONFIG_DIR,
        is_windows = is_windows, colors = 256, program_name = 'http')
    environment_2 = Environment(stdin = sys.stdin, stdout = sys.stdout, stderr = sys.stderr, config_dir = DEFAULT_CONFIG_DIR,
        is_windows = is_windows, colors = 256, program_name = 'http')
    environment_3 = Environment(config_dir = DEFAULT_CONFIG_DIR)
    environment_4 = Environment(program_name = 'http')
    environment_5 = Environment(stderr = sys.stderr)

# Unit test

# Generated at 2022-06-25 18:21:59.805204
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().__class__.__name__ == 'Environment'



# Generated at 2022-06-25 18:22:03.261023
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()
    environment_2 = Environment(devnull=2)
    assert environment_1.stdout_isatty == environment_2.stdout_isatty

# Generated at 2022-06-25 18:22:11.616627
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == (sys.stdin.isatty() if sys.stdin else False)
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    if is_windows:
        assert env.colors == 256

# Generated at 2022-06-25 18:22:14.837814
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert isinstance(environment_0, Environment)

# Generated at 2022-06-25 18:22:23.901266
# Unit test for constructor of class Environment
def test_Environment():

    environment = Environment()

    assert type(environment) == Environment
    assert environment.is_windows == False
    assert environment.program_name == 'http'
    assert environment.config_dir == pathlib.Path('/Users/konradk/.config/httpie')
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == True
    assert environment.stdin_encoding == None
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == True
    assert environment.stdout_encoding == None
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == True
    assert environment.colors == 256

    assert environment.devnull == sys.stdout


# Generated at 2022-06-25 18:22:33.922761
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment(devnull=None, **{'is_windows': False, 'config_dir': DEFAULT_CONFIG_DIR, 'stdin': sys.stdin, 'stdin_isatty': sys.stdin.isatty(), 'stdin_encoding': None, 'stdout': sys.stdout, 'stdout_isatty': sys.stdout.isatty(), 'stdout_encoding': None, 'stderr': sys.stderr, 'stderr_isatty': sys.stderr.isatty(), 'colors': 256, 'program_name': 'http'})


# Generated at 2022-06-25 18:22:46.026506
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()
    assert environment_1.is_windows == True
    assert environment_1.stdin == sys.stdin
    assert environment_1.stdin_isatty == sys.stdin.isatty()
    assert environment_1.stdin_encoding == 'utf8'
    assert environment_1.stdout == sys.stdout
    assert environment_1.stdout_isatty == sys.stdout.isatty()
    assert environment_1.stdout_encoding == 'utf8'
    assert environment_1.stderr == sys.stderr
    assert environment_1.stderr_isatty == sys.stderr.isatty()
    assert environment_1.program_name == 'http'
    assert environment_1 != None


# Generated at 2022-06-25 18:22:51.221170
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()

# Generated at 2022-06-25 18:23:58.592835
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0._devnull == None #private attribute
    assert environment_0._config == None #private attribute
    assert environment_0._orig_stderr == sys.stderr
    assert environment_0.is_windows == is_windows
    assert environment_0.config_dir == DEFAULT_CONFIG_DIR
    assert environment_0.stdin == sys.stdin
    assert environment_0.stdin_isatty == stdin.isatty()
    assert environment_0.stdin_encoding == None
    assert environment_0.stdout == sys.stdout
    assert environment_0.stdout_isatty == stdout.isatty()
    assert environment_0.stdout_encoding == None
    assert environment_0.stderr == sys.stderr


# Generated at 2022-06-25 18:24:08.042886
# Unit test for constructor of class Environment
def test_Environment():
    import sys
    import os
    from pathlib import Path
    from typing import IO, Optional
    import httpie.config
    import httpie.utils
    import httpie.compat

    try:
        import curses
    except ImportError:
        curses = None  # Compiled w/o curses
    if (curses == None):
        colors = None
    else:
        colors = 256
    if (httpie.compat.is_windows == True):
        colors = None
    else:
        if (curses != None):
            try:
                curses.setupterm()
                colors = curses.tigetnum('colors')
            except curses.error:
                colors = None

# Generated at 2022-06-25 18:24:14.284159
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()
    assert environment_1.is_windows == is_windows
    assert environment_1.stdin == sys.stdin
    assert environment_1.stdin_isatty == sys.stdin.isatty()
    assert environment_1.stdin_encoding == None
    assert environment_1.stdout == sys.stdout
    assert environment_1.stdout_isatty == sys.stdout.isatty()
    assert environment_1.stdout_encoding == None
    assert environment_1.stderr == sys.stderr
    assert environment_1.stderr_isatty == sys.stderr.isatty()
    assert environment_1.program_name == 'http'


# Generated at 2022-06-25 18:24:21.969790
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(
        is_windows = True,
        config_dir = '/httpie',
        stdin = None,
        stdin_isatty = True,
        stdin_encoding = 'utf8',
        stdout = 'test_out',
        stdout_isatty = False,
        stdout_encoding = 'utf8',
        stderr = 'test_err',
        stderr_isatty = False,
        colors = 256,
        program_name = 'http',
        )
    assert environment_1.is_windows == True
    assert str(environment_1.config_dir) == '/httpie'
    assert environment_1.stdin == None
    assert environment_1.stdin_isatty == True

# Generated at 2022-06-25 18:24:23.372518
# Unit test for constructor of class Environment
def test_Environment():
    # test case 0
    test_case_0()


# Generated at 2022-06-25 18:24:32.378555
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows == True
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin != None
    assert environment.stdin_isatty == True
    assert environment.stdin_encoding == None
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == True
    assert environment.stdout_encoding == None
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == True
    assert environment.stderr_encoding == None
    assert environment.colors == 256
    assert environment.program_name == 'http'
    assert environment.config_dir == DEFAULT_CONFIG_DIR

# Generated at 2022-06-25 18:24:33.650136
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment > 0


# Generated at 2022-06-25 18:24:34.559137
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert isinstance(environment, Environment) == True


# Generated at 2022-06-25 18:24:44.154657
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().is_windows == is_windows
    assert Environment().config_dir == DEFAULT_CONFIG_DIR
    assert Environment().stdin == sys.stdin
    assert Environment().stdin_isatty == sys.stdin.isatty()
    assert Environment().stdin_encoding == sys.stdin.encoding
    assert Environment().stdout == sys.stdout
    assert Environment().stdout_isatty == sys.stdout.isatty()
    assert Environment().stdout_encoding == sys.stdout.encoding
    assert Environment().stderr == sys.stderr
    assert Environment().stderr_isatty == sys.stderr.isatty()
    assert Environment().colors == 256
    assert Environment().program_name == 'http'

# Generated at 2022-06-25 18:24:45.377400
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0 is not None
