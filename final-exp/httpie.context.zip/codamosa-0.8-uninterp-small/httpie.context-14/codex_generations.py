

# Generated at 2022-06-25 18:15:33.048310
# Unit test for constructor of class Environment
def test_Environment():

    # test for a good scenario
    Environment()



# Generated at 2022-06-25 18:15:39.588044
# Unit test for constructor of class Environment
def test_Environment():

  environment = Environment(
    is_windows=False,
    config_dir = '',
    stdin = None,
    stdin_isatty = True,
    stdin_encoding = '',
    stdout = None,
    stdout_isatty = True,
    stdout_encoding = '',
    stderr = None,
    stderr_isatty = True,
    colors = 0,
    program_name = '',
    _orig_stderr = None,
    _devnull = None
  )
  
  assert environment.is_windows == False
  assert environment.config_dir == ''
  assert environment.stdin == None
  assert environment.stdin_isatty == True
  assert environment.stdin_encoding == ''
  assert environment.stdout == None
 

# Generated at 2022-06-25 18:15:48.366129
# Unit test for constructor of class Environment
def test_Environment():
    environment_test = Environment()
    assert environment_test.is_windows == is_windows
    assert environment_test.config_dir == DEFAULT_CONFIG_DIR
    assert environment_test.stdin == sys.stdin
    assert environment_test.stdin_isatty == sys.stdin.isatty()
    assert environment_test.stdout == sys.stdout
    assert environment_test.stdout_isatty == sys.stdout.isatty()
    assert environment_test.stderr == sys.stderr
    assert environment_test.stderr_isatty == sys.stderr.isatty()
    assert environment_test.colors == 256
    assert environment_test.program_name == 'http'


# Generated at 2022-06-25 18:15:50.750377
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment(devnull='No file')
    assert environment_0.devnull == 'No file'



# Generated at 2022-06-25 18:15:52.803477
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment is not None


# Generated at 2022-06-25 18:15:56.738801
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()
    assert environment_1.stdin_encoding == 'utf8'
    assert environment_1.stdout_encoding == 'utf8'
    assert environment_1._config == None
    assert environment_1.devnull == None
test_Environment()


# Generated at 2022-06-25 18:16:00.488598
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows is False
    assert environment.config_dir is not None
    assert environment.stdin is not None
    assert environment.stdin_isatty is True
    assert environment.stdout is not None
    assert environment.stdout_isatty is True
    assert environment.stderr is not None
    assert environment.stderr_isatty is True


# Generated at 2022-06-25 18:16:05.168529
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    environment_1 = Environment(devnull = None)
    environment_2 = Environment(program_name = 'http')
    environment_3 = Environment(program_name = 'http', devnull = None)


# Generated at 2022-06-25 18:16:15.363562
# Unit test for constructor of class Environment

# Generated at 2022-06-25 18:16:17.147616
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert isinstance(environment, Environment)


# Generated at 2022-06-25 18:16:29.290039
# Unit test for constructor of class Environment
def test_Environment():
   assert (
       Environment().__str__() ==
       '<Environment<(stdout_encoding, str, \'utf8\'>)>'
   )
   assert (
       Environment(stdout_encoding='utf8').__str__() ==
       '<Environment<(stdout_encoding, str, \'utf8\')>>'
   )
   assert (
       Environment(colors=256).__str__() ==
       '<Environment<(colors, int, 256)>>'
   )

# Generated at 2022-06-25 18:16:40.735369
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdin_isatty=False, stdin_encoding="utf8",
                      stdout=sys.stdout, stdout_isatty=False, stdout_encoding='utf8',
                      stderr=sys.stderr, stderr_isatty=False,
                      is_windows=False, config_dir=DEFAULT_CONFIG_DIR,
                      colors=256, program_name='http')
    # config is a property of Environment, thus do not test it
    assert env.stdin is None
    assert env.stdin_isatty is False
    assert env.stdin_encoding == "utf8"
    assert env.stdout is sys.stdout
    assert env.stdout_isatty is False

# Generated at 2022-06-25 18:16:42.107449
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    print(environment)


# Generated at 2022-06-25 18:16:52.716838
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(stdin='', stdin_encoding='', stdin_isatty=False,
                                stdout='', stdout_encoding='', stdout_isatty=False,
                                program_name='', is_windows=False,
                                stderr='', stderr_encoding='', stderr_isatty=False,
                                config_dir='', colors=256, devnull='',
                                _devnull='', _config=Config(),
                                _orig_stderr='', __dict__={})

    assert environment_1.stdin == ''
    assert environment_1.stdin_encoding == ''
    assert environment_1.stdin_isatty == False
    assert environment_1.stdout == ''

# Generated at 2022-06-25 18:17:03.990107
# Unit test for constructor of class Environment
def test_Environment():
    environment_test = Environment()
    assert environment_test.is_windows == is_windows
    assert isinstance(environment_test.config_dir, Path)
    assert environment_test.stdin == sys.stdin
    assert environment_test.stdin_isatty == sys.stdin.isatty() if sys.stdin else False
    assert environment_test.stdin_encoding == None
    assert environment_test.stdout == sys.stdout
    assert environment_test.stdout_isatty == sys.stdout.isatty()
    assert environment_test.stdout_encoding == None
    assert environment_test.stderr == sys.stderr
    assert environment_test.stderr_isatty == sys.stderr.isatty()
    assert environment_test.colors == 256


# Generated at 2022-06-25 18:17:07.349917
# Unit test for constructor of class Environment
def test_Environment():
    # Check if the constructor raises an AssertionError when an argument has no corresponding attribute
    with pytest.raises(AssertionError):
        Environment(a_random_keyword_argument = 'random_keyword_argument')


# Generated at 2022-06-25 18:17:16.780659
# Unit test for constructor of class Environment
def test_Environment():

    env = Environment()

    # Check if the attributes have the correct values
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == bool(sys.stdin.isatty())
    assert env.stdin_encoding is None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == bool(sys.stdout.isatty())
    assert env.stdout_encoding is None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == bool(sys.stderr.isatty())
    assert env.colors == 256
    assert env.program_name == 'http'



# Generated at 2022-06-25 18:17:23.380302
# Unit test for constructor of class Environment

# Generated at 2022-06-25 18:17:29.051682
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()

    assert '<Environment' in repr(environment_1)
    assert 'stdin' in str(environment_1)
    assert 'stdout' in str(environment_1)
    assert 'stderr' in str(environment_1)



# Generated at 2022-06-25 18:17:40.386260
# Unit test for constructor of class Environment
def test_Environment():
    #"""

    from httpie import __version__ as httpie_version
    from httpie import cli
    from httpie.client import  __version__ as httpie_client_version
    from httpie.core import __version__ as httpie_core_version
    from httpie.json import __version__ as httpie_json_version
    import io
    import os
    import sys
    environment_0 = Environment()
    assert environment_0.is_windows == True
    assert  environment_0.config_dir == DEFAULT_CONFIG_DIR
    assert environment_0.stdin is  sys.stdin
    assert environment_0.stdin_isatty == True
    assert environment_0.stdout is sys.stdout
    assert environment_0.stdout_isatty == True
    assert environment_0.stder

# Generated at 2022-06-25 18:17:54.231763
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()
    environment_2 = Environment(stdin=False)
    environment_3 = Environment(stdout=False)
    environment_4 = Environment(stderr=False)
    environment_5 = Environment(config_dir=DEFAULT_CONFIG_DIR)
    environment_6 = Environment(stdin_isatty=False)
    environment_7 = Environment(stdout_isatty=False)
    environment_8 = Environment(stderr_isatty=False)
    environment_9 = Environment(stdin_encoding=None)
    environment_10 = Environment(stdout_encoding=None)
    environment_11 = Environment(colors=256)
    environment_12 = Environment(program_name='http')
    environment_13 = Environment(is_windows=False)

# Generated at 2022-06-25 18:18:01.190170
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        config_dir=DEFAULT_CONFIG_DIR,
        stdin=sys.stdin,
        stdin_encoding=None,
        stdout=sys.stdout,
        stdout_encoding=None,
        stderr=sys.stderr,
        colors=256,
        program_name='http',
    )
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_encoding is None
    assert env.stdout == sys.stdout
    assert env.stdout_encoding is None
    assert env.stderr == sys.stderr
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env.is_windows == is_windows

# Generated at 2022-06-25 18:18:12.413874
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()
    assert environment_1._orig_stderr == sys.stderr
    assert environment_1._devnull == None
    assert environment_1.is_windows == is_windows
    assert str(environment_1.config_dir) == 'httpie'
    assert environment_1.stdin == sys.stdin
    assert environment_1.stdin_isatty == sys.stdin.isatty()
    assert environment_1.stdin_encoding == None
    assert environment_1.stdout == sys.stdout
    assert environment_1.stdout_isatty == sys.stdout.isatty()
    assert environment_1.stdout_encoding == None
    assert environment_1.stderr == sys.stderr
    assert environment_1.stderr_isat

# Generated at 2022-06-25 18:18:19.019632
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(devnull=None, is_windows=False, config_dir=None, stdin=None, stdin_isatty=None, stdin_encoding=None, stdout=None, stdout_isatty=None, stdout_encoding=None, stderr=None, stderr_isatty=None, colors=None, program_name="http")

    print(environment_1)
    print(environment_1.config)

if __name__ == "__main__":
    test_case_0()
    test_Environment()

# Generated at 2022-06-25 18:18:27.171937
# Unit test for constructor of class Environment
def test_Environment():
    try:
        environment_0 = Environment(stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr, config_dir=Path(
            '/Users/wli/.config/httpie/'), is_windows=False, devnull=open(os.devnull, 'w+'))
    except AssertionError as e:
        # Result from test_case_0 is required
        print(e)


if __name__ == '__main__':
    test_case_0()
    test_Environment()

# Generated at 2022-06-25 18:18:30.873704
# Unit test for constructor of class Environment
def test_Environment():
    # Test 0
    test_case_0()

if __name__ == '__main__':
    # Unit tests for Environment
    test_Environment()

# Generated at 2022-06-25 18:18:41.910198
# Unit test for constructor of class Environment
def test_Environment():
    environment=Environment()
    test_val=environment.is_windows
    true_val=is_windows
    assert (test_val==true_val)
    test_val=environment.config_dir
    true_val=DEFAULT_CONFIG_DIR
    assert (test_val==true_val)
    test_val=environment.stdin
    true_val=sys.stdin
    assert (test_val==true_val)
    test_val=environment.stdin_isatty
    true_val=sys.stdin.isatty()
    assert (test_val==true_val)

    if False:
        print("Environment.__init__(self, devnull=None, **kwargs):")
        devnull=None
        kwargs={}
        environment=Environment(devnull, **kwargs)

# Generated at 2022-06-25 18:18:50.828001
# Unit test for constructor of class Environment
def test_Environment():
    # Create an environment object
    environment_0 = Environment()
    # Check if colorama is being used
    if environment_0.is_windows:
        assert "colorama" in sys.modules
    # Check if config dir is DEFAULT_CONFIG_DIR
    assert environment_0.config_dir == DEFAULT_CONFIG_DIR
    # Check if stdin, stdout, stderr are sys.stdin, sys.stdout, sys.stderr
    assert environment_0.stdin == sys.stdin
    assert environment_0.stdout == sys.stdout
    assert environment_0.stderr == sys.stderr
    # Check if stdin_isatty, stdout_isatty, stderr_isatty are True
    assert environment_0.stdin_isatty == True

# Generated at 2022-06-25 18:19:00.005504
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().__dict__ == {
        'is_windows': False,
        'config_dir': Path('~/.httpie'),
        'stdin': sys.stdin,
        'stdin_isatty': False,
        'stdin_encoding': 'UTF-8',
        'stdout': sys.stdout,
        'stdout_isatty': False,
        'stdout_encoding': 'UTF-8',
        'stderr': sys.stderr,
        'stderr_isatty': False,
        'colors': 256,
        'program_name': 'http',
        '_orig_stderr': sys.stderr,
        '_devnull': None,
        '_config': None,
    }



# Generated at 2022-06-25 18:19:01.055978
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment


# Generated at 2022-06-25 18:19:22.140760
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()
    Environment.is_windows = True
    Environment.config_dir = Path()
    Environment.stdin = sys.stdin
    Environment.stdin_isatty = False
    Environment.stdin_encoding = None
    Environment.stdout_isatty = False
    Environment.stdout_encoding = None
    Environment.stderr_isatty = False
    Environment.colors = 1
    Environment.program_name = 'http'
    test_case_0()


# Generated at 2022-06-25 18:19:23.050818
# Unit test for constructor of class Environment
def test_Environment():
    # TODO
    pass



# Generated at 2022-06-25 18:19:27.782532
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(
        stdin_encoding = None,
        stdout_encoding = None,
        stderr_encoding = None
    )
    assert environment.stdin_encoding is None
    assert environment.stdout_encoding is None
    assert environment.stderr_encoding is None



# Generated at 2022-06-25 18:19:36.953505
# Unit test for constructor of class Environment
def test_Environment():
    stdin = open('tests/test_data/test_data1')
    stdin.isatty = lambda : False
    environment = Environment(stdin=stdin, stdin_isatty=False, stdin_encoding='utf8', stdout=False, stdout_isatty= False, stdout_encoding='utf8', stderr=False, stderr_isatty=False)
    assert environment.stdin == stdin
    assert environment.stdin_isatty == False
    assert environment.stdin_encoding == 'utf8'
    assert environment.stdout == False
    assert environment.stdout_isatty == False
    assert environment.stdout_encoding == 'utf8'
    assert environment.stderr == False
    assert environment.stderr_isatty == False



# Generated at 2022-06-25 18:19:41.342610
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows
    assert environment.config_dir
    assert environment.stdin
    assert environment.stdin_isatty
    assert environment.stdin_encoding
    assert environment.stdout
    assert environment.stdout_isatty
    assert environment.stdout_encoding
    assert environment.stderr
    assert environment.stderr_isatty
    assert environment.colors
    assert environment.program_name


# Generated at 2022-06-25 18:19:52.277480
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(
        is_windows=0,
        config_dir="/home/shivam/.config/httpie",
        stdin=open("/dev/pts/7", "r+"),
        stdin_isatty=0,
        stdin_encoding=None,
        stdout=sys.stdout,
        stdout_isatty=1,
        stdout_encoding=None,
        stderr=sys.stderr,
        stderr_isatty=1,
        colors=256,
        program_name="http",
        devnull=open("/dev/null", "w+"),
        config=None,
        _orig_stderr=sys.stderr
    )
    assert environment_1.is_windows == 0

# Generated at 2022-06-25 18:19:54.881216
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(config_dir=Path('/'), program_name='http0')
    assert env.config_dir == Path('/')
    assert env.program_name == 'http0'



# Generated at 2022-06-25 18:19:57.135166
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(program_name='http')
    assert environment_1.program_name == 'http'


# Generated at 2022-06-25 18:20:00.142988
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    environment_1 = Environment()
    environment_2 = Environment()



# Generated at 2022-06-25 18:20:02.311825
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0 is not None


# Generated at 2022-06-25 18:20:13.995357
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.stdout is sys.stdout
    assert environment_0.stderr is sys.stderr
    assert environment_0.stdin is sys.stdin
    

# Generated at 2022-06-25 18:20:14.879232
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()

# Generated at 2022-06-25 18:20:22.963057
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment(stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr,
                                stdin_encoding=getattr(sys.stdin, 'encoding', None) or 'utf8',
                                stdout_encoding=getattr(sys.stdout, 'encoding', None) or 'utf8',
                                stderr_isatty=sys.stderr.isatty(), stdout_isatty=sys.stdout.isatty(),
                                stdin_isatty=sys.stdin.isatty())
    assert type(environment_0) == Environment


# Generated at 2022-06-25 18:20:33.747826
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.config_dir == Path(DEFAULT_CONFIG_DIR)
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == sys.stdin.isatty()
    assert environment.stdin_encoding == None
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == sys.stdout.isatty()
    assert environment.stdout_encoding == None
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == sys.stderr.isatty()

# Generated at 2022-06-25 18:20:45.157427
# Unit test for constructor of class Environment
def test_Environment():
    print("\nUnit test for constructor of class Environment\n")

    print("\nTest case #0")
    environment_0 = Environment()
    print("\n")

    print("\nTest case #1")
    environment_1 = Environment(devnull=os.devnull, is_windows=False, config_dir=Path("~/.httpie"), stdin=sys.stdin,
                                stdin_isatty=False, stdin_encoding="utf8", stdout=sys.stdout, stdout_isatty=True,
                                stdout_encoding="utf8", stderr=sys.stderr, stderr_isatty=True, colors=256,
                                program_name="hello")
    print("\n")

    print("\nTest case #2")
    environment_2

# Generated at 2022-06-25 18:20:55.189053
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.__dict__['stdin'] == sys.stdin
    assert environment_0.__dict__['stdout'] == sys.stdout
    assert environment_0.__dict__['stderr'] == sys.stderr
    assert environment_0.__dict__['stdin_encoding'] == None
    assert environment_0.__dict__['stdout_encoding'] == None
    environment_1 = Environment(stdin = sys.stdin, stdout = sys.stdout, stderr = sys.stderr,
                                stdin_encoding = sys.stdin.encoding, stdout_encoding = sys.stdout.encoding)
    assert environment_1.__dict__['stdin'] == sys.stdin

# Generated at 2022-06-25 18:21:02.875186
# Unit test for constructor of class Environment
def test_Environment():
    TestCase = Environment
    assert TestCase.config_dir is Path(DEFAULT_CONFIG_DIR)
    assert TestCase.stdin is sys.stdin
    assert TestCase.stdin_isatty is True
    assert TestCase.stdout is sys.stdout
    assert TestCase.stdout_isatty is True
    assert TestCase.stderr is sys.stderr
    assert TestCase.stderr_isatty is True
    assert TestCase.colors is 256
    assert TestCase.program_name is 'http'


# Generated at 2022-06-25 18:21:06.656275
# Unit test for constructor of class Environment
def test_Environment():
    with pytest.raises(AssertionError):
        Environment(key=123)
    with pytest.raises(AssertionError):
        Environment(not_key1 = None)



# Generated at 2022-06-25 18:21:09.011980
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(stdin=None, stdout=None, stderr=None)
    assert environment.stdin == None
    assert environment.stdout == None
    assert environment.stderr == None

# Generated at 2022-06-25 18:21:15.090254
# Unit test for constructor of class Environment
def test_Environment():
    stdin = sys.stdin
    stdin_encoding = getattr(stdin, 'encoding', None)
    stdin_isatty = stdin.isatty()
    stdout = sys.stdout
    stdout_encoding = getattr(stdout, 'encoding', None)
    stdout_isatty = stdout.isatty()
    stderr = sys.stderr
    stderr_isatty = stderr.isatty()
    config_dir = Path(DEFAULT_CONFIG_DIR)
    is_windows = is_windows

# Generated at 2022-06-25 18:21:41.173616
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows == is_windows
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == environment.stdin.isatty()
    assert environment.stdin_encoding == None
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == environment.stdout.isatty()
    assert environment.stdout_encoding == None
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == environment.stderr.isatty()
    assert environment.colors == 256
    assert environment.program_name == 'http'


# Generated at 2022-06-25 18:21:49.351436
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert(type(environment_0) == Environment)

# Generated at 2022-06-25 18:21:57.194065
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(is_windows=False,
                                config_dir="D:/httpie/Downloads",
                                stdin=sys.stdin,
                                stdin_isatty=True,
                                stdin_encoding=None,
                                stdout=sys.stdout,
                                stdout_isatty=True,
                                stdout_encoding=None,
                                stderr=sys.stderr,
                                stderr_isatty=True,
                                colors=256,
                                program_name="http",
                                config_1=False,
                                is_new=False)
    assert environment_1.is_windows == False
    assert environment_1.config_dir == Path("D:/httpie/Downloads")

# Generated at 2022-06-25 18:22:08.612680
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.is_windows == is_windows
    assert environment_0.config_dir == DEFAULT_CONFIG_DIR
    assert environment_0.stdin == sys.stdin
    assert environment_0.stdout == sys.stdout
    assert environment_0.stderr == sys.stderr
    assert environment_0.colors == 256
    assert environment_0.program_name == 'http'
    assert environment_0 == environment_0
    assert environment_0 is not None

# Generated at 2022-06-25 18:22:20.440067
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.is_windows is False
    assert str(environment_0.config_dir) == str(DEFAULT_CONFIG_DIR)
    assert repr(environment_0.stdin) == repr(sys.stdin)
    assert environment_0.stdin_isatty == False
    assert str(environment_0.stdin_encoding) == 'utf8'
    assert repr(environment_0.stdout) == repr(sys.stdout)
    assert environment_0.stdout_isatty == False
    assert str(environment_0.stdout_encoding) == 'utf8'
    assert repr(environment_0.stderr) == repr(sys.stderr)
    assert environment_0.stderr_isatty == False
    assert environment_0.col

# Generated at 2022-06-25 18:22:21.937032
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(program_name='httpie')
    assert environment.program_name == 'httpie'


# Generated at 2022-06-25 18:22:28.378450
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()
    assert environment_1.is_windows == os.name == "nt"
    assert isinstance(environment_1.config_dir, Path)
    assert environment_1.config_dir == Path(os.path.expanduser("~/.httpie"))
    assert environment_1.stdin.buffer.fileno() == sys.__stdin__.fileno()
    assert environment_1.stdin_isatty == os.isatty(environment_1.stdin.buffer.fileno())
    assert environment_1.stdout.buffer.fileno() == sys.__stdout__.fileno()
    assert environment_1.stdout_isatty == os.isatty(environment_1.stdout.buffer.fileno())
    assert environment_1.stderr.buffer.fileno()

# Generated at 2022-06-25 18:22:30.387812
# Unit test for constructor of class Environment
def test_Environment():
    assert isinstance(Environment(), Environment)


# Generated at 2022-06-25 18:22:31.383755
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment()


# Generated at 2022-06-25 18:22:38.647182
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(
        is_windows=False,
        config_dir=Path("/config/directory"),
        stdin=open("stdin.txt", "w+"),
        stdin_isatty=False,
        stdin_encoding='utf8',
        stdout=open("stdout.txt", "w+"),
        stdout_isatty=False,
        stdout_encoding='utf8',
        stderr=open("stderr.txt", "w+"),
        stderr_isatty=False,
        colors=7,
        program_name='program',
    )

    assert environment_1.is_windows == False
    assert environment_1.config_dir == Path("/config/directory")
    assert environment_1.stdin
    assert environment_1.stdin

# Generated at 2022-06-25 18:23:17.993682
# Unit test for constructor of class Environment
def test_Environment():
    # Test with empty constructor
    environment_0 = Environment()
    # Test with non-default values
    environment_1 = Environment(
        colors=32,
        config_dir="testdir",
        devnull=None,
        is_windows=False,
        stdin=None,
        stdin_encoding="utf8",
        stdin_isatty=False,
        stdout=sys.stdout,
        stdout_encoding="utf8",
        stdout_isatty=False,
        stderr=sys.stderr,
        stderr_isatty=False,
        stderr_isatty=False,
        program_name="http"
    )


# Generated at 2022-06-25 18:23:24.890681
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir
    assert env.stdin
    assert env.stdin_isatty
    assert env.stdout
    assert env.stdout_isatty
    assert env.stderr
    assert env.stderr_isatty
    assert env.colors == 256
    assert env.program_name
    assert env.config
    assert env._config
    assert env._orig_stderr
    assert env._devnull is None
    assert repr(env)
    # No exception
    assert env.log_error('asdf')
    # No error
    assert not env.devnull



# Generated at 2022-06-25 18:23:26.912200
# Unit test for constructor of class Environment
def test_Environment():
    assert test_case_0().devnull == test_case_0().devnull



# Generated at 2022-06-25 18:23:36.980801
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    environment = environment()
    environment = Environment(stdin=None, stdin_isatty=False, stdin_encoding=None, stdout=sys.stdout, stdout_isatty=True, stdout_encoding=None, stderr=sys.stderr, stderr_isatty=True, stderr_encoding=None, colors=256, program_name='http', config_dir="/path/to/config/dir")

# Generated at 2022-06-25 18:23:37.990890
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()


# Generated at 2022-06-25 18:23:44.949277
# Unit test for constructor of class Environment
def test_Environment():
    print("test_Environment")

    config_dir = Path(os.getcwd())
    test_case_0()
    test_case_1 = Environment(is_windows=True, config_dir=config_dir, stdin=sys.stdin, stdin_isatty=False,
                              stdin_encoding='utf8', stdout=sys.stdout, stdout_isatty=True, stdout_encoding='utf8',
                              stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http')

# Generated at 2022-06-25 18:23:55.624293
# Unit test for constructor of class Environment
def test_Environment():
    is_windows = True
    stdin = None
    stdin_encoding = "utf8"
    stdout = None
    stdout_encoding = "utf8"
    stderr = None
    stderr_isatty = False
    stderr_encoding = "utf8"
    colors = 256
    program_name = "http"
    env = Environment(is_windows, stdin, stdin_encoding, stdout, stdout_encoding,
                      stderr, stderr_isatty, stderr_encoding, colors, program_name)
    assert env.is_windows == True
    assert env.stdin == None
    assert env.stdin_encoding == "utf8"
    assert env.stdout == None

# Generated at 2022-06-25 18:23:57.847884
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()



# Generated at 2022-06-25 18:24:02.309786
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()
    environment_2 = Environment(stdin=1)
    environment_3 = Environment(stdout=1)
    environment_4 = Environment(stderr=1)
    environment_5 = Environment(stdin_encoding='a')
    environment_6 = Environment(stdout_encoding='a')
    environment_7 = Environment(program_name='aa')

# Generated at 2022-06-25 18:24:05.241593
# Unit test for constructor of class Environment
def test_Environment():
    if is_windows:
        env = Environment(is_windows=True)
        assert env.is_windows
    assert env.devnull
    assert env.program_name == 'http'

# Unit test of function load

# Generated at 2022-06-25 18:25:07.169786
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().is_windows == is_windows


# Generated at 2022-06-25 18:25:13.747010
# Unit test for constructor of class Environment
def test_Environment():
    is_windows = False
    config_dir = Path('~/.config/httpie')
    stdin = sys.stdin
    stdin_isatty = stdin.isatty() if stdin else False
    stdin_encoding = None
    stdout = sys.stdout
    stdout_isatty = stdout.isatty()
    stdout_encoding = None
    stderr = sys.stderr
    stderr_isatty = stderr.isatty()
    if not is_windows:
        if curses:
            try:
                curses.setupterm()
                colors = curses.tigetnum('colors')
            except curses.error:
                pass
    else:
        # noinspection PyUnresolvedReferences
        import colorama.initialise

# Generated at 2022-06-25 18:25:24.706641
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(
        devnull=None,
        is_windows=True,
        config_dir=DEFAULT_CONFIG_DIR,
        stdin=sys.stdin,
        stdin_isatty=sys.stdin.isatty(),
        stdin_encoding=None,
        stdout=sys.stdout,
        stdout_encoding=None,
        program_name='http',
        stderr_isatty=sys.stdout.isatty(),
        stderr=sys.stdout,
        colors=64,
    )
    assert environment.is_windows == True
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == sys.stdin.isatty()


# Generated at 2022-06-25 18:25:36.212806
# Unit test for constructor of class Environment
def test_Environment():
    try:
        os.remove('.test_env_config')
    except OSError:
        pass
    env = Environment(config_dir='.', program_name='test')
    assert env.program_name == 'test'
    assert env.config_dir == Path('.')
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == sys.stdout.encoding
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.stderr_encoding == sys.stderr.encoding
    assert env.colors == 256