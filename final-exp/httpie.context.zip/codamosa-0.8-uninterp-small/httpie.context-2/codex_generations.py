

# Generated at 2022-06-25 18:15:37.210919
# Unit test for constructor of class Environment
def test_Environment():
    # A call to Environment()
    environment_0 = Environment()

if __name__ == "__main__":
    import logging
    logging.basicConfig(filename="test.log", level=logging.DEBUG)

    test_Environment()
    test_case_0()

# Generated at 2022-06-25 18:15:47.464042
# Unit test for constructor of class Environment
def test_Environment():
    def __init__(self, devnull=None, **kwargs):
        assert all(hasattr(type(self), attr) for attr in kwargs.keys())
        self.__dict__.update(**kwargs)

        # The original STDERR unaffected by --quiet’ing.
        self._orig_stderr = self.stderr
        self._devnull = devnull

        # Keyword arguments > stream.encoding > default utf8
        if self.stdin and self.stdin_encoding is None:
            self.stdin_encoding = getattr(
                self.stdin, 'encoding', None) or 'utf8'
        if self.stdout_encoding is None:
            actual_stdout = self.stdout

# Generated at 2022-06-25 18:15:50.600430
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    var_0 = environment_0.__repr__()
    var_1 = environment_0.__str__()

test_Environment()

# Generated at 2022-06-25 18:15:57.095837
# Unit test for constructor of class Environment
def test_Environment():
    if os.path.exists(os.getcwd() + '/httpie'):
        environment = Environment(config_dir=os.getcwd() + '/httpie')
        environment.program_name = 'httpie'
        assert environment.program_name == 'httpie'
        assert environment.stdin_encoding == 'utf-8'
        assert environment.stdout_encoding == 'utf-8'
        assert environment.stdout_isatty == True


# Generated at 2022-06-25 18:15:58.962499
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    var_0 = environment_0.__repr__()

# Generated at 2022-06-25 18:16:11.055374
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()
    assert isinstance(environment_1, Environment)
    assert isinstance(environment_1.is_windows, bool)
    assert isinstance(environment_1.config_dir, Path)
    assert isinstance(environment_1.stdin, Optional[IO])
    assert isinstance(environment_1.stdin_isatty, bool)
    assert isinstance(environment_1.stdin_encoding, str)
    assert isinstance(environment_1.stdout, IO)
    assert isinstance(environment_1.stdout_isatty, bool)
    assert isinstance(environment_1.stdout_encoding, str)
    assert isinstance(environment_1.stderr, IO)
    assert isinstance(environment_1.stderr_isatty, bool)

# Generated at 2022-06-25 18:16:19.080281
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    # assert that the initialization of Environment data members is successful
    assert environment.is_windows == False
    assert environment.config_dir != None
    assert environment.stdin != None
    assert environment.stdin_isatty == True
    assert environment.stdin_encoding == None
    assert environment.stdout != None
    assert environment.stdout_isatty == True
    assert environment.stdout_encoding == None
    assert environment.stderr != None
    assert environment.stderr_isatty == True
    assert environment.colors == 256
    assert environment.program_name != None
    assert environment._orig_stderr != None
    assert environment._devnull == None
    assert environment._config == None


# Generated at 2022-06-25 18:16:19.958970
# Unit test for constructor of class Environment
def test_Environment():
	environment_0 = Environment()


# Generated at 2022-06-25 18:16:32.258499
# Unit test for constructor of class Environment
def test_Environment():
    # Environment(self: httpie.Environment, devnull=None, **kwargs: Any) -> None
    environment_0 = Environment()
    var_0 = environment_0.__repr__()

# Generated at 2022-06-25 18:16:33.717591
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0 is not None


# Generated at 2022-06-25 18:16:49.809455
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(devnull = 'dev/null', config_dir = 'None', stdin = sys.stdin, stdin_isatty = sys.stdin.isatty(), stdin_encoding = sys.stdin.encoding, stdout = sys.stdout, stdout_isatty = sys.stdout.isatty(), stdout_encoding = sys.stdout.encoding, stderr = sys.stderr, stderr_isatty = sys.stderr.isatty())
    assert environment.devnull == 'dev/null'
    assert environment.config_dir == 'None'
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == sys.stdin.isatty()
    assert environment.stdin_encoding == sys.stdin.enc

# Generated at 2022-06-25 18:16:51.911851
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    environment_1 = Environment(devnull=None, is_windows=True, config_dir=Path())


# Generated at 2022-06-25 18:16:58.482124
# Unit test for constructor of class Environment
def test_Environment():
    assert(sys.stdin.fileno() > 0)
    assert(sys.stdout.fileno() > 0)
    assert(sys.stderr.fileno() > 0)
    environment0 = Environment()
    assert(environment0.is_windows == is_windows)
    assert(environment0.config_dir == DEFAULT_CONFIG_DIR)
    assert(environment0.stdin == sys.stdin)
    assert(environment0.stdin_isatty == sys.stdin.isatty())
    assert(environment0.stdout == sys.stdout)
    assert(environment0.stdout_isatty == sys.stdout.isatty())
    assert(environment0.stderr == sys.stderr)

# Generated at 2022-06-25 18:17:05.949075
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment(devnull=None, is_windows=True, config_dir='DEFAULT_CONFIG_DIR', stdin=sys.stdin, stdin_isatty=True, stdin_encoding=None, stdout=sys.stdout, stdout_isatty=True, stdout_encoding=None, stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http')
    assert environment_0._orig_stderr == sys.stderr

# Generated at 2022-06-25 18:17:06.877656
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()

# Generated at 2022-06-25 18:17:16.423069
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows == is_windows
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == sys.stdin.isatty()
    assert environment.stdin_encoding is None
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == sys.stdout.isatty()
    assert environment.stdout_encoding is None
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == sys.stderr.isatty()
    assert environment.colors == 256
    assert environment.program_name == 'http'

# Generated at 2022-06-25 18:17:17.259277
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()

# Generated at 2022-06-25 18:17:23.639398
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()
    assert environment_1.is_windows == environment_0.is_windows
    assert environment_1.config_dir == environment_0.config_dir
    assert environment_1.stdin == environment_0.stdin
    assert environment_1.stdin_isatty == environment_0.stdin_isatty
    assert environment_1.stdin_encoding == environment_0.stdin_encoding
    assert environment_1.stdout == environment_0.stdout
    assert environment_1.stdout_isatty == environment_0.stdout_isatty
    assert environment_1.stdout_encoding == environment_0.stdout_encoding
    assert environment_1.stderr == environment_0.stderr
    assert environment_1.stderr_isatty

# Generated at 2022-06-25 18:17:33.302481
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()

    assert environment_0.is_windows == False
    assert environment_0.stdin == sys.stdin
    assert environment_0.stdin_isatty == True
    assert environment_0.stdin_encoding == 'utf8'
    assert environment_0.stdout == sys.stdout
    assert environment_0.stdout_isatty == True
    assert environment_0.stdout_encoding == 'utf8'
    assert environment_0.stderr == sys.stderr
    assert environment_0.stderr_isatty == True
    assert environment_0.colors == 256
    assert environment_0.program_name == 'http'
    assert environment_0.config_dir == DEFAULT_CONFIG_DIR
    assert environment_0.stdout == sys.std

# Generated at 2022-06-25 18:17:44.893385
# Unit test for constructor of class Environment

# Generated at 2022-06-25 18:18:02.785910
# Unit test for constructor of class Environment
def test_Environment():
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from typing import IO
    import sys

    enc = getattr(sys.stdin, 'encoding', None) or 'utf8'
    
    st = sys.stdout

    directory = TemporaryDirectory()
    dir_name = Path(directory.name)

    # Case 1: Default Constructor
    environment_0 = Environment()
    assert environment_0.is_windows == is_windows
    assert environment_0.config_dir == DEFAULT_CONFIG_DIR
    assert environment_0.stdin == sys.stdin
    assert environment_0.stdin_isatty == sys.stdin.isatty()
    assert environment_0.stdin_encoding == enc
    assert environment_0.stdout == sys.stdout
    assert environment_0.stdout

# Generated at 2022-06-25 18:18:13.461102
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(
        stdin=open(os.devnull, 'r'),
        stdout=open(os.devnull, 'w'),
        stderr=open(os.devnull, 'w'),
    )
    assert type(environment_1) == Environment
    # w/o colorama
    environment_2 = Environment(
        stdin=open(os.devnull, 'r'),
        stdout=open(os.devnull, 'w'),
        stderr=open(os.devnull, 'w'),
        is_windows=False,
    )
    assert type(environment_2) == Environment
    # with colorama

# Generated at 2022-06-25 18:18:19.170945
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()
    assert environment_1.config_dir == os.path.expanduser(os.path.join('~',  '.config', 'httpie'))
    assert environment_1.colors == 256
    assert environment_1.stdin == sys.stdin
    assert environment_1.stdout == sys.stdout
    assert environment_1.stderr == sys.stderr
    assert environment_1.is_windows == is_windows


# Generated at 2022-06-25 18:18:28.648818
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.is_windows == is_windows
    assert environment_0.config_dir == DEFAULT_CONFIG_DIR
    assert environment_0.stdout == sys.stdout
    assert environment_0.stderr == sys.stderr
    assert environment_0.program_name == 'http'
    assert environment_0.stdout_encoding == 'utf8'
    assert environment_0.stdin_encoding == 'utf8'
    if is_windows:
        assert environment_0.colors == 16
    else:
        assert environment_0.colors == 256

test_case_0()

# Generated at 2022-06-25 18:18:33.855016
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    environment_1 = Environment(config_dir="/config_dir/")
    environment_2 = Environment(stdin="/stdin/", stdout="/stdout/", stderr="/stderr/")
    environment_3 = Environment(is_windows=False)
    environment_4 = Environment(stdin_encoding="/stdin_encoding/")
    environment_5 = Environment(stdout_encoding="/stdout_encoding/")
    environment_6 = Environment(stderr_encoding="/stderr_encoding/")
    environment_7 = Environment(program_name="http")
    environment_8 = Environment(colors=256)

# Generated at 2022-06-25 18:18:38.397092
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().config.directory == DEFAULT_CONFIG_DIR

    env = Environment(config_dir='foo', program_name='bar')
    assert env.config_dir == 'foo'
    assert env.program_name == 'bar'



# Generated at 2022-06-25 18:18:41.859910
# Unit test for constructor of class Environment
def test_Environment():

    environment_0 = Environment()
    environment_1 = Environment(is_windows=True)
    environment_2 = Environment(is_windows=True, colors=300)
    environment_3 = Environment(is_windows=False, colors=100)


# Generated at 2022-06-25 18:18:50.781016
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin  # `None` when closed fd (#791)
    assert env.stdin_isatty == (sys.stdin.isatty() if sys.stdin else False)
    assert env.stdin_encoding is None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding is None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name

# Generated at 2022-06-25 18:18:58.504583
# Unit test for constructor of class Environment
def test_Environment():
    # Test 1
    try:
        Environment(devnull = 'test_case_1', stdin = None)
    except Exception as e:
        assert type(e) == AssertionError

    # Test 2
    environment_1 = Environment(devnull = 'test_case_2', stdin='test_case_2')
    assert environment_1.devnull == 'test_case_2'
    assert environment_1.stdin == 'test_case_2'

    # Test 3
    environment_2 = Environment(devnull = 'test_case_3', stdin=None)
    assert environment_2.devnull == None


# Generated at 2022-06-25 18:19:08.499135
# Unit test for constructor of class Environment
def test_Environment():
    # Unit test for func __init__ in class Environment
    environment_0 = Environment(
        colors=256,
        config_dir=Path('/Users/nilesh/.config/httpie'),
        devnull=None,
        is_windows=False,
        program_name='http',
        stderr=sys.stderr,
        stderr_encoding='UTF-8',
        stderr_isatty=True,
        stdin=None,
        stdin_encoding=None,
        stdin_isatty=False,
        stdout=sys.stdout,
        stdout_encoding='UTF-8',
        stdout_isatty=True
    )


# Generated at 2022-06-25 18:19:33.452605
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()
    environment_0 = Environment()
    for attr in environment_0.__dict__:
        if not attr.startswith('_'):
            assert attr in ['config_dir', 'stdin', 'stdin_isatty', 'stdin_encoding', 'stdout', 'stdout_isatty', 'stdout_encoding', 'stderr', 'stderr_isatty', 'colors', 'program_name', 'is_windows', '_devnull', '_orig_stderr']

# A class for testing that python documentation can be generated.

# Generated at 2022-06-25 18:19:36.912583
# Unit test for constructor of class Environment
def test_Environment():
    try:
        test_case_0()
    except AssertionError:
        print('[FAILED] ---> Test Case 0')
        sys.exit(1)
    else:
        print('[OK] ---> Test Case 0')

# Generated at 2022-06-25 18:19:37.595290
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment.is_windows == is_windows


# Generated at 2022-06-25 18:19:48.117826
# Unit test for constructor of class Environment
def test_Environment():
    print("Unit testing for constructor of class Environment")

environment_1 = Environment(**{
  "is_windows": False,
  "config_dir": DEFAULT_CONFIG_DIR,
  "stdin": sys.stdin,
  "stdin_isatty": True,
  "stdin_encoding": "utf8",
  "stdout": sys.stdout,
  "stdout_isatty": True,
  "stdout_encoding": "utf8",
  "stderr": sys.stderr,
  "stderr_isatty": True,
  "colors": 256,
  "program_name": "http",
  "_orig_stderr": sys.stderr,
  "_devnull": None,
  "_config": None
})

# Generated at 2022-06-25 18:19:57.984575
# Unit test for constructor of class Environment
def test_Environment():
    # Test case 1
    environment = Environment(
        is_windows=False,
        config_dir=Path('~/.httpie'),
        stdin=sys.stdin,
        stdin_isatty=True,
        stdin_encoding='utf8',
        stdout=sys.stdout,
        stdout_isatty=True,
        stdout_encoding='utf8',
        stderr=sys.stderr,
        stderr_isatty=True,
        stderr_encoding='utf8',
        colors=256,
        program_name='http'
    )
    assert environment.is_windows == False
    assert environment.config_dir == Path('~/.httpie')
    assert environment.stdin == sys.stdin

# Generated at 2022-06-25 18:20:09.783144
# Unit test for constructor of class Environment
def test_Environment():
    '''
    assert repr_dict(env) == repr_dict(default)
    '''
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin  # `None` when closed fd (#791)
    assert env.stdin_isatty == env.stdin.isatty() if env.stdin else False
    assert env.stdin_encoding is None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == env.stdout.isatty()
    assert env.stdout_encoding is None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == env.stderr

# Generated at 2022-06-25 18:20:15.131232
# Unit test for constructor of class Environment
def test_Environment():
    print("\n")
    environment_0 = Environment()
    assert isinstance(environment_0, Environment)
    environment_1 = Environment(devnull=None)
    assert isinstance(environment_1, Environment)
    environment_2 = Environment(devnull=None, is_windows=True)
    assert isinstance(environment_2, Environment)


# Generated at 2022-06-25 18:20:20.381850
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(
        devnull='abc',
        stdin='xyz',
        program_name='cba'
    )

    assert environment_1.devnull == 'abc'
    assert isinstance(environment_1.config_dir, Path)
    assert environment_1.stdin == 'xyz'
    assert environment_1.program_name == 'cba'

# Generated at 2022-06-25 18:20:26.478365
# Unit test for constructor of class Environment
def test_Environment():
    fake_stdin = "fakestdin"
    fake_stdout = "fakestdout"
    fake_stderr = "fakestderr"
    # default value
    environment_default = Environment()
    assert environment_default.is_windows == is_windows
    assert environment_default.config_dir == DEFAULT_CONFIG_DIR
    assert environment_default.stdin == sys.stdin
    assert environment_default.stdin_isatty == sys.stdin.isatty()
    assert environment_default.stdin_encoding == None
    assert environment_default.stdout == sys.stdout
    assert environment_default.stdout_isatty == sys.stdout.isatty()
    assert environment_default.stdout_encoding == None

# Generated at 2022-06-25 18:20:34.828935
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()

    assert hasattr(env, 'is_windows')
    assert hasattr(env, 'config_dir')
    assert hasattr(env, 'config')
    assert hasattr(env, 'stdin')
    assert hasattr(env, 'stdin_isatty')
    assert hasattr(env, 'stdin_encoding')
    assert hasattr(env, 'stdout')
    assert hasattr(env, 'stdout_isatty')
    assert hasattr(env, 'stdout_encoding')
    assert hasattr(env, 'stderr')
    assert hasattr(env, 'stderr_isatty')
    assert hasattr(env, 'colors')
    assert hasattr(env, 'program_name')


# Generated at 2022-06-25 18:21:22.346399
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()
    assert environment_1.is_windows == is_windows
    assert environment_1.config_dir == DEFAULT_CONFIG_DIR
    assert environment_1.stdin == sys.stdin
    assert environment_1.stdin_isatty == sys.stdin.isatty()
    assert environment_1.stdin_encoding == None
    assert environment_1.stdout == sys.stdout
    assert environment_1.stdout_isatty == sys.stdout.isatty()
    assert environment_1.stdout_encoding == None
    assert environment_1.stderr == sys.stderr
    assert environment_1.stderr_isatty == sys.stderr.isatty()
    assert environment_1.colors == 256
    assert environment_1

# Generated at 2022-06-25 18:21:24.184681
# Unit test for constructor of class Environment
def test_Environment():
    assert test_case_0() is None, "failed"



# Generated at 2022-06-25 18:21:29.541783
# Unit test for constructor of class Environment
def test_Environment():
    from unittest.mock import Mock, patch
    environment = Environment(is_windows = True)
    assert environment.is_windows
    assert environment.stdin is None
    assert environment.stdin_isatty == False
    assert environment.stdout is None
    assert environment.stdout_isatty == False
    assert environment.stderr is None
    assert environment.stderr_isatty == False


# Generated at 2022-06-25 18:21:41.271470
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    env.__init__(devnull=None, is_windows=True, config_dir=Path('/home'), stdin=None, stdin_encoding='utf8',
                 stdout=sys.stdout, stdout_encoding='utf8', stderr=sys.stderr, stderr_isatty=True, colors=256,
                 program_name='http')
    assert env.is_windows == True
    assert env.config_dir == Path('/home')
    assert env.stdin == None
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout_encoding == 'utf8'
    assert env.stderr == sys.stderr
    assert env.stderr_isatty

# Generated at 2022-06-25 18:21:49.399332
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.config_dir == DEFAULT_CONFIG_DIR
    assert environment_0.stdin == sys.stdin
    assert environment_0.stdout == sys.stdout
    assert environment_0.stderr == sys.stderr
    assert environment_0.program_name == 'http'
    assert environment_0.devnull == None
    envir = Environment(config_dir = False, stdin = True, stdout = True, stderr = False, program_name = None, devnull = False)
    assert envir.config_dir == False
    assert envir.stdin == True
    assert envir.stdout == True
    assert envir.stderr == False
    assert envir.program_name == None
    assert envir.devnull == False



# Generated at 2022-06-25 18:21:56.608522
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(config_dir='/var/lib/httpie')
    assert environment_1.config_dir == '/var/lib/httpie'
    assert environment_1.stdin == sys.stdin
    assert environment_1.stdout == sys.stdout
    assert environment_1.stderr == sys.stderr
    assert environment_1.stdin_encoding is None
    assert environment_1.stdout_encoding is None
    assert environment_1.stderr_encoding is None
    assert environment_1.is_windows is False
    assert environment_1.colors == 256
    assert environment_1.program_name == 'http'


# Generated at 2022-06-25 18:22:01.563600
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(devnull='qaz')
    environment_2 = Environment(is_windows=True)
    environment_3 = Environment(stdin=sys.stdout, stdout=sys.stdin)
    environment_4 = Environment(stderr=sys.stdout)


# Generated at 2022-06-25 18:22:10.882048
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows == is_windows
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == sys.stdin.isatty()
    assert environment.stdin_encoding is None
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == sys.stdout.isatty()
    assert environment.stdout_encoding is None
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == sys.stderr.isatty()
    assert environment.colors == 256
    assert environment.program_name == 'http'
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.colors == 256
    environment.stdin = None


# Generated at 2022-06-25 18:22:22.443482
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(program_name = 'httpie', config_dir = DEFAULT_CONFIG_DIR, stdin = sys.stdin, stderr = sys.stderr, stdout = sys.stdout, stdin_encoding = None, stdout_encoding = None, stdin_isatty = sys.stdin.isatty() if sys.stdin else False, stdout_isatty = sys.stdout.isatty(), stderr_isatty = sys.stderr.isatty())
    assert environment_1.program_name == 'httpie'
    assert environment_1.config_dir == DEFAULT_CONFIG_DIR
    assert environment_1.stdin == sys.stdin
    assert environment_1.stderr == sys.stderr
    assert environment_1.stdout

# Generated at 2022-06-25 18:22:28.672108
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == env.stdin.isatty()
    assert env.stdin_encoding == sys.stdin.encoding
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == env.stdout.isatty()
    assert env.stdout_encoding == sys.stdout.encoding
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == env.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env._devnull is None
    assert env._orig_stder

# Generated at 2022-06-25 18:23:55.101375
# Unit test for constructor of class Environment
def test_Environment():
    environment_obj = Environment()
    assert environment_obj.is_windows == environment_obj.is_windows
    assert environment_obj.config_dir == environment_obj.config_dir
    assert environment_obj.stdin == environment_obj.stdin
    assert environment_obj.stdin_isatty == environment_obj.stdin_isatty
    assert environment_obj.stdin_encoding == environment_obj.stdin_encoding
    assert environment_obj.stdout == environment_obj.stdout
    assert environment_obj.stdout_isatty == environment_obj.stdout_isatty
    assert environment_obj.stdout_encoding == environment_obj.stdout_encoding
    assert environment_obj.stderr == environment_obj.stderr
    assert environment_obj.stderr_isatty

# Generated at 2022-06-25 18:24:05.434632
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()

# Generated at 2022-06-25 18:24:11.893145
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert type(environment.stdin) == file
    assert environment.is_windows == False
    assert type(environment.stdin_isatty) == bool
    assert type(environment.stdout) == file
    assert type(environment.stdin_encoding) == str
    assert type(environment.stdout_isatty) == bool
    assert type(environment.stdout_encoding) == str
    assert type(environment.stderr) == file
    assert type(environment.stderr_isatty) == bool
    assert type(environment.colors) == int
    assert type(environment.program_name) == str

# Generated at 2022-06-25 18:24:16.590115
# Unit test for constructor of class Environment
def test_Environment():
    environment1 = Environment()
    assert environment1.is_windows is False
    assert environment1.program_name is 'http'
    

# Generated at 2022-06-25 18:24:17.987434
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name='httpie')
    assert(env.program_name == 'httpie')

# Generated at 2022-06-25 18:24:22.006640
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(stdout='test_stdout', stderr='test_stderr')
    assert environment.stdout == 'test_stdout'
    assert environment.stderr == 'test_stderr'

# Generated at 2022-06-25 18:24:30.266455
# Unit test for constructor of class Environment
def test_Environment():
    if is_windows:
        assert Environment().is_windows is True
    else:
        assert Environment().is_windows is False

    if sys.stdin.isatty():
        assert Environment().stdin_isatty is True
    else:
        assert Environment().stdin_isatty is False

    if sys.stdout.isatty():
        assert Environment().stdout_isatty is True
    else:
        assert Environment().stdout_isatty is False

    if sys.stderr.isatty():
        assert Environment().stderr_isatty is True
    else:
        assert Environment().stderr_isatty is False



# Generated at 2022-06-25 18:24:39.010468
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(
        is_windows=not is_windows,
        config_dir=Path('/Users/.httpie/'),
        stdin=None,
        stdin_isatty=not environment_0.stdin_isatty,
        stdin_encoding='utf-16',
        stdout=None,
        stdout_isatty=not environment_0.stdout_isatty,
        stdout_encoding='utf-16-be',
        stderr=None,
        stderr_isatty=not environment_0.stderr_isatty,
        colors=100,
        program_name='httpie',
        _orig_stderr=None,
        _devnull=None,
        _config=None
    )

    # Test if all the class variables of

# Generated at 2022-06-25 18:24:46.832814
# Unit test for constructor of class Environment
def test_Environment():
    env=Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == True if sys.stdin else False
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'

    #assert env.is_windows == is_windows
    #assert env.

# Generated at 2022-06-25 18:24:56.342115
# Unit test for constructor of class Environment
def test_Environment():
    sys.stdin = None
    environment_0 = Environment()
    assert environment_0.is_windows == is_windows
    assert environment_0.config_dir == DEFAULT_CONFIG_DIR
    assert environment_0.devnull is None
    assert environment_0.stdin == sys.stdin
    assert environment_0.stdin_isatty == sys.stdin.isatty()
    assert environment_0.stdin_encoding is None
    assert environment_0.stdout == sys.stdout
    assert environment_0.stdout_isatty == sys.stdout.isatty()
    assert environment_0.stdout_encoding is None
    assert environment_0.stderr == sys.stderr
    assert environment_0.stderr_isatty == sys.stderr.isat