

# Generated at 2022-06-25 18:15:29.227168
# Unit test for constructor of class Environment
def test_Environment():
    Environment()
    test_case_0()

# Generated at 2022-06-25 18:15:30.068007
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()
    test_case_1()

# Generated at 2022-06-25 18:15:37.457690
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().is_windows == True
    assert Environment().config_dir == Path("~\\.config\\httpie\\config.json")
    assert Environment().stdin == sys.stdin
    assert Environment().stdin_isatty == True
    assert Environment().stdin_encoding == 'utf-8'
    assert Environment().stdout == sys.stdout
    assert Environment().stdout_isatty == True
    assert Environment().stdout_encoding == 'utf-8'
    assert Environment().stderr == sys.stderr
    assert Environment().stderr_isatty == True
    assert Environment().colors == 256
    assert Environment().program_name == 'http'

# Generated at 2022-06-25 18:15:47.630587
# Unit test for constructor of class Environment
def test_Environment():
    Environment(stdout = sys.stdout, stdin = sys.stdin)
    Environment(stdout = sys.stdout, stdin = sys.stdin, config_dir = DEFAULT_CONFIG_DIR, stderr = sys.stderr, stdout_isatty = True, stdin_isatty = True, stdout_encoding = None, stdin_encoding = None)
    Environment(stdout = sys.stdout, stdin = sys.stdin, config_dir = DEFAULT_CONFIG_DIR, stderr = sys.stderr, stdout_isatty = False, stdin_isatty = True, stdout_encoding = None, stdin_encoding = None)

# Generated at 2022-06-25 18:15:55.336041
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=False, config_dir=DEFAULT_CONFIG_DIR,
                      stdin=sys.stdin, stdin_isatty=True, stdin_encoding=None,
                      stdout=sys.stdout, stdout_isatty=True, stdout_encoding=None,
                      stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http')
    assert env is not None

# Generated at 2022-06-25 18:15:58.918072
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()
    environment_1.config
    utf8 = 'utf8'
    environment_1.stdin_encoding = utf8
    environment_1.stdout_encoding = utf8
    environment_1.stderr_encoding = utf8
    environment_1.stdin = None

# Generated at 2022-06-25 18:15:59.995988
# Unit test for constructor of class Environment
def test_Environment():
    assert repr(Environment())



# Generated at 2022-06-25 18:16:12.012437
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()
    assert environment_1.is_windows is True
    assert environment_1.config_dir is DEFAULT_CONFIG_DIR
    assert environment_1.stdin is sys.stdin
    assert environment_1.stdin_isatty is sys.stdin.isatty()
    assert environment_1.stdin_encoding is None
    assert environment_1.stdout is sys.stdout
    assert environment_1.stdout_isatty is sys.stdout.isatty()
    assert environment_1.stdout_encoding is None
    assert environment_1.stderr is sys.stderr
    assert environment_1.stderr_isatty is sys.stderr.isatty()
    assert environment_1.colors is 256
    assert environment_1.program

# Generated at 2022-06-25 18:16:18.934600
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(stdin="/usr/share/dict", stdout="/usr/lib/libstdc++.so.6.0.22", stderr="/usr/lib/libboost_python-py37.so.1.65.1", devnull="/usr/lib/libgcc_s.so.1", is_windows=True, config_dir="/usr/lib", stdin_isatty=True, stdin_encoding="utf8", stdout_isatty=True, stdout_encoding="utf8", stderr_isatty=True, stderr_encoding="utf8", colors=256, program_name="http")


# Generated at 2022-06-25 18:16:21.190817
# Unit test for constructor of class Environment
def test_Environment():
    # env = Environment(stdin=sys.stdin)
    # assert env.stdin == sys.stdin
    # f = open("input.txt", "r")
    # env = Environment(stdin=f)
    # assert env.stdin == f.stdin
    pass

# Generated at 2022-06-25 18:16:34.253844
# Unit test for constructor of class Environment
def test_Environment():
    devnull = 'a'
    env = Environment(devnull=devnull, is_windows=True)
    assert env.devnull == devnull
    assert env.is_windows is True
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin is sys.stdin
    assert env.stdout is sys.stdout
    assert env.stderr is sys.stderr
    assert env.program_name == 'http'
    assert env.colors == 256
    assert env._devnull == 'a'
    assert env._orig_stderr == sys.stderr
    assert env._config == None


# Generated at 2022-06-25 18:16:36.198461
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()

    assert environment is not None


# Unit tests for the readonly variables of class Environment

# Generated at 2022-06-25 18:16:46.157491
# Unit test for constructor of class Environment
def test_Environment():
    env1 = Environment()
    assert is_windows is env1.is_windows
    assert DEFAULT_CONFIG_DIR is env1.config_dir
    assert sys.stdin is env1.stdin
    assert sys.stdout is env1.stdout
    assert sys.stderr is env1.stderr

    assert env1.stdin_isatty
    assert env1.stdout_isatty
    assert env1.stderr_isatty
    assert not env1._devnull

    assert 256 is env1.colors
    assert 'http' is env1.program_name

    #assert devnull is env1.devnull



# Generated at 2022-06-25 18:16:55.263761
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(devnull=None, is_windows=True, config_dir=os.path.expanduser('~'), stdin=sys.stdin,
                              stdout=sys.stdout, stderr=sys.stderr,
                              stdin_encoding='utf8', stdout_encoding='utf8', stderr_encoding='utf8',
                              program_name='http')
    assert hasattr(environment, 'is_windows')
    assert hasattr(environment, 'config_dir')
    assert hasattr(environment, 'stdin')
    assert hasattr(environment, 'stdout')
    assert hasattr(environment, 'stderr')
    assert hasattr(environment, 'stdin_encoding')
    assert hasattr(environment, 'stdout_encoding')

# Generated at 2022-06-25 18:17:03.752313
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    environment_1 = Environment(
        is_windows=1,
        config_dir=1,
        stdin=1,
        stdin_isatty=1,
        stdin_encoding=1,
        stdout=1,
        stdout_isatty=1,
        stdout_encoding=1,
        stderr=1,
        stderr_isatty=1,
        colors=1,
        program_name=1,
        devnull=1)


# Generated at 2022-06-25 18:17:04.803446
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment()


# Generated at 2022-06-25 18:17:05.948502
# Unit test for constructor of class Environment
def test_Environment():
    pass



# Generated at 2022-06-25 18:17:15.560314
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows == is_windows
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin_isatty == sys.stdin.isatty() if sys.stdin else False
    assert environment.stdin_encoding == None
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == sys.stdout.isatty()
    assert environment.stdout_encoding == None
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == sys.stderr.isatty()
    if is_windows:
        assert environment.colors == 256
        from colorama.initialise import wrap_stream

# Generated at 2022-06-25 18:17:24.917614
# Unit test for constructor of class Environment
def test_Environment():
    # test_case_0
    environment_0 = Environment()
    assert environment_0.is_windows == is_windows
    assert environment_0.config_dir == DEFAULT_CONFIG_DIR
    assert environment_0.stdin == sys.stdin
    assert environment_0.stdin_isatty == environment_0.stdin.isatty() if environment_0.stdin else False
    assert environment_0.stdin_encoding == None
    assert environment_0.stdout == sys.stdout
    assert environment_0.stdout_isatty == environment_0.stdout.isatty()
    assert environment_0.stdout_encoding == None
    assert environment_0.stderr == sys.stderr
    assert environment_0.stderr_isatty == environment_0.stder

# Generated at 2022-06-25 18:17:33.841249
# Unit test for constructor of class Environment
def test_Environment():

    assert type(Environment) == type

    import sys
    import os
    from pathlib import Path
    from typing import IO, Optional

    try:
        import curses
    except ImportError:
        curses = None  # Compiled w/o curses
        is_windows = False
        DEFAULT_CONFIG_DIR="~/.config/httpie"
        stdin = sys.stdin
        stdin_isatty = stdin.isatty()
        stdin_encoding = None
        stdout = sys.stdout
        stdout_isatty = stdout.isatty()
        stdout_encoding = None
        stderr = sys.stderr
        stderr_isatty = stderr.isatty()
        colors = 256
        program_name = 'http'


# Generated at 2022-06-25 18:17:43.643122
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()


# Generated at 2022-06-25 18:17:52.832430
# Unit test for constructor of class Environment
def test_Environment():
    # we check everything, since we cannot know where to improve
    environment = Environment()
    assert environment.is_windows == is_windows
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin == sys.stdin  # `None` when closed fd (#791)
    assert environment.stdin_isatty == sys.stdin.isatty()
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == sys.stdout.isatty()
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == sys.stderr.isatty()
    assert environment.colors == 256
    assert environment.program_name == 'http'
    # assert environment._devnull == devnull
    assert environment

# Generated at 2022-06-25 18:18:00.316191
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull='Devnull')

    key_list = [
        'is_windows',
        'config_dir',
        'stdin',
        'stdin_isatty',
        'stdin_encoding',
        'stdout',
        'stdout_isatty',
        'stdout_encoding',
        'stderr',
        'stderr_isatty',
        'colors',
        'program_name',
        'devnull'
    ]
    for key in key_list:
        if key == 'devnull':
            assert env.__getattribute__(key) == 'Devnull'
        else:
            assert env.__getattribute__(key) == Environment.__dict__[key]


# Generated at 2022-06-25 18:18:09.367938
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.is_windows == is_windows
    assert environment_0.stdin.isatty() == sys.stdin.isatty()
    assert environment_0.stdout.isatty() == sys.stdout.isatty()
    assert environment_0.stderr.isatty() == sys.stderr.isatty()
    assert environment_0.colors == 256
    assert environment_0.program_name == 'http'
    assert environment_0._devnull is None
    assert environment_0._orig_stderr is sys.stderr


# Generated at 2022-06-25 18:18:12.463418
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert (isinstance(environment, Environment))
    assert (environment.is_windows == is_windows)
    assert (environment.program_name == 'http')


# Generated at 2022-06-25 18:18:23.071233
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    # test whether the class type is Environment
    assert type(environment) is Environment
    # test whether the is_windows is operating system
    same = environment.is_windows == is_windows
    assert same == True
    # test whether the config_dir is DEFAULT_CONFIG_DIR
    same1 = environment.config_dir == DEFAULT_CONFIG_DIR
    assert same1 == True
    # test whether the stdin is sys.stdin
    same2 = environment.stdin == sys.stdin
    assert same2 == True
    # test whether the stdin_isatty is stdin.isatty
    same3 = environment.stdin_isatty
    assert same3 == True
    # test whether the stdout is sys.stdout
    same4 = environment.stdout == sys.stdout
   

# Generated at 2022-06-25 18:18:31.712743
# Unit test for constructor of class Environment
def test_Environment():
    with open('/dev/null', 'w+') as devnull:
        environment_0 = Environment(devnull,
                                    is_windows=False,
                                    stdin=sys.stdin,
                                    stdin_isatty=True,
                                    stdin_encoding="utf-8",
                                    stdout=sys.stdout,
                                    stdout_isatty=True,
                                    stdout_encoding="utf-8",
                                    stderr=sys.stderr,
                                    stderr_isatty=True,
                                    colors=256,
                                    program_name="http",
                                    config_dir=Path('/home/jeff/.config/httpie/config.json'))

# Unit tests for constructor of class Environment

# Generated at 2022-06-25 18:18:36.362994
# Unit test for constructor of class Environment
def test_Environment():
    """
    The Environment class takes **kwargs in its constructor,
    but it cannot take any kwarg not defined in the class body.

    """
    with pytest.raises(TypeError, match='unexpected keyword argument') as e:
        env = Environment(foo=1)



# Generated at 2022-06-25 18:18:37.563841
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()

# Generated at 2022-06-25 18:18:47.029790
# Unit test for constructor of class Environment
def test_Environment():
    # Create a new Environment object
    environment = Environment()

    assert hasattr(environment, "is_windows")
    assert hasattr(environment, "config_dir")
    assert hasattr(environment, "stdin")
    assert hasattr(environment, "stdin_isatty")
    assert hasattr(environment, "stdin_encoding")
    assert hasattr(environment, "stdout")
    assert hasattr(environment, "stdout_isatty")
    assert hasattr(environment, "stdout_encoding")
    assert hasattr(environment, "stderr")
    assert hasattr(environment, "stderr_isatty")
    assert hasattr(environment, "colors")
    assert hasattr(environment, "program_name")
    assert hasattr(environment, "config")

# Generated at 2022-06-25 18:19:10.278771
# Unit test for constructor of class Environment
def test_Environment():
    environment_test = Environment()
    assert environment_test.stdin_isatty == environment_test.stdin.isatty()
    assert environment_test.stdout_isatty == environment_test.stdout.isatty()
    assert environment_test.stderr_isatty == environment_test.stderr.isatty()
    assert type(environment_test.config_dir) == Path
    assert environment_test.is_windows == os.name == 'nt'

# Generated at 2022-06-25 18:19:13.588470
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert(environment_0.is_windows == False)
    assert(str(environment_0.config_dir) == str(Path(DEFAULT_CONFIG_DIR)))


# Generated at 2022-06-25 18:19:23.383151
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.is_windows == is_windows
    assert environment_0.config_dir == DEFAULT_CONFIG_DIR
    assert environment_0.stdin == sys.stdin 
    assert environment_0.stdin_isatty == (sys.stdin.isatty() if sys.stdin else False)
    assert environment_0.stdin_encoding == None
    assert environment_0.stdout == sys.stdout
    assert environment_0.stdout_isatty == sys.stdout.isatty()
    assert environment_0.stdout_encoding == None
    assert environment_0.stderr == sys.stderr
    assert environment_0.stderr_isatty == sys.stderr.isatty()

# Generated at 2022-06-25 18:19:27.742337
# Unit test for constructor of class Environment
def test_Environment():
    try:
        test_case_0()
    except:
        print("test_case_0 failed")
        assert False
    else:
        print("test_case_0 succeeded")
        assert True

# Test if the attributes of the constructed class Environment is the same with the expected ones

# Generated at 2022-06-25 18:19:35.044741
# Unit test for constructor of class Environment
def test_Environment():
    try:
        assert not environment_0.stdin_isatty
    except AttributeError:
        environment_0.stdin_isatty = False  # Python 2.6
    assert environment_0.stdout_isatty
    assert environment_0.stderr_isatty
    assert environment_0.stdout_encoding is not None
    assert environment_0.stdout_encoding.lower() in ('utf8', 'utf-8')

if __name__ == "__main__":
    test_Environment()
    print('Test has passed.')

# Generated at 2022-06-25 18:19:40.720394
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=1, config_dir='/config', stdin=1, stdout=1, stderr=1, is_windows=False, name='http')
    assert env.devnull == 1
    assert env.config_dir == '/config'
    assert env.stdin == 1
    assert env.stdout == 1
    assert env.stderr == 1
    assert env.is_windows == False
    assert env.program_name == 'http'


if __name__ == '__main__':
    test_case_0()
    test_Environment()

# Generated at 2022-06-25 18:19:51.488872
# Unit test for constructor of class Environment
def test_Environment():
    from os import devnull
    from unittest import mock
    from httpie.config import Environment
    
    # Create a mock object of FileIO
    file_mock = mock.mock_open()
    file_mock.name = '/dev/null'
    file_mock.readable = True
    file_mock.writable = True

    # Open file
    with mock.patch('builtins.open', file_mock):
        file_handle = open('/dev/null')
        file_handle.isatty = True

        # Expected non-default values 
        file_handle.encoding = 'utf8'
        sys.stdout.isatty = True
        sys.stderr.isatty = True

        # Expected default values
        colorama.initialise.wrap_stream = True


# Generated at 2022-06-25 18:20:00.332073
# Unit test for constructor of class Environment
def test_Environment():
    # test environment with arguments
    env_args = Environment(devnull='null', is_windows='false', config_dir='./config', stdin='sys.stdin',
                           stdin_isatty=False, stdin_encoding='utf8', stdout='sys.stdout', stdout_isatty=True,
                           stdout_encoding='utf8', stderr='sys.stderr', stderr_isatty=True, colors=256,
                           program_name='httpie')

    # test environment without arguments
    env_none_args = Environment()

    # check whether devnull is being set correctly
    assert env_args.devnull == env_args._devnull == 'null'
    assert env_none_args.devnull == env_none_args._devnull

    # check whether is

# Generated at 2022-06-25 18:20:04.935893
# Unit test for constructor of class Environment
def test_Environment():
    import os

    env = Environment(devnull=os.devnull)
    assert env.devnull == os.devnull
    assert env.stderr_isatty is False
    assert env.stdout_isatty is False

# Generated at 2022-06-25 18:20:06.039520
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert isinstance(environment_0, Environment)


# Generated at 2022-06-25 18:20:47.242012
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin is sys.stdin
    assert env.stdout is sys.stdout
    assert env.stderr is sys.stderr
    assert env.program_name == 'http'
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.stdin_encoding == 'utf8'
    assert env.stdout_encoding == 'utf8'
    assert env.stderr_encoding == 'utf8'

# Generated at 2022-06-25 18:20:52.271612
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert isinstance(environment_0, object)
    assert isinstance(environment_0, Environment)
    environment_0 = Environment(devnull=None, is_windows=False, config_dir=DEFAULT_CONFIG_DIR)
    assert isinstance(environment_0, Environment)
    assert isinstance(environment_0, Environment)


# Generated at 2022-06-25 18:20:53.198076
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()


# Generated at 2022-06-25 18:20:56.459044
# Unit test for constructor of class Environment
def test_Environment():
    with pytest.raises(TypeError):
        environment_1 = Environment(None)

    with pytest.raises(AssertionError):
        environment_2 = Environment(None, key=1)



# Generated at 2022-06-25 18:21:07.317722
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    if not hasattr(environment_0, 'is_windows'):
        raise AssertionError
    if not hasattr(environment_0, 'config_dir'):
        raise AssertionError
    if not hasattr(environment_0, 'stdin'):
        raise AssertionError
    if not hasattr(environment_0, 'stdin_isatty'):
        raise AssertionError
    if not hasattr(environment_0, 'stdin_encoding'):
        raise AssertionError
    if not hasattr(environment_0, 'stdout'):
        raise AssertionError
    if not hasattr(environment_0, 'stdout_isatty'):
        raise AssertionError

# Generated at 2022-06-25 18:21:10.139847
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    environment_1 = Environment(devnull='/dev/null')
    assert(environment_0._devnull is None)
    assert(environment_1._devnull == '/dev/null')

# Generated at 2022-06-25 18:21:15.761649
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment()
    assert type(e) == Environment
    assert e.__delattr__ == None
    assert e.__dict__ == e.__dict__
    assert e.__doc__ == None
    assert e.__eq__ == None
    assert e.__format__ == None
    assert e.__ge__ == None
    assert e.__getattribute__ == None
    assert e.__gt__ == None
    assert e.__hash__ == None
    assert e.__init__ == None
    assert e.__init_subclass__ == None
    assert e.__le__ == None
    assert e.__lt__ == None
    assert e.__module__ == e.__module__
    assert e.__ne__ == None
    assert e.__new__ == None
    assert e.__reduce__ == None


# Generated at 2022-06-25 18:21:26.780323
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows is is_windows
    assert env.config_dir is DEFAULT_CONFIG_DIR
    assert env.stdin is sys.stdin
    assert env.stdin_isatty is sys.stdin.isatty()
    assert env.stdin_encoding is None
    assert env.stdout is sys.stdout
    assert env.stdout_isatty is sys.stdout.isatty()
    assert env.stdout_encoding is None
    assert env.stderr is sys.stderr
    assert env.stderr_isatty is sys.stderr.isatty()
    assert env.colors is 256
    assert env.program_name is 'http'


# Generated at 2022-06-25 18:21:34.127530
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment()
    assert e is not None
    assert e.config_dir is not None
    assert e.stdin is not None
    assert e.stdin_isatty
    assert e.stderr is not None
    assert e.stderr_isatty
    assert e.stdout is not None
    assert e.stdout_isatty
    assert e.colors == 256
    assert e.program_name == 'http'
    assert e.stderr_encoding is None
    assert e.stdin_encoding is not None
    assert e.stdout_encoding is not None

    assert str(e) is not None
    assert repr(e) is not None
    assert e.devnull is not None

    e.devnull = None
    assert e.devnull is not None

    #

# Generated at 2022-06-25 18:21:41.589790
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.colors == 256
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.stdout_encoding == sys.stdout.encoding
    assert isinstance(env.config_dir, Path)

# Generated at 2022-06-25 18:22:50.356929
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().config_dir == DEFAULT_CONFIG_DIR


# Generated at 2022-06-25 18:23:00.095470
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    config = environment.config
    assert config is not None
    assert config.is_user_config_dir is True
    assert environment.stdin is sys.stdin
    assert environment.stdout is sys.stdout
    assert environment.stderr is sys.stderr
    assert environment.program_name == 'http'
    assert environment.stdin_encoding == "utf8"
    assert environment.stderr_isatty is True
    assert environment.stdout_encoding == "utf8"

# Test for constructor of class Environment with keyword arguments:
# - program_name
# - colors
# - config_dir

# Generated at 2022-06-25 18:23:04.794161
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment();
    assert env.program_name == 'http'
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert env.colors == 256


# Generated at 2022-06-25 18:23:07.634364
# Unit test for constructor of class Environment
def test_Environment():
    print("\n1. Check constructor of class Environment")
    environment_0 = Environment()
    print("Environment:{0}".format(environment_0))

# Generated at 2022-06-25 18:23:08.649433
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert(env is not None)

# Generated at 2022-06-25 18:23:10.798638
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()

if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-25 18:23:14.685515
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    # Test:
    # 1. Attributes should be the same as of class Environment
    # 2. Colors should be atleast 8
    assert isinstance(env, Environment) and isinstance(env.colors, int) and env.colors >= 8



# Generated at 2022-06-25 18:23:23.600576
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    # print(environment_0)
    print(environment_0.stderr_isatty)
    print(environment_0.stderr)
    print(type(environment_0.stderr))
    print(environment_0.stderr_encoding)
    print(type(environment_0.stderr_encoding))
    print(environment_0.stdout)
    print(type(environment_0.stdout))
    print(environment_0.stdout_encoding)
    print(type(environment_0.stdout_encoding))
    print(environment_0.stdin)
    print(type(environment_0.stdin))
    print(environment_0.stdin_encoding)
    print(type(environment_0.stdin_encoding))


# Generated at 2022-06-25 18:23:31.953275
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()

    assert environment.is_windows == is_windows
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == sys.stdin.isatty()
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == sys.stdout.isatty()
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == sys.stderr.isatty()
    assert environment.colors == 256
    assert environment.program_name == 'http'

test_Environment()



# Generated at 2022-06-25 18:23:41.639483
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()
    assert environment_1.is_windows == is_windows
    assert environment_1.stdin == sys.stdin
    assert environment_1.stdin_isatty == sys.stdin.isatty()
    assert environment_1.stdout == sys.stdout
    assert environment_1.stdout_isatty == sys.stdout.isatty()
    assert environment_1.stderr == sys.stderr
    assert environment_1.stderr_isatty == sys.stderr.isatty()
    assert environment_1.program_name == 'http'

    # Test case with different arguments
    environment_2 = Environment(stderr='STDERR')
    assert environment_2.is_windows == is_windows

# Generated at 2022-06-25 18:25:00.869828
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().config == Config(directory=DEFAULT_CONFIG_DIR)
    assert Environment().config_dir == DEFAULT_CONFIG_DIR
    assert Environment().stderr == sys.stderr
    assert Environment().stderr_isatty == sys.stderr.isatty()
    assert Environment().stderr_encoding == sys.stderr.encoding
    assert Environment().stdout == sys.stdout
    assert Environment().stdout_isatty == sys.stdout.isatty()
    assert Environment().stdout_encoding == sys.stdout.encoding
    assert Environment().stdin == sys.stdin
    assert Environment().stdin_isatty == sys.stdin.isatty()
    assert Environment().stdin_encoding == sys.stdin.encoding

# Generated at 2022-06-25 18:25:09.588737
# Unit test for constructor of class Environment
def test_Environment():
    try:
        devnull=open("testfile.txt", "r+")
    except IOError:
        print("Could not open file!")
        return
    stdin = sys.stdin  # `None` when closed fd (#791)
    stdin_isatty = stdin.isatty() if stdin else False
    stdin_encoding = None
    stdout = sys.stdout
    stdout_isatty = stdout.isatty()
    stdout_encoding = None
    stderr = sys.stderr
    stderr_isatty = stderr.isatty()
    program_name = 'http'
    assert stdin == sys.stdin
    assert stderr == sys.stderr
    assert stdout == sys.stdout
    assert stdin

# Generated at 2022-06-25 18:25:17.626931
# Unit test for constructor of class Environment
def test_Environment():
    devnull = os.devnull
    stdin = (1).__repr__()
    stdout = (2).__repr__()
    stderr = (3).__repr__()
    config_dir = DEFAULT_CONFIG_DIR.__str__()
    stdin_isatty = False
    stdin_encoding = 'utf8'
    stdout_isatty = False
    stdout_encoding = 'utf8'
    stderr_isatty = False
    colors = 256
    program_name = 'http'

# Generated at 2022-06-25 18:25:26.966069
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(config_dir="1", stderr_isatty="2", stdout_encoding="3", devnull="4", 
                              stderr="5", stdin_isatty="6", stdin="7", stdout="8", is_windows="9", 
                              stdout_isatty="10", colors="11", program_name="12", stdin_encoding="13")
    assert environment.config_dir == "1"
    assert environment.stderr_isatty == "2"
    assert environment.stdout_encoding == "3"
    assert environment.devnull == "4"
    assert environment.stderr == "5"
    assert environment.stdin_isatty == "6"
    assert environment.stdin == "7"