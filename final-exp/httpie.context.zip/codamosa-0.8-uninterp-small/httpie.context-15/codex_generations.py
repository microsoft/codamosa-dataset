

# Generated at 2022-06-25 18:15:41.772894
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(devnull=open(os.devnull, 'w+'), stderr=sys.stderr)
    environment_1.stderr_isatty = False
    assert not environment_1.stderr_isatty


# Generated at 2022-06-25 18:15:49.339323
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment()
    assert isinstance(e, Environment)
    assert e.is_windows == is_windows
    assert e.config_dir == DEFAULT_CONFIG_DIR
    assert e.stdin == sys.stdin
    assert e.stdin_isatty == sys.stdin.isatty()
    assert e.stdin_encoding == None
    assert e.stdout == sys.stdout
    assert e.stdout_isatty == sys.stdout.isatty()
    assert e.stdout_encoding == None
    assert e.stderr == sys.stderr
    assert e.stderr_isatty == sys.stderr.isatty()

# Generated at 2022-06-25 18:15:53.883400
# Unit test for constructor of class Environment
def test_Environment():
    # Test 1
    try:
        test_case_0()
    except:
        print("Test 1: FAILED")
    else:
        print("Test 1: PASSED")


if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-25 18:15:59.562144
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(program_name='httpie.py', config_dir='/home/httpie/.config/httpie')
    assert environment_1.program_name == 'httpie.py'
    assert environment_1.config_dir == '/home/httpie/.config/httpie'
    assert environment_1.config.directory == '/home/httpie/.config/httpie'
    assert environment_1.stdin == sys.stdin
    assert environment_1.stdin_isatty == sys.stdin.isatty() if sys.stdin else False
    assert environment_1.stdout == sys.stdout
    assert environment_1.stdout_isatty == sys.stdout.isatty()
    assert environment_1.stderr == sys.stderr
    assert environment_1.stderr

# Generated at 2022-06-25 18:16:11.586303
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows == is_windows
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin_isatty == sys.stdin.isatty() if sys.stdin else False
    assert environment.stdin_encoding == os.getenv('PYTHONIOENCODING', 'utf8')
    assert environment.stdout_isatty == sys.stdout.isatty()
    assert environment.stdout_encoding == os.getenv('PYTHONIOENCODING', 'utf8')
    assert environment.stderr_isatty == sys.stderr.isatty()
    assert environment.stderr_encoding == os.getenv('PYTHONIOENCODING', 'utf8')
    assert environment.col

# Generated at 2022-06-25 18:16:19.725118
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(
        is_windows = True,
        config_dir = Path('/home/user'),
        stdin = sys.stdin,
        stdin_isatty = False,
        stdin_encoding = 'utf-8',
        stdout = sys.stdout,
        stdout_isatty = True,
        stdout_encoding = 'utf-8',
        stderr = sys.stderr,
        stderr_isatty = True,
        stderr_encoding = 'utf-8',
        colors = 256,
        program_name = 'httpie'
    )
    assert environment.is_windows == True
    assert environment.config_dir == Path('/home/user')
    assert environment.stdin == sys.stdin
    assert environment.stdin_isat

# Generated at 2022-06-25 18:16:31.704642
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.is_windows == is_windows
    assert environment_0.config_dir == DEFAULT_CONFIG_DIR
    assert environment_0.stdin == sys.stdin
    assert environment_0.stdin_isatty == environment_0.stdin.isatty()
    assert environment_0.stdout == sys.stdout
    assert environment_0.stdout_isatty == environment_0.stdout.isatty()
    assert environment_0.stderr == sys.stderr
    assert environment_0.stderr_isatty == environment_0.stderr.isatty()
    assert environment_0.colors == 256
    assert environment_0.program_name == 'http'


# Generated at 2022-06-25 18:16:42.744322
# Unit test for constructor of class Environment
def test_Environment():
    test_0 = Environment(
        config_dir= Path('/home/httpie'),
        stdin= sys.stdin,
        stdin_isatty= False,
        stdin_encoding= 'utf8',
        stdout= sys.stdout,
        stdout_isatty= False,
        stdout_encoding= 'utf8',
        stderr= sys.stderr,
        stderr_isatty= false,
        colors= 256,
        program_name= 'http',
    )
    assert test_0.config_dir == Path('/home/httpie')
    assert test_0.stdin == sys.stdin
    assert test_0.stdin_isatty == False
    assert test_0.stdin_encoding == 'utf8'
    assert test_

# Generated at 2022-06-25 18:16:52.315769
# Unit test for constructor of class Environment
def test_Environment():
    environment_1=Environment()
    # below assert statements are used to check the correct environment values are set.
    assert environment_1.is_windows == True
    assert environment_1.config_dir == Path(DEFAULT_CONFIG_DIR)
    assert environment_1.stdin_isatty == True
    assert environment_1.stdin_encoding == 'utf8'
    assert environment_1.stdout_isatty == True
    assert environment_1.stdout_encoding == 'utf8'
    assert environment_1.stderr_isatty == True
    assert environment_1.colors == 256
    assert environment_1.program_name == 'http'


# Generated at 2022-06-25 18:16:58.698679
# Unit test for constructor of class Environment
def test_Environment():
    # A new Environment object is created
    environment_1 = Environment()

    # A new Environment object with modified attributes is created
    attrs = {
        'is_windows': False,
        'config_dir': Path('/var/lib/httpie'),
        'stdin': sys.stdin,
        'stdin_isatty': False,
        'stdin_encoding': 'utf8',
        'stdout': sys.stdout,
        'stdout_isatty': True,
        'stdout_encoding': 'utf8',
        'stderr': sys.stderr,
        'stderr_isatty': True,
        'colors': 0,
        'program_name': 'httpie'
    }
    environment_2 = Environment(**attrs)

    # Check if the attributes

# Generated at 2022-06-25 18:17:13.049637
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.__class__ is Environment
    assert environment_0.is_windows is True
    assert environment_0.config_dir == DEFAULT_CONFIG_DIR
    assert environment_0.stdin.closed == False
    assert environment_0.stdin_isatty == True
    assert environment_0.stdin_encoding == "utf-8"
    assert environment_0.stdout.closed == False
    assert environment_0.stdout_isatty == True
    assert environment_0.stdout_encoding == "utf-8"
    assert environment_0.stderr.closed == False
    assert environment_0.stderr_isatty == True
    assert environment_0.stderr_encoding == None
    assert environment_0.colors == 256
   

# Generated at 2022-06-25 18:17:15.384865
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.stdin_isatty and env.stdout_isatty and env.stderr_isatty


# Generated at 2022-06-25 18:17:19.705093
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    env.stdin_encoding = "utf8"
    env.stderr_encoding = "utf8"
    env.stdout_encoding = "utf8"

    assert env is not None
    assert env.stdin_encoding is not None
    assert env.stdout_encoding is not None
    assert env.stderr_encoding is not None


# Generated at 2022-06-25 18:17:20.602461
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()


# Generated at 2022-06-25 18:17:23.938077
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert isinstance(environment, Environment)
    assert isinstance(environment.stdout_encoding, str)
    assert isinstance(environment.stdin_encoding, str)


# Generated at 2022-06-25 18:17:33.464396
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert type(env.is_windows) == bool
    assert type(env.config_dir) == Path
    assert type(env.stdin) == _io.TextIOWrapper
    assert type(env.stdin_isatty) == bool
    assert type(env.stdin_encoding) == str
    assert type(env.stdout) == _io.TextIOWrapper
    assert type(env.stdout_isatty) == bool
    assert type(env.stdout_encoding) == str
    assert type(env.stderr) == _io.TextIOWrapper
    assert type(env.stderr_isatty) == bool
    assert type(env.colors) == int
    assert type(env.program_name) == str

# Generated at 2022-06-25 18:17:45.091704
# Unit test for constructor of class Environment
def test_Environment():
    import sys

    config_dir = '~/.config/httpie/httpie.json'
    stdin = sys.stdin
    stdout = sys.stdout
    stderr = sys.stderr
    colors = 256
    program_name = 'http'

    # test constructor
    environment_1 = Environment(
                            config_dir = config_dir,
                            stdin = stdin,
                            stdout = stdout,
                            stderr = stderr,
                            colors = colors,
                            program_name = program_name,
                            )
    assert environment_1.config_dir == config_dir
    assert environment_1.stdin == stdin
    assert environment_1.stdout == stdout
    assert environment_1.stderr == stderr

# Generated at 2022-06-25 18:17:46.229672
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()


# Unit testing for function setter of property devnull

# Generated at 2022-06-25 18:17:51.538669
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin  # `None` when closed fd (#791)
    assert env.stdin_isatty == (sys.stdin.isatty() if sys.stdin else False)
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name

# Generated at 2022-06-25 18:17:59.728154
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    environment_0.is_windows = True
    environment_0.config_dir = Path('/Users/lw/Library/Preferences')
    environment_0.stdin = None
    environment_0.stdin_isatty = False
    environment_0.stdin_encoding = 'utf8'
    environment_0.stdout = sys.stdout
    environment_0.stdout_isatty = True
    environment_0.stdout_encoding = 'utf8'
    environment_0.stderr = sys.stderr
    environment_0.stderr_isatty = True
    environment_0.colors = 256
    environment_0.program_name = 'http'
    environment_0._orig_stderr = sys.stderr
    environment_0

# Generated at 2022-06-25 18:18:07.668905
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()

    assert env.is_windows == False
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == True
    assert env.stdin_encoding == None
    assert env.stdout_isatty == True
    assert env.stdout_encoding == None
    assert env.stderr_isatty == True
    assert env.colors == 256
    assert env.program_name == 'http'



# Generated at 2022-06-25 18:18:09.042782
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment()


# Generated at 2022-06-25 18:18:16.975395
# Unit test for constructor of class Environment
def test_Environment():
    base_dir = 'test/'

# Generated at 2022-06-25 18:18:18.186265
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0 is not None


# Generated at 2022-06-25 18:18:19.415092
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()


# Generated at 2022-06-25 18:18:29.446603
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == environment.stdin.isatty()
    assert environment.stdin_encoding == None
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == environment.stdout.isatty()
    assert environment.stdout_encoding == None
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == environment.stderr.isatty()
    assert environment.program_name == 'http'
    assert environment.colors == 256



# Generated at 2022-06-25 18:18:34.381308
# Unit test for constructor of class Environment
def test_Environment():
    import sys
    from httpie.config import DEFAULT_CONFIG_DIR
    environment_1 = Environment(is_windows=True, config_dir=DEFAULT_CONFIG_DIR, stdin=sys.stdin, stdin_isatty=sys.stdin.isatty(), stdin_encoding=None, stdout=sys.stdout, stdout_isatty=sys.stdout.isatty(), stdout_encoding=None, stderr=sys.stderr, stderr_isatty=sys.stderr.isatty(), colors=256, program_name='http', _orig_stderr=sys.stderr, _devnull=None)
    print(environment_1)

# Generated at 2022-06-25 18:18:36.716294
# Unit test for constructor of class Environment
def test_Environment():
    environment_test = Environment()
    assert type(environment_test) == Environment


# Generated at 2022-06-25 18:18:45.932558
# Unit test for constructor of class Environment
def test_Environment():
    from httpie.environment import Environment

    environment = Environment(
        is_windows = False,
        config_dir = '/home/httpie',
        stdin = sys.stdin,
        stdin_isatty = sys.stdin.isatty(),
        stdin_encoding = None,
        stdout = sys.stdout,
        stdout_isatty = sys.stdout.isatty(),
        stdout_encoding = None,
        stderr = sys.stderr,
        stderr_isatty = sys.stderr.isatty(),
        colors = 8,
        program_name = 'http'
    )
    return bool(isinstance(environment, Environment))


# Generated at 2022-06-25 18:18:51.921785
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.__dict__['is_windows'] == Environment.is_windows
    assert environment.__dict__['config_dir'] == Environment.config_dir
    assert environment.__dict__['stdin'] == Environment.stdin
    assert environment.__dict__['stdin_isatty'] == Environment.stdin_isatty
    assert environment.__dict__['stdin_encoding'] == Environment.stdin_encoding
    assert environment.__dict__['stdout_encoding'] == Environment.stdout_encoding
    assert environment.__dict__['stdout'] == Environment.stdout
    assert environment.__dict__['stdout_isatty'] == Environment.stdout_isatty
    assert environment.__dict__['stderr'] == Environment.stderr
    assert environment.__dict

# Generated at 2022-06-25 18:19:02.397745
# Unit test for constructor of class Environment
def test_Environment():
    case_0 = Environment()
    assert case_0


if __name__ == '__main__':
    import pytest
    pytest.main(['-s', __file__])

# Generated at 2022-06-25 18:19:13.547662
# Unit test for constructor of class Environment
def test_Environment():
    env1 = Environment(devnull=6, is_windows=False, config_dir="config_dir_1")
    assert env1.__dict__ == {'_devnull': 6, 'is_windows': False, 'config_dir': "config_dir_1", 'stdin': sys.stdin, 'stdin_isatty': False, 'stdin_encoding': None, 'stdout': sys.stdout, 'stdout_isatty': True, 'stdout_encoding': None, 'stderr': sys.stderr, 'stderr_isatty': True, 'colors': 256, 'program_name': 'http', '_orig_stderr': sys.stderr, '_config': None}
    env2 = Environment(devnull=7, config_dir="config_dir_2")


# Generated at 2022-06-25 18:19:16.632991
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows == is_windows
    assert sys.stdin == environment.stdin
    assert sys.stdout == environment.stdout
    assert sys.stderr == environment.stderr


# Testing Environment.stdin_isatty

# Generated at 2022-06-25 18:19:27.701932
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert type(environment) == Environment
    assert environment.is_windows == is_windows
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin is sys.stdin
    assert environment.stdin_isatty == environment.stdin.isatty()
    assert environment.stdin_encoding is None
    assert environment.stdout is sys.stdout
    assert environment.stdout_isatty == environment.stdout.isatty()
    assert environment.stdout_encoding is None
    assert environment.stderr is sys.stderr
    assert environment.stderr_isatty == environment.stderr.isatty()
    #assert environment.colors == 256
    assert environment.program_name == 'http'
    assert environment._orig_st

# Generated at 2022-06-25 18:19:36.889055
# Unit test for constructor of class Environment
def test_Environment():
    # Construct an Environment object
    environment_0 = Environment()
    assert (environment_0 is not None), "Failed to initialize Environment class"
    assert (environment_0.__dict__ is not None), "Failed to initialize Environment class"

    # Over-write an Environment object
    stdin = sys.stdin
    stdin_isatty = stdin.isatty() if stdin else False
    stdin_encoding = None
    stdout = sys.stdout
    stdout_isatty = stdout.isatty()
    stdout_encoding = None
    stderr = sys.stderr
    stderr_isatty = stderr.isatty()
    colors = 256
    program_name = 'http'

# Generated at 2022-06-25 18:19:38.873762
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(stdin=open("/dev/null"), devnull=open("dev/null"))
    assert environment.stdin == open("/dev/null") and environment.devnull == open("dev/null")


# Generated at 2022-06-25 18:19:50.772661
# Unit test for constructor of class Environment
def test_Environment():
    stdin = StringIO()
    stdout = StringIO()
    stderr = StringIO()
    stdin.write('Input')
    stdin.seek(0)
    stdout.write('Output')
    stdout.seek(0)
    stderr.write('Error')
    stderr.seek(0)

    env = Environment(
        stdin=stdin, stdout=stdout, stderr=stderr
    )
    assert env.stdin_isatty
    assert env.stdout_isatty
    assert env.stderr_isatty
    assert env.stdin_encoding is None
    assert env.stdout_encoding is None
    assert env.program_name == 'http'
    assert env.colors == 256

    stdin.seek(0)


# Generated at 2022-06-25 18:19:51.709171
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(program_name = 'httpie')
    assert environment.program_name == 'httpie'



# Generated at 2022-06-25 18:19:55.880079
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()
    assert environment_1.is_windows == is_windows
    assert environment_1.config_dir == DEFAULT_CONFIG_DIR
    assert environment_1.stdin == sys.stdin
    assert environment_1.stdin_isatty == sys.stdin.isatty()
    assert environment_1.stdin_encoding == 'utf-8'
    assert environment_1.stdout == sys.stdout
    assert environment_1.stdout_isatty == True
    assert environment_1.stdout_encoding == 'utf-8'
    assert environment_1.stderr == sys.stderr
    assert environment_1.stderr_isatty == True
    assert environment_1.colors == 256
    assert environment_1.program_name == 'http'


# Generated at 2022-06-25 18:20:02.325468
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().is_windows == Environment.is_windows
    assert Environment().config_dir == Environment.config_dir
    assert Environment().stdin == Environment.stdin
    assert Environment().stdin_isatty == Environment.stdin_isatty
    assert Environment().stdout == Environment.stdout
    assert Environment().stdout_isatty == Environment.stdout_isatty
    assert Environment().stderr == Environment.stderr
    assert Environment().stderr_isatty == Environment.stderr_isatty
    assert Environment().program_name == Environment.program_name
    Environment().stderr_isatty == Environment.stderr_isatty



# Generated at 2022-06-25 18:20:24.025979
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        stdin='stdin_fd',
        stdout='stdout_fd',
        stderr='stderr_fd',
        config_dir='config_dir',
        program_name='httpie'
    )

    assert env.stdin == 'stdin_fd'
    assert env.stdout == 'stdout_fd'
    assert env.stderr == 'stderr_fd'
    assert env.config_dir == 'config_dir'
    assert env.program_name == 'httpie'



# Generated at 2022-06-25 18:20:32.445408
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(is_windows=False,
                              config_dir='/home/httpie/.httpie',
                              stdin=None,
                              stdin_isatty=True,
                              stdin_encoding='UTF-8',
                              stdout=sys.stdout,
                              stdout_isatty=True,
                              stdout_encoding='UTF-8',
                              stderr=sys.stderr,
                              stderr_isatty=True,
                              colors=256,
                              program_name='http')
    assert isinstance(environment, Environment)



# Generated at 2022-06-25 18:20:36.413657
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(colors=256)
    assert environment_1.colors == 256
    environment_2 = Environment(devnull=None)
    assert environment_2.devnull == None


# Generated at 2022-06-25 18:20:45.831053
# Unit test for constructor of class Environment
def test_Environment():
    # Test the constructor
    config = Config(directory=Path(DEFAULT_CONFIG_DIR))
    curr_env = Environment(devnull=None, config_dir=config.directory)
    assert curr_env.is_windows == False
    assert curr_env.config_dir == Path(DEFAULT_CONFIG_DIR)
    assert curr_env.stdin == sys.stdin
    assert curr_env.stdin_isatty == True
    assert curr_env.stdout == sys.stdout
    assert curr_env.stdout_isatty == True
    assert curr_env.stderr == sys.stderr
    assert curr_env.stderr_isatty == True
    assert curr_env.colors == 256
    assert curr_env.program_name

# Generated at 2022-06-25 18:20:55.736218
# Unit test for constructor of class Environment
def test_Environment():
    input_arguments = ['http', 'https://google.com', '-g']
    environment = Environment()
    assert input_arguments == environment.input_arguments
    assert environment.program_name == 'http'
    assert environment.is_windows == is_windows
    assert os.path.join(os.path.expanduser('~'), ".config") == str(environment.config_dir)
    assert sys.stdin == environment.stdin
    assert sys.stdin == environment.stdin
    assert sys.stdout == environment.stdout
    assert sys.stderr == environment.stderr
    assert environment.stdout_encoding == sys.getdefaultencoding()
    assert environment.stderr_encoding == sys.getdefaultencoding()


# Generated at 2022-06-25 18:20:57.466044
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows == is_windows



# Generated at 2022-06-25 18:21:01.013495
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0 is not None
    assert environment_0.stdin_isatty
    assert isinstance(environment_0.config_dir, Path)
    assert environment_0.stdout_encoding == 'utf8'

# Generated at 2022-06-25 18:21:10.534487
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows == is_windows
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == sys.stdin.isatty()
    assert environment.stdin_encoding == None
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == sys.stdout.isatty()
    assert environment.stdout_encoding == None
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == sys.stderr.isatty()
    assert environment.stderr_encoding == None
    assert environment.colors == 256
    assert environment.program_name == 'http'

# Tests Environment

# Generated at 2022-06-25 18:21:12.454217
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()


if __name__ == '__main__':
    pytest.main()

# Generated at 2022-06-25 18:21:13.420416
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()

# Generated at 2022-06-25 18:21:59.305570
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment.stdin is not None
    assert not Environment.stdin_isatty
    assert Environment.stdout is not None
    assert not Environment.stdout_isatty
    assert Environment.stderr is not None
    assert not Environment.stderr_isatty
    assert Environment.stdin_encoding == 'utf8'
    assert Environment.stdout_encoding == 'utf8'
    assert Environment.stderr_encoding == 'utf8'
    environment = Environment()
    assert environment is not None
    assert environment.config_dir == Path.home() / '.config' / 'httpie'
    assert environment.stdin is not None
    assert not environment.stdin_isatty
    assert environment.stdout is not None
    assert not environment.stdout_isatty
    assert environment.stder

# Generated at 2022-06-25 18:22:09.666373
# Unit test for constructor of class Environment

# Generated at 2022-06-25 18:22:16.753441
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(__name__)
    assert environment_1.is_windows == False
    assert environment_1.config_dir == Path(DEFAULT_CONFIG_DIR)
    #assert environment_1.stdin is None
    #assert environment_1.stdin_isatty == False
    assert environment_1.stdout == sys.stdout


# Generated at 2022-06-25 18:22:18.320313
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment(is_windows=True).is_windows
    assert '<Environment {' in repr(Environment())

# Generated at 2022-06-25 18:22:26.387409
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.is_windows == is_windows
    assert environment_0.config_dir == DEFAULT_CONFIG_DIR
    assert environment_0.stdin == sys.stdin
    assert environment_0.stdin_isatty == stdin.isatty()
    assert environment_0.stdin_encoding == None
    assert environment_0.stdout == sys.stdout
    assert environment_0.stdout_isatty == stdout.isatty()
    assert environment_0.stdout_encoding == None
    assert environment_0.stderr == sys.stderr
    assert environment_0.stderr_isatty == stderr.isatty()
    assert environment_0.colors == 256

# Generated at 2022-06-25 18:22:36.709863
# Unit test for constructor of class Environment

# Generated at 2022-06-25 18:22:46.465484
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(devnull='TEST', is_windows=True, config_dir = Path('httpie'), stdin = sys.stdin, stdin_isatty = False,
                              stdout = sys.stdout, stdout_isatty = True, stderr = sys.stderr, stderr_isatty = True, colors = 184, program_name = 'httpie')
    assert environment.devnull == 'TEST'
    assert environment.is_windows == True
    assert environment.config_dir == Path('httpie')
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == False
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == True
    assert environment.stderr == sys.stderr
    assert environment

# Generated at 2022-06-25 18:22:49.397851
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert(environment_0.stdout_isatty == True)
    

# Generated at 2022-06-25 18:23:00.823934
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()

# Generated at 2022-06-25 18:23:04.121583
# Unit test for constructor of class Environment
def test_Environment():
    enviroment_expected = Environment()
    print('test_Environment: ' + str(enviroment_expected.colors == 256))

# Generated at 2022-06-25 18:24:22.060609
# Unit test for constructor of class Environment
def test_Environment():
    import io
    import sys
    import pathlib
    try:
        import curses
    except ImportError:
        curses = None  # Compiled w/o curses
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.compat import is_windows
    from httpie.utils import repr_dict
    from httpie.environment import Environment

    print("\nUnit test for constructor of class Environment")
    # Create a new instance of environment with new values for attributes
    stdin = io.StringIO("Test123")
    stdout = io.StringIO("")
    stderr = io.StringIO("")

    # Test whether the initialised attributes has the given value

# Generated at 2022-06-25 18:24:31.429301
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()

    assert(environment_1.stdin_isatty == sys.stdin.isatty())
    assert(environment_1.stdout_isatty == sys.stdout.isatty())
    assert(environment_1.stderr_isatty == sys.stderr.isatty())
    
    assert(environment_1.stdin_encoding == sys.stdin.encoding)
    # assert(environment_1.stdout_encoding == sys.stdout.encoding)
    assert(environment_1.stderr_encoding == sys.stderr.encoding)
    
    assert(environment_1.is_windows == is_windows)
    assert(environment_1.config_dir == DEFAULT_CONFIG_DIR)

# Generated at 2022-06-25 18:24:35.707083
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()

    assert env.is_windows
    assert env.config_dir.exists()
    assert env.stdin
    assert env.stdin_isatty
    assert env.stdout
    assert env.stdout_isatty
    assert env.stderr
    assert env.stderr_isatty
    assert env.colors >= 0
    assert env.program_name


# Generated at 2022-06-25 18:24:43.057355
# Unit test for constructor of class Environment
def test_Environment():
    print(test_case_0.__annotations__)
    if test_case_0.__annotations__['return'] == Environment:

        if test_case_0.__name__ == 'test_case_0':
            obj = test_case_0()
            if isinstance(obj, Environment):
                print('\nTEST CASE 0:  PASSED')
            else:
                print('\nTEST CASE 0:  FAILED')

        else:
            print('\nTEST CASE 0:  FAILED')
    else:
        print('\nTEST CASE 0:  FAILED')

# Generated at 2022-06-25 18:24:49.175760
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    # test the constructor:
    environment.is_windows = True
    environment.config_dir = 'Joel'
    environment.stdin = sys.stdin
    environment.stdin_isatty = sys.stdin.isatty()
    environment.stdin_encoding = sys.stdin.encoding
    environment.stdout = sys.stdout
    environment.stdout_isatty = sys.stdout.isatty()
    environment.stdout_encoding = sys.stdout.encoding
    environment.stderr = sys.stderr
    environment.stderr_isatty = sys.stderr.isatty()
    environment.program_name = 'Joel'
    # the attributes of the class which is the super-class of Environment
    environment.log_error

# Generated at 2022-06-25 18:24:59.337455
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.devnull == None
    assert env.config == Config(directory=DEFAULT_CONFIG_DIR)
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr
    assert env.config_dir == DEFAULT_CONFIG_DIR


# Generated at 2022-06-25 18:25:08.345678
# Unit test for constructor of class Environment
def test_Environment():
    from os import devnull
    environment_0 = Environment(devnull = open(devnull, 'w+'))
    assert environment_0
    print (environment_0)
    assert environment_0.devnull
    assert environment_0.is_windows
    assert environment_0.config_dir
    assert environment_0.stdin
    assert environment_0.stdin_isatty
    assert environment_0.stdin_encoding
    assert environment_0.stdout
    assert environment_0.stdout_isatty
    assert environment_0.stdout_encoding
    assert environment_0.stderr
    assert environment_0.stderr_isatty
    assert environment_0.colors
    assert environment_0.program_name
    assert environment_0.config
    assert environment_0._config
   

# Generated at 2022-06-25 18:25:14.098532
# Unit test for constructor of class Environment
def test_Environment():

    # Test case when stdin is not a tty
    stdin1 = io.StringIO('ABCD')
    stdout1 = io.StringIO()
    environment1 = Environment(stdin = stdin1, stdout=stdout1, stdin_isatty=False)
    assert environment1.stdin_isatty is False

    # Test case when stdin is a tty
    stdin2 = io.StringIO('ABCD')
    stdout2 = io.StringIO()
    environment2 = Environment(stdin = stdin2, stdout=stdout2, stdin_isatty=True)
    assert environment2.stdin_isatty is True


# Generated at 2022-06-25 18:25:21.071806
# Unit test for constructor of class Environment
def test_Environment():
    assert (Environment().is_windows == os.name == 'nt')
    assert (Environment().config_dir == Path(DEFAULT_CONFIG_DIR))
    assert (Environment().stdin == sys.stdin)
    assert (Environment().stdout == sys.stdout)
    assert (Environment().stderr == sys.stderr)
    assert (Environment().program_name == 'http')
    assert (Environment().is_windows == is_windows)



# Generated at 2022-06-25 18:25:28.136474
# Unit test for constructor of class Environment
def test_Environment():
    
    #Creating the object with passing stdin, stdout, stderr, is_windows, config_dir
    #stdin_isatty, stdin_encoding, stdout_isatty, stdout_encoding, stderr_isatty, colors
    #program_name, _devnull
    env = Environment(stdin = 123, stdout = 123, stderr = 123, is_windows = True, config_dir = 123, stdin_isatty = 123, stdin_encoding = 123, stdout_isatty = 123, stdout_encoding = 123, stderr_isatty = 123, colors = 123, program_name = 'http', _devnull = True )

    # Checking object should not be None
    assert env is not None

    # Checking attribute stdin is not None
    assert env