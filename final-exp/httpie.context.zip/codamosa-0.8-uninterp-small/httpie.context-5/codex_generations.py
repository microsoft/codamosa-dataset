

# Generated at 2022-06-25 18:15:47.785368
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin == sys.stdin
    if environment.stdin:
        assert environment.stdin_isatty == sys.stdin.isatty()
    else:
        assert environment.stdin_isatty == False
    assert environment.stdin_encoding == None
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == sys.stdout.isatty()
    assert environment.stdout_encoding == None
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == sys.stderr.isatty()
    assert environment.colors == 256

# Generated at 2022-06-25 18:15:55.157417
# Unit test for constructor of class Environment
def test_Environment():
  environment_0 = Environment()
  assert environment_0.is_windows == is_windows
  assert environment_0.config_dir == DEFAULT_CONFIG_DIR
  assert environment_0.stdin == sys.stdin 
  assert environment_0.stdout == sys.stdout
  assert environment_0.stderr == sys.stderr
  assert environment_0.colors == 256
  assert environment_0.program_name == 'http'
  

# Generated at 2022-06-25 18:16:00.335222
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows == is_windows
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == sys.stdin.isatty()
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == sys.stdout.isatty()
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == sys.stderr.isatty()
    assert environment.colors == 256
    assert environment.program_name == 'http'

# Generated at 2022-06-25 18:16:06.116916
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(colors = 8)
    assert env.colors == 8
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr


# Generated at 2022-06-25 18:16:15.286789
# Unit test for constructor of class Environment
def test_Environment():
    assert environment_0 == Environment()
    assert environment_0.stderr is sys.stderr
    assert environment_0.stderr_isatty is True
    assert environment_0.stderr_encoding == 'utf-8'
    assert environment_0.stdout is sys.stdout
    assert environment_0.stdout_isatty is True
    assert environment_0.stdout_encoding == 'utf-8'
    assert environment_0.stdin is sys.stdin
    assert environment_0.stdin_isatty is True
    assert environment_0.stdin_encoding == 'utf-8'
    assert environment_0.colors == 256
    assert environment_0.program_name == 'http'

# Generated at 2022-06-25 18:16:19.007566
# Unit test for constructor of class Environment
def test_Environment():
    stdin = sys.stdin
    stdout = sys.stdout
    stderr = sys.stderr
    environment = Environment(stdin=stdin, stdout=stdout, stderr=stderr)
    environment.stdin is stdin
    environment.stdout is stdout
    environment.stderr is stderr


# Generated at 2022-06-25 18:16:30.887583
# Unit test for constructor of class Environment
def test_Environment():
    """
    This is a test for the constructor of class Environment.
    """
    environment = Environment()
    assert environment.is_windows == False
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.devnull == None
    assert environment.is_windows == False
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == True
    assert environment.stdin_encoding == 'UTF-8'
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == True
    assert environment.stdout_encoding == 'UTF-8'
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == True
    assert environment.colors == 256

# Generated at 2022-06-25 18:16:40.971227
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin == sys.stdin
    assert environment.stdout == sys.stdout
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == sys.stderr.isatty()
    assert environment.stdout_encoding == sys.stdout.encoding
    assert environment.stderr_encoding == sys.stderr.encoding

    if not is_windows:
        if curses:
            try:
                curses.setupterm()
                colors = curses.tigetnum('colors')
            except curses.error:
                pass

# Generated at 2022-06-25 18:16:51.795303
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment(stdout='stdout', stderr='stderr')
    assert environment_0.stdin == None
    assert environment_0.stdin_isatty == False
    assert environment_0.stdin_encoding == None
    assert environment_0.stdout == 'stdout'
    assert environment_0.stdout_isatty == False
    assert environment_0.stdout_encoding == None
    assert environment_0.stderr == 'stderr'
    assert environment_0.stderr_isatty == False
    assert environment_0.colors == 256
    assert environment_0.program_name == 'http'
    assert environment_0.config_dir == DEFAULT_CONFIG_DIR
    assert environment_0.is_windows == is_windows
    assert environment_0

# Generated at 2022-06-25 18:16:58.415043
# Unit test for constructor of class Environment
def test_Environment():
    import os
    import sys
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_CONFIG_DIR
    from typing import IO, Optional

    # Test environment_0
    environment_0 = Environment(devnull=None,
                                is_windows=is_windows,
                                config_dir=DEFAULT_CONFIG_DIR,
                                stdin=sys.stdin,
                                stdin_isatty=True,
                                stdin_encoding=None,
                                stdout=sys.stdout,
                                stdout_isatty=True,
                                stdout_encoding=None,
                                stderr=sys.stderr,
                                stderr_isatty=True,
                                colors=256,
                                program_name='http')


# Generated at 2022-06-25 18:17:13.590198
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert isinstance(env.__dict__, dict)
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == (getattr(
        sys.stdin, 'encoding', None) or 'utf8')
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == (getattr(
        sys.stdout, 'encoding', None) or 'utf8')
    assert env.stderr == sys.stderr
    assert env.st

# Generated at 2022-06-25 18:17:14.517897
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment()


# Generated at 2022-06-25 18:17:21.152569
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows is False
    assert str(environment.config_dir) is "~/.httpie"
    assert environment.stdin is sys.stdin
    assert environment.stdin_isatty is True
    assert environment.stdin_encoding is "utf8"
    assert environment.stdout is sys.stdout
    assert environment.stdout_isatty is True
    assert environment.stdout_encoding is "utf8"
    assert environment.stderr is sys.stderr
    assert environment.stderr_isatty is True
    assert environment.colors is 256
    assert environment.program_name == "http"

# Generated at 2022-06-25 18:17:22.184634
# Unit test for constructor of class Environment

# Generated at 2022-06-25 18:17:32.584461
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows == False
    assert environment.config_dir == Path(os.path.join(os.path.expanduser('~'), '.httpie'))
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == False
    assert environment.stdin_encoding == None
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == True
    assert environment.stdout_encoding == 'utf8'
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == True
    assert environment.colors == 256
    assert environment.program_name == 'http'
    assert environment._orig_stderr == sys.stderr
    assert environment._devnull == None


# Generated at 2022-06-25 18:17:33.722534
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    print(environment_0)

test_Environment()

# Generated at 2022-06-25 18:17:36.818390
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert isinstance(env, Environment)

# Generated at 2022-06-25 18:17:46.450806
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().is_windows == is_windows()
    assert Environment().config_dir == Path(DEFAULT_CONFIG_DIR)
    assert Environment().stdin == sys.stdin
    assert Environment().stdin_isatty == sys.stdin.isatty()
    assert Environment().stdin_encoding == None
    assert Environment().stdout == sys.stdout
    assert Environment().stdout_isatty == sys.stdout.isatty()
    assert Environment().stdout_encoding == None
    assert Environment().stderr == sys.stderr
    assert Environment().stderr_isatty == sys.stderr.isatty()
    assert Environment().colors == 256
    assert Environment().program_name == 'http'

    # Turn off colorama

# Generated at 2022-06-25 18:17:47.637668
# Unit test for constructor of class Environment
def test_Environment():
    text = 'stdout_encoding'
    assert environment_0.stdout_encoding == text

# Generated at 2022-06-25 18:17:57.020395
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()

# Generated at 2022-06-25 18:18:12.848019
# Unit test for constructor of class Environment
def test_Environment():
    assert type(Environment()) == Environment
    assert type(Environment(stdin=sys.stdin)) == Environment
    assert type(Environment(stdout=sys.stdout)) == Environment
    assert type(Environment(stderr=sys.stderr)) == Environment
    assert type(Environment(is_windows=is_windows)) == Environment
    assert type(Environment(config_dir=DEFAULT_CONFIG_DIR)) == Environment
    assert type(Environment(stdin_isatty=sys.stdin.isatty())) == Environment
    assert type(Environment(stdin_encoding='utf8')) == Environment
    assert type(Environment(stdout_isatty=sys.stdout.isatty())) == Environment
    assert type(Environment(stdout_encoding='utf8')) == Environment

# Generated at 2022-06-25 18:18:23.814682
# Unit test for constructor of class Environment

# Generated at 2022-06-25 18:18:25.342906
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()
# test case end.



# Generated at 2022-06-25 18:18:32.996373
# Unit test for constructor of class Environment
def test_Environment():
    from pathlib import Path
    from httpie.config import Config
    from httpie.config import ConfigFileError
    from httpie.utils import version
    from httpie import ExitStatus

    config = Config(directory=DEFAULT_CONFIG_DIR)
    config_format = "httpie.generated.conf"  # format of config file
    config_file = os.path.join(DEFAULT_CONFIG_DIR, config_format)

    environment1 = Environment()
    assert environment1.is_windows == False
    assert environment1.config_dir == Path(DEFAULT_CONFIG_DIR)
    assert environment1.stdin == sys.stdin
    assert environment1.stdin_isatty == True
    assert environment1.stdin_encoding == "utf8"
    assert environment1.stdout == sys.stdout
   

# Generated at 2022-06-25 18:18:43.675987
# Unit test for constructor of class Environment
def test_Environment():
    arg = Environment()
    assert arg.is_windows == is_windows
    assert arg.config_dir == DEFAULT_CONFIG_DIR
    assert arg.stdin == sys.stdin
    assert arg.stdin_isatty is True
    assert arg.stdin_encoding == "utf8"
    assert arg.stdout == sys.stdout
    assert arg.stdout_isatty is True
    assert arg.stdout_encoding == "utf8"
    assert arg.stderr == sys.stderr
    assert arg.colors == 256
    assert arg.program_name == 'http'
    assert arg._orig_stderr == sys.stderr
    assert arg._devnull is None
    assert arg._config is None

# Generated at 2022-06-25 18:18:48.619833
# Unit test for constructor of class Environment
def test_Environment():
    try:
        sys.stdin = open('/dev/null', 'r')
        environment_0 = Environment()
        assert environment_0.stdin_isatty is False
        assert environment_0.stdout_isatty is True
        assert environment_0.stderr_isatty is True
    finally:
        sys.stdin = open(os.ttyname(sys.stdin.fileno()), 'r')
    print(environment_0)


# Generated at 2022-06-25 18:18:55.712088
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdout=sys.stdout)
    assert repr(env) == "Environment(stdout=sys.stdout)"
    assert str(env) == "{'stdout': <_io.TextIOWrapper name='<stdout>' mode='w' encoding='cp936'>"
    env = Environment(stdout=sys.stdout, stderr=sys.stderr, stdin=sys.stdin)
    assert env.stderr == sys.stderr
    assert env.stdout == sys.stdout

# Test devnull property of class Environment

# Generated at 2022-06-25 18:18:57.854503
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.stdout == sys.stdout
    assert env.is_windows == is_windows


# Generated at 2022-06-25 18:19:02.077665
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert isinstance(environment_0, Environment)
    assert 'stdin' in environment_0.__dict__
    assert 'stdout' in environment_0.__dict__
    assert 'stderr' in environment_0.__dict__


# Generated at 2022-06-25 18:19:03.568949
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0


# Generated at 2022-06-25 18:19:14.632441
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=False, config_dir=Path(os.getcwd()), stdin=sys.stdin, stdin_isatty=False, stdin_encoding=None, stdout=sys.stdout, stdout_isatty=True, stdout_encoding=None, stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http')
    print(type(env))

test_case_0()
test_Environment()

# Generated at 2022-06-25 18:19:25.118802
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()

    # Test the values of all class attributes
    assert environment_0.is_windows == is_windows
    assert environment_0.config_dir == DEFAULT_CONFIG_DIR
    assert environment_0.stdin == sys.stdin
    assert environment_0.stdin_isatty == (environment_0.stdin.isatty() if environment_0.stdin else False)
    assert environment_0.stdout == sys.stdout
    assert environment_0.stdout_isatty == environment_0.stdout.isatty()
    assert environment_0.stderr == sys.stderr
    assert environment_0.stderr_isatty == environment_0.stderr.isatty()
    assert environment_0.colors == 256

# Generated at 2022-06-25 18:19:35.459690
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()

# Generated at 2022-06-25 18:19:37.426234
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0 is not None

if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-25 18:19:41.941072
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(
        is_windows=True,
        stdin=None,
        stdin_encoding=None,
        stdout=sys.stdout,
        stdout_encoding=None,
        stderr=sys.stderr,
        stderr_isatty=True,
        config_dir=DEFAULT_CONFIG_DIR,
        program_name='http',
    )

# Generated at 2022-06-25 18:19:52.948667
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    environment1 = Environment(is_windows=False)
    environment2 = Environment(config_dir="/Users/linrongbin/httpie/httpie/config.py")
    environment3 = Environment(stdin=sys.stdin)
    environment4 = Environment(stdin_isatty=False)
    environment5 = Environment(stdin_encoding="utf8")
    environment6 = Environment(stdout=sys.stdout)
    environment7 = Environment(stdout_isatty=False)
    environment8 = Environment(stdout_encoding="utf8")
    environment9 = Environment(stderr=sys.stderr)
    environment10 = Environment(stderr_isatty=False)
    environment11 = Environment(colors=256)
    environment12 = Environment(program_name="http")

# Generated at 2022-06-25 18:20:01.080894
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()
    assert environment_1.is_windows == environment_0.is_windows
    assert environment_1.config_dir == environment_0.config_dir
    assert environment_1.stdin == environment_0.stdin
    assert environment_1.stdin_isatty == environment_0.stdin_isatty
    assert environment_1.stdin_encoding == environment_0.stdin_encoding
    assert environment_1.stdout == environment_0.stdout
    assert environment_1.stdout_isatty == environment_0.stdout_isatty
    assert environment_1.stdout_encoding == environment_0.stdout_encoding
    assert environment_1.stderr == environment_0.stderr
    assert environment_1.stderr_isatty

# Generated at 2022-06-25 18:20:12.470659
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()

    assert environment_0.is_windows == is_windows
    assert environment_0.config_dir == DEFAULT_CONFIG_DIR
    assert environment_0.stdin == sys.stdin
    assert environment_0.stdin_isatty == sys.stdin.isatty()
    assert environment_0.stdin_encoding == None
    assert environment_0.stdout == sys.stdout
    assert environment_0.stdout_isatty == sys.stdout.isatty()
    assert environment_0.stdout_encoding == None
    assert environment_0.stderr == sys.stderr
    assert environment_0.stderr_isatty == sys.stderr.isatty()
    assert environment_0.colors == 256
    assert environment_0

# Generated at 2022-06-25 18:20:22.509505
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()
    print(environment_1.config_dir)
    print(environment_1.stdin)
    print(environment_1.stdout)
    print(environment_1.stderr)
    print(environment_1.stdout_encoding)
    print(environment_1.stderr_encoding)
    print(environment_1.stdin_encoding)
    print(environment_1.stdin_isatty)
    print(environment_1.stdout_isatty)
    print(environment_1.stderr_isatty)
    print(environment_1.colors)
    print(environment_1.program_name)
    print(environment_1.is_windows)
    print(environment_1.config)
    print(environment_1.devnull)


# Generated at 2022-06-25 18:20:33.711387
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.is_windows == True
    assert environment_0.config_dir == DEFAULT_CONFIG_DIR
    assert environment_0.stdin == sys.stdin
    assert environment_0.stdin_isatty == True
    assert environment_0.stdin_encoding == 'utf-8'
    assert environment_0.stdout == sys.stdout
    assert environment_0.stdout_isatty == True
    assert environment_0.stdout_encoding == 'utf-8'
    assert environment_0.stderr == sys.stderr
    assert environment_0.stderr_isatty == True
    assert environment_0.colors == 256
    assert environment_0.program_name == 'http'


# Generated at 2022-06-25 18:20:44.232214
# Unit test for constructor of class Environment
def test_Environment():
    assert isinstance(Environment(), Environment)

# Generated at 2022-06-25 18:20:54.023880
# Unit test for constructor of class Environment
def test_Environment():
    from httpie.plugins import AuthPlugin, Plugin
    env = Environment(stdin=True,
                      stdout=True,
                      stderr=True,
                      program_name=Plugin.name,
                      stdin_encoding=AuthPlugin.raw_auth.encoding,
                      stdin_isatty=AuthPlugin.raw_auth.isatty(),
                      stdout_isatty="",
                      stdout_encoding=Plugin.output_stream.encoding,
                      stderr_isatty=False
                      )
    assert env.stdin_isatty is True
    assert env.stdout_isatty is True
    assert env.stderr_isatty is False
    # print(env)


    # print(env.config_dir)
    # print(env.stdin)
    # print

# Generated at 2022-06-25 18:21:01.442830
# Unit test for constructor of class Environment
def test_Environment():
    assert not Environment.is_windows
    assert Environment.config_dir == '/Users/dmli25/.config/httpie'
    assert Environment.stdin is sys.stdin
    assert Environment.stdin_isatty
    assert Environment.stdout is sys.stdout
    assert Environment.stdout_isatty is True
    assert Environment.stderr is sys.stderr
    assert Environment.stderr_isatty is True
    assert Environment.colors is 256
    assert Environment.program_name == 'http'


# Generated at 2022-06-25 18:21:10.859164
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == env.stdin.isatty()
    if env.stdin:
        assert env.stdin_encoding == env.stdin.encoding
    else:
        assert env.stdin_encoding is None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == env.stdout.isatty()
    assert env.stdout_encoding == env.stdout.encoding
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == env.stderr.isatty()
    #

# Generated at 2022-06-25 18:21:22.475747
# Unit test for constructor of class Environment
def test_Environment():
    new_env = Environment(
        is_windows=False,
        config_dir=DEFAULT_CONFIG_DIR,
        stdin=None,
        stdin_isatty=True,
        stdin_encoding=None,
        stdout=sys.stdout,
        stdout_isatty=True,
        stdout_encoding=None,
        stderr=sys.stderr,
        stderr_isatty=True,
        colors=0,
        program_name='http',
        _devnull=None,
        _orig_stderr=sys.stderr,
        _config=None
    )
    assert new_env.is_windows == False
    assert new_env.config_dir == DEFAULT_CONFIG_DIR
    assert new_env.stdin == None

# Generated at 2022-06-25 18:21:31.745282
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(
        is_windows=True,
        config_dir='/some/where',
        stdin='I am the stdin',
        stdin_isatty=False,
        stdin_encoding='utf8',
        stdout='I am the stdout',
        stdout_isatty=True,
        stderr='I am the stderr',
        stderr_isatty=True,
        colors=256,
        program_name='http'
    )
    assert environment_1._orig_stderr == 'I am the stderr'
    assert environment_1.stderr == 'I am the stderr'
    assert environment_1.is_windows == True
    assert environment_1.config_dir == Path('/some/where')
    assert environment_1

# Generated at 2022-06-25 18:21:43.232381
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(
        is_windows = False,
        config_dir = 'D:/httpie',
        stdin = sys.stdin,
        stdin_isatty = sys.stdin.isatty(),
        stdin_encoding = 'utf8',
        stdout = sys.stdout,
        stdout_isatty = sys.stdout.isatty(),
        stdout_encoding = 'utf8',
        stderr = sys.stderr,
        stderr_isatty = sys.stderr.isatty(),
        colors = 256,
        program_name = 'http',
        _config = Config(directory='D:/httpie'),
        _devnull = os.devnull,
        _orig_stderr = sys.stderr,
    )
    assert environment

# Generated at 2022-06-25 18:21:46.949519
# Unit test for constructor of class Environment
def test_Environment():
    assert test_case_0() == None

# Generated at 2022-06-25 18:21:47.831552
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment()
    pass


# Generated at 2022-06-25 18:21:52.175754
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()  # checks if class Environment can be instatiated

    # check if stdin_encoding is set by default to utf8
    assert type(env.stdin_encoding) == str
    assert env.stdin_encoding == 'utf8'
    assert type(env.stdout_encoding) == str
    assert env.stdout_encoding == 'utf8'

# Generated at 2022-06-25 18:22:10.183830
# Unit test for constructor of class Environment
def test_Environment():
    from httpie.compat import str_type
    stdin = sys.stdin
    stdin_isatty = stdin.isatty() if stdin else False
    stdin_encoding = getattr(stdin, 'encoding', None) or 'utf8'
    stdout = sys.stdout
    stdout_isatty = stdout.isatty()
    stdout_encoding = getattr(stdout, 'encoding', None) or 'utf8'
    stderr = sys.stderr
    stderr_isatty = stderr.isatty()
    colors = 256
    if curses:
        try:
            curses.setupterm()
            colors = curses.tigetnum('colors')
        except curses.error:
            pass

# Generated at 2022-06-25 18:22:11.884515
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert isinstance(environment, Environment)

# Generated at 2022-06-25 18:22:22.899322
# Unit test for constructor of class Environment
def test_Environment():
    environment_test = Environment(
        devnull=None,
        is_windows=is_windows,
        config_dir=DEFAULT_CONFIG_DIR,
        stdin=sys.stdin,
        stdin_isatty=sys.stdin,
        stdin_encoding=None,
        stdout=sys.stdout,
        stdout_isatty=sys.stdout,
        stdout_encoding=None,
        stderr=sys.stderr,
        stderr_isatty=sys.stderr,
        colors=256,
        program_name='http'
    )
    assert environment_test.devnull == None
    assert environment_test.is_windows == is_windows
    assert environment_test.config_dir == DEFAULT_CONFIG_DIR
    assert environment_

# Generated at 2022-06-25 18:22:28.425064
# Unit test for constructor of class Environment
def test_Environment():
    new_env=Environment()
    assert new_env.is_windows==new_env.is_windows
    assert new_env.config_dir== new_env.config_dir
    assert new_env.stdin == new_env.stdin
    assert new_env.stdin_isatty == new_env.stdin_isatty
    assert new_env.stdout_isatty == new_env.stdout_isatty
    assert new_env.stderr_isatty == new_env.stderr_isatty
    #assert new_env.colors == new_env.colors
    assert new_env.program_name == new_env.program_name


# Generated at 2022-06-25 18:22:32.102828
# Unit test for constructor of class Environment
def test_Environment():
    assert hasattr(Environment(), 'config')
    assert hasattr(Environment(), 'stderr')
    assert hasattr(Environment(), 'stdout')
    assert hasattr(Environment(), 'stdin')



# Generated at 2022-06-25 18:22:39.040484
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment()
    assert isinstance(e, Environment)
    assert isinstance(e.stdin, IO)
    assert isinstance(e.stdout, IO)
    assert isinstance(e.stderr, IO)
    assert isinstance(e.stdin_isatty, bool)
    assert isinstance(e.stdout_isatty, bool)
    assert isinstance(e.stderr_isatty, bool)
    assert isinstance(e.stdin_encoding, str)
    assert isinstance(e.stdout_encoding, str)
    assert isinstance(e.colors, int)
    assert isinstance(e.program_name, str)
    assert isinstance(e.config_dir, Path)
    assert isinstance(e.config, Config)
    assert e.stder

# Generated at 2022-06-25 18:22:49.747083
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()
    environment_2 = Environment(devnull="this is devnull")
    environment_3 = Environment(config_dir="this is config_dir")
    environment_4 = Environment(stdin="this is stdin")
    environment_5 = Environment(stdin_isatty="this is stdin_isatty")
    environment_6 = Environment(stdin_encoding="this is stdin_encoding")
    environment_7 = Environment(stdout="this is stdout")
    environment_8 = Environment(stdout_isatty="this is stdout_isatty")
    environment_9 = Environment(stdout_encoding="this is stdout_encoding")
    environment_10 = Environment(stderr="this is stderr")

# Generated at 2022-06-25 18:23:01.294380
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.is_windows == False
    assert environment_0.config_dir == Path.home() / '.config' / 'httpie'
    assert environment_0.stderr == sys.stderr
    assert environment_0.stdin == sys.stdin
    assert environment_0.stdin_isatty == True
    assert environment_0.stdin_encoding == 'utf8'
    assert environment_0.stdout == sys.stdout
    assert environment_0.stdout_isatty == True
    assert environment_0.stdout_encoding == 'utf8'
    assert environment_0.stderr_isatty == True
    assert environment_0.stderr_isatty == True
    assert environment_0.colors == 256
    assert environment_

# Generated at 2022-06-25 18:23:08.475840
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert not environment_0.is_windows
    assert environment_0.config_dir == DEFAULT_CONFIG_DIR
    assert environment_0.stdin == sys.stdin
    assert environment_0.stdin_isatty
    assert environment_0.stdin_encoding == 'utf8'
    assert environment_0.stdout == sys.stdout
    assert environment_0.stdout_isatty
    assert environment_0.stdout_encoding == 'utf8'
    assert environment_0.stderr == sys.stderr
    assert environment_0.stderr_isatty
    assert environment_0.colors == 256
    assert environment_0.program_name == 'http'


# Generated at 2022-06-25 18:23:18.784042
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(devnull=1)
    assert environment_1.devnull == 1
    environment_2 = Environment(devnull=1, is_windows=1, config_dir=1, stdin=1, stdin_isatty=1, stdin_encoding=1, stdout=1,
                                stdout_isatty=1, stdout_encoding=1, stderr=1, stderr_isatty=1, colors=1,
                                program_name=1)
    assert environment_2.devnull == 1
    assert environment_2.is_windows == 1
    assert environment_2.config_dir == 1
    assert environment_2.stdin == 1
    assert environment_2.stdin_isatty == 1
    assert environment_2.stdin_encoding == 1

# Generated at 2022-06-25 18:23:42.662940
# Unit test for constructor of class Environment
def test_Environment():
    global_env = Environment()
    assert global_env.is_windows == is_windows
    assert global_env.stdout_isatty == True
    assert global_env.stdout_isatty == isinstance(global_env.stdout,IO)
    assert global_env.stdin_encoding == "utf-8"
    local_env = Environment(stdin_encoding="cp737")
    assert local_env.stdin_encoding == "cp737"
    assert global_env.stdout_isatty == isinstance(global_env.stdout,IO)
    assert global_env.stdin_encoding == "utf-8"

# Generated at 2022-06-25 18:23:49.103388
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(stderr_isatty=True)
    assert environment_1.stderr_isatty
    environment_2 = Environment(stderr_isatty=True, stderr=None)
    assert environment_2.stderr_isatty
    assert environment_2.stderr == None


# Generated at 2022-06-25 18:23:57.887187
# Unit test for constructor of class Environment
def test_Environment():
    from io import TextIOWrapper
    environment_0 = Environment()
    assert (isinstance(environment_0.stdin,TextIOWrapper))
    assert (isinstance(environment_0.stdout,TextIOWrapper))
    assert (isinstance(environment_0.stderr,TextIOWrapper))
    assert (((type(environment_0.stdin) == type(sys.stdin)) and (type(environment_0.stderr) == type(sys.stderr)) and (type(environment_0.stdout) == type(sys.stdout))) == True)


# Generated at 2022-06-25 18:24:00.037918
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert len(environment_0.__dict__) == 19
    assert not os.path.exists('./config')

# Generated at 2022-06-25 18:24:09.091103
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(is_windows=False, config_dir='/etc/httpie/config.json', stdin='stdin', stdin_isatty=True, stdin_encoding='utf8', stdout='stdout', stdout_isatty=True, stdout_encoding='utf8', stderr='stderr', stderr_isatty=True, colors=256, program_name='http')
    assert environment.is_windows == False
    assert environment.config_dir == '/etc/httpie/config.json'
    assert environment.stdin == 'stdin'
    assert environment.stdin_isatty == True
    assert environment.stdin_encoding == 'utf8'
    assert environment.stdout == 'stdout'
    assert environment.stdout_isatty == True
    assert environment

# Generated at 2022-06-25 18:24:15.089483
# Unit test for constructor of class Environment
def test_Environment():
    # Testing default constructor
    env = Environment()
    assert isinstance(env, Environment)
    assert env.is_windows is True
    assert env.config_dir == Path(DEFAULT_CONFIG_DIR)
    assert env.stdin is sys.stdin  # `None` when closed fd (#791)
    assert env.stdin_isatty is True
    assert env.stdin_encoding == 'UTF-8'
    assert env.stdout is sys.stdout
    assert env.stdout_isatty is True
    assert env.stdout_encoding == 'UTF-8'
    assert env.stderr is sys.stderr
    assert env.stderr_isatty is True
    assert env.colors == 256
    assert env.program_name == 'http'

    # Testing parameter

# Generated at 2022-06-25 18:24:15.958780
# Unit test for constructor of class Environment
def test_Environment():
    print('*** test_Environment() ***')
    test_case_0()


# Generated at 2022-06-25 18:24:22.287809
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=False, config_dir='~/.config/httpie',
                      stdin=sys.stdin, stdin_isatty=sys.stdin.isatty(), stdin_encoding='utf8',
                      stdout=sys.stdout, stdout_isatty=sys.stdout.isatty(), stdout_encoding='utf8',
                      stderr=sys.stderr, stderr_isatty=sys.stderr.isatty(), colors=256,
                      program_name='http')
    print(type(env))
    print(type(env.stdin))
    print(type(env.config))
    assert isinstance(env, Environment) == True


# Generated at 2022-06-25 18:24:23.716387
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()
    test_case_1()



# Generated at 2022-06-25 18:24:32.447677
# Unit test for constructor of class Environment
def test_Environment():
    # Case 1
    environment_0 = Environment()

    # Case 2
    environment_1 = Environment(is_windows = True)

    # Case 3
    environment_2 = Environment(colors = 0)

    # Case 4
    environment_3 = Environment(program_name = "http")

    # Case 5
    environment_4 = Environment(devnull = "http")

    # Case 6
    environment_5 = Environment(config_dir = "/usr/bin/http", stdin_isatty = True, stdin_encoding = "utf-8", stdout_isatty = True, stdout_encoding = "utf-8", stderr_isatty = True)

    # Case 7

# Generated at 2022-06-25 18:25:08.951428
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().config_dir == DEFAULT_CONFIG_DIR
    assert Environment().stdin == sys.stdin
    assert Environment().stdout == sys.stdout
    assert Environment().stderr == sys.stderr


if __name__ == "__main__":
    test_case_0()
    test_Environment()

# Generated at 2022-06-25 18:25:16.874030
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    # Test `config_dir`
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    # Test `is_windows`
    assert isinstance(environment.is_windows, bool)
    # Test `stdin`
    assert environment.stdin is sys.stdin
    # Test `stdin_isatty`
    assert environment.stdin_isatty == environment.stdin.isatty() if environment.stdin else False
    # Test `stdin_encoding`
    assert environment.stdin_encoding is None
    # Test `stdout`
    assert environment.stdout is sys.stdout
    # Test `stdout_isatty`
    assert environment.stdout_isatty == environment.stdout.isatty()
    # Test `stdout_encoding

# Generated at 2022-06-25 18:25:26.505876
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty() if sys.stdin else False
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'

# Generated at 2022-06-25 18:25:37.677786
# Unit test for constructor of class Environment
def test_Environment():
    assert is_windows == environment_0.is_windows
    assert DEFAULT_CONFIG_DIR == environment_0.config_dir
    assert stdin == environment_0.stdin  # `None` when closed fd (#791)
    assert stdin_isatty == environment_0.stdin_isatty if stdin else False
    assert stdin_encoding == environment_0.stdin_encoding
    assert stdout == environment_0.stdout
    assert stdout_isatty == environment_0.stdout_isatty
    assert stdout_encoding == environment_0.stdout_encoding
    assert stderr == environment_0.stderr
    assert stderr_isatty == environment_0.stderr_isatty
    assert colors == environment_0.colors