

# Generated at 2022-06-25 18:15:46.971033
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows == is_windows
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin is sys.stdin
    assert environment.stdin_isatty == environment.stdin.isatty() if environment.stdin else False
    assert environment.stdin_encoding == None
    assert environment.stdout is sys.stdout
    assert environment.stdout_isatty == environment.stdout.isatty()
    assert environment.stdout_encoding == None
    assert environment.stderr is sys.stderr
    assert environment.stderr_isatty == environment.stderr.isatty()
    assert environment.program_name == 'http'
    assert environment.colors == 256
    print("test_Environment successful")



# Generated at 2022-06-25 18:15:50.348240
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.program_name == 'http'
    assert environment_0.stdin is sys.stdin
    assert environment_0.is_windows == is_windows

# Generated at 2022-06-25 18:15:59.599525
# Unit test for constructor of class Environment

# Generated at 2022-06-25 18:16:10.812626
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(devnull='httpie')
    assert environment.is_windows == True
    assert environment.config_dir == Path('C:\\Users\\admin\\.config\\httpie')
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == True
    assert environment.stdin_encoding == 'utf8'
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == True
    assert environment.stdout_encoding == 'utf8'
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == True
    assert environment.colors == 256
    assert environment.program_name == 'http'


# Generated at 2022-06-25 18:16:11.818516
# Unit test for constructor of class Environment
def test_Environment():
    assert test_case_0() == None

# Generated at 2022-06-25 18:16:19.335071
# Unit test for constructor of class Environment
def test_Environment():
    # The actual execution context.
    environment_1 = Environment()
    assert environment_1.is_windows == is_windows
    assert environment_1.config_dir == DEFAULT_CONFIG_DIR
    assert environment_1.stdin == sys.stdin
    assert environment_1.stdin_isatty == sys.stdin.isatty()
    assert environment_1.stdout == sys.stdout
    assert environment_1.stdout_isatty == sys.stdout.isatty()
    assert environment_1.stderr == sys.stderr
    assert environment_1.stderr_isatty == sys.stderr.isatty()
    assert environment_1.program_name == 'http'

# Generated at 2022-06-25 18:16:31.618623
# Unit test for constructor of class Environment
def test_Environment():
    # Environment instance
    env = Environment(is_windows=True)
    assert env.is_windows == True
    assert env.stdin == sys.stdin
    assert env.stdin.isatty() == sys.stdin.isatty()
    assert env.stdout == sys.stdout
    assert env.stdout.isatty() == sys.stdout.isatty()
    assert env.stderr == sys.stderr
    assert env.stderr.isatty() == sys.stderr.isatty()
    assert env.colors == 256

    # config_dir
    env = Environment(config_dir = '/config')
    assert env.config_dir == '/config'

    # stdin
    env = Environment(stdin = 3)
    assert env.stdin == 3
   

# Generated at 2022-06-25 18:16:42.644495
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    if env.is_windows:
        assert not sys.__stdout__
        assert env.config_dir == DEFAULT_CONFIG_DIR
        assert env.stdin is not None
        assert env.stdin_isatty is True
        assert env.stdin_encoding == 'utf-8'
        assert env.stdout is not None
        assert env.stdout_isatty is True
        assert env.stdout_encoding == 'cp936'
        assert env.stderr_isatty is True
        assert env.stderr_encoding == 'cp936'
        assert env.colors == 256
        assert env.program_name == 'http'
        assert env._orig_stderr is not None
        assert env._devnull is not None



# Generated at 2022-06-25 18:16:47.183762
# Unit test for constructor of class Environment
def test_Environment():
    if sys.stdin.isatty():
        stdin = sys.stdin
    else:
        stdin = None
    devnull = open(os.devnull, 'w+')
    environment_1 = Environment(devnull)
    assert environment_1.stdin == s

# Generated at 2022-06-25 18:16:55.873353
# Unit test for constructor of class Environment
def test_Environment():
    # Create object of class
    environment_0 = Environment()

    # Check if object is instance of class
    assert isinstance(environment_0, Environment)

    # Check every instance variable
    assert isinstance(environment_0.config_dir,Path)
    assert isinstance(environment_0.stdin,IO)
    assert isinstance(environment_0.stdin_isatty,bool)
    assert isinstance(environment_0.stdout,IO)
    assert isinstance(environment_0.stdout_isatty,bool)
    assert isinstance(environment_0.stderr,IO)
    assert isinstance(environment_0.stderr_isatty,bool)
    assert isinstance(environment_0.colors,int)
    assert isinstance(environment_0.program_name,str)
    assert isinstance

# Generated at 2022-06-25 18:17:10.403463
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.colors == 256
    assert environment_0.program_name == 'http'
    assert environment_0.stdout == sys.stdout
    assert environment_0.stdout_isatty == sys.stdout.isatty()
    assert environment_0.stdout_encoding is None

# Generated at 2022-06-25 18:17:19.123312
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert isinstance(environment, Environment)
    assert environment.is_windows == is_windows
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == sys.stdin.isatty()
    assert environment.stdin_encoding == sys.stdin.encoding if sys.stdin.isatty() else None
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == sys.stdout.isatty()
    assert environment.stdout_encoding == sys.stdout.encoding
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == sys.stderr.isatty()
    assert environment._

# Generated at 2022-06-25 18:17:30.586939
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(
            is_windows=1,
            config_dir=Path('test'),
            stdin=None,
            stdin_isatty=1,
            stdin_encoding=None,
            stdout=sys.stdout,
            stdout_isatty=1,
            stdout_encoding=None,
            stderr=sys.stderr,
            stderr_isatty=1,
            colors=1,
            program_name='http_test',
            stdout_actual=sys.stdout,
            stderr_actual=sys.stderr,
            _orig_stderr=sys.stderr,
            _devnull=None,
            )

# Generated at 2022-06-25 18:17:42.034874
# Unit test for constructor of class Environment
def test_Environment():
    environment_1=Environment(is_windows=0,config_dir='' ,stdin=None,stdin_isatty=0,stdin_encoding=None,stdout=None,
                              stdout_isatty=0,stdout_encoding=None,stderr=None,stderr_isatty=0,colors=0,program_name='')
    environment_2 = Environment(stdin_isatty=1, stdin_encoding='utf8',stdout_isatty=0,stdout_encoding='utf-8',stderr_isatty=1,colors=256,program_name='http')
    assert environment_1.is_windows == 0
    assert environment_2.config_dir == ''
    assert environment_1.stdin == None
    assert environment_

# Generated at 2022-06-25 18:17:51.302494
# Unit test for constructor of class Environment
def test_Environment():
    stdin_encoding = "utf8"

    environment = Environment(
        is_windows=True,
        config_dir="~/.httpie",
        stdin=None,
        stdin_isatty=True,
        stdin_encoding=stdin_encoding,
        stdout=None,
        stdout_isatty=True,
        stdout_encoding="utf8",
        stderr=None,
        stderr_isatty=True,
        colors=256,
        program_name="http",
    )

    assert environment.is_windows == True
    assert environment.config_dir == Path.home() / ".httpie"
    assert environment.stdin == None
    assert environment.stdin_isatty == True
    assert environment.stdin_encoding == stdin_enc

# Generated at 2022-06-25 18:17:56.299067
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows == is_windows
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == (sys.stdin is not None)
    assert environment.stdout == sys.stdout
    assert environment.stderr == sys.stderr
    assert environment._devnull is None



# Generated at 2022-06-25 18:17:56.699075
# Unit test for constructor of class Environment
def test_Environment():
    pass

# Generated at 2022-06-25 18:17:59.686315
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    if env.stdout_encoding:
        assert env.stdout_encoding == 'utf8'
    else:
        assert env.stdout_encoding == None


# Generated at 2022-06-25 18:18:10.904620
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment()._devnull is None
    assert Environment()._config is None

# Generated at 2022-06-25 18:18:17.772520
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment(stdin=sys.stdin,
                     stdout=sys.stdout,
                     stderr=sys.stderr,
                     is_windows=is_windows,
                     config_dir=DEFAULT_CONFIG_DIR,
                     stdin_isatty=environment_0.stdin.isatty() if environment_0.stdin else False,
                     stdout_isatty=environment_0.stdout.isatty(),
                     stderr_isatty=environment_0.stderr.isatty(),
                     colors=256,
                     program_name="http")


# Generated at 2022-06-25 18:18:34.003192
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.is_windows == False
    assert environment_0.colors == 256
    assert environment_0.program_name == 'http'
    assert environment_0.stdout_isatty == True
    assert environment_0.stdin_isatty == True
    assert environment_0.stderr_isatty == True
    assert environment_0.stdin_encoding == 'utf8'
    assert environment_0.stdout_encoding == 'utf8'
    assert environment_0._orig_stderr is sys.stderr
if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-25 18:18:45.121911
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.is_windows == True or environment_0.is_windows == False
    assert environment_0.config_dir == DEFAULT_CONFIG_DIR
    print("environment_0.stdin is", environment_0.stdin)
    print("environment_0.stdin is", environment_0.stdin.readable())
    
    print("environment_0.stdin_isatty is", environment_0.stdin_isatty)
    print("environment_0.stdin_encoding is", environment_0.stdin_encoding)
    print("environment_0.stdout is", environment_0.stdout)
    print("environment_0.stdout_isatty is", environment_0.stdout_isatty)

# Generated at 2022-06-25 18:18:53.905178
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert isinstance(environment_0.is_windows, bool)
    assert isinstance(environment_0.config_dir, Path)
    assert isinstance(environment_0.stdin, Optional[IO])
    assert isinstance(environment_0.stdin_isatty, bool)
    assert isinstance(environment_0.stdin_encoding, str)
    assert isinstance(environment_0.stdout, IO)
    assert isinstance(environment_0.stdout_isatty, bool)
    assert isinstance(environment_0.stdout_encoding, str)
    assert isinstance(environment_0.stderr, IO)
    assert isinstance(environment_0.stderr_isatty, bool)
    assert isinstance(environment_0.colors, int)

# Generated at 2022-06-25 18:19:01.989278
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()
    assert environment_1.is_windows == is_windows
    assert environment_1.config_dir == DEFAULT_CONFIG_DIR
    assert environment_1.stdin == sys.stdin  # `None` when closed fd (#791)
    assert environment_1.stdin_isatty == environment_1.stdin.isatty() if environment_1.stdin else False
    assert environment_1.stdin_encoding == None
    assert environment_1.stdout == sys.stdout
    assert environment_1.stdout_isatty == environment_1.stdout.isatty()
    assert environment_1.stdout_encoding == None
    assert environment_1.stderr == sys.stderr
    assert environment_1.stderr_isatty == environment

# Generated at 2022-06-25 18:19:06.288842
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull='hello', is_windows=True, config_dir='/etc')
    assert env.devnull == 'hello'
    assert env.is_windows == True
    assert env.config_dir.match('/etc')


# Generated at 2022-06-25 18:19:10.778881
# Unit test for constructor of class Environment
def test_Environment():
    environ  = Environment()
    assert environ.__class__.__name__ == "Environment"
    assert environ.is_windows == False
    assert str(environ.config_dir) == "C:\\Users\\user\\.httpie"
    assert environ.stdin == sys.stdin

# Generated at 2022-06-25 18:19:14.918554
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment(is_windows=True, config_dir="a", stdin=None, stdout=sys.stdout, stderr=sys.stderr, colors=256, program_name="a", _orig_stderr=sys.stderr, _devnull=None)


# Generated at 2022-06-25 18:19:21.330571
# Unit test for constructor of class Environment
def test_Environment():
    # Constructor with no arguments
    environment_0 = Environment()
    print("environment: \n%s" % environment_0)
    # Constructor with one argument
    environment_1 = Environment(is_windows=os.name=='nt')
    print("environment: \n%s" % environment_1)
    # Constructor with multiple arguments

# Generated at 2022-06-25 18:19:31.574582
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment(
        devnull='/dev/null',
        config_dir='/etc/httpie/',
        stdin_isatty=True,
        stdin_encoding='utf8',
        stdout_encoding='utf8',
        stderr_isatty=True,
        program_name='http'
    ) == Environment(
        devnull='/dev/null',
        config_dir='/etc/httpie/',
        stdin_isatty=True,
        stdin_encoding='utf8',
        stdout_encoding='utf8',
        stderr_isatty=True,
        program_name='http'
    )

# Generated at 2022-06-25 18:19:38.719827
# Unit test for constructor of class Environment
def test_Environment():
    assert hasattr(environment_0, 'is_windows')
    assert hasattr(environment_0, 'config_dir')
    assert hasattr(environment_0, 'stdin')
    assert hasattr(environment_0, 'stdin_isatty')
    assert hasattr(environment_0, 'stdin_encoding')
    assert hasattr(environment_0, 'stdout')
    assert hasattr(environment_0, 'stdout_isatty')
    assert hasattr(environment_0, 'stdout_encoding')
    assert hasattr(environment_0, 'stderr')
    assert hasattr(environment_0, 'stderr_isatty')
    assert hasattr(environment_0, 'colors')
    assert hasattr(environment_0, 'program_name')

# Generated at 2022-06-25 18:20:10.126408
# Unit test for constructor of class Environment
def test_Environment():
    stdin = sys.stdin
    stdin_isatty = stdin.isatty() if stdin else False
    stdin_encoding = getattr(
        stdin, 'encoding', None) or 'utf8'
    stdout = sys.stdout
    stdout_isatty = stdout.isatty()
    stdout_encoding = getattr(
        stdout, 'encoding', None) or 'utf8'
    stderr = sys.stderr
    stderr_isatty = stderr.isatty()
    test_stderr = sys.stdout
    test_stderr_isatty = test_stderr.isatty()
    test_stderr_encoding = getattr(
        test_stderr, 'encoding', None)

# Generated at 2022-06-25 18:20:11.038071
# Unit test for constructor of class Environment
def test_Environment():
    assert True


# Generated at 2022-06-25 18:20:12.330057
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()

# Generated at 2022-06-25 18:20:19.424508
# Unit test for constructor of class Environment
def test_Environment():
    defaults = dict(type(environment).__dict__)
    actual = dict(defaults)
    actual.update(environment.__dict__)
    actual['config'] = environment.config
    print(repr_dict({
        key: value
        for key, value in actual.items()
        if not key.startswith('_')
    }))


environment: Environment = Environment()

if __name__ == '__main__':
    test_case_0()
    test_Environment()

# Generated at 2022-06-25 18:20:23.829077
# Unit test for constructor of class Environment
def test_Environment():
    # Check if there is a process of class Environment
    try:
        environment_0 = Environment()
    except Exception as e:
        print('Error:', e)
        return False
    # Check whether the process of class Environment is executed successfully
    if not environment_0 is None:
        print('The constructor of class Environment works well')
        return True
    else:
        print('The constructor of class Environment does not work well')
        return False


# Generated at 2022-06-25 18:20:32.748233
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(devnull=3, stdin='stdin', stdin_isatty=True, stdin_encoding='utf-8', stdout='stdout',
                              stdout_isatty=True, stdout_encoding='utf-8', stderr='stderr', stderr_isatty=True,
                              colors=256, program_name='http', config_dir='config_dir', is_windows=is_windows)

    try:
        if isinstance(environment, object) and isinstance(Environment(), object):
            if issubclass(type(environment), type(Environment())):
                return True
    except:
        return False


# Generated at 2022-06-25 18:20:43.341742
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows == is_windows
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == sys.stdin.isatty()
    assert environment.stdin_encoding is None
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == sys.stdout.isatty()
    assert environment.stdout_encoding is None
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == sys.stderr.isatty()
    assert environment.colors == 256



# Generated at 2022-06-25 18:20:52.939146
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().config == Config(directory=DEFAULT_CONFIG_DIR)
    assert Environment().config_dir == Path(DEFAULT_CONFIG_DIR)
    # assert Environment().stdin == sys.stdin  # ???
    assert Environment().stdin_isatty == sys.stdin.isatty()
    assert Environment().stdin_encoding is None
    # assert Environment().stdout == sys.stdout  # ???
    assert Environment().stdout_isatty == sys.stdout.isatty()
    assert Environment().stdout_encoding is None
    # assert Environment().stderr == sys.stderr  # ???
    assert Environment().stderr_isatty == sys.stderr.isatty()
    assert Environment().is_windows == is_windows
    assert Environment().colors == 256
   

# Generated at 2022-06-25 18:21:04.309806
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows is True
    assert env.config_dir == Path(DEFAULT_CONFIG_DIR)
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert env.stdin_isatty is False
    assert env.stdout_isatty is False
    assert env.stderr_isatty is False
    assert env.stdin_encoding is None
    assert env.stdout_encoding == 'utf8'
    assert env.stderr_encoding is None
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr
    assert env._devnull is None


# Generated at 2022-06-25 18:21:12.175138
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.is_windows == False
    assert environment_0.config_dir == Path(os.path.join(os.path.expanduser("~"), ".config/httpie/"))
    assert environment_0.stdin == sys.stdin
    assert environment_0.stdin_isatty == True
    assert environment_0.stdin_encoding == 'UTF-8'
    assert environment_0.stdout == sys.stdout
    assert environment_0.stdout_isatty == True
    assert environment_0.stdout_encoding == 'UTF-8'
    assert environment_0.stderr == sys.stderr
    assert environment_0.stderr_isatty == True
    assert environment_0.colors == 256

# Generated at 2022-06-25 18:22:25.418915
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows == Environment.is_windows
    assert environment.config_dir == Environment.config_dir
    assert environment.stdin == Environment.stdin
    assert environment.stdin_isatty == Environment.stdin_isatty
    assert environment.stdin_encoding == Environment.stdin_encoding
    assert environment.stdout == Environment.stdout
    assert environment.stdout_isatty == Environment.stdout_isatty
    assert environment.stdout_encoding == Environment.stdout_encoding
    assert environment.stderr == Environment.stderr
    assert environment.stderr_isatty == Environment.stderr_isatty
    assert environment.colors == Environment.colors
    assert environment.program_name == Environment.program_name


# Unit

# Generated at 2022-06-25 18:22:27.616032
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()

if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-25 18:22:37.393252
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()

# Generated at 2022-06-25 18:22:39.701084
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    if curses:
        assert env.colors >= 0


# Generated at 2022-06-25 18:22:50.357328
# Unit test for constructor of class Environment
def test_Environment():
    # Environment(devnull)
    tmp_stdin = sys.stdin
    environment_0 = Environment(stdin=tmp_stdin, devnull=None, is_windows=None, config_dir=None, stdin_isatty=None, stdin_encoding=None, stdout=None, stdout_isatty=None, stdout_encoding=None, stderr=None, stderr_isatty=None, colors=None, program_name=None)

    # Environment(devnull, is_windows)
    tmp_stdin = sys.stdin

# Generated at 2022-06-25 18:22:53.349344
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(program_name = "httpie")
    assert environment.program_name == "httpie"


# Generated at 2022-06-25 18:23:02.341703
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment(is_windows=False,
                    config_dir=None,
                    stdin=None,
                    stdin_isatty=False,
                    stdin_encoding=sys.stdin.encoding,
                    stdout=sys.stdout,
                    stdout_isatty=sys.stdout.isatty(),
                    stdout_encoding=sys.stdout.encoding,
                    stderr=sys.stderr,
                    stderr_isatty=sys.stderr.isatty(),
                    colors=256,
                    program_name='http',
                    )
    assert e



# Generated at 2022-06-25 18:23:08.512825
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.is_windows == False
    assert environment_0.config_dir == Path(os.getcwd())  # os.getcwd() is the default path, in case the default path is not given
    assert environment_0.stdin == sys.stdin
    assert environment_0.stdin_isatty == sys.stdin.isatty()
    assert environment_0.stdin_encoding == None
    assert environment_0.stdout == sys.stdout
    assert environment_0.stdout_isatty == sys.stdout.isatty()
    assert environment_0.stdout_encoding == None
    assert environment_0.stderr == sys.stderr

# Generated at 2022-06-25 18:23:18.827071
# Unit test for constructor of class Environment
def test_Environment():
    fd = open('/tmp/test_httpie_env.txt', 'w')
    environment_1 = Environment(config_dir="/tmp/config_dir", stdin=fd)
    fd.close()
    assert(os.path.exists('/tmp/test_httpie_env.txt'))
    assert(os.path.exists('/tmp/config_dir'))
    assert(environment_1.config_dir == "/tmp/config_dir")
    os.remove('/tmp/test_httpie_env.txt')
    os.rmdir('/tmp/config_dir')
    assert(not os.path.exists('/tmp/test_httpie_env.txt'))
    assert(not os.path.exists('/tmp/config_dir'))


# Generated at 2022-06-25 18:23:23.114103
# Unit test for constructor of class Environment
def test_Environment():
    try:
        env = Environment()
    except Exception as e:
        print('Environment class constructor raises exception ' + repr(e))
        assert False
    if env is None:
        print('Environment class constructor returns None')
        assert False
    if not isinstance(env, Environment):
        print('Environment class constructor returned non-Environment object')
        assert False
    assert True


# Generated at 2022-06-25 18:24:33.068770
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().stdout.encoding == 'utf8'
    assert Environment(stdout_encoding='utf8').stdout.encoding == 'utf8'
    assert Environment(stdout_encoding='ascii').stdout.encoding == 'ascii'
    assert Environment(stdout_encoding=None).stdout.encoding == 'utf8'
    assert not Environment(stdout_encoding=None).stdout.isatty()


if __name__ == '__main__':
    import pytest
    pytest.main(args=[__file__]  # + ['--verbose']
                )

# Generated at 2022-06-25 18:24:37.621531
# Unit test for constructor of class Environment
def test_Environment():
    environment0=Environment()
    assert environment0.is_windows == False
    assert environment0.config_dir == "/home/httpie/config"
    assert environment0.stdin is not None
    assert environment0.stdin_isatty  == True
    assert environment0.stdin_encoding == 'cp1252'
    assert environment0.stdout.isatty() == True
    assert environment0.stdout_encoding == 'cp1252'
    assert environment0.stderr.isatty() == True
    assert environment0.stderr_isatty == True
    assert environment0.colors == 256
    assert environment0.program_name == 'http'

# Generated at 2022-06-25 18:24:46.422614
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows == is_windows
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == environment.stdin.isatty()
    assert environment.stdin_encoding == None
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == sys.stdout.isatty()
    assert environment.stdout_encoding == None
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == sys.stderr.isatty()
    assert environment.colors == 256
    assert environment.program_name == 'http'
    assert environment._orig_stderr == sys.stderr
   

# Generated at 2022-06-25 18:24:47.564781
# Unit test for constructor of class Environment
def test_Environment():
    Environment(devnull = open(os.devnull,'w+'))

# Generated at 2022-06-25 18:24:49.810083
# Unit test for constructor of class Environment
def test_Environment():
    global environment_1
    environment_1 = Environment(stdin='stdin')
    assert environment_1.stdin == 'stdin'


# Generated at 2022-06-25 18:24:53.429452
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.stdin is not None
    assert not env.stdin_isatty
    assert env.stdout_isatty
    assert env.stderr_isatty
    assert env.colors == 256
    
    

# Generated at 2022-06-25 18:24:59.987882
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment(
        is_windows=1, config_dir=1, stdin=1, stdin_isatty=1, stdin_encoding=1,
        stdout=1, stdout_isatty=1, stdout_encoding=1, stderr=1,
        stderr_isatty=1, colors=1, program_name=1,
        _orig_stderr=1, _devnull=1, _config=1
    )

# Generated at 2022-06-25 18:25:08.140659
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows is False
    assert environment.config_dir == Path.home() / '.config' / 'httpie'
    assert environment.program_name == 'http'
    assert environment.stdin.fileno() == 0
    assert environment.stdin_isatty == True
    assert environment.stdin_encoding == "cp65001"
    assert environment.stdout.fileno() == 1
    assert environment.stdout_isatty == True
    assert environment.stdout_encoding == "cp65001"
    assert environment.stderr.fileno() == 2
    assert environment.stderr_isatty == True
    assert environment.colors == 16

# Generated at 2022-06-25 18:25:14.924470
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.stdin is sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding is None
    assert env.stdout is sys.stdout
    assert env.stdout_isatty == sys.stdin.isatty()
    assert env.stdout_encoding is None
    assert env.stderr is sys.stderr
    assert env.stderr_isatty == sys.stdin.isatty()
    assert env.program_name == "http"
    assert env.colors == 256
    assert env.config_dir == DEFAULT_CONFIG_DIR


# Generated at 2022-06-25 18:25:16.294428
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()
    assert True