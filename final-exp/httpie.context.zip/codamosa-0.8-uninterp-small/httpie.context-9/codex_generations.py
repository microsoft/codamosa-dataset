

# Generated at 2022-06-25 18:15:40.310973
# Unit test for constructor of class Environment
def test_Environment():
    # Set default values
    assert (Environment().config_dir == DEFAULT_CONFIG_DIR)

    # Set passed values
    assert (Environment(config_dir="directory").config_dir == "directory")

# Generated at 2022-06-25 18:15:48.918574
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.__str__() == '<Environment is_windows=False, config_dir=/home/travis/.config/httpie, stdin=<_io.TextIOWrapper encoding=\'UTF-8\'>, stdin_isatty=True, stdout=<_io.TextIOWrapper name=1 encoding=\'UTF-8\'>, stdout_isatty=True, stderr=<_io.TextIOWrapper name=2 encoding=\'UTF-8\'>, stderr_isatty=True, program_name=\'http\', colors=256, config=<Config config_dir=/home/travis/.config/httpie, values={\'default_options\': []}>>'
    assert not callable(environment_0.__str__())

# Generated at 2022-06-25 18:15:52.847194
# Unit test for constructor of class Environment
def test_Environment():
    try:
        variable_0 = Environment()
        variable_0.stdin_encoding
    except Exception as exception:
        variable_1 = exception
    else:
        variable_1 = None



# Generated at 2022-06-25 18:16:00.548534
# Unit test for constructor of class Environment
def test_Environment():
    cmd_opts = {
        'debug': False,
        'help': False,
        'output_options': {
            'pretty': 'all',
            'format': 'colored_grid'},
        'output_formats': [],
        'style_options': {},
        'style_theme': 'default',
        'verbose': 0,
        'verify': True}
    environment_0 = Environment()

# Generated at 2022-06-25 18:16:07.496389
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert type(environment).__name__ == 'Environment'
    assert environment.__doc__ == "    Information about the execution context\n    (standard streams, config directory, etc).\n\n    By default, it represents the actual environment.\n    All of the attributes can be overwritten though, which\n    is used by the test suite to simulate various scenarios.\n"


# Generated at 2022-06-25 18:16:16.870013
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment.__doc__ is not None
    environment_0 = Environment()
    var_0 = environment_0.__str__()
    environment_1 = Environment(devnull=None, is_windows=False, config_dir='', stdin=None, stdin_isatty=False, stdin_encoding='', stdout=None, stdout_isatty=False, stdout_encoding='', stderr=None, stderr_isatty=False, colors=0, program_name='')
    var_1 = environment_1.__str__()

# Generated at 2022-06-25 18:16:22.781161
# Unit test for constructor of class Environment
def test_Environment():
    stderr_isatty = sys.stderr.isatty()
    stdin_isatty = sys.stdin.isatty()
    stdout_isatty = sys.stdout.isatty()
    is_windows = sys.platform.startswith('win')
    stdout_encoding = getattr(sys.stdout, 'encoding', None) or 'utf8'
    stdin_encoding = getattr(sys.stdin, 'encoding', None) or 'utf8'
    DEFAULT_CONFIG_DIR = Path.home().joinpath('.config', 'httpie')


# Generated at 2022-06-25 18:16:24.624398
# Unit test for constructor of class Environment
def test_Environment():
    test_Environment_0()
    test_Environment_1()


# Generated at 2022-06-25 18:16:27.375303
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None)
    var = env.__str__()
    return var

if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-25 18:16:38.017885
# Unit test for constructor of class Environment
def test_Environment():
    devnull = 'devnull'
    environment_0 = Environment(devnull)
    assert environment_0.devnull == 'devnull'
    assert environment_0.stderr == sys.stderr
    assert environment_0.stderr_isatty == sys.stderr.isatty()
    assert environment_0.stderr_encoding == sys.stderr.encoding
    assert environment_0.stdout == sys.stdout
    assert environment_0.stdout_isatty == sys.stdout.isatty()
    assert environment_0.stdout_encoding == sys.stdout.encoding
    assert environment_0.stdin == sys.stdin
    assert environment_0.stdin_isatty == sys.stdin.isatty()
    assert environment_0.stdin

# Generated at 2022-06-25 18:16:44.912488
# Unit test for constructor of class Environment
def test_Environment():
    # test whether the Environment class is defined
    assert inspect.isclass(Environment)


# Generated at 2022-06-25 18:16:48.648058
# Unit test for constructor of class Environment
def test_Environment():
    from httpie.config import Config
    import httpie.config
    environment_1 = Environment()
    config_0 = Config(directory=environment_1.config_dir)
    httpie.config.Config = config_0


# Generated at 2022-06-25 18:16:53.186430
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()
    # test if environment_1 is a Environment object
    assert type(environment_1) == Environment
    # test if environment_1 is not None
    assert environment_1 is not None
    environment_2 = Environment()
    # test if environment_1 and environment_2 are the same object
    assert environment_1 == environment_2


# Generated at 2022-06-25 18:16:54.645409
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    var_0 = environment_0.__str__()


# Generated at 2022-06-25 18:16:57.727067
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert isinstance(environment_0.config, Config)



# Generated at 2022-06-25 18:17:08.412020
# Unit test for constructor of class Environment
def test_Environment():
    import requests, json
    import time
    import ast

    # URL for the web application
    url = "http://127.0.0.1:5000" # change the URL as per your local machine

    # Test for new user registration
    client = requests.session()

    # Retrieve the CSRF token first
    client.get(url + "/login")  # sets cookie
    csrftoken = client.cookies['csrftoken']

    login_data = dict(username="testcase0", password="testcase0", csrfmiddlewaretoken=csrftoken, next='/')
    rv = client.post(url + "/login", data=login_data, headers=dict(Referer=url + "/login"))
    if rv.status_code == 200:
        print("Registration Successful")

# Generated at 2022-06-25 18:17:09.445108
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()


# Generated at 2022-06-25 18:17:18.333755
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment(devnull=None, is_windows=False, config_dir=DEFAULT_CONFIG_DIR, stdin=sys.stdin, stdin_isatty=True, stdin_encoding='utf8', stdout=sys.stdout, stdout_isatty=True, stdout_encoding='utf8', stderr=sys.stderr, stderr_isatty=True)
    assert environment_0.is_windows == False
    assert environment_0.config_dir == DEFAULT_CONFIG_DIR
    assert environment_0.stdin == sys.stdin
    assert environment_0.stdin_isatty == True
    assert environment_0.stdin_encoding == 'utf8'
    assert environment_0.stdout == sys.stdout

# Generated at 2022-06-25 18:17:20.817137
# Unit test for constructor of class Environment
def test_Environment():
    # Test if the constructor can run
    def test_constructor():
        temp = Environment()
        try:
            assert(True)
        except Exception:
            assert(False)

    test_constructor()


# Generated at 2022-06-25 18:17:32.025156
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()

# Uncomment given lines to test the behavior of functions in Environment class
# def test_function_0():
#     environment_0 = Environment()
#     var_0 = environment_0.__str__()
#     return var_0
#
# def test_function_1():
#     environment_0 = Environment()
#     var_0 = environment_0.__repr__()
#     return var_0
#
# def test_function_2():
#     environment_0 = Environment()
#     var_0 = environment_0.__dict__
#     return var_0
#
# def test_function_3():
#     environment_0 = Environment()
#     var_0 = environment_0.config
#     return var_0
#
# def test_function_4():
#

# Generated at 2022-06-25 18:17:40.518111
# Unit test for constructor of class Environment
def test_Environment():
    # test_case_0
    environment_0 = Environment()

# Generated at 2022-06-25 18:17:41.724368
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()

# Generated at 2022-06-25 18:17:46.153483
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.is_windows == environment_0.is_windows
    assert environment_0.stdin == environment_0.stdin
    assert environment_0.stdin_encoding == sys.stdin.encoding
    assert environment_0.stdout_encoding == sys.stdout.encoding
    assert environment_0.colors == 256

# Generated at 2022-06-25 18:17:51.490015
# Unit test for constructor of class Environment
def test_Environment():

    environment = Environment(
        is_windows = False, 
        config_dir = DEFAULT_CONFIG_DIR,
        stdin = sys.stdin,
        stdin_isatty = sys.stdin.isatty(),
        stdin_encoding = None,
        stdout = sys.stdout,
        stdout_isatty = sys.stdout.isatty(),
        stdout_encoding = None,
        stderr = sys.stderr,
        stderr_isatty = sys.stderr.isatty(),
        colors = 256,
        program_name = 'http'
    )

    assert environment.is_windows == False
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin == sys.stdin
    assert environment.stdin

# Generated at 2022-06-25 18:17:52.385881
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()

# Generated at 2022-06-25 18:17:54.474693
# Unit test for constructor of class Environment
def test_Environment():
    assert isinstance(Environment(), Environment)
    devnull = object()
    assert Environment(devnull=devnull).devnull is devnull


# Generated at 2022-06-25 18:18:03.690455
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0._config is None
    assert environment_0.stderr == sys.stderr
    assert environment_0.stderr_isatty == False
    assert environment_0.stderr_encoding == 'cp950'

# Generated at 2022-06-25 18:18:07.657132
# Unit test for constructor of class Environment
def test_Environment():
	# Positive testing:
	environment_0 = Environment()
	assert isinstance(environment_0, Environment)
	# Negative testing:
	try:
		environment_0 = Environment(0)
	except AssertionError:
		return
	assert False


# Generated at 2022-06-25 18:18:16.438268
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()

    assert isinstance(environment_0.is_windows, bool)
    assert isinstance(environment_0.config_dir, Path)
    assert isinstance(environment_0.stdin, Optional[IO])
    assert isinstance(environment_0.stdin_isatty, bool)
    assert isinstance(environment_0.stdin_encoding, str)
    assert isinstance(environment_0.stdout, IO)
    assert isinstance(environment_0.stdout_isatty, bool)
    assert isinstance(environment_0.stdout_encoding, str)
    assert isinstance(environment_0.stderr, IO)
    assert isinstance(environment_0.stderr_isatty, bool)
    assert isinstance(environment_0.colors, int)

# Generated at 2022-06-25 18:18:27.942100
# Unit test for constructor of class Environment
def test_Environment():
    # Test the default values of Environment
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == (sys.stdin.isatty() if sys.stdin else False)
    assert env.stdin_encoding is None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding is None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'

# Generated at 2022-06-25 18:18:43.690060
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=0)
    assert env.devnull is None
    assert env.is_windows == 0
    assert env.config_dir is not None
    assert env.stdin is not None
    assert env.stdin_isatty != 0
    assert env.stdin_encoding != ""
    assert env.stdout is not None
    assert env.stdout_isatty != 0
    assert env.stdout_encoding != ""
    assert env.stderr is not None
    assert env.stderr_isatty != 0
    assert env.colors != 0
    assert env.program_name != ""
    assert env._orig_stderr is not None
    assert env._devnull is None

# Generated at 2022-06-25 18:18:50.266238
# Unit test for constructor of class Environment
def test_Environment():
    cwd = os.getcwd()
    file_location = cwd + "/httpie/compat.py"
    file_path = file_location
    x = open(file_path, 'r')
    data = x.read()
    x.close()

    from io import StringIO

    f = StringIO(data)
    p = Environment(devnull=f, is_windows=True)

    assert p.devnull == f
    assert p.is_windows == True
    #assert p.config_dir == '/usr/local/etc/httpie'
    #assert p.stdin == f
    #assert p.stdin_isatty == False
    #assert p.stdin_encoding == 'cp1252'
    assert p.stdout_isatty == False
    assert p.stdout_enc

# Generated at 2022-06-25 18:18:59.620780
# Unit test for constructor of class Environment
def test_Environment():

    environment_1 = Environment()

# Generated at 2022-06-25 18:19:04.852375
# Unit test for constructor of class Environment
def test_Environment():
    "Environment constructor"
    env = Environment()
    assert env.stdin_isatty
    assert env.stderr_isatty
    assert env.stdout_isatty
    assert env.stderr is sys.stderr
    assert env.stdout is sys.stdout
    assert env.stdin is sys.stdin



# Generated at 2022-06-25 18:19:06.288975
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().__class__.__name__ == "Environment"


# Generated at 2022-06-25 18:19:07.896038
# Unit test for constructor of class Environment
def test_Environment():
    environment=Environment()
    assert isinstance(environment,Environment)

# Generated at 2022-06-25 18:19:12.900855
# Unit test for constructor of class Environment
def test_Environment():
    # test_case_1
    environment_1 = Environment()
    assert isinstance(environment_1, Environment)

    # test_case_2
    environment_2 = Environment(devnull=open(os.devnull, 'w+'))
    assert isinstance(environment_2, Environment)
    environment_2.devnull.close()


# Generated at 2022-06-25 18:19:22.484575
# Unit test for constructor of class Environment
def test_Environment():
    prog_name = 'http'
    environment_0 = Environment(program_name=prog_name)
    assert environment_0.program_name == prog_name, 'Expected program_name to be prog_name, but got %s' % environment_0.program_name
    assert isinstance(environment_0.config_dir, Path), 'Expected config_dir to be instance of Path, but got %s' % type(environment_0.config_dir)
    assert environment_0.stdin is sys.stdin, 'Expected stdin to be sys.stdin, but got %s' % environment_0.stdin
    assert environment_0.stdin_isatty == sys.stdin.isatty(), 'Expected stdin_isatty to be sys.stdin.isatty(), but got %s' % environment_

# Generated at 2022-06-25 18:19:30.594750
# Unit test for constructor of class Environment
def test_Environment():
    # devnull = None
    stderr = open (os.devnull, 'w+')
    stdout = open (os.devnull, 'w+')
    stdin = open (os.devnull, 'w+')
    environment = Environment(devnull=None, stderr=stderr, stdout=stdout, stdin=stdin)
    assert environment.stderr == stderr
    assert environment.stdout == stdout
    assert environment.stdin == stdin
    stderr.close()
    stdout.close()
    stdin.close()


# Generated at 2022-06-25 18:19:39.475923
# Unit test for constructor of class Environment
def test_Environment():
    if sys.platform != 'win32':
        assert Environment.stdin == sys.stdin
        assert Environment.stdout == sys.stdout
        assert Environment.stderr == sys.stderr
    else:
        import colorama.initialise

        assert isinstance(Environment.stdout, colorama.initialise.AnsiToWin32)
        assert isinstance(Environment.stderr, colorama.initialise.AnsiToWin32)

    assert Environment.stdin_encoding == 'utf8'
    assert Environment.stdout_encoding == 'utf8'
    assert Environment.is_windows == (sys.platform == 'win32')
    assert Environment.colors == 256
    assert Environment.config_dir == DEFAULT_CONFIG_DIR
    assert Environment.program_name == 'http'


# Generated at 2022-06-25 18:19:46.350704
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment() is not None

# Generated at 2022-06-25 18:19:54.522393
# Unit test for constructor of class Environment
def test_Environment():
    output_directory = os.path.dirname(os.path.realpath(__file__)) + "/output/"
    # In this test case, we will test constructor
    #  of class Environment to see whether it creates an instance correctly.

    # If we get an exception here, the test has failed.
    test_case_0()

    # If it runs to here, the test is passed.
    # Write the test result into a file so that we can get this result later.
    f = open(output_directory + "test_result_Environment_0.txt", "w+")
    f.write("Test for constructor of class Environment is passed!")
    f.close()

# Generated at 2022-06-25 18:20:01.651235
# Unit test for constructor of class Environment
def test_Environment():
    environment_test = Environment()
    DEFAULT_CONFIG_DIR = str(Path(DEFAULT_CONFIG_DIR))
    assert isinstance(environment_test.is_windows, bool)
    assert environment_test.config_dir.__str__() == DEFAULT_CONFIG_DIR
    assert environment_test.stdin is not None
    assert isinstance(environment_test.stdin_isatty, bool)
    assert environment_test.stdout is not None
    assert isinstance(environment_test.stdout_isatty, bool)
    assert environment_test.stderr is not None
    assert isinstance(environment_test.stderr_isatty, bool)
    assert environment_test.program_name == 'http'


# Generated at 2022-06-25 18:20:10.953227
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr

# Generated at 2022-06-25 18:20:17.684458
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()
    for attr in ['stdin', 'stdout', 'stderr']:
        assert getattr(sys, attr) == getattr(environment_1, attr)

    environment_2 = Environment(stdin=None)
    environment_2_stdin = getattr(environment_2, 'stdin')
    assert any([environment_2_stdin is None,
                sys.stdin._is_closed])



# Generated at 2022-06-25 18:20:20.768704
# Unit test for constructor of class Environment
def test_Environment():
    environ = os.environ
    os.environ["HTTPIE_CONFIG_DIR"] = "D:\\gits\\config"
    environment = Environment()
    print(environment.config_dir)



# Generated at 2022-06-25 18:20:26.659865
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(is_windows=True,
                              config_dir=DEFAULT_CONFIG_DIR,
                              stdin=sys.stdin,
                              stdin_isatty=sys.stdin.isatty(),
                              stdin_encoding=sys.stdin.encoding,
                              stdout=sys.stdout,
                              stdout_isatty=sys.stdout.isatty(),
                              stdout_encoding=sys.stdout.encoding,
                              stderr=sys.stderr,
                              stderr_isatty=sys.stderr.isatty(),
                              colors=True,
                              program_name='http',
                              config=Config(directory=DEFAULT_CONFIG_DIR))
    assert environment.is_windows == True
   

# Generated at 2022-06-25 18:20:32.671069
# Unit test for constructor of class Environment
def test_Environment():
    Environment(stderr=sys.stdin)
    Environment(stdin=sys.stdout)
    Environment(devnull=sys.stdout)
    Environment(stdout=sys.stderr)
    Environment(stdin=sys.stdin, stdout=sys.stdout)
    Environment(stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr)

# Test for output of method __repr__ from class Environment

# Generated at 2022-06-25 18:20:33.774180
# Unit test for constructor of class Environment
def test_Environment():
    # Test case 0
    environment_0 = Environment()


test_Environment()

# Generated at 2022-06-25 18:20:38.930565
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(devnull=os.devnull)
    assert environment_1.devnull == os.devnull

    environment_2 = Environment(devnull=True)
    assert environment_2.devnull == None



# Generated at 2022-06-25 18:21:02.327441
# Unit test for constructor of class Environment
def test_Environment():
    # Test case 1: is_windows = True, stdin = sys.stdin, stdout = sys.stdout, stderr = sys.stderr.
    environment_1 = Environment()
    assert environment_1.is_windows == is_windows
    assert environment_1.stdin is sys.stdin
    assert environment_1.stdout is sys.stdout
    assert environment_1.stderr is sys.stderr

    # Test case 2: is_windows = False, stdin = sys.stdin, stdout = sys.stdout, stderr = sys.stderr.
    environment_2 = Environment(is_windows = False, stdin = sys.stdin, stdout = sys.stdout, stderr = sys.stderr)
    assert not environment_2.is_windows
    assert environment_

# Generated at 2022-06-25 18:21:11.511079
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()
    assert environment_1.config_dir == DEFAULT_CONFIG_DIR
    assert environment_1.is_windows == is_windows
    if sys.stdin:
        if sys.stdin.isatty():
            assert environment_1.stdin_isatty == True
            assert environment_1.stdin_encoding == sys.stdin.encoding
        else:
            assert environment_1.stdin_isatty == False
            assert environment_1.stdin_encoding is None
    elif sys.stdin.isatty():
        assert environment_1.stdin_encoding == sys.stdin.encoding
    else:
        assert environment_1.stdin_encoding is None
    if sys.stdout.isatty():
        assert environment_1.stdout

# Generated at 2022-06-25 18:21:21.082136
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    sys.stdin = open(os.devnull, 'w+')
    assert environment_0.stdin is sys.stdin
    # assert environment_0.stdout is sys.stdout
    assert environment_0.stderr is sys.stderr
    sys.stdin = sys.__stdin__
    environment_1 = Environment(devnull=sys.stdin)
    assert environment_1.stderr is environment_1.stderr
    environment_2 = Environment(devnull=sys.stdin)
    assert environment_2.devnull is environment_2.devnull    


# Generated at 2022-06-25 18:21:30.895043
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows == is_windows
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == sys.stdin.isatty()
    assert environment.stdin_encoding == (getattr(sys.stdin, 'encoding', None))
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == sys.stdout.isatty()
    assert environment.stdout_encoding == (getattr(sys.stdout, 'encoding', None))
    assert environment.stderr == sys.stderr
    assert environment.colors == 256
    assert environment.program_name == 'http'
    environment = Environment(None)

# Unit test

# Generated at 2022-06-25 18:21:31.916651
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()


# Generated at 2022-06-25 18:21:43.378282
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows == is_windows
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == environment.stdin.isatty()
    assert environment.stdin_encoding == None
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == environment.stdout.isatty()
    assert environment.stdout_encoding == None
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == environment.stderr.isatty()
    assert environment.colors == 256
    assert environment.program_name == 'http'
    assert environment._orig_stderr == sys.stderr
   

# Generated at 2022-06-25 18:21:54.946814
# Unit test for constructor of class Environment
def test_Environment():
    if os.path.exists('httpie-test-config'):
        shutil.rmtree('httpie-test-config')
    os.mkdir('httpie-test-config')
    with open('httpie-test-config/config.json', 'w') as fp:
        fp.write('{"config-one": "Config-one-value"}')
    with open('httpie-test-config/config-two.json', 'w') as fp:
        fp.write('{"config-two": "Config-two-value"}')
    e = Environment(config_dir='httpie-test-config')
    config = e.config
    assert len(config) == 2
    assert config['config-one'] == 'Config-one-value'

# Generated at 2022-06-25 18:22:07.202779
# Unit test for constructor of class Environment
def test_Environment():
    e1 = Environment()
    e2 = Environment(devnull = './test_files/devnull_file')
    e3 = Environment(devnull = './test_files/devnull_file', is_windows=True)
    e4 = Environment(is_windows=True)
    e5 = Environment(stdin=None, stdin_isatty = False)
    e6 = Environment(stdin_isatty = False)
    e7 = Environment(stdin_encoding = 'abc')
    e8 = Environment(stdin_encoding = 'abc', is_windows=True)
    e9 = Environment(stdin=None, stdin_isatty = False, stdin_encoding = 'abc', is_windows=True)
    e10 = Environment(stdin_encoding = 'abc')

# Generated at 2022-06-25 18:22:08.958482
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    environment_1 = Environment(True)
    assert environment_0 is environment_1



# Generated at 2022-06-25 18:22:09.984769
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()

# Generated at 2022-06-25 18:22:46.113426
# Unit test for constructor of class Environment
def test_Environment():
    ## No parameter
    environment_0 = Environment()
    # stdin
    result = environment_0.stdin
    expect = sys.stdin
    assert result == expect, "result: %s, expect: %s" % (result, expect)
    # stdin_isatty
    result = environment_0.stdin_isatty
    expect = sys.stdin.isatty()
    assert result == expect, "result: %s, expect: %s" % (result, expect)
    # stdin_encoding
    result = environment_0.stdin_encoding
    expect = sys.stdin.encoding
    assert result == expect, "result: %s, expect: %s" % (result, expect)
    # stdout
    result = environment_0.stdout
    expect = sys.stdout


# Generated at 2022-06-25 18:22:51.254814
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()
    assert environment_1.is_windows == is_windows
    assert environment_1.config_dir == DEFAULT_CONFIG_DIR
    assert environment_1.stdin == sys.stdin
    assert environment_1.stdin_isatty == sys.stdin.isatty()
    if sys.stdin:
        assert environment_1.stdin_encoding == getattr(
            sys.stdin, 'encoding', None) or 'utf8'
    else:
        assert environment_1.stdin_encoding == None
    assert environment_1.stdout == sys.stdout
    assert environment_1.stdout_isatty == sys.stdout.isatty()
    if is_windows:
        # noinspection PyUnresolvedReferences
        from colorama import Ansi

# Generated at 2022-06-25 18:23:02.442444
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()
    assert(environment_1.stdout_isatty)
    assert('/Users/administrator/.httpie/config.json' == str(environment_1.config_dir))
    assert(environment_1.stdin.__class__ is sys.stdin.__class__)
    assert(environment_1.stdin_isatty == sys.stdin.isatty())
    assert(environment_1.stdin_encoding == sys.stdin.encoding)
    assert(environment_1.stdout.__class__ is sys.stdout.__class__)
    assert(environment_1.stdout_isatty == sys.stdout.isatty())
    assert(environment_1.stdout_encoding == sys.stdout.encoding)

# Generated at 2022-06-25 18:23:07.183403
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().is_windows
    assert isinstance(Environment().config_dir, Path)
    assert Environment().stdin
    assert isinstance(Environment().stdin_isatty, bool)
    assert Environment().stdin_encoding
    assert Environment().stdout
    assert isinstance(Environment().stdout_isatty, bool)
    assert Environment().stdout_encoding
    assert Environment().stderr
    assert isinstance(Environment().stderr_isatty, bool)
    assert isinstance(Environment().colors, int)
    assert Environment().program_name


# Generated at 2022-06-25 18:23:08.607762
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()

# Generated at 2022-06-25 18:23:18.903294
# Unit test for constructor of class Environment

# Generated at 2022-06-25 18:23:20.409429
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().config_dir == DEFAULT_CONFIG_DIR

# Generated at 2022-06-25 18:23:22.191532
# Unit test for constructor of class Environment
def test_Environment():
    print(Environment())

if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-25 18:23:31.775949
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    check = True
    if environment_0.is_windows != is_windows:
        print("Failed test_Environment")
        check = False
    if environment_0.config_dir != DEFAULT_CONFIG_DIR:
        print("Failed test_Environment")
        check = False
    if environment_0.stdin != sys.stdin:
        print("Failed test_Environment")
        check = False
    if environment_0.stdin_isatty != sys.stdin.isatty():
        print("Failed test_Environment")
        check = False
    if environment_0.stdout != sys.stdout:
        print("Failed test_Environment")
        check = False

# Generated at 2022-06-25 18:23:33.255342
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()

# Generated at 2022-06-25 18:24:28.668574
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    if environment.is_windows:
        assert "PySys_SetArgv(argv)" in str(environment.stdout)
        assert "ansi_to_win32.initialise" in str(environment.stdout)


# Generated at 2022-06-25 18:24:31.108123
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()

# Print the results and exit
if __name__ == "__main__":
    test_Environment()
    print("Unit tests for class Environment: PASS!")
    exit(0)

# Generated at 2022-06-25 18:24:39.945501
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.is_windows == is_windows
    assert environment_0.config_dir == Path(__file__).parent / 'config_dir'
    assert environment_0.stdin is sys.stdin
    assert environment_0.stdin_isatty is True
    assert environment_0.stdin_encoding is 'utf8'
    assert environment_0.stdout is sys.stdout
    assert environment_0.stdout_isatty is True
    assert environment_0.stdout_encoding is 'utf8'
    assert environment_0.stderr is sys.stderr
    assert environment_0.stderr_isatty is True
    assert environment_0.colors is 256
    assert environment_0.program_name is 'http'

# Generated at 2022-06-25 18:24:46.423345
# Unit test for constructor of class Environment
def test_Environment():
    with open(os.devnull, 'w+') as devnull:
        environment_0 = Environment(devnull=devnull)
        environment_1 = Environment(is_windows=True, stdin=None, stdout=None,
                                    stderr=None, devnull=devnull)
        assert environment_0.is_windows == environment_1.is_windows
        assert environment_0.stdin == environment_1.stdin
        assert environment_0.stdout == environment_1.stdout
        assert environment_0.stderr == environment_1.stderr
        assert environment_0.devnull == environment_1.devnull


# Generated at 2022-06-25 18:24:55.878092
# Unit test for constructor of class Environment
def test_Environment():
    if __name__ == "__main__":
        environment_0 = Environment()
        print(environment_0.config_dir)
        print(environment_0.stdin)
        print(environment_0.stdin_isatty)
        print(environment_0.stdin_encoding)
        print(environment_0.stdout)
        print(environment_0.stdout_isatty)
        print(environment_0.stdout_encoding)
        print(environment_0.stderr)
        print(environment_0.stderr_isatty)
        print(environment_0.colors)
        print(environment_0.program_name)
        print(environment_0._orig_stderr)
        print(environment_0._devnull)
        print(environment_0.config)




# Generated at 2022-06-25 18:24:59.427473
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment(program_name='test', config_dir='test_dir')
    assert e.program_name == 'test'
    assert e.config_dir == 'test_dir'

# Generated at 2022-06-25 18:25:06.390545
# Unit test for constructor of class Environment
def test_Environment():

    assert isinstance(Environment(), Environment)
    assert isinstance(Environment(is_windows=False, config_dir=Path('.config'),
                                 stdin=None, stdin_isatty=False,
                                 stdin_encoding=None, stdout=sys.stdout,
                                 stdout_isatty=False, stdout_encoding=None,
                                 stderr=sys.stderr, stderr_isatty=True,
                                 colors=256, program_name='http',
                                 devnull=None), Environment)


# Generated at 2022-06-25 18:25:12.768904
# Unit test for constructor of class Environment
def test_Environment():
    assert (is_windows == True) == Environment().is_windows
    assert DEFAULT_CONFIG_DIR == Environment().config_dir
    assert sys.stdin == Environment().stdin
    assert sys.stdin.isatty() == Environment().stdin_isatty
    assert None == Environment().stdin_encoding
    assert sys.stdout == Environment().stdout
    assert sys.stdout.isatty() == Environment().stdout_isatty
    assert None == Environment().stdout_encoding
    assert sys.stderr == Environment().stderr
    assert sys.stderr.isatty() == Environment().stderr_isatty
    assert 'http' == Environment().program_name

# Generated at 2022-06-25 18:25:23.884662
# Unit test for constructor of class Environment
def test_Environment():
    print('testing Environment constructor')
    print('testing on a case of is_windows = True, config_dir = /config, stdin = sys.stdin, stdin_isatty = True, stdin_encoding = None, stdout = sys.stdout, stdout_isatty = True, stdout_encoding = None, stderr = sys.stderr, stderr_isatty = True, colors = 256, program_name = http, devnull = None')

# Generated at 2022-06-25 18:25:34.483322
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(stdin_isatty=True)
    assert environment_1.stdin_isatty == True
    assert environment_1.stdout == sys.stdout
    assert environment_1.stderr == sys.stderr
    assert environment_1.stdout_isatty == True
    assert environment_1.stderr_isatty == True
    assert environment_1.stdin_encoding == 'utf8'
    assert environment_1.stdout_encoding == 'utf8'
    assert environment_1.program_name == 'http'
    assert environment_1.colors == 256
    assert environment_1.config_dir == DEFAULT_CONFIG_DIR
