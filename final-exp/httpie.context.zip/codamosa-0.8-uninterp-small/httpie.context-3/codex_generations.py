

# Generated at 2022-06-25 18:15:34.020143
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env

if __name__ == "__main__":
    test_Environment()

# Generated at 2022-06-25 18:15:40.108800
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.is_windows == environment_0.is_windows
    assert environment_0.config_dir == environment_0.config_dir
    assert environment_0.stdin == environment_0.stdin
    assert environment_0.stdin_isatty == environment_0.stdin_isatty
    assert environment_0.stdout == environment_0.stdout
    assert environment_0.stdout_isatty == environment_0.stdout_isatty
    assert environment_0.stderr == environment_0.stderr
    assert environment_0.stderr_isatty == environment_0.stderr_isatty
    assert environment_0.colors == environment_0.colors
    assert environment_0.program_name == environment_0.program

# Generated at 2022-06-25 18:15:48.847521
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.is_windows == is_windows and not is_windows
    assert environment_0.config_dir == DEFAULT_CONFIG_DIR
    assert environment_0.stdin == sys.stdin
    assert environment_0.stdin_isatty == (False if not sys.stdin else sys.stdin.isatty())
    assert environment_0.stdout == sys.stdout
    assert environment_0.stdout_isatty == sys.stdout.isatty()
    assert environment_0.stderr == sys.stderr
    assert environment_0.stderr_isatty == sys.stderr.isatty()
    assert environment_0.colors == 256
    assert environment_0.program_name == 'http'
    assert environment_0

# Generated at 2022-06-25 18:15:58.919021
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin  # `None` when closed fd (#791)
    assert env.stdin_isatty
    assert env.stdout == sys.stdout
    assert env.stdout_isatty
    assert env.stderr == sys.stderr
    assert env.stderr_isatty
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._devnull is None
    assert env._config is None
    assert env._orig_stderr == sys.stderr
    assert env.stdout_encoding == 'utf-8'

# Generated at 2022-06-25 18:16:11.004585
# Unit test for constructor of class Environment
def test_Environment():

    # Constructor without arguments
    environment_1 = Environment()
    assert environment_1.is_windows == False
    assert environment_1.config_dir == Path('/home/travis/.config/httpie')
    assert environment_1.stdin == sys.stdin
    assert environment_1.stdin_isatty == False
    assert environment_1.stdin_encoding == None
    assert environment_1.stdout == sys.stdout
    assert environment_1.stdout_isatty == True
    assert environment_1.stdout_encoding == None
    assert environment_1.stderr == sys.stderr
    assert environment_1.stderr_isatty == True
    assert environment_1.colors == 256
    assert environment_1.program_name == 'http'
    assert environment_1

# Generated at 2022-06-25 18:16:19.335347
# Unit test for constructor of class Environment

# Generated at 2022-06-25 18:16:22.694533
# Unit test for constructor of class Environment
def test_Environment():
    from io import StringIO
    from typing import IO
    from httpie.environment import Environment

    environment = Environment(stdin=StringIO('Hello, world!'), stdout=StringIO())
    assert environment.stdin == StringIO('Hello, world!')
    assert environment.stdout == StringIO()
    environment.devnull = 'devnull'
    assert environment.devnull == 'devnull'


if __name__ == '__main__':
    import pytest
    pytest.main(['-v', __file__])

# Generated at 2022-06-25 18:16:33.804354
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.is_windows == True
    assert str(environment_0.config_dir) == 'C:\\Users\\user\\.config\\httpie'
    assert str(environment_0.stdin) == '<_io.TextIOWrapper name=\'<stdin>\' mode=\'r\' encoding=\'cp949\'>'
    assert environment_0.stdin_isatty == True
    assert str(environment_0.stdin_encoding) == 'cp949'
    assert str(environment_0.stdout) == '<_io.TextIOWrapper name=\'<stdout>\' mode=\'w\' encoding=\'cp949\'>'
    assert environment_0.stdout_isatty == True

# Generated at 2022-06-25 18:16:45.566586
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment(colors=12, stdin_isatty=True)
    environment_1 = Environment(colors=12, stdin_isatty=False)
    environment_2 = Environment(colors=16, stdin_isatty=True)
    environment_3 = Environment(colors=16, stdin_isatty=False)
    assert environment_0.colors == 12
    assert environment_0.stdin_isatty == True
    assert environment_1.colors == 12
    assert environment_1.stdin_isatty == False
    assert environment_2.colors == 16
    assert environment_2.stdin_isatty == True
    assert environment_3.colors == 16
    assert environment_3.stdin_isatty == False

# Generated at 2022-06-25 18:16:54.827894
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert(env.is_windows == False)
    assert(env.config_dir == DEFAULT_CONFIG_DIR)
    assert(env.stdin == sys.stdin)
    #assert(env.stdin_isatty == False)
    assert(env.stdin_encoding == sys.stdin.encoding)
    assert(env.stdout == sys.stdout)
    assert(env.stdout_isatty == True)
    assert(env.stdout_encoding == sys.stdout.encoding)
    assert(env.stderr == sys.stderr)
    assert(env.stderr_isatty == True)
    assert(env.colors == 256)
    assert(env.program_name == 'http')


# Generated at 2022-06-25 18:17:10.497296
# Unit test for constructor of class Environment
def test_Environment():
    # Instance an environment
    env = Environment()
    assert isinstance(env, Environment)

    # Unit test for attribute is_windows
    assert env.is_windows == is_windows
    assert env.is_windows == os.name == 'nt'

    # Unit test for attribute config_dir
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.config_dir == Path.home() / '.config' / 'httpie'

    # Unit test for attribute stdin
    # for case that stdin is None
    env2 = Environment(stdin=None)
    assert env2.stdin is None

    # for case that stdin is not None
    assert env.stdin == sys.stdin
    assert env.stdin is sys.stdin

    # Unit test for attribute stdin_isatty
   

# Generated at 2022-06-25 18:17:11.447374
# Unit test for constructor of class Environment
def test_Environment():
    Environment(is_windows=False)



# Generated at 2022-06-25 18:17:19.952257
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert not (hasattr(env, '_something'))
    env = Environment(stdin=None, _something=4)
    assert hasattr(env, '_something')
    assert env._something == 4
    env = Environment(stdin=None, stdout=None, stderr=None)
    assert env.stdin is None
    assert env.stdout is None
    assert env.stderr is None
    env = Environment(stdin=None, stdout=io.StringIO(), stderr=io.StringIO())
    assert isinstance(env.stdout, io.StringIO)
    assert isinstance(env.stderr, io.StringIO)
    env = Environment(stdin=None, stdout_encoding= 'utf16')

# Generated at 2022-06-25 18:17:29.538110
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(
        is_windows = False,
        config_dir = Path('/home/a15198').resolve(),
        stdin = sys.stdin,
        stdin_isatty = True,
        stdin_encoding = None,
        stdout = sys.stdout,
        stdout_isatty = True,
        stdout_encoding = None,
        stderr = sys.stderr,
        stderr_isatty = True,
        program_name = 'test',
        colors = 256,
        devnull = None
    )


# Generated at 2022-06-25 18:17:40.826995
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment()
    # default attributes and directory

    assert e.is_windows == is_windows
    assert isinstance(e.config_dir, Path)
    assert e.stdin == sys.stdin
    assert e.stdout == sys.stdout
    assert e.stderr == sys.stderr

    # overwriting attributes
    e = Environment(devnull=True, stdin=None)
    assert e.devnull
    assert e.stdin is None
    assert e.stdin_isatty is False
    assert e.stdin_encoding is None
    assert e.devnull is not True
    assert isinstance(e.devnull, IO)

    # environment variables
    e = Environment(stdin=None, config_dir='/tmp')

# Generated at 2022-06-25 18:17:47.964467
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert(environment.is_windows == is_windows)
    assert(environment.config_dir == DEFAULT_CONFIG_DIR)
    assert(environment.stdin == sys.stdin)
    assert(environment.stderr == sys.stderr)
    assert(environment.stdout == sys.stdout)
    assert(environment.stdout_isatty == sys.stdout.isatty())
    assert(environment.stderr_isatty == sys.stderr.isatty())
    assert(environment.stdin_isatty == sys.stdin.isatty())

# Generated at 2022-06-25 18:17:57.369440
# Unit test for constructor of class Environment
def test_Environment():
    with Environment() as environment_1:
        assert environment_1.is_windows == False
        assert environment_1.config_dir == Path('/home/travis/.config/httpie/')
        assert environment_1.stdin == sys.stdin
        assert environment_1.stdin_isatty == False
        assert environment_1.stdin_encoding == 'utf8'
        assert environment_1.stdout == sys.stdout
        assert environment_1.stdout_isatty == True
        assert environment_1.stdout_encoding == 'utf8'
        assert environment_1.stderr == sys.stderr
        assert environment_1.stderr_isatty == True
        assert environment_1.colors == 256
        assert environment_1.program_name == 'http'
        assert environment

# Generated at 2022-06-25 18:18:02.729277
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    environment_1 = Environment(is_windows=False)
    environment_2 = Environment(stdin=None)
    environment_3 = Environment(stdout=None)
    environment_4 = Environment(stderr=None)
    environment_5 = Environment(colors=0)
    environment_6 = Environment(program_name="http")


# Generated at 2022-06-25 18:18:13.415736
# Unit test for constructor of class Environment
def test_Environment():
    # Real Environment
    env = Environment()
    assert env.__class__ == Environment
    assert env.is_windows == is_windows
    assert env.config_dir == Path.home() / '.config' / 'httpie'
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()

    # Environment with input
    env = Environment(stdin = "test")
    assert env.stdin == "test"

    # Environment with output

# Generated at 2022-06-25 18:18:14.661102
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert isinstance(environment, Environment)


# Generated at 2022-06-25 18:18:22.847262
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()



# Generated at 2022-06-25 18:18:24.039522
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()

# Generated at 2022-06-25 18:18:32.195515
# Unit test for constructor of class Environment

# Generated at 2022-06-25 18:18:43.492898
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.__dict__['stdin'] == sys.stdin
    assert env.__dict__['stdin_isatty'] == sys.stdin.isatty()
    assert env.__dict__['stdout'] == sys.stdout
    assert env.__dict__['stdout_isatty'] == sys.stdout.isatty()
    assert env.__dict__['stderr'] == sys.stderr
    assert env.__dict__['stderr_isatty'] == sys.stderr.isatty()
    assert env.__dict__['config_dir'] == DEFAULT_CONFIG_DIR
    assert isinstance(env.config, Config)
    assert env.__dict__['program_name'] == 'http'

# Generated at 2022-06-25 18:18:46.412952
# Unit test for constructor of class Environment
def test_Environment():
    with pytest.raises(AssertionError):
        Environment(attrs = 'test')
    with pytest.raises(AssertionError):
        Environment(attrs = ['test', 'test2'])


# Generated at 2022-06-25 18:18:47.218809
# Unit test for constructor of class Environment
def test_Environment():
    Environment()


# Generated at 2022-06-25 18:18:49.094640
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=1, config_dir=2)
    assert env.devnull == 1
    assert env.config_dir == 2

# Generated at 2022-06-25 18:18:56.067277
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    environment_1 = Environment(program_name = 'http' , devnull = None, config_dir = Path('~/.config/httpie'), stdin = sys.stdin, stdin_isatty = sys.stdin.isatty(), stderr = sys.stderr, stdin_encoding = sys.stdin.encoding, stdout_isatty = sys.stdout.isatty(), stdout_encoding = sys.stdout.encoding, stderr_isatty = sys.stderr.isatty())


# Generated at 2022-06-25 18:18:57.523713
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().config_dir == DEFAULT_CONFIG_DIR


# Generated at 2022-06-25 18:18:59.250777
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()
    assert isinstance(environment_1, Environment)



# Generated at 2022-06-25 18:19:09.214908
# Unit test for constructor of class Environment
def test_Environment():
    with pytest.raises(AssertionError):
        test_case_0()
    environment_0 = Environment.is_windows
    assert environment_0
    environment_0 = Environment.config_dir
    assert environment_0.resolve() == Path('~/.httpie').expanduser()
    environment_1 = Environment.stdout_encoding
    assert environm

# Generated at 2022-06-25 18:19:17.168472
# Unit test for constructor of class Environment
def test_Environment():
    print("Unit test for constructor of class Environment")
    environment_0 = Environment()
    assert environment_0.stdin.isatty() == sys.stdin.isatty()
    assert environment_0.stdin_isatty == sys.stdin.isatty()
    assert environment_0.stdout.isatty() == sys.stdout.isatty()
    assert environment_0.stdout_isatty == sys.stdout.isatty()
    assert environment_0.stderr.isatty() == sys.stderr.isatty()
    assert environment_0.stderr_isatty == sys.stderr.isatty()


# Generated at 2022-06-25 18:19:28.236633
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()

    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout_encoding == 'utf8'
    assert env.stderr == sys.stderr
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout_isatty == sys.stdout.isatty()

# Generated at 2022-06-25 18:19:35.754311
# Unit test for constructor of class Environment
def test_Environment():

    environment_1 = Environment(
        is_windows=True,
        config_dir=Path('/home/local/BINF/cliu17/.httpie/config.json'),
        stdin=sys.stdin,
        stdin_isatty=True,
        stdin_encoding=None,
        stdout=sys.stdout,
        stdout_isatty=True,
        stdout_encoding=None,
        stderr=sys.stderr,
        stderr_isatty=True,
        colors=256,
        program_name='http'
    )


# Generated at 2022-06-25 18:19:42.599149
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment
    env = Environment()
    assert isinstance(env, Environment)
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == bool(sys.stdin.isatty())
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == bool(sys.stdout.isatty())
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == bool(sys.stderr.isatty())
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._devnull == None
    assert env._config == None
    #assert env

# Generated at 2022-06-25 18:19:46.392122
# Unit test for constructor of class Environment
def test_Environment():
    for attribute in dir(Environment):
        if not attribute.startswith('__'):
            assert type(eval(attribute)) == type(eval('environment_0.' + attribute))

# unit test for __str__()

# Generated at 2022-06-25 18:19:55.164600
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()
    environment_2 = Environment(config_dir="c:\\Httpie")
    environment_3 = Environment(devnull = "c:\\Httpie\\devnull", config_dir = "c:\\Httpie\\", stdin = "c:\\Httpie\\stdin.txt", stdin_isatty = True, stdin_encoding = "UTF-8", stdout = "c:\\Httpie\\stdout.txt", stdout_isatty = False, stdout_encoding = "UTF-16", stderr = "c:\\Httpie\\stderr.txt", stderr_isatty = True, colors = 4800, program_name = "HTTP")


# Generated at 2022-06-25 18:19:56.729308
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().__class__.__name__ == "Environment"

# Generated at 2022-06-25 18:19:58.506750
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().program_name == "http"

# Generated at 2022-06-25 18:20:02.211386
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(is_windows=True, config_dir=".httpie")

# Test whether is_windows attribute is correctly set

# Generated at 2022-06-25 18:20:11.569887
# Unit test for constructor of class Environment
def test_Environment():
    devnull = None
    environment = Environment(devnull)
    assert environment.devnull == devnull
    assert environment.devnull_write == devnull.write
    assert environment.is_windows == is_windows
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == sys.stdin.isatty()
    assert environment.stdin_encoding == None
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == sys.stdout.isatty()
    assert environment.stdout_encoding == None
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == sys.stderr.isatty()

# Generated at 2022-06-25 18:20:21.803000
# Unit test for constructor of class Environment
def test_Environment():

    environment_1 = Environment(
        config_dir = "../httpie/config_dir",
        stdin = "stdin",
        stdin_isatty = True,
        stdin_encoding = "stdin_encoding",
        stdout = "stdout",
        stdout_isatty = True,
        stdout_encoding = "stdout_encoding",
        stderr = "stderr",
        stderr_isatty = True,
        colors = 256,
        program_name = "program_name",
        devnull = "devnull"
    )

    assert (environment_1.config_dir == "../httpie/config_dir")
    assert (environment_1.stdin == "stdin")
    assert (environment_1.stdin_isatty == True)
   

# Generated at 2022-06-25 18:20:27.500015
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin == sys.stdin
    assert environment.stdout == sys.stdout
    assert environment.stderr == sys.stderr
    assert environment.colors == 256
    assert environment.program_name == 'http'


# Generated at 2022-06-25 18:20:28.973004
# Unit test for constructor of class Environment
def test_Environment():
    assert test_case_0() == None

test_Environment()

# Generated at 2022-06-25 18:20:36.151763
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows is False
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin.buffer.fileno() == sys.__stdin__.buffer.fileno()
    assert environment.stdin_isatty is True
    assert environment.stdin_encoding == 'utf-8'
    assert environment.stdout.buffer.fileno() == sys.__stdout__.buffer.fileno()
    assert environment.stdout_isatty is True
    assert environment.stdout_encoding == 'utf-8'
    assert environment.stderr.buffer.fileno() == sys.__stderr__.buffer.fileno()
    assert environment.stderr_isatty is True
    assert environment.program_name == 'http'

# Unit

# Generated at 2022-06-25 18:20:41.699872
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(devnull="file")
    environment_2 = Environment()
    assert isinstance(environment_1,Environment)
    assert isinstance(environment_2,Environment)
    assert environment_2.is_windows == False
    assert environment_2.colors == 256
    assert environment_2.program_name == "http"


# Generated at 2022-06-25 18:20:47.816543
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.is_windows == is_windows
    assert environment_0.stdin == sys.stdin
    assert environment_0.stdin_isatty == environment_0.stdin.isatty()
    assert environment_0.stdin_encoding == None
    assert environment_0.stdout == sys.stdout
    assert environment_0.stdout_isatty == environment_0.stdout.isatty()
    assert environment_0.stdout_encoding == None
    assert environment_0.stderr == sys.stderr
    assert environment_0.stderr_isatty == environment_0.stderr.isatty()
    assert environment_0.program_name == 'http'
    assert environment_0._orig_stderr == environment_

# Generated at 2022-06-25 18:20:58.609980
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    if environment_0.is_windows:
        environment_0.config_dir = Path(r'C:\Users\user\AppData\Roaming\.config\httpie')
    else:
        environment_0.config_dir = Path(r"/home/user/.config/httpie")
    environment_0.stdin = sys.stdin
    environment_0.stdin_isatty = True
    environment_0.stdin_encoding = 'utf8'
    environment_0.stdout = sys.stdout
    environment_0.stdout_isatty = True
    environment_0.stdout_encoding = 'utf8'
    environment_0.stderr = sys.stderr
    environment_0.stderr_isatty = True
    environment_0.colors

# Generated at 2022-06-25 18:21:05.481892
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment()
    assert e.stderr
    assert e.stdout
    assert e.stdin
    assert e.config_dir
    assert e.is_windows
    assert e.stdin_isatty
    assert e.stdin_encoding
    assert e.stdout_isatty
    assert e.stdout_encoding
    assert e.stderr_isatty
    assert e.colors
    assert e.program_name

# Unit Test for method log_error

# Generated at 2022-06-25 18:21:12.977687
# Unit test for constructor of class Environment
def test_Environment():
    if is_windows:
        environ = Environment(is_windows=True,
                    stdin=None,
                    stdin_isatty=False,
                    stdin_encoding=None,
                    stdout=sys.stdout,
                    stdout_isatty=True,
                    stdout_encoding='utf8',
                    stderr=sys.stderr,
                    stderr_isatty=True,
                    colors=256,
                    program_name='http',
                    config_dir=Path('C:\\Users\\zhaoxu\\.config\\httpie'),
                    devnull=None)

# Generated at 2022-06-25 18:21:18.739462
# Unit test for constructor of class Environment
def test_Environment():
	environment_0 = Environment()
	assert isinstance(environment_0, Environment) is True

# Generated at 2022-06-25 18:21:20.114613
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()
    print("All tests passed")


# Generated at 2022-06-25 18:21:28.580143
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(is_windows=True, config_dir=DEFAULT_CONFIG_DIR, stdin=sys.stdin, stderr=sys.stderr, stdout=sys.stdout, program_name='hdfs')
    assert environment.is_windows == True
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin == sys.stdin
    assert environment.stderr == sys.stderr
    assert environment.stdout == sys.stdout
    assert environment.program_name == 'hdfs'


if __name__ == "__main__":
    test_Environment()

# Generated at 2022-06-25 18:21:35.077515
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    # Test environments of terminal, file and devnull
    env = Environment(stdout=open("test_no_tty", "w"))
    env = Environment(stdout=Path("test_no_tty"))
    env = Environment(stdout=os.open("test_no_tty", os.O_WRONLY | os.O_CREAT))
    env = Environment(stdout=os.fdopen(os.open("test_no_tty", os.O_WRONLY | os.O_CREAT), "w"))
    env = Environment(stdout=open("/dev/tty", "w"))
    env = Environment(stdout=open("/dev/null", "w"))

# Generated at 2022-06-25 18:21:39.010641
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=3, stdout=2, stderr=1)
    assert env.stdin == 3
    assert env.stdout == 2
    assert env.stderr == 1


# Generated at 2022-06-25 18:21:48.396377
# Unit test for constructor of class Environment
def test_Environment():
    # Check attributes
    assert_equal(environment_0.is_windows, Environment.is_windows)
    assert_equal(environment_0.config_dir, Environment.config_dir)
    assert_equal(environment_0.stdin, Environment.stdin)
    assert_equal(environment_0.stdin_isatty, Environment.stdin_isatty)
    assert_equal(environment_0.stdin_encoding, Environment.stdin_encoding)
    assert_equal(environment_0.stdout, Environment.stdout)
    assert_equal(environment_0.stdout_isatty, Environment.stdout_isatty)
    assert_equal(environment_0.stdout_encoding, Environment.stdout_encoding)

# Generated at 2022-06-25 18:21:50.103049
# Unit test for constructor of class Environment
def test_Environment():
    try:
        environment_0 = Environment()
    except:
        return False
    return True


# Generated at 2022-06-25 18:21:57.537091
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.is_windows == True
    assert environment_0.config_dir == Path.home() / '.config' / 'httpie'
    assert environment_0.stdin == sys.stdin
    assert environment_0.stdin_isatty == False
    assert environment_0.stdin_encoding == 'utf8'
    assert environment_0.stdout == sys.stdout
    assert environment_0.stdout_isatty == True
    assert environment_0.stdout_encoding == 'utf8'
    assert environment_0.stderr == sys.stderr
    assert environment_0.stderr_isatty == True
    assert environment_0.stderr_encoding == 'utf8'
    assert environment_0.colors == 256

# Generated at 2022-06-25 18:21:59.196394
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment


# Generated at 2022-06-25 18:22:06.252490
# Unit test for constructor of class Environment
def test_Environment():
    with pytest.raises(AssertionError):
        environment_1 = Environment(**{'devnull': None, 'a': 'b'})
    # noinspection PyTypeChecker
    environment_2 = Environment(**{'devnull': None})
    assert environment_2.stdin_isatty() == sys.stdin.isatty()
    assert environment_2._orig_stderr == sys.stderr



# Generated at 2022-06-25 18:22:23.447133
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(colors=256, is_windows=False, stdin=sys.stdin, 
                                stderr=sys.stderr, stdin_isatty=True, stdout_isatty=True, 
                                config_dir=Path(DEFAULT_CONFIG_DIR), stderr_isatty=True, 
                                program_name='http', stdout=sys.stdout)
    assert environment_1.colors == 256
    assert environment_1.is_windows == False
    assert environment_1.stdin == sys.stdin
    assert environment_1.stderr == sys.stderr
    assert environment_1.stdin_isatty == True
    assert environment_1.stdout_isatty == True
    assert environment_1.config_dir == Path

# Generated at 2022-06-25 18:22:35.424418
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull = open(os.devnull, 'w+'))
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin  # `None` when closed fd (#791)
    assert env.stdin_isatty == sys.stdin.isatty() if sys.stdin else False
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env

# Generated at 2022-06-25 18:22:39.489883
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(
        is_windows=False,
        config_dir=Path("C:/httpie/config"),
        stdin=None,
        stdin_isatty=False,
        stdin_encoding=None,
        stdout=None,
        stdout_isatty=False,
        stdout_encoding=None,
        stderr=None,
        stderr_isatty=False,
        colors=256,
        program_name='http')
    environment_1.log_error("test_error")
    environment_1.devnull = None



# Generated at 2022-06-25 18:22:49.632124
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows == is_windows
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == sys.stdin.isatty()
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == sys.stdout.isatty()
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == sys.stderr.isatty()
    assert environment.colors == 256
    assert environment.program_name == 'http'
    assert environment._orig_stderr == sys.stderr
    assert environment._devnull == None


# Generated at 2022-06-25 18:22:54.699264
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.config_dir == Path.home() / ".httpie"
    assert environment_0.stdin == 'null'
    assert environment_0.stdout == 'null'
    assert environment_0.stderr == 'null'


# Generated at 2022-06-25 18:23:04.082400
# Unit test for constructor of class Environment
def test_Environment():
    stdin = open("test_input.txt","rb")
    sys.stdin.close()
    os.dup2(stdin.fileno(),sys.stdin.fileno())
    stdin.close()
    stdout = open("test_output.txt","w")
    os.dup2(stdout.fileno(),sys.stdout.fileno())
    stdout.close()
    environment = Environment(is_windows = True,
                                      config_dir = "/usr/config",
                                      program_name = "httpie",
                                      devnull = "DevNull",
                                      colors = 16,
                                      stderr = sys.stderr,
                                      stdout = sys.stdout,
                                      stdin = sys.stdin)
    print(environment)

# Generated at 2022-06-25 18:23:09.232269
# Unit test for constructor of class Environment
def test_Environment():
    # default constructor
    environment_0 = Environment()

    # return value check
    assert environment_0
    assert environment_0._devnull == None
    assert environment_0._config == None
    assert environment_0._orig_stderr == sys.stderr
    assert environment_0.is_windows == True
    assert environment_0.config_dir == Path(DEFAULT_CONFIG_DIR)
    assert environment_0.stdin == sys.stdin
    assert environment_0.stdin_isatty == True
    assert environment_0.stdin_encoding == 'utf8'
    assert environment_0.stdout == sys.stdout
    assert environment_0.stdout_isatty == True
    assert environment_0.stdout_encoding == 'utf8'

# Generated at 2022-06-25 18:23:19.633429
# Unit test for constructor of class Environment
def test_Environment():
    current_stdin = sys.stdin
    my_stdin = open('test_input.txt', 'r')
    current_stdout = sys.stdout
    my_stdout = open('test_stdout.txt', 'w')
    current_stderr = sys.stderr
    my_stderr = open('test_stderr.txt', 'w')
    my_devnull = open('test_devnull.txt', 'w')
    my_config_dir = os.getcwd() + '\config'

    instance_1 = Environment()
    if instance_1.stdin != current_stdin:
        print('test_Environment() failed with instance_1.stdin')

# Generated at 2022-06-25 18:23:22.591550
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(program_name='http')
    environment_2 = Environment(program_name='http')
    print('%s, %s' % (environment_1, environment_2))
    assert environment_1 is environment_2

# Generated at 2022-06-25 18:23:27.140548
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(program_name='http')
    #print('actual:{}'.format(repr_dict(environment.__dict__)))
    #print('expected:{}'.format(repr_dict(type(environment).__dict__)))
    assert repr_dict(environment.__dict__) == repr_dict(type(environment).__dict__)


# Generated at 2022-06-25 18:23:40.654217
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(devnull=None, is_windows=False, config_dir='~/.config/httpie', stdin=None,
                                stdin_isatty=True, stdout='stdout', stdout_isatty=False,
                                stderr='stderr', stderr_isatty=False, colors=256, program_name='http')
    assert environment_1.devnull is not None


# Generated at 2022-06-25 18:23:41.749046
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    # it should not raise any exception



# Generated at 2022-06-25 18:23:44.272559
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-25 18:23:51.221042
# Unit test for constructor of class Environment
def test_Environment():
    stdin = sys.stdin
    stdout = sys.stdout
    stderr = sys.stderr

    test_args = {"stdin": stdin, "stdout": stdout, "stderr": stderr}
    environment_1 = Environment(**test_args)
    assert environment_1.stdin is stdin
    assert environment_1.stdout is stdout
    assert environment_1.stderr is stderr


# Generated at 2022-06-25 18:24:01.930766
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment()
    assert e.is_windows == is_windows
    assert e.config_dir == DEFAULT_CONFIG_DIR
    assert e.stdin == sys.stdin
    assert e.stdin_isatty == bool(sys.stdin.isatty())
    assert e.stdout == sys.stdout
    assert e.stdout_isatty == bool(sys.stdout.isatty())
    assert e.stderr == sys.stderr
    assert e.stderr_isatty == bool(sys.stderr.isatty())
    if curses:
        assert e.colors == curses.tigetnum('colors') or 0
    assert not isinstance(e.devnull, str)
    assert e.program_name == 'http'


# Generated at 2022-06-25 18:24:03.229248
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()
 
print("Unit test for class Environment: Success")

# Generated at 2022-06-25 18:24:08.666279
# Unit test for constructor of class Environment
def test_Environment():
    try:
        config_dir_orig = environment_0.config_dir
        environment_0 = Environment(config_dir = '/tmp/config')
        assert environment_0.config_dir != config_dir_orig
        assert environment_0.config_dir == '/tmp/config'
        assert isinstance(environment_0, Environment)
    except Exception as e:
        print("Test failed at test_Environment",e)
        assert False



# Generated at 2022-06-25 18:24:14.856209
# Unit test for constructor of class Environment
def test_Environment():
    from httpie.core import main
    from . import HTTP_OK
    env = Environment()
    env.config.default_options.timeout = 0.001
    env.config.default_options.verify = False
    env.config.default_options.allow_redirects = False
    env.config.default_options.headers = {"User-Agent":"http.py"}
    env.config.default_options.auth = None
    env.config.default_options.follow_redirects = True
    env.config.default_options.max_redirects = 10
    env.config.default_options.timeout = None
    env.config.default_options.max_timeout = 30
    env.config.default_options.headers = {"User-Agent":"http.py"}
    env.config.default_options.verify = True

# Generated at 2022-06-25 18:24:22.116613
# Unit test for constructor of class Environment
def test_Environment():
    # Initialize the class
    test_env = Environment()

    # Check if the initialization is correct
    assert test_env.is_windows is False
    assert test_env.config_dir is DEFAULT_CONFIG_DIR
    assert test_env.stdin_isatty is True
    assert test_env.stdin_encoding is None
    assert test_env.stdout_isatty is True
    assert test_env.stdout_encoding is None
    assert test_env.stderr_isatty is True
    assert test_env.colors is 256
    assert test_env.program_name is 'http'
    assert test_env._orig_stderr is sys.stderr
    assert test_env._devnull is None
    assert test_env._config is None



# Generated at 2022-06-25 18:24:27.515214
# Unit test for constructor of class Environment
def test_Environment():
    devnull = open(os.devnull, 'w+')
    Stream = StringIO
    environment_1 = Environment(
        stdin=Stream(),
        stdout=Stream(),
        stderr=Stream(),
        devnull=devnull
    )
    assert environment_1.stdin
    assert environment_1.stdout
    assert environment_1.stderr
    assert environment_1.devnull



# Generated at 2022-06-25 18:24:37.599366
# Unit test for constructor of class Environment
def test_Environment():
    """Check whether the constructor of class Environment works"""
    assert Environment().__init__()

# Generated at 2022-06-25 18:24:44.596469
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert isinstance(env, Environment)
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin_isatty == sys.stdin.isatty() if sys.stdin else False
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'


# Generated at 2022-06-25 18:24:46.780846
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdout=sys.stdout)
    assert env.stdout_encoding == 'UTF-8'
    assert env.stdout == sys.stdout
    assert env.stdout.encoding == 'UTF-8'

# Generated at 2022-06-25 18:24:56.308704
# Unit test for constructor of class Environment
def test_Environment():
    with Environment(devnull=None, stdout_encoding=None, stderr_encoding=None, colors=256, program_name='http') as environment:
        assert environment.devnull == None
        assert environment.stdout_encoding == None
        assert environment.stderr_encoding == None
        assert environment.colors == 256
        assert environment.program_name == 'http'

# Generated at 2022-06-25 18:25:06.935587
# Unit test for constructor of class Environment
def test_Environment():

    assert Environment().is_windows == is_windows
    assert Environment().config_dir == DEFAULT_CONFIG_DIR
    assert Environment().stdin == sys.stdin
    assert Environment().stdin_isatty == sys.stdin.isatty()
    assert Environment().stdin_encoding == None
    assert Environment().stdout == sys.stdout
    assert Environment().stdout_isatty == sys.stdout.isatty()
    assert Environment().stdout_encoding == None
    assert Environment().stderr == sys.stderr
    assert Environment().stderr_isatty == sys.stderr.isatty()
    assert Environment().colors == 256
    assert Environment().program_name == 'http'
    assert Environment()._orig_stderr == sys.stderr
    assert Environment()._dev

# Generated at 2022-06-25 18:25:13.282887
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(
        devnull=3,
        is_windows=True,
        config_dir=Path('~/.config/httpie/'),
        stdin=open('data.txt', 'r'),
        stdin_isatty=False,
        stdin_encoding="utf-8",
        stdout=sys.stdout,
        stdout_isatty=True,
        stdout_encoding=None,
        stderr=sys.stderr,
        stderr_isatty=False,
        colors=8,
        program_name="http"
    )
    print(environment_1)                      # Expected output: {
                                              # 'is_windows': True,
                                              # 'config_dir': '~/.config/httpie/',
                                              # '

# Generated at 2022-06-25 18:25:16.802412
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    environment = Environment(stdin=sys.stdin, stdout=sys.stdout,
                              stderr=sys.stderr)
    environment = Environment(devnull=sys.stderr)

# Generated at 2022-06-25 18:25:26.423610
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment(stderr_isatty=True, stdout_isatty=True, stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr, is_windows=False, stdout_encoding='utf8', stdin_encoding='utf8', stdin_isatty=True)
    assert environment_0.stderr_isatty == True
    assert environment_0.stdout_isatty == True
    assert environment_0.stdin == sys.stdin
    assert environment_0.stdout == sys.stdout
    assert environment_0.stderr == sys.stderr
    assert environment_0.is_windows == False
    assert environment_0.stdout_encoding == 'utf8'
    assert environment_0.stdin_