

# Generated at 2022-06-25 18:15:39.935866
# Unit test for constructor of class Environment
def test_Environment():
    try:
        # test case 1
        environment = Environment(
            devnull=True,
            is_windows=True,
            config_dir='C:/config',
            stdin=None,
            stdin_isatty=False,
            stdin_encoding='utf-8',
            stdout=sys.stdout,
            stdout_isatty=True,
            stdout_encoding='utf-8',
            stderr=sys.stderr,
            stderr_isatty=True,
            colors=128,
            program_name='http'
        )
        assert environment != None
    except:
        print('Exception raised in test_Environment() test case 1')



# Generated at 2022-06-25 18:15:46.287260
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(is_windows=True,config_dir=Path("~/.httpie"),stdin=sys.stdin, stderr=sys.stderr, stdout=sys.stdout)
    assert environment.is_windows == True
    assert environment.config_dir == Path("~/.httpie")
    assert environment.stdin == sys.stdin
    assert environment.stderr == sys.stderr
    assert environment.stdout == sys.stdout


# Generated at 2022-06-25 18:15:48.351836
# Unit test for constructor of class Environment
def test_Environment():
    assert isinstance(Environment(), Environment)
    assert Environment().devnull == None


# Generated at 2022-06-25 18:15:56.698000
# Unit test for constructor of class Environment
def test_Environment():
    import httpie.core
    env = httpie.core.Environment()
    assert env.is_windows is False
    assert env.config_dir == Path(DEFAULT_CONFIG_DIR)
    assert env.stdin is sys.stdin
    assert env.stdout is sys.stdout
    assert env.stderr is sys.stderr
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr is sys.stderr
    assert env._devnull is None
    assert env._config is None

# Generated at 2022-06-25 18:16:02.172412
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()
    assert environment_1.is_windows == is_windows
    assert environment_1.config_dir == DEFAULT_CONFIG_DIR
    assert environment_1.stdin == sys.stdin
    assert environment_1.stdin_isatty == (sys.stdin.isatty() if sys.stdin else False)
    assert environment_1.stdout == sys.stdout
    assert environment_1.stdout_isatty == sys.stdout.isatty()
    assert environment_1.stderr == sys.stderr
    assert environment_1.stderr_isatty == sys.stderr.isatty()
    assert environment_1.colors == 256
    assert environment_1.program_name == 'http'

# Unit tests for method __init__ of

# Generated at 2022-06-25 18:16:12.331502
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment.is_windows is is_windows
    assert Environment.config_dir == DEFAULT_CONFIG_DIR
    assert Environment.stdin == sys.stdin
    assert Environment.stdin_isatty == stdin.isatty()
    assert Environment.stdin_encoding == None
    assert Environment.stdout == sys.stdout
    assert Environment.stdout_isatty == stdout.isatty()
    assert Environment.stdout_encoding == None
    assert Environment.stderr == sys.stderr
    assert Environment.stderr_isatty == stderr.isatty()
    assert Environment.colors == 256
    assert Environment.program_name == 'http'


# Generated at 2022-06-25 18:16:14.671787
# Unit test for constructor of class Environment
def test_Environment():
    assert environment_0.is_windows == is_windows

if __name__ == "__main__":
    test_case_0()
    test_Environment()

# Generated at 2022-06-25 18:16:21.535058
# Unit test for constructor of class Environment
def test_Environment():
    test_stdin = sys.stdin
    test_stdout = sys.stdout
    test_stderr = sys.stderr
    test_config_dir = os.path.join(DEFAULT_CONFIG_DIR, "test")
    
    test_flags = {
        'stdin': test_stdin, 
        'stdout': test_stdout, 
        'stderr': test_stderr, 
        'config_dir': test_config_dir
    }
    test_environment = Environment(**test_flags)

    assert test_environment.is_windows == is_windows
    assert test_environment.config_dir == test_config_dir
    assert test_environment.stdin == test_stdin

# Generated at 2022-06-25 18:16:23.795707
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()
    assert environment_1 != None


# Generated at 2022-06-25 18:16:32.766902
# Unit test for constructor of class Environment
def test_Environment():
    x = Environment()
    assert x.is_windows == True
    assert x.config_dir == Path('.httpie')
    assert x.stdin == sys.stdin
    assert x.stdin_isatty == True
    assert x.stdin_encoding == 'utf8'
    assert x.stdout == sys.stdout
    assert x.stdout_isatty == True
    assert x.stdout_encoding == 'utf8'
    assert x.stderr == sys.stderr
    assert x.stderr_isatty == True
    assert x.colors == 256
    assert x.program_name == 'http'



# Generated at 2022-06-25 18:16:40.590957
# Unit test for constructor of class Environment
def test_Environment():
    try:
        environment_0 = Environment()
    except AssertionError as e:
        print('Error test_Environment(): Exception type: ' + str(type(e)))
        print('Exception message: ' + str(e))
        sys.exit(-1)


# Generated at 2022-06-25 18:16:51.130842
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment.is_windows == is_windows
    assert Environment.config_dir == Path(DEFAULT_CONFIG_DIR)
    assert Environment.stdin == sys.stdin
    assert Environment.stdin_isatty == sys.stdin.isatty()
    assert Environment.stdin_encoding == sys.stdin.encoding
    assert Environment.stdout == sys.stdout
    assert Environment.stdout_isatty == sys.stdout.isatty()
    assert Environment.stdout_encoding == sys.stdout.encoding
    assert Environment.stderr == sys.stderr
    assert Environment.stderr_isatty == sys.stderr.isatty()
    assert Environment.program_name == 'http'


# Generated at 2022-06-25 18:16:59.790629
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert type(env) is Environment

# Generated at 2022-06-25 18:17:07.050554
# Unit test for constructor of class Environment
def test_Environment():
    import tempfile
    with tempfile.TemporaryFile('w+') as f:
        environment = Environment(
            stdin=f,
            stdin_isatty=False,
            stdin_encoding='utf-8',
            stdout=f,
            stdout_isatty=False,
            stdout_encoding='utf-8',
            stderr=f,
            stderr_isatty=False,
            colors=256,
            program_name='http'
        )



# Generated at 2022-06-25 18:17:08.214722
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()


# Generated at 2022-06-25 18:17:17.098015
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment.is_windows == is_windows
    assert Environment.config_dir == DEFAULT_CONFIG_DIR
    assert Environment.stdin == sys.stdin
    assert Environment.stdin_isatty == sys.stdin.isatty() if sys.stdin else False
    assert Environment.stdin_encoding == None
    assert Environment.stdout == sys.stdout
    assert Environment.stdout_isatty == sys.stdout.isatty()
    assert Environment.stdout_encoding == None
    assert Environment.stderr == sys.stderr
    assert Environment.stderr_isatty == sys.stderr.isatty()
    assert Environment.colors == 256
    assert Environment.program_name == "http"



# Generated at 2022-06-25 18:17:21.782567
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment(program_name = "", colors = None, stderr_encoding=None, is_windows=False, config_dir=DEFAULT_CONFIG_DIR, stdin = None, stdin_isatty=False, stdin_encoding="utf8", stdout = sys.stdout, stdout_isatty=False, stdout_encoding="utf8", stderr = sys.stderr, stderr_isatty=False)
    print(environment_0)

# Generated at 2022-06-25 18:17:32.364332
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.is_windows == is_windows
    assert environment_0.config_dir == DEFAULT_CONFIG_DIR
    assert environment_0.stdin == sys.stdin
    assert environment_0.stdin_isatty == True
    assert environment_0.stdout == sys.stdout
    assert environment_0.stdout_isatty == True
    assert environment_0.stderr == sys.stderr
    assert environment_0.stderr_isatty == True
    assert environment_0.colors == 256
    assert environment_0.program_name == 'http'
    assert environment_0._devnull is None
    assert environment_0._config is None
    assert environment_0._orig_stderr == sys.stderr
    assert environment_0

# Generated at 2022-06-25 18:17:42.296253
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(devnull = 1)
    environment_2 = Environment()
    environment_3 = Environment(is_windows = True)
    environment_4 = Environment(config_dir = True, stdin = sys.stdout, stdin_isatty = True, stdin_encoding = 'utf8', stdout = sys.stdout, 
    stdout_isatty = True, stdout_encoding = 'utf8', stderr = sys.stderr, stderr_isatty = True, stderr_encoding = 'utf8', colors = 256,
    program_name = 'http')
    # All these should not raise any exception


# Generated at 2022-06-25 18:17:51.530744
# Unit test for constructor of class Environment
def test_Environment():
    import httpie.config
    from httpie.compat import is_windows
    from httpie.compat import stdin, stdout, stderr
    from pathlib import Path
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == httpie.config.DEFAULT_CONFIG_DIR
    assert env.stdin == stdin
    assert env.stdin_isatty == stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == stdout
    assert env.stdout_isatty == stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == stderr
    assert env.stderr_isatty == stderr.isatty()
   

# Generated at 2022-06-25 18:18:01.297022
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    environment_streams = [
        environment_0.stdin, environment_0.stdout, environment_0.stderr
    ]
    environment_isatty = [
        environment_0.stdin_isatty, environment_0.stdout_isatty, environment_0.stderr_isatty
    ]
    environment_encoding = [
        environment_0.stdin_encoding, environment_0.stdout_encoding
    ]
    environment_name = ['stdin', 'stdout', 'stderr']
    name = ['stdin_isatty', 'stdout_isatty', 'stderr_isatty']
    name2 = ['stdin_encoding', 'stdout_encoding']
    assert environment_0.is_windows == False

# Generated at 2022-06-25 18:18:02.729848
# Unit test for constructor of class Environment
def test_Environment():
    assert type(Environment()) is Environment

# Generated at 2022-06-25 18:18:07.651169
# Unit test for constructor of class Environment
def test_Environment():
    #assert Environment()
    assert Environment(stdin=False)
    assert Environment(stdin=StringIO(''))
    assert Environment(stdin=StringIO('123'))
    assert Environment(stdin=StringIO('123')).stdin.isatty()
    assert Environment(stdin=StringIO('123')).stdin_isatty
    assert Environment(stdin=StringIO('123')).stdin_encoding
    assert Environment(stdin=StringIO('123'), stdin_encoding='utf-8')
    assert Environment(stdin=StringIO('123'), stdin_encoding=None)
    assert Environment(stdout=StringIO(''))
    assert Environment(stderr=StringIO(''))
    assert Environment(devnull=None)

# Generated at 2022-06-25 18:18:16.227570
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()
    environment_2 = Environment(devnull='test')
    environment_3 = Environment(config_dir='test')
    environment_4 = Environment(stdin='test')
    environment_5 = Environment(stdin_isatty='test')
    environment_6 = Environment(stdin_encoding='test')
    environment_7 = Environment(stdout='test')
    environment_8 = Environment(stdout_isatty='test')
    environment_9 = Environment(stdout_encoding='test')
    environment_10 = Environment(stderr='test')
    environment_11 = Environment(stderr_isatty='test')
    environment_12 = Environment(colors='test')
    environment_13 = Environment(program_name='test')


# Generated at 2022-06-25 18:18:27.709523
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()

    assert environment_0.is_windows == is_windows
    assert environment_0.config_dir == DEFAULT_CONFIG_DIR
    assert environment_0.stdin == sys.stdin
    assert environment_0.stdin_isatty == environment_0.stdin.isatty()
    assert environment_0.stdin_encoding is None
    assert environment_0.stdout == sys.stdout
    assert environment_0.stdout_isatty == environment_0.stdout.isatty()
    assert environment_0.stdout_encoding is None
    assert environment_0.stderr == sys.stderr
    assert environment_0.stderr_isatty == environment_0.stderr.isatty()
    assert environment_0.colors == 256

# Generated at 2022-06-25 18:18:34.641850
# Unit test for constructor of class Environment
def test_Environment():
    if (os.name == 'nt'):
        environment_win_0 = Environment()
        assert(environment_win_0.is_windows == True)
        assert(environment_win_0.config_dir == Path('C:\\Users\\jiawei\\.httpie'))
        assert(environment_win_0.stdin == sys.stdin)
        assert(environment_win_0.stdin_isatty == True)
        assert(environment_win_0.stdin_encoding == None)
        assert(environment_win_0.stdout == sys.stdout)
        assert(environment_win_0.stdout_isatty == True)
        assert(environment_win_0.stdout_encoding == None)
        assert(environment_win_0.stderr == sys.stderr)
       

# Generated at 2022-06-25 18:18:45.286450
# Unit test for constructor of class Environment
def test_Environment():

    # Test 1
    # Test conditions: 
    # 1. is_windows = True
    # 2. stdin_isatty = False
    # 3. stdout_isatty = False
    # 4. stderr_isatty = False
    environment_1 = Environment()
    assert environment_1.is_windows == True
    assert environment_1.stdin_isatty == False
    assert environment_1.stdout_isatty == False
    assert environment_1.stderr_isatty == False
    assert environment_1.stdin_encoding == 'utf8'
    assert environment_1.stdout_encoding == 'utf8'

    # Test 2
    # Test conditions: 
    # 1. is_windows = False
    # 2. stdin_isatty = True
    #

# Generated at 2022-06-25 18:18:51.566114
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.is_windows == is_windows
    assert environment_0.stdin == sys.stdin
    assert environment_0.stdout == sys.stdout
    assert environment_0.stderr == sys.stderr
    assert environment_0.stdin_isatty == sys.stdin.isatty() if sys.stdin else False
    assert environment_0.stdout_isatty == sys.stdout.isatty()
    assert environment_0.stderr_isatty == sys.stderr.isatty()
    assert environment_0.colors == 256
    assert environment_0.program_name == 'http'
    assert environment_0.stdin_encoding is None
    assert environment_0.stdout_encoding is None

# Generated at 2022-06-25 18:19:00.468792
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(is_windows=False, config_dir='/usr/local/etc/httpie',
                      stdin=sys.stdin, stdin_isatty=sys.stdin.isatty(),
                      stdout=sys.stdout, stdout_isatty=sys.stdout.isatty(),
                      stderr=sys.stderr, stderr_isatty=sys.stderr.isatty(),
                      colors=256, program_name='http')
    assert env.is_windows == False
    assert env.config_dir == Path('/usr/local/etc/httpie')
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout == sys.stdout
    assert env

# Generated at 2022-06-25 18:19:01.363607
# Unit test for constructor of class Environment
def test_Environment():
    assert isinstance(Environment(), Environment)

# Generated at 2022-06-25 18:19:12.814946
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0


# Generated at 2022-06-25 18:19:19.998148
# Unit test for constructor of class Environment
def test_Environment():
    # Ensures that test_case_0 can be executed without exception
    try:
        test_case_0()
    except:
        import sys
        print("test_case_0()", file=sys.stderr)
        raise
    # Ensures that the Environment instance being created has the correct information
    e = Environment()
    assert e.is_windows == is_windows
    assert e.config_dir == DEFAULT_CONFIG_DIR
    assert e.stdin == sys.stdin
    assert e.stdin_isatty == stdin.isatty()
    assert e.stdout == sys.stdout
    assert e.stdout_isatty == stdout.isatty()
    assert e.stderr == sys.stderr

# Generated at 2022-06-25 18:19:30.585130
# Unit test for constructor of class Environment
def test_Environment():
    # Test case: config_dir = DEFAULT_CONFIG_DIR, stdin = sys.stdin, stdout = sys.stdout,
    # stderr = sys.stderr, colors = 256, program_name = "http"
    assert Environment().config_dir == DEFAULT_CONFIG_DIR
    assert Environment().stdin == sys.stdin
    assert Environment().stdout == sys.stdout
    assert Environment().stderr == sys.stderr
    assert Environment().colors == 256
    assert Environment().program_name == "http"

    # Test case: config_dir = DEFAULT_CONFIG_DIR, stdin = sys.stdout, stdout = sys.stdout,
    # stderr = sys.stderr, colors = 256, program_name = "http"

# Generated at 2022-06-25 18:19:39.482066
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(
        devnull=os.devnull,
        is_windows=True,
        config_dir="httpie",
        stdin=sys.stdin,
        stdin_isatty=sys.stdin.isatty(),
        stdin_encoding=sys.stdin.encoding,
        stdout=sys.stdout,
        stdout_isatty=sys.stdout.isatty(),
        stdout_encoding=sys.stdout.encoding,
        stderr=sys.stderr,
        stderr_isatty=sys.stderr.isatty(),
        colors=256,
        program_name="http"
    )

    assert environment_1.is_windows is True and \
           environment_1.config_dir == "httpie"

# Generated at 2022-06-25 18:19:41.513402
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env is not None


# Generated at 2022-06-25 18:19:52.450410
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows == is_windows
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == sys.stdin.isatty()
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == sys.stdout.isatty()
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == sys.stderr.isatty()
    assert environment._devnull is None
    assert environment._config is None
    assert environment.program_name == 'http'
    if is_windows:
        assert environment._orig_stderr == sys.stderr
    else:
        assert environment.colors

# Generated at 2022-06-25 18:19:53.714552
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert isinstance(environment, Environment)

# Generated at 2022-06-25 18:20:01.593653
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows == is_windows
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == environment.stdin.isatty()
    assert environment.stdin_encoding == getattr(
        environment.stdin, 'encoding', None) or 'utf8'
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == environment.stdout.isatty()
    assert environment.stdout_encoding == getattr(
        environment.stdout, 'encoding', None) or 'utf8'
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == environment.stderr.isatty

# Generated at 2022-06-25 18:20:12.502713
# Unit test for constructor of class Environment
def test_Environment():
    assert environment_0.is_windows in [True, False]
    assert isinstance(environment_0.config_dir, Path)
    assert environment_0.stdin is None or type(environment_0.stdin) == io.TextIOWrapper
    assert environment_0.stdin_isatty in [True, False]
    assert environment_0.stdin_encoding in [None, 'utf8']
    assert type(environment_0.stdout) == io.TextIOWrapper
    assert environment_0.stdout_isatty in [True, False]
    assert environment_0.stdout_encoding in ['utf8', 'utf-8']
    assert type(environment_0.stderr) == io.TextIOWrapper

# Generated at 2022-06-25 18:20:15.591724
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    if 'devnull' in environment_0.__dict__ and environment_0._devnull is None:
        assert True
    else:
        assert False



# Generated at 2022-06-25 18:20:31.008248
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(devnull='/dev/null', stdin=sys.stdin)
    assert environment.stdin == sys.stdin
    assert environment.devnull == '/dev/null'



# Generated at 2022-06-25 18:20:38.331798
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert isinstance(environment, Environment)
    assert environment.is_windows == is_windows
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin is sys.stdin
    assert environment.stdout is sys.stdout
    assert environment.stderr is sys.stderr
    assert environment.colors == 256
    assert environment.program_name == 'http'


# Generated at 2022-06-25 18:20:39.977634
# Unit test for constructor of class Environment
def test_Environment():
    actual_env = Environment()
    expected_env = Environment()

    assert actual_env == expected_env


# Generated at 2022-06-25 18:20:43.043293
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(program_name = 'http', stdin = None)
    assert environment.program_name == 'http'
    assert environment.stdin_isatty == False

# Generated at 2022-06-25 18:20:44.501750
# Unit test for constructor of class Environment
def test_Environment():
    try:
        environment_0 = Environment()
    except SystemExit:
        raise Exception('Raised exception when creating Environment')

# Generated at 2022-06-25 18:20:45.407390
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()

# Generated at 2022-06-25 18:20:47.598741
# Unit test for constructor of class Environment
def test_Environment():
    if is_windows:
        assert Environment().is_windows == True
    else:
        assert Environment().is_windows == False


# Generated at 2022-06-25 18:20:58.332236
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()
    assert environment_1.stdin == sys.stdin
    assert environment_1.stdout == sys.stdout
    assert environment_1.stderr == sys.stderr
    assert environment_1.stdout_encoding == 'utf8'
    assert environment_1.stdin_encoding == 'utf8'
    assert environment_1.colors == 256
    assert environment_1.program_name == 'http'
    assert environment_1.devnull == None
    assert environment_1.config_dir == DEFAULT_CONFIG_DIR
    assert environment_1.is_windows == is_windows
    assert environment_1._orig_stderr == sys.stderr
    assert environment_1._devnull == None

# Generated at 2022-06-25 18:20:59.029719
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment()

# Generated at 2022-06-25 18:21:00.923918
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    if env.colors == 256:
        assert True
    else:
        assert False


# Generated at 2022-06-25 18:21:28.293836
# Unit test for constructor of class Environment
def test_Environment():
    try:
        test_case_0()
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-25 18:21:34.934839
# Unit test for constructor of class Environment
def test_Environment():
    # No config directory
    e = Environment()
    assert isinstance(e, Environment)
    assert e.config_dir == DEFAULT_CONFIG_DIR
    assert e.stdin == sys.stdin
    assert e.stdin_isatty == True
    assert e.stdin_encoding == None
    assert e.stdout == sys.stdout
    assert e.stdout_isatty == True
    assert e.stdout_encoding == None
    assert e.stderr == sys.stderr
    assert e.stderr_isatty == True
    assert isinstance(e.colors, int)
    assert e.program_name == 'http'
    e.program_name = 'abc'
    assert e.program_name == 'abc'
    assert isinstance(e.config, Config)

# Generated at 2022-06-25 18:21:46.123826
# Unit test for constructor of class Environment
def test_Environment():
    """
    docstring for test_Environment
    """
    test_env_0 = Environment()
    assert test_env_0.is_windows == is_windows
    assert test_env_0.config_dir == DEFAULT_CONFIG_DIR
    assert test_env_0.stdin == sys.stdin
    assert test_env_0.stdin_isatty == (sys.stdin.isatty() if sys.stdin else False)
    assert test_env_0.stdin_encoding == None
    assert test_env_0.stdout == sys.stdout
    assert test_env_0.stdout_isatty == sys.stdout.isatty()
    assert test_env_0.stdout_encoding == None
    assert test_env_0.stderr == sys.stder

# Generated at 2022-06-25 18:21:47.500405
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0 is not None


# Generated at 2022-06-25 18:21:56.002207
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.is_windows == False
    assert environment_0.config_dir.__str__() == DEFAULT_CONFIG_DIR.__str__()
    assert environment_0.stdin == sys.stdin
    assert environment_0.stdin_isatty == True
    assert environment_0.stdin_encoding == sys.stdin.encoding
    assert environment_0.stdout == sys.stdout
    assert environment_0.stdout_isatty == True
    assert environment_0.stdout_encoding == sys.stdout.encoding
    assert environment_0.stderr == sys.stderr
    assert environment_0.stderr_isatty == True
    assert environment_0._orig_stderr == sys.stderr
    assert environment

# Generated at 2022-06-25 18:21:58.950729
# Unit test for constructor of class Environment
def test_Environment():
    devnull = open(os.devnull)
    environment = Environment(devnull=devnull)
    assert environment.devnull == devnull

# Generated at 2022-06-25 18:22:08.614942
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(stdin=None)
    assert environment.stdin == None
    assert environment.stdin_isatty == False
    assert environment.stdin_encoding == 'utf8'
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == True
    assert environment.stdout_encoding == 'utf8'
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == True
    assert environment.colors == 256
    assert environment.program_name == 'http'
    assert environment.config_dir.name == 'config'
    assert environment.is_windows == is_windows


# Generated at 2022-06-25 18:22:19.092562
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows == is_windows
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == sys.stdin.isatty()
    assert environment.stdin_encoding == None
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == True
    assert environment.stdout_encoding == None
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == True
    assert environment.colors == 256
    assert environment.program_name == 'http'


# Generated at 2022-06-25 18:22:26.863739
# Unit test for constructor of class Environment
def test_Environment():

    # Test attribute is_windows is correctly set
    environment_0 = Environment()
    assert environment_0.is_windows == is_windows

    # Test attribute config_dir is correctly set
    assert environment_0.config_dir == DEFAULT_CONFIG_DIR

    # Test attribute stdin is correctly set
    assert environment_0.stdin == sys.stdin

    # Test attribute stdin_isatty is correctly set
    assert environment_0.stdin_isatty == sys.stdin.isatty() if sys.stdin else False # stdin is None when closed fd

    # Test attribute stdin_encoding is correctly set
    assert environment_0.stdin_encoding == None

    # Test attribute stdout is correctly set
    assert environment_0.stdout == sys.stdout

    # Test attribute stdout_isat

# Generated at 2022-06-25 18:22:30.233388
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()
    assert environment_1.stdin.isatty()==True

# Unit test of property config

# Generated at 2022-06-25 18:23:33.112512
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.is_windows == is_windows
    assert environment_0.config_dir == DEFAULT_CONFIG_DIR
    assert environment_0.stdin == sys.stdin
    assert environment_0.stdin_isatty == sys.stdin.isatty()
    assert environment_0.stdin_encoding == None
    assert environment_0.stdout == sys.stdout
    assert environment_0.stdout_isatty == sys.stdout.isatty()
    assert environment_0.stdout_encoding == None
    assert environment_0.stderr == sys.stderr
    assert environment_0.stderr_isatty == sys.stderr.isatty()
    assert environment_0.colors == 256
    assert environment_0

# Generated at 2022-06-25 18:23:42.137343
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    # print('test_case_0:')
    # print(environment_0)
    # print('')
    environment_1 = Environment(config_dir='/test_dir')
    # print('test_case_1:')
    # print(environment_1)
    # print('')

# Generated at 2022-06-25 18:23:54.116623
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull = None, is_windows = False, program_name = 'http', 
                      stdin = sys.stdin, stdin_isatty = sys.stdin.isatty(), stdin_encoding = None, 
                      stdout = sys.stdout, stdout_isatty = sys.stdout.isatty(), stdout_encoding = None, 
                      stderr = sys.stderr, stderr_isatty = sys.stderr.isatty(), config_dir = DEFAULT_CONFIG_DIR, 
                      colors = 0)
    assert env.is_windows == False
    assert env.program_name == 'http'
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()


# Generated at 2022-06-25 18:23:58.448808
# Unit test for constructor of class Environment
def test_Environment():
    os.environ['http_proxy'] = 'http://127.0.0.1:8080'
    environment = Environment()
    assert environment.program_name == 'http'
    assert environment.stderr == sys.stderr


# Generated at 2022-06-25 18:24:00.276072
# Unit test for constructor of class Environment
def test_Environment():
    try:
        e = Environment()
    except NameError as e:
        print(e)

# Generated at 2022-06-25 18:24:09.302808
# Unit test for constructor of class Environment
def test_Environment():
    # default constructor
    environment_0 = Environment()
    assert environment_0.is_windows == is_windows
    assert environment_0.config_dir == DEFAULT_CONFIG_DIR
    assert environment_0.stdin == sys.stdin
    assert environment_0.stdin_isatty == (sys.stdin.isatty() if sys.stdin else False)
    assert environment_0.stdin_encoding is None
    assert environment_0.stdout == sys.stdout
    assert environment_0.stdout_isatty == sys.stdout.isatty()
    assert environment_0.stdout_encoding is None
    assert environment_0.stderr == sys.stderr
    assert environment_0.stderr_isatty == sys.stderr.isatty()

# Generated at 2022-06-25 18:24:11.428110
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdout='test_stdout', stdout_isatty=False)
    assert env.stdout == 'test_stdout'
    assert env.stdout_isatty == False



# Generated at 2022-06-25 18:24:21.796539
# Unit test for constructor of class Environment
def test_Environment():
    # create Environment object
    environment_1 = Environment()
    assert environment_1.is_windows == is_windows
    assert environment_1.config_dir == Path(DEFAULT_CONFIG_DIR)
    assert environment_1.stdin == sys.stdin
    assert environment_1.stdin_isatty == sys.stdin.isatty() if sys.stdin else False
    assert environment_1.stdout == sys.stdout
    assert environment_1.stdout_isatty == sys.stdout.isatty()
    assert environment_1.stderr == sys.stderr
    assert environment_1.stderr_isatty == sys.stderr.isatty()
    assert environment_1.colors == 256
    assert environment_1.program_name == 'http'
    assert environment

# Generated at 2022-06-25 18:24:25.803822
# Unit test for constructor of class Environment
def test_Environment():
    try:
        env_0 = Environment(False, True)
        assert False
    except AssertionError:
        assert True
    try:
        env_0 = Environment(True, False)
        assert False
    except AssertionError:
        assert True


# Generated at 2022-06-25 18:24:26.819449
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()
