

# Generated at 2022-06-25 18:15:38.431059
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(is_windows=True, stdin_encoding="utf8", stdout_encoding="utf8", stderr_isatty=True)
    assert hasattr(env, 'is_windows')
    assert hasattr(env, 'config_dir')
    assert hasattr(env, 'stdin')
    assert hasattr(env, 'stdin_isatty')
    assert hasattr(env, 'stdin_encoding')
    assert hasattr(env, 'stdout')
    assert hasattr(env, 'stdout_isatty')
    assert hasattr(env, 'stdout_encoding')
    assert hasattr(env, 'stderr')
    assert hasattr(env, 'stderr_isatty')
    assert hasattr(env, 'colors')

# Generated at 2022-06-25 18:15:48.010793
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment.is_windows == is_windows
    assert Environment.config_dir == DEFAULT_CONFIG_DIR
    assert Environment.stdin == sys.stdin  # `None` when closed fd (#791)
    assert Environment.stdin_isatty == sys.stdin.isatty() if sys.stdin else False
    assert Environment.stdin_encoding == None
    assert Environment.stdout == sys.stdout
    assert Environment.stdout_isatty == sys.stdout.isatty()
    assert Environment.stdout_encoding == None
    assert Environment.stderr == sys.stderr
    assert Environment.stderr_isatty == sys.stderr.isatty()
    assert Environment.colors == 256
    assert Environment.program_name == 'http'

# Generated at 2022-06-25 18:15:54.553750
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    print(environment)
    assert str(type(environment.stdin)) == "<class '_io.TextIOWrapper'>"
    assert str(type(environment.stdout)) == "<class '_io.TextIOWrapper'>"
    assert str(type(environment.stderr)) == "<class '_io.TextIOWrapper'>"


# Generated at 2022-06-25 18:16:01.307365
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()
    assert environment_1.is_windows == is_windows
    assert environment_1.config_dir == DEFAULT_CONFIG_DIR
    assert environment_1.stdin == sys.stdin
    assert environment_1.stdout == sys.stdout
    assert environment_1.stderr == sys.stderr
    assert environment_1.stdin_encoding == sys.stdin.encoding
    assert environment_1.stdout_encoding == sys.stdout.encoding
    assert environment_1.stderr_encoding == sys.stderr.encoding
    assert environment_1.program_name == 'http'
    assert environment_1.stdin_isatty == sys.stdin.isatty()
    assert environment_1.stdout_isatty == sys.std

# Generated at 2022-06-25 18:16:10.271866
# Unit test for constructor of class Environment

# Generated at 2022-06-25 18:16:18.750969
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()

# Generated at 2022-06-25 18:16:29.755314
# Unit test for constructor of class Environment
def test_Environment():
    environment_new = Environment(stderr=sys.stderr)
    assert environment_new.colors == 256
    assert environment_new.stdin_encoding == "utf8"
    assert environment_new.stdin_isatty == True
    assert environment_new.stdout_encoding == "utf8"
    assert environment_new.stdout_isatty == True
    assert environment_new.stderr_isatty == True
    assert environment_new.program_name == "http"
    assert environment_new.is_windows == False
    assert environment_new.stdin == sys.stdin
    assert environment_new.stdout == sys.stdout


# Generated at 2022-06-25 18:16:34.337793
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()


# Generated at 2022-06-25 18:16:46.158782
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment()
    assert type(e.is_windows) == bool
    assert type(e.stdin) == sys.stdin.__class__
    assert type(e.stdin) == sys.stdin.__class__
    assert type(e.stdout) == sys.stdout.__class__
    assert type(e.stderr) == sys.stderr.__class__
    assert type(e.program_name) == str
    #assert type(e.config) == Config
    assert type(e._devnull) == type(None)
    assert type(e._orig_stderr) == sys.stderr.__class__
    assert type(e.stdin_encoding) == type(None)
    assert type(e.stdout_encoding) == type(None)

# Unit

# Generated at 2022-06-25 18:16:52.357030
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr,
                      program_name="http", is_windows=False,
                      config_dir=DEFAULT_CONFIG_DIR,
                      _config=Config(directory=DEFAULT_CONFIG_DIR))
    config = Config(directory=DEFAULT_CONFIG_DIR)
    print(config)
    print(env)
    return


# Generated at 2022-06-25 18:17:06.662567
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    environment.program_name = 'http'
    assert environment.program_name == 'http'


# Generated at 2022-06-25 18:17:08.166729
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment()
    assert type(e) == Environment



# Generated at 2022-06-25 18:17:09.244939
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment()


# Generated at 2022-06-25 18:17:18.178011
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows == is_windows
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == environment.stdin.isatty() if environment.stdin else False
    assert environment.stdin_encoding == None
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == environment.stdout.isatty()
    assert environment.stdout_encoding == None
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == environment.stderr.isatty()
    assert environment.colors == 256
    assert environment.program_name == 'http'

# Generated at 2022-06-25 18:17:29.656306
# Unit test for constructor of class Environment
def test_Environment():
    assert sys.platform == 'linux'
    environment_1 = Environment()
    # print the value of func get_platform()
    # print(environment_1.get_platform())
    assert (environment_1.is_windows == False)
    assert (environment_1.config_dir == Path(DEFAULT_CONFIG_DIR))

    assert environment_1.stdin == sys.stdin
    assert environment_1.stdin_isatty == sys.stdin.isatty()
    assert (environment_1.stdin_encoding == 'utf8') # the encoding of sys.stdin = 'utf8'
    assert (environment_1.stdout == sys.stdout)
    assert (environment_1.stdout_isatty == sys.stdout.isatty())

# Generated at 2022-06-25 18:17:40.912674
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment._devnull is None
    assert environment.is_windows is False
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert type(environment.stdin) is sys.stdin.__class__
    assert environment.stdin_encoding is None
    assert environment.stdin_isatty is True
    assert environment.stdout is sys.stdout
    assert type(environment.stdout) is sys.stdout.__class__
    assert environment.stderr is sys.stderr
    assert type(environment.stderr) is sys.stderr.__class__
    assert environment.stdout_isatty is True
    assert environment.stdout_encoding == 'utf8'
    assert environment.stderr_isatty is True
    assert environment.colors

# Generated at 2022-06-25 18:17:42.123167
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment.__init__(Environment)

# Generated at 2022-06-25 18:17:51.380197
# Unit test for constructor of class Environment
def test_Environment():

    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.program_name == 'http'

# Generated at 2022-06-25 18:17:52.305769
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()


# Generated at 2022-06-25 18:17:54.731611
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    while True:
        try:
            environment_0.__init__()
        except Exception as e:
            print(e)


# Generated at 2022-06-25 18:18:22.951855
# Unit test for constructor of class Environment
def test_Environment():
    # Test default attributes
    assert Environment().is_windows == is_windows
    assert Environment().config_dir == Path(DEFAULT_CONFIG_DIR)
    assert Environment().stdin == sys.stdin
    assert Environment().stdin_isatty == sys.stdin.isatty() if sys.stdin else False
    assert Environment().stdout == sys.stdout
    assert Environment().stdout_isatty == sys.stdout.isatty()
    assert Environment().stderr == sys.stderr
    assert Environment().stderr_isatty == sys.stderr.isatty()
    if not is_windows:
        if curses:
            try:
                curses.setupterm()
                assert Environment().colors == curses.tigetnum('colors')
            except curses.error:
                pass


# Generated at 2022-06-25 18:18:30.856232
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=sys.stdin,
                      stdout=sys.stdout,
                      stderr=sys.stderr,
                      devnull=None,
                      config_dir="~/.httpie")
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert env.devnull == None
    assert env.config_dir == "~/.httpie"


# Generated at 2022-06-25 18:18:41.872516
# Unit test for constructor of class Environment
def test_Environment():
    devnull = open(os.devnull, 'w+')

    environ_2 = Environment(devnull = devnull,
                            stdin=sys.stdin,
                            stdout=sys.stdout,
                            stderr=sys.stderr,
                            is_windows=is_windows,
                            config_dir=Path(DEFAULT_CONFIG_DIR),
                            stdin_isatty=sys.stdin.isatty(),
                            stdin_encoding='utf8',
                            stdout_isatty=sys.stdout.isatty(),
                            stdout_encoding='utf8',
                            stderr_isatty=sys.stderr.isatty(),
                            colors=256,
                            program_name='http')

# Generated at 2022-06-25 18:18:42.926008
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment()
    


# Generated at 2022-06-25 18:18:50.257019
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows == is_windows
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == sys.stdin.isatty()
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == sys.stdout.isatty()
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == sys.stderr.isatty()
    assert environment.colors == 256
    assert environment.program_name == 'http'


# Generated at 2022-06-25 18:18:51.303267
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()

# Generated at 2022-06-25 18:18:54.420356
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.program_name == 'http'
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr


# Generated at 2022-06-25 18:19:02.219431
# Unit test for constructor of class Environment
def test_Environment():
    string_input = Environment(stderr = 'test_stderr', stdout = 'test_stdout', stderr_isatty = True, stdout_isatty = True, stdin = 'test_stdin', stdin_isatty = True, stdin_encoding = 'utf8', stdout_encoding = 'utf8', stderr_encoding = 'utf8', program_name = 'test_program_name', colors = '256')
    assert string_input.stderr == 'test_stderr'
    assert string_input.stdout == 'test_stdout'
    assert string_input.stderr_isatty == True
    assert string_input.stdout_isatty == True
    assert string_input.stdin == 'test_stdin'

# Generated at 2022-06-25 18:19:09.954286
# Unit test for constructor of class Environment
def test_Environment():
    # Test 1: Windows environment
    if is_windows:
        environment_1 = Environment(is_windows=True)
        assert environment_1.is_windows == True

    # Test 2: Devnull environment
    if not is_windows:
        environment_2 = Environment(devnull=open(os.devnull, 'w+'))
        assert environment_2.devnull.name == os.devnull
    else:
        environment_2 = Environment(devnull=None)
        assert environment_2.devnull == None


# Generated at 2022-06-25 18:19:18.585572
# Unit test for constructor of class Environment
def test_Environment():
    Env = Environment()
    # Test for the variables "config_dir" and "program_name"
    assert Env.config_dir == Path(DEFAULT_CONFIG_DIR)
    assert Env.program_name == 'http'
    # Test for the variables "stdout", "stdout_isatty", and "stdout_encoding"
    assert Env.stdout == sys.stdout
    assert Env.stdout_isatty == sys.stdout.isatty()
    assert Env.stdout_encoding == (getattr(sys.stdout, 'encoding', None) or 'utf8')
    # Test for the variables "stderr", "stderr_isatty", and "colors"
    assert Env.stderr == sys.stderr
    assert Env.st