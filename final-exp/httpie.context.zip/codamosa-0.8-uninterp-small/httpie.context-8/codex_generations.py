

# Generated at 2022-06-25 18:15:31.785485
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()

# Generated at 2022-06-25 18:15:38.109427
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == True or False
    assert env.stdin.isatty() == True or False
    assert env.stdin_isatty == True or False
    assert env.stdin_encoding
    assert env.stdout.isatty() == True or False
    assert env.stdout_isatty == True or False
    assert env.stdout_encoding
    assert env.stderr.isatty() == True or False
    assert env.stderr_isatty == True or False
    assert env.colors == 256
    assert env._orig_stderr is not None


# Generated at 2022-06-25 18:15:43.484734
# Unit test for constructor of class Environment
def test_Environment():
    environment_2 = Environment()
    assert environment_2.is_windows
    assert environment_2.config_dir == DEFAULT_CONFIG_DIR
    assert environment_2.stdin == sys.stdin
    assert environment_2.stdout == sys.stdout
    assert environment_2.stderr == sys.stderr


# Generated at 2022-06-25 18:15:50.265425
# Unit test for constructor of class Environment
def test_Environment():
    # test 'stdin' attribute
    env_0 = Environment()
    env_1 = Environment(stdin = sys.stdout)
    env_2 = Environment(stdin = sys.stderr)
    assert env_0.stdin == env_1.stdin == env_2.stdin == sys.stdin
    # test 'stdin_isatty' attribute
    env_0 = Environment()
    env_1 = Environment(stdin_isatty = True)
    env_2 = Environment(stdin_isatty = False)
    assert env_0.stdin_isatty == env_1.stdin_isatty == env_2.stdin_isatty == env_0.stdin.isatty()
    # test 'stdin_encoding' attribute
    env_0 = Environment()

# Generated at 2022-06-25 18:15:58.622129
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    environment_1 = Environment(stderr=sys.stdout)
    environment_2 = Environment(stderr_isatty=True)
    environment_3 = Environment(stdout_encoding='utf8')
    environment_4 = Environment(devnull=None)
    environment_5 = Environment(config_dir=DEFAULT_CONFIG_DIR)
    environment_6 = Environment(is_windows=is_windows)
    environment_7 = Environment(colors=256)
    environment_8 = Environment(program_name='http')
    environment_9 = Environment(devnull=open(os.devnull, 'w+'))


# Generated at 2022-06-25 18:16:10.711430
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(stdin=None)
    assert environment.is_windows == is_windows
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin is None
    assert environment.stdout is sys.stdout
    assert environment.stderr is sys.stderr
    assert environment.stdin_isatty == False
    assert environment.stdout_isatty == True
    assert environment.stderr_isatty == True
    assert environment.colors == 256
    assert environment.program_name == 'http'


# Generated at 2022-06-25 18:16:14.931141
# Unit test for constructor of class Environment
def test_Environment():
    colorama = Environment(is_windows = True, stdout_isatty = True, stderr_isatty = True, colors = 256)
    assert colorama.is_windows == True
    assert colorama.stdout_isatty == True
    assert colorama.stderr_isatty == True
    assert colorama.colors == 256

# Generated at 2022-06-25 18:16:26.801650
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows == is_windows
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == (sys.stdin.isatty() if sys.stdin else False)
    assert environment.stdin_encoding is None
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == sys.stdout.isatty()
    assert environment.stdout_encoding is None
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == sys.stderr.isatty()
    assert environment.colors == 256
    assert environment.program_name == 'http'


# Generated at 2022-06-25 18:16:27.250372
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment



# Generated at 2022-06-25 18:16:33.145105
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.stdin == sys.stdin
    assert environment.stdout == sys.stdout
    assert environment.stderr == sys.stderr
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdout_isatty
    assert environment.stderr_isatty
    assert environment.stdin_isatty
    assert environment.colors == 256



# Generated at 2022-06-25 18:16:46.200242
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(stdin=None, stdout=sys.stdout, \
                stderr=sys.stderr, program_name='httpie',\
                colors=8, devnull=None)

    assert environment_1.stdin == None
    assert environment_1.stdout == sys.stdout
    assert environment_1.stderr == sys.stderr
    assert environment_1.program_name == 'httpie'
    assert environment_1.colors == 8
    assert environment_1.devnull == None


# Generated at 2022-06-25 18:16:51.754596
# Unit test for constructor of class Environment
def test_Environment():
    print("Test constructor of class Environment")
    environment_0 = Environment()
    print(environment_0._orig_stderr)
    print(environment_0._devnull)
    print(environment_0._config)
    print(environment_0.config)
    print(environment_0.devnull)
    print(environment_0.log_error("This is a test"))


# Generated at 2022-06-25 18:16:56.450635
# Unit test for constructor of class Environment
def test_Environment():
    # __init__(devnull=None, **kwargs)
    env_0 = Environment()
    env_1 = Environment(devnull=os.devnull, is_windows=True, config_dir=DEFAULT_CONFIG_DIR, stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr)
    assert env_0
    assert env_0.__str__() == env_1.__str__()
    print(env_0.__str__())



# Generated at 2022-06-25 18:17:05.333171
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment.stdin
    assert Environment.stdout
    assert Environment.stderr
    assert Environment.stdin_isatty == True
    assert Environment.stderr_isatty == True
    assert Environment.stdout_isatty == True
    assert Environment.stdin_encoding == 'UTF-8'
    assert Environment.stdout_encoding == 'UTF-8'
    assert Environment.stderr_encoding == 'UTF-8'
    assert Environment.config_dir == '~/.httpie'
    assert Environment.program_name == 'http'
    assert Environment.is_windows == False


test_case_0()

# Generated at 2022-06-25 18:17:11.712838
# Unit test for constructor of class Environment
def test_Environment():
    print(Environment())
    print(Environment(stdin=None, stdin_isatty=None, stdin_encoding=None,
                      stdout=None, stdout_isatty=None, stdout_encoding=None,
                      stderr=None, stderr_isatty=None, stderr_encoding=None,
                      devnull=None, program_name=None, is_windows=None,
                      config_dir=None, colors=None))


# Generated at 2022-06-25 18:17:14.473172
# Unit test for constructor of class Environment
def test_Environment():
    #Evaluación de constructor con parámetros defectuoso
    assert Environment()

    #Evaluación de constructor con parámetro devnull
    assert Environment(devnull=4)


# Generated at 2022-06-25 18:17:16.060334
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()

if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-25 18:17:17.479623
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert isinstance(environment_0, Environment)


# Generated at 2022-06-25 18:17:19.605378
# Unit test for constructor of class Environment
def test_Environment():
    try:
        test_case_0() 
    except Exception as e:
        assert False, "Unable to instantiate the Environment class"
    

# Generated at 2022-06-25 18:17:31.119798
# Unit test for constructor of class Environment
def test_Environment():
    assert environment_0.is_windows == is_windows
    assert environment_0.config_dir == DEFAULT_CONFIG_DIR
    assert environment_0.stdin == sys.stdin  # `None` when closed fd (#791)
    assert environment_0.stdin_isatty == sys.stdin.isatty() if sys.stdin else False
    assert environment_0.stdin_encoding is None
    assert environment_0.stdout == sys.stdout
    assert environment_0.stdout_isatty == sys.stdout.isatty()
    assert environment_0.stdout_encoding is None
    assert environment_0.stderr == sys.stderr
    assert environment_0.stderr_isatty == sys.stderr.isatty()
    assert environment_

# Generated at 2022-06-25 18:17:45.406648
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.is_windows == False
    assert environment_0.config_dir == Path.home() / '.config' / 'httpie'
    assert environment_0.stdin.buffer == sys.stdin.buffer
    assert environment_0.stdin_isatty == True
    assert environment_0.stdin_encoding == 'utf8'
    assert environment_0.stdout.buffer == sys.stdout.buffer
    assert environment_0.stdout_isatty == True
    assert environment_0.stdout_encoding == 'utf8'
    assert environment_0.stderr.buffer == sys.stderr.buffer
    assert environment_0.stderr_isatty == True
    assert environment_0.colors == 256
    assert environment_0.program_

# Generated at 2022-06-25 18:17:47.169503
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()
    content = str(environment_1)
    assert content.startswith('<Environment')


# Generated at 2022-06-25 18:17:56.530289
# Unit test for constructor of class Environment

# Generated at 2022-06-25 18:18:07.197807
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(devnull=1)
    assert environment_1.devnull == 1
    environment_2 = Environment(stdin='random')
    assert environment_2.stdin == 'random'
    environment_3 = Environment(stdin_isatty='random')
    assert environment_3.stdin_isatty == 'random'
    environment_4 = Environment(stdin_encoding='random')
    assert environment_4.stdin_encoding == 'random'
    environment_5 = Environment(stdout='random')
    assert environment_5.stdout == 'random'
    environment_6 = Environment(stdout_isatty='random')
    assert environment_6.stdout_isatty == 'random'
    environment_7 = Environment(stdout_encoding='random')
    assert environment_7.std

# Generated at 2022-06-25 18:18:16.146765
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()


# Generated at 2022-06-25 18:18:26.328621
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(devnull="devnull", is_windows=False,
                              config_dir="config_dir",
                              stdin="stdin", stdin_isatty="stdin_isatty",
                              stdin_encoding="stdin_encoding",
                              stdout="stdout", stdout_isatty="stdout_isatty",
                              stdout_encoding="stdout_encoding", stderr="stderr",
                              stderr_isatty="stderr_isatty", colors="colors",
                              program_name="program_name", _devnull="_devnull",
                              _config="_config")


# Generated at 2022-06-25 18:18:32.405487
# Unit test for constructor of class Environment
def test_Environment():
    global test_case_0
    test_case_0()
    # TODO
    global test_case_1
    test_case_1()
    # TODO
    global test_case_2
    test_case_2()
    # TODO
    global test_case_3
    test_case_3()
    # TODO
    global test_case_4
    test_case_4()
    # TODO
    global test_case_5
    test_case_5()
    # TODO
    global test_case_6
    test_case_6()



# Generated at 2022-06-25 18:18:37.756158
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(stdin_isatty=False, stdout_isatty=True, stderr_isatty=False)
    assert environment.stdin_isatty == False
    assert environment.stdout_isatty == True
    assert environment.stderr_isatty == False


# Generated at 2022-06-25 18:18:44.710842
# Unit test for constructor of class Environment
def test_Environment():
  environment_1 = Environment(program_name = 'example_program', stderr_isatty = False, stdin_isatty = True, stdout_isatty = True)
  assert(environment_1.program_name == 'example_program')
  assert(environment_1.stderr_isatty == False)
  assert(environment_1.stdin_isatty == True)
  assert(environment_1.stdout_isatty == True)
  assert(environment_1.is_windows == False)

# Generated at 2022-06-25 18:18:46.252098
# Unit test for constructor of class Environment
def test_Environment():
    # Assert initialization with given arguments
    environment_1 = Environment(stdin = None)
    assert environment_1.stdin == None



# Generated at 2022-06-25 18:19:01.879053
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()  # default
    environment_1 = Environment(config_dir=Path('/dustin/Documents'))  # non-default
    environment_2 = Environment(is_windows=False)  # non-default
    environment_3 = Environment(stdin=None)  # non-default
    environment_4 = Environment(stdin_isatty=True)  # non-default
    environment_5 = Environment(stdin_encoding='utf8')  # non-default
    environment_6 = Environment(stdout=sys.stdout)  # non-default
    environment_7 = Environment(stderr=sys.stderr)  # non-default
    environment_8 = Environment(program_name='http')  # non-default


# Generated at 2022-06-25 18:19:09.673823
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(stdin=None, stdin_isatty=None, stdin_encoding=None, stdout=None, stdout_isatty=None, stdout_encoding=None, stderr=None, stderr_isatty=None, colors=None, program_name=None, is_windows=None, config_dir=None)
    try:
        environment.log_error(msg=None, level=None)
    except AssertionError:
        return True
    return False


# Generated at 2022-06-25 18:19:18.376058
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows == is_windows
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == sys.stdin.isatty() if sys.stdin else False
    assert environment.stdin_encoding == None
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == sys.stdout.isatty()
    assert environment.stdout_encoding == None
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == sys.stderr.isatty()
    assert environment.colors == 256
    assert environment.program_name == 'http'

# Generated at 2022-06-25 18:19:29.950800
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(
        stdin=sys.stdin,
        stdin_isatty=True,
        stdin_encoding='UTF8',
        stdout=sys.stdout,
        stdout_isatty=True,
        stdout_encoding=None,
        stderr=sys.stderr,
        stderr_isatty=True,
        colors=256,
        program_name='http'
    )
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == True
    assert environment.stdin_encoding == 'UTF8'
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == True
    assert environment.stdout_encoding == None
    assert environment.stderr == sys.stder

# Generated at 2022-06-25 18:19:37.792444
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.is_windows == is_windows
    assert type(environment_0.stdin) == type(sys.stdin)
    assert environment_0.stdin_isatty == sys.stdin.isatty()
    assert type(environment_0.stdout) == type(sys.stdout)
    assert environment_0.stdout_isatty == sys.stdout.isatty()
    assert type(environment_0.stderr) == type(sys.stderr)
    assert environment_0.stderr_isatty == sys.stderr.isatty()
    assert environment_0.program_name == 'http'


if __name__ == '__main__':
    test_case_0()
    test_Environment()

# Generated at 2022-06-25 18:19:43.730684
# Unit test for constructor of class Environment
def test_Environment():
    # Test constructor
    environment_0 = Environment()
    assert not environment_0.is_windows
    assert environment_0.config_dir == Path('.httpie')
    assert environment_0.stdin is not None
    assert environment_0.stdin_isatty
    assert environment_0.stdin_encoding == 'utf8'
    assert environment_0.stdout is not None
    assert environment_0.stdout_isatty
    assert environment_0.stdout_encoding == 'utf8'
    assert environment_0.stderr is not None
    assert environment_0.stderr_isatty
    assert environment_0.colors == 256
    assert environment_0.program_name == 'http'

    # Test function __str__
    print('\nTesting function __str__')

# Generated at 2022-06-25 18:19:53.812311
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(
        is_windows=True,
        config_dir=Path('/home/kent/httpie'),
        stdin=sys.stdin,
        stdin_isatty=True,
        stdin_encoding='utf8',
        stdout=sys.stdout,
        stdout_isatty=True,
        stdout_encoding='utf8',
        stderr=sys.stderr,
        stderr_isatty=True,
        colors=0,
        program_name='http',
        devnull=None
    )
    assert environment_1.is_windows == True
    assert environment_1.config_dir == Path('/home/kent/httpie')
    assert environment_1.stdin == sys.stdin
    assert environment_1.std

# Generated at 2022-06-25 18:19:55.367629
# Unit test for constructor of class Environment
def test_Environment():
    test_env = Environment()
    assert isinstance(test_env, Environment)


# Generated at 2022-06-25 18:19:57.908017
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(color=1, color_format='a')
    assert(env.color == 1)
    assert(env.color_format == 'a')


# Generated at 2022-06-25 18:20:09.222210
# Unit test for constructor of class Environment
def test_Environment():
    if (not hasattr(Environment, "__init__")):
        raise AssertionError("No class")
    try:
        environment_0 = Environment()
    except IOError as err:
        print(err)

    assert hasattr(Environment, "__init__") and Environment.__init__

    # Try incorrect types, non-existing objects, and incorrect return types
    try:
        environment_1 = Environment(45.0)
    except TypeError as err:
        print(err)

    assert hasattr(environment_0, "__init__") and environment_0.__init__

    # Find the docstring of the init function
    assert Environment.__init__.__doc__
    print(Environment.__init__.__doc__)

# Test whether the docstring exists

# Generated at 2022-06-25 18:20:25.800092
# Unit test for constructor of class Environment
def test_Environment():
    environment0 = Environment()
    assert isinstance(environment0, Environment)

# Generated at 2022-06-25 18:20:34.746285
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().is_windows == test_case_0().is_windows
    assert Environment().config_dir == test_case_0().config_dir
    assert Environment().stdin == test_case_0().stdin
    assert Environment().stdin_isatty == test_case_0().stdin_isatty
    assert Environment().stdout == test_case_0().stdout
    assert Environment().stdout_isatty == test_case_0().stdout_isatty
    assert Environment().stderr == test_case_0().stderr
    assert Environment().stderr_isatty == test_case_0().stderr_isatty
    assert Environment().colors == test_case_0().colors
    assert Environment().program_name == test_case_0().program_name


# Generated at 2022-06-25 18:20:43.340619
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        stdin_isatty=False, stdout_isatty=False, stderr_isatty=False, program_name='test')
    env.stderr_isatty = False
    env.stdin_isatty = False
    env.stdout_isatty = False
    env.program_name = 'test'
    env.stderr_encoding = 'utf8'
    env.stdin_encoding = 'utf8'
    env.stdout_encoding = 'utf8'


# Generated at 2022-06-25 18:20:48.247774
# Unit test for constructor of class Environment
def test_Environment():
   devnull = "Hello"
   environment = Environment(devnull)
   assert environment.devnull == devnull
   assert not environment.stdin_isatty
   assert environment.stdout_isatty
   assert environment.stderr_isatty
   assert environment.stdin_encoding == "utf8"
   assert environment.stdout_encoding == "utf8"


# Generated at 2022-06-25 18:20:59.072555
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(is_windows=True)
    environment_2 = Environment(is_windows=True, config_dir=DEFAULT_CONFIG_DIR)
    environment_3 = Environment(is_windows=True, config_dir=DEFAULT_CONFIG_DIR, stdin=sys.stdin)
    environment_4 = Environment(is_windows=True, config_dir=DEFAULT_CONFIG_DIR, stdin=sys.stdin, stdin_isatty=sys.stdin.isatty())
    environment_5 = Environment(is_windows=True, config_dir=DEFAULT_CONFIG_DIR, stdin=sys.stdin, stdin_isatty=sys.stdin.isatty(), stdin_encoding=None)

# Generated at 2022-06-25 18:21:08.867352
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(
        # stdin=open(os.devnull, 'r'),
        is_windows=False,
        config_dir=Path('~/Desktop/httpie/config'),
        stdin=sys.stdin,
        stdin_isatty=False,
        stdin_encoding=None,
        stdout=sys.stdout,
        stdout_isatty=True,
        stdout_encoding=None,
        stderr=sys.stderr,
        stderr_isatty=True,
        colors=256,
        program_name='http'
    )
    print(environment_1.is_windows)
    print(environment_1.config_dir)
    print(environment_1.stdin)

# Generated at 2022-06-25 18:21:15.025668
# Unit test for constructor of class Environment
def test_Environment():
    assert is_windows == Environment().is_windows
    assert DEFAULT_CONFIG_DIR == Environment().config_dir
    assert stdin == Environment().stdin
    assert stdin.isatty() if stdin else False == Environment().stdin_isatty
    assert None == Environment().stdin_encoding
    assert stdout == Environment().stdout
    assert stdout.isatty() == Environment().stdout_isatty
    assert None == Environment().stdout_encoding
    assert stderr == Environment().stderr
    assert stderr.isatty() == Environment().stderr_isatty
    assert 256 == Environment().colors
    assert 'http' == repr(Environment()).split()[0][1:]

# Generated at 2022-06-25 18:21:26.827300
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0
    assert environment_0.devnull is None
    assert environment_0.stderr is sys.stderr
    assert environment_0.stderr_isatty is environment_0.is_windows
    assert environment_0.stderr_isatty is environment_0.stdout_isatty
    assert environment_0.stdout is sys.stdout
    assert environment_0.stdin is sys.stdin
    assert environment_0.stdin_isatty is environment_0.is_windows
    assert environment_0.stdout_encoding is not None
    assert environment_0.stdin_encoding is not None
    assert environment_0.program_name is not None
    assert environment_0.colors is 256
    assert environment_0.config_

# Generated at 2022-06-25 18:21:31.908075
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert env.stdin_isatty == True
    assert env.stdout_isatty == True
    assert env.stderr_isatty == True

# Generated at 2022-06-25 18:21:40.372273
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert isinstance(environment_0.stdin, optional[IO])
    assert environment_0.stdin_encoding == 'utf8'
    assert isinstance(environment_0.stdout, IO)
    assert environment_0.stdout_encoding == 'utf8'
    assert environment_0.config._config_dir_path == Path.home() / '.httpie'
    assert environment_0.config.config == {}
    # Test for the constructor can not be completed because
    # of the implementation of the TestCase class.

# Generated at 2022-06-25 18:22:14.004711
# Unit test for constructor of class Environment
def test_Environment():
    print('Testing constructor of class Environment')
    assert Environment().__dict__ == vars(sys)


# Generated at 2022-06-25 18:22:23.228352
# Unit test for constructor of class Environment
def test_Environment():
    # Given
    devnull = open(os.devnull, 'w+')
    # When
    environment_1 = Environment(devnull=devnull, is_windows=True, config_dir=DEFAULT_CONFIG_DIR, stdin=sys.stdin,
    stdin_isatty=False, stdin_encoding='utf8', stdout=sys.stdout, stdout_isatty=True, stdout_encoding='utf8',
    stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http')
    # Then
    assert environment_1.devnull == devnull
    assert environment_1.is_windows == True
    assert environment_1.config_dir == DEFAULT_CONFIG_DIR

# Generated at 2022-06-25 18:22:35.392400
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(devnull="./devnull", is_windows=False, config_dir="./config_file", stdin="toto", stdin_isatty=False, stdin_encoding="utf8", stdout="stdout", stdout_isatty=False, stdout_encoding="utf8", stderr="stderr", stderr_isatty=False, colors=256, program_name="http", _orig_stderr="stderr")

# Generated at 2022-06-25 18:22:36.123547
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()


# Generated at 2022-06-25 18:22:37.129793
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment()


# Generated at 2022-06-25 18:22:47.671948
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.is_windows == False
    assert environment_0.config_dir == DEFAULT_CONFIG_DIR
    assert environment_0.stdin == sys.stdin
    assert environment_0.stdout == sys.stdout
    assert environment_0.stderr == sys.stderr
    assert environment_0.program_name == 'http'

    environment_1 = Environment(devnull=1, is_windows=True, config_dir=1,
        stdin=1, stdout=1, stderr=1, colors=1, program_name=1)
    assert environment_1.devnull == 1
    assert environment_1.is_windows == True
    assert environment_1.config_dir == 1
    assert environment_1.stdin == 1
    assert environment_

# Generated at 2022-06-25 18:22:59.432962
# Unit test for constructor of class Environment
def test_Environment():
    my_env = Environment()
    assert my_env.stderr == sys.stderr
    assert my_env.stderr_isatty == my_env.stderr.isatty()
    assert my_env.stdin == sys.stdin
    assert my_env.stdin_isatty == my_env.stdin.isatty()
    assert my_env.stdout == sys.stdout
    assert my_env.stdout_isatty == my_env.stdout.isatty()
    assert my_env.stderr_encoding == 'utf8'
    assert my_env.stdout_encoding == 'utf8'
    assert my_env.config_dir == DEFAULT_CONFIG_DIR
    assert my_env.program_name == 'http'
    assert my

# Generated at 2022-06-25 18:23:00.345027
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()


# Generated at 2022-06-25 18:23:08.432618
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(
        is_windows=False,
        config_dir=Path("/tmp"),
        stdin=sys.stdin,
        stdout=sys.stdout,
        stderr=sys.stderr,
    )
    assert environment_1.is_windows == False
    assert environment_1.config_dir == Path("/tmp")
    assert environment_1.stdin == sys.stdin
    assert environment_1.stdout == sys.stdout
    assert environment_1.stderr == sys.stderr
    assert environment_1.stdin_isatty == True
    assert environment_1.stdout_isatty == True
    assert environment_1.stderr_isatty == True
    assert environment_1.colors == 256
    assert environment_1.program_

# Generated at 2022-06-25 18:23:13.201299
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(config_dir=Path('test_data/test_config/test1'),stdout=open('test_data/test1.txt','w'),stderr=open('test_data/test1.txt','w'))
    environment_1.log_error("Test error message")
    print(environment_1)

# Generated at 2022-06-25 18:24:17.192551
# Unit test for constructor of class Environment
def test_Environment():
    assert type(Environment()) == Environment


# Generated at 2022-06-25 18:24:22.456694
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()
    assert environment_1.is_windows == False
    assert environment_1.stdin == sys.stdin
    assert environment_1.stdout == sys.stdout
    assert environment_1.stderr == sys.stderr

    environment_2 = Environment(is_windows=None)
    assert environment_2.is_windows == True

    environment_3 = Environment(stdin=None)
    assert environment_3.stdin is None

    environment_4 = Environment(stdout=None)
    assert environment_4.stdout is None

    environment_5 = Environment(stderr=None)
    assert environment_5.stderr is None

# Generated at 2022-06-25 18:24:24.003309
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert isinstance(env, Environment)



# Generated at 2022-06-25 18:24:32.567382
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(program_name='http')
    assert environment_1.program_name == 'http'
    environment_2 = Environment(stderr_isatty=stderr.isatty())
    assert environment_2.stderr_isatty == stderr.isatty()
    environment_3 = Environment(stdout_isatty=stdout.isatty())
    assert environment_3.stdout_isatty == stdout.isatty()
    environment_4 = Environment(stdin_encoding=stdin.encoding)
    assert environment_4.stdin_encoding == stdin.encoding
    environment_5 = Environment(stdin_encoding=stdin.encoding)
    assert environment_5.devnull is None


# Generated at 2022-06-25 18:24:34.025128
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert isinstance(environment_0, Environment)


# Generated at 2022-06-25 18:24:43.553439
# Unit test for constructor of class Environment
def test_Environment():
    print("test_Environment")
    environment_1 = Environment()
    print("test_Environment_1: " + str(environment_1.is_windows))
    print("test_Environment_1: " + str(environment_1.stdin_isatty))
    print("test_Environment_1: " + str(environment_1.stdin_encoding))
    print("test_Environment_1: " + str(environment_1.stdout_isatty))
    print("test_Environment_1: " + str(environment_1.stdout_encoding))
    print("test_Environment_1: " + str(environment_1.stderr_isatty))
    print("test_Environment_1: " + str(environment_1.colors))

# Generated at 2022-06-25 18:24:44.924542
# Unit test for constructor of class Environment
def test_Environment():
    envi = Environment()
    assert isinstance(envi, Environment)



# Generated at 2022-06-25 18:24:45.728364
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()


# Generated at 2022-06-25 18:24:52.900229
# Unit test for constructor of class Environment
def test_Environment():
    # test for the constructor of class Environment
    # assert the returned value is Environment
    env = Environment(devnull = "", stdin = "", stdin_isatty = True, stdin_encoding = "",
                        stdout = "", stdout_isatty = True, stdout_encoding = "",
                        stderr = "", stderr_isatty = True,
                        colors = 256, program_name = "http",
                        config_dir = DEFAULT_CONFIG_DIR,
                        is_windows = is_windows)

    assert type(env) == Environment  # check if the returned value is Environment


# Generated at 2022-06-25 18:25:02.958469
# Unit test for constructor of class Environment
def test_Environment():

    environment = Environment(
        is_windows=True,
        config_dir=Path('C:/config/directory'),
        stdin=sys.stdin,
        stdin_isatty=True,
        stdin_encoding='utf8',
        stdout=sys.stdout,
        stdout_isatty=True,
        stdout_encoding='utf8',
        stderr=sys.stderr,
        stderr_isatty=True,
        colors=256,
        program_name='http',
        devnull=open(os.devnull, 'w+'),
    )

    assert environment.is_windows == True
    assert environment.config_dir == Path('C:/config/directory')
    assert environment.devnull == open(os.devnull, 'w+')

    # Unit test