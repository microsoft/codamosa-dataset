

# Generated at 2022-06-25 18:15:44.729230
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(is_windows=True, stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr, config_dir=Path("/Users/anadep/.config/httpie"))
    assert environment.is_windows == True
    assert environment.stdin == sys.stdin
    assert environment.stdout == sys.stdout
    assert environment.stderr == sys.stderr
    assert environment.config_dir == Path("/Users/anadep/.config/httpie")

# Generated at 2022-06-25 18:15:57.363181
# Unit test for constructor of class Environment

# Generated at 2022-06-25 18:16:02.771639
# Unit test for constructor of class Environment
def test_Environment():
    if is_windows:
        try:
            from colorama.initialise import wrap_stream
            import colorama
        except ImportError:
            # Tox on AppVeyor does not install dev dependencies.
            pass
    environment = Environment()
    assert isinstance(environment, Environment)


# Generated at 2022-06-25 18:16:04.777387
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0 is not None

# Generated at 2022-06-25 18:16:13.382475
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    print(environment.is_windows)
    print(environment.config_dir)
    print(environment.stdin)
    print(environment.stdin_isatty)
    print(environment.stdin_encoding)
    print(environment.stdout)
    print(environment.stdout_isatty)
    print(environment.stdout_encoding)
    print(environment.stderr)
    print(environment.stderr_isatty)
    print(environment.colors)
    print(environment.program_name)
    print(environment.config)
    print(environment.devnull)


# Generated at 2022-06-25 18:16:19.405476
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()
    assert type(environment_1) == Environment
    assert environment_1.stdin_isatty == True
    assert environment_1.stdout_isatty == True
    assert environment_1.stderr_isatty == True
    assert environment_1.colors == 256
    assert environment_1.program_name == 'http'
    assert environment_1.stdin_encoding == 'UTF-8'
    assert environment_1.stdout_encoding == 'UTF-8'
    assert environment_1.stderr_encoding == 'UTF-8'


# Generated at 2022-06-25 18:16:31.712993
# Unit test for constructor of class Environment
def test_Environment():
    e = Environment()
    assert e.stdin == sys.stdin
    assert e.stdout == sys.stdout
    assert e.stderr == sys.stderr
    assert e.config_dir == DEFAULT_CONFIG_DIR
    assert e.is_windows == is_windows
    assert e.colors == 256
    assert e.stdout_encoding == sys.stdout.encoding
    assert e.stderr_encoding == sys.stderr.encoding
    assert e.stdin_encoding == sys.stdin.encoding
    assert isinstance(e.stdin, IO)
    assert isinstance(e.stdout, IO)
    assert isinstance(e.stderr, IO)
    assert isinstance(e.config, Config)

# Generated at 2022-06-25 18:16:32.806359
# Unit test for constructor of class Environment
def test_Environment():
    
    instance = Environment()

    try:
        assert isinstance(instance, Environment)
    except AssertionError:
        print('AssertionError raised when Environment() is called')



# Generated at 2022-06-25 18:16:36.983392
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment(devnull=None)
    environment_0.__init__()
    assert environment_0.stderr_encoding is None
    assert environment_0.stdin_encoding is None
    assert environment_0.stdout_encoding is None



# Generated at 2022-06-25 18:16:46.016446
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.program_name == 'http'

# Generated at 2022-06-25 18:16:57.840287
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows == is_windows
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == True
    assert environment.stdin_encoding == 'utf8'
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == True
    assert environment.stdout_encoding == 'utf8'
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == True
    assert environment.colors == 256
    assert environment.program_name == 'http'
    assert environment.config == Config(directory=self.config_dir)
    assert environment.devnull == open(os.devnull, 'w+')

# Generated at 2022-06-25 18:17:02.718261
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name='http',
                      stdin=StringIO('a'),
                      stdout=StringIO(),
                      stderr=StringIO())
    assert env.program_name == 'http'
    assert env.stdin == 'a'
    assert env.stdout == ''
    assert env.stderr == ''



# Generated at 2022-06-25 18:17:03.149357
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()


# Generated at 2022-06-25 18:17:10.979454
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment.is_windows == is_windows
    assert Environment.config_dir == DEFAULT_CONFIG_DIR
    assert Environment.stdin == sys.stdin
    assert Environment.stdin_isatty == sys.stdin.isatty()
    assert Environment.stdout == sys.stdout
    assert Environment.stdout_isatty == sys.stdout.isatty()
    assert Environment.stderr == sys.stderr
    assert Environment.stderr_isatty == sys.stderr.isatty()
    assert Environment.program_name == 'http'



# Generated at 2022-06-25 18:17:19.597030
# Unit test for constructor of class Environment
def test_Environment():
    try:
        os.mkdir(Path.home() / '.httpie')
    except FileExistsError:
        pass
    try:
        config_file = open(Path.home() / '.httpie' / 'config.json', 'w+')
        config_file.write('{"colors":{"short":{"Q":"blue"}}}')
        config_file.close()
    except FileNotFoundError:
        pass
    environment_0 = Environment()
    print(environment_0)
    print('stdin:', environment_0.stdin)
    print('stdout:', environment_0.stdout)
    print('stderr:', environment_0.stderr)
    print('isatty:', environment_0.stdout_isatty)

# Generated at 2022-06-25 18:17:31.086196
# Unit test for constructor of class Environment
def test_Environment():
    # Check the instance of the environment
    environment = Environment()
    if environment is None or not isinstance(environment, Environment):
        raise Exception(
            "Constructor of Environment has failed, no instance is returned.")

    # Check the default values

# Generated at 2022-06-25 18:17:33.723876
# Unit test for constructor of class Environment
def test_Environment():
    try:
        environment = Environment()
    except:
        assert False
    else:
        assert True


if __name__ == "__main__":
    test_case_0()
    test_Environment()

# Generated at 2022-06-25 18:17:38.475184
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment(config_dir=Path('/home/.config/httpie'),
                       stdin=sys.stdin,
                       stdout=sys.stdout,
                       stderr=None) is not None


# Generated at 2022-06-25 18:17:41.895631
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=sys.stdin,
                      stdout=sys.stdout,
                      stderr=sys.stderr,
                      config_dir=Path(DEFAULT_CONFIG_DIR),
                      colors=256,
                      program_name="http",
                      devnull=None)
    assert_equal(env.stdin, sys.stdin)
    assert_equal(env.stdout, sys.stdout)
    assert_equal(env.stderr, sys.stderr)
    assert_equal(env.config_dir, Path(DEFAULT_CONFIG_DIR))
    assert_true(env.colors == 256)
    assert_true(env.program_name == "http")
    assert_is_none(env.devnull)


# Generated at 2022-06-25 18:17:43.541479
# Unit test for constructor of class Environment
def test_Environment():
    assert hasattr(Environment, '__init__')
    assert hasattr(Environment, '__dict__')


# Generated at 2022-06-25 18:18:00.456866
# Unit test for constructor of class Environment
def test_Environment():
    # Arrange
    devnull = open('devnull.txt', 'w+')
    expected_stdout_isatty = os.isatty(sys.stdout.fileno())
    expected_stderr_isatty = os.isatty(sys.stderr.fileno())
    expected_stdin_isatty = os.isatty(sys.stdin.fileno())
    expected_stdin_encoding = getattr(sys.stdin, 'encoding', None) or 'utf8'
    expected_stdout_encoding = getattr(sys.stdout, 'encoding', None) or 'utf8'
    expected_stderr_encoding = getattr(sys.stderr, 'encoding', None) or 'utf8'
    expected_colors = 256

# Generated at 2022-06-25 18:18:11.633698
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.is_windows == is_windows
    assert environment_0.config_dir == DEFAULT_CONFIG_DIR
    assert environment_0.stdin == sys.stdin
    assert environment_0.stdin_isatty == (sys.stdin.isatty() if sys.stdin else False)
    assert environment_0.stdin_encoding == (getattr(sys.stdin, 'encoding', None) or 'utf8')
    assert environment_0.stdout == sys.stdout
    assert environment_0.stdout_isatty == sys.stdout.isatty()
    assert environment_0.stdout_encoding == (getattr(sys.stdout, 'encoding', None) or 'utf8')

# Generated at 2022-06-25 18:18:18.129816
# Unit test for constructor of class Environment
def test_Environment():
    # Test for constructor of class Environment
    # Test for
    # 1. colorama
    # 2. is_windows
    # 3. DEFAULT_CONFIG_DIR
    # 4. stdin
    # 5. stdin.isatty
    # 6. stdout
    # 7. stdout.isatty
    # 8. stderr
    # 9. stderr.isatty
    # 10. colors
    # 11. program_name
    # 12. stdin_encoding
    # 13. stdout_encoding, stdout may be a colorama.AnsiToWin32 instance
    # 14. stderr_encoding

    import tempfile

    temp_file_object, temp_file_name = tempfile.mkstemp()

# Generated at 2022-06-25 18:18:22.277157
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.__class__.__name__ == 'Environment'
    assert env.__class__.__module__ == 'httpie.environment'
    

# Generated at 2022-06-25 18:18:27.172649
# Unit test for constructor of class Environment
def test_Environment():
    devnull = open(os.devnull, 'w+')
    environment_1 = Environment(devnull=devnull, config_dir=Path('../test/test-config'))
    assert environment_1 is not None
    assert environment_1.devnull is devnull
    assert environment_1.config_dir == Path('../test/test-config')


# Generated at 2022-06-25 18:18:32.688086
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.is_windows == False
    assert environment_0.config_dir == Path('~/.config/httpie')
    assert environment_0.stdin == stdin
    assert environment_0.stdin_isatty == stdin.isatty()
    assert environment_0.stdout_isatty == stdout.isatty()
    assert environment_0.stderr_isatty == stderr.isatty()
    assert environment_0.program_name == 'http'


# Generated at 2022-06-25 18:18:37.142131
# Unit test for constructor of class Environment
def test_Environment():
    stdout_backup = sys.stdout
    sys.stdout = open(os.devnull, 'w')
    environment = Environment()
    assert isinstance(environment, Environment)
    sys.stdout = stdout_backup



# Generated at 2022-06-25 18:18:46.815385
# Unit test for constructor of class Environment
def test_Environment():
    ev = Environment()
    assert ev.is_windows == is_windows
    assert ev.config_dir == DEFAULT_CONFIG_DIR
    assert ev.stdin == sys.stdin
    assert ev.stdout == sys.stdout
    assert ev.stderr == sys.stderr
    assert ev.colors == 256
    assert ev.program_name == 'http'
    assert ev.stdin_isatty == ev.stdin.isatty()
    assert ev.stdout_isatty == ev.stdout.isatty()
    assert ev.stderr_isatty == ev.stderr.isatty()
    assert ev.stdin_encoding == (getattr(ev.stdin, 'encoding', None))

# Generated at 2022-06-25 18:18:47.628073
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()



# Generated at 2022-06-25 18:18:57.248000
# Unit test for constructor of class Environment
def test_Environment():

    # Check all the attributes.
    env = Environment()
    assert env.is_windows is is_windows
    assert env.config_dir is DEFAULT_CONFIG_DIR
    assert env.stdin is sys.stdin
    assert env.stdin_isatty is env.stdin.isatty()
    assert env.stdin_encoding is None
    assert env.stdout is sys.stdout
    assert env.stdout_isatty is env.stdout.isatty()
    assert env.stdout_encoding is None
    assert env.stderr is sys.stderr
    assert env.stderr_isatty is env.stderr.isatty()
    assert env.colors
    assert env.program_name == 'http'

    # Check environment_0
    assert test_

# Generated at 2022-06-25 18:19:23.548816
# Unit test for constructor of class Environment
def test_Environment():
    try:
        test_case_0()
    except:
        print('[Test failed] Environment::__init__')


# Generated at 2022-06-25 18:19:24.650972
# Unit test for constructor of class Environment
def test_Environment():
    assert test_case_0() is None


# Generated at 2022-06-25 18:19:26.739872
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0 


# Generated at 2022-06-25 18:19:36.790922
# Unit test for constructor of class Environment
def test_Environment():
	# Test for default values
	assert isinstance(Environment(), Environment)
	assert Environment().is_windows == is_windows
	assert Environment().config_dir == DEFAULT_CONFIG_DIR
	assert Environment().stdin == sys.stdin
	assert Environment().stdin_isatty == sys.stdin.isatty()
	assert Environment().stdout == sys.stdout
	assert Environment().stdout_isatty == sys.stdout.isatty()
	assert Environment().stderr == sys.stderr
	assert Environment().stderr_isatty == sys.stderr.isatty()
	assert Environment().colors == 256
	assert Environment().program_name == 'http'

	# Test for assigned values
	assert isinstance(Environment(**{'is_windows': True}), Environment)
	assert Environment

# Generated at 2022-06-25 18:19:41.589539
# Unit test for constructor of class Environment
def test_Environment():
    file = open('/dev/null', 'w+')
    environment_1 = Environment(devnull=file)
    assert environment_1.config_dir == DEFAULT_CONFIG_DIR
    assert environment_1.stdin is sys.stdin
    assert environment_1.stdin_isatty is True
    assert environment_1.stdin_encoding is 'utf8'
    assert environment_1.stdout is sys.stdout
    assert environment_1.stdout_isatty is True
    assert environment_1.stdout_encoding is 'utf8'
    assert environment_1.stderr is sys.stderr
    assert environment_1.stderr_isatty is True

    assert environment_1._devnull == file


# Generated at 2022-06-25 18:19:50.772611
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(program_name="kek", stdin=None, stdout=sys.stderr, stderr=sys.stdout,
                              stdin_encoding='utf-8', stdout_encoding='utf-8', stderr_encoding=None)
    assert environment.program_name == "kek"
    assert environment.stdin is None
    assert environment.stdout == sys.stderr
    assert environment.stderr == sys.stdout
    assert environment.stdin_encoding == 'utf-8'
    assert environment.stdout_encoding == 'utf-8'
    assert environment.stderr_encoding is None


# Generated at 2022-06-25 18:19:52.398061
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().is_windows is True or False


# Generated at 2022-06-25 18:19:57.054170
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr)
    assert environment.stdin == sys.stdin
    assert environment.stdout == sys.stdout
    assert environment.stderr == sys.stderr
    assert environment.is_windows == sys.platform.startswith('win')

# Generated at 2022-06-25 18:20:03.586939
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()
    assert environment_1.is_windows == is_windows
    assert environment_1.config_dir == DEFAULT_CONFIG_DIR
    assert environment_1.stdin == sys.stdin
    assert environment_1.stdin_isatty == (sys.stdin.isatty() if sys.stdin else False)
    assert environment_1.stdin_encoding == None
    assert environment_1.stdout == sys.stdout
    assert environment_1.stdout_isatty == sys.stdout.isatty()
    assert environment_1.stdout_encoding == None
    assert environment_1.stderr == sys.stderr
    assert environment_1.stderr_isatty == sys.stderr.isatty()
    assert environment_1.col

# Generated at 2022-06-25 18:20:07.816052
# Unit test for constructor of class Environment
def test_Environment():
    try:
        env = Environment()
    except:
        assert False

    # System is Linux or Mac OS
    assert env.is_windows == False

    # Test standard streams
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr

    # Current directory is /home
    assert env.config_dir == DEFAULT_CONFIG_DIR

# test_case_1

# Generated at 2022-06-25 18:20:34.022464
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(
        is_windows = True,
        config_dir = '~/.httpie',
        stdin = None,
        stdin_isatty = False,
        stdin_encoding = 'utf8',
        stdout = sys.stdout,
        stdout_isatty = sys.stdout,
        stdout_encoding = 'utf8',
        stderr = sys.stderr,
        stderr_isatty = sys.stderr,
        program_name = 'httpie',
        colors = 256)
    # check is_windows
    assert environment.is_windows == True
    # check config_dir
    assert environment.config_dir.is_absolute() == False
    # check stdin
    assert environment.stdin == None
    # check stdin_isatty

# Generated at 2022-06-25 18:20:42.903818
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(config_dir = "/test_httpie_config_dir", stdin = sys.stdin, stdin_isatty = True, stdin_encoding = None, stdout = sys.stdout, stdout_isatty = True, stdout_encoding = None, stderr = sys.stderr, stderr_isatty = True, colors = 256, program_name = "http")
    print(environment)
    print(environment.__dict__)
    print(environment.config)


# Generated at 2022-06-25 18:20:46.872820
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(devnull=1, is_windows=1, program_name='1')
    assert environment_1.devnull==1
    assert environment_1.is_windows==1
    assert environment_1.program_name == '1'
    
# Test of the getters and setters of the class Environment

# Generated at 2022-06-25 18:20:50.210039
# Unit test for constructor of class Environment
def test_Environment():
    """
    This unit test is used to test the constructor of the class Environment.
    :return: 
    """
    assert Environment(env=None)
    print('The constructor of the class Environment is right!')


# Generated at 2022-06-25 18:20:55.188297
# Unit test for constructor of class Environment
def test_Environment():
    environment_test = Environment(program_name = "httpie_test")
    assert environment_test.program_name == "httpie_test"
    assert not environment_test.stdin_isatty
    assert environment_test.stdout_isatty
    assert environment_test.stderr_isatty
    assert environment_test.colors == 256


# Generated at 2022-06-25 18:20:58.610985
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.is_windows == is_windows
    assert environment_0.config_dir == DEFAULT_CONFIG_DIR


# Generated at 2022-06-25 18:21:06.656529
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.stdin == sys.stdin
    assert environment_0.stdin_encoding == 'utf8'
    assert environment_0.stdout == sys.stdout_isatty
    assert environment_0.stdout_encoding == 'utf8'
    assert environment_0.stderr == sys.stderr
    assert environment_0.stderr_isatty == sys.stderr.isatty()
    assert environment_0.colors == 256
    assert environment_0.program_name == 'http'


# Generated at 2022-06-25 18:21:10.714671
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(
        stdin=123,
        stdin_isatty=False,
        stdin_encoding='utf8',
        stdout=123,
        stdout_isatty=False,
        stdout_encoding='utf8',
        stderr=123,
        stderr_isatty=False,
        colors=123,
        program_name='http'
    )

# Generated at 2022-06-25 18:21:22.348576
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.is_windows == True
    assert (environment_0.config_dir == 'C:\\Users\\jeffrey.hong\\AppData\\Roaming\\httpie')
    assert environment_0.stdin == sys.stdin
    assert environment_0.stdin_isatty == True
    assert environment_0.stdin_encoding == 'cp949'
    assert environment_0.stdout == sys.stdout
    assert environment_0.stdout_isatty == True
    assert environment_0.stdout_encoding == 'cp949'
    assert environment_0.stderr == sys.stderr
    assert environment_0.stderr_isatty == True
    assert environment_0.colors == 256

# Generated at 2022-06-25 18:21:24.536719
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()

    if curses:
        assert isinstance(environment, Environment)



# Generated at 2022-06-25 18:21:43.046334
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0

# Test for method __str__ of class Environment

# Generated at 2022-06-25 18:21:54.946514
# Unit test for constructor of class Environment
def test_Environment():
    """
    Tests for the Environment class

    :return: None
    """

    # because is_windows is cached
    import httpie.config
    reload(httpie.config)
    from httpie.config import Environment

    stdin = sys.stdin
    stdout = sys.stdout
    stderr = sys.stderr

    class MockStdin(object):
        def read(self):
            return 'string'

    class MockStdout(object):
        def write(self, s):
            pass

        def flush(self):
            pass

    class MockStderr(object):
        def write(self, s):
            pass

        def flush(self):
            pass

    class MockConfig(Config):
        is_new = False

    mock_stdin = MockStdin()
    mock_stdout

# Generated at 2022-06-25 18:22:07.203791
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert isinstance(environment, Environment)

# Generated at 2022-06-25 18:22:18.918056
# Unit test for constructor of class Environment
def test_Environment():
    '''
    test the constructor of class Environment 
    '''

# Generated at 2022-06-25 18:22:26.725066
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.is_windows == is_windows
    assert environment_0.config_dir == DEFAULT_CONFIG_DIR
    assert environment_0.stdin == sys.stdin
    assert environment_0.stdin_isatty == sys.stdin.isatty()
    assert environment_0.stdin_encoding == 'utf8'
    assert environment_0.stdout == sys.stdout
    assert environment_0.stdout_isatty == sys.stdout.isatty()
    assert environment_0.stdout_encoding == 'utf8'
    assert environment_0.stderr == sys.stderr
    assert environment_0.stderr_isatty == sys.stderr.isatty()
    assert environment_0.colors == 256

# Generated at 2022-06-25 18:22:36.877185
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()
    assert environment_1.config_dir == DEFAULT_CONFIG_DIR
    assert environment_1.is_windows
    assert environment_1.stdin == sys.stdin
    assert environment_1.stdout == sys.stdout
    assert environment_1.stderr == sys.stderr

    config_dir_name = "config_dir_1"
    environment_1.config_dir = config_dir_name
    assert environment_1.config_dir == config_dir_name

    # These attributes are static

    # environment_1.is_windows = False
    # assert environment_1.is_windows

    config_dir_name = "config_dir_2"
    environment_1.config_dir = config_dir_name
    config_dir = environment_1.config_dir


# Generated at 2022-06-25 18:22:46.536832
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(config_dir="foo")
    environment_2 = Environment(is_windows=True)
    environment_3 = Environment(stdin="foobar")
    environment_4 = Environment(stdin_isatty=True)
    environment_5 = Environment(stdin_encoding="foobar")
    environment_6 = Environment(stdout="foobar")
    environment_7 = Environment(stdout_isatty=True)
    environment_8 = Environment(stdout_encoding="foobar")
    environment_9 = Environment(stderr="foobar")
    environment_10 = Environment(stderr_isatty=True)
    environment_11 = Environment(colors=256)
    environment_12 = Environment(program_name="httpie")

    assert environment_1.config_dir == "foo"


# Generated at 2022-06-25 18:22:56.761656
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment.is_windows == (os.name == 'nt')
    environment = Environment.environment
    assert environment.is_windows == (os.name == 'nt')
    assert environment.stdin is sys.stdin
    assert environment.stdout is sys.stdout
    assert environment.stderr is sys.stderr
    assert environment.stdin_isatty == sys.stdin.isatty()
    assert environment.stdout_isatty == sys.stdout.isatty()
    assert environment.stderr_isatty == sys.stderr.isatty()


# Generated at 2022-06-25 18:23:04.754552
# Unit test for constructor of class Environment

# Generated at 2022-06-25 18:23:12.642550
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment(devnull=None, is_windows=False, config_dir=None, stdin=None, stdin_isatty=False,
                                stdin_encoding=None, stdout=None, stdout_isatty=False, stdout_encoding=None,
                                stderr=None, stderr_isatty=False, colors=256, program_name=None, _orig_stderr=None,
                                _devnull=None, _config=None)


# Generated at 2022-06-25 18:23:31.859058
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-25 18:23:33.347593
# Unit test for constructor of class Environment
def test_Environment():
    assert isinstance(Environment(), Environment)


# Generated at 2022-06-25 18:23:42.296973
# Unit test for constructor of class Environment
def test_Environment():
    import io
    import curses
    import pytest
    from pathlib import Path
    from httpie.core import main
    import os

    # Configure environment variables
    environment_1 = Environment(
        devnull=None,
        is_windows=False, config_dir=Path('~/.httpie/'), stdin=io.StringIO('user\n'), stdin_isatty=False,
        stdin_encoding=None, stdout=io.StringIO(), stdout_isatty=False, stdout_encoding=None, stderr=io.StringIO(),
        stderr_isatty=False, colors=256, program_name='http')
    # Check the type of the object
    assert isinstance(environment_1, Environment)
    # Check the object constructor

# Generated at 2022-06-25 18:23:50.051376
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment(colors=4)
    assert environment_0.colors == 4
    assert environment_0.devnull is None

    environment_1 = Environment(colors=16)
    assert environment_1.colors == 16
    assert environment_1.devnull is None

    environment_2 = Environment(colors=256)
    assert environment_2.colors == 256
    assert environment_2.devnull is None


# Generated at 2022-06-25 18:23:52.690190
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(colors=123, stdin_encoding='utf16')
    assert environment_1.colors == 123 and environment_1.stdin_encoding == 'utf16'


# Generated at 2022-06-25 18:23:59.332509
# Unit test for constructor of class Environment
def test_Environment():
    if __name__ == '__main__':
        environment_0 = Environment()
        assert environment_0.is_windows == is_windows
        assert environment_0.stdin == sys.stdin
        assert environment_0.stdin_isatty == stdin.isatty() if stdin else False
        assert environment_0.stdin_encoding is None
        assert environment_0.stdout == sys.stdout
        assert environment_0.stdout_isatty == stdout.isatty()
        assert environment_0.stdout_encoding is None
        assert environment_0.stderr == sys.stderr
        assert environment_0.stderr_isatty == stderr.isatty()
        assert environment_0.program_name == 'http'


# Generated at 2022-06-25 18:24:08.339187
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment.is_windows == is_windows
    assert Environment.config_dir == DEFAULT_CONFIG_DIR
    assert Environment.stdin == sys.stdin if sys.stdin else None
    assert Environment.stdin_isatty == Environment.stdin.isatty() if sys.stdin else False
    assert Environment.stdout == sys.stdout
    assert Environment.stdout_isatty == Environment.stdout.isatty()
    assert Environment.stderr == sys.stderr
    assert Environment.stderr_isatty == Environment.stderr.isatty()
    assert Environment._orig_stderr == sys.stderr
    assert Environment._devnull is None
    assert Environment._config is None
    assert Environment.program_name == 'http'

# Generated at 2022-06-25 18:24:14.653956
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert (environment_0.__class__.__name__ == 'Environment')
    assert (environment_0.__class__.__module__ == 'httpie.environment')

# Generated at 2022-06-25 18:24:22.209332
# Unit test for constructor of class Environment

# Generated at 2022-06-25 18:24:28.924085
# Unit test for constructor of class Environment
def test_Environment():
    assert is_windows == Environment.is_windows
    assert DEFAULT_CONFIG_DIR == Environment.config_dir
    assert sys.stdin == Environment.stdin
    assert isatty(sys.stdin) == Environment.stdin_isatty
    assert sys.stdout == Environment.stdout
    assert isatty(sys.stdout) == Environment.stdout_isatty
    assert sys.stderr == Environment.stderr
    assert isatty(sys.stderr) == Environment.stderr_isatty

# Generated at 2022-06-25 18:24:58.085091
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(colors=256)
    assert environment.is_windows == True, "is_windows is unexpected!"
    assert environment.config_dir == Path(".httpie"), "config_dir is unexpected!"
    assert environment.stdin == sys.stdin, "stdin is unexpected!"
    assert environment.stdin_isatty == sys.stdin.isatty(), "stdin_isatty is unexpected!"
    assert environment.stdin_encoding == "utf8", "stdin_encoding is unexpected!"
    assert environment.stdout == sys.stdout, "stdout is unexpected!"
    assert environment.stdout_isatty == sys.stdout.isatty(), "stdout_isatty is unexpected!"
    assert environment.stdout_encoding == "utf8", "stdout_encoding is unexpected!"


# Generated at 2022-06-25 18:25:07.548867
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(devnull=None)
    assert(str(environment.is_windows)==str(is_windows))
    assert(str(environment.config_dir)==str(DEFAULT_CONFIG_DIR))
    assert(str(environment.stdin)==str(sys.stdin))
    assert(environment.stdin_isatty==sys.stdin.isatty())
    assert(environment.stdin_encoding=="utf8")
    assert(str(environment.stdout)==str(sys.stdout))
    assert(environment.stdout_isatty==sys.stdout.isatty())
    assert(environment.stdout_encoding=="utf8")
    assert(str(environment.stderr)==str(sys.stderr))

# Generated at 2022-06-25 18:25:13.378085
# Unit test for constructor of class Environment

# Generated at 2022-06-25 18:25:16.016675
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert isinstance(environment, Environment)
    assert isinstance(environment, object)

test_case_1 = Environment()


# Generated at 2022-06-25 18:25:26.039739
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.stdout is sys.stdout
    assert env.stderr is sys.stderr
    assert env.stdin is sys.stdin
    assert env.config_dir is DEFAULT_CONFIG_DIR

    if os.isatty(sys.stdin.fileno()):
        assert env.stdin_isatty
    else:
        assert not env.stdin_isatty

    if os.isatty(sys.stdout.fileno()):
        assert env.stdout_isatty
    else:
        assert not env.stdout_isatty

    if os.isatty(sys.stderr.fileno()):
        assert env.stderr_isatty
    else:
        assert not env.stderr_isatty

# Generated at 2022-06-25 18:25:37.345160
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    # Check the instance attribute _config of environment_0
    config_0 = environment_0._config
    print(config_0)
    # Check the instance property config of environment_0
    config_1 = environment_0.config
    print(config_1)
    # Check the instance attribute stdin of environment_0
    stdin_0 = environment_0.stdin
    print(stdin_0)
    # Check the instance attribute stdout of environment_0
    stdout_0 = environment_0.stdout
    print(stdout_0)
    # Check the instance attribute stderr of environment_0
    stderr_0 = environment_0.stderr
    print(stderr_0)
    # Check the instance attribute _devnull of environment_0
    devnull_0