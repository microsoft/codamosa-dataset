

# Generated at 2022-06-25 18:15:33.048108
# Unit test for constructor of class Environment
def test_Environment():
    try:
        env = Environment()
        if env is None:
            stderr('Constructor error of class Environment')
        else:
            stdout('Constructor be successful')
    except Exception as e:
        stderr(e.args)

# Generated at 2022-06-25 18:15:39.571160
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()
    assert environment_1.devnull is None
    assert environment_1.is_windows == is_windows
    assert environment_1.config_dir == DEFAULT_CONFIG_DIR
    assert environment_1.stdin == sys.stdin
    assert environment_1.stdin_isatty == sys.stdin.isatty() if sys.stdin else False
    assert environment_1.stdin_encoding == None
    assert environment_1.stdout == sys.stdout
    assert environment_1.stdout_isatty == sys.stdout.isatty()
    assert environment_1.stdout_encoding == None
    assert environment_1.stderr == sys.stderr
    assert environment_1.stderr_isatty == sys.stderr.isatty

# Generated at 2022-06-25 18:15:41.987877
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()
    assert isinstance(environment_1, Environment)

# Generated at 2022-06-25 18:15:49.415055
# Unit test for constructor of class Environment

# Generated at 2022-06-25 18:15:59.128965
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(devnull=None, stdin=sys.stdin, stdout=sys.stdout, stderr=None, stdin_encoding='utf8', stdout_encoding='utf8', stderr_encoding='utf8')
    environment_2 = Environment(devnull=None, stdin=None, stdout=None, stderr=None, stdin_encoding='utf8', stdout_encoding='utf8', stderr_encoding='utf8')
    environment_3 = Environment(devnull=None, stdin=None, stdout=sys.stdout, stderr=None, stdin_encoding='utf8', stdout_encoding='utf8', stderr_encoding='utf8')

# Generated at 2022-06-25 18:16:04.626782
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0._orig_stderr == environment_0.stderr
    assert environment_0._devnull is None
    assert environment_0.config_dir == Path(DEFAULT_CONFIG_DIR)
    assert environment_0.stdin is sys.stdin


# Generated at 2022-06-25 18:16:12.554149
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(colors=256)
    assert env.program_name == 'http'
    assert env.is_windows == is_windows
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()



# Generated at 2022-06-25 18:16:19.601501
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert type(env) == Environment
    assert env.is_windows == False
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == True
    assert env.stdin_encoding == 'UTF-8'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stdout_encoding == 'UTF-8'
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == True
    assert env.program_name == 'http'


# Generated at 2022-06-25 18:16:22.473962
# Unit test for constructor of class Environment
def test_Environment():
    assert __name__ == "__main__"
    # test case 0
    test_case_0()

# Generated at 2022-06-25 18:16:33.676439
# Unit test for constructor of class Environment
def test_Environment():
# 1
    test_0_0 = Environment(is_windows = False, config_dir = Path(".config/httpie"), stdin = None, stdin_isatty = False, stdin_encoding = None, stdout = sys.stdout, stdout_isatty = True, stdout_encoding = None, stderr = sys.stderr, stderr_isatty = True, colors = 256, program_name = 'http')
    assert test_0_0.is_windows == False
    assert test_0_0.config_dir == Path(".config/httpie")
    assert test_0_0.stdin == None
    assert test_0_0.stdin_isatty == False
    assert test_0_0.stdin_encoding == None
    assert test_0_0.std

# Generated at 2022-06-25 18:16:48.082152
# Unit test for constructor of class Environment
def test_Environment():
    with pytest.raises(Exception) as excinfo:
        Environment(devnull='None')
    assert "AssertionError" in str(excinfo.value)
    assert "not all" in str(excinfo.value)
    assert "items" in str(excinfo.value)



# Generated at 2022-06-25 18:16:53.421216
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert all(hasattr(environment, attr) for attr in (
        'is_windows',
        'config_dir',
        'stdin',
        'stdin_isatty',
        'stdout',
        'stdout_isatty',
        'stderr',
        'stderr_isatty',
        'colors',
        'program_name',
    ))

# Generated at 2022-06-25 18:16:55.436880
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0 is not None
    assert environment_0.is_windows is False


# Generated at 2022-06-25 18:16:57.462583
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()

# Generated at 2022-06-25 18:17:06.078754
# Unit test for constructor of class Environment
def test_Environment():
    try:
        test_case_0()
        test_Environment.__test_count += 1
    except:
        print("Error in test case #0")
        print("Unable to create environment")
        print("Received exception: ")
        print(sys.exc_info()[1])

    print("Number of tests passed: ", test_Environment.__test_count)
    print("Number of tests failed: ", test_Environment.__test_count - test_Environment.__test_pass)


test_Environment.__test_count = 0
test_Environment.__test_pass = test_Environment.__test_count
test_Environment()

# Generated at 2022-06-25 18:17:12.104521
# Unit test for constructor of class Environment
def test_Environment():

    environment_1 = Environment(devnull=open(os.devnull, 'w+'), is_windows=True, program_name='http', stderr_isatty=False)
    assert environment_1.devnull._name == '/dev/null'
    assert environment_1.is_windows == True
    assert environment_1.program_name == 'http'
    assert environment_1.stderr_isatty == False
    environment_1.devnull.close()



# Generated at 2022-06-25 18:17:13.768698
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(stdout=None)
    assert environment_1.stdout is None


# Generated at 2022-06-25 18:17:14.692709
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()


# Generated at 2022-06-25 18:17:22.162859
# Unit test for constructor of class Environment

# Generated at 2022-06-25 18:17:32.584693
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    environment_1 = Environment(devnull=(open(os.devnull, 'w+')))
    environment_2 = Environment(devnull=(open(os.devnull, 'w+')))

    assert environment_0.is_windows is environment_1.is_windows
    assert environment_1.is_windows is environment_2.is_windows
    assert environment_0.config_dir is environment_1.config_dir
    assert environment_1.config_dir is environment_2.config_dir
    assert environment_0.stdin is environment_1.stdin
    assert environment_1.stdin is environment_2.stdin
    assert environment_0.stdin_isatty is environment_1.stdin_isatty

# Generated at 2022-06-25 18:17:53.225072
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()
###############################################################################

###############################################################################
# Class StdStreams
###############################################################################

# Generated at 2022-06-25 18:18:00.640311
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(is_windows=False,
                              config_dir='./test_dir',
                              stdout=sys.stdout,
                              stdout_isatty=False,
                              stdout_encoding='utf-8',
                              stderr=sys.stderr,
                              stderr_isatty=False,
                              colors=256,
                              program_name='http')
    assert environment.is_windows == False
    assert environment.config_dir == './test_dir'
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == False
    assert environment.stdout_encoding == 'utf-8'
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == False

# Generated at 2022-06-25 18:18:11.799688
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert isinstance(environment, Environment)
    assert environment.is_windows == Environment.is_windows
    assert environment.stdin == Environment.stdin
    assert environment.stdin_isatty == Environment.stdin_isatty
    assert environment.stdin_encoding == Environment.stdin_encoding
    assert environment.stdout == Environment.stdout
    assert environment.stdout_isatty == Environment.stdout_isatty
    assert environment.stdout_encoding == Environment.stdout_encoding
    assert environment.stderr == Environment.stderr
    assert environment.stderr_isatty == Environment.stderr_isatty
    assert environment.colors == Environment.colors
    assert environment.program_name == Environment.program_name



# Generated at 2022-06-25 18:18:18.237557
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows == is_windows
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == sys.stdin.isatty()
    assert environment.stdin_encoding is None
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == sys.stdout.isatty()
    assert environment.stdout_encoding is None
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == sys.stderr.isatty()
    assert environment.program_name == 'http'
    assert environment.colors == 256
    assert environment._orig_stderr == sys.stderr
   

# Generated at 2022-06-25 18:18:29.705050
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()


# Generated at 2022-06-25 18:18:38.646110
# Unit test for constructor of class Environment
def test_Environment():
    dict_0 = {'stdout': sys.stdout}
    environment_0 = Environment(**dict_0)
    assert environment_0.devnull is None
    assert environment_0.stderr_isatty is False
    dict_0 = {'stdout': sys.stdout}
    environment_1 = Environment(**dict_0)
    assert environment_1.devnull is None
    assert environment_1.stderr_isatty is False
    dict_0 = {'stderr': sys.stderr}
    environment_0 = Environment(**dict_0)
    assert environment_0.devnull is None
    assert environment_0.stderr_isatty is True


# Generated at 2022-06-25 18:18:47.523403
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.is_windows == True
    assert environment_0.config_dir == Path('.httpie')
    #assert environment_0.stdin == sys.stdin
    assert environment_0.stdin_isatty == False
    assert environment_0.stdin_encoding == None
    assert environment_0.stdout == sys.stdout
    assert environment_0.stdout_isatty == True
    assert environment_0.stdout_encoding == None
    assert environment_0.stderr == sys.stderr
    assert environment_0.stderr_isatty == True
    assert environment_0.colors == 256
    assert environment_0.program_name == 'http'


# Generated at 2022-06-25 18:18:57.133415
# Unit test for constructor of class Environment
def test_Environment():
    import sys
    env = Environment()
    assert env.is_windows == sys.platform == 'win32'
    assert env.config_dir == Path(DEFAULT_CONFIG_DIR)
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert env.stdin_isatty is not None
    assert env.stdout_isatty is not None
    assert env.stderr_isatty is not None
    assert env.stdin_encoding == sys.stdin.encoding
    assert env.stdout_encoding == sys.stdout.encoding
    assert env.stderr_encoding == sys.stderr.encoding
    assert env.program_name == 'http'

# Generated at 2022-06-25 18:19:03.316877
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert_true(environment.is_windows == is_windows)
    assert_true(environment.config_dir == DEFAULT_CONFIG_DIR)
    assert_true(environment.stdin is sys.stdin)
    assert_true(environment.stdin_isatty == environment.stdin.isatty())
    assert_false(environment.stdin_encoding)
    assert_true(environment.stdout is sys.stdout)
    assert_true(environment.stdout_isatty == environment.stdout.isatty())
    assert_false(environment.stdout_encoding)
    assert_true(environment.stderr is sys.stderr)
    assert_true(environment.stderr_isatty == environment.stderr.isatty())

# Generated at 2022-06-25 18:19:14.286205
# Unit test for constructor of class Environment
def test_Environment():
    import sys, os
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_CONFIG_DIR
    from pathlib import Path

    from httpie.utils import repr_dict


    class Environment:
        """
        Information about the execution context
        (standard streams, config directory, etc).

        By default, it represents the actual environment.
        All of the attributes can be overwritten though, which
        is used by the test suite to simulate various scenarios.

        """
        is_windows: bool = is_windows
        config_dir: Path = DEFAULT_CONFIG_DIR
        stdin: Optional[IO] = sys.stdin  # `None` when closed fd (#791)
        stdin_isatty: bool = stdin.isatty() if stdin else False
        stdin_enc

# Generated at 2022-06-25 18:19:41.098112
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.__dict__['is_windows'] == is_windows
    assert environment.__dict__['config_dir'] == DEFAULT_CONFIG_DIR
    assert environment.__dict__['stdin'] == sys.stdin
    assert environment.__dict__['stdin_isatty'] == sys.stdin.isatty()
    assert environment.__dict__['stdout'] == sys.stdout
    assert environment.__dict__['stdout_isatty'] == sys.stdout.isatty()
    assert environment.__dict__['stderr'] == sys.stderr
    assert environment.__dict__['stderr_isatty'] == sys.stderr.isatty()
    assert environment.__dict__['colors'] == 256

# Generated at 2022-06-25 18:19:51.614308
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.is_windows == False
    assert environment_0.config_dir == DEFAULT_CONFIG_DIR
    assert environment_0.stdin == sys.stdin
    assert environment_0.stdin_isatty == True
    assert environment_0.stdin_encoding == 'cp936'
    assert environment_0.stdout == sys.stdout
    assert environment_0.stdout_isatty == True
    assert environment_0.stdout_encoding == 'cp936'
    assert environment_0.stderr == sys.stderr
    assert environment_0.stderr_isatty == True
    assert environment_0.program_name == 'http'
    assert environment_0._orig_stderr == sys.stderr
    assert environment

# Generated at 2022-06-25 18:19:55.255541
# Unit test for constructor of class Environment
def test_Environment():
    envir = Environment()
    assert not envir.is_windows
    assert envir.config_dir == DEFAULT_CONFIG_DIR
    assert envir.stdin == sys.stdin
    assert envir.stdin_isatty == sys.stdin.isatty()
    assert envir.stdin_encoding == None
    assert envir.stdout == sys.stdout
    assert envir.stdout_isatty == sys.stdout.isatty()
    assert envir.colors == 256
    assert envir.program_name == 'http'
    assert envir._orig_stderr == sys.stderr


# Generated at 2022-06-25 18:20:01.508149
# Unit test for constructor of class Environment
def test_Environment():
    # test case 1
    environment_1 = Environment(stdin=None,
                                stdout=sys.stdout,
                                stderr=sys.stderr,
                                devnull=None)

    # test case 2
    environment_2 = Environment(stdin=None,
                                stdout=sys.stdout,
                                stderr=sys.stderr,
                                devnull=None)

    # test case 3
    environment_3 = Environment(stdin=None,
                                stdout=sys.stdout,
                                stderr=sys.stderr,
                                devnull=None)


# Generated at 2022-06-25 18:20:12.151956
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(is_windows=True, stdin=None, stdout=None, stderr=None, program_name='http')
    assert not environment_1.is_windows
    assert environment_1.config_dir == Path(DEFAULT_CONFIG_DIR)
    assert environment_1.stdin is None
    assert not environment_1.stdin_isatty
    assert environment_1.stdin_encoding is None
    assert environment_1.stdout is None
    assert not environment_1.stdout_isatty
    assert environment_1.stdout_encoding is None
    assert environment_1.stderr is None
    assert not environment_1.stderr_isatty
    assert environment_1.program_name == 'http'



# Generated at 2022-06-25 18:20:21.989863
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=sys.stdin, stdin_encoding='UTF-8', stdout=sys.stdout, stdout_encoding='UTF-8', stderr=sys.stderr, colors=256, program_name='test')
    assert env.stdin == sys.stdin
    assert env.stdin_encoding == 'UTF-8'
    assert env.stdout == sys.stdout
    assert env.stdout_encoding == 'UTF-8'
    assert env.stderr == sys.stderr
    assert env.colors == 256
    assert env.program_name == 'test'
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.is_windows == is_windows


# Generated at 2022-06-25 18:20:31.522283
# Unit test for constructor of class Environment
def test_Environment():
    environ_1 = Environment(
        devnull = open(os.devnull, 'w+'),
        config_dir ='/home/kant/httpie/test',
        stdin = sys.stdin,
        stdin_isatty =1,
        stderr = sys.stderr,
        stderr_isatty =1,
        stdout_isatty =1,
        program_name = "http"
    )
    print(environ_1)   
    assert environ_1.colors == 256


# Generated at 2022-06-25 18:20:32.895420
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env is not None


# Generated at 2022-06-25 18:20:33.670781
# Unit test for constructor of class Environment
def test_Environment():
    #Tests successful instantiation
    assert Environment() != None

# Generated at 2022-06-25 18:20:36.414807
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0


# Generated at 2022-06-25 18:21:26.033544
# Unit test for constructor of class Environment
def test_Environment():
    from unittest import mock
    env = Environment(devnull=1)
    assert env._devnull == 1
    mock_stdin = mock.Mock()
    mock_stdout = mock.Mock()
    mock_stderr = mock.Mock()
    mock_stdin.isatty.return_value = False
    mock_stdout.isatty.return_value = False
    mock_stderr.isatty.return_value = False
    env = Environment(stdin=mock_stdin, stdout=mock_stdout, stderr=mock_stderr)
    assert env.stdin_isatty == False
    assert env.stdout_isatty == False
    assert env.stderr_isatty == False
    assert env._devnull == 1



# Generated at 2022-06-25 18:21:33.760776
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(devnull='devnull',
                                is_windows=True,
                                config_dir=Path('config-dir'),
                                stdin=sys.stdin,
                                stdin_isatty=True,
                                stdin_encoding='utf8',
                                stdout=sys.stdout,
                                stdout_isatty=True,
                                stdout_encoding='utf8',
                                stderr=sys.stderr,
                                stderr_isatty=True,
                                colors=256,
                                program_name='http')
    assert environment_1.is_windows == True
    assert environment_1.devnull == 'devnull'
    assert str(environment_1.config_dir) == 'config-dir'

# Generated at 2022-06-25 18:21:37.588546
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(config_dir=Path(), program_name='http-test')
    assert environment_1.config_dir == Path() and environment_1.program_name == 'http-test'

# Generated at 2022-06-25 18:21:40.101517
# Unit test for constructor of class Environment
def test_Environment():
    try:
        test_case_0()
    except:
        print("Error while testing Constructor of Environment")



# Generated at 2022-06-25 18:21:42.090005
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(stdin=open("input.txt","r"), stdout=open("output.txt","w"))
    assert environment != None


# Generated at 2022-06-25 18:21:54.910619
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    environment_0.config_dir = "DefalutPath"
    assert environment_0.config_dir == "DefaultPath"
    environment_0.stdin = None
    environment_0.stdin_isatty = False
    environment_0.stdin_encoding = "None"
    environment_0.stdout = sys.stdout
    environment_0.stdout_isatty = True
    environment_0.stdout_encoding = "None"
    environment_0.stderr = sys.stderr
    environment_0.stderr_isatty = True
    environment_0.colors = 256
    environment_0.program_name = "http"
    assert environment_0.is_windows == is_windows == False


# Generated at 2022-06-25 18:22:05.957583
# Unit test for constructor of class Environment
def test_Environment():
    default_environment = Environment()
    assert default_environment.is_windows == True
    assert default_environment.config_dir == DEFAULT_CONFIG_DIR
    assert default_environment.stdin != None
    assert default_environment.stdin_encoding == None
    assert default_environment.stdout == sys.stdout
    assert default_environment.stdout_isatty == True
    assert default_environment.stdout_encoding == None
    assert default_environment.stderr == sys.stderr
    assert default_environment.stderr_isatty == True
    assert default_environment.colors == 256
    assert default_environment.program_name == "http"



# Generated at 2022-06-25 18:22:08.539668
# Unit test for constructor of class Environment
def test_Environment():
    try:
        environment = Environment(stdin='p')
        assert environment.stdin == 'p'
    except:
        print('Test for constructor of class Environment failed.')


# Generated at 2022-06-25 18:22:09.728201
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().stdin == sys.stdin


# Generated at 2022-06-25 18:22:21.543782
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(
        devnull = '/dev/null',
        is_windows = True,
        config_dir = '.',
        stdin = None,
        stdin_isatty = False,
        stdin_encoding = 'utf8',
        stdout = None,
        stdout_isatty = True,
        stdout_encoding = 'utf8',
        stderr = None,
        stderr_isatty = True,
        colors = 8,
        program_name = 'http',
    )
    assert environment_1.devnull == '/dev/null'
    assert environment_1.is_windows == True
    assert environment_1.config_dir == '.'
    assert environment_1.stdin == None
    assert environment_1.stdin_isatty == False


# Generated at 2022-06-25 18:23:40.706184
# Unit test for constructor of class Environment
def test_Environment():
    assert isinstance(Environment(), Environment)

# Generated at 2022-06-25 18:23:47.697014
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(stdin=None)
    assert environment_1.stdin is None
    environment_2 = Environment(stdout=None)
    assert environment_2.stdout is None
    environment_3 = Environment(stderr=None)
    assert environment_3.stderr is None
    environment_4 = Environment(colors=None)
    assert environment_4.colors is None
    environment_5 = Environment(program_name=None)
    assert environment_5.program_name is None


# Generated at 2022-06-25 18:23:59.120739
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment(stdin_isatty=False)
    environment_1 = Environment(stdin_isatty=True)
    environment_2 = Environment(stdout_isatty=False)
    environment_3 = Environment(stdout_isatty=True)
    environment_4 = Environment(stderr_isatty=False)
    environment_5 = Environment(stderr_isatty=True)
    environment_6 = Environment(colors=256)
    environment_7 = Environment(colors=0)
    environment_8 = Environment(program_name='http')
    environment_9 = Environment(program_name='')
    environment_10 = Environment(is_windows=True)
    environment_11 = Environment(is_windows=False)

# Generated at 2022-06-25 18:24:01.299550
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()


if __name__ == '__main__':
    import pytest
    pytest.main(__file__)

# Generated at 2022-06-25 18:24:10.133763
# Unit test for constructor of class Environment
def test_Environment():
    """
    test case 1:
        if stdin is None or stdin is not a tty
    test case 2:
        if stdout is not None and stdout is a tty
    test case 3:
        if stderr is not None and stderr is a tty

    """
    environment_1 = Environment(stdin=None)
    assert environment_1.stdin == None
    assert environment_1.stdin_isatty == False
    assert environment_1.stdin_encoding == 'utf8'
    assert environment_1.stdout_encoding == 'utf8'

    environment_2 = Environment(config_dir=DEFAULT_CONFIG_DIR, stdin=None)
    assert environment_2.is_windows == False
    assert environment_2.colors == 256

    environment_3 = Environment()

# Generated at 2022-06-25 18:24:20.662688
# Unit test for constructor of class Environment
def test_Environment():
    # Create an object using Environment()
    print("Create an object using Environment()")
    environment = Environment()
    print(type(environment))
    print(environment)
    try:
        environment.log_error('test')
    except Exception:
        pass
    print(environment.stderr)
    try:
        print(environment.devnull)
    except Exception:
        pass
    try:
        environment.config
    except Exception:
        pass
    # Create an object from class Environment
    print()
    print("Create an object from class Environment")

# Generated at 2022-06-25 18:24:30.194714
# Unit test for constructor of class Environment
def test_Environment():
    # environment_0 = Environment() # Init object
    assert environment_0.is_windows == 0
    assert environment_0.config_dir == Path('c:/Users/Administrator/.config/httpie')
    assert environment_0.stdin == sys.stdin # `None` when closed fd
    assert environment_0.stdin_isatty == True
    assert environment_0.stdin_encoding == None
    assert environment_0.stdout == sys.stdout
    assert environment_0.stdout_isatty == True
    assert environment_0.stdout_encoding == None
    assert environment_0.stderr == sys.stderr
    assert environment_0.stderr_isatty == True
    assert environment_0.program_name == 'http'
    assert environment_0._orig_stder

# Generated at 2022-06-25 18:24:31.001531
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()

# Generated at 2022-06-25 18:24:37.878933
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows == is_windows
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == sys.stdin.isatty()
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == sys.stdout.isatty()
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == sys.stderr.isatty()
    assert environment.colors == 256
    assert environment.program_name == 'http'


# Generated at 2022-06-25 18:24:39.430976
# Unit test for constructor of class Environment
def test_Environment():
    assert type(Environment())==Environment