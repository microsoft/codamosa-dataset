

# Generated at 2022-06-25 18:15:38.380810
# Unit test for constructor of class Environment
def test_Environment():
    try:
        from httpie import ExitStatus, ExitStatusException
    except ModuleNotFoundError:
        from httpie.cli import ExitStatus, ExitStatusException
    import sys
    import os
    from pathlib import Path
    from typing import IO
    import curses
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.utils import repr_dict
    assert sys.stdin
    assert sys.stdout
    environment_0 = Environment()
    assert environment_0.stdin_isatty
    assert environment_0.stdout_isatty
    assert environment_0.stderr_isatty
    assert environment_0.stderr
    assert environment_0.stdout
    assert environment_0.stdin
    assert not curses
    assert environment

# Generated at 2022-06-25 18:15:39.448885
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()



# Generated at 2022-06-25 18:15:48.501305
# Unit test for constructor of class Environment
def test_Environment():
    try:
        stdin = open('/dev/ttys003', 'r')
    except OSError:
        stdin = None
    environment = Environment(
        program_name = 'test',
        config_dir = '/User/lijing/.httpie',
        stdin = stdin,
        stdin_isatty = stdin.isatty() if stdin else False,
        stdin_encoding = None,
        stdout = sys.stdout,
        stdout_isatty = sys.stdout.isatty(),
        stdout_encoding = None,
        stderr = sys.stderr,
        stderr_isatty = sys.stderr.isatty(),
        colors = 256,
        is_windows = is_windows()
    )

# Generated at 2022-06-25 18:15:57.914614
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows == is_windows
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin_isatty == sys.stdin.isatty()
    assert environment.stdin_encoding == None
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == sys.stdout.isatty()
    assert environment.stdout_encoding == None
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == sys.stderr.isatty()
    assert environment.colors == 256
    assert environment.program_name == 'http'

# Generated at 2022-06-25 18:16:10.613573
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(is_windows=True, config_dir=Path("/config"), stdin=sys.stdin, stdin_isatty=True,
                        stdin_encoding=None, stdout=sys.stdout, stdout_isatty=True, stdout_encoding=None,
                        stderr=sys.stderr, stderr_isatty=True, colors=0, program_name="http")

# Generated at 2022-06-25 18:16:18.138583
# Unit test for constructor of class Environment
def test_Environment():
    e1 = Environment()
    assert e1.is_windows == is_windows
    assert e1.config_dir == DEFAULT_CONFIG_DIR
    assert e1.stdin == sys.stdin
    assert e1.stdin_isatty == e1.stdin.isatty()
    assert e1.stdout == sys.stdout
    assert e1.stdout_isatty == e1.stdout.isatty()
    assert e1.stderr == sys.stderr
    assert e1.stderr_isatty == e1.stderr.isatty()
    assert e1.colors == 256
    assert e1.program_name == 'http'

# Generated at 2022-06-25 18:16:22.233780
# Unit test for constructor of class Environment
def test_Environment():
    my_env = Environment()
    my_env.program_name = 'httpie_tester'
    print(my_env)
    print(my_env.config)


# Generated at 2022-06-25 18:16:33.244143
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()
    assert environment_1.is_windows == is_windows
    assert environment_1.config_dir == DEFAULT_CONFIG_DIR
    assert environment_1.stdin == sys.stdin
    assert environment_1.stdin_isatty == bool(sys.stdin.isatty())
    assert environment_1.stdin_encoding == None
    assert environment_1.stdout == sys.stdout
    assert environment_1.stdout_isatty == bool(sys.stdout.isatty())
    assert environment_1.stdout_encoding == None
    assert environment_1.stderr == sys.stderr
    assert environment_1.stderr_isatty == bool(sys.stderr.isatty())
    assert environment_1.colors == 256

# Generated at 2022-06-25 18:16:34.213475
# Unit test for constructor of class Environment
def test_Environment():
    assert isinstance(Environment(), Environment)


# Generated at 2022-06-25 18:16:35.326230
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()


# Generated at 2022-06-25 18:16:51.427803
# Unit test for constructor of class Environment
def test_Environment():
    env0 = Environment()

# Generated at 2022-06-25 18:17:00.676787
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment is not None
    assert environment.is_windows == is_windows
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == sys.stdin.isatty()
    assert environment.stdin_encoding is None
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == sys.stdout.isatty()
    assert environment.stdout_encoding is None
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == sys.stderr.isatty()
    if is_windows:
        assert environment.colors == 0
    else:
        assert environment.colors != 0

# Generated at 2022-06-25 18:17:07.095787
# Unit test for constructor of class Environment
def test_Environment():
    with open(os.devnull, 'w+') as devnull:
        environment_1 = Environment(devnull=devnull)
    assert environment_1.devnull.name == '/dev/null'
    devnull.close()
    assert environment_1.devnull.closed

    environment_2 = Environment(devnull=devnull)
    assert environment_2.devnull.name == '/dev/null'
    assert environment_2.devnull.closed


# Generated at 2022-06-25 18:17:11.712100
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr, config_dir=DEFAULT_CONFIG_DIR)
    assert env.stdin_encoding == sys.stdin.encoding
    assert env.stdout_encoding == sys.stdout.encoding

# Generated at 2022-06-25 18:17:19.597228
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.is_windows == is_windows
    assert environment_0.config_dir == DEFAULT_CONFIG_DIR
    assert environment_0.stdin == sys.stdin
    assert environment_0.stdin_isatty == stdin_isatty
    assert environment_0.stdout == sys.stdout
    assert environment_0.stdout_isatty == stdout_isatty
    assert environment_0.stderr == sys.stderr
    assert environment_0.stderr_isatty == stderr_isatty
    assert environment_0.colors == colors
    assert environment_0.program_name == 'http'


# Generated at 2022-06-25 18:17:24.800996
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    environment_0.devnull = open(os.devnull, 'w+')
    environment_0.config_dir = DEFAULT_CONFIG_DIR
    environment_0.stdin = sys.stdin  # `None` when closed fd (#791)
    environment_0.stdin_isatty = environment_0.stdin.isatty() if environment_0.stdin else False
    environment_0.stdin_encoding = None
    environment_0.stdout = sys.stdout
    environment_0.stdout_isatty = environment_0.stdout.isatty()
    environment_0.stdout_encoding = None
    environment_0.stderr = sys.stderr

# Generated at 2022-06-25 18:17:33.783988
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    environment_1 = Environment(devnull = None)
    environment_2 = Environment(is_windows = False)
    environment_3 = Environment(config_dir = Path("./httpie"))
    environment_4 = Environment(stdin = os.fdopen(0))
    environment_5 = Environment(stdin_isatty = True)
    environment_6 = Environment(stdin_encoding = "utf8")
    environment_7 = Environment(stdout = os.fdopen(1))
    environment_8 = Environment(stdout_isatty = True)
    environment_9 = Environment(stdout_encoding = "utf8")
    environment_10 = Environment(stderr = os.fdopen(2))
    environment_11 = Environment(stderr_isatty = True)
    environment

# Generated at 2022-06-25 18:17:45.327965
# Unit test for constructor of class Environment

# Generated at 2022-06-25 18:17:51.379132
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()

    assert environment_0.is_windows == is_windows
    assert environment_0.stdin == sys.stdin
    assert environment_0.stdout == sys.stdout
    assert environment_0.stderr == sys.stderr
    assert environment_0.config_dir == DEFAULT_CONFIG_DIR
    assert environment_0.program_name == "http"
    assert environment_0._orig_stderr == sys.stderr


# Generated at 2022-06-25 18:17:59.602141
# Unit test for constructor of class Environment