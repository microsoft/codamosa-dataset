

# Generated at 2022-06-25 18:15:37.632372
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()


# Generated at 2022-06-25 18:15:47.695367
# Unit test for constructor of class Environment
def test_Environment():
    is_windows_0 = is_windows
    config_dir_0 = DEFAULT_CONFIG_DIR
    stdin_0 = sys.stdin
    stdin_isatty_0 = stdin_0.isatty()
    stdout_0 = sys.stdout
    stdout_isatty_0 = stdout_0.isatty()
    stderr_0 = sys.stderr
    stderr_isatty_0 = stderr_0.isatty()
    colors_0 = 256
    program_name_0 = 'http'
    if not is_windows_0:
        if curses:
            try:
                curses.setupterm()
                colors_0 = curses.tigetnum('colors')
            except curses.error:
                pass

# Generated at 2022-06-25 18:15:50.348352
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    env.program_name = "http"
    assert env.program_name == "http"
    del env


# Generated at 2022-06-25 18:15:56.205200
# Unit test for constructor of class Environment
def test_Environment():
    stderr_original = sys.stderr
    stdout_original = sys.stdout
    stdin_original = sys.stdin
    environment = Environment(stderr=stderr_original, stdout=stdout_original, stdin=stdin_original)
    r = environment.stderr_isatty
    assert r == True
    r = environment.colors
    assert r == 256

# Generated at 2022-06-25 18:15:58.553091
# Unit test for constructor of class Environment
def test_Environment():
    environment_test = Environment(stdout=sys.stdout, stderr=sys.stderr, stdin=sys.stdin)
    assert isinstance(environment_test, Environment)


# Generated at 2022-06-25 18:16:10.662031
# Unit test for constructor of class Environment
def test_Environment():
    from io import StringIO
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from httpie.utils import unicode_output
    from httpie.config import Config
    from httpie.compat import is_windows

    with TemporaryDirectory() as config_dir:
        with StringIO() as devnull:
            environment = Environment(stdin=StringIO(),
                                      stdout=StringIO(),
                                      stderr=StringIO(),
                                      config_dir=Path(config_dir),
                                      devnull=devnull)

            assert environment.stdin.read() == ''
            assert environment.stdout.getvalue() == ''
            assert environment.stderr.getvalue() == ''
            assert environment.stdin_isatty == False
            assert environment.stdout_isatty == False
            assert environment.st

# Generated at 2022-06-25 18:16:19.800840
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.is_windows == True,"test_case_name_0 failed"
    assert environment_0.config_dir == Path("C:/Users/lzxb/.httpie"),"test_case_name_1 failed"
    assert environment_0.stdin == sys.stdin,"test_case_name_2 failed"
    assert environment_0.stdin_isatty == False,"test_case_name_3 failed"
    assert environment_0.stdin_encoding == None,"test_case_name_4 failed"
    assert environment_0.stdout == sys.stdout,"test_case_name_5 failed"
    assert environment_0.stdout_isatty == True,"test_case_name_6 failed"
    assert environment_0.stdout_encoding == None

# Generated at 2022-06-25 18:16:29.949582
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(
        stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr,
        is_windows=is_windows,
        config_dir=DEFAULT_CONFIG_DIR,
        program_name='http'
    )
    assert environment_1 == Environment(
        stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr,
        is_windows=is_windows,
        config_dir=DEFAULT_CONFIG_DIR,
        program_name='http'
    )
    assert environment_1 != Environment()

# Generated at 2022-06-25 18:16:38.151014
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    environment_1 = Environment(is_windows=False,
                                config_dir=DEFAULT_CONFIG_DIR,
                                stdin=sys.stdin,
                                stdin_isatty=False,
                                stdin_encoding='123',
                                stdout=sys.stdout,
                                stdout_isatty=False,
                                stdout_encoding='123',
                                stderr=sys.stderr,
                                stderr_isatty=False,
                                colors=256,
                                program_name='http')

# Generated at 2022-06-25 18:16:40.297744
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert isinstance(environment, Environment)


# Generated at 2022-06-25 18:16:51.131687
# Unit test for constructor of class Environment
def test_Environment():
    assert (Environment(colors = 256)
            == Environment(colors = 256))



# Generated at 2022-06-25 18:16:57.593674
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()
    environment_0 = Environment(devnull=None)
    environment_0 = Environment(program_name=None)
    environment_0 = Environment(stdin=None)
    environment_0 = Environment(stdin_isatty=None)
    environment_0 = Environment(stdin_encoding=None)
    environment_0 = Environment(stdout=None)
    environment_0 = Environment(stdout_isatty=None)
    environment_0 = Environment(stdout_encoding=None)
    environment_0 = Environment(stderr=None)
    environment_0 = Environment(stderr_isatty=None)
    environment_0 = Environment(colors=None)



# Generated at 2022-06-25 18:17:00.729357
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(config_dir = Path("."))
    if(environment.config_dir == Path(".")):
        print("Environment constructor works")
    else:
        print("Environment constructor has a bug")


# Generated at 2022-06-25 18:17:11.151191
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert path.exists(environment_0.config_dir) == 1
    assert environment_0.config == default_config
    assert environment_0.stdin == stdin
    assert environment_0.stdin_isatty == stdin_isatty
    assert environment_0.stdin_encoding == stdin_encoding
    assert environment_0.stdout == stdout
    assert environment_0.stdout_isatty == stdout_isatty
    assert environment_0.stdout_encoding == stdout_encoding
    assert environment_0.stderr == stderr
    assert environment_0.stderr_isatty == stderr_isatty
    assert environment_0._orig_stderr == stderr

# Generated at 2022-06-25 18:17:12.101102
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()

# Generated at 2022-06-25 18:17:20.441919
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        is_windows=True,
        config_dir=Path("./test_data"),
        stdin=None,
        stdin_isatty=False,
        stdin_encoding=None,
        stdout=sys.stdout,
        stdout_isatty=True,
        stdout_encoding=None,
        stderr=sys.stderr,
        stderr_isatty=True,
        colors=256,
        program_name="http"
    )

    assert env.is_windows == True
    assert env.config_dir == Path("./test_data")
    assert env.stdin == None
    assert env.stdin_isatty == False
    assert env.stdin_encoding == None
    assert env.stdout == sys.std

# Generated at 2022-06-25 18:17:30.905944
# Unit test for constructor of class Environment
def test_Environment():
    try:
        f = open('/dev/null', 'r')
    except:
        pass
    environment = Environment(
        devnull=f,
        is_windows=True,
        stdin=stdin,
        stdin_isatty=False,
        stdin_encoding='utf8',
        stdout=stdout,
        stdout_isatty=False,
        stdout_encoding='utf8',
        stderr=stderr,
        stderr_isatty=False,
        colors=256,
        program_name='http'
    )


if __name__ == '__main__':
    test_case_0()
    test_Environment()

# Generated at 2022-06-25 18:17:42.389776
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(
        is_windows=False,
        config_dir=Path('/home/usr/'),
        stdin=None,
        stdin_isatty=True,
        stdout=sys.stdout,
        stdout_isatty=sys.stdout.isatty(),
        stderr=sys.stderr,
        stderr_isatty=sys.stderr.isatty(),
        colors=256,
    )
    environment_1.__dict__
    assert environment_1.__dict__['is_windows'] == False
    assert environment_1.__dict__['config_dir'] == Path('/home/usr/')
    assert environment_1.__dict__['stdin'] == None

# Generated at 2022-06-25 18:17:51.607216
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.is_windows == False
    config_dir = DEFAULT_CONFIG_DIR
    assert environment_0.config_dir == config_dir
    devnull = None
    assert environment_0._devnull == devnull
    assert environment_0.stdin == sys.stdin
    assert environment_0.stdin_isatty == sys.stdin.isatty()
    assert environment_0.stdin_encoding == None
    assert environment_0.stdout == sys.stdout
    assert environment_0.stdout_isatty == sys.stdout.isatty()
    assert environment_0.stdout_encoding == None
    assert environment_0.stderr == sys.stderr

# Generated at 2022-06-25 18:17:57.511765
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment(devnull=open(os.devnull, 'w+'), is_windows=False, config_dir=Path('./'), stdin=sys.stdin, stdin_isatty=False, stdin_encoding='utf8', stdout=sys.stdout, stdout_isatty=True, stdout_encoding='utf8', stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http')
    assert environment_0 is not None

# Generated at 2022-06-25 18:18:26.579748
# Unit test for constructor of class Environment
def test_Environment():
    with open(os.devnull, "w") as devnull:
        with patch.object(sys.stdin, "isatty", return_value=False):
            with patch.object(sys.stdout, "isatty", return_value=False):
                with patch.object(sys.stderr, "isatty", return_value=False):
                    if curses:
                        with patch.object(curses.tigetnum, "__call__", return_value=0):
                            env = Environment(devnull)
                        assert not (env.stdin_isatty or env.stdout_isatty or env.stderr_isatty)
                        assert env.colors == 0
                    else:
                        env = Environment(devnull)

# Generated at 2022-06-25 18:18:33.679323
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    # Check if the attribute is_windows is not empty
    assert env.is_windows is not None
    # Check if the attribute config_dir is not empty
    assert env.config_dir is not None
    # Check if the attribute stdin is not empty
    assert env.stdin is not None
    # Check if the attribute stdin_isatty is not empty
    assert env.stdin_isatty is not None
    # Check if the attribute stdin_encoding is not empty
    assert env.stdin_encoding is not None
    # Check if the attribute stdout is not empty
    assert env.stdout is not None
    # Check if the attribute stdout_isatty is not empty
    assert env.stdout_isatty is not None
    # Check if the attribute stdout_encoding is not

# Generated at 2022-06-25 18:18:44.948876
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == (sys.stdin.isatty() if sys.stdin else False)
    assert env.stdin_encoding == (getattr(sys.stdin, 'encoding', None) or 'utf8')
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == (getattr(sys.stdout, 'encoding', None) or 'utf8')
    assert env.stderr == sys.stderr

# Generated at 2022-06-25 18:18:51.337674
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert isinstance(env, Environment)
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == (sys.stdin.isatty() if sys.stdin else False)
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    if sys.platform == "darwin":
        assert env.colors == 256

# Generated at 2022-06-25 18:19:00.335944
# Unit test for constructor of class Environment
def test_Environment():
    """
    The class Environment is used to pass the context of the user's
    environment to the program.
    """
    environment = Environment()
    assert isinstance(environment, Environment)
    assert environment.is_windows == is_windows
    assert isinstance(environment.config_dir, Path)
    assert environment.stdin == sys.stdin
    assert environment.stdin.isatty() == environment.stdin_isatty
    assert environment.stdin_encoding == None
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == environment.stdout.isatty()
    assert environment.stdout_encoding == None
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == environment.stderr.isatty()

# Generated at 2022-06-25 18:19:10.983675
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment(is_windows=True, config_dir=Path("./httpie/config"), stdin=sys.stdin, stdin_isatty=True,
                                stdin_encoding='ascii', stdout=sys.stdout, stdout_isatty=True,
                                stdout_encoding='utf-8', stderr=sys.stderr, stderr_isatty=True, colors=256,
                                program_name='http', devnull=None)
    assert environment_0.is_windows == True, "Expected True, but got False"
    assert environment_0.config_dir == Path("./httpie/config"), "Expected ./httpie/config, but got" + str(environment_0.config_dir)

# Generated at 2022-06-25 18:19:18.730462
# Unit test for constructor of class Environment
def test_Environment():
    assert 'is_windows' in dir(Environment)
    assert 'config_dir' in dir(Environment)
    assert 'stdin' in dir(Environment)
    assert 'stdin_isatty' in dir(Environment)
    assert 'stdin_encoding' in dir(Environment)
    assert 'stdout' in dir(Environment)
    assert 'stdout_isatty' in dir(Environment)
    assert 'stdout_encoding' in dir(Environment)
    assert 'stderr' in dir(Environment)
    assert 'stderr_isatty' in dir(Environment)
    assert 'colors' in dir(Environment)
    assert 'program_name' in dir(Environment)

    environment_0 = Environment()


# Generated at 2022-06-25 18:19:24.610099
# Unit test for constructor of class Environment
def test_Environment():
    args = Environment.__init__(Environment, devnull='null', test_0=0,
                                stdout_encoding='gbk', stdout_isatty=True,
                                stdin_isatty=False, stdin=None, stderr_isatty=True,
                                stderr=None, stdin_encoding='gbk')
    assert args == None


# Generated at 2022-06-25 18:19:29.564364
# Unit test for constructor of class Environment
def test_Environment():
    _stderr = sys.stderr
    orig_stderr = sys.stderr
    sys.stderr = _stderr
    try:
        sys.stderr.write("\n")
    finally:
        sys.stderr = _stderr


# Generated at 2022-06-25 18:19:38.484567
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    if not is_windows:
        if curses:
            try:
                assert env.colors == int(os.getenv('COLUMNS'))
            except curses.error:
                pass
    assert env.is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin is sys.stdin
    assert not env.stdin_isatty
    assert env.stdout is sys.stdout
    assert not env.stdout_isatty
    assert env.stderr is sys.stderr
    assert not env.stderr_isatty
    assert env.program_name == 'http'

    assert not isinstance(repr(env), Environment)
    assert isinstance(env.__str__(), str)

# Generated at 2022-06-25 18:20:03.209852
# Unit test for constructor of class Environment
def test_Environment():
    print('\n>>>environment_1 = Environment()')
    environment_1 = Environment()
    print('>>>print(environment_1)')
    print(environment_1)
    print('\n>>>environment_2 = Environment(devnull=True)')
    environment_2 = Environment(devnull=True)
    print('>>>print(environment_2)')
    print(environment_2)
    environment_3 = Environment(devnull=True)
    print('\n>>>environment_3 = Environment(devnull=True)')
    print('>>>print(environment_3)')
    print(environment_3)
    print('\n>>>environment_4 = Environment(devnull=False)')
    environment_4 = Environment(devnull=False)
    print('>>>print(environment_4)')
    print(environment_4)
   

# Generated at 2022-06-25 18:20:04.658496
# Unit test for constructor of class Environment
def test_Environment():
    assert test_case_0() == None

# Generated at 2022-06-25 18:20:10.420830
# Unit test for constructor of class Environment

# Generated at 2022-06-25 18:20:21.128435
# Unit test for constructor of class Environment
def test_Environment():
    print('in test_Environment')
    environment_1 = Environment(stdin=111)
    print(type(environment_1))
    assert(environment_1.stdin == 111)
    assert(environment_1._config == None)
    environment_1.stdin = '111'
    assert(environment_1.stdin == '111')

    assert(environment_1.config_dir == DEFAULT_CONFIG_DIR)
    environment_1.config_dir = '222'
    assert(environment_1.config_dir == '222')

    assert(environment_1.stdin_isatty == False)
    environment_1.stdin_isatty = '333'
    assert(environment_1.stdin_isatty == '333')

    assert(environment_1.stdin_encoding == None)
   

# Generated at 2022-06-25 18:20:30.355347
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(stdin_isatty=True, stdout=sys.stdout, stdout_isatty=True, stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http', devnull=None)
    environment_2 = Environment(stdin_isatty=True, stdout=sys.stdout, stdout_isatty=True, stderr=sys.stderr, stderr_isatty=True, colors=256, program_name=None)


# Generated at 2022-06-25 18:20:33.676160
# Unit test for constructor of class Environment
def test_Environment():
    assert Environment().stdout_isatty == sys.stdout.isatty()
    assert Environment().stdout == sys.stdout
    assert Environment().stderr == sys.stderr


if __name__ == '__main__':
    test_case_0()
    test_Environment()

# Generated at 2022-06-25 18:20:43.995409
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr)
    assert environment.stdin is sys.stdin
    assert environment.stdout is sys.stdout
    assert environment.stderr is sys.stderr
    assert environment.stdout_isatty
    assert environment.stdin_isatty
    assert environment.stderr_isatty
    assert environment.stdout_encoding
    assert environment.stdin_encoding
    assert environment.stdin_encoding
    assert environment.is_windows is not None
    assert environment.config_dir is not None


# Generated at 2022-06-25 18:20:53.725218
# Unit test for constructor of class Environment
def test_Environment():
    import io
    stdin = io.StringIO()
    stdin_encoding = 'utf8'
    stdout = io.StringIO()
    stdout_encoding = 'utf8'
    stderr = io.StringIO()
    devnull = "devnull"
    environment_0 = Environment(
        stdin=stdin,
        stdin_encoding=stdin_encoding,
        stdout=stdout,
        stdout_encoding=stdout_encoding,
        stderr=stderr,
        devnull=devnull
    )
    assert environment_0.stdin == stdin
    assert environment_0.stdin_encoding == stdin_encoding
    assert environment_0.stdout == stdout
    assert environment_0.stdout_encoding == stdout_encoding

# Generated at 2022-06-25 18:21:05.088555
# Unit test for constructor of class Environment
def test_Environment():
    stdout_ = sys.stdout
    stderr_ = sys.stderr
    stdin_ = sys.stdin
    stdout_encoding_ = getattr(stdout_, 'encoding', None) or 'utf8'
    stdin_encoding_ = getattr(stdin_, 'encoding', None) or 'utf8'
    stdout_isatty_ = stdout_.isatty()
    stdin_isatty_ = stdin_.isatty()
    stderr_isatty_ = stderr_.isatty()
    program_name_ = 'http'
    is_windows_ = is_windows
    config_dir_ = DEFAULT_CONFIG_DIR

    test_case_1 = Environment()

    assert test_case_1.is_windows == is_windows_

# Generated at 2022-06-25 18:21:06.500387
# Unit test for constructor of class Environment
def test_Environment():
    environment_1=Environment()
    assert environment_1!=None


# Generated at 2022-06-25 18:21:32.983005
# Unit test for constructor of class Environment
def test_Environment():
    with pytest.raises(TypeError, match=r'__init__() takes 1 positional argument but 2 were given'):
        class Environment_1():
            def __init__(self, name, descriptor):
                self.name = name
                self.descriptor = descriptor
        a = Environment_1('test_case', 'This is a test case')

    with pytest.raises(TypeError):
        class Environment_2():
            def __init__(self, name, descriptor):
                self.name = name
                self.descriptor = descriptor
        a = Environment_2()    # No argument given

    with pytest.raises(TypeError):
        class Environment_3():
            def __init__(self, name, descriptor):
                self.name = name
                self.descriptor = descriptor
        a = Environment_

# Generated at 2022-06-25 18:21:44.459777
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr)
    assert environment.stderr == sys.stderr
    assert environment.stdin == sys.stdin
    assert environment.stdout == sys.stdout

    assert environment.stdout_isatty == sys.stdout.isatty()
    assert environment.stdin_isatty == sys.stdin.isatty()
    assert environment.stderr_isatty == sys.stderr.isatty()

    # Test for stdout.encoding
    stdout_encoding = getattr(sys.stdout, 'encoding', None) or 'UTF8'
    assert environment.stdout_encoding == stdout_encoding

    # Test for stdin.encoding
   

# Generated at 2022-06-25 18:21:52.530244
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert type(env) == Environment
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == env.stdin.isatty()
    if env.stdin_encoding == None:
        assert env.stdin_encoding == None or env.stdin_encoding == 'utf8'
    else:
        assert env.stdin_encoding == sys.stdin.encoding
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == sys.stdout.encoding or env.stdout_encoding == 'utf8'

# Generated at 2022-06-25 18:21:58.618755
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()

    env.config_dir = Path(__file__)
    assert Path(__file__) == env.config_dir
    assert str(env.config_dir) == str(Path(__file__))

    with open(os.devnull, 'r') as f:
        env.stdin = f
        assert isinstance(env.stdin, IO)

    env.stdout = sys.stdout
    assert isinstance(env.stdout, IO)

    env.stderr = sys.stderr
    assert isinstance(env.stderr, IO)

    env.colors = 0
    assert env.colors == 0

    env.program_name = "test"
    assert env.program_name == "test"

    assert isinstance(env.stdin, IO)

# Generated at 2022-06-25 18:22:09.306907
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert environment_0.is_windows == is_windows
    assert environment_0.config_dir == DEFAULT_CONFIG_DIR
    assert environment_0.stdin == sys.stdin
    assert environment_0.stdin_isatty == sys.stdin.isatty()
    assert environment_0.stdin_encoding == None
    assert environment_0.stdout == sys.stdout
    assert environment_0.stdout_isatty == sys.stdout.isatty()
    assert environment_0.stderr == sys.stderr
    assert environment_0.stderr_isatty == sys.stderr.isatty()
    assert environment_0.stdout_encoding == None
    assert environment_0.colors == 256
    assert environment_0

# Generated at 2022-06-25 18:22:11.072650
# Unit test for constructor of class Environment
def test_Environment():
    test_case_0()


if __name__ == "__main__":
    test_Environment()

# Generated at 2022-06-25 18:22:22.599954
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.is_windows == False
    assert environment.config_dir == Path.joinpath(Path.home(), '.config', 'httpie')
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == True
    assert environment.stdin_encoding == None
    assert environment.stdout == sys.stdout
    assert environment.stdout_isatty == True
    assert environment.stdout_encoding == None
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == True
    assert environment.colors == 256
    assert environment.program_name == 'http'
    assert environment.config == Config(directory = Path.joinpath(Path.home(), '.config', 'httpie'))
    assert environment._original_st

# Generated at 2022-06-25 18:22:28.759443
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()

    assert environment_0.stdin is sys.stdin
    assert environment_0.stdout is sys.stdout
    assert environment_0.stderr is sys.stderr
    assert environment_0.stdin_isatty is True
    assert environment_0.stdout_isatty is True
    assert environment_0.stderr_isatty is True
    #assert environment_0.stdin_encoding is None
    assert environment_0.stdout_encoding is None
    assert environment_0.stderr_encoding is None
    assert environment_0.colors is 256
    assert environment_0.program_name == 'http'
    #assert isinstance(environment_0.config, Config)

# Generated at 2022-06-25 18:22:37.694549
# Unit test for constructor of class Environment
def test_Environment():
    from httpie import ExitStatus
    from httpie.cli import parser
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.output.streams import Streams

    stdin_isatty = sys.stdin.isatty() if sys.stdin else False
    env = Environment()
    assert env.stdin_isatty == stdin_isatty
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.is_windows == is_windows
    assert env.stdin_encoding == sys.stdin.encoding if stdin_isatty else None
    assert env.stdout_encoding == sys.stdout.enc

# Generated at 2022-06-25 18:22:44.376748
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(devnull=sys.stderr, stdin=sys.stderr, stdout=sys.stderr, stderr=sys.stderr)
    assert environment_1.stdin == sys.stderr
    assert environment_1.stdout == sys.stderr
    assert environment_1.stderr == sys.stderr
    assert environment_1.devnull == sys.stderr

# Generated at 2022-06-25 18:23:32.862132
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment(config_dir='./test_directory')
    assert environment_1.config_dir == './test_directory'

# Generated at 2022-06-25 18:23:34.563394
# Unit test for constructor of class Environment
def test_Environment():
    environment_0 = Environment()
    assert isinstance(environment_0, Environment)



# Generated at 2022-06-25 18:23:43.125082
# Unit test for constructor of class Environment
def test_Environment():
    env1 = Environment()
    assert env1.is_windows == Environment.is_windows
    assert env1.config_dir == Environment.config_dir
    assert env1.stdin == Environment.stdin
    assert env1.stdin_isatty == Environment.stdin_isatty
    assert env1.stdin_encoding == Environment.stdin_encoding
    assert env1.stdout == Environment.stdout
    assert env1.stdout_isatty == Environment.stdout_isatty
    assert env1.stdout_encoding == Environment.stdout_encoding
    assert env1.stderr == Environment.stderr
    assert env1.stderr_isatty == Environment.stderr_isatty
    assert env1.colors == Environment.colors

# Generated at 2022-06-25 18:23:53.427734
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment()
    assert environment.config_dir == DEFAULT_CONFIG_DIR
    assert environment.stdin == sys.stdin
    assert environment.stdin.read() == ""
    assert environment.stdin_isatty == False
    #assert environment.stdin_encoding == None
    assert environment.stdout == sys.stdout
    assert environment.stdout.encoding == "utf-8"
    assert environment.stdout_isatty == True
    assert environment.stderr == sys.stderr
    assert environment.stderr.encoding == "utf-8"
    assert environment.stderr_isatty == True
    assert environment.colors == 256



# Generated at 2022-06-25 18:24:03.817603
# Unit test for constructor of class Environment
def test_Environment():
    program_name = 'http'
    stdin = sys.stdin
    stdin_isatty = stdin.isatty()
    stdin_encoding = None
    stdout = sys.stdout
    stdout_isatty = stdout.isatty()
    stdout_encoding = None
    stderr = sys.stderr
    stderr_isatty = stderr.isatty()
    colors = 256
    if sys.platform == 'win32':
        is_windows = True
        # noinspection PyUnresolvedReferences
        import colorama.initialise
        stdout =colorama.initialise.wrap_stream(stdout,convert = None, strip = None, autoreset = True,wrap = True)
        stderr =colorama.initialise.wrap_stream

# Generated at 2022-06-25 18:24:10.825619
# Unit test for constructor of class Environment
def test_Environment():
    environment = Environment(stdout=None)
    assert environment.is_windows == True
    assert str(environment.config_dir) == str(DEFAULT_CONFIG_DIR)
    assert environment.stdin == sys.stdin
    assert environment.stdin_isatty == sys.stdin.isatty()
    assert environment.stdout == None
    assert environment.stdout_isatty == None
    assert environment.stderr == sys.stderr
    assert environment.stderr_isatty == sys.stderr.isatty()
    assert environment._orig_stderr == sys.stderr


# Generated at 2022-06-25 18:24:21.588922
# Unit test for constructor of class Environment
def test_Environment():
    environment_1 = Environment()
    environment_2 = Environment(devnull=None)
    environment_3 = Environment(devnull=None, config_dir=None)
    environment_4 = Environment(devnull=None, config_dir=None, stdin=None)
    environment_5 = Environment(devnull=None, config_dir=None, stdin=None, stdin_isatty=False)
    environment_6 = Environment(devnull=None, config_dir=None, stdin=None, stdin_isatty=False, stdin_encoding=None)
    environment_7 = Environment(devnull=None, config_dir=None, stdin=None, stdin_isatty=False, stdin_encoding=None, stdout=None)

# Generated at 2022-06-25 18:24:27.390795
# Unit test for constructor of class Environment
def test_Environment():
    # Test case (1): create an empty environment with default constructor
    env = Environment()
    # Test case (2): create an environment with specific parameters
    env = Environment(is_windows=True, config_dir=Path('config'), stderr_isatty=False)
    assert env.is_windows
    assert env.config_dir == Path('config')
    assert env.stderr_isatty == False


# Generated at 2022-06-25 18:24:35.148533
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == sys.platform == "win32"
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert env.stdin_isatty == env.stdin.isatty()
    assert env.stdout_isatty == env.stdout.isatty()
    assert env.stderr_isatty == env.stderr.isatty()
    if is_windows:
        assert env.stdout_encoding == 'mbcs'
        assert env.stderr_encoding == 'mbcs'
    else:
        assert env.stdout_encoding == sys.getdefaultencoding()

# Generated at 2022-06-25 18:24:44.743685
# Unit test for constructor of class Environment