

# Generated at 2022-06-17 20:13:00.968325
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdin_isatty=False, stdin_encoding=None, stdout=sys.stdout, stdout_isatty=True, stdout_encoding=None, stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http')
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == None
    assert env.stdin_isatty == False
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env

# Generated at 2022-06-17 20:13:08.043158
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=True, config_dir=DEFAULT_CONFIG_DIR, stdin=sys.stdin, stdin_isatty=True, stdin_encoding=None, stdout=sys.stdout, stdout_isatty=True, stdout_encoding=None, stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http')
    assert env.is_windows == True
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == True
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True

# Generated at 2022-06-17 20:13:19.654095
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=True, config_dir=DEFAULT_CONFIG_DIR, stdin=sys.stdin, stdin_isatty=sys.stdin.isatty(), stdin_encoding=None, stdout=sys.stdout, stdout_isatty=sys.stdout.isatty(), stdout_encoding=None, stderr=sys.stderr, stderr_isatty=sys.stderr.isatty(), colors=256, program_name='http')
    assert env.is_windows == True
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding

# Generated at 2022-06-17 20:13:27.690216
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdin_isatty=False, stdin_encoding=None, stdout=sys.stdout, stdout_isatty=True, stdout_encoding=None, stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http', is_windows=False, config_dir=Path('/home/httpie/.config/httpie'), devnull=None)
    assert env.stdin == None
    assert env.stdin_isatty == False
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env

# Generated at 2022-06-17 20:13:32.262392
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr
   

# Generated at 2022-06-17 20:13:44.737491
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdout=None, stderr=None)
    assert env.stdin is None
    assert env.stdout is None
    assert env.stderr is None
    assert env.stdin_isatty is False
    assert env.stdout_isatty is False
    assert env.stderr_isatty is False
    assert env.stdin_encoding is None
    assert env.stdout_encoding is None
    assert env.stderr_encoding is None
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.config is not None
    assert env.devnull is not None

# Generated at 2022-06-17 20:13:56.972609
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdin_isatty=False, stdin_encoding=None, stdout=sys.stdout, stdout_isatty=True, stdout_encoding=None, stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http')
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == None
    assert env.stdin_isatty == False
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env

# Generated at 2022-06-17 20:14:05.760604
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdin_isatty=False, stdin_encoding=None, stdout=sys.stdout, stdout_isatty=True, stdout_encoding=None, stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http')
    assert env.stdin == None
    assert env.stdin_isatty == False
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == True
    assert env.colors == 256

# Generated at 2022-06-17 20:14:14.601365
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr
   

# Generated at 2022-06-17 20:14:25.598214
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr
   

# Generated at 2022-06-17 20:14:44.680100
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        config_dir='/home/user/.config/httpie',
        stdin=None,
        stdin_isatty=False,
        stdin_encoding='utf8',
        stdout=sys.stdout,
        stdout_isatty=True,
        stdout_encoding='utf8',
        stderr=sys.stderr,
        stderr_isatty=True,
        colors=256,
        program_name='http'
    )
    assert env.config_dir == '/home/user/.config/httpie'
    assert env.stdin == None
    assert env.stdin_isatty == False
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout_

# Generated at 2022-06-17 20:14:59.225875
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdin_isatty=False, stdin_encoding='utf8', stdout=sys.stdout, stdout_isatty=True, stdout_encoding='utf8', stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http')
    assert env.stdin == None
    assert env.stdin_isatty == False
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stdout_encoding == 'utf8'
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == True
    assert env.colors == 256


# Generated at 2022-06-17 20:15:05.020736
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr
   

# Generated at 2022-06-17 20:15:10.923828
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdin_isatty=False, stdin_encoding='utf8', stdout=sys.stdout, stdout_isatty=True, stdout_encoding='utf8', stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http', is_windows=False, config_dir=DEFAULT_CONFIG_DIR)
    assert env.stdin == None
    assert env.stdin_isatty == False
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stdout_encoding == 'utf8'
    assert env.stderr == sys.stderr
    assert env.st

# Generated at 2022-06-17 20:15:17.309189
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdin_isatty=False, stdin_encoding=None, stdout=sys.stdout, stdout_isatty=True, stdout_encoding=None, stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http')
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == None
    assert env.stdin_isatty == False
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env

# Generated at 2022-06-17 20:15:27.219958
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        is_windows=True,
        config_dir='/home/user/.config/httpie',
        stdin=sys.stdin,
        stdin_isatty=True,
        stdin_encoding='utf8',
        stdout=sys.stdout,
        stdout_isatty=True,
        stdout_encoding='utf8',
        stderr=sys.stderr,
        stderr_isatty=True,
        colors=256,
        program_name='http'
    )
    assert env.is_windows == True
    assert env.config_dir == Path('/home/user/.config/httpie')
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == True
    assert env.stdin_enc

# Generated at 2022-06-17 20:15:36.068513
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdout=None, stderr=None)
    assert env.stdin is None
    assert env.stdout is None
    assert env.stderr is None
    assert env.stdin_isatty is False
    assert env.stdout_isatty is False
    assert env.stderr_isatty is False
    assert env.stdin_encoding is None
    assert env.stdout_encoding is None
    assert env.stderr_encoding is None
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.devnull is None
    assert env._orig_stderr is None

# Generated at 2022-06-17 20:15:46.590069
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdin_isatty=False, stdin_encoding=None, stdout=sys.stdout, stdout_isatty=True, stdout_encoding=None, stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http')
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == None
    assert env.stdin_isatty == False
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env

# Generated at 2022-06-17 20:15:59.231627
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=True, config_dir=DEFAULT_CONFIG_DIR, stdin=sys.stdin, stdin_isatty=sys.stdin.isatty(), stdin_encoding=None, stdout=sys.stdout, stdout_isatty=sys.stdout.isatty(), stdout_encoding=None, stderr=sys.stderr, stderr_isatty=sys.stderr.isatty(), colors=256, program_name='http')
    print(env)
    print(env.config)
    print(env.devnull)
    print(env.log_error("test"))
    print(env.__repr__())
    print(env.__str__())


# Generated at 2022-06-17 20:16:10.206863
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdin_isatty=False, stdin_encoding='utf8', stdout=sys.stdout, stdout_isatty=True, stdout_encoding='utf8', stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http')
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == None
    assert env.stdin_isatty == False
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stdout_encoding == 'utf8'
    assert env.stderr == sys

# Generated at 2022-06-17 20:16:39.976889
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        stdin=None,
        stdin_isatty=False,
        stdin_encoding='utf8',
        stdout=sys.stdout,
        stdout_isatty=True,
        stdout_encoding='utf8',
        stderr=sys.stderr,
        stderr_isatty=True,
        colors=256,
        program_name='http',
        config_dir=DEFAULT_CONFIG_DIR,
        devnull=None
    )
    assert env.stdin is None
    assert env.stdin_isatty is False
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty is True
    assert env.stdout_encoding

# Generated at 2022-06-17 20:16:50.928494
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdin_isatty=False, stdin_encoding='utf8', stdout=sys.stdout, stdout_isatty=True, stdout_encoding='utf8', stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http', is_windows=False, config_dir=DEFAULT_CONFIG_DIR)
    assert env.stdin == None
    assert env.stdin_isatty == False
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stdout_encoding == 'utf8'
    assert env.stderr == sys.stderr
    assert env.st

# Generated at 2022-06-17 20:17:03.023524
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=True, config_dir=None, stdin=None, stdin_isatty=False, stdin_encoding=None, stdout=None, stdout_isatty=False, stdout_encoding=None, stderr=None, stderr_isatty=False, colors=256, program_name='http')
    assert env.is_windows == True
    assert env.config_dir == None
    assert env.stdin == None
    assert env.stdin_isatty == False
    assert env.stdin_encoding == None
    assert env.stdout == None
    assert env.stdout_isatty == False
    assert env.stdout_encoding == None
    assert env.stderr == None
    assert env.stderr_

# Generated at 2022-06-17 20:17:13.449423
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdin_isatty=False, stdin_encoding=None, stdout=sys.stdout, stdout_isatty=True, stdout_encoding=None, stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http', is_windows=False, config_dir=Path('/home/user/.config/httpie'), devnull=None)
    assert env.stdin == None
    assert env.stdin_isatty == False
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr

# Generated at 2022-06-17 20:17:23.710284
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdin_isatty=False, stdin_encoding=None, stdout=sys.stdout, stdout_isatty=True, stdout_encoding=None, stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http')
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == None
    assert env.stdin_isatty == False
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env

# Generated at 2022-06-17 20:17:34.102068
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr
   

# Generated at 2022-06-17 20:17:42.607736
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdin_isatty=False, stdin_encoding='utf8',
                      stdout=sys.stdout, stdout_isatty=True, stdout_encoding='utf8',
                      stderr=sys.stderr, stderr_isatty=True,
                      colors=256, program_name='http',
                      is_windows=False, config_dir=DEFAULT_CONFIG_DIR)
    assert env.stdin is None
    assert env.stdin_isatty is False
    assert env.stdin_encoding == 'utf8'
    assert env.stdout is sys.stdout
    assert env.stdout_isatty is True
    assert env.stdout_encoding == 'utf8'
    assert env.stderr is sys.st

# Generated at 2022-06-17 20:17:49.321482
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdin_isatty=False, stdin_encoding='utf8',
                      stdout=sys.stdout, stdout_isatty=True, stdout_encoding='utf8',
                      stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http')
    assert env.stdin is None
    assert env.stdin_isatty is False
    assert env.stdin_encoding == 'utf8'
    assert env.stdout is sys.stdout
    assert env.stdout_isatty is True
    assert env.stdout_encoding == 'utf8'
    assert env.stderr is sys.stderr
    assert env.stderr_isatty is True
    assert env.col

# Generated at 2022-06-17 20:17:59.516431
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr
   

# Generated at 2022-06-17 20:18:08.977438
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        stdin=None,
        stdin_isatty=False,
        stdin_encoding='utf8',
        stdout=sys.stdout,
        stdout_isatty=True,
        stdout_encoding='utf8',
        stderr=sys.stderr,
        stderr_isatty=True,
        colors=256,
        program_name='http',
        is_windows=False,
        config_dir=DEFAULT_CONFIG_DIR,
        devnull=None
    )
    assert env.stdin is None
    assert env.stdin_isatty is False
    assert env.stdin_encoding == 'utf8'
    assert env.stdout is sys.stdout
    assert env.stdout_isatty is True
   

# Generated at 2022-06-17 20:18:58.784674
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=True, config_dir=DEFAULT_CONFIG_DIR, stdin=sys.stdin, stdin_isatty=True, stdin_encoding=None, stdout=sys.stdout, stdout_isatty=True, stdout_encoding=None, stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http')
    assert env.is_windows == True
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == True
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True

# Generated at 2022-06-17 20:19:06.444502
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdout=None, stderr=None, config_dir=None)
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin is None
    assert env.stdin_isatty is False
    assert env.stdin_encoding is None
    assert env.stdout is None
    assert env.stdout_isatty is False
    assert env.stdout_encoding is None
    assert env.stderr is None
    assert env.stderr_isatty is False
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr is None
    assert env._devnull is None
    assert env.config is None
   

# Generated at 2022-06-17 20:19:15.556362
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr
   

# Generated at 2022-06-17 20:19:22.378637
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr
   

# Generated at 2022-06-17 20:19:32.574674
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=False, config_dir=DEFAULT_CONFIG_DIR, stdin=sys.stdin, stdin_isatty=sys.stdin.isatty(), stdin_encoding=None, stdout=sys.stdout, stdout_isatty=sys.stdout.isatty(), stdout_encoding=None, stderr=sys.stderr, stderr_isatty=sys.stderr.isatty(), colors=256, program_name='http')
    assert env.is_windows == False
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding

# Generated at 2022-06-17 20:19:44.608957
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdin_isatty=False, stdin_encoding=None, stdout=sys.stdout, stdout_isatty=True, stdout_encoding=None, stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http')
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == None
    assert env.stdin_isatty == False
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env

# Generated at 2022-06-17 20:19:50.885642
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdin_isatty=False, stdin_encoding=None,
                      stdout=sys.stdout, stdout_isatty=True, stdout_encoding=None,
                      stderr=sys.stderr, stderr_isatty=True,
                      colors=256, program_name='http',
                      config_dir=DEFAULT_CONFIG_DIR,
                      is_windows=is_windows,
                      devnull=None)
    assert env.stdin is None
    assert env.stdin_isatty is False
    assert env.stdin_encoding is None
    assert env.stdout is sys.stdout
    assert env.stdout_isatty is True
    assert env.stdout_encoding is None

# Generated at 2022-06-17 20:20:00.088477
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdin_isatty=False, stdin_encoding='utf8', stdout=sys.stdout, stdout_isatty=True, stdout_encoding='utf8', stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http', config_dir=DEFAULT_CONFIG_DIR)
    assert env.stdin == None
    assert env.stdin_isatty == False
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stdout_encoding == 'utf8'
    assert env.stderr == sys.stderr
    assert env.stderr_isatty

# Generated at 2022-06-17 20:20:07.168538
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=True, config_dir=DEFAULT_CONFIG_DIR, stdin=sys.stdin, stdin_isatty=True, stdin_encoding=None, stdout=sys.stdout, stdout_isatty=True, stdout_encoding=None, stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http')
    assert env.is_windows == True
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == True
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True

# Generated at 2022-06-17 20:20:18.183490
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr
   

# Generated at 2022-06-17 20:21:45.921712
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr
   

# Generated at 2022-06-17 20:21:58.740416
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=True, config_dir=DEFAULT_CONFIG_DIR, stdin=sys.stdin, stdin_isatty=sys.stdin.isatty(), stdin_encoding=None, stdout=sys.stdout, stdout_isatty=sys.stdout.isatty(), stdout_encoding=None, stderr=sys.stderr, stderr_isatty=sys.stderr.isatty(), colors=256, program_name='http')
    assert env.is_windows == True
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding

# Generated at 2022-06-17 20:22:10.198912
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdin_isatty=False, stdin_encoding='utf8', stdout=sys.stdout, stdout_isatty=True, stdout_encoding='utf8', stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http')
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == None
    assert env.stdin_isatty == False
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stdout_encoding == 'utf8'
    assert env.stderr == sys

# Generated at 2022-06-17 20:22:17.284845
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=False, config_dir=Path('/home/httpie/.httpie'), stdin=sys.stdin, stdin_isatty=True, stdin_encoding='utf8', stdout=sys.stdout, stdout_isatty=True, stdout_encoding='utf8', stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http')
    assert env.is_windows == False
    assert env.config_dir == Path('/home/httpie/.httpie')
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == True
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == sys.stdout
    assert env

# Generated at 2022-06-17 20:22:25.988957
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdin_isatty=False, stdin_encoding=None, stdout=sys.stdout, stdout_isatty=True, stdout_encoding=None, stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http')
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == None
    assert env.stdin_isatty == False
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env

# Generated at 2022-06-17 20:22:35.625888
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr
   

# Generated at 2022-06-17 20:22:45.282554
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=False, config_dir=DEFAULT_CONFIG_DIR, stdin=sys.stdin, stdin_isatty=True, stdin_encoding='utf8', stdout=sys.stdout, stdout_isatty=True, stdout_encoding='utf8', stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http')
    assert env.is_windows == False
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == True
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty