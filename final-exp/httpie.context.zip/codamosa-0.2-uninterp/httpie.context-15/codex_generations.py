

# Generated at 2022-06-17 20:12:54.145362
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr
   

# Generated at 2022-06-17 20:13:03.901671
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.program_name == 'http'
    assert env.colors == 256
    assert env._orig_stderr == sys.stderr
   

# Generated at 2022-06-17 20:13:15.435211
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr
   

# Generated at 2022-06-17 20:13:25.905682
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        is_windows=True,
        config_dir=Path('/home/user/.config/httpie'),
        stdin=sys.stdin,
        stdin_isatty=True,
        stdin_encoding='utf8',
        stdout=sys.stdout,
        stdout_isatty=True,
        stdout_encoding='utf8',
        stderr=sys.stderr,
        stderr_isatty=True,
        colors=256,
        program_name='http'
    )
    assert env.is_windows == True
    assert env.config_dir == Path('/home/user/.config/httpie')
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == True
    assert env.stdin

# Generated at 2022-06-17 20:13:35.523468
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdin_isatty=False, stdin_encoding='utf8', stdout=sys.stdout, stdout_isatty=True, stdout_encoding='utf8', stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http')
    assert env.stdin == None
    assert env.stdin_isatty == False
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stdout_encoding == 'utf8'
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == True
    assert env.colors == 256


# Generated at 2022-06-17 20:13:46.942102
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.program_name == 'http'
    assert env.colors == 256
    assert env._orig_stderr == sys.stderr
   

# Generated at 2022-06-17 20:13:54.625969
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr
   

# Generated at 2022-06-17 20:14:05.341725
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdin_isatty=True, stdin_encoding='utf8',
                      stdout=sys.stdout, stdout_isatty=True, stdout_encoding='utf8',
                      stderr=sys.stderr, stderr_isatty=True,
                      is_windows=False, config_dir=DEFAULT_CONFIG_DIR,
                      program_name='http', colors=256, devnull=None)
    assert env.stdin is None
    assert env.stdin_isatty is True
    assert env.stdin_encoding == 'utf8'
    assert env.stdout is sys.stdout
    assert env.stdout_isatty is True
    assert env.stdout_encoding == 'utf8'
    assert env.stder

# Generated at 2022-06-17 20:14:14.201431
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdin_isatty=False, stdin_encoding=None, stdout=sys.stdout, stdout_isatty=True, stdout_encoding=None, stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http')
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == None
    assert env.stdin_isatty == False
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env

# Generated at 2022-06-17 20:14:25.597893
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == sys.stdin.encoding
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == sys.stdout.encoding
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig

# Generated at 2022-06-17 20:14:45.478272
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdout=None, stderr=None)
    assert env.stdin is None
    assert env.stdout is None
    assert env.stderr is None
    assert env.stdin_isatty is False
    assert env.stdout_isatty is False
    assert env.stderr_isatty is False
    assert env.stdin_encoding is None
    assert env.stdout_encoding is None
    assert env.stderr_encoding is None
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env._orig_stderr is None
    assert env._devnull is None

# Generated at 2022-06-17 20:14:59.323942
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=False, config_dir=DEFAULT_CONFIG_DIR, stdin=sys.stdin, stdin_isatty=sys.stdin.isatty(), stdin_encoding=None, stdout=sys.stdout, stdout_isatty=sys.stdout.isatty(), stdout_encoding=None, stderr=sys.stderr, stderr_isatty=sys.stderr.isatty(), colors=256, program_name='http')
    assert env.is_windows == False
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding

# Generated at 2022-06-17 20:15:11.972509
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=False, config_dir=DEFAULT_CONFIG_DIR, stdin=sys.stdin, stdin_isatty=sys.stdin.isatty(), stdin_encoding=None, stdout=sys.stdout, stdout_isatty=sys.stdout.isatty(), stdout_encoding=None, stderr=sys.stderr, stderr_isatty=sys.stderr.isatty(), colors=256, program_name='http')
    assert env.is_windows == False
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding

# Generated at 2022-06-17 20:15:22.172210
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr
   

# Generated at 2022-06-17 20:15:32.589450
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        stdin=None,
        stdin_isatty=False,
        stdin_encoding='utf8',
        stdout=sys.stdout,
        stdout_isatty=True,
        stdout_encoding='utf8',
        stderr=sys.stderr,
        stderr_isatty=True,
        colors=256,
        program_name='http',
        config_dir=DEFAULT_CONFIG_DIR,
        devnull=None,
    )
    assert env.stdin is None
    assert env.stdin_isatty is False
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty is True
    assert env.stdout_enc

# Generated at 2022-06-17 20:15:42.509162
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr
   

# Generated at 2022-06-17 20:15:51.427122
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdin_isatty=False, stdin_encoding='utf8', stdout=sys.stdout, stdout_isatty=True, stdout_encoding='utf8', stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http', config_dir=DEFAULT_CONFIG_DIR)
    assert env.stdin == None
    assert env.stdin_isatty == False
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stdout_encoding == 'utf8'
    assert env.stderr == sys.stderr
    assert env.stderr_isatty

# Generated at 2022-06-17 20:16:00.021529
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=True, config_dir=Path('./config'), stdin=sys.stdin, stdin_isatty=sys.stdin.isatty(), stdin_encoding=None, stdout=sys.stdout, stdout_isatty=sys.stdout.isatty(), stdout_encoding=None, stderr=sys.stderr, stderr_isatty=sys.stderr.isatty(), colors=256, program_name='http')
    assert env.is_windows == True
    assert env.config_dir == Path('./config')
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None


# Generated at 2022-06-17 20:16:06.100246
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=True, config_dir=DEFAULT_CONFIG_DIR, stdin=sys.stdin, stdin_isatty=sys.stdin.isatty(), stdin_encoding=None, stdout=sys.stdout, stdout_isatty=sys.stdout.isatty(), stdout_encoding=None, stderr=sys.stderr, stderr_isatty=sys.stderr.isatty(), colors=256, program_name='http')
    assert env.is_windows == True
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding

# Generated at 2022-06-17 20:16:15.432660
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=False, config_dir=Path('/home/httpie/.config/httpie'), stdin=sys.stdin, stdin_isatty=True, stdin_encoding='utf8', stdout=sys.stdout, stdout_isatty=True, stdout_encoding='utf8', stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http')
    assert env.is_windows == False
    assert env.config_dir == Path('/home/httpie/.config/httpie')
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == True
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == sys.stdout

# Generated at 2022-06-17 20:16:43.270420
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdin_isatty=False, stdin_encoding='utf8',
                      stdout=sys.stdout, stdout_isatty=True, stdout_encoding='utf8',
                      stderr=sys.stderr, stderr_isatty=True,
                      colors=256, program_name='http')
    assert env.stdin == None
    assert env.stdin_isatty == False
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stdout_encoding == 'utf8'
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == True
    assert env

# Generated at 2022-06-17 20:16:51.766315
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdin_isatty=False, stdin_encoding='utf8', stdout=sys.stdout, stdout_isatty=True, stdout_encoding='utf8', stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http', config_dir=DEFAULT_CONFIG_DIR)
    assert env.stdin is None
    assert env.stdin_isatty is False
    assert env.stdin_encoding == 'utf8'
    assert env.stdout is sys.stdout
    assert env.stdout_isatty is True
    assert env.stdout_encoding == 'utf8'
    assert env.stderr is sys.stderr
    assert env.stderr_isatty

# Generated at 2022-06-17 20:17:03.625420
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        stdin=None,
        stdin_isatty=False,
        stdin_encoding='utf8',
        stdout=sys.stdout,
        stdout_isatty=True,
        stdout_encoding='utf8',
        stderr=sys.stderr,
        stderr_isatty=True,
        colors=256,
        program_name='http',
        config_dir=DEFAULT_CONFIG_DIR,
        devnull=None,
        is_windows=is_windows
    )
    assert env.stdin == None
    assert env.stdin_isatty == False
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True

# Generated at 2022-06-17 20:17:12.743391
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=False, config_dir=DEFAULT_CONFIG_DIR, stdin=sys.stdin, stdin_isatty=True, stdin_encoding=None, stdout=sys.stdout, stdout_isatty=True, stdout_encoding=None, stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http')
    print(env)
    print(env.config)
    print(env.devnull)
    print(env.log_error("msg"))

if __name__ == "__main__":
    test_Environment()

# Generated at 2022-06-17 20:17:23.517169
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=True, config_dir=DEFAULT_CONFIG_DIR, stdin=sys.stdin, stdin_isatty=sys.stdin.isatty(), stdin_encoding=None, stdout=sys.stdout, stdout_isatty=sys.stdout.isatty(), stdout_encoding=None, stderr=sys.stderr, stderr_isatty=sys.stderr.isatty(), colors=256, program_name='http')
    assert env.is_windows == True
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding

# Generated at 2022-06-17 20:17:33.934008
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdout=None, stderr=None, config_dir=None, program_name=None)
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
   

# Generated at 2022-06-17 20:17:42.456592
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr
   

# Generated at 2022-06-17 20:17:49.207940
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdin_isatty=False, stdin_encoding=None, stdout=sys.stdout, stdout_isatty=True, stdout_encoding=None, stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http')
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == None
    assert env.stdin_isatty == False
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env

# Generated at 2022-06-17 20:17:54.750989
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'

# Generated at 2022-06-17 20:18:05.349704
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr
   

# Generated at 2022-06-17 20:18:58.672887
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdin_isatty=False, stdin_encoding='utf8',
                      stdout=sys.stdout, stdout_isatty=True, stdout_encoding='utf8',
                      stderr=sys.stderr, stderr_isatty=True,
                      colors=256, program_name='http',
                      is_windows=False, config_dir=DEFAULT_CONFIG_DIR)
    assert env.stdin is None
    assert env.stdin_isatty is False
    assert env.stdin_encoding == 'utf8'
    assert env.stdout is sys.stdout
    assert env.stdout_isatty is True
    assert env.stdout_encoding == 'utf8'
    assert env.stderr is sys.st

# Generated at 2022-06-17 20:19:06.370744
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdin_isatty=False, stdin_encoding=None, stdout=sys.stdout, stdout_isatty=True, stdout_encoding=None, stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http', is_windows=False, config_dir=DEFAULT_CONFIG_DIR)
    assert env.stdin == None
    assert env.stdin_isatty == False
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == True

# Generated at 2022-06-17 20:19:15.480865
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr
   

# Generated at 2022-06-17 20:19:22.329599
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None)
    assert env.stdin is None
    assert env.stdin_isatty is False
    assert env.stdin_encoding is None
    assert env.stdout is sys.stdout
    assert env.stdout_isatty is True
    assert env.stdout_encoding is None
    assert env.stderr is sys.stderr
    assert env.stderr_isatty is True
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env.is_windows is False
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.devnull is None
    assert env._orig_stderr is sys.stderr
    assert env._devnull is None
    assert env._config is None


# Generated at 2022-06-17 20:19:32.573426
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr
   

# Generated at 2022-06-17 20:19:44.471070
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr
   

# Generated at 2022-06-17 20:19:48.599707
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdin_isatty=False, stdin_encoding='utf8',
                      stdout=sys.stdout, stdout_isatty=True, stdout_encoding='utf8',
                      stderr=sys.stderr, stderr_isatty=True,
                      colors=256, program_name='http',
                      is_windows=False, config_dir=DEFAULT_CONFIG_DIR)
    assert env.stdin is None
    assert env.stdin_isatty is False
    assert env.stdin_encoding == 'utf8'
    assert env.stdout is sys.stdout
    assert env.stdout_isatty is True
    assert env.stdout_encoding == 'utf8'
    assert env.stderr is sys.st

# Generated at 2022-06-17 20:20:00.044975
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr
   

# Generated at 2022-06-17 20:20:07.112119
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull = None, is_windows = False, config_dir = DEFAULT_CONFIG_DIR, stdin = sys.stdin, stdin_isatty = sys.stdin.isatty(), stdin_encoding = None, stdout = sys.stdout, stdout_isatty = sys.stdout.isatty(), stdout_encoding = None, stderr = sys.stderr, stderr_isatty = sys.stderr.isatty(), colors = 256, program_name = 'http')
    assert env.is_windows == False
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_enc

# Generated at 2022-06-17 20:20:18.095871
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr
   

# Generated at 2022-06-17 20:21:53.897229
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr
   

# Generated at 2022-06-17 20:22:00.203051
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdin_isatty=False, stdin_encoding=None, stdout=sys.stdout, stdout_isatty=True, stdout_encoding=None, stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http')
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == None
    assert env.stdin_isatty == False
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env

# Generated at 2022-06-17 20:22:11.741403
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr
   

# Generated at 2022-06-17 20:22:16.369710
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr)
    assert env.stdin == sys.stdin
    assert env.stdout == sys.stdout
    assert env.stderr == sys.stderr
    assert env.stdin_encoding == sys.stdin.encoding
    assert env.stdout_encoding == sys.stdout.encoding
    assert env.stderr_encoding == sys.stderr.encoding
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr_isatty == sys.stderr.isatty()

# Generated at 2022-06-17 20:22:25.397004
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.program_name == 'http'
    assert env.colors == 256
    assert env.stdin_encoding is None
    assert env.stdout_encoding is None
    assert env.stderr_encoding is None
    assert env._

# Generated at 2022-06-17 20:22:35.433676
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdout=None, stderr=None)
    assert env.stdin is None
    assert env.stdout is None
    assert env.stderr is None
    assert env.stdin_isatty is False
    assert env.stdout_isatty is False
    assert env.stderr_isatty is False
    assert env.stdin_encoding is None
    assert env.stdout_encoding is None
    assert env.stderr_encoding is None
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr is None
    assert env._devnull is None
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.config is not None
    assert env.dev

# Generated at 2022-06-17 20:22:42.242969
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=False, config_dir=DEFAULT_CONFIG_DIR, stdin=sys.stdin, stdin_isatty=True, stdin_encoding=None, stdout=sys.stdout, stdout_isatty=True, stdout_encoding=None, stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http')
    assert env.is_windows == False
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == True
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True