

# Generated at 2022-06-17 20:13:01.822289
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr
   

# Generated at 2022-06-17 20:13:12.985180
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdin_isatty=False, stdin_encoding=None, stdout=sys.stdout, stdout_isatty=True, stdout_encoding=None, stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http', config_dir=Path('/home/user/.config/httpie'), devnull=None)
    assert env.is_windows == False
    assert env.config_dir == Path('/home/user/.config/httpie')
    assert env.stdin == None
    assert env.stdin_isatty == False
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.std

# Generated at 2022-06-17 20:13:24.459231
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'

# Generated at 2022-06-17 20:13:34.897017
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env.stdin_encoding == None
    assert env.stdout_encoding == None
    assert env._orig_stderr == sys.stderr
   

# Generated at 2022-06-17 20:13:46.590388
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=True, config_dir=DEFAULT_CONFIG_DIR, stdin=sys.stdin, stdin_isatty=True, stdin_encoding='utf8', stdout=sys.stdout, stdout_isatty=True, stdout_encoding='utf8', stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http')
    assert env.is_windows == True
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == True
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty

# Generated at 2022-06-17 20:13:57.382168
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding is None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding is None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr
   

# Generated at 2022-06-17 20:14:06.086620
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=False, config_dir=DEFAULT_CONFIG_DIR, stdin=sys.stdin, stdin_isatty=sys.stdin.isatty(), stdin_encoding=None, stdout=sys.stdout, stdout_isatty=sys.stdout.isatty(), stdout_encoding=None, stderr=sys.stderr, stderr_isatty=sys.stderr.isatty(), colors=256, program_name='http')
    assert env.is_windows == False
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding

# Generated at 2022-06-17 20:14:14.836718
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr
   

# Generated at 2022-06-17 20:14:25.733414
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=False, config_dir=DEFAULT_CONFIG_DIR, stdin=sys.stdin, stdin_isatty=sys.stdin.isatty(), stdin_encoding=None, stdout=sys.stdout, stdout_isatty=sys.stdout.isatty(), stdout_encoding=None, stderr=sys.stderr, stderr_isatty=sys.stderr.isatty(), colors=256, program_name='http')
    assert env.is_windows == False
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding

# Generated at 2022-06-17 20:14:34.503389
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr
   

# Generated at 2022-06-17 20:14:59.292982
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env.config == Config(directory=DEFAULT_CONFIG_DIR)
    assert env.devnull == None
    assert env._orig_stderr == sys.st

# Generated at 2022-06-17 20:15:11.851157
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdin_isatty=False, stdin_encoding='utf8',
                      stdout=sys.stdout, stdout_isatty=True, stdout_encoding='utf8',
                      stderr=sys.stderr, stderr_isatty=True,
                      colors=256, program_name='http',
                      is_windows=False, config_dir=DEFAULT_CONFIG_DIR,
                      devnull=None)
    assert env.stdin is None
    assert env.stdin_isatty is False
    assert env.stdin_encoding == 'utf8'
    assert env.stdout is sys.stdout
    assert env.stdout_isatty is True
    assert env.stdout_encoding == 'utf8'

# Generated at 2022-06-17 20:15:18.073949
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdin_isatty=False, stdin_encoding='utf8', stdout=sys.stdout, stdout_isatty=True, stdout_encoding='utf8', stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http', is_windows=False, config_dir=DEFAULT_CONFIG_DIR)
    assert env.stdin == None
    assert env.stdin_isatty == False
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stdout_encoding == 'utf8'
    assert env.stderr == sys.stderr
    assert env.st

# Generated at 2022-06-17 20:15:25.312233
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr
   

# Generated at 2022-06-17 20:15:34.788408
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=True, config_dir=DEFAULT_CONFIG_DIR, stdin=sys.stdin, stdin_isatty=sys.stdin.isatty(), stdin_encoding=None, stdout=sys.stdout, stdout_isatty=sys.stdout.isatty(), stdout_encoding=None, stderr=sys.stderr, stderr_isatty=sys.stderr.isatty(), colors=256, program_name='http')
    assert env.is_windows == True
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding

# Generated at 2022-06-17 20:15:43.511639
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        stdin=None,
        stdin_isatty=False,
        stdin_encoding='utf8',
        stdout=sys.stdout,
        stdout_isatty=True,
        stdout_encoding='utf8',
        stderr=sys.stderr,
        stderr_isatty=True,
        colors=256,
        program_name='http',
        config_dir=DEFAULT_CONFIG_DIR,
        devnull=None
    )
    assert env.stdin is None
    assert env.stdin_isatty is False
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty is True
    assert env.stdout_encoding

# Generated at 2022-06-17 20:15:51.665499
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdout=None, stderr=None)
    assert env.stdin is None
    assert env.stdout is None
    assert env.stderr is None
    assert env.stdin_isatty is False
    assert env.stdout_isatty is False
    assert env.stderr_isatty is False
    assert env.stdin_encoding is None
    assert env.stdout_encoding is None
    assert env.stderr_encoding is None
    assert env.is_windows is False
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr is None
    assert env._devnull is None
    assert env._

# Generated at 2022-06-17 20:16:00.050431
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdin_isatty=False, stdin_encoding=None, stdout=sys.stdout, stdout_isatty=True, stdout_encoding=None, stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http')
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == None
    assert env.stdin_isatty == False
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env

# Generated at 2022-06-17 20:16:06.128168
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr
   

# Generated at 2022-06-17 20:16:15.433158
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdin_isatty=False, stdin_encoding='utf8',
                      stdout=sys.stdout, stdout_isatty=True, stdout_encoding='utf8',
                      stderr=sys.stderr, stderr_isatty=True,
                      colors=256, program_name='http')
    assert env.stdin is None
    assert env.stdin_isatty is False
    assert env.stdin_encoding == 'utf8'
    assert env.stdout is sys.stdout
    assert env.stdout_isatty is True
    assert env.stdout_encoding == 'utf8'
    assert env.stderr is sys.stderr
    assert env.stderr_isatty is True
    assert env

# Generated at 2022-06-17 20:16:53.421880
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr
   

# Generated at 2022-06-17 20:17:04.600687
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdin_isatty=False, stdin_encoding='utf8', stdout=sys.stdout, stdout_isatty=True, stdout_encoding='utf8', stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http', config_dir=DEFAULT_CONFIG_DIR)
    assert env.stdin is None
    assert env.stdin_isatty is False
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty is True
    assert env.stdout_encoding == 'utf8'
    assert env.stderr == sys.stderr
    assert env.stderr_isatty

# Generated at 2022-06-17 20:17:14.661905
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(program_name='httpie', config_dir='/home/user/.httpie')
    assert env.program_name == 'httpie'
    assert env.config_dir == '/home/user/.httpie'
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256

# Generated at 2022-06-17 20:17:25.151154
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.program_name == 'http'
    assert env.colors == 256
    assert env._orig_stderr == sys.stderr
   

# Generated at 2022-06-17 20:17:30.264129
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin='stdin', stdout='stdout', stderr='stderr', config_dir='config_dir')
    assert env.stdin == 'stdin'
    assert env.stdout == 'stdout'
    assert env.stderr == 'stderr'
    assert env.config_dir == 'config_dir'


# Generated at 2022-06-17 20:17:36.970279
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=True, config_dir=DEFAULT_CONFIG_DIR, stdin=sys.stdin, stdin_isatty=True, stdin_encoding=None, stdout=sys.stdout, stdout_isatty=True, stdout_encoding=None, stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http')
    print(env)

if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-17 20:17:45.195611
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        stdin=None,
        stdin_isatty=False,
        stdin_encoding=None,
        stdout=None,
        stdout_isatty=False,
        stdout_encoding=None,
        stderr=None,
        stderr_isatty=False,
        colors=256,
        program_name='http',
        config_dir=DEFAULT_CONFIG_DIR,
        devnull=None
    )
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None

# Generated at 2022-06-17 20:17:59.006347
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=True, config_dir=DEFAULT_CONFIG_DIR, stdin=sys.stdin, stdin_isatty=sys.stdin.isatty(), stdin_encoding=None, stdout=sys.stdout, stdout_isatty=sys.stdout.isatty(), stdout_encoding=None, stderr=sys.stderr, stderr_isatty=sys.stderr.isatty(), colors=256, program_name='http')
    assert env.is_windows == True
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding

# Generated at 2022-06-17 20:18:08.582569
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=True, config_dir=DEFAULT_CONFIG_DIR, stdin=sys.stdin,
                      stdin_isatty=sys.stdin.isatty(), stdin_encoding=None, stdout=sys.stdout,
                      stdout_isatty=sys.stdout.isatty(), stdout_encoding=None, stderr=sys.stderr,
                      stderr_isatty=sys.stderr.isatty(), colors=256, program_name='http')
    assert env.is_windows == True
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env

# Generated at 2022-06-17 20:18:17.966826
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr
   

# Generated at 2022-06-17 20:19:03.385033
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdin_isatty=False, stdin_encoding='utf8', stdout=sys.stdout, stdout_isatty=True, stdout_encoding='utf8', stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http', is_windows=False, config_dir='/home/httpie/.config/httpie', devnull=None)
    assert env.stdin == None
    assert env.stdin_isatty == False
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True
    assert env.stdout_encoding == 'utf8'
    assert env.stderr == sys.st

# Generated at 2022-06-17 20:19:09.124561
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=True, config_dir=DEFAULT_CONFIG_DIR, stdin=sys.stdin, stdin_isatty=True, stdin_encoding=None, stdout=sys.stdout, stdout_isatty=True, stdout_encoding=None, stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http')
    assert env.is_windows == True
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == True
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True

# Generated at 2022-06-17 20:19:17.731672
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=False, config_dir=DEFAULT_CONFIG_DIR, stdin=sys.stdin, stdin_isatty=True, stdin_encoding='utf8', stdout=sys.stdout, stdout_isatty=True, stdout_encoding='utf8', stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http')
    assert env.is_windows == False
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == True
    assert env.stdin_encoding == 'utf8'
    assert env.stdout == sys.stdout
    assert env.stdout_isatty

# Generated at 2022-06-17 20:19:23.570559
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=False, config_dir=DEFAULT_CONFIG_DIR, stdin=sys.stdin, stdin_isatty=True, stdin_encoding='utf8', stdout=sys.stdout, stdout_isatty=True, stdout_encoding='utf8', stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http')
    print(env)
    print(env.config)
    print(env.devnull)
    env.devnull = None
    print(env.devnull)
    env.log_error('test')

if __name__ == '__main__':
    test_Environment()

# Generated at 2022-06-17 20:19:33.641470
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdin_isatty=False, stdin_encoding='utf8',
                      stdout=sys.stdout, stdout_isatty=True, stdout_encoding='utf8',
                      stderr=sys.stderr, stderr_isatty=True,
                      colors=256, program_name='http',
                      config_dir=DEFAULT_CONFIG_DIR,
                      devnull=None, is_windows=is_windows)
    assert env.stdin is None
    assert env.stdin_isatty is False
    assert env.stdin_encoding == 'utf8'
    assert env.stdout is sys.stdout
    assert env.stdout_isatty is True
    assert env.stdout_encoding == 'utf8'

# Generated at 2022-06-17 20:19:45.012628
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdout=None, stderr=None)
    assert env.stdin is None
    assert env.stdout is None
    assert env.stderr is None
    assert env.stdin_isatty is False
    assert env.stdout_isatty is False
    assert env.stderr_isatty is False
    assert env.stdin_encoding is None
    assert env.stdout_encoding is None
    assert env.stderr_encoding is None
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.devnull is None
    assert env._orig_stderr is None

# Generated at 2022-06-17 20:19:58.694712
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=False, config_dir=DEFAULT_CONFIG_DIR, stdin=sys.stdin, stdin_isatty=sys.stdin.isatty(), stdin_encoding=None, stdout=sys.stdout, stdout_isatty=sys.stdout.isatty(), stdout_encoding=None, stderr=sys.stderr, stderr_isatty=sys.stderr.isatty(), colors=256, program_name='http')
    assert env.is_windows == False
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding

# Generated at 2022-06-17 20:20:05.956871
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=False, config_dir=DEFAULT_CONFIG_DIR, stdin=sys.stdin, stdin_isatty=sys.stdin.isatty(), stdin_encoding=None, stdout=sys.stdout, stdout_isatty=sys.stdout.isatty(), stdout_encoding=None, stderr=sys.stderr, stderr_isatty=sys.stderr.isatty(), colors=256, program_name='http')
    assert env.is_windows == False
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding

# Generated at 2022-06-17 20:20:16.437153
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdout=None, stderr=None)
    assert env.stdin is None
    assert env.stdout is None
    assert env.stderr is None
    assert env.stdin_isatty is False
    assert env.stdout_isatty is False
    assert env.stderr_isatty is False
    assert env.stdin_encoding is None
    assert env.stdout_encoding is None
    assert env.stderr_encoding is None
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.is_windows == is_windows
    assert env.devnull is None
    assert env._orig_stderr is None

# Generated at 2022-06-17 20:20:25.272272
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr
   

# Generated at 2022-06-17 20:21:51.879944
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(stdin=None, stdin_isatty=False, stdin_encoding=None, stdout=sys.stdout, stdout_isatty=True, stdout_encoding=None, stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http', is_windows=False, config_dir=DEFAULT_CONFIG_DIR)
    assert env.stdin is None
    assert env.stdin_isatty is False
    assert env.stdin_encoding is None
    assert env.stdout is sys.stdout
    assert env.stdout_isatty is True
    assert env.stdout_encoding is None
    assert env.stderr is sys.stderr
    assert env.stderr_isatty is True

# Generated at 2022-06-17 20:21:57.800404
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=None, is_windows=False, config_dir=DEFAULT_CONFIG_DIR, stdin=sys.stdin, stdin_isatty=False, stdin_encoding=None, stdout=sys.stdout, stdout_isatty=True, stdout_encoding=None, stderr=sys.stderr, stderr_isatty=True, colors=256, program_name='http')
    assert env.is_windows == False
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == False
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == True

# Generated at 2022-06-17 20:22:03.383616
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(devnull=True, stdin=True, stdout=True, stderr=True)
    assert env.devnull == True
    assert env.stdin == True
    assert env.stdout == True
    assert env.stderr == True

# Generated at 2022-06-17 20:22:12.911063
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        devnull=None,
        is_windows=False,
        config_dir=DEFAULT_CONFIG_DIR,
        stdin=sys.stdin,
        stdin_isatty=sys.stdin.isatty(),
        stdin_encoding=None,
        stdout=sys.stdout,
        stdout_isatty=sys.stdout.isatty(),
        stdout_encoding=None,
        stderr=sys.stderr,
        stderr_isatty=sys.stderr.isatty(),
        colors=256,
        program_name='http'
    )
    assert env.is_windows == False
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
   

# Generated at 2022-06-17 20:22:24.271166
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment(
        config_dir='/home/httpie/.httpie',
        stdin=None,
        stdin_isatty=False,
        stdin_encoding='utf8',
        stdout=sys.stdout,
        stdout_isatty=True,
        stdout_encoding='utf8',
        stderr=sys.stderr,
        stderr_isatty=True,
        colors=256,
        program_name='http',
        devnull=None,
        is_windows=False
    )
    assert env.config_dir == '/home/httpie/.httpie'
    assert env.stdin is None
    assert env.stdin_isatty is False
    assert env.stdin_encoding == 'utf8'

# Generated at 2022-06-17 20:22:35.392482
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr
   

# Generated at 2022-06-17 20:22:45.284945
# Unit test for constructor of class Environment
def test_Environment():
    env = Environment()
    assert env.is_windows == is_windows
    assert env.config_dir == DEFAULT_CONFIG_DIR
    assert env.stdin == sys.stdin
    assert env.stdin_isatty == sys.stdin.isatty()
    assert env.stdin_encoding == None
    assert env.stdout == sys.stdout
    assert env.stdout_isatty == sys.stdout.isatty()
    assert env.stdout_encoding == None
    assert env.stderr == sys.stderr
    assert env.stderr_isatty == sys.stderr.isatty()
    assert env.colors == 256
    assert env.program_name == 'http'
    assert env._orig_stderr == sys.stderr
   