

# Generated at 2022-06-20 17:07:43.057798
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = get_mock_module()
    aix_hw = AIXHardware(module)
    vmstat_out = """
root@nim:/root #  /usr/bin/vmstat -v
 memory pages
    total =    2156920
    pin   =    2093921
    in    =         0
    free  =      63002
    pin   =    2093921
    v_wire =    2093921
    v_pglck=         0
    v_clean=    2093921
    v_free =      63475
    v_pgin =         0
    v_pgout=         0
    v_rept =         0
    v_pgint=         0
    v_swpin=         0
    v_swpout=        0
"""

# Generated at 2022-06-20 17:07:54.537359
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    aixHardware = AIXHardware()
    aixHardware.module = AnsibleModule(argument_spec=dict())
    lsconf_path = aixHardware.module.get_bin_path("lsconf")
    if lsconf_path:
        rc, out, err = aixHardware.module.run_command(lsconf_path)
        if rc == 0 and out:
            for line in out.splitlines():
                data = line.split(':')
                if 'Machine Serial Number' in line:
                    test_data = data[1].strip()
                    aix_data = aixHardware.get_dmi_facts()
                    assert test_data == aix_data['product_serial']
                if 'LPAR Info' in line:
                    test_data = data[1].strip()
                    aix_data = aixHardware

# Generated at 2022-06-20 17:08:03.498583
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    import sys

    class FakeAnsibleModule:
        def __init__(self):
            self.run_command_calls = []
            self.run_command_calls_args = []
            self.run_command_calls_res = []
            self.get_bin_path_calls = []
            self.get_bin_path_calls_args = []
            self.get_bin_path_calls_res = []
            self.ansible_facts = {}

        def run_command(self, args, use_unsafe_shell=False):
            self.run_command_calls.append(args[0])
            self.run_command_calls_args.append(args)
            return self.run_command_calls_res.pop(0)


# Generated at 2022-06-20 17:08:12.224506
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    vgs_facts = AIXHardware().get_vgs_facts()
    assert vgs_facts['vgs']['testvg'][1]['pv_name'] == 'hdisk105'
    assert vgs_facts['vgs']['testvg'][1]['free_pps'] == '838'
    assert vgs_facts['vgs']['testvg'][1]['total_pps'] == '999'
    assert vgs_facts['vgs']['testvg'][1]['pv_state'] == 'active'
    assert vgs_facts['vgs']['testvg'][1]['pp_size'] == '4 megabyte(s)'

# Generated at 2022-06-20 17:08:21.192920
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    class mock_module():
        def get_bin_path(self, path, required=False):
            return "/usr/sbin/lsconf"


# Generated at 2022-06-20 17:08:33.301869
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware_collector = AIXHardwareCollector(module=module)
    hardware_obj = hardware_collector.collect()[0]

    # test_device_facts is a dictionary that contains the desired output of get_device_facts method

# Generated at 2022-06-20 17:08:42.262163
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModuleMock()
    module.run_command.return_value = (0, 'proc0 Available 00-00 Processor\n'
                                           'proc1 Available 00-01 Processor\n'
                                           'proc2 Available 00-02 Processor\n'
                                           'proc3 Available 00-03 Processor\n'
                                           'proc4 Available 00-04 Processor\n'
                                           'proc5 Available 00-05 Processor\n'
                                           'proc6 Available 00-06 Processor\n'
                                           'proc7 Available 00-07 Processor', '')
    module.run_command.return_value = (0, 'type PowerPC_POWER9', '')
    module.run_command.return_value = (0, 'smt_threads 6', '')

# Generated at 2022-06-20 17:08:53.588201
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = MockModule()
    hardware = AIXHardware(module)
    vgs_facts = hardware.get_vgs_facts()
    assert 'vgs' in vgs_facts
    for vg in vgs_facts['vgs']:
        assert 'pv_name' in vgs_facts['vgs'][vg][0]
        assert 'pv_state' in vgs_facts['vgs'][vg][0]
        assert 'total_pps' in vgs_facts['vgs'][vg][0]
        assert 'free_pps' in vgs_facts['vgs'][vg][0]
        assert 'pp_size' in vgs_facts['vgs'][vg][0]


# Generated at 2022-06-20 17:09:05.007331
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    device_facts = {}
    device_facts['devices'] = {}

    device_attrs = {}
    device_name = 'ent0'
    device_state = 'Available'
    device_type = 'Ethernet'
    lsattr_cmd_args = ['/usr/sbin/lsattr', '-E', '-l', device_name]
    rc, out_lsattr, err = module.run_command(lsattr_cmd_args)
    for attr in out_lsattr.splitlines():
        attr_fields = attr.split()
        attr_name = attr_fields[0]
        attr_parameter = attr_fields[1]
        device_attrs[attr_name] = attr_parameter


# Generated at 2022-06-20 17:09:10.717290
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    h = AIXHardware()
    d1 = {
        'processor_cores': 4,
        'processor_count': 4,
        'processor': 'PowerPC_POWER8'
    }
    d2 = h.get_cpu_facts()
    assert d2 == d1

# Generated at 2022-06-20 17:09:32.071765
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={})
    hardware_obj = AIXHardware(module)

    assert hardware_obj.populate() is not None


# Generated at 2022-06-20 17:09:34.581038
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_obj = AIXHardwareCollector()
    assert hardware_obj.platform == 'AIX'


# Generated at 2022-06-20 17:09:37.545874
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hc = AIXHardwareCollector()
    assert hc.platform == 'AIX'


# Generated at 2022-06-20 17:09:49.023522
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    class MockModule(object):
        def __init__(self):
            self.run_command_results = []
            self.run_command_calls = []

        def run_command(self, args, use_unsafe_shell=False):
            self.run_command_calls.append(args)
            results = self.run_command_results.pop(0)
            return results

        def get_bin_path(self, arg, required=False):
            return "/usr/bin/%s" % arg

    hardware = AIXHardware()

    hardware.module = MockModule()


# Generated at 2022-06-20 17:09:56.544298
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )
    facts = AIXHardware(module=module).populate()

    assert isinstance(facts['processor'], list)
    assert isinstance(facts['processor_cores'], int)
    assert isinstance(facts['processor_count'], int)



# Generated at 2022-06-20 17:10:07.643969
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = AIXHardware(module)
    hardware_facts = hardware.get_memory_facts()
    assert hardware_facts['memtotal_mb'] == 16384
    assert hardware_facts['memfree_mb'] == 16384
    assert hardware_facts['swapfree_mb'] == 8389
    assert hardware_facts['swaptotal_mb'] == 8389


# Generated at 2022-06-20 17:10:22.140801
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    """
    To run the test:
    >>> python -m ansible.module_utils.facts.hardware.aix
    """
    from ansible.module_utils.facts import ModuleArgsParser

    cpu_facts = {u'processor': [u'PowerPC_POWER7'],
                 u'processor_cores': 2,
                 u'processor_count': 4}
    dmi_facts = {u'firmware_version': u'V7R2M0',
                 u'lpar_info': u'aixlpar1',
                 u'product_name': u'8286-42A',
                 u'product_serial': u'MJA123456'}

# Generated at 2022-06-20 17:10:25.280478
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModuleMock()

    hardware = AIXHardware(module)

    assert hardware

# Generated at 2022-06-20 17:10:32.084902
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware()
    hardware.module = module
    hardware.populate()
    assert hardware.facts['firmware_version'] is not None
    assert hardware.facts['lpar_info'] is not None
    assert hardware.facts['product_name'] is not None
    assert hardware.facts['product_serial'] is not None
    assert hardware.facts['processor'] is not None
    assert hardware.facts['processor_cores'] is not None
    assert hardware.facts['processor_count'] is not None
    assert hardware.facts['memfree_mb'] is not None
    assert hardware.facts['memtotal_mb'] is not None
    assert hardware.facts['swapfree_mb'] is not None
    assert hardware.facts['swaptotal_mb'] is not None


#

# Generated at 2022-06-20 17:10:44.781607
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    from ansible.module_utils._text import to_bytes
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-20 17:11:24.693793
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    # Create the object with custom facts module parameter
    aix_hw = AIXHardware({'gather_subset': '!all', 'gather_timeout': 10})

    assert aix_hw.facts == {}



# Generated at 2022-06-20 17:11:26.452880
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware = AIXHardware()
    assert hardware.platform == 'AIX'
    assert hardware.populate() is not None

# Generated at 2022-06-20 17:11:39.445061
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    hardware_obj = AIXHardware()

    # create a mock response and mock run_command method
    out = "firmware_version : IBM,FW630-1465-99"
    hardware_obj.module.run_command = lambda x: (0, out, '')
    dmi_facts = hardware_obj.get_dmi_facts()
    assert 'firmware_version' in dmi_facts
    assert 'IBM,FW630-1465-99' in dmi_facts['firmware_version']
    assert dmi_facts['firmware_version'] == 'IBM,FW630-1465-99'

    out = "firmware_version : IBM,U78C6-99"
    hardware_obj.module.run_command = lambda x: (0, out, '')
    dmi_

# Generated at 2022-06-20 17:11:46.224226
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    test_class = AIXHardware(None)
    test_class.module = None
    test_class.populate()
    # test_class.get_dmi_facts()


if __name__ == '__main__':
    test_AIXHardware_get_dmi_facts()

# Generated at 2022-06-20 17:11:51.465738
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    hw = AIXHardware()
    ansible_mod = MockAnsibleModule()
    setattr(hw, 'module', ansible_mod)
    cpu_facts = hw.get_cpu_facts()
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'PowerPC_POWER8'
    assert cpu_facts['processor_cores'] == 1

# Generated at 2022-06-20 17:12:01.082842
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    """
    Test to see if the constructor for AIXHardware is working correctly
    """
    module = AnsibleModule(argument_spec={})
    hw = AIXHardware({}, module=module)
    assert(hw.module.basic is not None)
    assert(hw.platform == 'AIX')
    assert(hw.get_cpu_facts() != {})
    assert(hw.get_memory_facts() != {})
    assert(hw.get_dmi_facts() != {})
    assert(hw.get_vgs_facts() != {})
    assert(hw.get_mount_facts() != {})
    assert(hw.get_device_facts() != {})
    assert(hw.populate() != {})


# Generated at 2022-06-20 17:12:12.167879
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    """Test get_memory_facts method of AIXHardware"""

    test_object = AIXHardware()
    test_object.module = MockModule()

    # case 1: vmstat returns success
    test_object.module.run_command.return_value = (0,
                                                   """ memory pages
    2824013
        free pages
    1388531
        large page memory pages
    0
        large page free pages
    0""",
                                                   '')
    expected_result = {'memfree_mb': 6945, 'memtotal_mb': 13920, 'swapfree_mb': 0, 'swaptotal_mb': 0}
    assert test_object.get_memory_facts() == expected_result

    # case 2: vmstat returns failure

# Generated at 2022-06-20 17:12:17.202515
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    h = AIXHardware({})
    facts = h.get_dmi_facts()
    assert 'firmware_version' in facts
    assert facts['firmware_version'] == 'IBM,'
    assert 'product_serial' in facts
    assert facts['product_serial'] == 'IBM,0'
    assert 'lpar_info' in facts
    assert facts['lpar_info'] == 'IBM,0'
    assert 'product_name' in facts
    assert facts['product_name'] == 'IBM,0'



# Generated at 2022-06-20 17:12:23.653781
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False
    )
    hardware = AIXHardware(module)
    out = hardware.get_dmi_facts()
    assert out.get('lpar_info') is not None
    assert out.get('product_name') is not None
    assert out.get('product_serial') is not None
    assert out.get('firmware_version') is not None


# Generated at 2022-06-20 17:12:28.255533
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    h = AIXHardware(module)

    result = h.get_device_facts()

# Generated at 2022-06-20 17:13:39.644757
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    facts = hardware.populate()
    assert facts['processor'] == 'PowerPC_POWER8'
    assert facts['processor_count'] == 2
    assert facts['processor_cores'] == 1
    assert facts['product_name'] == 'IBM,8286-41A'
    assert facts['product_serial'] == '50ABBGE'
    assert facts['firmware_version'] == '7.57'
    assert facts['memtotal_mb'] == 32768
    assert facts['memfree_mb'] == 244
    assert facts['swaptotal_mb'] == 1023
    assert facts['swapfree_mb'] == 1007

# Generated at 2022-06-20 17:13:48.385226
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    device = AIXHardware(dict())

    dummy_command = '/usr/bin/lsattr -El sys0 -a fwversion'
    dummy_command_output = 'fwversion IBM,8233-E8B'
    dummy_command_stderr = ''
    dummy_command_rc = 0

    with mock.patch.object(device.module, "run_command", return_value=(dummy_command_rc, dummy_command_output, dummy_command_stderr)):
        result = device.get_dmi_facts()
        assert result['firmware_version'] == 'IBM,8233-E8B'



# Generated at 2022-06-20 17:13:53.585235
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    collector = AIXHardwareCollector()
    assert collector.facts is None
    assert collector.legacy_facts is None
    assert isinstance(collector._fact_class, AIXHardware)
    assert collector._fact_class.platform == 'AIX'
    collector.collect()
    assert collector.facts is not None
    assert collector.legacy_facts is None

# Generated at 2022-06-20 17:14:05.889608
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    h = AIXHardware({})
    assert h.facts['processor'] is not None
    assert h.facts['processor_cores'] is not None
    assert h.facts['processor_count'] is not None
    assert h.facts['memtotal_mb'] is not None
    assert h.facts['memfree_mb'] is not None
    assert h.facts['swaptotal_mb'] is not None
    assert h.facts['swapfree_mb'] is not None
    assert h.facts['firmware_version'] is not None
    assert h.facts['product_serial'] is not None
    assert h.facts['lpar_info'] is not None
    assert h.facts['product_name'] is not None
    assert h.facts['vgs'] is not None
    assert h.facts['mounts'] is not None

# Generated at 2022-06-20 17:14:07.455439
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    assert AIXHardware().get_mount_facts()

# Generated at 2022-06-20 17:14:14.294598
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = AIXHardware(module)
    hardware_facts = hardware_obj.populate()
    assert hardware_facts['processor_cores'] == 4
    assert hardware_facts['memtotal_mb'] == 204400
    assert hardware_facts['swaptotal_mb'] == 314368
    assert hardware_facts['firmware_version'] == '1FW214.1'


# Generated at 2022-06-20 17:14:25.294205
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    hardware = AIXHardware(dict(), dict())
    hardware.module.run_command = Mock(return_value=(0, 'memory pages:         133392', ''))
    hardware.module.run_command = Mock(return_value=(0, 'free pages:            26647', ''))

    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 53189504
    assert memory_facts['memfree_mb'] == 10731520


# Generated at 2022-06-20 17:14:37.685093
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    '''
    Unit test for method get_vgs_facts of class AIXHardware
    '''
    module = AnsibleModule(argument_spec={})
    aix_hw = AIXHardware(module=module)
    res = aix_hw.get_vgs_facts()

# Generated at 2022-06-20 17:14:46.778854
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    from ansible.module_utils.facts import fact_collector
    collector = fact_collector.find_collector("hardware", "AIXHardwareCollector")
    hardware = collector.collect(None, None)

    assert hardware.memfree_mb == hardware.memtotal_mb - hardware.memused_mb
    assert hardware.swapfree_mb == hardware.swaptotal_mb - hardware.swapused_mb

# Generated at 2022-06-20 17:14:49.483606
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware_facts = AIXHardware()
    assert hardware_facts.populate()