

# Generated at 2022-06-20 17:07:47.895829
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    import sys

    import pytest

    class MockModule(object):

        def __init__(self):
            self.params = {
            }

        def run_command(self, command, check_rc=False, use_unsafe_shell=False):
            if isinstance(command, list):
                # AIX lsattr command
                return 0, lsattr_output, ''
            else:
                # AIX lsdev command
                return 0, lsdev_output, ''

        def get_bin_path(self, command, required=False, opt_dirs=[]):
            return '/bin/' + command

        def fail_json(self, msg, **kwargs):
            print('\tFailed to gather AIX hardware facts : %s' % msg, file=sys.stderr)
            return sys.exit(1)

# Generated at 2022-06-20 17:07:58.403417
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    '''Test class AIXHardware: Method - populate'''
    module = AnsibleModule(argument_spec={})


# Generated at 2022-06-20 17:08:00.537725
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware = AIXHardware()
    assert hardware.platform == 'AIX'

# Generated at 2022-06-20 17:08:11.199210
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    """
    dummy class containing expected data
    """
    class dummy():
        def __init__(self, out, err):
            self.out = out
            self.err = err
    """
    test with 1 cpu
    """
    out = "proc0  Available 00-00 Processor\n"
    err = ""
    module = dummy(out, err)
    module.run_command = lambda x, y: (0, out, err)
    hw = AIXHardware(module)
    cpu_facts = hw.get_cpu_facts()
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1
    """
    test with 2 cpu
    """
    out = "proc0  Available 00-00 Processor\nproc1  Available 00-00 Processor\n"


# Generated at 2022-06-20 17:08:17.333835
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    fact_hardware_module = AIXHardware(module)
    device_facts = fact_hardware_module.get_device_facts()

    assert device_facts
    assert 'devices' in device_facts
    assert device_facts['devices']

    assert 'ent3' in device_facts['devices']
    assert device_facts['devices']['ent3']
    assert 'state' in device_facts['devices']['ent3']
    assert 'type' in device_facts['devices']['ent3']
    assert 'attributes' in device_facts['devices']['ent3']

# Generated at 2022-06-20 17:08:20.965324
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    aixhw = AIXHardware(None)
    assert aixhw.get_cpu_facts()['processor_count'] > 0


# Generated at 2022-06-20 17:08:25.604416
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector._platform == 'AIX'
    assert hardware_collector._fact_class == AIXHardware

# Generated at 2022-06-20 17:08:34.703350
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    """
    mocker fixture to mock the module.run_command
        https://github.com/pytest-dev/pytest-mock
    run pytest with -s to print the stdout
    """
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils._text import to_bytes
    import pytest
    import os
    import tempfile
    # write a dummy lsps output file
    fd, path = tempfile.mkstemp()
    with os.fdopen(fd, 'wb') as f:
        f.write(to_bytes('''
NAME: swap
  Size:       512MB
  Free:        50MB (10.0%)
'''))
    os.environ['PATH'] += os.pathsep + os.path.dir

# Generated at 2022-06-20 17:08:39.768219
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )
    module.run_command = MagicMock(return_value=(0, 0, 0))
    ahw = AIXHardware(module)
    result = ahw.get_cpu_facts()
    assert type(result) == dict
    assert 'processor' in result
    assert 'processor_cores' in result
    assert 'processor_count' in result


# Generated at 2022-06-20 17:08:47.211883
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    """
    Constructor of AIXHardwareCollector class should create
    a new object of AIXHardwareCollector with correct attributes
    """
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector._platform == 'AIX'
    assert hardware_collector._fact_class == AIXHardware

# Generated at 2022-06-20 17:09:06.897324
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    facts = AIXHardwareCollector()
    assert facts.platform == AIXHardware().platform

# Generated at 2022-06-20 17:09:12.312684
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert 'processor_count' in cpu_facts
    assert 'processor' in cpu_facts
    assert 'processor_cores' in cpu_facts


# Generated at 2022-06-20 17:09:18.917097
# Unit test for method get_mount_facts of class AIXHardware

# Generated at 2022-06-20 17:09:25.076639
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    class MockModule(object):
        def __init__(self, params):
            self.params = params

        def run_command(self, cmd):
            if cmd == '/usr/sbin/lsvg -o':
                return 0, "rootvg realsyncvg testvg\n", ""
            if cmd == '/usr/sbin/lsvg rootvg':
                return 0, "", ""
            if cmd == '/usr/sbin/lsvg -p rootvg':
                return 0, "PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION\n" \
                          "hdisk0            active            546         0           00..00..00..00..00\n" \
                          "hdisk1            active            546         113         00..00..00..21..92\n", ""


# Generated at 2022-06-20 17:09:33.126798
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = type('FakeModule', (object, ), {
        'get_bin_path': lambda self, path, required=False: "/usr/sbin/%s" % path,
        'run_command': lambda self, cmd, use_unsafe_shell=True: (0, "", "")
    })
    ah = AIXHardware(module)
    ah.get_mount_facts()


# Generated at 2022-06-20 17:09:47.284217
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    module._load_params()
    fail = False
    fails = []
    out = "rootvg:\n" \
          "PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION\n" \
          "hdisk0            active            546         0           00..00..00..00..00\n" \
          "hdisk1            active            546         113         00..00..00..21..92"
    vgs_facts = AIXHardware(module).get_vgs_facts()
    if 'vgs' not in vgs_facts or 'rootvg' not in vgs_facts['vgs']:
        fail = True
        fails.append("Dictionary vgs_facts has no vgs key")

# Generated at 2022-06-20 17:09:59.058944
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    hardware = AIXHardware({})
    hardware_facts = hardware.populate()
    assert hardware_facts['firmware_version'] == '03.64.00.00'
    assert hardware_facts['lpar_info'] == '1 00A54F8C4C00 8192'
    assert hardware_facts['processor'] == 'PowerPC_POWER8'
    assert hardware_facts['processor_cores'] == 1
    assert hardware_facts['processor_count'] == 1
    assert hardware_facts['product_name'] == '8286-41A'
    assert hardware_facts['product_serial'] == '1234567890123456789'

# Generated at 2022-06-20 17:10:11.014281
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    class FakeModule(object):
        def __init__(self, module):
            self.module = module
            self.run_command = module.run_command
            self.get_bin_path = module.get_bin_path

    h = AIXHardware(FakeModule(module))


# Generated at 2022-06-20 17:10:23.024560
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = AIXHardware(module)

    # Example of lsdev -Cc disk output for 2 disks
    lsdev_cmd_output = """
        name status description
        hdisk0 Available PCI Socket 0 DASD Backplane
        hdisk1 Available PCI Socket 0 DASD Backplane
    """

    # Result from get_device_facts is dictionary and looks like this (for example for 2 disks)

# Generated at 2022-06-20 17:10:27.810304
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    facts_obj = AIXHardwareCollector()
    assert facts_obj._platform == 'AIX'
    assert facts_obj.__class__.__name__ == 'AIXHardwareCollector'


# Generated at 2022-06-20 17:11:04.569980
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    """ Unit test for AIXHardwareCollector """
    aix_hardware_collector = AIXHardwareCollector()
    assert aix_hardware_collector is not None

# Generated at 2022-06-20 17:11:16.819919
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    import sys
    import StringIO

    m = AIXHardware({})

    # simulate /usr/sbin/vmstat -v output
    vmstat_out = """
memory pages:           8192
cached file pages:      1884
free pages:             2270
pinned pages:           0
paging space pages:     4194
virtual memory:         4194304K
    """
    sys.stdin = StringIO.StringIO(vmstat_out)
    memory_facts = m.get_memory_facts()
    assert(memory_facts['memtotal_mb'] == 32768)
    assert(memory_facts['memfree_mb'] == 9088)
    assert(memory_facts['swaptotal_mb'] == 0)
    assert(memory_facts['swapfree_mb'] == 0)


# Generated at 2022-06-20 17:11:27.186185
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    aix_fact = AIXHardware(module)
    cpu_facts = aix_fact.get_cpu_facts()
    assert 'processor' in cpu_facts
    assert 'processor_count' in cpu_facts
    assert 'processor_cores' in cpu_facts
    assert len(cpu_facts['processor']) > 0
    assert cpu_facts['processor_count'] > 0
    assert cpu_facts['processor_cores'] > 0


# Generated at 2022-06-20 17:11:39.608177
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware

    module = object()
    def run_command(args, **kwargs):
        """
        method to mock run_command
        """
        out = """root@:[/]/ # lsattr -El sys0 -a fwversion
fwversion IBM,M10_1708_073              True
"""
        return 0, out, ''

    def get_bin_path(bin_name, required=True):
        """
        method to mock get_bin_path
        """
        return '/usr/sbin/' + bin_name

    module.run_command = run_command
    module.get_bin_path = get_bin_path
    obj = AIXHardware(module)

# Generated at 2022-06-20 17:11:52.339958
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_facts_instance = AIXHardware(module)
    facts = hardware_facts_instance.populate()
    assert facts['firmware_version'] == '1.29.0'
    assert facts['lpar_info'] == 'AIX test - aix.test'
    assert facts['product_name'] == 'TestModel'
    assert facts['product_serial'] == 'aix.test'
    assert facts['processor_cores'] == 1
    assert facts['processor_count'] == 2
    assert facts['processor'] == 'PowerPC_POWER7'
    assert facts['memtotal_mb'] == 2048
    assert facts['memfree_mb'] == 1024

# Generated at 2022-06-20 17:12:01.941909
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-20 17:12:12.403753
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    obj = AIXHardware(dict())

# Generated at 2022-06-20 17:12:17.364573
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    """ Unit test for method get_vgs_facts of class AIXHardware """

    def execute_mock(self, cmd, **kwargs):
        """ mock for module.run_command() """
        if cmd.startswith('lsvg'):
            if cmd.endswith('-p'):
                return (0, lsvg_data, '')
            else:
                return (0, lsvg_size, '')

    class AIXHardwareTest(AIXHardware):
        """ class to test method get_vgs_facts """

        def __init__(self, module):
            super(AIXHardwareTest, self).__init__(module)
            self.module.run_command = execute_mock

    module = MagicMock(name='module')

    # test data

# Generated at 2022-06-20 17:12:23.755562
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    hardware_collector = AIXHardwareCollector(module=module)
    hardware = hardware_collector.collect()[0]
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] > 0
    assert cpu_facts['processor']
    assert cpu_facts['processor_cores'] > 0



# Generated at 2022-06-20 17:12:28.349808
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    """
    Unit test for method populate of class AIXHardware
    """
    class AnsibleModule:
        def __init__(self):
            self.params = {}
            self.run_command_patcher = patchers.patch('ansible.module_utils.facts.hardware.aix.AIXHardware.run_command')
            self.run_command = self.run_command_patcher.start()

        def get_bin_path(self, path, opt_dirs=[]):
            return '/usr/bin/' + path

    ansible_module = AnsibleModule()
    hardware_collector = AIXHardware(ansible_module)

    hardware_collector.populate()
    assert ansible_module.run_command.call_count == 2, "module.run_command was not called once"

# Generated at 2022-06-20 17:13:47.908066
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    facts = AIXHardware()
    results = facts.get_device_facts()
    assert 'devices' in results
    device_facts = results['devices']
    assert 'ent0' in device_facts

# Generated at 2022-06-20 17:14:00.825986
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    hardware = AIXHardware()
    hardware.module = AnsibleModuleMock()

# Generated at 2022-06-20 17:14:09.742251
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware_obj = AIXHardware()

    lsdev_cmd = hardware_obj.module.get_bin_path('lsdev', True)
    lsattr_cmd = hardware_obj.module.get_bin_path('lsattr', True)

    rc, out_lsdev, err = module.run_command(lsdev_cmd)
    for line in out_lsdev.splitlines():
        field = line.split()
        device_name = field[0]
        lsattr_cmd_args = [lsattr_cmd, '-E', '-l', device_name]
        rc, out_lsattr, err = module.run_command(lsattr_cmd_args)
    device_name = field[0]

# Generated at 2022-06-20 17:14:19.156647
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    test_object = AIXHardware({})
    rc, out, err = test_object.module.run_command("/usr/sbin/lsdev -Cc processor")
    if out:
        i = 0
        for line in out.splitlines():

            if 'Available' in line:
                if i == 0:
                    data = line.split(' ')
                    cpudev = data[0]

                i += 1
        processor_count = int(i)

        rc, out, err = test_object.module.run_command("/usr/sbin/lsattr -El " + cpudev + " -a type")

        data = out.split(' ')
        processor_type = data[1]


# Generated at 2022-06-20 17:14:29.675610
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='')
    module.read_file = MagicMock(return_value='')

    hardware = AIXHardware(module)
    hardware.populate()

    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor'] == 'PowerPC_POWER8'
    assert hardware.facts['processor_cores'] == 1
    assert hardware.facts['memtotal_mb'] == 50
    assert hardware.facts['memfree_mb'] == 10
    assert hardware.facts['swaptotal_mb'] == 100

# Generated at 2022-06-20 17:14:35.841004
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    aixhw = AIXHardware()
    dmi_data = aixhw.get_dmi_facts()
    assert len(dmi_data) >= 3
    assert dmi_data['firmware_version'] is not None
    assert dmi_data['lpar_info'] is not None
    assert dmi_data['product_name'] is not None

# Generated at 2022-06-20 17:14:50.018855
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware

# Generated at 2022-06-20 17:15:01.393980
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    AixHardwareModule = AIXHardware()

    from ansible.module_utils.facts.hardware.aix import AIX_MEMORY_INPUT
    out = AIX_MEMORY_INPUT

    # Test when virtual memory is full
    test_memfree_mb, test_memtotal_mb, test_swapfree_mb, test_swaptotal_mb = AixHardwareModule.get_memory_facts(out)
    assert test_memfree_mb == 48
    assert test_memtotal_mb == 28136
    assert test_swapfree_mb == 3084
    assert test_swaptotal_mb == 3084

    # Test when virtual memory is full and swap space is full

# Generated at 2022-06-20 17:15:08.299069
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    hw = AIXHardware(module)
    out = hw.get_memory_facts()
    assert out['memfree_mb'] != None
    assert out['memtotal_mb'] != None
    assert out['swapfree_mb'] != None
    assert out['swaptotal_mb'] != None


# Generated at 2022-06-20 17:15:21.477672
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec=dict())
    out = """/dev/hd4                    /                       jfs         2       yes     rw
/dev/hd2                    /usr                     jfs         2       yes     rw
/dev/hd9var                 /var                     jfs         2       yes     rw
/dev/hd3                    /tmp                     jfs         2       yes     rw
/dev/hd1                    /home                    jfs         2       yes     rw
/proc                      /proc                    procfs      no      no      rw
/dev/hd10opt               /opt                     jfs         2       yes     rw
/dev/livedump             /var/adm/ras/livedump     jfs         2       yes     rw"""
    s = AIXHardware()
    facts = {'devices': {}}
    key = s