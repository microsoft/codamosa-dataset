

# Generated at 2022-06-20 17:07:38.297716
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={'filter': {'required': False, 'type': 'list'}})
    hardware = AIXHardware(module)
    facts = hardware.get_dmi_facts()
    module.exit_json(ansible_facts=facts)



# Generated at 2022-06-20 17:07:46.065910
# Unit test for method get_device_facts of class AIXHardware

# Generated at 2022-06-20 17:07:52.310488
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    """
    Unit test for constructor of class AIXHardware
    """
    aix_hardware = AIXHardware({}, dict(paths=dict(lsdev='/usr/bin/lsdev',
                                                    lsattr='/usr/bin/lsattr')))
    assert aix_hardware.lsdev_path == '/usr/bin/lsdev'
    assert aix_hardware.lsattr_path == '/usr/bin/lsattr'

# Generated at 2022-06-20 17:08:01.503011
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    obj = AIXHardware()
    collected_facts = {
        'ansible_os_family': 'AIX',
        'ansible_os_name': 'AIX'
    }
    obj.module.exit_json = obj.module.exit_json_from_get_facts
    cmd = AIXHardwareCollector.get_cmd_from_resource('memory')[1].format(module=obj.module, resource='memory', container=obj)
    obj.module.run_command = obj.module.run_command_from_file_output(cmd, 'AIXHardwareMemoryFacts')
    cmd = AIXHardwareCollector.get_cmd_from_resource('cpu')[1].format(module=obj.module, resource='cpu', container=obj)
    obj.module.run_command = obj.module.run_command_from

# Generated at 2022-06-20 17:08:11.552133
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware_facts = AIXHardware()
    facts = hardware_facts.populate()
    assert facts['firmware_version'] == 'IBM,8233-E8B'
    assert facts['product_name'] == '8233-E8B'
    assert facts['product_serial'] == '01A12345678'
    assert facts['processor'][0] == 'PowerPC_POWER7'
    assert facts['processor_cores'] == 16
    assert facts['processor_count'] == 2
    assert facts['memfree_mb'] == 6556
    assert facts['memtotal_mb'] == 32512
    assert facts['swapfree_mb'] == 9728
    assert facts['swaptotal_mb'] == 9728
    assert len(facts['vgs']['rootvg']) == 2

# Generated at 2022-06-20 17:08:18.229041
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    input = yaml.load(EXAMPLE_YAML_OUTPUT_FROM_AIX_HARDWARE_FACTS)
    ah = AIXHardware(module)
    ah.populate(input)
    assert ah.facts['processor_cores'] == 16
    assert ah.facts['processor_count'] == 4
    assert ah.facts['memtotal_mb'] == 33276
    assert ah.facts['lpar_info'] == 'AIX01'
    assert ah.facts['firmware_version'] == '3.001.000.0000'
    assert ah.facts['swaptotal_mb'] == 3727
    assert ah.facts['swapfree_mb'] == 3721
    assert ah.facts['memfree_mb'] == 1714

# Generated at 2022-06-20 17:08:32.192240
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = type('Module', (object,), {})
    aix_hardware = AIXHardware(module)

    lsps_out = """
    Page Space Information:
    Total            Paging Space        51200       MB
    Percent Used     Paging Space        0     %
    Percent Used     Paging Space        0     %
    Percent Used     Paging Space        0     %
    """
    aix_hardware.module.run_command = MockRunCommand(stdout=lsps_out)
    aix_hardware.module.get_bin_path = MockGetBinPath(bin_path=True, command='lsps')
    aix_hardware.module.get_bin_path = MockGetBinPath(bin_path=True, command='xargs')

# Generated at 2022-06-20 17:08:42.091156
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    class Module(object):
        class RunCommandResult(object):
            def __init__(self, rc, stdout, stderr):
                self.rc = rc
                self.stdout = stdout
                self.stderr = stderr

        def __init__(self):
            self.run_command_results = []

# Generated at 2022-06-20 17:08:54.523033
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    import sys
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts.collector import BaseFactCollector
    import tempfile

    # Unit test for method get_device_facts of class AIXHardware
    #
    # Test data
    #
    # Output of lsdev -Cc disk command. Set to aiX
    lsdev_cmd_out = 'name state description\n' \
                    'hdisk2 Available\n' \
                    'hdisk3 Available\n' \
                    'hdisk4 Available\n' \
                    'hdisk5 Available\n'

# Generated at 2022-06-20 17:08:59.051839
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    class MockModule(object):
        def __init__(self):
            self.run_command_counter = 0
            self.run_command_list = [
                (0, 'IBM,8233-E8B', ''),
                (0, 'CPC1 2A6230001', ''),
                (0, 'KVM Standard Virtual Machine', ''),
                (0, 'Z1193C7A', ''),
                (0, 'Machine Serial Number: Z1193C7A', ''),
                (0, 'LPAR Info: 1 LPAR(s) Total', ''),
                (0, 'System Model: IBM,8233-E8B', ''),
            ]

        def get_bin_path(self, arg1):
            return arg1


# Generated at 2022-06-20 17:09:18.675558
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hw_collector = AIXHardwareCollector()
    assert hw_collector._platform == 'AIX'
    assert hw_collector._fact_class == AIXHardware


# Generated at 2022-06-20 17:09:21.973128
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    '''
    Validate that class AIXHardware is constructed properly.
    '''
    fake_module = type('obj', (object,), {'run_command': lambda self, args, check_rc=True: (0, '', '')})
    hw = AIXHardware(fake_module)
    assert hw.module == fake_module

# Generated at 2022-06-20 17:09:35.663771
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():

    class mock_module:
        @staticmethod
        def get_bin_path(path, required=False):
            return '/usr/sbin/' + path


# Generated at 2022-06-20 17:09:45.890735
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.hardware.aix import AIXHardwareCollector
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    facts_collector = FactsCollector()
    aix_hardware_collector = AIXHardwareCollector(facts_collector)
    assert isinstance(aix_hardware_collector._fact_class, AIXHardware)
    assert aix_hardware_collector._platform == 'AIX'

# Generated at 2022-06-20 17:09:49.150619
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    aixhw = AIXHardware({'module_setup': True})
    assert aixhw.platform == 'AIX'

# Generated at 2022-06-20 17:10:01.056332
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec=dict())

    # create a test class
    class TestAIXHardware(AIXHardware):
        def __init__(self, module):
            super(TestAIXHardware, self).__init__(module=module)

        def get_cpu_facts(self):
            return {'processor_count': 2,
                    'processor': "PowerPC_POWER7"
                    }

        def get_memory_facts(self):
            return {'memtotal_mb': 1024,
                    'memfree_mb': 256,
                    'swaptotal_mb': 1024,
                    'swapfree_mb': 512
                    }


# Generated at 2022-06-20 17:10:09.065358
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = type('', (object,), {'run_command': run_command_mock})()
    ah = AIXHardware()
    ah.module = module
    memory_facts = ah.get_memory_facts()

    assert memory_facts['memfree_mb'] == 10
    assert memory_facts['memtotal_mb'] == 20
    assert memory_facts['swapfree_mb'] == 12
    assert memory_facts['swaptotal_mb'] == 24



# Generated at 2022-06-20 17:10:19.160521
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    aix_hardware = AIXHardware()
    aix_hardware.module = {
        'run_command': mock_run_command
    }

    aix_hardware.get_cpu_facts()

    assert aix_hardware.ansible_facts['processor_count'] == 6
    assert aix_hardware.ansible_facts['processor_cores'] == 1
    assert aix_hardware.ansible_facts['processor'] == "PowerPC_POWER7"


# Generated at 2022-06-20 17:10:26.651353
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.hardware.aix import AIXHardwareCollector

    fact_collector = FactCollector()
    aix_collector = AIXHardwareCollector(fact_collector)

    assert aix_collector._platform == 'AIX'

# Generated at 2022-06-20 17:10:33.014138
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_collector = AIXHardwareCollector(module=module)
    facts = hardware_collector.collect(module=module, collected_facts=None)
    assert isinstance(facts, dict)
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swapfree_mb' in facts

# Generated at 2022-06-20 17:11:10.042101
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    facts = AIXHardware()
    result = facts.get_mount_facts()
    assert result == {'mounts': []}, "Result : %s != %s" % (result, {'mounts': []})



# Generated at 2022-06-20 17:11:19.180066
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module=module)
    hardware.populate()

# Generated at 2022-06-20 17:11:27.961404
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    facts_obj = AIXHardware()
    facts_obj.module = AnsibleModuleMock()
    facts_obj.module.run_command = run_command
    dmi_facts = {'firmware_version': '0A00',
                 'product_serial': 'ABCDEFG',
                 'lpar_info': 'test_lpar',
                 'product_name': '9117-570'}

    assert facts_obj.get_dmi_facts() == dmi_facts



# Generated at 2022-06-20 17:11:39.777840
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    hardware = AIXHardware()
    hardware.module = FakeAnsibleModule()
    hardware.module.get_bin_path = lambda x, y: x
    vgs_facts = hardware.get_vgs_facts()
    assert len(vgs_facts) == 1
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs_facts['vgs']['rootvg'][0]['pv_state'] == 'active'
    assert vgs_facts['vgs']['rootvg'][0]['total_pps'] == '546'
    assert vgs_facts['vgs']['rootvg'][0]['free_pps'] == '0'

# Generated at 2022-06-20 17:11:52.413621
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    class ModuleMock(object):
        def __init__(self, value):
            self.value = value

        def get_bin_path(self, executable, required=False):
            dmi_path = ''
            if executable == 'lsconf':
                dmi_path = '/usr/sbin/lsconf'
            return dmi_path

        def run_command(self, command):
            rc = 0
            stdout = 'Machine Serial Number: ABC\nLPAR Info: 1 1 AIX 6.1\nSystem Model: IBM,9131-52A\n'
            stderr = ''
            return rc, stdout, stderr

    dmi_mock = ModuleMock('')
    aix_hw = AIXHardware(dmi_mock)

# Generated at 2022-06-20 17:12:01.970389
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    # Mock module
    module = AnsibleModule(argument_spec={})

    module.run_command = MagicMock()

# Generated at 2022-06-20 17:12:12.341288
# Unit test for method get_mount_facts of class AIXHardware

# Generated at 2022-06-20 17:12:24.709819
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True)

# Generated at 2022-06-20 17:12:34.971936
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    import io
    module = AnsibleModuleMock()
    mock_run_command = module.run_command
    aix_hardware = AIXHardware(module)

# Generated at 2022-06-20 17:12:45.728050
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    import copy
    from ansible.module_utils.facts.hardware.aix import AIXHardware

    test_context = {
        'module': None,
        'command_callbacks': None
    }
    test_context_aix = copy.deepcopy(test_context)
    test_context_aix['module'] = MockModuleUtils(
        {'command': '/usr/sbin/lsfs'},
        {'returncode': 0, 'stdout': 'test'},
        {},
        0,
        False
    )

# Generated at 2022-06-20 17:13:56.402661
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    facts = {}
    AIXHardwareCollector(facts).collect()
    assert(facts['ansible_facts']['hardware']['firmware_version'] == 'IBM,8205-E6C')

# Generated at 2022-06-20 17:13:57.915723
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = AIXHardware(module)
    assert hardware.get_mount_facts() == {'mounts': []}

# Generated at 2022-06-20 17:14:05.824976
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    class TestModule(object):
        attrs = {}
        run_command = test_run_command

    class TestAIXHardware(AIXHardware):
        def __init__(self, module):
            self.module = module

    test_module = TestModule()
    test_hardware = TestAIXHardware(test_module)
    test_hardware_facts = test_hardware.get_vgs_facts()
    if test_hardware_facts:
        assert 'vgs' in test_hardware_facts
        assert 'rootvg' in test_hardware_facts['vgs']
        assert 'realsyncvg' in test_hardware_facts['vgs']
        assert 'testvg' in test_hardware_facts['vgs']
    else:
        assert 1 == 0



# Generated at 2022-06-20 17:14:16.367078
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={})
    platform_facts = AIXHardware(module).populate()

    assert platform_facts['processor_cores'] > 0
    assert platform_facts['processor_count'] > 0
    assert platform_facts['memtotal_mb'] > 0
    assert platform_facts['memfree_mb'] > 0
    assert platform_facts['swaptotal_mb'] > 0
    assert platform_facts['swapfree_mb'] > 0
    assert platform_facts['firmware_version'] is not None
    assert platform_facts['product_serial'] is not None
    assert platform_facts['product_name'] is not None
    assert platform_facts['vgs']['rootvg'][0]['pp_size'] is not None

# Generated at 2022-06-20 17:14:26.412188
# Unit test for constructor of class AIXHardware
def test_AIXHardware():

    aix_hw = AIXHardware()
    aix_hw.populate()

    assert 'processor' in aix_hw.fact
    assert 'processor_cores' in aix_hw.fact
    assert 'processor_count' in aix_hw.fact
    assert 'memfree_mb' in aix_hw.fact
    assert 'memtotal_mb' in aix_hw.fact
    assert 'swapfree_mb' in aix_hw.fact
    assert 'swaptotal_mb' in aix_hw.fact



# Generated at 2022-06-20 17:14:37.971936
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    """
    This method is used to testing get_mount_facts method of class AIXHardware
    """
    from ansible.module_utils.facts.utils import get_mount_size

    class Options(object):
        def __init__(self, bin_path='/usr/bin', remote_tmp='/tmp', connection='local'):
            self.bin_path = bin_path
            self.remote_tmp = remote_tmp
            self.connection = connection

    class AnsibleModule(object):
        def __init__(self, bin_path='/usr/bin', remote_tmp='/tmp', connection='local'):
            self.bin_path = bin_path
            self.remote_tmp = remote_tmp
            self.connection = connection
            self.options = Options(bin_path, remote_tmp, connection)


# Generated at 2022-06-20 17:14:50.770706
# Unit test for method get_memory_facts of class AIXHardware

# Generated at 2022-06-20 17:15:01.683784
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    hardware = AIXHardware()
    hardware.module = AnsibleModule(argument_spec=dict())
    hardware.module.run_command = MagicMock(return_value=(0, VGS_OUTPUT, ""))
    hardware.module.get_bin_path = MagicMock(side_effect=lambda x: os.path.join(os.path.dirname(__file__), x))
    result = hardware.get_vgs_facts()
    assert result["vgs"].__len__() == 2
    assert result["vgs"]["rootvg"].__len__() == 2
    assert result["vgs"]["realsyncvg"].__len__() == 1
    assert result["vgs"]["rootvg"][0]["pv_name"] == "hdisk0"

# Generated at 2022-06-20 17:15:10.575832
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    aix_hardware_fact = AIXHardware(dict(module=None))

# Generated at 2022-06-20 17:15:22.532356
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    import sys
    import json
    import mock
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            filter=dict(type='list', default=['*'])
        )
    )

    # Mock lsdev command