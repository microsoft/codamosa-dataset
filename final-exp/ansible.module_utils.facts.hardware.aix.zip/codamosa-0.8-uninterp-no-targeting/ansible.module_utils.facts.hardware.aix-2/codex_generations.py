

# Generated at 2022-06-20 17:07:45.170940
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    vgs_facts = hardware.get_vgs_facts()
    assert vgs_facts["vgs"]
    assert vgs_facts["vgs"]["rootvg"]
    assert vgs_facts["vgs"]["testvg"]
    assert vgs_facts["vgs"]["realsyncvg"]
    assert len(vgs_facts) > 0


# Generated at 2022-06-20 17:07:56.544290
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    vgs_facts_data = {'vgs': {'testvg': [{'pp_size': '4 megabyte(s)',
                                          'free_pps': '838',
                                          'total_pps': '999',
                                          'pv_name': 'hdisk105',
                                          'pv_state': 'active'},
                                         {'pp_size': '4 megabyte(s)',
                                          'free_pps': '599',
                                          'total_pps': '999',
                                          'pv_name': 'hdisk106',
                                          'pv_state': 'active'}]}}

    test_hw = AIXHardware()
    vgs_facts = test_hw.get_vgs_facts()
    assert vgs_facts == vgs_facts

# Generated at 2022-06-20 17:08:09.406600
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts.utils import get_file_content

    mock_module = FactsCollector()
    mock_module.run_command = lambda *args: (0, get_file_content('tests/unit/output/aix_lsps_s', True), '')
    mock_module.get_bin_path = lambda *args: "fake cmd"

    aix_hardware = AIXHardware(mock_module)

    memory_facts = aix_hardware.get_memory_facts()
    assert memory_facts['swaptotal_mb'] == 1836
    assert memory_facts['swapfree_mb'] == 1836
    assert memory

# Generated at 2022-06-20 17:08:20.187148
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = FakeModule()
    aixhw = AIXHardware(module=module)

    # Test on empty list of devices
    lsdev_out = ''
    lsattr_out = ''
    module.run_command.return_value = (0, lsdev_out, '')
    module.get_bin_path.return_value = '/usr/bin/lsdev'
    device_facts = aixhw.get_device_facts()
    assert device_facts == {}

    # Test for normal case when there is one device with no attributes
    lsdev_out = 'fcs0 Available  Fibre Channel I/O adapter (FC8G-SW-E)'
    lsattr_out = ''
    module.run_command.return_value = (0, lsdev_out, '')
    module.get_bin_path.return_

# Generated at 2022-06-20 17:08:31.213623
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(arg_spec=dict(gather_subset=dict(default=["all"], type='list')))
    if not module.get_bin_path('lsdev'):
        module.exit_json(ansible_facts={}, skipped=True)
    if not module.get_bin_path('lsvg'):
        module.exit_json(ansible_facts={}, skipped=True)
    ah = AIXHardware()
    facts = ah.populate()
    # The only facts are AIX/Darwin specific, and can't be tested
    assert facts == {}



# Generated at 2022-06-20 17:08:41.752354
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    m = module_mock()

    m.run_command = run_command_mock()
    m.run_command.commands = {('/usr/sbin/lsattr -El sys0 -a fwversion',): (0, "fwversion IBM,G88000TL", ""),
                              ('/bin/lsconf',): (0, "Machine Serial Number:  serial_num\nLPAR Info: lpar_info\nSystem Model:  model_num", "")}

    m.get_bin_path = get_bin_path_mock()
    m.get_bin_path.paths = {'lsconf': '/bin/lsconf'}

    facts_collector = AIXHardwareCollector()
    facts_collector.module = m
    facts = facts_collector.collect()


# Generated at 2022-06-20 17:08:53.154193
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={})
    facts = AIXHardware(module).populate()

    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'memfree_mb' in facts
    assert 'memtotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'firmware_version' in facts
    assert 'product_serial' in facts
    assert 'lpar_info' in facts
    assert 'product_name' in facts
    assert 'vgs' in facts
    assert 'mounts' in facts
    assert 'devices' in facts


# Generated at 2022-06-20 17:09:04.797877
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():

    cpu_facts = AIXHardware.get_cpu_facts()
    assert isinstance(cpu_facts, dict), "cpu_facts should be a dict"
    assert 'processor_count' in cpu_facts, "cpu_facts should contain 'processor_count'"
    assert isinstance(cpu_facts['processor_count'], int), "cpu_facts['processor_count'] should be an int"
    assert 'processor' in cpu_facts, "cpu_facts should contain 'processor'"
    assert isinstance(cpu_facts['processor'], str), "cpu_facts['processor'] should be a string"
    assert 'processor_cores' in cpu_facts, "cpu_facts should contain 'processor_cores'"
    assert isinstance(cpu_facts['processor_cores'], int), "cpu_facts['processor_cores'] should be an int"



# Generated at 2022-06-20 17:09:11.933538
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )
    if not AIXHardware._module:
        AIXHardware._module = module
    cpu_facts = AIXHardware.get_cpu_facts()
    lsdev_path = AIXHardware.get_bin_path("lsdev")
    lsattr_path = AIXHardware.get_bin_path("lsattr")
    if lsdev_path and lsattr_path:
        rc, out, err = module.run_command("/usr/sbin/lsdev -Cc processor")
        if out:
            i = 0
            for line in out.splitlines():
                if 'Available' in line:
                    if i == 0:
                        data = line.split(' ')
                        cpudev = data[0]
                    i += 1
            processor_count

# Generated at 2022-06-20 17:09:17.070309
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    if not module.get_bin_path('lsdev'):
        module.fail_json(msg="'lsdev' not found in $PATH")
    if not module.get_bin_path('lsattr'):
        module.fail_json(msg="'lsattr' not found in $PATH")

    device_facts = AIXHardware(module).get_device_facts()
    assert device_facts['devices']



# Generated at 2022-06-20 17:09:48.519431
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['all'], type='list')
        ),
        supports_check_mode=True
    )

    if not HAS_AIX_MODULES:
        module.fail_json(msg='aix modules required for this module')

    hardware = AIXHardware('testmodule', module)

    # Get facts from AIXHardware
    facts = hardware.get_device_facts()

    assert 'devices' in facts
    assert 'fcs0' in facts['devices']
    assert 'state' in facts['devices']['fcs0']
    assert 'attributes' in facts['devices']['fcs0']
    assert 'type' in facts['devices']['fcs0']

# Generated at 2022-06-20 17:09:54.484808
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    o = AIXHardwareCollector()
    assert o is not None
    assert o._platform == 'AIX'
    assert o._fact_class == AIXHardware


# Generated at 2022-06-20 17:10:00.160391
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    try:
        Aixhw = AIXHardware()
        mem_facts = Aixhw.get_memory_facts()
        assert type(mem_facts['memtotal_mb']) == int
        assert type(mem_facts['memfree_mb']) == int
        assert type(mem_facts['swaptotal_mb']) == int
        assert type(mem_facts['swapfree_mb']) == int
    except AssertionError:
        return False
    return True

# Generated at 2022-06-20 17:10:03.239577
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    """
    Test AIXHardware class
    """
    hardware_obj = AIXHardware()
    assert hardware_obj

# Generated at 2022-06-20 17:10:05.354184
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    hardware = AIXHardware()
    hardware


# Generated at 2022-06-20 17:10:14.097542
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    hardware_facts = AIXHardware(module)
    hardware_facts.populate()

    assert hardware_facts.facts['devices']
    assert hardware_facts.facts['devices']['ent0']['state'] == 'Available'
    assert hardware_facts.facts['devices']['ent0']['type'] == 'Ethernet IEEE 802.3'
    assert hardware_facts.facts['devices']['ent0']['attributes']
    assert hardware_facts.facts['devices']['ent0']['attributes']['adapter_type'] == 'ent'
    assert hardware_facts.facts['devices']['ent0']['attributes']['current_address'] == 'default'
   

# Generated at 2022-06-20 17:10:17.134368
# Unit test for method get_memory_facts of class AIXHardware

# Generated at 2022-06-20 17:10:25.151703
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():

    # given
    test = AIXHardware()

    test.module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )
    test.module.run_command = MagicMock(return_value=(0, '', ''))
    test.module.get_bin_path = MagicMock(return_value=True)


# Generated at 2022-06-20 17:10:26.428289
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hwcollector = AIXHardwareCollector()
    assert hwcollector is not None


# Generated at 2022-06-20 17:10:30.360695
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec=dict())

    # create an object of AIXHardware
    hardware_obj = AIXHardware(module)
    hardware_obj.populate()

    module.exit_json(changed=False)



# Generated at 2022-06-20 17:11:09.690078
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    aix_hw = AIXHardware(dict())
    assert aix_hw._platform == 'AIX'

# Generated at 2022-06-20 17:11:18.952556
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    """
    Constructor of AIXHardwareCollector class sets up module.
    """
    import os
    import sys
    import unittest
    import platform
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()
    module = AnsibleModule(argument_spec={})

    stdout = StringIO()
    sys.stdout = stdout

    test_platform = 'AIX'
    # Test when platform is aix
    if platform.system() != test_platform:
        # Stub out os.uname with one that returns the test platform
        def uname():
            return (test_platform, ) + os.uname()[1:]

# Generated at 2022-06-20 17:11:31.318016
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():

    # TODO: Needing to specify this in a test is undesirable.
    from ansible.module_utils.facts.collector import BaseFactCollector
    BaseFactCollector._module = None

    aix_hardware = AIXHardware()
    res = aix_hardware.get_mount_facts()
    assert res['mounts'][0]['mount'] == '/'
    assert res['mounts'][0]['device'] == '/dev/hd4'
    assert res['mounts'][0]['fstype'] == 'jfs2'
    assert res['mounts'][0]['options'].split(',')[0] == 'rw'
    assert res['mounts'][0]['time'] == 'Thu Jan 1 00:00:00 1970'

# Generated at 2022-06-20 17:11:33.949467
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware_object = AIXHardware()
    assert hardware_object.platform == 'AIX'

# Generated at 2022-06-20 17:11:42.782917
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    collected_facts = hardware.populate()

    # check if it has right number of facts
    assert len(collected_facts) == 11

    # check if it has the right cpu facts
    assert hardware.cpu == collected_facts['processor']
    assert hardware.cpu_cores == collected_facts['processor_cores']
    assert hardware.cpu_count == collected_facts['processor_count']

    # check if it has the right memory facts
    assert hardware.memtotal == collected_facts['memtotal_mb']
    assert hardware.memfree == collected_facts['memfree_mb']
    assert hardware.swaptotal == collected_facts['swaptotal_mb']
    assert hardware.swapfree == collected_facts['swapfree_mb']

# Generated at 2022-06-20 17:11:53.485175
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    # Input line
    line1 = '/dev/hd4 / jfs2 rw,log=/dev/hd8 0 0\n'
    line2 = 'node1:/data /mnt/data nfs rw,bg,hard,intr,tcp,vers=3,sec=sys,mountprog=100003,mountvers=3,addr=10.0.0.11,mountport=32768,noac,nodev,nosuid 0 0\n'
    line3 = '//192.168.0.1/data /mnt/data cifs rw,bg,hard,intr,vers=1.0,sec=none,cache=strict,username=root,password=password 0 0\n'

# Generated at 2022-06-20 17:12:01.382213
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    """
    Unit test to validate facts returned based on input
    """

    device_facts = {}

    # Testcase - 1
    # testcase to verify device facts with
    # following lsdev input
    # fcs0 Available  09-08 Fibre Channel I/O Controller
    # fcs1 Available  09-08 Fibre Channel I/O Controller
    # fscsi0 Defined  09-08 Fibre Channel SCSI I/O Controller
    # fscsi1 Defined  09-08 Fibre Channel SCSI I/O Controller
    # fscsi2 Defined  09-08 Fibre Channel SCSI I/O Controller
    # fscsi3 Defined  09-08 Fibre Channel SCSI I/O Controller
    # fscsi4 Defined  09-08 Fibre Channel SCSI I/O Controller
    # fscsi

# Generated at 2022-06-20 17:12:05.217674
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    """
    Test the AIXHardwareCollector class
    """
    x = AIXHardwareCollector()
    assert x.platform == 'AIX'

# Generated at 2022-06-20 17:12:13.137058
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.utils.path import unfrackpath
    from ansible.module_utils._text import to_bytes

    class FakeModule(object):
        # AnsibleModule function
        def get_bin_path(self, arg, opt_dirs=[]):
            if arg == 'lsdev':
                return unfrackpath('/usr/bin/lsdev')
            elif arg == 'lsattr':
                return unfrackpath('/usr/bin/lsattr')
            else:
                return ''


# Generated at 2022-06-20 17:12:24.977547
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    aix_hardware_obj = AIXHardware()

    # [{'device_name': 'fcs0',
    #   'device_state': 'Available',
    #   'device_type': 'Fibre Channel Adapter',
    #   'device_attrs': {'bus_io_addr': '0xffffffff', 'bus_mem_addr': '0xffffffff', 'bus_dma_range': '0xffffffff',
    #                    'bus_intr_lvl': '3', 'bus_io_range': '0xffffffff', 'bus_mem_range': '0xffffffff',
    #                    'driver_name': 'fcs', 'bus_type': 'pciex'}}]
    expected_get

# Generated at 2022-06-20 17:13:16.188342
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    # Create AIXHardware object
    hardware = AIXHardware()

    # Create the lsdev command output
    lsdev_cmd_output = "\n".join((
        "proc0 Available 00-00 Processor",
        "proc1 Available 00-01 Processor",
        "proc2 Available 00-02 Processor",
        "proc3 Available 00-03 Processor",
        "proc4 Available 00-04 Processor",
        "proc5 Available 00-05 Processor",
        "proc6 Available 00-06 Processor",
        "proc7 Available 00-07 Processor"))

    # Mock module.run_command with lsdev command
    hardware.module.run_command = mock.Mock(return_value=(0, lsdev_cmd_output, ""))

    # Create the lsattr command output

# Generated at 2022-06-20 17:13:27.687033
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    test_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    test_module.run_command = Mock(side_effect=test_module_run_command)

    test_hardware = AIXHardware(test_module)
    test_hardware.populate()
    facts = test_hardware.facts

    assert facts['firmware_version'] == '1.0'
    assert facts['lpar_info'] == '1'
    assert facts['memfree_mb'] == 123
    assert facts['memtotal_mb'] == 2048

# Generated at 2022-06-20 17:13:34.883281
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(
        argument_spec={})
    set_module_args(
        dict(
        )
    )

    hardware = AIXHardware(module=module)
    hardware._lsdev_path = "/usr/bin/lsdev"
    hardware._lsattr_path = "/usr/sbin/lsattr"
    hardware.get_device_facts()

# Generated at 2022-06-20 17:13:47.701339
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts.utils import get_file_content

    mock_module = MockModule()
    mock_module.run_command.side_effect = [
        (0, get_file_content('files/lsattr.txt'), None),
        (0, get_file_content('files/lsconf.txt'), None),
    ]
    MockModule.run_command = mock_module.run_command

    aixHardware = AIXHardware(mock_module)
    gather_subset = ['!all', 'hardware']
    filter_subset = ['all', '']

    dmi_facts = aixHardware.get_dmi_facts()

# Generated at 2022-06-20 17:14:00.416485
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware_obj = AIXHardware(module)

    hardware_obj.module.run_command = MagicMock(return_value=(None, "memory pages:    5120   free pages:     547", None))
    module.run_command = MagicMock(return_value=(None, "", None))
    hardware_obj.get_memory_facts()
    assert hardware_obj.facts['memtotal_mb'] == 20
    assert hardware_obj.facts['memfree_mb'] == 2
    assert hardware_obj.facts['swapfree_mb'] == 0
    assert hardware_obj.facts['swaptotal_mb'] == 0

    # Memory stats

# Generated at 2022-06-20 17:14:03.387230
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    aix_hardware_obj = AIXHardware(module)
    assert aix_hardware_obj.module == module
    assert aix_hardware_obj.platform == 'AIX'


# Generated at 2022-06-20 17:14:06.775162
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    aix_hardware = AIXHardware()
    aix_hardware.populate()

# Generated at 2022-06-20 17:14:10.021914
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():

    obj = AIXHardwareCollector()
    assert obj._platform == 'AIX'
    assert obj._fact_class == AIXHardware

# Generated at 2022-06-20 17:14:17.652594
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    import datetime

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    now = datetime.datetime.now()


# Generated at 2022-06-20 17:14:21.388288
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec={
        },
        supports_check_mode = True
    )
    result = AIXHardware(module).get_cpu_facts()

    assert isinstance(result, dict)


# Generated at 2022-06-20 17:15:49.047746
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts.hardware.aix import AIXHardwareCollector

    assert AIXHardwareCollector.collect(verbose=False)
    assert AIXHardware.populate()

# Generated at 2022-06-20 17:15:56.233312
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    """
    Test to get vg and pv Facts
    :return: List of vg and pv Facts
    """
    facts_obj = AIXHardware()

# Generated at 2022-06-20 17:16:01.956197
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={})
    ob = AIXHardware(module)
    module.exit_json(changed=False, ansible_facts=dict(hardware=ob.populate()))



# Generated at 2022-06-20 17:16:03.728800
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec=dict())

    hardware = AIXHardware(module)

    assert hardware.platform == 'AIX'

# Generated at 2022-06-20 17:16:14.858727
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    # Create testfacts dictionary
    testfacts = {'ANSIBLE_SYSTEM_VERSION': '7',
                 'processor': 'PowerPC_POWER8'}

    # Create test Hardware class
    test_hardware = AIXHardware(module=None, facts=testfacts)

    # get_cpu_facts() should return expected dictionary
    assert test_hardware.get_cpu_facts() == {'processor': 'PowerPC_POWER8',
                                             'processor_count': 2,
                                             'processor_cores': 2}



# Generated at 2022-06-20 17:16:21.130476
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    aix_hardware = AIXHardware()
    mount_facts = aix_hardware.get_mount_facts()
    print(mount_facts)
    assert True

# Generated at 2022-06-20 17:16:29.447925
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    populate_result = AIXHardware(module).populate()
    assert type(populate_result['memory']['memfree_mb']) is int
    assert type(populate_result['memory']['memtotal_mb']) is int
    assert type(populate_result['memory']['swapfree_mb']) is int
    assert type(populate_result['memory']['swaptotal_mb']) is int
    assert type(populate_result['cpu']['processor']) is str
    assert type(populate_result['cpu']['processor_cores']) is int
    assert type(populate_result['cpu']['processor_count']) is int

# Generated at 2022-06-20 17:16:36.907794
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    import module_utils.facts.hardware.aix as aix
    module = AnsibleModule(argument_spec={})
    module.run_command = Mock(return_value=(0, "IBM,7D542", ""))
    aix_hardware = aix.AIXHardware(module)
    result = aix_hardware.get_dmi_facts()
    assert result['firmware_version'] == '7D542'



# Generated at 2022-06-20 17:16:49.159956
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModuleMock()
    module.run_command = run_command

    # Create an object of class AIXHardware
    aix = AIXHardware(module)

    # test case where output of mount command is empty
    result = {
              "mounts": []
             }
    assert aix.get_mount_facts() == result

    # test case where mount command has output
    class MockModule(object):
        def __init__(self):
            self.params = {'module_name': 'AIXHardware',
                           'module_args': [],
                           '_ansible_version': '2.10.3'
                          }
            self.check_mode = False
            self.exit_json = exit_json
            self.run_command = run_command
            self.fail_json = fail_

# Generated at 2022-06-20 17:17:00.073613
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    ah = AIXHardware({'module_setup': True})
    ah.module.run_command = mock_run_command
    ah.module.get_bin_path = mock_get_bin_path
    res = ah.populate()