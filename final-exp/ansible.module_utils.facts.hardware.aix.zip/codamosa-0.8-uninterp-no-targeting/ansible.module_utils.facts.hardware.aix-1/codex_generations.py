

# Generated at 2022-06-20 17:07:34.000135
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    ah = AIXHardware({})
    assert ah.populate()

# Generated at 2022-06-20 17:07:43.404984
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    from ansible.module_utils._text import to_bytes
    module = AnsibleModule(argument_spec=dict())
    module.mock_command("/usr/bin/vmstat -v", output="""
    memory pages 0000000000
    free_memory pages 0000000000
    """)
    module.mock_command("/usr/sbin/lsps -s", output="""
    Total Paging Space Percent Used: 0%
    """)
    hardware = AIXHardware(module)
    # memtotal_mb
    assert hardware.memtotal_mb == 0
    # memfree_mb
    assert hardware.memfree_mb == 0
    # swaptotal_mb
    assert hardware.swaptotal_mb == 0
    # swapfree_mb
    assert hardware.swapfree_mb == 0


# Generated at 2022-06-20 17:07:54.765628
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    aix_hw = AIXHardware(dict(module=dict(run_command=run_command)))
    assert aix_hw.get_dmi_facts() == {'firmware_version': 'IBM,1.0',
                                      'product_serial': '0123ABCD',
                                      'lpar_info': 'lpar1',
                                      'product_name': 'IBM,8286-42A'}

    # Get dmi_facts with a lot of unexpected output from lsconf command

# Generated at 2022-06-20 17:08:00.400312
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    hw = AIXHardware({'module': module})

    result = hw.get_mount_facts()

    assert result.get('mounts') is not None



# Generated at 2022-06-20 17:08:11.138114
# Unit test for method get_memory_facts of class AIXHardware

# Generated at 2022-06-20 17:08:15.881081
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = DummyModule()
    aix = AIXHardware(module)
    aix.get_device_facts()
    assert module.run_command.called


### Unit test helper classes and functions ###

import unittest
import sys


# Generated at 2022-06-20 17:08:17.477274
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    assert AIXHardwareCollector._platform == 'AIX'
    assert AIXHardwareCollector._fact_class == AIXHardware

# Generated at 2022-06-20 17:08:31.755258
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = Mock()

    vgs_facts_sample = {'vgs': {'testvg': [{'pv_name': 'hdisk1',
                                            'pv_state': 'active',
                                            'total_pps': '999',
                                            'free_pps': '838',
                                            'pp_size': '4 megabyte'
                                            },
                                           {'pv_name': 'hdisk2',
                                            'pv_state': 'active',
                                            'total_pps': '999',
                                            'free_pps': '599',
                                            'pp_size': '4 megabyte'
                                            }]}}

    hardware = AIXHardware(module)

# Generated at 2022-06-20 17:08:34.499701
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hc = AIXHardwareCollector()
    assert hc._fact_class.platform == 'AIX'

# Generated at 2022-06-20 17:08:36.003188
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    collector = AIXHardwareCollector()
    assert collector.fact_class == AIXHardware

# Generated at 2022-06-20 17:08:59.619827
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule({'ansible_facts': {}})

    # gather lspv output
    rc = 0
    out = '''name status state
proc0 Available 01-00
proc2 Available 01-00
proc4 Available 01-00
'''
    err = ''

    # mock run_command to return our canned response
    module.run_command = Mock(return_value=(rc, out, err))

    # create a AIXHardware instance
    hw = AIXHardware(module)

    # call get_cpu_facts with the mocked out run_command
    cpu_facts = hw.get_cpu_facts()

    # make sure we received the expected result
    assert 'processor_count' in cpu_facts
    assert 'processor' in cpu_facts
    assert 'processor_cores' in cpu_facts
    assert cpu

# Generated at 2022-06-20 17:09:07.623829
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = ansible_module_mock()
    aix_hardware = AIXHardware(module)

    assert aix_hardware.platform == 'AIX'

    cpu_facts = aix_hardware.get_cpu_facts()

    assert 'processor' in cpu_facts
    assert 'processor_count' in cpu_facts

    memory_facts = aix_hardware.get_memory_facts()

    assert 'memtotal_mb' in memory_facts
    assert 'memfree_mb' in memory_facts

    dmi_facts = aix_hardware.get_dmi_facts()

    assert 'firmware_version' in dmi_facts
    assert 'product_serial' in dmi_facts
    assert 'lpar_info' in dmi_facts
    assert 'product_name' in dmi_facts

# Generated at 2022-06-20 17:09:13.807274
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    """
    Unit test for method populate of class AIXHardware
    """

    # Create a AIXHardware instance
    hardware = AIXHardware()

    # Create expected output
    expected_hardware_facts = {'memtotal_mb': 8192,
                               'memfree_mb': 8192,
                               'swaptotal_mb': 10240,
                               'swapfree_mb': 10240,
                               'processor': 'powerpc',
                               'processor_cores': 1,
                               'processor_count': 2}

    # Populate
    hardware.populate()

    # Assert populated values are expected
    for key in expected_hardware_facts:
        assert key in hardware.facts, "Key {0} is missing from facts".format(key)
        assert hardware.facts[key] == expected_hardware_

# Generated at 2022-06-20 17:09:20.692720
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    from ansible.module_utils.facts import ModuleArgsParser

    module = AnsibleModule(
        argument_spec={
            'filter': {'required': False, 'type': 'list'},
            'gather_subset': {'required': False, 'type': 'list'}
        }
    )

    # prepare args
    args = ModuleArgsParser.get_module_args(module.params)

    # test
    hardware = AIXHardware(module=module)
    result = hardware.get_mount_facts()
    module.exit_json(ansible_facts=result)



# Generated at 2022-06-20 17:09:28.925158
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    aix_hardware = AIXHardware(module)

# Generated at 2022-06-20 17:09:38.391865
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    mount_facts = {}
    AIXHardware = AIXHardware()


# Generated at 2022-06-20 17:09:49.266875
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    class DummyModule:
        def __init__(self):
            self.run_command_count = 0
            self.run_command_args = []

        def get_bin_path(self, executable,
                         required=False, opt_dirs=[]):
            return '/usr/sbin/' + executable

        def run_command(self, arguments, check_rc=True, close_fds=True,
                        executable=None, data=None, binary_data=False,
                        path_prefix=None, cwd=None, use_unsafe_shell=False,
                        prompt_regex=None):
            returncode = 0
            out = ''
            err = ''
            if self.run_command_count == 0:
                out = 'firmware_version: IBM,7998-22C'

# Generated at 2022-06-20 17:10:01.079587
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    """
    Unit test for method get_vgs_facts of class AIXHardware
    """
    test_module = AnsibleModule(argument_spec={})
    test_module.run_command = MagicMock(return_value=(0, "", ""))
    test_module.get_bin_path = MagicMock(return_value='/usr/sbin/lsvg')

# Generated at 2022-06-20 17:10:09.925767
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    def mock_run_command(self, cmd, use_unsafe_shell=False):
        if "lsvg" in cmd:
            return rc, out, err

    module = type('MockModule', (object,), {})
    module.run_command = mock_run_command

    lsvg_path = '/usr/sbin/lsvg'
    xargs_path = '/usr/bin/xargs'

# Generated at 2022-06-20 17:10:22.575603
# Unit test for method get_memory_facts of class AIXHardware

# Generated at 2022-06-20 17:11:07.456216
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec=dict())
    AIXHardware.populate(module)

    # test if device facts are retrieved correctly
    assert(module.exit_json.called)

# Generated at 2022-06-20 17:11:17.258198
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={'filter': dict(default='', required=False)})
    print("testing AIXHardware.populate")
    ah = AIXHardware(module)
    facts = ah.populate()
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'firmware_version' in facts
    assert 'product_serial' in facts
    assert 'product_name' in facts
    assert 'lpar_info' in facts
#    assert 'devices' in facts
#    assert 'mounts' in facts
#    assert 'vgs' in facts


# Generated at 2022-06-20 17:11:21.730374
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware = AIXHardware()
    assert hardware.platform == 'AIX'
    assert hardware.collector == AIXHardwareCollector

# Generated at 2022-06-20 17:11:28.137849
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    import pytest, unittest
    class TestAIXHardware(unittest.TestCase):
        meminfo = """
memory pages:    69988              0              0
free pages:      24180
                 memory
memory
memory
                 memory
"""
        swapinfo = """Device          1M-blocks     Used    Avail Capacity
/dev/ada0p3        314368        0   314368     0%
"""

        def test_AIXHardware(self, mocker):
            mocker.patch('ansible.module_utils.facts.hardware.aix.get_mount_size')
            mocker.patch('ansible.module_utils.basic.AnsibleModule.run_command')
            ansible_module = mocker.MagicMock()

# Generated at 2022-06-20 17:11:39.146911
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec=dict(
    ))
    platform_value = AIXHardware.platform

# Generated at 2022-06-20 17:11:52.107668
# Unit test for method get_vgs_facts of class AIXHardware

# Generated at 2022-06-20 17:11:55.110093
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware = AIXHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['processor_count'] >= 1

# Generated at 2022-06-20 17:12:02.871070
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    out_lsattr = """firmware_version 1025_0227
sys0 Available 00-00-00 0918D0F4"""

    out_lsconf = """System Model: IBM,7038-6M2
Machine Serial Number: 05BA9B1
LPAR Info: 1 HA8
System Type: Standalone
Part Number: 00K3266
EC Level: A99
Serial Number: A99
Machine Type: 7038-6M2"""

    test_module = AnsibleModule(argument_spec=dict())
    test_module.run_command = MagicMock(return_value=(0, out_lsattr, ""))
    test_module.get_bin_path = MagicMock(return_value="/usr/sbin/lsattr")
    test_hw = AIXHardware(module=test_module)
    test_module

# Generated at 2022-06-20 17:12:13.322120
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    """
    Unit test for method get_mount_facts of class AIXHardware
    """
    m = AIXHardware(dict())
    # Format of each element of mounts_out is:
    # mount_point device fstype options rest_of_fields
    # rest_of_fields are not important for this test

# Generated at 2022-06-20 17:12:19.949878
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    mod_args = dict(
        gather_subset=[ 'all' ],
        filter=['*']
    )
    obj = AIXHardwareCollector(module=dict(), **mod_args)
    assert obj._platform == 'AIX'
    assert obj._fact_class == AIXHardware


# Generated at 2022-06-20 17:13:36.244261
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={
                           'gather_subset': dict(default=['!all'], type='list'),
                           'filter': dict(required=False, type='str'),
                           })

    if not HAS_AIX:
        module.fail_json(msg='AIX specific modules (pyAIX) are not installed')

    if platform.system() != 'AIX':
        module.fail_json(msg='Current system is not AIX')

    hardware = AIXHardware(module)
    facts = hardware.populate()

    if len(facts) == 0:
        module.fail_json(msg='Facts could not be gathered')
    module.exit_json(ansible_facts=facts)



# Generated at 2022-06-20 17:13:37.931624
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    m = AIXHardware()
    assert m.get_device_facts()['devices'] == {}

# Generated at 2022-06-20 17:13:47.010845
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    """This is a test method for the class AIXHardware"""

    # initialize an object
    hardware_obj = AIXHardware(None)
    hardware_obj.module = type('obj', (object,), {"run_command": run_command_mock})

    facts = hardware_obj.get_memory_facts()

    assert facts.get('memtotal_mb') == 37715
    assert facts.get('memfree_mb') == 2214
    assert facts.get('swapfree_mb') == 1022
    assert facts.get('swaptotal_mb') == 12288



# Generated at 2022-06-20 17:13:56.071379
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    """
    Test method get_cpu_facts of class AIXHardware
    """
    m = AIXHardware()
    tests = [
        {
            'input': 'proc0          Available 00-00 Processor\n'
                     'proc1          Available 00-01 Processor\n'
                     'proc2          Available 00-02 Processor\n'
                     'proc3          Available 00-03 Processor\n',
            'output': {'processor': 'PowerPC_POWER8', 'processor_count': 4, 'processor_cores': 8}
        }
    ]
    for test in tests:
        m.module.run_command = lambda x, **kwargs: (0, test['input'], '')
        result = m.get_cpu_facts()
        assert result == test['output']



# Generated at 2022-06-20 17:13:59.872800
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    # Test instantiation of class AIXHardwareCollector
    q = AIXHardwareCollector()
    assert isinstance(q, HardwareCollector)



# Generated at 2022-06-20 17:14:09.318500
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    """
     AIXHardware.get_memory_facts() Test:
     - an empty list is returned if the supplied input is an empty list
     - The truth value of an empty list is false
     - a list containing one pv named vgname is returned if the supplied input contains one pv named vgname
     - The truth value of a list containing one pv named vgname is true
    """
    aix_hw_inst = AIXHardware()

    aix_hw_inst.module = Mock()

    result = aix_hw_inst.get_memory_facts()
    assert(result['memtotal_mb'] >= 0)
    assert(result['memfree_mb'] >= 0)
    assert(result['swaptotal_mb'] >= 0)
    assert(result['swapfree_mb'] >= 0)


# Unit test

# Generated at 2022-06-20 17:14:14.777348
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    aixhw_collector = AIXHardware(module)
    result = aixhw_collector.get_dmi_facts()
    assert any(k in result for k in ['firmware_version', 'product_serial', 'lpar_info', 'product_name'])

# Generated at 2022-06-20 17:14:28.293844
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    test_module = 'ansible.module_utils.facts.hardware.aix'
    test_class = 'AIXHardware'
    test_method = 'get_cpu_facts'

    test_cpu_facts = {
        'processor': [],
        'processor_count': 0,
        'processor_cores': 0,
    }


# Generated at 2022-06-20 17:14:37.506594
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    mod = get_module_mock({})
    cln = AIXHardware(module=mod)

    mod.run_command.return_value = (0, 'proc0 Available 00-00-3000', '')
    mod.run_command.return_value = (0, 'type PowerPC_POWER7', '')
    mod.run_command.return_value = (0, 'smt_threads 8', '')

    result = cln.get_cpu_facts()

    assert result['processor_count'] == 1
    assert result['processor'] == 'PowerPC_POWER7'
    assert result['processor_cores'] == 8


# Generated at 2022-06-20 17:14:50.598541
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    import platform
    import re
    import ansible.module_utils.facts.hardware.aix as aix

    class FakeModule:
        def get_bin_path(self, name, required=False):
            imports = {'lsconf': '/usr/sbin/lsconf',
                       'lsattr': '/usr/sbin/lsattr',
                       'lsvg': '/usr/sbin/lsvg'}
            return imports[name]

        def run_command(self, cmd, use_unsafe_shell=False):
            return 0, '', ''

    class FakeFacts:
        def __init__(self):
            self.collector = AIXHardwareCollector(None, None)

    # output from lsconf command