

# Generated at 2022-06-20 17:07:47.927936
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    test_fact_data = {
        'devices': {
            'test1': {
                'state': 'Available',
                'type': 'test1',
                'attributes': {
                    'test1_attr': 'test1_parameter'
                }
            },
            'test2': {
                'state': 'Available',
                'type': 'test2',
                'attributes': {
                    'test2_attr': 'test2_parameter'
                }
            }
        }
    }

    module = MockModule()
    hardware = AIXHardware(module=module)

    module.run_command.return_value = (0, 'test1 Available test1\ntest2 Available test2', '')
    hardware.get_device_facts()
    module.run_command.assert_called_once_with

# Generated at 2022-06-20 17:07:58.440192
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # mock 'lsdev -Cc processor' and 'lsattr -El sys0 -a fwversion' command output
    lsdev_path = module.get_bin_path('lsdev')
    module.run_command = MagicMock(return_value=(0, 'proc0 Available 00-00  Processor\nproc1 Available 00-01  Processor\nproc2 Available 00-02  Processor\nproc3 Available 00-03  Processor', ''))
    module.get_bin_path = MagicMock(return_value=lsdev_path)

    lsattr_path = module.get_bin_path('lsattr')
    module.get_bin_path = MagicMock(return_value=lsattr_path)
   

# Generated at 2022-06-20 17:08:01.227542
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    result = hardware.get_memory_facts()
    assert result['memfree_mb'] > 0
    assert result['memtotal_mb'] > 0


# Generated at 2022-06-20 17:08:08.755611
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    hardware_instance = AIXHardware()
    result = hardware_instance.populate()
    assert result['firmware_version'] == '1.6.0_04     '
    assert result['lpar_info'] == '1 CEC'
    assert result['product_name'] == 'IBM,8247-22L'
    assert result['product_serial'] == '0009C88'

# Generated at 2022-06-20 17:08:19.884342
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    class Options:
        def __init__(self):
            self.gather_subset = ['all']
            self.gather_timeout = 10
            self.filter = []
            self.verbosity = 0
            self.show_custom_facts = True
            self.collect_default_facts = True

    class Collection:
        def __init__(self):
            self.aggregate = []

    class Module:
        def __init__(self):
            self.params = Options()
            self.facts = Collection()
            self.run_command = run_command_mock

        def get_bin_path(self, command, required=False):
            return "mount"

    hardware = AIXHardware(Module())
    mounts = hardware.get_mount_facts()

    assert 'mounts' in mounts

# Generated at 2022-06-20 17:08:30.682774
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    hardware.populate()
    # There is no easy way to debug this command
    assert "processor" in hardware.facts
    assert "processor_cores" in hardware.facts
    assert "processor_count" in hardware.facts
    assert "memtotal_mb" in hardware.facts
    assert "memfree_mb" in hardware.facts
    assert "swaptotal_mb" in hardware.facts
    assert "swapfree_mb" in hardware.facts


# Generated at 2022-06-20 17:08:40.047447
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    import os

    # Create instance of parameter 'module' and use it as input parameter in
    # instantiation of 'AIXHardware' class
    import ansible.module_utils.facts.hardware.aix
    ansible.module_utils.facts.hardware.aix.__file__
    module = ansible.module_utils.facts.hardware.aix.__dict__

    aix_hw_obj = AIXHardware(module, '/tmp/')

    # Create a method instance to call get_device_facts
    get_device_facts = aix_hw_obj.get_devic

# Generated at 2022-06-20 17:08:48.150357
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    aix_hw_class = AIXHardware()

    expected_result = {'processor': 'PowerPC_POWER8',
                       'processor_cores': 2,
                       'processor_count': 4}
    result = aix_hw_class.get_cpu_facts()
    assert result == expected_result



# Generated at 2022-06-20 17:08:50.940191
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    cls = AIXHardwareCollector()
    assert cls.platform == 'AIX'
    assert cls.fact_class == AIXHardware


# Generated at 2022-06-20 17:08:56.300129
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = FactsCollectorModule()
    module.run_command = mock.Mock()

    AIXHardware.module = module
    m = AIXHardware()
    m.get_vgs_facts()
    assert module.run_command.called



# Generated at 2022-06-20 17:09:23.186464
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    import sys
    import json

    from ansible.module_utils.facts.hardware.aix import AIXHardware

    module = type('AnsibleModule', (object,), {'run_command': noop_run_command})()
    module.get_bin_path = lambda *args, **kwargs: '/usr/bin/' + args[0]


# Generated at 2022-06-20 17:09:32.151325
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule()
    hw_mock = AIXHardware(module)
    memory_facts = hw_mock.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-20 17:09:40.917655
# Unit test for method populate of class AIXHardware

# Generated at 2022-06-20 17:09:50.107365
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = FakeAnsibleModule()
    lsdev_cmd = '/usr/sbin/lsdev -Cc processor'
    rc, out_lsdev, err = module.run_command(lsdev_cmd)
    lsattr_cmd = '/usr/sbin/lsattr -El proc0 -a type'
    rc, out_lsattr, err = module.run_command(lsattr_cmd)
    dmi_facts = {}
    dmi_facts['firmware_version'] = 'IBM,123'
    dmi_facts['product_serial'] = '123'
    dmi_facts['product_name'] = 'test'
    hardware_obj = AIXHardware(module)

    hardware_obj.get_cpu_facts = MagicMock(return_value={"cpu_facts": "cpu_facts"})
   

# Generated at 2022-06-20 17:09:59.059625
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    class FakeModule(object):
        def __init__(self):
            self.params = {
                'gather_subset': [],
            }

        def get_bin_path(self, path, opt_dirs=[]):
            return path
    module = FakeModule()
    hardware = AIXHardware(module=module)
    vgs_facts = hardware.get_vgs_facts()
    assert 'vgs' in vgs_facts
    assert vgs_facts['vgs'] is not None



# Generated at 2022-06-20 17:10:05.488500
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    '''Unit test for method get_dmi_facts of class AIXHardware'''
    module = AnsibleModule(argument_spec = dict())
    ah = AIXHardware()
    ah.module = module
    dmi_facts = ah.get_dmi_facts()
    assert dmi_facts['firmware_version']
    assert dmi_facts['product_name']
    assert dmi_facts['product_serial']
    assert dmi_facts['lpar_info']



# Generated at 2022-06-20 17:10:14.198498
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    myhw = AIXHardware()

    # Validate that the two methods return a different object
    assert myhw.get_cpu_facts() != myhw.get_memory_facts()
    assert myhw.get_cpu_facts() != myhw.get_dmi_facts()
    assert myhw.get_cpu_facts() != myhw.get_mount_facts()
    assert myhw.get_cpu_facts() != myhw.get_device_facts()
    assert myhw.get_cpu_facts() != myhw.populate()

    # Validate that the method 'populate' returns a dictionary
    assert isinstance(myhw.populate(), dict)
    assert isinstance(myhw.get_cpu_facts(), dict)
    assert isinstance(myhw.get_memory_facts(), dict)

# Generated at 2022-06-20 17:10:18.052423
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    module = Mock()
    module.run_command = lambda x: [0, "Available 00-00 Processor\nAvailable 00-01 Processor", '']
    aix_hw = AIXHardware(module)
    output = aix_hw.get_cpu_facts()
    assert output['processor_count'] == 2
    assert output['processor'] == 'Processor'
    assert output['processor_cores'] == 1



# Generated at 2022-06-20 17:10:25.387814
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    aix_hardware = AIXHardware()

    # Exercise for normal mount

# Generated at 2022-06-20 17:10:27.945594
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    facts = dict()

    AIX = AIXHardware(dict(module=dict()), facts)
    AIX.module.run_command = command_mockup

    AIX.populate()
    assert AIX.facts == facts



# Generated at 2022-06-20 17:10:58.965904
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    aix_hw = AIXHardware(module)


# Generated at 2022-06-20 17:11:08.369684
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    fc = AIXHardwareCollector()

# Generated at 2022-06-20 17:11:17.749800
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = FakeAnsibleModule()
    hardware_obj = AIXHardwareCollector(module=module).collect()[0]
    assert module.run_command.call_count == 2

# Generated at 2022-06-20 17:11:30.815747
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    from ansible.module_utils.facts.collector import get_file_content
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils._text import to_bytes

    lsdev_cmd = get_file_content('../../../module_utils/facts/hardware/aix/tests/fixtures/lsdev_out_1.txt')
    lsattr_cmd = get_file_content('../../../module_utils/facts/hardware/aix/tests/fixtures/lsattr_out_1.txt')

    aix_hardware = AIXHardware({})

# Generated at 2022-06-20 17:11:37.633923
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    assert 'memtotal_mb' in hardware.get_memory_facts()
    assert 'memfree_mb' in hardware.get_memory_facts()
    assert 'swaptotal_mb' in hardware.get_memory_facts()
    assert 'swapfree_mb' in hardware.get_memory_facts()



# Generated at 2022-06-20 17:11:51.548368
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    # Setup AIXHardware object
    mod = AnsibleModule({}, stub=True)
    AIXHW = AIXHardware(mod)

    # Prepare to mocks
    class B_Path(object):
        @staticmethod
        def which(fname, required=False):
            return True

    class CMD_output(object):
        def __init__(self, out, rc=0, err=''):
            self.out = out
            self.rc = rc
            self.err = err

        def __call__(self, cmd, use_unsafe_shell):
            out = self.out

            return (self.rc, out, self.err)

    # Prepare test data

# Generated at 2022-06-20 17:12:01.595387
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    AIXHardware.module = module

    test_facts = {}
    test_facts['vgs'] = {}

    test_facts['vgs']['rootvg'] = [{'pp_size': '4 Megabyte(s)',
                                    'pv_state': 'active',
                                    'pv_name': 'hdisk0',
                                    'total_pps': '546',
                                    'free_pps': '0'},
                                   {'pp_size': '4 Megabyte(s)',
                                    'pv_state': 'active',
                                    'pv_name': 'hdisk1',
                                    'total_pps': '546',
                                    'free_pps': '113'}]

# Generated at 2022-06-20 17:12:09.285840
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    """
    Unit test for method get_memory_facts of class AIXHardware
    """
    aixhardware = AIXHardware(None)
    assert aixhardware.get_memory_facts() == {'memtotal_mb': 4782, 'swapfree_mb': 519, 'swaptotal_mb': 3071, 'memfree_mb': 1419}



# Generated at 2022-06-20 17:12:23.654068
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware

# Generated at 2022-06-20 17:12:34.837674
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    class MockModule(object):
        def __init__(self, bin_path=None):
            self.params = {}
            self.bin_path = bin_path

        def get_bin_path(self, arg, opt_dirs=[]):
            return self.bin_path

        def run_command(self, args, check_rc=False, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None, environ_update=None, umask=None, encoding=None):
            if args == "/usr/sbin/lsattr -El sys0 -a fwversion":
                return 0, "fwversion IBM,8233-E8B", ""

# Generated at 2022-06-20 17:13:07.674389
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    collector = AIXHardwareCollector()
    assert collector._platform == 'AIX'
    assert collector._fact_class == AIXHardware

# Generated at 2022-06-20 17:13:13.067498
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    from ansible.module_utils.facts.hardware.sparc.aix import AIXHardware
    result = AIXHardware().get_dmi_facts()
    # to confirm that the classes of results are correct
    assert isinstance(result['firmware_version'], str)
    assert isinstance(result['product_serial'], str)
    assert isinstance(result['lpar_info'], str)
    assert isinstance(result['product_name'], str)

# Generated at 2022-06-20 17:13:21.306833
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = DummyModule()
    hardware = AIXHardware(module)
    hardware.module.run_command = MagicMock()
    hardware.module.run_command.return_value = 0, OUTPUT, ''

    vgs_facts = hardware.get_vgs_facts()

    assert vgs_facts == EXPECTED_VGS_FACTS


# Generated at 2022-06-20 17:13:35.156383
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    swapinfo_output = """
rootvg:
PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
hdisk0            active            546         0           00..00..00..00..00
hdisk1            active            546         113         00..00..00..21..92
realsyncvg:
PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
hdisk74           active            1999        6           00..00..00..00..06
testvg:
PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
hdisk105          active            999         838         200..39..199..200..200
hdisk106          active            999         599         200..00..00..199..200
"""

# Generated at 2022-06-20 17:13:39.057528
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector.platform == 'AIX'
    assert hardware_collector.fact_class == AIXHardware

# Generated at 2022-06-20 17:13:50.340336
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    import json
    from ansible.module_utils.facts.collector.aix import AIXHardware
    hw = AIXHardware({
        'run_command': lambda *args, **kwargs: (0, None, ''),
        'get_bin_path': lambda *args, **kwargs: None,
    })
    result = hw.get_device_facts()
    devices = result.get('devices')
    assert devices
    assert len(devices.keys()) > 0
    # Test disk device
    disk = devices['hdisk0']
    assert disk.get('state') == 'Available'
    assert disk.get('type') == 'SCSI Disk Drive'
    assert len(disk.get('attributes')) > 0
    assert disk.get('attributes').get('dev_size') == '131072'
   

# Generated at 2022-06-20 17:13:54.173024
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    "Function to test constructor of class AIXHardware"

    myAIXHardware = AIXHardware(dict(), dict())
    if myAIXHardware.platform != 'AIX':
        raise Exception("Invalid platform")
    if 'firmware_version' not in myAIXHardware.facts:
        raise Exception("Missing firmware")

# Generated at 2022-06-20 17:14:01.876102
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )

    ah = AIXHardware(module=module)

    mount_facts = ah.get_mount_facts()

    if mount_facts['mounts']:
        module.exit_json(changed=False, ansible_facts=mount_facts)
    else:
        module.fail_json(msg='Could not collect mount facts')


# Generated at 2022-06-20 17:14:10.176106
# Unit test for method get_memory_facts of class AIXHardware

# Generated at 2022-06-20 17:14:15.847499
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    hardware = AIXHardware(module=module)
    hardware.populate()
    assert hardware.fact == {}
    module.exit_json(changed=False, ansible_facts=hardware.fact)


# Generated at 2022-06-20 17:15:01.141316
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    module = AnsibleModule(argument_spec = dict())
    hardware_collector = AIXHardwareCollector(module)
    assert hardware_collector.platform == 'AIX'
    assert hardware_collector.fact_class.platform == 'AIX'


# Generated at 2022-06-20 17:15:09.176024
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    class FakeModule(object):
        def run_command(self, command, use_unsafe_shell=False):
            out = """memory pages: 695507
free pages: 695507
"""
            return 0, out, ""

    hw = AIXHardware(FakeModule())
    facts = hw.populate()
    assert facts['memtotal_mb'] == 274785
    assert facts['memfree_mb'] == 274785
    assert facts['swaptotal_mb'] == 0
    assert facts['swapfree_mb'] == 0


# Generated at 2022-06-20 17:15:19.009932
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    cpu_facts = []

    with open('tests/unit/module_utils/facts/hardware/AIX/lsdev_Cc_processor_content.txt') as f:
        cpu_facts = AIXHardware.get_cpu_facts(None, f.read())

    assert cpu_facts['processor'] == 'PowerPC_POWER8'
    assert cpu_facts['processor_count'] == 4
    assert cpu_facts['processor_cores'] == 1


# Generated at 2022-06-20 17:15:24.558186
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    """
    Does basic unit test of class.
    """
    facts = AIXHardware(dict())
    assert facts.platform == 'AIX'

# Generated at 2022-06-20 17:15:31.103470
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    aix = AIXHardware()
    dmi_facts = aix.get_dmi_facts()
    assert("firmware_version" in dmi_facts)
    assert("product_serial" in dmi_facts)
    assert("lpar_info" in dmi_facts)
    assert("product_name" in dmi_facts)


# Generated at 2022-06-20 17:15:44.096465
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    mem_facts = {
        'memtotal_mb': 2048,
        'memfree_mb': 1024,
        'swaptotal_mb': 314368,
        'swapfree_mb': 314368
    }
    class Mockmodule:
        def run_command(self, command):
            class mockdata:
                def __init__(self, out):
                    self.out = out

            out = "aix7:/root # /usr/bin/vmstat -v\n" \
                  "memory pages:\n" \
                  "          2097152         \n" \
                  "free pages:\n" \
                  "          1048576         \n" \
                  "aix7:/root # "
            ret = mockdata(out)
            return (0, ret, "")


# Generated at 2022-06-20 17:15:45.306834
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    al = AIXHardwareCollector()
    assert al.hardware
    assert al.platform


# Test AIXHardware class

# Generated at 2022-06-20 17:15:47.949278
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    result = dict(
        changed=False,
        ansible_facts=dict(
            hardware=AIXHardware(module).populate()
        )
    )
    module.exit_json(**result)



# Generated at 2022-06-20 17:15:52.323638
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module=module)
    assert hardware.get_cpu_facts()['processor_count'] == 1
    assert hardware.get_cpu_facts()['processor'] == 'PowerNV'
    assert hardware.get_cpu_facts()['processor_cores'] == 48


# Generated at 2022-06-20 17:15:55.830395
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    assert hardware
    assert hardware.module == module