

# Generated at 2022-06-20 17:07:42.549042
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    gvf = AIXHardware.get_vgs_facts(None)
    assert isinstance(gvf, dict)
    assert gvf == {}
    vgs_facts = {}

# Generated at 2022-06-20 17:07:48.622028
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = AIXHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert type(cpu_facts) is dict
    assert 'processor_count' in cpu_facts
    assert type(cpu_facts['processor_count']) is int
    assert 'processor' in cpu_facts
    assert type(cpu_facts['processor']) is str
    assert 'processor_cores' in cpu_facts
    assert type(cpu_facts['processor_cores']) is int


# Generated at 2022-06-20 17:07:51.659611
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware_obj = AIXHardware(module)
    results = hardware_obj.get_dmi_facts()
    assert results['product_serial'] is not None
    assert results['firmware_version'] is not None
    assert results['product_name'] is not None
    assert results['lpar_info'] is not None


# Generated at 2022-06-20 17:08:01.073240
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    def _run_module(module, module_args):
        module_args = module_args or dict()
        facts_module = AnsibleModule(
            argument_spec=module_args.get('argument_spec', dict()),
            supports_check_mode=module_args.get('supports_check_mode', False)
        )
        facts_module.exit_json = _ansible_exit_json

        return facts_module

    def _ansible_exit_json(self, **kwargs):
        for k in list(kwargs['ansible_facts'].keys()):
            if k.startswith('ansible_'):
                kwargs['ansible_facts'].pop(k)

        f = open('ansible_facts.json', 'w')

# Generated at 2022-06-20 17:08:07.641740
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    assert AIXHardwareCollector._platform == 'AIX'
    assert AIXHardwareCollector._fact_class == AIXHardware

# Instantiation of class AIXHardwareCollector
aix_hardware_collector = AIXHardwareCollector()


# Generated at 2022-06-20 17:08:19.634424
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():

    class TestAIXModules():

        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def run_command(self, args, use_unsafe_shell=False):
            return self.rc, self.out, self.err

        def get_bin_path(self, arg, required=False):
            return arg


# Generated at 2022-06-20 17:08:32.879259
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    class MockModule(object):
        # Add a class method to make it behave like a module
        @staticmethod
        def get_bin_path(arg=None, required=False):
            if arg in ("lsvg", "xargs"):
                return arg
            return None

        # Add a class method to make it behave like a module
        @staticmethod
        def run_command(arg, use_unsafe_shell=False):
            if arg.startswith("lsvg -o"):
                return 0, "rootvg\nrealsyncvg\ntestvg", None

# Generated at 2022-06-20 17:08:36.483299
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    h = AIXHardwareCollector()
    assert h._platform == 'AIX'
    assert h._fact_class == AIXHardware

# Generated at 2022-06-20 17:08:43.464320
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    hardware_facts = hardware.populate()
    # test if processor exists
    assert 'processor' in hardware_facts, 'Processor data not collected'

    # test if processor_count is of type int
    assert isinstance(hardware_facts['processor_count'], int), 'processor count should be an integer'

    # test if processor cores is of type int
    assert isinstance(hardware_facts['processor_cores'], int), 'processor cores should be an integer'

    # test if memtotal_mb is of type int
    assert isinstance(hardware_facts['memtotal_mb'], int), 'memtotal_mb should be an integer'

    # test if memfree_mb is of type int

# Generated at 2022-06-20 17:08:49.497326
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    facts = {}

    hardware_info = AIXHardware(True, facts, None)
    hardware_info.get_vgs_facts()

if __name__ == '__main__':
    test_AIXHardware_get_vgs_facts()

# Generated at 2022-06-20 17:09:12.312752
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)

    cpu_facts = hardware.get_cpu_facts()

    assert cpu_facts['processor_count'] > 0
    assert cpu_facts['processor_cores'] > 0


# Generated at 2022-06-20 17:09:17.758399
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    os_platform = 'AIX'

    hardware_collector = AIXHardwareCollector()
    assert hardware_collector._platform == os_platform
    assert hardware_collector._fact_class == AIXHardware
    assert hardware_collector._fact_class._platform == os_platform

# Generated at 2022-06-20 17:09:24.678047
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(
        argument_spec={
            'gather_subset': dict(default=['all'], type='list')
        },
        supports_check_mode=True)

    hardware_facts = AIXHardware(module=module)
    vgs_facts = hardware_facts.get_vgs_facts()

    module.exit_json(ansible_facts=vgs_facts)



# Generated at 2022-06-20 17:09:28.736385
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    facts_collector = AIXHardwareCollector()
    assert facts_collector.platform == 'AIX'
    assert facts_collector.fact_class == AIXHardware


# Generated at 2022-06-20 17:09:33.041412
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    aixhw = AIXHardware(module)
    aixhw.get_cpu_facts()
    assert module.run_command.call_count == 2



# Generated at 2022-06-20 17:09:47.202231
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    fixture_path = os.path.join(module_utils.get_fixtures_path(), 'module_utils', 'facts', 'hardware', 'AIX', 'lsattr_El_sys0_-a_fwversion.out')
    with open(fixture_path, 'r') as f:
        lsattr_El_sys0_a_fwversion_out = f.read()

    fixture_path = os.path.join(module_utils.get_fixtures_path(), 'module_utils', 'facts', 'hardware', 'AIX', 'lsconf.out')
    with open(fixture_path, 'r') as f:
        lsconf_out = f.read()


# Generated at 2022-06-20 17:09:55.075505
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module_mock = AnsibleModuleMock()
    hardware_facts = AIX_HARDWARE_FACTS

    hardware = AIXHardware(module_mock)

    vgs_facts = hardware.get_vgs_facts()
    assert vgs_facts == hardware_facts['vgs']



# Generated at 2022-06-20 17:10:02.538052
# Unit test for method get_vgs_facts of class AIXHardware

# Generated at 2022-06-20 17:10:12.334555
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = AIXHardware(module=module)
    vgs_facts = hardware.get_vgs_facts()

    assert vgs_facts['vgs']['rootvg'][0]['pp_size'] == '4 megabyte(s)'
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs_facts['vgs']['rootvg'][0]['free_pps'] == '0'
    assert vgs_facts['vgs']['rootvg'][1]['pp_size'] == '4 megabyte(s)'
    assert vgs_facts['vgs']['rootvg'][1]['pv_name'] == 'hdisk1'
    assert v

# Generated at 2022-06-20 17:10:23.589182
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    """ Method return dict of vg facts """
    module = AnsibleModule(argument_spec={})
    test_module = AIXHardware(module)

    # mock lsps return code and stdout
    lsps_rc = 0

# Generated at 2022-06-20 17:11:07.526926
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    class TestModule:
        def run_command(self, cmd, use_unsafe_shell=False):
            rc = 0
            out = 'dummy text'
            err = 'dummy text'
            return rc, out, err

        def get_bin_path(self, cmd):
            return cmd

    class TestAIHW:
        def __init__(self):
            self.module = TestModule()
            self.module.run_command = TestModule.run_command
            self.module.get_bin_path = TestModule.get_bin_path

    hw = TestAIHW()

# Generated at 2022-06-20 17:11:17.836877
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor_count'] > 0
    assert hardware_facts['processor_cores'] > 0
    assert hardware_facts['processor'] is not None
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['firmware_version'] is not None
    assert hardware_facts['product_name'] is not None
    assert hardware_facts['product_serial'] is not None
    assert hardware_facts['lpar_info'] is not None
    assert hardware_facts['vgs']

# Generated at 2022-06-20 17:11:30.852798
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    expected_memory_facts = {
        'memtotal_mb': 1615,
        'memfree_mb': 1447,
        'swaptotal_mb': 108,
        'swapfree_mb': 108,
    }

    class ModuleMock(object):
        class RunCommandMock(object):
            pass

        run_command = RunCommandMock()
        get_bin_path = lambda *args, **kwargs: "/usr/sbin/lsps"

    module = ModuleMock()

# Generated at 2022-06-20 17:11:41.591216
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():

    class AIXHardwareTest(AIXHardware):
        def __init__(self, module):
            self.module = module

        def run_command(self, cmd, use_unsafe_shell=False):
            (rc, stdout, stderr) = (0, '', '')
            if cmd == "/usr/sbin/lsdev -Cc processor":
                stdout = ('proc0 Available 00-00 Processor\n'
                          'proc4 Available 00-04 Processor\n'
                          'proc8 Available 00-08 Processor')
            elif cmd == "/usr/sbin/lsattr -El proc0 -a type":
                stdout = 'type PowerPC_POWER8 proc0 True'

# Generated at 2022-06-20 17:11:53.081924
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    import ansible.module_utils.facts.hardware.aix as aix_hw
    import ansible.module_utils.facts.utils as utils
    from ansible.module_utils.facts import FactCache
    from ansible.module_utils.facts.utils import get_file_content

    # Creating a temporary module in order to test with it
    # the methods of class AIXHardware
    module = utils.AnsibleModule(
        argument_spec={},
        supports_check_mode=False,
        add_file_common_args=True,
    )

    # Defining the data needed for test case 1
    cache_dir = 'ansible_collected_facts_cache'

# Generated at 2022-06-20 17:11:55.816842
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    cpu_facts = AIXHardware().get_cpu_facts()
    assert 'processor' in cpu_facts
    assert 'processor_cores' in cpu_facts
    assert 'processor_count' in cpu_facts


# Generated at 2022-06-20 17:12:02.205950
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    module = AnsibleModule(argument_spec={})
    aix_hardware = AIXHardware(module)
    dmi_facts = aix_hardware.get_dmi_facts()
    assert dmi_facts['firmware_version'] == 'V7,REL00'
    assert dmi_facts['product_serial'] == '0123456789'
    assert dmi_facts['lpar_info'] == '1 Ent'
    assert dmi_facts['product_name'] == 'IBM,8204-E8A'

# Generated at 2022-06-20 17:12:09.930882
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={})
    hardware_collector = AIXHardware(module)
    hardware_collector.populate()
    facts = hardware_collector.get_facts()
    # Assert number of keys in facts match with expected values
    assert len(facts) == 8
    # Assert keys are exactly what we expect
    assert sorted(facts.keys()) == ['memfree_mb', 'memtotal_mb', 'mounts', 'processor', 'processor_cores', 'processor_count', 'swapfree_mb', 'swaptotal_mb']

# Generated at 2022-06-20 17:12:14.958742
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    my_obj = AIXHardwareCollector()
    assert my_obj.platform == 'AIX'
    assert my_obj.fact_class == AIXHardware


# Generated at 2022-06-20 17:12:22.939481
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    class AIXHardware_test(AIXHardware):
        # Initialize test class
        def __init__(self):
            self.module = AnsibleModule(argument_spec={})
            self.facts = {}
            self.populated = False

        # Mock run_command method for get_device_facts() unit test case
        def run_command(self, cmd):
            return (0, '', '')

    hw = AIXHardware_test()
    hw.populate()
    assert hw.populated

# Generated at 2022-06-20 17:13:37.667989
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.hardware import aix as AixHardware
    from ansible.module_utils.facts.hardware.base import Hardware, HardwareCollector
    import ansible.module_utils.facts.hardware.aix as aix

    class MockModule(object):
        def __init__(self, params):
            self.params = params
        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception('FAIL')
        def exit_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs


# Generated at 2022-06-20 17:13:46.363404
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    from ansible.module_utils.facts import ModuleFactCollector
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts.hardware.base import Hardware

    obj = AIXHardware(None)

    # Tested code
    aix_hardware = AIXHardware(None)
    hardware_facts = aix_hardware.populate()

    # Testing results
    assert hardware_facts['firmware_version'] is not None
    assert hardware_facts['product_serial'] is not None
    assert hardware_facts['lpar_info'] is not None
    assert hardware_facts['product_name'] is not None


# Generated at 2022-06-20 17:13:49.981670
# Unit test for constructor of class AIXHardware
def test_AIXHardware():

    AIXHardware_inst = AIXHardware(dict())

    assert(AIXHardware_inst is not None)

    assert(AIXHardware_inst.module is not None)



# Generated at 2022-06-20 17:13:56.982075
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    from ansible.module_utils.facts import FactCollector

    hardware = AIXHardware()
    hardware.module = FactCollector('')._module
    result = hardware.get_vgs_facts()

# Generated at 2022-06-20 17:13:59.809033
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    # Test whether constructor's call does not fail
    AIXHardwareCollector()

# vim: expandtab:tabstop=4:shiftwidth=4

# Generated at 2022-06-20 17:14:09.289052
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)

    # output of vmstat -v on aix 7.2
    test_stdout = '''
            memory pages         =        171823
            free memory pages    =        171823
            memory page size     =        8192 bytes
            free memory          =        1397.60 GB
            memory size          =        1397.60 GB
            max user processes   =        8192
            max processor sets   =        8192
            max virtual processors        =        8192
            max virtual processors per system     =        8192
            max processor id     =        127
            max processes        =        16777236
            max file descriptors =        10240
            max open files       =        14000
    '''
    pagesize = 4096
    pagecount = 17

# Generated at 2022-06-20 17:14:17.451334
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    mock_module = Mock()

    # lsconf output for system having 'Machine Serial Number', 'LPAR Info' and 'System Model'
    mock_module.run_command.side_effect = [
        (0, '', ''),
        (0,
         'Machine Serial Number: 0123456789\n'
         'LPAR Info: 00\n'
         'System Model: IBM,9117-MMA',
         ''),
        (0, '', '')
    ]

    hardware = AIXHardware()
    hardware.module = mock_module
    dmi_facts = hardware.get_dmi_facts()

    assert dmi_facts['lpar_info'] == '00'
    assert dmi_facts['product_name'] == 'IBM,9117-MMA'

# Generated at 2022-06-20 17:14:29.069003
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    """
    For method get_vgs_facts and get_mount_facts of class AIXHardware
    assert that fact facts gathered are correct
    """
    module = AnsibleModule(argument_spec={})
    test_hardware = AIXHardware(module)
    assert test_hardware is not None


# Generated at 2022-06-20 17:14:38.671364
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():

    class TestAIXHardware(AIXHardware):
        module = None

        def __new__(cls, *args, **kwargs):
            obj = super(TestAIXHardware, cls).__new__(cls, *args, **kwargs)
            obj.module = MagicMock()
            obj.module.run_command.side_effect = [
              (0, "proc0 Available 00-00-04-00 AT/486\n"
                 "proc1 Available 00-00-04-01 AT/486\n", ""),
            ]
            return obj

    hardware_object = TestAIXHardware()

    cpu_facts = hardware_object.get_cpu_facts()

    assert cpu_facts == {'processor': 'AT/486', 'processor_cores': 1, 'processor_count': 2}

# Unit test

# Generated at 2022-06-20 17:14:44.564218
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():

    # Mocked data for lsdev output
    lsdev_out = """name          status  description
hdisk1        Available 00-06-A6-70-5E-F6-86-0A-07-00-E0-00-01-0C-00
ent0          Defined   Built-In Ethernet
ent1          Defined   Built-In Ethernet"""

    # Mocked data for lsattr output for ent0 device