

# Generated at 2022-06-20 17:07:41.158353
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    agt_hw = AIXHardware(module)
    res = agt_hw.get_cpu_facts()

    # res should be a dictionary with CPU facts
    assert res is not None
    assert isinstance(res, dict)

    # res should contain key processor_count
    assert 'processor_count' in res

    # res should contain key processor_cores
    assert 'processor_cores' in res

    # res should contain key processor
    assert 'processor' in res

    # processor should be a string
    assert isinstance(res['processor'], str)


# Generated at 2022-06-20 17:07:45.574149
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    # arrange
    module = AnsibleModule
    module.run_command = MagicMock(side_effect=[(0, 'memory pages', ''), (0, 'free pages', '')])
    aix_hw = AIXHardware(module)
    
    # act
    out = aix_hw.get_memory_facts()

    # assert
    assert out['memtotal_mb'] == 1426
    assert out['memfree_mb'] == 35


# Generated at 2022-06-20 17:07:48.533473
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector.platform == 'AIX'
    assert hardware_collector.fact_class == AIXHardware



# Generated at 2022-06-20 17:07:51.191830
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={})
    hardware_facts = AIXHardware(module)
    hardware_facts.populate()

    assert hardware_facts

# Generated at 2022-06-20 17:08:00.739310
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    from ansible.module_utils.facts.collector.aix import AIXHardware

    aix_hardware = AIXHardware()
    # Following test input is captured from AIX

# Generated at 2022-06-20 17:08:02.927085
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    m = AIXHardware()
    assert len(m.get_mount_facts()['mounts']) >= 1

# Generated at 2022-06-20 17:08:12.056316
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    DR_example = """ent0 Available 00-00
ent1 Available 00-01
ent2 Defined   00-02
ent3 Defined   00-03
ent4 Defined   00-04"""
    DR_example_attributes = """ent0 simple_attrib1 0 false
ent0 simple_attrib2 1 false
ent1 simple_attrib1 1 false
ent1 simple_attrib2 0 false
ent2 simple_attrib1 0 false
ent2 simple_attrib2 1 false
ent3 simple_attrib1 0 false
ent3 simple_attrib2 1 false
ent4 simple_attrib1 0 false
ent4 simple_attrib2 1 false"""
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)

# Generated at 2022-06-20 17:08:19.411362
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    import sys
    import os
    import tempfile
    import pytest
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts.utils import get_mount_size
    if sys.version_info[0] >= 3:
        from io import StringIO
    else:
        from StringIO import StringIO

    class TestModule:
        def __init__(self, stdout):
            self.stdout = stdout

        def run_command(self, cmd, use_unsafe_shell=False):
            return (0, self.stdout, '')


# Generated at 2022-06-20 17:08:29.372648
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    class module:
        def get_bin_path(self, arg1, arg2=False):
            return "/usr/sbin/lsvg"

        def run_command(self, arg1, use_unsafe_shell=False):
            return 0, dummy_lsvg_output, "err"

    class object1(AIXHardware):
        module = module()

    assert object1().get_vgs_facts()['vgs'] == expected_vgs_dict



# Generated at 2022-06-20 17:08:41.138458
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    hw = AIXHardware({})

    def run_command(args, **kwargs):
        if args[0] == '/usr/sbin/lsdev':
            return 0, out_lsdev, err
        elif args[0] == '/usr/sbin/lsattr':
            return 0, out_lsattr, err
        else:
            assert False

    # test for attribute fc_err_recov
    # test for generic attribute
    attr_name = 'fc_err_recov'
    device_name = 'sissas0'
    hw.module.run_command = run_command
    out_lsdev = '''sissas0 Available 07-08 SAS/SATA Controller
sissas1 Available 07-08 SAS/SATA Controller'''

# Generated at 2022-06-20 17:09:07.597644
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    class ModuleStub():
        def __init__(self):
            self.params = dict()

        def get_bin_path(self, path, required=False):
            return path


# Generated at 2022-06-20 17:09:13.782543
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    from ansible.module_utils.facts.hardware.ibm_aix import AIXHardware
    module = MockModule()
    hardware = AIXHardware(module)

    hardware.get_cpu_facts = Mock(return_value={
        'processor_count': 2,
        'processor': 'PowerPC_POWER8',
        'processor_cores': 4
    })
    hardware.get_memory_facts = Mock(return_value={
        'memtotal_mb': 16384,
        'memfree_mb': 16384,
        'swaptotal_mb': 16384,
        'swapfree_mb': 16384
    })

# Generated at 2022-06-20 17:09:22.221048
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)

    hardware.get_cpu_facts = MagicMock(return_value={})
    hardware.get_memory_facts = MagicMock(return_value={})
    hardware.get_dmi_facts = MagicMock(return_value={})
    hardware.get_mount_facts = MagicMock(return_value={})
    hardware.get_device_facts = MagicMock(return_value={})

    rc, out, err = module.run_command("/usr/sbin/lsvg")
    if out:
        for vg in out.splitlines():
            cmd = "/usr/sbin/lsvg " + vg + " -p"
            rc, out, err = module.run_command(cmd)
            hardware.get

# Generated at 2022-06-20 17:09:27.052997
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    factory = AIXHardware()
    test_device = factory.get_dmi_facts()
    # There are no guarantees the results are not empty
    assert test_device

# Generated at 2022-06-20 17:09:29.854494
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    from ansible.module_utils.facts.collector.generic.device_facts_cache import DeviceFactsCollector
    device_facts_cache = DeviceFactsCollector().populate()
    hw = AIXHardware(module=None, collected_facts=device_facts_cache)
    assert isinstance(hw.populate(), dict)



# Generated at 2022-06-20 17:09:38.913957
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    aix_hardware = AIXHardware({})
    aix_hardware.populate()
    assert 'memtotal_mb' in aix_hardware.facts
    assert 'memfree_mb' in aix_hardware.facts
    assert 'swaptotal_mb' in aix_hardware.facts
    assert 'swapfree_mb' in aix_hardware.facts
    assert 'processor' in aix_hardware.facts
    assert 'processor_cores' in aix_hardware.facts
    assert 'processor_count' in aix_hardware.facts
    assert 'firmware_version' in aix_hardware.facts
    assert 'vgs' in aix_hardware.facts
    assert 'devices' in aix_hardware.facts


# Generated at 2022-06-20 17:09:49.465576
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    from ansible.module_utils.facts.hardware import AIXHardware
    test_installation = AIXHardware()

    lsconf_path = test_installation.module.get_bin_path("lsconf")
    if lsconf_path:
        rc, out, err = test_installation.module.run_command(lsconf_path)
        if rc == 0 and out:
            for line in out.splitlines():
                data = line.split(':')
                if 'Machine Serial Number' in line:
                    serial_number = data[1].strip()
                if 'LPAR Info' in line:
                    lpar_info = data[1].strip()
                if 'System Model' in line:
                    system_model = data[1].strip()
    test_installation.get_dmi_facts()
    assert serial

# Generated at 2022-06-20 17:10:01.157767
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    file_path = os.path.join(os.path.dirname(__file__), "lsvg_output.txt")
    lsvg_path = "/usr/sbin/lsvg"
    xargs_path = "/usr/bin/xargs"

    ah = AIXHardware()
    ah.module = MagicMock()
    ah.module.get_bin_path.return_value = lsvg_path
    ah.module.run_command.side_effect = [(0, read_file_content(file_path), ""),
                                         (0, "", "")]

    # call function to test
    res = ah.get_vgs_facts()
    vgs = res['vgs']

    # assert that the result is as expected

# Generated at 2022-06-20 17:10:11.786868
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    import unittest

    class AIXHardwareTest(unittest.TestCase):
        def setUp(self):
            class FakeModule:
                def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None, environ_update=None):
                    return 0, '', ''

            class FakeProvider:
                def _exec_command(self, cmd):
                    return 0, '', ''

            self.module = FakeModule()
            self.module.get_bin_path = FakeProvider()._exec_command

            self.aix_hardware = AIXHardware(self.module)


# Generated at 2022-06-20 17:10:23.366287
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    if not HAS_AIX_UTILS:
        module.fail_json(msg=missing_required_lib('aix_lib'))

    actual_fact_subset = ['devices', 'firmware_version', 'lpar_info', 'memfree_mb', 'memtotal_mb', 'mounts',
                      'product_name', 'product_serial', 'processor', 'processor_cores', 'processor_count',
                      'swapfree_mb', 'swaptotal_mb', 'vgs']

    # Create instance of class AIXHardware and execute method populate with
    # below args

# Generated at 2022-06-20 17:11:03.207674
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    """Unit test for method get_memory_facts of class AIXHardware

    Args:
        None

    Returns:
        None

    """
    mem_facts = AIXHardware().get_memory_facts()

    assert mem_facts['memtotal_mb'] == 39141
    assert mem_facts['memfree_mb'] == 23278



# Generated at 2022-06-20 17:11:16.484135
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})

    hardware_mock = AIXHardware(module)


# Generated at 2022-06-20 17:11:26.674555
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    facts = AIXHardware(dict())
    assert facts.platform == 'AIX'
    assert len(facts.get_cpu_facts()) == 4
    assert len(facts.get_memory_facts()) == 5
    assert len(facts.get_dmi_facts()) == 4
    assert len(facts.get_vgs_facts()) == 1
    assert len(facts.get_device_facts()) == 1
    assert len(facts.get_mount_facts()) == 1

# Generated at 2022-06-20 17:11:39.575835
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    import platform
    import tempfile
    import shutil
    import os.path
    import os

    TEST_NFS_SHARE = '192.168.1.2:/share'
    TEST_NFS_VOLNAME = 'mynfsvol'
    TEST_NFS_MOUNT_DIR = tempfile.mkdtemp(prefix='ansible-nfs-test-')
    TEST_NFS_MOUNTPOINT = os.path.join(TEST_NFS_MOUNT_DIR, TEST_NFS_VOLNAME)

    # try to unmount incase something else mounted it before me
    module = AnsibleModule(argument_spec=dict())
    rc, _, _ = module.run_command('umount -f %s' % TEST_NFS_MOUNTPOINT)

# Generated at 2022-06-20 17:11:42.622674
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware_obj = AIXHardware(dict())
    assert hardware_obj.platform == 'AIX'



# Generated at 2022-06-20 17:11:53.458427
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = FakeAnsibleModule()
    hardware = AIXHardware(module)

# Generated at 2022-06-20 17:12:01.382510
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    class InMemoryModule(object):
        cmd_result = {}

        def run_command(self, cmd, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, encoding=None):
            if use_unsafe_shell:
                cmd = ' '.join(cmd)
            return self.cmd_result[cmd]
    hardware = AIXHardware(InMemoryModule())

# Generated at 2022-06-20 17:12:11.277714
# Unit test for method get_device_facts of class AIXHardware

# Generated at 2022-06-20 17:12:23.249958
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeAnsibleModuleRuncommands(
        '/usr/sbin/lsdev -Cc processor',
        'proc0   Available 00-00 Processor\nproc1   Available 00-01 Processor\nproc2   Available 00-02 Processor\nproc3   Available 00-03 Processor\n'
    )
    aix_hardware = AIXHardware(module)
    aix_facts = aix_hardware.populate()

    assert aix_facts['processor'] == 'Processor'
    assert aix_facts['processor_count'] == 4
    assert aix_facts['processor_cores'] == 1


# Generated at 2022-06-20 17:12:34.697026
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    aix_node = AIXHardware(module)

    aix_node.module.run_command = MagicMock(return_value=(0, "IBM,9117-MMB", ""))

    rc, out, err = aix_node.module.run_command("/usr/sbin/lsconf")
    if rc == 0 and out:
        for line in out.splitlines():
            data = line.split(':')
            if 'Machine Serial Number' in line:
                module.run_command = MagicMock(return_value=(0, data[1].strip(), ""))


# Generated at 2022-06-20 17:13:50.405756
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec=dict())
    hardware = AIXHardware(module)
    fact = hardware.populate()
    assert 'processor' in fact
    assert 'processor_cores' in fact
    assert 'processor_count' in fact
    assert 'memfree_mb' in fact
    assert 'memtotal_mb' in fact
    assert 'swapfree_mb' in fact
    assert 'swaptotal_mb' in fact
    assert 'firmware_version' in fact
    assert 'product_serial' in fact
    assert 'lpar_info' in fact
    assert 'product_name' in fact
    assert 'devices' in fact
    assert 'mounts' in fact
    assert 'vgs' in fact

# Generated at 2022-06-20 17:14:01.755490
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware_facts = AIXHardware()
    vgs_facts = hardware_facts.get_vgs_facts()

    assert vgs_facts['vgs']['rootvg'][0]['pp_size'] == '4 megabyte(s)'
    assert len(vgs_facts['vgs']['rootvg']) == 2
    assert vgs_facts['vgs']['testvg'][1]['pv_name'] == 'hdisk105'
    assert vgs_facts['vgs']['realsyncvg'][0]['free_pps'] == '6'


# Generated at 2022-06-20 17:14:10.125816
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    facts = AIXHardware()
    vgs_facts = facts.get_vgs_facts()

# Generated at 2022-06-20 17:14:19.813995
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    """
    Test method get_cpu_facts of class AIXHardware
    """
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    import platform

    test_module = AIXHardware()

    test_module._module = FakeModule()

    # get_cpu_facts test
    rc, out, err = test_module.run_command("/usr/sbin/lsdev -Cc processor")
    if out:
        i = 0
        for line in out.splitlines():

            if 'Available' in line:
                if i == 0:
                    data = line.split(' ')
                    cpudev = data[0]

                i += 1
        cpu_facts = test_module.get_cpu_facts()

# Generated at 2022-06-20 17:14:29.893773
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_instance = AIXHardware(module)
    hardware_instance.populate()
    assert hardware_instance.ansible_facts['firmware_version'] == '770-FMS1.100'
    assert hardware_instance.ansible_facts['product_serial'] == '123456789'
    assert hardware_instance.ansible_facts['lpar_info'] == '1 00C9C9FF4C00'
    assert hardware_instance.ansible_facts['product_name'] == '(Stand-alone)'
    assert hardware_instance.ansible_facts['processor_count'] == 4
    assert hardware_instance.ansible_facts['processor_cores'] == 1
    assert hardware_instance.ansible_facts['processor'] == 'PowerPC_POWER7'

#

# Generated at 2022-06-20 17:14:31.434428
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hw = AIXHardwareCollector()
    assert hw._platform == 'AIX'
    assert hw._fact_class == AIXHardware

# Generated at 2022-06-20 17:14:39.117264
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    """
    Test AIXHardware.get_cpu_facts
    """
    module = AnsibleModuleMock()
    module.run_command = create_run_command_mock(["/usr/sbin/lsdev -Cc processor",
                                                  "/usr/sbin/lsdev -Cc processor",
                                                  "/usr/sbin/lsdev -Cc processor",
                                                  "/usr/sbin/lsattr -El proc0 -a type",
                                                  "/usr/sbin/lsattr -El proc0 -a smt_threads"])

    ah = AIXHardware(module)
    assert ah.get_cpu_facts() == {'processor': 'PowerPC_POWER8',
                                  'processor_cores': 4,
                                  'processor_count': 4}



# Generated at 2022-06-20 17:14:51.211302
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    # Arrange
    class Module:
        def __init__(self):
            self.run_command_calls = 0

        def run_command(self, cmd, use_unsafe_shell=False):
            self.run_command_calls += 1
            if self.run_command_calls == 1:
                return 0, lsdev_out, None
            elif self.run_command_calls == 2:
                return 0, lsattr_out, None

        def get_bin_path(self, name, opt_dirs=[]):
            return name

    lsdev_out = '''hdisk0   Available 00-00-02-1,0
hdisk1   Available 00-01-00-2,0
hd5      Available 00-10-00-6,0
'''

# Generated at 2022-06-20 17:15:01.856206
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    """
    Unit test for method get_mount_facts of class AIXHardware
    """

    # Test case 1:
    # Test case when mount output is not of expected format
    aix_hw = AIXHardware()
    mount_output = 'garbage'
    mount_output_list = mount_output.splitlines()

    # Test for when line starts with other than '/'
    mount_facts = aix_hw.get_mount_facts(mount_output_list)
    assert mount_facts['mounts'] == []

    # Test case 2:
    # Test case when mount output is standard mount command output

# Generated at 2022-06-20 17:15:10.844113
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    host_info = {'module': MockModule()}
    aix_hardware = AIXHardware(host_info)
