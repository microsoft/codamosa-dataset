

# Generated at 2022-06-20 17:07:42.548999
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    hardware = AIXHardware()
    hardware.module = AnsibleModule(argument_spec=dict())
    hardware.module.run_command = run_command

    result = hardware.populate()

    assert 'firmware_version' in result
    assert 'product_serial' in result
    assert 'lpar_info' in result
    assert 'product_name' in result

    assert 'memfree_mb' in result
    assert 'memtotal_mb' in result
    assert 'swapfree_mb' in result
    assert 'swaptotal_mb' in result

    assert 'processor' in result
    assert 'processor_cores' in result
    assert 'processor_count' in result

    assert 'vgs' in result
    assert 'devices' in result
    assert 'mounts' in result



# Generated at 2022-06-20 17:07:44.616692
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={})
    hw = AIXHardware(module)
    assert hw.OS_FAMILY is None
    assert hw.platform == 'AIX'

# Generated at 2022-06-20 17:07:55.950513
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    test_obj = AIXHardware(None)

    # test missing lsconf
    test_obj.module.get_bin_path = lambda _: None
    test_obj._module.run_command = lambda _: (0, '', '')
    assert test_obj.get_dmi_facts() == {}

    # test missing lsattr
    test_obj.module.get_bin_path = lambda _: True
    test_obj._module.run_command = lambda _: (0, '', '')
    assert test_obj.get_dmi_facts() == {}

    # test missing output
    test_obj.module.get_bin_path = lambda _: True
    test_obj._module.run_command = lambda _: (0, '', '')
    assert test_obj.get_dmi_facts() == {}

# Generated at 2022-06-20 17:08:08.268641
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    mock_module = Mock(name="module")
    AIXHardware = AIXHardware(mock_module)

    result = AIXHardware.populate()

    assert result is not None
    assert result['processor_count']
    assert result['processor']
    assert result['memtotal_mb']
    assert result['memfree_mb']
    # test mountfacts
    assert result['mounts']
    # test devicefacts
    assert result['devices']
    # test vgsfacts
    assert result['vgs']
    # test dmifacts
    assert result['product_serial']
    assert result['lpar_info']
    assert result['product_name']
    assert result['firmware_version']

# Generated at 2022-06-20 17:08:17.055042
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = Mock(run_command=Mock(return_value=(1, '','')))
    script = AIXHardware(module=module)

    module.run_command.return_value = (0, """
hdisk0100 Available Virtual SCSI Disk Drive
hdisk0 Available Virtual SCSI Disk Drive
""", '')
    module.get_bin_path.side_effect = lambda x, y: x

# Generated at 2022-06-20 17:08:25.805891
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    obj = AIXHardware()
    out = """proc1 Available 00-00 Processor
proc0 Available 00-00 Processor"""
    obj.module.run_command.return_value = (0, out, '')
    expected = {'processor_count': 2, 'processor': '00-00'}
    result = obj.get_cpu_facts()
    assert result == expected


# Generated at 2022-06-20 17:08:29.187628
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})

    hardware = AIXHardware()
    hardware.module = module
    hardware.populate()



# Generated at 2022-06-20 17:08:41.074067
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module=module)
    ansible_facts = {u'ansible_system': u'AIX'}
    cpu_facts = {u'processor': [u'PowerPC_POWER8'],
                 u'processor_cores': 4,
                 u'processor_count': 2}
    memory_facts = {u'memtotal_mb': 1024,
                    u'swaptotal_mb': 2047,
                    u'swapfree_mb': 2048,
                    u'memfree_mb': 1023}

# Generated at 2022-06-20 17:08:53.588262
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    if not HAS_AIXTOOLS:
        module.fail_json(msg=missing_required_lib("aix-pwd"), exception=AIXTOOLS_IMP_ERR)

    failed = False
    out = {}
    aix_obj = AIXHardware()
    out = aix_obj.get_mount_facts()
    # Test with all the example mount output

# Generated at 2022-06-20 17:09:05.007357
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    # Initialize target object
    hardware = AIXHardware(None)

    # Define source data

# Generated at 2022-06-20 17:09:30.425114
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    aix_hardware_collector = AIXHardwareCollector()

    assert aix_hardware_collector._platform == 'AIX'
    assert aix_hardware_collector._fact_class == AIXHardware
    assert aix_hardware_collector._fact_class.platform == 'AIX'

# Generated at 2022-06-20 17:09:39.390149
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    memory_facts = {}
    hw = AIXHardware()
    # Test free memory: 314368 pages, 314368 * 4096 / 1024 / 1024 = 1258 MB
    memory_facts = hw._get_memory_facts("memory pages: 314368\nfree pages: 0")
    assert memory_facts['memtotal_mb'] == 1258
    assert memory_facts['memfree_mb'] == 0
    # Test free memory: 314368 pages, 314368 * 4096 / 1024 / 1024 = 1258 MB
    memory_facts = hw._get_memory_facts("memory pages: 314368\nfree pages: 314368")
    assert memory_facts['memtotal_mb'] == 1258
    assert memory_facts['memfree_mb'] == 1258
    # Test swap: 314368 blocks, 314368 * 512 / 1024 / 1024 = 155 MB
    memory

# Generated at 2022-06-20 17:09:46.376076
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    result = {}
    result['processor_count'] = 2
    result['processor'] = 'PowerPC_POWER8'
    result['processor_cores'] = 10

    args = {}
    aix_hardware = AIXHardware(None, args, None)
    aix_hardware.module.run_command = mock_run_command
    out = aix_hardware.get_cpu_facts()

    assert out == result



# Generated at 2022-06-20 17:10:00.043142
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    """
    AIXHardware - get_mount_facts method unit test stub.
    """
    # initialize object AIXHardware
    aix_hardware_obj = AIXHardware()
    aix_hardware_obj.module = MagicMock()
    aix_hardware_obj.module.get_bin_path.return_value = '/usr/sbin/mount'

    # call method
    expected_result = {
        'mounts': []
    }

    mount_cmd = aix_hardware_obj.module.get_bin_path('mount')
    aix_hardware_obj.module.run_command.return_value = (0, '\n'.join([]), '')

    result = aix_hardware_obj.get_mount_facts()

    aix_hardware_obj.module.run

# Generated at 2022-06-20 17:10:11.462667
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():

    """
    AIX does not have mtab and the method get_mount_facts
    has to parse the output of mount command instead to
    get mount point information.

    This is unit test for method get_mount_facts.
    """

    # Setup the test
    aix_hardware_object = AIXHardware()

    # Use the output of mount command as input to the method
    # get_mount_facts

# Generated at 2022-06-20 17:10:23.241127
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(
        argument_spec=dict(
        )
    )
    module.run_command = MagicMock(return_value=(0, '', ''))
    aix_hardware = AIXHardware(module=module)
    aix_hardware.get_mount_facts = MagicMock(return_value={"mounts": []})
    aix_hardware.get_dmi_facts = MagicMock(return_value={})
    aix_hardware.get_vgs_facts = MagicMock(return_value={})
    aix_hardware.get_device_facts = MagicMock(return_value={})
    aix_hardware.populate()

# Generated at 2022-06-20 17:10:33.738510
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    class TestModule(object):
        def __init__(self):
            self.params = dict()
            self.command_results = dict()

        def get_bin_path(self, name, required=False):
            return("/bin/true")

        def run_command(self, cmd, use_unsafe_shell=False):
            rc = 0

# Generated at 2022-06-20 17:10:42.988577
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    class FakeAIXHardware(AIXHardware):
        pass
    HA = FakeAIXHardware()
    HA.module = FakeAIXHardware
    HA.module.run_command = FakeAIXHardware
    HA.module.run_command.return_value = 0, 'test_get_memory_facts_output', ''
    HA.module.get_bin_path = FakeAIXHardware
    HA.module.get_bin_path.return_value = '/usr/sbin/vmstat'
    HA.get_memory_facts()

# Generated at 2022-06-20 17:10:53.806955
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    import sys
    sys.path.append('/Users/okocha/Documents/workspace/github/ansible/hacking/testsuite/units')
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.virt.hardware.aix import AIXHardware

    module = basic.AnsibleModule(
        argument_spec={
        }
    )

    memory_facts = AIXHardware(module)
    memory_facts.collect()


test_AIXHardware_get_memory_facts()


# Generated at 2022-06-20 17:10:57.954904
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    hardware_data = AIXHardware()
    device_info = hardware_data.get_device_facts()
    assert not device_info['devices']

# Generated at 2022-06-20 17:11:20.202640
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    collector = AIXHardwareCollector()
    assert collector.platform == 'AIX'
    assert collector.fact_class == AIXHardware
    assert isinstance(collector.fact_class({}), AIXHardware)

# Generated at 2022-06-20 17:11:27.092600
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    mod = AnsibleModule(argument_spec={})
    hardware_obj = AIXHardware(mod)


# Generated at 2022-06-20 17:11:39.609360
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    from ansible.module_utils.facts import get_module_path

# Generated at 2022-06-20 17:11:45.737987
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    test_AIXHardware = AIXHardware(dict())
    m = test_AIXHardware.get_device_facts()
    assert m
    assert m['devices']
    # Add assert statement here to check that function returns correct output


# Generated at 2022-06-20 17:11:54.252283
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts.plugins.test.test_hardware import TestHardware
    from ansible.module_utils._text import to_bytes
    from ansible_collections.ansible.community.tests.unit.compat.mock import mock_open, patch

    # The lsdev output is not so easy to mock, because of the formatting, so let us just define the complete output
    lsdev_output = """ent0 Available 01-08 Intel(R) PRO/1000 Gigabit Ethernet
ent1 Available 01-09 Intel(R) PRO/1000 Gigabit Ethernet
ent2 Defined 01-0a Intel(R) PRO/1000 Gigabit Ethernet"""


# Generated at 2022-06-20 17:12:02.592111
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():

    module = AnsibleModuleMock(argument_spec={})
    hardware_obj = AIXHardware(module)
    call_command_mock = MagicMock()
    hardware_obj.module.run_command = call_command_mock
    call_command_mock.return_value = [0, "", ""]

    assert hardware_obj.get_cpu_facts() == {}
    call_command_mock.assert_has_calls([call("/usr/sbin/lsdev -Cc processor"), ])
    call_command_mock.reset_mock()

    call_command_mock.return_value = [0, "proc0 Available 00-00 Processor\nproc1 Available 00-01 Processor", ""]

# Generated at 2022-06-20 17:12:13.030977
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():

    class MockModule:
        def __init__(self):
            self.run_command_calls = 0
            self.run_command_returns = []

        def run_command(self, cmd):
            self.run_command_calls += 1
            return self.run_command_returns.pop(0)

        def get_bin_path(self, cmd, required=False):
            if cmd == 'mount':
                return 'mount'
            else:
                return None

    # mock module
    module = MockModule()

    # mock mount output

# Generated at 2022-06-20 17:12:24.949462
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardwarecollector = AIXHardwareCollector(module=module)
    facts = hardwarecollector.collect(module=module, collected_facts=None)
    assert isinstance(facts, dict)
    assert isinstance(facts['ansible_facts']['ansible_processor'], list)
    assert isinstance(facts['ansible_facts']['ansible_processor_cores'], int)
    assert isinstance(facts['ansible_facts']['ansible_processor_count'], int)
    assert isinstance(facts['ansible_facts']['ansible_memfree_mb'], int)
    assert isinstance(facts['ansible_facts']['ansible_memtotal_mb'], int)

# Generated at 2022-06-20 17:12:34.229393
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    """
    Return a set of facts from the files in a given directory.  Files with an
    extension matching fact_extension are processed.  If a directory contains
    an executable file named 'fact_dir_path + "_facts"', it is executed and
    the output included in the fact list.  Executable files are only executed
    if the the 'gather_subset' list includes 'exec' otherwise the script is
    assumed to be a module and its arguments are passed as 'gather_timeout'.
    Executable files are not processed recursively.
    :param base_dir: directory containing files with facts
    :param gather_subset: list of fact subsets to gather
    :param gather_timeout: timeout to pass to module execution
    :return: list of Fact objects
    """

# Generated at 2022-06-20 17:12:37.976401
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    hardware.populate()
    assert hardware.facts['processor_count'] > 0

# Generated at 2022-06-20 17:13:28.871807
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    ansible_module_mock = DummyAnsibleModule()
    aix_hardware = AIXHardware(ansible_module_mock)

    aix_hardware.populate()
    assert 'processor' in ansible_module_mock.params
    assert 'processor_count' in ansible_module_mock.params
    assert 'processor_cores' in ansible_module_mock.params
    assert 'memtotal_mb' in ansible_module_mock.params
    assert 'memfree_mb' in ansible_module_mock.params
    assert 'swaptotal_mb' in ansible_module_mock.params
    assert 'swapfree_mb' in ansible_module_mock.params
    assert 'firmware_version' in ansible_module_mock.params


# Generated at 2022-06-20 17:13:35.540434
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.basic import AnsibleModule
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.facts.hardware.aix import AIXHardware, AIXHardwareCollector

    module = AnsibleModule(argument_spec={})

    fake_out_lsdev = "ent0 Available  00-08-74-64-A5-E1"
    lsdev_cmd = AIXHardwareCollector._fact_class.module.get_bin_path('lsdev', True)
    lsattr_cmd = AIXHardwareCollector._fact_class.module.get_bin_path('lsattr', True)

    module_instance = AIXHardware(module=module)

# Generated at 2022-06-20 17:13:47.874240
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    # Test initialization
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    hw = AIXHardware(module=module)

    # Test inputs

# Generated at 2022-06-20 17:13:57.341188
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    from ansible_collections.ansible.community.tests.unit.compat.mock import MagicMock
    from ansible_collections.ansible.community.tests.unit.modules.utils import set_module_args

    module = MagicMock()
    module.run_command = MagicMock(return_value=('', 'IBM,8237-22L', ''))

    set_module_args({})
    AIXHardware.populate(module)
    assert module.ansible_facts['firmware_version'] == 'IBM,8237-22L'


# Generated at 2022-06-20 17:14:00.687282
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = type('test', (object,), {})
    hardware = AIXHardware(module)

    assert hardware.module == module
    assert hardware.platform == 'AIX'
    assert hardware.facts == {}

# Generated at 2022-06-20 17:14:05.872735
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    aixhw = AIXHardware(module)
    facts = aixhw.populate()

    if facts['mounts']:
        for mount in facts['mounts']:
            assert mount['mount']
            assert mount['device']
            assert mount['fstype'] or mount['fstype'] == 'nfs' or mount['fstype'] == 'cifs'
            assert mount['options']
            assert mount['size_total'] >= 0
            assert mount['size_available'] >= 0
            assert mount['size_used'] >= 0
            assert mount['time']
    else:
        assert False

# Generated at 2022-06-20 17:14:15.641516
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    # Write unit test here
    module = MockModule()
    AH = AIXHardware(module=module)
    rc, out, err = module.run_command.return_value

    # data for test

# Generated at 2022-06-20 17:14:24.220139
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    from ansible.module_utils.facts.hardware import aix
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts.hardware.base import Hardware
    from ansible.module_utils.facts.hardware.base import HardwareCollector


# Generated at 2022-06-20 17:14:29.521880
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    hardware_obj = AIXHardware(module)
    mounts = hardware_obj.get_mount_facts()['mounts']
    assert len(mounts)
    assert mounts[0]['mount'] == '/'
    assert mounts[0]['device'] == '/dev/hd4'
    assert mounts[0]['fstype'] == 'jfs2'
    assert mounts[0]['time'] == 'Jan  8  01:12:50 2018'
    assert len(mounts[0]['options'])


# Generated at 2022-06-20 17:14:38.809504
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    fake_module = AnsibleModule(
        argument_spec={
        }
    )

    class DummyHardware:
        def __init__(self, module):
            self.module = module

    mock_run_command = MagicMock(return_value=(0, '', ''))
    mock_get_bin_path = MagicMock(return_value='/usr/bin/mount')

    fake_module.run_command = mock_run_command
    fake_module.get_bin_path = mock_get_bin_path

    fake_hardware = AIXHardware(DummyHardware(fake_module))


# Generated at 2022-06-20 17:16:16.151329
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    p = AIXHardware()

    # AIX vmstat -v output
    test_string = """
    memory pages                       :  78720
    ...
    free pages                         :    631
    ...
    """

    p.module.run_command = lambda cmd: (0, test_string, '')
    res = p.get_memory_facts()
    assert res['memtotal_mb'] == 314368
    assert res['memfree_mb'] == 2520



# Generated at 2022-06-20 17:16:20.678258
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector._platform == 'AIX'
    assert hardware_collector._fact_class == AIXHardware


# Generated at 2022-06-20 17:16:29.321081
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    """
    test method get_dmi_facts of class AIXHardware
    """
    hardware_obj = AIXHardware()

    rc, out, err = hardware_obj.module.run_command("/usr/sbin/lsattr -El sys0 -a fwversion")
    out_without_new_line = out.split('\n')[0]
    data = out_without_new_line.split()
    # check if fwversion matches with lsattr output
    assert (data[1].strip('IBM,') == hardware_obj.get_dmi_facts()['firmware_version'])

    lsconf_path = hardware_obj.module.get_bin_path("lsconf")


# Generated at 2022-06-20 17:16:36.334135
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    mem_mock = {
        'memtotal_mb': 16384,
        'memfree_mb': 1404,
        'swaptotal_mb': 2047,
        'swapfree_mb': 2046
    }

    test_obj = AIXHardware(module=None)
    obj = test_obj.get_memory_facts()

    assert obj == mem_mock



# Generated at 2022-06-20 17:16:48.974457
# Unit test for method populate of class AIXHardware

# Generated at 2022-06-20 17:16:55.294315
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    aix_hardware = AIXHardware()
    vgs_facts = aix_hardware.get_vgs_facts()

# Generated at 2022-06-20 17:16:57.492813
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    result = AIXHardware()
    assert result.populate()["processor_cores"] == int(8)

# Generated at 2022-06-20 17:16:59.819379
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hw = AIXHardware()
    assert hw.populate() is not None


# Generated at 2022-06-20 17:17:05.911033
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    aix_hardware = AIXHardware(None)

# Generated at 2022-06-20 17:17:17.031897
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_collector = AIXHardwareCollector(module=module, task=dict())
    hardware = hardware_collector.collect()[0]
    cpu_facts = hardware.cpu
    memory_facts = hardware.memory
    dmi_facts = hardware.dmi
    vgs_facts = hardware.vgs
    mount_facts = hardware.mounts
    devices_facts = hardware.devices

    assert isinstance(cpu_facts, dict)
    assert isinstance(memory_facts, dict)
    assert isinstance(dmi_facts, dict)
    assert isinstance(vgs_facts, dict)
    assert isinstance(mount_facts, list)
    assert isinstance(devices_facts, dict)