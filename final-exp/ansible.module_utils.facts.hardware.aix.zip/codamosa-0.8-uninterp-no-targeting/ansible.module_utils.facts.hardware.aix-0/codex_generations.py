

# Generated at 2022-06-20 17:07:48.016100
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    class MockModule(object):

        def __init__(self, name, path=None, use_unsafe_shell=False, rc=0, out=None, err=None):
            self.name = name
            self.path = path
            self.use_unsafe_shell = use_unsafe_shell
            self.rc = rc
            self.out = out
            self.err = err

        def get_bin_path(self, name, required=False):
            if self.name == name:
                return self.path
            else:
                return None

        def run_command(self, cmd, use_unsafe_shell=False):
            return (self.rc, self.out, self.err)


# Generated at 2022-06-20 17:07:54.017158
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    from ansible.module_utils.facts.collector.aix import AIXHardware
    module = {'run_command': run_command_mock}
    hardware = AIXHardware(module)
    result = hardware.get_cpu_facts()
    assert result == {'processor': 'PowerPC_POWER8', 'processor_cores': 8, 'processor_count': 4}


# Generated at 2022-06-20 17:08:07.973886
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    test_module = AnsibleModule(argument_spec={})
    aix_hw = AIXHardware(test_module)
    # Inject test data
    aix_hw.module.run_command = mock.MagicMock(return_value=(0, 'IBM,8233-E8B fwversion', 0))
    aix_hw.module.get_bin_path = mock.MagicMock(return_value='/usr/sbin/lsconf')
    lsconf_path = aix_hw.module.get_bin_path("lsconf")
    lsconf_path = aix_hw.module.get_bin_path("lsconf")

# Generated at 2022-06-20 17:08:19.668013
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    mod = AnsibleModule({'command': 'lsvg -o | xargs lsvg -p'}, '',
                        True, None)
    cls = AIXHardware()
    cls.module = mod
    cls.get_vgs_facts = types.MethodType(get_vgs_facts, cls)
    cls.run_command = types.MethodType(fake_run_command, cls)
    result = cls.get_vgs_facts()

# Generated at 2022-06-20 17:08:32.879811
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    # define return from lsdev command
    lsdev_content = '''
    hdisk0 Available 0000-00-00-00-00-00
    hdisk1 Available 0000-00-00-00-00-00
    hdisk2 Available 0006-1234-56-78-90-12
    hdisk3 Available 0006-1234-56-78-90-13
    '''

    # define return from lsattr command

# Generated at 2022-06-20 17:08:35.064001
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    facts = AIXHardware()
    mem_facts = facts.get_memory_facts()
    assert mem_facts['memtotal_mb'] > 0
    assert mem_facts['memfree_mb'] > 0
    if 'swaptotal_mb' in mem_facts:
        assert mem_facts['swaptotal_mb'] > 0
        assert mem_facts['swapfree_mb'] > 0

# Generated at 2022-06-20 17:08:36.278891
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hw = AIXHardwareCollector()
    assert hw.platform == 'AIX'

# Generated at 2022-06-20 17:08:43.312500
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    aix_hardware = AIXHardware()
    aix_hardware.module.run_command = run_command_mock_for_get_device_facts

    aix_hardware.get_device_facts()

    for device in aix_hardware.facts['devices']:
        assert aix_hardware.facts['devices'][device]['attributes']['bus_ioaddr'] == '0x10000'
        assert aix_hardware.facts['devices'][device]['attributes']['bus_id'] == '0x20000'
        assert aix_hardware.facts['devices'][device]['attributes']['bus_memaddr'] == '0x30000'

# Generated at 2022-06-20 17:08:50.443894
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    # instantiate the class AIXHardware
    aix_hardware = AIXHardware()
    # assert hardware platform as AIX
    assert aix_hardware.platform == 'AIX'
    # assert hardware has processor and processor_cores attributes
    assert aix_hardware.processor
    assert aix_hardware.processor_cores


# Generated at 2022-06-20 17:08:52.806955
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():

    module = AnsibleModule(argument_spec=dict())
    hardware_obj = AIXHardware(module)

    # Test get_cpu_facts method
    test_obj = hardware_obj.get_cpu_facts()
    assert test_obj['processor_count'] == 2
    assert test_obj['processor'] == 'PowerPC_POWER8'
    assert test_obj['processor_cores'] == 4



# Generated at 2022-06-20 17:09:18.681504
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    '''
    Unit test of method get_device_facts of class AIXHardware
    :return:
    '''
    import ansible.module_utils.facts.hardware.aix

# Generated at 2022-06-20 17:09:20.567836
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    """
    test the AIXHardware method get_cpu_facts
    """
    hardware_facts = AIXHardware()
    result = hardware_facts.get_cpu_facts()
    assert result['processor'] == 'POWER9'
    assert result['processor_cores'] == 2
    assert result['processor_count'] == 2


# Generated at 2022-06-20 17:09:26.576318
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    AIXHardware = AIXHardwareCollector(None).collect()

    assert AIXHardware.memfree_mb
    assert AIXHardware.memtotal_mb
    assert AIXHardware.swapfree_mb
    assert AIXHardware.swaptotal_mb
    assert AIXHardware.processor_count
    assert AIXHardware.processor_cores
    assert AIXHardware.processor_count
    assert AIXHardware.processor_cores


if __name__ == '__main__':
    test_AIXHardware_populate()

# Generated at 2022-06-20 17:09:36.983345
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    fact_subclass = AIXHardware(module)

    # lsdev -Cc processor
    # Get cpu facts
    fact_subclass.module.run_command = Mock(return_value=(0, 'proc0 Available 00-00-4C-00-00-00 Processor', ''))
    fact_subclass.module.run_command = Mock(return_value=(0, 'type PowerPC_POWER8', ''))
    fact_subclass.module.run_command = Mock(return_value=(0, 'smt_threads 1', ''))

    # vmstat -v
    # Get memory facts

# Generated at 2022-06-20 17:09:44.499706
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = type('module', (object,), {'run_command': run_command})
    facts = AIXHardware(module=module)
    assert facts.get_cpu_facts() == {'processor': 'Processor Type: PowerPC_POWER5',
                                     'processor_count': 2,
                                     'processor_cores': 1}



# Generated at 2022-06-20 17:09:51.557003
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    hardware = AIXHardwareCollector(module=module)
    mount_facts = hardware.collect()['mounts']
    assert mount_facts

# Generated at 2022-06-20 17:09:57.405577
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    # use dict for module
    mocked_module = dict()
    # use dict for hardware_object
    mocked_hardware_object = dict()

    # invoke constructor
    AIXHardware_obj = AIXHardware(mocked_module, mocked_hardware_object)
    # make it available as a global
    global module_obj
    module_obj = AIXHardware_obj.module
    # use dict to store command output
    mocked_module_obj = dict()
    mocked_module_obj['run_command'] = dict()
    # use dict to store lsconf output
    mocked_module_obj['run_command']['lsconf'] = dict()
    mocked_module_obj['run_command']['lsattr'] = dict()

# Generated at 2022-06-20 17:10:10.027270
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = DummyModule()
    module.run_command = MagicMock()
    out = 'firmware_version  fwversion       IBM,8233-E8B-SN10A0D6K    \n' \
          'product_serial    mfg_data        1234567890ABCDEF          '
    module.run_command.return_value = 0, out, ''
    hardware = AIXHardware(module)
    my_dmi_facts = hardware.get_dmi_facts()
    assert my_dmi_facts['firmware_version'] == '8233-E8B-SN10A0D6K'
    assert my_dmi_facts['product_serial'] == '1234567890ABCDEF'


# Generated at 2022-06-20 17:10:22.648245
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    hardware = AIXHardware()


# Generated at 2022-06-20 17:10:28.028772
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    hardware = AIXHardware()
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] > 0
    assert cpu_facts['processor'] != ''
    assert cpu_facts['processor_cores'] > 0

# Generated at 2022-06-20 17:11:09.878577
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    result = AIXHardwareCollector()
    assert result.__class__.__name__ == 'AIXHardwareCollector'
    assert result._platform == 'AIX'
    assert result._fact_class == AIXHardware

# Generated at 2022-06-20 17:11:13.848763
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    aix_hw_collector = AIXHardwareCollector()
    assert aix_hw_collector._platform == 'AIX'
    assert aix_hw_collector._fact_class == AIXHardware

# Generated at 2022-06-20 17:11:28.397402
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModuleMock(
        dict(
            command_defaults=dict(
                executable=dict(
                    lsdev='/usr/sbin/lsdev',
                    lsattr='/usr/sbin/lsattr'
                )
            )
        )
    )
    aix_hardware = AIXHardware(module)

    out_lsdev = """
proc0 Available 00-00 Processor
proc1 Available 00-01 Processor
proc2 Available 00-02 Processor
proc3 Available 00-03 Processor
proc4 Available 00-04 Processor
proc5 Available 00-05 Processor
proc6 Available 00-06 Processor
proc7 Available 00-07 Processor
    """

    out_lsattr_proc0 = """
type PowerPC_POWER7
smt_threads 3
"""

# Generated at 2022-06-20 17:11:39.805881
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    mount_facts = AIXHardware()

# Generated at 2022-06-20 17:11:47.033020
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    import datetime

    # Arrange
    AIX_hardware = AIXHardware()

    # Act
    # instance attributes
    platform = AIX_hardware.platform
    hostname = AIX_hardware.hostname
    domain = AIX_hardware.domain
    facts = AIX_hardware.facts
    cloud_provider = AIX_hardware.cloud_provider
    # public methods
    populated = AIX_hardware.populated
    update = AIX_hardware.update

    # Assert
    assert platform == 'AIX'
    assert hostname == 'hostname.domainname'
    assert domain == 'domainname'
    assert facts == {}
    assert cloud_provider == None
    assert populated == False
    assert update == datetime.datetime.now()

# Generated at 2022-06-20 17:11:53.485119
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    aix_hw = AIXHardware(None)
    out_get_memory_facts = aix_hw.get_memory_facts()
    assert out_get_memory_facts['memtotal_mb'] > 2048
    assert out_get_memory_facts['memfree_mb'] > 1024

# Generated at 2022-06-20 17:11:57.743102
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    test_module = AnsibleModule(argument_spec={})
    ah_obj = AIXHardware(module=test_module)
    test_data = ah_obj.populate()
    assert test_data['processor']
    assert test_data['processor_cores']
    assert test_data['processor_count']



# Generated at 2022-06-20 17:12:11.345211
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    class MockModule():
        def __init__(self):
            self.use_unsafe_shell = False
            self.bin_path = {'lsattr': '/usr/sbin/lsattr',
                             'lsconf': '/usr/sbin/lsconf'}
            self.run_command_returns = (0, 'IBM,5406-F80', '')
            self.run_command_run_count = 0

        def run_command(self, cmd, use_unsafe_shell=False):
            self.run_command_run_count += 1
            return self.run_command_returns

        def get_bin_path(self, name, opt_dirs=[]):
            return self.bin_path[name] if name in self.bin_path else None

    m = MockModule()
    h

# Generated at 2022-06-20 17:12:18.961461
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    class ModuleMock(object):
        def __init__(self):
            self.run_command_returns = []
            self.run_command_calls = []
            self.run_command_called = False

        def run_command(self, args):
            self.run_command_calls.append(args)
            return self.run_command_returns.pop(0)

    class FactsMock(object):
        def __init__(self):
            self.hardware = AIXHardware(ModuleMock())

    cpu_facts = FactsMock()

# Generated at 2022-06-20 17:12:21.151199
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    """AIXHardwareCollector is avaiable"""
    assert 'AIX' == AIXHardwareCollector._platform

# Generated at 2022-06-20 17:13:47.664807
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec=dict(filter=dict(type='list', default=[])))
    hardware = AIXHardware(module=module)

    rc = 0

# Generated at 2022-06-20 17:13:56.276625
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    AIXHardware_obj = AIXHardware()

    # test 1
    lsvg_output = 'rootvg: \n' \
                  'STALE PVs: none\n' \
                  'STALE PPs: none\n' \
                  'ACTIVE PVs: 0\n' \
                  'AUTO ON: yes\n' \
                  'MAX LVs: 256\n' \
                  'FREE PPs: 0\n' \
                  'LVs: 0\n' \
                  'USED PPs: 0\n' \
                  'OPEN LVs: 0\n' \
                  'TOTAL PPs: 546\n' \
                  'MAX PPs per VG: 32640\n' \
                  'MAX PVs: 32\n' \
                  'LTG size (Dynamic): 256 KB\n'

# Generated at 2022-06-20 17:14:03.973746
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts.utils import get_file_content
    import os

    # Test file and path of it
    test_file_path = "tests/unittests/test_data/hardware/aix/lsdev"
    lsdev_cmd = "cat " + test_file_path

    # Create input and expected output strings
    lsdev_input = get_file_content(lsdev_cmd)
    lsdev_output = os.linesep.join([s for s in lsdev_input.splitlines() if s.strip()])

    # Test AIXHardware.get_device_facts() method
    test_AIXHardware = AIXHardware(None)
    test_AIXHardware.module = DummyAnsible

# Generated at 2022-06-20 17:14:06.139224
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    assert AIXHardware().platform == 'AIX'


# Generated at 2022-06-20 17:14:08.225154
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    collector = AIXHardwareCollector()
    assert collector._fact_class == AIXHardware

# Generated at 2022-06-20 17:14:17.104835
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.base import get_collector_instance

    dmi_output = """sys0:
        fwversion                 IBM,330
"""
    lsconf_output = """
System Model: IBM,9131-52A
Machine Serial Number: CC06077
LPAR Info: 11
"""

    aix_fact_collector = get_collector_instance(BaseFactCollector, AIXHardware)
    aix_fact_collector.module.run_command = lambda x: (0, dmi_output, None)

# Generated at 2022-06-20 17:14:23.397157
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware = AIXHardware()
    assert hardware.platform == 'AIX'
    assert hardware.get_cpu_facts() == {
        'processor_count': 2,
        'processor': 'PowerPC_POWER6',
        'processor_cores': 2
    }

# Generated at 2022-06-20 17:14:28.146530
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    mounts = hardware.get_mount_facts()['mounts']
    assert len(mounts) > 0
    for mount in mounts:
        assert isinstance(mount['size_total'], int)
        assert isinstance(mount['size_available'], int)


# Generated at 2022-06-20 17:14:38.330968
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = type('_', (), {})()
    module.run_command = lambda x: (0, '', '')
    h = AIXHardware(module)

    # Test get_cpu_facts
    rc, out, err = module.run_command("/usr/sbin/lsdev -Cc processor")
    if out:
        i = 0
        for line in out.splitlines():

            if 'Available' in line:
                if i == 0:
                    data = line.split(' ')
                    cpudev = data[0]

                i += 1
        cpu_facts = h.get_cpu_facts()
        expected = {'processor_count': int(i)}

        rc, out, err = module.run_command("/usr/sbin/lsattr -El " + cpudev + " -a type")

# Generated at 2022-06-20 17:14:46.778523
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    aix_hardware = AIXHardware(module)
    aix_hardware.get_device_facts()
    assert aix_hardware.devices is not None
    assert aix_hardware.devices != {}
