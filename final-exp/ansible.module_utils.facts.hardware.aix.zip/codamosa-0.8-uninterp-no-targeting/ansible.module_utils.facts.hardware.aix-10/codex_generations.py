

# Generated at 2022-06-20 17:07:42.265002
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    fact_collector = AIXHardwareCollector(module, {})
    facts = fact_collector.collect(module, {})
    # test output from facts['dmi_facts']
    assert 'firmware_version' in facts['dmi_facts']
    assert 'product_serial' in facts['dmi_facts']
    assert 'lpar_info' in facts['dmi_facts']
    assert 'product_name' in facts['dmi_facts']
    # test output from facts['vgs_facts']
    assert 'vgs' in facts['vgs_facts']
    # test output from facts['mount_facts']
    assert 'mounts' in facts['mount_facts']
    # test output from facts['devices_facts']

# Generated at 2022-06-20 17:07:46.421885
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    AIXHardwareObject = AIXHardware()
    output = AIXHardwareObject.get_dmi_facts()

    assert 'lpar_info' in output
    assert output['lpar_info'] != ''

# Generated at 2022-06-20 17:07:57.458655
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    class TestAIXModule:
        def __init__(self):
            self.params = None

        def fail_json(self, *args, **kwargs):
            pass

        def get_bin_path(self, *args, **kwargs):
            pass

        def run_command(self, *args, **kwargs):
            return 0, "proc0 Available 00-00 Processor\nproc1 Available 00-01 Processor\nproc2 Available 00-02 Processor\nproc3 Available 00-03 Processor", ""

        def get_platform(self):
            return "AIX"

        def get_distribution(self):
            return "AIX"

    class TestArgs:
        def __init__(self):
            self.module = TestAIXModule()

    hardware = AIXHardware(TestArgs())

# Generated at 2022-06-20 17:07:59.242241
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    l = AIXHardwareCollector()
    assert l.platform == 'AIX'
    assert l._fact_class == AIXHardware


# Generated at 2022-06-20 17:08:08.133375
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModuleMock()
    aix_hardware = AIXHardware(module)

    # Test get_cpu_facts
    rc, out, err = module.run_command("/usr/sbin/lsdev -Cc processor")
    if out:
        i = 0
        for line in out.splitlines():

            if 'Available' in line:
                if i == 0:
                    cpu_dev = line.split(' ')[0]
                i += 1
        cpu_count = i

        rc, out, err = module.run_command("/usr/sbin/lsattr -El " + cpu_dev + " -a type")
        cpu_type = out.split(' ')[1]


# Generated at 2022-06-20 17:08:16.995382
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModuleMock()
    hardware = AIXHardware(module)


# Generated at 2022-06-20 17:08:24.522740
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    cpu_facts = AIXHardware.get_cpu_facts('')
    assert cpu_facts['processor_count'] == 10
    assert cpu_facts['processor'] == 'POWER8'
    assert cpu_facts['processor_cores'] == 4

# Generated at 2022-06-20 17:08:27.460604
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    aix_hardware = AIXHardware({})
    assert aix_hardware.platform == 'AIX'

# Generated at 2022-06-20 17:08:28.298770
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    assert isinstance(AIXHardwareCollector(), AIXHardwareCollector)


# Generated at 2022-06-20 17:08:36.409424
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = MockModule()
    hardware = AIXHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert res['kernel'] == 'Linux'
    assert res['machine_id'] == '1eadda65b37c47dca0b192f3a3be3c3b'
    assert res['system'] == 'Linux'


# Generated at 2022-06-20 17:08:55.802695
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    """
    Constructor test for class AIXHardware
    """
    aix_hw = AIXHardware()
    assert aix_hw.platform == 'AIX'


# Generated at 2022-06-20 17:09:05.699377
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    aixhardware = AIXHardware(dict(module=dict()))

    # Get lsdev command output
    lsdev_cmd = aixhardware.module.get_bin_path('lsdev', True)
    lsattr_cmd = aixhardware.module.get_bin_path('lsattr', True)
    rc, out_lsdev, err = aixhardware.module.run_command(lsdev_cmd)

    # Get hash of device facts
    device_facts = aixhardware.get_device_facts()['devices']

    # Loop on devices lines
    for line in out_lsdev.splitlines():
        field = line.split()
        device_name = field[0]
        device_state = field[1]

# Generated at 2022-06-20 17:09:16.256730
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    # prepare environment
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    # create an instance
    ah = AIXHardware(module=module)

    # prepare the mocks for lsdev

# Generated at 2022-06-20 17:09:28.077042
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    """
    aix_get_mount_facts()
    """
    module = MockModule()

    # the data is taken from 'mount' command
    # from aix 7.1 TL3 SP3

# Generated at 2022-06-20 17:09:37.442653
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    aix_hardware = AIXHardware(module)
    device_facts = aix_hardware.get_device_facts()

    assert 'devices' in device_facts
    assert isinstance(device_facts['devices'], dict)
    assert len(device_facts['devices']) != 0
    for device_name, device in device_facts['devices'].items():
        assert isinstance(device_name, str)
        assert 'state' in device
        assert isinstance(device['state'], str)
        assert 'type' in device
        assert isinstance(device['type'], str)
        assert 'attributes' in device
        assert isinstance(device['attributes'], dict)
        assert len(device['attributes']) != 0



# Generated at 2022-06-20 17:09:48.992503
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})

    hardware_collector = AIXHardwareCollector(module=module)
    hardware = hardware_collector.collect()[0]

    # check cpu facts
    assert hardware.cpu()['processor']
    assert hardware.cpu()['processor_cores']
    assert hardware.cpu()['processor_count']

    # check memory facts
    assert hardware.memory()['memfree_mb']
    assert hardware.memory()['memtotal_mb']
    assert hardware.memory()['swapfree_mb']
    assert hardware.memory()['swaptotal_mb']

    # check dmi facts
    assert hardware.dmi()['firmware_version']
    assert hardware.dmi()['product_name']
    assert hardware.dmi()['product_serial']
    assert hardware.dmi

# Generated at 2022-06-20 17:10:00.971917
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    test_data = '''rootvg:
PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
hdisk0            active            546         0           00..00..00..00..00
hdisk1            active            546         113         00..00..00..21..92
realsyncvg:
PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
hdisk74           active            1999        6           00..00..00..00..06
testvg:
PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
hdisk105          active            999         838         200..39..199..200..200
hdisk106          active            999         599         200..00..00..199..200'''

# Generated at 2022-06-20 17:10:09.814979
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    class FakeModule:
        def __init__(self, return_value):
            self.return_value = return_value
            self.run_command_calls = 0
            self.args = None

        def run_command(self, args, use_unsafe_shell=False):
            self.args = args
            self.run_command_calls += 1
            return self.return_value[self.run_command_calls - 1]

    class FakeStream:
        def __init__(self, return_values):
            self.return_values = return_values
            self.readlines_calls = 0

        def readlines(self):
            self.readlines_calls += 1
            return self.return_values[self.readlines_calls - 1]

    # Test when vmstat returns non zero value and ls

# Generated at 2022-06-20 17:10:13.812960
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hc = AIXHardwareCollector()
    assert hc.platform == 'AIX'
    assert hc._fact_class == AIXHardware


# Generated at 2022-06-20 17:10:16.550201
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    hardware_facts = AIXHardware()

    data = hardware_facts.get_device_facts()

    assert data is not None

# Generated at 2022-06-20 17:10:46.219112
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    mock_module = type('', (), {})
    mock_module.run_command = lambda x: [0, '', '']
    mock_module.get_bin_path = lambda x: ''
    mock_hw = AIXHardware(mock_module)
    facts = mock_hw.populate()
    assert facts['processor_count'] == 1
    assert facts['processor'] == ''
    assert facts['processor_cores'] == 0
    assert facts['memtotal_mb'] == 0
    assert facts['memfree_mb'] == 0
    assert facts['swaptotal_mb'] == 0
    assert facts['swapfree_mb'] == 0
    assert facts['firmware_version'] == ''
    assert facts['product_serial'] == ''
    assert facts['lpar_info'] == ''

# Generated at 2022-06-20 17:10:57.330765
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    import json
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts.utils import get_mount_size
    module = AnsibleModule(
        argument_spec=dict(),
    )
    mountcmd_path = module.get_bin_path("mount")

# Generated at 2022-06-20 17:11:06.848895
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = FakeModule()

    aix_hardware = AIXHardware(module=module)
    module.run_command = FakeCommand().run_command
    vgs_facts = aix_hardware.get_vgs_facts()


# Generated at 2022-06-20 17:11:17.461447
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    import ansible.module_utils.facts.hardware.aix as aixmod
    import ansible.module_utils.facts.utils as utilsmod
    origin_get_mount_size = utilsmod.get_mount_size
    origin_run_command = aixmod.AIXHardware.module.run_command
    origin_get_bin_path = aixmod.AIXHardware.module.get_bin_path


# Generated at 2022-06-20 17:11:30.714610
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    import sys
    import os
    import unittest
    class AnsibleModuleMock(object):
        def __init__(self, **kwargs):
            self.run_command_args = [kwargs['cmd']]
            if 'use_unsafe_shell' in kwargs:
                self.run_command_kwargs = {'use_unsafe_shell': True}
            else:
                self.run_command_kwargs = {}
            
        def run_command(self, cmd, **kwargs):
            if self.run_command_args[0] == cmd:
                if kwargs == self.run_command_kwargs:
                    if cmd == '/usr/bin/vmstat -v' and 'memory pages' in vmstatv_output and 'free pages' in vmstatv_output:
                        return 0

# Generated at 2022-06-20 17:11:41.524701
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    import mock
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.hardware.aix import AIXHardwareCollector

    mock_module = mock.MagicMock()
    mock_fact_class = mock.MagicMock()

    # Check without setting the _platform. Should fail
    mock_fact_class.platform = None
    with mock.patch.dict(collector.FactCollector._fact_classes, {'AIXHardware': mock_fact_class}):
        with mock.patch.object(BaseFactCollector, '__init__', lambda self, module=mock_module: None):
            with pytest.raises(Exception) as excinfo:
                AIXHardwareCollector(mock_module)

# Generated at 2022-06-20 17:11:53.053307
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    class MockModule(object):
        def __init__(self):
            self.params = {}

        def run_command(self, cmd):
            if cmd == "/usr/bin/vmstat -v":
                out = self.lsdev_cmd_out
            else:
                out = self.lsattr_cmd_out

            return 0, out, ''

        def get_bin_path(self, arg, required=False):
            return "/bin/%s" % arg

    mock_obj = MockModule()
    mock_obj.lsdev_cmd_out = '''
    memory pages     :     2062000
    memory page size :        4096
    free pages       :         940
    '''
    ah = AIXHardware(mock_obj)

    facts_memory = ah.get_memory_facts()

    assert facts

# Generated at 2022-06-20 17:12:01.111420
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    mod = AnsibleModule(argument_spec={})

    mock_get_bin_path = MagicMock(return_value='/usr/bin/vmstat')
    mod.get_bin_path = mock_get_bin_path

    mock_run_command = MagicMock(return_value=(0, 'procs   memory     page                    disks     faults     cpu r b w          pinned               \n'
                                                     'r  b   avm   fre  re  pi  po  fr   sr w0 w1  in   sy  cs us sy id wa pc ec ht ig  \n'
                                                     '2  0  9762 145456   0   0   0   0   0  0  0 4007 3666 87 0  0 100 0  0  0  0  0   \n', ''))
    mod.run_command

# Generated at 2022-06-20 17:12:12.143326
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    data = [
        {"stderr": None, "exit_status": 0, "stdout": "100 memory pages\n100 free pages\n100 pinned pages\n"},
        {"stderr": None, "exit_status": 0, "stdout": "0 memory pages\n0 free pages\n0 pinned pages\n"},
        {"stderr": None, "exit_status": 0, "stdout": "1024 memory pages\n0 free pages\n0 pinned pages\n"},
        {"stderr": None, "exit_status": 0, "stdout": "2048 memory pages\n1024 free pages\n0 pinned pages\n"}
    ]

    for test_data in data:
        ah = AIXHardware()
        test_mem_facts = ah.get_memory_facts()
        assert ah.get_memory_facts

# Generated at 2022-06-20 17:12:24.331333
# Unit test for constructor of class AIXHardwareCollector

# Generated at 2022-06-20 17:13:12.801635
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    result = AIXHardware(module).get_vgs_facts()

# Generated at 2022-06-20 17:13:25.274439
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():

    class MockModule(object):
        def __init__(self, lsconf_path=None, lsvg_path=None, xargs_path=None, lsdev_path=None, lsattr_path=None, mount_path=None, run_command=None):
            self.lsconf_path = lsconf_path
            self.lsvg_path = lsvg_path
            self.xargs_path = xargs_path
            self.lsdev_path = lsdev_path
            self.lsattr_path = lsattr_path
            self.mount_path = mount_path
            self.run_command = run_command

        def get_bin_path(self, cmd, required=False):
            if cmd == "lsconf":
                return self.lsconf_path

# Generated at 2022-06-20 17:13:30.254754
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector.get_platform() == 'AIX'
    assert isinstance(hardware_collector.get_fact_class(), AIXHardware)


# Generated at 2022-06-20 17:13:32.804459
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    obj = AIXHardwareCollector()
    assert obj.platform == "AIX"
    assert obj.fact_class == AIXHardware


# Generated at 2022-06-20 17:13:47.093293
# Unit test for method get_device_facts of class AIXHardware

# Generated at 2022-06-20 17:13:59.254161
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    """
    Test case to verify get_vgs_facts method of AIXHardware class
    """

# Generated at 2022-06-20 17:14:06.010588
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    class module_mock(object):
        args = {}
        params = {}

# Generated at 2022-06-20 17:14:15.007778
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    harware_obj = AIXHardware(module)
    collected_facts = {
        'ansible_system': 'AIX',
        'ansible_machine': 'ppc64',
    }
    gathered_facts = harware_obj.populate(collected_facts=collected_facts)
    assert gathered_facts['ansible_processor'] == ['PowerPC_POWER8']
    assert gathered_facts['ansible_processor_cores'] == 1
    assert gathered_facts['ansible_processor_count'] == 4



# Generated at 2022-06-20 17:14:21.350907
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    mod = AnsibleModule(argument_spec={}, supports_check_mode=True)
    collector = AIXHardwareCollector(module=mod)
    assert collector._platform == "AIX"
    assert collector._fact_class.platform == "AIX"


# Generated at 2022-06-20 17:14:28.438799
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    ansible_module_mock = AnsibleModuleMock({})
    ansible_module_mock.run_command = MagicMock(return_value=(0, 'IBM,8233-E8B fwversion', ''))
    facts_module_mock = AIXHardware(ansible_module_mock)
    facts = facts_module_mock.get_dmi_facts()
    assert facts['firmware_version'] == '8233-E8B'


# Generated at 2022-06-20 17:15:46.060692
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    aix_test_data = {
        'dmi_facts': {'firmware_version': 'IBM,ES132',
                      'lpar_info': '1 B1B-VM',
                      'product_name': 'IBM,8286-41A',
                      'product_serial': 'FCE1234'},
        'cpu_facts': {'processor': 'PowerPC_POWER8',
                      'processor_cores': 8,
                      'processor_count': 1},
        'memory_facts': {'memfree_mb': 7659,
                         'memtotal_mb': 7811,
                         'swapfree_mb': 7903,
                         'swaptotal_mb': 7903}}

    aixhw = Hardware()
    aixhw.populate()
    assert aixhw.populate() == aix

# Generated at 2022-06-20 17:15:55.220666
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = DummyModule()
    aix_hardware = AIXHardware(module)
    aix_hardware.get_mount_facts()


# Generated at 2022-06-20 17:16:06.262654
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={})
    result = {}

    # Prepare test data for constructor of class AIXHardware
    test_obj = AIXHardware(module)
    result['processor_count'] = test_obj.processor_count
    result['processor'] = test_obj.processor
    result['processor_cores'] = test_obj.processor_cores
    result['memtotal_mb'] = test_obj.memtotal_mb
    result['memfree_mb'] = test_obj.memfree_mb
    result['swaptotal_mb'] = test_obj.swaptotal_mb
    result['swapfree_mb'] = test_obj.swapfree_mb
    result['firmware_version'] = test_obj.firmware_version
    result['product_serial'] = test_obj.product_

# Generated at 2022-06-20 17:16:15.696708
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    test_out = """
    sys0 Available 00-00
    proc0 Available 00-00
    proc4 Available 00-00
    """
    module = AnsibleModule(argument_spec={})
    module.run_command = Mock(return_value=(0, test_out, None))
    ah = AIXHardware(module)
    ah = ah.populate()
    assert ah['processor_count'] == 2
    assert ah['memtotal_mb'] > 0
    assert ah['memfree_mb'] > 0



# Generated at 2022-06-20 17:16:27.982649
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    lsconf_path = module.get_bin_path("lsconf")
    lsvg_path = module.get_bin_path("lsvg")
    xargs_path = module.get_bin_path("xargs")

    if lsconf_path is None:
        module.fail_json(msg="lsconf not found")
    if lsvg_path is None:
        module.fail_json(msg="lsvg not found")
    if xargs_path is None:
        module.fail_json(msg="xargs not found")

    vgs_facts = {}
    cmd = "%s -o | %s %s -p" % (lsvg_path, xargs_path, lsvg_path)

# Generated at 2022-06-20 17:16:38.889279
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():

    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts import collector

    aixHardware = AIXHardware()
    collector.sys_facts['hardware'] = aixHardware


# Generated at 2022-06-20 17:16:45.431991
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-20 17:16:48.750412
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    hardware = AIXHardware()

    # Create a test case data structure which looks like the original "out"
    out = '''fwversion            IBM,9117-MMB   Software attribute
    '''
    hardware.module.run_command = mock_run_command(out)

    # Execute get_dmi_facts under test:
    dmi_facts = hardware.get_dmi_facts()
    assert 'firmware_version' in dmi_facts
    assert dmi_facts['firmware_version'] == '9117-MMB'



# Generated at 2022-06-20 17:16:55.368256
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module, {})
    mem_facts = hardware.get_memory_facts()
    assert mem_facts['memtotal_mb'] > 0
    assert mem_facts['memfree_mb'] < mem_facts['memtotal_mb']

# Generated at 2022-06-20 17:16:58.764089
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    # Test for creating object of class AIXHardwareCollector
    # check that the instance is created and platform is set
    # to AIX
    aix_hardware_collector = AIXHardwareCollector()
    assert aix_hardware_collector._platform == 'AIX'