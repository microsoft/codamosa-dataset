

# Generated at 2022-06-20 17:07:47.986906
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    # build a fake module for this unit test.
    module = AnsibleModule(
        argument_spec = dict(), # empty spec
        supports_check_mode = True
        )
    hardware_obj = AIXHardware(module)

    class Bunch(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    class MockModule:
        def __init__(self):
            self.get_bin_path = Bunch(return_value='lsconf')


    old_module = hardware_obj.module
    hardware_obj.module = MockModule()
    rc, out, err = hardware_obj.module.get_bin_path.side_effect = Bunch(return_value='lsconf')
    rc, out, err = hardware_obj.module.run_command.side

# Generated at 2022-06-20 17:07:55.230815
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(
        argument_spec={
        }
    )

    harware = AIXHardware(module)

    device_facts = harware.get_device_facts()

    if not isinstance(device_facts, dict):
        module.fail_json(msg="device_facts is not a dict type.")

    if "devices" not in device_facts.keys():
        fail_msg = "devices is missing from device facts."
        module.fail_json(msg=fail_msg)



# Generated at 2022-06-20 17:07:59.230055
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    assert AIXHardware().get_dmi_facts()["firmware_version"] == "IBM,8247-22L"


# Generated at 2022-06-20 17:08:01.971017
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware_obj = AIXHardware(dict())
    assert hardware_obj.platform == 'AIX'


# Generated at 2022-06-20 17:08:08.008614
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.hardware.aix import AIXHardware

    class DefaultFactsCollector(FactsCollector):
        def __init__(self):
            self.collectors = default_collectors

    test_fact_collector = DefaultFactsCollector()
    test_AIXHardware = AIXHardware(test_fact_collector)

# Generated at 2022-06-20 17:08:09.429475
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    aix_info = AIXHardwareCollector()
    assert aix_info._fact_class.platform == 'AIX'


# Generated at 2022-06-20 17:08:17.333972
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    class HardwareExecuteModule:
        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            if args == ["/usr/sbin/lsdev", "-Cc", "processor"]:
                return 0, "proc0 Available 01-00 Processors\nproc4 Available 05-00 Processors", ""
            if args == ["/usr/sbin/lsattr", "-El", "proc0", "-a", "smt_threads"]:
                return 0, "smt_threads  2", ""
            if args == ["/usr/sbin/lsattr", "-El", "proc0", "-a", "type"]:
                return 0, "type PowerPC_POWER8", ""


# Generated at 2022-06-20 17:08:24.131878
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    aix_hardware_collector = AIXHardwareCollector()
    assert aix_hardware_collector
    assert aix_hardware_collector._platform == 'AIX'
    assert aix_hardware_collector._fact_class == AIXHardware

# Generated at 2022-06-20 17:08:34.211351
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    """ Test method get_mount_facts of class AIXHardware """
    module = MockModule()
    hardware = AIXHardware(module)
    # Create file with content of "mount" command
    with open("mount_aix", "w") as f:
        f.write('node     mounted        mounted over    vfs   date        time options\n')
        f.write('--------------- --------------- --------------- ----- ---------- -----\n')
        f.write('/dev/hd4        /               jfs2   04/04/2018 07:19 rw,log=/dev/hd8\n')
        f.write('/dev/hd2        /usr            jfs2   04/04/2018 07:19 rw,log=/dev/hd8\n')

# Generated at 2022-06-20 17:08:42.349121
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = type('NativeAnsibleModule', (object,), {'run_command': run_command})
    module.get_bin_path = get_bin_path
    ahw = AIXHardware(module)
    ahw.populate()

# Generated at 2022-06-20 17:09:08.100559
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    assert hardware.platform == 'AIX'
    assert hardware.get_memory_facts()['memtotal_mb'] > 0
    assert hardware.get_cpu_facts()['processor_count'] > 0

# Generated at 2022-06-20 17:09:17.175747
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    """
    Unit test for method get_mount_facts and get_mount_size of class AIXHardware
    """
    import platform
    import StringIO
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.basic import AnsibleModule

    class DummyModule(object):
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, executable, required=False):
            if executable == 'mount':
                return mount_path
            if executable == 'df':
                return df_path
            if executable == 'lsvg':
                return lsvg_path
            if executable == 'xargs':
                return xargs_path

# Generated at 2022-06-20 17:09:28.137841
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():

    module_mock = Mock()
    module_mock.get_bin_path.return_value = True
    module_mock.run_command.return_value = (0, 'fcs0 Available 0-08-00-2,0\ncciss0 Available IBM,17126\nfcs1 Available 0-08-01-2,0\ncciss1 Available IBM,17126', '')

    aix_hardware = AIXHardware(module_mock)


# Generated at 2022-06-20 17:09:32.008012
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    """
    Testing AIXHardware.get_memory_facts
    """
    test_module = type('', (), {})()
    test_module.run_command = lambda *args, **kwargs: (0, 'memory pages:   851938\nfree pages:     847608\n', '')
    _hw = AIXHardware(module=test_module)
    meminfo = _hw.get_memory_facts()
    assert 'memtotal_mb' in meminfo
    assert 'memfree_mb' in meminfo



# Generated at 2022-06-20 17:09:34.772780
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    collector = AIXHardwareCollector()
    assert collector.platform == 'AIX'
    assert collector.fact_class == AIXHardware


# Generated at 2022-06-20 17:09:46.069033
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    ARGS = {
        'ANSIBLE_MODULE_ARGS': {
        },
    }

    RESULT = {
        'processor': ['PowerPC_POWER8'],
        'processor_cores': 8,
        'processor_count': 2,
    }

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    hardware = AIXHardware(module=module)

    cpu_facts = hardware.get_cpu_facts()

    module.exit_json(changed=False, ansible_facts=dict(hardware=cpu_facts))



# Generated at 2022-06-20 17:09:52.187246
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector_test = AIXHardwareCollector()
    assert hardware_collector_test.platform == 'AIX'
    assert hardware_collector_test.fact_class == AIXHardware

# Generated at 2022-06-20 17:09:53.774803
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    assert AIXHardware().platform == 'AIX'

# Generated at 2022-06-20 17:09:56.500701
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    obj = AIXHardwareCollector()
    assert obj._platform == 'AIX'
    assert obj._fact_class == AIXHardware


# Generated at 2022-06-20 17:10:10.464380
# Unit test for method get_memory_facts of class AIXHardware

# Generated at 2022-06-20 17:10:51.945739
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={})
    hardware_obj = AIXHardware(module)
    assert hardware_obj.populate() is not None

# Generated at 2022-06-20 17:11:05.216794
# Unit test for method get_device_facts of class AIXHardware

# Generated at 2022-06-20 17:11:17.046960
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    """
    Test method populate of AIXHardware.
    """

    # Create a dummy module and class name
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)

    class_name = 'AIXHardware'
    check_class = 'Hardware'

    # Initialize the class
    aix_facts_class = globals()[class_name](module)

    # Call the method populate
    aix_facts_class.populate()

    # Test the method populate
    assert hasattr(aix_facts_class, 'platform') == True
    assert aix_facts_class.platform == 'AIX'

    # Test the attributes of class AIXHardware

# Generated at 2022-06-20 17:11:30.602611
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    """
    Test the get_vgs_facts method
    """

    test_module = MockAnsibleModule(platform='AIX')
    test_module.run_command.return_value = (0, TEST_AIX_LSVG_OUT, '')

    test_instance = AIXHardware()

    vgs_facts = test_instance.get_vgs_facts()

    test_module.run_command.assert_called_once_with('lsvg -o | xargs lsvg -p', use_unsafe_shell=True)


# Generated at 2022-06-20 17:11:36.399680
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule({})
    result = AIXHardware(module).get_dmi_facts()
    assert 'firmware_version' in result
    assert 'lpar_info' in result
    assert 'product_name' in result
    assert 'product_serial' in result


# Generated at 2022-06-20 17:11:47.991186
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})

    ah = AIXHardware(module=module)

    vgs_facts = ah.get_vgs_facts()

    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs_facts['vgs']['rootvg'][1]['free_pps'] == '113'
    assert vgs_facts['vgs']['testvg'][0]['pp_size'] == '4 megabyte(s)'



# Generated at 2022-06-20 17:11:58.820484
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(gather_subset=dict(default=['!all'], type='list')))

    ### GIVEN ###
    test_subset = ['memory', 'cpu']
    AIXHardwareCollector.gather_subset = test_subset
    ahw = AIXHardwareCollector(module)

    ### WHEN ###
    ahw.populate()

    ### THEN ###
    assert ahw.ahw.gather_subset == test_subset
    assert set(ahw.ahw.populated_facts.keys()) == set(test_subset)

# Generated at 2022-06-20 17:12:09.993246
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModuleMock()
    module.run_command = AnsibleModuleMock.run_command_mock

    aixhardware = AIXHardware(module)
    out = aixhardware.get_dmi_facts()

    assert out['firmware_version'] == "07C7821"
    assert out['product_serial'] == "TAA0391443"
    assert out['lpar_info'] == "1 CECModel:2964-A7"
    assert out['product_name'] == "IBM,8286-41A"



# Generated at 2022-06-20 17:12:23.756277
# Unit test for method get_mount_facts of class AIXHardware

# Generated at 2022-06-20 17:12:25.273926
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    pass

# Generated at 2022-06-20 17:13:52.161105
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    test_module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    test_AIX_hardware_class = AIXHardware(test_module)
    fact_from_method = test_AIX_hardware_class.get_vgs_facts()

    assert fact_from_method['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert fact_from_method['vgs']['rootvg'][1]['pv_name'] == 'hdisk1'
    assert fact_from_method['vgs']['testvg'][0]['pv_name'] == 'hdisk105'

# Generated at 2022-06-20 17:14:03.989952
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={'gather_subset': dict(type='list', default=['all']),
                                          'filter': dict(type='list', default=['*'])})
    if not HAS_AIX:
        module.fail_json(msg='AIX facts module requires AIX')

    hardware = AIXHardware(module)
    result = hardware.populate()

    assert result['memfree_mb'] == hardware.get_memory_facts()['memfree_mb']
    assert result['memtotal_mb'] == hardware.get_memory_facts()['memtotal_mb']
    assert result['swapfree_mb'] == hardware.get_memory_facts()['swapfree_mb']

# Generated at 2022-06-20 17:14:07.140855
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_obj = AIXHardwareCollector()
    assert hardware_obj._platform == 'AIX'
    assert hardware_obj._fact_class == AIXHardware

# Generated at 2022-06-20 17:14:16.840868
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    from ansible.module_utils.facts import Collector

    c = Collector()
    facts_obj = AIXHardware(c)

    #Test vmstat output
    vmstat_out = "kthr     memory              page              faults              cpu\n r b w   avm   fre  re  pi  po  fr   sr w0  w1  w2  w3  in   sy  cs us sy id wa\n 0 0 0 1890239 628143  0   0   0   0     0  0   0   0   0   622  488  333 0  0 100 0\n"
    out = "memory pages:9988049"
    out1 = "free pages:8"


# Generated at 2022-06-20 17:14:28.872939
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    test_class = AIXHardware()

# Generated at 2022-06-20 17:14:31.402369
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    test_class = AIXHardware()
    facts = test_class.populate()


# Generated at 2022-06-20 17:14:39.457430
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    """Unit tests for method 'get_dmi_facts' of class AIXHardware."""
    import os

    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts.hardware.base import Hardware, HardwareCollector
    from ansible.module_utils._text import to_bytes

    class FakeModule(object):

        def __init__(self, bin_path='/bin/ls'):
            self.params = {'gather_subset': '!all'}
            self.bin_path = bin_path

        def get_bin_path(self, app, required=False):
            return self.bin_path


# Generated at 2022-06-20 17:14:45.225358
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    # We cannot use mock_module_helper() from ansible/test/unit/module_utils/facts/test_facts.py
    # because the returned mocked module contains a lot of stub functions
    from ansible.module_utils.facts import Plugins
    from ansible.module_utils.facts.hardware.aix import AIXHardwareCollector
    plugin = AIXHardwareCollector()
    result = plugin.get_facts({}, Plugins(), {})

    assert result['firmware_version'] == '8.00'
    assert result['product_serial'] == '1234567890'
    assert result['lpar_info'] == '12345'
    assert result['product_name'] == 'IBM,8203-E4A'


test_AIXHardware_get_dmi_facts()

# Generated at 2022-06-20 17:14:53.435087
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = FakeAnsibleModule()
    aixhw = AIXHardware(module)
    expected_mem_total_size = 2264
    expected_mem_free_size = 2142
    expected_mem_swap_total_size = 314368
    expected_mem_swap_free_size = 0
    mem_facts = aixhw.get_memory_facts()
    assert mem_facts['memtotal_mb'] == expected_mem_total_size
    assert mem_facts['memfree_mb'] == expected_mem_free_size
    assert mem_facts['swaptotal_mb'] == expected_mem_swap_total_size
    assert mem_facts['swapfree_mb'] == expected_mem_swap_free_size


# Generated at 2022-06-20 17:14:58.097882
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    vgs_facts = hardware.get_vgs_facts()
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk2'