

# Generated at 2022-06-20 17:07:42.625712
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    """ Test of AIXHardware method get_device_facts """
    module = AnsibleModule(argument_spec={})

    # get_device_facts is using lsdev command and lsdev command is present by default on AIX
    if module.get_bin_path('lsdev') is None:
        module.fail_json(msg="Ansible Module AIXHardware get_device_facts unit test needs 'lsdev' command")


# Generated at 2022-06-20 17:07:54.765406
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = MockModule()
    hardware = AIXHardware(module=module)

    # return code of command is 0 and output of command is not empty
    lsdev_rc = 0
    lsdev_out = '''processor 0 Available 00-00 Processor
processor 1 Available 00-00 Processor
processor 2 Available 00-00 Processor'''
    lsdev_err = ''
    module.run_command.return_value = (lsdev_rc, lsdev_out, lsdev_err)

    # return code of command is 0 and output of command is not empty
    lsattr_rc = 0
    lsattr_out = "type PowerPC_POWER8"
    lsattr_err = ''
    module.run_command.return_value = (lsattr_rc, lsattr_out, lsattr_err)

    # return code of command is 0 and output

# Generated at 2022-06-20 17:08:00.969509
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module_mock = AnsibleModuleMock()

    # Create test object
    aix_hw = AIXHardware(module_mock)
    assert aix_hw.module == module_mock
    assert aix_hw.platform == 'AIX'



# Generated at 2022-06-20 17:08:06.531099
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():

    hardware = AIXHardware({})
    hardware.module = type('obj', (object,), {'run_command': run_command})

    hardware.populate()

    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['processor'] == 'POWER8'
    assert hardware.facts['processor_cores'] == 8
    assert hardware.facts['memtotal_mb'] == 983920
    assert hardware.facts['memfree_mb'] == 1882
    assert hardware.facts['swaptotal_mb'] == 327580
    assert hardware.facts['swapfree_mb'] == 327438

# Generated at 2022-06-20 17:08:19.491907
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = MagicMock()


# Generated at 2022-06-20 17:08:31.875353
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():

    # Create a test class instance
    test_AIXHW = AIXHardware()

    # Mock the run_command method of class AIXHardware
    test_AIXHW.module.run_command = lambda x: (0,'%s' % x, '')
    # Capture the output of get_mount_facts method for test class instance
    get_mount_facts_out = test_AIXHW.get_mount_facts()
    # Check the output for type dict and presence of key mounts
    assert isinstance(get_mount_facts_out, dict)
    assert get_mount_facts_out.has_key('mounts')
    assert not get_mount_facts_out.has_key('error')

# Generated at 2022-06-20 17:08:38.447529
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware = AIXHardware(dict())
    assert hardware.platform == 'AIX'

    if hardware.lsdev_path is None or hardware.lsattr_path is None:
        try:
            hardware._find_bin_file("lsdev")
            hardware._find_bin_file("lsattr")
        except Exception:
            assert False

# Generated at 2022-06-20 17:08:43.311735
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
      mod = AnsibleModule({})
      hw = AIXHardware(mod)
      mounts = hw.get_mount_facts()
      assert mounts['mounts'] != []

# Generated at 2022-06-20 17:08:52.343296
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec=dict())
    # create an object of class AIXHardware
    obj = AIXHardware(module)
    facts = obj.populate()
    assert 'mounts' in facts
    assert 'memfree_mb' in facts
    assert 'memtotal_mb' in facts
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'swapfree_mb' in facts
    assert 'swaptotal_mb' in facts


# Generated at 2022-06-20 17:08:57.917150
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector_instance = AIXHardwareCollector()

    assert(hardware_collector_instance._platform == 'AIX')
    assert(hardware_collector_instance._fact_class == AIXHardware)



# Generated at 2022-06-20 17:09:19.244157
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = DummyModule()
    facts = AIXHardware(module).get_dmi_facts()
    assert facts['lpar_info'] == '1 CEC(s)'
    assert facts['firmware_version'] == '2.11.0'


# Generated at 2022-06-20 17:09:23.694752
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec=dict(
        ))
    hw = AIXHardware(module)
    cpu_facts = hw.get_cpu_facts()
    assert type(cpu_facts) is dict
    assert type(cpu_facts['processor']) is list
    assert type(cpu_facts['processor_cores']) is int
    assert type(cpu_facts['processor_count']) is int


# Generated at 2022-06-20 17:09:36.168636
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = MockOrderableModule()
    aix_hardware = AIXHardware(module=module)

    # Snippet of output of 'lsdev' command
    lsdev_out = "hdisk1 Available 03-08-01         Virtual SCSI Disk Drive"

    # Snippet of output of command 'lsattr -E -l hdisk1'
    lsattr_out = "algorithm enhanced\n" \
                 "auto_scrub         yes\n" \
                 "clr_q             yes\n" \
                 "device_type        8mm\n" \
                 "......" \

    rc = 0
    err = ''
    module.run_command.return_value = (rc, lsdev_out, err)
    rc = 0
    err = ''

# Generated at 2022-06-20 17:09:48.524145
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    fake_module = type('', (), {})()
    fake_module.run_command = lambda x: (0, '', '')

    hw_obj = AIXHardware(fake_module)
    hw_obj.populate()

    assert hw_obj.platform == 'AIX'
    assert hw_obj.firmware_version == 'IBM,7200-02-02-1418'
    assert hw_obj.product_serial == '12345'
    assert hw_obj.product_name == 'IBM,7000'
    assert hw_obj.lpar_info == 'none'
    assert hw_obj.memtotal_mb == 10
    assert hw_obj.memfree_mb == 9
    assert hw_obj.swaptotal_mb == 10
    assert hw_

# Generated at 2022-06-20 17:09:51.553107
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)


# Generated at 2022-06-20 17:10:00.644222
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    memory_facts = AIXHardware.get_memory_facts(None)
    assert isinstance(memory_facts, dict)
    assert 'memfree_mb' in memory_facts
    assert 'memtotal_mb' in memory_facts
    assert 'swapfree_mb' in memory_facts
    assert 'swaptotal_mb' in memory_facts
    assert isinstance(memory_facts['memfree_mb'], int)
    assert isinstance(memory_facts['memtotal_mb'], int)
    assert isinstance(memory_facts['swapfree_mb'], int)
    assert isinstance(memory_facts['swaptotal_mb'], int)


# Generated at 2022-06-20 17:10:09.447116
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    class AIXHardwareTest:
        def __init__(self):
            self.params = {}
            self.module = self
            self.bin_path = '/usr/bin'

        def get_bin_path(self, cmdname, opt_dirs=[]):
            return "/usr/bin/%s" % cmdname

        def run_command(self, cmd, use_unsafe_shell=False):
            return (0, vg_info, None)


# Generated at 2022-06-20 17:10:12.750097
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    x = AIXHardwareCollector()
    assert x.platform == 'AIX'
    assert x._fact_class == AIXHardware

# Generated at 2022-06-20 17:10:16.845541
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector._platform == 'AIX'
    assert hardware_collector._fact_class == AIXHardware

# Generated at 2022-06-20 17:10:25.077358
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    """
    Test method populate of class AIXHardware
    """
    import sys
    import os
    import ansible.module_utils.facts.hardware.aix as haix
    from ansible.module_utils.facts import ModuleFacts

    test_dir = os.path.dirname(os.path.dirname(__file__))
    sys.path.insert(0, test_dir)

    module = ModuleFacts(argument_spec={})
    module._use_safe_shell = False
    module.run_command = run_command
    module.get_bin_path = get_bin_path

    haix.Hardware.module = module


# Generated at 2022-06-20 17:10:57.001317
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    results = hardware.populate()

    assert len(results['processor']) > 0
    assert results['processor_cores'] > 0
    assert results['processor_count'] > 0
    assert results['memtotal_mb'] > 0
    assert results['memfree_mb'] > 0
    assert results['swaptotal_mb'] > 0
    assert results['swapfree_mb'] > 0
    assert results['firmware_version'] == "IBM,1A7F"
    assert results['product_serial'] == '00000000'
    assert results['lpar_info'] == "1 127.0.0.1 AIX esxi7"
    assert results['product_name'] == "PowerNV 8001-22C"



# Generated at 2022-06-20 17:11:06.650935
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    """
    This function unit tests method get_mount_facts.
    """
    class AIXHardware_Mock():
        """ simply a mock class to facilitate unit testing"""
        def __init__(self, module):
            self.module = module
        def get_mount_facts(self):
            return AIXHardware.get_mount_facts(self)
        def get_bin_path(self, path, opt_dirs=[]):
            return module.get_bin_path(path, opt_dirs=opt_dirs)
        def run_command(self, cmd):
            return module.run_command(cmd)

    class AnsibleModule_Mock():
        """ simply a mock class to facilitate unit testing"""
        def __init__(self):
            self.params = {}
            self.tmpdir = "/tmp"
       

# Generated at 2022-06-20 17:11:17.259431
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = MagicMock()
    module.get_bin_path.return_value = "/usr/sbin/lsconf"
    hardware = AIXHardware(module)

# Generated at 2022-06-20 17:11:21.730922
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    aix_hardware = AIXHardware()
    assert aix_hardware.platform == 'AIX'



# Generated at 2022-06-20 17:11:26.718610
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    """
    This test functions to test methods of class AIXHardware.
    """
    import ansible.module_utils.facts.hardware.aix
    print(ansible.module_utils.facts.hardware.aix.AIXHardware().get_device_facts())

# Generated at 2022-06-20 17:11:32.477121
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    """
    Unit test for method get_mount_facts of class AIXHardware
    """
    module = FakeModule()
    ah = AIXHardware(module)
    ah.get_mount_facts()



# Generated at 2022-06-20 17:11:42.458024
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    from ansible_collections.ansible.community.tests.unit.compat.mock import MagicMock
    from ansible_collections.ansible.community.tests.unit.modules.utils import set_module_args

    mod = MagicMock()
    mod.get_bin_path = MagicMock(return_value='/usr/bin/lsdev')
    mod.run_command = MagicMock(return_value = (0, '', ''))

    set_module_args(dict(
        gather_subset='all'
    ))

    AIXHardware = AIXHardwareCollector(mod).collect()[0]

# Generated at 2022-06-20 17:11:54.475528
# Unit test for method get_mount_facts of class AIXHardware

# Generated at 2022-06-20 17:11:58.641610
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert 'processor' in cpu_facts
    assert 'processor_count' in cpu_facts
    assert 'processor_cores' in cpu_facts


# Generated at 2022-06-20 17:12:09.715843
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    m = AIXHardware({})
    vgs_facts = m.get_vgs_facts()
    assert len(vgs_facts) == 1
    assert 'vgs' in vgs_facts
    assert len(vgs_facts['vgs']) == 3
    assert len(vgs_facts['vgs']['realsyncvg']) == 1
    assert len(vgs_facts['vgs']['testvg']) == 2
    assert len(vgs_facts['vgs']['rootvg']) == 2

# Generated at 2022-06-20 17:13:01.996926
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    ahw = AIXHardware(module=module)
    vgs_facts = ahw.get_vgs_facts()

    assert vgs_facts['vgs'] is not None
    for vgname in vgs_facts['vgs']:
        assert isinstance(vgs_facts['vgs'][vgname], list)
        for pv in vgs_facts['vgs'][vgname]:
            assert isinstance(pv, dict)
            assert pv['pv_name'] is not None
            assert pv['pv_state'] is not None
            assert pv['pp_size'] is not None
            assert pv['total_pps'] is not None

# Generated at 2022-06-20 17:13:11.068641
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    module = AnsibleModuleMock()
    module.run_command = run_command
    aix = AIXHardware(module)

    cmd = "/usr/sbin/lsattr -El sys0 -a fwversion"
    cmd_output = "fwversion IBM,8247-22L"
    assert aix.get_dmi_facts()['firmware_version'] == '8247-22L'



# Generated at 2022-06-20 17:13:16.245556
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hw_collector = AIXHardwareCollector()
    assert hw_collector._platform == 'AIX'
    assert hw_collector._fact_class == AIXHardware

# Generated at 2022-06-20 17:13:17.944947
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector.platform == 'AIX'
    assert hardware_collector.fact_class == AIXHardware

# Generated at 2022-06-20 17:13:18.948755
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware = AIXHardware('ansible.module_utils.facts', {})
    assert hardware

# Generated at 2022-06-20 17:13:22.931056
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    """
    Test case to test the constructor of class AIXHardwareCollector
    """
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector.platform == 'AIX'
    assert hardware_collector.fact_class == AIXHardware



# Generated at 2022-06-20 17:13:35.724226
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    """Unit test for method get_vgs_facts of class AIXHardware"""
    import sys
    import os

    # Initialize pseudo module object
    class Module(object):
        def run_command(self, cmd, **kwargs):
            return 0, vgs_out, ''

    class AIXHardware(object):
        def __init__(self):
            self.module = Module()

    sys.modules['ansible'] = MagicMock()
    sys.modules['ansible.module_utils.facts'] = MagicMock()
    sys.modules['ansible.module_utils.facts.hardware'] = MagicMock()

    # Test with vg.out data
    file_path = "test/unit/ansible/module_utils/facts/hardware/test_aix_vgs.out"

# Generated at 2022-06-20 17:13:44.792502
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    class test_module:
        @staticmethod
        def run_command(command):
            out_lsdev = """\
fcs0 Available 04-08 PCI-X Fibre Channel Adapter
fcs1 Available 04-08 PCI-X Fibre Channel Adapter
fcs2 Available 04-08 PCI-X Fibre Channel Adapter
fcs3 Available 04-08 PCI-X Fibre Channel Adapter
hdisk1 Defined       KUSPI-LTO2-1-3580
        """
            out_lsattr = """\
max_transfer 16384
blksize 512
maxbufsize 32768
""".format()
            return 0, out_lsattr, None

        @staticmethod
        def get_bin_path(path, required=False):
            return "/bin/"+ path

    hardware = AIXHardware(test_module)
    hardware.populate

# Generated at 2022-06-20 17:13:55.269477
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    """
    Unit test for method get_vgs_facts of class AIXHardware
    """
    from ansible_collections.ansible.community.tests.unit.modules.utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase, set_module_args


# Generated at 2022-06-20 17:14:07.179700
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    # Create the class object
    aix_hw = AIXHardware()

    # Test the gpfs_facts function
    assert aix_hw.get_cpu_facts() == {'processor_count': 1, 'processor': 'PowerPC_POWER7', 'processor_cores': 1}

    # Test the get_memory_facts function
    assert aix_hw.get_memory_facts() == {'memtotal_mb': 4588, 'memfree_mb': 431, 'swaptotal_mb': 2048, 'swapfree_mb': 1901}

    # Test the get_mount_facts function
    assert aix_hw.get_mount_facts() == {'mounts': []}

    # Test the get_vgs_facts function

# Generated at 2022-06-20 17:15:26.385634
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    my_platform = AIXHardwareCollector._platform
    my_fact_class = AIXHardwareCollector._fact_class
    assert my_platform == 'AIX'
    assert my_fact_class.platform == 'AIX'


# Generated at 2022-06-20 17:15:35.126280
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    class TestModule:
        def get_bin_path(self, name):
            if name == "mount":
                return name
            else:
                return ""
        def run_command(self, args, use_unsafe_shell=False):
            if args == "mount":
                test_data = """
/dev/hd4 on / type jfs (log)
/dev/hd2 on /usr type jfs (log)
/dev/hd9var on /var type jfs (log)
/dev/hd3 on /tmp type jfs (log)
/dev/hd1 on /home type jfs (log)
/dev/livedump on /var/adm/ras/livedump type jfs (log)
proc /proc procfs
nodev /dev/fd
fd   /dev/fd
        """
                return 0,

# Generated at 2022-06-20 17:15:37.218843
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    x = AIXHardware({})

    assert x.platform == 'AIX'

# Generated at 2022-06-20 17:15:40.497167
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware = AIXHardware()
    print("AIXHardware():")
    print("  hardware =" + str(hardware))


# Generated at 2022-06-20 17:15:52.767069
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    import os
    import ansible.module_utils.facts.hardware.aix

    # This is the mock-return values for commands like
    # /usr/sbin/lsdev -Cc processor, etc.

# Generated at 2022-06-20 17:15:57.849790
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    """Test AIXHardwareCollector constructor"""

    facts_collector = AIXHardwareCollector()
    assert facts_collector._platform == 'AIX'
    assert facts_collector._fact_class == AIXHardware



# Generated at 2022-06-20 17:16:07.160693
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    # Test with single mount

# Generated at 2022-06-20 17:16:17.981122
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.common._collections_compat import Mapping
    import sys
    import string
    import StringIO

    flstr = '''memory pages
            63384
            free pages
            18650
            large pages
            0
            total paging space
            63384
            free paging space
            18650'''


# Generated at 2022-06-20 17:16:21.488911
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    assert hardware.platform == 'AIX'

# Generated at 2022-06-20 17:16:29.542796
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = MagicMock()
    hardware_facts = AIXHardware(module)
    hardware_facts.get_bin_path = MagicMock(return_value='/bin/lsvg')