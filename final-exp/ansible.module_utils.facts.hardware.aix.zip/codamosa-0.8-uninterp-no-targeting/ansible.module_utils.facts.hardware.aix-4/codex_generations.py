

# Generated at 2022-06-20 17:07:34.287945
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    facts = AIXHardwareCollector()
    assert facts.platform == 'AIX'

# Generated at 2022-06-20 17:07:42.145836
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    # Test input
    content = """
proc0 Available 00-00 Processor 0
proc1 Available 00-01 Processor 1
proc2 Defined   00-02 Processor 2
proc3 Defined   00-03 Processor 3"""
    aix_hardware = AIXHardware(dict(module=None))
    aix_hardware.module.run_command = lambda _: (0, content, '')
    # Test execution
    expected = dict(
        processor_count=4,
        processor_cores=1,
        processor='POWER6'
    )
    result = aix_hardware.get_cpu_facts()
    assert expected == result


# Generated at 2022-06-20 17:07:54.427281
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    class MockModule():
        def run_command(self, cmd, use_unsafe_shell=False):
            cmd = cmd.lower()
            if cmd == "/usr/sbin/lsattr -el sys0 -a fwversion":
                out = "FWVERSION IBM,IH91020"
            elif cmd == "/usr/bin/lsconf":
                out = "Machine Serial Number: 00F1234568\nLPAR Info: 1 1 1 320\nSystem Model: IBM,8286-41A\n"
            else:
                raise Exception("Bad command: " + cmd)
            return 0, out, ""

    aix_hardware = AIXHardware(MockModule())
    dmi_facts = aix_hardware.get_dmi_facts()

# Generated at 2022-06-20 17:08:03.391508
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():

    from ansible_collections.community.general.plugins.module_utils.facts import ModuleFacts
    from ansible_collections.community.general.plugins.module_utils.facts.collector.hardware.aix import AIXHardware
    from ansible_collections.community.general.plugins.module_utils.facts.collector.hardware.aix import AIXHardwareCollector

    class MockModule(object):
        command_warnings = []
        params = {}
        env = {}

        def __init__(self):
            self._name = None

        def get_bin_path(self, arg, required=False, opt_dirs=[]):
            if arg == 'lsdev':
                return '/usr/bin/lsdev'
            elif arg == 'lsattr':
                return '/usr/sbin/lsattr'

# Generated at 2022-06-20 17:08:04.505743
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hw = AIXHardware()
    assert hw.platform == 'AIX'


# Generated at 2022-06-20 17:08:07.126701
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    assert AIXHardware().get_mount_facts()

if __name__ == '__main__':
    test_AIXHardware_get_mount_facts()

# Generated at 2022-06-20 17:08:19.530188
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    """
    Unit test for method get_dmi_facts of class AIXHardware
    """
    class mock_module():
        def run_command(self, cmd):
            class mock_run_command():
                def __init__(self):
                    self._rc = 0
                    self._out = "fwversion IBM,8233-E8B\n"
                    self._err = ""

                @property
                def rc(self):
                    return self._rc

                @property
                def stdout(self):
                    return self._out

                @property
                def stderr(self):
                    return self._err

            return mock_run_command()


# Generated at 2022-06-20 17:08:31.222195
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    facts = AIXHardware()

    facts.module.run_command = my_run_command
    facts.module.get_bin_path = my_get_bin_path

    dmi_facts = facts.get_dmi_facts()

    assert dmi_facts['firmware_version'] == '7.1'
    assert dmi_facts['product_serial'] == 'Q8KG5V1'
    assert dmi_facts['lpar_info'] == '1 Q8KG5V1_CONSOLE_008'
    assert dmi_facts['product_name'] == '9117-570'



# Generated at 2022-06-20 17:08:41.749911
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = MagicMock()

# Generated at 2022-06-20 17:08:54.521021
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})

    class FakeAnsibleModule:
        def __init__(self):
            self.run_command = test_AIXHardware_get_device_facts_mock_run_command
            self.get_bin_path = test_AIXHardware_get_device_facts_mock_get_bin_path

    class FakeModuleUtils:
        def __init__(self):
            self.module = FakeAnsibleModule()

    class FakeAnsibleModuleUtilsExit:
        def __init__(self):
            self.module_utils = FakeModuleUtils()

    aix_hw = AIXHardware(FakeAnsibleModuleUtilsExit())
    device_facts = aix_hw.get_device_facts()


# Generated at 2022-06-20 17:09:17.927773
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    from ansible.module_utils import basic

    options = basic.AnsibleModule(argument_spec={'gather_subset': dict(type='list', elements='str')})
    options.params['gather_subset'].append('!all')

    obj = AIXHardware(options)
    facts = obj.populate()
    f = open('/tmp/test_AIXHardware_get_vgs_facts.facts', 'w')
    f.write(str(facts))
    f.close()



# Generated at 2022-06-20 17:09:19.952741
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    """
    AIXHardwareCollector unit test
    """
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector is not None


# Generated at 2022-06-20 17:09:28.290857
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(
        argument_spec=dict()
    )

    hardware_collector = AIXHardwareCollector(module=module)

    # Create some facts
    hardware_collector.facts['processor'] = [{'model name': 'processor1'}]
    hardware_collector.facts['processor_cores'] = 4
    hardware_collector.facts['processor_count'] = 4
    hardware_collector.facts['memtotal_mb'] = 1024
    hardware_collector.facts['memfree_mb'] = 512
    hardware_collector.facts['swaptotal_mb'] = 2048
    hardware_collector.facts['swapfree_mb'] = 1024

    hardware_collector.populate()

    # test_populate_cpu

# Generated at 2022-06-20 17:09:33.590417
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec=dict())
    hardware = AIXHardware(module)

    hardware.populate()

    assert hardware.facts['memtotal_mb'] == 64
    assert hardware.facts['memfree_mb'] == 16
    assert hardware.facts['processor_cores'] == 4
    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['processor'] == 'POWER8'
    assert hardware.facts['swaptotal_mb'] == 4096
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['firmware_version'] == '61H'
    assert hardware.facts['product_serial'] == 'd5c7aafb'
    assert hardware.facts['lpar_info'] == '1 CEC'

# Generated at 2022-06-20 17:09:39.390260
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    collector = AIXHardwareCollector()
    assert collector.platform == 'AIX'
    assert collector.fact_class == AIXHardware
    assert collector.fact_subscribers is None

# Generated at 2022-06-20 17:09:45.247363
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    module = AnsibleModule(
        argument_spec={
            'gather_subset': dict(default=['all'], type='list'),
            'filter': dict(default=None, type='list')
           })
    hardware = AIXHardware.populate(module)
    assert hardware.get('firmware_version') == b'IBM,8233-E8B'
    assert hardware.get('product_serial') == b'01CFG123'
    assert hardware.get('lpar_info') == b'lpar1'
    assert hardware.get('product_name') == b'8233-E8B'


# Generated at 2022-06-20 17:09:59.578396
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    """This test verifies the output of get_device_facts method in AIXHardware class."""

    # Create a test_module object
    test_module = type('', (object,), {'run_command': run_command_test})

    # Create an object of AIXHardware class
    test_obj = AIXHardware(test_module)

    # Call the method under test
    output = test_obj.get_device_facts()

    # Verify the output

# Generated at 2022-06-20 17:10:04.445305
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    hw = AIXHardware()
    facts = hw.populate()
    assert facts['processor']
    assert facts['processor_cores']
    assert facts['processor_count']



# Generated at 2022-06-20 17:10:09.065221
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector._platform == "AIX"
    assert hardware_collector._fact_class == AIXHardware
    assert hardware_collector._fact_class.platform == "AIX"

# Generated at 2022-06-20 17:10:23.005463
# Unit test for method get_vgs_facts of class AIXHardware

# Generated at 2022-06-20 17:10:54.415968
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    hardware = AIXHardware()
    hardware.module = AnsibleModule(argument_spec={})
    hardware.module.run_command = MagicMock(return_value=(0, '/usr/sbin/lsattr -El sys0 -a fwversion', ''))
    hardware.module.get_bin_path = MagicMock(return_value=True)
    facts = hardware.populate()
    assert facts['firmware_version'] == 'V7,9200123456789'
    assert facts['product_name'] == 'ibm,p7'
    assert facts['product_serial'] == '123456789'
    assert facts['lpar_info'] == '2'

# Generated at 2022-06-20 17:11:06.140364
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    # Arrange
    (lsdev_rc, lsdev_out, lsdev_err) = (0, '', '')
    lsdev_cmdout = """name status description
adapter Available OSA Express 5S55 4-port
adapter Available OSA Express 5S55 4-port
adapter Defined    OSA-Express 5S56 4-port
adapter Defined    OSA-Express 5S56 4-port
"""
    (lsattr_rc, lsattr_out, lsattr_err) = (0, '', '')

# Generated at 2022-06-20 17:11:14.978580
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = type('', (), {})()
    module.run_command = lambda *args: (0, 'IBM,8233-E8B TONE3', '')
    if not hasattr(module, 'get_bin_path'):
        module.get_bin_path = lambda *args, **kwargs: None
    facts = AIXHardware(module).get_dmi_facts()
    assert facts['firmware_version'] == 'IBM,8233-E8B TONE3'


# Generated at 2022-06-20 17:11:27.519444
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import FactManager

    fm = FactManager(collectors=[AIXHardwareCollector])
    fm.collect()
    dmi_facts = fm.ansible_facts['ansible_dmi']
    assert dmi_facts is not None
    assert dmi_facts['firmware_version'] is not None
    assert dmi_facts['product_serial'] is not None
    assert dmi_facts['product_name'] is not None
    assert dmi_facts['lpar_info'] is not None



# Generated at 2022-06-20 17:11:39.669475
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    # Constructor of class AIXHardware
    aix_hw = AIXHardware()

    # Assign vmstat output to variable
    # vmstat output as follows:
    # kthr      memory              page            faults      cpu
    # ----- ----------- ------------------------ ------------ -----------
    # r  b   avm   fre  re  pi  po  fr   sr  cy  in   sy  cs us sy id wa
    # 0  0   7600 62617   0   0   0   0    0    0   0    0   0  0  0  0  0
    # vmstat should return 0 when run successful
    rc, out, err = aix_hw.module.run_command("/usr/bin/vmstat -v")

    # Test assertion for method get_memory_facts of class AIXHardware
    assert aix_

# Generated at 2022-06-20 17:11:53.036200
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    # Get command output for command mount
    with open('./mount_cmd_output.txt', 'r') as f:
        mount_out = f.read()
    # Get command output for command lsattr
    with open('./lsattr_cmd_output.txt', 'r') as f:
        lsattr_out = f.read()

    # Process command output for command mount and build list of mount
    mount_facts = {'mounts': []}
    with open('./test_mount_facts.txt', 'r') as f:
        test_mount_facts = f.read()

    # Process command output for command lsattr and build dictionnary of vgs
    with open('./test_lsattr_facts.txt', 'r') as f:
        test_lsattr_facts = f.read()

    # Process

# Generated at 2022-06-20 17:11:54.845747
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    facts = AIXHardware()
    assert 'processor_cores' and 'processor_count' and 'processor' in facts.populate()

# Generated at 2022-06-20 17:11:58.202969
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    class_inst = AIXHardwareCollector()
    assert class_inst.platform == 'AIX'
    assert class_inst._fact_class == AIXHardware
    assert class_inst._fact_class().platform == 'AIX'


# Generated at 2022-06-20 17:12:11.492587
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils._text import to_bytes

    fact_collector = FactCollector()

# Generated at 2022-06-20 17:12:16.525708
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})

    hardware_facts = AIXHardware(module).populate()

    assert hardware_facts['architecture'] == 'ppc'



# Generated at 2022-06-20 17:12:57.600262
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    # Create object of class AIXHardwareCollector
    fact_collector = AIXHardwareCollector(None)
    # check the value of fact class
    assert fact_collector._fact_class == AIXHardware

# Unit test of populate method of class AIXHardware

# Generated at 2022-06-20 17:13:04.976596
# Unit test for method get_mount_facts of class AIXHardware

# Generated at 2022-06-20 17:13:13.968039
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    import ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.facts.hardware.aix as dut
    class FakeModule:
        def __init__(self, lsconf_path, lsattr_path):
            self.paths_for_lsconf = lsconf_path
            self.paths_for_lsattr = lsattr_path

        def get_bin_path(self, command, required=False):
            if command == 'lsconf':
                return self.paths_for_lsconf

            if command == 'lsattr':
                return self.paths_for_lsattr


# Generated at 2022-06-20 17:13:25.594121
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    collected_facts = {'PATH': '/usr/sbin:/sbin:/usr/bin:/bin:/usr/sbin',
                       'ansible_system': 'AIX',
                       'ansible_version': {'full': '4.3.4', 'major': '4', 'minor': '3', 'revision': 0, 'string': '4.3.4'},
                       'ansible_user_dir': '/home/giagule/.ansible',
                       'ansible_user_id': 'giagule',
                       'ansible_user_shell': '/usr/bin/ksh',
                       'ansible_userspace_architecture': 'powerpc',
                       'ansible_userspace_bits': '64',
                       'gather_subset': ['min'],
                       'gather_timeout': 10
                       }


# Generated at 2022-06-20 17:13:31.522657
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    hardware = AIXHardware(module)
    device_facts = hardware.get_device_facts()

    assert device_facts['devices'] != {}

    for device in device_facts['devices'].values():
        assert device['state'] in ('Available', 'Defined', 'Configured', 'Running')



# Generated at 2022-06-20 17:13:36.682681
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    class AIXHardwareMock():
        def get_bin_path(self, cmd, *args, **kwargs):
            return cmd

        def run_command(self, cmd, *args, **kwargs):
            if cmd == 'lsvg -o | xargs lsvg -p':
                return 0, 'rootvg:\nFREE DISTRIBUTION\nhdisk0 active 546 0   00..00..00..00..00\nhdisk1 active 546 113 00..00..00..21..92\nrealsyncvg:\nFREE DISTRIBUTION\nhdisk74 active 1999 6   00..00..00..00..06\ntestvg:\nFREE DISTRIBUTION\nhdisk105 active 999 838 200..39..199..200..200\nhdisk106 active 999 599 200..00..00..199..200\n',

# Generated at 2022-06-20 17:13:42.176541
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module=module)
    facts = hardware.populate()
    assert len(facts['mounts']) > 0, 'Expected number of filesystem mounts to be greater than 0!'
    for mount in facts['mounts']:
        if mount['mount'] == '/':
            assert mount['size_total'] > 0, 'Expected mountpoint %s size to be greater than 0!' % mount['mount']


# Generated at 2022-06-20 17:13:45.582159
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module=module)
    mount_facts = hardware.get_mount_facts()
    assert isinstance(mount_facts['mounts'], list)

# Generated at 2022-06-20 17:13:55.533056
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    # Create mock module
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    # Create mock class
    aix_hardware = AIXHardware(module)
    # Set mocked facts
    aix_hardware.facts = {}

    # Run method populate
    mem_stats = aix_hardware.get_memory_facts()
    # Check if the result has the expected keys
    assert mem_stats.has_key('memtotal_mb')
    assert mem_stats.has_key('memfree_mb')
    assert mem_stats.has_key('swaptotal_mb')
    assert mem_stats.has_key('swapfree_mb')

    # Unit test for method get_memory_facts of class AIXHardware
# when no swap is present

# Generated at 2022-06-20 17:14:07.334109
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = MockModule()
    aixhw = AIXHardware(module=module)
    lsconf_path = '/usr/sbin/lsconf'

    rc, out, err = aixhw.module.run_command(lsconf_path)
    if rc == 0 and out:
        for line in out.splitlines():
            data = line.split(':')
            if 'Machine Serial Number' in line:
                aixhw.module.serial = data[1].strip()
            if 'LPAR Info' in line:
                aixhw.module.lpar_info = data[1].strip()
            if 'System Model' in line:
                aixhw.module.name = data[1].strip()
            if 'Machine Type' in line:
                aixhw.module.machine_type = data[1].strip()

# Generated at 2022-06-20 17:14:50.841978
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hw_obj = AIXHardware()

    assert hw_obj.platform == 'AIX'

# Generated at 2022-06-20 17:14:52.962526
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    facts_collector = AIXHardwareCollector()
    assert facts_collector._platform == 'AIX'
    assert facts_collector._fact_class == AIXHardware

# Generated at 2022-06-20 17:15:01.362137
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec=dict())
    hw = AIXHardware(module=module)

    vgs_facts = hw.get_vgs_facts()
    assert vgs_facts['vgs']['testvg'][0]['pv_name'] == 'hdisk105'
    assert vgs_facts['vgs']['testvg'][0]['pp_size'] == '4 megabyte(s)'


if __name__ == '__main__':
    from ansible.module_utils.basic import *
    main()


# vim: expandtab:tabstop=4:shiftwidth=4

# Generated at 2022-06-20 17:15:10.791241
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = AIXHardware(module)

# Generated at 2022-06-20 17:15:22.610022
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    cpu_facts = {'processor': [],
                 'processor_cores': 0,
                 'processor_count': 0
                 }

    class AIXModuleMock():
        def __init__(self):
            self.bin_path_cache = {}

        def get_bin_path(self, name, opt_dirs=[]):
            return self.bin_path_cache[name]


# Generated at 2022-06-20 17:15:28.443745
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module=module)

# Generated at 2022-06-20 17:15:31.656344
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    module = AnsibleModule(argument_spec={})
    assert AIXHardwareCollector(module).platform == AIXHardwareCollector._platform
    assert AIXHardwareCollector(module).fact_class == AIXHardwareCollector._fact_class


# Generated at 2022-06-20 17:15:38.798266
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    """
    Test case for AIXHardware.get_device_facts
    """
    module = AnsibleModule(argument_spec=dict())
    dmi_obj = AIXHardware(module)
    dmi_facts = dmi_obj.populate()
    assert 'devices' in dmi_facts, dmi_facts

# Generated at 2022-06-20 17:15:44.492908
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    aix = AIXHardware(module=module)
    aix.populate()
    facts = aix.get_memory_facts()
    assert facts['memtotal_mb'] > 0, "Memory should be greater than 0"
    assert facts['memfree_mb'] >= 0, "Memory should be greater than or equal to 0"


# Generated at 2022-06-20 17:15:52.046821
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    fake_module = FakeAnsibleModule({})
    fake_module.run_command = lambda *args, **kwargs: (0, 'IBM,8233-E8B', '')     # output of command lsattr -El sys0 -a fwversion
    hardware_facts = AIXHardware(fake_module)
    dmi_facts = hardware_facts.get_dmi_facts()
    assert dmi_facts['firmware_version'] == 'IBM,8233-E8B'

