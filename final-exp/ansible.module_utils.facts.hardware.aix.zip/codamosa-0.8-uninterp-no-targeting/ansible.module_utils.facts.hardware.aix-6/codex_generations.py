

# Generated at 2022-06-20 17:07:42.079551
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})

    aix_hardware_mock = AIXHardware()
    aix_hardware_mock.module = module
    aix_hardware_mock.module.run_command = Mock(return_value=(0, '{"devices":{}}', ''))

    assert aix_hardware_mock.get_device_facts() == {'devices': {}}

    aix_hardware_mock.module.run_command = Mock(return_value=(0, '', ''))
    assert aix_hardware_mock.get_device_facts() == {'devices': {}}

    aix_hardware_mock.module.run_command = Mock(return_value=(1, '', ''))
    assert aix_hardware_mock.get_device_

# Generated at 2022-06-20 17:07:54.392262
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    class Options:
        def __init__(self):
            self.become = False
            self.become_method = None
            self.become_user = None
            self.no_log = False

    class AnsibleModuleMock:
        def __init__(self):
            self.params = {}
            self.options = Options()
            self.check_mode = False
            self.no_log = False
            self.log = None

        def get_bin_path(self, arg, required=False):
            return '/usr/bin/%s' % arg


# Generated at 2022-06-20 17:08:03.382888
# Unit test for method get_memory_facts of class AIXHardware

# Generated at 2022-06-20 17:08:12.178771
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    # Test case 1:
    # mocked lsattr -El sys0 -a fwversion command output
    # Tested method invocation
    # Expected output:
    # dmi_facts dictionary contains firmware_version and product_name keys
    # whose values are 'IBM,6.1' and 'IBM,8286-41A' respectively
    # Actual output:
    # dmi_facts dictionary contains firmware_version and product_name keys
    # whose values are 'IBM,6.1' and 'IBM,8286-41A' respectively
    lsattr_cmd_out = "fwversion IBM,6.1"

# Generated at 2022-06-20 17:08:14.409152
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    """
    Unit test for constructor of class AIXHardwareCollector
    """
    hwc = AIXHardwareCollector()
    assert hwc.platform == 'AIX'
    assert hwc._fact_class is AIXHardware


# Generated at 2022-06-20 17:08:23.107107
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    mockmodule = Mock()
    mockmodule.run_command = Mock(side_effect=[
        (0, "test1 Available 10-baseT-FD PCMCIA Device\n"
         "test2 Defined 10-baseT-FD PCMCIA Device", None),
        (0, "test3 Defined 10-baseT-FD PCMCIA Device", None),
        (0, "", None),
        (0, "test3 Defined 10-baseT-FD PCMCIA Device", None),
        (0, "", None)
    ])
    hardware = AIXHardware(mockmodule)

# Generated at 2022-06-20 17:08:25.931609
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = AIXHardware(module)
    hardware_obj.populate()
    assert hardware_obj.ansible_facts['ansible_processor'][0] == 'POWER7'
    assert hardware_obj.ansible_facts['ansible_processor_cores'] == 2
    assert hardware_obj.ansible_facts['ansible_processor_count'] == 2



# Generated at 2022-06-20 17:08:34.810738
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    # Test input
    test_input = """
    Method Error (/usr/lib/methods/cfgscsid):
    0514-061 Cannot find a child device.
    Method Error (/usr/lib/methods/cfgscsi):
    0514-061 Cannot find a child device.
    0301-040 Cannot find device scsid2.
    Method Error (/usr/lib/methods/ucfgdevice):
    0514-061 Cannot find a child device.
    Method Error (/usr/lib/methods/cfgadapter):
    0514-061 Cannot find a child device.
    """

    # Create an instance of the AIXHardware class which inherits from GenericHardware class
    my_obj = AIXHardware(module=None)
    # Call the method get_dmi_facts of the class AIXHardware
    fw_

# Generated at 2022-06-20 17:08:42.453575
# Unit test for method get_vgs_facts of class AIXHardware

# Generated at 2022-06-20 17:08:47.543925
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})

    harware_facts = AIXHardware(module).populate()
    print(json.dumps(harware_facts, indent=4))



# Generated at 2022-06-20 17:09:13.627527
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    """
    Unit test for method AIXHardware.get_cpu_facts
    """
    hardware = AIXHardware({'ANSIBLE_MODULE_ARGS': {}})
    hardware._run_command = run_command_mock
    hardware._get_bin_path = get_bin_path_mock
    hardware.populate()

    assert hardware.cpu
    assert hardware.cpu['processor'] == 'PowerPC_POWER8'
    assert hardware.cpu['processor_cores'] == 4
    assert hardware.cpu['processor_count'] == 8



# Generated at 2022-06-20 17:09:18.412436
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():

    module = AnsibleModule(argument_spec={})

    aixhardware = AIXHardware(module)

    expected = {'memtotal_mb': 8192, 'swapfree_mb': 10240, 'memfree_mb': 1002, 'swaptotal_mb': 20480}

    out = aixhardware.get_memory_facts()

    assert out == expected



# Generated at 2022-06-20 17:09:24.765616
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():

    # Data
    cpu = {'processor_count': 20,
           'processor': 'PowerPC_POWER6',
           'processor_cores': 2}
    mem = {'memtotal_mb': 66720,
           'swaptotal_mb': 38394,
           'swapfree_mb': 38394,
           'memfree_mb': 15228}
    dmi = {'lpar_info': '2 LPARs',
           'firmware_version': 'FW320',
           'product_serial': '12345',
           'product_name': 'IBM,9117-MMA'}

# Generated at 2022-06-20 17:09:25.949902
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hw = AIXHardware()



# Generated at 2022-06-20 17:09:33.902894
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    # Create a MockModule object
    mock_module = MockModule()
    mock_module.run_command = Mock(return_value=(0, "proc0 Available 00-00 Processor\nproc1 Available 00-01 Processor\n", ""))
    aix_hardware = AIXHardware(mock_module)
    cpu_facts = aix_hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 2


# Generated at 2022-06-20 17:09:47.706502
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    aix_facts = AIXHardware({})
    assert aix_facts.get_memory_facts() == {
        'memfree_mb': 122,
        'memtotal_mb': 48163,
        'swapfree_mb': 0,
        'swaptotal_mb': 0
    }
    assert aix_facts.get_cpu_facts() == {
        'processor': 'PowerPC_POWER7',
        'processor_cores': 4,
        'processor_count': 1
    }

# Generated at 2022-06-20 17:09:54.749157
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    aix_hw = AIXHardware()

    # Call method populate with 'collected_facts' equal to None
    # Returned result is 'dict' of hardware facts
    result = aix_hw.populate()
    assert isinstance(result, dict)



# Generated at 2022-06-20 17:10:01.552940
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    from collections import namedtuple
    module = namedtuple('module', ['run_command', 'get_bin_path'])
    module.run_command = lambda cmd: (0, 'firmware_version IBM,8812HML, 4.0.1.1', '')
    module.get_bin_path = lambda bin_name: '/usr/sbin/' + bin_name

    # this has to be done in order to get the right platform and
    # OS distribution set in the _platform_facts dict
    aix_collector = AIXHardwareCollector()
    platform_facts = aix_collector.collect()

    aix_hardware = AIXHardware(module)
    dmi_facts = aix_hardware.get_dmi_facts()

# Generated at 2022-06-20 17:10:11.923239
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    set_module_args(module)
    hw = AIXHardware(module)
    memory_facts = hw.get_memory_facts()
    assert int(memory_facts['memfree_mb']) < int(memory_facts['memtotal_mb'])
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] <= int(memory_facts['swaptotal_mb'])
    assert int(memory_facts['swapfree_mb']) < int(memory_facts['memfree_mb'])
    assert memory_facts['memfree_mb'] == 0 or int(memory_facts['memfree_mb']) > int(memory_facts['swaptotal_mb'])



# Generated at 2022-06-20 17:10:23.453009
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    mount_facts = {}
    mount_facts['mounts'] = []
    # AIX does not have mtab but mount command is only source of info (or to use
    # api calls to get same info)
    mount_path = '/usr/sbin/mount'
    rc, mount_out, err = run_command(mount_path)
    if mount_out:
        for line in mount_out.split('\n'):
            fields = line.split()

# Generated at 2022-06-20 17:10:58.269700
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    assert AIXHardwareCollector()._platform == 'AIX'


# Generated at 2022-06-20 17:11:07.173900
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = get_module_mock()
    hardware_obj = AIXHardware(module)
    hardware_obj.module.run_command = run_command_mock

    # For rootvg
    hardware_obj.module.run_command.return_value = (0, ROOTVG_LSVG_OUTPUT, '')
    hardware_obj.module.run_command.side_effect = [
        (0, ROOTVG_LSVG_PP_OUTPUT, ''),
        (0, ROOTVG_LSVG_PV_OUTPUT, ''),
    ]

    # For realsyncvg

# Generated at 2022-06-20 17:11:17.558410
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    import re
    import ansible.module_utils.facts.hardware.aix


# Generated at 2022-06-20 17:11:30.113045
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    test_module = AnsibleModule(argument_spec={})
    test_module.run_command = MagicMock(return_value=(0, 'mem:  16G    real,   16G    virtual,   3.2G   free', ''))
    test_module.run_command = MagicMock(return_value=(0, '6123 memory pages\n6559 free pages', ''))

    test_obj = AIXHardware(module=test_module)
    test_obj.populate()

    assert test_obj['memtotal_mb'] == 16388
    assert test_obj['memfree_mb'] == 16388
    assert test_obj['swaptotal_mb'] == test_obj['swapfree_mb'] == 0



# Generated at 2022-06-20 17:11:39.882002
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware = Hardware()
    fact = AIXHardware()
    fact.populate()

    assert fact.platform == 'AIX'
    assert isinstance(fact.memfree_mb, int)
    assert isinstance(fact.memtotal_mb, int)
    assert isinstance(fact.swapfree_mb, int)
    assert isinstance(fact.swaptotal_mb, int)
    assert isinstance(fact.processor, list)
    assert isinstance(fact.processor_cores, int)
    assert isinstance(fact.processor_count, int)
    assert isinstance(fact.firmware_version, str)
    assert isinstance(fact.product_serial, str)
    assert isinstance(fact.product_name, str)

# Generated at 2022-06-20 17:11:52.489744
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    out = """
hdisk0 Available 00-00-00-0,0
hdisk1 Available 00-00-00-1,0
hdisk2 Available 00-00-00-2,0
hdisk3 Available 00-00-00-3,0
hdisk4 Available 00-00-00-4,0
hdisk5 Available 00-00-00-5,0
First open-vios:eth0
Second open-vios:eth0
First open-vios:eth1
Second open-vios:eth1
"""

    module = AnsibleModule(argument_spec=dict())
    set_module_args(dict(gather_subset='!all', gather_timeout=10))
    hardware = AIXHardware(module=module)
    hardware.populate()

    assert hardware.facts['processor_cores'] == 2


# Generated at 2022-06-20 17:12:00.834886
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware_obj = AIXHardware(module)

# Generated at 2022-06-20 17:12:11.635283
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    """
    Test function get_cpu_facts of class AIXHardware

    :return:
    """
    # NOTE: the test case here will be enhanced after the test class
    # Hardware is refactored.
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=["all"], type='list')
        ),
        supports_check_mode=True
    )

    aix = AIXHardware(module)
    aix_facts = aix.get_cpu_facts()

    assert aix_facts['processor_count'] == 1
    assert aix_facts['processor'] == 'PowerPC_POWER8'
    assert aix_facts['processor_cores'] == 1

# Generated at 2022-06-20 17:12:17.057924
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    h = AIXHardware()
    vgs_facts = h.get_vgs_facts()
    assert 'vgs' in vgs_facts

    for vg_name in vgs_facts['vgs']:
        for vg_info in vgs_facts['vgs'][vg_name]:
            assert 'pv_name' in vg_info
            assert 'pv_state' in vg_info
            assert 'total_pps' in vg_info
            assert 'free_pps' in vg_info
            assert 'pp_size' in vg_info

# Generated at 2022-06-20 17:12:21.068046
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    from ansible.module_utils.facts.collector import CollectorsRegistry
    collector = CollectorsRegistry().get_collector('AIX')
    assert isinstance(collector, AIXHardwareCollector)

# Generated at 2022-06-20 17:13:30.410703
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    hardware = AIXHardware()
    hardware.module = MockModule()
    hardware.populate()

# Unit test class for method populate of class AIXHardware

# Generated at 2022-06-20 17:13:35.492028
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    # mock module object
    module = MockAIXModule()
    # create object
    aix_hw = AIXHardware()
    # set module object to aix_hw object
    aix_hw.module = module
    # test get_memory_facts method
    memory_facts = aix_hw.get_memory_facts()
    # set expected values
    expected_mem_facts = {'memtotal_mb': 8129,
                          'memfree_mb': 8113,
                          'swaptotal_mb': 10240,
                          'swapfree_mb': 10240
                          }
    # check if the test and the actual results are equal
    assert expected_mem_facts == memory_facts



# Generated at 2022-06-20 17:13:47.843171
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    import collections
    import json

    module = collections.namedtuple('Module', ['run_command'])
    args = dict(path='/tmp')
    lsconf_path = '/usr/sbin/lsconf'
    lsattr_path = '/usr/sbin/lsattr'

    class CommandResult:
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

    class ModuleMock():
        def __init__(self, rc, out, err):
            self.command_result = CommandResult(rc, out, err)

        def get_bin_path(self, name, required=False):
            return lsconf_path

        def run_command(self, cmd, use_unsafe_shell=False):
            return self.command

# Generated at 2022-06-20 17:13:55.575402
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={'gather_subset': dict(default=['!all'], type='list')})
    hardware = AIXHardware(module).populate()
    assert type(hardware['processor_count']) is int
    assert hardware['processor_count'] >= 1
    assert type(hardware['processor_cores']) is int
    assert hardware['processor_cores'] >= 1
    assert type(hardware['processor']) is list
    assert hardware['processor'] != []



# Generated at 2022-06-20 17:13:57.633491
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec=dict()
    )
    hardware = AIXHardware()

    hardware.module = module

    cpu_facts = hardware.get_cpu_facts()

    module.exit_json(msg=cpu_facts)


# Generated at 2022-06-20 17:14:02.046711
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module_mock = AnsibleModuleMock()
    module_mock.run_command = run_command_mock
    hardware = AIXHardware(module_mock)
    facts = hardware.get_dmi_facts()
    assert facts['firmware_version'] == 'IBM,V1R6M1'



# Generated at 2022-06-20 17:14:15.500070
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    from ansible.module_utils.facts.collector import HardwareCollector
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    import os
    import pytest
    import re
    aix_hardware = AIXHardware()
    collected_facts = {'lsconf': '/usr/sbin/lsconf'}

# Generated at 2022-06-20 17:14:19.243286
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware_obj = AIXHardware(module)
    dmi_facts = hardware_obj.get_dmi_facts()
    keys = ['firmware_version', 'product_serial', 'lpar_info', 'product_name']
    for key in keys:
        assert key in dmi_facts, "dmi fact %s missing" % key


# Generated at 2022-06-20 17:14:29.711751
# Unit test for method get_device_facts of class AIXHardware

# Generated at 2022-06-20 17:14:37.964547
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    class MockModule:
        def run_command(self, arg):
            # Command "lsdev -Cc processor"
            if arg == "/usr/sbin/lsdev -Cc processor":
                return 0, "proc0 Available 00-00 Processor\nproc1 Available 00-01 Processor\nproc2 Available 00-02 Processor", None

            # Command "lsattr -El proc0 -a type"
            if arg == "/usr/sbin/lsattr -El proc0 -a type":
                return 0, "type PowerPC_POWER8", None

            # Command "lsattr -El proc0 -a smt_threads"
            if arg == "/usr/sbin/lsattr -El proc0 -a smt_threads":
                return 0, "smt_threads 4", None
