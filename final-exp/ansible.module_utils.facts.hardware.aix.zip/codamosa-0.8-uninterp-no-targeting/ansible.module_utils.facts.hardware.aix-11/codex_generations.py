

# Generated at 2022-06-20 17:07:43.610590
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)

    hardware.populate()
    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['processor_cores'] == 4
    assert hardware.facts['processor'][0] == 'POWER8'
    assert hardware.facts['memtotal_mb'] == 8192
    assert hardware.facts['memfree_mb'] == 801
    assert hardware.facts['firmware_version'] == 'IBM,8247-22L'
    assert hardware.facts['product_serial'] == '06F6A2C9'
    assert hardware.facts['lpar_info'] == '1-U1-DB2-AIX-1'
    assert hardware.facts['product_name'] == '8247-22L'
    assert hardware

# Generated at 2022-06-20 17:07:54.626555
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    from ansible.module_utils.facts.plugins.hardware.aix import AIXHardware

    module_mock = Mock()
    module_mock.run_command.return_value = (0, AIXHARDWARE_LSDEV_CPU_OUTPUT, None)

    hardware_mock = AIXHardware(module_mock)
    hardware_mock.get_cpu_facts()

    assert module_mock.run_command.call_args_list[0] == call("/usr/sbin/lsdev -Cc processor")
    assert module_mock.run_command.call_args_list[1] == call("/usr/sbin/lsattr -El proc0 -a type")

# Generated at 2022-06-20 17:07:57.534046
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware_obj = AIXHardware(module)
    result = hardware_obj.get_cpu_facts()
    assert result['processor_count'] >= 1


# Generated at 2022-06-20 17:08:06.711407
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.hardware.aix import AIXHardware

    lsdev_path = 'ansible/module_utils/facts/hardware/aix/lsdev_out'
    lsattr_path = 'ansible/module_utils/facts/hardware/aix/lsattr_out'
    module = AnsibleModuleMock(AIXHardware, 'test', lsdev_path, lsattr_path)
    fact_collector = FactCollector()
    aix_hw = AIXHardware(fact_collector, module)


# Generated at 2022-06-20 17:08:14.549789
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] > 0
    assert cpu_facts['processor'] != ""
    assert cpu_facts['processor_cores'] > 0


# Generated at 2022-06-20 17:08:18.776243
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = FakeModule()

    aix_hardware = AIXHardware(module)
    aix_hardware.module.run_command = run_command_mock_return_value

    aix_hardware.get_cpu_facts()
    assert aix_hardware.module.run_command.call_count == 2



# Generated at 2022-06-20 17:08:32.504795
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = FakeAnsibleModule()
    module.run_command = fake_run_command
    module.get_bin_path = fake_get_bin_path

    ah = AIXHardware(module)
    ah._module = module
    facts = ah.get_device_facts()
    assert('devices' in facts)
    assert(facts['devices']['ent0']['state'] == 'Available')
    assert(facts['devices']['ent0']['type'] == 'Device Ethernet IVE')
    assert(facts['devices']['ent0']['attributes']['ent_state'] == 'enable')
    assert(facts['devices']['ent0']['attributes']['link_state'] == 'unknown')

# Generated at 2022-06-20 17:08:42.166097
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = AIXHardware(module)
    hardware_obj.populate()
    assert hardware_obj.facts['firmware_version'] == 'IBM,0104E0'
    assert hardware_obj.facts['mounts'][0]['device'] == '/dev/hd4'
    assert hardware_obj.facts['mounts'][0]['mount'] == '/'
    assert hardware_obj.facts['mounts'][0]['size_total'] == 12961408
    assert hardware_obj.facts['mounts'][0]['size_available'] == 7786240
    assert hardware_obj.facts['mounts'][0]['size_used'] == 3411008
    assert hardware_obj.facts['swaptotal_mb'] == 5832
    assert hardware

# Generated at 2022-06-20 17:08:50.775659
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    dmi_facts = AIXHardware.get_dmi_facts()
    assert dmi_facts['firmware_version'] == 'IBM,8233-E8B'
    assert dmi_facts['product_serial'] == '0123ABC'
    assert dmi_facts['lpar_info'] == 'AIX'
    assert dmi_facts['product_name'] == 'IBM,8233-E8B'

# Generated at 2022-06-20 17:08:53.724583
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    result = AIXHardwareCollector()
    assert result.platform == 'AIX'
    assert result.fact_class == AIXHardware


# Generated at 2022-06-20 17:09:14.091231
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    collector = AIXHardwareCollector()
    assert collector.platform == AIXHardware._platform
    assert collector.fact_class == AIXHardware

# Generated at 2022-06-20 17:09:22.566776
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    class MockModule:
        def run_command(arg_cmd):
            if arg_cmd == '/usr/bin/vmstat -v':
                return 0, '''memory pages: 1520863
                free pages: 1501386
                pinned pages: 3932''', ''

# Generated at 2022-06-20 17:09:35.969450
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    # Unit test for method get_cpu_facts of class AIXHardware
    lsdev_cmd = '/usr/sbin/lsdev -Cc processor'
    lsattr_cmd = '/usr/sbin/lsattr -El '
    command_get_cpu_facts = AIXHardware.get_cpu_facts(None, lsdev_cmd, lsattr_cmd, None, None)

    assert command_get_cpu_facts['processor_count'] == 64
    assert command_get_cpu_facts['processor'] == 'PowerPC_POWER8'
    assert command_get_cpu_facts['processor_cores'] == 4
    # Unit test for method get_cpu_facts of class AIXHardware
    lsdev_cmd = '/usr/sbin/lsdev -Cc processor'

# Generated at 2022-06-20 17:09:48.448400
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    hardware = AIXHardware()
    hardware.module.run_command = run_command_mock
    hardware.module.get_bin_path = get_bin_path_mock
    hardware_facts = hardware.populate()
    assert hardware_facts['processor_count'] == 2
    assert hardware_facts['processor'] == 'PowerPC_POWER6'
    assert hardware_facts['processor_cores'] == 1
    assert hardware_facts['memtotal_mb'] == 2064544
    assert hardware_facts['memfree_mb'] == 2049184
    assert hardware_facts['swaptotal_mb'] == 314368
    assert hardware_facts['swapfree_mb'] == 314368

    assert len(hardware_facts['vgs']['rootvg']) == 2

# Generated at 2022-06-20 17:09:57.521371
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    """
    Test method get_dmi_facts of class AIXHardware
    """
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'IBM,B82427SV', ''))
    ah = AIXHardware(module)
    assert ah.get_dmi_facts() == {'firmware_version': 'B82427SV'}

# Generated at 2022-06-20 17:10:05.682737
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    # Setup mock input
    output_lsdev_Cc_processor = """
    proc0 Available 00-00 Processor
    proc4 Available 00-04 Processor
    """
    module = Mock()
    module.run_command.return_value = (0, output_lsdev_Cc_processor, "")

    # Call method under test
    cpu_facts = AIXHardware(module).get_cpu_facts()

    # Setup expected result
    expected_result = {
        'processor': 'PowerPC_POWER7',
        'processor_count': 2,
        'processor_cores': 1
    }

    # Assert result
    assert cpu_facts == expected_result


# Generated at 2022-06-20 17:10:12.283508
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    class Options():
        def __init__(self, module):
            self.module = module

    class Module():
        def __init__(self, params=None):
            self.params = params

        def run_command(self, cmd, use_unsafe_shell=False):
            out = "Filesystem          512-blocks      Free %Used    Iused %Iused Mounted on\n"
            out = out + "node                /dev/hd4         14829088  3049616  80%   74585   23%   /\n"
            out = out + "node                /dev/hd2         30806528   735888  98%   289272   27%   /usr\n"

# Generated at 2022-06-20 17:10:23.566963
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec=dict())

    ah = AIXHardware(module)
    v = ah.get_dmi_facts()

# Generated at 2022-06-20 17:10:33.890484
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    class MockModule(object):
        def __init__(self, out_lsdev):
            self.out_lsdev = out_lsdev

        def run_command(self, cmd):
            return (0, self.out_lsdev, '')

    lscpu_facts = {}
    obj_lsdev = "proc0 Available 00-00 Processor    \nproc1 Defined   00-01 Processor    \nproc2 Defined   00-02 Processor    "
    my_obj = AIXHardware(MockModule(out_lsdev=obj_lsdev))
    lscpu_facts = my_obj.get_cpu_facts()

    assert 'processor_count' in lscpu_facts
    assert lscpu_facts['processor_count'] == 3
    assert 'processor' in lscpu_facts
    assert lscpu

# Generated at 2022-06-20 17:10:39.408369
# Unit test for method get_dmi_facts of class AIXHardware

# Generated at 2022-06-20 17:11:04.772058
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = MockModule()
    aix_hardware = AIXHardware(module)
    aix_hardware.populate()

    module.run_command.assert_any_call("/usr/bin/vmstat -v")

    assert aix_hardware.facts['memtotal_mb'] == 7680
    assert aix_hardware.facts['memfree_mb'] == 7680



# Generated at 2022-06-20 17:11:06.887444
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    assert AIXHardware()


# Generated at 2022-06-20 17:11:14.521945
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    mod_obj = AIXHardware(module)
    cpu_facts = mod_obj.get_cpu_facts()

    assert 'processor_count' in cpu_facts
    assert cpu_facts['processor_count'] >= 1
    assert 'processor' in cpu_facts
    assert cpu_facts['processor']
    assert 'processor_cores' in cpu_facts
    assert cpu_facts['processor_cores'] >= 1


# Generated at 2022-06-20 17:11:28.834490
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec=dict())
    module.run_command = MagicMock()

# Generated at 2022-06-20 17:11:39.857992
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module=module)
    output = hardware.get_vgs_facts()

# Generated at 2022-06-20 17:11:52.489535
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    class MockModule:
        def __init__(self):
            self.run_command_result = 0
            self.run_command_stdout = """
fwversion IBM,8233-E8B
"""
            self.run_command_stderr = ""
            self.get_bin_path_result = "/usr/sbin/lsattr"

        def get_bin_path(self, arg, required=False):
            return self.get_bin_path_result

        def run_command(self, cmd, use_unsafe_shell=False):
            return self.run_command_result, self.run_command_stdout, self.run_command_stderr

    mockModule = MockModule()
    h = AIXHardware(mockModule)
    out = h.get_dmi_facts()

    assert out

# Generated at 2022-06-20 17:12:01.996425
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    class module_tmp:
        def __init__(self):
            self.run_command = run_command_tmp
            self.get_bin_path = bin_path_tmp

    class run_command_tmp:
        def __init__(self):
            pass

        def __call__(self, command, **kwargs):
            rc = 0
            out = "ent0 Available    N/A  N/A  N/A             None MIGRATED\nent1 Available    N/A  N/A  N/A             None MIGRATED\nent2 Available    N/A  N/A  N/A             None MIGRATED\nfcs0 Available   10/0/1  N/A  N/A             None PERMISSION"
            err = ""
            return rc, out, err


# Generated at 2022-06-20 17:12:12.378824
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    class Options:
        def __init__(self):
            self.host = None
            self.module_path = None
    class Module:
        def __init__(self):
            self.options = Options()
            class RunCommand:
                def __init__(self):
                    self.rc = 0

# Generated at 2022-06-20 17:12:14.760376
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    hw = AIXHardware(module=module)
    res = hw.get_cpu_facts()
    assert res['processor_count'] == 8

# Generated at 2022-06-20 17:12:18.259153
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert isinstance(hardware_collector._fact_class, AIXHardware)

# Generated at 2022-06-20 17:13:02.847577
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    target = AIXHardware({})
    facts = target.populate()

    assert facts['processor_cores'] == 4
    assert facts['processor_count'] == 2
    assert facts['memtotal_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['vgs']
    assert facts['devices']
    assert facts['mounts']
    assert facts['firmware_version']
    assert facts['lpar_info']
    assert facts['product_name']
    assert facts['product_serial']

# Generated at 2022-06-20 17:13:07.462638
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    aix=AIXHardwareCollector()
    assert aix._platform == 'AIX'
    assert isinstance(aix._fact_class(), AIXHardware)

# Generated at 2022-06-20 17:13:16.234130
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    import re
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.hardware.aix import AIXHardware

    class TestAIXHardware(AIXHardware):
        def __init__(self, module):
            self.module = module

        def get_mount_facts(self):
            return super(TestAIXHardware, self).get_mount_facts()

    class TestModule():
        def __init__(self):
            self.params = {'gather_subset': '!all', 'gather_timeout': 10}
            self.exit_json = lambda **args: None
            self.run_command = run_command


# Generated at 2022-06-20 17:13:21.860794
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    class MockModule:
        def get_bin_path(self, command):
            return '/usr/sbin/' + command
        def run_command(self):
            return 0, vgs_out, ''

    m = MockModule()
    a = AIXHardware(m)
    result = a.get_vgs_facts()
    print(result)
    assert(result['vgs']['rootvg'][0]['pp_size'] == '4 megabyte(s)')

if __name__ == '__main__':
    test_AIXHardware_get_vgs_facts()


# Generated at 2022-06-20 17:13:35.404521
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    memfree = 1048576
    memtotal = 2097152
    swapfree = 1894400
    swaptotal = 3143680
    out = "50000 memory pages\n"
    out += "%d free pages\n" % memfree
    out += "10000000 swap pages\n"
    out += "%d free pages\n" % swapfree
    out += "10 fs cache pages\n"
    out += "0 free pages\n"
    module = MagicMock()
    module.run_command.return_value = (0, out, '')
    ah = AIXHardware(module)
    mem_facts = ah.get_memory_facts()
    assert mem_facts['memtotal_mb'] == memtotal / 1024
    assert mem_facts['memfree_mb'] == memfree / 1024

# Generated at 2022-06-20 17:13:47.808690
# Unit test for method get_memory_facts of class AIXHardware

# Generated at 2022-06-20 17:14:00.637964
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    """Test AIXHardware.get_cpu_facts
    AIX-specific subclass of Hardware.  Defines memory and CPU facts:
    - memfree_mb
    - memtotal_mb
    - swapfree_mb
    - swaptotal_mb
    - processor (a list)
    - processor_cores
    - processor_count
    """
    def mock_run_command(self, args, **kwargs):
        # Test version 1
        out_version_1 = """proc0 Available 00-00
proc1 Available 00-01
proc2 Available 00-02
proc3 Available 00-03
proc4 Available 00-04
proc5 Available 00-05
proc6 Available 00-06
proc7 Available 00-07
"""
        # Test version 2

# Generated at 2022-06-20 17:14:04.233442
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    mem_facts = AIXHardware(module).get_memory_facts()
    assert mem_facts['memtotal_mb'] > 0
    assert mem_facts['memfree_mb'] >= 0
    assert mem_facts['swaptotal_mb'] >= 0
    assert mem_facts['swapfree_mb'] >= 0



# Generated at 2022-06-20 17:14:15.969394
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    aix_hw = AIXHardware()
    mock_os_path_exists_method = lambda path: True
    aix_hw.module.run_command = lambda command: (0, 'memory pages:\t\t\t81689\nfree pages:\t\t\t81682\n', '')
    aix_hw.module.get_bin_path = mock_os_path_exists_method
    facts = aix_hw.get_memory_facts()
    assert facts['memtotal_mb'] == 32768
    assert facts['memfree_mb'] == 32766
    aix_hw.module.run_command = lambda command: (0, '', '')
    facts = aix_hw.get_memory_facts()
    assert facts['memtotal_mb'] == 0

# Generated at 2022-06-20 17:14:28.530570
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module=module)

    lsattr_command = ['/usr/bin/lsattr', '-E', '-l', 'hdisk0']
    lsdev_command = ['/usr/bin/lsdev']

    # Create a list of mock return values for the lsdev command
    lsdev_return_value = []
    lsdev_return_value.append('hdisk0 Available 00-00-00-00-00-00-00-00-00-00-00-00-00-00-00-00')
    lsdev_return_value.append('hdisk1 Available 00-00-00-00-00-00-00-00-00-00-00-00-00-00-00-00')

# Generated at 2022-06-20 17:15:48.977869
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    hardware = AIXHardware()
    assert hardware.get_cpu_facts()


# Generated at 2022-06-20 17:15:51.537405
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    facts = AIXHardware()
    assert facts.platform == 'AIX'

# Generated at 2022-06-20 17:15:54.596065
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    facts = AIXHardware({})
    assert facts.platform == 'AIX'


# Generated at 2022-06-20 17:15:56.054052
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware = AIXHardware()

# Generated at 2022-06-20 17:16:06.592323
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    """ Test the get_memory_facts method of class AIXHardware

    Uses the following mocking classes:
    - mock_module: used to mock the AnsibleModule class and its method run_command
    - mock_command: used to mock the methods: run_command of class AnsibleModule
    """

    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts.hardware.aix import test_AIXHardware_get_memory_facts
    from mock import patch

    mem_out = """
        memory pages      =       1852432
        rtsched pages     =          7984
        configured page   =       1971953
        free pages        =        678497
    """


# Generated at 2022-06-20 17:16:17.758138
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    facts = {}

    # mock vmstat
    vmstat_out = '''
    kthr      memory            page              faults      cpu
    ----- ----------- ------------------------ ------------ -----------
    r b avm   fre  re  pi  po  fr   sr  cy  in   sy  cs us sy id wa pc ec
    0 0 6138526 14466 0  0  0    0    0   0    0    0   0  0  0  0  1  0  0

    %s
    %s
    %s
    %s
    %s
    ''' % (' memory pages', '1559596', 'free pages', '14466', '1-kbyte-pages')
    module = AnsibleModule({'vmstat': vmstat_out})

# Generated at 2022-06-20 17:16:25.888092
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(
        argument_spec=dict()
    )
    ah = AIXHardware({'module': module})
    facts = ah.get_dmi_facts()
    assert facts['product_name'] is not None
    assert 'IBM,9111-520' in facts['product_name']
    assert facts['product_serial'] is not None
    assert facts['firmware_version'] is not None
    assert facts['lpar_info'] is not None

# Generated at 2022-06-20 17:16:38.511973
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():

    class TestModule(object):
        def __init__(self, *args, **kwargs):
            self.run_command_args = []

        def get_bin_path(self, executable, required=False):
            return executable

        def run_command(self, executable, *args, **kwargs):
            self.run_command_args.append(executable)
            return (0, '', '')

    # test 1
    module = TestModule()
    ah = AIXHardware(module)
    mounts_test_1 = ah.get_mount_facts()
    assert mounts_test_1['mounts'] == []

    # test 2
    cmd = 'mount'
    rc, out, err = module.run_command(cmd)
    assert module.run_command_args == [cmd]

    # test 3
   

# Generated at 2022-06-20 17:16:41.758059
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hw = AIXHardwareCollector()
    assert isinstance(hw, AIXHardwareCollector)

# Generated at 2022-06-20 17:16:45.047092
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    obj = AIXHardware()
    assert obj.platform == "AIX"
    assert obj.populate() == {}
