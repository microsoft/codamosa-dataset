

# Generated at 2022-06-22 22:53:46.179214
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    # Test constructor
    aixhw = AIXHardware('module')
    assert aixhw.platform == 'AIX'

# Generated at 2022-06-22 22:53:47.989157
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    aixhardware = AIXHardware()
    assert aixhardware.platform == 'AIX'
    assert aixhardware.populate()

# Generated at 2022-06-22 22:53:51.714588
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware = AIXHardware(dict())
    assert hardware.populate() == hardware.facts
    assert hardware.get_cpu_facts() == hardware.facts['processor']
    assert hardware.get_dmi_facts() == hardware.facts['dmi']
    assert hardware.get_memory_facts() == hardware.facts['memory']

# Generated at 2022-06-22 22:53:57.245790
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    '''test constructor of class AIXHardware'''
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    assert hardware.platform == 'AIX'
    assert hardware._module == module
    assert isinstance(hardware, AIXHardware)
    assert hardware.lsdev_path == module.get_bin_path('lsdev')



# Generated at 2022-06-22 22:54:09.438139
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    class ModuleStub(object):
        def run_command(self, args):
            out = 'firmware_version    IBM,7134-AC1'
            rc = 0
            err = ''
            return (rc, out, err)
        def get_bin_path(self, executable, required=False):
            return "/usr/sbin/lsconf"
    class AIXHardwareStub(AIXHardware):
        def __init__(self):
            pass
    module_stub = ModuleStub()
    hardware_stub = AIXHardwareStub()
    hardware_stub.module = module_stub
    dmi_facts = hardware_stub.get_dmi_facts()
    assert 'firmware_version' in dmi_facts
    assert 'product_serial' in dmi_facts

# Generated at 2022-06-22 22:54:13.435674
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    # This can't really be unit tested as it requires a running system
    # to work against.  However, the method takes a lot of time to execute
    # so we need to test it in some way or another
    pass

# Generated at 2022-06-22 22:54:25.133863
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    hardware = AIXHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['firmware_version'].startswith('7')
    assert hardware_facts['lpar_info'].startswith('lpar')
    assert hardware_facts['product_name'].startswith('p')
    assert hardware_facts['product_serial'].startswith('i')
    assert hardware_facts['processor'].startswith('Power')
    assert hardware_facts['processor_cores'] >= 1
    assert hardware_facts['processor_count'] >= 1
    assert hardware_facts['memtotal_mb'] >= 1
    assert hardware_facts['memfree_mb'] >= 1
    assert hardware_facts['swaptotal_mb'] >= 1
    assert hardware_facts['swapfree_mb'] >= 1
    assert hardware

# Generated at 2022-06-22 22:54:32.099262
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = type('Module', (object,), {'run_command': run_command_mock, 'get_bin_path': get_bin_path_mock})
    obj = AIXHardware(module)

    # Run the method with mocked lsdev command.
    facts = obj.get_cpu_facts()
    assert facts['processor_count'] == 4
    assert facts['processor'] == 'PowerPC_POWER8'
    assert facts['processor_cores'] == 8


# Generated at 2022-06-22 22:54:40.020310
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    # Initialize the AIXHardware class
    hardware = AIXHardware(module)

    # Test get_cpu_facts method of AIXHardware class
    hardware.populate()

    cpu_facts = hardware.get_cpu_facts()

    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'PowerPC_POWER8'
    assert cpu_facts['processor_cores'] == 4



# Generated at 2022-06-22 22:54:48.195135
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={})
    aixhardware_object = AIXHardware(module)
    assert aixhardware_object is not None
    assert hasattr(aixhardware_object, 'module')
    assert hasattr(aixhardware_object, 'populate')
    assert isinstance(aixhardware_object, AIXHardware)
    assert hasattr(aixhardware_object, 'platform')
    assert aixhardware_object.platform == 'AIX'

# Generated at 2022-06-22 22:54:58.394328
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    """Unit tests for method get_device_facts of class AIXHardware"""
    # test data
    # lsdev -Cc disk
    lsdev_out = """
name         status  description
hdisk0       Available 00-08-00-2,0-V1-C12345678-L12345678-T1
hdisk1       Available 06-08-00-2,0-V2-C12345678-L12345678-T2
hdiskpower0  Available
"""
    # lsattr -E -l hdisk0

# Generated at 2022-06-22 22:55:10.738489
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)

    # test with lsdev command available
    module.run_set_module_args(dict(bin_path='/usr/bin'))
    rc, out, err = module.run_command.call_args[0]
    assert rc == 0 and (out or err)

    cpu_facts = hardware.get_cpu_facts()
    assert 'processor' in cpu_facts
    assert 'processor_count' in cpu_facts
    assert 'processor_cores' in cpu_facts

    # test with lsdev command unavailable
    module.run_set_module_args(dict(bin_path='/bin'))
    rc, out, err = module.run_command.call_args[0]
    assert rc == 1 and (out or err)

# Generated at 2022-06-22 22:55:15.178505
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    device_facts = AIXHardware().get_cpu_facts()
    assert 'processor_count' in device_facts
    assert 'processor_cores' in device_facts
    assert 'processor' in device_facts


# Generated at 2022-06-22 22:55:20.662320
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={})
    hardware_collector = AIXHardwareCollector(module=module)
    hardware_instance = hardware_collector.collect()[0]
    assert hardware_instance.platform == 'AIX'


# Generated at 2022-06-22 22:55:32.178553
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    lsdev_cmd = '/usr/sbin/lsdev -Cc processor'
    lsattr_cmd = '/usr/sbin/lsattr -El %s -a %s'
    real_out_lsdev = """proc0 Available 00-00 Processor
proc4 Available 00-04 Processor
proc8 Available 00-08 Processor
proc12 Available 00-0C Processor
proc16 Available 00-10 Processor"""
    real_out_lsattr_proc0 = """type PowerPC_POWER5 True"""
    real_out_lsattr_smt_threads = """smt_threads 2 True"""
    real_cpu_facts = {'processor_cores': 2,
                      'processor_count': 4,
                      'processor': 'PowerPC_POWER5'}

    test_module = MockModule("testmodule")
    test_module.run

# Generated at 2022-06-22 22:55:41.279242
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    lsconf_path = module.get_bin_path("lsconf")
    # On Travis-CI, lsconf is not available
    if lsconf_path:
        cmd = lsconf_path
        rc, out, err = module.run_command(cmd)
        if rc != 0:
            module.fail_json(msg="Failed to run %s: %s" % (cmd, err))

        aixhardware = AIXHardware(module)
        dmi_facts = aixhardware.get_dmi_facts()
        assert dmi_facts['firmware_version']
        assert dmi_facts['product_serial']
        assert dmi_facts['lpar_info']
        assert dmi

# Generated at 2022-06-22 22:55:42.763595
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    mod = AIXHardware()
    assert mod.platform == 'AIX'

# Generated at 2022-06-22 22:55:44.127065
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    x = AIXHardware()
    assert x.get_cpu_facts() == {'processor': ['POWER8'], 'processor_cores': 24, 'processor_count': 4}



# Generated at 2022-06-22 22:55:48.337269
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False)
    hardware_facts = AIXHardware(module)
    test_devices = hardware_facts.get_device_facts()['devices']

    # Expected results

# Generated at 2022-06-22 22:55:57.023153
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware_obj = AIXHardware(module)

    vgs_facts = hardware_obj.get_vgs_facts()

    assert 'vgs' in vgs_facts
    assert type(vgs_facts['vgs']) is dict
    assert 'testvg' in vgs_facts['vgs']
    assert type(vgs_facts['vgs']['testvg']) is list
    assert 'hdisk105' in vgs_facts['vgs']['testvg'][0]
    assert vgs_facts['vgs']['testvg'][0]['pv_name'] == 'hdisk105'
    assert vgs_facts['vgs']['testvg'][0]['pv_state'] == 'active'
    assert vgs_facts

# Generated at 2022-06-22 22:56:06.584461
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AIXHardware()

    (rc, out, err) = module.run_command("/usr/sbin/lsdev -Cc processor")
    if out:
        i = 0
        for line in out.splitlines():

            if 'Available' in line:
                if (i == 0):
                    data = line.split(' ')
                    cpudev = data[0]

                i += 1
        processor_count = int(i)

        (rc, out, err) = module.run_command("/usr/sbin/lsattr -El " + cpudev + " -a type")

        data = out.split(' ')
        processor = data[1]


# Generated at 2022-06-22 22:56:17.112383
# Unit test for method get_mount_facts of class AIXHardware

# Generated at 2022-06-22 22:56:19.132859
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    ins = AIXHardwareCollector()
    assert isinstance(ins, AIXHardwareCollector)



# Generated at 2022-06-22 22:56:26.377981
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = AIXHardware(module)
    rc, out, err = hardware.module.run_command("echo 'memory pages:   1679112' && echo 'free pages:     876415'")
    mem_facts = hardware.get_memory_facts()
    result = {'memfree_mb': 177976, 'memtotal_mb': 16384}
    assert(mem_facts == result)


# Generated at 2022-06-22 22:56:38.906504
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    import io

    module = MockModule()

    # Return value of method run_command
    vmstat_output = """
    System configuration: lcpu=4 mem=3072MB ent=0.50
    kthr      memory              page              faults      cpu
    ----- ----------- ------------------------ ------------ -----------
    r  b   avm   fre  re  pi  po  fr   sr  cy  in   sy  cs us sy id wa
    4  0  2347  4952   0   0   0  25   23  32 2308 4811 1302  3  2 94  1
    """
    module.run_command.return_value = (0, vmstat_output, '')

    hardware = AIXHardware()
    hardware.module = module

    hardware.populate()

    assert hardware.memfree_mb == 12
   

# Generated at 2022-06-22 22:56:47.701323
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False,
    )
    macs_to_facts = {
        '0000.1111.2222': {'ipv4': '192.0.2.1', 'ipv6': '2001:db8::1'},
        'ffff.eeee.dddd': {'ipv4': '192.0.2.2', 'ipv6': '2001:db8::2'},
    }
    hardware_obj = AIXHardware(module=module, macs_to_facts=macs_to_facts)
    hardware_obj.populate()

    facts = hardware_obj.get_facts()
    assert isinstance(facts, dict)
    assert 'firmware_version' in facts
    assert 'product_serial' in facts

# Generated at 2022-06-22 22:56:54.742789
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    """
    Unit test for method get_memory_facts of class AIXHardware
    """

    # Test with valid data
    data = '''
memory pages: 5325120
free pages: 5252211
smallest block: 48
largest block: 524272
'''

    class TestClass(object):
        def __init__(self, data):
            self.data = data
            self.run_command_data = data

        def run_command(self, cmd, use_unsafe_shell=False):
            testout = self.run_command_data
            return 0, testout, None

    testmodule = TestClass(data)

    testclass = AIXHardware(module=testmodule)
    testclass.populate()
    memory_facts = testclass.get_memory_facts()

# Generated at 2022-06-22 22:56:59.468289
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module=module)
    collected_facts = hardware.get_memory_facts()
    assert collected_facts['memtotal_mb'] > 0
    assert collected_facts['memfree_mb'] > 0

# Generated at 2022-06-22 22:57:03.671800
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    """
    Test constructor of class AIXHardware.
    """

    from ansible.module_utils.facts.hardware.aix import AIXHardware
    aixhw = AIXHardware({})
    assert(aixhw.platform == 'AIX')

# Generated at 2022-06-22 22:57:15.035215
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    """
    Test get_vgs_facts method of class AIXHardware
    """


# Generated at 2022-06-22 22:57:22.111041
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    from ansible.module_utils.facts.collector.hardware.aix import AIXHardware
    hardware = AIXHardware()
    mount_facts = hardware.get_mount_facts()
    assert 'mounts' in mount_facts
    assert 'mount' in mount_facts['mounts'][0]
    assert 'device' in mount_facts['mounts'][0]
    assert 'fstype' in mount_facts['mounts'][0]
    assert 'options' in mount_facts['mounts'][0]
    assert 'time' in mount_facts['mounts'][0]

# Generated at 2022-06-22 22:57:29.595297
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware_facts = AIXHardware(module=module)

    device_facts = hardware_facts.get_device_facts()

    assert device_facts
    assert device_facts['devices']['ent0']['type'] == "1/0/ethernet"
    assert device_facts['devices']['ent0']['state'] == "Available"
    assert device_facts['devices']['ent0']['attributes']



# Generated at 2022-06-22 22:57:37.835194
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    import ansible_collections.ansible.community.tests.unit.plugins.module_utils.facts.test_utils as test_utils
    import ansible_collections.ansible.community.plugins.module_utils.facts.hardware.aix as aix_hw

    temp_lsdev_output = '''ent0 Available 09-08-08 Ethernet I/F
ent1 Defined        09-08-08 Ethernet I/F
ent2 Defined        09-08-08 Ethernet I/F (Dedicated to LPAR 1)
ent3 Defined        09-08-08 Ethernet I/F (Dedicated to LPAR 2)
ent4 Defined        09-08-08 Ethernet I/F
'''

# Generated at 2022-06-22 22:57:40.661398
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector._platform == 'AIX'
    assert hardware_collector._fact_class == AIXHardware


# Generated at 2022-06-22 22:57:51.139423
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    dmi_facts = {
        'firmware_version': 'IBM,8100-42A',
        'lpar_info': '1 CEC(s)',
        'product_name': 'IBM,8100-42A',
        'product_serial': '06A846B'
    }
    hardware = AIXHardware({}, {'system': {'distribution': {'name': 'AIX'}}}, dmi_facts)
    assert hardware.platform == 'AIX'
    assert hardware.distribution == 'AIX'
    assert hardware.product_name == 'IBM,8100-42A'
    assert hardware.firmware_version == 'IBM,8100-42A'

# Generated at 2022-06-22 22:58:01.382098
# Unit test for method get_device_facts of class AIXHardware

# Generated at 2022-06-22 22:58:06.681243
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    hardware = AIXHardware(module=module)

    # Test with no mount output
    mount_facts = hardware.get_mount_facts()
    assert mount_facts == {
        'mounts': []
    }

    # Test with mount output

# Generated at 2022-06-22 22:58:15.768610
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})

    # Prepare sample output of lsdev command
    out_lsdev = 'rsct_rmdisp  Available  Reliable Scalable Cluster Technology Remote Resource Monitor'
    out_lsdev += 'rsct_rmdevice  Available  Reliable Scalable Cluster Technology Remote Resource Monitor Device'
    out_lsdev += 'rsct_rmevent  Available  Reliable Scalable Cluster Technology Remote Resource Monitor Event'
    out_lsdev += 'rsct_rmeventlog  Available  Reliable Scalable Cluster Technology Remote Resource Monitor Event Log'
    out_lsdev += 'rsct_rmlog  Available  Reliable Scalable Cluster Technology Remote Resource Monitor Log'
    out_lsdev += 'rsct_rmreq  Available  Reliable Scalable Cluster Technology Remote Resource Monitor Sentinel'

# Generated at 2022-06-22 22:58:27.675633
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    class TestModule:
        def get_bin_path(self, arg, opt_dirs=[]):
            return "/usr/sbin/mount"


# Generated at 2022-06-22 22:58:31.000231
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    module.params = {}

    fact_collector = AIXHardwareCollector(module=module)
    fact_collector.get_devices()



# Generated at 2022-06-22 22:58:41.147457
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={})
    aixhardware_obj = AIXHardware(module)
    aixhardware_obj.populate()
    aixhardware_obj.get_cpu_facts()
    aixhardware_obj.get_memory_facts()
    aixhardware_obj.get_cpu_facts()
    aixhardware_obj.get_dmi_facts()
    aixhardware_obj.get_vgs_facts()
    aixhardware_obj.get_mount_facts()
    aixhardware_obj.get_device_facts()


# Generated at 2022-06-22 22:58:48.984378
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    class TestModule(object):
        def __init__(self):
            self.lsdev_out = """\
hdisk0 Available 00-08-70-FE-18-50-F6-B1-0E-01-00-00-00-00-00
hdisk1 Defined   00-08-70-FE-18-50-F6-B1-0E-02-00-00-00-00-00
hdisk2 Available 00-08-70-FE-18-50-F6-B1-0E-03-00-00-00-00-00"""

# Generated at 2022-06-22 22:59:00.945359
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts.utils import get_mount_size

    module = AnsibleModule(
        argument_spec = dict(
        )
    )

    aix_hw = AIXHardware(module=module)

    mount_facts = {}
    mount_facts['mounts'] = []

    mounts = []
    #lines of input to test method

# Generated at 2022-06-22 22:59:07.203198
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    test_obj = None
    test_obj = AIXHardware(test_obj)
    test_out = test_obj.get_memory_facts()
    assert test_out['memtotal_mb'] > 0
    assert test_out['memfree_mb'] > 0
    assert 'swapfree_mb' in test_out
    assert 'swaptotal_mb' in test_out


# Generated at 2022-06-22 22:59:11.599603
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})

    hardware = AIXHardware(module=module)
    device_facts = hardware.get_device_facts()

    assert device_facts['devices']  # device_facts['devices'] is not empty



# Generated at 2022-06-22 22:59:22.759209
# Unit test for method get_memory_facts of class AIXHardware

# Generated at 2022-06-22 22:59:28.130473
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    module = basic.AnsibleModule(
        argument_spec = dict(
        )
    )

    hardware_facts = AIXHardware(module=module).populate()
    assert hardware_facts['memtotal_mb'] == 536870912
    assert hardware_facts['memfree_mb'] == 536870912
    assert hardware_facts['swaptotal_mb'] == 314368
    assert hardware_facts['swapfree_mb'] == 314368



# Generated at 2022-06-22 22:59:33.081058
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    aix_hc = AIXHardwareCollector()
    assert aix_hc._platform == 'AIX'
    assert aix_hc._fact_class == AIXHardware



# Generated at 2022-06-22 22:59:36.771425
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    # Check if _platform and _fact_class is the same as the class
    # variables
    assert AIXHardwareCollector._platform == 'AIX'
    assert AIXHardwareCollector._fact_class == AIXHardware


# Generated at 2022-06-22 22:59:40.761926
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    """
    This is a test for the __init__ method from AIXHardwareCollector class
    """
    _platform = 'AIX'
    _fact_class = AIXHardware
    obj = AIXHardwareCollector(_platform, _fact_class)
    assert isinstance(obj, AIXHardwareCollector)



# Generated at 2022-06-22 22:59:52.713402
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    ansible_module_mock = AnsibleModuleMock()
    aix_hardware = AIXHardware(ansible_module_mock)

    aix_hardware.populate()

    assert aix_hardware.facts['processor']
    assert aix_hardware.facts['firmware_version']
    assert aix_hardware.facts['processor_count']
    assert aix_hardware.facts['lpar_info']
    assert aix_hardware.facts['product_serial']
    assert aix_hardware.facts['product_name']
    assert aix_hardware.facts['swaptotal_mb']
    assert aix_hardware.facts['swapfree_mb']
    assert aix_hardware.facts['memtotal_mb']

# Generated at 2022-06-22 22:59:55.217214
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector._platform == 'AIX'
    assert hardware_collector._fact_class == AIXHardware

# Generated at 2022-06-22 23:00:05.987230
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():

    class TestModule(object):
        def __init__(self, params):
            self.params = params

        def run_command(self, cmd, use_unsafe_shell=True):
            return rc, out, err

        def get_bin_path(self, executable, required=True):
            return executable

    # test parametrs
    params = {}

# Generated at 2022-06-22 23:00:09.353997
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())

    h = AIXHardware(module=module)
    h.populate()

    assert h.memfree_mb  # Make sure memfree_mb is not None


# Generated at 2022-06-22 23:00:14.951601
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    ah = AIXHardware(module)
    facts = ah.get_cpu_facts()
    assert 'processor_count' in facts
    assert 'processor' in facts
    assert 'processor_cores' in facts



# Generated at 2022-06-22 23:00:22.868772
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    vgs_facts = """(rootvg):
    PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
    hdisk0            active            546         0           00..00..00..00..00
    hdisk1            active            546         113         00..00..00..21..92
(realsyncvg):
    PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
    hdisk74           active            1999        6           00..00..00..00..06
(testvg):
    PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
    hdisk105          active            999         838         200..39..199..200..200
    hdisk106          active            999         599         200..00..00..199..200"""
    expected

# Generated at 2022-06-22 23:00:28.955763
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    lsdev_path = "/usr/sbin/lsdev"
    lsattr_path = "/usr/sbin/lsattr"

    # test cpu facts
    ah = AIXHardware(lsdev_path, lsattr_path)
    data = ah.get_cpu_facts()
    assert ('processor_count' in data)
    assert ('processor' in data)
    assert ('processor_cores' in data)



# Generated at 2022-06-22 23:00:40.494185
# Unit test for method get_cpu_facts of class AIXHardware

# Generated at 2022-06-22 23:00:48.057282
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module=module)
    hardware.get_cpu_facts()
    if module.exit_json.called:
        result = module.exit_json.call_args[0][1]
        assert result['processor_count'] == 4
        assert result['processor_cores'] == 1
        assert result['processor'] == 'POWER8'



# Generated at 2022-06-22 23:00:56.782065
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    class AIXHardwareTest(AIXHardware):
        def __init__(self, *args, **kwargs):
            self.module_mock = kwargs['module']
            super(AIXHardwareTest, self).__init__(*args, **kwargs)

    
    class TestModule():
        def __init__(self):
            self.mount_out = ""

        def get_bin_path(self, cmd, opt_dirs=None):
            return cmd


# Generated at 2022-06-22 23:00:59.125871
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hw = AIXHardwareCollector()
    assert hw.platform == 'AIX'
    assert hw.fact_class == AIXHardware

# Generated at 2022-06-22 23:01:02.996929
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    mod = None
    obj = AIXHardwareCollector('test', mod)
    assert obj.platform == 'AIX'
    assert obj.fact_class == AIXHardware


# Generated at 2022-06-22 23:01:04.609080
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    test = AIXHardware()
    test.populate()


# Generated at 2022-06-22 23:01:16.661949
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec=dict())
    exit_args = dict(failed=False, changed=False, skip=False, skipped=False, msg='')

    # Setup a test class to test class AIXHardware
    class MyAIXHardware():
        def __init__(self):
            self.module = module

        def get_bin_path(self, bin_name):
            return bin_name

        def run_command(self, command, use_unsafe_shell=False):
            if '/mount' in command:
                out = "/dev/fs1 /                                 jfs2         Oct 25 10:54                 rw,log=/dev/hd8 - " \
                      "mount point for /\n/dev/fs1 /usr/local/ansible                               jfs2         Nov  3 08:44 " \
                     

# Generated at 2022-06-22 23:01:25.746573
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    class MockAIXHardware(AIXHardware):
        def __init__(self, module_name):
            self.module = module_name

        def run_command(self, cmd):
            out = "proc0 Available 00-00 Proc 0\n"
            out += "proc1 Available 00-01 Proc 1\n"
            out += "proc2 Available 00-02 Proc 2\n"
            out += "proc3 Defined   00-03 Proc 3\n"
            out += "fcs0  Available 00-04 Fibre Channel SCSI IOA\n"
            out += "fcs1  Available 00-05 Fibre Channel SCSI IOA\n"
            out += "fcs2  Available 00-06 Fibre Channel SCSI IOA\n"

# Generated at 2022-06-22 23:01:38.022201
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    """
    test get_vgs_facts method of Ansible AIXHardware class
    """

    # build a mock module
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.six.moves import StringIO

    # build a mock module for aix
    class TestAIXModule(object):
        def __init__(self, module_args):
            self.params = {
                'fact_path': '/tmp/ansible_aix_facts'
            }

        def get_bin_path(self, arg1, arg2=None):
            if arg2:
                return '/usr/bin/' + arg1

# Generated at 2022-06-22 23:01:45.367708
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    hardware = AIXHardware()
    hardware.module = FakeModule()
    hardware.module.run_command = MagicMock(return_value=(1, '', ''))

    dmi_facts = hardware.get_dmi_facts()
    assert 'lpar_info' in dmi_facts
    assert 'product_name' in dmi_facts
    assert 'product_serial' in dmi_facts
    assert 'firmware_version' in dmi_facts



# Generated at 2022-06-22 23:01:49.603748
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector
    assert hardware_collector._fact_class == AIXHardware

# Generated at 2022-06-22 23:01:53.938807
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware_obj = AIXHardware()
    hardware_obj.module = module
    cpu_facts = hardware_obj.get_cpu_facts()
    assert cpu_facts['processor'] == 'PowerPC_POWER8'
    assert cpu_facts['processor_count'] <= cpu_facts['processor_cores']


# Generated at 2022-06-22 23:02:02.380246
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    # create a AIXHardware object to test
    ah = AIXHardware()
    # create a string to simulate the output of
    # vmstat -v on AIX

# Generated at 2022-06-22 23:02:12.833042
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    from ansible.module_utils.facts.collector import get_collector
    from ansible.module_utils.facts.utils import get_file_content

    HWCollector = get_collector('hardware')

# Generated at 2022-06-22 23:02:16.767008
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec=dict())
    ah = AIXHardware(module)

    ah.get_dmi_facts()



# Generated at 2022-06-22 23:02:22.621847
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    """
    Unit test for method get_cpu_facts of class AIXHardware
    """
    module = AnsibleModule(argument_spec=dict())
    hw = AIXHardware(module)
    cpu_facts = hw.get_cpu_facts()
    assert cpu_facts['processor_count'] > 0
    assert cpu_facts['processor_cores'] > 0


# Generated at 2022-06-22 23:02:24.804206
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    test_AIXHardware = AIXHardware()
    assert test_AIXHardware.platform == 'AIX'


# Generated at 2022-06-22 23:02:36.157086
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    import tempfile


# Generated at 2022-06-22 23:02:37.178969
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    AIXHardwareCollector()

# Generated at 2022-06-22 23:02:39.143605
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    obj = AIXHardwareCollector()
    assert isinstance(obj, HardwareCollector)


# Generated at 2022-06-22 23:02:40.623931
# Unit test for constructor of class AIXHardware
def test_AIXHardware():

    hardware_instance = AIXHardware({}, None)

    assert hardware_instance.platform == 'AIX'

# Generated at 2022-06-22 23:02:49.654637
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    h = AIXHardware()
    h._module = Mock()
    # Test case 1: test case without swapinfo lines
    h._module.run_command = Mock(return_value=(0, '', ''))
    assert h.get_memory_facts() == {'memfree_mb': 0, 'memtotal_mb': 0, 'swaptotal_mb': None, 'swapfree_mb': None}
    # Test case 2: test case with swapinfo lines
    h._module.run_command = Mock(return_value=(0, 'Device          1M-blocks     Used    Avail Capacity\n/dev/ada0p3        314368        0   314368     0%', ''))

# Generated at 2022-06-22 23:02:58.572945
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
    from ansible.module_utils import basic
    from ansible.module_utils.facts import module_utils
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.hardware.aix import AIXHardware

    class FakeModule:
        _module = 'basic'

        def get_bin_path(self, cmd, required=False):
            return "/usr/bin/%s" % cmd


# Generated at 2022-06-22 23:03:00.238972
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    assert hardware.get_memory_facts()['memtotal_mb'] > 0

# Generated at 2022-06-22 23:03:02.890798
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={})
    hardware_obj = AIXHardware(module=module)
    assert "AIX" == hardware_obj.platform

# Generated at 2022-06-22 23:03:06.974519
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    device_facts = AIXHardware(module).get_device_facts()

    assert device_facts['devices']

# Generated at 2022-06-22 23:03:18.249688
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    import sys
    sys.modules['ansible'] = type('FakeAnsibleModule', (), {})
    h = AIXHardware()

# Generated at 2022-06-22 23:03:24.740894
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    dmi_facts_result = {'firmware_version': '1.1.3', 'product_serial': '95B6F7B', 'lpar_info': 'aixlpar', 'product_name': '9117-MMA'}
    assert(dmi_facts_result == AIXHardware().get_dmi_facts())


# Generated at 2022-06-22 23:03:34.599805
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    # testing
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'hdisk0 Available 00-00-01 fake_firmware_level\nhdisk1 Available 00-01-02 fake_firmware_level', ''))
    aix_hardware = AIXHardware(module)
    device_facts = aix_hardware.get_device_facts()
    # assertions
    assert device_facts['devices']['hdisk0']['type'] == '00-00-01'
    assert device_facts['devices']['hdisk1']['type'] == '00-01-02'


# Generated at 2022-06-22 23:03:40.989133
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = MagicMock()
    ah = AIXHardware(module)
    ah.module.run_command = MagicMock(return_value=(0, '', ''))
    out_get_cpu_facts = ah.get_cpu_facts()
    assert out_get_cpu_facts['processor_count'] == 2
    assert out_get_cpu_facts['processor'] == 'PowerPC_POWER8'
    assert out_get_cpu_facts['processor_cores'] == 4


# Generated at 2022-06-22 23:03:48.306695
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModuleStub()

    hardware_collector = AIXHardwareCollector()
    hardware = hardware_collector.collect(module=module, collected_facts={})

    assert hardware
    assert hardware['processor']
    assert hardware['processor_cores']
    assert hardware['processor_count']
    assert hardware['memtotal_mb']
    assert hardware['memfree_mb']
    assert hardware['swaptotal_mb']
    assert hardware['swapfree_mb']
    assert hardware['firmware_version']
    assert hardware['product_serial']
    assert hardware['lpar_info']
    assert hardware['product_name']
    assert hardware['vgs']
    assert hardware['mounts']
    assert hardware['devices']


# 'name' and 'arguments' are required by AnsibleModule