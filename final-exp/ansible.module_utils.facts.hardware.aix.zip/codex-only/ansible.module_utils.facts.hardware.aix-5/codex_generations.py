

# Generated at 2022-06-22 22:53:56.441647
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModuleMock()
    hardware = AIXHardware(module)

    lsdev_cmd = '/usr/sbin/lsdev -Cc processor'
    lsattr_cmd = '/usr/sbin/lsattr -El '
    lsvg_path = module.get_bin_path("lsvg")
    xargs_path = module.get_bin_path("xargs")
    cmd = "%s -o | %s %s -p" % (lsvg_path, xargs_path, lsvg_path)
    lsconf_path = module.get_bin_path("lsconf")
    lsvg_path = module.get_bin_path("lsvg")
    xargs_path = module.get_bin_path("xargs")
    cmd = "%s -o | %s %s -p"

# Generated at 2022-06-22 22:54:08.548587
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    # Mock module
    module = AnsibleModule(argument_spec={})

    # Mock facts
    collected_facts = dict()

    # Create AIXHardware object
    aix_hardware_instance = AIXHardware(module)

    # Update facts
    aix_hardware_instance.populate(collected_facts)

    # Basic tests
    assert type(collected_facts) is dict
    assert 'firmware_version' in collected_facts
    assert 'product_name' in collected_facts
    assert 'product_serial' in collected_facts
    assert 'lpar_info' in collected_facts
    assert 'mounts' in collected_facts
    assert 'swapfree_mb' in collected_facts
    assert 'swaptotal_mb' in collected_facts
    assert 'memfree_mb' in collected_facts
   

# Generated at 2022-06-22 22:54:18.253345
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    cpu_facts = {}
    cpu_facts['processor'] = []

    rc, out, err = module.run_command("/usr/sbin/lsdev -Cc processor")
    if out:
        i = 0
        for line in out.splitlines():
            if 'Available' in line:
                if i == 0:
                    data = line.split(' ')
                    cpudev = data[0]
                i += 1
        cpu_facts['processor_count'] = int(i)
        rc, out, err = module.run_command("/usr/sbin/lsattr -El " + cpudev + " -a type")

        data = out.split(' ')
        cpu_facts['processor'] = data[1]


# Generated at 2022-06-22 22:54:24.756866
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    """
    Unit test for method get_memory_facts of class AIXHardware
    """
    aix_hardware = AIXHardware()
    memory_facts = aix_hardware.get_memory_facts()
    assert memory_facts
    assert memory_facts['memtotal_mb']
    assert memory_facts['memfree_mb']
    assert memory_facts['swaptotal_mb']
    assert memory_facts['swapfree_mb']


# Generated at 2022-06-22 22:54:27.263022
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    """
    This is the unit test of method get_cpu_facts of class AIXHardware
    """
    module = MockModule()
    hardware = AIXHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'PowerPC_POWER8'
    assert cpu_facts['processor_cores'] == 8
    assert cpu_facts['processor_count'] == 4


# Generated at 2022-06-22 22:54:38.987522
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    test_module = type('', (), {})()

# Generated at 2022-06-22 22:54:45.496895
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    aix_hardware_obj = AIXHardware()
    dmi_facts = aix_hardware_obj.get_dmi_facts()
    assert dmi_facts['product_name'] == '9117-MMA'
    assert dmi_facts['firmware_version'] == '3.3.0'
    assert dmi_facts['product_serial'] == '02D1B8B'

# Generated at 2022-06-22 22:54:51.101799
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    mem_facts = AIXHardware().get_memory_facts()
    assert mem_facts['memtotal_mb'] > 0
    assert mem_facts['memfree_mb'] > 0
    assert mem_facts['swaptotal_mb'] > 0
    assert mem_facts['swapfree_mb'] > 0

# Generated at 2022-06-22 22:54:56.262460
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    # Boiler-plate code to mock commands and statements
    mock_module = MagicMock()
    mock_module.lsdev = "lsdev"
    mock_module.lsattr = "lsattr"
    # lsattr -E -l device_name
    mock_module.lsattr_device_name = "/usr/sbin/lsattr -E -l device_name"
    # lsattr output
    lsattr_output = \
        "attr1 attr_value1\n" + \
        "attr2 attr_value2\n"

# Generated at 2022-06-22 22:55:08.133651
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    # Testing on AIX
    module = AnsibleModule(argument_spec={})
    hardware = module.params.copy()

    out = """
proc0 Available 00-00 Proc0 Processor
proc4 Available 00-04 Proc4 Processor
    """

    # Testing if processor count, processor type, processor cores are correctly retrieved
    lsdev_path = module.get_bin_path("lsdev")
    if lsdev_path:
        rc, out, err = module.run_command(lsdev_path + " -Cc processor")
        i = 0
        for line in out.splitlines():

            if 'Available' in line:
                if i == 0:
                    data = line.split(' ')
                    cpudev = data[0]
                i += 1
        assert (5 == i)

        rc, out, err = module.run

# Generated at 2022-06-22 22:55:17.363481
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware_obj = AIXHardware(module)
    hardware_obj.populate()
    hardware_obj.get_vgs_facts()

# Generated at 2022-06-22 22:55:29.436462
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    from ansible.compat.tests import unittest
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    import os
    import sys

    class AnsibleModuleMock(object):
        def __init__(self, *args, **kwargs):
            self.run_command_args = []
            self.run_command_positive_rcs = [0]

        def run_command(self, args, check_rc=True):
            self.run_command_args.append(args)
            rc = self.run_command_positive_rcs.pop(0)

# Generated at 2022-06-22 22:55:37.231904
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    class AIXHardwareMock:
        def run_command(self, cmd, use_unsafe_shell=False):
            return 0, AIX_MOUNT_OUT, ''
        def get_bin_path(self, cmd, required=False):
            return '/usr/bin/%s' % cmd
    class AIXHardware_get_mount_facts_test:
        def __init__(self):
            self.module = AIXHardwareMock()
    ah = AIXHardware_get_mount_facts_test()
    mount_facts = ah.module.get_mount_facts()

    assert mount_facts['mounts'][0]['options'] == 'rw,suid,intr,hard,proto=tcp,nointr,rsize=32768,wsize=32768'

# Generated at 2022-06-22 22:55:44.174409
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():

    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils._text import to_bytes

    aix_hardware = AIXHardware(None)

    lsdev_path = aix_hardware.module.get_bin_path("lsdev")
    lsattr_path = aix_hardware.module.get_bin_path("lsattr")
    mock_path = aix_hardware.module.get_bin_path("mock")


# Generated at 2022-06-22 22:55:45.099226
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    '''
    Unit test for constructor of class AIXHardwareCollector
    '''
    AIXHardwareCollector()

# Generated at 2022-06-22 22:55:54.690291
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    aix_hardware = AIXHardware()

# Generated at 2022-06-22 22:56:00.633806
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    test_AIXHardware = AIXHardware({'module_setup': True}, None, None)

    # Test 1
    out = "memory pages :    437791      . . . . . . . . . . total\n"
    out = out + "memory pages :       664      . . . . . . . . . . free\n"
    out = out + "memory pages :    437127      . . . . . . . . . . used\n"
    out = out + "memory pages :        1536      . . . . . . . . . . pinned\n"
    out = out + "memory pages :         60      . . . . . . . . . . page stealers\n"
    memory_facts = test_AIXHardware.get_memory_facts(out)

# Generated at 2022-06-22 22:56:13.539938
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.hardware.aix import AIXHardware

    class MockAIXModule(object):
        # Fake the xcrun binary not being present
        def get_bin_path(self, binary, required=False):
            if binary == "lsconf":
                return "/usr/sbin/lsconf"
            else:
                raise Exception("Unexpected call for binary: " + binary)

        # Fake the run_command function (run_command is wrapped in the module)

# Generated at 2022-06-22 22:56:14.323528
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware = AIXHardware()
    hardware.populate()

# Generated at 2022-06-22 22:56:26.646397
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    memtotal = 137438953472
    memfree = 7095306240
    swaptotal = 4294967295
    swapfree = 3595667968
    module = AnsibleModule(argument_spec={'filter': {'type': 'list', 'elements': 'str'}})

    hardware_obj = AIXHardware()

    # patch module.run_command

# Generated at 2022-06-22 22:56:33.759973
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = FakeModule()
    aix = AIXHardware(module)
    cpu_facts = aix.get_cpu_facts()
    assert cpu_facts['processor_count'] == 4
    assert cpu_facts['processor'] == "PowerPC_POWER8"
    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor'] == "PowerPC_POWER8"


# Generated at 2022-06-22 22:56:44.699420
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    # For testing purpose, we create a dummy module object
    module = type('', (), {})()

    # We will need to reget bin path as this method is dependent on its result.
    # To test it correctly, it is required to mock this method.
    module.get_bin_path = lambda *args: "/usr/bin/lsattr"

    module.run_command = lambda *args: (0, "sys0 Available 00-00-00 IBM,8233-E8B firmware  041B0165 IBM,8233-E8B", "")

    aix_hardware = AIXHardware(module)

    dmi_facts = aix_hardware.get_dmi_facts()

    assert dmi_facts['firmware_version'] == '041B0165'



# Generated at 2022-06-22 22:56:52.720326
# Unit test for method get_memory_facts of class AIXHardware

# Generated at 2022-06-22 22:57:01.339212
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})

    aix_hardware = AIXHardware(module)

    cpu_facts = aix_hardware.get_cpu_facts()

    assert cpu_facts

    assert 'processor_count' in cpu_facts
    assert cpu_facts['processor_count'] == 1
    assert 'processor' in cpu_facts
    assert cpu_facts['processor'] == 'PowerPC_POWER7'
    assert 'processor_cores' in cpu_facts
    assert cpu_facts['processor_cores'] == 1


# Generated at 2022-06-22 22:57:13.109666
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    facts = {}
    out_lsdev = """type:
Available
Processor
Available
Processor
Available
Processor
Available
Processor
Available
Processor
Available
Processor
Available
Processor
Available
Processor
Available
Processor
Available
Processor
"""
    out_lsattr = """type: type
powerpc_POWER8
"""
    return_code = 0
    test_object = AIXHardware(facts)
    test_object.module.run_command = Mock(
        return_value=(
            return_code,
            out_lsdev,
            ''
        )
    )
    test_object.module.run_command = Mock(
        return_value=(
            return_code,
            out_lsattr,
            ''
        )
    )

# Generated at 2022-06-22 22:57:21.088634
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    from ansible.module_utils.facts.hardware.base import Hardware
    hw = Hardware()
    hw.module = MockModule()
    facts = hw.get_device_facts()

    # Verify that the function returned a dictionary
    assert type(facts) is dict

    # Verify that the dictionary contains a key 'devices'
    assert 'devices' in facts.keys()

    # Verify that the value of the 'devices' key is a dictionary
    assert type(facts['devices']) is dict

    # Verify that the 'devices' dictionary contains a key 'ent0'
    assert 'ent0' in facts['devices'].keys()

    # Verify that the 'ent0' key has a string value for the state key
    assert type(facts['devices']['ent0']['state']) is str

    # Verify that the 'ent0

# Generated at 2022-06-22 22:57:23.975758
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardwareCollector = AIXHardwareCollector()
    assert hardwareCollector._platform == 'AIX'
    assert hardwareCollector._fact_class == AIXHardware


# Generated at 2022-06-22 22:57:30.405107
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    aix_hardware = AIXHardware({})
    aix_hardware.module = MockModule()
    aix_hardware.module.run_command = run_command_mock

    aix_hardware.get_dmi_facts()

    assert aix_hardware.facts['firmware_version'] == 'DETERMINED'
    assert aix_hardware.facts['product_serial'] == 'DETERMINED'
    assert aix_hardware.facts['lpar_info'] == 'DETERMINED'



# Generated at 2022-06-22 22:57:37.084147
# Unit test for constructor of class AIXHardware
def test_AIXHardware():

    module = AnsibleModule(argument_spec={})
    hardware_collector = AIXHardwareCollector(module=module)
    hardware = AIXHardware(module)

    logger.debug("AIXHardwareCollector._platform = %s" % hardware_collector._platform)
    logger.debug("AIXHardwareCollector._fact_class = %s" % hardware_collector._fact_class)

    assert hardware_collector._platform == 'AIX'
    assert hardware_collector._fact_class == AIXHardware

    assert hardware.platform == 'AIX'
    assert hardware.populate() == hardware.get_facts()


# Generated at 2022-06-22 22:57:45.641204
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hw = AIXHardware({})
    assert hw.populate()['ansible_facts']
    assert hw.populate()['ansible_facts']['ansible_processor_cores'] == 2
    assert hw.populate()['ansible_facts']['ansible_processor_count'] == 2
    assert 'ansible_processor' in hw.populate()['ansible_facts']['ansible_processor']
    assert hw.populate()['ansible_facts']['ansible_memtotal_mb'] == 32768
    assert hw.populate()['ansible_facts']['ansible_memfree_mb'] == 9280
    assert hw.populate()['ansible_facts']['ansible_swaptotal_mb'] == 1126
    assert hw.populate

# Generated at 2022-06-22 22:57:48.010832
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hwc = AIXHardwareCollector()
    assert hwc._platform == 'AIX'
    assert hwc._fact_class == AIXHardware

# Generated at 2022-06-22 22:57:54.306541
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec=dict())

    # Construct an object of AIXHardware
    ah = AIXHardware(module)

    if ah.get_mount_facts():
        module.exit_json(changed=False)
    else:
        module.fail_json(msg="test_AIXHardware_get_mount_facts failed")



# Generated at 2022-06-22 22:58:03.090312
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    hardware = AIXHardware({})
    test_data = {
        '''memory pages:   1037593
        free pages:      645324
        ''': {
            'memfree_mb': 2653,
            'memtotal_mb': 5079
        },
        '''memory pages:   1037593
        free pages:      698244
        ''': {
            'memfree_mb': 2842,
            'memtotal_mb': 5079
        },
    }

    for out, result in test_data.items():
        memory_facts = hardware.get_memory_facts()
        for key in result:
            assert memory_facts[key] == result[key]

        # '''.format(out)
        #
        # memory_facts = hardware.get_memory_facts()
        #
        # assert

# Generated at 2022-06-22 22:58:08.994799
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    aixhardware = AIXHardware({})
    cpu_facts = aixhardware.get_cpu_facts()

    assert type(cpu_facts['processor_count']) is int
    assert cpu_facts['processor'] != ''



# Generated at 2022-06-22 22:58:17.083370
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    hardware_obj = AIXHardwareCollector(module=module)
    hardware_obj.collect()
    result = module.exit_json(ansible_facts=module.params['gather_subset'])

    print(result)


# Generated at 2022-06-22 22:58:23.823757
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    import module_utils.facts.hardware.aix as aix_module

    testmodule = aix_module.AIXHardware()
    vgs_facts = testmodule.get_vgs_facts()

    assert 'vgs' in vgs_facts
    for k in vgs_facts['vgs'].keys():
        assert len(vgs_facts['vgs'][k]) > 0

# Generated at 2022-06-22 22:58:29.213933
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module_mock = AnsibleModuleMock()
    lscpu_out = """processor 0:0
processor 0:1
processor 0:2
processor 1:0
processor 1:1
processor 1:2
processor 2:0
processor 2:1
processor 2:2
processor 3:0
processor 3:1
processor 3:2
"""
    module_mock.run_command.return_value = (0, lscpu_out, '')
    ah = AIXHardwareCollector(module=module_mock)
    ah.populate()
    assert ah.hw.processor_count == 12
    

# Generated at 2022-06-22 22:58:30.790332
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware_facts = AIXHardware()
    assert hardware_facts.platform == 'AIX'

# Generated at 2022-06-22 22:58:43.087301
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    aixhw = AIXHardware(dict())

    out_lsdev = """en0 Available     08-08-A5 Ethernet IVE
en1 Defined       08-08-A5 Ethernet IVE"""


# Generated at 2022-06-22 22:58:49.007602
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = type('', (), {})()
    module.run_command = type('', (), {})()
    module.run_command.return_value = (0, 'output', 'error')
    module.get_bin_path = type('', (), {})()
    module.get_bin_path.return_value = 'path'

    aixhw = AIXHardware(module)
    device_facts = aixhw.get_device_facts()

    assert 'devices' in device_facts
    assert isinstance(device_facts['devices'], dict)



# Generated at 2022-06-22 22:58:56.912573
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    facts = hardware.get_device_facts()
    # ensure facts is a dict
    assert isinstance(facts, dict)
    # ensure keys match readable output for devices
    for dev_name in facts['devices'].keys():
        assert facts['devices'][dev_name] == hardware.read_file_lines('/dev/null', dev_name)


# Generated at 2022-06-22 22:59:01.990940
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=[], type='list')
        ),
        supports_check_mode=True
    )
    hardware_collector = AIXHardwareCollector(module=module)
    assert hardware_collector._fact_class == AIXHardware
    assert hardware_collector.platform == 'AIX'



# Generated at 2022-06-22 22:59:11.704141
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    import sys

    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts.utils import CoreFactCollector


# Generated at 2022-06-22 22:59:15.352563
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )

    hardware_obj = AIXHardware(module=module)
    cpu_facts = hardware_obj.get_cpu_facts()
    assert cpu_facts['processor'] == 'PowerPC_POWER8'
    assert cpu_facts['processor_count'] == 32
    assert cpu_facts['processor_cores'] == 8



# Generated at 2022-06-22 22:59:26.472348
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    hardware = AIXHardware({})

    rc, out, err = hardware.module.run_command("/usr/sbin/lsattr -El sys0 -a fwversion")
    data = out.split()
    assert data[1].strip('IBM,') == hardware.get_dmi_facts()['firmware_version']

    lsconf_path = hardware.module.get_bin_path("lsconf")
    if lsconf_path:
        rc, out, err = hardware.module.run_command(lsconf_path)
        if rc == 0 and out:
            for line in out.splitlines():
                data = line.split(':')
                if 'Machine Serial Number' in line:
                    assert data[1].strip() == hardware.get_dmi_facts()['product_serial']

# Generated at 2022-06-22 22:59:32.910986
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    hw = AIXHardware(None)
    out = 'proc0 Available 00-00 Processor'
    result = hw.get_cpu_facts()
    assert result['processor'] == '00-00'
    assert result['processor_cores'] == 1
    assert result['processor_count'] == 1



# Generated at 2022-06-22 22:59:43.098656
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = FakeModule()
    hardware = AIXHardware(module)


# Generated at 2022-06-22 22:59:46.591585
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()

    assert(hardware_collector.platform == 'AIX')


# Generated at 2022-06-22 22:59:56.164537
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    class MockModule(object):
        def __init__(self, *args, **kwargs):
            self.params = {
                'lsconf_path': '/usr/sbin/lsconf',
                'bin_path': '/usr/sbin'
            }

        def get_bin_path(self, binary, required=True):
            if binary == 'lsconf':
                return self.params['lsconf_path']
            else:
                return self.params['bin_path']

        def run_command(self, command, use_unsafe_shell=False):
            if command == '/usr/sbin/lsattr -El sys0 -a fwversion':
                return 0, " fwversion IBM,U810.02.33.00.1", ""

# Generated at 2022-06-22 22:59:59.128668
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)

    # test populate method
    return hardware.populate()



# Generated at 2022-06-22 23:00:10.082816
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    """
    Class AIXHardware
    method populate
    Test case 1 (general)
    Test case 2 (memory)
    Test case 3 (cpu)
    Test case 4 (dmi)
    Test case 5 (vg)
    Test case 6 (mount)
    Test case 7 (devices)
    Test case 8 (os_version)
    """
    import os
    import sys
    import unittest
    import mock
    import ansible.module_utils.facts.collector.solaris

    # The module const.py will be loaded before configuration file is loaded.
    # Define the common configuration here as a mock.
    mock_conf = mock.MagicMock()
    mock_conf.filename = 'test.cfg'
    mock_conf.url = 'https://localhost:8443/test'
    mock_conf.http_

# Generated at 2022-06-22 23:00:20.828955
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    import sys
    import json
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.aix import AnsibleModule
    mypath = os.path.abspath(os.path.dirname(__file__))
    modulepath = mypath + "/../../../../lib/ansible/module_utils/aix/hardware.py"
    sys.path.append(modulepath)
    sys.path.append(mypath)
    from hardware import AIXHardware
    args = {"base_output_dir": "/tmp/ansible-aix-output-dir",
            "base_prefix": "ansible_aix_"}
    module = AnsibleModule(argument_spec=args)
    h = AIXHardware(module)
    fact = h.get_device_facts()
   

# Generated at 2022-06-22 23:00:30.493628
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    hardware_facts = AIXHardware(module)
    hardware_facts.populate()
    hardware_facts_result = hardware_facts.as_dict()

    # Test that the key processor is a list
    assert isinstance(hardware_facts_result['processor'], list)
    # Test that the key processor_cores is an integer
    assert isinstance(hardware_facts_result['processor_cores'], int)
    # Test that the key processor_count is an integer
    assert isinstance(hardware_facts_result['processor_count'], int)

    # Test that the key memtotal_mb is an integer
    assert isinstance(hardware_facts_result['memtotal_mb'], int)
    #

# Generated at 2022-06-22 23:00:37.667953
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():

    # to mimic the module object we are using the Mock object.
    module = Mock()
    module.run_command.return_value = (1, '0 memory pages\n', '')
    aix_hardware = AIXHardware(module)
    facts = aix_hardware.get_memory_facts()
    assert 'memtotal_mb' in facts
    assert facts['memtotal_mb'] == 0
    assert 'memfree_mb' in facts
    assert facts['memfree_mb'] == 0


# Generated at 2022-06-22 23:00:39.355215
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    cpus = AIXHardware.get_cpu_facts()
    assert cpus['processor_count'] == 1


# Generated at 2022-06-22 23:00:52.293370
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    class AIXHardware_Mock(AIXHardware):
        def __init__(self, *args, **kwargs):
            self.module = MockModule()
            self.module.run_command = mock_run_command(**kwargs)

    def mock_run_command(**kwargs):
        def mock_run_command_inner(cmd, *args, **kwargs):
            if cmd[1] == '-o':
                return 0, '\n'.join(kwargs['lsdev_out']), None
            elif cmd[2] == '-l':
                return 0, '\n'.join(kwargs['lsattr_out']), None
            else:
                raise ValueError('Unknown command: %s' % cmd)

        return mock_run_command_inner


# Generated at 2022-06-22 23:01:04.715239
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    class MockModule(object):
        def __init__(self, *args, **kwargs):
            self.params = {'gather_timeout': 1}

        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin'

        def run_command(self, *args, **kwargs):
            return 0, 'hdisk0 Available 03-08-00-1,0 16 Bit LVD SCSI Disk Drive\nhdisk1 Available 03-08-00-1,0 16 Bit LVD SCSI Disk Drive\nfcs0  Defined   Fibre Channel SCSI I/O Controller\nsf0   Available 03-08-00-5,0 16 Bit LVD SCSI Processor Device\n', ''


# Generated at 2022-06-22 23:01:11.120683
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    """
    This test is not meant to be executed, just to be imported and nose used
    to test it with:
    nosetests -s -v -w test/unit/ hardware/test_aix.py

    :return:
    """
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)

    # with no args, all mounts should be returned, with no exception raised
    assert hardware.get_mount_facts()

# Generated at 2022-06-22 23:01:15.619299
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    # create an object
    my_obj = AIXHardwareCollector()

    # test platform of object
    assert my_obj.platform == 'AIX'

    # test fact_class of object
    assert my_obj.fact_class == AIXHardware



# Generated at 2022-06-22 23:01:25.527254
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )
    # Override this method to return static value
    # to be used in test_AIXHardware_get_dmi_facts
    def get_bin_path(self, arg, required=False):
        if arg == 'lsconf':
            return '/usr/sbin/lsconf'
        else:
            return None

    module.get_bin_path = get_bin_path.__get__(module)

    # Define a static value for lsconf output to be used
    # in test_AIXHardware_get_dmi_facts

# Generated at 2022-06-22 23:01:28.724705
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    collector = AIXHardwareCollector()
    assert collector._platform == 'AIX'
    assert collector._fact_class == AIXHardware

# Generated at 2022-06-22 23:01:40.302317
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    import os

    facts = {}
    for f in FactCollector().get_facts([]).values():
        facts.update(f)

    hardware = AIXHardware(None, facts)
    hardware.module.run_command = run_command
    hardware.module.get_bin_path = get_bin_path

    device_facts = hardware.get_device_facts()
    assert device_facts['devices']
    # test if device's attributes are populated
    assert device_facts['devices']['en0']['attributes']
    assert 'en0' in device_facts['devices']

# Generated at 2022-06-22 23:01:46.012449
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    # Create the class to be tested
    aix_hardware = AIXHardware()

    # Define the expected results
    expected_result = {'processor_count': 2,
                       'processor': 'POWER8'}

    # Get the facts
    result = aix_hardware.get_cpu_facts()

    assert result == expected_result



# Generated at 2022-06-22 23:01:57.621053
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    ah = AIXHardware()
    vgs_facts = ah.get_vgs_facts()
    assert 'vgs' in vgs_facts
    assert 'rootvg' in vgs_facts['vgs']
    assert len(vgs_facts['vgs']['rootvg']) == 2
    assert 'hdisk0' in vgs_facts['vgs']['rootvg']
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs_facts['vgs']['rootvg'][0]['pv_state'] == 'active'
    assert vgs_facts['vgs']['rootvg'][0]['total_pps'] == '546'

# Generated at 2022-06-22 23:02:09.890983
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    aixhw = AIXHardware()
    aixhw.module = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    aixhw.module_commands = {}
    aixhw.module_commands['lsvg'] = 'lsvg_output'


# Generated at 2022-06-22 23:02:22.620951
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware

    module = AnsibleModule(argument_spec=dict())

    aix_hardware = AIXHardware(module)

    vgs_facts = aix_hardware.get_vgs_facts()
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs_facts['vgs']['rootvg'][0]['pv_state'] == 'active'
    assert vgs_facts['vgs']['rootvg'][0]['total_pps'] == '546'
    assert vgs_facts['vgs']['rootvg'][0]['free_pps'] == '0'

# Generated at 2022-06-22 23:02:30.104024
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    from ansible.module_utils.facts import ModuleFactCollector
    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec=dict()
    )
    module.params = dict()
    collector = ModuleFactCollector(module=module)
    test_class = AIXHardware(module=module)
    result = test_class.get_device_facts()
    collector._update_facts(result)
    assert 'devices' in collector.facts



# Generated at 2022-06-22 23:02:39.476634
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    ah = AIXHardware()
    ah.module = FakeAnsibleModule()
    ah.module.get_bin_path = Mock(return_value=True)
    ah.module.run_command = Mock(return_value=(0, 'node /dev/hd4       /dev/hd4  jfs   2       Wed Jun 12 11:28:04 2013', ''))

    mount_facts = ah.get_mount_facts()


# Generated at 2022-06-22 23:02:40.624115
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware = AIXHardware({})
    assert hardware.platform == 'AIX'

# Generated at 2022-06-22 23:02:48.314725
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    """Test AIXHardware.get_mount_facts() method"""
    module = AnsibleModuleMock()
    AIX_hardware = AIXHardware(module)
    result = AIX_hardware.get_mount_facts()
    expected_result = {
        'mounts': [{
            'mount': '/',
            'fstype': 'jfs2',
            'device': '/dev/hd4',
            'options': 'rw',
            'time': 'Tue Mar 24 19:16:19 2020',
            'size_total': 15302983008,
            'size_available': 3970013184
        }]
    }
    assert result == expected_result


# Generated at 2022-06-22 23:02:57.710591
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    from ansible.module_utils.facts import FactRetrievalError
    AIXHardware.module = MockModule()
    vgs_facts = AIXHardware().get_vgs_facts()
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs_facts['vgs']['rootvg'][0]['pv_state'] == 'active'
    assert vgs_facts['vgs']['rootvg'][0]['total_pps'] == '546'
    assert vgs_facts['vgs']['rootvg'][0]['free_pps'] == '0'
    assert vgs_facts['vgs']['testvg'][0]['pp_size'] == '4 megabyte(s)'
    assert vgs_

# Generated at 2022-06-22 23:02:58.939179
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    assert(issubclass(AIXHardware, Hardware))


# Generated at 2022-06-22 23:03:02.932538
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    """Unit test for constructor of class AIXHardwareCollector"""
    aix_hardware_collector = AIXHardwareCollector()

    assert aix_hardware_collector.get_platform() == 'AIX'
    assert aix_hardware_collector.get_fact_class() == AIXHardware



# Generated at 2022-06-22 23:03:15.158023
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(
        argument_spec={
            'gather_subset': dict(default=['all'], type='list'),
            'filter': dict(default=None, required=False),
        }
    )

    aix_hardware_instance = AIXHardware()
    aix_hardware_instance.module = module

    dmi_facts = aix_hardware_instance.get_dmi_facts()

    assert dmi_facts['firmware_version'] == 'IBM,'
    assert dmi_facts['lpar_info'] == '1'
    assert dmi_facts['product_name'] == 'IBM,9117-MMB'
    assert dmi_facts['product_serial'] == '1234'



# Generated at 2022-06-22 23:03:20.619808
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    hw = AIXHardware()
    rc, out, err = hw.module.run_command('printf "proc0\nproc1\n"')
    setattr(hw.module, 'run_command', lambda *args, **kwargs: (rc, out, err))
    cpu_facts = hw.get_cpu_facts()
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'PowerPC_POWER7'



# Generated at 2022-06-22 23:03:30.916511
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils._text import to_text

    test_aix_mount_facts = AIXHardware()
    test_mount_facts = {}

    test_mount_facts = test_aix_mount_facts.get_mount_facts()
    expected_mount_facts = get_file_content(
        "../../../../../test/integration/output/aix_mount_facts")
    assert to_text(expected_mount_facts) == to_text(test_mount_facts)

# Generated at 2022-06-22 23:03:36.011613
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)

    cpu_facts = hardware.get_cpu_facts()

    assert cpu_facts['processor'] == 'PowerPC_POWER8'
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor_cores'] == 16



# Generated at 2022-06-22 23:03:42.918042
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    """
        Test AIXHardware class get_dmi_facts method.
    """
    fake_module = AnsibleModule(
            argument_spec=dict(),
            supports_check_mode=True)
    fake_module.run_command = Mock(return_value=(0, "IBM,8247-21L", ""))

    aix_hw = AIXHardware(fake_module)
    aix_vars = aix_hw.get_dmi_facts()

    assert aix_vars == {'firmware_version': '8247-21L'}

# Generated at 2022-06-22 23:03:54.567073
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    aix_hw = AIXHardware(module)
    result = aix_hw.populate()

    assert result['memory_facts']['memtotal_mb'] == 4192
    assert result['memory_facts']['memfree_mb'] == 405
    assert result['memory_facts']['swaptotal_mb'] == 314260
    assert result['memory_facts']['swapfree_mb'] == 314255
    assert result['dmi_facts']['product_name'] == 'IBM,8204-E8A'
    assert result['dmi_facts']['product_serial'] == 'E510A0A'