

# Generated at 2022-06-22 22:53:52.494052
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    facts = AIXHardwareCollector()
    fact = facts._fact_class()
    vgs_facts = fact.get_vgs_facts()
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs_facts['vgs']['rootvg'][0]['pv_state'] == 'active'
    assert vgs_facts['vgs']['rootvg'][0]['total_pps'] == '546'
    assert vgs_facts['vgs']['rootvg'][0]['free_pps'] == '0'
    assert vgs_facts['vgs']['rootvg'][0]['pp_size'] == '4 megabyte(s)'

# Generated at 2022-06-22 22:53:57.313576
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
    )

    hardware = AIXHardware(module)
    result = hardware.get_device_facts()

    assert len(result) > 0
    assert isinstance(result['devices'], dict)

# Generated at 2022-06-22 22:54:09.426134
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware()
    hardware_facts = hardware.populate()

    assert hardware_facts['processor'][0] == "PowerPC_POWER8"
    assert hardware_facts['processor_count'] == 1
    assert hardware_facts['processor_cores'] == 16
    assert hardware_facts['memtotal_mb'] == 8186
    assert hardware_facts['memfree_mb'] == 2663
    assert hardware_facts['swaptotal_mb'] == 131072
    assert hardware_facts['swapfree_mb'] == 121601
    assert hardware_facts['firmware_version'] == "06A1410001051A1002A9"
    assert hardware_facts['product_serial'] == "P215A11A"

# Generated at 2022-06-22 22:54:20.577405
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    class MockModule(object):
        def __init__(self, cmd_out):
            self.cmd_out = cmd_out
        def run_command(self, command, *args, **kwargs):
            if command == '/usr/sbin/lsattr -El sys0 -a fwversion':
                return 0, self.cmd_out, ''

    aix_hw = AIXHardware({})
    cmd_out = 'fwversion IBM,8233-E8B'

    aix_hw.module = MockModule(cmd_out)
    assert aix_hw.get_dmi_facts() == {'firmware_version': '8233-E8B'}

    cmd_out = 'fwversion IBM,8247-42L'

    aix_hw.module = MockModule(cmd_out)

# Generated at 2022-06-22 22:54:26.728397
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = AIXHardware(module=module)


# Generated at 2022-06-22 22:54:30.324306
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():

    # Created an object of class AIXHardwareCollector
    obj = AIXHardwareCollector(None)

    # Check whether the created object is an instance of class AIXHardwareCollector
    assert isinstance(obj, AIXHardwareCollector)

# Generated at 2022-06-22 22:54:39.821313
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    out = """proc0 Available 00-00 Processor 0
proc4 Available 00-04 Processor 4
proc8 Available 00-08 Processor 8
proc12 Available 00-12 Processor 12"""

    module.run_command = MagicMock(return_value=(0, out, ''))

    hw_fact = AIXHardware(module)
    cpu_facts = hw_fact.get_cpu_facts()

    assert cpu_facts['processor'] == 'PowerPC_POWER9'
    assert cpu_facts['processor_count'] == 4
    assert cpu_facts['processor_cores'] == 1


# Generated at 2022-06-22 22:54:52.509688
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    class module(object):
        def __init__(self, name):
            self.name = name
            self.params = {}

        def get_bin_path(self, binary, required=True):
            self.binary = binary
            if required:
                return '/usr/sbin/lsvg'
            else:
                return False

        def run_command(self, cmd, use_unsafe_shell=False):
            self.cmd = cmd
            return 0, vg_out, []

    aix = AIXHardware()
    aix.module = module('AIXHardware')


# Generated at 2022-06-22 22:54:58.921533
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    test_module = AnsibleModule(argument_spec={})
    test_class = AIXHardware(module=test_module)
    test_class.module.params['gather_subset'] = [
        '!all', 'memory']
    test_class.module.params['filter'] = '*'
    test_out = test_class.populate()
    assert 'memtotal_mb' in test_out
    assert 'memfree_mb' in test_out
    assert 'swaptotal_mb' in test_out
    assert 'swapfree_mb' in test_out


# Generated at 2022-06-22 22:55:10.969145
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    test = AIXHardware('module')
    output = """rootvg:
PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
hdisk0            active            546         0           00..00..00..00..00
hdisk1            active            546         113         00..00..00..21..92
realsyncvg:
PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
hdisk74           active            1999        6           00..00..00..00..06
testvg:
PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
hdisk105          active            999         838         200..39..199..200..200
hdisk106          active            999         599         200..00..00..199..200
"""
    test

# Generated at 2022-06-22 22:55:13.847170
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={})
    hardware_facts = AIXHardware(module)
    assert hardware_facts is not None


# Generated at 2022-06-22 22:55:17.276203
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    facts = AIXHardware()
    assert facts.platform == 'AIX'
    assert facts.version == '7.2'
    assert facts.hostname == 'myserver'

# Generated at 2022-06-22 22:55:29.388063
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = MockAnsibleModule()
    module.run_command = Mock(return_value=(1, '', ''))
    AIXHardware.module = module
    AIXHardware.lsvg = Mock(return_value=None)
    AIXHardware.xargs = Mock(return_value=None)
    vgs_facts = AIXHardware().get_vgs_facts()
    assert vgs_facts == {}

    module.run_command = Mock(return_value=(0, vgs_output, ''))
    AIXHardware.lsvg = Mock(return_value='/usr/sbin/')
    AIXHardware.xargs = Mock(return_value='/usr/bin/')
    vgs_facts = AIXHardware().get_vgs_facts()
    assert vgs_facts == vgs_facts_expected

   

# Generated at 2022-06-22 22:55:39.505509
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    from ansible.module_utils.facts.collector import get_collector
    from ansible.module_utils.facts.utils import DEFAULT_COLLECTORS

    # create fake facts module
    module = AnsibleModule(argument_spec={})
    module.params = {
        'gather_subset': ['default'],
        'gather_timeout': 10,
        'filter': '*'
    }

    # create a collector without loading any data
    fact_collector = get_collector(module=module, collectors=DEFAULT_COLLECTORS)

    # create a AIXHardware object
    hw = AIXHardware(module)

    # call the method to test
    device_facts = hw.get_device_facts()

    # test if dict returned has the expected structure

# Generated at 2022-06-22 22:55:49.863080
# Unit test for method get_device_facts of class AIXHardware

# Generated at 2022-06-22 22:55:58.143927
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module=module)


# Generated at 2022-06-22 22:56:07.091881
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    import sys
    import json

    # The test input is taken from a 'vmstat -v' command output on a dockerized AIX
    # A dockerized AIX can be obtained by running:
    #
    #  $ docker run --rm -it aix/aix:latest /bin/bash
    #
    # The test output is taken from a python3 shell, where the get_memory_facts() method
    # has been invoked with vmstat_out as input.

# Generated at 2022-06-22 22:56:10.536588
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector._platform == 'AIX'
    assert hardware_collector._fact_class.platform == 'AIX'


# Generated at 2022-06-22 22:56:19.187878
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    import os
    test_hostname = 'test_hostname'
    test_memtotal_mb = 123456789
    test_memfree_mb = 123
    test_swaptotal_mb = 2
    test_swapfree_mb = 1
    test_processor = [u'PowerPC_POWER8', u'PowerPC_POWER8']
    test_processor_cores = 44
    test_processor_count = 1
    test_firmware_version = 'test_firmware_version'
    test_product_serial = 'test_product_serial'
    test_lpar_info = 'test_lpar_info'
    test_product_name = 'test_product_name'

# Generated at 2022-06-22 22:56:29.824621
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    import re
    import sys
    # Python 2 and 3 support
    if sys.version_info > (3,):
        unicode = str

    class RunCommand:
        def __init__(self):
            self.stdout = u"fwversion IBM,80910CZ"
            self.stderr = u''

    class Module:
        def __init__(self):
            self.run_command = RunCommand()

    class AIXHardware:
        def __init__(self):
            self.module = Module()
            self.platform = 'AIX'

        def populate(self):
            self.get_dmi_facts()

    aix_hardware = AIXHardware()
    aix_hardware.populate()

# Generated at 2022-06-22 22:56:40.430375
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(
        argument_spec=dict()
    )
    hardware_collector = AIXHardwareCollector(module=module)
    hardware = hardware_collector.collect()['ansible_facts']['ansible_hardware']
    assert hardware['processor_count'] == 1
    assert hardware['processor'] == 'POWER6'
    assert hardware['processor_cores'] == 4
    assert hardware['memtotal_mb'] > 49152
    assert hardware['memfree_mb'] > 32768
    assert hardware['swaptotal_mb'] > 49152
    assert hardware['swapfree_mb'] > 32768
    assert hardware['mounts'][0]['device'] == '/dev/hd1'
    assert hardware['mounts'][0]['mount'] == '/'

# Generated at 2022-06-22 22:56:42.999197
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(
        argument_spec={}
    )
    ah = AIXHardware(module=module)
    ah.populate()



# Generated at 2022-06-22 22:56:51.441141
# Unit test for method populate of class AIXHardware

# Generated at 2022-06-22 22:57:02.698991
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={},
                           supports_check_mode=False)
    hardware_info = AIXHardware(module)
    devices_facts = hardware_info.get_device_facts()

    assert 'devices' in devices_facts.keys(), \
        "device_facts must be a dict containing a key 'devices' but it is: %s" % devices_facts
    assert isinstance(devices_facts['devices'], dict)

    for device in devices_facts['devices']:
        assert 'state' in devices_facts['devices'][device].keys(), \
        "device_facts must be a dict containing a key 'state' for each device"
        assert 'type' in devices_facts['devices'][device].keys(), \
        "device_facts must be a dict containing a key 'type' for each device"
       

# Generated at 2022-06-22 22:57:14.020080
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)

    result = hardware.get_mount_facts()
    assert 'mounts' in result
    assert isinstance(result['mounts'], list)

    if len(result['mounts']) > 0:
        test_mount_entry = result['mounts'][0]
        assert 'mount' in test_mount_entry
        assert 'device' in test_mount_entry
        assert 'fstype' in test_mount_entry
        assert 'options' in test_mount_entry
        assert 'time' in test_mount_entry
        assert 'space_total' in test_mount_entry
        assert 'space_used' in test_mount_entry
        assert 'space_free' in test_mount_entry
        assert 'space_percent'

# Generated at 2022-06-22 22:57:21.384853
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    module = AnsibleModule(argument_spec={})
    aixhardware_collector = AIXHardwareCollector(module)
    assert aixhardware_collector.get_facts()['ansible_facts']['ansible_processor_cores'] == 2
    assert aixhardware_collector.get_facts()['ansible_facts']['ansible_processor'] == ['PowerPC_POWER9']
    assert aixhardware_collector.get_facts()['ansible_facts']['ansible_processor_count'] == 20
    assert aixhardware_collector.get_facts()['ansible_facts']['ansible_memtotal_mb'] == 16384

# Test script that runs module with all the arguments required to run successfully

# Generated at 2022-06-22 22:57:32.391783
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    hardware = AIXHardware()
    hardware.module = MockModule()

# Generated at 2022-06-22 22:57:39.982000
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    hardware = AIXHardware()
    hardware.module = MagicMock()
    setattr(hardware, 'module', MagicMock())
    hardware.module.run_command.return_value = (0, "4   memory pages", "")
    hardware.module.run_command.return_value = (0, "2   free pages", "")
    hardware_facts = hardware.get_memory_facts()
    assert hardware_facts['memtotal_mb'] == 1 #Because pageCount * pageSize is 4kB
    assert hardware_facts['memfree_mb'] == 1 #Because freeCount * pageSize is 4kB


# Generated at 2022-06-22 22:57:51.921036
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    import re
    import json
    module = MockModule()
    hw = AIXHardware(module)

    lsdev_out = '''ent0             Available 00-00-02
ent1             Available 00-00-03
lo0              Available
lo0              Defined
lo0              Defined
lo0              Defined
lo0              Defined
lo0              Defined
lo0              Defined
lo0              Defined
lo0              Defined
lo0              Defined
'''


# Generated at 2022-06-22 22:57:58.905996
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    # Setup
    module_spec = dict()
    module_spec['argument_spec'] = dict()
    module_spec['params'] = dict()

    from ansible.module_utils.facts.aix import AIXHardwareCollector
    aix_hw_collector = AIXHardwareCollector()
    aix_hw_collector.collect(module_spec)
    class_name = type(aix_hw_collector).__name__
    assert class_name == "AIXHardwareCollector"


# Generated at 2022-06-22 22:58:00.441638
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    """
    This method is used to test the get_vgs_facts method of AIXHardware
    """
    assert True

# Generated at 2022-06-22 22:58:12.200642
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    vmstat = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    vmstat.run_command = MagicMock(return_value=(0, 'Total:           2048000                memory pages\n', ''))

    lsps = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    lsps.run_command = MagicMock(return_value=(0, 'Total Paging Space Percent Used: 0%\n', ''))

    AIXHardware.vmstat = vmstat
    AIXHardware.lsps = lsps

    hardware = AIXHardware(module)
    facts = hardware.get_memory_facts()

# Generated at 2022-06-22 22:58:24.944277
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch

    mock_module = patch('ansible_collections.ansible.community.tests.unit.module_utils.facts.hardware.aix.module')
    mock_runcommand = patch('ansible_collections.ansible.community.tests.unit.module_utils.facts.hardware.aix.run_command')
    mock_get_bin_path = patch('ansible_collections.ansible.community.tests.unit.module_utils.facts.hardware.aix.get_bin_path')

    mock_module = mock_module.start()
    mock_runcommand = mock_runcommand.start()
    mock_get_bin_path = mock_get_bin_path.start()
    mock_module.ls

# Generated at 2022-06-22 22:58:32.937360
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    test_module = AnsibleModule(
        argument_spec = dict()
    )

    test_obj = AIXHardware(module=test_module)

    test_dmi_facts = {'firmware_version': '1S51005_5200011',
                      'lpar_info': '00C8C3C0 4 CEC1C9C9C9C9C9C9',
                      'product_name': '8233-E8B',
                      'product_serial': '05G5138'}

    assert test_obj.get_dmi_facts() == test_dmi_facts

# Generated at 2022-06-22 22:58:37.450697
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    a = AIXHardware({}, dict())
    cpu_facts = a.get_cpu_facts()
    assert('processor' in cpu_facts)
    assert('processor_count' in cpu_facts)
    assert('processor_cores' in cpu_facts)


# Generated at 2022-06-22 22:58:40.008246
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    """
    Test class constructor of AIXHardware
    """
    module = DummyModule()
    hw = AIXHardware(module)

    assert hw.module == module
    assert hw.platform == 'AIX'



# Generated at 2022-06-22 22:58:52.037805
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    facts = hardware.populate()
    assert facts['processor'][0] == 'PowerPC_POWER8'
    assert facts['processor_cores'] == 4
    assert facts['processor_count'] == 2
    assert facts['memtotal_mb'] == 7823
    assert facts['memfree_mb'] == 8
    assert facts['swaptotal_mb'] == 314368
    assert facts['swapfree_mb'] == 314368
    assert facts['firmware_version'] == 'CPC710_091'
    assert facts['lpar_info'] == '1'
    assert facts['product_name'] == 'IBM,8286-41A'
    assert facts['product_serial'] == 'YVA8WY1'


# Generated at 2022-06-22 22:58:59.482594
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    aix_hardware = AIXHardware(module)
    dmi_facts = aix_hardware.get_dmi_facts()
    assert dmi_facts['firmware_version']
    assert dmi_facts['product_serial']
    assert dmi_facts['lpar_info']
    assert dmi_facts['product_name']
    module.exit_json(changed=False, ansible_facts={'dmi_facts': dmi_facts})



# Generated at 2022-06-22 22:59:10.149148
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    """
    Unit test for method get_vgs_facts of class AIXHardware
    """
    import os
    import sys
    import tempfile
    import unittest


# Generated at 2022-06-22 22:59:14.870984
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    module = FakeAnsibleModule()
    fact_module = AIXHardwareCollector(module=module)
    assert fact_module.module == module
    assert fact_module.platform == 'AIX'
    assert fact_module.fact_class == AIXHardware

# Unit tests for constructor of class AIXHardware

# Generated at 2022-06-22 22:59:17.266453
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    aix = AIXHardwareCollector()
    assert aix._platform == 'AIX'
    assert aix._fact_class == AIXHardware

# Generated at 2022-06-22 22:59:24.286318
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module=module)
    actual_results = hardware.get_dmi_facts()
    expected_results = {
        'firmware_version': 'IBM,A.02.11',
        'product_serial': '123456789',
        'lpar_info': '1 CEC(s)',
        'product_name': 'IBM,9117-MMA'
    }
    assert actual_results == expected_results


# Generated at 2022-06-22 22:59:32.506251
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    hardware = AIXHardware()
    hardware.module = MagicMock()

    hardware_facts = hardware.get_memory_facts()
    assert hardware_facts['memfree_mb'] == 0
    assert hardware_facts['memtotal_mb'] == 0
    assert hardware_facts['swapfree_mb'] is None
    assert hardware_facts['swaptotal_mb'] is None
    assert hardware_facts['processor'] == 'N/A'
    assert hardware_facts['processor_cores'] == 0
    assert hardware_facts['processor_count'] == 0

    hardware.module.run_command().return_value = 0, '1234', ''
    hardware_facts = hardware.get_memory_facts()
    assert hardware_facts['memfree_mb'] == 0
    assert hardware_facts['memtotal_mb'] == 1234
    assert hardware

# Generated at 2022-06-22 22:59:42.785356
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():

    class ModuleStub:
        def __init__(self):
            self.fact_cache = {}
            self.args = {}
            self.params = {}
            self.config = {}

        def get_bin_path(self, arg, opt_dirs=[]):
            return arg


# Generated at 2022-06-22 22:59:52.347259
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    # mock_module provides the necessary mocks for testing
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts.utils import mock_module

    ansible_module_mock = mock_module.MockModule(platform='AIX')
    facts_obj = AIXHardware(ansible_module_mock)
    mount_facts = facts_obj.get_mount_facts()

    assert mount_facts['mounts'] is not None
    assert ansible_module_mock.run_command.call_count == 1



# Generated at 2022-06-22 22:59:53.390865
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware = AIXHardware({})
    assert hardware.platform == 'AIX'

# Generated at 2022-06-22 23:00:00.741756
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        )
    )
    hardware_fact = AIXHardware(module)
    hardware_fact.get_cpu_facts()
    hardware_fact_dict = hardware_fact.populate()
    assert hardware_fact_dict['processor_count'] == 2


# Generated at 2022-06-22 23:00:06.799573
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    """
    Unit test for method get_memory_facts of class AIXHardware
    """
    hardware_obj = AIXHardware()
    memory_facts = hardware_obj.get_memory_facts()
    assert 'memtotal_mb' in memory_facts
    assert 'memfree_mb' in memory_facts
    assert 'swaptotal_mb' in memory_facts
    assert 'swapfree_mb' in memory_facts



# Generated at 2022-06-22 23:00:18.654275
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)

    # Unit test with output of mount command on AIX

# Generated at 2022-06-22 23:00:29.252926
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    """
    Test method get_vgs_facts of class AIXHardware
    """
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    hardware = AIXHardware(module)

# Generated at 2022-06-22 23:00:40.696840
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    # Initialize class instance for testing
    ahw = AIXHardware(dict(module=dict(run_command=run_command)))

    # Expected facts

# Generated at 2022-06-22 23:00:46.902617
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    hardware = AIXHardware(None)
    memory_facts = hardware.get_memory_facts()

    assert 'memtotal_mb' in memory_facts
    assert 'memfree_mb' in memory_facts
    assert 'swaptotal_mb' in memory_facts
    assert 'swapfree_mb' in memory_facts



# Generated at 2022-06-22 23:00:48.898551
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hasattr(hardware_collector, 'collect')

# Generated at 2022-06-22 23:00:57.017454
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    # Create a class object AIXHardware and initialize it
    aix_hw = AIXHardware(dict())

    # Get the facts in dict() format
    aix_hw.populate()

    # Test the processor_cores and processor_count facts
    if aix_hw.facts['processor_cores'] >= 0 and aix_hw.facts['processor_count'] >= 0:
        assert True

    # Test the memory facts
    if aix_hw.facts['memfree_mb'] >= 0 and aix_hw.facts['memtotal_mb'] >= 0 and aix_hw.facts['swapfree_mb'] >= 0 and aix_hw.facts['swaptotal_mb'] >= 0:
        assert True

    # Test the dmi facts

# Generated at 2022-06-22 23:01:08.657548
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    """Unit test for method get_mount_facts of class AIXHardware.
    """


# Generated at 2022-06-22 23:01:11.176891
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_facts = AIXHardwareCollector()
    assert hardware_facts._fact_class == AIXHardware

# Generated at 2022-06-22 23:01:17.173422
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    hardware = AIXHardware(module=module)

    memory_facts = hardware.get_memory_facts()

    module.exit_json(changed=False, ansible_facts=memory_facts)


# Generated at 2022-06-22 23:01:25.389941
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils import basic
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts.utils import get_mount_size

    # create a fake module for use in the tests
    module = basic.AnsibleModule(argument_spec=dict(),
                                 supports_check_mode=True)

    # create a fake module with a fake lsps -s output

# Generated at 2022-06-22 23:01:37.652387
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    # Initialize the class
    hardware = AIXHardware()

    # Create the vmstat output

# Generated at 2022-06-22 23:01:48.818769
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = DummyAnsibleModule()

    hardware_collector = AIXHardwareCollector(module)
    hardware = hardware_collector.collect()[0]

    assert hardware.platform == 'AIX'
    assert hardware.firmware_version == 'IBM,69Y4560'
    assert hardware.lpar_info == '1 69Y4560 AIX testansible 1 1017683687 5715094 Active'
    assert hardware.product_name == 'IBM,69Y4560'
    assert hardware.product_serial == '69Y4560'
    assert len(hardware.mounts) == 2
    assert hardware.mounts[0]['mount'] == '/'
    assert hardware.mounts[0]['device'] == '/dev/hd4'
    assert hardware.mounts[0]['fstype']

# Generated at 2022-06-22 23:01:51.444518
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    """
    AIXHardware - get_vgs_facts
    """

    aix = AIXHardware()
    if 'lsvg' in aix.module.get_bin_path('lsvg', True):
        aix.get_vgs_facts()



# Generated at 2022-06-22 23:02:00.310789
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec=dict())

    ah = AIXHardware(module=module)

    ah.populate()

    assert ah.facts['firmware_version'] == 'IBM,DSAXX-0647-06'
    assert ah.facts['product_serial'] == '1234567890'
    assert ah.facts['lpar_info'] == '1 [DSAXX-0647-06] '
    assert ah.facts['product_name'] == 'IBM,9117-570'
    assert ah.facts['processor_count'] == 2
    assert ah.facts['processor_cores'] == 2
    assert ah.facts['processor'] == 'PowerPC_POWER7'
    assert ah.facts['memfree_mb'] == 2095512
    assert ah.facts['memtotal_mb'] == 312

# Generated at 2022-06-22 23:02:07.562453
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    """
    This test creates an object of type AIXHardwareCollector and tests the value of
    the object variables. These tests are currently commented out since they can't
    run in this environment.
    """
    # aix_hw_collector = AIXHardwareCollector()
    # assert aix_hw_collector._platform == 'AIX'
    # assert aix_hw_collector._fact_class is AIXHardware
    pass

# Generated at 2022-06-22 23:02:13.791251
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = AIXHardware(module=module)

    # Sample string from lsps -s
    out = '"vgid  pv                pp        lv        hd        pps        lps        pv_name          "\n"rootvg hdisk0           546       31        0        546       187      hdisk0           "\n"rootvg hdisk1           546       30        0        546       187      hdisk1           "\n"realsyncvg hdisk74       1999      6         0        1999       6      hdisk74           "\n"testvg hdisk105          999       42         0        999       42       hdisk105          "\n"testvg hdisk106          999       29         0        999       29       hdisk106          "\n"'
    vgs_info = hardware

# Generated at 2022-06-22 23:02:18.432003
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    testModule = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
        ),
        # required=True,
        supports_check_mode=True)

    testModule.run_command = mock.Mock(return_value=(0, '', ''))
    testModule.get_bin_path = mock.Mock(return_value=True)

    testInventory = AIXHardware(testModule)
    testInventory.populate()

    assert testInventory.data['firmware_version'] == 'IBM,810F.86B.00'
    assert testInventory.data['product_name'] == '8286-42A'
    assert testInventory.data['product_serial'] == '06101ABCD4C4'

# Generated at 2022-06-22 23:02:27.640540
# Unit test for method get_memory_facts of class AIXHardware

# Generated at 2022-06-22 23:02:37.712852
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = MockModule()
    # output of vmstat -v
    module.run_command.return_value = 0, 'memory pages\n1069928\nfree pages\n785468', ''
    # output of lsps -a
    module.run_command.side_effect = [
        0, 'Device              1M-blocks     Used    Avail Capacity\n/dev/ada0p3        314368        0   314368     0%', ''
    ]
    hardware = AIXHardware(module)
    # Expected result
    assert hardware.get_memory_facts() == {'swaptotal_mb': 314368, 'swapfree_mb': 314368, 'memtotal_mb': 4232, 'memfree_mb': 2.7}



# Generated at 2022-06-22 23:02:47.852041
# Unit test for method get_mount_facts of class AIXHardware

# Generated at 2022-06-22 23:02:57.391873
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    """
    Tests for the get_memory_facts method of the AIXHardware class.
    """
    def run_run_command(return_value, module=None):
        if module is None:
            module = AIXHardwareCollector.get_instance(FakeModule())

            if isinstance(return_value, str):
                return_value = return_value.splitlines()

            return_value = (0, return_value, '')

        return module.run_command(return_value)

    # a regex matching the output of `vmstat -v`

# Generated at 2022-06-22 23:03:04.206008
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    import unittest
    import mock

    from ansible.module_utils.facts.hardware.aix import AIXHardware

    class TestAIXHardware(unittest.TestCase):

        @mock.patch('ansible.module_utils.facts.hardware.aix.AIXHardware.get_vgs_facts')
        def test_output_1(self, *args):
            setattr(args[0], 'module', mock.MagicMock())

# Generated at 2022-06-22 23:03:14.394402
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = type('', (object,), {"run_command": lambda *x: (0,
                                                             "proc0 Available 00-00 Processor\n"
                                                             "proc1 Available 00-01 Processor\n"
                                                             "proc2 Available 00-02 Processor\n",
                                                             "")})()
    hardware_obj = AIXHardware(module)
    cpu_facts = hardware_obj.get_cpu_facts()
    assert cpu_facts['processor_count'] == 3
    assert cpu_facts['processor'] == 'Processor'
    assert cpu_facts['processor_cores'] == 4


# Generated at 2022-06-22 23:03:25.931714
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    test_module = AnsibleModule(argument_spec={})
    test_module.run_command = MagicMock(return_value=(0, "", ""))
    test_module.get_bin_path = MagicMock(return_value='/usr/bin/lsvg')
    ah = AIXHardware(module=test_module)

# Generated at 2022-06-22 23:03:35.068982
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    import os

    aix_hardware = AIXHardware(dict())

    class FakeModule:

        def __init__(self):
            self.params = dict()
            self.params['gather_subset'] = []

        def get_bin_path(self, arg, required=False):
            if arg == "lsvg":
                return os.path.join(os.path.dirname(__file__), "files/lsvg")
            if arg == "xargs":
                return "/usr/bin/xargs"
            return None

        def run_command(self, cmd, use_unsafe_shell=False):
            rc = 0
            output = ""
            errors = ""
            return rc, output, errors

    fake_module

# Generated at 2022-06-22 23:03:44.001593
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    """
    Unit test for method get_vgs_facts of class AIXHardware
    """

    class ModuleStub():

        def __init__(self):
            self.params = {}
            self.check_mode = False

        def get_bin_path(self, executable, required=False):
            return executable

        def run_command(self, cmd, use_unsafe_shell=False):
            return (0, "/dev/asr0p1: in use: active\nFREE DISTRIBUTION\nhdisk144 active 546 0 00..00..00..00..00\nhdisk143 active 546 113 00..00..00..21..92", "")

    m = ModuleStub()
    ah = AIXHardware(m)
    vgs_facts = ah.get_vgs_facts()

# Generated at 2022-06-22 23:03:47.327498
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={})
    hardware_facts_obj = AIXHardware(module)
    assert hardware_facts_obj.platform == 'AIX'