

# Generated at 2022-06-22 22:53:48.390884
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector._platform == 'AIX'
    assert hardware_collector._fact_class == AIXHardware

# Generated at 2022-06-22 22:53:53.562174
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = MockModule()
    hardware = AIXHardware(module)
    dmi_facts = hardware.get_dmi_facts()

    assert dmi_facts['firmware_version'] != ''
    assert dmi_facts['product_serial'] != ''
    assert dmi_facts['lpar_info'] != ''
    assert dmi_facts['product_name'] != ''



# Generated at 2022-06-22 22:53:56.853946
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware = AIXHardware({}, {})
    assert hardware.populate()['vgs']['realsyncvg'][0]['pp_size'] == '4 megabyte(s)'

# Generated at 2022-06-22 22:54:09.079933
# Unit test for method get_cpu_facts of class AIXHardware

# Generated at 2022-06-22 22:54:20.340108
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    MODULES_PATH = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )
    module.run_command = mock.Mock(return_value=(0, '', ''))
    module.get_bin_path = mock.Mock(return_value=os.path.join(MODULES_PATH, 'system', 'aix', 'tests', 'test_data', 'mount'))

    ah = AIXHardware(module=module)
    mount_facts = ah.get_mount_facts()

# Generated at 2022-06-22 22:54:25.417481
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    tests = []
    module = AnsibleModule(argument_spec=dict())
    # Mock module.run_command
    # lsdev command output definition

# Generated at 2022-06-22 22:54:37.437042
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    dmi_data = '''System Model: IBM,8233-E8B
Machine Serial Number: 12345
System Type: PowerPC_POWER7
LPAR Info: 1 AIX,
firmware_version: IBM,8233-E8B
'''
    aix_hardware = AIXHardware(None)
    aix_hardware.get_bin_path = lambda x: x
    aix_hardware.run_command = lambda x: (0, dmi_data, None)
    facts = aix_hardware.populate()

    assert facts['firmware_version'] == 'IBM,8233-E8B'
    assert facts['product_serial'] == '12345'
    assert facts['lpar_info'] == '1 AIX'

# Generated at 2022-06-22 22:54:44.984913
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    m = basic.AnsibleModule(
        argument_spec={
            'gather_subset': dict(default=['!all'], type='list'),
            'gather_timeout': dict(default=10, required=False),
            'filter': dict(default='*', required=False),
        }
    )

    fc = collector.get_collector(m)
    fc.collect()
    output = fc.get_facts()


# Generated at 2022-06-22 22:54:52.286874
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = FakeModule()
    module.run_command = run_command

    hardware = AIXHardware(module)
    mem_facts = hardware.get_memory_facts()
    assert isinstance(mem_facts, dict)
    assert 'memtotal_mb' in mem_facts
    assert 'memfree_mb' in mem_facts
    assert 'swaptotal_mb' in mem_facts
    assert 'swapfree_mb' in mem_facts



# Generated at 2022-06-22 22:54:55.670979
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware_inst = AIXHardware(dict())
    assert hardware_inst.platform == 'AIX'

if __name__ == '__main__':
    test_AIXHardware()

# Generated at 2022-06-22 22:55:01.684831
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    hardware = AIXHardware(module)
    rc, out, err = module.run_command("/usr/bin/cat /tmp/test_AIX_lsvg -p")
    hardware.get_vgs_facts()



# Generated at 2022-06-22 22:55:13.023842
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    lsdev_path = '/usr/sbin/lsdev'
    lsdev_content = \
        '''
        Processor P320
        Processor P520
        Processor P520
        Processor P520
        '''

    lsattr_path = '/usr/sbin/lsattr'
    lsattr_content = \
        '''
        type PowerPC_POWER7
        smt_threads 8
        '''

    get_bin_path_mock = MagicMock(return_value='/usr/sbin/lsdev')
    module.get_bin_path = get_bin_path_mock
    module.run_command = MagicMock(return_value=(0, lsdev_content, ''))

# Generated at 2022-06-22 22:55:25.903959
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    """
    Test case for method get_vgs_facts of class AIXHardware
    This test case creates an instance of AIXHardware class,
    then calls get_vgs_facts() method of this instance and
    tests if we got right value
    """
    hardware = AIXHardware()
    hardware.module = Mock()
    hardware.module.get_bin_path.return_value = '/usr/sbin/lsvg'

# Generated at 2022-06-22 22:55:28.243372
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    harwd = AIXHardware(module)
    facts = harwd.populate()
    assert facts['processor_cores'] == 16

# Generated at 2022-06-22 22:55:32.855213
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    """Create a new AIXHardware class and test it's fields"""

    # Get the device class
    hardware_test = AIXHardware()

    # Test the platform field
    assert(hardware_test.platform == 'AIX')


# Generated at 2022-06-22 22:55:42.215227
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    """
    Test get_memory_facts of class AIXHardware
    """
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    aix_hw = AIXHardware(None, '/dev/null', '/dev/null')
    returned = aix_hw.get_memory_facts()
    expected = {
        'swapfree_mb': 36005,
        'swaptotal_mb': 65535,
        'memfree_mb': 12841,
        'memtotal_mb': 16384
    }
    assert returned == expected

# Generated at 2022-06-22 22:55:43.639470
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    x = AIXHardwareCollector()
    assert x.platform == 'AIX'
    assert x.fact_class == AIXHardware

# Generated at 2022-06-22 22:55:53.311885
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
  hardware = AIXHardware()
  rc, out, err = hardware.module.run_command("/usr/bin/vmstat -v")
  lines = out.splitlines()
  hardware.get_memory_facts()

  assert hardware.facts['memtotal_mb'] == hardware.pagesize * int(lines[2].split()[0].split(".")[0]) // 1024 // 1024
  assert hardware.facts['memfree_mb'] == hardware.pagesize * int(lines[3].split()[0].split(".")[0]) // 1024 // 1024

  data = lines[4].split()
  swaptotal = int(data[0].split(".")[0])
  percused = int(data[1][0:-1])
  assert hardware.facts['swaptotal_mb'] == swaptotal

# Generated at 2022-06-22 22:55:57.057730
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    # Create a instance of class AIXHardware
    memory_facts = AIXHardware().get_memory_facts()
    # Test memfree_mb and swapfree_mb is greater than or equal to zero
    assert memory_facts['memfree_mb'] >= 0
    assert memory_facts['swapfree_mb'] >= 0


# Generated at 2022-06-22 22:56:01.057882
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hwCollector = AIXHardwareCollector()
    assert hwCollector is not None
    assert hwCollector._platform == 'AIX'
    assert hwCollector._fact_class == AIXHardware


# Generated at 2022-06-22 22:56:09.932450
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module=module)
    num = re.compile(r'^\d+$')
    assert num.match(str(hardware.facts['memtotal_mb']))
    assert num.match(str(hardware.facts['memfree_mb']))
    assert num.match(str(hardware.facts['swaptotal_mb']))
    assert num.match(str(hardware.facts['swapfree_mb']))

# Generated at 2022-06-22 22:56:18.960300
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    class TestModule(object):
        def __init__(self, rc=0, out="", err=""):
            self.rc = rc
            self.out = out
            self.err = err
            self.run_command_count = 0
            self.run_command_args = []
            self.run_command_kwargs = []

        def run_command(self, args, **kwargs):
            self.run_command_count += 1
            self.run_command_args.append(args)
            self.run_command_kwargs.append(kwargs)

            return (self.rc, self.out, self.err)


# Generated at 2022-06-22 22:56:26.192739
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    from ansible.module_utils.facts.collector import TestModule
    from ansible.module_utils.facts import gather_subset

    attrs = ['hardware']
    test_module = TestModule({'gather_subset': gather_subset}, attrs)

    hardware_facts = AIXHardware(test_module).populate()

    test_module.exit_json(changed=False, ansible_facts={'hardware': hardware_facts})


# Generated at 2022-06-22 22:56:29.437381
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    collector = AIXHardwareCollector()
    assert collector != None

# Generated at 2022-06-22 22:56:39.103142
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    # create a test AIXHardware with no parameters
    aixh = AIXHardware()
    from ansible.module_utils.facts.utils import set_module_args
    set_module_args({'gather_subset': 'all'})
    aixh.populate()
    facts = aixh.get_facts()
    assert 'AIX' == facts['ansible_system']
    assert 'IBM,9117-570' == facts['firmware_version']
    assert '07A02319' == facts['product_serial']
    assert 'not-specified' == facts['lpar_info']
    assert 'IBM,9117-570' == facts['product_name']

# Generated at 2022-06-22 22:56:42.627334
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    from ansible.module_utils.facts.hardware.aix import AIXHardwareCollector
    d = AIXHardwareCollector()
    assert d.platform == 'AIX'
    assert isinstance(d.collect(), AIXHardware)


# Generated at 2022-06-22 22:56:51.183159
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_facts = AIXHardware(module).populate()

    assert hardware_facts['firmware_version'] == 'IBM,8233-E8B'
    assert hardware_facts['lpar_info'] == '1'
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['processor'] == 'PowerPC_POWER7'
    assert hardware_facts['processor_count'] == 2
    assert hardware_facts['processor_cores'] == 8
    assert hardware_facts['product_name'] == '8233-E8B'
    assert hardware_facts['product_serial'] == '06EABLB'

# Generated at 2022-06-22 22:57:02.106228
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    # Create a module to mock the run_command method,
    # using it to return the test values
    class FakeModule:
        def __init__(self):
            self.run_command_results = []
        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False):
            return self.run_command_results.pop(0)

    test_module = FakeModule()

# Generated at 2022-06-22 22:57:13.669516
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    """Tests for method AIXHardware.get_mount_facts"""
    class FakeModule(object):
        def __init__(self, return_values):
            self.return_values = return_values
            self.params = {}

        def run_command(self, cmd, use_unsafe_shell=False):
            return self.return_values.pop(0)

        def get_bin_path(self, arg, required=False):
            return arg

    def get_mount_size(mount):
        return {'size_total': '1234'}

    # test with mount info output

# Generated at 2022-06-22 22:57:21.421839
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = AIXHardware(module)

    collected_hardware_facts = {}
    hardware_obj.populate(collected_hardware_facts)

    assert collected_hardware_facts['processor_count'] == 1
    assert collected_hardware_facts['processor'] == 'PowerPC_POWER8'
    assert collected_hardware_facts['memtotal_mb'] == 24576
    assert collected_hardware_facts['memfree_mb'] == 641
    assert collected_hardware_facts['swaptotal_mb'] == 314368
    assert collected_hardware_facts['swapfree_mb'] == 0
    assert collected_hardware_facts['firmware_version'] == '3.15.8'
    assert collected_hardware_facts['product_serial']

# Generated at 2022-06-22 22:57:32.436692
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    rc, out, err = module.run_command("/usr/sbin/lsattr -El sys0 -a fwversion")
    data = out.split()
    fwversion = data[1].strip('IBM,')
    lsconf_path = module.get_bin_path("lsconf")
    if lsconf_path:
        rc, out, err = module.run_command(lsconf_path)
        if rc == 0 and out:
            for line in out.splitlines():
                data = line.split(':')
                if 'Machine Serial Number' in line:
                    serial = data[1].strip()
                if 'LPAR Info' in line:
                    lparinfo = data[1].strip()

# Generated at 2022-06-22 22:57:42.152572
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    lsdev_path = module.get_bin_path('lsdev', True)
    lsattr_path = module.get_bin_path('lsattr', True)

    content = '''
proc0 Available 00-00 Processor
proc4 Available 00-04 Processor
'''
    set_module_args(dict(content=content))

    with open('/tmp/lsdev_out', 'w') as f:
        f.write(content)

    module.run_command = MagicMock(return_value=(0, '', ''))

# Generated at 2022-06-22 22:57:49.559628
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    """Unit test for method populate of class AIXHardware"""
    import os
    import sys
    import json
    import platform
    import tempfile
    from ansible.module_utils._text import to_text

    # Create missing constants
    # (normally set by Ansible)
    module_name = 'ansible_unittest'
    module_args = {}

    # Create a temp directory
    tmpdir = tempfile.mkdtemp()

    # Create a ansible mock
    module_path = os.path.join(tmpdir, 'ansible')
    os.mkdir(module_path)

    # Create a module_utils directory
    module_utils_path = os.path.join(tmpdir, 'module_utils')
    os.mkdir(module_utils_path)

    # Create a utils directory
    ut

# Generated at 2022-06-22 22:58:00.380256
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    import os
    import sys
    import unittest

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.utils import get_mount_size

    class TestAIXHardwareGetDeviceFacts(unittest.TestCase):
        """test get_device_facts"""
        def setUp(self):
            self.sys_modules_orig = sys.modules.copy()
            self.os_environ_orig = os.environ.copy()
            from ansible.module_utils.facts import hardware
            sys.modules['ansible.module_utils.facts'] = hardware
            self.module = hardware.Hardware()
            self.module.run_command = self.run_command
            # lsdev command output for testing

# Generated at 2022-06-22 22:58:12.103142
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    # Create a dummy AnsibleModule object
    from ansible.module_utils.facts import ModuleFacts
    module = ModuleFacts('AIX')

    # Create an object of class AIXHardware
    aix_hw = AIXHardware(module=module)

    # Generate some fake data for testing
    out_lsdev = """
hdisk0 Available 03-08-02-7,0  FC FC 1793 GB
hdisk1 Defined   03-08-02-8,0  FC FC 1793 GB
lo0  Defined   Loopback Device
md0  Defined   Mdisk
lo0  Defined   Logical volume
fcs0 Available 0C-00        FC FC 1849 GB
"""


# Generated at 2022-06-22 22:58:14.118761
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector

# Generated at 2022-06-22 22:58:26.139602
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    import inspect
    import sys
    import unittest

    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.facts.hardware.aix import AIXHardware

    class AIXHardwareTestCase(unittest.TestCase):

        def setUp(self):
            self.aix_hardware = AIXHardware()

        # This test case verifies if number of processor is correctly obtained from the output of command '/usr/sbin/lsdev -Cc processor'

# Generated at 2022-06-22 22:58:32.016658
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'IBM,123ABCD 1.0.0', ''))
    ah = AIXHardware(module=module)
    dmi_facts = ah.get_dmi_facts()
    assert dmi_facts['firmware_version'] == '1.0.0'


# Generated at 2022-06-22 22:58:42.971782
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    # Set up our module and 'exit_json' function
    module.exit_json = exit_json
    set_module_args(dict(
    ))

    # instantiate object of class AIXHardware
    hw_obj = AIXHardware(module)

    cpu_facts = hw_obj.get_cpu_facts()
    assert cpu_facts['processor'] == 'PowerPC_POWER8'
    assert cpu_facts['processor_cores'] == 2
    assert cpu_facts['processor_count'] == 12



# Generated at 2022-06-22 22:58:54.369948
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    output_lsdev = '''
    name:
    entry1 Available
    entry2 Defined
    '''

    output_lsattr_entry1 = '''
    name:
    attr1 value1
    attr2 value2
    '''

    output_lsattr_entry2 = '''
    name:
    attr3 value3
    attr4 value4
    '''

    class MockModule:
        def __init__(self, module):
            self.module = module

        def get_bin_path(self, executable, required=False):
            return executable


# Generated at 2022-06-22 22:59:03.756242
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(
        argument_spec=dict()
    )
    aixhw = AIXHardware(module)

    # Test for product_serial
    out_pserial = "sys0 Available 00-00-00-00-00-00-00-00-00-00-00-00-00-00-00-00\n"
    rc = 0
    err = ''
    aixhw.module.run_command = Mock(return_value=(rc, out_pserial, err))
    dmi_facts = aixhw.get_dmi_facts()
    assert dmi_facts['product_serial'] == '00-00-00-00-00-00-00-00-00-00-00-00-00-00-00-00'

    # Test for firmware_version

# Generated at 2022-06-22 22:59:15.796932
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    """
    Test for method get_mount_facts of class AIXHardware
    """
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json

    if module.get_bin_path('mount'):
        hw = AIXHardware(module)
        mounts_facts = hw.get_mount_facts()

        if mounts_facts:
            assert mounts_facts['mounts'] is not None
            assert mounts_facts['mounts'][0]['mount'] is not None
            assert mounts_facts['mounts'][0]['device'] is not None
            assert mounts_facts['mounts'][0]['fstype'] is not None
            assert mounts_facts['mounts'][0]['options'] is not None

# Generated at 2022-06-22 22:59:25.854933
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
  from ansible.module_utils.facts.hardware.aix import AIXHardware
  import mock

  m_module = mock.MagicMock()

# Generated at 2022-06-22 22:59:33.420172
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModuleMock({})
    hardware = AIXHardware(module)


# Generated at 2022-06-22 22:59:44.795520
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    ah = AIXHardware(module)
    result = ah.get_mount_facts()
    assert isinstance(result, dict)
    assert 'mounts' in result
    mounts = result['mounts']
    assert isinstance(mounts, list)
    assert len(mounts) > 0
    for m in mounts:
        assert isinstance(m, dict)
        assert 'mount' in m
        assert 'device' in m
        assert 'fstype' in m
        assert 'options' in m
        assert 'time' in m
        assert 'space_total' in m and isinstance(m['space_total'], float) and m['space_total'] > 0
        assert 'space_free' in m and isinstance(m['space_free'], float) and m

# Generated at 2022-06-22 22:59:54.449088
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    '''Unit test of class AIXHardwareCollector'''
    mod = None
    tmp_path = '/tmp/ansible_unittests'
    mod_args = {'ansible_facts': {'ansible_mounts': [{'options': 'rw',
                                                     'mount': '/'},
                                                    {'options': 'rw',
                                                     'mount': '/usr/local'}]},
                'ansible_path': tmp_path,
                '_ansible_remote_tmp': tmp_path,
                'ansible_remote_tmp': tmp_path}

    hc = AIXHardwareCollector(module=mod, args=mod_args)
    assert isinstance(hc, AIXHardwareCollector)

# Generated at 2022-06-22 22:59:56.875136
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    collector = AIXHardwareCollector()
    assert collector._platform == 'AIX'
    assert collector._fact_class == AIXHardware


# Generated at 2022-06-22 23:00:07.398565
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    # aix.yml has the required command outputs for running below test
    # and aix.yml should be copied and put in tests/unit/data/ansible_local fact_data
    module = AnsibleModule(argument_spec={})
    module.run_command = mock.Mock(return_value=(0, '', ''))
    module.get_bin_path = mock.Mock(return_value="/bin/lsdev")
    hardware_obj = AIXHardware(module)
    hardware_obj.module.run_command = mock.Mock(return_value=(0, '', ''))
    hardware_obj.module.get_bin_path = mock.Mock(return_value="/bin/lsdev")
    hardware_obj.module.run_command.return_value = read_file_lines("aix")[0],

# Generated at 2022-06-22 23:00:10.203321
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    x = AIXHardwareCollector()
    assert x.platform == 'AIX'
    assert x.fact_class == AIXHardware

# Generated at 2022-06-22 23:00:13.241780
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    # create a test module object
    import ansible.module_utils.facts.hardware.aix as aix
    module = aix.ANSIBLE_MODULE
    # set module arguments
    module.params = {}
    aix_hardware = aix.AIXHardware(module)
    aix_hardware.get_mount_facts()



# Generated at 2022-06-22 23:00:21.871379
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module_args = {}
    module = AnsibleModule(argument_spec=module_args, supports_check_mode=True)
    hardware = AIXHardware(module)

    rc = 0
    out = """proc0 Available 00-00 Processor
proc4 Available 00-04 Processor"""
    err = ''
    hardware.module.run_command = Mock(return_value=(rc, out, err))
    rc, out, err = hardware.module.run_command("/usr/sbin/lsattr -El " + "proc0" + " -a type")
    hardware.populate()
    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['processor'] == 'POWER8'
    assert hardware.facts['processor_cores'] == 1


# Generated at 2022-06-22 23:00:30.998901
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():

    import ansible.module_utils.facts.hardware.aix as aix

    ahw = aix.AIXHardware()

    mock_module = MockModule()

    ahw.module = mock_module

    mock_module.run_command.return_value = (0, """memory pages
        162097       133574
        free pages
        95857
        """, '')
    assert ahw.get_memory_facts() == {'memtotal_mb': 64751, 'memfree_mb': 38023}

    mock_module.run_command.return_value = (0, """memory pages
        162097       133574
        free pages
        95857
        """, '')

# Generated at 2022-06-22 23:00:35.086467
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    module.run_command = mock.MagicMock(return_value=(0, '', ''))
    module.get_bin_path = mock.MagicMock(return_value=True)
    ah = AIXHardware(module=module)
    ah.populate()
    assert(module.run_command.call_count == 6)



# Generated at 2022-06-22 23:00:43.376746
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware_facts = AIXHardware()

    # verify memory_facts
    assert hardware_facts.memory_facts['memtotal_mb'] is not None
    assert hardware_facts.memory_facts['memfree_mb'] is not None
    assert hardware_facts.memory_facts['swaptotal_mb'] is not None
    assert hardware_facts.memory_facts['swapfree_mb'] is not None

    # verify cpu_facts
    assert hardware_facts.cpu_facts['processor_count'] > 0
    assert hardware_facts.cpu_facts['processor_cores'] > 0
    assert hardware_facts.cpu_facts['processor'] is not None

    # verify dmi_facts
    assert hardware_facts.dmi_facts['firmware_version'] is not None

# Generated at 2022-06-22 23:00:54.430995
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    out = get_file_content('lsvg_aix_v7.txt')
    aix_h = AIXHardware(BaseFactCollector())
    vgs = aix_h.get_vgs_facts()['vgs']
    assert vgs
    assert isinstance(vgs, dict)

    rootvg = vgs['rootvg'][0]
    assert rootvg['pv_name'] == 'hdisk0'
    assert rootvg['pv_state'] == 'active'
    assert rootvg['total_pps'] == '546'

# Generated at 2022-06-22 23:01:06.347255
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    out_lsvg_p = """rootvg:
PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
hdisk0            active            546         0           00..00..00..00..00
hdisk1            active            546         113         00..00..00..21..92
realsyncvg:
PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
hdisk74           active            1999        6           00..00..00..00..06
testvg:
PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
hdisk105          active            999         838         200..39..199..200..200
hdisk106          active            999         599         200..00..00..199..200"""

# Generated at 2022-06-22 23:01:19.147804
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    # Testing for device 'ent3' (Virtual I/O Ethernet Adapter)
    text_lsdev = 'ent3 Available 10-Gigabit Ethernet PCI-X Adapter (ef5a)'
    text_lsattr = 'adapter_names  ent3'

    mod = AnsibleModule(argument_spec={})
    mod.params = {}
    m = AIXHardware(mod)
    m.module.run_command = MagicMock(return_value=(0, text_lsdev, ''))
    m.module.get_bin_path = MagicMock(return_value='/usr/sbin/lsdev')
    out = m.get_device_facts()
    assert out['devices']['ent3']['type'] == 'Virtual I/O Ethernet Adapter'

# Generated at 2022-06-22 23:01:29.993083
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():

    import os
    import tempfile
    import pytest
    from ansible.module_utils.facts.hardware.aix import AIXHardware

    if not os.path.exists('/usr/bin/mount'):
        pytest.skip("path not found. skipping")

    temp_file_fd, temp_file_path = tempfile.mkstemp()
    f = os.fdopen(temp_file_fd, 'w+')
    f.write('/dev/hd4                 /                       jfs     2       yes     rw      0 0\n'
            '/dev/hd2                 /usr                    jfs     2       yes     rw      0 0')
    f.close()
    module = os.path.splitext(os.path.basename(__file__))[0]

# Generated at 2022-06-22 23:01:36.556946
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    # pylint: disable=protected-access
    aix_hw = AIXHardware()
    dmi_facts = {'firmware_version': 'V7R2M0.20170903.0858', 'product_serial': '063E520', 'lpar_info': '', 'product_name': '8286-42A'}
    # Test case with correct dmi file contents

# Generated at 2022-06-22 23:01:47.712073
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():

    import os

    test_file = '/tmp/test_AIXHardware.json'
    lsdev_path = '/usr/sbin/lsdev'
    lsattr_path = '/usr/sbin/lsattr'

    os.system('rm -rf ' + test_file)

    module = AnsibleModule(argument_spec={})
    module.get_bin_path = MagicMock(return_value=True)
    module.run_command = MagicMock(return_value=True)
    module.run_command.return_value = (0, 'hdisk0 Available  Virtual SCSI Disk Drive', '')

# Generated at 2022-06-22 23:01:57.880800
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})

    # create an instance of AIXHardware class.
    # This class override the default implementation of method populate of
    # Hardware class in order to test its own implementation
    aix_hardware = AIXHardware(module=module)
    cpu_facts = aix_hardware.get_cpu_facts()
    memory_facts = aix_hardware.get_memory_facts()
    dmi_facts = aix_hardware.get_dmi_facts()
    vgs_facts = aix_hardware.get_vgs_facts()
    mount_facts = aix_hardware.get_mount_facts()
    devices_facts = aix_hardware.get_device_facts()

    # check values returned by get_cpu_facts

# Generated at 2022-06-22 23:02:01.150741
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    facts_collector = AIXHardwareCollector
    assert facts_collector._platform == 'AIX'
    assert facts_collector._fact_class == AIXHardware

# Generated at 2022-06-22 23:02:04.323785
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    aix_hardware_collector = AIXHardwareCollector()
    assert isinstance(aix_hardware_collector, AIXHardwareCollector)


# Generated at 2022-06-22 23:02:07.354621
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec=dict())
    hardware_obj = AIXHardware(module)
    assert hardware_obj.platform == 'AIX'

# Generated at 2022-06-22 23:02:15.156564
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    import platform
    import sys
    if (sys.version_info[0] == 2 and (int(platform.python_version_tuple()[0]) < 3 or int(
            platform.python_version_tuple()[1]) < 6)) or (
            sys.version_info[0] == 3 and int(platform.python_version_tuple()[0]) < 3):
        import unittest2 as unittest
    else:
        import unittest

    import ansible.module_utils.facts.hardware.aix as aix
    aix_hardware = aix.AIXHardware()


# Generated at 2022-06-22 23:02:21.820986
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    test_out = [
        "memory pages: 40000",
        "free pages:  10000",
        "AIX"
    ]
    module = FakeModule(test_out)
    hardware = AIXHardware(module)
    hw_facts = hardware.populate()
    assert hw_facts['memtotal_mb'] == 15984
    assert hw_facts['memfree_mb'] == 3968


# Generated at 2022-06-22 23:02:29.688147
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = type('', (), {})()
    module.run_command = lambda x: ('', 'Available Friday June 6 2014 09:22:19 +03:00:00 PST\n'
                                        'Available\n'
                                        'Available\n'
                                        'Available\n', '')

    hardware = AIXHardware(module)
    cpu_facts = hardware.get_cpu_facts()

    assert cpu_facts['processor'] != ''
    assert cpu_facts['processor_count'] == 4
    assert cpu_facts['processor_cores'] == 1



# Generated at 2022-06-22 23:02:32.987621
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    print(cpu_facts)


# Generated at 2022-06-22 23:02:44.749254
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    import os
    import module_utils.facts.hardware.aix

    # test_AIXHardware_get_dmi_facts
    # Create a fake module
    module = type('module', (object,), {'run_command': lambda *_: (0, os.path.join(os.path.dirname(__file__), 'lsconf_out.txt'), '')})()
    hardware = module_utils.facts.hardware.aix.AIXHardware(module=module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['firmware_version'] == '723EF3F'
    assert dmi_facts['product_serial'] == '01ABCDEFGH'
    assert dmi_facts['lpar_info'] == '1 8 101'
    assert dmi_

# Generated at 2022-06-22 23:02:54.055940
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False)
    module.run_command = MagicMock(return_value=(0, 'Fake output', ''))
    module.get_bin_path = MagicMock(
        side_effect=lambda path, required: path if path != 'lsdev' else '')

    # Test lsdev command does not exist
    facts = {}
    AIXHardware(module).get_device_facts()

    # Test lsdev command does exist
    facts = {}

# Generated at 2022-06-22 23:02:59.087931
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule
    module.run_command = MagicMock(return_value=(0, 'memory pages: 6178\nfree pages: 355\n', ''))
    module.get_bin_path = MagicMock(return_value='/usr/bin/vmstat')

    hw = AIXHardware(module)

    assert hw.get_memory_facts() == {'memtotal_mb': 2736, 'memfree_mb': 1477}

# Generated at 2022-06-22 23:03:10.519328
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = MockModule()

# Generated at 2022-06-22 23:03:12.419728
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    aix_h = AIXHardware()
    assert aix_h.platform == 'AIX'

# Generated at 2022-06-22 23:03:21.891062
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = AIXHardware(module)

    mount_out = '''
    node       mounted        mounted over    vfs       date        options
    /dev/hd1   /              /dev/hd4        jfs2      Nov 25 17:12 rw,log=INLINE
    /dev/hd2   /usr           /dev/hd9var     jfs2      Nov 25 17:12 rw,log=INLINE
    '''

# Generated at 2022-06-22 23:03:32.870063
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    class TestModule:
        def __init__(self, command):
            self.run_command = command

        def get_bin_path(self, bin):
            if bin == 'lsvg':
                return '/usr/sbin/lsvg'
            elif bin == 'lsdev':
                return '/usr/sbin/lsdev'
            elif bin == 'lsattr':
                return '/usr/sbin/lsattr'
            elif bin == 'mount':
                return '/usr/sbin/mount'
            elif bin == 'lsconf':
                return '/usr/sbin/lsconf'
            elif bin == 'xargs':
                return '/usr/bin/xargs'

    test_module = TestModule(test_AIXHardware_test_command)


# Generated at 2022-06-22 23:03:39.502246
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    import datetime
    from ansible.module_utils.facts.hardware.aix import AIXHardware

    facts = AIXHardware(None)
    facts.module = datetime
    memory_facts = facts.get_memory_facts()
    assert memory_facts['memtotal_mb'] is not None
    assert memory_facts['memfree_mb'] is not None
    assert memory_facts['swaptotal_mb'] is not None
    assert memory_facts['swapfree_mb'] is not None


# Generated at 2022-06-22 23:03:47.419936
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    """
    Test to verify AIXHardware behavior of get_memory_facts method
    """

    class MockModule():
        def __init__(self, params):
            self.params = params

        def run_command(self, cmd, use_unsafe_shell=False):
            if use_unsafe_shell:
                return (0, "hdisk0           active            546         0           00..00..00..00..00\n"
                           "hdisk1           active            546         113         00..00..00..21..92\n", "")
            else:
                return (0, "memory pages:    47419\n"
                           "free pages:      18442\n", "")

        def get_bin_path(self, executable, required=False):
            return True
