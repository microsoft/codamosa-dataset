

# Generated at 2022-06-22 22:53:47.648596
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_facts_obj = AIXHardware(module)
    module.exit_json(ansible_facts=hardware_facts_obj.populate())



# Generated at 2022-06-22 22:53:57.605580
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    obj = AIXHardware({})
    out = """
    memory pages       =    26908200
    memory size        =     1073984
    memory pin         =    26908200
    physical pages     =    26908200
    virtual pages      =    26908200
    free pages         =     3611976
    real mem           =     1448704
    free mem           =      716610
    pin mem            =       95206
    pin resv           =          96
    page ins           =  1916035504
    page outs          =         612
    pager waits        =          81
    paging space       =    314368
    %paging space      =          0
    """

    mem = obj.get_memory_facts()
    assert mem['memtotal_mb'] == 1073984
    assert mem['memfree_mb']

# Generated at 2022-06-22 22:54:03.464332
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={})

    # Construct an AIXHardware object
    hardware_collector = AIXHardware(module)

    # Validate results of constructor
    assert hardware_collector.module is module
    assert hardware_collector.platform == 'AIX'
    assert hardware_collector.facts == {}



# Generated at 2022-06-22 22:54:12.901390
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    hardware = AIXHardware(dict())
    hardware_facts = hardware.populate()

    assert_equals(hardware_facts['memtotal_mb'], int(hardware_facts['memtotal_mb']))
    assert_equals(hardware_facts['memfree_mb'], int(hardware_facts['memfree_mb']))
    assert_equals(hardware_facts['swaptotal_mb'], int(hardware_facts['swaptotal_mb']))
    assert_equals(hardware_facts['swapfree_mb'], int(hardware_facts['swapfree_mb']))
    assert_equals(hardware_facts['processor'], str)
    assert_equals(hardware_facts['processor_cores'], int(hardware_facts['processor_cores']))

# Generated at 2022-06-22 22:54:17.146861
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(
        argument_spec=dict()
    )

    ah = AIXHardware(module=module)
    ah.populate()
    ah.get_vgs_facts()
    # should return an empty dictionary
    assert ah.facts['vgs'] is {}

# Generated at 2022-06-22 22:54:24.748660
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    # Testcase 1:
    # Testcase for AIX 7.2: Processor with SMT_Threads
    # lsdev -Cc processor
    # proc0 Available 00-00 Processor
    # proc1 Available 00-01 Processor
    # proc2 Available 00-02 Processor
    # proc3 Available 00-03 Processor
    #
    # lsattr -El proc0 -a type -F value
    # type
    # PowerPC_POWER8
    #
    # lsattr -El proc0 -a smt_threads -F value
    # smt_threads
    # 4
    #
    #
    aix_cpu_facts = AIXHardware().get_cpu_facts()
    assert aix_cpu_facts['processor'] == 'PowerPC_POWER8'
    assert aix_cpu_facts['processor_count']

# Generated at 2022-06-22 22:54:29.764876
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    vgs_facts = AIXHardware(module).get_vgs_facts()
    assert(vgs_facts['vgs']['testvg'][0]['pv_name'] == 'hdisk105')

# Generated at 2022-06-22 22:54:41.029366
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    class ModuleTest(object):
        def __init__(self, device_raw_output, attribute_raw_output):
            self.syscall = {
                'lsdev': device_raw_output,
                'lsattr': attribute_raw_output
            }
            self.bin_path_cache = {}

        def run_command(self, args, use_unsafe_shell=False):
            bin_name = args.split()[0]
            return (0, self.syscall[bin_name], None)

        def get_bin_path(self, arg, required=False):
            path = self.bin_path_cache.get(arg, arg)
            if required and not path:
                msg = "Could not find required executable %s from %s" % (arg, self.bin_path_cache.keys())
                raise

# Generated at 2022-06-22 22:54:54.170061
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    hardware_test_module = setup_module(test_module=True)
    hardware_test_module.set_bin_path('/sbin')
    lsdev_cmd = hardware_test_module.get_bin_path('lsdev', True)
    lsattr_cmd = hardware_test_module.get_bin_path('lsattr', True)
    lsdev_cmd = '/bin/cat /tmp/lsdev.out'
    lsattr_cmd = '/bin/cat /tmp/lsattr.out'
    hardware_test_module.run_command = lambda x, **kwargs: ('0', '', '')

# Generated at 2022-06-22 22:55:07.074670
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    device_attrs = {}
    device_attrs['attr_name'] = 'attr_parameter'
    device_facts = {}
    device_facts['devices'] = {}
    device_facts['devices']['device_name'] = {}
    device_facts['devices']['device_name']['state'] = 'device_state'
    device_facts['devices']['device_name']['type'] = 'device_type'
    device_facts['devices']['device_name']['attributes'] = device_attrs

    memory_facts = {}
    memory_facts['memtotal_mb'] = 1038
    memory_facts['memfree_mb'] = 531
    memory_facts['swaptotal_mb'] = 2048
    memory_facts['swapfree_mb'] = 2035

    cpu_facts

# Generated at 2022-06-22 22:55:12.028653
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector.platform == 'AIX'
    assert hardware_collector.fact_class == AIXHardware

if __name__ == '__main__':
    test_AIXHardwareCollector()

# Generated at 2022-06-22 22:55:25.291280
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    data = """
    rootvg:
    PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
    hdisk0            active            546         0           00..00..00..00..00
    hdisk1            active            546         113         00..00..00..21..92
    realsyncvg:
    PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
    hdisk74           active            1999        6           00..00..00..00..06
    testvg:
    PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
    hdisk105          active            999         838         200..39..199..200..200
    hdisk106          active            999         599         200..00..00..199..200
    """
    d

# Generated at 2022-06-22 22:55:27.289098
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware = AIXHardware()
    assert hardware.platform == 'AIX'

# Generated at 2022-06-22 22:55:37.614811
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    mount_facts = hardware.get_mount_facts()

# Generated at 2022-06-22 22:55:48.093697
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )


# Generated at 2022-06-22 22:55:56.845442
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    # Unit test to validate AIXHardware.get_mount_facts
    # Setup
    # get AIXHardware object
    aix_hardware = AIXHardware()
    # create a instance of module_utils.facts.utils.Mount
    from ansible.module_utils.facts.utils import Mount
    mount = Mount()
    # call mount.get_mounts_from_mtab

# Generated at 2022-06-22 22:55:59.616226
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    collector = AIXHardwareCollector()
    assert collector._platform == 'AIX'
    assert collector._fact_class == AIXHardware


# Generated at 2022-06-22 22:56:01.767705
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    """
    Instantiate AIXHardwareCollector() object
    """
    obj = AIXHardwareCollector()
    obj.collect()

# Generated at 2022-06-22 22:56:14.790409
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    # create a module object
    module = AnsibleModule(
        argument_spec=dict()
    )
    # create a AIXHardware object
    ah = AIXHardware(module)
    ah.populate()
    # check if all the keys are present in the facts dict
    assert 'firmware_version' in ah.facts
    assert 'lpar_info' in ah.facts
    assert 'product_name' in ah.facts
    assert 'product_serial' in ah.facts
    assert 'memtotal_mb' in ah.facts
    assert 'memfree_mb' in ah.facts
    assert 'processor' in ah.facts
    assert 'processor_cores' in ah.facts
    assert 'processor_count' in ah.facts
    assert 'swapfree_mb' in ah.facts

# Generated at 2022-06-22 22:56:26.995148
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    # assumes:
    # - AIX 6.1 or higher
    # - lsconf binary
    class module:
        def get_bin_path(self, path, required=True):
            return '/usr/sbin/lsconf'

        def run_command(self, cmd):
            if '/usr/sbin/lsattr -El sys0 -a fwversion' in cmd:
                return (0, 'fwversion IBM,019024', '')

# Generated at 2022-06-22 22:56:39.006977
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    # create module
    import ansible.module_utils.aix as aix
    m = aix.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    # create class
    hw = AIXHardware(m)

    # create lsdev output
    lsdev_output = "name                 status  description\n"
    lsdev_output += "loop0                Available  Virtual SCSI Disk Drive\n"
    lsdev_output += "loop1                Available  Virtual SCSI Disk Drive\n"
    lsdev_output += "namei                 Defined    Logical Volume Manager\n"
    lsdev_output += "lscsa0                 Defined    Virtual I/O SCSI Adapter\n"
    lsdev_output += "loop0                Available  Virtual SCSI Disk Drive\n"


# Generated at 2022-06-22 22:56:40.316345
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware = AIXHardware()
    assert hardware.platform == 'AIX'

# Generated at 2022-06-22 22:56:43.622449
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    module = AnsibleModule(argument_spec={})
    collector = AIXHardwareCollector(module=module)
    assert collector.platform == 'AIX'
    assert collector.fact_class == AIXHardware


# Generated at 2022-06-22 22:56:46.019133
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector._fact_class == AIXHardware
    assert hardware_collector._platform == 'AIX'

# Generated at 2022-06-22 22:56:53.205814
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    os_object = AIXHardware()
    os_object.module.get_bin_path = Mock(return_value="/usr/sbin/lsdev")
    os_object.module.run_command = Mock(
        return_value=[0, "proc0 Available 00-00 IBM,7044-270          Processor\nproc1 Defined   00-01 IBM,7044-270          Processor\nproc2 Defined   00-02 IBM,7044-270          Processor\n", None])
    cpu_facts = os_object.get_cpu_facts()
    assert cpu_facts['processor_cores'] == 2
    assert cpu_facts['processor'] == 'IBM,7044-270'
    assert cpu_facts['processor_count'] == 3



# Generated at 2022-06-22 22:57:05.727660
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    class module:
        def run_command(cmd, use_unsafe_shell=False):
            return (0, """
                    sys0 Available 00-00-00
                    hw_provider: IBM
                    firmware_version: IBM,820-48P
                    hw_type: machine
                    modelname: IBM,8203-E4A
                    smt_enabled: true
                    smt_threads_per_core: 2
                    weight: 0
                    lpar_name:
                    partition_id: 1
                    """, None)

    class module:
        def get_bin_path(cmd, required=False):
            return '/usr/sbin/lsattr'

    dmi_facts = {}
    dmi_facts = AIXHardware(module).get_dmi_facts()

# Generated at 2022-06-22 22:57:16.408129
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    hardware = AIXHardware()
    hardware.module = DummyAnsibleModule()
    hardware.module.run_command = run_command
    try:
        hardware.populate()
    except:
        raise
    assert hardware.facts['memfree_mb'] == 1024
    assert hardware.facts['memtotal_mb'] == 2048
    assert hardware.facts['swapfree_mb'] == 128
    assert hardware.facts['swaptotal_mb'] == 256
    assert hardware.facts['processor'] == ['PowerPC_POWER5']
    assert hardware.facts['processor_cores'] == 2
    assert hardware.facts['processor_count'] == 4
    #assert hardware.facts['processor_threads_per_core'] == 2
    #assert hardware.facts['processor_vcpus'] == 8



# Generated at 2022-06-22 22:57:24.078971
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    hw = AIXHardware()
    hw.module = MockModule()
    hw.module.run_command.return_value = (0, "proc0 Available 00-00-0C-00-00-00 Processor\nproc1 Defined 00-00-0D-00-00-00 Processor", 0)

    hw.get_cpu_facts()
    expected_result = {'processor': '00-00-0C-00-00-00', 'processor_count': 2, 'processor_cores': 4}
    assert hw.facts == expected_result



# Generated at 2022-06-22 22:57:25.678392
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware_facts = AIXHardware()
    assert hardware_facts


# Generated at 2022-06-22 22:57:27.756267
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    facts = AIXHardware()
    assert facts.platform == 'AIX'



# Generated at 2022-06-22 22:57:36.783131
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = FakeModule()
    hardware = AIXHardware(module)
    hardware.facts['system']['firmware_version'] = 'IBM,7233-CR9'
    hardware.facts['system']['product_name'] = 'IBM,7233-CR9'
    hardware.facts['system']['product_serial'] = ''
    hardware.facts['system']['lpar_info'] = ''
    hardware.get_dmi_facts()

    assert hardware.facts['system']['firmware_version'] == '7233-CR9'
    assert hardware.facts['system']['product_name'] == 'IBM,7233-CR9'
    assert hardware.facts['system']['product_serial'] == '1234567890'

# Generated at 2022-06-22 22:57:45.554149
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():

    #
    # Test setup
    #
    from ansible.module_utils.facts import Hardware as hardware
    from ansible.module_utils.six import PY2
    import os
    import json
    import tempfile

    # create tempfile context and add 'syspath' directory to path
    tmp = tempfile.TemporaryDirectory()
    if PY2:
        from ansible.module_utils.facts.tests.syspath import syspath
        tmp.syspath = syspath()
        tmp.syspath.push(os.path.dirname(tmp.syspath.module_utils))
        tmp.syspath.push(os.path.join(tmp.syspath.module_utils, 'ansible'))

# Generated at 2022-06-22 22:57:57.360214
# Unit test for method get_mount_facts of class AIXHardware

# Generated at 2022-06-22 22:58:08.734968
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():

    # create a AIXHardware object
    aixhardware = AIXHardware()

    # populate out, err and rc with data
    out = "proc0 Available 00-00 Processor\nproc1 Available 00-00 Processor"
    err = ""
    rc = 0

    # assign value to aixhardware.module.run_command
    aixhardware.module.run_command = lambda x: (rc, out, err)

    # execute the get_cpu_facts method assuming we are running on AIX
    cpu = aixhardware.get_cpu_facts()

    # assert that cpu_facts is not empty
    assert cpu

    # assert that cpu_facts is a dictionary
    assert isinstance(cpu, dict)

    # assert that the number of cpus is 2
    assert cpu['processor_count'] == 2

    # assert that the

# Generated at 2022-06-22 22:58:11.892507
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = FakeModule()
    hardware = AIXHardware(module)
    assert hardware.module == module
    assert hardware.platform == AIXHardware.platform



# Generated at 2022-06-22 22:58:24.686672
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = MockModule()
    hardware = AIXHardware(module)
    mount_facts = hardware.get_mount_facts()

# Generated at 2022-06-22 22:58:29.958060
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    hardware = AIXHardware(module=module)

    hardware.get_device_facts()

# Generated at 2022-06-22 22:58:38.393816
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = type('', (object,), {'run_command': run_command})()

    def run_command(cmd, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt=None, environ_update=None):
        if cmd == '/usr/sbin/mount':
            rc = 0

# Generated at 2022-06-22 22:58:50.727198
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    facts = {'module_setup': True}
    hardware = AIXHardware(facts)

    output = """proc0 Available 00-00 Processor
proc1 Available 00-01 Processor
proc2 Available 00-02 Processor
proc3 Available 00-03 Processor"""
    hardware.module.run_command = lambda *args, **kwargs: (0, output, "")

    output = """type PowerPC_POWER6"""
    hardware.module.run_command = lambda *args, **kwargs: (0, output, "")

    output = """smt_threads 1"""
    hardware.module.run_command = lambda *args, **kwargs: (0, output, "")

    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 4

# Generated at 2022-06-22 22:58:52.124511
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    h = AIXHardware()

    assert h is not None


# Generated at 2022-06-22 22:58:57.596080
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    response = hardware.get_memory_facts()
    assert 'swaptotal_mb' in response
    assert 'swapfree_mb' in response
    assert 'memtotal_mb' in response
    assert 'memfree_mb' in response

# Generated at 2022-06-22 22:59:05.314279
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module=module)
    device_facts = hardware.get_device_facts()

    assert device_facts['devices']
    assert device_facts['devices']['ent0']['type'] == 'Ethernet Adapter'
    assert device_facts['devices']['ent0']['state'] == 'Available'
    assert device_facts['devices']['ent0']['attributes']
    assert device_facts['devices']['ent0']['attributes']['auto_login_on'] == 'yes'
    assert device_facts['devices']['ent0']['attributes']['backup_pool_id'] == '0'

# Generated at 2022-06-22 22:59:08.606254
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware

    hw_obj = AIXHardware()

    # test aix hardware collection
    hw_obj.get_device_facts()

# Generated at 2022-06-22 22:59:15.159365
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware_facts_collector = AIXHardware(module)

    cpu_facts = hardware_facts_collector.get_cpu_facts()

    assert len(cpu_facts) == 3
    assert int(cpu_facts['processor_count']) > 0
    assert int(cpu_facts['processor_cores']) > 0
    assert cpu_facts['processor'] != ""


# Generated at 2022-06-22 22:59:25.345850
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware

# Generated at 2022-06-22 22:59:33.139165
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.basic import AnsibleModule
    import pytest

    # construct the ansible module
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False
    )

    # set the command paths to local static commands
    module.get_bin_path = lambda x, opt_dirs: 'test/integration/utils/fake_binaries/%s' % x

    # read the output of the fake lsdev command

# Generated at 2022-06-22 22:59:38.327321
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == int(1)
    assert cpu_facts['processor'] == "PowerPC_POWER7"
    assert cpu_facts['processor_cores'] == int(1)



# Generated at 2022-06-22 22:59:41.346020
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    obj = AIXHardware()

    # do not run the populate method, it will try to call lsdev -Cc processor
    # resulting in a non-zero return code
    # obj.populate()

# Generated at 2022-06-22 22:59:50.055487
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    m = AIXHardware()
    dmi_facts = m.get_dmi_facts()
    assert dmi_facts['firmware_version'] == "1.0.17"
    assert dmi_facts['product_serial'] == "0C87D84"
    assert dmi_facts['lpar_info'] == "1 CEC"
    assert dmi_facts['product_name'] == "IBM,8286-42A"


# Generated at 2022-06-22 22:59:53.751733
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec=dict()
    )
    hardware = AIXHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    module.exit_json(changed=False, ansible_facts=cpu_facts)



# Generated at 2022-06-22 23:00:04.863827
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    # Set up mock module
    class Mock_module:
        def __init__(self):
            self.run_command = Mock_run_command

    def Mock_run_command(self, command):
        if '/usr/sbin/lsdev -Cc processor' in command:
            return 0, GET_CPU_FACTS_LSDEV_OUTPUT, ''
        if '/usr/sbin/lsattr' in command:
            return 0, GET_CPU_FACTS_LSATTR_OUTPUT, ''

    # Set up module input parameters
    params = {}

    # Set up expected results of module execution.
    result = {'processor': 'PowerPC_POWER8',
              'processor_cores': 8,
              'processor_count': 3}

    # Instantiate the AIXHardware class with the mock module


# Generated at 2022-06-22 23:00:13.266035
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    class module:
        def run_command(self, command, use_unsafe_shell=False):
            if command == "/usr/sbin/lsdev -Cc processor":
                return 0, 'processor  Available 00-00 Defined  Processor 0\n'

# Generated at 2022-06-22 23:00:15.050086
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware = AIXHardware()
    assert hardware.platform == 'AIX'

# Generated at 2022-06-22 23:00:19.001220
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(dict())
    hardware = AIXHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor']
    assert cpu_facts['processor_count'] > 0
    assert cpu_facts['processor_cores'] > 0


# Generated at 2022-06-22 23:00:29.434201
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    # Stub out class Hardware and its method run_command
    class HWStub(AIXHardware):
        module = None


# Generated at 2022-06-22 23:00:31.964391
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():

    # Test initialize of the collector
    aix_hwobj = AIXHardwareCollector()
    assert aix_hwobj

    # Test inherit of HardwareCollector
    assert aix_hwobj.collect() == aix_hwobj.get_facts()

# Generated at 2022-06-22 23:00:41.806300
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    import tempfile
    import ansible.module_utils.facts.hardware.base

    facts = {}
    tmpdir = tempfile.mkdtemp()
    tmpfile = tmpdir + '/lsconf'
    rc, out, err = ansible.module_utils.facts.hardware.base.get_file_content(tmpfile)

# Generated at 2022-06-22 23:00:44.879962
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={})
    hardware_obj = AIXHardware(module)
    # Check whether constructor works fine
    assert hardware_obj.module is module

# Generated at 2022-06-22 23:00:47.088540
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module=module)
    vgs_facts = hardware.get_vgs_facts()
    print(vgs_facts)

# Generated at 2022-06-22 23:00:47.755870
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    HardwareCollector('AIX', None)

# Generated at 2022-06-22 23:00:50.232178
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={})
    # test class constructor
    AIXHardwareCollector(module)

# Generated at 2022-06-22 23:00:52.795011
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    module.exit_json(**hardware.get_dmi_facts())



# Generated at 2022-06-22 23:00:59.921712
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    hd = AIXHardware()

    # (memtotal_mb, memfree_mb, swapfree_mb, swaptotal_mb)
    hd.module.run_command = Mock(return_value=(0, '', ''))
    hd.module.run_command.side_effect = [(0, 'memory pages: 511905\nfree pages:  491574\n', ''),
                                         (0, '/dev/hd6 599999MB  0MB  599999MB  0% /usr/tmp', ''),
                                         (0, '1:  hdisk0 1:1 Available 0', ''),
                                         (0, 'type: PowerPC_POWER5', ''),
                                         (0, 'smt_threads: 2', '')]

    results = hd.get_memory_facts()

   

# Generated at 2022-06-22 23:01:11.858891
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    import logging
    import os
    import unittest
    import subprocess

    class FakeModule(object):
        def __init__(self):
            self._debug = False

        def run_command(self, cmd, use_unsafe_shell=False):
            return os.system(cmd)

        def get_bin_path(self, arg1=None, required=False, opt_dirs=None):
            # Check if file exist in this directory
            for f in os.listdir('.'):
                if f == arg1:
                    return f
            return None

    class AIXHardwareTestCase(unittest.TestCase):
        """
        Test get_vgs_facts
        """
        def setUp(self):
            self.module = FakeModule()

# Generated at 2022-06-22 23:01:23.259620
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec = dict(
            foo = dict(required=False, type='str')
        ),
        supports_check_mode=True
    )

# Generated at 2022-06-22 23:01:30.339082
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    facts = {
        'facts': {
            'lsdev_cmd': '/usr/sbin/lsdev',
            'lsattr_cmd': '/usr/sbin/lsattr',
            'lsvg_path': '/usr/sbin/lsvg'
        }
    }

    hardware_collector = AIXHardwareCollector(facts)
    assert hardware_collector.fact_class is AIXHardware

# Generated at 2022-06-22 23:01:42.028928
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = MockANSIBLEModule()
    hardware = AIXHardware(module)

    module.run_command.return_value = (0, '', '')
    module.run_command.return_value = (0, '/usr/sbin/lsps -s\n'
                                           'Page Space Physical Volume Volume Group Size %Used Active Auto Type\n'
                                           '  paging00 hdisk0   rootvg         1829MB  0% yes yes lv\n', '')
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['swaptotal_mb'] == 1829


# Generated at 2022-06-22 23:01:51.217482
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-22 23:01:54.452783
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    h = AIXHardware()

    assert h.platform == 'AIX'
    assert h.collector.__class__.__name__ == 'AIXHardwareCollector'



# Generated at 2022-06-22 23:02:02.699237
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    hardware = AIXHardware()
    hardware.module = MagicMock()
    hardware.module.get_bin_path.return_value = "/usr/sbin/lsvg"

# Generated at 2022-06-22 23:02:07.089813
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    aih = AIXHardware()
    aih.module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
        check_invalid_arguments=False
    )
    aih.get_device_facts()

# Generated at 2022-06-22 23:02:15.042945
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    class TestModule(object):
        def __init__(self, args=None, tmpdir=None):
            self.run_command_args = None
            self.run_command_rc = 0
            self.run_command_err = ''
            self.run_command_out = """proc0 Available 00-00-0C Processor
proc1 Available 00-00-10 Processor
proc2 Available 00-00-14 Processor
proc3 Available 00-00-18 Processor
proc4 Available 00-00-1C Processor
proc5 Available 00-00-20 Processor
proc6 Available 00-00-24 Processor
proc7 Available 00-00-28 Processor
proc8 Available 00-00-2C Processor
proc9 Available 00-00-30 Processor
proca Available 00-00-34 Processor
procb Available 00-00-38 Processor"""
            self.run_command

# Generated at 2022-06-22 23:02:25.767801
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import timeout_cache
    from ansible.module_utils.facts.cache import FactCache
    from ansible.module_utils.facts.system import BaseFactSystem

    class TestFactCache(FactCache):
        def __init__(self):
            self._cache = {}

    class TestModule(object):
        def __init__(self):
            self.params = {}
            self.exit_args = None

        def exit_json(self, **kwargs):
            self.exit_args = kwargs


# Generated at 2022-06-22 23:02:36.825794
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={'gather_subset': dict(default=['all'], type='list')})
    shared_obj = AIXHardware(module)
    initial_facts = shared_obj.populate()
    assert initial_facts['processor_count'] > 0
    assert initial_facts['processor'] != ''
    assert initial_facts['swaptotal_mb'] >= 0
    assert initial_facts['swapfree_mb'] >= 0
    assert initial_facts['memtotal_mb'] >= 0
    assert initial_facts['memfree_mb'] >= 0
    assert initial_facts['firmware_version'] is not None
    assert initial_facts['product_serial'] is not None
    assert initial_facts['lpar_info'] is not None
    assert initial_facts['product_name'] is not None
   

# Generated at 2022-06-22 23:02:42.739619
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    test_module = AnsibleModule(argument_spec={})
    test_AIXHardware = AIXHardware(test_module)
    assert test_AIXHardware.get_memory_facts() == {'memfree_mb': 1143,
                                                   'memtotal_mb': 9830,
                                                   'swapfree_mb': 1225,
                                                   'swaptotal_mb': 1229
                                                   }


# Generated at 2022-06-22 23:02:44.822233
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={})
    hardware_collector = AIXHardware(module)
    assert hardware_collector


# Generated at 2022-06-22 23:02:52.039555
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = AIXHardware(module)

    mounts = hardware.get_mount_facts()['mounts']
    assert len(mounts) > 0
    for mount in mounts:
        assert 'mount' in mount
        assert 'device' in mount
        assert 'fstype' in mount
        assert 'options' in mount
        assert 'time' in mount
        assert 'size_total' in mount
        assert 'size_available' in mount
        assert 'size_used' in mount



# Generated at 2022-06-22 23:02:55.856345
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={})
    hardware_obj = AIXHardware(module)

    assert hardware_obj.platform == 'AIX'
    assert hardware_obj.module == module

# Unit Test for populate()

# Generated at 2022-06-22 23:02:58.116701
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    test_module = AnsibleModule(argument_spec={})
    test_object = AIXHardware(module=test_module)
    test_object.get_mount_facts()

# Generated at 2022-06-22 23:03:02.374143
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={})
    hardware_obj = AIXHardware(module)
    hardware_obj.populate()
    hardware_obj.get_cpu_facts()
    hardware_obj.get_memory_facts()
    hardware_obj.get_dmi_facts()
    hardware_obj.get_vgs_facts()
    hardware_obj.get_mount_facts()
    hardware_obj.get_device_facts()

# Generated at 2022-06-22 23:03:05.271599
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    collector = AIXHardwareCollector()

    assert collector.hardware
    assert collector.platform == 'AIX'
    assert collector.hardware._module

# Generated at 2022-06-22 23:03:17.187292
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module_mock = AnsibleModuleMock()
    device_facts = AIXHardware.get_device_facts(module_mock)


# Generated at 2022-06-22 23:03:22.762517
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = 'aix_facts'
    cls = AIXHardware(module)
    assert cls.get_cpu_facts()['processor_count'] == 2
    assert cls.get_cpu_facts()['processor'] == "POWER8"
    assert cls.get_cpu_facts()['processor_cores'] == 4

# Generated at 2022-06-22 23:03:33.525915
# Unit test for method get_mount_facts of class AIXHardware

# Generated at 2022-06-22 23:03:43.162777
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import DEFAULT_TIME_FORMAT
    import time

    module = AnsibleModule(argument_spec={})

    cpu_facts = {
        'processor': [b'POWER8'],
        'processor_count': 4,
        'processor_cores': 2
    }
    memory_facts = {
        'memtotal_mb': 2768,
        'memfree_mb': 1119,
        'swaptotal_mb': 2048,
        'swapfree_mb': 2048
    }

# Generated at 2022-06-22 23:03:54.566810
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    b = AIXHardware(dict())