

# Generated at 2022-06-22 22:53:52.163967
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_collector = AIXHardwareCollector(module=module, facts={})
    facts = hardware_collector.collect(module=module, collected_facts={})
    # Do we have vgs facts
    if 'vgs' in facts:
        assert isinstance(facts['vgs'], dict)
        assert 'realsyncvg' in facts['vgs']
        assert 'testvg' in facts['vgs']
        assert 'rootvg' in facts['vgs']
    # Do we have mount facts
    if 'mounts' in facts:
        assert isinstance(facts['mounts'], list)
    # Do we have devices facts
    if 'devices' in facts:
        assert isinstance(facts['devices'], dict)
        assert '/dev/ipldev0'

# Generated at 2022-06-22 22:54:00.743590
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():

    # mock module class to provide a static value for lsdev output
    class FakeModule(object):
        def __init__(self, device_name, device_state, device_type, attributes):
            self.run_command_values = {
                ('which lsdev',): (0, 'lsdev', ''),
                ('lsdev',): (0, '%s %s %s' % (device_name, device_state, ' '.join(device_type)), ''),
                ('which lsattr',): (0, 'lsattr', ''),
                ('lsattr', '-E', '-l', device_name): (0, '\n'.join(attributes), '')
            }


# Generated at 2022-06-22 22:54:11.512521
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    """
    Unit test for method get_mount_facts of class AIXHardware.
    Parameters:
        - None.
    Returns:
        - None.
    """
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts.utils import get_mount_size
    device_fact = AIXHardware()
    device_fact.module = AnsibleModule()
    output = device_fact.get_mount_facts()
    assert 'mounts' in output
    assert output['mounts'][0]['mount'] == '/'
    assert output['mounts'][0]['device'] == '/dev/hd4'
    assert output['mounts'][0]['fstype'] == 'jfs2'
    assert output['mounts'][0]['time']

# Generated at 2022-06-22 22:54:21.671876
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    class MockModuleObject(object):
        def __init__(self):
            self.run_command_args = []

        def run_command(self, args, **kwargs):
            self.run_command_args = [args, kwargs]
            if args == '/usr/sbin/lsattr -El sys0 -a fwversion':
                return 0, 'fwversion IBM,8233-E8B', ''
            if args == '/usr/sbin/lsconf':
                return 0, 'Machine Serial Number: 09K9S12\nSystem Model: IBM,8233-E8B\nLPAR Info: 1 SuperVSA_LPAR', ''
            return 0, '', ''


# Generated at 2022-06-22 22:54:33.075811
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import os
    import json

    module = basic.AnsibleModule(
        argument_spec=dict()
    )

    test_data_dir = os.path.join(os.path.dirname(__file__), 'unittests',
                                 'test_data', 'aix_hardware', 'get_devices')

# Generated at 2022-06-22 22:54:42.668258
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})

    hardware = AIXHardware(module)
    devices = hardware.get_device_facts()

    assert devices is not None
    assert len(devices['devices']) > 0
    assert devices['devices']['hdisk3']['state'] == 'Available'
    assert devices['devices']['hdisk3']['type'] == 'SCSI Disk Drive'
    assert devices['devices']['hdisk3']['attributes']['size'] == '505780'
    assert devices['devices']['hdisk3']['attributes']['clr_q'] == 'enable'
    assert devices['devices']['hdisk3']['attributes']['q_type'] == 'Simple'



# Generated at 2022-06-22 22:54:47.094437
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    '''
    Unit test for the constructor of class AIXHardware.

    :return:
    '''
    hardware_facts = AIXHardware(dict())
    assert hardware_facts.platform == "AIX"


# Generated at 2022-06-22 22:54:57.892702
# Unit test for method get_dmi_facts of class AIXHardware

# Generated at 2022-06-22 22:55:10.502694
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(
        argument_spec={}
    )
    hardware_facts = AIXHardware()

    # Test case 1. General AIX mount
    # cmd = "dummy_mount -v"
    # out = """
    #     node: /dev/hd4
    #     mount: /
    #     time: Tue Jun  6 14:41:17 2017
    #     type: jfs2
    #     options: log=/dev/hd8
    #     mode: rw,log=/dev/hd8
    #     account: 0
    #     0/0/1/3.0.0:
    #     node: /dev/hd2
    #     mount: /usr
    #     time: Mon Feb  5 06:05:54 2018
    #     type: jfs2
    #     options

# Generated at 2022-06-22 22:55:14.049388
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] > 0
    assert cpu_facts['processor']
    assert cpu_facts['processor_cores'] > 0



# Generated at 2022-06-22 22:55:26.410168
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():

    class FakeModule(object):
        def __init__(self):
            self.run_command_args_list = []
            self.run_command_returns = []
            self.run_command_succeeds = True
            self.run_command_exits = []

        def run_command(self, cmd, use_unsafe_shell=False):
            self.run_command_args_list.append(cmd)
            if self.run_command_succeeds:
                if len(self.run_command_returns) > 0:
                    results = self.run_command_returns[0]
                    self.run_command_returns = self.run_command_returns[1:]
                    return results
                else:
                    if len(self.run_command_exits) > 0:
                        results

# Generated at 2022-06-22 22:55:36.913206
# Unit test for method get_mount_facts of class AIXHardware

# Generated at 2022-06-22 22:55:40.154998
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
     aix_collector = AIXHardwareCollector()
     assert AIXHardwareCollector._platform == 'AIX'
     assert AIXHardwareCollector._fact_class == AIXHardware


# Generated at 2022-06-22 22:55:50.388383
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    hard = AIXHardware(module)
    facts_dict = hard.populate()
    assert facts_dict['ansible_processor'][0] == 'PowerPC_POWER8'
    assert facts_dict['ansible_memtotal_mb'] == 990864
    assert facts_dict['ansible_memfree_mb'] == 989434
    assert facts_dict['ansible_swaptotal_mb'] == 519423
    assert facts_dict['ansible_swapfree_mb'] == 519359
    assert facts_dict['ansible_devices']['ent0']['state'] == 'Available'
    assert facts_dict['ansible_devices']['ent0']['type'] == 'Ethernet Adapter'

# Generated at 2022-06-22 22:55:58.263949
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    f = AIXHardware({
        'module_setup': True,
        'gather_subset': [''],
        'filter': '*'
    })
    facts = f.populate()
    assert 'mounts' in facts.keys()
    assert 'mount' in facts['mounts'][0]
    assert 'device' in facts['mounts'][0]
    assert 'fstype' in facts['mounts'][0]
    assert 'options' in facts['mounts'][0]
    assert 'time' in facts['mounts'][0]
    assert 'size_total' in facts['mounts'][0]
    assert 'size_available' in facts['mounts'][0]
    assert 'size_used' in facts['mounts'][0]

# Generated at 2022-06-22 22:56:07.188258
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-22 22:56:13.082745
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = get_platform_subclass('AIX', MockModule())
    meminfo = module.get_memory_facts()

    assert meminfo['memfree_mb'] == get_mount_size('/proc/meminfo')['avail'] // 1024
    assert meminfo['swapfree_mb'] == get_mount_size('/proc/meminfo')['swapfree'] // 1024



# Generated at 2022-06-22 22:56:25.138223
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    from ansible.module_utils import basic
    import os
    import sys

    module = basic.AnsibleModule(
        argument_spec=dict(
            mounts=dict(required=False, default=True, type='bool'),
        )
    )

    if not sys.platform.startswith('aix'):
        module.exit_json(changed=False)

    device_facts = AIXHardware(module).get_device_facts()
    expected_keys = ['devices']
    expected_dev_keys = ['lsvob', 'lscfg', 'lsdev', 'lsattr', 'lsvg', 'lsps', 'lsvg', 'lspv']

    for k in expected_keys:
        if k not in device_facts:
            module.fail_json(msg="%s missing in returned facts" % k)



# Generated at 2022-06-22 22:56:27.854815
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    mock_AIXHardware = AIXHardware({})
    for key in mock_AIXHardware.get_dmi_facts():
        assert mock_AIXHardware.get_dmi_facts()[key] is not None

# Generated at 2022-06-22 22:56:39.329820
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    command_output_dict = {
        '/usr/sbin/lsattr -El sys0 -a fwversion': 'fwversion IBM,R610_022',
        '/usr/bin/oslevel': '7.2.0.3',
        '/usr/sbin/lsconf': '''
Machines:
Machine Serial Number:
Machine Type:
Model:
Processor Type:
Physical Memory Size (bytes):
Processor Clock Speed (MHz):
CPU Type:
LPAR Info:
<--lpar info-->
System Model:
Machine Serial Number:
'''
    }
    test_hardware = AIXHardware(dict(), command_output_dict, '')
    test_hardware_dmi_facts = test_hardware.get_dmi_facts()

# Generated at 2022-06-22 22:56:48.829661
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    lsdev_output = """Available 01-00 Processor
Available 02-00 Processor
True   03-00 Processor
Available 04-00 Processor
True   05-00 Processor
Available 06-00 Processor
Available 07-00 Processor
Available 08-00 Processor
Available 09-00 Processor
Available 10-00 Processor"""
    lsattr_output = """type PowerPC_POWER8
smt_threads 4"""
    facts_obj = AIXHardware()
    facts_file_name = "facts/hardware/hardware_facts.txt"
    facts_file = open(facts_file_name, "w")
    facts_file.write(lsdev_output)
    facts_file.close()
    dummy_module = basic.AnsibleModule

# Generated at 2022-06-22 22:56:52.654073
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = FakeAnsibleModule()
    module.run_command = Mock(return_value=(0, "firmware_version", ""))
    hardware = AIXHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['firmware_version'] == "IBM,C190_158"



# Generated at 2022-06-22 22:56:56.458753
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    '''
    Return vg and pv facts
    '''
    module = AnsibleModule(
        argument_spec={}
    )

    hardware = AIXHardware(module=module)
    hardware.get_vgs_facts()



# Generated at 2022-06-22 22:57:08.531276
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    """ Unit test for method get_vgs_facts of class AIXHardware """
    from ansible.module_utils import basic
    import ansible.module_utils.facts.hardware.aix
    from ansible.module_utils.facts.hardware.aix import AIXHardware

    module = basic.AnsibleModule(
        argument_spec={
            'filter': {'required': False, 'type': 'list'}
        }
    )
    module.exit_json = lambda **kwargs: kwargs


# Generated at 2022-06-22 22:57:18.644587
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    # test aix facts
    module = FakeAnsibleModule()
    hardware = AIXHardware(module)
    facts = hardware.populate()
    assert facts['firmware_version'] == 'VE330A01'
    assert facts['lpar_info'] == '51C8C2A9  A  0010F0A300C11E8A  #  AIX/7'
    assert facts['product_name'] == '9117-MMB'
    assert facts['product_serial'] == '06A93D2E'
    assert facts['processor'] == 'PowerPC_POWER8'
    assert facts['processor_cores'] == 8
    assert facts['processor_count'] == 32
    assert facts['swapfree_mb'] == 0
    assert facts['swaptotal_mb'] == 0
    assert isinstance

# Generated at 2022-06-22 22:57:20.822324
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    aix_hardware = AIXHardware()
    assert aix_hardware.platform == 'AIX'

# Generated at 2022-06-22 22:57:31.995022
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    class ModuleMock(object):
        def __init__(self, out=None, err=None, rc=0):
            self.rc = rc
            self.out = out
            self.err = err

# Generated at 2022-06-22 22:57:35.954389
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={'paths': {'required': False, 'default': None}})
    obj = AIXHardware(module)
    res = obj.get_device_facts()
    assert isinstance(res, dict)
    assert 'devices' in res


# Generated at 2022-06-22 22:57:40.811664
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )

    ah = AIXHardware(module)

    # Add test for when a processor is found
    cpu_facts_out = ah.get_cpu_facts()
    assert type(cpu_facts_out) is dict

    # Add test for when a processor is not found


# Generated at 2022-06-22 22:57:52.809311
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    '''Test of method get_device_facts of class AIXHardware'''
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector.aix import AIXHardware
    from ansible.module_utils.facts.utils import get_file_content
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file with the output of the command lsdev
    path_lsdev = tmpdir + '/lsdev'
    with open(path_lsdev, 'wb') as f_lsdev:
        f_lsdev.write(to_bytes('ent0 Available 01-00 Backplane Ethernet Adapter (lpcs0) Ethernet PCI Adapter'))

# Generated at 2022-06-22 22:57:57.853204
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec=dict())
    hardware_obj = AIXHardware(module)
    hardware_obj.populate()
    module.exit_json(changed=False, ansible_facts=dict(hardware=hardware_obj.facts))


# Ansible module arguments specification
argument_spec = dict()

# Ansible module

# Generated at 2022-06-22 22:58:04.476955
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    hardware = AIXHardware()
    hardware.module = MagicMock()

    memory_facts = {}

    hardware.module.run_command.return_value = (0, "73557688 memory pages\n471997 free pages\n", "")

    memory_facts = hardware.get_memory_facts()

    assert memory_facts['memtotal_mb'] == 147 * 1024
    assert memory_facts['memfree_mb'] == 9 * 1024

    hardware.module.run_command.return_value = (0, "error\n", "")

    memory_facts = hardware.get_memory_facts()

    assert memory_facts['memtotal_mb'] == 0
    assert memory_facts['memfree_mb'] == 0



# Generated at 2022-06-22 22:58:14.872179
# Unit test for method get_device_facts of class AIXHardware

# Generated at 2022-06-22 22:58:27.065720
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec={}
    )

    aix_hardware = AIXHardware(module)

    expected_dmi_facts = {
        'firmware_version': '1.8.12',
        'lpar_info': '1 lpar2: version=BOS.6.1.7.0',
        'product_name': 'RS/6000 7248-420',
        'product_serial': '02270109'
    }

    lsconf_path = aix_hardware.module.get_bin_path("lsconf")
    if lsconf_path:
        rc, out, err = aix_hardware.module.run_command(lsconf_path)

# Generated at 2022-06-22 22:58:36.633593
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    # Test array of vgs facts

# Generated at 2022-06-22 22:58:49.175207
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)


# Generated at 2022-06-22 22:58:55.357678
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0


# Generated at 2022-06-22 22:58:59.359770
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    hardware = AIXHardware(module)
    hardware.populate()
    assert hardware.memory['memtotal_mb'] > 0
    assert 'memfree_mb' in hardware.memory



# Generated at 2022-06-22 22:59:08.829736
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module_mock = AnsibleModuleMock()
    module_mock.run_command = run_command_mock_a
    module_mock.get_bin_path = get_bin_path_mock_a
    ahw = AIXHardware(module_mock)
    dmi_facts = ahw.get_dmi_facts()
    assert dmi_facts['firmware_version'] == 'M9X123'
    assert dmi_facts['lpar_info'] == 'lpar_info'
    assert dmi_facts['product_name'] == 'PowerNV'
    assert dmi_facts['product_serial'] == '1234567890'


# Generated at 2022-06-22 22:59:13.535427
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    hardware_obj = AIXHardware()
    cpu_facts = hardware_obj.get_cpu_facts()
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor'] == 'PowerPC_POWER8'
    assert cpu_facts['processor_cores'] == 1



# Generated at 2022-06-22 22:59:24.310434
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    # need to define structure that class function can use - TestAnsibleModule is a
    # class defined in the unit test module and TestAnsibleModule._exec_module is a
    # function that does some stuff that is not interesting for the test function
    # and returns a tuple for which the first element is a dictionary and the second
    # element is a string.
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts.utils import TestAnsibleModule

    module = TestAnsibleModule()

    # stub for the lsconf command

# Generated at 2022-06-22 22:59:25.701901
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware = AIXHardware({})
    assert hardware.platform == 'AIX'

# Generated at 2022-06-22 22:59:29.660703
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    """Instantiate the class and call its get_memory_facts method."""
    from ansible.module_utils.facts.hardware.aix import AIXHardware

    aix = AIXHardware({})
    aix.get_memory_facts()


if __name__ == '__main__':
    test_AIXHardware_get_memory_facts()

# Generated at 2022-06-22 22:59:34.926465
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    mp = AIXHardwareCollector(module)
    res = mp.get_mount_facts()
    assert res['mounts'][0]['mount'] == '/'


# Generated at 2022-06-22 22:59:46.138501
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    """
    Unit test get_memory_facts method of class AIXHardware
    """
    class TestModule(object):
        def __init__(self, out):
            self.out = out
        def run_command(self, cmd, use_unsafe_shell=False):
            return(0, self.out, None)

    # Test case #1: vmstat out has my memory info

# Generated at 2022-06-22 22:59:55.914443
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    hardware = AIXHardware()
    hardware.module = MagicMock()

    vmstat_out = """System configuration: lcpu=2 mem=2048MB ent=0.50
kthr      memory            page            faults      cpu
----- ----------- ------------------------ ------------ -----------
 r  b   avm   fre  re  pi  po  fr   sr  cy  in   sy  cs us sy id wa
 1  0 672.8M 34.0M  0  0  0   0    0   0  0 248.4M 8.1M  0  0  0  0"""
    hardware.module.run_command.return_value = (0, vmstat_out, None)


# Generated at 2022-06-22 23:00:03.341019
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    aix_hardware = AIXHardware()
    fact_collector = FactCollector()
    fact_collector._module = MockModule
    fact_collector.collect()
    dmi_facts = aix_hardware.get_dmi_facts()
    for fact in dmi_facts:
        assert fact, "Not Collecting %s fact" % fact


# Generated at 2022-06-22 23:00:08.128866
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = AIXHardware(module)
    facts = hardware.get_memory_facts()

    assert facts['memtotal_mb'] == '2077'
    assert facts['memfree_mb'] == '497'

# Generated at 2022-06-22 23:00:19.589842
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    # Setup hardware object to simulate lsconf results
    hardware_object = AIXHardware()
    hardware_object.module = Mock()
    hardware_object.module.run_command.return_value = (0, '\nMachine Serial Number:0A06W8K6-B1\nLPAR Info:4\nSystem Model:IBM,8286-41A\n', None)

    # run method to test
    result = hardware_object.get_dmi_facts()

    # verify results
    assert '8286-41A' == result['product_name']
    assert '4' == result['lpar_info']
    assert '0A06W8K6-B1' == result['product_serial']
    assert 'IBM,' == result['firmware_version']


# Generated at 2022-06-22 23:00:21.450162
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    mount_facts = AIXHardware.get_mount_facts(None)
    print(mount_facts)

# Generated at 2022-06-22 23:00:30.795486
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    # Here, we need to mock a module and a module.run_command()
    # We can start with module_utils.basic.AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.hardware.aix import AIXHardwareCollector

    # Helper function to mock module.run_command()

# Generated at 2022-06-22 23:00:33.161958
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware_info = AIXHardware(None)
    assert hardware_info.platform == 'AIX'

# Generated at 2022-06-22 23:00:42.357120
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    import ansible
    aix = AIXHardware(ansible.module_utils.basic.AnsibleModule(
    argument_spec = dict()
    ))

    aix.get_mount_facts()

    # Unit test for method get_mount_facts of class AIXHardware with mock data
    import mock

    aix = AIXHardware(ansible.module_utils.basic.AnsibleModule(
    argument_spec = dict()
    ))

    mount_path = aix.module.get_bin_path('mount')
    aix.module.run_command = mock.Mock()
    rc = 0
    err = ""

# Generated at 2022-06-22 23:00:44.617077
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware = AIXHardware()
    assert hardware.platform == 'AIX'


# Generated at 2022-06-22 23:00:50.792318
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    hardware = AIXHardware()
    hardware.module = ModuleStub()
    hardware.module.run_command = run_command_stub
    device_facts = hardware.get_device_facts()

    assert len(device_facts) != 0
    assert len(device_facts.keys()) == 1
    assert len(device_facts['devices'].keys()) == 2



# Generated at 2022-06-22 23:00:53.772479
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    facts = AIXHardware({})
    assert isinstance(facts, dict)
    assert facts['processor_count'] == 1
    assert facts['processor'] == 'PowerPC_POWER8'
    assert facts['processor_cores'] == 4


# Generated at 2022-06-22 23:01:05.882854
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    test_facts = hardware.get_vgs_facts()

# Generated at 2022-06-22 23:01:17.613632
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = MockModule()
    hardware = AIXHardware(module)
    hardware.module.run_command.return_value = (0, "proc0 Available 00-00 Processor\n"
                                                "proc1 Available 00-01 Processor", "")
    hardware.module.run_command.return_value = (0, "type PowerPC_POWER8", "")
    hardware.module.run_command.return_value = (0, "smt_threads 4 True", "")
    assert hardware.get_cpu_facts() == {'processor': 'PowerPC_POWER8',
                                        'processor_cores': 4,
                                        'processor_count': 2,
                                        'processor_threads_per_core': 2}



# Generated at 2022-06-22 23:01:26.023030
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    from ansible.module_utils._text import to_bytes

    module = AnsibleModule({}, {}, {}, {}, False, False, False)

# Generated at 2022-06-22 23:01:31.682079
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    aixhw = AIXHardware()
    assert aixhw.get_memory_facts()['memtotal_mb'] >= 1
    assert aixhw.get_memory_facts()['memfree_mb'] >= 1

if __name__ == '__main__':
    test_AIXHardware_get_memory_facts()

# Generated at 2022-06-22 23:01:34.109512
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    collector = AIXHardwareCollector()
    assert collector.platform == 'AIX'
    assert collector.fact_class == AIXHardware


# Generated at 2022-06-22 23:01:45.769138
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    fake_module = type("obj", (object,), {'run_command': run_command_mock})()
    ah = AIXHardware(fake_module)

# Generated at 2022-06-22 23:01:53.314621
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    text_pv = """rootvg:
PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
hdisk0            active            546         0           00..00..00..00..00
hdisk1            active            546         113         00..00..00..21..92
realsyncvg:
PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
hdisk74           active            1999        6           00..00..00..00..06
testvg:
PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
hdisk105          active            999         838         200..39..199..200..200
hdisk106          active            999         599         200..00..00..199..200
"""
    hardware = AIXHardware()
   

# Generated at 2022-06-22 23:01:55.621801
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    obj = AIXHardware()
    result = obj.get_memory_facts()
    assert type(result) == dict


# Generated at 2022-06-22 23:01:59.441856
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)

    cpu_facts = hardware.get_cpu_facts()

    assert cpu_facts['processor'][0] is not None
    assert cpu_facts['processor_count'] is not None
    assert cpu_facts['processor_cores'] is not None



# Generated at 2022-06-22 23:02:10.933391
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    mock_module = type("AnsibleModule", (), {})()
    mock_module.run_command = run_command
    clstest = AIXHardware(mock_module)
    result = clstest.populate()

    assert result['ansible_processor'] == "00F76900"
    assert result['ansible_processor_cores'] == 4
    assert result['ansible_processor_count'] == 2
    assert result['ansible_memfree_mb'] == 102
    assert result['ansible_memtotal_mb'] == 1000
    assert result['ansible_swapfree_mb'] == 95
    assert result['ansible_swaptotal_mb'] == 1000
    assert result['ansible_firmware_version'] == 'V7R3M0'
    assert result['ansible_product_name']

# Generated at 2022-06-22 23:02:18.624238
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = FakeAnsibleModule()
    hardware = AIXHardware(module)

    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['firmware_version'] == '1.1.1'
    assert dmi_facts['lpar_info'] == '1 CEC'
    assert dmi_facts['product_name'] == 'pSeries'
    assert dmi_facts['product_serial'] == '000XXXXXXXXXXX'



# Generated at 2022-06-22 23:02:25.508355
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    # We know facts on AIX with pp size 4 kB
    assert hardware.get_memory_facts()['memtotal_mb'] == 2097152
    assert hardware.get_memory_facts()['memfree_mb'] == 1048576
    assert hardware.get_memory_facts()['swaptotal_mb'] == 2047
    assert hardware.get_memory_facts()['swapfree_mb'] == 1541

# Generated at 2022-06-22 23:02:36.640965
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)

    ah = AIXHardware(module=module)
    ah.populate()

    assert ah.facts['processor_count'] == 1
    assert ah.facts['processor_cores'] == 4
    assert ah.facts['processor'] == 'PowerPC_POWER7'
    assert ah.facts['memtotal_mb'] == 2142
    assert ah.facts['memfree_mb'] == 1454
    assert ah.facts['swaptotal_mb'] == 1018
    assert ah.facts['swapfree_mb'] == 1018
    assert ah.facts

# Generated at 2022-06-22 23:02:46.499568
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = MagicMock()
    hw_collector = AIXHardwareCollector(module)

    # get_bin_path is mocked to return '/usr/bin/lsdev'
    # and '/usr/bin/lsattr'
    lsdev_path = hw_collector.module.get_bin_path.side_effect = ['/usr/bin/lsdev', '/usr/bin/lsattr']

    attr_out = "attribute      value\nmessage_level    4\nalt_tgt_support  yes\n"
    attr_err = ''
    attr_rc = 0

# Generated at 2022-06-22 23:02:56.579868
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    hw = AIXHardware()
    facts = hw.populate()
    assert facts['memory'] == {'swaptotal_mb': 1019, 'memfree_mb': 554, 'swapfree_mb': 806, 'memtotal_mb': 2383}
    assert facts['cpu'] == {'processor_cores': 4, 'processor_count': 4, 'processor': 'PowerPC_POWER8'}
    assert facts['dmi'] == {'firmware_version': 'IBM,BQ12345', 'product_serial': '12345ABCDE', 'product_name': 'IBM,8335-GTB', 'lpar_info': 'LPAR Number            1'}

# Generated at 2022-06-22 23:03:02.117292
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    """
    Unit test for method populate of class AIXHardware
    """
    module = AnsibleModule(argument_spec=dict())
    hardware = AIXHardware(module)
    result = hardware.populate()
    assert result['firmware_version']
    assert result['product_serial']
    assert result['product_name']
    assert result['mounts']
    assert result['devices']
    assert result['memory']
    assert result['system']
    assert result['cpu']


# Generated at 2022-06-22 23:03:05.168309
# Unit test for constructor of class AIXHardware
def test_AIXHardware():

    hardware_obj = AIXHardware()
    platform = hardware_obj.populate()
    assert platform == 'AIX'


# Generated at 2022-06-22 23:03:09.234977
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    hw = AIXHardware()
    result = hw.get_cpu_facts()

    assert result == {'processor_count': 4, 'processor': 'PowerPC_POWER7'}

# Generated at 2022-06-22 23:03:16.363181
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec=dict())
    aixhw = AIXHardware(module)
    mount_facts = aixhw.get_mount_facts()
    assert 'mounts' in mount_facts.keys()
    assert type(mount_facts['mounts']) is list
    for mnt in mount_facts['mounts']:
        assert 'fstype' in mnt.keys()
        assert type(mnt['fstype']) is str
        assert 'mount' in mnt.keys()
        assert type(mnt['mount']) is str
        assert 'device' in mnt.keys()
        assert type(mnt['device']) is str
        assert 'time' in mnt.keys()
        assert type(mnt['time']) is str
        assert 'options' in mnt.keys

# Generated at 2022-06-22 23:03:24.048573
# Unit test for method get_mount_facts of class AIXHardware

# Generated at 2022-06-22 23:03:31.840617
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    hw_facts = AIXHardware(module)
    cpu_facts = hw_facts.get_cpu_facts()
    assert cpu_facts['processor'].startswith(('PowerPC_POWER8')), "Invalid processor facts"
    assert cpu_facts['processor_cores'] >= 1 and cpu_facts['processor_cores'] <= 8, "Invalid processor cores facts"
    assert cpu_facts['processor_count'] > 0, "Invalid processor count facts"


# Generated at 2022-06-22 23:03:39.299797
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.run_command = MagicMock(return_value=(0, '', ''))

# Generated at 2022-06-22 23:03:43.042284
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(
        argument_spec = dict()
    )

    hardware_obj = AIXHardware(module)

    assert hardware_obj.platform == 'AIX'
    assert hardware_obj.module == module
    assert hardware_obj.collector == None
    assert hardware_obj.facts == {}

# Generated at 2022-06-22 23:03:54.567859
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    """
    Run get_vgs_facts() and compare the results with values previously recorded.
    """

    new_facts = AIXHardware().get_mount_facts()

    # Recreate the structure of previously recorded dict to perform comparison