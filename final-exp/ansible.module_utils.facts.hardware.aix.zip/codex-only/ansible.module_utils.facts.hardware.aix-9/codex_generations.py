

# Generated at 2022-06-22 22:53:54.174975
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec=dict())
    obj = module.params
    obj['_ansible_verbosity'] = 4
    ansible_facts = {}
    result = {'changed': False}
    obj['ansible_facts'] = ansible_facts
    aix_hw_obj = AIXHardware(module)
    ansible_facts['ansible_mounts'] = []
    ansible_facts['ansible_mounts'].append({'device': '/dev/hd1', 'mount': '/'})

# Generated at 2022-06-22 22:53:56.901199
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
# The assert statement is used to check if the expression returns True.
# The test case below tests the AIXHardware constructor.
    aixhardware = AIXHardware()

# Generated at 2022-06-22 22:54:09.124720
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = MockANSIRunner()
    hardware = AIXHardware(module)
    # Set the output of commands

# Generated at 2022-06-22 22:54:20.377523
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    import StringIO
    # Create string object as file object
    fake_out = StringIO.StringIO('')

    # Create object of AIXHardware
    hw = AIXHardware()

    # Set fake module
    class MyModule(object):
        def __init__(self):
            self.run_command_called = False
            self.run_command_rc = 0
            self.run_command_outs = []
            self.run_command_errs = []

        def run_command(self, args, check_rc=False, close_fds=True, executable=None, use_unsafe_shell=False, data=None):
            self.run_command_called = True
            self.run_command_outs.append(fake_out.getvalue())
            self.run_command_errs.append('')

# Generated at 2022-06-22 22:54:21.487623
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware = AIXHardware()
    assert hardware.platform == 'AIX'

# Generated at 2022-06-22 22:54:26.647310
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    set_module_args(dict())
    aix_hardware = AIXHardware(module)
    aix_hardware.populate()
    aix_hardware.get_device_facts()



# Generated at 2022-06-22 22:54:38.470295
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={})
    hardware_obj = AIXHardware(module)

    processor_cores = hardware_obj.get_cpu_facts()['processor_cores']
    assert processor_cores is not None

    processor_count = hardware_obj.get_cpu_facts()['processor_count']
    assert processor_count is not None

    memory_facts = hardware_obj.get_memory_facts()
    assert memory_facts['memfree_mb'] is not None
    assert memory_facts['memtotal_mb'] is not None
    assert memory_facts['swapfree_mb'] is not None
    assert memory_facts['swaptotal_mb'] is not None

    dmi_facts = hardware_obj.get_dmi_facts()

# Generated at 2022-06-22 22:54:50.160497
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = MockModule()
    hardware = AIXHardware(module)

    def _run_command(cmd, **kwargs):
        assert '/usr/sbin/lsattr -El sys0 -a fwversion' == cmd
        return 0, "firmware_version IBM,1234-P011", ''

    hardware.module.run_command = _run_command
    facts = hardware.get_dmi_facts()

    assert facts['firmware_version'] == '1234-P011'
    assert facts['product_serial'] == "123456789"
    assert facts['lpar_info'] == "lparname:1"
    assert facts['product_name'] == "bigbox"



# Generated at 2022-06-22 22:54:55.210981
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    # Define a class that simulates module class for Ansible
    class AnsibleModuleFake:

        # Mock method get_bin_path of AnsibleModuleFake to return expected value
        @staticmethod
        def get_bin_path(command, required=False):
            return '/usr/bin/' + command

        # Mock method run_command of AnsibleModuleFake to return expected value

# Generated at 2022-06-22 22:54:58.893018
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    aixhw = AIXHardware(dict())
    assert aixhw.platform == 'AIX'

# Generated at 2022-06-22 22:55:01.886753
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts.hardware.aix import AIXHardwareCollector
    from ansible.module_utils.facts.utils import FactsParams
    params = FactsParams()
    aix = AIXHardware(params)
    aixc = AIXHardwareCollector()
    aixc.collect(aix, params)

# Generated at 2022-06-22 22:55:12.859761
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    class AIXHardwareMock(AIXHardware):
        def __get_command_results(self, cmd):
            if cmd == '/usr/bin/vmstat -v':
                return 0, "memory pages: 7270 \nfree pages: 3", None
            elif cmd == '/usr/sbin/lsps -s':
                return 0, "Device          1M-blocks     Used    Avail Capacity\n"

# Generated at 2022-06-22 22:55:25.860641
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_mock = AIXHardware(module)

    hardware_mock.get_cpu_facts = MagicMock()
    hardware_mock.get_memory_facts = MagicMock()
    hardware_mock.get_dmi_facts = MagicMock()
    hardware_mock.get_vgs_facts = MagicMock()
    hardware_mock.get_mount_facts = MagicMock()
    hardware_mock.get_device_facts = MagicMock()

    hardware_mock.populate()
    assert hardware_mock.get_cpu_facts.called
    assert hardware_mock.get_memory_facts.called
    assert hardware_mock.get_dmi_facts.called
    assert hardware_mock.get_vgs_facts

# Generated at 2022-06-22 22:55:31.549123
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    collected_facts = {}
    collected_facts['ansible_architecture'] = 'ppc64'
    aix_facts = AIXHardware(collected_facts=collected_facts)
    device_facts = aix_facts.get_device_facts()
    assert type(device_facts) == dict
    assert device_facts['devices']

# Generated at 2022-06-22 22:55:41.113037
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    """
    This is where you'd write a test if you wanted to.
    """
    # Get data from files in tests/mock_data
    import os
    import sys
    import ansible.module_utils.facts.hardware.aix
    sys.modules['ansible.module_utils.facts.hardware.aix'] = ansible.module_utils.facts.hardware.aix
    sys.path.append(os.path.join(os.path.dirname(os.path.realpath(__file__)), "../../../../tests/mock_data"))
    from ansible.module_utils.facts.hardware.aix import MockModule
    from ansible.module_utils.facts.hardware.aix import MockLSDEV
    from ansible.module_utils.facts.hardware.aix import Mock

# Generated at 2022-06-22 22:55:51.179370
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    aix_hardware = AIXHardware
    test_out_lsconf = """
Version:@(#) lscfg command lscfg_AIX 5.1.0.0 03/01/2017
System Model: IBM,8284-22A
Serial Number: YBPKF5U
Machine Serial Number: 11A5803
LPAR Info: 1 AIX,
"""
    test_out_lsattr = """
fwversion IBM,8247-22L
"""
    aix_hardware.module = MockModule()
    aix_hardware.module.run_command.return_value = 0, test_out_lsconf, ''
    lsconf_path = aix_hardware.module.get_bin_path("lsconf")

# Generated at 2022-06-22 22:55:59.065282
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    harwd = AIXHardware(module)


# Generated at 2022-06-22 22:56:01.564858
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    # Declare object of class AIXHardwareCollector()
    obj = AIXHardwareCollector()

    # Test value of _platform
    assert obj._platform == 'AIX'

    # Test value of _fact_class
    assert obj._fact_class == AIXHardware

# Generated at 2022-06-22 22:56:04.140622
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    test_hardware = AIXHardware()
    assert test_hardware is not None

# Generated at 2022-06-22 22:56:11.469258
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = Mock()
    module.run_command.return_value = (0, "memory pages:  1542677\nfree pages:      19379", "")
    aix = AIXHardware(module)

    facts = aix.get_memory_facts()
    assert facts['memtotal_mb'] == 60569
    assert facts['memfree_mb'] == 75
    assert facts['swaptotal_mb'] == 0


# Generated at 2022-06-22 22:56:15.280872
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)

    # Test with the output of vmstat command
    if hardware.module.check_mode:
        hardware.module.exit_json()
    hardware.get_memory_facts()



# Generated at 2022-06-22 22:56:27.245752
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    HW = AIXHardware()
    HW.module = AnsibleModuleMock()
    HW.module.get_bin_path=get_bin_path_mock
    HW.module.run_command=run_command_mock

    ret = HW.get_device_facts()

# Generated at 2022-06-22 22:56:32.756855
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    m = AIXHardware()
    dmi_facts = m.get_dmi_facts()
    assert 'product_serial' in dmi_facts
    assert 'firmware_version' in dmi_facts
    assert 'lpar_info' in dmi_facts
    assert 'product_name' in dmi_facts

# Generated at 2022-06-22 22:56:35.493519
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware = AIXHardware({})
    assert hardware.platform == "AIX"
    assert hardware.VERSION == "1.0"
    assert hardware.collector == "AIXHardware"


# Generated at 2022-06-22 22:56:36.682225
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    AIXHardwareCollector()

# Generated at 2022-06-22 22:56:46.724079
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module_aix_hw = AIXHardware()
    out_cpu_facts = {'processor_count': 4, 'processor': "PowerPC_POWER7", 'processor_cores': 4}
    out_memory_facts = {'swaptotal_mb': 17171, 'swapfree_mb': 4781, 'memtotal_mb': 20479, 'memfree_mb': 15388}
    out_dmi_facts = {'firmware_version': '750 1', 'product_serial': '0123ABC', 'lpar_info': 'my_lpar', 'product_name': 'my_system'}

# Generated at 2022-06-22 22:56:54.128943
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    import mock
    module = mock.MagicMock()
    module.run_command = mock.MagicMock()
    module.get_bin_path = mock.MagicMock()
    module.get_bin_path.return_value = '/usr/sbin/mount'

# Generated at 2022-06-22 22:56:56.507704
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware = AIXHardwareCollector()
    assert hardware._platform == 'AIX'


# Generated at 2022-06-22 22:57:08.567766
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)


# Generated at 2022-06-22 22:57:18.644931
# Unit test for method get_vgs_facts of class AIXHardware

# Generated at 2022-06-22 22:57:22.584709
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    collectors = [(AIXHardwareCollector, 'aix')]
    collector_instances = []
    for (klass, platform) in collectors:
        collector_instances.append(klass())
        
test_AIXHardwareCollector()

# Generated at 2022-06-22 22:57:27.815246
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    cpu_facts = hardware.get_cpu_facts()

    assert cpu_facts['processor_cores'] == 4
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor'] == 'PowerPC_POWER8'


# Generated at 2022-06-22 22:57:29.896390
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    aix_hardware = AIXHardwareCollector("module")
    return aix_hardware.fetch_all()

# Generated at 2022-06-22 22:57:38.005310
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    aix_hardware = AIXHardware()
    test_data = {"mounts": [
      {
        "mount": "/",
        "device": "hd4",
        "fstype": "jfs2",
        "options": "rw,log=/dev/hd8",
        "time": "Mon Dec  4 01:17:51 2017"
      },
      {
        "mount": "/usr",
        "device": "hd2",
        "fstype": "jfs2",
        "options": "rw,log=/dev/hd8",
        "time": "Mon Dec  4 01:18:01 2017"
      }
    ]}
    test_output = aix_hardware.get_mount_facts()


# Generated at 2022-06-22 22:57:46.208908
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    from ansible.module_utils.facts.collector.aix import AIXHardware
    aix_facts = AIXHardware()

# Generated at 2022-06-22 22:57:55.025394
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = AIXHardware(module=module)
    vgs_facts = hardware.get_vgs_facts()
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs_facts['vgs']['realsyncvg'][0]['pv_name'] == 'hdisk74'
    assert vgs_facts['vgs']['testvg'][1]['pv_name'] == 'hdisk106'

# Generated at 2022-06-22 22:57:56.996177
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    m = AIXHardwareCollector()
    assert isinstance(m, AIXHardwareCollector)



# Generated at 2022-06-22 22:58:04.454161
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    out_lsattr_fwversion = 'system firmware level:IBM,8233-E8B'
    out_lsconf = """
System Model: IBM,8233-E8B
Machine Serial Number: 123456789
ROS Level and ID: IBM,8233-E8B: 1.15.4.0 (smp)
Machine Type: 8233
LPAR Info: 1 SEC
System's Firmware is: IBM,8233-E8B
"""

# Generated at 2022-06-22 22:58:14.872729
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    class ModuleMock:
        @staticmethod
        def get_bin_path(program, required=False):
            return program

        @staticmethod
        def run_command(cmd, use_unsafe_shell=False):
            if cmd[0] == '/usr/sbin/lsdev':
                return 0, '''
name1 Available 00-00
name2 Defined   01-02
name3 Defined   00-01
name4 Defined   00-05
name5 Error     00-06
name6 Defined   00-07
name7 Unavailable 00-08
                    ''', ''

# Generated at 2022-06-22 22:58:27.066365
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    """Method get_vgs_facts of class AIXHardware should return
    the correct list of vg and pv info.
    """
    class MockModule:
        def __init__(self):
            pass


# Generated at 2022-06-22 22:58:28.055299
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    assert AIXHardwareCollector._platform == 'AIX'
    assert AIXHardwareCollector._fact_class == AIXHardware


# Generated at 2022-06-22 22:58:37.298788
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    hardware_object = AIXHardware(dict())


# Generated at 2022-06-22 22:58:40.874441
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    assert AIXHardwareCollector.__doc__ is not None
    hw = AIXHardwareCollector()
    assert hw.get_facts() is not None

# Generated at 2022-06-22 22:58:52.542444
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    aix_hardware = AIXHardware({})
    out = """
        memory pages: 215097
        memory pages pinned: 0
        memory pages paging: 0
        memory pages VSZ: 0
        memory pages free: 155933
        memory pages reserved: 0
        memory pages minimum: 250
        memory pages largest: 53
        memory pages default: 512
        memory pages active: 51662
        memory pages inactive: 0
        memory pages in use: 51662
        memory pages free: 155933
        memory pages free largest: 1207
        memory pages free default: 205
        memory pages free smallest: 47"""
    memory_facts = aix_hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 2166
    assert memory_facts['memfree_mb'] == 1544
    # System have

# Generated at 2022-06-22 22:58:57.885189
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = MockModule()
    hardware_collector = AIXHardware(module)
    hardware_collector.get_cpu_facts()
    assert hardware_collector.facts['processor_count'] == 2
    assert hardware_collector.facts['processor_cores'] == 2
    assert hardware_collector.facts['processor'] == 'PowerPC_POWER8'



# Generated at 2022-06-22 22:58:59.435075
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware = AIXHardware({'module_setup': True})
    assert hardware is not None

# Generated at 2022-06-22 22:59:04.342002
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    aix_hardware_obj = AIXHardware(module)
    vgs_facts = aix_hardware_obj.get_vgs_facts()
    assert isinstance(vgs_facts, dict)


# Generated at 2022-06-22 22:59:06.641865
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hw = AIXHardware(None)
    assert hw is not None
    assert hw.platform == 'AIX'

# Generated at 2022-06-22 22:59:13.193268
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    # Inject our fake command functions:
    setattr(module, 'run_command', _command_fake)

    hardware = AIXHardware(module)

    assert hardware.get_memory_facts()['memtotal_mb'] == 12658
    assert hardware.get_memory_facts()['memfree_mb'] == 4896


# Generated at 2022-06-22 22:59:23.964114
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec=dict())

    # mock module object
    setattr(module, 'get_bin_path', lambda *args, **kwargs: '/usr/bin')

    # mock module.run_command()
    class RunCommandMock():
        def __init__(self, *args, **kwargs):
            self.rc = 0
            self.cmd = args[0]

        def __call__(self, *args, **kwargs):
            if self.cmd == '/usr/bin/lsdev':
                self.out = test_AIXHardware_get_device_facts_lsdev.split('\n')
            elif self.cmd == ['/usr/bin/lsattr', '-E', '-l', 'hacmp.perf']:
                self.out = test_AIXHardware

# Generated at 2022-06-22 22:59:26.470574
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    aix_hw = AIXHardware(dict())
    assert aix_hw.platform == 'AIX'
    assert aix_hw.collector == 'AIXHardware'

# Generated at 2022-06-22 22:59:33.757918
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    import os
    import tempfile
    module_args = dict(
        gather_subset='all'
    )
    module_name = 'setup'
    module_path = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'hacking', 'test_module.py')
    tmp_dir = tempfile.gettempdir()
    test_ansible_module = os.path.join(tmp_dir, 'ansible_module_' + module_name)

    with open(test_ansible_module, 'w') as f:
        f.write('#!/usr/bin/python\n')
        f.write('import sys\n')
        f.write('from ansible.module_utils.basic import *\n')
        f.write('try:\n')

# Generated at 2022-06-22 22:59:45.126926
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    lsdev_cmd = 'lsdev'
    lsattr_cmd = 'lsattr'

# Generated at 2022-06-22 22:59:55.336347
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.hardware import Hardware
    from ansible.module_utils.facts.hardware.base import HardwareCollector
    from ansible.module_utils.facts.utils import get_file_content

    module = ModuleFacts(
        dict(
            ANSIBLE_MODULE_ARGS=dict(gather_subset=['all'])
        )
    )

    hardware = AIXHardware(module)
    # Create cpu_facts as a dict, with output of 'lsdev -Cc processor'

# Generated at 2022-06-22 23:00:06.138914
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module=module)
    device_facts = hardware.get_device_facts()
    assert 'devices' in device_facts
    assert 'ent0' in device_facts['devices']
    assert len(device_facts['devices']['ent0']) == 3
    assert 'attributes' in device_facts['devices']['ent0']
    assert 'media' in device_facts['devices']['ent0']['attributes']
    assert 'state' in device_facts['devices']['ent0']
    assert device_facts['devices']['ent0']['state'] == 'Available'
    assert 'type' in device_facts['devices']['ent0']
    assert device_facts['devices']['ent0']['type']

# Generated at 2022-06-22 23:00:13.709409
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts.utils import mock_module
    from ansible.module_utils._text import to_bytes

    aix_hardware = AIXHardware()
    # Mock m module that is used in AnsibleModule
    test_module = mock_module(name='aix_facts')
    # Mock AnsibleModule and attach mocked m module to it
    test_ansible_module = mock_module(module_args='', module=test_module)
    # create FactsCollector and attach it to mocked AnsibleModule

# Generated at 2022-06-22 23:00:22.347254
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hdwr = AIXHardware(module)
    hdwr_facts = hdwr.populate()

    assert hdwr_facts['firmware_version'] == '12.1.6.0'
    assert hdwr_facts['product_serial'] == '01E1EB'
    assert hdwr_facts['lpar_info'] == '01EE2C53'
    assert hdwr_facts['product_name'] == 'p520'

    assert hdwr_facts['processor_cores'] == 4
    assert hdwr_facts['processor'] == 'PowerPC_POWER8'
    assert hdwr_facts['processor_count'] == 1

    assert hdwr_facts['memtotal_mb'] == 8192
    assert hdwr_

# Generated at 2022-06-22 23:00:26.253179
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware_collector = AIXHardwareCollector(module=module)
    hardware = hardware_collector.collect()[0]
    assert hardware.get_cpu_facts()


# Generated at 2022-06-22 23:00:28.773089
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    x = AIXHardwareCollector()
    assert x._platform == 'AIX'
    assert issubclass(x._fact_class, AIXHardware)

# Generated at 2022-06-22 23:00:40.361496
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    m = AIXHardware({})

# Generated at 2022-06-22 23:00:44.163554
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    aix_inst = AIXHardwareCollector()
    assert aix_inst._platform == "AIX"
    assert aix_inst._fact_class == AIXHardware

# Generated at 2022-06-22 23:00:47.330803
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={})

    # Test for AIXHardware() with empty argument {}
    obj_empty_args = AIXHardware(module)
    # Test for AIXHardware() with valid argument {'module': <ansible.module_utils.basic.AnsibleModule object>}
    obj_valid_args = AIXHardware(module)

    # Test for default values of argument passed to AIXHardware()
    assert obj_empty_args.module == obj_valid_args.module

# Generated at 2022-06-22 23:00:55.233206
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.hardware import AIXHardware
    from ansible.module_utils.facts.utils import FactsParseException

    ah = AIXHardware()
    facts = ah.get_dmi_facts()
    mf = ModuleFacts(aix_lsattr_out=LSATTR_OUT, aix_lsconf_out=LSCONF_OUT, aix_lsdev_out=LSDEV_OUT, aix_mount_out=MOUNT_OUT)
    ah.module = mf

    facts = ah.get_dmi_facts()
    assert facts['firmware_version'] == '7.1.0.8'
    assert facts['product_name'] == 'IBM,8286-42A'

# Generated at 2022-06-22 23:01:00.419353
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = AIXHardware(module=module)
    cpu_facts = hardware.get_cpu_facts()
    for key in ['processor_count', 'processor', 'processor_cores']:
        assert key in cpu_facts


# Generated at 2022-06-22 23:01:12.136522
# Unit test for method get_memory_facts of class AIXHardware

# Generated at 2022-06-22 23:01:21.156583
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    ah = AIXHardware()
    dmi_facts = ah.get_dmi_facts()
    assert dmi_facts['firmware_version'] == "1.6.0.0"
    assert dmi_facts['product_serial'] == "0123456789"
    assert dmi_facts['lpar_info'] == "10b0a00b1abc"
    assert dmi_facts['product_name'] == "IBM,8231-E2B"

# Generated at 2022-06-22 23:01:23.148488
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware

    AIXHardware.get_cpu_facts("")

# Generated at 2022-06-22 23:01:35.887352
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():

    # test with no swap
    class MockModule:
        def __init__(self):
            self.exit_json = lambda *args, **kwargs: None

        def run_command(self, cmd, use_unsafe_shell=False):
            out = """memory pages:                            8192
            free pages:                                 8001
            pin:                                       0
            pin percent:                               0%
            xpin:                                      0
            xpin percent:                              0%
            Virtual Memory:
            VM segments:                               4
            VM segments used:                          2
            VM pages:                                  524288
            VM pages used:                             18746
            VM percent used:                           3%
            physical memory:                           8192MB
            KBytes used:                               28192KB
            percent used:                              2%"""
            rc

# Generated at 2022-06-22 23:01:38.174042
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    collector = AIXHardwareCollector()
    assert(collector._platform == 'AIX')
    assert(collector._fact_class == AIXHardware)

# Generated at 2022-06-22 23:01:42.539767
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    module = DummyAnsibleModule()
    hardware_collector = AIXHardwareCollector(module=module)
    assert hardware_collector._platform == 'AIX'
    assert hardware_collector._fact_class == AIXHardware


# Generated at 2022-06-22 23:01:48.748149
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hp = AIXHardware()
    assert hp.populate()['processor_count'] == 2
    assert hp.populate()['processor'][0] == 'PowerPC_POWER4'
    assert hp.populate()['memtotal_mb'] == 8192
    assert hp.populate()['memfree_mb'] == 3243
    assert hp.populate()['swaptotal_mb'] == 31744
    assert hp.populate()['swapfree_mb'] == 30906



# Generated at 2022-06-22 23:01:54.353722
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    class AnsibleModule(object):
        def __init__(self):
            self.run_command = mock.MagicMock()
            self.run_command.return_value = 0, '', ''
            self.get_bin_path = mock.MagicMock()
            self.get_bin_path.return_value = True;

    aix_hardware_collector = AIXHardwareCollector(AnsibleModule)

# Generated at 2022-06-22 23:01:57.047740
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    """
    Test the constructor of the AIXHardware class.
    """
    aix_hardware = AIXHardware()

    assert aix_hardware.platform == 'AIX'

# Generated at 2022-06-22 23:01:59.442888
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hw = AIXHardware()
    assert hw.platform == 'AIX'



# Generated at 2022-06-22 23:02:05.634229
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = FakeAnsibleModule()
    hardware = AIXHardware(module)

# Generated at 2022-06-22 23:02:14.362078
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    import unittest
    import sys
    import os
    import platform

    class TestAIXHardwareCollector(unittest.TestCase):
        def setUp(self):
            if platform.system() != 'AIX':
                self.skipTest('TestAIXHardwareCollector runs only on AIX')
            self.h = AIXHardwareCollector()

        def test_get_platform(self):
            self.assertEqual('AIX', self.h.platform)

        def test_get_fact_class(self):
            self.assertEqual(AIXHardware, self.h.fact_class)

        def test_get_fact_dir_path(self):
            abspath = os.path.dirname(os.path.abspath(__file__))

# Generated at 2022-06-22 23:02:15.693079
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    collector = AIXHardwareCollector()
    assert collector
    assert collector._platform == 'AIX'
    assert collector._fact_class == AIXHardware

# Generated at 2022-06-22 23:02:26.177479
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import DummyModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils import basic


# Generated at 2022-06-22 23:02:37.078064
# Unit test for method get_mount_facts of class AIXHardware

# Generated at 2022-06-22 23:02:45.226773
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    hardware = AIXHardware()
    hardware.module = MagicMock()

    # Non rootvg
    hardware.module.run_command.return_value = (0, "", "")
    assert hardware.get_dmi_facts() == {}

    # rootvg
    hardware.module.run_command.return_value = (0, "value value value", "")
    assert hardware.get_dmi_facts() == {}

    # rootvg
    hardware.module.run_command.return_value = (0, "IBM,value value value", "")
    assert hardware.get_dmi_facts() == {'firmware_version': 'value'}

# Generated at 2022-06-22 23:02:54.638622
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(
        argument_spec=dict(
            filter=dict(default=None, type='list')
        )
    )
    set_module_args(dict(
        filter=['devices']
    ))
    ahw = AIXHardware(module)
    facts = ahw.populate()

    assert facts['devices']['ent0']['state'] == 'Available'
    assert facts['devices']['ent0']['type'] == '10/100 Mbps Ethernet PCI Adapter (14106902)'
    assert facts['devices']['ent0']['attributes']['mtu_bypass_en'] == 'yes'
    assert facts['devices']['ent0']['attributes']['device_smbus_en'] == 'no'

# Generated at 2022-06-22 23:03:02.213751
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    from ansible_collections.community.general.tests.unit.compat.mock import patch
    from ansible_collections.community.general.plugins.modules import aix_hardware
    import sys
    sys.modules['__main__'] = aix_hardware

    class Object(object):
        pass

    module = Object()
    module.run_command = patch('ansible_collections.community.general.plugins.modules.aix_hardware.AIXHardware.run_command')
    module.run_command.return_value = (0, 'memory pages :  16384\nmemory\nfree pages :   9200', '')
    hardware = AIXHardware(module)

# Generated at 2022-06-22 23:03:15.005605
# Unit test for method get_mount_facts of class AIXHardware

# Generated at 2022-06-22 23:03:23.278840
# Unit test for method get_cpu_facts of class AIXHardware

# Generated at 2022-06-22 23:03:33.810174
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModuleMock()
    hw = AIXHardware(module)
    hw.populate()
    assert hw.cpu() == dict(
        processor_count=2,
        processor=['PowerPC_POWER8'],
        processor_cores=10)

    assert hw.memory() == dict(
        memtotal_mb=3924,
        memfree_mb=1587,
        swapfree_mb=0,
        swaptotal_mb=0)

    assert hw.dmi() == dict(
        firmware_version='8.0',
        product_serial=None,
        lpar_info=None,
        product_name=None)


# Generated at 2022-06-22 23:03:36.562500
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={})
    hardware_collector = AIXHardware(module)
    assert hardware_collector.platform == 'AIX'

# Generated at 2022-06-22 23:03:45.422233
# Unit test for method get_mount_facts of class AIXHardware