

# Generated at 2022-06-22 22:53:55.740198
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    """
    Test for method ``get_vgs_facts`` of class ``AIXHardware``
    """
    # Test data
    # ls -o | xargs lsvg -p

# Generated at 2022-06-22 22:53:58.731710
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    module = AnsibleModule(argument_spec={})
    hc = AIXHardwareCollector(module=module)
    assert hc is not None

# Generated at 2022-06-22 22:54:10.273640
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module_mock = AnsibleModuleMock()
    hardware = AIXHardware(module_mock)

    rc, out, err = module_mock.run_command.return_value
    assert rc == 0
    assert out == "test_out"
    assert err == "test_err"

    assert len(module_mock.run_command.call_args_list) == 7
    assert module_mock.run_command.call_args_list[0][0][0] == "/usr/sbin/lsdev -Cc processor"
    assert module_mock.run_command.call_args_list[1][0][0] == "/usr/sbin/lsattr -El proc0 -a type"

# Generated at 2022-06-22 22:54:20.577143
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = MockModule()
    mock_lsdev = [
            'proc0 Available 00-00 Processor',
            'proc1 Available 00-01 Processor',
            'proc2 Available 00-02 Processor']

    mock_lsattr = [
            'type PowerPC_POWER5',
            'smt_threads 2']

    module.run_commands.append(mock_lsdev)
    module.run_commands.append(mock_lsattr)

    ah = AIXHardware(module)
    cpu_facts = ah.get_cpu_facts()

    assert cpu_facts['processor_count'] == 3
    assert cpu_facts['processor'] == 'PowerPC_POWER5'
    assert cpu_facts['processor_cores'] == 2


# Generated at 2022-06-22 22:54:25.688527
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    class MockModule:
        pass

    mock_module = MockModule()
    mock_module.run_command = MagicMock()
    mock_module.run_command.return_value = (0, '481748 memory pages\n481748 free pages', '')
    aix_hw = AIXHardware(mock_module)
    ret = aix_hw.get_memory_facts()
    assert ret['memtotal_mb'] == 481748 * 4 * 1024 / 1024 / 1024
    assert ret['memfree_mb'] == 481748 * 4 * 1024 / 1024 / 1024
    mock_module.run_command.return_value = (0, '',
                                            'vmstat: Not enough valid adapters configured to run command')
    ret = aix_hw.get_memory_facts()
    assert ret == {}


#

# Generated at 2022-06-22 22:54:27.851529
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hw = AIXHardware({'module_setup': True})
    assert hw.platform == 'AIX'

# Generated at 2022-06-22 22:54:39.483491
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )


# Generated at 2022-06-22 22:54:52.138848
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)

    # Test method populate of class AIXHardware
    hardware.populate()
    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['processor'] == 'PowerPC_POWER8'
    assert hardware.facts['memtotal_mb'] == 3418788
    assert hardware.facts['memfree_mb'] == 143886
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['vgs']['rootvg'] == []

# Generated at 2022-06-22 22:55:00.061315
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module_mock = AnsibleModuleMock()
    module_mock.get_bin_path.return_value = '/usr/bin/mount'
    module_mock.run_command.return_value = 0, '', ''

# Generated at 2022-06-22 22:55:06.822863
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = AIXHardware(module)
    rc, out, err = module.run_command("/usr/sbin/lsdev -Cc processor")
    i = 0
    for line in out.splitlines():
        if 'Available' in line:
            if i == 0:
                data = line.split(' ')
                cpudev = data[0]
            i += 1
    cpu_count = int(i)

    if cpu_count > 1:
        rc, out, err = module.run_command("/usr/sbin/lsattr -El " + cpudev + " -a smt_threads")
        if out:
            data = out.split(' ')
            cpu_count = cpu_count * int(data[1])

    rc

# Generated at 2022-06-22 22:55:16.708890
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    m = AIXHardware({'module_setup': True})

# Generated at 2022-06-22 22:55:17.439439
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    pass

# Generated at 2022-06-22 22:55:21.753763
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    facts = hardware.get_dmi_facts()

    assert facts is not None


# Generated at 2022-06-22 22:55:25.766384
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    class ModuleMock(object):

        @staticmethod
        def get_bin_path(cmd, required=False):
            cmds = {
                'lsconf': '/usr/sbin/lsconf',
                'lsvg': '/usr/sbin/lsvg',
                'lsattr': '/usr/sbin/lsattr'
            }
            return cmds[cmd]

        @staticmethod
        def run_command(cmd, use_unsafe_shell=False):
            out = """
Device                Device Type  Reg
=======================================
sys0                  System
  SerialNumber          892                 0
  MachineType            9124-52A            0

"""
            return 0, out, 0


# Generated at 2022-06-22 22:55:30.659527
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    facts_obj = AIXHardware(module)
    res = facts_obj.get_memory_facts()
    assert res['memtotal_mb'] > 0
    assert res['memfree_mb'] > 0
    assert res['swaptotal_mb'] >= 0
    assert res['swapfree_mb'] >= 0


# Generated at 2022-06-22 22:55:40.344620
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    test_string = """
rootvg:
PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
hdisk0            active            546         0           00..00..00..00..00
hdisk1            active            546         113         00..00..00..21..92
realsyncvg:
PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
hdisk74           active            1999        6           00..00..00..00..06
testvg:
PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
hdisk105          active            999         838         200..39..199..200..200
hdisk106          active            999         599         200..00..00..199..200"""
    ah = AIXHardware()

    v

# Generated at 2022-06-22 22:55:41.407536
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    assert issubclass(AIXHardwareCollector, HardwareCollector)

# Generated at 2022-06-22 22:55:42.855157
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    aix_hw = AIXHardware()
    assert aix_hw



# Generated at 2022-06-22 22:55:45.629236
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    test_obj = AIXHardware()
    test_obj.lsconf_path = "./lsconf"
    assert test_obj.get_dmi_facts() == {
        'firmware_version': 'IBM,8233-E8B',
        'product_serial': '0216037094',
        'product_name': 'IBM,8233-E8B',
        'lpar_info': 'vios_lpar2'}


# Generated at 2022-06-22 22:55:47.082300
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    o = AIXHardwareCollector()
    assert o.platform == 'AIX'

# Generated at 2022-06-22 22:55:56.242089
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    x = AIXHardware(None, None)

    m = x.get_cpu_facts()
    assert isinstance(m['processor'], str)
    assert isinstance(m['processor_cores'], int)
    assert isinstance(m['processor_count'], int)

    m = x.get_device_facts()
    assert isinstance(m['devices'], dict)
    for key in m['devices']:
        assert isinstance(m['devices'][key]['state'], str)
        assert isinstance(m['devices'][key]['type'], str)
        assert isinstance(m['devices'][key]['attributes'], dict)

    m = x.get_mount_facts()
    assert isinstance(m['mounts'], list)

# Generated at 2022-06-22 22:56:01.368348
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    # create class object
    hardware_obj = AIXHardware()
    # create variable in which the output of method get_cpu_facts will be stored
    cpu_facts = hardware_obj.get_cpu_facts()
    # test that variable processor_count contains correct value
    assert cpu_facts['processor_count'] == 2


# Generated at 2022-06-22 22:56:07.465983
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware_info = AIXHardware(module)
    cpu_facts = hardware_info.get_cpu_facts()
    assert cpu_facts['processor']
    assert cpu_facts['processor_count']
    assert cpu_facts['processor_cores']


# Generated at 2022-06-22 22:56:12.867063
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(
        argument_spec = dict()
    )

    # Populate the module with dummy arguments/values
    module.params = {}

    aix_mock = AIXHardware(module)
    aix_mock.get_mount_facts()



# Generated at 2022-06-22 22:56:25.084972
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    import platform

    facts = {'machine': platform.machine(),
             'architecture': platform.architecture(),
             'system': platform.system(),
             'distribution': platform.dist(),
             'distribution_version': platform.dist()[1],
             'distribution_major_version': platform.dist()[1].split('.')[0],
             'distribution_release': platform.dist()[2],
             'kernel': platform.release(),
             }


# Generated at 2022-06-22 22:56:31.969886
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    import socket
    import json
    import os
    import sys
    # hack to make sure we use module_utils from our ansible checkout
    # and ignore system installed version of module_utils
    module_utils_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), '../module_utils')
    if module_utils_path not in sys.path:
        sys.path.insert(0, module_utils_path)
    from module_utils.facts.hardware.aix import AIXHardware

    ah = AIXHardware(dict(module=dict(params={'gather_subset': ['all']})))
    ah.populate()
    facts = ah.get_facts()
    print(json.dumps(facts, indent=4))

# Generated at 2022-06-22 22:56:34.091197
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    AIXHardwareCollector()

# Generated at 2022-06-22 22:56:37.675224
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    """
    Constructor test for class AIXHardwareCollector
    """
    collector = AIXHardwareCollector()
    assert collector.platform == 'AIX'
    assert collector.fact_class == AIXHardware

# Generated at 2022-06-22 22:56:41.393663
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
    )
    set_module_args(dict())
    hardware = AIXHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['firmware_version'] == 'N/A'

# Generated at 2022-06-22 22:56:50.418113
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    """
    Unit test for method get_vgs_facts of class AIXHardware
    :return:
    """

    aix_hw_obj = AIXHardware()
    vgs_facts = aix_hw_obj.get_vgs_facts()
    assert vgs_facts is not None, 'Expected vgs_facts obtained is not None'

    assert 'vgs' in vgs_facts, 'Expected vgs_facts to have vgs'
    assert vgs_facts['vgs'] is not None, 'Expected vgs_facts obtained is not None'
    assert 'rootvg' in vgs_facts['vgs'], 'Expected vgs_facts to have rootvg'
    assert vgs_facts['vgs']['rootvg'] is not None, 'Expected vgs_facts obtained is not None'
   

# Generated at 2022-06-22 22:57:00.630537
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    hw = AIXHardware()
    hw.module.run_command = lambda x: (0, 'lsdev_out', '')
    hw.module.get_bin_path = lambda x: 'lsdev'

    facts = hw.populate()

    assert 'processor_count' in facts
    assert 'processor_cores' in facts
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'firmware_version' in facts
    assert 'product_serial' in facts
    assert 'lpar_info' in facts
    assert 'product_name' in facts
    assert 'vgs' in facts
    assert 'mounts' in facts
    assert 'devices' in facts

# Generated at 2022-06-22 22:57:12.321862
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    fake_lsvg_patcher = mock.patch('ansible.module_utils.facts.hardware.aix.AIXHardware.module.get_bin_path')
    fake_lsvg = fake_lsvg_patcher.start()
    fake_lsvg.return_value = '/usr/sbin/lsvg'
    fake_xargs_patcher = mock.patch('ansible.module_utils.facts.hardware.aix.AIXHardware.module.get_bin_path')
    fake_xargs = fake_xargs_patcher.start()
    fake_xargs.return_value = '/usr/bin/xargs'
    fake_run_command_patcher = mock.patch('ansible.module_utils.facts.hardware.aix.AIXHardware.module.run_command')
    fake_run

# Generated at 2022-06-22 22:57:20.686946
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    """
    AIXHardware.get_mount_facts() Test
    """

    mock = AIXHardware(dict(module=dict()))
    mock.module.run_command = lambda *args, **kwargs: (0, mount_out, '')


# Generated at 2022-06-22 22:57:31.861782
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    """ Unit test for method get_vgs_facts of class AIXHardware """
    aix_hardware = AIXHardware()

# Generated at 2022-06-22 22:57:33.497427
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={})

    hardware = AIXHardware(module)

    assert hardware.module is module

# Generated at 2022-06-22 22:57:43.183546
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModuleMock({})
    hardware_obj = AIXHardware(module)
    module.run_command.return_value = (0, 'test', '')

    hardware_obj.populate()

    assert 'firmware_version' in hardware_obj.facts
    assert 'product_serial' in hardware_obj.facts
    assert 'lpar_info' in hardware_obj.facts
    assert 'product_name' in hardware_obj.facts
    assert 'processor_count' in hardware_obj.facts
    assert 'processor_cores' in hardware_obj.facts
    assert 'processor' in hardware_obj.facts
    assert 'memtotal_mb' in hardware_obj.facts
    assert 'memfree_mb' in hardware_obj.facts
    assert 'swaptotal_mb' in hardware_obj.facts
   

# Generated at 2022-06-22 22:57:49.435312
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    hardware = AIXHardware({})
    hardware_info = hardware.get_cpu_facts()

    assert isinstance(hardware_info['processor_count'], int)
    assert isinstance(hardware_info['processor'], str)
    assert isinstance(hardware_info['processor_cores'], int)


# Generated at 2022-06-22 22:58:00.298866
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    device_info = []
    mount_info = {'mount': '/', 'options': 'rw,log=/dev/log', 'fstype': 'jfs2', 'device': '/dev/hd4', 'time': 'Tue Sep 27 13:12:16 2016'}
    device_info.append(mount_info)
    mount_info = {'mount': '/usr', 'options': 'rw', 'fstype': 'jfs2', 'device': '/dev/hd2', 'time': 'Tue Sep 27 13:12:16 2016'}
    device_info.append(mount_info)

# Generated at 2022-06-22 22:58:12.010166
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = FakeANSIModule()
    aix_hw = AIXHardware(module)
    cmd = "lsvg -o | xargs lsvg -p"

# Generated at 2022-06-22 22:58:24.773031
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware

# Generated at 2022-06-22 22:58:28.382412
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    """
    Unit test for constructor of class AIXHardwareCollector
    """
    collector = AIXHardwareCollector()
    assert collector.platform == 'AIX'
    assert collector.fact_class == AIXHardware


# Generated at 2022-06-22 22:58:35.496406
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    hw = AIXHardware()
    hw.populate(None)
    facts = hw.get_facts()

    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'processor' in facts
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'devices' in facts
    assert 'mounts' in facts
    assert 'vgs' in facts


# Generated at 2022-06-22 22:58:48.184955
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils._text import to_bytes

    module = AnsibleModule(
        argument_spec={
            'gather_subset': dict(default=[], type='list'),
            'filter': dict(default='*', type='str'),
        },
        supports_check_mode=True
    )

    ah = AIXHardware(module)
    ah.populate()

    facts = {}
    get_file_content('sys0.lsattr', dict_type=facts)
    get_file_content('sys0.lsdev_Cc_processor', dict_type=facts)

# Generated at 2022-06-22 22:58:59.392959
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    module.run_command = MagicMock(return_value=(0,
                                                 "memory pages:  89531\n"
                                                 "free pages:    86423\n",
                                                 ""))
    aix_hardware = AIXHardware(module)
    memory_facts = aix_hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 35656
    assert memory_facts['memfree_mb'] == 34108
    assert memory_facts['swaptotal_mb'] == 0


# Generated at 2022-06-22 22:59:06.763907
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModuleMock()
    hardware = AIXHardware(module)
    lsdev_command = "lsdev -Cc processor"
    lsattr_command = "lsattr -El sys0 -a fwversion"
    lsps_command = "lsps -s"
    lsvg_command = "lsvg -o | xargs lsvg -p"
    mount_command = "mount"
    fact_data = FactData()

    fact_data.add_command_output(lsdev_command, 'proc0 Available 00-00 Processor')
    fact_data.add_command_output(lsdev_command, 'proc1 Available 00-00 Processor')
    fact_data.add_command_output(lsattr_command, 'fwversion 0 IBM,8247-22L')
    fact_data.add_command_output

# Generated at 2022-06-22 22:59:10.269707
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    aix_hw = AIXHardware()
    cpu_facts = aix_hw.get_cpu_facts()
    assert cpu_facts['processor_count']
    assert cpu_facts['processor']


# Generated at 2022-06-22 22:59:17.775099
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={})
    hw = AIXHardware(module=module)
    facts = hw.populate()
    assert 'processor_count' in facts
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'firmware_version' in facts
    assert 'product_name' in facts
    assert 'product_serial' in facts
    assert 'lpar_info' in facts
    assert 'vgs' in facts
    assert 'mounts' in facts
    assert 'devices' in facts

from ansible.module_utils.basic import *


# Generated at 2022-06-22 22:59:24.207048
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    hardware = AIXHardware()

    hardware.module = Mock()
    hardware.module.run_command.return_value = (0, 'Here is output\nof memory pages:5000 \nof free pages:2000 \nof something:3', '')
    d = hardware.get_memory_facts()
    assert d['memtotal_mb'] == 25
    assert d['memfree_mb'] == 10
    assert d['swaptotal_mb'] == 0
    assert d['swapfree_mb'] == 0


# Generated at 2022-06-22 22:59:32.476883
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    class MockModule:
        class MockRunCommand:
            def __init__(self, return_code, stdout, err):
                self.return_code = return_code
                self.stdout = stdout
                self.err = err

            def run_command(self, cmd, check_rc=False):
                return self.return_code, self.stdout, self.err

        def __init__(self, memory_out, vmstat_out):
            self.run_command = self.MockRunCommand(0, vmstat_out, '')
            self.run_command.run_command = self.run_command.run_command
            self.run_command = self.MockRunCommand(0, memory_out, '')
            self.run_command.run_command = self.run_command.run_command



# Generated at 2022-06-22 22:59:36.960591
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    """
    This is a test method to test method get_memory_facts of class AIXHardware
    """
    import os
    import tempfile
    import shutil

    from ansible.module_utils.facts import Collector

    def create_tmp_dir(suffix='ansible-local-facts'):
        tmp_dir = tempfile.mkdtemp(suffix=suffix)
        return tmp_dir

    def create_temp_file(directory, data):
        tmp_file = tempfile.NamedTemporaryFile(delete=False, dir=directory)
        tmp_file.write(data)
        tmp_file.close()
        return tmp_file.name

    def remove_tmp_dir(tmp_dir):
        if os.path.exists(tmp_dir):
            shutil.rmtree(tmp_dir)

# Generated at 2022-06-22 22:59:40.512723
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] != 0
    assert memory_facts['memfree_mb'] != 0
    assert memory_facts['swaptotal_mb'] != 0
    assert memory_facts['swapfree_mb'] != 0



# Generated at 2022-06-22 22:59:52.442008
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = AIXHardware(module)
    mount_facts = hardware.get_mount_facts()

# Generated at 2022-06-22 23:00:02.895550
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    class Options:
        def __init__(self, path):
            self.module_path = path

    class Module:
        def __init__(self, options):
            self.options = options
            self.run_command_calls = []

        def get_bin_path(self, name, required=False, opt_dirs=[]):
            if name == 'mount':
                return './dummy_mount'
            else:
                return None

        def run_command(self, cmd, use_unsafe_shell=False):
            self.run_command_calls.append(cmd)
            return 0, "", ""

    # Test1: Expected result is a dictionary with a list of mount_info dictionary
    #        mount_info dictionary is filled with device, mount, fstype, options and time fields

# Generated at 2022-06-22 23:00:15.157550
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware = AIXHardware()

    assert hardware is not None

    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] is not None
    assert cpu_facts['processor_cores'] is not None
    assert cpu_facts['processor_count'] is not None

    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memfree_mb'] is not None
    assert memory_facts['memtotal_mb'] is not None
    assert memory_facts['swapfree_mb'] is not None
    assert memory_facts['swaptotal_mb'] is not None

    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['firmware_version'] is not None
    assert dmi_facts['product_serial'] is not None
    assert dmi_

# Generated at 2022-06-22 23:00:17.462911
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    mod = AnsibleModule(argument_spec={})
    AIXHardwareCollector = AIXHardwareCollector(module=mod)
    assert isinstance(AIXHardwareCollector, AIXHardwareCollector)


# Generated at 2022-06-22 23:00:21.396207
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})

    hardware = AIXHardware(module=module)

    hardware.populate()

    module.exit_json(changed=False, ansible_facts=module.params['ansible_facts'])

from ansible.module_utils.basic import AnsibleModule
if __name__ == '__main__':
    main()

# Generated at 2022-06-22 23:00:26.435028
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.hardware.aix import AIXHardware
    aixhardware = AIXHardware()
    for key, value in aixhardware.get_device_facts().items():
        print(key, value)

# Generated at 2022-06-22 23:00:38.574366
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)

# Generated at 2022-06-22 23:00:45.243234
# Unit test for method get_device_facts of class AIXHardware

# Generated at 2022-06-22 23:00:55.444367
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec={},
    )

    set_module_args(dict(
        _ansible_selection=dict(
            gather_subset=['all'],
        ),
        _ansible_check_mode=True,
    ))

    module_params = module.params
    obj = AIXHardware(module_params)
    obj.populate()
    # Test case 1: All available memory and swap
    obj.get_memory_facts()
    assert obj.memory_facts['memtotal_mb'] == 8192
    assert obj.memory_facts['memfree_mb'] == 8192
    assert obj.memory_facts['swaptotal_mb'] == 4194304
    assert obj.memory_facts['swapfree_mb'] == 4194304
    # Test case 2: Not all available memory

# Generated at 2022-06-22 23:00:59.264969
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={})
    hardware_obj = AIXHardware(module)
    if hardware_obj:
        print("AIXHardware object Created")
    else:
        print("AIXHardware object not created")

# Generated at 2022-06-22 23:01:06.064446
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware_collector = AIXHardwareCollector(module=module)
    hardware = AIXHardware(hardware_collector)
    cpu_facts = hardware.get_cpu_facts()

    assert cpu_facts['processor']
    assert cpu_facts['processor_count']
    assert cpu_facts['processor_cores']



# Generated at 2022-06-22 23:01:18.864848
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    """ test get_mount_facts method of class AIXHardware.
        Return values of method get_mount_facts are in the form :
        { 'mount': 'xxx', 'device': 'xxx', 'fstype': 'xxx', 'options': 'xxx' }
    """

    from io import StringIO

    # first case
    # populate mount_facts with one mount
    answer = ['/dev/hd1       /home                   jfs2        rw,log=/dev/hd8          Mar 28 12:25'
              '/dev/hd2       /                      jfs2        rw,log=/dev/hd8          Mar 28 12:25'
              '/dev/hd8       /tmp                    xfs         rw,inode64,logbsize=32768Mar 28 12:25']
    answer = '\n'.join(answer)

# Generated at 2022-06-22 23:01:29.415372
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = type('', (), {"run_command": fake_run_command})()
    hardware_fact_class = AIXHardware(module)

# Generated at 2022-06-22 23:01:40.899039
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )
    # Create dmidecode object
    ah = AIXHardware(module=module)

# Generated at 2022-06-22 23:01:47.993396
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    test_module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )
    test_AIXHardware = AIXHardware(test_module)
    test_AIXHardware.get_cpu_facts()
    assert test_AIXHardware.cpu['processor_count'] == 64
    assert test_AIXHardware.cpu['processor'] == 'PowerPC_POWER8'


# Generated at 2022-06-22 23:01:54.509876
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    """
    This function passes the output of the ls -o command to the AIXHardware get_vgs_facts method and
    tests the output.

    :return:
    """

# Generated at 2022-06-22 23:01:56.835890
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    aixhw = AIXHardware()
    assert aixhw.platform == 'AIX'


# unit test for populate method of class AIXHardware

# Generated at 2022-06-22 23:02:09.133970
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec=dict())
    hardware = AIXHardware(module)
    facts = hardware.populate()
    assert(facts['firmware_version'] == "IBM,810C855")
    assert(facts['product_serial'] == "06CD87A")
    assert(facts['product_name'] == "7012-F80")
    assert(facts['mounts'][0]['mount'] == "/")
    assert(facts['mounts'][0]['device'] == "/dev/hd4")
    assert(facts['mounts'][0]['fstype'] == "jfs2")
    assert(facts['mounts'][0]['options'] == "rw")
    assert(facts['mounts'][0]['size_total'] == 3065643008)

# Generated at 2022-06-22 23:02:17.196903
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    import unittest
    module = AnsibleModule(argument_spec={})

    hardware = AIXHardware(module)
    memory_facts = hardware.get_memory_facts()

    assert 'memtotal_mb' in memory_facts.keys()
    assert 'memfree_mb' in memory_facts.keys()
    assert 'swaptotal_mb' in memory_facts.keys()
    assert 'swapfree_mb' in memory_facts.keys()



# Generated at 2022-06-22 23:02:27.000998
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    # initialize module instance
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
    )

    # initialize aix hardware instance
    hw = AIXHardware(module)

    # populate aix hardware facts
    facts = hw.populate()

    assert 'ansible_facts' in facts
    assert 'hardware' in facts['ansible_facts']

    facts = facts['ansible_facts']

    assert 'processor' in facts['hardware']
    assert 'processor_cores' in facts['hardware']
    assert 'processor_count' in facts['hardware']
    assert 'memtotal_mb' in facts['hardware']
    assert 'memfree_mb' in facts['hardware']



# Generated at 2022-06-22 23:02:32.486391
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    """
    Constructor of AIXHardwareCollector should use a platform of 'AIX'
    and a fact class of AIXHardware.
    """
    facts_collector = AIXHardwareCollector()
    assert facts_collector._platform == 'AIX'
    assert facts_collector._fact_class == AIXHardware

# Generated at 2022-06-22 23:02:38.230279
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware_obj = AIXHardware(module)
    cpu_facts = hardware_obj.get_cpu_facts()
    assert cpu_facts['processor']
    assert cpu_facts['processor_cores']
    assert cpu_facts['processor_count']


# Generated at 2022-06-22 23:02:48.385463
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    if not HAS_AIX_UTILS:
        module.fail_json(msg="Looks like 'lsdev' command is not installed, please install it")
    if not module.run_command('lsdev'):
        module.fail_json(msg="Looks like 'lsdev' command is not installed, please install it")
    if not module.run_command('lslv'):
        module.fail_json(msg="Looks like 'lslv' command is not installed, please install it")

# Generated at 2022-06-22 23:02:57.782140
# Unit test for method get_device_facts of class AIXHardware

# Generated at 2022-06-22 23:03:04.507236
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    from ansible_collections.notmintest.not_a_real_collection.tests.unit.compat.mock import patch
    from ansible_collections.notmintest.not_a_real_collection.plugins.modules import aix_hardware

    with patch.object(aix_hardware.AnsibleModule, 'get_bin_path') as mock_get_bin_path:
        fake_module = aix_hardware.AnsibleModule(
            argument_spec={'module_name': {'type': 'str'}})
        fake_module.run_command = lambda *args, **kwargs: (0, 'lsvg_out', '')
        fake_module.run_command.return_value = (0, 'lsvg_out', '')

        mock_get_bin_path.return_value

# Generated at 2022-06-22 23:03:08.319554
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    """ This is  method to test the constructor of class AIXHardwareCollector """
    aix_hw_collector = AIXHardwareCollector()
    assert isinstance(aix_hw_collector, AIXHardwareCollector)

# Generated at 2022-06-22 23:03:09.188996
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    # Create an AIXHardwareCollector object
    AIXHardwareCollector()

# Generated at 2022-06-22 23:03:16.257017
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    hardware = AIXHardware()

# Generated at 2022-06-22 23:03:23.756270
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    vgs_facts = hardware.get_vgs_facts()
    assert 'vgs' in vgs_facts
    for group in vgs_facts['vgs'].values():
        for pv_info in group:
            assert 'pv_name' in pv_info
            assert 'pv_state' in pv_info
            assert 'total_pps' in pv_info
            assert 'free_pps' in pv_info
            assert 'pp_size' in pv_info


if __name__ == '__main__':
    from ansible.module_utils.basic import AnsibleModule
    test_AIXHardware_get_vgs_facts()

# Generated at 2022-06-22 23:03:27.095544
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    x = AIXHardwareCollector()
    assert x.platform == 'AIX'

    assert x.fact_class is not None
    assert x.fact_class.platform == 'AIX'

# Generated at 2022-06-22 23:03:35.031776
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['firmware_version'] == '1.8.5'
    assert dmi_facts['product_name'] == '8801-XXX'
    assert dmi_facts['product_serial'] == 'XXXXXXX'
    assert dmi_facts['lpar_info'] == 'UserPartition'

# Generated at 2022-06-22 23:03:38.461498
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    device_facts = AIXHardware.get_device_facts(dict())

    assert device_facts['devices']['fcs0']['attributes']['bus_io_addr'] == '0xFE020000'


# Generated at 2022-06-22 23:03:39.821263
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    h = AIXHardware()
    assert h.platform == 'AIX'

# Generated at 2022-06-22 23:03:52.705848
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    data = '''
    rootvg:
    PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
    hdisk0            active            546         0           00..00..00..00..00
    hdisk1            active            546         113         00..00..00..21..92
    realsyncvg:
    PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
    hdisk74           active            1999        6           00..00..00..00..06
    testvg:
    PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
    hdisk105          active            999         838         200..39..199..200..200
    hdisk106          active            999         599         200..00..00..199..200
    '''

