

# Generated at 2022-06-22 22:53:54.129939
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():

    class ModuleMock(object):
        def __init__(self, **kwargs):
            self.params = {'gather_subset': '!all,!min'}
            self.params.update(kwargs)

        def get_bin_path(self, arg, required=False):
            return arg

        def run_command(self, cmd):
            lsdev_output = ('mem0 Available 00-00 Memory\n'
                            'mem1 Available 00-01 Memory\n'
                            'mem2 Available 00-02 Memory\n'
                            'mem3 Available 00-03 Memory')
            lsattr_output = ('size_in_mb 32\n'
                             'num_bytes 0x20000000')
            if cmd[0] == 'lsattr':
                return (0, lsattr_output, '')


# Generated at 2022-06-22 22:54:06.387009
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    test_module = AnsibleModule(argument_spec={'fact_path': dict(required=True, type='path')},
                                supports_check_mode=False)
    test_module.params['fact_path'] = os.path.join(os.path.dirname(__file__), '../../../../../test/units/module_utils/facts/facts_d')
    if not os.path.exists(test_module.params['fact_path']):
        test_module.params['fact_path'] = os.path.join(os.path.dirname(__file__), '../../../../../../test/units/module_utils/facts/facts_d')

    hardware_collector = AIXHardwareCollector(test_module)
    hardware = hardware_collector.collect(None, test_module)

   

# Generated at 2022-06-22 22:54:15.602530
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    import re
    vgs_facts = {}
    test_output = 'rootvg: \nPV_NAME PV STATE TOTAL PPs FREE PPs FREE DISTRIBUTION \nhdisk0 active 546 0 00..00..00..00..00 \nhdisk1 active 546 113 00..00..00..21..92 \nrealsyncvg: \nPV_NAME PV STATE TOTAL PPs FREE PPs FREE DISTRIBUTION \nhdisk74 active 1999 6 00..00..00..00..06 \ntestvg: \nPV_NAME PV STATE TOTAL PPs FREE PPs FREE DISTRIBUTION \nhdisk105 active 999 838 200..39..199..200..200 \nhdisk106 active 999 599 200..00..00..199..200 '
    vgs = {}

# Generated at 2022-06-22 22:54:19.031395
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    test_obj = AIXHardware()
    test_obj.module = None
    test_method = test_obj.get_vgs_facts()
    assert isinstance(test_method, dict)

# Generated at 2022-06-22 22:54:25.577482
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModuleMock()
    hw = AIXHardware(module)
    vgs_facts = hw.get_vgs_facts()
    assert 'vgs' in vgs_facts
    assert 'rootvg' in vgs_facts['vgs']
    assert 'testvg' in vgs_facts['vgs']
    assert 'realsyncvg' in vgs_facts['vgs']


# Test for method get_dmi_facts of class AIXHardware

# Generated at 2022-06-22 22:54:33.658553
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule({})
    module.params = {}
    aixhardware = AIXHardware(module)
    actual_mem_facts = aixhardware.get_memory_facts()
    expected_mem_facts = {'memfree_mb': 512, 'swaptotal_mb': 2048, 'swapfree_mb': 1487, 'memtotal_mb': 2048}
    for key in actual_mem_facts.keys():
        assert actual_mem_facts[key] == expected_mem_facts[key]



# Generated at 2022-06-22 22:54:39.739121
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    m = AIXHardware(dict(module=dict(run_command=lambda *_, **__: (0, 'fake_rc, fake_out, fake_err'))))
    cpu_facts = m._get_cpu_facts()
    assert cpu_facts['processor'] == 'fake_out'
    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor_count'] == 1

# Generated at 2022-06-22 22:54:52.286860
# Unit test for method get_dmi_facts of class AIXHardware

# Generated at 2022-06-22 22:54:57.324002
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModuleMock()
    module.run_command = run_command
    module.get_bin_path = get_bin_path
    aix_hw = AIXHardware(module)
    # get_device_facts not implemented on aix 7, so test it on aix 6.1
    platform_version = 6.1
    device_facts = aix_hw.get_device_facts()

# Generated at 2022-06-22 22:55:10.047094
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    module = basic.AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    # For testing purposes, create the class object
    # in the module namespace
    module.AIXHardware = AIXHardware

    # For testing purposes, enable the lsconf command
    # by stubbing it out with the module namespace
    module.get_bin_path = lambda name, required=False: os.path.dirname(__file__) + "/fixtures/lsconf"

    # Run the get_dmi_facts method on the module object
    result = module.AIXHardware.get_dmi_facts()

    assert "firmware_version" in result

# Generated at 2022-06-22 22:55:17.021922
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    hardware = AIXHardware()
    hardware.get_device_facts()

    # Check for specific device
    for device_name, device in hardware.devices.items():
        if device_name == 'ent0':
            assert device['state']
            assert device['type']
            assert device['attributes']
            break

# Generated at 2022-06-22 22:55:24.927067
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    test_module = AnsibleModule(argument_spec={})
    test_module.run_command = Mock(return_value=(0, '', ''))
    test_module._ansible_version = MagicMock(return_value='magic value')
    test_module.get_bin_path = Mock(return_value='/usr/bin/')
    get_device_facts = AIXHardware(test_module).get_device_facts()

    assert get_device_facts['devices'] == {}

# Generated at 2022-06-22 22:55:34.771129
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    from ansible.module_utils.facts.hardware.aix import AIXHardware

    # Test constructor of AIXHardware
    aix_hardware = AIXHardware()

    assert AIXHardware.platform == 'AIX', \
        "platform of AIXHardware should be 'AIX'"

    assert aix_hardware._platform == 'AIX', \
        "_platform of AIXHardware should be 'AIX'"

    aix_hardware_collector = AIXHardwareCollector()
    assert AIXHardwareCollector._platform == 'AIX', \
        "_platform of AIXHardwareCollector should be 'AIX'"
    assert AIXHardwareCollector._fact_class.__name__ == 'AIXHardware', \
        "_fact_class of AIXHardwareCollector should be AIXHardware"

    fact_list = aix_hard

# Generated at 2022-06-22 22:55:38.521482
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    hw = AIXHardware({})
    hw.module = MockModule()
    hw.module.run_command = Mock(return_value=(0, 'IBM,7044-270', ""))
    assert hw.get_dmi_facts() == {'firmware_version': '7044-270'}

# Generated at 2022-06-22 22:55:49.007869
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():

    # Test populate method of AIXHardware
    hardware = AIXHardware()

    hardware.module = AnsibleModule(argument_spec={})
    hardware.module.run_command = lambda *args, **kwargs: (0, '', '')

    hardware_facts = hardware.populate()

    # test for cpu facts
    assert hardware_facts['processor_cores'] == 1
    assert hardware_facts['processor_count'] == 1
    assert hardware_facts['processor'] == 'PowerPC_POWER8'

    # test for memory facts
    assert hardware_facts['memtotal_mb'] >= 0
    assert hardware_facts['memfree_mb'] >= 0
    assert hardware_facts['swaptotal_mb'] >= 0
    assert hardware_facts['swapfree_mb'] >= 0

    # test for dmi facts
    assert hardware_facts

# Generated at 2022-06-22 22:55:55.401639
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    hw = AIXHardware()
    hw.module = MockModule({})
    hw.populate()
    assert hw.facts['processor'] == ['PowerPC_POWER6']
    assert hw.facts['processor_count'] == 4
    assert hw.facts['processor_cores'] == 2
    assert hw.facts['memtotal_mb'] == 8352
    assert hw.facts['memfree_mb'] == 8352
    assert hw.facts['swaptotal_mb'] == 0
    assert hw.facts['swapfree_mb'] == 0

# Generated at 2022-06-22 22:56:05.709573
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = dict()
    module.update({'run_command.return_value': (0, "", "")})

    aix_hw = AIXHardware(module)

    aix_hw.get_memory_facts = MagicMock(name='get_memory_facts')
    aix_hw.get_memory_facts.return_value = {'memtotal_mb': 16, 'memfree_mb': 12}
    aix_hw.get_cpu_facts = MagicMock(name='get_cpu_facts')
    aix_hw.get_cpu_facts.return_value = {'processor': 'PowerPC_POWER8'}
    aix_hw.get_dmi_facts = MagicMock(name='get_dmi_facts')
    aix_hw.get_dmi_facts.return_value

# Generated at 2022-06-22 22:56:16.506523
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    hardware = AIXHardware()
    hardware.module = MagicMock()
    hardware.module.run_command.return_value = (0, 'proc0 Available 00-00 Processor', '')
    hardware.module.run_command.return_value = (0, 'PowerPC_POWER8', '')
    hardware.module.run_command.return_value = (0, 'smt_threads 1 False', '')
    hardware.module.run_command.return_value = (0, 'smt_threads 1 False', '')
    hardware.module.run_command.return_value = (0, 'smt_threads 1 False', '')
    hardware.module.run_command.return_value = (0, 'smt_threads 1 False', '')

# Generated at 2022-06-22 22:56:28.056619
# Unit test for method get_vgs_facts of class AIXHardware

# Generated at 2022-06-22 22:56:35.268260
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    aix_hardware = AIXHardware(dict())
    device_facts = aix_hardware.get_device_facts()
    assert ('devices' in device_facts) is True
    assert ('eth0' in device_facts['devices']) is True
    assert ('state' in device_facts['devices']['eth0']) is True
    assert ('type' in device_facts['devices']['eth0']) is True
    assert ('attributes' in device_facts['devices']['eth0']) is True

# Generated at 2022-06-22 22:56:40.395167
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    hardware_obj = AIXHardware()
    memory_facts = hardware_obj.get_memory_facts()

    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0

# Generated at 2022-06-22 22:56:49.760371
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})

    hardware = AIXHardware(module)
    hardware_facts = hardware.populate()

    assert hardware_facts['processor'] == 'PowerPC_POWER5+'
    assert hardware_facts['processor_cores'] == 2
    assert hardware_facts['processor_count'] == 16
    assert hardware_facts['memtotal_mb'] == 32768
    assert hardware_facts['memfree_mb'] == 1064
    assert hardware_facts['swaptotal_mb'] == 256
    assert hardware_facts['swapfree_mb'] == 256
    assert hardware_facts['firmware_version'] == '1.9'
    assert hardware_facts['product_serial'] == '06C1947P6S'
    assert hardware_facts['lpar_info'] == '1'
    assert hardware

# Generated at 2022-06-22 22:56:53.518778
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    facts = AIXHardwareCollector.collect()
    assert ('processor_cores' in facts)
    assert ('firmware_version' in facts)
    assert ('product_serial' in facts)
    assert ('lpar_info' in facts)
    assert ('product_name' in facts)
    assert ('vgs' in facts)
    assert ('devices' in facts)



# Generated at 2022-06-22 22:56:58.482873
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module=module)
    hardware.populate()
    facts = hardware.get_facts()
    assert facts['memfree_mb'] == facts['memtotal_mb'] - facts['swaptotal_mb']



# Generated at 2022-06-22 22:57:00.536539
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    result = AIXHardwareCollector()
    assert result


# Generated at 2022-06-22 22:57:06.940146
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hw = AIXHardware(module)
    memory_facts = hw.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0

# Generated at 2022-06-22 22:57:17.412762
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    with open("test_AIXHardware_lsdev_output", "r") as f:
        lsdev_out = f.read()
    with open("test_AIXHardware_lsattr_output", "r") as f:
        lsattr_out = f.read()
    module = get_module_mock(lsdev_out=lsdev_out, lsattr_out=lsattr_out)
    hardware = AIXHardware(module)
    facts = hardware.populate()
    assert hardware.platform == 'AIX'

# Generated at 2022-06-22 22:57:29.028047
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    hardware = AIXHardware()
    hardware.module = AnsibleModule(argument_spec={})
    hardware.module.run_command = MagicMock(return_value=(0, "proc0 Available 00-00-00-00", ""))
    hardware.module.run_command = MagicMock(return_value=(0, "proc1 Available 00-00-00-01", ""))
    hardware.module.run_command = MagicMock(return_value=(0, "proc2 Available 00-00-00-02", ""))
    hardware.module.run_command = MagicMock(return_value=(0, "proc3 Defined   00-00-00-03", ""))
    hardware.module.run_command = MagicMock(return_value=(0, "type POWER3", ""))
    hardware.module.run_command = MagicM

# Generated at 2022-06-22 22:57:37.494942
# Unit test for constructor of class AIXHardware

# Generated at 2022-06-22 22:57:43.744878
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    result = AIXHardware.get_cpu_facts()
    assert len(result) == 4
    processor = result['processor']
    assert isinstance(processor, list)
    processor_count = result['processor_count']
    assert isinstance(processor_count, int)
    processor_cores = result['processor_cores']
    assert isinstance(processor_cores, int)


# Generated at 2022-06-22 22:57:56.534221
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    aix_virtual_disk_sample = """rootvg:
PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
hdisk0            active            546         0           00..00..00..00..00
hdisk1            active            546         113         00..00..00..21..92
realsyncvg:
PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
hdisk74           active            1999        6           00..00..00..00..06
testvg:
PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
hdisk105          active            999         838         200..39..199..200..200
hdisk106          active            999         599         200..00..00..199..200
"""

# Generated at 2022-06-22 22:57:58.733876
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    obj = AIXHardwareCollector()
    assert obj._platform == 'AIX'
    assert obj._fact_class == AIXHardware


# Generated at 2022-06-22 22:58:09.877371
# Unit test for method get_memory_facts of class AIXHardware

# Generated at 2022-06-22 22:58:23.243680
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    # Create instances of class AIXHardware
    aix_inventory = AIXHardware(dict(module=None))

    # Check value of var 'platform'
    assert aix_inventory.platform == 'AIX'
    # Check value of var 'memfree_mb'
    assert aix_inventory.memfree_mb is None
    # Check value of var 'memtotal_mb'
    assert aix_inventory.memtotal_mb is None
    # Check value of var 'swapfree_mb'
    assert aix_inventory.swapfree_mb is None
    # Check value of var 'swaptotal_mb'
    assert aix_inventory.swaptotal_mb is None
    # Check value of var 'processor'
    assert aix_inventory.processor == []
    # Check value of var 'processor_cores'

# Generated at 2022-06-22 22:58:27.830271
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = AIXHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert (memory_facts['memtotal_mb'] is not None), "memtotal_mb is empty"
    assert (memory_facts['memfree_mb'] is not None), "memfree_mb is empty"
    assert (memory_facts['swaptotal_mb'] is not None), "swaptotal_mb is empty"
    assert (memory_facts['swapfree_mb'] is not None), "swapfree_mb is empty"



# Generated at 2022-06-22 22:58:30.222353
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hw = AIXHardware(dict())
    assert isinstance(hw, Hardware)
    assert hw.platform == 'AIX'

# Generated at 2022-06-22 22:58:38.534193
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    """
    Test to get dmi facts from AIX on Power Systems.
    """

    class Options:
        def __init__(self):
            self.gathering = 'implicit'
            self.facter = None
            self.terse = False
            self.verbosity = None
    options = Options()

    # Mock module
    class Module:
        def __init__(self):
            self.run_command = aix_run_command

    hardware = AIXHardware(Module(), options)

    # Calling get_dmi_facts
    dmi_facts = hardware.get_dmi_facts()

    # Assertion
    assert dmi_facts['firmware_version'] == 'V7,2,9,0'
    assert dmi_facts['product_serial'] == 'BH0067435'
   

# Generated at 2022-06-22 22:58:50.770901
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    module_mock = AIXHardware()
    module_mock.module = module
    module_mock._mount_path = '/dev/fslv00 /home jfs rw,log=/dev/hd8 0 0'

    result = module_mock.get_mount_facts()

    assert result['mounts'][0]['device'] == '/dev/fslv00'
    assert result['mounts'][0]['mount'] == '/home'
    assert result['mounts'][0]['fstype'] == 'jfs'
    assert result['mounts'][0]['options'] == 'rw,log=/dev/hd8'

# Generated at 2022-06-22 22:59:01.163603
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    """
    Unit test for method get_mount_facts of class AIXHardware
    """

    class MockModule(object):

        def __init__(self):
            self.run_command_args_list = []
            self.run_command_calls = 0
            self.get_bin_path_args_list = []
            self.get_bin_path_calls = 0
            self.fail_json_args_list = []
            self.fail_json_calls = 0

        def run_command(self, args, **kwargs):
            self.run_command_calls += 1
            self.run_command_args_list.append(args)


# Generated at 2022-06-22 22:59:07.704124
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    # Mocking method run_command of module_utils.facts.hardware.base
    AIXHardware.run_command = lambda self: (0, 'IBM,8233-E8B', '')

    # Test method get_dmi_facts of class AIXHardware
    hardware_info = AIXHardware.get_dmi_facts()
    assert hardware_info['firmware_version'] == '8233-E8B'


# Generated at 2022-06-22 22:59:19.566169
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    module = basic.AnsibleModule(argument_spec={})
    facts_collector = collector.get_collector(module, 'hardware')
    facts = facts_collector.collect(module, 'hardware')
    assert facts['processor_count'] == 1
    assert facts['processor'] == 'PowerPC_POWER7'
    assert facts['processor_cores'] == 4
    assert facts['firmware_version'] == '2.2.0.0'
    assert facts['product_serial'] == '0123AB'
    assert facts['lpar_info'] == 'aix7'
    assert facts['product_name'] == 'IBM,7000-MMA'

# Generated at 2022-06-22 22:59:28.282925
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    facts = hardware.populate()
    assert facts['firmware_version'] == 'Firmware Type: IBM,PCI,89A0'
    assert facts['product_name'] == 'System Model: IBM,8203-E4A'
    assert facts['product_serial'] == 'Machine Serial Number: 000ED2F485'
    assert facts['memory_mb'] == {'swapfree_mb': 8192, 'swaptotal_mb': 8192, 'memfree_mb': 8192, 'memtotal_mb': 40960}
    assert facts['processor'] == ['IBM,970MP,PowerPC_POWER8']
    assert facts['processor_cores'] == 2

# Generated at 2022-06-22 22:59:32.910853
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    """ Unit test for method get_cpu_facts of class AIXHardware """
    # TODO: Write unit tests for get_cpu_facts
    pass


# Generated at 2022-06-22 22:59:42.062106
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)

    populate_result = hardware.populate()
    assert populate_result is not None
    assert 'processor' in populate_result
    assert 'processor_cores' in populate_result
    assert 'processor_count' in populate_result
    assert 'memtotal_mb' in populate_result
    assert 'memfree_mb' in populate_result
    assert 'swaptotal_mb' in populate_result
    assert 'swapfree_mb' in populate_result
    assert 'firmware_version' in populate_result
    assert 'product_name' in populate_result or 'product_serial' in populate_result

# Generated at 2022-06-22 22:59:53.751319
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():

    class RUN_COMMAND_RESPONSE:
        def __init__(self, out, rc):
            self.out = out
            self.rc = rc

    # Test case 1: Normal mount

# Generated at 2022-06-22 22:59:59.181739
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default='!all', required=False),
        ),
    )

    AIXHardware.get_mount_facts(module)

    results = module.exit_json()
    assert 'ansible_mounts' in results['ansible_facts']

# Generated at 2022-06-22 23:00:10.153036
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    """
    Test get_memory_facts of AIXHardware
    """
    from ansible.module_utils.facts.hardware.aix import AIXHardware


# Generated at 2022-06-22 23:00:15.234703
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    hardware = AIXHardware()
    hardware.module.run_command = mock_command(0, '', '', '')
    hardware.module.run_command = mock_command(0, 'memory pages              :     66569\n', '', '')
    hardware.module.run_command = mock_command(0, 'free pages                :      8503\n', '', '')
    hardware.module.run_command = mock_command(0, '1048576 blocks\n', '', '')
    hardware.module.run_command = mock_command(0, 'Device          1M-blocks     Used    Avail Capacity\n', '', '')
    hardware.module.run_command = mock_command(0, '/dev/ada0p3        314368        0   314368     0%\n', '', '')
   

# Generated at 2022-06-22 23:00:24.664093
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware_obj = AIXHardware(module)
    vgs_facts = hardware_obj.get_vgs_facts()
    mounts_facts = vgs_facts['vgs']['/']
    assert mounts_facts[0]['pv_name'] == 'hdisk0'
    assert mounts_facts[0]['pv_state'] == 'active'
    assert mounts_facts[0]['total_pps'] == '546'
    assert mounts_facts[0]['free_pps'] == '0'
    assert 'pp_size' in mounts_facts[0]


# Generated at 2022-06-22 23:00:27.289779
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector._platform == "AIX"
    assert hardware_collector._fact_class == AIXHardware


# Generated at 2022-06-22 23:00:39.073849
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    ansible_module = MagicMock()
    ansible_module.run_command.return_value = ("", "/usr/sbin/lsdev -Cc processor\nproc0 Available 00-00 Processor\nproc4 Available 00-04 Processor", "")
    ansible_module.get_bin_path.return_value = "/usr/sbin/lsattr"
    ansible_module.run_command.return_value[1] = "/usr/sbin/lsattr -El proc0 -a smt_threads\nsmt_threads 1 False\n"
    ansible_module.run_command.return_value[1] = "/usr/sbin/lsattr -El proc0 -a type\ntype PowerPC_POWER8 False\n"

# Generated at 2022-06-22 23:00:44.215638
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    from ansible.module_utils.facts.hardware.aix import AIXHardwareCollector
    hardwareCollector = AIXHardwareCollector()

    assert hardwareCollector.platform == 'AIX'
    assert hardwareCollector.fact_class == AIXHardware
#

# Generated at 2022-06-22 23:00:47.363223
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware_module = AIXHardware(dict())

    assert hardware_module.platform == 'AIX'
    assert hardware_module.module == dict()


# Generated at 2022-06-22 23:00:55.564022
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    hardware = AIXHardware()
    hardware.module = AnsibleModule({})
    hardware.module.run_command = lambda *args, **kwargs: (0, 'memory pages: 116867\nfree pages: 113\n', None)

    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 45471
    assert memory_facts['memfree_mb'] == 443

    memory_facts['swapfree_mb'] = 10
    memory_facts['swaptotal_mb'] = 20

    assert memory_facts['swapfree_mb'] == 10
    assert memory_facts['swaptotal_mb'] == 20


# Generated at 2022-06-22 23:01:01.888547
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={})
    hardware_obj = AIXHardware(module)
    if hardware_obj:
        print(hardware_obj.populate())
    else:
        print("AIXHardware object not created")


from ansible.module_utils.basic import *

if __name__ == '__main__':
    test_AIXHardware()

# Generated at 2022-06-22 23:01:13.801608
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    """
    Unit test class AIXHardware
    """

    class HardwareModule(object):
        def __init__(self):
            self.params = {'gather_subset': 'all'}

        def run_command(self, args, use_unsafe_shell=False):
            if re.search(r"cpu", args):
                out = "proc0 Available 00-00 Processor\nproc4 Defined 05-20 Processor\n"
                return 0, out, ""
            elif re.search(r"mem", args):
                out = """memory pages         144585
                free pages           2927
                """
                return 0, out, ""
            elif re.search(r"vmstat", args):
                out = """memory pages         144585
                free pages           2927
                """
                return 0, out

# Generated at 2022-06-22 23:01:20.065420
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware = AIXHardware()
    facts = hardware.populate()
    assert 'memfree_mb' in facts
    assert 'memtotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts

# Generated at 2022-06-22 23:01:21.792546
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = get_fake_module()
    hardware = AIXHardware(module)
    assert hardware.platform == "AIX"



# Generated at 2022-06-22 23:01:34.200441
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    ansible_module_mock = AnsibleModuleMock()

    # Get out of vmstat
    ansible_module_mock.run_command = MagicMock(return_value=(0, "kthr      memory              page              faults          cpu\n----- ----------- ------------------------ ------------------------ -----------\n r  b   avm   fre  re  pi  po  fr   sr  cy  in   sy  cs us sy id wa  pc %ec", ""))

    # Get out of lsps
    ansible_module_mock.run_command = MagicMock(return_value=(0, "Page Space Physical Volume    Volume Group    Size %Used  Active Auto Type\nrawvg   hdisk1             rawvg             537.00MB    0.02 yes   yes  lv\n", ""))

    aix_hw = AIXHardware

# Generated at 2022-06-22 23:01:36.636809
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():

    # Create an instance of class AIXHardwareCollector
    hardware_collector_instance = AIXHardwareCollector()

    # Assert that the platform that the class pertains to is AIX
    assert hardware_collector_instance._platform == "AIX"

# Generated at 2022-06-22 23:01:47.791662
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    # Fake command outputs
    module.run_command = MagicMock(side_effect=['0\nhdisk0 Available 00-00\nhdisk1 Available 00-00\n',
                                                '0\nattr1 yes rootvg\nattr2 yes rw\n'])
    # Fake command path
    module.get_bin_path = MagicMock(side_effect=['/usr/sbin/lsdev',
                                                 '/usr/sbin/lsattr'])
    hardware = AIXHardware(module)
    # Run the tested method
    devices = hardware.get_device_facts()

    assert devices['devices']['hdisk0']['state'] == 'Available'

# Generated at 2022-06-22 23:01:57.953937
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    class TestModule(object):
        def __init__(self):
            self.params = {}

        def run_command(self, command, use_unsafe_shell=False):
            if command == '/usr/sbin/lsvg -o | /usr/bin/xargs /usr/sbin/lsvg -p':
                return 0, FAKE_LSVG_OUTPUT, ''
            if command == '/usr/sbin/lsvg rootvg':
                return 0, FAKE_LSVG_ROOTVG_OUTPUT, ''
            if command == '/usr/sbin/lsvg testvg':
                return 0, FAKE_LSVG_TESTVG_OUTPUT, ''

    hardware = AIXHardware(TestModule())
    vgs_facts = hardware.get_vgs_facts()
    assert vgs_facts

# Generated at 2022-06-22 23:02:10.185736
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    import __main__
    from ansible.module_utils.facts.hardware.aix import AIXHardware

    __main__.AIXHardware = AIXHardware

    ah = AIXHardware({'ANSIBLE_MODULE_ARGS': {}})
    rc, out, err = ah.module.run_command('/usr/bin/lsdev -Cc disk -F "name:type:status"')
    assert rc == 0
    assert len(out.splitlines()) > 0

    rc, out, err = ah.module.run_command('/usr/bin/lsattr -El hdisk0')
    assert rc == 0
    assert len(out.splitlines()) > 0

    # Setup Mocked functions
    ah.module.get_bin_path = lambda *args, **kwargs: '/usr/bin/dummy'
   

# Generated at 2022-06-22 23:02:12.492506
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    aix_hw = AIXHardware()
    assert aix_hw.platform == 'AIX'

# Generated at 2022-06-22 23:02:24.565952
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == 'PowerPC_POWER8'
    assert hardware.facts['processor_cores'] == 2
    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['memtotal_mb'] > 2048
    assert hardware.facts['memfree_mb'] > 2048
    assert hardware.facts['swaptotal_mb'] > 0
    assert hardware.facts['swapfree_mb'] > 0
    assert hardware.facts['firmware_version'] == 'IBM,760-HHBTM'
    assert hardware.facts['product_serial'] == '3578NAL'
    assert hardware.facts['lpar_info'] == 'aix-hmc1-lpar1'

# Generated at 2022-06-22 23:02:32.031446
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    ansible_module = AnsibleModule(argument_spec={'lsconf': {'type': 'str', 'required': False},
                                                  'lsattr': {'type': 'str', 'required': False}})
    ansible_module.execute_task()
    result = ansible_module.exit_json()
    fail_msg = 'DMI facts should be gathered'
    assert result['ansible_facts']['dmi'], fail_msg



# Generated at 2022-06-22 23:02:43.580013
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    cpu_facts = {}
    cpu_facts['processor'] = []
    cpu_facts['processor_count'] = None
    cpu_facts['processor_cores'] = None
    lsdev_cmd = "/usr/sbin/lsdev -Cc processor"
    rc, out_lsdev, err = run_command(lsdev_cmd)
    if out_lsdev:
        i = 0
        for line in out_lsdev.splitlines():
            if 'Available' in line:
                if i == 0:
                    data = line.split(' ')
                    cpudev = data[0]
                i += 1
        cpu_facts['processor_count'] = int(i)

        rc, out_lsattr, err = run_command("/usr/sbin/lsattr -El " + cpudev + " -a type")

# Generated at 2022-06-22 23:02:52.023409
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    class AIXHardware_get_memory_facts_module:
        def __init__(self):
            pass

        def run_command(self, cmd):
            if cmd == '/usr/bin/vmstat -v':
                out = '''
                  memory pages
                  10485760
                  free pages
                  84916
                '''
            elif cmd == '/usr/sbin/lsps -s':
                out = '''
                    Device          1M-blocks     Used    Avail Capacity
                    /dev/ada0p3        314368        0   314368     0%
                '''
            else:
                out = ''
                cmd = -1
            return cmd, out, 'stderr'


# Generated at 2022-06-22 23:02:56.222067
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    cpu_facts = hardware.get_cpu_facts()

    assert cpu_facts['processor'] == 'PowerPC_POWER8'
    assert cpu_facts['processor_count'] == 16
    assert cpu_facts['processor_cores'] == 1


# Generated at 2022-06-22 23:03:00.153003
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    ahc = AIXHardware(module=module)
    assert ahc

    cpu_facts = ahc.get_cpu_facts()
    assert cpu_facts['processor_count']
    assert cpu_facts['processor_cores']
    assert cpu_facts['processor']



# Generated at 2022-06-22 23:03:11.468425
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    class ModuleMock:
        def run_command(self, cmd):
            if cmd == '/usr/bin/vmstat -v':
                return (0, '2097152memory pages0free pages', None)
            else:
                return (0, '  /dev/hd6            2097151     1596755     500396       77%    /', None)
    module_mock = ModuleMock()
    ah = AIXHardware(module_mock)
    ah.populate()
    assert ah.facts['memtotal_mb'] == 1024
    assert ah.facts['memfree_mb'] == 0
    assert ah.facts['swaptotal_mb'] == 2047
    assert ah.facts['swapfree_mb'] == 1530



# Generated at 2022-06-22 23:03:21.226858
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    import sys
    module = sys.modules["ansible.module_utils.facts.hardware.aix.aix"]
    ah = module.AIXHardware()
    cmd = ah.module.get_bin_path("lsconf")
    ah.module.run_command = lambda *args, **kwargs: (0, "Machine Serial Number: IBM,71Y0281\nLPAR Info: 1 1\nSystem Model: IBM,9117-MMA", "")
    serial_number = ah.get_dmi_facts()["product_serial"]
    assert serial_number == 'IBM,71Y0281'
    product_name = ah.get_dmi_facts()["product_name"]
    assert product_name == 'IBM,9117-MMA'
    lpar_info = ah.get_dmi_facts

# Generated at 2022-06-22 23:03:28.859375
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():

    class MockModule(object):
        def __init__(self):
            self.params = {'gather_subset': ['all'],
                           'filter': '*'}
            self.run_command = lambda x, **z: (0, "", "")
    module = MockModule()

    ah = AIXHardware(module)

    expected = {'mounts': []}

    mounts = ah.get_mount_facts()

    assert mounts == expected

# Generated at 2022-06-22 23:03:39.914915
# Unit test for method get_dmi_facts of class AIXHardware

# Generated at 2022-06-22 23:03:47.938226
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    import sys
    sys.modules['ansible'] = type('FakeAnsibleModule', (object,), {'AnsibleModule': type('FakeAnsibleModule', (object,), {'run_command': lambda args: (0, 'FWVERSION IBM,8233-E8B\n', None)})})
    ah = AIXHardware()
    assert ah.get_dmi_facts()['firmware_version'] == '8233-E8B'