

# Generated at 2022-06-22 22:53:49.776009
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    '''
    Test get_memory_facts method
    '''
    module = type('',(object,),{'run_command': lambda self,command: (0,'1048576 memory pages\n0 free pages\n','aix')})

    hardware = AIXHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 512.0
    assert memory_facts['memfree_mb'] == 0.0

# Generated at 2022-06-22 22:53:52.428635
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector.platform == 'AIX'
    assert isinstance(hardware_collector.fact_class(), AIXHardware)


# Generated at 2022-06-22 22:53:56.401540
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    m = AIXHardware({})
    device_facts_result = m.get_device_facts()
    assert type(device_facts_result) is dict
    assert 'devices' in device_facts_result.keys()

# Generated at 2022-06-22 22:54:08.505443
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    class ModuleStub(object):
        def get_bin_path(bin_name, required=False):
            if bin_name == 'lsvg':
                return "/usr/sbin/lsvg"
            else:
                return "/usr/bin/xargs"


# Generated at 2022-06-22 22:54:15.235114
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module=module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['firmware_version']
    assert dmi_facts['product_serial']
    assert dmi_facts['lpar_info']
    assert dmi_facts['product_name']



# Generated at 2022-06-22 22:54:23.680035
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    memory_facts = {'memfree_mb': 18,
                    'memtotal_mb': 96,
                    'swapfree_mb': 19,
                    'swaptotal_mb': 20}
    out = """memory pages                                            :     2048
free pages                                              :        18
large page memory pages                                  :         0
free large page memory pages                             :         0
pinned pages                                             :         0
pinned pages waiting for I/O                             :         0"""
    module = MagicMock()
    AIXHardwareModule = AIXHardware(module)
    module.run_command.return_value = 0, out, ''
    assert memory_facts == AIXHardwareModule.get_memory_facts()

    # Unsupported output for vmstat -v

# Generated at 2022-06-22 22:54:35.707221
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts.utils import get_mount_size
    import os

    test_files = {
        '/var/adm/wtmp': 'wtmp',
        '/var/adm/lastlog': 'lastlog'
    }


# Generated at 2022-06-22 22:54:41.252437
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    # Create an instance of class AIXHardware and set module to dummy AnsibleModule
    a = AIXHardware()
    a.module = MockAnsibleModule()

    # create class AIXHardware get_cpu_facts()
    out = a.get_cpu_facts()

    assert out['processor_count'] == 1
    assert out['processor'] == 'PowerPC_POWER8'
    assert out['processor_cores'] == 8



# Generated at 2022-06-22 22:54:54.428277
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    ls_bin_path = "/bin/ls"
    mount_path = "/bin/mount"

# Generated at 2022-06-22 22:54:58.059485
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware_facts = AIXHardware({})
    assert hardware_facts.platform == 'AIX', 'Test Failed - platform not AIX'


# Generated at 2022-06-22 22:55:03.734828
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)

    free_memory = hardware.get_memory_facts().get("memfree_mb")
    total_memory = hardware.get_memory_facts().get("memtotal_mb")

    assert (free_memory <= total_memory) is True



# Generated at 2022-06-22 22:55:10.589970
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    """
    This is a test for method populate of class AIXHardware.
    """
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    fact = AIXHardware()
    fact._get_cpu_number = lambda: 2
    fact._get_cpu_vendor = lambda: 'IBM POWER'
    fact._get_cpu_model = lambda: 'POWER4'
    fact._get_cpu_hz = lambda: '2000000000'
    fact._get_cpu_hz_info = lambda: '2GHz'
    fact._get_cpu_cores = lambda: '8'
    fact._get_cpu_threads = lambda: '16'
    fact._get_mem_size = lambda: '103809024'

# Generated at 2022-06-22 22:55:18.059594
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    parser = Parser()
    path = 'utils/ansible_facts/facts/hardware/aix_lsdev.out'
    aix_lsdev_out = parser.parse_file(path)
    path = 'utils/ansible_facts/facts/hardware/aix_lsattr_csm.out'
    aix_lsattr_csm_out = parser.parse_file(path)
    path = 'utils/ansible_facts/facts/hardware/aix_lsattr_fscsi0.out'
    aix_lsattr_fscsi0_out = parser.parse_file(path)
    path = 'utils/ansible_facts/facts/hardware/aix_lsattr_fscsi1.out'
    aix_lsattr_fscsi1_out = parser.parse

# Generated at 2022-06-22 22:55:29.607149
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.run_command = MagicMock()
    module.run_command.return_value = (0, "", "")

    ah = AIXHardware(module)

    # lsattr -El sys0 -a fwversion doesn't find anything
    dmi_facts = {}
    module.run_command.return_value = (1, "", "")
    ah.get_dmi_facts()
    module.fail_json.assert_called_with(msg="Failed to find fwversion")

    # lsattr -El sys0 -a fwversion returns something
    dmi_facts = {}
    module.run_command.return_value = (0, "fwversion IBM,8233-E8B", "")
    ah.get

# Generated at 2022-06-22 22:55:38.164855
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    from operator import itemgetter
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    aix_hardware_obj = AIXHardware()

    dmi_facts = aix_hardware_obj.get_dmi_facts()
    # Check if the output is non-empty
    assert dmi_facts
    # Check if there is a keys in the output
    assert 'lpar_info' in dmi_facts
    assert 'firmware_version' in dmi_facts
    assert 'product_name' in dmi_facts
    assert 'product_serial' in dmi_facts



# Generated at 2022-06-22 22:55:39.637217
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    assert AIXHardware().get_mount_facts()

# Generated at 2022-06-22 22:55:49.995172
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule({})
    hardware = AIXHardware(module)

    vgs_facts = hardware.get_vgs_facts()
    assert vgs_facts['vgs']['testvg'][0]['pv_name'] == 'hdisk105'
    assert vgs_facts['vgs']['testvg'][0]['total_pps'] == '999'
    assert vgs_facts['vgs']['testvg'][1]['pv_name'] == 'hdisk106'
    assert vgs_facts['vgs']['testvg'][1]['total_pps'] == '999'
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'

# Generated at 2022-06-22 22:55:55.315522
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    """This unit test for method populate of class AIXHardware"""
    module = AnsibleModule(argument_spec={'gather_subset': dict(default=['!all'], type='list')})
    hardware = AIXHardware(module=module)
    hardware.populate()
    module.exit_json(ansible_facts=module.ansible_facts)


from ansible.module_utils.basic import *
if __name__ == '__main__':
    main()

# Generated at 2022-06-22 22:56:01.889402
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    import sys
    import os
    import uuid
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils._text import to_bytes

    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

    fake_module = type('', (), {
        'params': {},
        'run_command': lambda a, b, c=None, d=None: ('', to_bytes("ent0 Available 01-08-00 Ethernet IVE"), ''),
        'get_bin_path': lambda a, b=False: a,
        'fail_json': lambda a, **kw: None,
        'exit_json': lambda **kw: None
    })()


# Generated at 2022-06-22 22:56:14.789939
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    class AIXHardware_get_mount_facts_Module(object):
        def __init__(self, module):
            self.module = module

        def get_bin_path(self, cmd, required=False):
            if cmd == 'mount':
                return '/usr/sbin/mount'
            if cmd == 'lsvg':
                return '/usr/sbin/lsvg'
            if cmd == 'xargs':
                return '/usr/bin/xargs'
            return None


# Generated at 2022-06-22 22:56:19.977664
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    aix_hc = AIXHardwareCollector()
    assert aix_hc._platform == 'AIX'
    assert aix_hc._fact_class == AIXHardware
    assert len(aix_hc._collectors) == 0


# Generated at 2022-06-22 22:56:29.915233
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware_facts = AIXHardware(module)
    dmi_facts = hardware_facts.get_dmi_facts()
    assert dmi_facts['firmware_version'] == '1.7 (1.0)', "firmware version is not as expected"
    assert re.match(r'\w{3}[0-9]+\-[0-9]+', dmi_facts['lpar_info']), "lpar info is not as expected"
    assert re.match(r'\w{3}[0-9]+\-[0-9]+', dmi_facts['product_serial']), "product serial is not as expected"
    assert dmi_facts['product_name'] == '8286-42A', "product name is not as expected"

# Unit

# Generated at 2022-06-22 22:56:40.718436
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():

    from ansible.module_utils.facts.hardware.aix import AIXHardware

    hardware_facts = AIXHardware()

    memory_facts = hardware_facts.get_memory_facts()

    with open('/proc/meminfo', 'r') as meminfo:
        meminfo_lines = meminfo.readlines()

    # in AIX MemTotal is called memtotal_mb
    assert meminfo_lines[0].split()[1] == memory_facts['memtotal_mb']

    # in AIX MemFree is called memfree_mb
    assert meminfo_lines[1].split()[1] == memory_facts['memfree_mb']

    # in AIX SwapTotal is called swaptotal_mb
    assert meminfo_lines[14].split()[1] == memory_facts['swaptotal_mb']

    #

# Generated at 2022-06-22 22:56:50.018333
# Unit test for constructor of class AIXHardware

# Generated at 2022-06-22 22:56:59.411929
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)

    vgs_facts = hardware.get_vgs_facts()
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs_facts['vgs']['rootvg'][0]['pv_state'] == 'active'
    assert vgs_facts['vgs']['rootvg'][0]['total_pps'] == '546'
    assert vgs_facts['vgs']['rootvg'][1]['pv_name'] == 'hdisk1'
    assert vgs_facts['vgs']['rootvg'][1]['pp_size'] == '4 megabyte(s)'

# Generated at 2022-06-22 22:57:07.401500
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    facts_collector = AIXHardwareCollector(module=module)
    facts = facts_collector.collect()
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'processor' in facts
    assert 'processor_count' in facts
    assert 'processor_cores' in facts



# Generated at 2022-06-22 22:57:17.771469
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleMockModule()

    class TestAIXHardware(AIXHardware):
        def __init__(self, module):
            self.module = module
            self.mount_path = "/usr/bin/mount"

        def get_mount_path(self):
            return self.mount_path

    aix_hardware = TestAIXHardware(module)
    aix_hardware.mount_path = "/tmp/mount.out"
    file_handle = open(aix_hardware.mount_path)
    file_data = file_handle.read()
    file_handle.close()

    mount_facts = aix_hardware.get_mount_facts()


# Generated at 2022-06-22 22:57:29.547958
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():

    # Mocking run_command
    def run_command_mock(cmd, use_unsafe_shell=None):
        if cmd == '/usr/sbin/lsdev':
            return (0, 'ent0 Available  00-08-74-fe-e9-4e IBM,8247-42E', '')
        if cmd == '/usr/sbin/lsattr -E -l ent0':
            return ('0', 'state            Available\ntype             Full duplex\n', '')

    module_mock = Mock()
    module_mock.run_command = MagicMock(side_effect=run_command_mock)

    # Get device facts
    aix_facts = AIXHardware(module=module_mock)
    result = aix_facts.get_device_facts()

# Generated at 2022-06-22 22:57:37.805191
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    """ Method populate returns a dictionary of facts about hardware,
    but not all facts are NOT guaranteed to exist on every platform.
    This is a subset of the facts from Linux.
    """
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    hardware = AIXHardware()

    hardware.module.run_command = lambda x: (0, 'output', '')

    hardware.populate()

    assert hardware.facts['processor_count']

    assert hardware.facts['processor']

    assert hardware.facts['processor_cores']

    assert hardware.facts['memtotal_mb']

    assert hardware.facts['memfree_mb']

    assert hardware.facts['firmware_version']

    assert hardware.facts['product_serial']

    assert hardware.facts['product_name']


# Generated at 2022-06-22 22:57:49.487253
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    hardware = AIXHardware(None)
    vmstat_out = """memory pages
       113904         88624         25280
        logical pages
            2097152
        physical pages
            486528
        virtual pages
            2097152
        free pages
            246921
        free_paging_space 113904
        pinned pages
            0
        paging space
            640576
"""
    lsps_out = """PAGESIZE:  4096
TOTAL PAGING SPACE   %USED     %FREE
2097148MB      2%     98%
"""

    out_tuple = (0, vmstat_out, None)
    mem_facts = hardware.get_memory_facts(out_tuple, lsps_out)

# Generated at 2022-06-22 22:58:00.340214
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    test_module = AnsibleModule(argument_spec=dict())
    test_module.params = {}
    hardware = AIXHardware(test_module)
    vgs_facts = hardware.get_vgs_facts()

# Generated at 2022-06-22 22:58:07.238688
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    # Instantiate module
    module = AnsibleModule(argument_spec=dict())
    collector = AIXHardwareCollector(module=module)
    hardware = collector.collect()[collector.platform]
    current_facts = hardware.populate()
    assert current_facts['memory_mb']['real']['total'] > 0
    assert current_facts['memory_mb']['swap']['total'] > 0



# Generated at 2022-06-22 22:58:15.975985
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    """
    Unit test for method get_memory_facts of class AIXHardware
    """
    aix_hardware = AIXHardware()
    open('/etc/vm_info').write('MEMORY_PAGES:  16384\nFREE_PAGES:    8510\n')
    memory_facts = aix_hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 16384 * 4 // 1024
    assert memory_facts['memfree_mb'] == 8510 * 4 // 1024
    assert 'swaptotal_mb' not in memory_facts
    assert 'swapfree_mb' not in memory_facts
    open('/etc/vm_info').write('MEMORY_PAGES:  8388608\nFREE_PAGES:    8388608\n')

# Generated at 2022-06-22 22:58:19.879137
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    collect = AIXHardware()
    assert collect.platform == 'AIX'
    assert collect.get_cpu_facts()['processor_count'] == 2


# Generated at 2022-06-22 22:58:23.734466
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    harware = AIXHardware(module)
    facts = harware.populate()
    assert facts['firmware_version'] == 'IBM,2145F34'


# Generated at 2022-06-22 22:58:25.706890
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    aix = AIXHardwareCollector()
    assert aix.platform == 'AIX'
    assert aix.fact_class == AIXHardware

# Unit tests for class AIXHardware

# Generated at 2022-06-22 22:58:29.957576
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    mount_info = hardware.get_mount_facts()
    assert 'mounts' in mount_info
    assert isinstance(mount_info['mounts'], list)

# Generated at 2022-06-22 22:58:33.883361
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = AIXHardware(module=module)
    facts = {}
    vgs_facts = hardware.get_vgs_facts()
    facts.update(vgs_facts)
    module.exit_json(ansible_facts=facts)


# Generated at 2022-06-22 22:58:47.058887
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    class FactsModuleMock(object):
        def get_bin_path(self, arg):
            commands = {
                'lsvg': '/usr/sbin/lsvg',
                'xargs': '/usr/bin/xargs'
            }
            return commands[arg]

        def run_command(self, arg, use_unsafe_shell=False):
            lsvg_command = '/usr/sbin/lsvg -o | /usr/bin/xargs /usr/sbin/lsvg -p'

# Generated at 2022-06-22 22:58:58.604947
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    aixhw = AIXHardware()
    # capture output from function to a string
    import StringIO
    out = StringIO.StringIO()
    # create a dict object from this string
    import ast
    import re

# Generated at 2022-06-22 22:59:06.266604
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware

    h = AIXHardware(None)


# Generated at 2022-06-22 22:59:17.781737
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    facts = AIXHardware(module).populate()
    assert facts['processor_count'] == 2
    assert facts['processor_cores'] == 2
    assert facts['processor'] == 'POWER8'
    assert facts['memtotal_mb'] == 12188
    assert facts['memfree_mb'] == 12143
    assert facts['swaptotal_mb'] == 0
    assert facts['swapfree_mb'] == 0
    assert facts['firmware_version'] == '4.4.0.0'
    assert facts['product_serial'] == '07E5D70CEL'
    assert facts['lpar_info'] == '00c5b21a4c00c7ff'
    assert facts['product_name'] == '8286-41A'
    assert facts

# Generated at 2022-06-22 22:59:28.845400
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    rc, out, err = module.run_command("/usr/sbin/lsdev -Cc processor")
    if out:
        i = 0
        for line in out.splitlines():
            if 'Available' in line:
                if i == 0:
                    data = line.split()
                    cpudev = data[0]
                i += 1
        processor_cnt = int(i)

    rc, out, err = module.run_command("/usr/sbin/lsattr -El " + cpudev + " -a type")
    if out:
        data = out.split()
        processor = [data[1], ]


# Generated at 2022-06-22 22:59:32.481946
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware_obj = AIXHardware()
    assert hardware_obj.platform == 'AIX'



# Generated at 2022-06-22 22:59:42.739237
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    import sys
    import os

    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    fake_ansible_module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )

    ah = AIXHardware(fake_ansible_module)
    res = ah.populate()
    assert res['firmware_version'] is not None
    assert res['product_serial'] is not None
    assert res['product_name'] is not None
    assert res['lpar_info'] is not None

# Generated at 2022-06-22 22:59:47.153721
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={})

    # Create instance of AIXHardware
    hardware = AIXHardware(module)

    # Assert that we create the object
    assert hardware is not None


# Generated at 2022-06-22 22:59:53.537913
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(
        argument_spec=dict(),
    )

    hardware = AIXHardware(module=module)
    hardware.collect()

    assert hardware.firmware_version == 'BM86950A21'
    assert hardware.product_serial == '86950GJ'
    assert hardware.lpar_info == '1'
    assert hardware.product_name == '9117-MMB'
    assert hardware.product_name != 'VMware Virtual Platform'



# Generated at 2022-06-22 23:00:04.510062
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    class ModuleMock(object):
        def run_command(self, command):
            cmd = command
            bin_path, cmd_name, cmd_args = cmd.partition(' ')
            if cmd_name == 'mount':
                out =  'node mounted mounted over      vfs       date        options'.encode('utf-8')
                out += '/dev/hd9var /var jfs2     Aug  1 12:10 rw,log=/dev/hd8'.encode('utf-8')
                out += '/dev/hd4 / jfs2     Aug  1 10:42 rw'.encode('utf-8')
                out += '192.168.0.15:/export/home/export /export/home nfs4  Aug  1 12:07 rw,intr,vers=4'.encode('utf-8')


# Generated at 2022-06-22 23:00:16.767728
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    import shutil
    import tempfile
    import json
    import os
    import sys

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-22 23:00:23.738659
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    hardware = AIXHardware()


# Generated at 2022-06-22 23:00:35.379323
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={})
    hardware_obj = AIXHardware(module)
    mem_facts = hardware_obj.get_memory_facts()
    cpu_facts = hardware_obj.get_cpu_facts()
    dmi_facts = hardware_obj.get_dmi_facts()
    vgs_facts = hardware_obj.get_vgs_facts()
    mount_facts = hardware_obj.get_mount_facts()
    device_facts = hardware_obj.get_device_facts()
    facts = hardware_obj.populate()

    assert mem_facts['swaptotal_mb'] == int(facts['swaptotal_mb'])
    assert cpu_facts['processor'] == facts['processor']
    assert dmi_facts['product_serial'] == facts['product_serial']
    assert vgs_

# Generated at 2022-06-22 23:00:47.720138
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    ah = AIXHardware(module)
    mount_facts = ah.get_mount_facts()

# Generated at 2022-06-22 23:00:56.621094
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )


# Generated at 2022-06-22 23:01:08.210104
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = DummyModule()
    hardware = AIXHardware()
    hardware.module = module

    hardware.module.run_command = MagicMock(return_value=(0, 'proc0 Available 00-00-0000 PROCESSOR',
                                                          ''))
    hardware.module.run_command.return_value = (0, 'proc1 Available 00-00-0000 PROCESSOR', '')
    hardware.module.run_command.return_value = (0, 'proc2 Available 00-00-0000 PROCESSOR', '')
    hardware.module.run_command.return_value = (0, 'type PowerPC_POWER6', '')
    hardware.module.run_command.return_value = (0, 'smt_threads 1 True', '')
    cpu_facts = hardware.get_cpu_facts()

    hardware

# Generated at 2022-06-22 23:01:19.797818
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})

    obj = AIXHardware(module)

    def execute_side_effect(command, use_unsafe_shell):
        out = """proc1 Available 00-00 Processor
proc2 Available 00-01 Processor
proc3 Available 00-02 Processor
proc4 Available 00-03 Processor"""
        return 0, out, ''

    module.execute_command = MagicMock(side_effect=execute_side_effect)
    cpu_facts = obj.get_cpu_facts()
    assert cpu_facts['processor_count'] == 4
    assert cpu_facts['processor'] == 'PowerPC_POWER7'
    assert cpu_facts['processor_cores'] == 1



# Generated at 2022-06-22 23:01:27.225499
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    import sys
    import tempfile
    import subprocess
    mock_module = type('MockModule', (), {'run_command': run_command, 'get_bin_path': get_bin_path})
    mock_module.fail_json = fail_json
    mock_module.exit_json = exit_json
    ah = AIXHardware(mock_module)
    device_facts = ah.get_device_facts()

# Generated at 2022-06-22 23:01:34.200298
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    import sys
    import ansible.utils.module_docs as mdoc
    import ansible.module_utils.facts.hardware.aix as aix_facts

    m = aix_facts.AIXHardware(None)
    out = m.get_vgs_facts()
    print(out)

    if out['vgs']['rootvg']:
        sys.exit(0)
    else:
        sys.exit(1)

# Generated at 2022-06-22 23:01:45.850190
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    import os
    import sys
    import unittest

    from ansible.module_utils.facts.hardware.aix import AIXHardware

    class AnsibleModuleFake(object):
        """
        Fake class to avoid AnsibleModule dependency
        """

# Generated at 2022-06-22 23:01:46.884333
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    AIXHardwareCollector()

# Generated at 2022-06-22 23:01:50.942282
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    aix_hw_col = AIXHardwareCollector()
    assert aix_hw_col.platform == 'AIX'
    assert aix_hw_col.fact_class == AIXHardware


# Generated at 2022-06-22 23:02:01.152000
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    import json

    device_facts = AIXHardware().get_device_facts()

    print(json.dumps(device_facts['devices']['ent0'], indent=2))

    assert device_facts['devices']['ent0']['state'] == 'Available'
    assert device_facts['devices']['ent0']['type'] == 'Ethernet I/O Adapter'
    assert len(device_facts['devices']['ent0']['attributes'].keys()) > 0


if __name__ == '__main__':
    test_AIXHardware_get_device_facts()

# Generated at 2022-06-22 23:02:05.399917
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert(hardware_collector._platform == 'AIX')
    assert(hardware_collector._fact_class == AIXHardware)


# Generated at 2022-06-22 23:02:14.252038
# Unit test for method populate of class AIXHardware

# Generated at 2022-06-22 23:02:17.331864
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    h = AIXHardware()
    assert h.platform == 'AIX'
    assert h.get_cpu_facts()['processor_count'] == 2
    assert h.get_memory_facts()['swaptotal_mb'] == 4095
    assert h.get_dmi_facts()['firmware_version'] == '21.3.0.0 (build 03021300)'



# Generated at 2022-06-22 23:02:25.469979
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import get_collector
    import os
    import unittest

    fc = FactCollector(get_collector(os.getcwd() + '/library/aix_hardware.py', None))
    hardware_facts = fc.collect()
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0

# Generated at 2022-06-22 23:02:36.604238
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils._text import to_bytes

    ah = AIXHardware()
    assert type(ah) == AIXHardware

    class MockModule():
        def __init__(self):
            self._ansible_verbosity = 0
            self._ansible_no_log = False

        def run_command(self, *args, **kwargs):
            if args[0] == "/usr/sbin/lsattr -El sys0 -a fwversion":
                lsattr_out = to_bytes("sys0 fwversion IBM,8233-E8B\n")
                return 0, lsattr_out, ''
            elif args[0] == "/usr/bin/lsconf":
                lsconf_out = to_bytes

# Generated at 2022-06-22 23:02:46.405953
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    hw = AIXHardware()
    hw.module = MockModule()

    hw.module.run_command.return_value = (0, "", "")
    print(hw.populate())

    # Test with lsattr -El sys0 -a fwversion output
    hw.module.run_command.side_effect = [(0, "sys0 Available 02-00 IBM,7011-250 IBM,7011-250", ""),
                                         (0, "sys0 Available 02-00 IBM,7011-250 IBM,7011-250", ""),
                                         (0, "sys0 Available 02-00 IBM,7011-250 IBM,7011-250", "")]
    print(hw.populate())

    # Test with lsattr -El sys0 -a fwversion output for AIX 6.1
    hw

# Generated at 2022-06-22 23:02:51.507085
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    aixhwc = AIXHardwareCollector(module=module)
    assert aixhwc.module == module
    assert aixhwc.platform == 'AIX'
    assert aixhwc.fact_class == AIXHardware


# Generated at 2022-06-22 23:02:58.572800
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    args = dict(module_utils=dict(run_command=lambda x: (0, '', '')))
    facts = AIXHardware(module=None, params=args)
    facts_output = facts.get_dmi_facts()
    assert (facts_output['firmware_version'] == 'IBM,8205-E6B')
    assert (facts_output['product_serial'] == 'YEA0F061')
    assert (facts_output['lpar_info'] == '1 CWlpar_entitled')
    assert (facts_output['product_name'] == '8286-41A')



# Generated at 2022-06-22 23:03:05.550564
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    hardware = AIXHardware()
    hardware.module = FakeAnsibleModule(platform='AIX')
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['lpar_info'] == "1 "
    assert dmi_facts['firmware_version'] == "5.5.5.5"
    assert dmi_facts['product_name'] == "IBM,8286-42A"
    assert dmi_facts['product_serial'] == "12345678901234567890123456789012"



# Generated at 2022-06-22 23:03:17.372743
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModuleMock()
    hardware = AIXHardware(module)

    rc, out, err = module.run_command("/usr/sbin/lsdev -Cc processor")
    if out:
        i = 0
        for line in out.splitlines():
            if 'Available' in line:
                if i == 0:
                    data = line.split(' ')
                    cpudev = data[0]

                i += 1

    rc, out, err = module.run_command("/usr/sbin/lsattr -El " + cpudev + " -a type")
    data = out.split(' ')
    cpu = data[1]

    rc, out, err = module.run_command("/usr/sbin/lsattr -El " + cpudev + " -a smt_threads")

# Generated at 2022-06-22 23:03:29.600490
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec=dict())
    obj = AIXHardware()

    # Testing with one device, 2 attributes, which should return a
    # valid device fact.
    test_lsattr_out = "state           enabled\n" + \
        "eclevel         1\n"
    test_lsdev_out = "rsmap0          Available   30-00-00        IBM,RS/6000 Serial Port\n"
    test_lsattr_cmd = 'lsattr -E -l rsmap0'


# Generated at 2022-06-22 23:03:34.936294
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    m = AIXHardware()
    dmi_facts = m.get_dmi_facts()
    assert dmi_facts['firmware_version']
    assert dmi_facts['product_name']
    assert dmi_facts['lpar_info']
    assert dmi_facts['product_serial']



# Generated at 2022-06-22 23:03:44.274784
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    test_module_path = '/ansible/module_utils/facts/hardware/aix.py'
    test_data_path = '/ansible/module_utils/facts/hardware/test/data'
    out_lsdev = open(test_data_path + '/out_lsdev.txt', 'r').read()
    out_lsattr = open(test_data_path + '/out_lsattr.txt', 'r').read()
    out_mount = open(test_data_path + '/out_mount.txt', 'r').read()
    out_lsps = open(test_data_path + '/out_lsps.txt', 'r').read()
    out_lsvg = open(test_data_path + '/out_lsvg.txt', 'r').read()
    out_lsattr_E_l_

# Generated at 2022-06-22 23:03:56.111045
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    AIXhw = AIXHardware()
    rc, out, err = AIXhw.module.run_command("/usr/sbin/lsdev -Cc processor")
    i = 0
    for line in out.splitlines():
        if 'Available' in line:
            if i == 0:
                data = line.split(' ')
                cpudev = data[0]
            i += 1
    cpu_facts = {'processor_count': int(i)}
    rc, out, err = AIXhw.module.run_command("/usr/sbin/lsattr -El " + cpudev + " -a type")
    data = out.split(' ')
    cpu_facts['processor'] = data[1]