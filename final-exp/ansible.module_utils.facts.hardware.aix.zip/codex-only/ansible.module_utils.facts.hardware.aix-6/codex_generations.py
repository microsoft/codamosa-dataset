

# Generated at 2022-06-22 22:53:52.722804
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    class Options:
        filters = []
    facts_module_args = Options
    facts_module = AnsibleModule(argument_spec=dict(), supports_check_mode=False)
    facts_module.params = facts_module_args
    aix_hardware = AIXHardware(facts_module)

    aix_hardware.get_memory_facts()
    assert aix_hardware.facts['memtotal_mb'] is not None
    assert 'memfree_mb' in aix_hardware.facts
    assert 'swaptotal_mb' in aix_hardware.facts
    assert 'swapfree_mb' in aix_hardware.facts

# Generated at 2022-06-22 22:54:01.095905
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():

    # If aix module is not listed in the module_utils/facts/hardware folder then
    # ansible will throw an exception and exit. The below set up code is to work
    # around the problem.
    import sys
    import os
    CWD = os.path.dirname(os.path.realpath(__file__))
    module_utils_dir = os.path.join(CWD,"../../../module_utils/facts")
    sys.path.insert(0,module_utils_dir)

    from ansible.module_utils.facts.hardware.aix import AIXHardware

    aix_hardware = AIXHardware()
    facts = aix_hardware.get_mount_facts()
    assert 'mounts' in facts, "Mount information is not retrieved successfully"


# Generated at 2022-06-22 22:54:11.755137
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    """
    This function is a unit test for method get_mount_facts of class
    AIXHardware.  The test case ensures that the get_mount_facts
    returns correct value for given sample output of mount command
    """
    from ansible.module_utils.facts import facts
    import os
    import shutil
    from os.path import dirname, join
    from tempfile import mkdtemp

    module = facts.AnsibleModuleMock(
        name='test_AIXHardware_get_mount_facts', init_subclass=True)

    hardware_obj = AIXHardware(module)

    # Create temporary directory to mock sample output of mount command
    temp_dir = mkdtemp()

    sample_output_path = join(dirname(__file__), 'test_output/mount')

# Generated at 2022-06-22 22:54:21.261336
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.facts import modules

    module_mock = modules.AnsibleModule(
        argument_spec=dict()
    )

    dmi_facts = {'firmware_version': 'IBM,8247-42L',
                 'lpar_info': '1 VIOS',
                 'product_name': 'PowerNV 8247-42L',
                 'product_serial': 'D7A0F8F'
                 }

    HardwareClass = AIXHardware()
    get_dmi_facts_result = HardwareClass.get_dmi_facts()

    assert dmi_facts == get_dmi_facts_result


# Generated at 2022-06-22 22:54:32.598106
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    hardware = AIXHardware()
    hardware.module = DummyModule()
    hardware.module.get_bin_path = DummyModule().get_bin_path

    hardware.module.run_command = DummyModule.run_command
    hardware.module.get_bin_path = DummyModule.get_bin_path


# Generated at 2022-06-22 22:54:39.654128
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    hardware = AIXHardware()

    hardware.module = FakeModule()
    hardware.module.run_command = fake_run_command

    hardware.populate()

    assert hardware.firmware_version == 'IBM,8245KVX'
    assert hardware.product_serial == '0123ABC'
    assert hardware.lpar_info == '1 LABEL,10 NUMBER'
    assert hardware.product_name == 'IBM,8245KVX'


# Generated at 2022-06-22 22:54:52.237483
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    hardware = AIXHardware(module)

    # create test data

# Generated at 2022-06-22 22:54:56.630499
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={})
    hardware_obj = AIXHardware(module)

    assert hardware_obj.platform == 'AIX'
    assert hardware_obj.collector._platform == 'AIX'
    assert hardware_obj.collector._fact_class == AIXHardware


# Generated at 2022-06-22 22:55:01.579491
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)

    facts = hardware.get_cpu_facts()
    assert facts['processor']
    assert facts['processor_cores']
    assert facts['processor_count']


# Generated at 2022-06-22 22:55:04.401090
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    fact_collector = AIXHardwareCollector()
    assert fact_collector._platform == 'AIX'
    assert fact_collector._fact_class == AIXHardware


# Generated at 2022-06-22 22:55:15.015879
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    test_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    vgs_facts = AIXHardware(test_module).get_vgs_facts()
    realsyncvg = {
        'pv_name': 'hdisk74',
        'pv_state': 'active',
        'total_pps': '1999',
        'free_pps': '6',
        'pp_size': '4 megabyte(s)'
    }
    testvg = {
        'pv_name': 'hdisk105',
        'pv_state': 'active',
        'total_pps': '999',
        'free_pps': '838',
        'pp_size': '4 megabyte(s)'
    }

# Generated at 2022-06-22 22:55:26.998274
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    """
    test get_vgs_facts method
    """

# Generated at 2022-06-22 22:55:37.365070
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    aixhardware = AIXHardware()


# Generated at 2022-06-22 22:55:41.880441
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    """
    creates an instance of AIXHardware class
    """
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    if not HAS_AIX:
        module.fail_json(msg='aix_facts required for this module')
    harwareobj = AIXHardware(module)
    module.exit_json(ansible_facts={'ansible_hardware': harwareobj.populate()})



# Generated at 2022-06-22 22:55:51.827581
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    facts = AIXHardware()
    # Case 1: A directory having no files and no subdirectories

# Generated at 2022-06-22 22:55:57.834867
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    hw = AIXHardware(dict(), dict())

    # mock run method
    hw._run_command = lambda x: (0, test_lsconf_stdout, '')

    facts = hw.get_dmi_facts()
    assert facts['firmware_version'] == 'IBM,C011041'
    assert facts['product_serial'] == '0123456789'
    assert facts['lpar_info'] == 'Hostname01 lpar1 1 CEC'
    assert facts['product_name'] == 'IBM,8286-41A'


# Generated at 2022-06-22 22:55:58.796515
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    AIXHardwareCollector()

# Generated at 2022-06-22 22:56:04.700544
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    aix_hardware = AIXHardware()
    cmd = ["/usr/sbin/lsvg -o | /usr/bin/xargs /usr/sbin/lsvg -p"]
    rc, out, err = aix_hardware.module.run_command(cmd, use_unsafe_shell=True)

    aix_hardware.get_vgs_facts()


if __name__ == '__main__':
    test_AIXHardware_get_vgs_facts()

# Generated at 2022-06-22 22:56:15.923926
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    # create instance of AIXHardware
    aixh = AIXHardware()
    # create instance of lsconf command output
    lsconf_out = "Processor Type: PowerPC_POWER5\nProcessor Implementation Mode: POWER 5\n" \
                 "Processor Version: PV_5_Compat\nNumber Of Processors: 20\n" \
                 "Kernel Type: 64-bit\nLPAR Info: 1 Node,1 Partition\n" \
                 "VMM Mode: Not Available\nMax Mem:\t4096 MB\nMemory Size:\t2048 MB\n" \
                 "Good Memory Size:\t2048 MB\nPlatform Firmware level:\t\tS4C0\n" \
                 "Firmware Version:\tIBM,7F40V91\nConsole Login:\tenable\n" \
                

# Generated at 2022-06-22 22:56:26.775588
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    import sys
    # Mock module to use ai_module
    mock_module = sys.modules['ansible']
    mock_module.run_command = lambda x: (0, "processor 0 Available 09-00 Capped\nprocessor 1 Available 09-00", "")
    mock_module.get_bin_path = lambda x: "path"
    ai_module = AIXHardware()
    ai_module.read_file = lambda x: "type: PowerPC_POWER8"
    cpu_facts = ai_module.get_cpu_facts()
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'PowerPC_POWER8'


# Generated at 2022-06-22 22:56:38.954933
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    class MockModule(object):
        def run_command(self, command):
            if command == '/usr/sbin/lsattr -El sys0 -a fwversion':
                returned_value = 0, 'fwversion IBM,7223-938-720-SN10 SD33069A', ''
            elif command == '/usr/sbin/lsconf':
                returned_value = 0, '/lsconf output /', ''
            return returned_value

        def get_bin_path(self, command, required=True):
            if command == 'lsconf':
                returned_value = '/usr/sbin/lsconf'
            return returned_value

    theTestClass = AIXHardware()
    theTestClass.module = MockModule()
    dmi_facts = theTestClass.get_dmi_facts()
    assert dmi_facts

# Generated at 2022-06-22 22:56:41.349222
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    ahc = AIXHardwareCollector('adummymodule')
    assert ahc._platform == 'AIX'
    assert ahc._fact_class == AIXHardware


# Generated at 2022-06-22 22:56:50.381982
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    # Create a dummy module for unit testing
    fake_module = basic.AnsibleModule(argument_spec={})

    # Create a dummy lsdev output for unit testing
    lsdev_out = to_bytes("""
proc0 Available 00-00 Processor
proc1 Available 00-01 Processor
proc2 Available 00-02 Processor
proc3 Available 00-03 Processor
    """)

    # Create a dummy lsattr output for unit testing
    lsattr_out = to_bytes("""
smt_threads  1  False
type  PowerPC_POWER8  False
    """)

    # Create a dummy module.run_command return for unit testing
    fake_module.run_command_environ_update = dict()
    fake_module

# Generated at 2022-06-22 22:56:51.098331
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware = AIXHardware(dict())


# Generated at 2022-06-22 22:57:01.740847
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(
        argument_spec=dict()
    )

    fact_class_obj = AIXHardware(module)

    result = fact_class_obj.populate()

    cpu_facts_result = {'processor': ['POWER8', 'POWER'], 'processor_cores': 1,
                        'processor_count': 2}
    memory_facts_result = {'swaptotal_mb': 1023, 'memtotal_mb': 4095, 'memfree_mb': 626,
                           'swapfree_mb': 1022}
    dmi_facts_result = {'product_serial': '0123456789', 'product_name': 'pSeries 570',
                        'lpar_info': '1', 'firmware_version': '1.9.7'}
    vgs_facts_

# Generated at 2022-06-22 22:57:13.371592
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    dmi_facts_result = {'firmware_version': 'IBM,1FW720.01-SG-01',
                        'product_serial': 'FCH12345',
                        'product_name': '1632'}


# Generated at 2022-06-22 22:57:14.282836
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    x = AIXHardwareCollector()
    assert x.collect() is not None

# Generated at 2022-06-22 22:57:16.046527
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hd = AIXHardware(dict())
    assert hd.platform == 'AIX'


# Generated at 2022-06-22 22:57:20.301762
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    aix_hardware = AIXHardware(module)
    memory_facts = aix_hardware.get_memory_facts()
    assert 'memfree_mb' in memory_facts
    assert 'memtotal_mb' in memory_facts
    assert 'swapfree_mb' in memory_facts
    assert 'swaptotal_mb' in memory_facts


# Generated at 2022-06-22 22:57:25.522053
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    aix_hardware_collector = AIXHardwareCollector()
    assert isinstance(aix_hardware_collector, AIXHardwareCollector)
    assert issubclass(aix_hardware_collector.platform, str)
    assert issubclass(aix_hardware_collector.fact_class, Hardware)

# Generated at 2022-06-22 22:57:35.389507
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    test = AIXHardware()
    test.module = AnsibleModule(argument_spec={})

# Generated at 2022-06-22 22:57:44.640695
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    import subprocess

    class MockModule(object):
        def __init__(self):
            self.run_command = self.mock_run_command

        def mock_run_command(self, cmd):
            if cmd == "/usr/sbin/lsattr -El sys0 -a fwversion":
                return subprocess.Popen(['echo', "fwversion IBM,A.08.00"], stdout=subprocess.PIPE)
            if cmd == "/usr/bin/oslevel":
                return subprocess.Popen(['echo', "7.1.0.0"], stdout=subprocess.PIPE)

# Generated at 2022-06-22 22:57:56.721670
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    def run_command_mock(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None):
        if args[0] == '/usr/sbin/lsdev -Cc processor':
            out = 'proc0 Available 01-00 Processor\nproc1 Available 02-00 Processor'
        elif args[0] == '/usr/sbin/lsattr -El proc0 -a type':
            out = 'type PowerPC_POWER6 None'
        elif args[0] == '/usr/sbin/lsattr -El proc0 -a smt_threads':
            out = 'smt_threads 2 True'

# Generated at 2022-06-22 22:58:03.003734
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = type('MyModule', (object,), {})
    module.run_command = run_command_mock
    module.get_bin_path = get_bin_path_mock

    hardware = AIXHardware(module)
    hardware.populate()
    memory_facts = hardware.get_memory_facts()

    assert memory_facts['memtotal_mb'] == 49148
    assert memory_facts['memfree_mb'] == 4887
    assert memory_facts['swaptotal_mb'] == 314368
    assert memory_facts['swapfree_mb'] == 314366



# Generated at 2022-06-22 22:58:14.284958
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    """
    Unit test for the method get_vgs_facts of class AIXHardware
    """
    class module(object):
        """
        Class used to pass self.module to class AIXHardware
        """
        def __init__(self):
            self.params = {}

        def get_bin_path(self):
            """
            Method used to return the path of commands lsvg and xargs
            """
            return '/usr/sbin/'

        def run_command(self, cmd, use_unsafe_shell=False):
            """
            Method used to return the output of commands lsvg
            """

# Generated at 2022-06-22 22:58:25.859382
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():

    class ModuleStub:

        class run_command_result:
            @staticmethod
            def __init__(rc, out, err):
                pass

        def run_command(self, cmd, use_unsafe_shell=False):
            out = "firmware_version IBM,8205-E6C"
            return ModuleStub.run_command_result(0, out, '')

    class AIXHardwareStub(AIXHardware):
        def __init__(self, module):
            self.module = module

    # Define parameters
    module_stub = ModuleStub()
    hardware_object = AIXHardwareStub(module_stub)
    assert hardware_object.get_dmi_facts()['firmware_version'] == '8205-E6C'

# Generated at 2022-06-22 22:58:32.147777
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())

    hardware = AIXHardware(module)
    mock_command = Mock(return_value=(0, '', ''))
    hardware.module.run_command = mock_command
    hardware.get_memory_facts()

    # /usr/bin/vmstat -v is called
    hardware.module.run_command.assert_any_call("/usr/bin/vmstat -v")



# Generated at 2022-06-22 22:58:36.888638
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    aix_hardware = AIXHardware(None)
    assert aix_hardware.platform == 'AIX'
    assert aix_hardware.collector._platform == 'AIX'

if __name__ == '__main__':
    test_AIXHardware()

# Generated at 2022-06-22 22:58:49.521254
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    import ansible.module_utils.facts.hardware.aix as aix_module
    aix_mount_facts = aix_module.AIXHardware().get_mount_facts()
    print(aix_mount_facts)
    assert isinstance(aix_mount_facts, dict)
    # Expected result:
    # {'mounts': [{'mount': u'/dev/hd4', 'device': u'/dev/hd4', 'fstype': u'jfs2', 'options': u'log', 'time': u'Tue Aug 22 23:29:27 2017',
    # 'fs_size_kb': '9999676', 'fs_size_gb': '9.77', 'fs_used_kb': '5468276', 'fs_used_percent': '54', 'fs_free_kb': '4530

# Generated at 2022-06-22 22:58:54.328561
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    hw = AIXHardware(module)
    hw.populate()
    assert hw.memory['real']['total'] != 0
    assert hw.cpu['count'] != 0


# Generated at 2022-06-22 22:59:03.722928
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(
        argument_spec=dict()
    )
    # Testing in AIX 7.2.
    # To test in 5.3, 6.1 or others, change values below
    module.run_command = Mock(
        return_value=(
            0,
            """
            proc0           Available 00-00 Processor
            proc4           Available 00-04 Processor
            proc1           Available 00-01 Processor
            proc5           Available 00-05 Processor
            proc2           Available 00-02 Processor
            proc6           Available 00-06 Processor
            proc3           Available 00-03 Processor
            proc7           Available 00-07 Processor
            """,
            '')
    )

# Generated at 2022-06-22 22:59:15.748726
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    facts = {'module_setup': True, 'ansible_facts': {}}
    module = facts['ansible_facts']
    module.update = MagicMock(return_value=None)

    m = AIXHardware()
    m.module = module
    m.module.run_command = MagicMock(return_value=(0, '/dev/sda1        9165568 2634376 6325788  30% /\nnone            5120      0    5120   0% /dev\n', ''))
    m.populate()
    m.get_memory_facts()
    m.module.run_command.assert_called_with("/usr/bin/vmstat -v")
    assert module['ansible_facts']['memtotal_mb'] == 16074

# Generated at 2022-06-22 22:59:25.814393
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    facts = {}

    # Create AIXHardware object
    hardware = AIXHardware(module=None, facts=facts)

    # Add lsdev program to autodetect
    hardware.module.bin_path['lsdev'] = '/usr/bin/lsdev'
    # Add lsattr program to autodetect
    hardware.module.bin_path['lsattr'] = '/usr/bin/lsattr'

    # Call get_device_facts method
    hardware.get_device_facts()

    # Check device scsi0 is present in facts
    assert 'scsi0' in facts['devices']
    # Check device scsi0 state
    assert facts['devices']['scsi0']['state'] == 'Available'
    # Check device scsi0 type

# Generated at 2022-06-22 22:59:29.128203
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    args = {}
    args['ansible_facts'] = {}
    args['ansible_facts']['ansible_system'] = 'AIX'
    hw = AIXHardware(args)

    for key in hw.facts.keys():
        assert key in hw.facts

# Generated at 2022-06-22 22:59:36.214424
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModuleMock()
    module.run_command = AnsibleModuleMock.run_command
    hw_collector = AIXHardwareCollector(module)
    hw_facts = hw_collector.collect()
    assert 'client' in hw_facts
    assert hw_facts['client'] == 'AIXHardware'


# Generated at 2022-06-22 22:59:39.754718
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    ah = AIXHardware(module)
    device_facts = ah.get_device_facts()
    assert device_facts['devices'] != {}


# Generated at 2022-06-22 22:59:51.779668
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    test_module = AnsibleModule(argument_spec={})
    test_module.params = {}
    test_module.run_command = MagicMock(return_value=('', 'IBM,8238-E8F\n', ''))
    test_module.get_bin_path = MagicMock(return_value=True)
    test_module.run_command = MagicMock(return_value=('', ' type PowerPC_POWER8', ''))
    test_module.run_command = MagicMock(return_value=('', ' DFLT_TUNE                        yes', ''))
    test_module.run_command = MagicMock(return_value=('', 'Machine Serial Number: 129C129C', ''))

# Generated at 2022-06-22 22:59:58.785706
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    mymodule = AnsibleModuleMock()
    mymodule.run_command.return_value = (0,
                                         "firmware_version IBM,770.620.0205.00.11232019.1120.[a]:ISERIES-ENTERPRISE-V7R2M0",
                                         "")
    mymodule.get_bin_path.return_value = '/usr/sbin/lsconf'
    mymodule.run_command.return_value = (0,
                                         """
System Model: IBM,8203-E4A
Machine Serial Number: XXXXXXXXX
                         """,
                                         "")
    hardware = AIXHardware(module=mymodule)
    dmi_facts = hardware.get_dmi_facts()


# Generated at 2022-06-22 23:00:09.154743
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():

    import os
    import sys
    import json
    import unittest
    import subprocess
    import platform

    from ansible.module_utils.facts.hardware.aix import AIXHardware

    class TestAIXHardware(unittest.TestCase):

        def setUp(self):
            os.environ['PATH'] = '/usr/sbin:/usr/bin:/sbin:/bin'
            memory_facts = {'memtotal_mb': 4096, 'memfree_mb': 2048, 'swaptotal_mb': 0, 'swapfree_mb': 0}
            cpu_facts = {'processor': ['PowerPC_POWER8'], 'processor_cores': 4, 'processor_count': 2}

# Generated at 2022-06-22 23:00:13.832824
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)

    assert hardware.platform == 'AIX'

# Unit Test for function populate() of class AIXHardware

# Generated at 2022-06-22 23:00:22.428785
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.hardware.aix import AIXHardware

    module = AnsibleModule(
        argument_spec=dict(gather_subset=dict(default=[], type='list')))

    # Get hardware facts
    facts = Facts(module)
    hardware_collector = AIXHardware(module)
    facts.populate(hardware_collector)
    results = facts.get_facts()

    # AIX hardware facts should have the following fields
    assert 'memfree_mb' in results['hardware'], 'memfree_mb should be in aix hardware facts'
    assert 'memtotal_mb' in results['hardware'], 'memtotal_mb should be in aix hardware facts'

# Generated at 2022-06-22 23:00:23.799995
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module=module)
    hardware.get_mount_facts()



# Generated at 2022-06-22 23:00:35.383459
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec=dict())
    AIX_facts_collector = AIXHardwareCollector(module)

    # value of lsdev command output
    lsdev_cmd_out = '''
hdisk97 Available cfggen -
memory memory -
scsi0 Available
scsi3 Available
vscsi0 Available Virtual SCSI Client Adapter
vscsi1 Available Virtual SCSI Client Adapter'''

    set_module_args({})

    with patch('ansible.module_utils.facts.hardware.aix.AIXHardware.run_command') as run_command_mock:
        run_command_mock.return_value = (0, lsdev_cmd_out, None)
        AIX_facts_collector._collect()
        assert run_command_mock.call_count == 1
        # value

# Generated at 2022-06-22 23:00:47.721198
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    testModule = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )
    testModule.params = {}

    testObj = AIXHardware(testModule)
    testObj.module = testModule

    facts = testObj.get_vgs_facts()


# Generated at 2022-06-22 23:00:53.919261
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(dict())
    fact_module = AIXHardware(module)
    cpu_facts = fact_module.get_cpu_facts()
    print("get_cpu_facts = {0}".format(cpu_facts))
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor'] == 'PowerPC_POWER8'
    assert cpu_facts['processor_cores'] == 1



# Generated at 2022-06-22 23:01:00.898510
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module=module)
    hardware.populate()

    assert hardware.facts['firmware_version'] == "1.3"
    assert hardware.facts['product_serial'] == "SERIAL"
    assert hardware.facts['lpar_info'] == "LPAR INFO"
    assert hardware.facts['product_name'] == "PRODUCT NAME"


# Generated at 2022-06-22 23:01:07.010632
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['firmware_version'] == ''
    assert dmi_facts['product_serial'] == ''
    assert dmi_facts['lpar_info'] == ''
    assert dmi_facts['product_name'] == ''



# Generated at 2022-06-22 23:01:08.451955
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hw = AIXHardware({})
    assert hw.platform == 'AIX'

# Generated at 2022-06-22 23:01:21.070184
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():

    class ModuleStub:
        def run_command(self, cmd):
            if cmd == '/usr/sbin/lsattr -El sys0 -a fwversion':
                output = 'fwversion IBM,9117-MMB,06F0F48'
            elif cmd == '/usr/sbin/lsconf':
                output = 'Machine Serial Number\n: 1A\nLPAR Info: 1\n: 2\nSystem Model: 3\n: 4'
            else:
                output = ''
            return 0, output, ''

        def get_bin_path(self, cmd):
            if cmd == "lsvg":
                return '/usr/sbin/lsvg'
            elif cmd == "xargs":
                return '/bin/xargs'

# Generated at 2022-06-22 23:01:33.200635
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    """Test the device facts retrieval of the AIX hardware class"""

    # install AIX hardware
    module = AnsibleModule(argument_spec={})
    aix_hardware = AIXHardware(module)

    # create lsdev_output

# Generated at 2022-06-22 23:01:42.385215
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    class MockModule():
        def __init__(self):
            self.run_command = lambda cmd: (0, '', '')
            self.get_bin_path = lambda name, required=False: ''

    mock_module = MockModule()

    aix_hardware = AIXHardware(mock_module)

    dmi_facts = aix_hardware.get_dmi_facts()

    assert dmi_facts['firmware_version'] == ''
    assert dmi_facts['product_serial'] == ''
    assert dmi_facts['lpar_info'] == ''


# Generated at 2022-06-22 23:01:45.184083
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hc = AIXHardwareCollector()
    assert hc._platform == 'AIX'
    assert hc._fact_class == AIXHardware


# Generated at 2022-06-22 23:01:50.940825
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    # Initialize test environment
    hardware_collector = AIXHardwareCollector(dict())

    # Assert that hardware_collector is not None and is of type AIXHardwareCollector
    assert hardware_collector is not None
    assert isinstance(hardware_collector, HardwareCollector)

# Generated at 2022-06-22 23:01:59.933251
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import hash_params

    # define lsdev and lsvg mock
    import os
    import shutil
    import tempfile

    def mock_module_get_bin_path(module, name, required=True):
        return os.path.join(tempdir, name)


# Generated at 2022-06-22 23:02:11.300613
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    import sys
    from ansible.module_utils._text import to_bytes

    # First set the module path to ansible.module_utils.facts.hardware.aix
    # This is to test the method with the file setup_module_object which
    # is the base class method that has been called in the module_init function
    # of AIXHardware, so that the module_utils.facts.hardware.aix can be found
    # when the self.module.get_bin_path() function is called within this method
    sys.path.insert(1, 'lib/ansible/module_utils/facts/hardware')

    from ansible.module_utils.facts.hardware.aix import AIXHardware
    test_device_facts = {}
    test_device_facts['devices'] = {}

# Generated at 2022-06-22 23:02:14.003425
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    cpu_facts = AIXHardware().get_cpu_facts()
    assert cpu_facts['processor_count'] >= 0


# Generated at 2022-06-22 23:02:16.240092
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    """Test constructor of class AIXHardwareCollector"""
    AIXHardwareCollector()

# Generated at 2022-06-22 23:02:26.450081
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec=dict())

    # monkey patch module.run_command
    # For each path we will give back a specific 'mount' output
    def run_command_mock(cmd, **kwargs):
        # Return none in case of lsblk
        if cmd.startswith('lsblk'):
            return 0, None, None
        # No mount path
        if cmd == 'mount':
            return 0, '', ''
        # Normal mount
        if cmd == 'mount | grep "/mount_point_1"':
            return 0, '/mount_point_1 on /mount_point_1 type ext4 (rw,relatime,data=ordered)', ''
        # NFS mount

# Generated at 2022-06-22 23:02:29.583027
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
  hc = AIXHardwareCollector()
  assert hc._platform == 'AIX', 'Failed test_AIXHardwareCollector'

# Generated at 2022-06-22 23:02:39.057618
# Unit test for method get_device_facts of class AIXHardware

# Generated at 2022-06-22 23:02:49.429961
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    vgs_facts = AIXHardware().get_vgs_facts()

# Generated at 2022-06-22 23:02:50.885433
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    # instance of class AIXHardware
    ah = AIXHardware()



# Generated at 2022-06-22 23:02:59.508377
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    args = {
        'ANSIBLE_MODULE_ARGS': {
            'gather_subset': 'all',
            'gather_timeout': 10,
        },
    }


# Generated at 2022-06-22 23:03:00.994976
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    assert AIXHardwareCollector._platform == 'AIX'
    assert AIXHardwareCollector._fact_class == AIXHardware

# Generated at 2022-06-22 23:03:10.677252
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils._text import to_bytes

    device_facts = AIXHardware().get_device_facts()

    if device_facts:
        devices_content = get_file_content('/usr/sbin/lsdev')
        assert devices_content['content'] is not None
        assert to_bytes(devices_content['content']) in to_bytes(device_facts.get('devices'))
    else:
        assert False

# Generated at 2022-06-22 23:03:18.766818
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    test_module = type('', (), {})()

    test_module.run_command = lambda x: (0, '', '')

    test_module.get_bin_path = lambda x: '/usr/bin/%s' % x

    test_facts = AIXHardware()
    test_facts.module = test_module
    test_facts.populate()

    vgs_facts = test_facts.get_vgs_facts()

    assert vgs_facts['vgs']['rootvg'][0]['pp_size'] == '128 megabyte(s)'
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs_facts['vgs']['testvg'][1]['pv_state'] == 'active'

# Generated at 2022-06-22 23:03:31.051985
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    from ansible.module_utils.facts.hardware.ibm import AIXHardware

# Generated at 2022-06-22 23:03:41.388099
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    """ Unit test for method get_dmi_facts of class AIXHardware """
    aixhardware = AIXHardware()
    lsconf_path = aixhardware.module.get_bin_path("lsconf")
    lsattr_path = aixhardware.module.get_bin_path("lsattr")
    if lsconf_path and lsattr_path:
        # Set up the output of lsattr command. Value of firmware_version attribute is set to
        # None to test the case that the attribute does not exist.
        lsattr_out = 'firmware_version: None'
        # Set up the output of lsconf command. This is a sample output which is often
        # returned by lsconf for an AIX machine.

# Generated at 2022-06-22 23:03:51.378970
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    hardware_facts = hardware.populate()
    keys = """
        processor_cores
        processor_count
        processor
        memtotal_mb
        memfree_mb
        swapfree_mb
        swaptotal_mb
        firmware_version
        lpar_info
        product_name
        product_serial
        vgs
        mounts
        devices
    """.split()
    for key in keys:
        assert key in hardware_facts
