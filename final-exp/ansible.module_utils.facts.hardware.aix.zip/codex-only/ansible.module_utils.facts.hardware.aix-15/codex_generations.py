

# Generated at 2022-06-22 22:53:54.174524
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts.utils import get_file_content
    result = {}
    result['ansible_facts'] = {}
    result['ansible_facts']['hardware'] = {}
    tmp_aixhardware = AIXHardware()
    result['ansible_facts']['hardware']['devices'] = {}

    # Test get_device_facts with no devices
    tmp_aixhardware.module = MockModule()
    mock_run_command = Mock(return_value=(0, to_text(get_file_content('./unit/ansible/module_utils/facts/hardware/aix/lsdev-unit1')), ''))
    tmp_aixhardware.module.run_command = mock_run_command



# Generated at 2022-06-22 22:54:01.816999
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec=dict())
    # for testing only
    module.run_command = MagicMock(return_value=(0, 'lsvg -o\nrootvg\nrealsyncvg\ntestvg', ''))

# Generated at 2022-06-22 22:54:03.570863
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    instance = AIXHardwareCollector()
    assert instance != None


# Generated at 2022-06-22 22:54:09.858922
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    facts = hardware.get_memory_facts()
    assert isinstance(facts.get('memfree_mb'), int)
    assert isinstance(facts.get('memtotal_mb'), int)
    assert isinstance(facts.get('swapfree_mb'), int)
    assert isinstance(facts.get('swaptotal_mb'), int)



# Generated at 2022-06-22 22:54:20.623155
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    class args:
        def __init__(self):
            self.shell = '/bin/sh'

    class tmpmodule:
        def __init__(self):
            self.run_command = tmpmodule.run_command
            self.params = args()


# Generated at 2022-06-22 22:54:24.029259
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    """Validate the constructor for AIXHardwareCollector"""
    hw = AIXHardwareCollector()
    if hw._platform != 'AIX':
        raise AssertionError('Expected _platform to be "AIX"')
    if hw._fact_class != AIXHardware:
        raise AssertionError('Expected _fact_class to be "AIXHardware"')

if __name__ == '__main__':
    # Unit test for constructor of class AIXHardwareCollector
    test_AIXHardwareCollector()

# Generated at 2022-06-22 22:54:36.122664
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    import sys
    import os
    import shutil
    import tempfile
    import json
    from ansible.module_utils import facts
    from ansible.module_utils.facts.hardware.aix import AIXHardware

    # Create mock module
    test_dir = tempfile.mkdtemp()
    sys.modules['ansible.module_utils.facts'] = facts
    sys.modules['ansible.module_utils.facts.hardware'] = facts.hardware
    sys.modules['ansible.module_utils.facts.hardware.aix'] = facts.hardware.aix
    shutil.copyfile(os.path.join(test_dir, '../test_data/test_files/aix/lsdev'), os.path.join(test_dir, 'lsdev'))

# Generated at 2022-06-22 22:54:39.214525
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware_obj = AIXHardware(module)
    hardware_obj.populate()
    assert hardware_obj.memtotal_mb != 0



# Generated at 2022-06-22 22:54:51.050303
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    """unit test for method get_memory_facts of class AIXHardware"""
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    test_class = AIXHardware(module)
    out = test_class.get_memory_facts()

    assert isinstance(out, dict)
    assert 'memtotal_mb' in out
    assert out['memtotal_mb'] >= 0
    assert 'memfree_mb' in out
    assert out['memfree_mb'] >= 0
    assert 'swaptotal_mb' in out
    assert out['swaptotal_mb'] >= 0
    assert 'swapfree_mb' in out
    assert out['swapfree_mb'] >= 0



# Generated at 2022-06-22 22:54:59.544479
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(
        argument_spec=dict()
    )
    hardware_collector = AIXHardwareCollector(module=module)
    hardware_facts = hardware_collector.collect()

    assert hardware_facts['firmware_version'] is not None
    assert hardware_facts['product_serial'] is not None
    assert hardware_facts['lpar_info'] is not None
    assert hardware_facts['product_name'] is not None

    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['processor_cores'] >= 1


# Generated at 2022-06-22 22:55:04.595138
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware = AIXHardware({'module_name': 'test'})

    #Test constructor
    assert hardware.module.params['module_name'] == 'test'

    #Test populate method
    assert hardware.populate() is None
    #TODO: Improve testing here...
    #assert hardware.populate().__class__.__name__ == 'dict'

# Generated at 2022-06-22 22:55:15.110203
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():

    class TestModule():
        def run_command(self, cmd, check_rc=True):
            if 'lsvg -o | xargs lsvg -p' in cmd:
                rc = 0

# Generated at 2022-06-22 22:55:27.081767
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module_mock = AnsibleModuleMock({'module_name': 'test_module'})
    module_mock.run_command = MagicMock(return_value=('0', 'hdisk0 Available 00-00-4b-4a-43-30', ''))
    module_mock.get_bin_path = MagicMock(return_value='/usr/bin/lsdev')

    test_hardware = AIXHardware()
    test_hardware.module = module_mock
    test_hardware.populate()
    device_facts = test_hardware._device_facts

    # get_device_facts return device_facts
    assert isinstance(device_facts, dict)
    assert isinstance(device_facts['devices'], dict)
    assert 'hdisk0' in device_facts['devices']
   

# Generated at 2022-06-22 22:55:36.267139
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():

    module = AnsibleModule(argument_spec={})

    ansible_facts = {
        "ansible_facts": {
            "ansible_hostname": "test123",
            "ansible_distribution": "AIX",
            "ansible_system": "AIX",
            "ansible_distribution_version": "7.2.1.0"
        }
    }

    ah = AIXHardware(module=module)
    ah.populate(ansible_facts)


# Generated at 2022-06-22 22:55:46.329902
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    """
    Unit test for method get_mount_facts of class AIXHardware
    """

    module = AnsibleModule(
        argument_spec=dict()
    )

    base = AIXHardware(module)
    res = base.get_mount_facts()
    assert res['mounts'][0]['mount'] == '/'
    assert res['mounts'][0]['device'] == '/dev/hd4'
    assert res['mounts'][0]['fstype'] == 'jfs2'
    assert res['mounts'][0]['options'] == 'log=INLINE'
    assert res['mounts'][0]['size_total'] == 217759744
    assert res['mounts'][0]['size_available'] == 83884288



# Generated at 2022-06-22 22:55:53.646219
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    """Test method populate of class AIXHardware
    """
    module = type('module', (), {})()
    dummy_args = []

    dummy_system_module = type('module', (), {'run_command': lambda self, cmd: (0, cmd, '')})
    system_module = dummy_system_module()
    module.run_command = system_module.run_command

    module.get_bin_path = lambda dummy: '/bin/' + dummy

    aix_hardware = AIXHardware(module, dummy_args)
    result = aix_hardware.populate()

    assert result is not None

# Generated at 2022-06-22 22:56:00.947084
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = type('AnsibleModule', (object,), {'run_command': run_command})
    module.get_bin_path = lambda _: '/usr/bin/lsdev'
    hardware_facts = AIXHardware(module)
    

# Generated at 2022-06-22 22:56:08.548530
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    """
    AIXHardware - populate
    """
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    hardware = AIXHardware(module=module)
    hardware.populate()
    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['processor'] == 'POWER8'
    assert hardware.facts['memtotal_mb'] == 32759
    assert hardware.facts['memfree_mb'] == 629
    assert hardware.facts['swaptotal_mb'] == 512
    assert hardware.facts['swapfree_mb'] == 2
    assert hardware.facts['processor_cores'] == 4
    assert hardware.facts['firmware_version'] == 'SF240_277'
    assert hardware.facts['product_serial'] == '101137Z'

# Generated at 2022-06-22 22:56:18.353996
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    test_class = AIXHardware()

    test_class.module = MockModule()

    test_class.module.run_command = Mock(return_value=("0", "/4 kB", ""))
    test_class.module.run_command = Mock(return_value=("0", "memory pages\t2097152\n"
                                                             "free pages\t1155625\n", ""))
    test_class.module.run_command = Mock(return_value=("0", "Device\t\t1M-blocks     Used    Avail Capacity\n"
                                                             "/dev/ada0p3\t\t314368        0   314368     0%", ""))

# Generated at 2022-06-22 22:56:25.715848
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    fact_aixhw = AIXHardware(module)
    result = fact_aixhw.get_dmi_facts()
    assert isinstance(result, dict)
    assert result["product_name"] == "IBM,9131-52A"
    assert result["product_serial"] == "0595B3B"
    assert result["firmware_version"] == "T1A050"


# Generated at 2022-06-22 22:56:32.525327
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec=dict()
    )
    hardware = AIXHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_cores'] > 0
    assert len(cpu_facts['processor']) > 0


# Generated at 2022-06-22 22:56:44.343862
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():

    # load the module for fake ansible module testing
    import ansible.module_utils.facts.hardware.aix.aix_hardware_module

    # initialize the module
    module = ansible.module_utils.facts.hardware.aix.aix_hardware_module.AIXHardware()

    # initialize the AIXHardware class
    aix_hardware = AIXHardware(module)

    # call the function get_memory_facts of the class AIXHardware
    result = aix_hardware.get_memory_facts()

    # check the result
    assert type(result) is dict
    assert 'memfree_mb' in result
    assert 'memtotal_mb' in result
    assert 'swapfree_mb' in result
    assert 'swaptotal_mb' in result



# Generated at 2022-06-22 22:56:52.421563
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = AIXHardware(module)


# Generated at 2022-06-22 22:56:58.332337
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    """
    (unit test)
    - test the vgs facts
    """
    module = AnsibleModule(argument_spec={})
    aix_hardware = AIXHardware(module=module)
    vgs_facts = aix_hardware.get_vgs_facts()
    assert 'vgs' in vgs_facts and len(vgs_facts['vgs'].keys()) != 0


# Generated at 2022-06-22 22:57:10.458902
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    import os
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    os.environ['PATH'] = '/bin:/usr/bin:/usr/sbin'
    a = AIXHardware()
    a.module = MockAnsibleModule()
    a.module.run_command = _run_command
    data = a.get_device_facts()

# Generated at 2022-06-22 22:57:18.692714
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule({})
    hardware = AIXHardware(module)
    vgs_facts = hardware.get_vgs_facts()

    assert 'vgs' in vgs_facts
    assert 'rootvg' in vgs_facts['vgs']
    assert len(vgs_facts['vgs']['rootvg']) == 2
    assert 'hdisk105' in [v['pv_name'] for v in vgs_facts['vgs']['testvg']]
    assert '200' in [v['free_pps'] for v in vgs_facts['vgs']['testvg'] if v['pv_name'] == 'hdisk105']



# Generated at 2022-06-22 22:57:22.108872
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={})
    facts = AIXHardware(module).populate()
    assert 'memfree_mb' in facts
    assert 'memtotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'firmware_version' in facts
    assert 'product_serial' in facts
    assert 'product_name' in facts
    assert 'vgs' in facts
    assert 'mounts' in facts
    assert 'devices' in facts

# Generated at 2022-06-22 22:57:32.995213
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    test_mod = AnsibleModule(argument_spec={}, supports_check_mode=False)
    test_obj = AIXHardware(module=test_mod)
    test_obj._module.run_command = run_command_mock
    tests = [
        (run_command_mock.COMMAND_LSATTR_EL_SYS0_A_FWVERSION_OUT_NORMAL,
         {'firmware_version': 'IBM,970R7DP',
         }),
        (run_command_mock.COMMAND_LSATTR_EL_SYS0_A_FWVERSION_OUT_DEGRADED,
         {}),
        ('',
         {})
    ]
    for dmi_out, expected_dmi_facts in tests:
        run_command_mock.set_command

# Generated at 2022-06-22 22:57:42.719571
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    lsdev_output = """ent0 Available 00-08-0E-6C-69-8A Ethernet IVE
hdisk0 Defined 01-08-33-C5-E2-00-00-00
cd0 Defined 0E-08-33-C5-E2-00-00-00
dac0 Defined 01-08-33-C5-E2-00-00-00"""


# Generated at 2022-06-22 22:57:49.929126
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    """
    Unit test for method get_vgs_facts of class AIXHardware
    """
    test_module = AnsibleModule(argument_spec={})
    test_obj = AIXHardware(module=test_module)
    test_out = test_obj.get_vgs_facts()
    assert test_out['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert test_out['vgs']['testvg'][1]['pv_state'] == 'active'
    assert test_out['vgs']['testvg'][1]['total_pps'] == '999'
    assert test_out['vgs']['testvg'][1]['free_pps'] == '599'

# Generated at 2022-06-22 22:58:00.574740
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    aixhw = AIXHardware()
    aix_vgs_facts = aixhw.get_vgs_facts()

# Generated at 2022-06-22 22:58:12.392916
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hostname = AIXHardware()
    memory_facts = hostname.get_memory_facts()
    assert hostname
    assert memory_facts
    assert memory_facts['memtotal_mb']
    assert memory_facts['memfree_mb']
    cpu_facts = hostname.get_cpu_facts()
    assert cpu_facts
    assert cpu_facts['processor_cores']
    assert cpu_facts['processor_count']
    assert cpu_facts['processor']
    dmi_facts = hostname.get_dmi_facts()
    assert dmi_facts
    assert dmi_facts['firmware_version']
    assert dmi_facts['product_serial']
    assert dmi_facts['lpar_info']
    assert dmi_facts['product_name']
    vgs_facts = hostname.get_v

# Generated at 2022-06-22 22:58:23.999713
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    module = AnsibleModule({})
    hardware_collector = AIXHardware(module)
    facts = hardware_collector.populate()
    assert(facts['processor'] == 'POWER7')
    assert(facts['processor_cores'] == 4)
    assert(facts['processor_count'] == 4)
    assert(facts['memtotal_mb'] == 16615)
    assert(facts['memfree_mb'] == 508)
    assert(facts['firmware_version'] == 'V7R1M0')
    assert(facts['product_name'] == 'IBM,8408-E8D')

# Generated at 2022-06-22 22:58:24.904485
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    assert AIXHardware(dict())

# Generated at 2022-06-22 22:58:29.492135
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    # Get test data from yaml file
    test_data = load_fixture('AIXHardware_populate')

    # create instance of class AIXHardware and call populate
    hardware = AIXHardware()
    result = hardware.populate()

    # check test data and result
    assert test_data == result


# Generated at 2022-06-22 22:58:38.170373
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    import sys
    import os
    import unittest
    import tempfile
    # used as fake input to lsps -s

# Generated at 2022-06-22 22:58:41.040985
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    assert AIXHardwareCollector(None)._fact_class == AIXHardware


# Generated at 2022-06-22 22:58:52.677338
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    # Set module to fake
    module = AnsibleModule(argument_spec={},
                           supports_check_mode=True)

    # With the module fake, all the commands we run will return rc == 0
    module.run_command = fake_run_command

    # Create AIXHardware instance and add the module for use in the class
    hardware = AIXHardware(module=module)
    hardware.module = module

    # Set the return value of the fake command

# Generated at 2022-06-22 22:59:02.733335
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    class ModuleStub(object):
        def __init__(self):
            self.bin_path = None

        def get_bin_path(self, name, required=False):
            return self.bin_path

        def run_command(self, cmd, use_unsafe_shell=False):
            if 'lsattr -El sys0 -a fwversion' in cmd:
                return 0, "fwversion IBM,8247-22L", ""
            elif '/usr/sbin/lsconf' in cmd:
                return 0, "Machine Serial Number: 111222333\n"

# Generated at 2022-06-22 22:59:11.362522
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module=module)
    result = hardware.get_mount_facts()

    assert result is not None
    assert result != {}
    assert type(result) == dict
    assert 'mounts' in result
    assert type(result['mounts']) == list
    assert len(result['mounts']) > 0
    assert 'mount' in result['mounts'][0]
    assert 'device' in result['mounts'][0]
    assert 'fstype' in result['mounts'][0]
    assert 'options' in result['mounts'][0]
    assert 'time' in result['mounts'][0]


# Generated at 2022-06-22 22:59:22.628369
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = FakeAnsibleModule()
    module.params = {}
    module.params['gather_subset'] = 'all'
    module.run_command = run_command
    hardware_obj = AIXHardware(module)

# Generated at 2022-06-22 22:59:24.014680
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    mod = None
    AIXHardwareCollector(mod)

# Generated at 2022-06-22 22:59:30.487778
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    import sys

    module = sys.modules['ansible.module_utils.facts.hardware.aix']
    c = module.AIXHardware()

    facts = c.get_dmi_facts()
    # facts = { 'firmware_version': '',
    #    'product_serial': '',
    #    'lpar_info': '',
    #    'product_name': '' }
    assert facts['firmware_version']
    assert facts['product_serial']
    assert facts['lpar_info']
    assert facts['product_name']

# Generated at 2022-06-22 22:59:36.630627
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    facts = AIXHardware()
    cpu_facts = facts.get_cpu_facts()
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_count'] != 2
    assert cpu_facts['processor'] == "PowerPC_POWER7"
    assert cpu_facts['processor'] != "PowerPC_POWER9"
    del cpu_facts


# Generated at 2022-06-22 22:59:40.987281
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    """
    Unit test for get_cpu_facts in AIXHardware
    """

    facts = AIXHardware()
    cpu_facts = facts.get_cpu_facts()
    assert cpu_facts['processor'] is not None
    assert cpu_facts['processor_cores'] > 0
    assert cpu_facts['processor_count'] > 0



# Generated at 2022-06-22 22:59:52.846714
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    import os
    class TestModule(object):
        def __init__(self):
            self.run_command_calls = []

        def run_command(self, args, use_unsafe_shell=False):
            self.run_command_calls.append(args)
            if args == "vmstat -v":
                out = "memory pages:     8383520\nfree pages:      1405868\nfree memory         580751736\n"
            elif args == "lsps -s":
                out = "Total Paging Space Percent Used  : 0%\n"
            else:
                raise Exception("unexpected lsps -s")

            return (0, out, "")

        def get_bin_path(self, arg, required=False):
            return "/usr/bin/" + arg

# Generated at 2022-06-22 23:00:03.342104
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec=dict())
    hardware = AIXHardware(module)


# Generated at 2022-06-22 23:00:12.559419
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    test_args = {'ANSIBLE_MODULE_ARGS': {}}
    test_mock = {'/usr/sbin/lsdev -Cc processor': (0, 'proc0 Available 00-00 Processor\nproc1 Available 00-01 Processor'),
                 '/usr/sbin/lsattr -El proc0 -a type': (0, 'type PowerPC_POWER7'),
                 '/usr/sbin/lsattr -El proc0 -a smt_threads': (0, 'smt_threads 2'),
                 }

    test_hw = AIXHardware(mock=test_mock, module_args=test_args)

    test_cpu_facts = test_hw.get_cpu_facts()

# Generated at 2022-06-22 23:00:21.762566
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = type('', (object,), dict(run_command=lambda cmd, check_rc=True, close_fds=True: (0, '', '')))()
    AIXHardware.module = module
    hardware_facts = AIXHardware()
    module.run_command = lambda cmd, check_rc=True, close_fds=True: (0, "sys0          IBM,9117-MMB       F101040A    IBM,037G3502    IBM,9117-MMB       x86/x86_64", "")
    assert hardware_facts.get_dmi_facts() == {'firmware_version': 'F101040A'}
    module.run_command = lambda cmd, check_rc=True, close_fds=True: (0, 'Machine Serial Number:123456', '')

# Generated at 2022-06-22 23:00:29.528706
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    aix_hw=AIXHardware()
    aix_hw.module=Mock()
    aix_hw.module.run_command.return_value=(0, 'value', None)
    aix_hw.module.get_bin_path.return_value='/usr/sbin/lsconf'
    dmi_facts={'firmware_version': 'value', 'lpar_info': 'value',
               'product_name': 'value', 'product_serial': 'value'}
    assert aix_hw.get_dmi_facts()==dmi_facts



# Generated at 2022-06-22 23:00:37.512792
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    test_module = MockAnsibleModule()
    test_module.run_command = Mock()

# Generated at 2022-06-22 23:00:47.059437
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    hardware_obj = AIXHardware(module=module)
    module.exit_json(changed=False, ansible_facts=dict(ansible_hardware=hardware_obj.populate()))


# Ansible Module Boilerplate
from ansible.module_utils.basic import *
main = AnsibleModule(
    argument_spec=dict(),
    supports_check_mode=True
)
main.exit_json(changed=False, ansible_facts=dict(ansible_hardware=AIXHardware(module=main).populate()))

# Generated at 2022-06-22 23:00:56.299251
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec={}
    )

    hardware_obj = AIXHardware(module)
    result = hardware_obj.get_cpu_facts()
    assert result['processor_count'] == 1
    assert result['processor'] == 'PowerPC_POWER7'
    assert result['processor_cores'] == 1

    module = AnsibleModule(
        argument_spec={}
    )
    del os.environ['LC_ALL']
    del os.environ['LANG']
    os.environ['LC_ALL'] = 'en_IN'
    os.environ['LANG'] = 'en_IN'

    hardware_obj = AIXHardware(module)
    result = hardware_obj.get_cpu_facts()
    assert result['processor_count'] == 1

# Generated at 2022-06-22 23:01:07.928890
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = MagicMock()
    module.run_command.return_value = 0, '', ''
    module.params = {}
    module.params['gather_subset'] = ['all']

    module.get_bin_path = MagicMock(return_value='/usr/bin/lsdev')
    device_facts = AIXHardware().get_device_facts()
    assert device_facts == {u'devices': {}}

    module.run_command.return_value = 0, 'aes0 Available 09-08 T10 RISC AES Accelerator', ''
    device_facts = AIXHardware().get_device_facts()
    assert device_facts['devices']['aes0']['state'] == 'Available'


# Generated at 2022-06-22 23:01:20.637549
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    import os

    class MockModule(object):
        def __init__(self, bin_path=None):
            self.params = {}
            self.bin_path = bin_path

        def get_bin_path(self, cmd, opt_dirs=[]):
            return os.path.join(self.bin_path, cmd)

        def run_command(self, cmd, use_unsafe_shell=False):
            if 'mount' in cmd:
                return 0, "node mounted mounted_on vfs nfs/cifs_server:share time", None

        def fail_json(self, **kwargs):
            raise Exception(kwargs)

    # Mock /usr/sbin/mount

# Generated at 2022-06-22 23:01:25.771562
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    aix_hardware = AIXHardware(dict(module=None))
    result = aix_hardware.get_memory_facts()
    assert result.has_key('memtotal_mb')
    assert result.has_key('memfree_mb')
    assert result.has_key('swaptotal_mb')
    assert result.has_key('swapfree_mb')


# Generated at 2022-06-22 23:01:31.017636
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    m = dict(
        module=dict(
            run_command=run_command
        )
    )
    aix_facts = AIXHardware(m)
    aix_facts.populate()
    print(aix_facts.data)



# Generated at 2022-06-22 23:01:38.639611
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    class FakeModule(object):
        def run_command(self, *args, **kwargs):
            return (0, 'Available 10\nAvailable 10', '')

    mock_module = FakeModule()

    cpu_facts = AIXHardware(mock_module)

    # Test get_cpu_facts()
    assert cpu_facts.get_cpu_facts() == {
        'processor': 'PowerPC_POWER8',
        'processor_count': 2,
        'processor_cores': 10
    }



# Generated at 2022-06-22 23:01:45.548163
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    hardware_facts = AIXHardware()
    facts_dict = hardware_facts.populate()

    assert facts_dict["firmware_version"] == "IBM,8245R12-C"
    assert facts_dict["product_name"] == "8245-42L"
    assert facts_dict["product_serial"] == "06F9134"
    assert facts_dict["lpar_info"] == "1 AONEP00 partition"

# Generated at 2022-06-22 23:01:57.453306
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )

    module.get_bin_path = MagicMock(return_value='/usr/bin/lsdev')
    aixhw = AIXHardware(module)


# Generated at 2022-06-22 23:02:09.716005
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    import sys
    import imp
    import os

    # create a mock module
    test_module = imp.new_module('test_module')
    test_module.params = {}
    test_module.exit_json = lambda **kwargs: sys.exit(0)
    test_module.run_command = lambda *args, **kwargs: (0, '', '')
    test_module.fail_json = lambda **kwargs: sys.exit(1)
    test_module.get_bin_path = lambda *args, **kwargs: os.path.join(os.path.dirname(__file__), 'data/bin/lsdev')
    sys.modules['ansible.module_utils.basic'] = test_module
    sys.modules['ansible.modules.system.hardware'] = test_module
    globals()

# Generated at 2022-06-22 23:02:19.172752
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModuleMock()
    hardware = AIXHardware(module)

    cmd_out = """proc0 Available 00-00 Processor
    proc1 Available 00-01 Processor
    proc2 Available 00-02 Processor
    proc3 Available 00-03 Processor"""

    hardware._run_command = MagicMock()
    hardware._run_command.return_value = True, cmd_out, ''

    hardware.get_cpu_facts()
    assert {'processor': ['PowerPC_POWER7'],
            'processor_count': 4,
            'processor_cores': 2} == hardware.facts



# Generated at 2022-06-22 23:02:21.860564
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    AIXHardware_obj = AIXHardware()
    vgs_facts = AIXHardware_obj.get_vgs_facts()



# Generated at 2022-06-22 23:02:24.498537
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    test_AIXhc = AIXHardwareCollector()
    assert test_AIXhc.platform == 'AIX'
    assert test_AIXhc.fact_class == AIXHardware

# Generated at 2022-06-22 23:02:30.468253
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    facts = {
        'device': '/dev/aixlv01',
        'fstype': 'jfs2',
        'mount': '/test/mount',
        'options': 'rw,log=/dev/hd8'
    }
    h = AIXHardware(dict())

    assert facts == h.get_mount_facts()['mounts'][0]

# Generated at 2022-06-22 23:02:31.312942
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    pass

# Generated at 2022-06-22 23:02:40.238085
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    import pytest
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts import Fact
    import json

    module_mock = Fact({})
    module_mock.get_bin_path = Fact({}).get_bin_path
    module_mock.run_command = lambda path, use_unsafe_shell=True: (0, json.dumps(FAKE_COMMAND_OUTPUT), '')
    aix_hardware_mock = AIXHardware(module_mock)
    device_facts = aix_hardware_mock.get_device_facts()
    assert device_facts['devices']['fcs0']['type'] == 'IBM,2109 Fibre Channel Adapter'

# Generated at 2022-06-22 23:02:45.023783
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModuleMock()
    module.run_command = run_command_results
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    test_obj = AIXHardware(module=module)
    cpu_facts = test_obj.get_cpu_facts()
    assert(cpu_facts == cpu_facts_expected)



# Generated at 2022-06-22 23:02:54.001293
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModuleMock()
    aix_hardware = AIXHardware(module)

    # successful run
    out = """
    sys0        IBM,7028-6C1     HMC managed
    """
    aix_hardware.module.run_command.return_value = (0, out, '')
    dmi_facts = aix_hardware.get_dmi_facts()
    assert dmi_facts == {'firmware_version': '7028-6C1'}

    # unsuccessful run
    aix_hardware.module.run_command.return_value = (1, '', 'error message')
    dmi_facts = aix_hardware.get_dmi_facts()
    assert dmi_facts == {}



# Generated at 2022-06-22 23:02:58.073189
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    test_module = AnsibleModuleMock()
    res_finder = ResourceFinder()
    fact_collector = AIXHardwareCollector(test_module, res_finder)
    facts_class = AIXHardware(test_module)
    data = facts_class.get_device_facts()
    assert 'devices' in data
    assert data['devices']

# Generated at 2022-06-22 23:02:59.904092
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    m = AIXHardware()
    # no return value so just run to make sure no exceptions are raised
    m.get_mount_facts()

# Generated at 2022-06-22 23:03:05.934997
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    """
    Test that Ansible module sets correct mount facts on AIX platform
    """

    class ModuleStub(object):
        """
        Stub for AnsibleModule class which provides get_bin_path method.
        """
        def __init__(self):
            """
            Constructor for ModuleStub class.
            """

            self.run_command_calls = 0
            self.command = ""
            self.rc = 0
            self.out = ""
            self.err = ""

        def get_bin_path(self, arg, required=False):
            """
            Returns path to binary if it exists in o/s.
            """

            if arg == 'mount':
                return "/usr/sbin/mount"

            if arg == 'lsvg':
                return "/usr/sbin/lsvg"


# Generated at 2022-06-22 23:03:11.750616
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    har = AIXHardware(module)
    cpu_facts = har.get_cpu_facts()

    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'PowerPC_POWER9'
    assert cpu_facts['processor_cores'] == 2



# Generated at 2022-06-22 23:03:12.429890
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    pass

# Generated at 2022-06-22 23:03:13.212221
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    assert AIXHardwareCollector is not None

# Generated at 2022-06-22 23:03:22.287176
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    from ansible.module_utils.facts import Collector

    class MockModule(object):

        def __init__(self, vmstat_out='', lsps_out=''):
            self.run_command = Mock(return_value=(0, vmstat_out, ''))

            self.get_bin_path = Mock(return_value='')
            self.run_command = Mock(return_value=lsps_out)

        def get_bin_path(self, arg, required=False):
            return self.get_bin_path(arg, required)

        def run_command(self, cmd, use_unsafe_shell=False):
            return self.run_command(cmd, use_unsafe_shell)

    fact_collector = Collector(MockModule())

# Generated at 2022-06-22 23:03:31.728496
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware = AIXHardware({})
    assert hardware.get_cpu_facts() == {'processor': 'POWER8', 'processor_count': 2, 'processor_cores': 2}
    assert hardware.get_memory_facts() == {'memtotal_mb': 65536, 'memfree_mb': 65513, 'swaptotal_mb': 10000, 'swapfree_mb': 7240}
    assert hardware.get_dmi_facts() == {'firmware_version': 'IBM,8233-E8B', 'product_serial': '02FD4F4', 'lpar_info': '1', 'product_name': '8233-E8B'}

# Generated at 2022-06-22 23:03:41.864333
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    class ModuleStub:
        def __init__(self, mount_out):
            self.mount_out = mount_out

        def run_command(self, cmd):
            return 0, self.mount_out, ''

    AH = AIXHardware()

    # has no mounts

# Generated at 2022-06-22 23:03:51.805022
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    # input
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'device  mount         fstype    vfs     date        options', None))

    # run
    ansible_module_facts = AIXHardware(module).get_mount_facts()

    # assert
    assert len(ansible_module_facts['mounts']) > 0

    # ran as root and AIX system, ok
    assert ansible_module_facts['mounts'][0]['size_total'] > 0
