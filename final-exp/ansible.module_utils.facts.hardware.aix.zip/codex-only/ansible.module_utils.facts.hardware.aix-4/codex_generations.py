

# Generated at 2022-06-22 22:53:48.273272
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    results = {}
    module = AnsibleModule(argument_spec=dict())
    hw = AIXHardware(module)
    results['AIXHardware'] = hw.populate()
    module.exit_json(**results)



# Generated at 2022-06-22 22:53:58.060749
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():

    class MockModule:
        """Mock module for testing AIXHardware.populate()"""
        def __init__(self):
            self.params = {}

        def run_command(self, cmd, use_unsafe_shell=False):
            data = {}
            data[b'/usr/sbin/lsdev -Cc processor'] = (0, b'proc0 Available 00-00 Processor \nproc1 Available 00-01 Processor \n', '')
            data[b'/usr/sbin/lsattr -El proc0 -a type'] = (0, b' type PowerPC_POWER7 PowerPC_POWER7', None)
            data[b'/usr/sbin/lsattr -El proc0 -a smt_threads'] = (0, b'smt_threads 8 Enabled', None)

# Generated at 2022-06-22 22:54:09.820706
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    hardware = AIXHardware({})
    hardware.module.run_command = lambda *args, **kwargs: (0, '', '')
    hardware.module.run_command = lambda *args, **kwargs: (0, 'memory pages: 677750\nfree pages: 343781', '')
    hardware.module.run_command = lambda *args, **kwargs: (0, 'Device          1M-blocks     Used    Avail Capacity\n/dev/ada0p3        314368        0   314368     0%', '')

    memory_facts = hardware.get_memory_facts()

    assert memory_facts['memtotal_mb'] == 2714
    assert memory_facts['memfree_mb'] == 1351
    assert memory_facts['swaptotal_mb'] == 314

# Generated at 2022-06-22 22:54:20.620476
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={})
    inventory_hostname = 'hostname'
    gathered_subset = ['']
    hardware_collector = AIXHardwareCollector(module, inventory_hostname, gathered_subset)
    hardware_collector.collect()
    facts_dict = hardware_collector.get_facts()
    assert facts_dict['ansible_facts']['ansible_processor_cores'] == 8
    assert facts_dict['ansible_facts']['ansible_processor_count'] == 8
    assert facts_dict['ansible_facts']['ansible_processor'] == ['PowerPC_POWER8']
    assert facts_dict['ansible_facts']['ansible_memtotal_mb'] > 0

# Generated at 2022-06-22 22:54:22.309617
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware = AIXHardware('/etc/redhat-release')
    assert hardware
    assert isinstance(hardware, AIXHardware)


# Generated at 2022-06-22 22:54:23.853367
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware = AIXHardware({})
    assert hardware.platform == 'AIX'

# Generated at 2022-06-22 22:54:35.919865
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = get_fake_module()
    hardware_obj = AIXHardware(module=module)
    lsvg_path = hardware_obj.module.get_bin_path("lsvg")
    xargs_path = hardware_obj.module.get_bin_path("xargs")
    cmd = "%s -o | %s %s -p" % (lsvg_path, xargs_path, lsvg_path)
    rc, out, err = module.run_command(cmd, use_unsafe_shell=True)
    assert rc == 0
    vg_facts = hardware_obj.get_vgs_facts()
    assert vg_facts
    assert vg_facts['vgs']
    assert vg_facts['vgs']['rootvg']

# Generated at 2022-06-22 22:54:38.267431
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    assert AIXHardwareCollector._platform == 'AIX'
    assert AIXHardwareCollector._fact_class == AIXHardware


# Generated at 2022-06-22 22:54:42.890668
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware = AIXHardware()
    assert hardware.platform == 'AIX'
    assert hardware.get_cpu_facts() is not None
    assert hardware.get_memory_facts() is not None
    assert hardware.get_dmi_facts() is not None
    assert hardware.get_vgs_facts() is not None
    assert hardware.get_device_facts() is not None
    assert hardware.get_mount_facts() is not None


# Generated at 2022-06-22 22:54:55.508128
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    from ansible.module_utils.facts.aix import AIXHardware
    import json

    class TestAIXHardware:
        def get_bin_path(self, item, required=False):
            return '/usr/sbin/' + item

        def run_command(self, cmd, use_unsafe_shell=False):
            return 0, out_lsdev, err_lsdev

    test_module = TestAIXHardware()
    aix_hardware = AIXHardware(test_module)

    # sample output of lsdev command

# Generated at 2022-06-22 22:55:07.859821
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModuleMock({})
    plugin = AIXHardware(module=module)

    # This is just a sample, based on output for our test AIX machine.
    # Expected output is:
    # {'devices': {u'hdisk0': {'attributes': {u'max_transfer': u'0x100000', u'pvid':
    # u'00f61e84b9c9eea2', u'queue_depth': u'1', u'status': u'enabled', u'tag': u'rootvg'},
    # 'state': u'Available', u'type': u'Other FC Device'}, u'vscsi0': {'attributes':
    # {u'vscsi_paths': u'2', u'vscsi_type': u'client'}, 'state

# Generated at 2022-06-22 22:55:11.322505
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    platform_fact = AIXHardwareCollector()
    assert platform_fact.platform == 'AIX'
    assert platform_fact._fact_class == AIXHardware

# Generated at 2022-06-22 22:55:24.699975
# Unit test for method get_mount_facts of class AIXHardware

# Generated at 2022-06-22 22:55:31.170847
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    hw = AIXHardware({})
    cpu_facts = hw.get_cpu_facts()
    assert len(cpu_facts) == 3
    assert 'processor' in cpu_facts
    assert 'processor_cores' in cpu_facts
    assert 'processor_count' in cpu_facts
    assert cpu_facts['processor'] == 'POWER8' or cpu_facts['processor'] == 'POWER7+'



# Generated at 2022-06-22 22:55:40.840554
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModuleMock({})
    hardware_facts = AIXHardware(module).populate()

    # test get_cpu_facts
    assert hardware_facts['processor_count'] == 4
    assert hardware_facts['processor'] == 'PowerPC_POWER8'
    assert hardware_facts['processor_cores'] == 4

    # test get_memory_facts
    assert hardware_facts['memtotal_mb'] == 64
    assert hardware_facts['memfree_mb'] == 40
    assert hardware_facts['swaptotal_mb'] == 2048
    assert hardware_facts['swapfree_mb'] == 1948

    # test get_dmi_facts
    assert 'firmware_version' in hardware_facts
    assert 'product_serial' in hardware_facts
    assert 'lpar_info' in hardware_facts

# Generated at 2022-06-22 22:55:46.672034
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    class MockModule(object):
        def __init__(self):
            self.run_command = lambda cmd: (0, out, '')
            self.get_bin_path = lambda cmd: '/usr/bin/{0}'.format(cmd)

    m = MockModule()
    hardware = AIXHardware(m)
    vgs_facts = hardware.get_vgs_facts()

# Generated at 2022-06-22 22:55:51.912540
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec=dict(path='/tmp/mount.out'))
    fp = open(module.params['path'], 'r')
    mount_out = fp.read()
    fp.close()
    hardware = AIXHardware(module)
    mount_facts = hardware.get_mount_facts()
    print("results: " + str(mount_facts))


# Generated at 2022-06-22 22:55:59.566816
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)

    # Test populate function
    hardware_facts = hardware.populate()
    assert hardware_facts is not None, "Get null response for populate"
    assert isinstance(hardware_facts, dict), "Response is not a dictionary"

    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts is not None, "Get null response for get_cpu_facts"
    assert isinstance(cpu_facts, dict), "Response is not a dictionary"

    memory_facts = hardware.get_memory_facts()
    assert memory_facts is not None, "Get null response for get_memory_facts"
    assert isinstance(memory_facts, dict), "Response is not a dictionary"

    dmi_facts = hardware.get_dmi_facts

# Generated at 2022-06-22 22:56:07.808841
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    # Get data for test
    test_data = {
      'device': 'node',
      'fstype': 'type',
      'mount': 'mount_point',
      'options': 'opts',
      'time': 'time'
    }
    class options:
        gather_subset = []
    module = type('', (), {})()
    module.run_command = type('', (), {})()

# Generated at 2022-06-22 22:56:11.022367
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector._platform == 'AIX'
    assert hardware_collector._fact_class == AIXHardware

# Generated at 2022-06-22 22:56:19.361688
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():

    class TestAIXHardware:
        """
        Unit test for method get_dmi_facts of class AIXHardware
        """

        def run_command(self, cmd, use_unsafe_shell=False):
            """
            Method stub to simulate the behaviour of ansible.module_utils.basic.AnsibleModule class.
            Used to mock module.run_command() method.

            :param cmd: Command that is to be executed.
            :type cmd: str
            :param use_unsafe_shell: if set to True, the module will run cmd via /bin/sh.
            :type use_unsafe_shell: bool
            :return: out, err, rc - command output, error and return code
            """

            out = ''
            err = ''
            rc = 0

# Generated at 2022-06-22 22:56:29.730467
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    class AIX_Test_Module(object):
        def __init__(self):
            pass

        def get_bin_path(self, name, opt_dirs=[]):
            return '/usr/sbin/' + name

        def run_command(self, cmd, use_unsafe_shell=False):
            if cmd == '/usr/sbin/lsvg -o | /usr/bin/xargs /usr/sbin/lsvg -p':
                return 0, mount_out, ''

# Generated at 2022-06-22 22:56:40.356773
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={})
    hardware = module.get_bin_path('hardware')
    if hardware:
        hardware_facts = AIXHardware(module)
        test_facts = hardware_facts.populate()
        assert 'memfree_mb' in test_facts
        assert 'memtotal_mb' in test_facts
        assert 'swapfree_mb' in test_facts
        assert 'swaptotal_mb' in test_facts
        assert 'processor' in test_facts
        assert 'processor_cores' in test_facts
        assert 'processor_count' in test_facts
        assert 'firmware_version' in test_facts
        assert 'lpar_info' in test_facts
        assert 'product_name' in test_facts
        assert 'product_serial' in test_facts
       

# Generated at 2022-06-22 22:56:48.054967
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    fake_module = type('obj', (object,), {'run_command': run_command})
    hardware_collector = AIXHardwareCollector(fake_module)

    dmi_facts = hardware_collector.collect().get_dmi_facts()

    assert dmi_facts['firmware_version'] == 'IBM,8233-E8B'
    assert dmi_facts['product_serial'] == 'Y9C0N71'
    assert dmi_facts['lpar_info'] == '1 DED  LPAR 0  LPAR NAME:ANSIBLELPAR'
    assert dmi_facts['product_name'] == 'IBM,9117-MMA'



# Generated at 2022-06-22 22:56:52.198661
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    cpu_facts = {}
    cpu_facts['processor_count'] = 2
    cpu_facts['processor_cores'] = 2
    cpu_facts['processor'] = 'PowerPC_POWER8'
    cpu_facts['processor'] = ['PowerPC_POWER8']

    test_AIXHardware = AIXHardware()
    assert cpu_facts == test_AIXHardware.get_cpu_facts()



# Generated at 2022-06-22 22:57:03.873152
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    ah = AIXHardware(module=module)

    ah.populate()

    if not ah.memfree_mb:
        module.fail_json(msg='memfree_mb fact was not set')
    if not ah.memtotal_mb:
        module.fail_json(msg='memtotal_mb fact was not set')
    if not ah.swapfree_mb:
        module.fail_json(msg='swapfree_mb fact was not set')
    if not ah.swaptotal_mb:
        module.fail_json(msg='swaptotal_mb fact was not set')
    if not ah.processor:
        module.fail_json(msg='processor fact was not set')

# Generated at 2022-06-22 22:57:15.225573
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec=dict())
    hardware_obj = AIXHardware(module)
    hardware_obj.populate()

    assert(hardware_obj.facts['memtotal_mb'] == 4096)
    assert(hardware_obj.facts['memfree_mb'] == 1027)
    assert(hardware_obj.facts['processor_cores'] == 8)
    assert(hardware_obj.facts['processor_count'] == 4)
    assert(hardware_obj.facts['processor'] == 'PowerPC_POWER8')
    assert(hardware_obj.facts['firmware_version'] == 'S8MKD145')
    assert(hardware_obj.facts['product_serial'] == '05D97F')

# Generated at 2022-06-22 22:57:17.289462
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    hw = AIXHardware(module=module)
    hw.populate()



# Generated at 2022-06-22 22:57:28.827629
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    aix_collector = AIXHardwareCollector(None)
    facts = aix_collector.collect(None, None)

    # Assert that memfree_mb is found - it's provided by the get_memory_facts() method
    assert 'memfree_mb' in facts

    # Assert that memtotal_mb is found - it's provided by the get_memory_facts() method
    # make sure that it is a number
    assert 'memtotal_mb' in facts
    assert isinstance(facts['memtotal_mb'], int) is True

    # Assert that swapfree_mb is found - it's provided by the get_memory_facts() method
    # make sure that it is a number
    assert 'swapfree_mb' in facts
    assert isinstance(facts['swapfree_mb'], int) is True

   

# Generated at 2022-06-22 22:57:33.530369
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    global module
    module = AnsibleModule(argument_spec=dict())
    global hardware
    hardware = AIXHardware(module=module)
    assert hardware.get_memory_facts() == {'memtotal_mb': '20240', 'memfree_mb': '8648', 'swaptotal_mb': '314368', 'swapfree_mb': '314368'}

# Generated at 2022-06-22 22:57:43.184025
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    import sys
    sys.modules['_ansible_module_generated_by_Ansible'] = MockModule
    import ansible.module_utils.facts.hardware.aix as aixfacts


# Generated at 2022-06-22 22:57:55.944028
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    import sys

    import ansible.module_utils.facts.hardware.aix as aix_hardware
    from ansible.module_utils.facts.hardware.aix import AIXHardware

    test_aix_hardware = aix_hardware.AIXHardware()

    import ansible.module_utils.facts.cache as cache
    from ansible.module_utils.facts.cache import BaseFactCache
    test_base_fact_cache = BaseFactCache(test_aix_hardware)


# Generated at 2022-06-22 22:58:00.299019
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    fact_collector = AIXHardwareCollector(module=module)
    facts = fact_collector.collect(module, collected_facts=None)

# import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 22:58:11.611617
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    class MockModule():
        def __init__(self):
            self.run_command = Mock(return_value=(0, '', ''))
            self.get_bin_path = Mock(return_value='lsconf')

    ansible_module_mock = MockModule()
    aix_module = AIXHardware(ansible_module_mock)
    dmi_facts = aix_module.get_dmi_facts()
    test_dict = {'product_name': '<product name>',
                 'product_serial': '<product serial>',
                 'lpar_info': '<lpar info>',
                 'firmware_version': '<firmware version>'}
    assert dmi_facts == test_dict



# Generated at 2022-06-22 22:58:24.432677
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    """Test for AIXHardware.get_dmi_facts()"""
    assert get_aix_hardware_mock(AIXHardware.get_dmi_facts,
                                 'lsattr -El sys0 -a fwversion',
                                 'IBM,825fcec0.b1f\n').firmware_version == '825fcec0.b1f'

    assert get_aix_hardware_mock(AIXHardware.get_dmi_facts,
                                 'lsconf',
                                 'Machine Serial Number: 12345678901\nLPAR Info: 1 6\nSystem Model: IBM,8231-E2B\n').product_serial == '12345678901'


# Generated at 2022-06-22 22:58:34.393190
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    test_device_output = """ent0 Available Ethernet Entity
ent1 Available Ethernet Entity
ent2 Available Ethernet Entity"""

# Generated at 2022-06-22 22:58:38.335783
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hw_c = AIXHardwareCollector()
    assert hw_c._platform == 'AIX'
    assert isinstance(hw_c._fact_class, AIXHardware)


# Generated at 2022-06-22 22:58:50.640472
# Unit test for method get_memory_facts of class AIXHardware

# Generated at 2022-06-22 22:58:55.106714
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    hardware_obj = AIXHardware(module)

    result = hardware_obj.get_cpu_facts()
    assert result['processor_count'] == 6
    assert result['processor'] == 'POWER8'
    assert result['processor_cores'] == 12

# Generated at 2022-06-22 22:58:58.158152
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    m = AIXHardware()
    vgs_facts = m.get_vgs_facts()
    assert vgs_facts['vgs']['rootvg'][0]['pp_size'] == '4 megabytes'

# Generated at 2022-06-22 22:59:06.152299
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})

    ah = AIXHardware(module)
    vgs_facts = ah.get_vgs_facts()

    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs_facts['vgs']['rootvg'][0]['pv_state'] == 'active'
    assert vgs_facts['vgs']['rootvg'][0]['total_pps'] == '546'
    assert vgs_facts['vgs']['rootvg'][0]['free_pps'] == '0'
    assert vgs_facts['vgs']['rootvg'][0]['pp_size'] == '4 megabyte(s)'


# Generated at 2022-06-22 22:59:17.485387
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    aixhw = AIXHardware({})
    aixhw.module = MagicMock()
    aixhw.module.run_command.return_value = [0, """
proc0 Available 00-00 Processor                            Processor 0
proc2 Available 00-02 Processor                            Processor 2
proc4 Available 00-04 Processor                            Processor 4
proc6 Available 00-06 Processor                            Processor 6
proc8 Available 00-08 Processor                            Processor 8
proc10 Available 00-0A Processor                            Processor 10
proc12 Available 00-0C Processor                            Processor 12
proc14 Available 00-0E Processor                            Processor 14
proc16 Available 00-10 Processor                            Processor 16
""", ""]
    aixhw.get_cpu_facts()
    assert aixhw.facts['processor'] == 'PowerPC_POWER8'

# Generated at 2022-06-22 22:59:26.838013
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import collector
    from ansible.module_utils import basic
    import tempfile

    class MockModule(basic.AnsibleModule):

        def __init__(self, *args, **kwargs):
            self.params = {}
            super(MockModule, self).__init__(*args, **kwargs)
            tempdir = tempfile.mkdtemp()
            self.tmpdir = tempdir

        def run_command(self, args, check_rc=False, close_fds=True, executable=None, data=None, binary_data=False):
            rc = 0
            out = ''
            err = ''


# Generated at 2022-06-22 22:59:36.958593
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware_obj = AIXHardware(module)
    memory_facts = hardware_obj.get_memory_facts()

    assert memory_facts['swaptotal_mb'] >= 0
    assert memory_facts['swapfree_mb'] >= 0
    assert memory_facts['memtotal_mb'] >= 0
    assert memory_facts['memfree_mb'] >= 0
    assert memory_facts['memtotal_mb'] >= memory_facts['memfree_mb']
    assert memory_facts['swaptotal_mb'] >= memory_facts['swapfree_mb']



# Generated at 2022-06-22 22:59:42.604910
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = type('module', (object,), {})
    module.run_command = run_command_mock
    aixhw = AIXHardware(module)

    cpu_facts = aixhw.get_cpu_facts()
    assert cpu_facts['processor'] == 'PowerPC_POWER9'
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor_cores'] == 4



# Generated at 2022-06-22 22:59:54.248305
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    device_facts = {'firmware_version': 'IBM,8233-E8B',
                    'product_serial': '123456789012',
                    'lpar_info': '1 Virtual I/O Server',
                    'product_name': 'IBM,8233-E8B'}
    out_lsattr = 'fwversion IBM,8233-E8B'
    out_lsconf = '''
        System Model: IBM,8233-E8B
        Machine Serial Number: 123456789012
        LPAR Info: 1 Virtual I/O Server'''

    aix_hardware_obj = AIXHardware()
    aix_hardware_obj.module.run_command = Mock(return_value=(0, out_lsattr, ''))
    aix_hardware_obj.module.get_bin

# Generated at 2022-06-22 22:59:56.905964
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})

    hardware_obj = AIXHardware(module=module)

    hardware_obj.populate()

    module.exit_json(changed=False, ansible_facts={'ansible_hardware': hardware_obj.facts})



# Generated at 2022-06-22 23:00:07.445433
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModuleMock({})
    hardware = AIXHardware(module)
    hardware.populate()
    assert hardware.facts
    assert hardware.facts['firmware_version'] == 'IBM,Firmware:8.30.00.00'
    assert hardware.facts['product_name'].startswith('IBM,')
    assert hardware.facts['product_serial'].startswith('IBM,')
    assert hardware.facts['product_uuid'].startswith('IBM,')
    assert hardware.facts['processor'] == 'PowerPC_POWER7'
    assert hardware.facts['processor_cores'] == 1
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['memtotal_mb'] == 9759
    assert hardware.facts['memfree_mb'] == 631

# Generated at 2022-06-22 23:00:19.257193
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware = AIXHardware({})

    assert hardware.platform == 'AIX'

    hardware.populate()

    assert hardware.facts['firmware_version'] == '7110108'
    assert hardware.facts['product_serial'] == '23EA9N9'
    assert hardware.facts['lpar_info'] == 'PowerVM,7042-CR6'
    assert hardware.facts['product_name'] == 'IBM,7042-CR6'

    assert hardware.facts['processor_count'] == 4
    assert hardware.facts['processor'] == 'POWER7'
    assert hardware.facts['processor_cores'] == 1

    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['swaptotal_mb'] == 8064
    assert hardware.facts['swapfree_mb'] == 8064

# Generated at 2022-06-22 23:00:29.466317
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    class AIXHardwareTest(AIXHardware):
        def __init__(self, module, command_runner):
            self.module = module
            self.command_runner = command_runner


# Generated at 2022-06-22 23:00:33.327540
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module_mock = Mock(spec_set=AnsibleModule)
    module_mock.run_command.return_value = 0, "IBM,770,M15", ""

    hw = AIXHardware()
    hw.module = module_mock

    dmi_facts = hw.get_dmi_facts()

    assert dmi_facts == {'firmware_version': '770,M15'}



# Generated at 2022-06-22 23:00:42.441909
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    """
    Testing AIXHardware class method get_memory_facts.
    """

    class ModuleStub():
        def __init__(self):
            self.params = None
            self.run_command_results = []
            self.run_command_index = 0

        def run_command(self, args, check_rc=False, close_fds=False, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False):
            """
            Return the value of the next entry in run_command_results
            """
            rc = self.run_command_results[self.run_command_index][0]
            out = self.run_command_results[self.run_command_index][1]

# Generated at 2022-06-22 23:00:53.957578
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    """Unit test for method get_vgs_facts of class AIXHardware"""
    from ansible.module_utils.facts import hardware

    # This is a simple text sample, which is used for unit testing.
    # This sample is parsed into a dictionary and partially tested.

# Generated at 2022-06-22 23:01:06.064464
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    from ansible.module_utils.facts.aix.hardware import AIXHardware
    from ansible.module_utils.facts.aix.hardware import AIXHardwareCollector
    from ansible.module_utils.facts.utils import mock_uname
    from ansible.module_utils.facts.utils import mock_uname_cache
    from ansible.module_utils.facts.utils import mock_runner

    # Helper function to mock the facts module
    def mock_facts_module(facts):
        from ansible.module_utils.facts import Facts
        facts_instance = Facts(module=mock_ansible_module, runner=mock_runner)
        facts_instance.populate()
        facts_instance.get_facts()
        facts_instance.get_filesystem_facts()
        facts_instance._legacy_

# Generated at 2022-06-22 23:01:18.864523
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    # Simulate class module as a mocked object
    class ModuleMock():
        def get_bin_path(self, arg, required=False):
            lsvg_path = os.path.join(os.path.dirname(__file__), "files/lsvg")
            xargs_path = os.path.join(os.path.dirname(__file__), "files/xargs")
            if arg == "lsvg":
                return lsvg_path
            if arg == "xargs":
                return xargs_path

        def run_command(self, cmd, use_unsafe_shell=False):
            return 0, out_get_vgs_facts, ''

    # Simulate class facts.module as a mocked object

# Generated at 2022-06-22 23:01:26.674045
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils._text import to_bytes

# Generated at 2022-06-22 23:01:38.796171
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModuleMock()
    module.run_command.return_value = (0, "proc13 Available 00-00-00-C0 Processor\nproc14 Defined   00-00-00-C0 Processor", "")
    module.get_bin_path.return_value = "/bin/lsattr"
    module.run_command.return_value = (0, "type PowerPC_POWER5", "")
    module.run_command.return_value = (0, "smt_threads 1", "")
    aixhw = AIXHardware(module)
    # test get_cpu_facts
    result_dict = aixhw.get_cpu_facts()
    assert result_dict['processor_count'] == 2
    assert result_dict['processor'] == 'PowerPC_POWER5'
    assert result

# Generated at 2022-06-22 23:01:49.598137
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    mocked_module = MockModule()
    mocked_module.run_command = Mock(return_value=(0, """
    proc0 Available PowerPC_POWER8 Processor
    proc1 Available PowerPC_POWER8 Processor
    proc2 Available PowerPC_POWER8 Processor
    proc3 Available PowerPC_POWER8 Processor
    """, ""))

    mocked_module.run_command = Mock(return_value=(0, "type PowerPC_POWER8", ""))
    mocked_module.run_command = Mock(return_value=(0, "smt_threads 4", ""))
    ahw = AIXHardware(mocked_module)
    ahw.populate()
    assert ahw.facts['processor_count'] == 4
    assert ahw.facts['processor'] == 'PowerPC_POWER8'

# Generated at 2022-06-22 23:01:52.828916
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    mock_module = MockModule()
    memory_facts = AIXHardware(mock_module).get_memory_facts()
    assert memory_facts['memtotal_mb'] == 16384
    assert memory_facts['memfree_mb'] == 37
    assert memory_facts['swaptotal_mb'] == 256
    assert memory_facts['swapfree_mb'] == 200



# Generated at 2022-06-22 23:01:54.650154
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    hw = AIXHardware()
    hw.get_mount_facts()
    assert True

# Generated at 2022-06-22 23:01:57.993135
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    assert isinstance(hardware, AIXHardware)
    assert hardware._platform == 'AIX'
    assert hardware._fact_class == AIXHardware

# Generated at 2022-06-22 23:02:04.232592
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    cpu_facts_test = {}
    cpu_facts_test['processor'] = ['PowerPC_POWER8']
    cpu_facts_test['processor_count'] = 8
    cpu_facts_test['processor_cores'] = 2

    aix_hardware= AIXHardware({})
    assert aix_hardware.get_cpu_facts() == cpu_facts_test

# Generated at 2022-06-22 23:02:13.953599
# Unit test for constructor of class AIXHardware
def test_AIXHardware():

    import sys
    if sys.version_info[0] < 3:
        from StringIO import StringIO
    else:
        from io import StringIO

    test_AIXHardware = AIXHardware(dict(module=None))

# Generated at 2022-06-22 23:02:19.862831
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardwareCollector(module).collect()[0]
    assert hardware.platform == "AIX"
    assert len(hardware.processor) > 0
    assert hardware.processor_cores > 0
    assert hardware.processor_count == hardware.processor_cores



# Generated at 2022-06-22 23:02:28.259474
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    m = AIXHardware(None)
    o = open('/tmp/aix_vgs_facts', 'r')
    out = o.read()
    o.close()
    facts = m.get_vgs_facts(out)
    assert 'vgs' in facts
    assert 'rootvg' in facts['vgs']
    assert 'realsyncvg' in facts['vgs']
    assert 'testvg' in facts['vgs']
    assert len(facts['vgs']['rootvg']) == 2
    assert len(facts['vgs']['realsyncvg']) == 1
    assert len(facts['vgs']['testvg']) == 2
    rootvg = facts['vgs']['rootvg'][0]

# Generated at 2022-06-22 23:02:34.083403
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware = AIXHardware()
    assert hardware.platform == 'AIX'
    assert hardware.populate()
    assert hardware.get_cpu_facts()
    assert hardware.get_memory_facts()
    assert hardware.get_dmi_facts()
    assert hardware.get_vgs_facts()
    assert hardware.get_mount_facts()
    assert hardware.get_device_facts()

# Generated at 2022-06-22 23:02:43.465824
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    vgs_facts = {}
    lsvg_path = '/usr/sbin/lsvg'
    xargs_path = '/usr/bin/xargs'
    cmd = "%s -o | %s %s -p" % (lsvg_path, xargs_path, lsvg_path)


# Generated at 2022-06-22 23:02:47.139805
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    hardware = AIXHardware({})
    dmi_facts = hardware.get_dmi_facts()
    if 'product_name' in dmi_facts:
        product_name = dmi_facts['product_name']
    else:
        product_name = 'I have no name'
    assert product_name == 'I have no name'

# Generated at 2022-06-22 23:02:56.263049
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    # test default
    x = AIXHardware()
    assert x.get_memory_facts() == {'memtotal_mb': 0, 'memfree_mb': 0, 'swapfree_mb': 0, 'swaptotal_mb': 0}

    # test memtotal
    x._facts['memtotal'] = 4096 * 1024 * 1024
    assert x.get_memory_facts()['memtotal_mb'] == 4096

    # test swapfree
    x._facts['swapfree'] = 4096 * 1024 * 1024
    assert x.get_memory_facts()['swapfree_mb'] == 4096

    # test memfree
    x._facts['memfree'] = 4096 * 1024 * 1024
    assert x.get_memory_facts()['memfree_mb'] == 4096

# Generated at 2022-06-22 23:03:04.104244
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    """this function is used to test the get_mount_facts method of class AIXHardware
    """
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )

    hardware = AIXHardware(module)
    cmd = hardware.get_bin_path('mount')

# Generated at 2022-06-22 23:03:09.178580
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    """
    Unit test for method populate of class AIXHardware
    """
    # Initialize class
    fact_module = AIXHardwareCollector('setup')

    # Create the fact instance
    fact_instance = fact_module.collect()

    fact_module.populate()

# Generated at 2022-06-22 23:03:13.914450
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    # Set up the module used for unit testing
    from ansible.module_utils.facts import ModuleTestCase
    #from ansible.__init__ import AnsibleModule
    class ModuleTestCase(ModuleTestCase):
        module = AnsibleModule(
            argument_spec=dict(
                gather_subset=dict(default=['!all', 'hardware'], type='list'),
            )
        )

    # Test get_memory_facts
    hardware = AIXHardware(ModuleTestCase())
    facts = hardware.get_memory_facts()
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swapfree_mb' in facts

    # Unit test for method get_cpu_facts of class AIXHardware

# Generated at 2022-06-22 23:03:22.725027
# Unit test for method populate of class AIXHardware

# Generated at 2022-06-22 23:03:33.489354
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    """
    Test AIXHardware.get_memory_facts()
    """

    class ModuleMock:
        class RunCommandMock:
            def __init__(self, output, exitcode):
                self.output = output
                self.exitcode = exitcode
            def __call__(self, cmd, *args, **kwargs):
                return self.exitcode, self.output, ""
        def __init__(self):
            self.get_bin_path = lambda x: 'command'

# Generated at 2022-06-22 23:03:38.101520
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = type('module', (object, ), {
        'run_command': lambda *args, **kwargs: (0, '', ''),
        'get_bin_path': lambda *args, **kwargs: None
    })

    hardware = AIXHardware(module)

    assert hardware.populate()['processor_cores'] == 1

# Generated at 2022-06-22 23:03:46.527983
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_collector = AIXHardwareCollector(module=module)
    hardware = AIXHardware(module)

    cpu_facts = {'processor': 'PowerPC_POWER8',
                 'processor_cores': '32',
                 'processor_count': '12'}
    memory_facts = {'memtotal_mb': '8192',
                    'memfree_mb': '256',
                    'swaptotal_mb': '16384',
                    'swapfree_mb': '16383'}
    dmi_facts = {'product_serial': '07A4B4E',
                 'firmware_version': 'SV810_432',
                 'product_name': '7998-620',
                 'lpar_info': 'test'}
    v