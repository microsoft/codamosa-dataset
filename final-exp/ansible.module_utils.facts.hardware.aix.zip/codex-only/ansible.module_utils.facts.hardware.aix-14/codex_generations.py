

# Generated at 2022-06-22 22:53:54.388556
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    import unittest
    import sys
    import os
    import tempfile
    import shutil
    import json
    import re

    class TestFacts(unittest.TestCase):
        def setUp(self):
            self.facts = AIXHardware(dict())
            self.facts.module = AnsibleModule(argument_spec=dict())
            self.tempdir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_get_dmi_facts(self):
            # Check for dmidecode
            output_dict = {}
            output_dict = self.facts.get_dmi_facts()
            self.assertTrue(len(output_dict) > 0)


# Generated at 2022-06-22 22:54:03.732240
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    # create a test module
    test_module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    # create an instance of AIXHardware class
    hardware_obj = AIXHardware(module=test_module)
    # store results of method get_dmi_facts in variable dmi_facts
    dmi_facts = hardware_obj.get_dmi_facts()
    # ensure method get_dmi_facts has returned not empty dictionary
    assert dmi_facts


if __name__ == '__main__':
    from ansible.module_utils.basic import *
    main()

# Generated at 2022-06-22 22:54:13.024914
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    mount_facts = AIXHardware(module=module).get_mount_facts()
    assert 'mounts' in mount_facts
    assert type(mount_facts['mounts']) is list

    if len(mount_facts['mounts']) != 0:
        for mount in mount_facts['mounts']:
            assert 'device' in mount
            assert 'mount' in mount
            assert 'fstype' in mount
            assert 'options' in mount
            assert 'time' in mount

        assert 'size_total' in mount_facts['mounts'][0]
        assert 'size_available' in mount_facts['mounts'][0]

# Generated at 2022-06-22 22:54:22.509698
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = MockAnsibleModule()
    lsdev_cmd = 'lsdev'
    lsattr_cmd = 'lsattr'
    out_lsdev = """name1 Available 00-00-00
name2 Available 02-00-00
name3 Defined   00-00-00"""
    out_lsattr = """name1 value1
name2 value2
name3 value3"""
    lsattr_lsdev_cmd_out = {lsdev_cmd : (0, out_lsdev, ''),
                            lsattr_cmd : (0, out_lsattr, '')
                            }

    module.run_command = Mock(side_effect=lsattr_lsdev_cmd_out.get)
    hardware = AIXHardware()

    aix_device_facts = hardware.get_device_facts()
    device_name1_

# Generated at 2022-06-22 22:54:34.115580
# Unit test for method get_cpu_facts of class AIXHardware

# Generated at 2022-06-22 22:54:36.122610
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware = AIXHardware()
    assert hardware.populate()['processor_count'] == 2

# Generated at 2022-06-22 22:54:42.517529
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=[], type='list'),
        ),
        supports_check_mode=True)

    AIXHardware.module = module
    AIXHardware.populate(collected_facts={})
    assert 'mounts' in AIXHardware.facts
    assert len(AIXHardware.facts['mounts']) > 0

# Generated at 2022-06-22 22:54:47.536888
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    """
    Constructor of class AIXHardwareCollector should assign
    value of _fact_class variable to variable named _fact_class
    """
    aix_hardware_collector = AIXHardwareCollector()
    assert aix_hardware_collector._fact_class == AIXHardware

# Generated at 2022-06-22 22:54:56.892600
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    class AnsibleModuleMock:
        def run_command(self, cmd):
            out = """
proc0 Available 00-00-00 Processor
proc1 Available 00-00-01 Processor
        """
            return 0, out, ""

    class AIXHardwareMock:
        def __init__(self):
            pass
        def populate(self):
            pass
        def module(self):
            return AnsibleModuleMock()

    cpu_facts = AIXHardwareMock()

    assert cpu_facts.get_cpu_facts(cpu_facts) == {'processor_count': 2, 'processor': 'Processor'}


# Generated at 2022-06-22 22:55:09.371383
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    processor_count = '2'
    processor = 'PowerPC_POWER8'
    processor_cores = '8'

# Generated at 2022-06-22 22:55:10.920311
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    aixhw = AIXHardware()
    assert aixhw is not None

# Generated at 2022-06-22 22:55:17.379191
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    test_module = AnsibleModule(argument_spec=dict())
    test_module.params = {}
    result = AIXHardware.get_dmi_facts(test_module)
    assert 'product_name' in result
    assert 'product_serial' in result
    assert 'firmware_version' in result
    assert 'lpar_info' in result



# Generated at 2022-06-22 22:55:29.435909
# Unit test for constructor of class AIXHardware

# Generated at 2022-06-22 22:55:34.707218
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    AIXHardware_get_memory_facts = AIXHardware(module=module)
    mem_facts = AIXHardware_get_memory_facts.get_memory_facts()
    assert 'swaptotal_mb' in mem_facts
    assert 'swapfree_mb' in mem_facts
    assert 'memfree_mb' in mem_facts
    assert 'memtotal_mb' in mem_facts

# Generated at 2022-06-22 22:55:45.824591
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    aix_hardware_collector = AIXHardwareCollector()
    assert aix_hardware_collector is not None

if __name__ == '__main__':

    aix_hardware = AIXHardware()
    hardware_facts = aix_hardware.populate()
    print("memfree_mb: %s" % hardware_facts['memfree_mb'])
    print("memtotal_mb: %s" % hardware_facts['memtotal_mb'])
    print("swapfree_mb: %s" % hardware_facts['swapfree_mb'])
    print("swaptotal_mb: %s" % hardware_facts['swaptotal_mb'])
    print("processor: %s" % hardware_facts['processor'])

# Generated at 2022-06-22 22:55:55.230917
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():

    out_lsdev = """ent0   Available             00-08                    Ethernet
ent1   Available             00-09                    Ethernet"""

# Generated at 2022-06-22 22:56:02.016314
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    test_input = """
    rootvg:
    PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
    hdisk0            active            10          0           00..00..00..00..00
    hdisk1            active            10          2           00..00..00..00..02
    testvg:
    PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
    hdisk10           active            20          8           00..00..00..00..08
    hdisk11           active            20          5           00..00..00..00..05
    """
    fact_class = AIXHardware()
    test_output = fact_class.get_vgs_facts()

# Generated at 2022-06-22 22:56:05.880917
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    collector = AIXHardwareCollector()
    assert collector
    assert collector._platform == 'AIX'
    assert collector._fact_class == AIXHardware

# Generated at 2022-06-22 22:56:08.337255
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    test_module = AnsibleModule(argument_spec={})
    obj = AIXHardware(test_module)
    obj.get_memory_facts()

# Generated at 2022-06-22 22:56:18.231878
# Unit test for method get_device_facts of class AIXHardware

# Generated at 2022-06-22 22:56:28.677882
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    module = AnsibleModuleMock()
    fact_module = AIXHardware({}, module)
    assert isinstance(AIXHardware, type)
    assert isinstance(fact_module, AIXHardware)
    assert isinstance(fact_module, BaseFactCollector)
    module.run_command.return_value = (0, 'sys0 IBM,8233-E8B fwversion IBM,810.200.0.009-20121026', '')
    dmi_facts = fact_module.get_dmi_facts()
    assert dmi_facts == {'firmware_version': 'IBM,810.200.0.009-20121026'}


# Generated at 2022-06-22 22:56:39.726978
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    # Create mock module
    module = AnsibleModule(argument_spec={})
    # Create mock output of command vmstat -v
    out_vmstat = '''memory pages:            10383
    free pages:               56
    large pages:              19
    pinned pages:             56
    virtual memory:           8388608 Megabytes
    real memory:              1048544 Megabytes'''
    # Create mock hardware class
    hardware = AIXHardware(module)
    # Replace method module.run_command with mock output
    hardware.module.run_command = mock_run_command([(0, out_vmstat, '')])
    # Call method get_memory_facts
    memory_facts = hardware.get_memory_facts()
    # Assert memtotal_mb is equal to expected value
    assert memory_facts['memtotal_mb'] == 1024

# Generated at 2022-06-22 22:56:47.741831
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    hardware = AIXHardware()
    hardware.module = MockModule()
    hardware.module.run_command = Mock(return_value=(0, "proc0 Available 00-00 Processor\nproc1 Defined 00-01 Processor", ""))

    hardware.module.run_command = Mock(return_value=(0, "type PowerPC_POWER5+", ""))

    hardware.module.run_command = Mock(return_value=(0, "smt_threads 4", ""))

    processor_facts = hardware.get_cpu_facts()
    assert processor_facts['processor_count'] == 2
    assert processor_facts['processor'] == 'PowerPC_POWER5+'
    assert processor_facts['processor_cores'] == 4



# Generated at 2022-06-22 22:56:54.951063
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = type(str('AnsibleModuleMock'), (object,), {})()
    module.run_command = lambda x, y=True: ('', '', '')
    module.get_bin_path = lambda x, y=True: ('/usr/bin/some_cmd')


# Generated at 2022-06-22 22:56:57.260313
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModuleMock(params={})
    AIXHardware().get_memory_facts()


# Generated at 2022-06-22 22:57:03.528465
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts import Collector

    hardware = AIXHardware(Collector({}, {'gather_subset': ['all']}))
    hardware_facts_result = hardware.populate()
    assert type(hardware_facts_result['devices']) is dict



# Generated at 2022-06-22 22:57:05.923396
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    test_hardware = AIXHardware()
    assert test_hardware.platform == 'AIX'

# Generated at 2022-06-22 22:57:16.582500
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    from ansible.module_utils.facts.aix.hardware import AIXHardware
    from ansible.module_utils.facts.aix.hardware import read_file
    from ansible.module_utils.facts.aix.hardware import get_file_content
    from ansible.module_utils.facts import Facts
    import pytest

    # create instance of Facts class
    module_instance = Facts(dict())

    # create instance of AIXHardware class
    hardware_instance = AIXHardware(module_instance)

    # test get_vgs_facts method
    vgs_facts = hardware_instance.get_vgs_facts()

    # test the result

# Generated at 2022-06-22 22:57:27.471042
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = DummyModule()
    hardware_fact_class = AIXHardware(module, 'root')
    # Output of command lsdev
    output_lsdev = "name    status  description\n" \
                   "lo0     Available  Loopback Adapter\n" \
                   "inet0   Available  TCP/IP Interface\n" \
                   "inet6   Defined    Internetwork Version 6 interface\n" \
                   "fcs0    Available  Fiber Channel SCSI Interface\n" \
                   "fscsi0  Available  FC Adapter"

    # Output of command lsattr -E -l fcs0

# Generated at 2022-06-22 22:57:30.049781
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    collector = AIXHardwareCollector()
    assert collector.platform == 'AIX'
    assert collector.fact_class == AIXHardware
    assert collector.config

# Generated at 2022-06-22 22:57:31.740117
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware = AIXHardware({})
    assert hardware.facts['distribution_version'] == '7.1'

# Generated at 2022-06-22 22:57:41.586391
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    """unit test for AIX get_device_facts method
    """
    # Device hdisk1 not in lspv output, have attributes...
    out_lsdev = '''hdisk0 Available 00-00-00               POWER4+
hdisk1 Defined  00-00-00               POWER4+
hdisk2 Defined  00-00-00               POWER4+
cd0 Available  00-00-00               POWER4+
ce0 Available  00-0D-60-A1-3F-A0     Ethernet
'''

# Generated at 2022-06-22 22:57:49.113116
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    facts = hardware.populate()
    assert facts['processor'][0] == 'PowerPC_POWER8'
    assert facts['processor_cores'] == 16
    assert facts['processor_count'] == 2
    assert facts['memtotal_mb'] == 8192
    assert facts['memfree_mb'] == 7043
    assert facts['swaptotal_mb'] == 313024
    assert facts['swapfree_mb'] == 313024
    assert facts['lpar_info'] == '1 partition, 1 dedicated physical processors'
    assert facts['product_name'] == 'IBM,8286-42A'
    assert facts['product_serial'] == '90A10F0D'

# Generated at 2022-06-22 22:57:54.661657
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    from ansible.module_utils.facts.hardware.aix import AIXHardwareCollector
    hwc = AIXHardwareCollector()
    assert hwc.platform == 'AIX', 'AIXHardwareCollector.platform'
    assert hwc.fact_class == AIXHardware, 'AIXHardwareCollector.fact_class'

# Generated at 2022-06-22 22:58:00.815248
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'IBM,AIX 7.2.0.0\n', ''))
    ahw = AIXHardware(module)
    found_facts = ahw.get_dmi_facts()
    assert 'firmware_version' in found_facts
    assert found_facts['firmware_version'] == 'AIX 7.2.0.0'


# Generated at 2022-06-22 22:58:12.675061
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModuleMock()
    hardware = AIXHardware(module)

    # test memory facts
    mock_run_command_vmstat = MagicMock(return_value=(0, 'memory pages:                          73985', ''))
    hardware.module.run_command = mock_run_command_vmstat
    memory_facts_actual = hardware.get_memory_facts()
    memory_facts_expected = {
        'memtotal_mb': 74352,
        'memfree_mb': 74352
    }
    assert memory_facts_expected == memory_facts_actual

    mock_run_command_vmstat = MagicMock(return_value=(0, 'memory pages:                          73985\nfree pages:                           73985', ''))
    hardware.module.run_command = mock_run_command_vm

# Generated at 2022-06-22 22:58:25.245846
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    class AIXHardwareMock():
        def __init__(self):
            self.module = MockModule()

    class MockModule():
        def get_bin_path(self, path, opt_dirs=[]):
            return "/usr/sbin/lsattr"

        def run_command(self, cmd, use_unsafe_shell=False, check_rc=True):
            if cmd == "/usr/sbin/lsattr -El sys0 -a fwversion":
                out = "fwversion IBM,8233-E8B                         False"
                rc = 0

# Generated at 2022-06-22 22:58:35.418103
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():

    mem_fact_unused_pages = {
            'memtotal_mb': 512,
            'memfree_mb': 506,
            'swaptotal_mb': 2048,
            'swapfree_mb': 2014,
    }
    mem_fact_max_pages = {
            'memtotal_mb': 196608,
            'memfree_mb': 196602,
            'swaptotal_mb': 2048,
            'swapfree_mb': 2014,
    }
    mem_fact_min_pages = {
            'memtotal_mb': 1024,
            'memfree_mb': 5,
            'swaptotal_mb': 2048,
            'swapfree_mb': 2014,
    }

# Generated at 2022-06-22 22:58:48.184912
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    hw = AIXHardware()


# Generated at 2022-06-22 22:58:59.347629
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    instance = AIXHardware()
    instance.module = MockModule()
    result = instance.populate()
    assert 'product_name' in result
    assert 'product_serial' in result
    assert 'firmware_version' in result
    assert 'processor_count' in result
    assert 'processor' in result
    assert 'processor_cores' in result
    assert 'memtotal_mb' in result
    assert 'memfree_mb' in result
    assert 'swaptotal_mb' in result
    assert 'swapfree_mb' in result
    assert 'devices' in result
    assert 'mounts' in result
    assert 'vgs' in result



# Generated at 2022-06-22 22:59:06.738155
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    aixhardware = AIXHardware(dict())
    aixhardware.module.run_command = MagicMock(return_value=(0, '', ''))

# Generated at 2022-06-22 22:59:18.338677
# Unit test for method populate of class AIXHardware

# Generated at 2022-06-22 22:59:26.514945
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    from ansible_collections.ansible.community.plugins.module_utils.facts.hardware.aix import AIXHardwareCollector
    from ansible.module_utils.facts.collector import HardwareCollector
    from ansible.module_utils.facts import FactManager

    if __name__ != '__main__':
        # test AIXHardwareCollector class
        facts = AIXHardwareCollector()
        assert isinstance(facts, AIXHardwareCollector)
        assert isinstance(facts, HardwareCollector)
        assert isinstance(facts, FactManager)

# Generated at 2022-06-22 22:59:38.909492
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    import platform

    module = AnsibleModule(
        argument_spec = dict()
    )

    def run_command(command, use_unsafe_shell=False):
        data = {
            '/usr/sbin/lsattr -El sys0 -a fwversion': 'fwversion IBM,8247-22L,8247A22L    Firmware Version',
            '/usr/bin/lsconf': '''System Model: IBM,8247-22L
Machine Serial Number: 06B1710
LPAR Info: 1 CEC(s)
FW Version: IBM,8247-22L,8247A22L    Firmware Version
LPAR Name: test_host
HW Model: IBM,8247-22L'''
        }

        return (0, data[command], '')

    module.run_command = run_command
   

# Generated at 2022-06-22 22:59:45.136531
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModuleMock()
    hardware = AIXHardware(module)
    # Test get_cpu_facts
    rc, out, err = module.run_command("/usr/sbin/lsdev -Cc processor")
    module.run_command.assert_called_with("/usr/sbin/lsdev -Cc processor")
    if out:
        i = 0
        for line in out.splitlines():

            if 'Available' in line:
                if i == 0:
                    data = line.split(' ')
                    cpudev = data[0]

                i += 1
        processor_count = int(i)

        rc, out, err = module.run_command("/usr/sbin/lsattr -El " + cpudev + " -a type")
        module.run_command.assert_called

# Generated at 2022-06-22 22:59:55.336707
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(
        argument_spec=dict()
    )

    class Mock_lsconf_path:
        def __init__(self, lsconf_path):
            self.lsconf_path = lsconf_path

        def get_bin_path(self, cmd):
            if cmd == 'lsconf':
                return True

    class Mock_lsconf_no_path:
        def get_bin_path(self, cmd):
            if cmd == 'lsconf':
                return False

    class Mock_Command:
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

    # Happy path test
    module.run_command = Mock_Command(0, 'Machine Serial Number:', '')
    module_obj = Mock_ls

# Generated at 2022-06-22 22:59:58.702512
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hw = AIXHardwareCollector()
    # Verify platform
    assert hw.platform == 'AIX'
    # Verify fact_class
    assert hw.fact_class == AIXHardware



# Generated at 2022-06-22 23:00:09.060292
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    # test case 1
    line = "mount -v /dev/hd1 on / type jfs log /dev/hd8"\
           " (local) 0 0"

    fields = line.split()
    if len(fields) != 0 and fields[0] != 'node' and fields[0][0] != '-' and re.match('^/.*|^[a-zA-Z].*|^[0-9].*', fields[0]):
        if re.match('^/', fields[0]):
            # normal mount
            mount = fields[1]

# Generated at 2022-06-22 23:00:20.560868
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec=dict())
    lsdev_cmd = module.get_bin_path('lsdev', True)
    lsattr_cmd = module.get_bin_path('lsattr', True)
    rc, out_lsdev, err = module.run_command(lsdev_cmd)

    hardware = AIXHardware(module)
    device_facts = hardware.get_device_facts()
    for device_name, device_facts in device_facts['devices'].items():
        device_attrs = {}
        for line in out_lsdev.splitlines():
            field = line.split()
            if device_name == field[0]:
                device_state = field[1]
                device_type = ' '.join(field[2:])

# Generated at 2022-06-22 23:00:27.162321
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    class TestModule():
        def __init__(self):
            pass
        def get_bin_path(self, path):
            if path == "lsconf":
                return "/usr/sbin/lsconf"
            return None

    class TestAIXHardware():
        def __init__(self):
            self.module = TestModule()

    ahw = TestAIXHardware()
    ahw.get_dmi_facts()

# Generated at 2022-06-22 23:00:31.829676
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():

    from ansible.module_utils.facts.aix import AIXHardware
    from ansible.module_utils.facts.hardware.aix import AIXHardwareCollector

    AIXHardwareCollector.collect()


# Generated at 2022-06-22 23:00:35.745808
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    result = hardware.get_vgs_facts()
    module.fail_json(msg='expected result to be defined', **result)



# Generated at 2022-06-22 23:00:42.851756
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    import copy

    test_module = AnsibleModule(
        argument_spec=dict(
        )
    )

    test_module.run_command = MagicMock(return_value=(0,VMSTAT,None))

    test_fact_class = AIXHardware(test_module)
    test_memory_facts = test_fact_class.get_memory_facts()

    assert test_memory_facts['memtotal_mb'] == 2048
    assert test_memory_facts['swaptotal_mb'] == 4096
    assert test_memory_facts['swapfree_mb'] == 3871
    assert test_memory_facts['memfree_mb'] == 101


# Generated at 2022-06-22 23:00:44.520809
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    collector = AIXHardwareCollector()
    assert collector.platform == 'AIX'

# Generated at 2022-06-22 23:00:52.386457
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    mock_module = AnsibleModuleMock()
    mock_module.run_command.return_value = (0, 'memory pages:\n1159998 total\n3 free\n', '')
    hardware = AIXHardware()
    hardware.module = mock_module
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 1159998 * 4 / 1024 / 1024
    assert memory_facts['memfree_mb'] ==  3 * 4 / 1024 / 1024



# Generated at 2022-06-22 23:00:53.699108
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    HardwareCollector()


# Generated at 2022-06-22 23:01:05.789321
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = MagicMock()
    module.get_bin_path = MagicMock(return_value='/bin/lsvg')

    aix_facts = AIXHardware(module)

    lsvg_path = '/bin/lsvg'
    xargs_path = '/usr/bin/xargs'
    cmd = "%s -o | %s %s -p" % (lsvg_path, xargs_path, lsvg_path)


# Generated at 2022-06-22 23:01:18.557059
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    class Module(object):
        def __init__(self, run_command_args, run_command_rc, run_command_err):
            self.run_command_args = run_command_args
            self.run_command_rc = run_command_rc
            self.run_command_err = run_command_err

        def run_command(self, args, **kwargs):
            assert self.run_command_args == args
            return (self.run_command_rc, '', self.run_command_err)

    class AnsibleModule(object):
        def __init__(self, argument_spec):
            self.params = {}


# Generated at 2022-06-22 23:01:26.515771
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    # create a dummy AIXHardware object
    hardware = AIXHardware()

    # get vgs facts
    vgs_facts = hardware.get_vgs_facts()

    # assert that testvg and rootvg are in vgs_facts['vgs']
    assert 'rootvg' in vgs_facts['vgs']
    assert 'testvg' in vgs_facts['vgs']

    # assert that testvg is listed as subkey in vgs_facts['vgs'] and that it has 2 entries
    assert len(vgs_facts['vgs']['testvg']) == 2
    # assert that rootvg is listed as subkey in vgs_facts['vgs'] and that it has 2 entries
    assert len(vgs_facts['vgs']['rootvg']) == 2
    # assert that realsyncvg is listed

# Generated at 2022-06-22 23:01:35.385715
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    results = dict(
        changed=False,
        ansible_facts=dict(
            ansible_processor=['PowerPC_POWER8'],
            ansible_processor_cores=32,
            ansible_processor_count=32
        )
    )

    hardware = AIXHardware(module)

    cpu_facts = hardware.get_cpu_facts()

    compare_dicts(results, cpu_facts)



# Generated at 2022-06-22 23:01:38.070374
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hw = AIXHardware()
    assert hw.platform == 'AIX'
    assert hw.get_mount_facts()['mounts'] is not None

# Generated at 2022-06-22 23:01:41.457398
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] > 0


# Generated at 2022-06-22 23:01:45.638404
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    hardware_facts = AIXHardware()
    memory_facts = hardware_facts.get_memory_facts()
    assert memory_facts['memfree_mb'] > 0 and memory_facts['memfree_mb'] < memory_facts['memtotal_mb']

# Generated at 2022-06-22 23:01:57.583723
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    """
    @summary: Unit test for method get_dmi_facts of class AIXHardware
    @Requirement: HardwareCommandParser
    @CaseLevel: System
    @CaseComponent: Facts
    @TestType: Functional
    @CaseImportance: High
    @Upstream: No
    """
    def run_test(test_case, test_device, expected_value, current_values=None,
                 test_case_name=None, test_device_name=None):
        test_case_name = test_case_name or test_case
        test_device_name = test_device_name or test_device

# Generated at 2022-06-22 23:02:09.847896
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    class TestModule:
        def run_command(self, command):
            if command[0] == '/usr/bin/lsdev':
                return 0, '''ent0 Available 10/100 Mbps Ethernet PCI Adapter (14106902)
ent1 Available 10/100 Mbps Ethernet PCI Adapter (14106904)
ent2 Available 10/100 Mbps Ethernet PCI Adapter (14106906)
ent3 Available 10/100 Mbps Ethernet PCI Adapter (14106908)
ent4 Available 10/100 Mbps Ethernet PCI Adapter (1410690B)
ent5 Available 10/100 Mbps Ethernet PCI Adapter (1410690D)
ent6 Available 10/100 Mbps Ethernet PCI Adapter (1410690F)
ent7 Available 10/100 Mbps Ethernet PCI Adapter (14106911)
ent8 Available 10/100 Mbps Ethernet PCI Adapter (14106913)
''', ''

# Generated at 2022-06-22 23:02:14.852702
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    """aix_hardware_collector.py: Test class constructor parameters"""
    hw_collector = AIXHardwareCollector()
    assert (hw_collector.platform == "AIX")
    assert (hw_collector.fact_class == AIXHardware)

# Generated at 2022-06-22 23:02:19.889608
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = Mock(side_effect=lambda x, **kwargs: (0, '', ''))

    # Successful case
    hw = AIXHardware(module=module)
    hw.lsdev = '/usr/sbin/lsdev'
    hw.lsattr = '/usr/sbin/lsattr'
    hw.get_device_facts()

    # Fail case for lsdev command
    module.run_command = Mock(side_effect=lambda x, **kwargs: (1, '', ''))
    hw = AIXHardware(module=module)
    hw.lsdev = '/usr/sbin/lsdev'
    hw.get_device_facts()

    # Fail case for lsattr command

# Generated at 2022-06-22 23:02:28.520956
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    data = [
        'name            status  description',
        'ad0             Available',
        'adapter         Defined',
        'adapter         Defined',
        'fcs0            Available',
        'fcs1            Available',
        'fcs2            Available',
        'fcs3            Available',
        'fscsi0          Available',
        'fscsi1          Available',
        'lan0            Available',
        'lan1            Available',
        'scsi0           Defined',
        'scsi1           Defined',
        'scsi2           Defined',
        'scsi3           Defined',
        'sea0            Available',
        'sea1            Available',
        'sea2            Available',
        'sea3            Available']
    module = AnsibleModuleFake(data)
    hardware = AI

# Generated at 2022-06-22 23:02:33.822326
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={})
    hardware_collector = AIXHardwareCollector(module=module)
    hardware = AIXHardware(module)
    hardware_collector.collect(module=module, collected_facts=hardware.populate())
    assert hardware_collector.hardware.get('processor_count') > 0



# Generated at 2022-06-22 23:02:36.377998
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    hardware_fact = AIXHardware({})
    hardware_fact.get_cpu_facts()
    assert hardware_fact.cpu_facts['processor_count'] > 0

# Generated at 2022-06-22 23:02:44.532547
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = FakeAnsibleModule()
    hardware = AIXHardware(module)
    hardware.module.run_command = run_command_mock
    hardware.module.get_bin_path = get_bin_path_mock
    hardware.get_dmi_facts()
    assert hardware.firmware_version == '1.2.4'
    assert hardware.product_serial == '888888'
    assert hardware.lpar_info == 'LPAR Number:0 LPAR Characteristics: C=Capable,B=Bounded'
    assert hardware.product_name == 'IBM,8203-E4A'


# Generated at 2022-06-22 23:02:54.658248
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    """ Unit test for method get_mount_facts of class AIXHardware """
    from ansible_collections.ansible.community.tests.unit.compat.mock import Mock
    from ansible.module_utils.facts import facts

    class AIXHardware(facts.hardware.base.Hardware):
        platform = 'AIX'

        def __init__(self):
            pass

        def populate(self, collected_facts=None):
            pass

    mock_module = Mock()

    aix_hw = AIXHardware()
    aix_hw.module = mock_module


# Generated at 2022-06-22 23:03:00.697710
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    class MockModule(object):
        def __init__(self):
            self.params = {}

        def run_command(self, command):
            if command == "/usr/bin/vmstat -v":
                out = "memory pages  :    164720\nfree pages     :     48518"
                return (0, out, '')
            elif command == "/usr/sbin/lsps -s":
                out = "SWAP SPACE INFORMATION            (MB)\nDevice     1M-blocks  Used      Avail     Capacity\n/dev/ada0p3     314368   0         314368     0%"
                return (0, out, '')

    module = MockModule()
    hardware = AIXHardware(module)
    memory_facts = hardware.get_memory_facts()

    assert memory_facts['memtotal_mb']

# Generated at 2022-06-22 23:03:02.205869
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModuleMock()
    hardware = AIXHardware(module)

    assert hardware.get_facts() == {}

# Generated at 2022-06-22 23:03:15.005516
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec=dict())

# Generated at 2022-06-22 23:03:15.660758
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    pass

# Generated at 2022-06-22 23:03:23.658592
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    class Options(object):
        def __init__(self):
            self.shell = '/bin/sh'
            self.timeout = 10
            self.connection = 'smart'
            self.remote_user = 'root'

    class Module(object):
        def __init__(self):
            self.params = Options()

    class Runner(object):
        def __init__(self):
            self.module = Module()

        def run(self, module_name, module_args, use_unsafe_shell=False, **kwargs):
            cmd = 'mount'

# Generated at 2022-06-22 23:03:31.277085
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module=module)
    vgs_facts = hardware.get_vgs_facts()
    assert 'vgs' in vgs_facts, vgs_facts

    for vg in vgs_facts['vgs']:
        assert 'root' not in vg.lower(), vg.lower()

        for pv in vgs_facts['vgs'][vg]:
            assert 'pp_size' in pv.keys(), pv.keys()

# Generated at 2022-06-22 23:03:35.435705
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    module = AnsibleModuleMock()
    hardware_collector = AIXHardwareCollector(module)

    assert hardware_collector._platform == 'AIX'
    assert hardware_collector._fact_class == AIXHardware


##
## Unit test for class AIXHardware
##

# Generated at 2022-06-22 23:03:44.662286
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    facts = AIXHardwareCollector.collect()
    assert facts['firmware_version'] == 'IBM,8233-E8B'
    assert facts['product_serial'] == '12345678900'
    assert facts['lpar_info'] == '0'
    assert facts['product_name'] == '8233-E8B'
    assert facts['processor'] == 'PowerPC_POWER8'
    assert facts['processor_cores'] == 4
    assert facts['processor_count'] == 4
    assert facts['memtotal_mb'] == 8251
    assert facts['memfree_mb'] == 506
    assert facts['swaptotal_mb'] == 6499
    assert facts['swapfree_mb'] == 508
    assert facts['mounts'][0]['mount'] == '/'