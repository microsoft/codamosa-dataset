

# Generated at 2022-06-22 22:53:54.420482
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = MockModule()
    hardware = AIXHardware(module)
    mounts = hardware.get_mount_facts()
    mounts = mounts['mounts']

    assert len(mounts) >= 8
    assert mounts[1]['mount'] == '/home'
    assert mounts[1]['device'] == '/dev/hd1'
    assert mounts[1]['fstype'] == 'jfs2'
    assert mounts[1]['options'] == 'rw,log=/dev/hd8'
    assert mounts[1]['mount_size_kb'] >= 1792
    assert mounts[1]['used_kb'] < 1792
    assert mounts[1]['mount_size_kb'] > 300
    assert mounts[4]['mount'] == '/proc'
    assert mounts[4]['device'] == '/proc'

# Generated at 2022-06-22 22:53:56.825615
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec=dict()
    )

    facts_module = AIXHardware(module=module)

    cpu_facts = facts_module.get_cpu_facts()

    assert 'processor' in cpu_facts
    assert 'processor_cores' in cpu_facts
    assert 'processor_count' in cpu_facts



# Generated at 2022-06-22 22:54:09.034560
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():

    def mock_module_run_command(cmd, *args, **kwargs):
        """
        Mocker for AnsibleModule.run_command
        """
        if cmd == '/usr/sbin/lsdev -Cc processor':
            return 0, \
                   "proc0 Available 00-00 Processor "

# Generated at 2022-06-22 22:54:20.338117
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():

    class ModuleMock(object):
        def run_command(self, command):
            if 'lsdev' in command:
                return 0, ("proc0 Available 00-00 Processor\n"
                           "proc1 Available 00-01 Processor\n"
                           "proc2 Available 00-02 Processor\n"
                           "proc3 Available 00-03 Processor\n"
                           "proc4 Available 00-04 Processor\n"
                           "proc5 Available 00-05 Processor\n"
                           "proc6 Available 00-06 Processor\n"
                           "proc7 Available 00-07 Processor"), ''
            elif 'lsattr' in command:
                return 0, "type PowerPC_POWER7 True", ''

        def get_bin_path(self, *args, **kwargs):
            return None

    cpu_facts = AIX

# Generated at 2022-06-22 22:54:26.567571
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(
        argument_spec=dict(
        ))
    out = 'ent0 Available 03-08-08 Ethernet I/F'
    hardware = AIXHardware(module)
    hardware.parse_proc = MagicMock(return_value=out)
    hardware.module = module
    hardware.module.run_command = MagicMock(return_value=(0, 'attr1 param1\n attr2 param2', ''))
    hardware_facts = hardware.get_device_facts()
    expected = {'devices':
                {'ent0':
                    {'attributes':
                        {'attr1': 'param1',
                         'attr2': 'param2'},
                     'state': 'Available',
                     'type': '03-08-08 Ethernet I/F'}
                    }
                }
    assert hardware

# Generated at 2022-06-22 22:54:28.090946
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    collector = AIXHardwareCollector()
    assert collector is not None



# Generated at 2022-06-22 22:54:39.696906
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    """
    test_AIXHardware_get_mount_facts: Test that all mounts are displayed
    """
    AIXHardware_facts = AIXHardware({})

# Generated at 2022-06-22 22:54:50.599917
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    m = AIXHardware()
    cpu_facts = m.get_cpu_facts()

    assert 'processor_count' in cpu_facts, "No processor_count in cpu facts"
    assert 'processor' in cpu_facts, "No processor in cpu facts"
    assert 'processor_cores' in cpu_facts, "No processor_cores in cpu facts"
    assert isinstance(cpu_facts['processor_count'], int), "processor_count is not an integer"
    assert isinstance(cpu_facts['processor_cores'], int), "processor_cores is not an integer"
    assert isinstance(cpu_facts['processor'], str), "processor is not a string"


# Generated at 2022-06-22 22:54:55.740352
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.facts.collector.base import TestAnsibleModule
    from ansible.module_utils.facts.utils import get_file_content

    data = get_file_content('test/unit/module_utils/facts/hardware/aix_lsvg_output')

    if PY3:
        data = data.encode()

    module = TestAnsibleModule(
        argument_spec={
        }
    )
    hardware = AIXHardware(module)
    result = hardware.get_vgs_facts()


# Generated at 2022-06-22 22:55:02.143069
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = Mock(run_command=Mock(return_value=(0, '', '')))
    aixhardware = AIXHardware(module)
    assert aixhardware.get_cpu_facts() == {'processor': ['POWER7'], 'processor_cores': 1, 'processor_count': 2}



# Generated at 2022-06-22 22:55:13.379228
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    """ Unit test for method get_memory_facts of class AIXHardware """
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.hardware.aix import AIXHardware

    class TestModule(object):
        def get_bin_path(self, executable, required=False):
            executable_paths = {'/usr/sbin/lsps -s': '/usr/sbin/lsps',
                                '/usr/bin/vmstat -v': '/usr/bin/vmstat'
                                }

            if executable in executable_paths:
                return executable_paths[executable]
            else:
                raise Exception("Binary %s not found" % executable)


# Generated at 2022-06-22 22:55:25.988118
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    """
    Test get_vgs_facts method of class AIXHardware
    """
    aix = AIXHardware()


# Generated at 2022-06-22 22:55:36.527726
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    hardware_collector = AIXHardwareCollector(module=module)
    hardware = hardware_collector.collect()[0]
    assert hardware.memfree_mb == 1015
    assert hardware.memtotal_mb == 2048
    assert hardware.swapfree_mb == 523
    assert hardware.swaptotal_mb == 1024
    assert hardware.processor == 'PowerPC_POWER8'
    assert hardware.processor_cores == 12
    assert hardware.processor_count == 12
    assert hardware.firmware_version == 'SF240_271'
    assert hardware.product_serial == 'XXXXXXXXXXXXXX'
    assert hardware.lpar_info == 'my_lpar_info'

# Generated at 2022-06-22 22:55:40.155695
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    hardware = AIXHardware({})
    hardware.populate()
    assert hardware.factdict['processor']
    assert hardware.factdict['processor_count']
    assert hardware.factdict['processor_cores']



# Generated at 2022-06-22 22:55:49.281054
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec=dict())
    facts_collector = AIXHardware(module)

    facts = facts_collector.get_facts()
    assert 'processor' in facts
    assert 'processor_count' in facts
    assert 'processor_cores' in facts
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'firmware_version' in facts
    assert 'product_serial' in facts
    assert 'product_name' in facts
    assert 'vgs' in facts
    assert 'mounts' in facts
    assert 'devices' in facts

# Generated at 2022-06-22 22:55:57.722486
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    """Using dicts to mock module and module.run_command"""

    mock_module = dict(
        run_command=dict(
            return_value=(0, "", "")
        )
    )

    aix_hardware = AIXHardware(mock_module)
    aix_hardware.module.run_command = lambda cmd, use_unsafe_shell=False: mock_module.run_command
    aix_hardware.module.get_bin_path = lambda cmd, required=True: '/usr/sbin/lsconf'

    # successful run with empty output
    aix_hardware.module.run_command.return_value = (0, "", "")
    result = aix_hardware.get_dmi_facts()
    assert result == {}

    # successful run

# Generated at 2022-06-22 22:56:05.937924
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module_args = dict()
    module_args['gather_subset'] = ['all']
    module_args['gather_timeout'] = 10
    module_args['filter'] = '*'

    from ansible.modules.system.hardware.aix import Platform
    from ansible.module_utils.facts.hardware import Hardware
    from ansible.module_utils.facts import Facts
    facts = Facts(module_args, Platform('aix'), Hardware)
    facts.populate()
    hardware_facts = facts.get('hardware')
    assert hardware_facts['firmware_version'] is not None
    assert hardware_facts['processor_count'] > 0
    assert hardware_facts['vgs'] is not None

# Generated at 2022-06-22 22:56:15.070249
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    class FakeModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, *args, **kwargs):
            pass

        def run_command(self, *args, **kwargs):
            return 0, 'output', 'error'

        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/command'
    module = FakeModule()
    hardware = AIXHardwareCollector(module)

    assert hardware.module == module
    assert hardware.fact_class == module.params['fact_class']
    assert hardware.collect() == {}

# Generated at 2022-06-22 22:56:27.121520
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    import sys
    import os
    import unittest
    # Need to add to path so that module_utils/facts/hardware/aix.py will be discovered
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))))
    from ansible.module_utils.facts.hardware.aix import AIXHardware as AIXHardware_test
    from ansible.module_utils.facts.utils import ModuleDeprecationWarning

    class TestAIXHardware(unittest.TestCase):

        def setUp(self):
            self.mock_module = MockModule()

# Generated at 2022-06-22 22:56:39.051065
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    # For the tests we need to fake the module class, in our case we will use basic module
    module = basic.AnsibleModule(argument_spec=dict())


# Generated at 2022-06-22 22:56:44.240230
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hw_collector = AIXHardwareCollector()
    assert hw_collector._platform == 'AIX'
    assert hw_collector._fact_class is not None
    assert hw_collector._fact_class.__name__ == 'AIXHardware'
    assert hw_collector._fact_class.platform == 'AIX'


# Generated at 2022-06-22 22:56:49.113982
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    aixhardware = AIXHardware(module)
    cpu_facts = aixhardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 3
    assert cpu_facts['processor'] == 'PowerPC_POWER5'
    assert cpu_facts['processor_cores'] == 4



# Generated at 2022-06-22 22:56:51.840847
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    m = AIXHardwareCollector(None)
    assert isinstance(m, AIXHardwareCollector)
    assert isinstance(m._fact_class, AIXHardware)
    assert m._platform == 'AIX'


# Generated at 2022-06-22 22:57:03.432576
# Unit test for method get_mount_facts of class AIXHardware

# Generated at 2022-06-22 22:57:07.055758
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModuleMock()
    hardware = AIXHardware(module)

    module.run_command = run_command_mock
    hardware.module = module

    hardware.get_device_facts()



# Generated at 2022-06-22 22:57:17.494567
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    class ModuleMock(object):
        def __init__(self):
            self.run_command_calls = []

        # Method run_command of class ModuleMock
        def run_command(self, cmd, use_unsafe_shell=False, check_rc=True):
            self.run_command_calls.append((cmd, use_unsafe_shell, check_rc))
            if cmd == '/usr/bin/vmstat -v':
                return 0, 'memory pages: 1600000\nfree pages: 1599999', None
            elif cmd == '/usr/sbin/lsps -s':
                return 0, 'PAGESIZE:      4096\n'

# Generated at 2022-06-22 22:57:23.109069
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec={
            'gather_subset': dict(default=['!all'], type='list'),
        }
    )
    obj = AIXHardware(module=module)
    result = obj.get_cpu_facts()
    assert ('processor_count' in result)
    assert ('processor' in result)


# Generated at 2022-06-22 22:57:33.079793
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    """ Unit test for constructor of class AIXHardwareCollector"""
    from ansible.module_utils.facts.hardware.aix import AIXHardwareCollector

    # check if _platform is set correctly
    aix_hardware_collector = AIXHardwareCollector()
    assert aix_hardware_collector._platform == 'AIX'

    # check if platform is set correctly
    aix_hardware_collector = AIXHardwareCollector()
    assert aix_hardware_collector.platform == 'AIX'

    # check if _fact_class is set correctly
    aix_hardware_collector = AIXHardwareCollector()
    assert aix_hardware_collector._fact_class == AIXHardware



# Generated at 2022-06-22 22:57:42.805319
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    """
    Purpose:
      Unit test to verify that the method get_device_facts of AIXHardware class returns
      the expected device facts.
    Arguments:
      None.
    Return:
      None.
    """
    # Set up a mock module and mock class.
    module = MockModule()
    fact_class = AIXHardware()
    # Set up lsdev and lsattr commands to be used by get_device_facts method.
    lsdev_path = '/usr/bin/mock_lsdev'
    lsattr_path = '/usr/bin/mock_lsattr'
    # Create mock output for lsdev command.

# Generated at 2022-06-22 22:57:55.436335
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    """
    Unit test for method AIXHardware.populate of class AIXHardware
    """
    module = AnsibleModule(argument_spec={},
                           supports_check_mode=False)

    # Mock class to load data for processing

# Generated at 2022-06-22 22:57:57.992772
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    """
    Test constructor of class AIXHardware
    """
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    assert hardware.platform == 'AIX'


# Generated at 2022-06-22 22:58:01.161159
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = AIXHardware(module)
    result = hardware.get_vgs_facts()
    module.exit_json(changed=False, ansible_facts=result)



# Generated at 2022-06-22 22:58:07.125183
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    hardware = Hardware()
    assert hardware.get_memory_facts()['memtotal_mb'] == 314368
    assert hardware.get_memory_facts()['memfree_mb'] == 314368
    assert hardware.get_memory_facts()['swaptotal_mb'] == 1
    assert hardware.get_memory_facts()['swapfree_mb'] == 1

# Generated at 2022-06-22 22:58:10.550618
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = FakeAnsibleModule()
    module.params = {'gather_subset': ['all']}
    hw = AIXHardware(module)
    assert hw.module == module


# Generated at 2022-06-22 22:58:12.657035
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    aix_hardware = AIXHardware(dict())
    assert aix_hardware.platform == 'AIX'

# Generated at 2022-06-22 22:58:14.636273
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    assert AIXHardware(dict()).platform == 'AIX'


# Generated at 2022-06-22 22:58:26.589242
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils._text import to_bytes
    import os

    # Copy file lsvg to /tmp for tests
    file_path = os.path.join(os.path.dirname(__file__), '_lsvg')

# Generated at 2022-06-22 22:58:29.063029
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    x = AIXHardwareCollector()
    assert x._platform == 'AIX'
    assert x._fact_class == AIXHardware

# Generated at 2022-06-22 22:58:37.928710
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware_collector = AIXHardwareCollector(module=module, subcollector_class=AIXHardware)
    vgs_facts = hardware_collector.collect()['vgs']
    assert(vgs_facts['rootvg'][0]['pv_name'] == 'hdisk0')
    assert(vgs_facts['rootvg'][0]['pv_state'] == 'active')
    assert(vgs_facts['rootvg'][0]['total_pps'] == '546')
    assert(vgs_facts['rootvg'][0]['free_pps'] == '0')
    assert(vgs_facts['rootvg'][0]['pp_size'] == '4 Megabyte(s)')


# Generated at 2022-06-22 22:58:49.304886
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    class FakeObj():
        def __init__(self):
            self.name = "FakeName"
            self.return_code = 0
            self.command = "FakeCommand"
            self.stderr = "FakeError"
            self.stdout = "FakeOut"

    cpu_facts = AIXHardware(FakeObj()).get_cpu_facts()
    assert 'processor' in cpu_facts
    assert isinstance(cpu_facts['processor'], list)
    assert 'processor_cores' in cpu_facts
    assert isinstance(cpu_facts['processor_cores'], int)
    assert 'processor_count' in cpu_facts
    assert isinstance(cpu_facts['processor_count'], int)



# Generated at 2022-06-22 22:58:53.626645
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hw_facts = AIXHardware(module)
    hw_facts.populate()
    print(json.dumps(hw_facts.device_facts))


if __name__ == '__main__':
    main()

# Generated at 2022-06-22 22:58:58.767451
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    # Unit test using mocked module
    module = AnsibleModule(argument_spec={})

    # Creating an instance of AIXHardware
    aix_hw = AIXHardware(module)

    # Getting the facts
    aix_facts = aix_hw.populate()

    assert 'firmware_version' in aix_facts



# Generated at 2022-06-22 22:59:09.167316
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    f =AIxHardware(module)

    # test swap
    module.run_command = mock_run_command((0,"Device\n/dev/ada0p3\n314368\n0\n314368\n0%\n", ""))
    assert f.get_memory_facts()["swaptotal_mb"] == 314368
    assert f.get_memory_facts()["swapfree_mb"] == 314368

    # test swap with full swap 
    module.run_command = mock_run_command((0, "Device\n/dev/ada0p3\n314368\n314368\n0\n100%\n", ""))
    assert f.get_memory_facts()["swaptotal_mb"] == 314368
    assert f.get

# Generated at 2022-06-22 22:59:12.043379
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    mod = type('Module', (object,), {'run_command': lambda x: (0, '', '')})()

    obj = AIXHardware(mod)

# Generated at 2022-06-22 22:59:14.620679
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    h = AIXHardware()
    assert h
    assert h.kernel == "AIX"
    assert h.os == "AIX"


# Generated at 2022-06-22 22:59:24.917650
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():

    # Create a subclass of AIXHardware to mock the run_command method
    class MockAIXHardware(AIXHardware):

        # Mock the run_command method
        def __init__(self, module):
            self.module = module


# Generated at 2022-06-22 22:59:31.842861
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    # Creating the module and passing it 'fake' facts
    fake_ansible_module = FakeAnsibleModule()
    fake_ansible_module.params = {'gather_subset': [], 'filter': '*'}
    hardware_fact_instance = AIXHardware(fake_ansible_module)
    hardware_fact_instance.populate()
    vgs_facts = hardware_fact_instance.get_vgs_facts()
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == "hdisk0"
    assert vgs_facts['vgs']['rootvg'][0]['pv_state'] == "active"
    assert vgs_facts['vgs']['rootvg'][0]['total_pps'] == "546"
    assert vgs_

# Generated at 2022-06-22 22:59:38.908934
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    mock_module = MockModule()
    mock_module.run_command = _mock_run_command
    aix_hw = AIXHardware(mock_module)
    memory_facts = aix_hw.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 262312
    assert memory_facts['memfree_mb'] == 90560
    assert memory_facts['swaptotal_mb'] == 471859
    assert memory_facts['swapfree_mb'] == 354746



# Generated at 2022-06-22 22:59:50.846679
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)

    # Test normal output of commands
    module.run_command = MagicMock(return_value=(0, '', ''))
    hardware.populate()
    module.run_command.assert_any_call('/usr/sbin/lsdev -Cc processor')
    module.run_command.assert_any_call('/usr/sbin/lsattr -El sys0 -a fwversion')
    module.run_command.assert_any_call('lsconf')
    module.run_command.assert_any_call('/usr/bin/vmstat -v')
    module.run_command.assert_any_call('/usr/sbin/lsps -s')

# Generated at 2022-06-22 22:59:58.355035
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModuleMock()

# Generated at 2022-06-22 23:00:08.662768
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    from ansible.module_utils.facts import collector

    module = AnsibleModule(argument_spec=dict())
    # the module argument is set to None because it is not needed here
    # but this method expects it
    facts = collector.get_platform_facts(module=None)
    test_module = type('module', (object,), facts)
    test_module.get_bin_path = lambda x: x  # mock get_bin_path to make it return the binary name as path
    test_module.run_command = lambda x: (0, 'lsvg -o | xargs lsvg -p', '')
    aix_hardware = AIXHardware(module=test_module)
    result = aix_hardware.get_vgs_facts()

# Generated at 2022-06-22 23:00:20.378909
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    class module(object):
        def __init__(self):
            self.params = {}
            self.fail_json = None


# Generated at 2022-06-22 23:00:30.220140
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    out_lsdev_cmd = """
    proc0 Available 00-00 Processor
    proc1 Available 00-01 Processor
    proc2 Available 00-02 Processor
    proc3 Available 00-03 Processor
    """

    out_lsattr_cmd = """
    type PowerPC_POWER5
    smt_threads 1
    state enable
    """

    set_module_args(dict(
        gather_subset='!all',
        filter=dict(type='processor', status='Available')
    ))

    lsdev_cmd = module.get_bin_path('lsdev', True)
    lsattr_cmd = module.get_bin_path('lsattr', True)

    hw = AIXHardware()

    cpu

# Generated at 2022-06-22 23:00:40.795185
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():

    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-22 23:00:42.086787
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    aixhw = AIXHardware()
    assert isinstance(aixhw, AIXHardware)



# Generated at 2022-06-22 23:00:50.288777
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    collecter = AIXHardwareCollector()
    facts = collecter.collect()
    assert facts['processor'][0] == 'PowerPC_POWER8'
    assert facts['processor_count'] == 2
    assert facts['processor_cores'] == 1
    assert facts['firmware_version'] == 'IBM,910-4126'
    assert facts['lpar_info'] == '2 6 3 AIX'
    assert facts['product_name'] == 'IBM,8286-41A'

# Generated at 2022-06-22 23:00:54.320966
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    hardware = AIXHardware(module)
    cpu_facts = hardware.get_cpu_facts()

    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'PowerPC_POWER8'
    assert cpu_facts['processor_cores'] == 2


# Generated at 2022-06-22 23:00:57.656755
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    # Creating AIXHardwareCollector object
    hardware_obj = AIXHardwareCollector()
    assert hardware_obj._platform == 'AIX'
    assert hardware_obj._fact_class == AIXHardware

# Generated at 2022-06-22 23:01:09.498323
# Unit test for method get_mount_facts of class AIXHardware

# Generated at 2022-06-22 23:01:17.068533
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    hardware = AIXHardware()
    hardware.module = AnsibleModule(argument_spec={})
    hardware.module.run_command = Mock(return_value=(0, '', ''))
    hardware.module.get_bin_path = Mock(return_value='')
    hardware.module._socket_path = '/tmp/socket'
    hardware.populate()
    assert hardware.get_device_facts() == {'devices': {}}

# Generated at 2022-06-22 23:01:25.236878
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    aix_h = AIXHardware(dict())

    aix_h.module.run_command = mock_run_command
    aix_h.module.get_bin_path = mock_get_bin_path

    dmi_facts = aix_h.get_dmi_facts()
    assert dmi_facts == {
        'firmware_version': '6.1.11.10',
        'product_serial': '0214A5E',
        'lpar_info': 'n/a',
        'product_name': 'IBM,8286-42A'
    }



# Generated at 2022-06-22 23:01:37.464397
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    class MockModule:
        def __init__(self):
            self.run_command_return_value = (0, '', '')
            self.get_bin_path_return_value = ''

        def run_command(self, args):
            return self.run_command_return_value

        def get_bin_path(self, args, require_executability=False):
            return self.get_bin_path_return_value

    def preset_run_command_return_value(ret_value):
        m.run_command_return_value = ret_value

    def preset_get_bin_path_return_value(ret_value):
        m.get_bin_path_return_value = ret_value

    # lsattr -E -l hdisk0
    # PCM/adapter                PCM/ad

# Generated at 2022-06-22 23:01:44.856490
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    """
    Test get_cpu_facts of class AIXHardware
    """
    module = MockModule()
    hardware = AIXHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'PowerPC_POWER8'
    assert cpu_facts['processor_cores'] == 8
    assert cpu_facts['processor'] == 'PowerPC_POWER8'



# Generated at 2022-06-22 23:01:52.012750
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    aixhw = AIXHardwareCollector()
    mem_facts = aixhw.get_memory_facts()
    assert type(mem_facts) is dict
    assert 'memtotal_mb' in mem_facts
    assert 'memfree_mb' in mem_facts
    assert 'swaptotal_mb' in mem_facts
    assert 'swapfree_mb' in mem_facts



# Generated at 2022-06-22 23:02:00.736558
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    """
    Test method get_vgs_facts of class AIXHardware.
    """
    import ansible.module_utils.facts.hardware.aix as aix


# Generated at 2022-06-22 23:02:11.932037
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    test_module = AnsibleModule(argument_spec={})
    test_module.exit_json = exit_json
    test_module.fail_json = fail_json

    # Test get_device_facts function of AIXHardware class with a valid output

# Generated at 2022-06-22 23:02:24.011518
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    m = AIXHardware({})

    # Set up dummy mocks for commands and the input from each command
    m.module.run_command = lambda x, y: (0, "", "")
    m.module.run_command.__name__ = 'run_command'

    m.module.get_bin_path = lambda x: '/usr/bin/' + x
    m.module.get_bin_path.__name__ = 'get_bin_path'


# Generated at 2022-06-22 23:02:35.069427
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    """
    AIXHardware.get_mount_facts()
    """
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )


# Generated at 2022-06-22 23:02:37.591044
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    collector = AIXHardwareCollector()
    assert collector.platform == 'AIX'
    assert collector.fact_class == AIXHardware


# Generated at 2022-06-22 23:02:44.218363
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    out = '1:        memory pages                              =            366096\n' \
          '2:        free pages                                 =             55290'

    module = AnsibleModuleMock()
    module.run_command = MagicMock()

    module.run_command.return_value = 0, out, ''

    aix = AIXHardware(module=module)

    memory = aix.get_memory_facts()

    assert memory['memtotal_mb'] == 1416
    assert memory['memfree_mb'] == 21

# Generated at 2022-06-22 23:02:52.934225
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={})
    facts = AIXHardware(module)
    assert isinstance(facts.get_cpu_facts(), dict)
    assert isinstance(facts.get_memory_facts(), dict)
    assert isinstance(facts.get_dmi_facts(), dict)
    assert isinstance(facts.get_vgs_facts(), dict)
    assert isinstance(facts.get_mount_facts(), dict)
    assert isinstance(facts.get_device_facts(), dict)
    assert isinstance(facts.populate(), dict)


from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 23:02:55.746876
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hc = AIXHardwareCollector()
    assert hc.platform == 'AIX'
    assert hc.fact_class == AIXHardware


# Generated at 2022-06-22 23:03:03.725165
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    hardware = AIXHardware()
    hardware._module = AnsibleModule(argument_spec=dict())
    hardware._module.run_command = MagicMock(return_value=(0, "IBM,7247-22L", ""))
    hardware._module.get_bin_path = MagicMock(return_value="/usr/sbin/lsconf")
    hardware._module.run_command = MagicMock(return_value=(0, "Serial Number:                         1234A567890\nSystem Model:                          IBM,8233-E8B", ""))


# Generated at 2022-06-22 23:03:16.008525
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    hardware = AIXHardware(dict(module=dict()))
    hardware.module.run_command = run_command_mock

    hardware.populate()


# Generated at 2022-06-22 23:03:21.838217
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={})
    rh = AIXHardware(module)

    assert rh.platform == 'AIX'

    assert rh.get_cpu_facts()

    assert rh.get_memory_facts()

    assert rh.get_dmi_facts()

    assert rh.get_mount_facts()

    assert rh.get_device_facts()

    assert rh.populate()



# Generated at 2022-06-22 23:03:31.728835
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    """
    Method get_dmi_facts of class AIXHardware returns a dictionary
    with the firmware and product serial number of a AIX system.
    """
    test_module = type('', (object,), dict(run_command=lambda *_, **__: (0, 'IBM,C1B3C1EA', None)))
    test_module.get_bin_path = lambda *_, **__: '/usr/sbin/lsattr'
    result = AIXHardware(test_module).get_dmi_facts()
    assert result == {'firmware_version': 'C1B3C1EA', 'product_serial': 'IBM,C1B3C1EA'}


# Generated at 2022-06-22 23:03:33.671630
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    collector = AIXHardwareCollector()
    assert collector.platform == 'AIX'
    assert collector.fact_class == AIXHardware


# Generated at 2022-06-22 23:03:35.538256
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    ah = AIXHardware(module=None)
    assert ah.platform == 'AIX'


# Generated at 2022-06-22 23:03:44.736940
# Unit test for method get_vgs_facts of class AIXHardware

# Generated at 2022-06-22 23:03:56.455904
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    """
    Test method get_device_facts of class AIXHardware
    """

    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False
    )

    aix_hw = AIXHardware(module)

    # test for AIX 7.1
    aix_hw.module.run_command = MagicMock(return_value=(0,
                                                        """hdisk0 Available 00-00-05-73-00-06-4D-02 FCP SCSI Disk Drive
                                                        fscsi0 Available 00-00-05-73-00-06-4D-02 
                                                        fscsi1 Available 00-00-05-73-00-06-4D-02 """,
                                                        ""))
    aix_hw.module.get_bin_path = Magic