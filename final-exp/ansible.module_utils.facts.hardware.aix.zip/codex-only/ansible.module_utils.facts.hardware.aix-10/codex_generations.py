

# Generated at 2022-06-22 22:53:45.813130
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    device_facts = AIXHardware.get_device_facts()
    assert device_facts != {}

# Generated at 2022-06-22 22:53:56.242606
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    """
    AIXHardware.get_cpu_facts() Test method
    """
    # Test 0: no output, test condition:
    # - out == None
    # Expected result:
    # - cpu_facts['processor'] == None
    # - cpu_facts['processor_cores'] == None
    # - cpu_facts['processor_count'] == None
    module = AnsibleModule(argument_spec={})
    out = None
    result = AIXHardware.get_cpu_facts(module, out)
    assert result['processor'] is None
    assert result['processor_cores'] is None
    assert result['processor_count'] is None

    # Test 1: empty output, test condition:
    # - out == ''
    # Expected result:
    # - cpu_facts['processor'] == None
    # - cpu_facts

# Generated at 2022-06-22 22:54:08.366070
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec=dict())
    hw = AIXHardware(module)
    result = hw.get_vgs_facts()
    assert result['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert result['vgs']['rootvg'][0]['pv_state'] == 'active'
    assert result['vgs']['rootvg'][0]['total_pps'] == '546'
    assert result['vgs']['rootvg'][0]['free_pps'] == '0'
    assert result['vgs']['rootvg'][0]['pp_size'] == '4 megabyte(s)'
    assert result['vgs']['rootvg'][1]['pv_name'] == 'hdisk1'

# Generated at 2022-06-22 22:54:14.823315
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    """
    Unit test for method populate of class AIXHardware.
    """
    hardware_facts = AIXHardware(None)
    hardware_facts.populate()
    assert hardware_facts.facts['memory_mb']['real']['total'] > 0
    assert hardware_facts.facts['memory_mb']['swap']['total'] > 0

# Generated at 2022-06-22 22:54:23.577092
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    test_module = AnsibleModule(argument_spec={})
    test_hw = AIXHardware()
    test_hw.module = test_module
    test_get_cpu_facts = test_hw.get_cpu_facts()
    assert test_get_cpu_facts["processor_count"] >= 1
    assert isinstance(test_get_cpu_facts["processor_count"], int)
    assert test_get_cpu_facts["processor_cores"] >= 1
    assert isinstance(test_get_cpu_facts["processor_cores"], int)
    assert len(test_get_cpu_facts["processor"]) >= 1


# Generated at 2022-06-22 22:54:35.652321
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    import sys
    import os

    from ansible.compat.tests import unittest

    test_dir = os.path.dirname(os.path.realpath(__file__))
    test_root = os.path.dirname(test_dir)
    modules_dir = os.path.dirname(test_root)
    sys.path.insert(0, modules_dir)

    from ansible.module_utils.facts import collector

    # init module_utils.facts collector
    collector.collect()
    collected_facts = collector._COLLECTED_FACTS

    class TestAIXHardwareModule(unittest.TestCase):
        def setUp(self):
            self.facts_module = AIXHardware(collector.Facts())
            self.facts_module.populate()

    test_case = TestAIX

# Generated at 2022-06-22 22:54:44.047255
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    import shutil
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    test_obj = AIXHardware()
    test_obj.module = module
    test_obj.module.get_bin_path = lambda x, y: shutil.which(x)
    vgs_facts = test_obj.get_vgs_facts()
    assert vgs_facts['vgs'] is not None
    assert vgs_facts['vgs']['rootvg'] is not None
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs_facts['vgs']['rootvg'][0]['pv_state'] == 'active'

# Generated at 2022-06-22 22:54:46.110032
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware = AIXHardware(dict())
    assert hardware.platform == 'AIX'

# Generated at 2022-06-22 22:54:52.954985
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    '''
    Unit test for constructor of class AIXHardware
    '''

    module = AnsibleModule(argument_spec={})
    aix_hardware = AIXHardware(module)

    assert (aix_hardware.module)
    assert (aix_hardware.facts['system'] == 'AIX')
    assert (aix_hardware.facts['kernel'] == 'AIX')


# Generated at 2022-06-22 22:54:57.009197
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():

    hardware_obj = AIXHardware()
    cpu_facts = hardware_obj.get_cpu_facts()
    assert cpu_facts['processor'] == "PowerPC_POWER8"
    assert cpu_facts['processor_count'] == 4
    assert cpu_facts['processor_cores'] == 1


# Generated at 2022-06-22 22:55:09.650699
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module=module)

    # Test the mock data
    vgs_facts = hardware.get_vgs_facts()

# Generated at 2022-06-22 22:55:15.677177
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    attrs = {'run_command.side_effect': [[1, "", ""]]}
    module = FakeAnsibleModule(**attrs)
    AIXHardware.get_device_facts(module)
    assert module.exit_json.called
    result = module.exit_json.call_args[0][0]
    assert result['devices'] == {}


# Generated at 2022-06-22 22:55:17.532742
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector is not None

# Generated at 2022-06-22 22:55:29.479991
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModuleMock()
    module.run_command = mock.Mock(return_value=(0, '', ''))
    hardware = AIXHardware(module)
    # test populate of High level Facts
    hardware.populate()
    assert hardware.facts['ansible_processor_count'] == 12
    # test populate of CPU facts
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'PowerPC_POWER4'
    assert cpu_facts['processor_cores'] == 4
    assert cpu_facts['processor_count'] == 12
    # test populate of Memory facts
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memfree_mb'] == 12345
    assert memory_facts['memtotal_mb'] == 23456
    assert memory_facts

# Generated at 2022-06-22 22:55:39.574536
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    class AIModule:
        def __init__(self):
            self.run_command_calls = []
            self.get_bin_path_calls = []

        def run_command(self, command, use_unsafe_shell=False):
            self.run_command_calls.append(command)
            if command == '/usr/sbin/mount':
                return (0, 'node            mounted        mounted over    vfs   date        opts        account\n'
                           '/dev/hd1        /              /dev/hd2        jfs2  Aug 26 12:27   rw,log=/dev/hd8\n', '')
            else:
                return (0, '', '')

        def get_bin_path(self, executable, required=False):
            self.get_bin_path_c

# Generated at 2022-06-22 22:55:45.153363
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    h = AIXHardware(dict())

    output = """
proc0 Available 00-00 Processor
proc1 Available 00-01 Processor
proc4 Defined   00-04 Processor
proc5 Defined   00-05 Processor
proc6 Defined   00-06 Processor
proc7 Defined   00-07 Processor
"""

    h.module.run_command = lambda *a, **kw: (0, output, '')

    # Calculate get_cpu_facts

    cpu_facts = h.get_cpu_facts()
    assert cpu_facts['processor_count'] == 6
    assert cpu_facts['processor'] == 'PowerPC_POWER8'
    assert cpu_facts['processor_cores'] == 4


# Generated at 2022-06-22 22:55:49.238133
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    module = AnsibleModuleMock()
    aix_hw_collector = AIXHardwareCollector(module)
    assert aix_hw_collector.platform == 'AIX'
    assert aix_hw_collector.fact_class == AIXHardware


# Generated at 2022-06-22 22:55:53.604852
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware_obj = AIXHardware()
    assert hardware_obj.platform == 'AIX'
    assert hardware_obj.all_blocks == ['/dev/hdisk0', '/dev/hdisk1', '/dev/hdisk2', '/dev/hdisk3', '/dev/hdisk4', '/dev/hdisk5', '/dev/hdisk6']



# Generated at 2022-06-22 22:55:59.093042
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():

    # Data
    facts = {}
    facts['processor'] = []
    module = object()
    setattr(module, 'run_command', mock_run_command)

    # Mocks
    aix_hw = AIXHardware(module)

    # Execution
    aix_hw.get_cpu_facts()

    # Assertions
    assert aix_hw.facts['processor_cores'] == 2
    assert aix_hw.facts['processor_count'] == 4
    assert aix_hw.facts['processor'] == ['PowerPC_POWER7']



# Generated at 2022-06-22 22:56:01.356375
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware_obj = AIXHardware(module)
    memory_facts = hardware_obj.get_memory_facts()
    assert isinstance(memory_facts, dict)


# Generated at 2022-06-22 22:56:08.764887
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = AIXHardware(module)
    expected_out = {
        'memfree_mb': 2343,
        'memtotal_mb': 2445,
        'swapfree_mb': 32,
        'swaptotal_mb': 20
    }
    module.run_command = MagicMock(return_value=(0, 'memory pages  :   2465\nfree pages    :   2343\n', None))
    module.run_command.side_effect = [(0, 'memory pages  :   2465\nfree pages    :   2343\n', None), (0, 'Device          1M-blocks     Used    Avail Capacity\n/dev/ada0p3        314368        0   314368     0%\n', None)]
    actual_out

# Generated at 2022-06-22 22:56:17.764810
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    result = AIXHardware(module).populate()
    assert 'memtotal_mb' in result
    assert 'memfree_mb' in result
    assert 'swaptotal_mb' in result
    assert 'swapfree_mb' in result
    assert 'processor' in result
    assert 'processor_cores' in result
    assert 'processor_count' in result
    assert 'firmware_version' in result
    assert 'product_serial' in result
    assert 'lpar_info' in result
    assert 'product_name' in result
    assert 'vgs' in result
    assert 'mounts' in result
    assert 'devices' in result

# Generated at 2022-06-22 22:56:20.917882
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    (module, hardware) = get_test_AIXHardware()
    hardware.get_dmi_facts()
    assert 'firmware_version' in hardware.facts



# Generated at 2022-06-22 22:56:25.426346
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule({})
    hardware = AIXHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor']
    assert cpu_facts['processor_count']
    assert cpu_facts['processor_cores']


# Generated at 2022-06-22 22:56:32.277148
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock

    aix_hw = AIXHardware(module)
    facts = aix_hw.populate()

    assert facts['firmware_version'] == 'V7R2M0.9123'
    assert facts['processor_count'] == 8
    assert facts['processor_cores'] == 8
    assert facts['processor'] == 'POWER8'
    assert facts['memtotal_mb'] == 1048
    assert facts['memfree_mb'] == 1048
    assert facts['swaptotal_mb'] == 16
    assert facts['swapfree_mb'] == 16
    assert facts['product_name'] == 'IBM,8286-41A'
    assert facts['product_serial'] == '12345ABCDE'
    assert facts

# Generated at 2022-06-22 22:56:44.240331
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    hardware = AIXHardware()
    hardware.module = AnsibleModule
    hardware.module.run_command = Mock(return_value=(0, '', ''))


# Generated at 2022-06-22 22:56:45.933510
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    collector = AIXHardwareCollector()
    assert collector._platform == 'AIX'
    assert collector._fact_class == AIXHardware


# Generated at 2022-06-22 22:56:53.343029
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    # Helper class to mock module.run_command
    class RunCommand:
        def __init__(self, result):
            self.result = result
            self.params = []
            self.kwargs = []

        def __call__(self, args, **kwargs):
            self.params.append(args)
            self.kwargs.append(kwargs)
            return self.result

    expected_result = {}

# Generated at 2022-06-22 22:57:05.875189
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    hardware = AIXHardware({})

# Generated at 2022-06-22 22:57:16.539215
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    hardware = AIXHardware()


# Generated at 2022-06-22 22:57:22.481541
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    hw = AIXHardware(dict(ANSIBLE_MODULE_ARGS={}))
    assert hw.get_dmi_facts() == {'firmware_version': 'IBM,06EZT060', 'lpar_info': '1 MIPROC1ENT',
                                  'product_serial': '9X95DNJ', 'product_name': 'IBM,9119-MME'}


# Generated at 2022-06-22 22:57:23.712886
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    h = AIXHardware({})

# Generated at 2022-06-22 22:57:34.128239
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    facts_collector = AIXHardwareCollector(module=module)
    facts = facts_collector.collect()

    assert facts['firmware_version'] == 'IBM,8247-22L'
    assert facts['processor_cores'] == 4
    assert facts['processor_count'] == 2
    assert facts['processor'] == 'POWER8'
    assert facts['memtotal_mb'] == 47339
    assert facts['memfree_mb'] == 13503
    assert facts['swaptotal_mb'] == 314368
    assert facts['swapfree_mb'] == 314368
    assert facts['product_serial'] == '12345'
    assert facts['lpar_info'] == 'LPAR:1 Virtual IO Client        type:IO    mode:Uncapped'

# Generated at 2022-06-22 22:57:43.706484
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    # Define a mock class to track calls to function run_command
    class Mock_run_command():
        def __init__(self, module):
            self.result_lsattr = ""
            self.result_lsconf = ""
            self.lsattr_called = 0
            self.lsconf_called = 0

        # Mock run_command method
        def __call__(self, command, *args, **kwargs):
            if command == '/usr/sbin/lsattr -El sys0 -a fwversion':
                self.lsattr_called += 1
                return 0, self.result_lsattr, ""
            if command == '/usr/bin/lsconf':
                self.lsconf_called += 1
                return 0, self.result_lsconf, ""


# Generated at 2022-06-22 22:57:56.482918
# Unit test for constructor of class AIXHardware
def test_AIXHardware():

    hardware = AIXHardware()
    assert hardware.collect()['processor'][0] == 'PowerPC_POWER8'
    assert hardware.collect()['processor_count'] == 2
    assert hardware.collect()['processor_cores'] == 4
    assert hardware.collect()['memtotal_mb'] == 65536
    assert hardware.collect()['memfree_mb'] == 3977
    assert hardware.collect()['swaptotal_mb'] == 4096
    assert hardware.collect()['swapfree_mb'] == 4096
    assert hardware.collect()['firmware_version'] == '2.9.0'
    assert hardware.collect()['product_serial'] == '12345678'
    assert hardware.collect()['lpar_info'] == '1 2 3 4'

# Generated at 2022-06-22 22:58:00.060773
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    facts = hardware.get_memory_facts()
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts

# Generated at 2022-06-22 22:58:02.852584
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    ansible_module = AnsibleModule({})
    test_obj = AIXHardware(ansible_module)
    test_dict = test_obj.get_mount_facts()

    assert test_dict
    assert 'mounts' in test_dict



# Generated at 2022-06-22 22:58:09.555161
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    ah = AIXHardware(module=module)

    rc, out, err = module.run_command("/usr/sbin/lsattr -El sys0 -a fwversion")
    data = out.split()
    assert ah.get_dmi_facts() == dict(firmware_version=data[1].strip('IBM,'))



# Generated at 2022-06-22 22:58:23.066288
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.hardware.aix import AIXHardwareCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size

    test_lines = dict(
        product_serial="System Serial Number............1234ABCD\n",
        product_name="System Model......................IBM,8203-E4A\n",
        firmware_version="Firmware Version................IBM,0106B0\n",
    )

    module = AnsibleModuleMock(collector=AIXHardwareCollector(module=AnsibleModuleMock()))
    module.get_file_lines = get_file_lines
    module.get_mount_

# Generated at 2022-06-22 22:58:24.765487
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = FakeAnsibleModule()
    hardware = AIXHardware(module)
    assert hardware.platform == 'AIX'


# Generated at 2022-06-22 22:58:32.103168
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(
        argument_spec=dict(
            filter=dict(required=False, type='list'),
            gather_subset=dict(required=False, type='list')
        ),
        supports_check_mode=True
    )

    if not HAS_AIX_UTILS:
        module.fail_json(msg='AIX utils required for this module')

    hw = AIXHardware()
    facts = hw.populate()

    module.exit_json(ansible_facts=facts)


# Generated at 2022-06-22 22:58:45.281341
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = MockModule()
    hardware = AIXHardware(module=module)

    hardware.populate()


# Generated at 2022-06-22 22:58:47.515478
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hw = AIXHardware({}, None)
    assert hw.platform == 'AIX'

# Generated at 2022-06-22 22:58:59.268658
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = FakeAnsibleModule()
    hardware = AIXHardware(module)
    hardware.get_mount_facts()
    assert hardware.facts['mounts'][0]['mount'] == '/'
    assert hardware.facts['mounts'][0]['device'] == '/dev/hd4'
    assert hardware.facts['mounts'][0]['fstype'] == 'jfs2'
    assert hardware.facts['mounts'][0]['options'] == 'rw'
    assert hardware.facts['mounts'][0]['time'] == 'Jan  1 00:00'
    assert hardware.facts['mounts'][0]['size_total'] == 628864
    assert hardware.facts['mounts'][0]['size_available'] == 597248

# Generated at 2022-06-22 22:59:06.688940
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    import tempfile
    filename = tempfile.mkstemp()
    facts = AIXHardware()
    # test output from lsattr -El sys0 -a fwversion
    fhandle = open(filename[1], 'w')
    fhandle.write('\nfirmware_version    IBM,8233-E8B\n')
    fhandle.close()
    facts.module.run_command = lambda cmd: (0, open(filename[1], 'r').read(), '')

    facts.get_dmi_facts()
    assert facts.firmware_version == 'IBM,8233-E8B'

    # test output from lsconf with lpar_info
    fhandle = open(filename[1], 'w')
   

# Generated at 2022-06-22 22:59:14.226536
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    fct = AIXHardware()
    fcts = fct.populate()
    assert fcts['memtotal_mb'] > 0
    assert fcts['memfree_mb'] > 0
    assert fcts['swaptotal_mb'] > 0
    assert fcts['swapfree_mb'] > 0
    assert len(fcts['processor']) > 0
    assert fcts['processor_cores'] > 0
    assert fcts['processor_count'] > 0

# Generated at 2022-06-22 22:59:15.719939
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    """
    Constructor can be initialized
    """
    AIXHardwareCollector()

# Generated at 2022-06-22 22:59:17.327569
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hw = AIXHardware()
    assert isinstance(hw, AIXHardware)

# Generated at 2022-06-22 22:59:20.507957
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = FakeAnsibleModule()
    aix_fact = AIXHardware(module)
    aix_fact.populate()

    assert module.fail_json.called is False

# Generated at 2022-06-22 22:59:30.524707
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware


# Generated at 2022-06-22 22:59:36.438812
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    current_hardware = AIXHardware()

    current_hardware.populate()
    assert current_hardware.facts['processor_count'] == 4
    assert current_hardware.facts['processor'] == 'PowerPC_POWER8'
    assert current_hardware.facts['firmware_version'] == '9111-520'
    assert current_hardware.facts['lpar_info'] == '1/Default/Primary'
    assert current_hardware.facts['product_name'] == 'IBM,8286-41A'
    assert current_hardware.facts['product_serial'] == '09000000'
    assert current_hardware.facts['memtotal_mb'] == 5936
    assert current_hardware.facts['memfree_mb'] == 1469
    assert current_hardware.facts['swaptotal_mb']

# Generated at 2022-06-22 22:59:42.938561
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    stats = AIXHardware(module)

    rc, out, err = stats.module.run_command("/usr/sbin/lsattr -El sys0 -a fwversion")
    data = out.split()
    fwversion = data[1].strip('IBM,')

    rc, out, err = stats.module.run_command("/usr/bin/lsconf -q sys")
    if rc == 0 and out:
        for line in out.splitlines():
            data = line.split(':')
            if 'Machine Serial Number' in line:
                sn = data[1].strip()
            if 'LPAR Info' in line:
                lparinfo = data[1].strip()
            if 'System Model' in line:
                product = data[1].strip

# Generated at 2022-06-22 22:59:46.479555
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    module = AnsibleModule(argument_spec={})
    hw = AIXHardware(module)
    assert hw.platform == 'AIX'



# Generated at 2022-06-22 22:59:56.102805
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    """
    Unit test to test method get_vgs_facts of class AIXHardware
    """

    class ModuleMock(object):
        """
        Mocks methods of AnsibleModule class
        """
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, exe, required=False):
            return "lsvg"

        def run_command(self, cmd, use_unsafe_shell=False):
            """
            Mocks AnsibleModule.run_command method
            """

# Generated at 2022-06-22 22:59:59.128597
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    aix_collector = AIXHardwareCollector()
    assert aix_collector.platform == 'AIX'
    assert isinstance(aix_collector.collect(), AIXHardware)

# Generated at 2022-06-22 23:00:09.643981
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    """
    Test method get_cpu_facts of class AIXHardware on correct and incorrect
    output of lsdev -Cc processor, lspv, lsattr, swapon and swapon -s commands
    """

    class RunModule:
        def __init__(self, *args, **kwargs):
            self.args = args[0]

# Generated at 2022-06-22 23:00:20.702818
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec=dict())
    results = {}
    ah = AIXHardware(module=module)
    results = ah.get_mount_facts()
    assert 'mounts' in results
    assert type(results['mounts']) == list
    for mount in results['mounts']:
        assert ('mount' in mount and mount['mount'] != "")
        assert ('device' in mount and mount['device'] != "")
        assert ('fstype' in mount and mount['fstype'] != "")
        assert ('options' in mount and mount['options'] != "")
        assert ('time' in mount and mount['time'] != "")
        assert ('size_total' in mount and mount['size_total'] != 0)
        assert ('size_available' in mount and mount['size_available'] != 0)

# Generated at 2022-06-22 23:00:24.663865
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    aix_hc = AIXHardwareCollector()
    assert aix_hc._fact_class == AIXHardware
    assert aix_hc._platform == 'AIX'


# Generated at 2022-06-22 23:00:36.520849
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    """
    Unit test for method get_mount_facts of class AIXHardware:
    """
    class TestModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def run_command(self, cmd, use_unsafe_shell=False):
            return (0, 'node:          /dev/cd0 mount point:  /cdrom  device type: CD-ROM protocol:   ISOFS options:   rw', '')
        def get_bin_path(self, binary, required=False):
            return "/usr/bin/{0}".format(binary)
    module = TestModule()
    ah = AIXHardware(module)
    assert 'mounts' in ah.get_mount_facts()

# Generated at 2022-06-22 23:00:44.174441
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():

    aix_hw = AIXHardware()


# Generated at 2022-06-22 23:00:54.875848
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    """Unit test for get_vgs_facts of class AIXHardware """
    module = AnsibleModule(argument_spec={})
    hardware_info = AIXHardware(module=module)
    vgs_facts = hardware_info.get_vgs_facts()

# Generated at 2022-06-22 23:01:06.821356
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():

    class Device(object):
        def __init__(self, module):
            self.module = module

        def get_bin_path(self, arg):
            return arg

    class AnsibleModule(object):

        def __init__(self):
            self.module = Device(self)

        def get_bin_path(self, arg, opt=None):
            return '/bin/'+arg


# Generated at 2022-06-22 23:01:11.346519
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'gather_subset': ["all"]
    }
    hardware = AIXHardware(module)
    module.exit_json(ansible_facts=hardware.populate())


# Generated at 2022-06-22 23:01:14.152381
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    hardware = AIXHardware()
    assert hardware.platform == "AIX"
    assert hardware.populate()


# Generated at 2022-06-22 23:01:23.021581
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    ah = AIXHardware()
    ah.module = DummyModule()
    ah.module.run_command = DummyRunCommand({"/usr/bin/vmstat -v": (0, AIX_VMSTAT_V, "")})
    expected_memory_facts = {
        'memtotal_mb': 82799,
        'memfree_mb': 14721,
        'swaptotal_mb': 16384,
        'swapfree_mb': 16383
    }
    assert ah.get_memory_facts() == expected_memory_facts



# Generated at 2022-06-22 23:01:28.930275
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule()
    hardware = AIXHardware(module)
    with open('/tmp/lsvg', 'w') as file:
        file.write("rootvg:\n")
        file.write("PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION\n")
        file.write("hdisk0            active            546         0           00..00..00..00..00\n")
        file.write("hdisk1            active            546         113         00..00..00..21..92\n")
        file.write("realsyncvg:\n")
        file.write("PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION\n")

# Generated at 2022-06-22 23:01:31.629064
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = DummyAnsibleModule()
    hardware = AIXHardware(module)
    hardware.get_memory_facts()



# Generated at 2022-06-22 23:01:37.564373
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    # initialize module class
    module = AnsibleModule(argument_spec={})
    hw = AIXHardware(module=module)

    mem_facts = hw.get_memory_facts()

    facts = {'memfree_mb': '339', 'swaptotal_mb': '2048', 'memtotal_mb': '4096', 'swapfree_mb': '2048'}

    assert mem_facts == facts

# Generated at 2022-06-22 23:01:44.568872
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(
        argument_spec=dict()
    )

    hardware_mock = AIXHardware({'module': module})

    assert hardware_mock.get_dmi_facts() == {
        'firmware_version': '1.2 3.4 5',
        'product_serial': '123456',
        'lpar_info': 'someinfo',
        'product_name': 'product_name'
    }

# Generated at 2022-06-22 23:01:56.250973
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    class mod:
        def __init__(self):
            self.params = {}
            self.run_command_out = []
        def get_bin_path(self, cmd, trueroot=False):
            cmdlist = {
                'lsdev': '/usr/sbin/lsdev',
                'mount': '/usr/sbin/mount',
                'lsvg': '/usr/sbin/lsvg',
                'xargs': '/usr/bin/xargs',
                'lsconf': '/usr/sbin/lsconf'
            }
            return cmdlist[cmd]
        def run_command(self, cmd, use_unsafe_shell=False):
            if cmd.startswith('/usr/sbin/lsdev') or cmd.startswith('/usr/sbin/lsattr'):
                self.run

# Generated at 2022-06-22 23:02:08.546057
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    test_obj = AIXHardware()

# Generated at 2022-06-22 23:02:14.772604
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    # Mock module and its methods
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    # Mock object
    aix_hw = AIXHardware(module)
    # Call method and check
    aix_hw.get_dmi_facts()
    assert aix_hw.firmware_version == '7.1.0.0'
    assert aix_hw.product_serial == '1234567890'
    assert aix_hw.lpar_info == '1'
    assert aix_hw.product_name == 'IBM,9117-MMA'


# Generated at 2022-06-22 23:02:23.748877
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    module.run_command = MagicMock(return_value=(0, '', ''))
    set_module_args(dict(
    ))

    from ansible.module_utils.facts.hardware.aix import AIXHardware
    
    # Call it
    aixhardware = AIXHardware(module)
    aixhardware.get_device_facts()

    # Verify results
    assert 1 == 1


# Generated at 2022-06-22 23:02:34.815450
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = MockModule()
    hardware = AIXHardware(module)

# Generated at 2022-06-22 23:02:45.269723
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    input = """
rootvg:
PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
hdisk0            active            546         0           00..00..00..00..00
hdisk1            active            546         113         00..00..00..21..92
realsyncvg:
PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
hdisk74           active            1999        6           00..00..00..00..06
testvg:
PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
hdisk105          active            999         838         200..39..199..200..200
hdisk106          active            999         599         200..00..00..199..200"""

# Generated at 2022-06-22 23:02:54.638776
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    input_lsps_out = 'PAGESIZE:            4096\n' \
                     'TOTAL PAGING SPACE:  4165696    Megabytes\n' \
                     'LARGEST FREE        : 3340368    Megabytes\n' \
                     '\n' \
                     'TOTAL PAGING SPACE IN USE:      825328      \n' \
                     'PERCENT OF PAGING SPACE IN USE: 20%\n' \
                     'MAXIMUM PERCENT OF PAGING SPACE IN USE: 95%\n'


# Generated at 2022-06-22 23:03:00.539744
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    # module.run_command returns (rc, out, err) tuple
    module = type('test_module', (object,), {'run_command': lambda *_: (0, test_vmstat_v_out, '')})
    aix = AIXHardware(module)

    expected = {'memfree_mb': 317, 'swapfree_mb': 0, 'memtotal_mb': 377, 'swaptotal_mb': 0}
    actual = aix.get_memory_facts()

    assert expected == actual



# Generated at 2022-06-22 23:03:12.997426
# Unit test for constructor of class AIXHardware
def test_AIXHardware():
    # set up a module object
    module = AnsibleModule(argument_spec={})
    hardware_facts = AIXHardware(module)
    hardware_facts.populate()
    processor_count = hardware_facts.get_fact('processor_count')
    assert processor_count is not None
    assert isinstance(processor_count, str)
    processor = hardware_facts.get_fact('processor')
    assert processor is not None
    assert isinstance(processor, str)
    processor_cores = hardware_facts.get_fact('processor_cores')
    assert processor_cores is not None
    assert isinstance(processor_cores, str)

    memtotal_mb = hardware_facts.get_fact('memtotal_mb')
    assert memtotal_mb is not None
    assert isinstance(memtotal_mb, str)

   

# Generated at 2022-06-22 23:03:22.159819
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    """
    Test case for method get_dmi_facts of class AIXHardware
    """
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts.utils import AnsibleModuleMock
    from ansible.module_utils.facts.utils import MockModuleUtils

    # create mock module
    mock = AnsibleModuleMock()
    mock = MockModuleUtils(module=mock)
    aix_hardware = AIXHardware(module=mock)

    # create return values

# Generated at 2022-06-22 23:03:33.069404
# Unit test for method get_dmi_facts of class AIXHardware

# Generated at 2022-06-22 23:03:42.794327
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    # test case 1

# Generated at 2022-06-22 23:03:49.361002
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule({})
    hardware = AIXHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memfree_mb']
    assert memory_facts['memtotal_mb']
    assert memory_facts['swaptotal_mb']
    assert memory_facts['swapfree_mb']
