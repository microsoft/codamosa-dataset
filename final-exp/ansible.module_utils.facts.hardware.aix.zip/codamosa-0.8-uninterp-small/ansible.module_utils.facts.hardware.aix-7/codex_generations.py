

# Generated at 2022-06-24 21:48:33.618073
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    str_0 = 'j'
    a_i_x_hardware_0 = AIXHardware(str_0)
    a_i_x_hardware_0.get_mount_facts()


# Generated at 2022-06-24 21:48:37.250106
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    str_0 = '0'
    a_i_x_hardware_0 = AIXHardware(str_0)
    a_i_x_hardware_0.get_mount_facts()


# Generated at 2022-06-24 21:48:43.399191
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    str_1 = 'j'
    a_i_x_hardware_1 = AIXHardware(str_1)
    result_0 = a_i_x_hardware_1.get_memory_facts()
    assert result_0['memfree_mb'] == 0
    assert result_0['memtotal_mb'] == 0
    assert result_0['swapfree_mb'] == 0
    assert result_0['swaptotal_mb'] == 0


# Generated at 2022-06-24 21:48:48.659109
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    a_i_x_hardware_0 = AIXHardware(str_0)
    str_0 = 'T^'
    # Test is not correct
    # Test is not correct
    # Test is not correct
    # Test is not correct
    a_i_x_hardware_0.get_mount_facts()


# Generated at 2022-06-24 21:48:59.494096
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    str_0 = 'T^'
    a_i_x_hardware_0 = AIXHardware(str_0)

    curr_dir = os.path.dirname(os.path.realpath(__file__))
    path_lsdev_cmd = os.path.join(curr_dir, 'lsdev_out.txt')
    path_lsattr_cmd = os.path.join(curr_dir, 'lsattr_out.txt')

    with open(path_lsdev_cmd) as lsdev_cmd_output:
        lsdev_cmd_output_lines = lsdev_cmd_output.readlines()
    with open(path_lsattr_cmd) as lsattr_cmd_output:
        lsattr_cmd_output_lines = lsattr_cmd_output.readlines()

    out_lsdev

# Generated at 2022-06-24 21:49:09.060133
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    """
    Test get_memory_facts
    """
    # Define a class MockModule
    class MockModule():
        def __init__(self, cmd, path):
            self.run_command = Mock(return_value=(0, cmd, ""))
            self.get_bin_path = Mock(return_value=path)
        def get_bin_path(self, cmd, required):
            return cmd

    str_0 = 'T^'
    mock_module_0 = MockModule(str_0, str_0)
    a_i_x_hardware_0 = AIXHardware(mock_module_0)
    # ----------
    rc, out, err = a_i_x_hardware_0.module.run_command("/usr/bin/vmstat -v")

# Generated at 2022-06-24 21:49:13.477440
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    str_0 = 'T^'
    a_i_x_hardware_0 = AIXHardware(str_0)
    # Call the method to test
    assert a_i_x_hardware_0.get_cpu_facts() == {}


# Generated at 2022-06-24 21:49:19.807369
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    str_0 = 'l0,d'
    a_i_x_hardware_0 = AIXHardware(str_0)
    a_i_x_hardware_0.module = MockModule()
    a_i_x_hardware_0.module.run_command = Mock(return_value=(0, "", ""))

    a_i_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:49:23.859086
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    str_0 = 'thisIsAString'

    a_i_x_hardware_0 = AIXHardware(str_0)
    a_i_x_hardware_0.module = get_module_mock()
    a_i_x_hardware_0.populate()


# Generated at 2022-06-24 21:49:27.270739
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    str_0 = '2'
    str_1 = 'processor'
    ai_x_hardware_0 = AIXHardware(str_0)
    ai_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:49:58.513395
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():

    # Test with dummy data
    str_0 = 'some_cmd'
    str_1 = 'some_cmd'
    str_2 = 'some_cmd'
    str_3 = 'device'
    str_4 = 'some_cmd'
    list_0 = []
    list_1 = []
    float_0 = float(25)
    float_1 = float(25)

    # Test with dummy data
    str_5 = 'some_cmd'
    str_6 = 'some_cmd'
    str_7 = 'some_cmd'
    str_8 = 'device'
    str_9 = 'some_cmd'
    list_2 = []
    list_3 = []
    float_2 = float(25)
    float_3 = float(25)

    obj = AIXHardware()
    collect_

# Generated at 2022-06-24 21:50:10.725949
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    # unit tests for method get_vgs_facts of class AIXHardware
    # mock module
    failed_conditions = []
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    aix_hardware = AIXHardware(module)
    # mock add_path
    def add_path_mock(self, path, path_list=None, with_subdir=False):
        if not path_list:
            path_list = []
        path_list.append(path)
    aix_hardware.add_path = add_path_mock.__get__(aix_hardware)
    # test
    # mock get_bin_path

# Generated at 2022-06-24 21:50:14.189705
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    # aixfacts = AIXHardware({})
    str_0 = 'T^'
    test_obj_0 = AIXHardware({})
    test_obj_0.get_vgs_facts()
# End of test case


# Generated at 2022-06-24 21:50:15.782959
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    assert len(AIXHardware.get_vgs_facts(test_case_0).keys()) == 1
    assert list(AIXHardware.get_vgs_facts(test_case_0).values())[0]['vgs'] == {}


# Generated at 2022-06-24 21:50:17.219028
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    assert AIXHardwareCollector._platform == 'AIX'
    assert AIXHardwareCollector._fact_class == AIXHardware
    assert AIXHardwareCollector._fact_class().platform == 'AIX'


# Generated at 2022-06-24 21:50:19.747406
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    print('Testing AIXHardware.get_memory_facts()')
    A = AIXHardware()
    out = A.get_memory_facts()
    assert out


# Generated at 2022-06-24 21:50:29.841381
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    str_0 = 'T^'
    str_1 = 's)d'
    str_2 = 'Z'
    str_3 = '7'
    str_4 = '%'
    str_5 = 'lQ#'
    str_6 = 'b%'
    str_7 = 'Cf'
    str_8 = 'f'
    str_9 = 'N8'
    str_10 = 'J'
    str_11 = '4'
    str_12 = 'Z'
    str_13 = 'p|'
    str_14 = '5'
    str_15 = 'n'
    str_16 = 'S'
    str_17 = '@'
    str_18 = '|i'
    str_19 = '}9'
    str_20 = 'k'

# Generated at 2022-06-24 21:50:32.228103
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    facts = AIXHardware()
    device = facts.get_device_facts()
    assert type(device) is dict


# Generated at 2022-06-24 21:50:40.521138
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    lsdev_out = '''
proc0 Available 00-00 Processor
proc2 Available 00-02 Processor
proc3 Available 00-03 Processor
proc4 Available 00-04 Processor
proc5 Available 00-05 Processor
proc6 Available 00-06 Processor
proc7 Available 00-07 Processor
proc8 Available 00-08 Processor
proc9 Available 00-09 Processor
proc10 Available 00-10 Processor
proc11 Available 00-11 Processor
proc12 Available 00-12 Processor
proc13 Available 00-13 Processor
proc14 Available 00-14 Processor
proc15 Available 00-15 Processor
proc16 Available 00-16 Processor
proc17 Available 00-17 Processor
proc18 Available 00-18 Processor
proc19 Available 00-19 Processor
proc20 Available 00-20 Processor
proc21 Available 00-21 Processor
proc22 Available 00-22 Processor
proc23 Available 00-23 Processor
'''
    lsattr

# Generated at 2022-06-24 21:50:43.680272
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    aix_hardware_collector = AIXHardwareCollector()
    assert aix_hardware_collector._platform == 'AIX'
    assert aix_hardware_collector._fact_class == AIXHardware


# Generated at 2022-06-24 21:51:07.025635
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    print('Test Case 1 : Test Case to check constructor of the class')
    print('---------------------------------------------------------------------------')
    print('---------------------------------------------------------------------------')
    collector_0 = AIXHardwareCollector()
    print('---------------------------------------------------------------------------')
    print('---------------------------------------------------------------------------')


# Generated at 2022-06-24 21:51:10.442146
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    try:
        AIXHardwareCollector()
    except Exception as err:
        assert False, str(err)

# Generated at 2022-06-24 21:51:12.824286
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    # pass
    obj_AIXHardwareCollector = AIXHardwareCollector()


# Generated at 2022-06-24 21:51:14.497702
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    facts = AIXHardware()
    assert isinstance(facts, AIXHardware)


# Generated at 2022-06-24 21:51:22.465808
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    aix_hardware_instance = AIXHardware(module)

    rc, out, err = aix_hardware_instance.module.run_command('lsdev -Cc adapter')
    if out:
        adapter_list = out.split('\n')
        i = len(adapter_list)
        while i > 0:
            if 'Available' in adapter_list[i]:
                adapter_name = adapter_list[i].split(':')[0]
                if 'Ethernet' in adapter_list[i]:
                    adapter_subtype = adapter_list[i].split(':')[1].split()[0]
                else:
                    adapter_subtype = ''
                break
            i -= 1


# Generated at 2022-06-24 21:51:25.648071
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    data = AIXHardware.get_dmi_facts()
    assert data



# Generated at 2022-06-24 21:51:28.255315
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    AIXHardware_instance = AIXHardware({},{},{},{})
    AIXHardware_instance.get_memory_facts()


# Generated at 2022-06-24 21:51:30.014590
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    # Test create class object
    obj1 = AIXHardwareCollector(test_case_0)
    assert obj1 is not None



# Generated at 2022-06-24 21:51:31.371142
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hc = AIXHardwareCollector()
    hc.collect()


# Generated at 2022-06-24 21:51:34.001237
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    assert(str(AIXHardwareCollector._platform) == 'AIX')
    assert(isinstance(AIXHardwareCollector._fact_class(), AIXHardware))


# Generated at 2022-06-24 21:51:55.134074
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    test_case_0()


# Generated at 2022-06-24 21:52:01.640386
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    test_case_data_0 = [{'test_0':'test_0'}]

    expected_result_0 = [{'test_0':'test_0'}]

    test_obj = AIXHardware(module=None)

    result_1 = test_obj.get_device_facts()

    assert type(result_1) == type(expected_result_0)

    assert result_1 == expected_result_0


# Generated at 2022-06-24 21:52:02.625004
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    assert True

# Generated at 2022-06-24 21:52:04.295187
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    str_1 = 'Z4'


# Generated at 2022-06-24 21:52:13.722533
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    str_0 = 'T^'
    str_1 = 'G|'
    str_2 = 'Og'
    str_3 = '|!'
    str_4 = '^['
    str_5 = '55'
    str_6 = ']p'
    str_7 = 'sQ'
    str_8 = 'oG'
    str_9 = '-'
    str_10 = 'Yl'
    str_11 = '}'
    str_12 = '4'
    str_13 = 'I'
    str_14 = 'W'
    str_15 = ':'
    str_16 = 'o'
    str_17 = '_'
    str_18 = '8'
    str_19 = '@'
    str_20 = 'w'

# Generated at 2022-06-24 21:52:14.661383
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    assert test_case_0() == 'T^'

# Generated at 2022-06-24 21:52:17.997101
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    # Case 0
    test_obj = AIXHardware(module=None)
    ans_obj = test_obj.get_device_facts()
    assert ans_obj['devices'] == {}


# Generated at 2022-06-24 21:52:19.908280
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    aixhardwarecollector_0 = AIXHardwareCollector()
test_AIXHardwareCollector()


# Generated at 2022-06-24 21:52:20.822585
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    test_case_0()


# Generated at 2022-06-24 21:52:29.794201
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    str_0 = 'T^'

# Generated at 2022-06-24 21:52:54.376263
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    str_0 = 'TN'
    a_i_x_hardware_0 = AIXHardware(str_0)
    var_0 = a_i_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:52:56.916587
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    str_0 = 'TN'
    a_i_x_hardware_0 = AIXHardware(str_0)

    a_i_x_hardware_0.populate()


# Generated at 2022-06-24 21:52:59.511711
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    str_0 = 'DN'
    a_i_x_hardware_0 = AIXHardware(str_0)
    var_0 = a_i_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:53:00.641644
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    _ = AIXHardwareCollector()



# Generated at 2022-06-24 21:53:02.955777
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    str_0 = 'TN'
    a_i_x_hardware_0 = AIXHardware(str_0)


# Generated at 2022-06-24 21:53:05.933098
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    str_0 = 'TN'
    a_i_x_hardware_0 = AIXHardware(str_0)
    a_i_x_hardware_0.get_device_facts()


# Generated at 2022-06-24 21:53:08.742484
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    str_0 = 'TN'
    a_i_x_hardware_0 = AIXHardware(str_0)
    var_0 = a_i_x_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 21:53:11.328167
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    str_0 = 'TN'
    a_i_x_hardware_0 = AIXHardware(str_0)
    assert 'devices' not in a_i_x_hardware_0.get_device_facts()


# Generated at 2022-06-24 21:53:14.068914
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    fact_class = 'AIX'
    test_AIX_hardware_collector_0 = AIXHardwareCollector(fact_class)
    assert test_AIX_hardware_collector_0.fact_class == 'AIX'

# Generated at 2022-06-24 21:53:18.159620
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    # Setting up the test environment
    str_0 = 'TN'
    a_i_x_hardware_0 = AIXHardware(str_0)

    # Invoking the tested method
    var_0 = a_i_x_hardware_0.get_dmi_facts()

    # Asserting the return type
    assert type(var_0) is dict


# Generated at 2022-06-24 21:54:20.835174
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    str_0 = 'TN'
    a_i_x_hardware_0 = AIXHardware(str_0)
    var_0 = a_i_x_hardware_0.get_mount_facts()


# Generated at 2022-06-24 21:54:22.736567
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    # Create an instance of class AIXHardware
    a_i_x_hardware_0 = AIXHardware("TN")
    # Test method get_cpu_facts with arguments
    # Return type: dict
    var_0 = a_i_x_hardware_0.get_cpu_facts()



# Generated at 2022-06-24 21:54:25.268446
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    str_0 = 'TN'
    a_i_x_hardware_0 = AIXHardware(str_0)
    var_0 = a_i_x_hardware_0.get_vgs_facts()


# Generated at 2022-06-24 21:54:28.534304
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    str_0 = 'TN'
    a_i_x_hardware_0 = AIXHardware(str_0)
    var_0 = a_i_x_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 21:54:32.157987
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    str_0 = 'TN'
    a_i_x_hardware_0 = AIXHardware(str_0)
    var_0 = a_i_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:54:33.819412
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    str_0 = 'TN'
    a_i_x_hardware_0 = AIXHardware(str_0)
    var_0 = a_i_x_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 21:54:38.575673
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    str_0 = 'TN'
    a_i_x_hardware_0 = AIXHardware(str_0)
    var_0 = a_i_x_hardware_0.get_vgs_facts()

# Generated at 2022-06-24 21:54:41.842105
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    # Declare the following test case parameters
    #
    #str_0 = "TN"
    #a_i_x_hardware_0 = AIXHardware(str_0)
    # Declare the following test case results
    #
    #var_0 = a_i_x_hardware_0.get_mount_facts()
    assert True # TODO: implement your test here


# Generated at 2022-06-24 21:54:44.109088
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    str_0 = 'TN'
    a_i_x_hardware_0 = AIXHardware(str_0)
    var_0 = a_i_x_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 21:54:47.159073
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    str_0 = '0s'
    a_i_x_hardware_0 = AIXHardware(str_0)
    var_0 = a_i_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:57:03.811411
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    str_0 = 'TN'
    a_i_x_hardware_0 = AIXHardware(str_0)
    var_0 = a_i_x_hardware_0.get_mount_facts()

    # str_1 = 'TN '
    # a_i_x_hardware_1 = AIXHardware(str_1)
    # var_1 = a_i_x_hardware_1.get_mount_facts()
    # print(var_1)



# Generated at 2022-06-24 21:57:08.524469
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    str_0 = 'TN'
    a_i_x_hardware_collector_0 = AIXHardwareCollector(str_0)
    assert isinstance(a_i_x_hardware_collector_0, AIXHardwareCollector)


# Generated at 2022-06-24 21:57:10.033059
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    str_0 = 'TN'
    a_i_x_hardware_0 = AIXHardware(str_0)
    a_i_x_hardware_0.get_device_facts()


# Generated at 2022-06-24 21:57:12.737134
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    str_1 = 'TN'
    a_i_x_hardware_1 = AIXHardware(str_1)
    assert a_i_x_hardware_1.populate() == AIXHardware().populate()


# Generated at 2022-06-24 21:57:20.395199
# Unit test for method get_vgs_facts of class AIXHardware

# Generated at 2022-06-24 21:57:25.344832
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    str_0 = 'TN'
    a_i_x_hardware_0 = AIXHardware(str_0)
    var_0 = a_i_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:57:27.166832
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    str_0 = 'TN'
    a_i_x_hardware_collector_0 = AIXHardwareCollector(str_0)

# Generated at 2022-06-24 21:57:29.501171
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    str_0 = 'TN'
    a_i_x_hardware_0 = AIXHardware(str_0)
    var_0 = a_i_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:57:30.588002
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    pass # TODO



# Generated at 2022-06-24 21:57:34.086351
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    str_0 = 'K'
    a_i_x_hardware_0 = AIXHardware(str_0)
    var_0 = a_i_x_hardware_0.get_mount_facts()
