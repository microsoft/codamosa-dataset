

# Generated at 2022-06-24 21:48:37.822525
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    h = AIXHardware({'module_setup': True})
    cpu_facts = h.get_cpu_facts()

    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'PowerPC_POWER8'



# Generated at 2022-06-24 21:48:48.659380
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    a_i_x_hardware_0 = AIXHardware()

# Generated at 2022-06-24 21:48:50.266304
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_0 = AIXHardwareCollector()


# Generated at 2022-06-24 21:48:58.545188
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():

    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(type='list', default=['!all'])
        )
    )

    # Test code should be run only on platforms other than AIX
    if module.get_platform() != 'AIX':

        # Testing method get_device_facts(self)
        # Getting 'devices' facts
        devices_facts = module.run_command('lscfg')
        # Call method get_device_facts to get devices facts
        device_facts = AIXHardware.get_device_facts(module)
        # Assertion for devices facts obtained from 'devices' facts
        assert_equals(device_facts['devices'], {})

        # Getting 'devices' facts
        devices_facts = module.run_command('lscfg -vp')
        #

# Generated at 2022-06-24 21:49:02.021392
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    a_i_x_hardware_0 = AIXHardware()
    assert isinstance(a_i_x_hardware_0.get_mount_facts(), dict)



# Generated at 2022-06-24 21:49:04.966142
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    a_i_x_hardware = AIXHardware()
    a_i_x_hardware_get_memory_facts = a_i_x_hardware.get_memory_facts()


# Generated at 2022-06-24 21:49:07.534667
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_0 = AIXHardwareCollector()
    assert a_i_x_hardware_collector_0._fact_class == AIXHardware


# Generated at 2022-06-24 21:49:09.976307
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    from ansible.module_utils.facts.hardware.aix import test_case_0 as test_case
    test_case.a_i_x_hardware_collector_0.get_mount_facts()


# Generated at 2022-06-24 21:49:11.067163
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    a_i_x_hardware_0 = AIXHardware()
    str_0 = a_i_x_hardware_0.get_cpu_facts()



# Generated at 2022-06-24 21:49:17.755503
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    print("Begin get_mount_facts test")
    a_i_x_hardware_0 = AIXHardware()
    result = a_i_x_hardware_0.get_mount_facts()
    print(result)
    print("End get_mount_facts test")



# Generated at 2022-06-24 21:49:44.745725
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    aix_hardware_obj = AIXHardware()
    ret = aix_hardware_obj.get_mount_facts()
    print(ret)

if __name__ == '__main__':
    test_AIXHardware_get_mount_facts()

# Generated at 2022-06-24 21:49:46.969501
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    assert type(AIXHardware().get_cpu_facts()) is dict


# Generated at 2022-06-24 21:49:52.499685
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    a_i_x_hardware_0 = AIXHardware()
    memory_facts = a_i_x_hardware_0.get_memory_facts()
    assert type(memory_facts) is dict
    assert 'memtotal_mb' in memory_facts
    assert 'memfree_mb' in memory_facts
    assert 'swaptotal_mb' in memory_facts
    assert 'swapfree_mb' in memory_facts


# Generated at 2022-06-24 21:49:56.901535
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    aix_hardware_0 = AIXHardware()
    result = aix_hardware_0.get_cpu_facts()
    assert result['processor'] == 'PowerPC_POWER8'


# Generated at 2022-06-24 21:50:06.728769
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    a_i_x_hardware_0 = AIXHardware()
    _b_i_n_path_0 = a_i_x_hardware_0.module.get_bin_path('lsconf')
    if _b_i_n_path_0:
        _r_c_0, _o_u_t_0, _e_r_r_0 = a_i_x_hardware_0.module.run_command(_b_i_n_path_0)

# Generated at 2022-06-24 21:50:09.902724
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_0 = AIXHardwareCollector()



# Generated at 2022-06-24 21:50:19.889827
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    a_i_x_hardware_0 = AIXHardware()
    # Case id 0
    a_i_x_hardware_0.module = AnsibleModule(argument_spec={})
    rc, out, err = a_i_x_hardware_0.module.run_command("/usr/sbin/lsattr -El sys0 -a fwversion")
    data = out.split()
    fwversion = data[1].strip('IBM,')
    # Case id 1
    a_i_x_hardware_0.module = AnsibleModule(argument_spec={})
    rc, out, err = a_i_x_hardware_0.module.run_command("/usr/sbin/lsattr -El sys0 -a fwversion")
    data = out.split()
    fwversion

# Generated at 2022-06-24 21:50:23.770443
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_0.get_mount_facts()


# Generated at 2022-06-24 21:50:28.145712
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    a_i_x_hardware_obj_0 = AIXHardware()
    a_i_x_hardware_vgs_facts_obj_0 = a_i_x_hardware_obj_0.get_vgs_facts()
    return a_i_x_hardware_vgs_facts_obj_0


# Generated at 2022-06-24 21:50:35.033399
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    a_i_x_hardware_0 = AIXHardware({})
    a_i_x_hardware_0.module.run_command = MagicMock(return_value=(0, ' memory pages         =  8385600\n free pages            =  8380738\n', ''))
    assert a_i_x_hardware_0.get_memory_facts() == {'swapfree_mb': 0, 'memfree_mb': 33790, 'swaptotal_mb': 0, 'memtotal_mb': 33791}


# Generated at 2022-06-24 21:51:22.120524
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts.utils import get_mount_size
    a_i_x_hardware_obj = AIXHardware()

# Generated at 2022-06-24 21:51:23.452656
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    pass


# Generated at 2022-06-24 21:51:33.025655
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    out_1 = 'node        mounted        mounted over    vfs    date        options         account\n'
    out_2 = '/dev/hd4      /                     jfs2   Aug 26 10:38   rw              \n'
    out_3 = '/dev/hd2      /usr                  jfs2   Aug 26 10:38   rw              \n'
    out_4 = '/dev/hd9var   /var                  jfs2   Aug 26 10:38   rw              \n'
    out_5 = '/dev/hd3      /tmp                  jfs2   Aug 26 10:38   rw              \n'
    out_6 = '/proc         /proc                 procfs Aug 26 10:38   rw              \n'

# Generated at 2022-06-24 21:51:36.040583
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    a_i_x_hardware_0 = AIXHardware()
    out = a_i_x_hardware_0.get_vgs_facts()
    assert out


# Generated at 2022-06-24 21:51:40.332917
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_0.populate()


# Generated at 2022-06-24 21:51:48.144836
# Unit test for method get_device_facts of class AIXHardware

# Generated at 2022-06-24 21:51:51.326280
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_collector_0 = a_i_x_hardware_0.collect()

# Generated at 2022-06-24 21:51:55.839471
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    AIXHardware_instance = AIXHardware()
    AIXHardware_instance.module = MagicMock()
    AIXHardware_instance.module.run_command = MagicMock(return_value=(0, 'aix', ''))
    AIXHardware_instance.populate()


# Generated at 2022-06-24 21:52:08.383456
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    get_mount_facts_instance = AIXHardware()
    a_i_x_hardware_get_mount_facts_run = get_mount_facts_instance.get_mount_facts()
    assert a_i_x_hardware_get_mount_facts_run['mounts'][0]['mount'] == '/'
    assert a_i_x_hardware_get_mount_facts_run['mounts'][0]['device'] == '/dev/hd4'
    assert a_i_x_hardware_get_mount_facts_run['mounts'][0]['fstype'] == 'jfs2'
    assert a_i_x_hardware_get_mount_facts_run['mounts'][0]['time'] == '05:26:42 01/20/2017'
    assert a_i

# Generated at 2022-06-24 21:52:10.373951
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_0.populate()



# Generated at 2022-06-24 21:52:53.670097
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    test_case_0()


# Generated at 2022-06-24 21:53:01.076267
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    # Create test object
    sample_attributes = (
        {'attribute': 'value',
         'attribute2': 'value2'}
    )

    aix_hardware_obj = AIXHardware(sample_attributes)

    # Create sample data

# Generated at 2022-06-24 21:53:04.493174
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    bytes_0 = b''
    a_i_x_hardware_0 = AIXHardware(bytes_0)
    var_0 = a_i_x_hardware_0.get_mount_facts()


# Generated at 2022-06-24 21:53:07.409668
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    bytes_0 = b''
    a_i_x_hardware_0 = AIXHardware(bytes_0)
    var_0 = a_i_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:53:15.371778
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():

    # bytes()
    bytes_0 = b''
    a_i_x_hardware_0 = AIXHardware(bytes_0)
    assert a_i_x_hardware_0.get_cpu_facts() == {'processor': [], 'processor_cores': None, 'processor_count': None}

    # bytes()
    bytes_0 = b''
    a_i_x_hardware_0 = AIXHardware(bytes_0)
    assert a_i_x_hardware_0.get_cpu_facts() == {'processor': [], 'processor_cores': None, 'processor_count': None}

    # bytes()
    bytes_0 = b''
    a_i_x_hardware_0 = AIXHardware(bytes_0)

# Generated at 2022-06-24 21:53:18.034762
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    bytes_0 = b''
    a_i_x_hardware_0 = AIXHardware(bytes_0)
    var_0 = a_i_x_hardware_0.populate()

# Generated at 2022-06-24 21:53:20.886702
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    bytes_0 = b''
    a_i_x_hardware_0 = AIXHardware(bytes_0)
    var_0 = a_i_x_hardware_0.get_device_facts()



# Generated at 2022-06-24 21:53:23.788641
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    if __name__ == "__main__":
        
        # Call function constructor of class 
        # AIXHardwareCollector
        test_case_0()

# Generated at 2022-06-24 21:53:27.534350
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    bytes_0 = b''
    a_i_x_hardware_0 = AIXHardware(bytes_0)
    var_0 = a_i_x_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 21:53:30.733618
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    bytes_0 = b''
    a_i_x_hardware_0 = AIXHardware(bytes_0)
    var_0 = a_i_x_hardware_0.get_mount_facts()

    assert var_0 == {'mounts': []}


# Generated at 2022-06-24 21:55:39.017261
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    bytes_0 = b''
    a_i_x_hardware_0 = AIXHardware(bytes_0)
    var_0 = a_i_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:55:39.934781
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
  pass


# Generated at 2022-06-24 21:55:43.430317
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    bytes_0 = b''
    a_i_x_hardware_0 = AIXHardware(bytes_0)
    var_0 = a_i_x_hardware_0.populate()

# Generated at 2022-06-24 21:55:46.554554
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    bytes_0 = b''
    a_i_x_hardware_0 = AIXHardware(bytes_0)
    var_0 = a_i_x_hardware_0.get_mount_facts()


# Generated at 2022-06-24 21:55:50.346254
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    bytes_0 = b''
    a_i_x_hardware_0 = AIXHardware(bytes_0)
    a_i_x_hardware_0.lsconf_bin_path = '/usr/sbin/lsconf'
    var_0 = a_i_x_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 21:55:53.579075
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():

    # setup
    bytes_0 = b''
    a_i_x_hardware_0 = AIXHardware(bytes_0)

    # execute method
    var_0 = a_i_x_hardware_0.get_device_facts()

    # verify results
    assert var_0 == {'devices': {}}


# Generated at 2022-06-24 21:55:57.690070
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    bytes_0 = b''
    a_i_x_hardware_0 = AIXHardware(bytes_0)
    var_0 = a_i_x_hardware_0.get_dmi_facts()
    assert isinstance(var_0, dict)


# Generated at 2022-06-24 21:56:04.549478
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    bytes_0 = b'\n\nrootvg:\nPV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION\nhdisk0            active            546         0           00..00..00..00..00\nhdisk1            active            546         113         00..00..00..21..92\nrealsyncvg:\nPV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION\nhdisk74           active            1999        6           00..00..00..00..06\ntestvg:\nPV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION\nhdisk105          active            999         838         200..39..199..200..200\nhdisk106          active            999         599         200..00..00..199..200'

# Generated at 2022-06-24 21:56:15.301551
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    bytes_0 = b''
    a_i_x_hardware_0 = AIXHardware(bytes_0)
    var_0 = a_i_x_hardware_0.get_vgs_facts()
    var_0 = a_i_x_hardware_0.get_vgs_facts()
    var_0 = a_i_x_hardware_0.get_vgs_facts()
    var_0 = a_i_x_hardware_0.get_vgs_facts()
    var_0 = a_i_x_hardware_0.get_vgs_facts()

if __name__ == '__main__':
    test_case_0()
    test_AIXHardware_get_vgs_facts()

# Generated at 2022-06-24 21:56:20.645410
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    out = b'memory pages: 8388608         total            \npage size: 4096                  (0.5MB)\npage size: 4096                  (0.5MB)\npage size: 4096                  (0.5MB)\nfree pages:  4072218            \n'
    a_i_x_hardware_0 = AIXHardware(out)
    var_0 = a_i_x_hardware_0.get_memory_facts()
