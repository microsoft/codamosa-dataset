

# Generated at 2022-06-24 21:48:41.839519
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    bytes_0 = b'\xab\x04\x1f\xe8\x12\xe7'
    a_i_x_hardware_0 = AIXHardware(bytes_0)

# Generated at 2022-06-24 21:48:49.098417
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    bytes_0 = b'9\x875#\xbf\xdbG\xc1\x91\xd8\x1a\xfb\x18\x83\x8b\x99\x05\x7f\xc2Q\xb7\xc5\xbf\x8c\x02\xbc\xb1\xbc\xa4\x11\xed'
    a_i_x_hardware_collector_0 = AIXHardwareCollector(bytes_0)


# Generated at 2022-06-24 21:49:00.309468
# Unit test for method get_memory_facts of class AIXHardware

# Generated at 2022-06-24 21:49:09.504675
# Unit test for method get_device_facts of class AIXHardware

# Generated at 2022-06-24 21:49:12.387005
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    bytes_0 = b'\xab\x04\x1f\xe8\x12\xe7'
    a_i_x_hardware_0 = AIXHardware(bytes_0)
    ret = a_i_x_hardware_0.get_mount_facts()
    assert ret == {'mounts': []}


# Generated at 2022-06-24 21:49:23.766964
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    # Test with device file
    devicefile = "tests/unit/module_utils/facts/hardware/test_files/test_lsdev.txt"
    cmd = "cat " +  devicefile
    with open(devicefile, "r") as f:
        bytes_0 = b'\xab\x04\x1f\xe8\x12\xe7'
        a_i_x_hardware_0 = AIXHardware(bytes_0)
        a_i_x_hardware_0.module.run_command = mock_run_command(out=f.read())
        out = a_i_x_hardware_0.get_device_facts()
        assert out['devices']['ent0']['state'] == 'Available'

# Generated at 2022-06-24 21:49:26.003061
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_0 = AIXHardwareCollector()
    return a_i_x_hardware_collector_0

# Generated at 2022-06-24 21:49:30.140907
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    bytes_0 = b'\xab\x04\x1f\xe8\x12\xe7'
    a_i_x_hardware_0 = AIXHardware(bytes_0)
    test_case_0(a_i_x_hardware_0)
    a_i_x_hardware_0.get_mount_facts()

# Generated at 2022-06-24 21:49:36.956501
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    bytes_0 = b'\xb1\x0f\xbc\x85\x8d\xe1'
    a_i_x_hardware_0 = AIXHardware(bytes_0)
    mount_facts = a_i_x_hardware_0.get_mount_facts()

    assert(mount_facts['mounts'])
    assert(isinstance(mount_facts['mounts'][0], dict))

    assert(mount_facts['mounts'][0]['mount'])
    assert(mount_facts['mounts'][0]['device'])
    assert(mount_facts['mounts'][0]['fstype'])
    assert(mount_facts['mounts'][0]['options'])
    assert(mount_facts['mounts'][0]['time'])

# Generated at 2022-06-24 21:49:47.877052
# Unit test for method get_cpu_facts of class AIXHardware

# Generated at 2022-06-24 21:50:09.541583
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    # create an object
    a_i_x_hardware_0 = AIXHardware(None)
    # get the result
    result = a_i_x_hardware_0.populate()


# Generated at 2022-06-24 21:50:15.939745
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    a_i_x_hardware_0 = AIXHardware()
    assert a_i_x_hardware_0.get_dmi_facts() == {'lpar_info': 'None',
                                               'firmware_version': 'IBM,1.0.0.0',
                                               'product_name': '8880-41A',
                                               'product_serial': '40F7D1E',
                                               'system_uuid': ''}


# Generated at 2022-06-24 21:50:18.643481
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_0 = AIXHardwareCollector()
    assert a_i_x_hardware_collector_0


# Generated at 2022-06-24 21:50:26.432637
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    hw_facts = AIXHardware()

    result = hw_facts.get_device_facts()
    assert isinstance(result,dict)
    assert result['devices']['fcs0']['state'] == 'Available'
    assert result['devices']['fcs0']['type'] == 'FC Adapter'
    assert result['devices']['fcs0']['attributes']['cable_type'] == 'N/A'


# Generated at 2022-06-24 21:50:31.343455
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    a_i_x_hardware_0 = AIXHardware()
    memory_facts = a_i_x_hardware_0.get_memory_facts()
    assert (memory_facts['memtotal_mb'] == '999'
            and memory_facts['memfree_mb'] == '999')


# Generated at 2022-06-24 21:50:35.072595
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_1 = AIXHardwareCollector()
    assert a_i_x_hardware_collector_1._platform == 'AIX'
    assert a_i_x_hardware_collector_1._fact_class == AIXHardware


# Generated at 2022-06-24 21:50:37.747413
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    assert AIXHardware('').get_mount_facts() == {'mounts': []}


# Generated at 2022-06-24 21:50:47.781733
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_0.module.run_command = MagicMock(return_value=(0, 'IBM,aix71', ''))
    a_i_x_hardware_0.module.get_bin_path = MagicMock(return_value='PATH')
    a_i_x_hardware_0.module.run_command = MagicMock(return_value=(0, 'IBM,7110-D60', ''))
    a_i_x_hardware_0.module.run_command = MagicMock(return_value=(0, 'U787Z1M', ''))

# Generated at 2022-06-24 21:50:49.773655
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_0 = AIXHardwareCollector()


# Generated at 2022-06-24 21:51:00.048954
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    # Test definition
    _a_i_x_hardware_get_vgs_facts_a_i_x_hardware_0 = AIXHardware()

# Generated at 2022-06-24 21:51:20.999621
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    a_i_x_hardware = AIXHardware()
    mount_facts = a_i_x_hardware.get_mount_facts()
    print(mount_facts)


# Generated at 2022-06-24 21:51:31.693751
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    """AIXHardware.get_memory_facts"""
    a_i_x_hardware = AIXHardware()
    a_i_x_hardware.module.run_command = lambda args, **kwargs: (0, 'memory pages:\t\t2097152\nfree pages:\t\t328816', '')
    a_i_x_hardware.module.get_bin_path = lambda arg: '/usr/sbin/lsps'
    a_i_x_hardware.module.run_command = lambda args, **kwargs: (0, '100mb', '')
    assert a_i_x_hardware.get_memory_facts() == {'memtotal_mb': 8192, 'memfree_mb': 1600, 'swaptotal_mb': 100, 'swapfree_mb': 100}



# Generated at 2022-06-24 21:51:44.062599
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    a_i_x_hardware_obj_0 = AIXHardware()
    the_result_0 = a_i_x_hardware_obj_0.get_dmi_facts()
    the_result_0 = a_i_x_hardware_obj_0.get_cpu_facts()
    the_result_0 = a_i_x_hardware_obj_0.get_memory_facts()
    the_result_0 = a_i_x_hardware_obj_0.get_vgs_facts()
    the_result_0 = a_i_x_hardware_obj_0.get_mount_facts()
    the_result_0 = a_i_x_hardware_obj_0.get_device_facts()


# Generated at 2022-06-24 21:51:47.616260
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    print("test_AIXHardware_populate")

    # Test with invalid input
    try:
        a_i_x_hardware_0 = AIXHardware()
        fact_ansible_collector = FactAnsibleCollector()
        a_i_x_hardware_0.populate(fact_ansible_collector)
    except Exception as e:
        print(e)



# Generated at 2022-06-24 21:51:48.766031
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector = AIXHardwareCollector()


# Generated at 2022-06-24 21:51:51.077895
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_0 = AIXHardwareCollector()
    assert  a_i_x_hardware_collector_0._platform == 'AIX'


# Generated at 2022-06-24 21:52:02.196170
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_0.module = MagicMock()

# Generated at 2022-06-24 21:52:05.450605
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    a_i_x_hardware_0 = AIXHardware()
    assert not a_i_x_hardware_0.get_mount_facts()


# Generated at 2022-06-24 21:52:10.082737
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    #aix_hardware_instance = AIXHardware()
    AIXHardware.get_mount_facts('aix_hardware_instance')


# Generated at 2022-06-24 21:52:21.914474
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    a_i_x_hardware_collector_0 = AIXHardwareCollector()
    a_i_x_hardware_collector_0.get_lsattr_out = Mock(return_value='ajdsfhjk')
    a_i_x_hardware_collector_0.get_mount_out = Mock(return_value='ajdsfhjk')
    a_i_x_hardware_collector_0.get_lsdev_out = Mock(return_value='ajdsfhjk')
    a_i_x_hardware_collector_0.get_lsps_out = Mock(return_value='ajdsfhjk')

# Generated at 2022-06-24 21:52:49.762881
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    test_case_0()

# This is the default entry point for AYAME's automated testing.
# It will run all tests in this file when executed.
if __name__ == '__main__':
    import pytest
    pytest.main(['-x', '-v', __file__])

# Generated at 2022-06-24 21:52:51.351666
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    a = AIXHardware()
    a.get_vgs_facts()

# Generated at 2022-06-24 21:52:54.029706
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    a_i_x_hardware_0 = AIXHardware()
    assert a_i_x_hardware_0.get_device_facts() == {'devices': {}}


# Generated at 2022-06-24 21:53:01.256918
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    hardware = AIXHardware()
    hardware.module = MagicMock()
    hardware.module.get_bin_path = MagicMock(return_value = "/usr/bin/lsdev")
    hardware.module.run_command = MagicMock(return_value = (0, "test", ""))

    assert hardware.get_device_facts() == {'devices': {}}

    hardware.module.get_bin_path = MagicMock(side_effect = [
        "/usr/bin/lsdev",
        "/usr/bin/lsattr"])

# Generated at 2022-06-24 21:53:04.139877
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    a_i_x_hardware = AIXHardware()
    a_i_x_hardware_populate_0 = a_i_x_hardware.populate()


# Generated at 2022-06-24 21:53:05.932993
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_0 = AIXHardwareCollector()


# Generated at 2022-06-24 21:53:09.033787
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
  test0_a_i_x_hardware = AIXHardwareCollector().get_fact_class()()
  result = test0_a_i_x_hardware.get_vgs_facts()
  assert result == {}, "Returned: %s" % result


# Generated at 2022-06-24 21:53:12.816583
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector = AIXHardwareCollector()
    my_dict = {}
    a_i_x_hardware = a_i_x_hardware_collector.collect(my_dict, None)
    assert isinstance(a_i_x_hardware, a_i_x_hardware.__class__) == True


# Generated at 2022-06-24 21:53:14.941475
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    a_i_x_hardware_0 = AIXHardware(module='module_0', facts=None)
    a_i_x_hardware_0.populate()



# Generated at 2022-06-24 21:53:16.784951
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    try:
        test_case_0()
    except SystemExit:
        pass
    except:
        print('x')



# Generated at 2022-06-24 21:54:09.162875
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    hw = AIXHardware()
    hw._module = type('', (), {'run_command':test_AIXHardware_get_vgs_facts.run_command, 'get_bin_path':test_AIXHardware_get_vgs_facts.get_bin_path})()

# Generated at 2022-06-24 21:54:18.161646
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    a_i_x_hardware_0 = AIXHardware()

    # Try setting up a page size of negative number
    pagesize_0 = -1
    try:
        # Try calling the function with arguments that are likely to cause an error
        result = a_i_x_hardware_0.get_memory_facts(pagesize=pagesize_0)
        assert False
    except:
        # In case of error return value should be False
        assert True
    # Try setting up a page size of 1000
    pagesize_0 = 1000

# Generated at 2022-06-24 21:54:26.058118
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    a_i_x_hardware_get_vgs_facts_1 = AIXHardware(module=dict())

    # Test case 2
    setattr(a_i_x_hardware_get_vgs_facts_1, 'module', module_mock)
    vgs_facts_1 = a_i_x_hardware_get_vgs_facts_1.get_vgs_facts()

# Generated at 2022-06-24 21:54:31.791190
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    a_i_x_hardware_0 = AIXHardware()
    memory_facts = a_i_x_hardware_0.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 256
    assert memory_facts['memfree_mb'] == 0
    assert memory_facts['swaptotal_mb'] == 2048
    assert memory_facts['swapfree_mb'] == 1500


# Generated at 2022-06-24 21:54:39.179134
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_0._module = MagicMock()
    a_i_x_hardware_0._module.run_command = MagicMock()
    a_i_x_hardware_0._module.run_command.return_value = (0, 'memory pages : 32', '')
    a_i_x_hardware_0._module.run_command.return_value = (0, 'memory pages : 32', '')
    a_i_x_hardware_0._module.run_command.return_value = (0, 'memory pages : 32', '')
    a_i_x_hardware_0._module.run_command.return_value = (0, 'memory pages : 32', '')
    a_i

# Generated at 2022-06-24 21:54:40.309271
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_0 = AIXHardwareCollector()


# Generated at 2022-06-24 21:54:41.931003
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    ret_vgs_facts = AIXHardware.get_vgs_facts(AIXHardware())
    assert isinstance(ret_vgs_facts, dict)


# Generated at 2022-06-24 21:54:49.573870
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    out = '''ent0 Available        10/100/1000 Base-TX Ethernet PCI-X Adapter (14108902)
ent2 Available        10/100/1000 Base-TX Ethernet PCI-X Adapter (14108902)
ent3 Available        10/100/1000 Base-TX Ethernet PCI-X Adapter (14108902)
ent6 Defined          10/100/1000 Base-TX Ethernet PCI-X Adapter (14108902)
ent7 Defined          10/100/1000 Base-TX Ethernet PCI-X Adapter (14108902)
cua0 Available        Serial Port
cua1 Available        Serial Port
'''


# Generated at 2022-06-24 21:54:54.812431
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    a_i_x_hardware_0 = AIXHardware({})
    a_i_x_hardware_0.module.run_command = MagicMock(return_value=(0, '', ''))
    a_i_x_hardware_0.module.get_bin_path = MagicMock(return_value=True)
    a_i_x_hardware_0.get_mount_facts()


# Generated at 2022-06-24 21:55:02.688901
# Unit test for method populate of class AIXHardware

# Generated at 2022-06-24 21:56:13.465792
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    a_i_x_hardware_instance = AIXHardware({})
    mount_facts_ret_code = a_i_x_hardware_instance.get_mount_facts()['mounts'][0].get('mount')
    assert mount_facts_ret_code is not None

# Generated at 2022-06-24 21:56:15.513345
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_1 = AIXHardwareCollector()


# Generated at 2022-06-24 21:56:23.388853
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    a_i_x_hardware_0 = AIXHardware(
        module=AnsibleModule(
            argument_spec=dict(),
            supports_check_mode=False,
        ),
    )
    a_i_x_hardware_0.module.run_command = MagicMock(
        return_value=(0, "LSDEV - Output\nIBM,8233-E8B          PowerPC_POWER8 Processor Adapter (4 CPUS)"
                      "\nMem 0x300000000-0x3FFFFFFFF\n", "")
    )

    a_i_x_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 21:56:27.967374
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    # Normal case with values for memfree_mb, memtotal_mb, swaptotal_mb, swapfree_mb
    a_i_x_hardware_0 = AIXHardware()

    assert a_i_x_hardware_0.get_memory_facts() == {'memtotal_mb': 8128, 'memfree_mb': 8128, 'swaptotal_mb': 4096, 'swapfree_mb': 4096}


# Generated at 2022-06-24 21:56:30.948120
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    my_AIXHardware = AIXHardware()
    # No test data available in module_utils/facts/hardware/aix.py
    pass


# Generated at 2022-06-24 21:56:34.427384
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    hardware = AIXHardware()
    hardware.module.run_command = Mock(return_value=(0, 'node         mounted        mounted over    vfs   date        options', ''))
    hardware.get_mount_size = Mock(return_value={'size_total': 1073741824, 'size_available': 536870912})
    hardware.get_mount_facts()


# Generated at 2022-06-24 21:56:35.426324
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_0 = AIXHardwareCollector()


# Generated at 2022-06-24 21:56:37.458596
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    a_i_x_hardware_0 = AIXHardware()
    result_get_memory_facts_0 = a_i_x_hardware_0.get_memory_facts()

# Generated at 2022-06-24 21:56:43.101694
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    memtotal_mb = 256
    memfree_mb = memtotal_mb - 22
    swaptotal_mb = memtotal_mb
    swapfree_mb = 84
    pagesize = 4096
    pagecount = memtotal_mb * 1024 * 1024 // pagesize
    freecount = memfree_mb * 1024 * 1024 // pagesize
    memory_facts = {}
    memory_facts['memtotal_mb'] = memtotal_mb
    memory_facts['memfree_mb'] = memfree_mb
    memory_facts['swaptotal_mb'] = swaptotal_mb
    memory_facts['swapfree_mb'] = swapfree_mb

    a_i_x_hardware_0 = AIXHardware({'module': MagicMock()})

# Generated at 2022-06-24 21:56:45.760773
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    arg0 = None
    arg1 = AIXHardwareCollector(arg0)
