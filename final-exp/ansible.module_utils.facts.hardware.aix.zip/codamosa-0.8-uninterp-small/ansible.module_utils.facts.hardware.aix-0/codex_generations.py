

# Generated at 2022-06-24 21:48:38.057064
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    a_i_x_hardware = AIXHardware()
    vgs_facts = a_i_x_hardware.get_vgs_facts()
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs_facts['vgs']['rootvg'][0]['pv_state'] == 'active'
    assert vgs_facts['vgs']['rootvg'][0]['total_pps'] == '546'
    assert vgs_facts['vgs']['rootvg'][0]['free_pps'] == '0'
    assert vgs_facts['vgs']['rootvg'][0]['pp_size'] == '4 megabyte(s)'

# Generated at 2022-06-24 21:48:48.815965
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_0.module = MagicMock()
    a_i_x_hardware_0.module.run_command.return_value = (0, 'node: /dev/hd4 mounted on / type jfs (write-through)', None)
    a_i_x_hardware_0.module.get_bin_path.return_value = '/usr/bin/mount'
    out = a_i_x_hardware_0.get_mount_facts()
    assert out['mounts'][0]['device'] == '/dev/hd4'
    assert out['mounts'][0]['fstype'] == 'jfs'
    assert out['mounts'][0]['mount'] == '/'
    assert out

# Generated at 2022-06-24 21:48:53.817346
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    a_i_x_hardware_0 = AIXHardware()
    assert a_i_x_hardware_0.get_memory_facts() == {'memtotal_mb': 2057, 'memfree_mb': 128, 'swaptotal_mb': 32, 'swapfree_mb': 32}


# Generated at 2022-06-24 21:48:55.908271
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    a_i_x_hardware__0 = AIXHardware()
    a_i_x_hardware__0.module.run_command = fake_run_command_0
    a_i_x_hardware__0.get_memory_facts()


# Generated at 2022-06-24 21:49:02.712953
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    a_i_x_hardware_0 = AIXHardware()
    facts = a_i_x_hardware_0.get_cpu_facts()
    assert facts['processor_cores'] == 1
    assert facts['processor'] == 'POWER5'


# Generated at 2022-06-24 21:49:06.450621
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    a_i_x_hardware_0 = AIXHardware(module=None)

    # get a vgs facts
    vgs_facts = a_i_x_hardware_0.get_vgs_facts()

    assert vgs_facts['vgs'] is not None


# Generated at 2022-06-24 21:49:18.083406
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    aix_hardware_get_vgs_facts = AIXHardware(dict())

# Generated at 2022-06-24 21:49:23.460654
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    a_i_x_hardware_0 = AIXHardware({})
    device_facts = a_i_x_hardware_0.get_device_facts()
    assert device_facts['devices']['ent0']['attributes']['media'] == 'Ethernet 10/100BaseTX'

# Generated at 2022-06-24 21:49:32.461569
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    lsps = """
    Size(kb)       Free     PVID
    -----------    -----    ---------------------------
    32.00MB          0      00004a00000000000000000
    8.00MB           0      0001497e0000000000000000
    10.00MB          0      000249c10000000000000000
    8.00MB           0      0003588c0000000000000000
    2.00MB           0      00005d150000000000000000
    32.00MB          0      00005d160000000000000000
    2.00MB           0      00005d170000000000000000
    """


# Generated at 2022-06-24 21:49:38.289588
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_0.module = AnsibleModuleMock()
    rc = 1
    out = "out"
    err = "err"
    a_i_x_hardware_0.module.run_command = MagicMock(return_value=(rc, out, err))
    a_i_x_hardware_0.populate = MagicMock(return_value="")
    assert a_i_x_hardware_0.get_memory_facts() == {}

    rc = 0
    out = "memory pages:    75937\nfree pages:      17212"
    a_i_x_hardware_0.module.run_command = MagicMock(return_value=(rc, out, err))
    assert a

# Generated at 2022-06-24 21:50:09.747063
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():

    # Initializing root object
    root_obj = AIXHardware()

    # Given and response
    # Stubbing out get_mount_size method
    def get_mount_size(x1):
        return {
            'size_total': None,
            'size_available': None,
            'size_used': None,
            'size_used_percent': None
        }

    root_obj.get_mount_size = get_mount_size

    # Expected result
    expected_result = {
        'swaptotal_mb': 1,
        'memfree_mb': 1,
        'memtotal_mb': 1,
        'swapfree_mb': 1
    }

    # Stubbing out get_mount_facts method
    def get_mount_facts():
        return {
            'mounts': []
        }

# Generated at 2022-06-24 21:50:17.732994
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():

    set_module_args({
        'failed_when_result': 'ok',
    })
    a_i_x_hardware_0 = AIXHardware(
        module=ans_module
    )

    a_i_x_hardware_1 = a_i_x_hardware_0.get_device_facts()
    assert a_i_x_hardware_1 is not None
    assert isinstance(a_i_x_hardware_1, dict)
    assert 'devices' in a_i_x_hardware_1
    assert isinstance(a_i_x_hardware_1['devices'], dict)



# Generated at 2022-06-24 21:50:22.525704
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    a_i_x_hardware_0 = AIXHardware()
    assert a_i_x_hardware_0.get_cpu_facts() == {'processor': ['PowerPC_POWER8'], 'processor_cores': 4, 'processor_count': 4}


# Generated at 2022-06-24 21:50:28.993253
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():

    a_i_x_hardware_0 = AIXHardware()

    # test with vgs from AIX
    vgs_facts = a_i_x_hardware_0.get_vgs_facts()
    assert vgs_facts['vgs']['rootvg'][0]['total_pps'] == '546' and vgs_facts['vgs']['testvg'][1]['pp_size'] == '4 megabyte(s)', \
        "Failed to get correct vgs facts from AIX system."


# Generated at 2022-06-24 21:50:32.225969
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    print("unit test get_cpu_facts")

    a_i_x_hardware_0 = AIXHardware()

    a_i_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:50:33.244128
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_1 = AIXHardwareCollector()


# Generated at 2022-06-24 21:50:41.240069
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    '''
    Unit test for method get_vgs_facts of class AIXHardware
    '''

    #
    # Parent class constructor call
    #
    a_i_x_hardware_0 = AIXHardware()

    # Test

# Generated at 2022-06-24 21:50:47.936392
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    a_i_x_hardware = AIXHardware()
    a_i_x_hardware.module = MockModule()
    out = a_i_x_hardware.get_dmi_facts()
    assert out['firmware_version'] == 'IBM,9117-570'
    assert out['product_serial'] == 'IBM.DU81231B6D'
    assert out['lpar_info'] == '2 N/A N/A'
    assert out['product_name'] == '9117-MMB'


# Generated at 2022-06-24 21:50:58.723436
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    # Test with a device
    a_i_x_hardware_0 = AIXHardware()
    device_facts = a_i_x_hardware_0.get_device_facts()

# Generated at 2022-06-24 21:51:05.551008
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    a_i_x_hardware_obj_0 = AIXHardware()
    cpu_facts_obj_0 = a_i_x_hardware_obj_0.get_cpu_facts()
    assert cpu_facts_obj_0['processor_count'] == 4, "Expected value {0} but got {1}.".format(4, cpu_facts_obj_0['processor_count'])
    assert len(cpu_facts_obj_0['processor']) > 0, "Expected value greater than 0 but got {0}".format(len(cpu_facts_obj_0['processor']))
    assert cpu_facts_obj_0['processor_cores'] == 1, "Expected value {0} but got {1}.".format(1, cpu_facts_obj_0['processor_cores'])

# Unit test

# Generated at 2022-06-24 21:51:45.622150
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    ai_x_hardware_0 = AIXHardware()
    ai_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:51:48.202975
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_0.module.run_command = MagicMock(return_value=(0, 'the output', ''))

    result = a_i_x_hardware_0.get_cpu_facts()
    assert result['processor_count'] == 10


# Generated at 2022-06-24 21:51:54.808809
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    test = AIXHardware()
    test._module = TestAnsibleModule()
    test._module.run_command = MagicMock(return_value=(0, '', ''))
    test.module.run_command = MagicMock(return_value=(0, '', ''))
    test._module.get_bin_path = MagicMock(return_value='/usr/bin/mount')
    test.module.get_bin_path = MagicMock(return_value='/usr/bin/mount')
    test._module.run_command = MagicMock(return_value=(0, '', ''))
    test.module.run_command = MagicMock(return_value=(0, '', ''))
    out = test.get_mount_facts()
    assert 'mounts' in out



# Generated at 2022-06-24 21:51:57.166370
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_0.populate()


# Generated at 2022-06-24 21:52:10.344927
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_0.module.run_command = MagicMock(return_value=(0, "", ""))
    a_i_x_hardware_0.module.get_bin_path = MagicMock(return_value=True)
    vgs_facts = a_i_x_hardware_0.get_vgs_facts()

# Generated at 2022-06-24 21:52:11.689677
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    hardware = AIXHardware({'module_setup': False})
    hardware.get_vgs_facts()

# Generated at 2022-06-24 21:52:16.655560
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_get_cpu_facts_ret = a_i_x_hardware_0.get_cpu_facts()
    assert isinstance(a_i_x_hardware_get_cpu_facts_ret, dict)


# Generated at 2022-06-24 21:52:18.307721
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    fixture = AIXHardware()
    fixture.get_device_facts()


# Generated at 2022-06-24 21:52:28.364485
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    a_i_x_hardware_0 = AIXHardware({})
    a_i_x_hardware_0._module = Mock()

    a_i_x_hardware_0._module.run_command.return_value = 0, "", ""
    a_i_x_hardware_0._module.run_command.return_value = 0, """Available 24-25 Processor 0 Available
Available 24-25 Processor 1 Available""", ""
    a_i_x_hardware_0._module.run_command.return_value = 0, "type PowerPC_POWER8", ""
    a_i_x_hardware_0._module.run_command.return_value = 0, "smt_threads 4", ""

    assert a_i_x_hardware_0._module.run_command.call_args_

# Generated at 2022-06-24 21:52:32.266368
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    AIXHardware_obj = AIXHardware()
    result = AIXHardware_obj.get_device_facts()


# Generated at 2022-06-24 21:54:12.278103
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_0.populate()

# Generated at 2022-06-24 21:54:16.753124
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    a_i_x_hardware_0 = AIXHardware(None)
    _fact_dict = dict()
    result = a_i_x_hardware_0.get_cpu_facts(_fact_dict)
    assert result == {'processor': [], 'processor_count': 2, 'processor_cores': 2}


# Generated at 2022-06-24 21:54:17.984887
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector = AIXHardwareCollector()

# Generated at 2022-06-24 21:54:20.121275
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    a_i_x_hardware_0 = AIXHardware(module=None)
    a_i_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:54:21.861250
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    # Pass
    AIX_hardware_0 = AIXHardware()
    AIX_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:54:23.735898
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():

    a_i_x_hardware_collector_0 = AIXHardwareCollector()



# Generated at 2022-06-24 21:54:26.309868
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    a_i_x_hardware_0 = AIXHardware()
    return_value_0 = a_i_x_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 21:54:30.367086
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_0 = AIXHardwareCollector()
    assert a_i_x_hardware_collector_0 is not None
    assert a_i_x_hardware_collector_0._fact_class == AIXHardware


# Generated at 2022-06-24 21:54:31.632815
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    a_i_x_hardware_0 = AIXHardware()

    a_i_x_hardware_0.get_device_facts()

# Generated at 2022-06-24 21:54:33.164782
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_0 = AIXHardwareCollector()
