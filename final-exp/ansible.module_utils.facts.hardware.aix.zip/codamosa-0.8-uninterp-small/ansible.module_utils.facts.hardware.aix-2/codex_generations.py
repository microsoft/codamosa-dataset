

# Generated at 2022-06-24 21:48:30.307674
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    ai_x_hardware_0 = AIXHardware()
    ai_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:48:33.761107
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    float_0 = -749.14
    a_i_x_hardware_collector_0 = AIXHardwareCollector()
    out_0 = a_i_x_hardware_collector_0.get_dmi_facts()
    return out_0


# Generated at 2022-06-24 21:48:37.732704
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    a_i_x_hardware_0 = AIXHardware()
    assert a_i_x_hardware_0.get_cpu_facts() == {'processor_count': 1, 'processor': 'PowerPC_POWER6'}


# Generated at 2022-06-24 21:48:39.675261
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    hw = AIXHardware()
    # assert hw.get_vgs_facts()


# Generated at 2022-06-24 21:48:49.188716
# Unit test for method get_cpu_facts of class AIXHardware

# Generated at 2022-06-24 21:48:57.833748
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():

    # From module_utils.facts.hardware.aix.test_AIXHardware
    # In test_case_0
    aix_hardware_0 = AIXHardware()
    aix_hardware_0.module.run_command = MagicMock(return_value=(0, 'Product_Serial_Number: <removed>\nMachine_Type: 8231-E2B', ''))
    assert aix_hardware_0.get_dmi_facts() == {'product_name': '8231-E2B', 'product_serial': '<removed>'}


# Generated at 2022-06-24 21:49:00.362159
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    float_0 = -749.14
    a_i_x_hardware_0 = AIXHardware()
    assert a_i_x_hardware_0.get_vgs_facts() == {}, 'AIXHardware.get_vgs_facts returned different value then expected'


# Generated at 2022-06-24 21:49:05.131596
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    float_0 = -749.14
    a_i_x_hardware_collector_0 = AIXHardwareCollector()
    a_i_x_hardware_0 = AIXHardware(a_i_x_hardware_collector_0)
    a_i_x_hardware_0.populate()


# Generated at 2022-06-24 21:49:06.739040
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    AixHardwareInstance = AIXHardware()
    AixHardwareInstance.get_device_facts()


# Generated at 2022-06-24 21:49:15.653498
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    # test_dict = {}
    # test_dict['_fact_class'] = 'AIXHardware'
    # test_dict['firmware_version'] = '1'
    # test_dict['product_serial'] = '2'
    # test_dict['lpar_info'] = '3'
    # test_dict['product_name'] = '4'
    #
    # assert test_dict == AIXHardware().get_dmi_facts()
    pass


# Generated at 2022-06-24 21:49:34.433527
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    aix_hardware = AIXHardware()
    aix_hardware.get_dmi_facts()


# Generated at 2022-06-24 21:49:36.912913
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    a_i_x_hardware_0 = AIXHardware(None)
    var_0 = a_i_x_hardware_0.get_mount_facts()



# Generated at 2022-06-24 21:49:41.680422
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    str_0 = '[tesAo\rri'
    a_i_x_hardware_0 = AIXHardware(str_0)
    var_0 = a_i_x_hardware_0.get_vgs_facts()
    assert var_0 != '[]'


# Generated at 2022-06-24 21:49:42.857844
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    a_i_x_hardware_0 = AIXHardware(None)
    a_i_x_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 21:49:43.500104
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    test_case_0()


# Generated at 2022-06-24 21:49:45.163871
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    str_0 = '`P'
    a_i_x_hardware_0 = AIXHardware(str_0)
    var_0 = a_i_x_hardware_0.get_dmi_facts()

# Generated at 2022-06-24 21:49:51.310806
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    str_0 = 'AIXHardware'
    a_i_x_hardware_0 = AIXHardware(str_0)
    device_facts = a_i_x_hardware_0.get_device_facts()
    if 'devices' not in device_facts:
        print("1")
    if 'lo0' not in device_facts['devices']:
        print("2")
    if len(device_facts['devices']['lo0']['attributes']) != 6:
        print("3")
    if 'ent0' not in device_facts['devices']['lo0']['attributes']:
        print("4")


# Generated at 2022-06-24 21:49:57.948078
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    print('Testing get_cpu_facts')
    str_0 = '[tesAo\rri'
    a_i_x_hardware_0 = AIXHardware(str_0)
    var_0 = a_i_x_hardware_0.get_cpu_facts()
    assert var_0 is None


# Generated at 2022-06-24 21:50:06.981617
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    mount_path = '/tmp/foo'
    lsdev_cmd = '/tmp/lsdev'
    lsattr_cmd = '/tmp/lsattr'
    test_case_output_0 = 'hdisk0 Available 03-08-01-0  Other FC SCSI Disk Drive'
    test_case_output_1 = 'name bus_id status queue_depth pvid'
    test_case_output_2 = 'hdisk0 50050768018827C0.009.0CE89C1473EF.C0B.000000000000 active 256 00c3d3ef016d8b18'
    test_case_output_3 = 'name bus_id status queue_depth pvid'

# Generated at 2022-06-24 21:50:11.270875
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    str_data = '[tesAo\rri'
    a_i_x_hardware_0 = AIXHardware(str_data)
    str_data = '\r'
    a_i_x_hardware_data = AIXHardware(str_data)
    var1 = a_i_x_hardware_data.populate()


# Generated at 2022-06-24 21:50:48.509371
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    str_0 = '[terseau\rri'
    a_i_x_hardware_0 = AIXHardware(str_0)
    var_0 = a_i_x_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 21:50:53.549241
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    str_0 = '[testAo\rri'
    a_i_x_hardware_0 = AIXHardware(str_0)
    var_0 = a_i_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:50:54.479777
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    col_0 = AIXHardwareCollector()

# Generated at 2022-06-24 21:51:01.851183
# Unit test for method get_cpu_facts of class AIXHardware

# Generated at 2022-06-24 21:51:04.855521
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    str_0 = '[ansible@test-aix-0 ~]'
    a_i_x_hardware_0 = AIXHardware(str_0)
    var_0 = a_i_x_hardware_0.get_mount_facts()


# Generated at 2022-06-24 21:51:16.391145
# Unit test for method get_dmi_facts of class AIXHardware

# Generated at 2022-06-24 21:51:19.878043
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    print("test aix_hardware_get_vgs_facts")
    str_0 = '[tesAo\rri'
    a_i_x_hardware_0 = AIXHardware(str_0)
    a_i_x_hardware_0.get_vgs_facts()


# Generated at 2022-06-24 21:51:20.599025
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    assert isinstance(AIXHardwareCollector(), AIXHardwareCollector)


# Generated at 2022-06-24 21:51:25.650153
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    str_0 = '[tesAo\rri'
    a_i_x_hardware_0 = AIXHardware(str_0)
    var_0 = a_i_x_hardware_0.get_dmi_facts()



# Generated at 2022-06-24 21:51:27.533771
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    str_0 = '[tesAo\rri'
    a_i_x_hardware_0 = AIXHardware(str_0)
    assert {} == a_i_x_hardware_0.get_vgs_facts()


# Generated at 2022-06-24 21:52:39.358931
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    print('Method get_vgs_facts')
    str_0 = ''
    a_i_x_hardware_0 = AIXHardware(str_0)
    str_1 = '/usr/sbin/lsvg -o | /usr/bin/xargs /usr/sbin/lsvg -p'
    var_0 = a_i_x_hardware_0.module.run_command(str_1, True)
    var_1 = var_0[1]
    var_2 = a_i_x_hardware_0.get_vgs_facts()
    print(var_2)
    print('Fact vgs')
    var_3 = var_2.get('vgs')
    print(var_3)
    print('Fact rootvg')
    var_4 = var_3['rootvg']

# Generated at 2022-06-24 21:52:42.800506
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    str_0 = '[testAo\rri'
    a_i_x_hardware_0 = AIXHardware(str_0)
    var_0 = a_i_x_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 21:52:46.696172
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    str_0 = '[tesAo\rri'
    a_i_x_hardware_0 = AIXHardware(str_0)
    var_1 = a_i_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:52:56.612459
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    device_facts = {'devices': {}}

    # AIX does not have mtab but mount command is only source of info (or to use
    # api calls to get same info)
    mount_path = '/usr/sbin/mount'
    rc, mount_out, err = module.run_command(mount_path)
    if mount_out:
        for line in mount_out.split('\n'):
            fields = line.split()
            if len(fields) != 0 and fields[0] != 'node' and fields[0][0] != '-' and re.match('^/.*|^[a-zA-Z].*|^[0-9].*', fields[0]):
                if re.match('^/', fields[0]):
                    # normal mount
                    mount = fields[1]
                    mount

# Generated at 2022-06-24 21:52:59.385167
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    str_0 = 'G\xff'
    a_i_x_hardware_0 = AIXHardware(str_0)
    var_1 = a_i_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:53:03.394335
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    str_0 = 'AIXHardware'
    a_i_x_hardware_0 = AIXHardware(str_0)
    var_0 = a_i_x_hardware_0.get_mount_facts()
    assert var_0 == {'mounts': []}

# Generated at 2022-06-24 21:53:08.523175
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    arg_0 = 'aix_facts'
    arg_1 = 'aix_facts'
    arg_2, arg_3 = 'none', 'none'
    a_i_x_hardware_0 = AIXHardware(arg_0, arg_1, arg_2, arg_3, 'none')
    var_0 = a_i_x_hardware_0.get_vgs_facts()


# Generated at 2022-06-24 21:53:11.394013
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    str_0 = '[serveAo\rri'
    a_i_x_hardware_0 = AIXHardware(str_0)
    var_0 = a_i_x_hardware_0.get_vgs_facts()


# Generated at 2022-06-24 21:53:14.473342
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    str_0 = '[tesAo\rri'
    a_i_x_hardware_0 = AIXHardware(str_0)
    var_0 = a_i_x_hardware_0.populate((None, []))


# Generated at 2022-06-24 21:53:23.995161
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():

    # Setup
    str_0 = '[tesAo\rri'
    a_i_x_hardware_0 = AIXHardware(str_0)
    var_0 = True

    # Getting test data from test data file
    test_data_file_path = 'test_data.txt'
    data_file = open(test_data_file_path, 'r')
    lsattr_cmd = data_file.readline()
    lsconf_cmd = data_file.readline()
    lsconf_cmd = lsconf_cmd.split(',')
    lsattr_cmd = lsattr_cmd.split(',')

    # Executing method under test.
    out = a_i_x_hardware_0.get_dmi_facts()

    # Verify

# Generated at 2022-06-24 21:56:39.465553
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    host_name_0 = '10.0.2.15'
    ansible_facts_0_0 = AnsibleFacts(host_name_0, [], [], [], [], [])
    ansible_facts_0_1 = {}
    ansible_facts_0_2 = {}
    ansible_facts_0_3 = {}
    aw_0 = AIXHardware(ansible_facts_0_1, host_name_0, ansible_facts_0_0)
    aw_0.get_mount_facts(ansible_facts_0_0, host_name_0, ansible_facts_0_1, ansible_facts_0_2, ansible_facts_0_3)


# Generated at 2022-06-24 21:56:42.109937
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    code_0 = 'Y4gXI'
    a_i_x_hardware_0 = AIXHardware(code_0)
    a_i_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:56:46.669348
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    str_0 = 'ay\r,\x0fs'
    a_i_x_hardware_0 = AIXHardware(str_0)
    var_0 = a_i_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:56:49.288277
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    str_0 = ''
    a_i_x_hardware_collector_0 = AIXHardwareCollector(str_0)
    test_case_0()

# Generated at 2022-06-24 21:56:52.089183
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    str_0 = '[tesAo\rri'
    a_i_x_hardware_0 = AIXHardware(str_0)
    var_0 = a_i_x_hardware_0.get_device_facts()


# Generated at 2022-06-24 21:56:56.393224
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    str_0 = '[tesAo\rri'
    a_i_x_hardware_0 = AIXHardware(str_0)
    var_0 = a_i_x_hardware_0.populate()

if __name__ == '__main__':
    test_case_0()
    test_AIXHardware_populate()

# Generated at 2022-06-24 21:57:01.619231
# Unit test for method get_memory_facts of class AIXHardware

# Generated at 2022-06-24 21:57:12.290488
# Unit test for method get_device_facts of class AIXHardware

# Generated at 2022-06-24 21:57:15.618076
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    str_0 = '[tesAo\rri'
    a_i_x_hardware_0 = AIXHardware(str_0)
    var_0 = a_i_x_hardware_0.get_vgs_facts()


# Generated at 2022-06-24 21:57:22.204173
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    import os
    import mock
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_0.module = mock.Mock()
    os.environ['ANSIBLE_SHOW_CUSTOM_STATS'] = '0'
    a_i_x_hardware_0.module.run_command.return_value = (0, '', '')
    a_i_x_hardware_0.get_cpu_facts()
    a_i_x_hardware_0.module.run_command.return_value = (0, 'lsdev: 0653-341 Cannot let go of /dev/hdisk0', '')
    a_i_x_hardware_0.get_cpu_facts()