

# Generated at 2022-06-24 21:48:32.559156
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_0.populate()


# Generated at 2022-06-24 21:48:35.675519
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    a_i_x_hardware_0 = AIXHardware(module=MagicMock())
    a_i_x_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 21:48:37.137942
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_0 = AIXHardwareCollector()



# Generated at 2022-06-24 21:48:40.169451
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    a_i_x_hardware_0 = AIXHardware()
    assert a_i_x_hardware_0.get_device_facts() == {'devices': {}}


# Generated at 2022-06-24 21:48:43.147784
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    a_i_x_hardware = AIXHardware(dict())
    a_i_x_hardware.module = MockModule()
    a_i_x_hardware.populate()


# Generated at 2022-06-24 21:48:50.235750
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_0.module = AnsibleModuleFake()
    test_memory_facts_dict = {
        "swaptotal_mb": 0,
        "swapfree_mb": 0,
        "memtotal_mb": 0,
        "memfree_mb": 0,
    }
    assert a_i_x_hardware_0.get_memory_facts() == test_memory_facts_dict


# Generated at 2022-06-24 21:48:58.486463
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    a_i_x_hardware_0 = AIXHardware()

# Generated at 2022-06-24 21:49:03.171808
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    a_i_x_hardware_0 = AIXHardware()
    result = a_i_x_hardware_0.get_cpu_facts()
    assert isinstance(result, dict)
    assert 'processor_count' in result
    assert 'processor' in result


# Generated at 2022-06-24 21:49:05.247990
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    a_i_x_hardware_hardware_0 = AIXHardware()

# Generated at 2022-06-24 21:49:08.418327
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    a_i_x_hardware_1 = AIXHardware()
    a_i_x_hardware_1.module.run_command = MagicMock(return_value=(1, "", ""))
    a_i_x_hardware_1.populate()
    a_i_x_hardware_1.get_dmi_facts()



# Generated at 2022-06-24 21:49:28.818961
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    # Test method get_dmi_facts of class AIXHardware
    a_i_x_hardware_0 = AIXHardware()
    assert a_i_x_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 21:49:35.884141
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    from ansible.module_utils.facts.hardware.base import Hardware
    from ansible.module_utils.facts.utils import get_mount_size
    a_i_x_hardware_0 = AIXHardware()
    my_path = "/usr/sbin/lsdev -Cc processor"
    my_rc = 128
    my_out = "hello"
    my_err = "goodbye"
    my_rc = 0
    my_out = "\n"
    a_i_x_hardware_0.module.run_command = MagicMock(side_effect=[(my_rc, my_out, my_err), (my_rc, my_out, my_err), (my_rc, my_out, my_err)])
    my_rc = 0

# Generated at 2022-06-24 21:49:40.556936
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    AIXHardware_instance = AIXHardware()
    assert AIXHardware_instance.get_memory_facts() == {'memfree_mb': 647288, 'memtotal_mb': 647288, 'swapfree_mb': 0, 'swaptotal_mb': 0}


# Generated at 2022-06-24 21:49:44.908736
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
   a_i_x_hardware_0 = AIXHardware()
   a_i_x_hardware_0.populate_facts()
   a_i_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:49:45.786963
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    test_case_0()


# Generated at 2022-06-24 21:49:48.740345
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    print('Testing populate of class AIXHardware')
    a_i_x_hardware_0 = AIXHardware()
    collected_facts = {}
    collected_facts = a_i_x_hardware_0.populate(collected_facts)


# Generated at 2022-06-24 21:49:51.190326
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    a_i_x_hardware = AIXHardware()

    a_i_x_hardware.populate()


# Generated at 2022-06-24 21:49:54.271655
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    print()
    print("Unit test for method get_mount_facts of class AIXHardware")

    # Define the arguments

    # Create a new instance
    a_i_x_hardware = AIXHardware()

    # Execute the method
    result = a_i_x_hardware.get_mount_facts()
    print("Result:")
    print(result)
    print()
    assert result



# Generated at 2022-06-24 21:50:00.348231
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    a_i_x_hardware = AIXHardware()
    assert a_i_x_hardware.get_cpu_facts() == {'processor': ['PowerPC_POWER5'], 'processor_count': 8, 'processor_cores': 1}


# Generated at 2022-06-24 21:50:05.125227
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    a_i_x_hardware_0 = AIXHardware()
    vgs_facts = a_i_x_hardware_0.get_vgs_facts()


# Generated at 2022-06-24 21:50:47.591660
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    m = AIXHardware(dict())

    m.module.run_command = MagicMock(return_value=(0, '', ''))
    assert m.get_mount_facts() == {'mounts': []}


# Generated at 2022-06-24 21:50:49.688697
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    device_facts_0 = AIXHardware.get_device_facts()


# Generated at 2022-06-24 21:50:59.983443
# Unit test for method get_device_facts of class AIXHardware

# Generated at 2022-06-24 21:51:01.854480
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_1 = AIXHardwareCollector()
    assert a_i_x_hardware_collector_1._platform == 'AIX'


# Generated at 2022-06-24 21:51:03.973706
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    test_instance = AIXHardware({"module": "test_module"})
    test_out = test_instance.get_vgs_facts()
    assert isinstance(test_out, dict)


# Generated at 2022-06-24 21:51:04.919305
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    test_case_0()


# Generated at 2022-06-24 21:51:16.475878
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():

    hw0 = AIXHardware()
    hw0.module = AnsibleModule(argument_spec=dict())

    rc, out, err = hw0.module.run_command("/usr/sbin/lsdev -Cc processor")
    out = """proc0 Available 00-00 Processor
proc1 Available 00-01 Processor
proc2 Available 00-02 Processor
proc3 Available 00-03 Processor
proc4 Available 00-04 Processor
proc5 Available 00-05 Processor
proc6 Available 00-06 Processor
proc7 Available 00-07 Processor"""
    hw0.module.run_command = MagicMock(return_value=(0, out, ''))

    rc, out, err = hw0.module.run_command("/usr/sbin/lsattr -El proc0 -a type")

# Generated at 2022-06-24 21:51:23.760530
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    a_i_x_hardware_collector_0 = AIXHardwareCollector()
    stats_d = {'has_lsattr': True, 'has_lsdev': True}
    a_i_x_hardware_0 = AIXHardware(a_i_x_hardware_collector_0.module, stats_d)
    returned_value = a_i_x_hardware_0.get_device_facts()

if __name__ == '__main__':
    test_case_0()
    test_AIXHardware_get_device_facts()

# Generated at 2022-06-24 21:51:33.192273
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    print("Test get_dmi_facts")
    # Test with empty facts
    collected_facts = {}
    a_i_x_hardware_0 = AIXHardware(collected_facts)

    # lsconf executable not found
    a_i_x_hardware_0.module.run_command = MagicMock(return_value=(0, '', ''))
    assert 'firmware_version' not in a_i_x_hardware_0.get_dmi_facts()
    assert 'product_serial' not in a_i_x_hardware_0.get_dmi_facts()
    assert 'lpar_info' not in a_i_x_hardware_0.get_dmi_facts()
    assert 'product_name' not in a_i_x_hardware_0.get_d

# Generated at 2022-06-24 21:51:45.623177
# Unit test for method get_device_facts of class AIXHardware

# Generated at 2022-06-24 21:53:04.316040
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    a_i_x_hardware_0 = AIXHardware()
    expected_value = {'devices': {'hdisk0': {'attributes': {}, 'type': '', 'state': ''}}}
    actual_value = a_i_x_hardware_0.get_device_facts()
    assert actual_value == expected_value, "'devices' are not equal"


# Generated at 2022-06-24 21:53:09.864866
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    test_case = AIXHardware()
    test_case.module = AnsibleModule(argument_spec={})

    test_case.module.run_command = Mock(return_value=(0, '', ''))
    result = test_case.get_memory_facts()
    assert result['memtotal_mb'] == 24576
    assert result['memfree_mb'] == 24576
    assert result['swaptotal_mb'] == 0
    assert result['swapfree_mb'] == 0


# Generated at 2022-06-24 21:53:14.363494
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    a_i_x_hardware_0 = AIXHardware()
    assert a_i_x_hardware_0.get_dmi_facts() == {'firmware_version': 'bg12345',
                                                'lpar_info': '1 CEC , 2 CPUs , 4 GB',
                                                'product_name': 'IBM,8284-22A',
                                                'product_serial': '1234'}


# Generated at 2022-06-24 21:53:15.711778
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_0 = AIXHardwareCollector()


# Generated at 2022-06-24 21:53:26.425002
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_0.module.run_command = MagicMock(return_value=(0, 'IBM,9117-570.00.00.00123', ''))
    a_i_x_hardware_0.module.get_bin_path = MagicMock(return_value="/usr/bin/lsattr")
    a_i_x_hardware_0.module.run_command = MagicMock(return_value=(0, 'Machine Serial Number:............076C12', 0))
    a_i_x_hardware_0.module.get_bin_path = MagicMock(return_value="/usr/sbin/lsconf")
    a_i_x_hardware_0.module.run_command = Magic

# Generated at 2022-06-24 21:53:30.514163
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(
        argument_spec = dict(
            filter = dict(default='*', type='list')
        ),
        supports_check_mode = True
    )

    aix_hardware = AIXHardware(module)

    mounts = aix_hardware.get_mount_facts()

    assert len(mounts['mounts']) > 0


# Generated at 2022-06-24 21:53:36.137905
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_1 = AIXHardwareCollector()
    assert isinstance(a_i_x_hardware_collector_1, AIXHardwareCollector)
    assert isinstance(a_i_x_hardware_collector_1, HardwareCollector)
    assert a_i_x_hardware_collector_1._platform == 'AIX'
    assert a_i_x_hardware_collector_1._fact_class == AIXHardware

# Generated at 2022-06-24 21:53:39.061118
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    a_i_x_hardware_0 = AIXHardware()
    assert isinstance(a_i_x_hardware_0.get_device_facts(), dict)


# Generated at 2022-06-24 21:53:41.663419
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_0 = AIXHardwareCollector()
    assert a_i_x_hardware_collector_0.hardware is not None

# Generated at 2022-06-24 21:53:42.944414
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    hardware = AIXHardware()
    hardware.get_memory_facts()


# Generated at 2022-06-24 21:57:11.502689
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    a_i_x_hardware = AIXHardware()
    a_i_x_hardware.module = MockModule()

# Generated at 2022-06-24 21:57:14.461858
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    a_i_x_hardware_0 = AIXHardware()
    print(a_i_x_hardware_0.get_device_facts())


if __name__ == '__main__':
    test_AIXHardware_get_device_facts()

# Generated at 2022-06-24 21:57:15.654995
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    pass # stub


# Generated at 2022-06-24 21:57:22.230100
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    out_lsdev = """hdisk0 Available  Virtual SCSI Disk Drive
hdisk1 Available  Virtual SCSI Disk Drive
hdisk2 Available  Virtual SCSI Disk Drive
hdisk3 Available  Virtual SCSI Disk Drive
hdisk4 Available  Virtual SCSI Disk Drive
hdisk5 Available  Virtual SCSI Disk Drive
hdisk6 Available  Virtual SCSI Disk Drive
hdisk7 Available  Virtual SCSI Disk Drive"""

# Generated at 2022-06-24 21:57:24.833484
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    aix_hardware_obj = AIXHardware()
    aix_hardware_obj.get_vgs_facts()


# Generated at 2022-06-24 21:57:32.682237
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    lsdev_path = "/usr/sbin/lsdev -Cc processor"
    lsattr_path = "/usr/sbin/lsattr -El "

# Generated at 2022-06-24 21:57:41.267031
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_0._module.get_bin_path = MagicMock(return_value='/usr/sbin/lsvg')

# Generated at 2022-06-24 21:57:43.373258
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    a = AIXHardware()
    a.module.run_command = lambda x: (0, 'test_AIXHardware_get_cpu_facts', '')
    assert a.get_cpu_facts() == {'processor_count': 2, 'processor': '9111-520'}


# Generated at 2022-06-24 21:57:51.239163
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    a_i_x_hardware_0 = AIXHardware()
    collected_facts = {}
    actual_result = a_i_x_hardware_0.populate(collected_facts)

# Generated at 2022-06-24 21:57:53.672693
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    test_case = AIXHardware()
    mount_facts = test_case.get_mount_facts()
    assert type(mount_facts) == dict
