

# Generated at 2022-06-24 21:48:30.843862
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    a_i_x_hardware_0 = AIXHardware()
    assert a_i_x_hardware_0.get_memory_facts() is not None


# Generated at 2022-06-24 21:48:36.135707
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    a_i_x_hardware_0 = AIXHardware()
    facts = a_i_x_hardware_0.get_memory_facts()
    assert isinstance(facts, dict)
    assert 'memfree_mb' in facts
    assert isinstance(facts['memfree_mb'], int)
    assert 'memtotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'swaptotal_mb' in facts


# Generated at 2022-06-24 21:48:39.718751
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    a_i_x_hardware = AIXHardware()

    # Call method  get_cpu_facts of object a_i_x_hardware
    a_i_x_hardware.get_cpu_facts()


# Generated at 2022-06-24 21:48:41.840594
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    a_i_x_hardware = AIXHardware()
    a_i_x_hardware.populate()


# Generated at 2022-06-24 21:48:44.845377
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:48:54.787773
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    a_i_x_hardware = AIXHardware(dict())

    mount_path = a_i_x_hardware.module.get_bin_path('mount')
    rc, mount_out, err = a_i_x_hardware.module.run_command(mount_path)

    if mount_out:
        for line in mount_out.split('\n'):
            fields = line.split()
            if len(fields) != 0 and fields[0] != 'node' and fields[0][0] != '-' and re.match('^/.*|^[a-zA-Z].*|^[0-9].*', fields[0]):
                if re.match('^/', fields[0]):
                    # normal mount
                    mount = fields[1]

# Generated at 2022-06-24 21:48:56.475962
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    a_i_x_hardware_get_devices_facts_0 = AIXHardware()
    assert a_i_x_hardware_get_devices_facts_0.get_device_facts()


# Generated at 2022-06-24 21:49:08.236638
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    a_i_x_hardware = AIXHardware()

# Generated at 2022-06-24 21:49:16.041381
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_get_mount_facts_0 = a_i_x_hardware_0.get_mount_facts()
    mount_facts_keys_0 = a_i_x_hardware_get_mount_facts_0.keys()
    assert 'mounts' in mount_facts_keys_0
    assert a_i_x_hardware_get_mount_facts_0.get('mounts')


# Generated at 2022-06-24 21:49:18.744507
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_0.populate()


# Generated at 2022-06-24 21:49:41.531124
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    # Test case setup
    a_i_x_hardware_0 = AIXHardware()

    # Test case execution
    result_a_i_x_hardware_0 = a_i_x_hardware_0.populate()

    # Test case verification

    assert result_a_i_x_hardware_0 is None


# Generated at 2022-06-24 21:49:50.621355
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    a_i_x_hardware_0 = AIXHardware()
    rc, out, err = a_i_x_hardware_0.module.run_command("/usr/sbin/lsdev -Cc processor")
    if out:
        i = 0
        for line in out.splitlines():
            if 'Available' in line:
                if i == 0:
                    data = line.split(' ')
                    cpudev = data[0]
                i += 1
        processor_count = int(i)
        rc, out, err = a_i_x_hardware_0.module.run_command("/usr/sbin/lsattr -El " + cpudev + " -a type")
        data = out.split(' ')
        processor = data[1]
        rc, out, err = a_

# Generated at 2022-06-24 21:49:54.901530
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector = AIXHardwareCollector()
    assert a_i_x_hardware_collector.platform == 'AIX'
    assert a_i_x_hardware_collector.fact_class == AIXHardware


# Generated at 2022-06-24 21:49:58.663931
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector = AIXHardwareCollector()
    assert a_i_x_hardware_collector is not None

# Generated at 2022-06-24 21:50:04.038177
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    aix_fixture = AIXHardware()

    # There should be at least one mountpoint.
    assert(len(aix_fixture.get_mount_facts()['mounts']) > 0)

# Generated at 2022-06-24 21:50:06.980765
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    a_i_x_hardware_0 = AIXHardware()
    collected_facts = {}
    a_i_x_hardware_0.populate(collected_facts=collected_facts)


# Generated at 2022-06-24 21:50:11.453941
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    m = AIXHardware()
    m.module = MockAnsibleModule()
    m.module.run_command = MockRunCommand()

# Generated at 2022-06-24 21:50:23.062407
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    a_i_x_hardware_0 = AIXHardware()
    data = dict()
    data['lsconf_path'] = '/usr/sbin/lsconf'

    ansible_module_0 = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )

    ansible_module_0.params = data
    a_i_x_hardware_0.module = ansible_module_0
    a_i_x_hardware_0.populate()

    rc, out, err = ansible_module_0.run_command('/usr/sbin/lsattr -El sys0 -a fwversion')
    data = out.split()
    dmi_facts = {'firmware_version': data[1].strip('IBM,')}
    rc, out,

# Generated at 2022-06-24 21:50:25.407146
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_0 = AIXHardwareCollector()


# Generated at 2022-06-24 21:50:30.700109
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector = AIXHardwareCollector()
    assert a_i_x_hardware_collector is not None
    assert a_i_x_hardware_collector._platform == 'AIX'
    assert a_i_x_hardware_collector._fact_class == AIXHardware



# Generated at 2022-06-24 21:51:16.569512
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_0.module = AnsibleModuleStub()
    a_i_x_hardware_0.module.get_bin_path = lambda arg1="mount": "/fake/mount"


# Generated at 2022-06-24 21:51:19.139520
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    hw = AIXHardware({})
    hw.populate()

# Unit test to check dict returned by get_cpu_facts method of class AIXHardware

# Generated at 2022-06-24 21:51:21.562920
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_0 = AIXHardwareCollector()
    return a_i_x_hardware_collector_0


# Generated at 2022-06-24 21:51:24.825044
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    a_i_x_hardware_0 = AIXHardware()
    assert a_i_x_hardware_0.get_memory_facts() is not None

# Generated at 2022-06-24 21:51:33.485617
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    a_i_x_hardware_0 = AIXHardware()

# Generated at 2022-06-24 21:51:36.851626
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    a_i_x_hardware_0 = AIXHardware()
    assert a_i_x_hardware_0.get_device_facts() == {'devices': {}}


# Generated at 2022-06-24 21:51:41.773522
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    a_i_x_hardware_0 = AIXHardware()
    assert not len(a_i_x_hardware_0.get_memory_facts())


# Generated at 2022-06-24 21:51:51.508535
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    a_i_x_hardware_0_object = AIXHardware(dict())
    a_i_x_hardware_0_object.module = MagicMock()
    a_i_x_hardware_0_object.module.get_bin_path.return_value = '/usr/sbin/mount'

# Generated at 2022-06-24 21:52:02.580998
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():

    a_i_x_hardware_0 = AIXHardware()

    out_0 = a_i_x_hardware_0.get_mount_facts()


# Generated at 2022-06-24 21:52:05.853352
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    a_i_x_hardware_get_device_facts_0 = AIXHardware().get_device_facts()
    # assert if device_facts['devices'] == {}



# Generated at 2022-06-24 21:53:25.251824
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    a_i_x_hardware_0 = AIXHardware()
    assert a_i_x_hardware_0.get_mount_facts() == {'mounts': []}


# Generated at 2022-06-24 21:53:26.909299
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    a_i_x_hardware_0 = AIXHardware({})
    a_i_x_hardware_0.populate()


# Generated at 2022-06-24 21:53:28.256609
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    a_i_x_hardware_collector = AIXHardwareCollector()


# Generated at 2022-06-24 21:53:31.088053
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    a_i_x_hardware_0 = AIXHardware()
    out_mounts = a_i_x_hardware_0.get_mount_facts();
    # Print output of method to stdout
    print(out_mounts)


# Generated at 2022-06-24 21:53:33.707215
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    hardware_0 = AIXHardware()

    # Case 1: simple
    memory_facts = hardware_0.get_memory_facts()
    print(memory_facts)



# Generated at 2022-06-24 21:53:37.493789
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    assert AIXHardwareCollector.__name__ == 'AIXHardwareCollector'
    assert AIXHardwareCollector.__doc__ == '\n    AIX subclass of HardwareCollector to support AIX specific facts.\n    '
    assert AIXHardwareCollector.platform == 'AIX'


# Generated at 2022-06-24 21:53:40.709138
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    a_i_x_hardware_0 = AIXHardware()

    # unit test for method get_vgs_facts of class AIXHardware
    vgs_facts = a_i_x_hardware_0.get_vgs_facts()


# Generated at 2022-06-24 21:53:42.405784
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_0 = AIXHardwareCollector()



# Generated at 2022-06-24 21:53:43.686269
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_0 = AIXHardwareCollector()


# Generated at 2022-06-24 21:53:49.340491
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    a_i_x_hardware_0 = AIXHardware()
    # assert a_i_x_hardware_0.get_mount_facts() == {'mounts': [{'mount': '/', 'device': '/dev/hd4', 'fstype': 'jfs2', 'options': 'rw'}]}


# Generated at 2022-06-24 21:55:31.889767
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_0 = AIXHardwareCollector()
    var_0 = a_i_x_hardware_collector_0.get_fact_class()
    var_1 = a_i_x_hardware_collector_0.get_platform()
    return a_i_x_hardware_collector_0


# Generated at 2022-06-24 21:55:39.044833
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    bool_0 = False
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    list_0 = [dict_0, dict_0]
    list_1 = [list_0, dict_0, dict_0]
    a_i_x_hardware_0 = AIXHardware(list_1, dict_0)
    var_0 = a_i_x_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 21:55:47.192779
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    list_0 = [True, True, False]
    dict_0 = {True: list_0, False: list_0, True: list_0}
    list_1 = [dict_0, dict_0]
    a_i_x_hardware_0 = AIXHardware(list_1, dict_0)
    a_i_x_hardware_0.module.run_command = MagicMock(return_value=(0, 'stdout', 'stderr'))
    var_0 = a_i_x_hardware_0.get_dmi_facts()
    #assert var_0 == var_0


# Generated at 2022-06-24 21:55:52.306163
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    bool_0 = False
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    list_0 = [dict_0, dict_0]
    list_1 = [list_0, dict_0, dict_0]
    a_i_x_hardware_0 = AIXHardware(list_1, dict_0)
    var_0 = a_i_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:55:54.808949
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module_0 = AnsibleModule(argument_spec={})
    a_i_x_hardware_0 = AIXHardware(module_0)
    var_0 = a_i_x_hardware_0.get_device_facts()


# Generated at 2022-06-24 21:56:00.700174
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    bool_0 = False
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    list_0 = [dict_0, dict_0]
    list_1 = [list_0, dict_0, dict_0]
    a_i_x_hardware_0 = AIXHardware(list_1, dict_0)
    var_0 = a_i_x_hardware_0.get_dmi_facts()
    var_1 = a_i_x_hardware_0.get_mount_facts()


# Generated at 2022-06-24 21:56:06.697038
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    # Test case with hardcoded data
    # Define a AIXHardware object
    bool_0 = False
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    list_0 = [dict_0, dict_0]
    list_1 = [list_0, dict_0, dict_0]
    a_i_x_hardware_0 = AIXHardware(list_1, dict_0)

    # Call method get_dmi_facts
    var_0 = a_i_x_hardware_0.get_dmi_facts()

    # Test case with hardcoded data
    # Define a AIXHardware object
    bool_0 = True
    list_0 = [bool_0, bool_0]

# Generated at 2022-06-24 21:56:14.207902
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    bool_0 = False
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    list_0 = [dict_0, dict_0]
    list_1 = [list_0, dict_0, dict_0]
    a_i_x_hardware_0 = AIXHardware(list_1, dict_0)
    var_0 = a_i_x_hardware_0.get_vgs_facts()


# Generated at 2022-06-24 21:56:16.666386
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_0 = AIXHardwareCollector()
    var_0 = a_i_x_hardware_collector_0.collect()

# Generated at 2022-06-24 21:56:25.796713
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    my_aix_hardware = AIXHardwareCollector.fetch_fact()
    if my_aix_hardware:
        my_aix_hardware_get_cpu_facts = my_aix_hardware.get_cpu_facts()
        my_aix_hardware_get_cpu_facts_processor_cores = my_aix_hardware_get_cpu_facts['processor_cores']
        assert my_aix_hardware_get_cpu_facts_processor_cores != 0
        my_aix_hardware_get_cpu_facts_processor_count = my_aix_hardware_get_cpu_facts['processor_count']
        assert my_aix_hardware_get_cpu_facts_processor_count != 0
        my_aix_hardware_get_cpu_facts