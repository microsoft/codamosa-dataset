

# Generated at 2022-06-24 21:48:33.141880
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    list_0 = []
    a_i_x_hardware_0 = AIXHardware(list_0)
    assert a_i_x_hardware_0.get_device_facts() == {'devices': {}}


# Generated at 2022-06-24 21:48:37.406941
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    list_0 = []

    a_i_x_hardware_0 = AIXHardware(list_0)
    # this is a stub, it will cause a TypeError
    a_i_x_hardware_0.populate(collected_facts=None)

# Generated at 2022-06-24 21:48:44.028375
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    with mock.patch('ansible.module_utils.facts.hardware.aix.AIXHardware.get_mount_facts') as mocked_get_mount_facts:
        mocked_get_mount_facts.return_value = {'mounts': []}
        list_0 = []
        a_i_x_hardware_0 = AIXHardware(list_0)
        a_i_x_hardware_0.get_mount_facts()
        assert mocked_get_mount_facts.called


# Generated at 2022-06-24 21:48:46.821728
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    list_0 = []
    a_i_x_hardware_collector_0 = AIXHardwareCollector(list_0)


# Generated at 2022-06-24 21:48:49.756661
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    list_0 = []
    a_i_x_hardware_0 = AIXHardware(list_0)
    a_i_x_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 21:48:58.946473
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware

    for line in 'memory pages:'.split('\n'):
        data = line.split()
        if 'memory pages' in line:
            pagecount = int(data[0])
    pagecount = pagecount + 1
    assert pagecount == 1
    # assert_true(pagecount == 1)
    # assert_false(pagecount == 2)
    # assert_equal(pagecount, 2)
    # assert_not_equal(pagecount, 3)
    # assert_false(pagecount == 4)
    # assert_true(pagecount == 5)


# Generated at 2022-06-24 21:49:08.879666
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    list_0 = []
    a_i_x_hardware_0 = AIXHardware(list_0)
    # Check with lsvg_path and xargs_path is found

# Generated at 2022-06-24 21:49:11.281725
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    assert AIXHardwareCollector is not None


# Generated at 2022-06-24 21:49:13.559814
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_0 = AIXHardwareCollector()
    a_i_x_hardware_collector_0.collect()

# Generated at 2022-06-24 21:49:24.056051
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    list_0 = []
    a_i_x_hardware_0 = AIXHardware(list_0)
    a_i_x_hardware_0.module.run_command = MagicMock()

    a_i_x_hardware_0.module.run_command.return_value = [0, 'memory pages:  268268\nfree pages:  13531\n', None]
    a_i_x_hardware_0.get_memory_facts()
    a_i_x_hardware_0.module.run_command.return_value = [0, 'Device          1M-blocks     Used    Avail Capacity\n/dev/ada0p3        314368        0   314368     0%\n', None]
    a_i_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:49:44.039203
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    test_case_0()

# Generated at 2022-06-24 21:49:46.863504
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    var_0 = a_i_x_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 21:49:49.900753
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    var_0 = a_i_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:49:53.399929
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    bool_1 = True
    a_i_x_hardware_1 = AIXHardware(bool_1)
    a_i_x_hardware_1.get_vgs_facts()


# Generated at 2022-06-24 21:49:56.259395
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    assert isinstance(AIXHardware().get_vgs_facts(), dict)


# Generated at 2022-06-24 21:50:01.145118
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    a_i_x_hardware_0.populate()
    var_0 = a_i_x_hardware_0.populate()

# Generated at 2022-06-24 21:50:09.541947
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    var_0 = a_i_x_hardware_0.populate()
    var_1 = a_i_x_hardware_0.get_cpu_facts()
    assert var_1 == {
        'processor': ['PowerPC_POWER8'],
        'processor_count': 4,
        'processor_cores': 1,
    }


# Generated at 2022-06-24 21:50:12.217701
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    a_i_x_hardware_0.get_vgs_facts()


# Generated at 2022-06-24 21:50:15.104483
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    # Create a new instance of AIXHardwareCollector
    a_i_x_hardware_collector_0 = AIXHardwareCollector(None)


# Generated at 2022-06-24 21:50:18.518205
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    map_0 = a_i_x_hardware_0.populate()
    print(map_0)


# Generated at 2022-06-24 21:50:58.983484
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    param_0 = True
    a_i_x_hardware_0 = AIXHardware(param_0)
    assert isinstance(a_i_x_hardware_0.get_device_facts(), dict, 'AIXHardware.get_device_facts method is returning a wrong type')


# Generated at 2022-06-24 21:51:00.793755
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    pass
    # a_i_x_hardware = AIXHardware()
    # a_i_x_hardware_obj = a_i_x_hardware.get_mount_facts()


# Generated at 2022-06-24 21:51:04.379074
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_0 = AIXHardwareCollector()
    a_i_x_hardware_collector_1 = AIXHardwareCollector(None)
    var_0 = a_i_x_hardware_collector_0.collect()
    var_1 = a_i_x_hardware_collector_1.collect()

# Generated at 2022-06-24 21:51:06.951323
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    a_i_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:51:12.346523
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    var_0 = a_i_x_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 21:51:14.499120
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    # NOTE: only the test case 'test_case_0' is implemented so far.
    test_case_0()


# Generated at 2022-06-24 21:51:16.261409
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_0 = AIXHardwareCollector()
    pass


if __name__ == "__main__":
    test_case_0()
    test_AIXHardwareCollector()
    pass

# Generated at 2022-06-24 21:51:17.906107
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    print('Testing method populate of class AIXHardware')

    test_case_0()


# Generated at 2022-06-24 21:51:29.079524
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    bool_1 = True

# Generated at 2022-06-24 21:51:32.669693
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    var_0 = a_i_x_hardware_0.get_mount_facts()
    assert var_0 == {'mounts': []}


# Generated at 2022-06-24 21:52:53.859387
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    mount_facts = a_i_x_hardware_0.get_mount_facts()
    expected = {'mounts': [{'mount': '/usr', 'device': '/dev/hd4', 'fstype': 'jfs2', 'options': 'log', 'time': 'Thu Mar 26 18:16:13 2020', 'size_total': 604469248.0, 'size_available': 399228928.0, 'inode_total': 2097152.0, 'inode_available': 1517215.0, 'inode_percent': 27.8}]}

    assert mount_facts == expected

if __name__ == "__main__":
    test_case_0()
    test_AIX

# Generated at 2022-06-24 21:52:56.425142
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    a_i_x_hardware_0.get_vgs_facts()


# Generated at 2022-06-24 21:52:59.194340
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    var_0 = a_i_x_hardware_0.get_mount_facts()

# Unit test

# Generated at 2022-06-24 21:53:02.776110
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    var_0 = a_i_x_hardware_0.get_vgs_facts()


# Generated at 2022-06-24 21:53:03.774296
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    test_case_0()

# Generated at 2022-06-24 21:53:12.127414
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():

    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)

    # Test with lsconf command present
    a_i_x_hardware_0.module.lsconf_path = "/usr/sbin/lsconf"

    # Test with lsconf invocation successful
    def run_command_side_effect(cmd, **kwargs):
        out = "System Model:\tIBM,8231-E2B\nMachine Serial Number:\t0123456789\nPart Number:\t123456789\nFD Disk:\tnone\nHD Disk:\t2100 GB\nLPAR Info:\t1 Node, 1 Partition\nMemory Size:\t32768 MB\nGood Memory Size:\t32768 MB\nPlatform Firmware level:\tSF240_262\nHMC:\tnone"

# Generated at 2022-06-24 21:53:12.889765
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    test_case_0()


# Generated at 2022-06-24 21:53:22.246753
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)

    # Test for vg with no pvs

# Generated at 2022-06-24 21:53:26.297876
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    var_0 = a_i_x_hardware_0.get_device_facts()


# Generated at 2022-06-24 21:53:29.027578
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    var_0 = a_i_x_hardware_0.get_vgs_facts()


# Generated at 2022-06-24 21:57:08.106396
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    import tempfile
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    temp_fh = tempfile.NamedTemporaryFile()
    temp_fh.write(b'processor 0 Available 00-00-00-00-00-00 Processor\n')
    temp_fh.write(b'processor 1 Available 00-00-00-00-00-00 Processor\n')
    temp_fh.flush()
    assert AIXHardware.get_cpu_facts(temp_fh.name) == {'processor': ['Processor'], 'processor_cores': 1, 'processor_count': 2}


if __name__ == '__main__':
    test_case_0()
    test_AIXHardware_get_cpu_facts()

# Generated at 2022-06-24 21:57:11.644042
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    var_0 = a_i_x_hardware_0.get_device_facts()


# Generated at 2022-06-24 21:57:13.338690
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    bool_0 = True
    a_i_x_hardware_collector_0 = AIXHardwareCollector(bool_0)

# Generated at 2022-06-24 21:57:16.901649
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)

    # Call method
    var_0 = a_i_x_hardware_0.get_memory_facts()

    # Check return value
    assert var_0 == {}


# Generated at 2022-06-24 21:57:19.354057
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    var_0 = a_i_x_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 21:57:23.913323
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    a_i_x_hardware_0.get_device_facts()


# Generated at 2022-06-24 21:57:26.445619
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    a_i_x_hardware_0.get_vgs_facts()


# Generated at 2022-06-24 21:57:27.825086
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    var_0 = AIXHardware()
    var_1 = var_0.populate()


# Generated at 2022-06-24 21:57:29.168969
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    test_case_0()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 21:57:31.732444
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    a_i_x_hardware_0 = AIXHardware(False)
    var_0 = a_i_x_hardware_0.get_vgs_facts()
