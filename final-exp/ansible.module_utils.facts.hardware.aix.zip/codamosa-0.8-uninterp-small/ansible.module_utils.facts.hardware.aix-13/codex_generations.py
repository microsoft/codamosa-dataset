

# Generated at 2022-06-24 21:48:31.560157
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():

    # AIXHardware.get_memory_facts(self)
    pass


# Generated at 2022-06-24 21:48:41.886698
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    bytes_0 = b'\x98\x16z\x8f\xd7\xb3\xae8\x9a\xabA\xf5\xc0>\xa2\x92\xb8'
    a_i_x_hardware_0 = AIXHardware(bytes_0)

    # Call method
    a_i_x_hardware_0.get_device_facts()


# Generated at 2022-06-24 21:48:48.762781
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    bytes_0 = b'\x98\x16z\x8f\xd7\xb3\xae8\x9a\xabA\xf5\xc0>\xa2\x92\xb8'
    a_i_x_hardware_0 = AIXHardware(bytes_0)

    # Call method
    result = a_i_x_hardware_0.get_device_facts()

    # Check result
    assert result is not None


# Generated at 2022-06-24 21:48:54.911236
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    bytes_0 = b'\xee\xb2\x18\xd3\x90\x91\xb7\xdf\x89\xeb\xc8\xae\xa8\xdc\x88'
    a_i_x_hardware_0 = AIXHardware(bytes_0)
    a_i_x_hardware_0.get_device_facts()


# Generated at 2022-06-24 21:48:59.751163
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    bytes_0 = b'\xa6\x1f\x0e\xd6\xaa=\x9e\x98k\xca\xe8\xdd\x83\x94+\x0f\x8c'
    a_i_x_hardware_0 = AIXHardware(bytes_0)

# Generated at 2022-06-24 21:49:09.183735
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    bytes_0 = b'\x98\x16z\x8f\xd7\xb3\xae8\x9a\xabA\xf5\xc0>\xa2\x92\xb8'
    a_i_x_hardware_0 = AIXHardware(bytes_0)
    module_0 = a_i_x_hardware_0.module_executor
    module_0.get_bin_path = Mock(return_value="/usr/sbin/lsvg")
    module_0.run_command = Mock(return_value=(0, b'/usr/sbin/lsvg -o \n\nrootvg:', b''))

# Generated at 2022-06-24 21:49:15.796549
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    bytes_0 = b'\x98\x16z\x8f\xd7\xb3\xae8\x9a\xabA\xf5\xc0>\xa2\x92\xb8'
    a_i_x_hardware_0 = AIXHardware(bytes_0)

    # Call the method
    cpu_facts_0 = a_i_x_hardware_0.get_cpu_facts()



# Generated at 2022-06-24 21:49:16.845949
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_0 = AIXHardwareCollector()

# Generated at 2022-06-24 21:49:24.991127
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    bytes_0 = b'\x98\x16z\x8f\xd7\xb3\xae8\x9a\xabA\xf5\xc0>\xa2\x92\xb8'
    a_i_x_hardware_0 = AIXHardware(bytes_0)
    str_0 = '#'
    str_1 = 'c%r#&'
    str_2 = '5'
    str_3 = '3&'
    int_0 = a_i_x_hardware_0.get_mount_facts(str_0, str_1, str_2, str_3)
    assert int_0 == 3


# Generated at 2022-06-24 21:49:28.209134
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    bytes_0 = b'\xa7\x14\xee\xae\x8e\xe3\x83\xc9\xbd\x8c\x19\xfb\r\xde'
    a_i_x_hardware_0 = AIXHardware(bytes_0)
    expected_0 = ''
    actual_0 = a_i_x_hardware_0.get_vgs_facts()
    assert actual_0 == expected_0


# Generated at 2022-06-24 21:49:48.308144
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    bool_0 = False
    a_i_x_hardware_0 = AIXHardware(bool_0)
    var_0 = a_i_x_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 21:49:54.122069
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    var_0 = a_i_x_hardware_0.get_dmi_facts()
    assert var_0 == {'firmware_version': '', 'product_name': '', 'product_serial': '', 'lpar_info': ''}


# Generated at 2022-06-24 21:49:59.838395
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    var_0 = a_i_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:50:02.683716
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    assert a_i_x_hardware_0.get_mount_facts() is None

# Generated at 2022-06-24 21:50:06.986984
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardwareCollector(bool_0)

if __name__ == '__main__':
    test_case_0()
    test_AIXHardwareCollector()

# Generated at 2022-06-24 21:50:10.578471
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    bool_0 = True
    # Creation of the instance of class AIXHardware
    a_i_x_hardware_0 = AIXHardware(bool_0)
    var_0 = a_i_x_hardware_0.get_device_facts()


# Generated at 2022-06-24 21:50:13.687163
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    var_0 = a_i_x_hardware_0.get_vgs_facts()


# Generated at 2022-06-24 21:50:16.713059
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    print('Starting test_AIXHardware_get_memory_facts')
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    var_0 = a_i_x_hardware_0.get_memory_facts()
    assert var_0['memtotal_mb'] == '2048'
    assert var_0['memfree_mb'] == '2048'


# Generated at 2022-06-24 21:50:19.796715
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    a_i_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:50:22.265701
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    test_case_0()


# Generated at 2022-06-24 21:50:57.961880
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    print ('Test for class AIXHardwareCollector')
    # Create an object of the class
    a_i_x_hardware_collector_0 = AIXHardwareCollector()
    assert (a_i_x_hardware_collector_0.platform == 'AIX')
    assert (a_i_x_hardware_collector_0._fact_class == AIXHardware)


test_AIXHardwareCollector()
test_case_0()

# Generated at 2022-06-24 21:51:00.235570
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    var_0 = a_i_x_hardware_0.populate()

# Generated at 2022-06-24 21:51:01.037130
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    pass



# Generated at 2022-06-24 21:51:04.072724
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    vgs_facts_0 = a_i_x_hardware_0.get_vgs_facts()
    assert isinstance(vgs_facts_0, dict)
    assert vgs_facts_0 == {}


# Generated at 2022-06-24 21:51:08.001265
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    var_0 = a_i_x_hardware_0.get_dmi_facts()
    assert var_0 == None, 'Failed on line 8 - None'



# Generated at 2022-06-24 21:51:11.786449
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    print('===== In test_AIXHardware_get_mount_facts =====')
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    var_0 = a_i_x_hardware_0.get_mount_facts()
    print('mounts: ', var_0['mounts'])


# Generated at 2022-06-24 21:51:14.800060
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    bool_0 = True
    a_i_x_hardware_1 = AIXHardware(bool_0)
    # unit test for populate
    var_0 = a_i_x_hardware_1.populate()

# Generated at 2022-06-24 21:51:21.438531
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    var_0 = a_i_x_hardware_0.get_dmi_facts()
    expected = {
        'product_serial': '20161024050808',
        'firmware_version': '7200-03-03-1519',
        'product_name': 'IBM,8286-42A',
        'lpar_info': '1 C0C9,8286-42ABL-SN128K20A RSCT'
    }
    assert var_0 == expected


# Generated at 2022-06-24 21:51:31.968814
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():

    # Check if lsdev is present
    lsdev_path = '/usr/sbin/lsdev' # For now test works on AIX only
    if not os.path.isfile(lsdev_path):
        raise Exception('lsdev command cannot be found. This test cannot be run.')

    # Check if lsattr is present
    lsattr_path = '/usr/sbin/lsattr' # For now test works on AIX only
    if not os.path.isfile(lsattr_path):
        raise Exception('lsattr command cannot be found. This test cannot be run.')

    # We know that AIX has at least one interface so we check that there is at least
    # one interface in the list of devices.
    a_i_x_hardware_0 = AIXHardware(0)
    var_0 = a_i_x

# Generated at 2022-06-24 21:51:38.594879
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    a_i_x_hardware_0.module.run_command = lambda x, y: (0, 'test string', '')
    var_0 = a_i_x_hardware_0.get_cpu_facts()
    assert isinstance(var_0, dict)


# Generated at 2022-06-24 21:52:47.656562
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    var_0 = a_i_x_hardware_0.get_vgs_facts()


# Generated at 2022-06-24 21:52:51.313782
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    var_0 = a_i_x_hardware_0.populate()

# Generated at 2022-06-24 21:52:53.995794
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    a_i_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:52:56.574129
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    a_i_x_hardware_0.populate()


# Generated at 2022-06-24 21:52:57.540074
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    AIXHardwareCollector()

# Generated at 2022-06-24 21:53:00.641695
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    var_0 = a_i_x_hardware_0.get_mount_facts()


# Generated at 2022-06-24 21:53:04.092160
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    var_0 = a_i_x_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 21:53:12.364893
# Unit test for method get_memory_facts of class AIXHardware

# Generated at 2022-06-24 21:53:15.376567
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)

    # Call method
    res_0 = a_i_x_hardware_0.get_device_facts()

    assert res_0 is not None



# Generated at 2022-06-24 21:53:19.226337
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    vgs_facts = a_i_x_hardware_0.get_vgs_facts()
    # print json.dumps(vgs_facts)


# Generated at 2022-06-24 21:56:37.997383
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    bool_1 = True
    str_0 = 'ansible.utils.unsafe_proxy.AnsibleUnsafeText'
    bool_2 = True
    bool_3 = True
    int_0 = 7
    str_1 = 'ansible.utils.unsafe_proxy.AnsibleUnsafeText'
    str_2 = 'ansible.utils.unsafe_proxy.AnsibleUnsafeText'
    str_3 = 'ansible.utils.unsafe_proxy.AnsibleUnsafeText'
    str_4 = 'ansible.utils.unsafe_proxy.AnsibleUnsafeText'
    str

# Generated at 2022-06-24 21:56:40.769659
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    var_0 = a_i_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:56:45.802082
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    var_0 = a_i_x_hardware_0.get_vgs_facts()


# Generated at 2022-06-24 21:56:49.369583
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    collected_facts_0 = {}
    a_i_x_hardware_0.populate(collected_facts_0)


# Generated at 2022-06-24 21:56:51.855126
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    a_i_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:56:55.226540
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    var_1 = a_i_x_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 21:56:57.423214
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    a_i_x_hardware_0.get_vgs_facts()


# Generated at 2022-06-24 21:56:59.956915
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    var_0 = a_i_x_hardware_0.get_device_facts()
    assert var_0 == {'devices': {}}


# Generated at 2022-06-24 21:57:11.009199
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    import os
    import tempfile


# Generated at 2022-06-24 21:57:13.711691
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    bool_0 = True
    a_i_x_hardware_0 = AIXHardware(bool_0)
    var_0 = a_i_x_hardware_0.get_cpu_facts()
