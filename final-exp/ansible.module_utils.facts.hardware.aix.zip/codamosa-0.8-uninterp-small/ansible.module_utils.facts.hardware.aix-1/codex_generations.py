

# Generated at 2022-06-24 21:48:30.578048
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    a_i_x_hardware_0 = AIXHardware()
    assert a_i_x_hardware_0.get_vgs_facts() != {}



# Generated at 2022-06-24 21:48:33.631126
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    # Try to instantiate object AIXHardwareCollector
    try:
        test_case_0()
    # Exception handling
    except Exception as exc:
        print("Exception while calling method AIXHardwareCollector: {0}".format(exc))


# Generated at 2022-06-24 21:48:43.198150
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    # return the test setup
    a_i_x_hardware = AIXHardware()
    a_i_x_hardware.module._debug = False
    a_i_x_hardware.module.params = {}
    a_i_x_hardware.module.run_command = MagicMock(return_value=(0, '', ''))
    a_i_x_hardware.module.get_bin_path = MagicMock(return_value='/usr/bin/mount')

    # all return values
    return_value = a_i_x_hardware.get_mount_facts()

    # assertions
    assert return_value.get('mounts') == []


# Generated at 2022-06-24 21:48:53.137962
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    a_i_x_hardware = AIXHardware()
    #assert a_i_x_hardware.populate() == {'firmware_version': 'IBM,1B37A535', 'lpar_info': 'lpar_name=rhel-7.2,lpar_id=2', 'processor': ['PowerPC_POWER7','pSeries'], 'vgs': {'rhel-7.2': [{'total_pps': '999', 'free_pps': '838', 'pv_state': 'active', 'pv_name': 'hdisk105', 'pp_size': '4 megabyte(s)'}, {'total_pps': '999', 'free_pps': '599', 'pv_state': 'active', 'pv_name': 'hdisk106', 'pp_size': '4

# Generated at 2022-06-24 21:48:58.056774
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    a_i_x_hardware_0 = AIXHardware(module=None)
    a_i_x_hardware_0.populate()
    assert a_i_x_hardware_0.get_memory_facts() == {'swapfree_mb': 3299, 'swaptotal_mb': 3299, 'memtotal_mb': 181496, 'memfree_mb': 181342}


# Generated at 2022-06-24 21:49:01.355056
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    a_i_x_hardware_0 = AIXHardwareCollector()
    consumer_of_a_i_x_hardware_0 = a_i_x_hardware_0.collect()
    a_i_x_hardware_0.populate(consumer_of_a_i_x_hardware_0)
    a_i_x_hardware_0.get_device_facts()


# Generated at 2022-06-24 21:49:03.303428
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_0 = AIXHardwareCollector()


# Generated at 2022-06-24 21:49:11.112103
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    vgs_facts = {}

# Generated at 2022-06-24 21:49:15.584375
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_0 = AIXHardwareCollector()
    assert a_i_x_hardware_collector_0 is not None


# Generated at 2022-06-24 21:49:20.197585
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    # Memory facts for empty system
    assert AIXHardware().get_memory_facts() == {
        'memfree_mb': 0,
        'memtotal_mb': 0,
        'swapfree_mb': 0,
        'swaptotal_mb': 0
    }


# Generated at 2022-06-24 21:49:42.296768
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    try:
        test_case_0()
        print("test case 0 passed.")
    except Exception as e:
        print("test case 0 failed.")
        print(e)


# Generated at 2022-06-24 21:49:50.961744
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    # Generate test data
    lsdev_out = u'ent0 Available 08-08-10 Gigabit Ethernet Adapter (df1000fe) \n\
                ent1 Available 08-09-10 Gigabit Ethernet Adapter (df1000fe)'
    lsattr_out = u'alt_addr        0x000000000000 Alternate Ethernet address False\n\
                  dma_rlock_lim    -1            DMA read lock limit False\n\
                  large_send       yes           Large Send False\n\
                  large_receive    yes           Large Receive False\n\
                  media_speed      Auto          Media Speed False\n\
                  num_tx_buf       2048          Number of transmit buffers False'

    # Initialise object

# Generated at 2022-06-24 21:50:02.846798
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_0.module = Mock()
    a_i_x_hardware_0.module.run_command = Mock()

    # Set up the mock
    # get_cpu_facts

# Generated at 2022-06-24 21:50:03.902487
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_0.populate()


# Generated at 2022-06-24 21:50:08.471421
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_0 = AIXHardwareCollector()
    assert a_i_x_hardware_collector_0.get_platform() == 'AIX'
    assert a_i_x_hardware_collector_0.get_fact_class() == AIXHardware


# Generated at 2022-06-24 21:50:14.665497
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    a_i_x_hardware = AIXHardware()
    cpu_facts = a_i_x_hardware.get_cpu_facts()
    assert isinstance(cpu_facts, dict)
    assert 'processor_count' in cpu_facts.keys()
    assert 'processor' in cpu_facts.keys()
    assert 'processor_cores' in cpu_facts.keys()


# Generated at 2022-06-24 21:50:25.320153
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    a_i_x_hardware_collector_0 = AIXHardwareCollector()
    a_i_x_hardware_0 = AIXHardware({})
    a_i_x_hardware_0.populate()
    # AssertionError: {'processor': ['PowerPC_POWER5'], 'processor_cores': 2, 'processor_count': 2} != {'processor': ['PowerPC_POWER5'], 'processor_cores': 4, 'processor_count': 4}
    assert a_i_x_hardware_0.get_cpu_facts() == {'processor': ['PowerPC_POWER5'], 'processor_cores': 4, 'processor_count': 4}


# Generated at 2022-06-24 21:50:35.553030
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    # Valid mount point
    mount_path = '/'
    module = AnsibleModuleMock.get_mock()

    a_i_x_hardware = AIXHardware(module)

    module.run_command = MagicMock(return_value=(0, ' \n/dev/hd1  /  jfs2  rw,log=/dev/hd8  0 0\nnode:node:/nodename:/ /net/node/node:/nfs  nfs  rw,nointr,rsize=32768,wsize=32768,soft\n', ''))

    a_i_x_hardware.get_mount_facts()

    module.run_command.assert_called_with("mount", check_rc=False)

    # valid mount point with no options

# Generated at 2022-06-24 21:50:39.788857
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    a_i_x_hardware_0 = AIXHardware()
    assert a_i_x_hardware_0.get_cpu_facts() == {}


# Generated at 2022-06-24 21:50:44.376613
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    AIXHardware_populate_0 = AIXHardware(None)
    AIXHardware_populate_1 = AIXHardware(None)
    AIXHardware_populate_1.populate(None)
    AIXHardware_populate_2 = AIXHardware(None)
    AIXHardware_populate_2.populate(None)


# Generated at 2022-06-24 21:51:29.540044
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    """
    Unit test for method get_vgs_facts of class AIXHardware
    """
    a_i_x_hardware_0 = AIXHardware()

    # Test with good input
    try:
        phw = AIXHardware()
        pfacts = a_i_x_hardware_0.get_vgs_facts()
        assert len(pfacts['vgs']['rootvg']) == 2
    except Exception as e:
        if isinstance(e, AssertionError):
            raise e
        assert False

    # Test with bad input



# Generated at 2022-06-24 21:51:42.180982
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    a_i_x_hardware_0 = AIXHardware()

# Generated at 2022-06-24 21:51:44.529370
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    a_i_x_hardware_0 = AIXHardware({})


# Generated at 2022-06-24 21:51:45.737130
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    obj = AIXHardware({}) # AnsibleModule)
    out = obj.get_dmi_facts()
    assert out



# Generated at 2022-06-24 21:51:48.074401
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    a_i_x_hardware_0 = AIXHardware()
    # get_memory_facts() return value
    a_i_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:51:54.705652
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    a_i_x_hardware_0 = AIXHardware()
    lsps_path = a_i_x_hardware_0.module.get_bin_path("lsps")
    lsvg_path = a_i_x_hardware_0.module.get_bin_path("lsvg")
    xargs_path = a_i_x_hardware_0.module.get_bin_path("xargs")
    cmd = "%s -s | %s %s -p" % (lsps_path, xargs_path, lsvg_path)
    if lsps_path and lsvg_path and xargs_path:
        rc, out, err = a_i_x_hardware_0.module.run_command(cmd, use_unsafe_shell=True)

# Generated at 2022-06-24 21:51:59.298719
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_0.module.run_command = MagicMock(return_value=(0, "", ""))

    result = a_i_x_hardware_0.get_mount_facts()



# Generated at 2022-06-24 21:52:08.653401
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_0.module.run_command = Mock(return_value=(0, 'output', 'error'))
    a_i_x_hardware_0.populate()
    memory_facts = a_i_x_hardware_0.get_memory_facts()

    assert(memory_facts == {'memfree_mb': 1, 'memtotal_mb': 2,
                            'swapfree_mb': 1, 'swaptotal_mb': 2})


# Generated at 2022-06-24 21:52:13.548922
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_0.module.run_command = lambda args, **kwargs: (0, 'FW-LIC-8231-E2C-R       IBM,8231-E2C-R\n', '')
    return a_i_x_hardware_0.get_dmi_facts() == {'firmware_version': '8231-E2C-R'}


# Generated at 2022-06-24 21:52:19.187523
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():

    a_i_x_hardware_0 = AIXHardware()
    result = a_i_x_hardware_0.get_mount_facts()

    assert result is not None
    assert type(result) is dict
    assert 'mounts' in result
    assert type(result['mounts']) is list
    assert len(result['mounts']) > 0


# Generated at 2022-06-24 21:53:45.609664
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    print("")
    print("-------------------------------------------")
    print("Testing: get_memory_facts")
    print("-------------------------------------------")
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_0.module = MagicMock()
    a_i_x_hardware_0.module.run_command.return_value = (0, "memory pages:   819136", "")
    a_i_x_hardware_0.module.run_command.return_value = (0, "free pages:    819136", "")
    # Test 1
    mem_facts = {"memfree_mb": 819136, "memtotal_mb": 819136, "swapfree_mb": None, "swaptotal_mb": None}

# Generated at 2022-06-24 21:53:52.711358
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    a_i_x_hardware = AIXHardware()

    rc, out, err = a_i_x_hardware.module.run_command('/usr/sbin/lsdev -C')
    device_list = []
    for line in out.splitlines():
        fields = line.split()
        device_list.append(fields[0])

    device_facts = a_i_x_hardware.get_device_facts()
    assert "devices" in device_facts

    for device in device_list:
        assert device in device_facts['devices']


# Generated at 2022-06-24 21:54:01.959325
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    a_i_x_hardware = AIXHardware()
    a_i_x_hardware_get_mount_facts_retval = a_i_x_hardware.get_mount_facts()

# Generated at 2022-06-24 21:54:10.170066
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    hardware_0 = AIXHardware()
    vgs_facts = hardware_0.get_vgs_facts()
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs_facts['vgs']['rootvg'][0]['pv_state'] == 'active'
    assert vgs_facts['vgs']['rootvg'][0]['total_pps'] == '546'
    assert vgs_facts['vgs']['rootvg'][0]['free_pps'] == '0'
    assert vgs_facts['vgs']['rootvg'][0]['pp_size'] == '4 megabytes'


# Generated at 2022-06-24 21:54:12.423060
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_0 = AIXHardwareCollector()
    assert a_i_x_hardware_collector_0._platform == 'AIX'


# Generated at 2022-06-24 21:54:21.422888
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    a_i_x_hardware = AIXHardware()
    result = a_i_x_hardware.get_cpu_facts()
    assert len(result) == 3
    assert 'processor' in result

# Generated at 2022-06-24 21:54:26.758260
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_1 = AIXHardwareCollector()
    assert (a_i_x_hardware_collector_1.platform == 'AIX')  # Constructor
    assert (a_i_x_hardware_collector_1._platform == 'AIX')  # Constructor
    assert (a_i_x_hardware_collector_1._fact_class == AIXHardware)  # Constructor
    assert (a_i_x_hardware_collector_1.collect() == None)  # Method


# Generated at 2022-06-24 21:54:29.422366
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_0.populate()


# Generated at 2022-06-24 21:54:31.711000
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_0.populate()



# Generated at 2022-06-24 21:54:35.352573
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    a_i_x_hardware_0 = AIXHardware()
    assert a_i_x_hardware_0.get_memory_facts() == {'memfree_mb': 1766, 'memtotal_mb': 1679, 'swapfree_mb': 1787, 'swaptotal_mb': 2048}
