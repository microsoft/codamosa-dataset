

# Generated at 2022-06-24 21:48:35.138730
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    print("")
    print("--- Test AIXHardware.get_memory_facts ---")
    int_0 = -1605
    a_i_x_hardware_0 = AIXHardware(int_0)
    a_i_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:48:46.123048
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    AIXHardware_get_dmi_facts_0 = AIXHardware()
    AIXHardware_get_dmi_facts_0.module = MagicMock()
    AIXHardware_get_dmi_facts_0.module.run_command = MagicMock(return_value=(0, 'IBM,8233-E8B', ''))
    AIXHardware_get_dmi_facts_0.module.get_bin_path = MagicMock()
    AIXHardware_get_dmi_facts_0.module.get_bin_path.return_value = '/usr/sbin/lsconf'
    AIXHardware_get_dmi_facts_0.module.run_command.return_value = (0, 'lparg1\nSystem Model: IBM,8233-E8B', '')
    AIXHardware

# Generated at 2022-06-24 21:48:48.813955
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_0.get_mount_facts()


# Generated at 2022-06-24 21:48:51.072777
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    a_i_x_hardware_0 = AIXHardware("module_0")
    a_i_x_hardware_0.populate()



# Generated at 2022-06-24 21:49:03.135985
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    a_i_x_hardware_collector_0 = AIXHardwareCollector(-1)
    a_i_x_hardware_collector_0.module = "an AnsibleModule object"
    a_i_x_hardware_collector_0.module.get_bin_path = "an ansible_module get_bin_path method"
    a_i_x_hardware_collector_0.module.run_command = "an ansible_module run_command method"
    a_i_x_hardware_collector_0.facts.populate()

# Generated at 2022-06-24 21:49:07.769148
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    int_0 = -1605
    a_i_x_hardware_collector_0 = AIXHardwareCollector(int_0)
    assert a_i_x_hardware_collector_0._fact_class.get_cpu_facts() == {'processor': ['PowerPC_POWER8'], 'processor_cores': 8, 'processor_count': 4}


# Generated at 2022-06-24 21:49:18.157176
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    lsdev_cmd = "lsdev"
    lsattr_cmd = "lsattr"
    lsdev_content = "ent0 Available 06-08 Gigabit Ethernet PCI-X Adapter (df1000fe) \nent1 Available 06-08 Gigabit Ethernet PCI-X Adapter (df1000fe) \nent2 Available 06-08 Gigabit Ethernet PCI-X Adapter (df1000fe) \nent3 Available 06-08 Gigabit Ethernet PCI-X Adapter (df1000fe)"

# Generated at 2022-06-24 21:49:20.434297
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    a_i_x_hardware_0 = AIXHardware()
    print('AIXHardware_get_cpu_facts')
    a_i_x_hardware_0.get_cpu_facts()
    print('AIXHardware_get_cpu_facts')


# Generated at 2022-06-24 21:49:24.438389
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    int_0 = -1605
    a_i_x_hardware_collector_0 = AIXHardwareCollector(int_0)

    str_0 = 'AIX'
    str_1 = a_i_x_hardware_collector_0.platform
    assert (str_0 == str_1)


# Generated at 2022-06-24 21:49:29.236950
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    print('>', end=' ')
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_get_vgs_facts_0 = a_i_x_hardware_0.get_vgs_facts()
    print(a_i_x_hardware_get_vgs_facts_0)


# Generated at 2022-06-24 21:49:58.252618
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_0.module.run_command = lambda *args, **kwargs: (0, "", "")
    assert a_i_x_hardware_0.get_memory_facts() == {
        'swapfree_mb': a_i_x_hardware_0.swapfree_mb,
        'swaptotal_mb': a_i_x_hardware_0.swaptotal_mb,
        'memfree_mb': a_i_x_hardware_0.memfree_mb,
        'memtotal_mb': a_i_x_hardware_0.memtotal_mb}

# Generated at 2022-06-24 21:50:02.423993
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    a_i_x_hardware_collector_0 = AIXHardwareCollector()
    a_i_x_hardware_0 = AIXHardware(a_i_x_hardware_collector_0.module)
    a_i_x_hardware_0.get_mount_facts()

# Generated at 2022-06-24 21:50:06.204818
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    a_i_x_hardware_0 = AIXHardware()
    # Should raise no exception
    a_i_x_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 21:50:09.714292
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    a_i_x_hardware_0 = AIXHardware()

    # Test with no params
    a_i_x_hardware_0.populate(collected_facts={})



# Generated at 2022-06-24 21:50:19.635956
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    a_i_x_hardware_0 = AIXHardware()
    rc, out, err = a_i_x_hardware_0.module.run_command("/usr/sbin/lsattr -El sys0 -a fwversion")
    data = out.split()
    result = data[1].strip('IBM,')
    assert result == '820-2013-12-10', "Firmware version not as expected"
    rc, out, err = a_i_x_hardware_0.module.run_command("/usr/sbin/lsconf")
    assert rc == 0, "lsconf command failed"
    assert out, "lsconf command output empty"
    assert 'Machine Serial Number' in out, "Machine Serial Number not present in lsconf"

# Generated at 2022-06-24 21:50:22.410342
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector = AIXHardwareCollector()


# Generated at 2022-06-24 21:50:33.341682
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    AIX_hardware = AIXHardware()
    rc, out, err = AIX_hardware.module.run_command("/usr/sbin/lsconf")
    if rc == 0 and out:
        dmi_facts = AIX_hardware.get_dmi_facts()
        assert dmi_facts['product_serial'] == re.search(r'Machine Serial Number:\s+(\S+)', out).group(1)
        assert dmi_facts['lpar_info'] == re.search(r'LPAR Info:\s+(\S+)', out).group(1)
        assert dmi_facts['product_name'] == re.search(r'System Model:\s+(\S+)', out).group(1)


# Generated at 2022-06-24 21:50:38.125057
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    a_i_x_hardware_0 = AIXHardware({})
    a_i_x_hardware_0._module = MockModule()
    assert a_i_x_hardware_0.get_dmi_facts() == {'firmware_version': 'IBM,1.1.1.1', 'product_serial': 'ABCD12345', 'lpar_info': 'robin', 'product_name': 'IBM,7998'}


# Generated at 2022-06-24 21:50:42.031635
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    # common
    a_i_x_hardware_collector_0 = AIXHardwareCollector()
    # var.1: None
    a_i_x_hardware_collector_0.get_mount_facts()

# Generated at 2022-06-24 21:50:46.714186
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():

    hw = AIXHardware({})

    hw.module.run_command = get_cpu_facts_command

    cpu_facts = hw.get_cpu_facts()

    assert cpu_facts['processor'] == 'PowerPC_POWER9'
    assert cpu_facts['processor_cores'] == 8
    assert cpu_facts['processor_count'] == 2


# Generated at 2022-06-24 21:51:09.426497
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    a_i_x_hardware_0 = AIXHardware()
    test_result = a_i_x_hardware_0.get_cpu_facts()
    assert test_result is None


# Generated at 2022-06-24 21:51:15.100992
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    a_i_x_hardware_collector_1 = AIXHardwareCollector()
    a_i_x_hardware_1 = AIXHardware(a_i_x_hardware_collector_1)
    out = a_i_x_hardware_1.get_vgs_facts()
    assert isinstance(out, dict)


# Generated at 2022-06-24 21:51:17.093850
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_0.populate()


# Generated at 2022-06-24 21:51:18.630347
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector = AIXHardwareCollector()


# Generated at 2022-06-24 21:51:21.333623
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    a_i_x_hardware_get_dmi_facts = AIXHardware()
    a_i_x_hardware_get_dmi_facts.get_dmi_facts()


# Generated at 2022-06-24 21:51:22.307373
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    pass


# Generated at 2022-06-24 21:51:31.556956
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():

    a_i_x_hardware = AIXHardware(dict(), '', '')

    rc, out_lsdev, err = a_i_x_hardware.module.run_command('/usr/bin/lsdev -S 1')

    rc, out_lsattr, err = a_i_x_hardware.module.run_command(['/usr/bin/lsattr', '-E', '-l', 'hdisk0'])

    device_facts = a_i_x_hardware.get_device_facts()

    assert device_facts['devices']['hdisk0']['attributes']['dev_size'] == '3072'



# Generated at 2022-06-24 21:51:44.060271
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    test_mount_facts = {
        'mounts':
        [{u'mount': u'/',
            u'options': u'rw,log=/dev/hd8',
            u'device': u'/dev/hd4',
            u'bytes_used': 57733406720, u'bytes_total': 323314372,
            u'available_percent': 100,
            u'path': u'/',
            u'percent_used': 9,
            u'fstype': u'jfs2',
            u'time': u'Thu Mar 5 19:23:56 2009',
            u'used': 323314372}]}

    a_i_x_hardware = AIXHardware()
    assert test_mount_facts == a_i_x_hardware.get_mount_facts()

# Unit test

# Generated at 2022-06-24 21:51:47.588637
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    a_i_x_hardware_0 = AIXHardware()
    out = a_i_x_hardware_0.get_vgs_facts()
    assert 'vgs' in out.keys()


# Generated at 2022-06-24 21:51:49.668638
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_0.populate()


# Generated at 2022-06-24 21:52:14.258407
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    int_0 = 4
    list_0 = [int_0, int_0, int_0]
    a_i_x_hardware_0 = AIXHardware(list_0)
    vg_info = {'total_pps': '11', 'pv_name': 'hdisk105', 'pp_size': '4 MB', 'pv_state': 'active', 'free_pps': '4'}
    var_1 = a_i_x_hardware_0.populate()
    var_2 = 'realsyncvg'
    test_case_0(var_1, var_2)

# Generated at 2022-06-24 21:52:18.411197
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    int_0 = 23
    list_0 = [int_0, int_0, int_0]
    a_i_x_hardware_0 = AIXHardware(list_0)
    a_i_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:52:28.425154
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    int_0 = 2
    list_0 = [int_0, int_0, int_0]
    a_i_x_hardware_0 = AIXHardware(list_0)
    int_1 = 4096
    int_2, out_0, err_0 = a_i_x_hardware_0.module.run_command("/usr/bin/vmstat -v")
    int_3 = 0
    int_4 = 0
    var_0 = a_i_x_hardware_0.get_memory_facts()
    # Test has been suspended:
    # Other tests may produce this file, so it may be readable/writable by
    # another user

# Generated at 2022-06-24 21:52:34.343014
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    int_0 = 23
    list_1 = [int_0, int_0, int_0]
    a_i_x_hardware_1 = AIXHardware(list_1)

    a_i_x_hardware_1.get_dmi_facts()


# Generated at 2022-06-24 21:52:42.300348
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    int_0 = 72
    list_0 = [int_0, int_0, int_0]
    a_i_x_hardware_0 = AIXHardware(list_0)
    a_i_x_hardware_0.module = MagicMock(spec_set=None)
    a_i_x_hardware_0.module.run_command.return_value = (0, '', 0)
    var_0 = a_i_x_hardware_0.get_dmi_facts()
    assert var_0 == {'firmware_version': 'IBM,6.30', 'product_serial': 'FA000000', 'lpar_info': '<none>', 'product_name': 'IBM,8286-42A'}


# Generated at 2022-06-24 21:52:48.041992
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module_0 = AnsibleModule(
        argument_spec = dict()
    )
    int_0 = 23
    list_0 = [int_0, int_0, int_0]
    a_i_x_hardware_0 = AIXHardware(list_0)
    result_0 = a_i_x_hardware_0.populate()
    print(result_0)


# Generated at 2022-06-24 21:52:53.384106
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    int_0 = 23
    list_0 = [int_0, int_0, int_0]
    a_i_x_hardware_0 = AIXHardware(list_0)
    var_0 = a_i_x_hardware_0.get_device_facts()
    print(var_0.get('devices'))


# Generated at 2022-06-24 21:53:00.521662
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    int_0 = 25
    list_0 = [int_0]
    a_i_x_hardware_0 = AIXHardware(list_0)
    a_i_x_hardware_0._module = MagicMock()
    a_i_x_hardware_0._module.run_command.return_value = (0, 'memory pages', '')
    var_0 = a_i_x_hardware_0.get_memory_facts()
    expected_0 = {'memfree_mb': '', 'memtotal_mb': '', 'swapfree_mb': '', 'swaptotal_mb': ''}
    assert isinstance(var_0, dict)
    assert var_0 == expected_0


# Generated at 2022-06-24 21:53:04.358803
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    list_0 = []
    a_i_x_hardware_0 = AIXHardware(list_0)
    a_i_x_hardware_0.populate()
    var_0 = a_i_x_hardware_0.populate()


# Generated at 2022-06-24 21:53:08.413201
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    int_0 = 23
    list_0 = [int_0, int_0, int_0]

    a_i_x_hardware_0 = AIXHardware(list_0)
    var_0 = a_i_x_hardware_0.get_memory_facts()
    # assert var_0==None


# Generated at 2022-06-24 21:53:59.146954
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    int_0 = 23
    list_0 = [int_0, int_0, int_0]
    a_i_x_hardware_0 = AIXHardware(list_0)
    var_0 = a_i_x_hardware_0.get_vgs_facts()
    assert isinstance(var_0, dict)


# Generated at 2022-06-24 21:54:01.583899
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    list_0 = ['23', '23', '23']
    a_i_x_hardware_0 = AIXHardware(list_0)
    var_0 = a_i_x_hardware_0.populate()


# Generated at 2022-06-24 21:54:06.406835
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_0 = AIXHardwareCollector()
    bool_0 = isinstance(a_i_x_hardware_collector_0, AIXHardwareCollector)
    assert bool_0 == True

if __name__ == '__main__':
    test_AIXHardwareCollector()
    test_case_0()

# Generated at 2022-06-24 21:54:09.086191
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    lsdev_path = None
    lsattr_path = None
    a_i_x_hardware_collector_0 = AIXHardwareCollector(lsdev_path, lsattr_path)

# Generated at 2022-06-24 21:54:12.742122
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    int_0 = 23

    list_0 = [int_0, int_0, int_0]


    a_i_x_hardware_0 = AIXHardware(list_0)

    # call the method
    var_0 = a_i_x_hardware_0.get_cpu_facts()



# Generated at 2022-06-24 21:54:16.958304
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    int_0 = 23
    list_0 = [int_0, int_0, int_0]
    a_i_x_hardware_0 = AIXHardware(list_0)
    var_0 = a_i_x_hardware_0.get_device_facts()


# Generated at 2022-06-24 21:54:20.421055
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    int_0 = 23
    list_0 = [int_0, int_0, int_0]
    a_i_x_hardware_0 = AIXHardware(list_0)
    var_0 = a_i_x_hardware_0.populate()



# Generated at 2022-06-24 21:54:23.557869
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    list_0 = [23, 23]
    a_i_x_hardware_0 = AIXHardware(list_0)
    var_1 = a_i_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:54:25.042701
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    test_AIXHardware_get_mount_facts_SampleInput_1()


# Generated at 2022-06-24 21:54:26.581039
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_0 = AIXHardwareCollector()


# Generated at 2022-06-24 21:56:26.784312
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    aix_hardware_collector_0 = AIXHardwareCollector()

# Generated at 2022-06-24 21:56:33.189685
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    int_0 = 8
    int_1 = 15
    str_1 = "processor"
    int_2 = 2
    str_2 = "processor_cores"
    int_3 = 1
    str_3 = "processor_count"
    list_0 = [int_0, int_1, str_1, int_2, str_2, int_3, str_3]
    a_i_x_hardware_0 = AIXHardware(list_0)
    a_i_x_hardware_1 = AIXHardware(list_0)
    a_i_x_hardware_2 = AIXHardware(list_0)
    a_i_x_hardware_3 = AIXHardware(list_0)
    a_i_x_hardware_4 = AIXHardware(list_0)

# Generated at 2022-06-24 21:56:36.198730
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    int_0 = 23
    list_0 = [int_0, int_0, int_0]
    a_i_x_hardware_0 = AIXHardware(list_0)
    var_0 = a_i_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:56:37.023776
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    assert AIXHardwareCollector._platform == 'AIX'
    assert AIXHardwareCollector._fact_class == AIXHardware

# Generated at 2022-06-24 21:56:39.572804
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    int_0 = 0
    list_0 = [int_0, int_0, int_0]
    a_i_x_hardware_0 = AIXHardware(list_0)
    a_i_x_hardware_0.get_vgs_facts()

# Generated at 2022-06-24 21:56:42.640807
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    int_0 = 23
    list_0 = [int_0, int_0, int_0]
    a_i_x_hardware_0 = AIXHardware(list_0)
    var_0 = a_i_x_hardware_0.populate()


# Generated at 2022-06-24 21:56:48.954196
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    int_0 = 23
    list_0 = [int_0, int_0, int_0]
    a_i_x_hardware_0 = AIXHardware(list_0)
    var_0 = a_i_x_hardware_0.get_memory_facts()
    a_i_x_hardware_0 = AIXHardware([list_0])


# Generated at 2022-06-24 21:56:53.174105
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    int_0 = 46
    list_0 = [int_0, int_0, int_0]
    a_i_x_hardware_0 = AIXHardware(list_0)
    vgs_facts = a_i_x_hardware_0.get_vgs_facts()
    assert type(vgs_facts) is dict


# Generated at 2022-06-24 21:56:56.964016
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    int_0 = 23
    list_0 = [int_0, int_0, int_0]
    a_i_x_hardware_0 = AIXHardware(list_0)
    var_0 = a_i_x_hardware_0.get_mount_facts()


# Generated at 2022-06-24 21:56:59.520879
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    int_0 = 41
    list_0 = [int_0, int_0, int_0]
    a_i_x_hardware_0 = AIXHardware(list_0)

    a_i_x_hardware_0.get_memory_facts()
