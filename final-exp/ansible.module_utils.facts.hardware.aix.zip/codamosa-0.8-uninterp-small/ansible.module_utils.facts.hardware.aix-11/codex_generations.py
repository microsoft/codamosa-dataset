

# Generated at 2022-06-24 21:48:29.777006
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    pass


# Generated at 2022-06-24 21:48:38.221943
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    bytes_0 = b'e\xd2\x12\xe2\xf39\xc1\xa7P\xff(d\x83\x98\xd8\xa6\xba'
    a_i_x_hardware_0 = AIXHardware(bytes_0)

    # Test exception handling for AIXHardware.get_vgs_facts()
    # Test with a AIXHardware object

# Generated at 2022-06-24 21:48:43.458230
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    bytes_0 = b'\x86\xf7\x17\x06~\x9b\xba\x83\x0b\x13L\x8a\xad\xb3\xcf'
    a_i_x_hardware_0 = AIXHardware(bytes_0)
    result = a_i_x_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 21:48:53.311150
# Unit test for method get_vgs_facts of class AIXHardware

# Generated at 2022-06-24 21:48:54.759479
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    rc, out, err = get_dmi_facts()
    assert rc == 0

# Generated at 2022-06-24 21:49:05.838360
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    bytes_0 = b'\xacm\xb4\xd4\x04\x7fB\x1c\xde\xe3\x0f\x1e\xaeZ\x9d\x8c\x91\xe6#\x92'
    a_i_x_hardware_0 = AIXHardware(bytes_0)
    a_i_x_hardware_0.gather_mount_facts = lambda : None
    a_i_x_hardware_0.module = MagicMock()
    a_i_x_hardware_0.get_mount_facts()
    a_i_x_hardware_0.get_mount_facts()

# Generated at 2022-06-24 21:49:07.305237
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    a_i_x_hardware_1 = AIXHardware(b'')
    a_i_x_hardware_1.populate()

# Generated at 2022-06-24 21:49:18.135843
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    bytes_0 = b'Y\xf4I\xe1\x12\xcc\x90\x88\xe5\xaf\x87\x06\xa8\x0b\x9d\x15'
    a_i_x_hardware_0 = AIXHardware(bytes_0)

    vgs_facts_0 = a_i_x_hardware_0.get_vgs_facts()
    assert not vgs_facts_0
    bytes_1 = b'\xb8\x1c\x15\xd5\x19D\xdb\x8dX\xce\x93\xeeS\x8c\xb1\x08'
    a_i_x_hardware_1 = AIXHardware(bytes_1)

    vgs_facts_1 = a_i

# Generated at 2022-06-24 21:49:23.893660
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    bytes_0 = b'\xfc\xe1\xef\xe1$\xbe\xb7\xcc\xcf\xab\xdb\xfb\x1a\x06\xea\xde\x02\xf7\x83\xaf\xdd\x12\xfa\xef'
    a_i_x_hardware_0 = AIXHardware(bytes_0)

# Generated at 2022-06-24 21:49:25.193265
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_0 = AIXHardwareCollector()


# Generated at 2022-06-24 21:49:47.621454
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    int_0 = -980
    a_i_x_hardware_0 = AIXHardware(int_0)
    var_0 = a_i_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:49:54.068342
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():

    try:
        # Initiating the AIXHardware class
        int_0 = -944
        a_i_x_hardware_0 = AIXHardware(int_0)
        # Calling get_cpu_facts method
        # Calling get_cpu_facts method
        # Calling get_cpu_facts method
        var_0 = a_i_x_hardware_0.get_cpu_facts()
    except Exception:
        print('Caught exception')
        raise


# Generated at 2022-06-24 21:49:56.086977
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    test_case_0()


# Generated at 2022-06-24 21:49:58.556587
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_0 = AIXHardwareCollector()


# Generated at 2022-06-24 21:50:02.119757
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    int_0 = -480
    a_i_x_hardware_0 = AIXHardware(int_0)
    assert a_i_x_hardware_0.get_vgs_facts() != None


# Generated at 2022-06-24 21:50:06.332947
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    int_0 = -983
    a_i_x_hardware_0 = AIXHardware(int_0)
    var_0 = a_i_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:50:15.897967
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    a_i_x_hardware_0 = AIXHardware(1)
    a_i_x_hardware_0.get_cpu_facts()
    a_i_x_hardware_0.get_memory_facts()
    a_i_x_hardware_0.get_dmi_facts()
    a_i_x_hardware_0.get_vgs_facts()
    a_i_x_hardware_0.get_mount_facts()
    a_i_x_hardware_0.get_device_facts()
    a_i_x_hardware_0.populate()


# Generated at 2022-06-24 21:50:20.158817
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    print("TEST get_mount_facts ...")
    int_1 = -980
    a_i_x_hardware_1 = AIXHardware(int_1)
    assert a_i_x_hardware_1.get_mount_facts() is not None
    print("OK")


# Generated at 2022-06-24 21:50:27.623408
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    int_0 = -907
    a_i_x_hardware_0 = AIXHardware(int_0)
    a_i_x_hardware_0.module.set_bin_path('/usr/sbin/lsvg')
    a_i_x_hardware_0.module.set_bin_path('/usr/bin/xargs')
    str_0 = a_i_x_hardware_0.get_vgs_facts()


# Generated at 2022-06-24 21:50:29.503765
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    var_0 = AIXHardware()
    var_0.get_dmi_facts()


# Generated at 2022-06-24 21:51:09.917953
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    int_1 = -698
    a_i_x_hardware_1 = AIXHardware(int_1)
    var_1 = a_i_x_hardware_1.get_mount_facts()
    assert var_1 == var_1


# Generated at 2022-06-24 21:51:19.359813
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    int_0 = -730
    a_i_x_hardware_0 = AIXHardware(int_0)
    a_i_x_hardware_0.module = Mock(name='module')
    type(a_i_x_hardware_0.module).get_bin_path = Mock(return_value='/usr/sbin/lsdev')
    type(a_i_x_hardware_0.module).run_command = Mock(return_value=(0, get_device_facts_mock_out, 'stdout', 'stderr'))
    var_0 = a_i_x_hardware_0.get_device_facts()
    assert var_0 == get_device_facts_mock_out_result


# Generated at 2022-06-24 21:51:22.585386
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    int_0 = -980
    a_i_x_hardware_0 = AIXHardware(int_0)
    var_0 = a_i_x_hardware_0.get_device_facts()


# Generated at 2022-06-24 21:51:25.767182
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_0 = AIXHardwareCollector()


# Generated at 2022-06-24 21:51:27.648289
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    int_0 = -980
    a_i_x_hardware_0 = AIXHardware(int_0)
    var_0 = a_i_x_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 21:51:29.946381
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    a_i_x_hardware_1 = AIXHardware(0)
    var_1 = a_i_x_hardware_1.get_device_facts()


# Generated at 2022-06-24 21:51:33.331787
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    int_0 = -34
    a_i_x_hardware_0 = AIXHardware(int_0)
    var_0 = a_i_x_hardware_0.get_mount_facts()


# Generated at 2022-06-24 21:51:44.486363
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    int_0 = -980
    a_i_x_hardware_0 = AIXHardware(int_0)
    a_i_x_hardware_0.module.get_bin_path = MagicMock(return_value='/bin/mount')
    a_i_x_hardware_0.module.run_command = MagicMock(return_value=(0, '', ''))
    a_i_x_hardware_0.get_mount_facts()
    assert a_i_x_hardware_0.module.get_bin_path.call_count == 2
    assert a_i_x_hardware_0.module.run_command.call_count == 1


# Generated at 2022-06-24 21:51:46.128255
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    int_0 = -661
    a_i_x_hardware_0 = AIXHardware(int_0)
    a_i_x_hardware_0.populate()


# Generated at 2022-06-24 21:51:55.994770
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    int_0 = -980
    a_i_x_hardware_0 = AIXHardware(int_0)

# Generated at 2022-06-24 21:53:17.908550
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    uu_0 = AIXHardware()
    uu_1 = []
    uu_1.append('lsdev')
    uu_1.append('-Cc')
    uu_1.append('disk')
    uu_2 = []
    uu_3 = []
    uu_3.append('lsattr')
    uu_3.append('-E')
    uu_3.append('-l')
    uu_4 = []
    uu_4.append(uu_3)
    uu_4.append('sdisk')
    uu_5 = {}
    uu_6 = {}
    uu_6['devices'] = uu_5
    uu_7 = []
    uu_7.append(uu_6)
    uu_8 = {}


# Generated at 2022-06-24 21:53:20.499570
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    int_0 = -980
    a_i_x_hardware_0 = AIXHardware(int_0)
    a_i_x_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 21:53:29.908764
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    int_0 = -980
    a_i_x_hardware_0 = AIXHardware(int_0)

    rc, out, err = a_i_x_hardware_0.module.run_command("/usr/sbin/lsdev -Cc processor")
    if out:
        i = 0
        for line in out.splitlines():

            if 'Available' in line:
                if i == 0:
                    data = line.split(' ')
                    cpudev = data[0]

                i += 1

    rc, out, err = a_i_x_hardware_0.module.run_command("/usr/sbin/lsattr -El " + cpudev + " -a type")

    data = out.split(' ')

    rc, out, err = a_i_x_hardware

# Generated at 2022-06-24 21:53:33.276520
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    int_0 = -980
    a_i_x_hardware_0 = AIXHardware(int_0)
    var_0 = a_i_x_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 21:53:37.452768
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    int_0 = -980
    a_i_x_hardware_0 = AIXHardware(int_0)
    expected_0 = "mounts"
    var_0 = a_i_x_hardware_0.get_mount_facts()
    actual_0 = var_0
    assert expected_0 == actual_0


# Generated at 2022-06-24 21:53:39.362229
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    assert isinstance(AIXHardware(0).get_dmi_facts(), dict)


# Generated at 2022-06-24 21:53:42.447425
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    int_0 = -980
    a_i_x_hardware_0 = AIXHardware(int_0)
    var_0 = a_i_x_hardware_0.get_vgs_facts()


# Generated at 2022-06-24 21:53:46.202644
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    int_0 = -980
    a_i_x_hardware_0 = AIXHardware(int_0)
    a_i_x_hardware_0.populate()
    var_0 = a_i_x_hardware_0.get_dmi_facts()



# Generated at 2022-06-24 21:53:49.986501
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    int_1 = -796
    a_i_x_hardware_1 = AIXHardware(int_1)
    var_1 = a_i_x_hardware_1.get_mount_facts()


# Generated at 2022-06-24 21:53:55.294666
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    """Method get_vgs_facts of class AIXHardware"""
    int_0 = -980
    a_i_x_hardware_0 = AIXHardware(int_0)
    var_0 = a_i_x_hardware_0.get_vgs_facts()

# Generated at 2022-06-24 21:57:37.174514
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    int_0 = -980
    a_i_x_hardware_0 = AIXHardware(int_0)
    var_0 = a_i_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:57:39.551767
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    int_0 = 0
    a_i_x_hardware_0 = AIXHardware(int_0)
    var_0 = a_i_x_hardware_0.populate()
    assert (var_0 == {})


# Generated at 2022-06-24 21:57:42.442792
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    int_0 = -19
    a_i_x_hardware_0 = AIXHardware(int_0)
    obj_0 = a_i_x_hardware_0.get_cpu_facts()
    assert obj_0 is not None
    assert obj_0 == {'processor': 'PowerPC_POWER8', 'processor_count': 4, 'processor_cores': 8}


# Generated at 2022-06-24 21:57:46.535952
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    int_0 = -276
    a_i_x_hardware_0 = AIXHardware(int_0)
    var_0 = a_i_x_hardware_0.populate()
    assert var_0 is not False


# Generated at 2022-06-24 21:57:49.474750
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    int_0 = -980
    a_i_x_hardware_0 = AIXHardware(int_0)
    var_0 = a_i_x_hardware_0.get_device_facts()


# Generated at 2022-06-24 21:57:52.165067
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    int_0 = -993
    a_i_x_hardware_0 = AIXHardware(int_0)
    var_0 = a_i_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:57:53.671564
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    # get_mount_facts() doesn't return anything
    # We can't test this method
    pass


# Generated at 2022-06-24 21:57:54.469654
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    assert True



# Generated at 2022-06-24 21:58:01.661193
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    int_0 = -980
    a_i_x_hardware_0 = AIXHardware(int_0)

# Generated at 2022-06-24 21:58:04.614110
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    int_0 = -980
    a_i_x_hardware_0 = AIXHardware(int_0)
    a_i_x_hardware_0.get_device_facts()
