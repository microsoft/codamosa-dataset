

# Generated at 2022-06-24 21:48:38.921221
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    a_i_x_hardware_0 = AIXHardware()
    mount_facts = a_i_x_hardware_0.get_mount_facts()

# Generated at 2022-06-24 21:48:41.181351
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_0.populate()
    rc = a_i_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:48:47.256544
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    a_i_x_hardware_0 = AIXHardware({},{},{})
    a_i_x_hardware_0.module = {'run_command': run_command_0}
    a_i_x_hardware_0.populate_processor = {'run_command': run_command_1}
    a_i_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:48:58.881119
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_0.module.run_command = run_command
    a_i_x_hardware_0.module.run_command_environ_update = run_command_environ_update
    a_i_x_hardware_0.module.get_bin_path = get_bin_path
    cpu_facts = a_i_x_hardware_0.get_cpu_facts()
    assert type(cpu_facts['processor_count']) == int
    assert type(cpu_facts['processor_cores']) == int
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor'] == 'PowerPC_POWER8'
    assert cpu_facts['processor_cores'] == 40



# Generated at 2022-06-24 21:49:08.236850
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    fixture = [
        {
            'device': 'hdisk0',
            'attributes': {
                'device_type': 'SCSI',
                'vendor': 'IBM'
            },
            'type': 'Ethernet',
            'state': 'Available'
        },
        {
            'device': 'hdisk1',
            'attributes': {
                'device_type': 'SCSI',
                'vendor': 'IBM'
            },
            'type': 'Ethernet',
            'state': 'Available'
        }
    ]
    a_i_x_hardware_0 = AIXHardware()

    assert a_i_x_hardware_0.get_device_facts() == fixture



# Generated at 2022-06-24 21:49:14.436591
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    a_i_x_hardware = AIXHardware({'module_setup': False})

    # set up the mocked lsconf command output

# Generated at 2022-06-24 21:49:15.775967
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    a_i_x_hardware = AIXHardware()

    a_i_x_hardware.get_cpu_facts()


# Generated at 2022-06-24 21:49:23.293762
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    hardware = AIXHardware()
    hardware.module = MagicMock()
    hardware.module.run_command = MagicMock()
    hardware.module.run_command.return_value = 0, '', ''
    hardware.module.get_bin_path = MagicMock()
    hardware.module.get_bin_path.return_value = True
    assert hardware.get_dmi_facts() == {'firmware_version': '', 'product_serial': '', 'lpar_info': '', 'product_name': ''}


# Generated at 2022-06-24 21:49:27.402157
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    result = AIXHardware.get_memory_facts()
    assert not result.get('memtotal_mb')
    assert not result.get('memfree_mb')
    assert not result.get('swaptotal_mb')
    assert not result.get('swapfree_mb')


# Generated at 2022-06-24 21:49:32.150178
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    a_i_x_hardware = AIXHardware()
    assert a_i_x_hardware.get_dmi_facts() == {'firmware_version': 'IBM,i5/OS V7R1M0', 'product_serial': '5000005F5CABA507', 'lpar_info': '1 WPAR(S)', 'product_name': 'IBM,901113'}


# Generated at 2022-06-24 21:50:09.841766
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_0 = AIXHardwareCollector()



# Generated at 2022-06-24 21:50:12.131606
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    a_i_x_hardware_0 = AIXHardware()
    assert isinstance(a_i_x_hardware_0.get_device_facts(), dict)


# Generated at 2022-06-24 21:50:13.444875
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    a_i_x_hardware_0 = AIXHardware({})


# Generated at 2022-06-24 21:50:16.637392
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    a_i_x_hardware_0 = AIXHardware()
    mount_facts = a_i_x_hardware_0.get_mount_facts()
    assert mount_facts is not None

# Generated at 2022-06-24 21:50:19.747137
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    a_i_x_hardware_0 = AIXHardware(
        module_executor=None
    )

    a_i_x_hardware_0.populate()


# Generated at 2022-06-24 21:50:24.073871
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    a_i_x_hardware_1 = AIXHardware()

    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_0.populate()


# Generated at 2022-06-24 21:50:35.193291
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    cmd_stdout_0, cmd_stderr_0 = """IBM,8233-E8B1
""", ""
    cmd_stdout_1, cmd_stderr_1 = """IBM,8233-E8B1
""", ""

    cmd_stdout_1, cmd_stderr_1 = """IBM,8233-E8B1
""", ""
    cmd_stdout_2, cmd_stderr_2 = """IBM,8233-E8B1
""", ""

    a_i_x_hardware_0 = AIXHardware()

# Generated at 2022-06-24 21:50:39.326016
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:50:41.421500
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    AIXHardware_instance_0 = AIXHardware()
    AIXHardware_instance_0.populate()


# Generated at 2022-06-24 21:50:50.077371
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    # These values are from the facts as returned from the test system.
    processor = "PowerPC_POWER8"
    processor = "PowerPC_POWER8"
    processor_cores = "16"
    processor_count = "2"
    aix_hardware_0 = AIXHardware()
    aix_hardware_0.get_cpu_facts()

    rc, out, err = aix_hardware_0.module.run_command("/usr/sbin/lsdev -Cc processor")
    if out:
        i = 0
        for line in out.splitlines():

            if 'Available' in line:
                if i == 0:
                    data = line.split(' ')
                    cpudev = data[0]

                i += 1

# Generated at 2022-06-24 21:51:32.224781
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    a_i_x_hardware_0 = AIXHardware()
    CPU_FACTS = {'processor': ['PowerPC_POWER7'], 'processor_cores': 2, 'processor_count': 4}
    assert a_i_x_hardware_0.get_cpu_facts() == CPU_FACTS


# Generated at 2022-06-24 21:51:36.011689
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    print("In test_AIXHardwareCollector")
    a_i_x_hardware_collector_0 = AIXHardwareCollector()
    assert type(a_i_x_hardware_collector_0) == AIXHardwareCollector


# Generated at 2022-06-24 21:51:46.124829
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector = AIXHardwareCollector()
    assert isinstance(a_i_x_hardware_collector, AIXHardwareCollector)
    assert hasattr(a_i_x_hardware_collector, '_platform')
    assert hasattr(a_i_x_hardware_collector, '_fact_class')
    assert a_i_x_hardware_collector._platform == 'AIX'
    assert a_i_x_hardware_collector._fact_class == AIXHardware

# Test Cases for class AIXHardware
# Test case for instance attributes of class AIXHardware

# Generated at 2022-06-24 21:51:48.090849
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    a_i_x_hardware_0 = AIXHardware()
    assert a_i_x_hardware_0.get_device_facts() is None


# Generated at 2022-06-24 21:51:50.208642
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    data = {"memtotal_mb": "unknown", "memfree_mb": "unknown"}
    assert data == AIXHardware().get_memory_facts()


# Generated at 2022-06-24 21:52:01.597276
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    device_facts = {}
    device_facts['devices'] = {}

    lsdev_cmd = module.get_bin_path('lsdev', True)
    lsattr_cmd = module.get_bin_path('lsattr', True)
    rc, out_lsdev, err = module.run_command(lsdev_cmd)

    for line in out_lsdev.splitlines():
        field = line.split()

        device_attrs = {}
        device_name = field[0]
        device_state = field[1]
        device_type = field[2:]
        lsattr_cmd_args = [lsattr_cmd, '-E', '-l', device_name]
        rc, out_lsattr, err = module.run_command(lsattr_cmd_args)

# Generated at 2022-06-24 21:52:07.851268
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    print("test_AIXHardware_get_vgs_facts")
    print("================================")
    _ai_x_hardware_0_instance = AIXHardware()
    out = _ai_x_hardware_0_instance.get_vgs_facts()
    print("vg facts :" + str(out))


# Generated at 2022-06-24 21:52:08.486245
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
  pass

# Generated at 2022-06-24 21:52:12.205026
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    #
    # Create an instance of AIXHardware
    #
    a_i_x_hardware_0 = AIXHardware()

    #
    # Assertion that population of 'a_i_x_hardware_0' succeeds
    #
    assert a_i_x_hardware_0.populate() is None



# Generated at 2022-06-24 21:52:15.460593
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    a_i_x_hardware = AIXHardware()
    a_i_x_hardware_get_device_facts_0 = a_i_x_hardware.get_device_facts()


# Generated at 2022-06-24 21:53:01.665772
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    list_0 = []
    a_i_x_hardware_0 = AIXHardware(list_0)
    var_0 = a_i_x_hardware_0.get_mount_facts()


# Generated at 2022-06-24 21:53:04.493367
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    list_0 = []
    a_i_x_hardware_0 = AIXHardware(list_0)
    var_0 = a_i_x_hardware_0.populate()

# Generated at 2022-06-24 21:53:07.416574
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts.hardware.aix import test_case_0
    test_case_0()


# Generated at 2022-06-24 21:53:15.372554
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    lsdev_cmd = "/usr/sbin/lsdev"
    lsattr_cmd = "/usr/sbin/lsattr"

# Generated at 2022-06-24 21:53:23.413386
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    list_0 = []
    a_i_x_hardware_0 = AIXHardware(list_0)
    a_i_x_hardware_0.module = ansible.module_utils.facts.hardware.aix.get_bin_path()
    var_1 = a_i_x_hardware_0.get_vgs_facts()
    try:
        assert var_1 == {}, 'AssertionError: {} != {}'.format(var_1, {})
    except AssertionError:
        ansible.module_utils.facts.hardware.aix.AnsibleTestError()


# Generated at 2022-06-24 21:53:27.183383
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    list_0 = []
    a_i_x_hardware_0 = AIXHardware(list_0)
    var_0 = a_i_x_hardware_0.get_device_facts()


# Generated at 2022-06-24 21:53:29.880494
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    list_0 = []
    a_i_x_hardware_0 = AIXHardware(list_0)
    var_0 = a_i_x_hardware_0.get_mount_facts()

# Generated at 2022-06-24 21:53:33.184694
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    list_0 = []
    a_i_x_hardware_0 = AIXHardware(list_0)
    var_0 = a_i_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:53:37.409757
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    list_0 = [1, 1, 1, 1, 1]
    a_i_x_hardware_1 = AIXHardware(list_0)
    a_i_x_hardware_0 = AIXHardware(list_0)
    var_0 = a_i_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:53:40.662517
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    list_0 = []
    a_i_x_hardware_0 = AIXHardware(list_0)
    var_0 = a_i_x_hardware_0.populate(None)
    assert var_0 == {}

# Generated at 2022-06-24 21:55:50.243731
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    list_0 = []
    a_i_x_hardware_0 = AIXHardware(list_0)
    result = a_i_x_hardware_0.get_vgs_facts()
    assert isinstance(result, dict)


# Generated at 2022-06-24 21:55:53.766179
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    list_0 = []
    a_i_x_hardware_0 = AIXHardware(list_0)
    var_0 = a_i_x_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 21:55:57.215819
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    list_0 = []
    a_i_x_hardware_0 = AIXHardware(list_0)
    var_0 = a_i_x_hardware_0.get_vgs_facts()

# Generated at 2022-06-24 21:56:00.797066
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_0 = AIXHardwareCollector()
    assert a_i_x_hardware_collector_0._fact_class == AIXHardware
    assert a_i_x_hardware_collector_0._platform == 'AIX'
    assert a_i_x_hardware_collector_0._requirements == []

# Generated at 2022-06-24 21:56:03.190075
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    list_0 = []
    a_i_x_hardware_0 = AIXHardware(list_0)
    var_0 = a_i_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:56:07.417897
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    list_1 = []
    a_i_x_hardware_1 = AIXHardware(list_1)
    var_1 = a_i_x_hardware_1.get_device_facts()


# Generated at 2022-06-24 21:56:12.294479
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    list_0 = []
    a_i_x_hardware_0 = AIXHardware(list_0)
    var_0 = a_i_x_hardware_0.get_memory_facts()



# Generated at 2022-06-24 21:56:15.812220
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    """
    Unit test for method get_memory_facts of class AIXHardware

    Returns: 
    var_0 -- An instance of a class that is memory facts

    """
    list_0 = []
    a_i_x_hardware_0 = AIXHardware(list_0)
    var_0 = a_i_x_hardware_0.get_memory_facts()

# Generated at 2022-06-24 21:56:18.880842
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    # Test case data
    list_0 = []
    a_i_x_hardware_0 = AIXHardware(list_0)
    var_0 = a_i_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:56:22.677374
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    list_0 = []
    a_i_x_hardware_0 = AIXHardware(list_0)
    var_0 = a_i_x_hardware_0.get_cpu_facts()
