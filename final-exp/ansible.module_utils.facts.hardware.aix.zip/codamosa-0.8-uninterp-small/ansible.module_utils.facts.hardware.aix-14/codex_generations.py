

# Generated at 2022-06-24 21:48:33.340523
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    a_i_x_hardware_0 = AIXHardware()
    memory_facts_0 = a_i_x_hardware_0.get_memory_facts()
    assert memory_facts_0 == {}

# Generated at 2022-06-24 21:48:44.028624
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    a_i_x_hardware = AIXHardware(dict())
    a_i_x_hardware.module.run_command = MagicMock(return_value=(0, 'IBM,1.2.3', ''))
    a_i_x_hardware.lsconf_path = '/usr/sbin/lsconf'
    a_i_x_hardware.module.get_bin_path = MagicMock(return_value='/usr/sbin/lsconf')
    a_i_x_hardware.cmd0_rc = 0

# Generated at 2022-06-24 21:48:53.708962
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    a_i_x_hardware_collector_0 = AIXHardwareCollector()
    # Testing if exception raised by AIXHardware.get_dmi_facts() is caught
    # by the call to AIXHardwareCollector.collect()
    # Get facts for class AIXHardware

    # Creating object instance of class AIXHardware
    a_i_x_hardware_0 = AIXHardware({}, {})

    # Creating an instance of a dummy subprocess.Popen object
    class dummy_Popen:
        # Assigning values to instance attributes
        args = None
        returncode = None

        # Attribute 'communicate' of a class needs to be redefined
        def communicate(self):
            return ('', '')
    # The created instance of dummy_Popen is assigned to attribute 'module'
    # of object 'a_i

# Generated at 2022-06-24 21:48:56.307174
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    a_i_x_hardware = AIXHardware(None)
    assert a_i_x_hardware.get_device_facts() is None

# Generated at 2022-06-24 21:49:02.222194
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_0 = AIXHardwareCollector()
    if isinstance(a_i_x_hardware_collector_0, object):
        assert True
    else:
        assert False


# Generated at 2022-06-24 21:49:06.207048
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    # tester's comment: what is this supposed to test?
    hardware = AIXHardware()
    hardware.module = ansible.module_utils.facts.hardware.base.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    hardware.module.run_command = lambda args, check_rc=True, close_fds=True, executable=None, data=None: (0, '', '')

    hardware.module.get_bin_path = lambda s: "/bin/%s" % (s)

    hardware.get_vgs_facts()


# Generated at 2022-06-24 21:49:11.100291
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    test_AIXHardware = AIXHardware()

# Generated at 2022-06-24 21:49:13.073399
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_0.populate()


# Generated at 2022-06-24 21:49:22.075998
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    AIXHardware_obj = AIXHardware()
    AIXHardware_obj.module.run_command = lambda x, **kwargs: (0, 'Available 00-00 Processor 00-00\nAvailable 00-01 Processor 00-01', '')
    AIXHardware_obj.module.run_command = lambda x, **kwargs: (0, 'Processor_Card POWER8', '')
    AIXHardware_obj.module.run_command = lambda x, **kwargs: (0, 'smt_threads 1', '')
    AIXHardware_obj.get_cpu_facts()


# Generated at 2022-06-24 21:49:24.563639
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_0.module = AnsibleModule
    a_i_x_hardware_0.populate()



# Generated at 2022-06-24 21:49:46.150623
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    # Checks for HardwareCollector class type
    assert isinstance(AIXHardwareCollector, HardwareCollector) == True

# Generated at 2022-06-24 21:49:47.612213
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    test_case_0()

if __name__ == '__main__':
    test_AIXHardwareCollector()

# Generated at 2022-06-24 21:49:48.418727
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    pass


# Generated at 2022-06-24 21:49:50.732457
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    a_i_x_hardware_0 = AIXHardware()
    assert a_i_x_hardware_0.get_device_facts() == {}

# Generated at 2022-06-24 21:50:02.729128
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_0.populate()

    expected_memtotal_mb = None
    expected_memfree_mb = None
    expected_swaptotal_mb = None
    expected_swapfree_mb = None

    assert (a_i_x_hardware_0.memtotal_mb == expected_memtotal_mb)
    assert (a_i_x_hardware_0.memfree_mb == expected_memfree_mb)
    assert (a_i_x_hardware_0.swaptotal_mb == expected_swaptotal_mb)
    assert (a_i_x_hardware_0.swapfree_mb == expected_swapfree_mb)


# Generated at 2022-06-24 21:50:07.658597
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    # Setup test case
    a_i_x_hardware = AIXHardware()

    # Call the method
    get_device_facts_return = a_i_x_hardware.get_device_facts()

    # Assert result
    assert len(get_device_facts_return) == 1
    assert len(get_device_facts_return['devices']) > 0
    assert set(get_device_facts_return.keys()) == set(['devices'])


# Generated at 2022-06-24 21:50:08.820308
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_1 = AIXHardwareCollector()



# Generated at 2022-06-24 21:50:13.734973
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_0.module = Mock()
    a_i_x_hardware_0.module.run_command = Mock()
    a_i_x_hardware_0.module.run_command.return_value = (0, '', '')
    a_i_x_hardware_0.module.get_bin_path = Mock(return_value='/bin/lsdev -Cc processor')
    collected_facts = None

# Generated at 2022-06-24 21:50:16.472065
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    a_i_x_hardware_0 = AIXHardware()
    assert a_i_x_hardware_0.get_vgs_facts() == {}


# Generated at 2022-06-24 21:50:27.912705
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    hardware_instance_0 = AIXHardware()
    hardware_instance_0.module = MagicMock()
    hardware_instance_0.module.get_bin_path.return_value = '/usr/bin/lsvg'

# Generated at 2022-06-24 21:50:49.813722
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    set_0 = {'lsvg', 'xargs'}
    a_i_x_hardware_0 = AIXHardware(set_0)
    result = a_i_x_hardware_0.get_vgs_facts()
    assert result[0] == 0
    assert result[1] == ''
    assert result[2] == ''

# Generated at 2022-06-24 21:50:54.599338
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    set_0 = {False, False, False}
    a_i_x_hardware_0 = AIXHardware(set_0)
    a_i_x_hardware_0.populate()


# Generated at 2022-06-24 21:51:00.753166
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    case_0 = {'bin_path': {'lsdev': '/usr/sbin/lsdev', 'lsattr': '/usr/sbin/lsattr'}, 'run_command': {0: (0, 'hdisk0 Available Virtual SCSI Disk Drive', '')}}
    a_i_x_hardware_0 = AIXHardware(case_0)
    var_0 = a_i_x_hardware_0.get_device_facts()
    assert var_0 == {'devices': {'hdisk0': {'state': 'Available', 'type': 'Virtual SCSI Disk Drive', 'attributes': {}}}}


# Generated at 2022-06-24 21:51:04.071432
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_0.populate()


# To run all the tests:
# Run this module alone with command `python -m test_hardware_aix`
#   or `python -m test_hardware_aix <test_case_functional_name>`

# Generated at 2022-06-24 21:51:04.917318
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    assert set_0 == set_0


# Generated at 2022-06-24 21:51:07.656217
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    set_0 = {''}
    a_i_x_hardware_0 = AIXHardware(set_0)
    var_0 = a_i_x_hardware_0.populate()


# Generated at 2022-06-24 21:51:09.548420
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    a_i_x_hardware_0 = AIXHardware(set())
    var_0 = a_i_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:51:10.635667
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    assert AIXHardware.get_cpu_facts('self') == 'TODO'


# Generated at 2022-06-24 21:51:16.135958
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    print('TEST METHOD get_vgs_facts')
    bool_0 = False
    set_0 = {bool_0, bool_0, bool_0}
    a_i_x_hardware_0 = AIXHardware(set_0)
    var_0 = a_i_x_hardware_0.get_vgs_facts()
    assert isinstance(var_0, dict)



# Generated at 2022-06-24 21:51:20.285277
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    # Test case for method get_mount_facts of class AIXHardware
    bool_0 = False
    set_0 = {bool_0, bool_0, bool_0}
    a_i_x_hardware_0 = AIXHardware(set_0)
    var_0 = a_i_x_hardware_0.get_mount_facts()


# Generated at 2022-06-24 21:51:58.340063
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    bool_0 = False
    set_0 = {bool_0, bool_0, bool_0}
    a_i_x_hardware_0 = AIXHardware(set_0)
    var_0 = a_i_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:52:10.979349
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    out_lsdev_test_data = "hdisk0 Available Virtual SCSI Disk Drive\nhdisk1 Available Virtual SCSI Disk Drive\nhdisk2 Available Virtual SCSI Disk Drive\nfcs0 Available FC Adapter\nfcs1 Available FC Adapter\nfscsi0 Available FC SCSI I/O Controller\nfscsi1 Available FC SCSI I/O Controller\nrmt0 Available Virtual Tape\nrmt1 Available Virtual Tape\n"

# Generated at 2022-06-24 21:52:14.157838
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    bool_0 = False
    set_0 = {bool_0, bool_0, bool_0}
    a_i_x_hardware_0 = AIXHardware(set_0)
    var_0 = a_i_x_hardware_0.get_cpu_facts()
    assert isinstance(var_0, dict) == True


# Generated at 2022-06-24 21:52:23.532649
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    bool_0 = False
    set_0 = {bool_0, bool_0, bool_0}
    a_i_x_hardware_0 = AIXHardware(set_0)
    var_0 = a_i_x_hardware_0.get_memory_facts()
    assert var_0['memtotal_mb'].__class__ == int
    assert var_0['memfree_mb'].__class__ == int
    assert var_0['swaptotal_mb'].__class__ == int
    assert var_0['swapfree_mb'].__class__ == int


# Generated at 2022-06-24 21:52:27.060390
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    # Test with parameters:
    bool_0 = False
    set_0 = {bool_0, bool_0, bool_0}

    a_i_x_hardware_0 = AIXHardware(set_0)
    var_0 = a_i_x_hardware_0.populate()


# Generated at 2022-06-24 21:52:29.676671
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    bool_0 = False
    set_0 = {bool_0, bool_0, bool_0}
    a_i_x_hardware_0 = AIXHardware(set_0)
    var_0 = a_i_x_hardware_0.get_vgs_facts()


# Generated at 2022-06-24 21:52:39.382727
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    mount_facts = {}
    mount_facts['mounts'] = []

    mounts = []

    # AIX does not have mtab but mount command is only source of info (or to use
    # api calls to get same info)
    mount_path = '/usr/bin/mount'
    rc, mount_out, err = module.run_command(mount_path)
    if mount_out:
        for line in mount_out.split('\n'):
            fields = line.split()

# Generated at 2022-06-24 21:52:43.288481
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    _platform = 'AIX'
    _fact_class = AIXHardware

    a_i_x_hardware_collector_0 = AIXHardwareCollector(_platform, _fact_class)
    assert isinstance(a_i_x_hardware_collector_0, AIXHardwareCollector)

# Generated at 2022-06-24 21:52:48.310610
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    set_0 = {'AIXHardware', 'AIXHardware.get_cpu_facts()', 'AIXHardware.get_cpu_facts()'}
    a_i_x_hardware_0 = AIXHardware(set_0)
    assert a_i_x_hardware_0.get_device_facts() is None


# Generated at 2022-06-24 21:52:52.948713
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    bool_0 = False
    set_0 = {bool_0, bool_0, bool_0}
    a_i_x_hardware_0 = AIXHardware(set_0)
    var_0 = a_i_x_hardware_0.get_vgs_facts()


# Generated at 2022-06-24 21:54:27.225466
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    bool_0 = False
    set_0 = {bool_0, bool_0, bool_0}
    a_i_x_hardware_0 = AIXHardware(set_0)
    var_0 = a_i_x_hardware_0.populate()

# Generated at 2022-06-24 21:54:31.457233
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    set_0 = set({''})
    a_i_x_hardware_0 = AIXHardware(set_0)
    var_0 = a_i_x_hardware_0.get_cpu_facts()
    assert var_0 == None


# Generated at 2022-06-24 21:54:34.796428
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    bool_0 = False
    set_0 = {bool_0, bool_0, bool_0}
    a_i_x_hardware_0 = AIXHardware(set_0)
    var_0 = a_i_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:54:36.564172
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    set_0 = {False, False, False}
    a_i_x_hardware_0 = AIXHardware(set_0)
    var_0 = a_i_x_hardware_0.get_vgs_facts()


# Generated at 2022-06-24 21:54:39.576335
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    regex_0 = re.compile('\w')
    regex_1 = re.compile('\w')
    set_0 = {regex_0, regex_1}
    a_i_x_hardware_0 = AIXHardware(set_0)
    a_i_x_hardware_0.populate()


# Generated at 2022-06-24 21:54:40.753469
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    # Constructor Test
    assert isinstance(AIXHardwareCollector(), AIXHardwareCollector)

# Generated at 2022-06-24 21:54:48.139346
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    bool_0 = False
    set_0 = {bool_0, bool_0, bool_0}
    a_i_x_hardware_0 = AIXHardware(set_0)

    # Test with an sys.executable that is valid and supports -p option
    xargs_path = a_i_x_hardware_0.module.get_bin_path('xargs', True)
    assert xargs_path is not None
    lsvg_path = a_i_x_hardware_0.module.get_bin_path('lsvg', True)
    assert lsvg_path is not None

    # Test with a mtab that contains information about a vg
    cmd = "%s -o | %s %s -p" % (lsvg_path, xargs_path, lsvg_path)
   

# Generated at 2022-06-24 21:54:51.411097
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    bool_0 = False
    set_0 = {bool_0, bool_0, bool_0}
    a_i_x_hardware_collector_0 = AIXHardwareCollector(set_0)
    var_0 = a_i_x_hardware_collector_0.get_vgs_facts()

# Generated at 2022-06-24 21:55:00.305651
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    bool_0 = False
    set_0 = {bool_0, bool_0, bool_0}
    a_i_x_hardware_0 = AIXHardware(set_0)
    var_0 = a_i_x_hardware_0.get_vgs_facts()
    num_0 = 1000
    num_1 = 1
    num_2 = 2
    num_3 = 3
    num_4 = 4
    num_5 = 5
    num_6 = 6
    num_7 = 7
    num_8 = 8
    num_9 = 9

# Generated at 2022-06-24 21:55:02.182693
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_0 = AIXHardwareCollector()
    assert a_i_x_hardware_collector_0
