

# Generated at 2022-06-24 21:48:40.478231
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    bytes_0 = None
    a_i_x_hardware_0 = AIXHardware(bytes_0)

    rc, out, err = a_i_x_hardware_0.module.run_command("/usr/sbin/lsdev -Cc processor")

    # /usr/sbin/lsdev -Cc processor exit code is different on AIX 7.1 and AIX 7.2:
    # 0 on AIX 7.1
    # 8 on AIX 7.2
    if out:
        cpu_facts = {}
        cpu_facts['processor'] = []

        i = 0
        for line in out.splitlines():

            if 'Available' in line:
                if i == 0:
                    data = line.split(' ')
                    cpudev = data[0]

                i += 1
        cpu_

# Generated at 2022-06-24 21:48:44.328903
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    bytes_0 = None
    a_i_x_hardware_0 = AIXHardware(bytes_0)

    collected_facts_0 = dict()
    print(a_i_x_hardware_0.populate(collected_facts_0))


# Generated at 2022-06-24 21:48:46.982302
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    bytes_1 = None
    a_i_x_hardware_collector_0 = AIXHardwareCollector(bytes_1)


# Generated at 2022-06-24 21:48:50.228907
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    bytes_0 = None
    a_i_x_hardware_0 = AIXHardware(bytes_0)
    if not a_i_x_hardware_0.get_memory_facts():
        print('None')
    

# Generated at 2022-06-24 21:48:52.687397
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    bytes_0 = None
    a_i_x_hardware_0 = AIXHardware(bytes_0)

    a_i_x_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 21:48:58.885991
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    os_distribution_0 = None
    lsphymem_path_0 = ''
    part_size_0 = None
    lsattr_path_0 = ''
    a_i_x_hardware_0 = AIXHardware(os_distribution_0)
    arg = None
    ref_0 = {}
    ref_1 = {}
    a_i_x_hardware_0.cpu = ref_0
    a_i_x_hardware_0.module = ref_1
    a_i_x_hardware_0.get_cpu_facts(arg)


# Generated at 2022-06-24 21:49:01.811199
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    bytes_0 = b''
    a_i_x_hardware_collector_0 = AIXHardwareCollector(bytes_0)



# Generated at 2022-06-24 21:49:06.493562
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    bytes_0 = None
    a_i_x_hardware_0 = AIXHardware(bytes_0)
    pattern = re.compile(r'(sbin|usr)', re.IGNORECASE | re.DOTALL)
    assert re.search(pattern, a_i_x_hardware_0.get_cpu_facts())


# Generated at 2022-06-24 21:49:13.072668
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
  bytes_0 = None
  a_i_x_hardware_0 = AIXHardware(bytes_0)
  a_i_x_hardware_0.module = ansible_module_0
  a_i_x_hardware_0.get_mount_facts()

# Generated at 2022-06-24 21:49:15.105590
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    bytes_0 = None
    a_i_x_hardware_0 = AIXHardware(bytes_0)
    w_0 = a_i_x_hardware_0.get_mount_facts()



# Generated at 2022-06-24 21:49:34.784621
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    obj = AIXHardwareCollector()
    assert obj.test_AIXHardware().get_memory_facts() == 'test_memory_facts'


# Generated at 2022-06-24 21:49:46.028873
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    out = '''
Available
Available
Available
Available
Available
Available
Available
Available
Available
Available
Available
Available
Available
Available
Available
Available
Available
Available
Available
Available
Available
Available
Available
Available
Available
Available
Available
Available
Available
Available
Available
Available
Available
Available
Available
Available
Available
Available
Available
Available
Available
Available
Available
Available
Available
Available
Available
Available
Available
Available
Available
Available
    '''

    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_0.module = MagicMock()
    a_i_x_hardware_0.module.run_command.return_value = (0, out, '')
    a_i_x_hardware_0.populate()

# Unit

# Generated at 2022-06-24 21:49:50.580943
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module_0 = AnsibleModule(argument_spec={}, supports_check_mode=False)
    a_i_x_hardware_0 = AIXHardware(module_0)
    a_i_x_hardware_0.populate()
    return a_i_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:50:02.390897
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    a_i_x_hardware = AIXHardware({})
    rc, out, err = a_i_x_hardware.module.run_command("/usr/sbin/lsdev -Cc disk")
    assert(rc == 0)
    assert('hdisk0' in out)
    lsdev_fd = a_i_x_hardware.module.get_bin_path('lsdev', True)
    lsattr_fd = a_i_x_hardware.module.get_bin_path('lsattr', True)
    assert(lsdev_fd)
    assert(lsattr_fd)
    devices = a_i_x_hardware.get_device_facts()
    for device in devices['devices'].keys():
        assert(device in out)


# Generated at 2022-06-24 21:50:06.540837
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    a_i_x_hardware = AIXHardware()
    memory_facts = a_i_x_hardware.get_memory_facts()
    if len(memory_facts) == 0:
        assert False


# Generated at 2022-06-24 21:50:11.951802
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    a_i_x_hardware_0 = AIXHardware()

    assert a_i_x_hardware_0.get_memory_facts() == {'memfree_mb': 7, 'memtotal_mb': 7, 'swapfree_mb': 6, 'swaptotal_mb': 6}


# Generated at 2022-06-24 21:50:16.250823
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    a_i_x_hardware_0 = AIXHardware()
    cpu_facts = a_i_x_hardware_0.get_cpu_facts()
    assert cpu_facts['processor']
    assert cpu_facts['processor_cores']
    assert cpu_facts['processor_count']


# Generated at 2022-06-24 21:50:19.315689
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    a_i_x_hardware_0 = AIXHardware()
    cpu_facts_0 = a_i_x_hardware_0.get_cpu_facts()

# Test of class AIXHardware

# Generated at 2022-06-24 21:50:29.567123
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    a_i_x_hardware_0 = AIXHardware()
    rc, out, err = a_i_x_hardware_0.module.run_command('/usr/bin/cat ./test_data/lsvg')
    vgs_facts = a_i_x_hardware_0.get_vgs_facts()
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs_facts['vgs']['realsyncvg'][0]['pv_name'] == 'hdisk74'
    assert vgs_facts['vgs']['testvg'][0]['pv_name'] == 'hdisk105'

# Generated at 2022-06-24 21:50:31.343419
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_test_case_0 = AIXHardwareCollector()


# Generated at 2022-06-24 21:50:54.911115
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    a_i_x_hardware_0 = AIXHardware()
    collected_facts = None
    a_i_x_hardware_0.populate(collected_facts)


# Generated at 2022-06-24 21:50:58.012045
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    a_i_x_hardware_0 = AIXHardware()
    assert a_i_x_hardware_0.get_cpu_facts() == {'processor_cores': 4, 'processor': 'PowerPC_POWER8', 'processor_count': 4}


# Generated at 2022-06-24 21:51:00.320123
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_0 = AIXHardwareCollector()
    assert a_i_x_hardware_collector_0._fact_class == AIXHardware


# Generated at 2022-06-24 21:51:06.461303
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    HW = AIXHardware()
    hardware_facts = HW.populate()
    mount_facts = hardware_facts['mounts']
    assert mount_facts[0]['device'] == '/dev/hd4'
    assert mount_facts[0]['mount'] == '/'
    assert mount_facts[0]['fstype'] == 'jfs2'
    assert mount_facts[0]['options'] == 'rw'
    assert mount_facts[0]['size_available'] > 0
    assert mount_facts[0]['size_total'] > 0
    assert mount_facts[0]['size_used'] > 0
    assert mount_facts[1]['device'] == '/dev/hd2'
    assert mount_facts[1]['mount'] == '/usr'

# Generated at 2022-06-24 21:51:13.843009
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    a_i_x_hardware_0 = AIXHardware()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()


# Generated at 2022-06-24 21:51:22.057156
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    # Setup test data
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_0._module = AnsibleModule(argument_spec=dict())
    a_i_x_hardware_0._module.run_command = mock.Mock(return_value=(0, '8M-blocks\nlda0 Available 04-08-00                Logical Disk Adapter\nlsattr -El lda0 -a avail_prio -a restore_prio -a adapter_names -a blksize -a device_type\n', ''))

    # Invoke method
    response = a_i_x_hardware_0.get_device_facts()

# Generated at 2022-06-24 21:51:24.170896
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_0 = AIXHardwareCollector()


# Generated at 2022-06-24 21:51:30.489356
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    a_i_x_hardware_0 = AIXHardware()
    memory_facts = a_i_x_hardware_0.get_memory_facts()
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0


# Generated at 2022-06-24 21:51:43.112908
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    a_i_x_hardware_0 = AIXHardware()

    # Test case - AnsibleModule import
    from ansible.module_utils.facts import hardware as hardware_module
    hardware_module.ANSIBLE_MODULE_UTILS = {'ansible_module': 'AnsibleModule'}
    # Test case - module_utils import
    hardware_module.MODULE_UTILS_PATH = {'ansible.module_utils.basic': 'basic'}

    # Test case - all return default values
    rc, out, err, tmp = a_i_x_hardware_0.get_vgs_facts()
    assert rc == 0
    assert out == {'vgs': {}}

    # Test case - normal

    # Test case - all return default values
    rc, out, err, tmp = a_i_x

# Generated at 2022-06-24 21:51:45.582172
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    a_i_x_hardware_0 = AIXHardware()
    assert isinstance(a_i_x_hardware_0.get_mount_facts(), dict)


# Generated at 2022-06-24 21:52:24.306678
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    a_i_x_hardware = AIXHardware()
    cpu_facts = a_i_x_hardware.get_cpu_facts()
    assert cpu_facts['processor_cores'] == 4
    assert cpu_facts['processor_count'] == 1


# Generated at 2022-06-24 21:52:31.225725
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    hardware_obj = AIXHardware()

# Generated at 2022-06-24 21:52:39.889028
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    test_a_i_x_hardware_populate = AIXHardware(module=None)

# Generated at 2022-06-24 21:52:50.946594
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    lsdev_cmd = '/usr/sbin/lsdev'
    lsattr_cmd = '/usr/sbin/lsattr'
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_0.module.get_bin_path = MagicMock(return_value='/usr/sbin/lsdev')
    a_i_x_hardware_0.module.run_command = MagicMock(return_value=(0, 'fcs0        Available 23-08-00  Fibre Channel I/O Card\n', ''))
    a_i_x_hardware_0.module.get_bin_path = MagicMock(return_value='/usr/sbin/lsattr')
    a_i_x_hardware_0.module.run_command = MagicMock

# Generated at 2022-06-24 21:52:52.318450
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_0 = AIXHardware()


# Generated at 2022-06-24 21:52:54.496963
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    a = AIXHardware()
    a.module = AnsibleModule(
        argument_spec = dict()
    )
    a.get_cpu_facts()


# Generated at 2022-06-24 21:52:56.685445
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    a_i_x_hardware_collector_0 = AIXHardwareCollector()
    assert a_i_x_hardware_collector_0.platform == 'AIX'

# Generated at 2022-06-24 21:52:59.602422
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    f_a_i_x_hardware = AIXHardware()
    mount_facts = f_a_i_x_hardware.get_mount_facts()

    assert len(mount_facts) == 1
    assert type(mount_facts['mounts']) == list



# Generated at 2022-06-24 21:53:02.712428
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    a_i_x_hardware_0 = AIXHardware()
    assert isinstance(a_i_x_hardware_0.get_dmi_facts(), dict) is True


# Generated at 2022-06-24 21:53:04.493911
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    assert a_i_x_hardware_collector_0.get_facts() == {}


# Generated at 2022-06-24 21:54:36.133356
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    a_i_x_hardware_0 = AIXHardware()
    result = a_i_x_hardware_0.get_device_facts()

    assert result == {'devices': {}}


# Generated at 2022-06-24 21:54:37.639888
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    a_i_x_hardware_0 = AIXHardware()
    collected_facts = {}
    assert a_i_x_hardware_0.populate(collected_facts)


# Generated at 2022-06-24 21:54:40.752572
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    hw = AIXHardware()
    hw.module = None
    hw.module.run_command = hw.run_command
    expected_dict = {'processor_count': 1,  'processor': ['PowerPC_POWER8'], 'processor_cores': 4}
    assert hw.get_cpu_facts() == expected_dict


# Generated at 2022-06-24 21:54:48.138588
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():

    hw_facts = AIXHardware()
    vgs_facts = hw_facts.get_vgs_facts()


# Generated at 2022-06-24 21:54:49.522572
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    hardware = AIXHardware()

    hardware_vgs_facts_0 = hardware.get_vgs_facts()
    assert hardware_vgs_facts_0.get('vgs') == {}


# Generated at 2022-06-24 21:54:52.555319
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    hardware_instance = AIXHardware()
    rc, out, err = hardware_instance.module.run_command("/usr/sbin/lsattr -El sys0 -a fwversion")
    assert out != None


# Generated at 2022-06-24 21:55:00.016151
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_0.module = MagicMock()
    lsconf_path = '/usr/sbin/lsconf'
    a_i_x_hardware_0.module.get_bin_path = MagicMock(return_value=lsconf_path)
    a_i_x_hardware_0.module.run_command = MagicMock(return_value=(0, 'rootvg:', None))
    vgs_facts = a_i_x_hardware_0.get_vgs_facts()
    assert vgs_facts == {}


# Generated at 2022-06-24 21:55:01.927028
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
  a_i_x_hardware_0 = AIXHardware()
  assert a_i_x_hardware_0.get_memory_facts() == {}

# Generated at 2022-06-24 21:55:04.425678
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    a_i_x_hardware_0 = AIXHardware()
    a_i_x_hardware_0.module = MagicMock()
    a_i_x_hardware_0.module.run_command.return_value = (0, '', '')

    a_i_x_hardware_0.populate()
    assert a_i_x_hardware_0.facts == {'mounts': [], 'devices': {}}


# Generated at 2022-06-24 21:55:05.704270
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    a_i_x_hardware = AIXHardware()
    assert a_i_x_hardware.get_device_facts()