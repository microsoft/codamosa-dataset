

# Generated at 2022-06-16 23:51:20.874024
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    vgs_facts = hardware.get_vgs_facts()
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs_facts['vgs']['rootvg'][0]['pv_state'] == 'active'
    assert vgs_facts['vgs']['rootvg'][0]['total_pps'] == '546'
    assert vgs_facts['vgs']['rootvg'][0]['free_pps'] == '0'
    assert vgs_facts['vgs']['rootvg'][0]['pp_size'] == '4 megabyte(s)'

# Generated at 2022-06-16 23:51:23.393728
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector._platform == 'AIX'
    assert hardware_collector._fact_class == AIXHardware


# Generated at 2022-06-16 23:51:25.903549
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hw_collector = AIXHardwareCollector()
    assert hw_collector.platform == 'AIX'
    assert hw_collector.fact_class == AIXHardware

# Generated at 2022-06-16 23:51:31.036350
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-16 23:51:35.207282
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'PowerPC_POWER8'
    assert cpu_facts['processor_cores'] == 2


# Generated at 2022-06-16 23:51:43.289394
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    vgs_facts = hardware.get_vgs_facts()
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs_facts['vgs']['rootvg'][0]['pv_state'] == 'active'
    assert vgs_facts['vgs']['rootvg'][0]['total_pps'] == '546'
    assert vgs_facts['vgs']['rootvg'][0]['free_pps'] == '0'
    assert vgs_facts['vgs']['rootvg'][0]['pp_size'] == '4 megabyte(s)'

# Generated at 2022-06-16 23:51:54.566291
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils._text import to_bytes

    aix_hardware = AIXHardware()
    aix_hardware.module.get_bin_path = lambda x: x
    aix_hardware.module.run_command = lambda x: (0, to_bytes(get_file_content('unit/ansible/module_utils/facts/hardware/aix/lsvg_output.txt')), None)
    vgs_facts = aix_hardware.get_vgs_facts()
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs

# Generated at 2022-06-16 23:51:57.582011
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector._platform == 'AIX'
    assert hardware_collector._fact_class == AIXHardware

# Generated at 2022-06-16 23:52:05.537298
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor_count'] == 2
    assert hardware_facts['processor'] == 'PowerPC_POWER8'
    assert hardware_facts['processor_cores'] == 4
    assert hardware_facts['memtotal_mb'] == 8192
    assert hardware_facts['memfree_mb'] == 8192
    assert hardware_facts['swaptotal_mb'] == 4096
    assert hardware_facts['swapfree_mb'] == 4096
    assert hardware_facts['firmware_version'] == '1.0'
    assert hardware_facts['product_serial'] == '123456789'
    assert hardware_facts['lpar_info'] == '1'

# Generated at 2022-06-16 23:52:12.275892
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-16 23:52:32.098111
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    mount_facts = hardware.get_mount_facts()
    assert mount_facts['mounts'] is not None

# Generated at 2022-06-16 23:52:37.740328
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['firmware_version'] == 'IBM,8233-E8B'
    assert dmi_facts['product_serial'] == '0123ABC'
    assert dmi_facts['lpar_info'] == '1 CEC(s)'
    assert dmi_facts['product_name'] == 'IBM,8233-E8B'


# Generated at 2022-06-16 23:52:39.540858
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hw = AIXHardwareCollector()
    assert hw.platform == 'AIX'
    assert hw.fact_class == AIXHardware

# Generated at 2022-06-16 23:52:43.579135
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    test_module = AnsibleModule(argument_spec={})
    test_module.params = {}
    test_module.run_command = MagicMock(return_value=(0, '', ''))
    test_module.get_bin_path = MagicMock(return_value=True)

# Generated at 2022-06-16 23:52:46.687576
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert 'firmware_version' in dmi_facts
    assert 'product_serial' in dmi_facts
    assert 'lpar_info' in dmi_facts
    assert 'product_name' in dmi_facts


# Generated at 2022-06-16 23:52:55.676884
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    hardware_facts = hardware.populate()

    assert hardware_facts['processor'] == ['PowerPC_POWER8']
    assert hardware_facts['processor_cores'] == 4
    assert hardware_facts['processor_count'] == 4
    assert hardware_facts['memtotal_mb'] == 16384
    assert hardware_facts['memfree_mb'] == 16384
    assert hardware_facts['swaptotal_mb'] == 0
    assert hardware_facts['swapfree_mb'] == 0
    assert hardware_facts['firmware_version'] == '1.1.1.1'
    assert hardware_facts['product_serial'] == '0123456789'
    assert hardware_facts['lpar_info'] == '1'

# Generated at 2022-06-16 23:53:01.935994
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor'] == 'PowerPC_POWER8'


# Generated at 2022-06-16 23:53:04.305192
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0


# Generated at 2022-06-16 23:53:13.700882
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    vgs_facts = hardware.get_vgs_facts()
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs_facts['vgs']['rootvg'][0]['pv_state'] == 'active'
    assert vgs_facts['vgs']['rootvg'][0]['total_pps'] == '546'
    assert vgs_facts['vgs']['rootvg'][0]['free_pps'] == '0'
    assert vgs_facts['vgs']['rootvg'][0]['pp_size'] == '4 megabyte(s)'

# Generated at 2022-06-16 23:53:18.761507
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'PowerPC_POWER8'
    assert cpu_facts['processor_cores'] == 8


# Generated at 2022-06-16 23:53:57.402925
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-16 23:54:00.956269
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector._platform == 'AIX'
    assert hardware_collector._fact_class == AIXHardware

# Generated at 2022-06-16 23:54:11.562081
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor_count'] == 2
    assert hardware_facts['processor'] == 'PowerPC_POWER8'
    assert hardware_facts['processor_cores'] == 4
    assert hardware_facts['memtotal_mb'] == 16384
    assert hardware_facts['memfree_mb'] == 16384
    assert hardware_facts['swaptotal_mb'] == 32768
    assert hardware_facts['swapfree_mb'] == 32768
    assert hardware_facts['firmware_version'] == 'IBM,8247-22L'
    assert hardware_facts['product_serial'] == '0123456789'

# Generated at 2022-06-16 23:54:13.681258
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    module = AnsibleModule(argument_spec={})
    hardware_collector = AIXHardwareCollector(module=module)
    assert hardware_collector.platform == 'AIX'
    assert hardware_collector.fact_class == AIXHardware


# Generated at 2022-06-16 23:54:15.922364
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    aix_hardware_collector = AIXHardwareCollector()
    assert aix_hardware_collector._platform == 'AIX'
    assert aix_hardware_collector._fact_class == AIXHardware

# Generated at 2022-06-16 23:54:21.179530
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'PowerPC_POWER8'
    assert cpu_facts['processor_cores'] == 4


# Generated at 2022-06-16 23:54:31.912984
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    device_facts = hardware.get_device_facts()

    assert device_facts['devices']['ent0']['state'] == 'Available'
    assert device_facts['devices']['ent0']['type'] == 'Ethernet Adapter (l-lan)'
    assert device_facts['devices']['ent0']['attributes']['mtu'] == '1500'
    assert device_facts['devices']['ent0']['attributes']['state'] == 'up'
    assert device_facts['devices']['ent0']['attributes']['tcp_mssdflt'] == '0'

# Generated at 2022-06-16 23:54:35.159596
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module=module)
    device_facts = hardware.get_device_facts()
    assert device_facts['devices'] != {}


# Generated at 2022-06-16 23:54:45.055924
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    hardware_facts = hardware.populate()

    assert hardware_facts['processor_count'] == 2
    assert hardware_facts['processor'] == 'PowerPC_POWER8'
    assert hardware_facts['processor_cores'] == 8
    assert hardware_facts['memtotal_mb'] == 8192
    assert hardware_facts['memfree_mb'] == 7897
    assert hardware_facts['swaptotal_mb'] == 0
    assert hardware_facts['swapfree_mb'] == 0
    assert hardware_facts['firmware_version'] == 'IBM,8233-E8B'
    assert hardware_facts['product_serial'] == '123456789'
    assert hardware_facts['lpar_info'] == '1'


# Generated at 2022-06-16 23:54:57.508706
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    device_facts = hardware.get_device_facts()
    assert device_facts['devices']['ent0']['state'] == 'Available'
    assert device_facts['devices']['ent0']['type'] == 'Ethernet Adapter (l-lan)'
    assert device_facts['devices']['ent0']['attributes']['bus_mem_addr'] == '0x0'
    assert device_facts['devices']['ent0']['attributes']['bus_io_addr'] == '0x0'
    assert device_facts['devices']['ent0']['attributes']['bus_dma_lvl'] == '0x0'

# Generated at 2022-06-16 23:56:23.796285
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_collector = AIXHardwareCollector(module=module)
    hardware = AIXHardware(module)
    hardware_collector.collect(hardware, module)

# Generated at 2022-06-16 23:56:32.000938
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils._text import to_bytes

    class TestModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, arg, required=False):
            return arg

        def run_command(self, cmd, use_unsafe_shell=False):
            return 0, get_file_content(to_bytes('test/unit/ansible/module_utils/facts/hardware/aix/lsvg_out.txt')), ''


# Generated at 2022-06-16 23:56:39.758719
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-16 23:56:48.694818
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    vgs_facts = hardware.get_vgs_facts()
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs_facts['vgs']['rootvg'][0]['pv_state'] == 'active'
    assert vgs_facts['vgs']['rootvg'][0]['total_pps'] == '546'
    assert vgs_facts['vgs']['rootvg'][0]['free_pps'] == '0'
    assert vgs_facts['vgs']['rootvg'][0]['pp_size'] == '4 megabyte(s)'

# Generated at 2022-06-16 23:56:55.067627
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor'] == 'PowerPC_POWER8'
    assert cpu_facts['processor_cores'] == 4


# Generated at 2022-06-16 23:57:00.046451
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'PowerPC_POWER8'
    assert cpu_facts['processor_cores'] == 4
    assert cpu_facts['processor_count'] == 2


# Generated at 2022-06-16 23:57:07.732169
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['firmware_version'] == 'IBM,8233-E8B'
    assert dmi_facts['product_serial'] == '0123ABC'
    assert dmi_facts['lpar_info'] == '1 CEC(s)'
    assert dmi_facts['product_name'] == 'IBM,8233-E8B'


# Generated at 2022-06-16 23:57:11.646907
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    """
    Test the constructor of class AIXHardwareCollector
    """
    aix_hw_collector = AIXHardwareCollector()
    assert aix_hw_collector._platform == 'AIX'
    assert aix_hw_collector._fact_class == AIXHardware

# Generated at 2022-06-16 23:57:18.115547
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert 'firmware_version' in dmi_facts
    assert 'product_serial' in dmi_facts
    assert 'lpar_info' in dmi_facts
    assert 'product_name' in dmi_facts


# Generated at 2022-06-16 23:57:21.811926
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'PowerPC_POWER8'
    assert cpu_facts['processor_cores'] == 4


# Generated at 2022-06-16 23:58:54.317878
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'PowerPC_POWER8'
    assert cpu_facts['processor_cores'] == 4


# Generated at 2022-06-16 23:58:57.392908
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    mount_facts = hardware.get_mount_facts()
    assert mount_facts['mounts']


# Generated at 2022-06-16 23:59:02.497500
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    device_facts = hardware.get_device_facts()
    assert device_facts['devices']['ent0']['state'] == 'Available'
    assert device_facts['devices']['ent0']['type'] == 'Device'
    assert device_facts['devices']['ent0']['attributes']['PdDvLn'] == 'ent/en'
    assert device_facts['devices']['ent0']['attributes']['netaddr'] == '00:00:00:00:00:00'
    assert device_facts['devices']['ent0']['attributes']['netaddr_set'] == 'yes'

# Generated at 2022-06-16 23:59:11.834802
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['firmware_version'] == 'IBM,8233-E8B'
    assert dmi_facts['product_serial'] == '0123456789'
    assert dmi_facts['lpar_info'] == '1 CEC(s)'
    assert dmi_facts['product_name'] == 'IBM,8233-E8B'


# Generated at 2022-06-16 23:59:18.470313
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['firmware_version']
    assert dmi_facts['product_serial']
    assert dmi_facts['lpar_info']
    assert dmi_facts['product_name']



# Generated at 2022-06-16 23:59:28.931780
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    vgs_facts = hardware.get_vgs_facts()
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs_facts['vgs']['rootvg'][0]['pv_state'] == 'active'
    assert vgs_facts['vgs']['rootvg'][0]['total_pps'] == '546'
    assert vgs_facts['vgs']['rootvg'][0]['free_pps'] == '0'
    assert vgs_facts['vgs']['rootvg'][0]['pp_size'] == '4 megabyte(s)'

# Generated at 2022-06-16 23:59:32.095411
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    facts = hardware.get_memory_facts()
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swapfree_mb' in facts


# Generated at 2022-06-16 23:59:34.857054
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    mount_facts = hardware.get_mount_facts()
    assert mount_facts['mounts'] != []


# Generated at 2022-06-16 23:59:41.015569
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['firmware_version'] == 'IBM,8233-E8B'
    assert hardware_facts['product_name'] == '8233-E8B'
    assert hardware_facts['product_serial'] == '0123ABC'
    assert hardware_facts['lpar_info'] == '1'
    assert hardware_facts['processor'] == 'PowerPC_POWER8'
    assert hardware_facts['processor_cores'] == 4
    assert hardware_facts['processor_count'] == 4
    assert hardware_facts['memtotal_mb'] == 16384
    assert hardware_facts['memfree_mb'] == 16384
    assert hardware_facts['swaptotal_mb']

# Generated at 2022-06-16 23:59:49.807435
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    device_facts = hardware.get_device_facts()
    assert device_facts['devices']['ent0']['state'] == 'Available'
    assert device_facts['devices']['ent0']['type'] == 'Device'
    assert device_facts['devices']['ent0']['attributes']['PdDvLn'] == 'ent/en'
    assert device_facts['devices']['ent0']['attributes']['bus_ioaddr'] == '0x1000'
    assert device_facts['devices']['ent0']['attributes']['bus_memaddr'] == '0x20000000'