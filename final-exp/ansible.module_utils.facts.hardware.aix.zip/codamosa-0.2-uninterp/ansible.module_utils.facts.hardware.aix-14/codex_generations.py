

# Generated at 2022-06-16 23:51:22.792553
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    device_facts = hardware.get_device_facts()
    assert device_facts['devices']['ent0']['state'] == 'Available'
    assert device_facts['devices']['ent0']['type'] == 'Device'
    assert device_facts['devices']['ent0']['attributes']['PdDvLn'] == 'ent/en'
    assert device_facts['devices']['ent0']['attributes']['bus_ioaddr'] == '0x0'
    assert device_facts['devices']['ent0']['attributes']['bus_memaddr'] == '0x0'

# Generated at 2022-06-16 23:51:32.621888
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)

    hardware.populate()

    assert hardware.facts['processor_cores'] == 2
    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['processor'] == 'PowerPC_POWER7'
    assert hardware.facts['memtotal_mb'] == 61440
    assert hardware.facts['memfree_mb'] == 61440
    assert hardware.facts['swaptotal_mb'] == 314368
    assert hardware.facts['swapfree_mb'] == 314368
    assert hardware.facts['firmware_version'] == '1.0'
    assert hardware.facts['product_serial'] == '123456789'
    assert hardware.facts['lpar_info'] == '1'

# Generated at 2022-06-16 23:51:34.609929
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hw = AIXHardwareCollector()
    assert hw.platform == 'AIX'
    assert hw.fact_class == AIXHardware

# Generated at 2022-06-16 23:51:36.507931
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    module = AnsibleModule(argument_spec={})
    hardware_collector = AIXHardwareCollector(module=module)
    assert hardware_collector.platform == 'AIX'
    assert hardware_collector.fact_class == AIXHardware


# Generated at 2022-06-16 23:51:39.526494
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert 'processor' in cpu_facts
    assert 'processor_count' in cpu_facts
    assert 'processor_cores' in cpu_facts


# Generated at 2022-06-16 23:51:47.755906
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['product_name'] == 'IBM,8286-42A'
    assert dmi_facts['firmware_version'] == 'S82861.B00.17080807.BQG'
    assert dmi_facts['product_serial'] == '06A6E5D'
    assert dmi_facts['lpar_info'] == '1 CEC(s)'


# Generated at 2022-06-16 23:51:50.579548
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector._platform == 'AIX'
    assert hardware_collector._fact_class == AIXHardware


# Generated at 2022-06-16 23:52:01.218459
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command.return_value = (0, 'ent0 Available 00-00-00-00-00-00 Ethernet IVE', '')
    module.run_command.return_value = (0, 'ent0 Available 00-00-00-00-00-00 Ethernet IVE', '')
    module.run_command.return_value = (0, 'ent0 Available 00-00-00-00-00-00 Ethernet IVE', '')

# Generated at 2022-06-16 23:52:06.948459
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)

    cpu_facts = hardware.get_cpu_facts()

    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'PowerPC_POWER8'
    assert cpu_facts['processor_cores'] == 8


# Generated at 2022-06-16 23:52:17.897773
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    device_facts = hardware.get_device_facts()
    assert device_facts['devices']['ent0']['state'] == 'Available'
    assert device_facts['devices']['ent0']['type'] == 'Device'
    assert device_facts['devices']['ent0']['attributes']['PdDvLn'] == 'ent/en'
    assert device_facts['devices']['ent0']['attributes']['bus_ioaddr'] == '0x2000'
    assert device_facts['devices']['ent0']['attributes']['bus_memaddr'] == '0x20000000'

# Generated at 2022-06-16 23:52:39.965249
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector._platform == 'AIX'
    assert hardware_collector._fact_class == AIXHardware

# Generated at 2022-06-16 23:52:42.403311
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    mount_facts = hardware.get_mount_facts()
    assert mount_facts['mounts'] is not None


# Generated at 2022-06-16 23:52:48.293603
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    mount_facts = hardware.get_mount_facts()
    assert mount_facts['mounts'] != []
    assert mount_facts['mounts'][0]['mount'] != ''
    assert mount_facts['mounts'][0]['device'] != ''
    assert mount_facts['mounts'][0]['fstype'] != ''
    assert mount_facts['mounts'][0]['options'] != ''
    assert mount_facts['mounts'][0]['time'] != ''
    assert mount_facts['mounts'][0]['size_total'] != ''
    assert mount_facts['mounts'][0]['size_available'] != ''

# Generated at 2022-06-16 23:52:56.350188
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    result = hardware.get_device_facts()
    assert result['devices']
    assert result['devices']['ent0']
    assert result['devices']['ent0']['state'] == 'Available'
    assert result['devices']['ent0']['type'] == 'Ethernet Adapter (l-lan)'
    assert result['devices']['ent0']['attributes']
    assert result['devices']['ent0']['attributes']['mtu'] == '1500'
    assert result['devices']['ent0']['attributes']['tcp_sendspace'] == '262144'

# Generated at 2022-06-16 23:53:04.885893
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['firmware_version'] == 'IBM,8233-E8B'
    assert dmi_facts['product_serial'] == '0123ABC'
    assert dmi_facts['lpar_info'] == '1 CEC(s)'
    assert dmi_facts['product_name'] == 'IBM,8233-E8B'


# Generated at 2022-06-16 23:53:14.138737
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    hardware_obj = AIXHardware(module)
    device_facts = hardware_obj.get_device_facts()
    assert device_facts['devices']['ent0']['state'] == 'Available'
    assert device_facts['devices']['ent0']['type'] == 'Ethernet Adapter (l-lan)'
    assert device_facts['devices']['ent0']['attributes']['adapter_type'] == 'EN_10G_ROCE'
    assert device_facts['devices']['ent0']['attributes']['alt_addr'] == '0x000000000000'

# Generated at 2022-06-16 23:53:21.907870
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['firmware_version'] == 'IBM,8233-E8B'
    assert dmi_facts['product_serial'] == '0123ABC'
    assert dmi_facts['lpar_info'] == '1 CEC(s)'
    assert dmi_facts['product_name'] == 'IBM,8233-E8B'


# Generated at 2022-06-16 23:53:32.810264
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor_count'] == 1
    assert hardware_facts['processor'] == 'PowerPC_POWER8'
    assert hardware_facts['processor_cores'] == 4
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['firmware_version'] == 'IBM,8247-22L'
    assert hardware_facts['product_serial'] == '0123456789'
    assert hardware_facts['lpar_info'] == '1 CEC(s)'

# Generated at 2022-06-16 23:53:37.365379
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    memory_facts = hardware.get_memory_facts()

    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-16 23:53:39.856430
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    mount_facts = hardware.get_mount_facts()
    assert mount_facts['mounts']

# Generated at 2022-06-16 23:54:19.422022
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hw = AIXHardwareCollector()
    assert hw.platform == 'AIX'
    assert hw.fact_class == AIXHardware


# Generated at 2022-06-16 23:54:30.084829
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    class TestModule(object):
        def __init__(self):
            self.run_command_calls = []

        def get_bin_path(self, arg, opt_dirs=[]):
            return '/usr/bin/' + arg

        def run_command(self, cmd, use_unsafe_shell=False):
            self.run_command_calls.append(cmd)

# Generated at 2022-06-16 23:54:39.747884
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    hardware_facts = hardware.populate()

    assert hardware_facts['firmware_version'] == 'IBM,8233-E8B'
    assert hardware_facts['product_name'] == '8233-E8B'
    assert hardware_facts['product_serial'] == '0123ABC'
    assert hardware_facts['lpar_info'] == '1 CEC'
    assert hardware_facts['processor_count'] == 2
    assert hardware_facts['processor'] == 'PowerPC_POWER8'
    assert hardware_facts['processor_cores'] == 4
    assert hardware_facts['memtotal_mb'] == 16384
    assert hardware_facts['memfree_mb'] == 16384

# Generated at 2022-06-16 23:54:42.398506
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    mount_facts = hardware.get_mount_facts()
    assert mount_facts['mounts']

# Generated at 2022-06-16 23:54:55.311632
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    device_facts = hardware.get_device_facts()
    assert 'devices' in device_facts
    assert 'ent0' in device_facts['devices']
    assert 'state' in device_facts['devices']['ent0']
    assert 'type' in device_facts['devices']['ent0']
    assert 'attributes' in device_facts['devices']['ent0']
    assert 'ent0' in device_facts['devices']
    assert 'state' in device_facts['devices']['ent0']
    assert 'type' in device_facts['devices']['ent0']
    assert 'attributes' in device_facts['devices']['ent0']
    assert 'ent0' in device_facts['devices']


# Generated at 2022-06-16 23:54:58.856857
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    device_facts = hardware.get_device_facts()
    assert device_facts['devices']


# Generated at 2022-06-16 23:55:07.006700
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    vgs_facts = hardware.get_vgs_facts()
    assert 'vgs' in vgs_facts
    assert 'rootvg' in vgs_facts['vgs']
    assert 'realsyncvg' in vgs_facts['vgs']
    assert 'testvg' in vgs_facts['vgs']
    assert len(vgs_facts['vgs']['rootvg']) == 2
    assert len(vgs_facts['vgs']['realsyncvg']) == 1
    assert len(vgs_facts['vgs']['testvg']) == 2
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'

# Generated at 2022-06-16 23:55:11.171462
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    mount_facts = hardware.get_mount_facts()
    assert mount_facts['mounts']


# Generated at 2022-06-16 23:55:22.031454
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    hardware.populate()
    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['processor'] == 'PowerPC_POWER8'
    assert hardware.facts['processor_cores'] == 4
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['memfree_mb'] == 16384
    assert hardware.facts['swaptotal_mb'] == 65536
    assert hardware.facts['swapfree_mb'] == 65536
    assert hardware.facts['firmware_version'] == 'IBM,8247-22L'
    assert hardware.facts['product_serial'] == '123456789'
    assert hardware.facts['lpar_info'] == '1'

# Generated at 2022-06-16 23:55:30.478350
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    hardware.populate()
    assert hardware.facts['devices']['ent0']['state'] == 'Available'
    assert hardware.facts['devices']['ent0']['type'] == 'Device'
    assert hardware.facts['devices']['ent0']['attributes']['PdDvLn'] == 'ent/en'
    assert hardware.facts['devices']['ent0']['attributes']['bus_ioaddr'] == '0x0'
    assert hardware.facts['devices']['ent0']['attributes']['bus_memaddr'] == '0x0'

# Generated at 2022-06-16 23:56:24.410619
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware_obj = AIXHardware(module)
    memory_facts = hardware_obj.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-16 23:56:32.382145
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    device_facts = hardware.get_device_facts()
    assert device_facts['devices']
    assert device_facts['devices']['ent0']
    assert device_facts['devices']['ent0']['state'] == 'Available'
    assert device_facts['devices']['ent0']['type'] == 'Ethernet Adapter (l-lan)'
    assert device_facts['devices']['ent0']['attributes']
    assert device_facts['devices']['ent0']['attributes']['adapter_name'] == 'ent0'
    assert device_facts['devices']['ent0']['attributes']['bus_io_addr'] == '0x0'
    assert device_facts

# Generated at 2022-06-16 23:56:42.093026
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['firmware_version'] == 'IBM,8247-22L'
    assert dmi_facts['product_serial'] == '123456789'
    assert dmi_facts['lpar_info'] == '1'
    assert dmi_facts['product_name'] == 'IBM,8247-22L'


# Generated at 2022-06-16 23:56:49.706176
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = AIXHardware(module)
    hardware_obj.populate()
    assert hardware_obj.facts['processor_count'] == 2
    assert hardware_obj.facts['processor'] == 'PowerPC_POWER8'
    assert hardware_obj.facts['processor_cores'] == 8
    assert hardware_obj.facts['memtotal_mb'] == 8192
    assert hardware_obj.facts['memfree_mb'] == 8192
    assert hardware_obj.facts['swaptotal_mb'] == 0
    assert hardware_obj.facts['swapfree_mb'] == 0
    assert hardware_obj.facts['firmware_version'] == 'IBM,8247-22L'
    assert hardware_obj.facts['product_serial'] == '0123456789'

# Generated at 2022-06-16 23:56:57.859252
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['firmware_version'] == 'IBM,8233-E8B'
    assert dmi_facts['product_serial'] == '0123456789'
    assert dmi_facts['lpar_info'] == '1 LPAR (Default)'
    assert dmi_facts['product_name'] == 'IBM,8233-E8B'


# Generated at 2022-06-16 23:57:00.865346
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector._platform == 'AIX'
    assert hardware_collector._fact_class == AIXHardware

# Generated at 2022-06-16 23:57:11.875250
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)

    # Test case 1:
    # lsdev output:
    # ent0 Available 00-08-74-FF-FF-FF Ethernet IVE
    # ent1 Available 00-08-74-FF-FF-FF Ethernet IVE
    # ent2 Available 00-08-74-FF-FF-FF Ethernet IVE
    # ent3 Available 00-08-74-FF-FF-FF Ethernet IVE
    # ent4 Available 00-08-74-FF-FF-FF Ethernet IVE
    # ent5 Available 00-08-74-FF-FF-FF Ethernet IVE
    # ent6 Available 00-08-74-FF-FF-FF Ethernet IVE
    # ent7 Available 00-08-74-FF-FF-FF Ethernet IVE
    #

# Generated at 2022-06-16 23:57:21.985502
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    device_facts = hardware.get_device_facts()
    assert 'devices' in device_facts
    assert 'ent0' in device_facts['devices']
    assert 'state' in device_facts['devices']['ent0']
    assert 'type' in device_facts['devices']['ent0']
    assert 'attributes' in device_facts['devices']['ent0']
    assert 'ent0' in device_facts['devices']
    assert 'state' in device_facts['devices']['ent0']
    assert 'type' in device_facts['devices']['ent0']
    assert 'attributes' in device_facts['devices']['ent0']
    assert 'ent0' in device_facts['devices']


# Generated at 2022-06-16 23:57:34.182798
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor_count'] == 1
    assert hardware_facts['processor_cores'] == 1
    assert hardware_facts['processor'] == 'PowerPC_POWER8'
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['firmware_version'] == 'IBM,8247-22L'
    assert hardware_facts['product_serial'] == '0123ABC'
    assert hardware_facts['lpar_info'] == '1'
    assert hardware_facts

# Generated at 2022-06-16 23:57:46.104966
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    hardware.populate()
    assert hardware.facts['devices']['ent0']['state'] == 'Available'
    assert hardware.facts['devices']['ent0']['type'] == 'Device'
    assert hardware.facts['devices']['ent0']['attributes']['PdDvLn'] == 'en_pci0/ent0'
    assert hardware.facts['devices']['ent0']['attributes']['bus_ioaddr'] == '0x2000'
    assert hardware.facts['devices']['ent0']['attributes']['bus_memaddr'] == '0x20000000'

# Generated at 2022-06-16 23:59:29.022420
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    module = AnsibleModule(argument_spec={})
    hardware_collector = AIXHardwareCollector(module)
    assert hardware_collector.platform == 'AIX'
    assert hardware_collector.fact_class == AIXHardware


# Generated at 2022-06-16 23:59:35.408209
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['firmware_version'] == 'IBM,8233-E8B'
    assert dmi_facts['product_serial'] == '0123456789'
    assert dmi_facts['lpar_info'] == '1'
    assert dmi_facts['product_name'] == 'IBM,8233-E8B'


# Generated at 2022-06-16 23:59:38.860041
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-16 23:59:48.013509
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor_count'] == 1
    assert hardware_facts['processor'] == 'PowerPC_POWER8'
    assert hardware_facts['processor_cores'] == 4
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['firmware_version'] == 'IBM,8247-22L'
    assert hardware_facts['product_serial'] == '0123456789'

# Generated at 2022-06-16 23:59:53.168483
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'PowerPC_POWER8'
    assert cpu_facts['processor_cores'] == 8


# Generated at 2022-06-16 23:59:59.117936
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    vgs_facts = hardware.get_vgs_facts()
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs_facts['vgs']['rootvg'][0]['pv_state'] == 'active'
    assert vgs_facts['vgs']['rootvg'][0]['total_pps'] == '546'
    assert vgs_facts['vgs']['rootvg'][0]['free_pps'] == '0'
    assert vgs_facts['vgs']['rootvg'][0]['pp_size'] == '4 megabyte(s)'

# Generated at 2022-06-17 00:00:05.592680
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['firmware_version'] == 'IBM,8247-22L'
    assert dmi_facts['product_serial'] == '1234567890'
    assert dmi_facts['lpar_info'] == '1'
    assert dmi_facts['product_name'] == '8247-22L'


# Generated at 2022-06-17 00:00:10.568983
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert 'firmware_version' in dmi_facts
    assert 'product_serial' in dmi_facts
    assert 'lpar_info' in dmi_facts
    assert 'product_name' in dmi_facts


# Generated at 2022-06-17 00:00:22.831217
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    vgs_facts = hardware.get_vgs_facts()
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs_facts['vgs']['rootvg'][0]['pv_state'] == 'active'
    assert vgs_facts['vgs']['rootvg'][0]['total_pps'] == '546'
    assert vgs_facts['vgs']['rootvg'][0]['free_pps'] == '0'
    assert vgs_facts['vgs']['rootvg'][0]['pp_size'] == '4 megabyte(s)'

# Generated at 2022-06-17 00:00:32.327605
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['firmware_version'] == 'IBM,8233-E8B'
    assert dmi_facts['product_serial'] == '0123456789'
    assert dmi_facts['lpar_info'] == '1 CEC(s)'
    assert dmi_facts['product_name'] == 'IBM,8233-E8B'
