

# Generated at 2022-06-16 23:51:17.793547
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector._platform == 'AIX'
    assert hardware_collector._fact_class == AIXHardware


# Generated at 2022-06-16 23:51:19.742804
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hw = AIXHardwareCollector()
    assert hw.platform == 'AIX'
    assert hw.fact_class == AIXHardware

# Generated at 2022-06-16 23:51:26.219988
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['firmware_version'] == 'IBM,8247-22L'
    assert dmi_facts['product_serial'] == '123456789'
    assert dmi_facts['lpar_info'] == '1'
    assert dmi_facts['product_name'] == 'IBM,8247-22L'


# Generated at 2022-06-16 23:51:30.613198
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'PowerPC_POWER8'
    assert cpu_facts['processor_cores'] == 4


# Generated at 2022-06-16 23:51:33.071341
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector.platform == 'AIX'
    assert hardware_collector.fact_class == AIXHardware


# Generated at 2022-06-16 23:51:38.487403
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module=module)

    device_facts = hardware.get_device_facts()

    assert 'devices' in device_facts
    assert 'ent0' in device_facts['devices']
    assert 'state' in device_facts['devices']['ent0']
    assert 'type' in device_facts['devices']['ent0']
    assert 'attributes' in device_facts['devices']['ent0']
    assert 'ent0' in device_facts['devices']
    assert 'state' in device_facts['devices']['ent0']
    assert 'type' in device_facts['devices']['ent0']
    assert 'attributes' in device_facts['devices']['ent0']

# Generated at 2022-06-16 23:51:41.753320
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    mount_facts = hardware.get_mount_facts()
    assert mount_facts['mounts']


# Generated at 2022-06-16 23:51:52.825010
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    device_facts = hardware.get_device_facts()
    assert device_facts['devices']['fcs0']['state'] == 'Available'
    assert device_facts['devices']['fcs0']['type'] == 'FC Adapter'
    assert device_facts['devices']['fcs0']['attributes']['bus_id'] == '0x50050763020c0c00'
    assert device_facts['devices']['fcs0']['attributes']['bus_mem'] == '0x0'
    assert device_facts['devices']['fcs0']['attributes']['bus_io'] == '0x0'

# Generated at 2022-06-16 23:51:55.060344
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert 'firmware_version' in dmi_facts
    assert 'product_serial' in dmi_facts
    assert 'lpar_info' in dmi_facts
    assert 'product_name' in dmi_facts


# Generated at 2022-06-16 23:51:59.483916
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    vgs_facts = hardware.get_vgs_facts()
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs_facts['vgs']['rootvg'][0]['pv_state'] == 'active'
    assert vgs_facts['vgs']['rootvg'][0]['total_pps'] == '546'
    assert vgs_facts['vgs']['rootvg'][0]['free_pps'] == '0'
    assert vgs_facts['vgs']['rootvg'][0]['pp_size'] == '4 megabyte(s)'

# Generated at 2022-06-16 23:52:26.459880
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    vgs_facts = hardware.get_vgs_facts()
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs_facts['vgs']['rootvg'][0]['pv_state'] == 'active'
    assert vgs_facts['vgs']['rootvg'][0]['total_pps'] == '546'
    assert vgs_facts['vgs']['rootvg'][0]['free_pps'] == '0'
    assert vgs_facts['vgs']['rootvg'][0]['pp_size'] == '4 megabyte(s)'

# Generated at 2022-06-16 23:52:35.045756
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    vgs_facts = hardware.get_vgs_facts()
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs_facts['vgs']['rootvg'][0]['pv_state'] == 'active'
    assert vgs_facts['vgs']['rootvg'][0]['total_pps'] == '546'
    assert vgs_facts['vgs']['rootvg'][0]['free_pps'] == '0'
    assert vgs_facts['vgs']['rootvg'][0]['pp_size'] == '4 megabyte(s)'

# Generated at 2022-06-16 23:52:36.160825
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector._platform == 'AIX'
    assert hardware_collector._fact_class == AIXHardware


# Generated at 2022-06-16 23:52:38.583964
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    mount_facts = hardware.get_mount_facts()
    assert mount_facts['mounts']


# Generated at 2022-06-16 23:52:46.024297
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    vgs_facts = hardware.get_vgs_facts()
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs_facts['vgs']['rootvg'][0]['pv_state'] == 'active'
    assert vgs_facts['vgs']['rootvg'][0]['total_pps'] == '546'
    assert vgs_facts['vgs']['rootvg'][0]['free_pps'] == '0'
    assert vgs_facts['vgs']['rootvg'][0]['pp_size'] == '4 megabyte(s)'

# Generated at 2022-06-16 23:52:49.684158
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector._platform == 'AIX'
    assert hardware_collector._fact_class == AIXHardware

# Generated at 2022-06-16 23:52:52.340366
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    mount_facts = hardware.get_mount_facts()
    assert mount_facts['mounts']


# Generated at 2022-06-16 23:52:54.887494
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector._platform == 'AIX'
    assert hardware_collector._fact_class == AIXHardware

# Generated at 2022-06-16 23:53:07.148016
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    hardware.populate()
    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['processor_cores'] == 4
    assert hardware.facts['processor'] == 'PowerPC_POWER8'
    assert hardware.facts['memtotal_mb'] == 8192
    assert hardware.facts['memfree_mb'] == 8192
    assert hardware.facts['swaptotal_mb'] == 32768
    assert hardware.facts['swapfree_mb'] == 32768
    assert hardware.facts['firmware_version'] == '1.9.0'
    assert hardware.facts['product_serial'] == '0123456789'
    assert hardware.facts['lpar_info'] == '1'

# Generated at 2022-06-16 23:53:15.558017
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor_count'] == 2
    assert hardware_facts['processor_cores'] == 2
    assert hardware_facts['processor'] == 'PowerPC_POWER8'
    assert hardware_facts['memtotal_mb'] == 8192
    assert hardware_facts['memfree_mb'] == 8192
    assert hardware_facts['swaptotal_mb'] == 2048
    assert hardware_facts['swapfree_mb'] == 2048
    assert hardware_facts['firmware_version'] == 'IBM,8247-22L'
    assert hardware_facts['product_serial'] == '0123ABC'
    assert hardware_facts['lpar_info'] == '1'
    assert hardware

# Generated at 2022-06-16 23:53:57.449493
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    module = AnsibleModule(argument_spec={})
    hardware_collector = AIXHardwareCollector(module=module)
    assert hardware_collector.platform == 'AIX'
    assert hardware_collector.fact_class == AIXHardware


# Generated at 2022-06-16 23:54:01.334207
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    mount_facts = hardware.get_mount_facts()
    assert mount_facts['mounts']


# Generated at 2022-06-16 23:54:11.953712
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    vgs_facts = hardware.get_vgs_facts()
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs_facts['vgs']['rootvg'][0]['pv_state'] == 'active'
    assert vgs_facts['vgs']['rootvg'][0]['total_pps'] == '546'
    assert vgs_facts['vgs']['rootvg'][0]['free_pps'] == '0'
    assert vgs_facts['vgs']['rootvg'][0]['pp_size'] == '4 megabyte(s)'

# Generated at 2022-06-16 23:54:13.446343
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    mount_facts = hardware.get_mount_facts()
    assert mount_facts['mounts']

# Generated at 2022-06-16 23:54:23.531456
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    device_facts = hardware.get_device_facts()
    assert device_facts['devices']['ent0']['state'] == 'Available'
    assert device_facts['devices']['ent0']['type'] == 'Device'
    assert device_facts['devices']['ent0']['attributes']['bus_io_addr'] == '0x1000'
    assert device_facts['devices']['ent0']['attributes']['bus_mem_addr'] == '0x20000000'
    assert device_facts['devices']['ent0']['attributes']['bus_pci_dev'] == '0x00'

# Generated at 2022-06-16 23:54:34.649176
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    device_facts = hardware.get_device_facts()
    assert 'devices' in device_facts
    assert 'ent0' in device_facts['devices']
    assert 'state' in device_facts['devices']['ent0']
    assert 'type' in device_facts['devices']['ent0']
    assert 'attributes' in device_facts['devices']['ent0']
    assert 'ent0' in device_facts['devices']
    assert 'state' in device_facts['devices']['ent0']
    assert 'type' in device_facts['devices']['ent0']
    assert 'attributes' in device_facts['devices']['ent0']
    assert 'ent0' in device_facts['devices']


# Generated at 2022-06-16 23:54:40.250900
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    dmi_facts = hardware.get_dmi_facts()

    assert dmi_facts['firmware_version'] == 'IBM,8233-E8B'
    assert dmi_facts['product_serial'] == '0123ABC'
    assert dmi_facts['lpar_info'] == '1 CEC(s)'
    assert dmi_facts['product_name'] == 'IBM,8233-E8B'



# Generated at 2022-06-16 23:54:45.984704
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'PowerPC_POWER8'
    assert cpu_facts['processor_cores'] == 4


# Generated at 2022-06-16 23:54:52.919063
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert 'firmware_version' in dmi_facts
    assert 'product_serial' in dmi_facts
    assert 'lpar_info' in dmi_facts
    assert 'product_name' in dmi_facts


# Generated at 2022-06-16 23:54:55.570714
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    mount_facts = hardware.get_mount_facts()
    assert mount_facts['mounts']

# Generated at 2022-06-16 23:56:25.174185
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    hardware.populate()
    assert hardware.facts['memtotal_mb'] == hardware.facts['memfree_mb'] + hardware.facts['swaptotal_mb'] - hardware.facts['swapfree_mb']


# Generated at 2022-06-16 23:56:29.959010
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert 'memtotal_mb' in memory_facts
    assert 'memfree_mb' in memory_facts
    assert 'swaptotal_mb' in memory_facts
    assert 'swapfree_mb' in memory_facts


# Generated at 2022-06-16 23:56:33.218726
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector._platform == 'AIX'
    assert hardware_collector._fact_class == AIXHardware


# Generated at 2022-06-16 23:56:45.382689
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    vgs_facts = hardware.get_vgs_facts()
    assert 'vgs' in vgs_facts
    assert 'rootvg' in vgs_facts['vgs']
    assert 'realsyncvg' in vgs_facts['vgs']
    assert 'testvg' in vgs_facts['vgs']
    assert len(vgs_facts['vgs']['rootvg']) == 2
    assert len(vgs_facts['vgs']['realsyncvg']) == 1
    assert len(vgs_facts['vgs']['testvg']) == 2
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'

# Generated at 2022-06-16 23:56:58.073866
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    vgs_facts = hardware.get_vgs_facts()
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs_facts['vgs']['rootvg'][0]['pv_state'] == 'active'
    assert vgs_facts['vgs']['rootvg'][0]['total_pps'] == '546'
    assert vgs_facts['vgs']['rootvg'][0]['free_pps'] == '0'
    assert vgs_facts['vgs']['rootvg'][0]['pp_size'] == '4 megabyte(s)'

# Generated at 2022-06-16 23:57:09.846958
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.run_command = run_command
            self.get_bin_path = get_bin_path


# Generated at 2022-06-16 23:57:16.772347
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert 'processor' in cpu_facts
    assert 'processor_cores' in cpu_facts
    assert 'processor_count' in cpu_facts


# Generated at 2022-06-16 23:57:20.606983
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware_obj = AIXHardware(module)
    cpu_facts = hardware_obj.get_cpu_facts()
    assert cpu_facts['processor'] == 'PowerPC_POWER8'
    assert cpu_facts['processor_cores'] == 4
    assert cpu_facts['processor_count'] == 2


# Generated at 2022-06-16 23:57:26.719484
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    class ModuleStub(object):
        def __init__(self):
            self.params = {}
            self.run_command_calls = []

        def run_command(self, cmd, use_unsafe_shell=False):
            self.run_command_calls.append(cmd)

# Generated at 2022-06-16 23:57:37.498341
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)

    # Test with no mount
    mount_out = ''
    mounts = hardware.get_mount_facts(mount_out)
    assert mounts == {'mounts': []}

    # Test with one mount
    mount_out = 'node mounted        mounted over    vfs    date        options\n/dev/hd4         /               jfs2   Aug  5 13:09 rw,log=/dev/hd8'
    mounts = hardware.get_mount_facts(mount_out)

# Generated at 2022-06-16 23:59:38.980746
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    hardware_facts = hardware.populate()

    assert hardware_facts['processor_count'] == 2
    assert hardware_facts['processor'] == 'PowerPC_POWER8'
    assert hardware_facts['processor_cores'] == 4
    assert hardware_facts['memtotal_mb'] == 1048576
    assert hardware_facts['memfree_mb'] == 1048576
    assert hardware_facts['swaptotal_mb'] == 1048576
    assert hardware_facts['swapfree_mb'] == 1048576
    assert hardware_facts['firmware_version'] == '1.0'
    assert hardware_facts['product_serial'] == '0123456789'
    assert hardware_facts['lpar_info'] == '1'


# Generated at 2022-06-16 23:59:43.750561
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0

# Generated at 2022-06-16 23:59:48.524281
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['firmware_version'] is not None
    assert dmi_facts['product_serial'] is not None
    assert dmi_facts['lpar_info'] is not None
    assert dmi_facts['product_name'] is not None



# Generated at 2022-06-16 23:59:57.245144
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)

    # Test with vmstat output

# Generated at 2022-06-17 00:00:01.392500
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    result = hardware.get_mount_facts()
    assert result['mounts']


# Generated at 2022-06-17 00:00:10.841320
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['firmware_version'] == 'IBM,8247-22L'
    assert dmi_facts['product_serial'] == '123456789'
    assert dmi_facts['lpar_info'] == '1'
    assert dmi_facts['product_name'] == 'IBM,8247-22L'


# Generated at 2022-06-17 00:00:22.863046
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_collector = AIXHardwareCollector(module=module)
    hardware = hardware_collector.collect()[0]

# Generated at 2022-06-17 00:00:34.301679
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    vgs_facts = hardware.get_vgs_facts()
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs_facts['vgs']['rootvg'][0]['pv_state'] == 'active'
    assert vgs_facts['vgs']['rootvg'][0]['total_pps'] == '546'
    assert vgs_facts['vgs']['rootvg'][0]['free_pps'] == '0'
    assert vgs_facts['vgs']['rootvg'][0]['pp_size'] == '4 megabyte(s)'

# Generated at 2022-06-17 00:00:39.032931
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor'] == 'PowerPC_POWER8'
    assert cpu_facts['processor_cores'] == 1


# Generated at 2022-06-17 00:00:47.748245
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['firmware_version'] == 'IBM,8233-E8B'
    assert dmi_facts['product_serial'] == '123456789'
    assert dmi_facts['lpar_info'] == '1'
    assert dmi_facts['product_name'] == 'IBM,8233-E8B'

