

# Generated at 2022-06-16 23:51:22.858846
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    vgs_facts = hardware.get_vgs_facts()
    assert vgs_facts['vgs']
    assert vgs_facts['vgs']['rootvg']
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs_facts['vgs']['rootvg'][0]['pv_state'] == 'active'
    assert vgs_facts['vgs']['rootvg'][0]['total_pps'] == '546'
    assert vgs_facts['vgs']['rootvg'][0]['free_pps'] == '0'

# Generated at 2022-06-16 23:51:25.943933
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    aix_hw_collector = AIXHardwareCollector()
    assert aix_hw_collector._platform == 'AIX'
    assert aix_hw_collector._fact_class == AIXHardware

# Generated at 2022-06-16 23:51:32.937065
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    """
    Unit test for method get_mount_facts of class AIXHardware
    """
    class TestModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, arg, required=False):
            return '/usr/sbin/mount'

        def run_command(self, cmd, use_unsafe_shell=False):
            return 0, '', ''

    test_module = TestModule()
    test_AIXHardware = AIXHardware(test_module)
    test_AIXHardware.get_mount_facts()

# Generated at 2022-06-16 23:51:38.137088
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    vgs_facts = hardware.get_vgs_facts()
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs_facts['vgs']['rootvg'][0]['pv_state'] == 'active'
    assert vgs_facts['vgs']['rootvg'][0]['total_pps'] == '546'
    assert vgs_facts['vgs']['rootvg'][0]['free_pps'] == '0'
    assert vgs_facts['vgs']['rootvg'][0]['pp_size'] == '4 megabyte(s)'

# Generated at 2022-06-16 23:51:48.845365
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    device_facts = hardware.get_device_facts()
    assert device_facts['devices']['ent0']['state'] == 'Available'
    assert device_facts['devices']['ent0']['type'] == 'Device'
    assert device_facts['devices']['ent0']['attributes']['PdDvLn'] == 'ent/en'
    assert device_facts['devices']['ent0']['attributes']['bus_ioaddr'] == '0xef40'
    assert device_facts['devices']['ent0']['attributes']['bus_memaddr'] == '0xef400000'

# Generated at 2022-06-16 23:51:59.844857
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    hardware.populate()
    facts = hardware.get_device_facts()
    assert 'devices' in facts
    assert 'ent0' in facts['devices']
    assert 'state' in facts['devices']['ent0']
    assert 'type' in facts['devices']['ent0']
    assert 'attributes' in facts['devices']['ent0']
    assert 'ent0' in facts['devices']
    assert 'state' in facts['devices']['ent0']
    assert 'type' in facts['devices']['ent0']
    assert 'attributes' in facts['devices']['ent0']
    assert 'ent0' in facts['devices']
    assert 'state' in facts['devices']['ent0']

# Generated at 2022-06-16 23:52:03.456703
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector._platform == 'AIX'
    assert hardware_collector._fact_class == AIXHardware


# Generated at 2022-06-16 23:52:15.236450
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    device_facts = hardware.get_device_facts()
    assert 'devices' in device_facts
    assert 'ent0' in device_facts['devices']
    assert 'state' in device_facts['devices']['ent0']
    assert 'type' in device_facts['devices']['ent0']
    assert 'attributes' in device_facts['devices']['ent0']
    assert 'ent0' in device_facts['devices']
    assert 'state' in device_facts['devices']['ent0']
    assert 'type' in device_facts['devices']['ent0']
    assert 'attributes' in device_facts['devices']['ent0']
    assert 'ent0' in device_facts['devices']


# Generated at 2022-06-16 23:52:23.987631
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    hardware.populate()
    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['processor'] == 'PowerPC_POWER7'
    assert hardware.facts['processor_cores'] == 4
    assert hardware.facts['memtotal_mb'] == 63936
    assert hardware.facts['memfree_mb'] == 63936
    assert hardware.facts['swaptotal_mb'] == 314368
    assert hardware.facts['swapfree_mb'] == 314368
    assert hardware.facts['firmware_version'] == '1.0'
    assert hardware.facts['product_serial'] == '0123456789'
    assert hardware.facts['lpar_info'] == '1'

# Generated at 2022-06-16 23:52:33.497235
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == 'PowerPC_POWER8'
    assert hardware.facts['processor_cores'] == 4
    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['memfree_mb'] == 16384
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['firmware_version'] == '1.9.0'
    assert hardware.facts['product_serial'] == '0123456789'
    assert hardware.facts['lpar_info'] == '1-2-3-4'

# Generated at 2022-06-16 23:53:03.801757
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    vgs_facts = hardware.get_vgs_facts()
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs_facts['vgs']['rootvg'][0]['pv_state'] == 'active'
    assert vgs_facts['vgs']['rootvg'][0]['total_pps'] == '546'
    assert vgs_facts['vgs']['rootvg'][0]['free_pps'] == '0'
    assert vgs_facts['vgs']['rootvg'][0]['pp_size'] == '4 megabyte(s)'

# Generated at 2022-06-16 23:53:13.355484
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    hardware = AIXHardware(module)
    vgs_facts = hardware.get_vgs_facts()
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs_facts['vgs']['rootvg'][0]['pv_state'] == 'active'
    assert vgs_facts['vgs']['rootvg'][0]['total_pps'] == '546'
    assert vgs_facts['vgs']['rootvg'][0]['free_pps'] == '0'

# Generated at 2022-06-16 23:53:24.237707
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    device_facts = hardware.get_device_facts()
    assert 'devices' in device_facts
    assert 'ent0' in device_facts['devices']
    assert 'state' in device_facts['devices']['ent0']
    assert 'type' in device_facts['devices']['ent0']
    assert 'attributes' in device_facts['devices']['ent0']
    assert 'ent0' in device_facts['devices']
    assert 'state' in device_facts['devices']['ent0']
    assert 'type' in device_facts['devices']['ent0']
    assert 'attributes' in device_facts['devices']['ent0']
    assert 'ent0' in device_facts['devices']


# Generated at 2022-06-16 23:53:30.079061
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    hardware.populate()
    assert hardware.firmware_version == 'IBM,8233-E8B'
    assert hardware.product_serial == '0123456789'
    assert hardware.lpar_info == '1 CEC(s)'
    assert hardware.product_name == 'IBM,8233-E8B'



# Generated at 2022-06-16 23:53:35.706657
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-16 23:53:45.307242
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    vgs_facts = hardware.get_vgs_facts()
    assert 'vgs' in vgs_facts
    assert 'rootvg' in vgs_facts['vgs']
    assert 'realsyncvg' in vgs_facts['vgs']
    assert 'testvg' in vgs_facts['vgs']
    assert len(vgs_facts['vgs']['rootvg']) == 2
    assert len(vgs_facts['vgs']['realsyncvg']) == 1
    assert len(vgs_facts['vgs']['testvg']) == 2
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'

# Generated at 2022-06-16 23:53:48.691365
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    module = AnsibleModule(argument_spec={})
    hardware_collector = AIXHardwareCollector(module=module)
    assert hardware_collector.platform == 'AIX'
    assert hardware_collector.fact_class == AIXHardware


# Generated at 2022-06-16 23:53:51.156940
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    aix_hw_collector = AIXHardwareCollector()
    assert aix_hw_collector._platform == 'AIX'
    assert aix_hw_collector._fact_class == AIXHardware

# Generated at 2022-06-16 23:53:54.858682
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-16 23:54:00.997897
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-16 23:54:40.496191
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    mount_facts = hardware.get_mount_facts()
    assert mount_facts['mounts']

# Generated at 2022-06-16 23:54:46.284535
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'PowerPC_POWER8'
    assert cpu_facts['processor_cores'] == 8


# Generated at 2022-06-16 23:54:54.762433
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['firmware_version'] == 'IBM,8233-E8B'
    assert dmi_facts['product_serial'] == '0123456789'
    assert dmi_facts['lpar_info'] == '1'
    assert dmi_facts['product_name'] == 'IBM,8233-E8B'


# Generated at 2022-06-16 23:55:04.604999
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    device_facts = hardware.get_device_facts()
    assert 'devices' in device_facts
    assert 'ent0' in device_facts['devices']
    assert 'state' in device_facts['devices']['ent0']
    assert 'type' in device_facts['devices']['ent0']
    assert 'attributes' in device_facts['devices']['ent0']
    assert 'ent0' in device_facts['devices']
    assert 'state' in device_facts['devices']['ent0']
    assert 'type' in device_facts['devices']['ent0']
    assert 'attributes' in device_facts['devices']['ent0']
    assert 'ent0' in device_facts['devices']


# Generated at 2022-06-16 23:55:17.015666
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    vgs_facts = hardware.get_vgs_facts()
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs_facts['vgs']['rootvg'][0]['pv_state'] == 'active'
    assert vgs_facts['vgs']['rootvg'][0]['total_pps'] == '546'
    assert vgs_facts['vgs']['rootvg'][0]['free_pps'] == '0'
    assert vgs_facts['vgs']['rootvg'][0]['pp_size'] == '4 megabyte(s)'

# Generated at 2022-06-16 23:55:24.022889
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    device_facts = hardware.get_device_facts()
    assert device_facts['devices']['ent0']['state'] == 'Available'
    assert device_facts['devices']['ent0']['type'] == 'Device'
    assert device_facts['devices']['ent0']['attributes']['state'] == 'available'
    assert device_facts['devices']['ent0']['attributes']['type'] == 'Ethernet'


# Generated at 2022-06-16 23:55:26.531309
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hw_collector = AIXHardwareCollector()
    assert hw_collector._platform == 'AIX'
    assert hw_collector._fact_class == AIXHardware


# Generated at 2022-06-16 23:55:31.850640
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['firmware_version'] == 'IBM,8233-E8B'
    assert dmi_facts['product_serial'] == '123456789ABC'
    assert dmi_facts['lpar_info'] == '1 CEC'
    assert dmi_facts['product_name'] == 'IBM,8233-E8B'



# Generated at 2022-06-16 23:55:33.340526
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    assert AIXHardwareCollector._platform == 'AIX'
    assert AIXHardwareCollector._fact_class == AIXHardware

# Generated at 2022-06-16 23:55:40.935957
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['firmware_version'] == 'IBM,8233-E8B'
    assert dmi_facts['product_serial'] == '0123456789'
    assert dmi_facts['lpar_info'] == '1 CEC(s)'
    assert dmi_facts['product_name'] == 'IBM,8233-E8B'


# Generated at 2022-06-16 23:56:28.629002
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector._platform == 'AIX'
    assert hardware_collector._fact_class == AIXHardware

# Generated at 2022-06-16 23:56:41.464523
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    device_facts = hardware.get_device_facts()

# Generated at 2022-06-16 23:56:46.263786
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-16 23:56:53.796475
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-16 23:57:01.301787
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['firmware_version'] == 'IBM,8247-22L'
    assert dmi_facts['product_serial'] == '123456789'
    assert dmi_facts['lpar_info'] == '1'
    assert dmi_facts['product_name'] == 'IBM,8247-22L'



# Generated at 2022-06-16 23:57:04.683074
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector._platform == 'AIX'
    assert hardware_collector._fact_class == AIXHardware


# Generated at 2022-06-16 23:57:13.883990
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_collector = AIXHardwareCollector(module=module)
    hardware = hardware_collector.collect()[0]


# Generated at 2022-06-16 23:57:17.199614
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    module = AnsibleModule(argument_spec={})
    collector = AIXHardwareCollector(module=module)
    assert collector.platform == 'AIX'
    assert collector.fact_class == AIXHardware


# Generated at 2022-06-16 23:57:24.546339
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    hardware.populate()
    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['processor'] == 'PowerPC_POWER8'
    assert hardware.facts['processor_cores'] == 1
    assert hardware.facts['memtotal_mb'] == 8192
    assert hardware.facts['memfree_mb'] == 8192
    assert hardware.facts['swaptotal_mb'] == 8192
    assert hardware.facts['swapfree_mb'] == 8192
    assert hardware.facts['firmware_version'] == '1.0'
    assert hardware.facts['product_serial'] == '0123456789'
    assert hardware.facts['lpar_info'] == '1'

# Generated at 2022-06-16 23:57:27.022327
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector._platform == 'AIX'
    assert hardware_collector._fact_class == AIXHardware

# Generated at 2022-06-16 23:59:14.149779
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['firmware_version'] == 'IBM,8233-E8B'
    assert dmi_facts['product_serial'] == '0123456789'
    assert dmi_facts['lpar_info'] == '1 CEC(s)'
    assert dmi_facts['product_name'] == 'IBM,8233-E8B'


# Generated at 2022-06-16 23:59:18.469890
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector._platform == 'AIX'
    assert hardware_collector._fact_class == AIXHardware


# Generated at 2022-06-16 23:59:27.142043
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    vgs_facts = hardware.get_vgs_facts()
    assert vgs_facts['vgs']
    assert vgs_facts['vgs']['rootvg']
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs_facts['vgs']['rootvg'][0]['pv_state'] == 'active'
    assert vgs_facts['vgs']['rootvg'][0]['total_pps'] == '546'
    assert vgs_facts['vgs']['rootvg'][0]['free_pps'] == '0'

# Generated at 2022-06-16 23:59:38.150404
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    device_facts = hardware.get_device_facts()
    assert 'devices' in device_facts
    assert 'ent0' in device_facts['devices']
    assert device_facts['devices']['ent0']['state'] == 'Available'
    assert device_facts['devices']['ent0']['type'] == 'Ethernet Adapter'
    assert 'attributes' in device_facts['devices']['ent0']
    assert 'ent0' in device_facts['devices']['ent0']['attributes']
    assert 'ent0' in device_facts['devices']['ent0']['attributes']

# Generated at 2022-06-16 23:59:42.388380
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    module = AnsibleModule(argument_spec={})
    hardware_collector = AIXHardwareCollector(module=module)
    assert hardware_collector.platform == 'AIX'
    assert hardware_collector.fact_class == AIXHardware


# Generated at 2022-06-16 23:59:46.399261
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    """
    This is a unit test for the constructor of the class AIXHardwareCollector.
    It tests that the class is properly constructed.
    """
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector._platform == 'AIX'
    assert hardware_collector._fact_class == AIXHardware

# Generated at 2022-06-16 23:59:50.574384
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['product_name'] == 'IBM,8286-42A'
    assert dmi_facts['product_serial'] == '06A0B9X'
    assert dmi_facts['firmware_version'] == 'V1.8'
    assert dmi_facts['lpar_info'] == '1 CEC(s)'


# Generated at 2022-06-16 23:59:53.541620
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hw_collector = AIXHardwareCollector()
    assert hw_collector.platform == 'AIX'
    assert hw_collector.fact_class == AIXHardware


# Generated at 2022-06-17 00:00:01.915808
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['firmware_version'] == 'IBM,8233-E8B'
    assert dmi_facts['product_serial'] == '123456789'
    assert dmi_facts['lpar_info'] == '1'
    assert dmi_facts['product_name'] == 'IBM,8233-E8B'


# Generated at 2022-06-17 00:00:12.997300
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = AIXHardware(module)
    device_facts = hardware.get_device_facts()
    assert device_facts['devices']['ent0']['state'] == 'Available'
    assert device_facts['devices']['ent0']['type'] == 'Device'
    assert device_facts['devices']['ent0']['attributes']['PdDvLn'] == 'ent/en'
    assert device_facts['devices']['ent0']['attributes']['bus_ioaddr'] == '0x1000'
    assert device_facts['devices']['ent0']['attributes']['bus_memaddr'] == '0x20000000'