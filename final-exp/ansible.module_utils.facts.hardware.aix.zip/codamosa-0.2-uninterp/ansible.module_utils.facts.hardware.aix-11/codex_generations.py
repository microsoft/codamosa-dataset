

# Generated at 2022-06-16 23:51:15.368109
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector._platform == 'AIX'
    assert hardware_collector._fact_class == AIXHardware

# Generated at 2022-06-16 23:51:18.280668
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    mount_facts = hardware.get_mount_facts()
    assert mount_facts['mounts']


# Generated at 2022-06-16 23:51:25.533048
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    device_facts = hardware.get_device_facts()
    assert device_facts['devices']['ent0']['state'] == 'Available'
    assert device_facts['devices']['ent0']['type'] == 'Device'
    assert device_facts['devices']['ent0']['attributes']['bus'] == 'True'
    assert device_facts['devices']['ent0']['attributes']['bus_ioaddr'] == '0x2000'
    assert device_facts['devices']['ent0']['attributes']['bus_memaddr'] == '0x20000000'

# Generated at 2022-06-16 23:51:34.994117
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor_count'] == 2
    assert hardware_facts['processor'] == 'PowerPC_POWER8'
    assert hardware_facts['processor_cores'] == 4
    assert hardware_facts['memtotal_mb'] == 8192
    assert hardware_facts['memfree_mb'] == 8192
    assert hardware_facts['swaptotal_mb'] == 0
    assert hardware_facts['swapfree_mb'] == 0
    assert hardware_facts['firmware_version'] == 'IBM,8247-22L'
    assert hardware_facts['product_serial'] == '0123456789'
    assert hardware_facts['lpar_info'] == '1'
   

# Generated at 2022-06-16 23:51:38.517309
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor'] == 'PowerPC_POWER8'
    assert cpu_facts['processor_cores'] == 1


# Generated at 2022-06-16 23:51:49.459291
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)

    # Test for device with attributes
    device_name = 'ent0'
    device_state = 'Available'
    device_type = ['Device', 'Network', 'I/O', 'Ethernet']

# Generated at 2022-06-16 23:51:52.358319
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector.platform == 'AIX'
    assert hardware_collector.fact_class == AIXHardware


# Generated at 2022-06-16 23:52:02.447493
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    hardware.populate()
    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['processor_cores'] == 2
    assert hardware.facts['processor'] == 'POWER8'
    assert hardware.facts['memtotal_mb'] == 8192
    assert hardware.facts['memfree_mb'] == 8192
    assert hardware.facts['swaptotal_mb'] == 32768
    assert hardware.facts['swapfree_mb'] == 32768
    assert hardware.facts['firmware_version'] == 'IBM,S814_068'
    assert hardware.facts['product_serial'] == '06C9A7C'
    assert hardware.facts['lpar_info'] == '1 CEC'

# Generated at 2022-06-16 23:52:06.334335
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    aix_hardware_collector = AIXHardwareCollector()
    assert aix_hardware_collector._platform == 'AIX'
    assert aix_hardware_collector._fact_class == AIXHardware

# Generated at 2022-06-16 23:52:09.776453
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    mount_facts = hardware.get_mount_facts()
    assert mount_facts['mounts']

# Generated at 2022-06-16 23:52:33.169568
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-16 23:52:41.281377
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    vgs_facts = hardware.get_vgs_facts()
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs_facts['vgs']['rootvg'][0]['pv_state'] == 'active'
    assert vgs_facts['vgs']['rootvg'][0]['total_pps'] == '546'
    assert vgs_facts['vgs']['rootvg'][0]['free_pps'] == '0'
    assert vgs_facts['vgs']['rootvg'][0]['pp_size'] == '4 megabyte(s)'

# Generated at 2022-06-16 23:52:48.021056
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    mount_facts = hardware.get_mount_facts()

# Generated at 2022-06-16 23:52:50.770912
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    mount_facts = hardware.get_mount_facts()
    assert mount_facts['mounts']


# Generated at 2022-06-16 23:52:53.896482
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    device_facts = hardware.get_device_facts()
    assert device_facts['devices']


# Generated at 2022-06-16 23:53:06.062065
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    vgs_facts = hardware.get_vgs_facts()
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs_facts['vgs']['rootvg'][0]['pv_state'] == 'active'
    assert vgs_facts['vgs']['rootvg'][0]['total_pps'] == '546'
    assert vgs_facts['vgs']['rootvg'][0]['free_pps'] == '0'
    assert vgs_facts['vgs']['rootvg'][0]['pp_size'] == '4 megabyte(s)'

# Generated at 2022-06-16 23:53:10.492941
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'PowerPC_POWER8'
    assert cpu_facts['processor_cores'] == 8


# Generated at 2022-06-16 23:53:17.472510
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    device_facts = hardware.get_device_facts()
    assert 'devices' in device_facts
    assert 'ent0' in device_facts['devices']
    assert 'state' in device_facts['devices']['ent0']
    assert 'type' in device_facts['devices']['ent0']
    assert 'attributes' in device_facts['devices']['ent0']
    assert 'ent0' in device_facts['devices']
    assert 'state' in device_facts['devices']['ent0']
    assert 'type' in device_facts['devices']['ent0']
    assert 'attributes' in device_facts['devices']['ent0']
    assert 'ent0' in device_facts['devices']


# Generated at 2022-06-16 23:53:26.880221
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    class ModuleStub:
        def run_command(self, cmd):
            if cmd == '/usr/bin/vmstat -v':
                return 0, 'memory pages:  8192\nfree pages:   1024', ''
            else:
                return 0, '', ''

    class AIXHardwareStub(AIXHardware):
        def __init__(self, module):
            self.module = module

    module = ModuleStub()
    hardware = AIXHardwareStub(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 32
    assert memory_facts['memfree_mb'] == 4


# Generated at 2022-06-16 23:53:28.594043
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector._platform == 'AIX'
    assert hardware_collector._fact_class == AIXHardware


# Generated at 2022-06-16 23:54:13.292839
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module=module)
    device_facts = hardware.get_device_facts()
    assert 'devices' in device_facts
    assert 'ent0' in device_facts['devices']
    assert 'state' in device_facts['devices']['ent0']
    assert 'type' in device_facts['devices']['ent0']
    assert 'attributes' in device_facts['devices']['ent0']
    assert 'ent0' in device_facts['devices']
    assert 'state' in device_facts['devices']['ent0']
    assert 'type' in device_facts['devices']['ent0']
    assert 'attributes' in device_facts['devices']['ent0']

# Generated at 2022-06-16 23:54:19.894719
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils._text import to_bytes

    test_data = get_file_content(
        '/usr/share/ansible_collections/ansible/community/tests/unit/module_utils/facts/hardware/aix/test_data/lsvg_output')
    test_data = to_bytes(test_data)

    aix_hardware = AIXHardware(dict(module=dict(run_command=lambda *_, **__: (0, test_data, ''))))
    vgs_facts = aix_hardware.get_vgs_facts()


# Generated at 2022-06-16 23:54:25.983762
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-16 23:54:36.042486
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_collector = AIXHardwareCollector(module=module)
    hardware = hardware_collector.collect()[0]

# Generated at 2022-06-16 23:54:47.392268
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)

    # Test case 1:
    # Test case for normal mount
    # mount output:
    # /dev/hd4 on / type jfs (log)
    # /dev/hd2 on /usr type jfs (log)
    # /dev/hd9var on /var type jfs (log)
    # /dev/hd3 on /tmp type jfs (log)
    # /dev/hd1 on /home type jfs (log)
    # /proc on /proc type procfs (rw)
    # /dev/hd10opt on /opt type jfs (log)
    # /dev/livedump on /var/adm/ras/livedump type jfs (log)
    # /dev/fslv00 on /usr/

# Generated at 2022-06-16 23:54:58.992827
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    vgs_facts = hardware.get_vgs_facts()
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs_facts['vgs']['rootvg'][0]['pv_state'] == 'active'
    assert vgs_facts['vgs']['rootvg'][0]['total_pps'] == '546'
    assert vgs_facts['vgs']['rootvg'][0]['free_pps'] == '0'
    assert vgs_facts['vgs']['rootvg'][0]['pp_size'] == '4 megabyte(s)'

# Generated at 2022-06-16 23:55:07.089674
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    class ModuleStub(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'firmware_version: IBM,8233-E8B', ''),
                (0, 'Machine Serial Number: 123456789', ''),
                (0, 'LPAR Info: 1 LPARs: 1 active, 0 open, 0 failed, 0 reserved', ''),
                (0, 'System Model: IBM,8233-E8B', '')
            ]
            self.run_command_index = 0

        def get_bin_path(self, arg, required=False):
            return '/usr/sbin/lsattr'


# Generated at 2022-06-16 23:55:14.610221
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-16 23:55:17.103118
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hw = AIXHardwareCollector()
    assert hw.platform == 'AIX'
    assert hw.fact_class == AIXHardware


# Generated at 2022-06-16 23:55:21.555308
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    facts = hardware.get_memory_facts()
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swapfree_mb' in facts


# Generated at 2022-06-16 23:56:13.221345
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['firmware_version'] == 'IBM,8233-E8B'
    assert dmi_facts['product_serial'] == '123456789'
    assert dmi_facts['lpar_info'] == '1'
    assert dmi_facts['product_name'] == 'IBM,8233-E8B'



# Generated at 2022-06-16 23:56:25.639680
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    hardware.populate()
    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['processor'] == 'PowerPC_POWER8'
    assert hardware.facts['processor_cores'] == 8
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['memfree_mb'] == 16384
    assert hardware.facts['swaptotal_mb'] == 16384
    assert hardware.facts['swapfree_mb'] == 16384
    assert hardware.facts['firmware_version'] == '1.0'
    assert hardware.facts['product_serial'] == '123456789'
    assert hardware.facts['lpar_info'] == '1'

# Generated at 2022-06-16 23:56:28.548165
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    device_facts = hardware.get_device_facts()
    assert device_facts['devices']


# Generated at 2022-06-16 23:56:34.532969
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    device_facts = hardware.get_device_facts()
    assert device_facts['devices']['ent0']['state'] == 'Available'
    assert device_facts['devices']['ent0']['type'] == 'Device'
    assert device_facts['devices']['ent0']['attributes']['PdDvLn'] == 'ent/en'
    assert device_facts['devices']['ent0']['attributes']['bus_ioaddr'] == '0x1000'
    assert device_facts['devices']['ent0']['attributes']['bus_memaddr'] == '0x20000000'

# Generated at 2022-06-16 23:56:41.569404
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-16 23:56:44.469609
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    mount_facts = hardware.get_mount_facts()
    assert mount_facts['mounts']


# Generated at 2022-06-16 23:56:57.487110
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    hardware.populate()
    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['processor'] == 'PowerPC_POWER8'
    assert hardware.facts['processor_cores'] == 8
    assert hardware.facts['memtotal_mb'] == 8192
    assert hardware.facts['memfree_mb'] == 8192
    assert hardware.facts['swaptotal_mb'] == 8192
    assert hardware.facts['swapfree_mb'] == 8192
    assert hardware.facts['firmware_version'] == '1.0'
    assert hardware.facts['product_serial'] == '123456789'
    assert hardware.facts['lpar_info'] == '1'

# Generated at 2022-06-16 23:57:06.065921
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['firmware_version'] == 'IBM,8233-E8B'
    assert dmi_facts['product_serial'] == '0123456789ABCDEF'
    assert dmi_facts['lpar_info'] == '1 CEC(s)'
    assert dmi_facts['product_name'] == 'IBM,8233-E8B'


# Generated at 2022-06-16 23:57:14.585648
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)

    device_facts = hardware.get_device_facts()

    assert device_facts['devices']
    assert device_facts['devices']['ent0']
    assert device_facts['devices']['ent0']['state'] == 'Available'
    assert device_facts['devices']['ent0']['type'] == 'Ethernet Adapter (l-lan)'
    assert device_facts['devices']['ent0']['attributes']
    assert device_facts['devices']['ent0']['attributes']['alt_addr'] == '0x000000000000'
    assert device_facts['devices']['ent0']['attributes']['bus_io_addr'] == '0x000000000000'
    assert device

# Generated at 2022-06-16 23:57:23.061650
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    device_facts = hardware.get_device_facts()
    assert 'devices' in device_facts
    assert 'ent0' in device_facts['devices']
    assert 'state' in device_facts['devices']['ent0']
    assert 'type' in device_facts['devices']['ent0']
    assert 'attributes' in device_facts['devices']['ent0']
    assert 'ent0' in device_facts['devices']
    assert 'state' in device_facts['devices']['ent0']
    assert 'type' in device_facts['devices']['ent0']
    assert 'attributes' in device_facts['devices']['ent0']
    assert 'ent0' in device_facts['devices']


# Generated at 2022-06-16 23:58:57.709051
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    vgs_facts = hardware.get_vgs_facts()
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs_facts['vgs']['rootvg'][0]['pv_state'] == 'active'
    assert vgs_facts['vgs']['rootvg'][0]['total_pps'] == '546'
    assert vgs_facts['vgs']['rootvg'][0]['free_pps'] == '0'
    assert vgs_facts['vgs']['rootvg'][0]['pp_size'] == '4 megabyte(s)'

# Generated at 2022-06-16 23:59:03.206378
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector._platform == 'AIX'
    assert hardware_collector._fact_class == AIXHardware


# Generated at 2022-06-16 23:59:06.195543
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector.platform == 'AIX'
    assert hardware_collector.fact_class == AIXHardware


# Generated at 2022-06-16 23:59:10.855119
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    mount_facts = hardware.get_mount_facts()
    assert mount_facts['mounts']


# Generated at 2022-06-16 23:59:20.445188
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    device_facts = hardware.get_device_facts()

# Generated at 2022-06-16 23:59:24.838158
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor'] == 'PowerPC_POWER8'
    assert cpu_facts['processor_cores'] == 1


# Generated at 2022-06-16 23:59:31.874908
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    module = AnsibleModule(argument_spec={})
    collector = AIXHardwareCollector(module=module)
    assert collector.platform == 'AIX'
    assert collector.fact_class == AIXHardware


# Generated at 2022-06-16 23:59:39.416034
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    vgs_facts = hardware.get_vgs_facts()
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs_facts['vgs']['rootvg'][0]['pv_state'] == 'active'
    assert vgs_facts['vgs']['rootvg'][0]['total_pps'] == '546'
    assert vgs_facts['vgs']['rootvg'][0]['free_pps'] == '0'
    assert vgs_facts['vgs']['rootvg'][0]['pp_size'] == '4 megabyte(s)'

# Generated at 2022-06-16 23:59:48.143676
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    mount_facts = hardware.get_mount_facts()
    assert mount_facts['mounts'] is not None
    assert mount_facts['mounts'][0]['mount'] is not None
    assert mount_facts['mounts'][0]['device'] is not None
    assert mount_facts['mounts'][0]['fstype'] is not None
    assert mount_facts['mounts'][0]['options'] is not None
    assert mount_facts['mounts'][0]['time'] is not None
    assert mount_facts['mounts'][0]['size_total'] is not None
    assert mount_facts['mounts'][0]['size_available'] is not None

# Generated at 2022-06-16 23:59:56.995855
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    hardware.populate()
    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['processor'] == 'PowerPC_POWER8'
    assert hardware.facts['processor_cores'] == 4
    assert hardware.facts['memtotal_mb'] == 8192
    assert hardware.facts['memfree_mb'] == 8192
    assert hardware.facts['swaptotal_mb'] == 4096
    assert hardware.facts['swapfree_mb'] == 4096
    assert hardware.facts['firmware_version'] == 'IBM,8247-22L'
    assert hardware.facts['product_serial'] == '123456789'
    assert hardware.facts['lpar_info'] == '1'