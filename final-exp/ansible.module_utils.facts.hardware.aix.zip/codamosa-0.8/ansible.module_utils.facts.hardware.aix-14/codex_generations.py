

# Generated at 2022-06-11 02:22:37.388023
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False)
    module.run_command = MagicMock(return_value=(0, 'Available 07-00 Processor', ''))
    hardware_collector = AIXHardwareCollector(module=module)
    cpu_facts = hardware_collector.collect().popitem()[1]
    module.run_command.assert_has_calls([call("/usr/sbin/lsdev -Cc processor")])
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor'] == 'Processor'


# Generated at 2022-06-11 02:22:49.052831
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hw = AIXHardware(module)

    rc, out, err = module.run_command("/usr/sbin/lsdev -Cc processor")
    if out:
        i = 0
        for line in out.splitlines():
            if 'Available' in line:
                if i == 0:
                    data = line.split(' ')
                    cpudev = data[0]

                i += 1
        cpu_count = int(i)

        rc, out, err = module.run_command("/usr/sbin/lsattr -El " + cpudev + " -a type")
        data = out.split(' ')
        cpu_name = data[1]


# Generated at 2022-06-11 02:22:55.955209
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    ah = AIXHardware()
    ah.module = ansible_fake_module()
    ah.populate()
    assert ah.firmware_version == 'VM002542'
    assert ah.product_serial == '1019X3G'
    assert ah.lpar_info == '1 CEC'
    assert ah.product_name == 'IBM,9117-570'



# Generated at 2022-06-11 02:23:06.334474
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    from ansible.module_utils.facts.collector import mock
    from ansible.module_utils.facts.hardware.aix import Hardware as AIXHardware
    import re

    facts = mock.MockFactCollector()
    hardware = AIXHardware(facts)
    memory_facts = hardware.get_memory_facts()

    assert isinstance(memory_facts, dict)
    assert 'memtotal_mb' in memory_facts
    assert re.match(r'[0-9]+', str(memory_facts['memtotal_mb']))
    assert 'memfree_mb' in memory_facts
    assert re.match(r'[0-9]+', str(memory_facts['memfree_mb']))
    assert 'swaptotal_mb' in memory_facts

# Generated at 2022-06-11 02:23:15.821844
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    # Init class to test
    aix_hardware = AIXHardware()
    aix_hardware.module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False
    )

    # Create test output
    out = """
memory pages
190464
real memory
2097152
virtual memory
4096536
    """

    aix_hardware.module.run_command = MagicMock(return_value=(0, out, ''))

    # Call method to test
    facts = aix_hardware.get_memory_facts()

    assert facts['memtotal_mb'] == 7981
    assert facts['memfree_mb'] == 7773



# Generated at 2022-06-11 02:23:27.008628
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    # Create a AIXHardware module class
    test_module = AnsibleModule(argument_spec={})

    # Get path of executables
    lsvg_path = test_module.get_bin_path("lsvg")
    xargs_path = test_module.get_bin_path("xargs")
    # Construct command to get free pps for all VGs
    cmd = "%s -o | %s %s -p" % (lsvg_path, xargs_path, lsvg_path)
    # Run command and get command output
    rc, out, err = test_module.run_command(cmd, use_unsafe_shell=True)
    if rc == 0 and out:
        # Create a AIXHardware object
        test_obj = AIXHardware()
        # Call get_vgs_facts method and check output

# Generated at 2022-06-11 02:23:35.767698
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    """
    Purpose: Testing get_cpu_facts method of the class AIXHardware
    This test case test the cpu information
    """
    module = AnsibleModule(argument_spec={})
    hardware_obj = AIXHardware(module)
    hardware_obj.populate()
    cpu_facts = hardware_obj.get_cpu_facts()

    # Check whether we are getting the expected cpu information
    assert cpu_facts['processor'] == 'POWER9'
    assert cpu_facts['processor_cores'] == 4
    assert cpu_facts['processor_count'] == 2


# Generated at 2022-06-11 02:23:45.912570
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    facts = AIXHardware().populate()
    # Test for basic facts
    assert facts['processor_cores'] > 0
    assert facts['processor_count'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] >= 0

    # Test for vgs and pv facts
    assert facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert facts['vgs']['rootvg'][1]['pv_name'] == 'hdisk1'
    assert facts['vgs']['testvg'][0]['pv_name'] == 'hdisk0'

# Generated at 2022-06-11 02:23:54.348618
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    # Sample output from lsps -s command
    lsps_output = [
        "Page Space Physical Volume Volume Group Size %Used Active Auto Type",
        "/dev/hd4  rootvg        314368MB   0% yes   yes  lv",
        "/dev/fslv00 rootvg        2048MB   0% yes   yes  lv",
        "",
        "",
        "Page Space Volume Group Size %Used Active Auto Type",
        "fslv00    rootvg        2048MB   0% yes   yes  lv"]

    # Sample output from lsvg command

# Generated at 2022-06-11 02:24:04.617001
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    """
    Unit tests for method get_mount_facts of class AIXHardware.
    """
    facts = AIXHardware({})
    test_cases = [
        # (mount_out_value, expected_value)
        ('/dev/hd4 / ext3 rw 0 0\n/dev/hd2 /usr jfs2 rw,log=/dev/hd8 0 0', [{'mount': '/', 'device': '/dev/hd4', 'fstype': 'ext3', 'options': 'rw', 'time': '0 0'},
                                                                           {'mount': '/usr', 'device': '/dev/hd2', 'fstype': 'jfs2', 'options': 'rw,log=/dev/hd8', 'time': '0 0'}]),
        ]

# Generated at 2022-06-11 02:24:30.777842
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-11 02:24:43.125061
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    test_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )


# Generated at 2022-06-11 02:24:52.829877
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware=AIXHardwareCollector().collect()
    assert 'memfree_mb' in hardware.keys()
    assert hardware['memfree_mb']
    assert 'memtotal_mb' in hardware.keys()
    assert hardware['memtotal_mb']
    assert 'swapfree_mb' in hardware.keys()
    assert hardware['swapfree_mb']
    assert 'swaptotal_mb' in hardware.keys()
    assert hardware['swaptotal_mb']
    assert 'processor' in hardware.keys()
    assert hardware['processor']
    assert 'processor_cores' in hardware.keys()
    assert hardware['processor_cores']
    assert 'processor_count' in hardware.keys()
    assert hardware['processor_count']
    assert 'device' in hardware.keys()
    assert hardware['device']

# Generated at 2022-06-11 02:24:58.887473
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = FakeModule()

    hardware_facts = AIXHardware(module).populate()

    assert hardware_facts['firmware_version'] == '3.9'
    assert hardware_facts['product_serial'] == '200408011000'
    assert hardware_facts['lpar_info'] == '1'
    assert hardware_facts['product_name'] == 'IBM,9131-52A'



# Generated at 2022-06-11 02:25:02.788827
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hw_collector = AIXHardwareCollector()
    assert hw_collector._platform == 'AIX'
    assert hw_collector._fact_class == AIXHardware


# Generated at 2022-06-11 02:25:10.245221
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    ans_module = AnsibleModule(argument_spec={})
    test = AIXHardware(ans_module)


# Generated at 2022-06-11 02:25:16.948061
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_collector = AIXHardwareCollector(module=module)
    hardware_facts = hardware_collector.collect()['ansible_facts']['ansible_hardware']

    assert hardware_facts['memfree_mb'] > 0, "memfree_mb is not available"
    assert hardware_facts['memtotal_mb'] > 0, "memtotal_mb is not available"
    assert hardware_facts['swapfree_mb'] > 0, "swapfree_mb is not available"
    assert hardware_facts['swaptotal_mb'] > 0, "swaptotal_mb is not available"
    assert len(hardware_facts['processor']) > 0, "processor is not available"

# Generated at 2022-06-11 02:25:27.232072
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    ps = AIXHardware({})

    attributes = ps.populate()
    assert attributes.get('processor')
    assert attributes.get('processor_cores')
    assert attributes.get('processor_count')
    assert attributes.get('memtotal_mb')
    assert attributes.get('memfree_mb')
    assert attributes.get('firmware_version')
    assert attributes.get('product_serial')
    assert attributes.get('lpar_info')
    assert attributes.get('product_name')
    assert attributes.get('swaptotal_mb')
    assert attributes.get('swapfree_mb')
    assert attributes.get('vgs')
    assert attributes.get('devices')

# Generated at 2022-06-11 02:25:36.626686
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    class FakeModule:
        def run_command(self, command):
            if command == '/usr/sbin/lsattr -El sys0 -a fwversion':
                return (0, 'fwversion IBM,8973-01', '')
            if command == '/usr/bin/lsconf':
                return (0, 'Machine Serial Number: 00EAE2\nLPAR Info: 1 VNIC\nSystem Model: IBM,7038-6M2', '')
            return (0, '', '')

        def get_bin_path(self, path):
            if path == 'lsconf':
                return '/usr/bin/lsconf'
            return None

    fake_module = FakeModule()
    ah = AIXHardware(module=fake_module)
    dmi_facts = ah.get_dmi_facts()
   

# Generated at 2022-06-11 02:25:38.729742
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector.platform == 'AIX'
    assert hardware_collector.fact_class == AIXHardware

# Generated at 2022-06-11 02:26:04.196335
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    aix_hw = AIXHardware()
    aix_hw.module = MockModule(aix_hw)
    aix_hw.module.run_command = Mock(return_value=(0, " IBM,8233-E8B\n", ""))
    facts = aix_hw.get_dmi_facts()
    assert facts['firmware_version'] == '8233-E8B'
    aix_hw.module.run_command.assert_called_with('/usr/sbin/lsattr -El sys0 -a fwversion')


# Generated at 2022-06-11 02:26:12.807550
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = os.path.join(sys.path[0], 'ansible_module_facts.py')
    module = imp.load_source('ansible_module_facts', module)
    module.params = {}
    module.exit_json = exit_json
    module.fail_json = fail_json
    module.run_command = run_command
    obj = AIXHardware(module)
    out = obj.get_cpu_facts()
    assert out['processor_count'] == 4
    assert out['processor'] == 'PowerPC_POWER7'
    assert out['processor_cores'] == 4



# Generated at 2022-06-11 02:26:25.947115
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    """
    We are requiring a 4th field here so that '/' is always the first entry
    in the dictionary
    """

# Generated at 2022-06-11 02:26:37.617838
# Unit test for method get_dmi_facts of class AIXHardware

# Generated at 2022-06-11 02:26:42.547513
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    hardware = AIXHardware()

    hardware.module = MockModule()

# Generated at 2022-06-11 02:26:52.929535
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    hardware_module = AIXHardware(dict(module=dict()))
    output = (0, "sys0 Available 00-00-00 IBM,8286-41A IBM,8286-41A\n", '')
    hardware_module.module.run_command.return_value = output

    output = (0, "firmware_version IBM,8286-41A\n", '')
    hardware_module.module.run_command.return_value = output

    output = (0, "Machine Serial Number: 06C1A\nSystem Model: IBM,8286-41A\nLPAR Info: 2 Pairs of 2.0 GHz CPUS\n", '')
    hardware_module.module.run_command.return_value = output

    facts = hardware_module.get_dmi_facts()


# Generated at 2022-06-11 02:27:03.705684
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    class TestModule():
        def __init__(self, *args, **kwargs):
            self.params = kwargs
            self.params['gather_subset'] = {'aix': 'enabled'}

        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/{0}'.format(args[0])


# Generated at 2022-06-11 02:27:14.864609
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    fake_module = FakeModule({})
    fact_class = AIXHardware(module=fake_module)

    expected = {
        "devices": {
            "loop0": {
                "state": "Available",
                "attributes": {
                    "sw_name": "compat",
                },
                "type": "Loop Device"
            },
            "rmt0": {
                "state": "Available",
                "attributes": {
                    "sw_name": "compat",
                },
                "type": "Tape Drive"
            },
            "rmt1": {
                "state": "Available",
                "attributes": {
                    "sw_name": "compat",
                },
                "type": "Tape Drive"
            },
        }
    }

    fake_module.run_command

# Generated at 2022-06-11 02:27:26.549995
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})

    class MockAIXHardware(AIXHardware):
        def __init__(self, module):
            self._module = module

        def _get_lsconf_path(self):
            return 'tests/module_utils/facts/hardware/lsconf'

        def _get_lsattr_path(self):
            return 'tests/module_utils/facts/hardware/lsattr'

    h = MockAIXHardware(module)
    dmi_facts = h.get_dmi_facts()

    assert dmi_facts['firmware_version'] == '1.1.1'
    assert dmi_facts['product_serial'] == '1234-a'
    assert dmi_facts['lpar_info'] == 'AIX test'

# Generated at 2022-06-11 02:27:37.680565
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    test_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    test_module.run_command = MagicMock(return_value=(0, '', ''))
    test_module.get_bin_path = MagicMock(return_value='/usr/bin/lsdev')

    aix_hardware_test = AIXHardware(test_module)


# Generated at 2022-06-11 02:28:21.180385
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware_collector = AIXHardwareCollector(module=module)
    hardware = hardware_collector.collect()[0]
    assert hardware.memory['memtotal_mb'] != None
    assert hardware.memory['memfree_mb'] != None
    assert hardware.memory['swapfree_mb'] != None
    assert hardware.memory['swaptotal_mb'] != None
    assert hardware.memory['memfree_mb'] <= hardware.memory['memtotal_mb']
    assert hardware.memory['swapfree_mb'] <= hardware.memory['swaptotal_mb']



# Generated at 2022-06-11 02:28:27.578390
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec=dict())
    ah = AIXHardware()
    ah.module = module
    rc, out, err = module.run_command("/usr/sbin/lsps -s")
    assert rc == 0 and out
    lines = out.splitlines()
    data = lines[1].split()
    swaptotal_mb = int(data[0].rstrip('MB'))
    percused = int(data[1].rstrip('%'))
    ah.get_vgs_facts()
    vgs = ah.facts['vgs']
    assert vgs

    assert vgs['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs['rootvg'][0]['pv_state'] == 'active'

# Generated at 2022-06-11 02:28:33.148980
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = FakeModule([])
    hardware = AIXHardware(module)

# Generated at 2022-06-11 02:28:42.075582
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    class TestModule():
        def get_bin_path(self, cmd, required=False):
            return cmd

        def run_command(self, cmd, use_unsafe_shell=False):
            return 0, test_AIXHardware_get_dmi_facts_data_out, ""
    hw = AIXHardware(TestModule())
    assert hw.get_dmi_facts() == {'lpar_info': '1 Virtual SCSI client adapter',
        'firmware_version': '16378', 'product_name': '9131-52A',
        'product_serial': '69FF2C5'}


# Sample output of lsconf on AIX

# Generated at 2022-06-11 02:28:55.186604
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    class AIXHardwareTest(AIXHardware):
        def __init__(self):
            self.module = AnsibleModuleMock('', '')

# Generated at 2022-06-11 02:29:04.389572
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    import sys
    import ansible.module_utils.facts.hardware.aix as aix_hw_facts
    hw_obj = aix_hw_facts.AIXHardware()
    hw_obj.module = sys

# Generated at 2022-06-11 02:29:08.893021
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    aix_hc = AIXHardwareCollector()
    assert aix_hc._platform == 'AIX'
    assert aix_hc.platform == 'AIX'
    assert aix_hc._fact_class == AIXHardware
    assert aix_hc.fact_class == AIXHardware



# Generated at 2022-06-11 02:29:19.328779
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_collector = AIXHardwareCollector(module=module)
    facts = hardware_collector.collect(module=module, collected_facts={})

    assert facts['processor_count'] == 96
    assert facts['processor'] == 'PowerPC_POWER8'
    assert facts['processor_cores'] == 24
    assert facts['memtotal_mb'] == 1048576
    assert facts['memfree_mb'] == 1048576
    assert facts['swaptotal_mb'] == 314368
    assert facts['swapfree_mb'] == 314368
    assert facts['firmware_version'] == 'P8='
    assert facts['product_serial'] == '712345678'
    assert facts['lpar_info'] == '1 lpar2'

# Generated at 2022-06-11 02:29:28.760322
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    test = AIXHardware()
    test_input = """IBM,8205-E6D
Machine Serial Number...........1234567
Part Number...........................00
EC Level..............................F0
Machine Type..........................001
Model..................................123
Processor Id..........................I1234567
LPAR Info..............................1C-123
FW Version.............................I1234567
System Model....................IBM,8205-E6D"""

    class ModuleStub:
        def __init__(self):
            self.run_command_args = None

        def run_command(self, cmd, use_unsafe_shell=False):
            self.run_command_args = cmd
            return 0, test_input, "error"

        def get_bin_path(self, path):
            pass

    test.module = ModuleStub()
    expected

# Generated at 2022-06-11 02:29:39.244684
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    class AnsibleModuleMock():
        def __init__(self):
            self.run_command_params = []
            self.run_command_results = [
                                           [0, '', '']
                                       ]

        def set_run_command_result(self, result):
            self.run_command_results = result

        def run_command(self, cmd, use_unsafe_shell=False):
            self.run_command_params.append(cmd)
            return self.run_command_results.pop(0)

        def get_bin_path(self, cmd, required=False):
            return cmd

    aix_hardware = AIXHardware(AnsibleModuleMock())


# Generated at 2022-06-11 02:31:18.031806
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    '''Unit test for method get_dmi_facts of class AIXHardware'''
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    aix_hardware = AIXHardware()
    aix_hardware.module.run_command = MockCommand('./unit/aix-dmi-facts.txt')
    out = {'firmware_version': '7.12',
           'lpar_info': '3700-M10',
           'product_name': 'iSeries',
           'product_serial': '0123456789'}
    assert out == aix_hardware.get_dmi_facts()


# Generated at 2022-06-11 02:31:24.029732
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    """
    Test get_dmi_facts method when facts are gathering.
    """
    module = AnsibleModule(argument_spec={})
    facts = AIXHardware().get_dmi_facts()

    # result is correctly gathered?
    assert isinstance(facts['firmware_version'], str), \
        'Firmware version is not a string'
    assert isinstance(facts['product_serial'], str), \
        'Product serial is not a string'
    assert isinstance(facts['lpar_info'], str), \
        'Logical partition information is not a string'
    assert isinstance(facts['product_name'], str), \
        'Product name is not a string'


# Generated at 2022-06-11 02:31:26.835025
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector_obj = AIXHardwareCollector()

    assert hardware_collector_obj.platform == 'AIX'
    assert hardware_collector_obj.fact_class == AIXHardware

# Generated at 2022-06-11 02:31:35.051284
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    import os
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.six import PY3

    mock_module = type('ansible.module_utils.facts.hardware.aix.AnsibleModule',
                       (object,), {'run_command': AnsibleModule_run_command})()
    mock_module.params = {}

    module = os.path.join(os.path.dirname(__file__),
                          'unit/ansible/module_utils/facts/hardware/aix/lsdev_Cc_processor')
    with open(module, 'r') as f:
        lsdev_output = f.read()

# Generated at 2022-06-11 02:31:39.749886
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    hardware_collector = AIXHardwareCollector(module)
    hardware = hardware_collector.collect()[0]

    assert hardware.get('processor_count') == 1
    assert hardware.get('processor_cores') == 2
    assert hardware.get('processor') == 'PowerPC_POWER8'



# Generated at 2022-06-11 02:31:47.664808
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    set_module_args({})
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    host_obj = AIXHardware()
    hosts = {}
    host_obj.populate(hosts=hosts)
    vgs_facts = host_obj.get_vgs_facts()
    assert vgs_facts['vgs']['rootvg'][1]['pv_name'] == 'hdisk1'
    assert vgs_facts['vgs']['rootvg'][1]['pv_state'] == 'active'
    assert vgs_facts['vgs']['rootvg'][1]['total_pps'] == '546'
    assert vgs_facts['vgs']['rootvg'][1]['free_pps'] == '113'
    assert vgs_

# Generated at 2022-06-11 02:31:53.191040
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    """This method unit test get_vgs_facts of class AIXHardware."""
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    aix_hardware = AIXHardware()
    print(aix_hardware.get_vgs_facts())


if __name__ == '__main__':
    test_AIXHardware_get_vgs_facts()

# Generated at 2022-06-11 02:32:00.401715
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    """
    Test get_device_facts method of AIXHardware class
    """
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    module = basic.AnsibleModule(argument_spec={})

    m = AIXHardware(module)

# Generated at 2022-06-11 02:32:02.341273
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    module = AnsibleModule(argument_spec={})
    collector = AIXHardwareCollector(module=module)

# Generated at 2022-06-11 02:32:12.338604
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware_collector = AIXHardwareCollector(module=module)
    hardware = hardware_collector.collect()[0]