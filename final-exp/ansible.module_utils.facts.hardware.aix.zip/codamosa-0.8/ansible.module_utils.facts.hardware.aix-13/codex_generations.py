

# Generated at 2022-06-11 02:22:35.574051
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    hardware = AIXHardware(module=module)
    hardware.collect()
    mount_facts = hardware.get_mount_facts()
    assert mount_facts['mounts']
    assert mount_facts['mounts'][0]['mount']

# Generated at 2022-06-11 02:22:47.522635
# Unit test for method get_mount_facts of class AIXHardware

# Generated at 2022-06-11 02:22:59.721712
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import default_collector

    aix_get_dmi_facts = AIXHardware(basic.AnsibleModule(argument_spec={}))
    lsconf_path = '/usr/bin/lsconf'

# Generated at 2022-06-11 02:23:09.838550
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    # Prepare module
    module = AnsibleModule(argument_spec={})

    # Prepare class
    aix_hardware = AIXHardware(module)

    # Prepare lsdev output

# Generated at 2022-06-11 02:23:19.116534
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    hardware = AIXHardware(module=module)
    mount_facts = hardware.get_mount_facts()
    mounts = mount_facts['mounts']

    assert mounts[0]['mount'] == '/'
    assert mounts[0]['device'] == '/dev/hd4'
    assert mounts[0]['fstype'] == 'jfs2'
    assert mounts[0]['options'] == 'rw,log=/dev/hd8'
    assert mounts[0]['size_available'] > 0
    assert mounts[0]['size_total'] > 0
    assert mounts[0]['uuid'] == '0ca334f8-0f9a-4c3f-bf16-a8d0c1e1428b'



# Generated at 2022-06-11 02:23:29.632995
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    import os
    import tempfile
    from ansible.module_utils.facts.hardware.aix import AIXHardware

    # prepare tmp file for mount command output
    temp_file = tempfile.NamedTemporaryFile(mode='wt', delete=False)

# Generated at 2022-06-11 02:23:40.723916
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    class OptionsModule:
        def __init__(self):
            self.binary_replace = False

    class ModuleMock:
        def __init__(self):
            self.params = {}
            self.options = OptionsModule()
            self.run_command = run_command


# Generated at 2022-06-11 02:23:42.210095
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hw = AIXHardwareCollector()
    assert hw.collect() is not None

# Generated at 2022-06-11 02:23:49.013354
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={
        'gather_subset': dict(default=['!all'], type='list')
    })

    hardware = AIXHardware(module)

    cpu_facts = hardware.get_cpu_facts()

    assert cpu_facts['processor_count'] == 4
    assert cpu_facts['processor'] == 'PowerPC_POWER8'
    assert cpu_facts['processor_cores'] == 8



# Generated at 2022-06-11 02:24:00.763072
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    hardware = AIXHardware()

    hardware.module = MockModule()
    hardware.module.run_command.return_value = (0, "proc0 Available 00-00 Processor", "")

    facts = hardware.get_cpu_facts()

    assert facts['processor_count'] == 1

    hardware.module.run_command.return_value = (0, "proc0 Available 00-00 Processor\nproc1 Available 00-01 Processor\nproc2 Available 00-02 Processor", "")

    facts = hardware.get_cpu_facts()

    assert facts['processor_count'] == 3

    # No processor entry
    hardware.module.run_command.return_value = (0, "", "")

    facts = hardware.get_cpu_facts()

    assert facts['processor_count'] == 0



# Generated at 2022-06-11 02:24:23.301383
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    test_instance = AIXHardware(dict())
    test_out = test_instance._get_cpu_facts()
    assert test_out['processor_count'] == 2
    assert 'PowerPC' in test_out['processor']
    assert test_out['processor_cores'] == 1


# Generated at 2022-06-11 02:24:32.559166
# Unit test for method get_memory_facts of class AIXHardware

# Generated at 2022-06-11 02:24:38.487145
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    """Unit test for constructor of class AIXHardwareCollector"""
    aix_hardware_collector = AIXHardwareCollector()
    assert isinstance(aix_hardware_collector, AIXHardwareCollector)
    assert aix_hardware_collector._platform == 'AIX'
    assert aix_hardware_collector._fact_class == AIXHardware


# Generated at 2022-06-11 02:24:48.211359
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = AIXHardware(module)
    vgs_facts = hardware.get_vgs_facts()
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk1'
    assert vgs_facts['vgs']['rootvg'][0]['pv_state'] == 'active'

    # check data after deleting a PV and adding it again to the VG
    del vgs_facts['vgs']['rootvg'][0]
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs_facts['vgs']['rootvg'][0]['pv_state'] == 'active'
    vgs_

# Generated at 2022-06-11 02:24:55.581730
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    obj = AIXHardware(dict())

# Generated at 2022-06-11 02:25:01.863776
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.exit_json = exit_json
    module.fail_json = fail_json
    aix = AIXHardware(module)
    facts = aix.get_device_facts()
    assert facts['devices']
    #assert facts['devices'].values()[0]['state']
    #assert facts['devices'].values()[0]['type']
    #assert facts['devices'].values()[0]['attributes']

# Generated at 2022-06-11 02:25:13.210410
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    aixhw = AIXHardware()
    aixhw.module.run_command = MagicMock(return_value=(0, 'IBM,8233-E8B', ''))
    aixhw.module.get_bin_path = MagicMock(return_value='/usr/sbin/lsconf')
    aixhw.module.run_command = MagicMock(return_value=(0, 'Machine Serial Number:     999999999', ''))
    aixhw.module.run_command = MagicMock(return_value=(0, 'LPAR Info:                1 LPAR(S)', ''))
    aixhw.module.run_command = MagicMock(return_value=(0, 'System Model:             IBM,8233-E8B', ''))
    facts = aixhw.get_dmi_facts()

# Generated at 2022-06-11 02:25:25.536412
# Unit test for method get_memory_facts of class AIXHardware

# Generated at 2022-06-11 02:25:30.510380
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = type("Module", (), {"run_command": fake_run_command})
    aix_h = AIXHardware(module)

    aix_h.get_mount_facts()

    # get_mount_facts should call run_command with the mount path
    assert module.run_command.call_args[0][0] == 'mount'



# Generated at 2022-06-11 02:25:39.286344
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware({}, module)

    hardware.module.run_command = MagicMock()

    out_lsdev = '''ent0 Available 00-00-00-00-00-00
ent1 Defined 00-00-00-00-00-01
ent2 Available 00-00-00-00-00-02
ip0 Available 00-00-00-80-80-80
ip1 Available 00-00-00-80-80-81
lo0 Available None
lo1 Available None'''
    hardware.module.run_command.return_value = 0, out_lsdev, ''


# Generated at 2022-06-11 02:26:15.801927
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    simple_aix_hardware = AIXHardware()
    assert simple_aix_hardware.get_dmi_facts()['lpar_info'] == '1 HMC MANAGED'


# Generated at 2022-06-11 02:26:25.370654
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    """
    Test that class AIXHardware can be instantiated and method populate
    creates correct number of facts.
    """
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    hardware_facts = AIXHardware()
    ansible_module = BaseFactCollector()
    ansible_module.run_command = lambda x: (0, x, '')
    hardware_facts.populate(ansible_module)
    assert len(hardware_facts._fact_ids) == 12

# Generated at 2022-06-11 02:26:37.134752
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    # Test output of lsvg -p command
    out = """rootvg:
PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
hdisk0            active            546         0           00..00..00..00..00
hdisk1            active            546         113         00..00..00..21..92
realsyncvg:
PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
hdisk74           active            1999        6           00..00..00..00..06
testvg:
PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
hdisk105          active            999         838         200..39..199..200..200
hdisk106          active            999         599         200..00..00..199..200
"""


# Generated at 2022-06-11 02:26:46.936927
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    facts = hardware.populate()

    assert facts['firmware_version'] == 'IBM,8233-E8B'
    assert facts['product_name'] == '8233-E8B'
    assert facts['product_serial'] == 'YCP7J0235'
    assert facts['lpar_info'] == '1 ENT 4105 Metal'
    assert facts['vgs'] == {}
    assert facts['mounts'] == []
    assert facts['devices'] == {}
    assert facts['memtotal_mb'] == 8192
    assert facts['memfree_mb'] == 768
    assert facts['processor_count'] == 4
    assert facts['swaptotal_mb'] == 262144

# Generated at 2022-06-11 02:26:58.060608
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    ah = AIXHardware(module)


# Generated at 2022-06-11 02:27:07.973179
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    from ansible.module_utils.facts.hardware.aix import _get_lb_mapping_expanded
    module = AnsibleModule(argument_spec={'get_device_facts': dict(type='bool')})
    hardware_obj = AIXHardware(module)
    result = hardware_obj.get_device_facts()
    # Check that a dictionary is returned
    assert isinstance(result, dict)
    # Check that there are devices
    assert len(result['devices'].keys()) > 0
    # Check that all devices have attributes
    for dev in result['devices'].keys():
        # Check that all devices have state
        assert 'state' in result['devices'][dev].keys()
        # Check that all devices have type
        assert 'type' in result['devices'][dev].keys()
        # Check that all devices have

# Generated at 2022-06-11 02:27:14.539825
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware

    hardware = AIXHardware()
    hardware.module = None

    vgs_facts = hardware.get_vgs_facts()

    if isinstance(vgs_facts, dict):
        if 'vgs' in vgs_facts:
            ret = True
        else:
            ret = False
    else:
        ret = False

    assert ret == True

# Generated at 2022-06-11 02:27:18.924703
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    module = AnsibleModuleMock()
    obj = AIXHardwareCollector(module)
    assert obj.platform == 'AIX'
    assert obj.fact_class == AIXHardware
    assert obj.command_loader_class == AIXCommandLoader



# Generated at 2022-06-11 02:27:27.582131
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = Hardware(module=module)

    # Create device_facts dict
    devices_facts = {'devices': {}}
    devices_facts['devices']['fcs0'] = {
        'state': 'Available',
        'type': 'Flags:  1 Port Adapter',
        'attributes': {'adapter_type': 'fcp', 'node_name': 'a'}
    }

    # Get device facts
    result = hardware.get_device_facts()

    # Test compare results
    assert(result == devices_facts)



# Generated at 2022-06-11 02:27:31.899420
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware_obj = AIXHardware(module)
    dmi_facts = hardware_obj.get_dmi_facts()

    module.exit_json(ansible_facts=dict(dmi_facts=dmi_facts))


# Generated at 2022-06-11 02:28:54.701780
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = {"run_command": lambda x: (0, "", "")}
    hardware = AIXHardware(module)

    # Test get_device_facts
    lsdev_cmd = hardware.module.get_bin_path('lsdev', True)
    lsattr_cmd = hardware.module.get_bin_path('lsattr', True)
    rc, out_lsdev, err = hardware.module.run_command(lsdev_cmd)

    for line in out_lsdev.splitlines():
        field = line.split()

        device_attrs = {}
        device_name = field[0]
        device_state = field[1]
        lsattr_cmd_args = [lsattr_cmd, '-E', '-l', device_name]
        rc, out_lsattr, err = hardware.module.run_

# Generated at 2022-06-11 02:29:01.609879
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    check_mode = module.check_mode
    if check_mode:
        module.exit_json(changed=False)
    else:
        aixhw = AIXHardware(module)
        dmi_facts = aixhw.get_dmi_facts()
        aixhw.exit_json(changed=False, ansible_facts=dmi_facts)


# Generated at 2022-06-11 02:29:04.484081
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    """Test class constructor"""
    module = AnsibleModule(
        argument_spec = dict(),
    )
    result = AIXHardwareCollector(module=module)
    assert type(result) == AIXHardwareCollector


# Generated at 2022-06-11 02:29:14.634569
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    class module:
        def run_command(cmd, use_unsafe_shell=False):
            out = "/dev/hd4                 /                       jfs2         rw,log=INLINE 0       0\n" \
                  "/dev/hd2                 /usr                    jfs2         rw,log=INLINE 0       0\n" \
                  "node                   /mount_point             jfs2         rw,log=INLINE 0       0"
            return 0, out, None

        class params:
            tuning = False

        def get_bin_path(cmd, required=False):
            return cmd

    import re
    import pprint
    fake_module = module()
    hw = AIXHardware(fake_module)
    pprint.pprint(hw.get_mount_facts())

# Generated at 2022-06-11 02:29:25.050109
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})

    # Create instance of class AIXHardware
    aix_hardware = AIXHardware(module)

    # Create a command mock for lsdev command

# Generated at 2022-06-11 02:29:31.719087
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    cpu_facts = hardware.get_cpu_facts()

    assert cpu_facts['processor_count'] == 4
    assert cpu_facts['processor'] == 'PowerPC_POWER7'
    assert cpu_facts['processor_cores'] == 8



# Generated at 2022-06-11 02:29:40.740685
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():

    # empty module input
    module = Mock(params={})
    ah_instance = AIXHardware()
    ah_instance.module = module
    assert ah_instance.get_cpu_facts() == {}

    # module input with processor count
    module = Mock(params={'processor_count': 2})
    ah_instance = AIXHardware()
    ah_instance.module = module
    assert ah_instance.get_cpu_facts() == {'processor_count': 2}

    # module input with processor count and processor cores
    module = Mock(params={'processor_count': 2, 'processor_cores': 4})
    ah_instance = AIXHardware()
    ah_instance.module = module
    assert ah_instance.get_cpu_facts() == {'processor_count': 2,
                                           'processor_cores': 4}

# Generated at 2022-06-11 02:29:49.177319
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    this_module = sys.modules[__name__]
    this_module.module = MagicMock()
    this_module.module.get_bin_path.return_value = 'mount'
    this_module.module.run_command.return_value = (0,
                                                   '/dev/hd4       /           jfs2     log       yes     rw,log=/dev/hd8\nhd2:/export/home /home      nfs       rw\nnfs.oak.oakland.edu:/dir1/dir2 on /dir1/dir2 type cifs (rw)\n',
                                                   '')
    aix = AIXHardware()
    result = aix.get_mount_facts()

# Generated at 2022-06-11 02:29:53.101435
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all', '!min'], type='list')
        ),
        supports_check_mode=True
    )
    aix_hardware = AIXHardware()
    aix_hardware.module = module
    aix_hardware.gather_device_facts(module.params)
    aix_hardware.module.exit_json()


# Generated at 2022-06-11 02:29:59.386369
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    """
    Test a variety of mount lines to make sure the regex is correct.
    """
