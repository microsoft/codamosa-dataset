

# Generated at 2022-06-11 02:22:39.773207
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AIXHardware()

    # Test when no mount_out
    mount_out = []
    mount_facts = module.get_mount_facts(mount_out)
    assert mount_facts == {'mounts': []}

    # Test a normal mount

# Generated at 2022-06-11 02:22:49.993314
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    """ Unit test for mount facts.

    1. Different mount point- fstype- fs device mapping
    2. nfs mount point- with no attr
    3. nfs mount point- with attr
    4. cifs mount point- no attr
    5. cifs mount point- with attr

    """
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    import json

    # 1. Different mount point- fstype- fs device mapping

# Generated at 2022-06-11 02:23:00.752716
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})

    # mock module input parameters
    module.params = {'gather_subset': ['all']}

    # initialize hardware object
    hardware = AIXHardware(module)

    # set collected facts to empty dict
    module.exit_json.update({'ansible_facts': {}})

    # read return values from populate method
    hardware.populate()

    # fetch ansible_facts
    result = module.exit_json['ansible_facts']

    # check if values are matched
    assert result['hardware']['memory']['memtotal_mb'] == 16384
    assert result['hardware']['memory']['memfree_mb'] == 16384



# Generated at 2022-06-11 02:23:10.600947
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts import FactCache
    from ansible.module_utils._text import to_text

    # For test case we will mock class method run_command of class Hardware, method run_commad
    # will return a tuple for output and error, based on input value for command
    AIXHardware.run_command = lambda self, command: None, None, None
    memfree_bytes = 1048576
    memtotal_bytes = 1048576

    # Case 1: vmstat not found
    # Case 2: vmstat return empty
    # Case 3: vmstat return no memory and free pages
    # Case 4: vmstat return memory and free pages
    # Case 5: vmstat return memory and free pages and swapinfo not found
    # Case

# Generated at 2022-06-11 02:23:18.503945
# Unit test for method get_device_facts of class AIXHardware

# Generated at 2022-06-11 02:23:29.236478
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    class MockModule:
        class MockRunCommand:
            @staticmethod
            def __init__(self, rc=0, out="", err=""):
                self.rc = rc
                self.out = out
                self.err = err

            @staticmethod
            def run_command(self, cmd, use_unsafe_shell=False):
                return self.rc, self.out, self.err

        @staticmethod
        def get_bin_path(self, mode, opt_dirs=[]):
            return '/bin/' + mode

        @staticmethod
        def run_command(self, cmd, use_unsafe_shell=False):
            return self.MockRunCommand.run_command(self, cmd, use_unsafe_shell)


# Generated at 2022-06-11 02:23:35.655203
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    mock_module = MockModule()
    obj = AIXHardware(module=mock_module, collected_facts=None)
    obj.get_memory_facts()
    assert mock_module.run_command.call_args_list == [call("/usr/bin/vmstat -v"),
                                                      call("/usr/sbin/lsps -s")]

# Generated at 2022-06-11 02:23:45.730807
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    h = Hardware()
    h.module = AnsibleModuleMock()

# Generated at 2022-06-11 02:23:52.799948
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['all'], type='list')
        ),
        supports_check_mode=True)

    if not HAS_AIX_UTILS:
        module.fail_json(msg='Error: Required aix-rte is missing')

    # Populate the instance
    aixhw = AIXHardware(module)
    aixhw.populate()

    module.exit_json(
        ansible_facts=dict(
            aixhw=dict(aixhw.facts)
        )
    )



# Generated at 2022-06-11 02:23:57.120774
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    AIX_hw_obj = AIXHardware({})
    dmi_facts = AIX_hw_obj.get_dmi_facts()
    assert dmi_facts



# Generated at 2022-06-11 02:24:18.688734
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hw_facts_instance = AIXHardware(module)
    facts_dic = hw_facts_instance.populate()

    assert facts_dic is not None
    assert facts_dic['ansible_facts'] is not None



# Generated at 2022-06-11 02:24:29.003342
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(gather_subset=dict(default=[], type='list')),
        supports_check_mode=True)

    h = AIXHardware(module=module)
    results = h.populate()
    assert 'vendor' in results
    assert 'product_name' in results
    assert 'firmware_version' in results
    assert 'processor' in results
    assert 'processor_cores' in results
    assert 'processor_count' in results
    assert 'memtotal_mb' in results
    assert 'memfree_mb' in results
    assert 'swaptotal_mb' in results
    assert 'swapfree_mb' in results
    assert 'vgs' in results
    assert 'rootvg' in results['vgs']
    assert 'devices' in results


# Generated at 2022-06-11 02:24:41.490246
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    from ansible.module_utils import basic
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils._text import to_bytes

    module = basic.AnsibleModule(
        argument_spec={},
    )

    if not module.HAS_AIX_LIBRARIES:
        module.fail_json(msg="aix_libs is required")

    hardware_collection = [to_bytes('''
IBM,8204-E8A
''')]

    lsconf_collection = [to_bytes('''
System Model: IBM,8204-E8A
Machine Serial Number: 06E3D2F
LPAR Info: 1 POSIX Conformant
''')]


# Generated at 2022-06-11 02:24:46.889084
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    aix_collector = AIXHardwareCollector(module)
    assert isinstance(aix_collector, AIXHardwareCollector)
    assert isinstance(aix_collector.collect(), dict)
    assert "ansible_processor_vcpus" in aix_collector.collect()


# Generated at 2022-06-11 02:24:49.862815
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    collector = AIXHardwareCollector(module=module)
    assert collector.platform == 'AIX'

# Generated at 2022-06-11 02:24:57.282491
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    """
    Test that the method get_memory_facts from class AIXHardware works correctly
    :return:
    """
    test_obj = AIXHardware()

    test_obj.module = MockModule()
    test_obj.module.run_command.return_value = 0, "memory pages:  44838\nfree pages:  188\n", ""

    expected_result = {"memtotal_mb": 179, "memfree_mb": 0}

    result = test_obj.get_memory_facts()

    assert expected_result == result

# Generated at 2022-06-11 02:25:09.534867
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    # Unit test for method get_cpu_facts() of class AIXHardware
    #
    test_hw = AIXHardware()
    test_hw.module = MockModule()

    # output of /usr/sbin/lsdev -Cc processor

# Generated at 2022-06-11 02:25:16.743842
# Unit test for method get_memory_facts of class AIXHardware

# Generated at 2022-06-11 02:25:21.224485
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    """Test AIXHardwareCollector"""

    hardware_collector = AIXHardwareCollector()
    assert hardware_collector._platform == 'AIX'
    assert hardware_collector._fact_class == AIXHardware


# Generated at 2022-06-11 02:25:31.783162
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule()
    hardware = AIXHardware(module)

    # In this case correct mount command output is generated
    mount_path = hardware.module.get_bin_path('mount')
    rc, mount_out, err = hardware.module.run_command(mount_path)
    if mount_out:
        for line in mount_out.split('\n'):
            fields = line.split()
            if len(fields) != 0 and fields[0] != 'node' and fields[0][0] != '-' and re.match('^/.*|^[a-zA-Z].*|^[0-9].*', fields[0]):
                if re.match('^/', fields[0]):
                    # normal mount
                    mount = fields[1]

# Generated at 2022-06-11 02:26:14.452631
# Unit test for method get_mount_facts of class AIXHardware

# Generated at 2022-06-11 02:26:15.544725
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    AIXHardwareCollector()

# Generated at 2022-06-11 02:26:28.225523
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    class FakeModule(object):
        def run_command(self, cmd):
            cmd = cmd.strip()
            assert cmd == '/usr/sbin/lsps -s'

# Generated at 2022-06-11 02:26:34.922683
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)

    # Create test files for each fact
    hardware_facts = hardware.populate()
    for key, value in hardware_facts.items():
        with open('../../../lib/ansible/module_utils/facts/hardware/aix/%s' % key, 'w') as f:
            f.write(json.dumps(value))


# Generated at 2022-06-11 02:26:36.684427
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    assert isinstance(AIXHardwareCollector(), HardwareCollector)

# Generated at 2022-06-11 02:26:46.364578
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    hardware = AIXHardware(module=module)
    vgs_facts = hardware.get_vgs_facts()  # Create dict of dicts

# Generated at 2022-06-11 02:26:57.169886
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    class TestModule:
        def __init__(self, params):
            self.params = params
            self.run_command_calls = []

        def run_command(self, cmd, use_unsafe_shell=False, check_rc=True):
            rc = 0
            out = ""
            err = ""
            self.run_command_calls.append(cmd)
            if cmd == "/usr/sbin/mount":
                rc = 0
                out = """
    Mounting /usr
    /usr:
            Device         Mountpoint      FStype  Options     Dump    Pass    MntRef  #Mnt
            /dev/hd4       /usr            jfs     rw,log=/dev/hd8        1       1      5345
"""

            return rc, out, err
    module = TestModule(params={})

# Generated at 2022-06-11 02:27:05.331871
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = ('!all')
    hw = AIXHardware(module=module)
    result = hw.populate()
    for item in result['vgs']['vgs']['rootvg']:
        assert item.get('pv_state') == 'active'
        assert item.get('pp_size') is not None
        assert item.get('pv_name') is not None
        assert item.get('free_pps') is not None
        assert item.get('total_pps') is not None

    return True


# Generated at 2022-06-11 02:27:10.526737
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] >= 0
    assert facts['swaptotal_mb'] >= 0
    assert facts['swapfree_mb'] >= 0

# Generated at 2022-06-11 02:27:13.888881
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule({})

    hw = AIXHardware()

    # pylint: disable=protected-access
    hw.module = module

    hw.get_dmi_facts()



# Generated at 2022-06-11 02:28:33.897287
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    datadir = os.path.join(os.path.dirname(__file__), 'data')
    class module:
        class run_command(object):
            pass

    module.run_command = lambda s: (0, open(os.path.join(datadir, 'mount_data.txt')).read(), '')
    hardware = AIXHardware(module)
    mount_facts = hardware.get_mount_facts()
    assert mount_facts['mounts'][0]['device'] == 'none'
    assert mount_facts['mounts'][0]['fstype'] == 'procfs'
    assert mount_facts['mounts'][0]['mount'] == '/proc'
    assert mount_facts['mounts'][0]['options'] == 'rw,noexec,nosuid,nodev'

# Generated at 2022-06-11 02:28:41.705381
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware_facts_obj = AIXHardware(module)
    device_facts = hardware_facts_obj.get_device_facts()
    assert device_facts['devices']['fcs0']['state'] == 'Available'
    assert device_facts['devices']['fcs0']['type'] == '64-bit PCI FC Adapter (df1000f9)'
    assert device_facts['devices']['fcs0']['attributes']['bus_id'] == '0'
    module.exit_json(ansible_facts=device_facts)



# Generated at 2022-06-11 02:28:55.135272
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    import json
    import textwrap

    module = FakeModule()


# Generated at 2022-06-11 02:28:58.110683
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    collector = AIXHardwareCollector()
    assert collector._platform == 'AIX'
    assert collector._fact_class == AIXHardware

# Generated at 2022-06-11 02:29:07.599566
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule({})
    aix_hw = AIXHardware(module)

# Generated at 2022-06-11 02:29:18.175905
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():

    def run_command_side_effect(*args, **kwargs):
        out = ''

# Generated at 2022-06-11 02:29:20.720032
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    """
    Test for method get_mount_facts of class AIXHardware
    """
    module = AnsibleModule(argument_spec=dict())
    ah = AIXHardware(module)
    mount_facts = ah.get_mount_facts()
    assert mount_facts

# Generated at 2022-06-11 02:29:29.660833
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    hardware = AIXHardware()
    hardware.module = MockModule()
    hardware.module.run_command.return_value = (0, "IBM,8233-E8B  MEMORY: 2.00 GB    DISK: 2.0 TB    CPU: 4 x POWER8, 3.42 GHz", '')
    res = hardware.get_dmi_facts()
    assert 'firmware_version' in res
    assert res['firmware_version'] == '8233-E8B'
    assert 'product_serial' not in res
    assert 'product_name' not in res
    assert 'lpar_info' not in res


# Generated at 2022-06-11 02:29:39.809741
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    from ansible.module_utils.facts.processor.aix import AIXProcessor
    from ansible.module_utils.facts.processor.aix import get_processor_info
    from ansible.module_utils.facts.system.aix import AIXSystem
    from ansible.module_utils.facts.system.aix import get_system_info

    hardware_instance = AIXHardware()
    processor_class = AIXProcessor()
    system_class = AIXSystem()

    hardware_instance.module = AnsibleModuleMock()
    processor_class.module = AnsibleModuleMock()
    system_class.module = AnsibleModuleMock()

    processor_class.module.run_command = run_command_mock_processor
    system_class.module.run_command = run_command_mock_system
   

# Generated at 2022-06-11 02:29:42.269753
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    d = AIXHardwareCollector()
    assert d._platform == 'AIX'
    assert d._fact_class == AIXHardware