

# Generated at 2022-06-11 02:22:30.516167
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    AIXHardwareCollector.collect()

# Generated at 2022-06-11 02:22:33.923918
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hc = AIXHardwareCollector()
    assert hc._platform == "AIX"
    assert hc._fact_class == AIXHardware
    assert hc._fact_class().platform == "AIX"



# Generated at 2022-06-11 02:22:46.448569
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    lsdev_cmd = '/usr/sbin/lsdev'
    lsattr_cmd = '/usr/sbin/lsattr'
    lsdev_out = """name              status
fcs0              Available
eth0              Available
proc0             Available
proc4             Defined
proc8             Defined
proc12            Defined"""


# Generated at 2022-06-11 02:22:59.445346
# Unit test for method get_cpu_facts of class AIXHardware

# Generated at 2022-06-11 02:23:09.580278
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )


# Generated at 2022-06-11 02:23:13.274367
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    collector = AIXHardwareCollector()
    assert collector.__class__.__name__ == 'AIXHardwareCollector'
    assert collector.fact_class == AIXHardware
    assert collector.fact_subclasses == {}
    assert collector.platform == 'AIX'


# Generated at 2022-06-11 02:23:20.799155
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    # Create a fake module
    class FakeModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs
            self.failed = False

        def fail_json(self, *args, **kwargs):
            self.failed = True

        def run_command(self, cmd, use_unsafe_shell=False):
            rc = 0
            out = ""
            err = ""
            if cmd == 'lsvg -o':
                out = "rootvg\nrealsyncvg\ntestvg\n"

# Generated at 2022-06-11 02:23:30.419004
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    class AIXHardware(object):
        def __init__(self, module):
            self.module = module


# Generated at 2022-06-11 02:23:33.141064
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hw = AIXHardware(module)
    hw.populate()

# Generated at 2022-06-11 02:23:42.218140
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    facts = AIXHardware(module).populate()

    expected_cpu_facts = {
        'processor_count': 1,
        'processor_cores': 4,
        'processor': 'PowerPC_POWER8'
    }
    assert facts['processor'] == expected_cpu_facts['processor']
    assert facts['processor_cores'] == expected_cpu_facts['processor_cores']
    assert facts['processor_count'] == expected_cpu_facts['processor_count']

    # No real way to determine what these will be (unless we run an emulator)
    # so we'll just check that they are present
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'swaptotal_mb' in facts

# Generated at 2022-06-11 02:24:04.032777
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = AIXHardware(module)
    hardware_obj.populate()
    assert hardware_obj.facts['processor_count'] >= 0
    assert hardware_obj.facts['memtotal_mb'] >= 0
    assert hardware_obj.facts['memfree_mb'] >= 0

# AnsibleModule boilerplate

# Generated at 2022-06-11 02:24:14.131272
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    def get_bin_path(name, required=False):
        return '/bin/%s' % name

    _module = Mock()
    _module.get_bin_path.side_effect = get_bin_path
    _module.run_command.return_value = (0, '', '')

    _host_name = 'host_name'

    hp = AIXHardwareCollector(_module, _host_name)

    assert hp.module == _module
    assert hp.host_name == _host_name
    assert 'memfree_mb' in hp.facts
    assert 'memtotal_mb' in hp.facts
    assert 'swapfree_mb' in hp.facts
    assert 'swaptotal_mb' in hp.facts
    assert 'processor' in hp.facts

# Generated at 2022-06-11 02:24:18.361092
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    """
    Unit test for method get_device_facts of class AIXHardware
    """
    test_module = AnsibleModule(argument_spec={})

    hd = AIXHardware()
    hd.module = test_module

    hd.get_device_facts()

# Generated at 2022-06-11 02:24:28.764491
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    '''
    Test module for dmi_facts
    '''
    from ansible.module_utils.facts.hardware.aix import AIXHardware

    class AIXHardwareModule(AIXHardware):
        '''
        Test class for AIXHardware
        '''
        def __init__(self):
            self.module = AnsibleModuleMock()

    class AnsibleModuleMock:
        '''
        Test class for AnsibleModule
        '''
        def __init__(self):
            pass

        def run_command(self, command, use_unsafe_shell=False):
            '''
            Mock function which returns expected out and err
            '''
            return 0, EXPECTED_OUT, ''


# Generated at 2022-06-11 02:24:41.323091
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.utils import get_mount_size

    m = AIXHardware({})


# Generated at 2022-06-11 02:24:45.152098
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    """
    Test for class AIXHardware method get_memory_facts
    """
    assert AIXHardware.get_memory_facts(None) == {'memtotal_mb': 0, 'memfree_mb': 0, 'swaptotal_mb': 0, 'swapfree_mb': 0}

# Generated at 2022-06-11 02:24:48.777412
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    """
    Unit test for constructor of class AIXHardwareCollector
    """
    hc = AIXHardwareCollector()
    assert hc.platform == 'AIX'
    assert issubclass(hc.fact_class, AIXHardware)


# Generated at 2022-06-11 02:24:50.838706
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    hardware_obj = AIXHardware(dict())
    hardware_obj.populate()
    assert hardware_obj.hw_facts['processor_count'] == 16

# Generated at 2022-06-11 02:25:01.247212
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    hardware = AIXHardware()
    hardware.module = MagicMock()

# Generated at 2022-06-11 02:25:04.667104
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    ahc = AIXHardwareCollector()
    assert ahc._platform == 'AIX'
    assert ahc._fact_class == AIXHardware

# Generated at 2022-06-11 02:25:45.575221
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    # no mount command found
    mock_module = MagicMock()
    mock_module.get_bin_path.return_value = None
    aix_hardware = AIXHardware(mock_module)
    result = aix_hardware.get_mount_facts()
    assert ('mounts' in result) and (len(result['mounts']) == 0)

    # mount command is present but no mounts currently
    mock_module = MagicMock()
    mock_module.get_bin_path.return_value = 'mount'
    mock_module.run_command.return_value = (0, 'node', '')
    aix_hardware = AIXHardware(mock_module)
    result = aix_hardware.get_mount_facts()

# Generated at 2022-06-11 02:25:56.381931
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware_fact = AIXHardware(module)


# Generated at 2022-06-11 02:26:06.181073
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    # Simulate subprocesses
    mock_run_commands = []
    print('Running lsdev -Cc processor')
    mock_run_commands.append([0, 'proc0 Available 00-00 Processor\nproc1 Available 00-01 Processor', None])
    print('Running lsattr -El proc0 -a type')
    mock_run_commands.append([0, 'type PowerPC_POWER6 False', None])
    print('Running lsattr -El proc0 -a smt_threads')
    mock_run_commands.append([0, 'smt_threads 1 False', None])
    print('vmstat -v')

# Generated at 2022-06-11 02:26:10.400383
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec=dict())
    aix_hardware = AIXHardware(module=module)
    mount_facts = aix_hardware.get_mount_facts()
    assert mount_facts['mounts']



# Generated at 2022-06-11 02:26:18.467497
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = AIXHardware(module)
    hardware_obj.populate()

    assert hardware_obj.facts['processor_count'] == 1
    assert hardware_obj.facts['processor'] == 'PowerPC_POWER7'
    assert hardware_obj.facts['processor_cores'] == 2
    assert hardware_obj.facts['memtotal_mb'] == 69632
    assert hardware_obj.facts['memfree_mb'] == 53988
    assert hardware_obj.facts['firmware_version'] == '7.9.9.9'
    assert hardware_obj.facts['product_serial'] == '1234567890ABCDEF'
    assert hardware_obj.facts['product_name'] == 'System p'

# Generated at 2022-06-11 02:26:31.098187
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    ah = AIXHardware()
    # Generate the output from command /usr/sbin/lsdev -Cc processor
    out = """proc0 Available 00-00 Processor
proc2 Available 00-02 Processor
proc4 Available 00-04 Processor
proc6 Available 00-06 Processor
proc8 Available 00-08 Processor
proc10 Available 00-0A Processor
proc12 Available 00-0C Processor
proc14 Available 00-0E Processor"""
    ah.module.run_command = lambda x, **kwargs: (0, out, '')

    processor_facts = ah.get_cpu_facts()
    assert 'processor_count' in processor_facts
    assert processor_facts['processor_count'] == 8
    assert 'processor' in processor_facts
    assert processor_

# Generated at 2022-06-11 02:26:33.163031
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    hardware_obj = AIXHardware({})
    hardware_obj.populate()



# Generated at 2022-06-11 02:26:42.107960
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec=dict())

    hardware_object = AIXHardware(module)
    mount_facts = hardware_object.get_mount_facts()
    mount_facts_list = mount_facts['mounts']
    for mount_fact in mount_facts_list:
        assert mount_fact['mount'] is not None
        assert mount_fact['device'] is not None
        assert mount_fact['fstype'] is not None
        assert mount_fact['options'] is not None
        assert mount_fact['time'] is not None
        assert mount_fact['size_total'] is not None
        assert mount_fact['size_available'] is not None
        assert mount_fact['size_used'] is not None
        assert mount_fact['size_percent'] is not None

# Generated at 2022-06-11 02:26:52.639672
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    # Initalize module
    module = AnsibleModule(argument_spec={})

    # Set up mock of class AIXHardware
    hardware_mock = MagicMock(spec=AIXHardware)

    # Get output of lsdev -Cc processor command
    lsdev_path = module.get_bin_path("lsdev")

    rc, out, err = module.run_command(lsdev_path + " -Cc processor")
    if out:
        i = 0
        for line in out.splitlines():

            if 'Available' in line:
                if i == 0:
                    data = line.split(' ')
                    cpudev = data[0]

                i += 1
        processor_count = int(i)


# Generated at 2022-06-11 02:27:00.743559
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    import json
    import argparse
    parser = argparse.ArgumentParser(description='get_dmi_facts')
    parser.add_argument('--argh', dest='argh')
    parser.add_argument('--args', dest='args')
    args = parser.parse_args()
    module_args = json.loads(args.argh)

    from ansible.module_utils.facts.hardware.aix import AIXHardware
    aix_hw = AIXHardware(module_args)

    print(aix_hw.get_dmi_facts())


# Generated at 2022-06-11 02:28:13.416405
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    collector = AIXHardwareCollector()
    assert collector.platform == 'AIX'
    assert collector.fact_class == AIXHardware


# Generated at 2022-06-11 02:28:24.961002
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():

    obj = AIXHardware()

    # Testing method get_memory_facts of class AIXHardware when vmstat output
    # is expected
    out = """memory pages
    page count          =        396032
    page size           =         4096
    total size          =      164086784
    free pages          =         63490
    free pages nz       =         63490"""
    rc = 0
    err = ''
    obj.module.run_command = Mock(return_value=(rc, out, err))

    # Testing method get_memory_facts of class AIXHardware when swapinfo output
    # is expected
    out_swap = """Device          1M-blocks     Used    Avail Capacity
    /dev/ada0p3        314368        0   314368     0%"""

# Generated at 2022-06-11 02:28:34.767569
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec=dict()
    )

    module.run_command = Mock(return_value=(0, "sys0    U787E.001.DQ18478-P1-C4-T1-L88        IBM,8233-E8B       IBM,P50 0604ABSW  IBM,0820601A")
    )

    h = AIXHardware(module)
    assert h.get_dmi_facts() == {'firmware_version': 'P50 0604ABSW', 'product_serial': '0820601A', 'product_name': '8233-E8B'}

# Generated at 2022-06-11 02:28:38.378817
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    result = hardware.get_memory_facts()
    assert result["memtotal_mb"]
    assert result["memfree_mb"]
    assert result["swaptotal_mb"]
    assert result["swapfree_mb"]

# Generated at 2022-06-11 02:28:42.436132
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    # Call AIXHardware class module_utils.facts.hardware.aix.get_cpu_facts() method
    out = AIXHardware().get_cpu_facts()
    print(out)


# Generated at 2022-06-11 02:28:54.453405
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    hw = AIXHardware(module)

    # mock vgs output
    hw.module.run_command = MagicMock(return_value=(0, test_vgs, ""))

    vgs_facts = hw.get_vgs_facts()
    assert vgs_facts['vgs']['rootvg'] == test_aix_rootvg_vgs
    assert vgs_facts['vgs']['realsyncvg'] == test_aix_realsyncvg_vgs
    assert vgs_facts['vgs']['testvg'] == test_aix_testvg_vgs



# Generated at 2022-06-11 02:29:01.732693
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    facts = AIXHardware({}).get_memory_facts()
    assert type(facts) is dict
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert int(facts['memtotal_mb']) >= 0
    assert int(facts['memfree_mb']) >= 0
    assert int(facts['swaptotal_mb']) >= 0
    assert int(facts['swapfree_mb']) >= 0

# Generated at 2022-06-11 02:29:11.812606
# Unit test for method get_vgs_facts of class AIXHardware

# Generated at 2022-06-11 02:29:22.469592
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    ah = AIXHardware()
    vgs_facts = ah.get_vgs_facts()
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs_facts['vgs']['rootvg'][0]['pv_state'] == 'active'
    assert vgs_facts['vgs']['rootvg'][0]['total_pps'] == '546'
    assert vgs_facts['vgs']['rootvg'][0]['free_pps'] == '0'
    assert vgs_facts['vgs']['rootvg'][0]['pp_size'] == '4 megabyte(s)'
    assert vgs_facts

# Generated at 2022-06-11 02:29:29.102923
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    class MockModule():
        def get_bin_path(self, module_name, required=False):
            return module_name

        def run_command(self, cmd, use_unsafe_shell=False):
            return 0, cmd, None

    class MockFacts():
        def __init__(self):
            self.data = {}

    test_obj = AIXHardware(MockModule(), MockFacts())
    data = test_obj.get_vgs_facts()
    assert len(data['vgs']['realsyncvg']) == 1
    assert len(data['vgs']['testvg']) == 2