

# Generated at 2022-06-11 02:22:31.070679
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    x = AIXHardwareCollector()
    assert x._platform == 'AIX'

# Generated at 2022-06-11 02:22:39.535346
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    # Reference values of facts:
    # 'mounts': [{'mount': '/foo',
    #             'device': '/dev/bar',
    #             'fstype': 'fstype',
    #             'options': 'rw',
    #             'time': 'dd MMM hh:mm',
    #             'size_total': 1234567,
    #             'size_available': 1222222}]

    # Faker module mock objects:
    fake = Faker()
    fake.seed(0)
    mount = fake.file_path()
    device = fake.file_path()
    fstype = fake.file_name()
    options = fake.file_extension()
    dd = fake.day_of_month()
    mm = fake.month_name()
    hh = fake.hour()

# Generated at 2022-06-11 02:22:41.885200
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hw = AIXHardwareCollector()
    assert hw.platform == 'AIX'
    assert hw._fact_class == AIXHardware



# Generated at 2022-06-11 02:22:51.233199
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    result = {}

    lsdev_cmd = module.get_bin_path('lsdev', True)

    rc, out, err = module.run_command(lsdev_cmd)
    if rc == 0:
        result['lsdev'] = out

    lsconf_cmd = module.get_bin_path('lsconf', True)
    rc, out, err = module.run_command(lsconf_cmd)
    if rc == 0:
        result['lsconf'] = out

    lsattr_cmd = module.get_bin_path('lsattr', True)
    rc, out, err = module.run_command(lsattr_cmd)
    if rc == 0:
        result['lsattr'] = out


# Generated at 2022-06-11 02:22:52.885149
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()

    assert hardware_collector is not None

# Generated at 2022-06-11 02:23:02.983716
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    class fake_module(object):
        def __init__(self):
            self.params = None
            self.params = {
                'path': '/usr/bin/'
            }

        def get_bin_path(self, executable, required=False):
            if executable == 'lsvg':
                return '/usr/sbin/lsvg'
            elif executable == 'xargs':
                return '/usr/bin/xargs'
            else:
                return None


# Generated at 2022-06-11 02:23:08.947537
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    """
    Test the get_dmi_facts method of class AIXHardware
    """
    module = MockModule()
    hardware = AIXHardware(module)
    # Create an object for testing the method get_dmi_facts
    dmi_facts = hardware.get_dmi_facts()
    # Check the value of dmi_facts['firmware_version']
    assert dmi_facts['firmware_version'] == 'IBM,306F0DD0'
    # Check the value of dmi_facts['lpar_info']
    assert dmi_facts['lpar_info'] == '1 PVM (AIX 7.1)'
    # Check the value of dmi_facts['product_name']
    assert dmi_facts['product_name'] == 'IBM,9117-575'
    # Check the value

# Generated at 2022-06-11 02:23:17.480385
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    # Initialize the test module
    module = AnsibleModule(argument_spec={})
    module.run_command = mock.Mock(return_value=(0, '', ''))
    module.get_bin_path = mock.Mock(return_value='/bin/lsdev')
    module.read_file = mock.Mock(return_value='\n'.join(['name1 Available       00-00        en0                    Ethernet Network I/F',
                                                         'name2 Defined        00-01        en1                    Ethernet Network I/F',
                                                         'name3 Defined        00-02        en2                    Ethernet Network I/F']))
    # Initialize the AIXHardware Object 
    aix_hardware = AIXHardware(module=module)
    # Assert the facts on get_device_facts
    assert a

# Generated at 2022-06-11 02:23:23.947675
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module=module)
    cpu_facts = hardware.get_cpu_facts()
    assert ('processor_count' in cpu_facts)
    assert ('processor' in cpu_facts)
    assert ('processor_cores' in cpu_facts)
    module.exit_json(ansible_facts=dict(hardware=cpu_facts))


# Generated at 2022-06-11 02:23:26.696519
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    facts = {}
    collector = AIXHardwareCollector(facts)
    assert collector.platform == 'AIX'
    assert collector._fact_class == AIXHardware

# Generated at 2022-06-11 02:23:53.164175
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    import pytest
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils import basic

    # Create an instance of AIXHardware to use it in unit test
    class module_args():
        pass
    module_args.filter = None
    module_args.gather_subset = 'all'
    module_args.checked = None
    module_args.gather_network_resources = None
    module = basic.AnsibleModule(argument_spec={})
    module.args = module_args
    ah = AIXHardware(module)

    cmd = ah.module.get_bin_path('mount')

    import re.sub
    rc, out, err = ah.module.run_command(cmd)
    # When running from a xterm:
    # node mounted

# Generated at 2022-06-11 02:23:56.899417
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    my_AIXHardwareCollector = AIXHardwareCollector()
    assert my_AIXHardwareCollector.platform == 'AIX'
    assert my_AIXHardwareCollector.fact_class == AIXHardware


# Generated at 2022-06-11 02:24:04.148909
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    aixhardware = AIXHardware({})
    out = '''proc0 Available 00-00 Processor
proc1 Available 00-01 Processor'''
    aixhardware.module.run_command.return_value = (0, out, '')
    aixhardware.get_cpu_facts()
    assert aixhardware.facts['processor_cores'] == 1
    assert aixhardware.facts['processor_count'] == 2
    assert aixhardware.facts['processor'] == 'PowerPC_POWER8'


# Generated at 2022-06-11 02:24:08.773344
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = AIXHardware(module)
    mount_facts = hardware.get_mount_facts()
    assert mount_facts == {'mounts': []}


# Generated at 2022-06-11 02:24:10.294710
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    assert AIXHardwareCollector._platform == 'AIX'

# Generated at 2022-06-11 02:24:20.740568
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    '''Return a set of CPU facts for a given system'''
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    hardware_mock = AIXHardware(module)

    # Test with multiple processor and multiple core
    module.run_command = Mock(return_value=(0, "proc0 Available 00-00-04-00-00-00 Processor\nproc1 Available 00-00-04-00-00-01 Processor", ""))
    module.run_command.side_effect = [(0, "type PowerPC_POWER8", ""), (0, "smt_threads 4", "")]
    hardware_mock.get_cpu_facts()
    assert module.run_command.call_count == 1
    assert module.exit_json.called
    assert module

# Generated at 2022-06-11 02:24:30.818930
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    """
    :return: False if unit test failed, True if unit test success
    """
    from ansible.module_utils import basic
    from ansible.module_utils.facts import hardware

    failed = False
    hardware_collector = hardware.HardwareCollector()
    hardware_collector.collect()
    hardware_facts = hardware_collector.get_facts()
    if 'vgs' not in hardware_facts or 'testvg' not in hardware_facts['vgs']:
        basic.fail_json(msg="Unit test of AIXHardware.get_vgs_facts failed")
    if len(hardware_facts['vgs']['testvg']) != 2:
        basic.fail_json(msg="Unit test of AIXHardware.get_vgs_facts failed")


# Generated at 2022-06-11 02:24:41.907408
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)

    facts = hardware.populate()

    assert 'memfree_mb' in facts
    assert 'memtotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'firmware_version' in facts
    assert 'lpar_info' in facts
    assert 'product_name' in facts
    assert 'product_serial' in facts
    assert 'vgs' in facts
    assert 'mounts' in facts


# Generated at 2022-06-11 02:24:45.662684
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module=module)

    dmi_facts = hardware.get_dmi_facts()
    assert 'firmware_version' in dmi_facts



# Generated at 2022-06-11 02:24:53.541140
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    mem_facts = {
        'memtotal_mb': 12288,
        'memfree_mb': 124,
        'swaptotal_mb': 4096,
        'swapfree_mb': 4095
    }
    # run command "vmstat -v" via module's run_command method
    # and return a tuple of rc, stdout, stderr
    lsps_cmd = '/usr/sbin/lsps -s'
    module = AnsibleModuleMock(run_command=lambda cmd: (0, '5Mb', ''))
    hardware = AIXHardware(module=module)
    result = hardware.get_memory_facts()

    assert result == mem_facts



# Generated at 2022-06-11 02:25:35.811469
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})

    module.run_command = Mock(return_value=(0, 'IBM,8233-E8B', ''))
    module.get_bin_path = Mock(return_value='/usr/sbin/lsconf')
    module.run_command = Mock(return_value=(0, '''
Machine Type: IBM,8233-E8B
Machine Serial Number: 06E0319
LPAR Info: 1 0 0 00
Part Number: 2113-540
Machine Model: IBM,8233-E8B
System Model: IBM,8233-E8B
''', ''))

    hardware = AIXHardware(module)
    dmi_facts = hardware.get_dmi_facts()

    assert dmi_facts['product_serial'] == '06E0319'

# Generated at 2022-06-11 02:25:37.540872
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    assert 'devices' in AIXHardware.get_device_facts(None)
    assert 'devices' in AIXHardware.get_device_facts(None)['devices']

# Generated at 2022-06-11 02:25:39.356613
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hc = AIXHardwareCollector()
    assert hc.platform == 'AIX'
    assert hc.fact_class == AIXHardware

# Generated at 2022-06-11 02:25:45.378028
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    class AIXHardware(object):

        def __init__(self, module):
            self.module = module

        def populate(self, collected_facts=None):
            hardware_facts = {}

            hardware_facts['processor_cores'] = 2
            hardware_facts['processor_count'] = 2

            return hardware_facts

    hw_obj = AIXHardware(None)
    facts = hw_obj.populate()
    assert facts['ansible_processor_cores'] == 2
    assert facts['ansible_processor_count'] == 2
    assert facts['ansible_processor'][0]['cores'] == 2
    assert facts['ansible_processor'][0]['threads'] == 2
    assert facts['ansible_processor'][0]['vcpus'] == 2

# Generated at 2022-06-11 02:25:54.488057
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    # Test function for method get_dmi_facts of class AIXHardware
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    if not module.check_mode:
        dmi_facts = AIXHardware().get_dmi_facts()

    dmi_facts_expected = {'firmware_version': '8245-22L IBM,8245C1L', 'product_serial': '23A25ZBW', 'lpar_info': '1 CEC 2 CPU', 'product_name': 'IBM,8245-22L'}

    assert dmi_facts == dmi_facts_expected

# Generated at 2022-06-11 02:26:05.125949
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    out_lsvg = """rootvg:
        PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
        hdisk0            active            546         0           00..00..00..00..00
        hdisk1            active            546         113         00..00..00..21..92
        realsyncvg:
        PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
        hdisk74           active            1999        6           00..00..00..00..06
        testvg:
        PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
        hdisk105          active            999         838         200..39..199..200..200
        hdisk106          active            999         599         200..00..00..199..200"""
    out_

# Generated at 2022-06-11 02:26:15.549885
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware_object = AIXHardware(module)
    rc, out, err = module.run_command("/usr/sbin/lsdev -Cc processor")
    if out:
        i = 0
        for line in out.splitlines():

            if 'Available' in line:
                if i == 0:
                    data = line.split(' ')
                    cpudev = data[0]

                i += 1
        cpu_count = int(i)

        rc, out, err = module.run_command("/usr/sbin/lsattr -El " + cpudev + " -a type")

        data = out.split(' ')
        cpu_model = data[1]


# Generated at 2022-06-11 02:26:24.018751
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    # Create module which will be used in AIXHardware class
    module = AnsibleModule(argument_spec={})

    # Create instance of AIXHardware class
    my_hw = AIXHardware(module)

    # Retrieve data from method get_device_facts
    data = my_hw.get_device_facts()

    # Check if data is empty
    assert data

    # Check if device_facts key is present
    assert 'devices' in data

    # Check if devices contains any devices
    assert data['devices']

# Generated at 2022-06-11 02:26:36.063596
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    test_out = """sys0                System\t\t\tAvailable\t00-00\t\tIBM,8286-41A            Firmware V7R3M0 06/29/2017"""
    test_facts = AIXHardware()
    dmi_facts = test_facts.get_dmi_facts(test_out)

    assert 'firmware_version' in dmi_facts
    assert 'lpar_info' in dmi_facts
    assert 'product_name' in dmi_facts
    assert 'product_serial' in dmi_facts

    assert dmi_facts['firmware_version'] == 'V7R3M0'
    assert dmi_facts['lpar_info'] == '00-00'
    assert dmi_facts['product_name'] == '8286-41A'


# Generated at 2022-06-11 02:26:45.831235
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    test_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    test_module.params = {}
    test_module.run_command = MagicMock(return_value=(0, 'IBM,8233-E8B   \n', None))
    test_module.get_bin_path = MagicMock(return_value='/usr/sbin/lsconf')
    test_module.run_command = MagicMock(side_effect=[
        (0, "Machine Serial Number:\t\tU0G6U62\n", None),
        (0, "LPAR Info:\t1\tMAX\tENT\t2\tMIN\tENT", None),
        (0, "System Model:\tIBM,8286-42A", None)
    ])

# Generated at 2022-06-11 02:27:53.758362
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    assert AIXHardwareCollector._platform == 'AIX'
    assert AIXHardwareCollector._fact_class == AIXHardware

# Generated at 2022-06-11 02:27:58.434202
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    test_module = AnsibleModuleMock()
    test_module.run_command = run_command_mock
    test_module.get_bin_path = get_bin_path_mock

    aix_hardware = AIXHardware(module=test_module)
    assert aix_hardware.get_dmi_facts() == {'firmware_version': '3.1 (3.1.0.0)',
                                            'product_serial': '000D5A5E5BEF',
                                            'lpar_info': '4C1C49084C1C4908',
                                            'product_name': 'IBM,7044-AC1'}



# Generated at 2022-06-11 02:28:08.931237
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    lsdevinfo = """
proc0 Available 00-00 Processor
proc1 Available 00-01 Processor
proc2 Available 00-02 Processor
proc3 Available 00-03 Processor
    """
    proc0 = 'proc0'
    lsvariable_stdout = 'type: PowerPC_POWER7'

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    def mock_run_command(command, use_unsafe_shell=False):
        if command == '/usr/sbin/lsdev -Cc processor':
            return 0, lsdevinfo, ''
        if command == '/usr/sbin/lsattr -El %s -a type' % proc0:
            return 0, lsvariable_stdout, ''

# Generated at 2022-06-11 02:28:21.828537
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    module.check_mode = False
    hardware = AIXHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor'] == 'PowerPC_POWER7'
    assert hardware_facts['processor_cores_per_package'] == 1
    assert hardware_facts['processor_count'] == 16
    assert hardware_facts['processor_threads_per_core'] == 2
    assert hardware_facts['memtotal_mb'] == 48064
    assert hardware_facts['memfree_mb'] == 28422
    assert hardware_facts['swaptotal_mb'] == 32
    assert hardware_facts['swapfree_mb'] == 31

# Generated at 2022-06-11 02:28:33.119364
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    class Module(object):
        def run_command(self, *args, **kwargs):
            class Result(object):
                def __init__(self, content):
                    self.content = content
                def splitlines(self):
                    return self.content.splitlines()

# Generated at 2022-06-11 02:28:41.363124
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    class Object:
        pass

    module = Object()

# Generated at 2022-06-11 02:28:54.701058
# Unit test for method get_vgs_facts of class AIXHardware

# Generated at 2022-06-11 02:28:59.588231
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})

    hardware_obj = AIXHardware(module)

    hardware_obj.get_memory_facts()

    assert hardware_obj.facts['memfree_mb'] >= 0
    assert hardware_obj.facts['swapfree_mb'] >= 0



# Generated at 2022-06-11 02:29:08.761386
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    vgs_facts = hardware.get_vgs_facts()
    assert vgs_facts['vgs'] is not None
    assert len(vgs_facts['vgs']) >= 0
    assert vgs_facts['vgs']['rootvg'] is not None
    assert len(vgs_facts['vgs']['rootvg']) >= 0
    assert vgs_facts['vgs']['rootvg'][0]['free_pps'] is not None
    assert vgs_facts['vgs']['rootvg'][0]['free_pps'] >= 0
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] is not None

# Generated at 2022-06-11 02:29:12.321164
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    assert AIXHardware().get_memory_facts() == {'memfree_mb': 767, 'memtotal_mb': 1278, 'swapfree_mb': 0, 'swaptotal_mb': 0}