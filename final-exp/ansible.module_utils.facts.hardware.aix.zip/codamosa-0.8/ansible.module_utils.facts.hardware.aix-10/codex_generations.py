

# Generated at 2022-06-11 02:22:32.126559
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    os_hw = AIXHardwareCollector()
    assert os_hw.platform == 'AIX'
    assert os_hw.fact_class == AIXHardware

# Generated at 2022-06-11 02:22:40.164731
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = FakeAnsibleModule()
    aix_hw = AIXHardware(module)
    aix_hw.module.run_command = FakeRunCommand(aix_hw.module)

    aix_hw.module.run_command.set_command('lsdev', '0', 'hdisk0          Available           00-01-2', 'stderr')
    aix_hw.module.run_command.set_command('lsattr', '0', '', 'stderr')

    aix_hw.module.run_command.set_command('lsdev', '0', 'hdisk1          Defined             00-01-2', 'stderr')
    aix_hw.module.run_command.set_command('lsattr', '0', '', 'stderr')

    aix_hw.module.run

# Generated at 2022-06-11 02:22:50.234372
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    class MockAIXHardware(AIXHardware):
        def __init__(self):
            self.module = AnsibleModule
            self.module.get_bin_path = lambda cmd, opt=False: cmd

# Generated at 2022-06-11 02:22:56.119947
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    expected_facts = {'processor': 'PowerPC_POWER8',
                      'processor_count': 8,
                      'processor_cores': 1}
    aix_hardware = AIXHardware(None)
    cpu_facts = aix_hardware.get_cpu_facts()
    assert cpu_facts == expected_facts


# Generated at 2022-06-11 02:23:06.653420
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    aix_hardware = AIXHardware({})
    # Create a test mounts object
    mounts = [{"mount": "/tmp", "device": "/dev/hd4", "fstype": "jfs2", "options": "rw,log=/dev/hd8", "time": "Fri Dec 21, 23:47"}]
    # Create a test device object
    devices = {}
    devices['devices'] = {}
    devices['devices']['hdisk0'] = {'state': 'Available', 'type': 'Generic FC SCSI Disk Drive', 'attributes': {'dev_size': '500 GB'}}
    # Populate a return object
    aix_hardware_facts = {}
    aix_hardware_facts['mounts'] = mounts
    aix_hardware_facts['devices'] = devices
    # Run test mount and device

# Generated at 2022-06-11 02:23:16.734261
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = MagicMock()
    result = {}
    # Expected vgs_facts

# Generated at 2022-06-11 02:23:27.828340
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    hw = AIXHardware(module=module)
    hw.populate()

    assert 'memtotal_mb' in hw.facts
    assert 'memfree_mb' in hw.facts
    assert 'swaptotal_mb' in hw.facts
    assert 'swapfree_mb' in hw.facts
    assert 'processor_count' in hw.facts
    assert 'processor' in hw.facts
    assert 'processor_cores' in hw.facts
    assert 'firmware_version' in hw.facts
    assert 'product_serial' in hw.facts
    assert 'lpar_info' in hw.facts
    assert 'product_name' in hw.facts

# Generated at 2022-06-11 02:23:29.369691
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    assert {} == AIXHardware(None, None).get_mount_facts()

# Generated at 2022-06-11 02:23:30.333967
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    pass

# Generated at 2022-06-11 02:23:40.099064
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():

    line = '/dev/fslv01 /nls                    jfs2       rw,log   fake,intr,largefiles,compress=on,delwri=0,wsext=disable   0       0'
    fields = line.split()
    if len(fields) != 8:
        fields.append("")

    mount_info = {'mount': fields[1],
                  'device': '%s:%s' % (fields[0], fields[1]),
                  'fstype': fields[2],
                  'options': fields[7],
                  'time': '%s %s %s' % (fields[4], fields[5], fields[6])}
    print(mount_info)



# Generated at 2022-06-11 02:24:06.123723
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    """
    This function returns a dictionary containing the test results.
    The keys 'counters', 'skipped', 'failed', 'ok' and 'exceptions'
    are used by the Ansible test module.
    """
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import ansible.module_utils.facts.hardware.aix  # pylint: disable=import-error
    import json

    testcases = [
        {
            'stdout': b"""
abc0 Defined
abc1 Defined
"""
        },
        {
            'stdout': b"""
abc0 Defined
abc1 Defined
abc2 Defined
abc3 Defined
"""
        }
    ]


# Generated at 2022-06-11 02:24:09.638071
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(
        argument_spec={}
    )

    hw_ins = AIXHardware({})
    hw_ins.module = module

    hw_ins.populate()

    assert module.exit_json.called

# Generated at 2022-06-11 02:24:20.319874
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware_facts = AIXHardware(module)

    # When "lsdev" command return with error
    hardware_facts.module.run_command.return_value = (1, "", "")
    assert hardware_facts.get_device_facts() == {'devices': {}}

    # When "lsdev" command return with "no such devices"
    hardware_facts.module.run_command.return_value = (0, "", "")
    assert hardware_facts.get_device_facts() == {'devices': {}}

    # When "lsdev" command return with no more than two fields on any line
    hardware_facts.module.run_command.return_value = (0, "device_a available hardware\ndevice_b available hardware", "")
    assert hardware_facts

# Generated at 2022-06-11 02:24:22.738463
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector.fact_class == AIXHardware



# Generated at 2022-06-11 02:24:26.093432
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    facts_collector = AIXHardwareCollector()

    # Test platform set
    assert(facts_collector.platform == 'AIX')

    # Test fact class set
    assert(facts_collector.fact_class == AIXHardware)



# Generated at 2022-06-11 02:24:37.302326
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():

    with open(os.path.join(sys.path[0], 'fixture', 'AIX', 'lsdev_-Cc_processor_0'), 'r') as f:
        lsdev_processor_0 = f.read()

    with open(os.path.join(sys.path[0], 'fixture', 'AIX', 'lsattr_-El_proc0_type_0'), 'r') as f:
        lsattr_proc0_type_0 = f.read()

    with open(os.path.join(sys.path[0], 'fixture', 'AIX', 'vmstat_-v_0'), 'r') as f:
        vmstat_0 = f.read()


# Generated at 2022-06-11 02:24:47.459582
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():

    # test case with no attributes
    lsdev_out = """ent8 Available 10/100/1000-Base-T Ethernet Adapter (l-lan)
ent9 Available 10/100/1000-Base-T Ethernet Adapter (l-lan)
ent10 Available 10/100/1000-Base-T Ethernet Adapter (l-lan)
ent11 Available 10/100/1000-Base-T Ethernet Adapter (l-lan)"""

    test_tools = {'lsdev': 'lsdev',
                  'lsattr': 'lsattr'}
    test_module = MagicMock()

    test_module.get_bin_path.side_effect = lambda tool, opt=False: test_tools[tool]
    test_module.run_command.side_effect = [(0, lsdev_out, ''), (0, '', '')]

    aix_hw = AI

# Generated at 2022-06-11 02:24:55.200492
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    class MockModule(object):
        def __init__(self, module_name):
            self.module_name = module_name
            self.params = {}

        def get_bin_path(self, executable):
            return '/usr/bin/' + executable

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception(kwargs['msg'])

        def run_command(self, cmd, **kwargs):
            if self.lsvg_path_cmd == cmd:
                return (0, '/usr/bin/lsvg', None)

# Generated at 2022-06-11 02:25:01.600978
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    test_module = AnsibleModule(argument_spec=dict())
    test_AIXHardware = AIXHardware(module=test_module)
    test_vgs_facts = test_AIXHardware.get_vgs_facts()
    assert 'vgs' in test_vgs_facts
    assert 'rootvg' in test_vgs_facts['vgs']
    assert 'realsyncvg' in test_vgs_facts['vgs']
    assert 'testvg' in test_vgs_facts['vgs']

# Generated at 2022-06-11 02:25:05.005632
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    collector = AIXHardwareCollector()
    assert isinstance(collector._fact_class, AIXHardware)


# Generated at 2022-06-11 02:25:47.476324
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = FakeModule()
    aix_hardware = AIXHardware(module)
    aix_hardware.populate()

    module.run_command.assert_has_calls([
        mock.call("/usr/bin/vmstat -v"),
        mock.call("/usr/sbin/lsps -s")
    ])

    assert aix_hardware.facts['memtotal_mb'] == 8192
    assert aix_hardware.facts['memfree_mb'] == 2048
    assert aix_hardware.facts['swaptotal_mb'] == 4096
    assert aix_hardware.facts['swapfree_mb'] == 1024



# Generated at 2022-06-11 02:25:50.095105
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hw = AIXHardwareCollector()
    assert hw._platform == 'AIX'
    assert hw._fact_class == AIXHardware

# Generated at 2022-06-11 02:25:52.889243
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    aix_hw = AIXHardwareCollector()
    assert AIXHardware == aix_hw._fact_class
    assert 'AIX' == aix_hw._platform

# Generated at 2022-06-11 02:26:04.116970
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_args = None
            self.run_command_rc = 0
            self.run_command_stdout = ''
            self.run_command_stderr = ''

        def get_bin_path(self, arg, opt_dirs=[]):
            return '/usr/sbin/mount'

        def run_command(self, args, check_rc=True, close_fds=True, executable=None,
                        data=None, binary_data=False, path_prefix=None, cwd=None,
                        use_unsafe_shell=False, prompt_regex=None):

            self.run_command_args = args
            return self.run_command_rc, self.run_command_std

# Generated at 2022-06-11 02:26:13.418353
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts.utils import FactsParams
    from ansible.module_utils.facts.utils import AnsibleModuleMock

    test_module = AnsibleModuleMock(return_values={
        'run_command.return_value': ('', 'memory pages:        74993989\n'
                                         'free pages:         44820847', '')})

    hardware = AIXHardware(module=test_module)
    assert hardware.get_memory_facts() == {'memtotal_mb': 299935, 'memfree_mb': 175928}


# Generated at 2022-06-11 02:26:21.625073
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    ahfacts = AIXHardware(module)
    facts = ahfacts.populate()
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swapfree_mb' in facts

    assert 'vgs' in facts
    assert 'devices' in facts



# Generated at 2022-06-11 02:26:34.073528
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    """Test for method get_memory_facts of class AIXHardware"""

    test_module = AnsibleModule(argument_spec={})
    test_object = AIXHardware(test_module)
    rc, out, err = test_object.module.run_command('/usr/sbin/vmstat -v')
    test_object.vmstat_output = out
    test_object.module.run_command = MagicMock(side_effect=[
        [0, '/usr/sbin/lsps -s', ''],
        [0, 'rootvg:', '']])
    test_object.get_memory_facts()
    assert test_object.facts['memtotal_mb'] == 4800
    assert test_object.facts['memfree_mb'] == 4753

# Generated at 2022-06-11 02:26:42.839802
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hw = AIXHardwareCollector.load_collector_from_file('/etc/ansible/facts.d/test_AIX_collector.fact', 'TestHost', 'test_AIXHardwareCollector')

# Generated at 2022-06-11 02:26:53.211023
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    # setup test
    reason = None
    module = FakeModule()
    hardware = AIXHardware(module)

    # initialize lsdev
    hardware._lsdev_cache = """
hdisk0 Available 00-08-00-3,0
hdisk1 Defined   00-08-00-3,1
hdisk2 Available 00-08-00-3,2
"""

    # initialize lsattr

# Generated at 2022-06-11 02:26:59.576322
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    """Test module AIXHardware"""

    # Given
    # When
    memory_facts = AIXHardware.get_memory_facts()

    # Then
    assert memory_facts is not None
    assert 'memtotal_mb' in memory_facts
    assert 'memfree_mb' in memory_facts
    assert 'swaptotal_mb' in memory_facts
    assert 'swapfree_mb' in memory_facts

# Generated at 2022-06-11 02:28:22.326096
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec=dict())

    h = AIXHardware(module=module)

    vgs_facts = h.get_vgs_facts()

    # vgs_facts = {
    # 'vgs': {
    #     'rootvg': [
    #         {'free_pps': '0',
    #          'pv_name': 'hdisk0',
    #          'pv_state': 'active',
    #          'pp_size': '4 megabyte(s)',
    #          'total_pps': '546'},
    #         {'free_pps': '113',
    #          'pv_name': 'hdisk1',
    #          'pv_state': 'active',
    #          'pp_size': '4 megabyte(s)',
    #

# Generated at 2022-06-11 02:28:33.483040
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    m = AIXHardware()

    class Object:
        pass

    m.module = Object()
    m.module.run_command = run_command
    m.module.get_bin_path = get_bin_path


# Generated at 2022-06-11 02:28:41.551491
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    from ansible.module_utils.facts.aix import AIXHardware
    from ansible.module_utils._text import to_bytes

    # original data from mount command

# Generated at 2022-06-11 02:28:54.952949
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    test_module = AnsibleModule(argument_spec=dict())

    test_module.params['gather_subset'] = ['all']

    result = {'changed': False, 'ansible_facts': {'devices': {}}}


# Generated at 2022-06-11 02:29:04.252714
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    import mock
    test_module = mock.Mock()
    test_module.run_command.return_value = (0, "", "")
    hw_facts_obj = AIXHardware(test_module)
    pop_facts = hw_facts_obj.populate()
    assert pop_facts['processor'][0] == "PowerPC_POWER8"
    assert pop_facts['processor_cores'] == 1
    assert pop_facts['processor_count'] == 8
    assert pop_facts['memfree_mb'] == 9309
    assert pop_facts['memtotal_mb'] == 16383
    assert pop_facts['swapfree_mb'] == 14596
    assert pop_facts['swaptotal_mb'] == 14596

# Generated at 2022-06-11 02:29:14.782968
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all', 'min'], type='list')
        ),
        supports_check_mode=True
    )

    if not HAS_AIX_MODULES:
        module.fail_json(msg='aix_mount_facts module is required for this test')

    hardware_collector = AIXHardwareCollector(module=module)
    hardware_module = AIXHardware(module=module)
    hardware_collector.collect(module, hardware_module)
    result = hardware_module.populate()
    assert result['mounts'][0]['mount'] == '/'
    assert result['mounts'][0]['device'] == '/dev/hd3'

# Generated at 2022-06-11 02:29:16.246198
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    collector = AIXHardwareCollector()
    assert collector.platform == 'AIX'

# Generated at 2022-06-11 02:29:24.363582
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    dmi_facts = hardware.get_dmi_facts()

    assert dmi_facts['product_name'] == 'IBM,8231-E2B'
    assert dmi_facts['product_serial'] == '123456789'
    assert dmi_facts['lpar_info'] == '1 00C9AB87C8B0 04C9AB87C8B0'
    assert dmi_facts['firmware_version'] == 'V7R3M0'



# Generated at 2022-06-11 02:29:34.004166
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    module = type('', (), {'run_command': lambda *args, **kwargs: None})
    module.params = {}
    module.params['gather_subset'] = ['min']

    hardware_collector = AIXHardwareCollector(module=module)

    assert hardware_collector.module == module
    assert hardware_collector.platform == 'AIX'
    assert hardware_collector.fact_class == AIXHardware
    assert hardware_collector.file.name == '/usr/sbin/lsdev'


# Generated at 2022-06-11 02:29:42.715189
# Unit test for method get_mount_facts of class AIXHardware