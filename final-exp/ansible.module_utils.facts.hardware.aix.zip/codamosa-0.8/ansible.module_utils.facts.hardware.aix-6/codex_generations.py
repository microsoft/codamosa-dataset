

# Generated at 2022-06-11 02:22:39.135849
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    from ansible.module_utils.facts.hardware import AIXHardware
    import tempfile
    import os

    # First create file with fake command output

    with tempfile.NamedTemporaryFile(mode="w", delete=False) as temp:
        temp.write('/dev/hd0 / jfs2 rw,log=INLINE 0 0')
        temp.flush()
    temp_file_path = os.path.realpath(temp.name)

    # Test under temp working dir
    prev_dir = os.getcwd()
    temp_dir = tempfile.mkdtemp()
    os.chdir(temp_dir)

    # Set path for fake command output
    os.environ['PATH'] = ':'.join((os.path.dirname(temp_file_path), os.environ['PATH']))



# Generated at 2022-06-11 02:22:49.843429
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts import FactManager
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils import basic
    import ansible.module_utils.facts.hardware.aix
    import platform
    import sys
    import os

    fake_platform = 'AIX'
    fake_version = '7.1'
    fake_release = '1'
    fake_machine = 'PowerPC_POWER9'

    # Save the platform, version and release fields of module os
    real_platform = sys.modules['platform'].platform
    real_version = sys.modules['platform'].version
    real_release = sys.modules['platform'].release

# Generated at 2022-06-11 02:22:57.428362
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = FakeAnsibleModule()
    hardware = AIXHardware(module)
    result = hardware.get_dmi_facts()
    assert result['product_serial'] == '{1234-5678-9012-3456}'
    assert result['product_name'] == 'IBM,9131-52A'
    assert result['firmware_version'] == 'V2.4'
    assert result['lpar_info'] == 'DefaultPartition'



# Generated at 2022-06-11 02:23:02.969342
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    f = AIXHardware()
    f.module = MockModule()
    f.module.run_command = Mock(return_value=(0, 'powerpc 0001', ''))
    data = f.get_cpu_facts()
    assert data['processor'] == 'powerpc'
    assert data['processor_count'] == 1
    assert data['processor_cores'] == 1


# Generated at 2022-06-11 02:23:11.579921
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():

    class MockRunner(object):
        def __init__(self):
            self.calls = []

        def run_command(self, command, use_unsafe_shell=False):

            self.calls.append(command)

            if command == '/usr/bin/vmstat -v':
                out = '100 memory pages\n' \
                      '200 free pages\n'
                return 0, out, None

            return 0, '', None

    class MockModule(object):
        def __init__(self):
            self.runner = MockRunner()
            self.params = {}
            self.exit_json = None
            self.fail_json = None

        def get_bin_path(self, arg, required=False):
            return "/usr/bin/%s" % arg

    ah = AIXHardware()
    ah

# Generated at 2022-06-11 02:23:13.684745
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector._platform == 'AIX'



# Generated at 2022-06-11 02:23:20.585979
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    class TestModule(object):
        def run_command(cmd):
            out = 'proc0 Available 00-00 Processor\n'
            return 0, out, None

        def get_bin_path(name):
            assert name in ('lsdev', 'lsattr', 'lsconf'), \
                   "get_bin_path is called with non-expected command as argument"
            return name

    mod = TestModule()
    aix_hardware = AIXHardware(mod)
    cpu_facts = aix_hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor'] == '00-00'
    assert cpu_facts['processor_cores'] == 1



# Generated at 2022-06-11 02:23:29.456174
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    aix_hw = AIXHardware(module)
    facts = aix_hw.get_cpu_facts()

    assert 'processor' in facts
    assert facts['processor_count'] > 0
    assert facts['processor_cores'] > 0
    assert facts['processor'] in ['PowerPC_POWER8', 'PowerPC_POWER9', 'PowerPC_POWER8_V2', 'PowerPC_POWER9_V2',
                                  'PowerPC_POWER7', 'PowerPC_POWER7_V2']


# Generated at 2022-06-11 02:23:40.587916
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    """
    Test method get_cpu_facts
    """
    module = AnsibleModule(argument_spec={})
    mock_values = [
                    ('/usr/sbin/lsdev -Cc processor', 'processor   0 Available 00-00-0 Processor\nprocessor   1 Available 00-00-0 Processor\nprocessor   2 Available 00-00-0 Processor\nprocessor   3 Available 00-00-0 Processor', '', 0),
                    ('/usr/sbin/lsattr -El processor0 -a type', 'type powerpc POWER5+', '', 0),
                    ('/usr/sbin/lsattr -El processor0 -a smt_threads', 'smt_threads 1', '', 0)
                  ]

    result = {'processor': 'powerpc', 'processor_cores': 1, 'processor_count': 4}



# Generated at 2022-06-11 02:23:47.626153
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    """unit test for method get_cpu_facts of class AIXHardware"""

    module_mock = FakeModule()
    aix_hw = AIXHardware(module_mock)

    cpu_facts = aix_hw.get_cpu_facts()
    expected_facts = {
        'processor': ['PowerPC_POWER8'],
        'processor_cores': 2,
        'processor_count': 4
        }

    assert cpu_facts == expected_facts


# Generated at 2022-06-11 02:24:10.453387
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    dmi_facts = AIXHardware(module).get_dmi_facts()
    assert 'firmware_version' in dmi_facts
    assert 'product_serial' in dmi_facts
    assert 'lpar_info' in dmi_facts
    assert 'product_name' in dmi_facts



# Generated at 2022-06-11 02:24:14.691371
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    info = AIXHardware()
    result = info.get_memory_facts()
    assert result['swaptotal_mb'] >= 0
    assert result['swapfree_mb'] >= 0
    assert result['memtotal_mb'] >= 0
    assert result['memfree_mb'] >= 0

# Generated at 2022-06-11 02:24:23.441654
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    '''Unit test for method get_mount_facts of class AIXHardware'''
    AIXHD = AIXHardware()
    mount_facts = AIXHD.get_mount_facts()
    assert type(mount_facts) == dict
    assert type(mount_facts['mounts']) == list
    assert mount_facts['mounts'][0]['mount'] == '/'
    assert mount_facts['mounts'][0]['device'] == '/dev/hd4'
    assert mount_facts['mounts'][0]['fstype'] == 'jfs2'
    assert mount_facts['mounts'][0]['options'] == 'log'
    assert mount_facts['mounts'][0]['time'] == 'Jun  8  2016   00:25:21'


# Generated at 2022-06-11 02:24:32.654758
# Unit test for method get_mount_facts of class AIXHardware

# Generated at 2022-06-11 02:24:37.137450
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    hardware = AIXHardware()
    hardware.module = AnsibleModule(argument_spec={})
    hardware.module.run_command = lambda *_, **__: (0, mock_vmstat_out, "")
    hardware.module.add_file_common_arguments = lambda x: x
    hardware.get_memory_facts()
    assert hardware.facts['memtotal_mb'] == 4096
    assert hardware.facts['memfree_mb'] == 1024
    assert hardware.facts['swaptotal_mb'] == 12288
    assert hardware.facts['swapfree_mb'] == 12288


# Generated at 2022-06-11 02:24:44.904287
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = FakeAnsibleModule()
    aix_facts = AIXHardware()

    rc, out, err = module.run_command("mount")
    out += '\n'

    mount_facts = aix_facts.get_mount_facts()

    assert mount_facts['mounts'] != []
    for item in mount_facts['mounts']:
        assert re.search(r'^%s.*%s' % (item['device'], item['mount']), out, re.MULTILINE)



# We can not use AnsibleModule as a context object...

# Generated at 2022-06-11 02:24:53.711995
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)

    # the following values need to be updated if the test is run on a different platform
    memory_facts = {
        'memtotal_mb': 7984,
        'memfree_mb': 78,
        'swaptotal_mb': 314368,
        'swapfree_mb': 314368,
    }

    cpu_facts = {
        'processor_count': 16,
        'processor_cores': 8,
        'processor': 'PowerPC_POWER8'
    }


# Generated at 2022-06-11 02:24:58.322813
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    """Test case for constructor of class AIXHardwareCollector."""
    aix_hw_collector = AIXHardwareCollector()
    assert aix_hw_collector
    assert aix_hw_collector.platform == 'AIX'
    assert aix_hw_collector._fact_class == AIXHardware

# Generated at 2022-06-11 02:25:03.725547
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec={
        },
        supports_check_mode=True)

    hardware = AIXHardware(module)

    cpu_facts = hardware.get_cpu_facts()

    module.exit_json(changed=False, ansible_facts=cpu_facts)


# Generated at 2022-06-11 02:25:07.747386
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    harware_collector = AIXHardwareCollector()
    assert harware_collector._platform == 'AIX'
    assert harware_collector._fact_class == AIXHardware

# Generated at 2022-06-11 02:25:32.739709
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = FakeAnsibleModule()
    hw = AIXHardware(module, "hardware_collector")

    hw.module.run_command = mock_run_command
    expected_get_memory_facts = {
        'memfree_mb': 90,
        'memtotal_mb': 202,
        'swaptotal_mb': 312,
        'swapfree_mb': 312
    }
    assert expected_get_memory_facts == hw.get_memory_facts()



# Generated at 2022-06-11 02:25:38.986227
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={'test': dict(default=True, type='bool')})

    lsdev_cmd = module.get_bin_path('lsdev', True)
    lsattr_cmd = module.get_bin_path('lsattr', True)

    rc, out_lsdev, err = module.run_command(lsdev_cmd)

    if rc == 0:
        device_facts = {}
        device_facts['devices'] = {}

        for line in out_lsdev.splitlines():
            field = line.split()

            device_attrs = {}
            device_name = field[0]
            device_state = field[1]
            device_type = field[2:]
            lsattr_cmd_args = [lsattr_cmd, '-E', '-l', device_name]
           

# Generated at 2022-06-11 02:25:42.254308
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    m = AIXHardware({})
    assert_that(m.get_cpu_facts(), has_entries('processor_count'))
    assert_that(m.get_cpu_facts(), has_entries('processor'))
    assert_that(m.get_cpu_facts(), has_entries('processor_cores'))


# Generated at 2022-06-11 02:25:45.016776
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec=dict())
    module.params = {}

    ah = AIXHardware(module)

    mount_facts = ah.get_mount_facts()
    assert ('/' in [x['mount'] for x in mount_facts['mounts']])

# Generated at 2022-06-11 02:25:55.789013
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module_mock = AnsibleModuleMock()
    aix_hardware = AIXHardware(module_mock)
    vgs_facts = aix_hardware.get_vgs_facts()
    assert vgs_facts['vgs']['rootvg'][0] == { 'pv_name': 'hdisk0', 'pv_state': 'active', 'total_pps': '546', 'free_pps': '0', 'pp_size': '4,096 megabyte(s)' }
    assert vgs_facts['vgs']['rootvg'][1] == { 'pv_name': 'hdisk1', 'pv_state': 'active', 'total_pps': '546', 'free_pps': '113', 'pp_size': '4,096 megabyte(s)' }
    assert v

# Generated at 2022-06-11 02:26:01.898400
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(
        argument_spec=dict()
    )
    hardware_info = AIXHardware(module)
    dmi_info = hardware_info.get_dmi_facts()
    assert 'firmware_version' in dmi_info
    assert 'product_serial' in dmi_info
    assert 'product_name' in dmi_info


# Generated at 2022-06-11 02:26:08.532924
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    test_data = """

Memory Resources
Physical Memory:    129 MB
AIX:                49 MB (36%)
Free memory:        80 MB (62%)

Virtual Memory:     129 MB
AIX:                49 MB (36%)
Free memory:        80 MB (62%)

"""
    test_obj = AIXHardware()
    result = test_obj.get_memory_facts()
    assert result['memtotal_mb'] == 129
    assert result['memfree_mb'] == 80



# Generated at 2022-06-11 02:26:12.496958
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    aix_hw = AIXHardware()
    aix_hw.module = AnsibleModule(argument_spec={})
    cpu_facts = aix_hw.get_cpu_facts()
    assert cpu_facts['processor_count'] == 8


# Generated at 2022-06-11 02:26:23.954724
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    """
    Test method get_memory_facts of class AIXHardware
    """
    hardware = AIXHardware()

    hardware.module = MockModule()
    hardware.module.run_command.side_effect = [
        (0, '/usr/sbin/vmstat -v\n', ''),
        (0, '/usr/sbin/lsps -s\n', '')
    ]

    facts = hardware.populate()
    assert facts['memtotal_mb'] == 327680
    assert facts['memfree_mb'] == 0
    assert facts['swaptotal_mb'] == 262144
    assert facts['swapfree_mb'] == 131072


# Test module class

# Generated at 2022-06-11 02:26:36.063112
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    obj = AIXHardware()
    obj.module = AnsibleModuleMock()
    obj.module.run_command.return_value = (0, """/dev/hd4          /home        jfs     2     yes     rw,log=/dev/hd8
/dev/hd2          /            jfs     2     yes     rw,log=/dev/hd8
/proc             /proc        proc    nosuid        no     rw""", '')

    result = obj.get_mount_facts()


# Generated at 2022-06-11 02:27:16.921184
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module=module)
    result = hardware.get_mount_facts()
    assert type(result) is dict
    assert len(result) == 1
    assert 'mounts' in result
    assert type(result['mounts']) is list

# Generated at 2022-06-11 02:27:21.889215
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    dmi_facts = AIXHardware.get_dmi_facts(None)
    assert type(dmi_facts) is dict
    assert 'product_name' in dmi_facts
    assert 'product_serial' in dmi_facts
    assert 'lpar_info' in dmi_facts
    assert 'firmware_version' in dmi_facts

# Generated at 2022-06-11 02:27:23.987680
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector.platform == 'AIX'
    assert hardware_collector.fact_class == AIXHardware


# Generated at 2022-06-11 02:27:34.891172
# Unit test for method get_vgs_facts of class AIXHardware

# Generated at 2022-06-11 02:27:41.532752
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    test_object = AIXHardware({})
    test_object.module = MagicMock()
    test_object.module.run_command = MagicMock(return_value=(0, '1 memory pages\n'
                                                                  '8 free pages\n',
                                                             ''))
    result = test_object.get_memory_facts()
    assert result == {'memtotal_mb': 4096, 'memfree_mb': 32, 'swapfree_mb': None, 'swaptotal_mb': None}



# Generated at 2022-06-11 02:27:50.123550
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )
    aixhw_collector = AIXHardwareCollector(module=module)
    aix_hw_obj = aixhw_collector.collect()
    facts = aix_hw_obj.populate()
    assert facts['devices'] is not None
    attr_exists = ['device', 'state', 'attributes']
    for device in facts['devices'].values():
        assert all(x in device for x in attr_exists)


# Generated at 2022-06-11 02:28:00.022890
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    # Initialize the object
    test_obj = AIXHardware(dict())
    # Define the input parameters for method 'get_memory_facts'
    inputs = {}
    test_obj.module.run_command = Mock(return_value=(0, 'memory pages: 18058                memory size:      1681 MB ( 1730592 KB)\nfree pages:       898                memory size:        85 MB (  88576 KB)', ''))
    test_obj.populate_from_vgs = Mock(return_value={'swaptotal_mb': 1681, 'swapfree_mb': 1730})
    # Run the method 'get_memory_facts'
    result = test_obj.get_memory_facts()
    # Check the result

# Generated at 2022-06-11 02:28:09.988925
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    test_data = """ sys0 Available 00-00-00 System,IBM,9117-570,1D61A,C
    MPC: Model 9004-570,Machine Serial Number YCPB1371
    CPU: Proc 1,Processor Serial Number YCPB1371
    CPU: Proc 2,Processor Serial Number YCPB1371
    CPU: Proc 3,Processor Serial Number YCPB1371
    CPU: Proc 4,Processor Serial Number YCPB1371
    Mem: Total Memory 0,Memory Type DDR-2,ECC Support Yes,ECC System
    Console Type RS232
    Power Supply: FRU Type 70Y9950"""
    module = AnsibleModule(argument_spec={})
    ah = AIXHardware(module)
    dmi_facts = ah.get_dmi_facts()

    assert dmi_

# Generated at 2022-06-11 02:28:22.550247
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    memtotal_mb = 1024 ** 2
    memfree_mb = 1024
    swaptotal_mb = 1024 * 10
    swapfree_mb = 1024 * 5

    user_facts = AIXHardware(dict(module=MockModule(params=dict(gather_subset='!all,!min'))))

    # Return empty dict as memfree_mb is not defined in subset
    assert user_facts.get_memory_facts() == {}

    user_facts = AIXHardware(dict(module=MockModule(params=dict(gather_subset='!all,!min,memory'))))

    # Return empty dict as memtotal_mb, memfree_mb are not defined in subset
    assert user_facts.get_memory_facts() == {}


# Generated at 2022-06-11 02:28:33.714848
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    import io
    import sys
    import unittest

    class TestAIXHardware_get_device_facts(unittest.TestCase):
        def setUp(self):
            from ansible.module_utils.facts import ModuleArgsParser

            class Module(object):
                def __init__(self, args=None, *kwargs):
                    self.args = args
                    self.params = args
                    self.connection = ''
                    self.run_command = self.run_command_mock

                def run_command_mock(self, args):
                    if args == ['/usr/bin/lsdev', '-Cc', 'processor']:
                        return 0, 'proc0 Available 00-00 Processor\nproc1 Defined  00-01 Processor', ''

# Generated at 2022-06-11 02:29:18.448846
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module=module)
    hardware.populate()
    assert hardware.memfree_mb == 'UNAVAILABLE'
    assert hardware.memtotal_mb == 'UNAVAILABLE'
    assert hardware.swapfree_mb == 'UNAVAILABLE'
    assert hardware.swaptotal_mb == 'UNAVAILABLE'
    assert hardware.processor == []
    assert hardware.processor_cores == 'UNAVAILABLE'
    assert hardware.processor_count == 'UNAVAILABLE'



# Generated at 2022-06-11 02:29:20.462023
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
     fact = AIXHardwareCollector()
     assert fact._platform == 'AIX'
     assert fact._fact_class is AIXHardware



# Generated at 2022-06-11 02:29:29.540523
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    class HModule(object):
        def __init__(self):
            self._output = "name status description\n" \
                           "proc0 Available 00-00 Processor 0\n" \
                           "proc1 Available 00-00 Processor 1\n" \
                           "proc2 Available 00-00 Processor 2\n" \
                           "proc3 Available 00-00 Processor 3\n" \
                           "proc4 Available 00-00 Processor 4\n" \
                           "proc5 Available 00-00 Processor 5\n"
            self.fail_json = self._fail_json

        def run_command(self, args, use_unsafe_shell=False):
            if args == "/usr/sbin/lsdev -Cc processor":
                return (0, self._output, "")

# Generated at 2022-06-11 02:29:34.813475
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    from ansible.module_utils.facts import collector

    from ansible.module_utils.facts.hardware.aix import AIXHardware

    m = AIXHardware()
    m._module = collector
    m._module.run_command = lambda x: (0, "", "")
    m.get_dmi_facts()


# Generated at 2022-06-11 02:29:43.222480
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    class AIXHardwareMock(AIXHardware):
        def __init__(self, module):
            self.module = module

        def run_command(self, command, use_unsafe_shell=False):
            stdoutdata = """IBM,82527267"""
            stderrdata = """IBM,82527267"""
            rc = 0
            return (rc, stdoutdata, stderrdata)

        def get_bin_path(self, name, required=False):
            return "/usr/sbin/{0}".format(name)


    from ansible.module_utils.facts import Facts
    module = Facts(
        {'ANSIBLE_MODULE_ARGS': {}},
        check_invalid_arguments=False,
        ansible_facts_module=True,
    )
    module.run

# Generated at 2022-06-11 02:29:46.609604
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    """
    AttributeError: 'AIXHardware' object has no attribute 'get_mount_facts'
    """
    assert hasattr(AIXHardware, 'get_mount_facts')
    assert callable(getattr(AIXHardware, 'get_mount_facts'))


# Generated at 2022-06-11 02:29:53.887261
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    class FauxModule(object):
        def __init__(self):
            self.run_command_called = False
            self.run_command_calls = []

        def get_bin_path(self, path, required=False):
            return path

        def run_command(self, cmd, use_unsafe_shell=False):
            self.run_command_called = True
            self.run_command_calls.append(cmd)


# Generated at 2022-06-11 02:30:01.418295
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    hardware_facts = {}
    module = AnsibleModule(argument_spec={'gather_subset':
                                          dict(default=['!all'], type='list')})
    hardware_module_facts = AIXHardware(module, hardware_facts)
    hardware_facts_result = hardware_module_facts.populate()
    assert hardware_facts_result['firmware_version'] == '7.6.0.0'
    assert hardware_facts_result['processor_count'] == 1
    assert hardware_facts_result['product_name'] == 'PowerNV 8408-21L'
    assert hardware_facts_result['product_serial'] == 'YGYG7W8'
    assert hardware_facts_result['memtotal_mb'] == 16777216
    assert hardware_facts_result['memfree_mb'] == 1419

# Generated at 2022-06-11 02:30:04.514364
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector._platform == 'AIX'
    assert hardware_collector._fact_class == AIXHardware


# Generated at 2022-06-11 02:30:12.037839
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():

    import pytest
    from ansible.module_utils.facts import collector

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    hardware_mock = AIXHardware(module)


# Generated at 2022-06-11 02:31:50.477305
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    AIXHardwareCollector()

# Generated at 2022-06-11 02:31:52.667027
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    ohw = AIXHardwareCollector()
    assert ohw._platform == 'AIX'
    assert ohw._fact_class == AIXHardware

# Generated at 2022-06-11 02:31:57.648894
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    test_module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    hardware = AIXHardware(module=test_module)
    test_cpu_facts = hardware.get_cpu_facts()
    assert test_cpu_facts['processor_cores'] is not None
    assert test_cpu_facts['processor_count'] is not None
    assert test_cpu_facts['processor'] is not None


# Generated at 2022-06-11 02:32:04.328736
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = AIXHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert 'firmware_version' in dmi_facts
    assert 'product_serial' in dmi_facts
    assert 'lpar_info' in dmi_facts
    assert 'product_name' in dmi_facts


# Generated at 2022-06-11 02:32:13.701052
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    if not HAS_AIX_UTILS:
        module.fail_json(msg='aix_utils required for this module')

    hardware_collector = AIXHardwareCollector(module=module)
    ansible_facts = {}

    if not hardware_collector.is_platform_supported():
        module.exit_json(ansible_facts=ansible_facts)

    ansible_facts.update(hardware_collector.collect())

    # Unit test will always use gather_subset=['!all'] which
    # should cause empty facts to be returned.
    assert ansible_facts == {}
