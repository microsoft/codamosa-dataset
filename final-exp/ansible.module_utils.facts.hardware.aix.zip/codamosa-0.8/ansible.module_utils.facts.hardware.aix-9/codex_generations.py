

# Generated at 2022-06-11 02:22:40.138381
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})

    aix_hardware_obj = AIXHardware(module)

    rc, out, err = aix_hardware_obj.module.run_command("/usr/bin/vmstat -v")
    out_list = out.splitlines()

    flag_pagecount = False
    flag_freecount = False

    for line in out_list:
        if flag_pagecount is True:
            pagecount = int(line.split()[0])
            break
        flag_pagecount = 'memory pages' in line
    for line in out_list:
        if flag_freecount is True:
            freecount = int(line.split()[0])
            break
        flag_freecount = 'free pages' in line


# Generated at 2022-06-11 02:22:50.199366
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    harwd = AIXHardware(module)
    facts = harwd.populate()

    assert facts.keys() == {'firmware_version', 'lpar_info', 'memtotal_mb', 'mounts', 'processor', 'processor_cores', 'processor_count', 'product_name', 'product_serial', 'swapfree_mb', 'swaptotal_mb', 'vgs'}
    assert 'swaptotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'mounts' in facts
    assert 'vgs' in facts
    assert 'devices' in facts
    assert 'processor_cores' in facts
    assert 'processor_count'

# Generated at 2022-06-11 02:23:01.571777
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    harware_obj = AIXHardware(module)
    result = harware_obj.populate()
    assert 'firmware_version' in result
    assert 'product_serial' in result
    assert 'lpar_info' in result
    assert 'product_name' in result
    assert 'processor_count' in result
    assert 'processor_cores' in result
    assert 'memtotal_mb' in result
    assert 'memfree_mb' in result
    assert 'processor' in result
    assert 'swaptotal_mb' in result
    assert 'swapfree_mb' in result
    assert 'vgs.rootvg.0.device' in result
    assert 'vgs.rootvg.0.fstype' in result

# Generated at 2022-06-11 02:23:11.151355
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    test_hw = AIXHardware()

    rc = 0
    out = """
System Model: IBM,8286-41A
Machine Serial Number: 2677CK7
LPAR Info: 1 SSP                         
firmware_version: IBM,8286-41A
product_serial: 2677CK7
lpar_info: 1 SSP
product_name: IBM,8286-41A
"""
    err = ''
    test_hw.module.run_command = lambda *args, **kwargs: (rc, out, err)

    hw_facts = test_hw.populate()

    assert hw_facts['firmware_version'] == 'IBM,8286-41A'
    assert hw_facts['product_serial'] == '2677CK7'

# Generated at 2022-06-11 02:23:16.161500
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    """Tests hardware facts for AIX hardware"""
    hardware = AIXHardware(dict(), 'aix')
    hardware.module.params['gather_subset'] = ['all']
    hardware.module.run_command = lambda *args, **kwargs: (0, '', '')
    facts = hardware.populate()
    assert 'processor' in facts
    assert 'memtotal_mb' in facts

# Generated at 2022-06-11 02:23:27.434651
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts.utils import get_mount_size

    data = 'rootvg:\n  PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION\n'
    data += '  hdisk0            active            546         0           00..00..00..00..00\n'
    data += '  hdisk1            active            546         113         00..00..00..21..92\n'
    data += 'realsyncvg:\n  PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION\n'
    data += '  hdisk74           active            1999        6           00..00..00..00..06\n'

# Generated at 2022-06-11 02:23:38.990007
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    """
    Test method get_mount_facts
    """

    import mock
    from ansible.module_utils.facts.hardware.aix import AIXHardware

    aix_hw = AIXHardware({})


# Generated at 2022-06-11 02:23:45.078046
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    hardware = AIXHardware('module')
    hardware.module.run_command = MagicMock(return_value=(0, "memory pages: 32752\nfree pages: 32189", ""))
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 128
    assert memory_facts['memfree_mb'] == 125


# Generated at 2022-06-11 02:23:53.954611
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    from ansible.module_utils.facts import hardware
    for fact in hardware.collector.collect(['vgs']):
        assert 'vgs' in fact
        vgs = fact['vgs']
        assert 'testvg' in vgs
        assert len(vgs['testvg']) == 2
        assert vgs['testvg'][0]['pv_name'] == 'hdisk105'
        assert vgs['testvg'][0]['pv_state'] == 'active'
        assert vgs['testvg'][0]['total_pps'] == '999'
        assert vgs['testvg'][0]['free_pps'] == '838'
        assert vgs['testvg'][0]['pp_size'] == '4 megabyte(s)'

# Generated at 2022-06-11 02:24:04.357585
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    # AIX has no mtab, so the mount command is the only way to get the mount information.
    # Test parse_mounts_output method
    line = "node /dev/hd2       /               jfs2   log       yes     rw,log=/dev/hd8     040000000       13715     13718  0       0"
    fields = line.split()
    test_facts = AIXHardware()
    mount_info = {}

    mount = fields[1]
    mount_info = {'mount': mount,
                  'device': fields[0],
                  'fstype': fields[2],
                  'options': fields[6],
                  'time': '%s %s %s' % (fields[3], fields[4], fields[5])}
    mount_info.update(get_mount_size(mount))
   

# Generated at 2022-06-11 02:24:26.929806
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    """
    This method is used to test the cpu fact gathering
    of class AIXHardware
    """

    module_mock = MagicMock()
    lsdev_out = """proc0 Available 00-00 Processor
proc1 Available 00-00 Processor
proc2 Available 00-00 Processor
proc3 Available 00-00 Processor
proc4 Available 00-00 Processor
proc5 Available 00-00 Processor
proc6 Available 00-00 Processor
proc7 Available 00-00 Processor
proc8 Defined   00-00 Processor
proc9 Defined   00-00 Processor"""
    lsattr_out = """type POWER7
smt_threads 1"""

    module_mock.run_command.return_value = (0, lsdev_out, '')
    module_mock.get_bin_path.return_value = '/usr/sbin/lsdev'
   

# Generated at 2022-06-11 02:24:29.837633
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    output = AIXHardware.get_cpu_facts(module)
    assert output == None


# Generated at 2022-06-11 02:24:36.457782
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    """Unit test for method get_dmi_facts of class AIXHardware"""
    expected_dict = {"firmware_version": "CE210_087", "product_name": "pSeries System p5 505 (lpar_name=my_lpar_name)", "lpar_info": "lpar_id=2 lpar_env=aix lpar_name=my_lpar_name", "product_serial": "04-A8-C0-A7-82-A1"}
    teststring="IBM,CE210_087\nSystem Model: IBM,8203-E4A\nMachine Serial Number: 04-A8-C0-A7-82-A1\nLPAR Info: lpar_id=2 lpar_env=aix lpar_name=my_lpar_name\n"
   

# Generated at 2022-06-11 02:24:38.488716
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    # Single invocation of constructor will check validity of class
    collector = AIXHardwareCollector()


# Generated at 2022-06-11 02:24:42.977285
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    fact_module = ansible_module_mock()
    fact_module.run_command.return_value = (0, """name status    description
        hdisk0 Available
        """, '')
    fact_module.get_bin_path.return_value = '/usr/sbin/lsdev'

    fact_module.run_command.return_value = (0, """attribute value description
        type   disk      disk type
        """, '')
    fact_module.get_bin_path.return_value = '/usr/sbin/lsattr'

    fact_instance = AIXHardware()
    fact_instance.module = fact_module

    device_facts = fact_instance.get_device_facts()

# Generated at 2022-06-11 02:24:52.829232
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    import os
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.hardware import AIXHardware
    from ansible.module_utils._text import to_bytes
    import sys

    class FakeModule(object):
        @staticmethod
        def get_bin_path(*args, **kwargs):
            return "/bin/mount"

        @staticmethod
        def run_command(mount_path):
            test_directory = os.path.dirname(os.path.abspath(__file__))

# Generated at 2022-06-11 02:25:00.019388
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)

    mounts = hardware.get_mount_facts()
    mounts_array = mounts['mounts']

    assert mounts_array
    for m in mounts_array:
        assert m['device']
        assert m['mount']
        assert m['fstype']
        assert m['options']
        assert m['size_total']
        assert m['size_available']
        assert m['size_used']


# Generated at 2022-06-11 02:25:12.198331
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    class ModuleMock(object):
        """
        Mocking class ansible.module_utils.basic.AnsibleModule
        """
        def __init__(self):
            self.run_command_calls = []
        def run_command(self, cmd, **kw):
            self.run_command_calls.append(cmd)
            if cmd == "/usr/sbin/lsps -s":
                return 0, "", ""
            if cmd == "/usr/bin/vmstat -v":
                return 0, "memory pages:  23660961\nfree pages:   23267108", ""
            if cmd == "/usr/sbin/lsdev -Cc processor":
                return 0, "proc0 Available 00-00 Processor\nproc1 Available 00-01 Processor", ""
            return 0, "", ""

    module

# Generated at 2022-06-11 02:25:15.857895
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    module = AnsibleModule(argument_spec=dict())
    ahc = AIXHardwareCollector(module)
    assert ahc.platform == "AIX"
    assert ahc.fact_class == AIXHardware

from ansible.module_utils.basic import *  # NOQA
from ansible.module_utils.facts.hardware.aix import AIXHardwareCollector

if __name__ == "__main__":
    main()

# Generated at 2022-06-11 02:25:27.831104
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    class ModuleMock():
        def get_bin_path(self, arg, opt_dirs=[]):
            return "lsvg"

# Generated at 2022-06-11 02:25:59.739599
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware

# Generated at 2022-06-11 02:26:05.958812
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    # Create a mock module
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    # Create an instance of class AIXHardware
    hw = AIXHardware(module)
    # Get the cpu facts
    cpu = hw.get_cpu_facts()
    # Ensure the cpu facts are correct
    assert cpu['processor_count'] == 8
    assert cpu['processor_cores'] == 4
    assert cpu['processor'] == 'PowerPC_POWER8'



# Generated at 2022-06-11 02:26:15.801240
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    lsdev_path = module.get_bin_path("lsdev")
    lsattr_path = module.get_bin_path("lsattr")
    if lsdev_path and lsattr_path:
        AIXHardware.module = module
        aix_hardware_facts = AIXHardware()
        device_facts = aix_hardware_facts.get_device_facts()
        assert device_facts['devices'].keys() is not None
        assert device_facts['devices']['fd0'] == {'state': 'Defined',
                                                  'attributes': {'size': '39', 'type': 'diskette'},
                                                  'type': '1501-F1 IBM 9121  DASD'}


# Generated at 2022-06-11 02:26:28.535043
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = FakeAnsibleModule()

# Generated at 2022-06-11 02:26:39.670489
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    from ansible.module_utils.facts.collector import CallbackModule
    from ansible.module_utils.facts.hardware.aix import AIXHardware

    data = """Available 04-08-00 Processor 0
Available 04-08-00 Processor 1
Available 04-08-00 Processor 2
Available 04-08-00 Processor 3
Available 04-08-00 Processor 4
Available 04-08-00 Processor 5
Available 04-08-00 Processor 6
Available 04-08-00 Processor 7"""
    o = AIXHardware()
    o.module = CallbackModule()
    o.module.run_command = lambda x: (0, data, '')
    o.populate()

    assert o.processor_count == 8
    assert o.processor_cores == 1
    assert o.processor == 'PowerPC_POWER7'


#

# Generated at 2022-06-11 02:26:41.213090
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    c = AIXHardwareCollector()
    assert c is not None

# Test AIXHardware:populate()

# Generated at 2022-06-11 02:26:51.867685
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
        module = type('', (), {'get_bin_path': lambda x: '/usr/sbin/mount'})
        ac = AIXHardware(module)

        # Create mount command output

# Generated at 2022-06-11 02:26:56.664499
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)

    result = hardware.get_cpu_facts()
    assert result['processor_count'] == 4
    assert result['processor'] == 'PowerPC_POWER8'
    assert result['processor_cores'] == 4



# Generated at 2022-06-11 02:27:06.025016
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    har_obj = AIXHardware(module)
    har_obj.populate()
    assert 'memtotal_mb' in module.exit_json['ansible_facts']
    assert 'memfree_mb' in module.exit_json['ansible_facts']
    assert 'swaptotal_mb' in module.exit_json['ansible_facts']
    assert 'swapfree_mb' in module.exit_json['ansible_facts']
    assert 'processor' in module.exit_json['ansible_facts']
    assert 'processor_cores' in module.exit_json['ansible_facts']
    assert 'processor_count' in module.exit_json['ansible_facts']

# Generated at 2022-06-11 02:27:17.845807
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    hardware_facts = AIXHardware(dict(), dict()).populate()
    assert 'processor' in hardware_facts
    assert 'processor_cores' in hardware_facts
    assert 'processor_count' in hardware_facts
    assert 'memtotal_mb' in hardware_facts
    assert 'memfree_mb' in hardware_facts
    assert 'active_memory' in hardware_facts
    assert 'inactive_memory' in hardware_facts
    assert 'wired_memory' in hardware_facts
    assert 'swaptotal_mb' in hardware_facts
    assert 'swapfree_mb' in hardware_facts
    assert 'firmware_version' in hardware_facts
    assert 'product_serial' in hardware_facts
    assert 'lpar_info' in hardware_facts
    assert 'product_name' in hardware_facts

# Generated at 2022-06-11 02:27:58.902872
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    module.exit_json(ansible_facts=hardware.populate())



# Generated at 2022-06-11 02:28:09.298125
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    test_module = type('test_module_aix', (object,), {'run_command': run_command,
                                                      'get_bin_path': get_bin_path})
    test_module.check_mode = False
    test_module.debug = False
    test_module.warn = True
    test_module.fail_json = False
    test_module.lsconf_path = '/usr/sbin/lsconf'
    test_module.lsattr_path = '/usr/sbin/lsattr'
    test_module.lsattr_path = '/usr/sbin/lsattr'
    test_module.manage_existing_arg_spec = {}

    ah = AIXHardware(module=test_module)
    dmi = ah.get_dmi_facts()


# Generated at 2022-06-11 02:28:22.055997
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    test_instance = AIXHardware(dict())
    test_instance.lsps_out = "Page Space Physical Volume      Size %Used Active Auto Type  Chksum\nhd6           hdisk0                 4096MB  0.0   yes no  lv   0x05f5\nhd5           hdisk1                 4096MB  0.0   yes yes lv   0x05f5\n"
    result = test_instance.get_memory_facts()
    assert 'swapfree_mb' in result
    assert 'swaptotal_mb' in result
    assert 'memfree_mb' in result
    assert 'memtotal_mb' in result
    assert result['memtotal_mb'] == (4096*2)
    assert result['memfree_mb'] == (4096*2)
    assert result['swaptotal_mb']

# Generated at 2022-06-11 02:28:25.270026
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    hardware = AIXHardware()

    hardware_facts = hardware.populate()

    assert hardware_facts['processor_cores'] == 2
    assert hardware_facts['swaptotal_mb'] > 0

# Generated at 2022-06-11 02:28:29.428093
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    hardwarecollector = AIXHardwareCollector()
    hardware = AIXHardware(dict(), hardwarecollector.module)
    hardware_facts = hardware.get_cpu_facts()
    assert('processor_count' in hardware_facts)


# Generated at 2022-06-11 02:28:32.976044
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule({}, supports_check_mode=True)
    fact_module = AIXHardware()
    fact_module.module = module
    facts = fact_module.populate()
    assert facts


# Generated at 2022-06-11 02:28:41.561155
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    """
    This function tests the get_vgs_facts method of the AIXHardware class
    """

    def get_bin_path(s):
        if s == "lsvg":
            return s
        elif s == "xargs":
            return s


# Generated at 2022-06-11 02:28:54.941428
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = fake_get_bin_path
    hardware = AIXHardware(module=module)
    vgs_facts = hardware.get_vgs_facts()
    # check vgs facts
    assert 'vgs' in vgs_facts
    assert len(vgs_facts['vgs']) == 3

    # check rootvg facts
    assert 'rootvg' in vgs_facts['vgs']
    rootvg = vgs_facts['vgs']['rootvg']
    assert len(rootvg) == 2
    assert rootvg[0]['pv_name'] == 'hdisk0'
    assert rootvg[1]['pv_name'] == 'hdisk1'

    # check realsyncvg facts

# Generated at 2022-06-11 02:29:04.255668
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_collector = AIXHardwareCollector(module=module)
    hardware_collector.collect()
    hardware_facts = hardware_collector.get_facts()

    assert hardware_facts['processor'] == ['PowerPC_POWER8']
    assert hardware_facts['processor_count'] == 2
    assert hardware_facts['processor_cores'] == 8

    assert hardware_facts['memtotal_mb'] == 32760
    assert hardware_facts['memfree_mb'] == 1020

    assert hardware_facts['firmware_version'] == 'IBM,8247-22L'
    assert hardware_facts['product_serial'] == '01UBE06'
    assert hardware_facts['lpar_info'] == '1 LPAR (Default)'

# Generated at 2022-06-11 02:29:08.762107
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    class AIXHardwareMock:
        def __init__(self):
            self.module = {}
        def get_bin_path(self, arg1, arg2):
            return arg1
    module = AIXHardwareMock()
    hardwareFacts = AIXHardware(module)
    hardwareFacts.get_device_facts()



# Generated at 2022-06-11 02:30:45.307813
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    facts = AIXHardwareCollector.collect()
    assert(facts['platform'] == 'AIX')

# Generated at 2022-06-11 02:30:51.362662
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    """Test for method get_dmi_facts"""
    module = AnsibleModuleMock()
    module.run_command.return_value = (0, 'IBM,81032AA', '')
    hardware = AIXHardware(module)
    facts = hardware.get_dmi_facts()
    assert 'firmware_version' in facts
    assert facts['firmware_version'] == 'IBM,81032AA'



# Generated at 2022-06-11 02:30:59.043440
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)

    hardware.module.run_command = MagicMock()

# Generated at 2022-06-11 02:31:05.958509
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    aix_hardware = AIXHardware(module)
    aix_hardware.populate()

    assert type(aix_hardware.get_mount_facts()['mounts']) is list
    assert aix_hardware.get_mount_facts()['mounts'][0]['mount'] == '/'
    assert aix_hardware.get_mount_facts()['mounts'][0]['fstype'] == 'jfs2'
    assert aix_hardware.get_mount_facts()['mounts'][0]['options'] == 'rw'



# Generated at 2022-06-11 02:31:08.259662
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector._platform == 'AIX'

# Generated at 2022-06-11 02:31:19.466793
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec=dict())
    fake_module = module.params

    def run_command(args, **kwargs):
        if args[0] == '/usr/sbin/lsdev':
            return 0, """name     status  description
mem0    Available  Memory
sys0    Available  System
proc0   Available  Processor
proc4   Defined    Processor
hdisk0  Available  Disk Drive
hdisk1  Defined    Disk Drive
common1 Available  I/O Backplane
tr0     Available  Token-Ring Adapter
tr1     Defined    Token-Ring Adapter
en0     Available  Ethernet Adapter
en4     Defined    Ethernet Adapter
""", ""

# Generated at 2022-06-11 02:31:24.215605
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module=module)

# Generated at 2022-06-11 02:31:33.515442
# Unit test for method get_device_facts of class AIXHardware

# Generated at 2022-06-11 02:31:41.828694
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    """This is a test of AIXHardware class's method get_dmi_facts"""
    module = AnsibleModule(argument_spec={})
    aix_hardware = AIXHardware(module=module)

    lsvg_path = module.get_bin_path("lsvg")
    xargs_path = module.get_bin_path("xargs")
    # Test command_executor with run_command
    cmd = "%s -o | %s %s -p" % (lsvg_path, xargs_path, lsvg_path)
    if lsvg_path and xargs_path:
        rc, out, err = aix_hardware.module.run_command(cmd, use_unsafe_shell=True)

# Generated at 2022-06-11 02:31:47.786802
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    hardware = AIXHardware()
    hardware.module = MagicMock()
    hardware.module.run_command.return_value = (0, 'firmware_version: IBM,8233-E8B\nlpar_info: 1\nproduct_name: IBM,8233-E8B\nproduct_serial: YG01S26\n', '')
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts == {'firmware_version': '8233-E8B', 'product_serial': 'YG01S26', 'lpar_info': '1', 'product_name': '8233-E8B'}
