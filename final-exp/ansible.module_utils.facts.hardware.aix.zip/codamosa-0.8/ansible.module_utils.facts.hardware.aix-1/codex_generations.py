

# Generated at 2022-06-11 02:22:33.553543
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    assert AIXHardware(dict()).get_memory_facts() == \
           {'memtotal_mb': 772, 'memfree_mb': 767, 'swapfree_mb': 0, 'swaptotal_mb': 0}



# Generated at 2022-06-11 02:22:40.862985
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec=dict())
    fake_module = FakeAnsibleModule(module=module, platform='AIX')
    hw = AIXHardware(fake_module)

    # test get_device_facts

# Generated at 2022-06-11 02:22:50.660086
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModuleMock()
    hardware_facts_obj = AIXHardware(module)

    # Test for method populate for cpu facts
    hardware_facts_obj.module.run_command = mocked_run_command
    hardware_facts_obj.module.get_bin_path = mocked_get_bin_path
    cpu_facts = {'processor': [], 'processor_cores': 0, 'processor_count': 0}
    cpu_facts_aix = {'processor': ['POWER8'], 'processor_cores': 16, 'processor_count': 2}
    cpu_facts_aix1 = {'processor': ['POWER9'], 'processor_cores': 24, 'processor_count': 4}


# Generated at 2022-06-11 02:23:01.828872
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware

    hardware = AIXHardware()
    hardware.module = AnsibleModule(argument_spec={})
    hardware.module.run_command = MagicMock()


# Generated at 2022-06-11 02:23:11.296654
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    hardware = AIXHardware(dict())

    # Test Case 1, page size is as big as usual case

# Generated at 2022-06-11 02:23:19.651908
# Unit test for method get_mount_facts of class AIXHardware

# Generated at 2022-06-11 02:23:29.948746
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    class AIX:
        def get_bin_path(self, command, required=False):
            return command

        def run_command(self, command, use_unsafe_shell=False):
            cmd = command.split()
            if cmd[0] == 'lsvg' and len(cmd) == 2:
                if cmd[1] == 'rootvg':
                    return 0, """rootvg:
PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
hdisk0            active            546         0           00..00..00..00..00
hdisk1            active            546         113         00..00..00..21..92
""", ''

# Generated at 2022-06-11 02:23:36.579996
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(
        argument_spec=dict(gather_subset=dict(type='list', default=['all']))
    )
    module.params['gather_subset'] = ['!all']
    facts_instance = AIXHardware(module)
    facts_result = facts_instance.populate()
    assert facts_result == {}

# Generated at 2022-06-11 02:23:40.906457
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'PowerPC_POWER8'
    assert cpu_facts['processor_cores'] == 4


# Generated at 2022-06-11 02:23:50.047100
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    module.run_command = MagicMock(return_value=(0, '', ''))
    set_module_args(dict())
    ah = AIXHardware(module=module)
    facts = ah.populate()
    processor_count = ah.get_cpu_facts()['processor_count']

    assert facts['processor_count'] == processor_count
    assert facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert len(facts['mounts']) == 0

# Generated at 2022-06-11 02:24:19.912852
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    hw = AIXHardware()


# Generated at 2022-06-11 02:24:30.160808
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = None
    module_rc = 0

# Generated at 2022-06-11 02:24:36.009753
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    import ansible.module_utils.facts.hardware.aix as aix
    aix_hardware = aix.AIXHardware()
    aix_hardware._module = Mock(return_value=0)
    aix_hardware._module.run_command = Mock(return_value=[0, 'IBM,810-41A', ''])
    aix_hardware.get_dmi_facts()
    aix_hardware._module.run_command.assert_has_calls([('/usr/sbin/lsattr -El sys0 -a fwversion')])
    # Uncomment to check results of the test
    # print(aix_hardware.get_dmi_facts())

# Generated at 2022-06-11 02:24:38.939738
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    from ansible.module_utils.facts.hardware import AIXHardware
    aix_hardware = AIXHardware()
    assert aix_hardware.get_vgs_facts()

# Generated at 2022-06-11 02:24:46.047782
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    class MockModule(object):
        def run_command(self, cmd):
            return 0, 'proc0 Available 01-00 Processor\nproc1 Available 01-01 Processor\nproc2 Defined\n', ''

    m = MockModule()
    a = AIXHardware(m)
    a.get_cpu_facts()
    assert m.cpu_facts['processor'] == 'Processor'
    assert m.cpu_facts['processor_count'] == 2
    assert m.cpu_facts['processor_cores'] == 1


# Generated at 2022-06-11 02:24:53.218170
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    import sys
    import os
    sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
    from .. import core

    module = core.AnsibleModule(argument_spec={})
    module.command = "lsattr -El sys0 -a fwversion"
    module.run_command = lambda *args, **kwargs: (0, "firmware_version IBM, 7641-44A", None)
    result = AIXHardware(module).get_dmi_facts()
    assert result['firmware_version'] == 'IBM, 7641-44A'


# Generated at 2022-06-11 02:25:01.084306
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    hardware_obj = AIXHardware(module)
    device_facts = hardware_obj.get_device_facts()
    assert 'devices' in device_facts
    assert len(device_facts['devices']) > 0
    for device in device_facts['devices']:
        assert 'state' in device_facts['devices'][device]
        assert 'type' in device_facts['devices'][device]
        assert 'attributes' in device_facts['devices'][device]


# Generated at 2022-06-11 02:25:11.071075
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    """ Unit test for method get_memory_facts of class AIXHardware """
    m = AIXHardware()
    m.module = AnsibleModule(argument_spec={})
    m.module.run_command = Mock(return_value=(0, 'memory pages:   309200\nfree pages:      149533', ''))
    m.get_memory_facts()

    assert m.facts['memtotal_mb'] == 1229
    assert m.facts['memfree_mb'] == 579
    assert m.facts['swaptotal_mb'] == 0
    assert m.facts['swapfree_mb'] == 0



# Generated at 2022-06-11 02:25:17.394992
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts.hardware.aix import AIXHardwareCollector

    class _BaseFactCollector(BaseFactCollector):
        @property
        def loaders(self):
            return (self.loader, )

    class _AIXHardware(AIXHardware):
        def __init__(self, module):
            self.module = module

    class ModuleMock():
        def get_bin_path(self, arg1, arg2 = False):
            if arg1 == "lsdev":
                return "/usr/sbin/lsdev"

# Generated at 2022-06-11 02:25:29.276342
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    mock_module = MockModule()
    hw = AIXHardware(module=mock_module)
    hw.populate()


# Generated at 2022-06-11 02:26:11.940235
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    from ansible.module_utils.facts import ModuleDataCollector # for mocking module
    module = ModuleDataCollector()
    ah = AIXHardware(module)
    ah.populate()
    assert ah.populate()['memtotal_mb'] > 0
    assert ah.populate()['swaptotal_mb'] > 0
    assert ah.populate()['swapfree_mb'] > 0
    assert ah.populate()['memfree_mb'] > 0


# Generated at 2022-06-11 02:26:25.599185
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    """
    Unit test for method populate of class AIXHardware
    """
    module = AnsibleModule(argument_spec=dict())
    hardware = AIXHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts.get('firmware_version') is not None
    assert dmi_facts.get('product_serial') is not None
    assert dmi_facts.get('lpar_info') is not None
    assert dmi_facts.get('product_name') is not None
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts.get('processor_count') is not None
    assert cpu_facts.get('processor') is not None
    assert cpu_facts.get('processor_cores') is not None
    memory_facts = hardware.get_

# Generated at 2022-06-11 02:26:28.946649
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    """
    Simple test for AIXHardwareCollector
    """

    hardware_obj = HardwareCollector.factory()
    assert hardware_obj.__class__.__name__ == 'AIXHardwareCollector'

# Generated at 2022-06-11 02:26:39.982155
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    import sys
    import ansible.module_utils.facts.hardware.aix as aix_fct
    sys.modules["ansible"].module_utils.facts.hardware.aix = aix_fct
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    aix_hardware = AIXHardware(dict(), False)
    aix_hardware.module = MockAnsibleModule()

    # Test if command fails
    aix_hardware.module.run_command = Mock(return_value=(1, '', ''))
    cpu_facts = aix_hardware.get_cpu_facts()
    assert cpu_facts == {}

    # Test if Processor is empty
    aix_hardware.module.run_command = Mock(return_value=(0, '', ''))

# Generated at 2022-06-11 02:26:50.622952
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(
        argument_spec={}
    )

    # Arrange
    facts = {'module': module}
    AIXHardware_obj = AIXHardware(module, facts)

    # Act
    vgs_facts = AIXHardware_obj.get_vgs_facts()

    # Assert

# Generated at 2022-06-11 02:27:01.155329
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    if not HAS_AIX:
        module.fail_json(msg='AIX support (the "aix" python package) is required for this module')

    # Set up the test instance
    runner = AnsibleRunner(module=module)
    # don't load the collection as it is not present on Aix
    # the test is forbidden to fail because the collection is not available.
    runner.collection._load_collections = lambda: None

    # execute facts and check results
    result = runner.run_facts()
    assert result['ansible_facts']['ansible_device_facts']['devices']

# Generated at 2022-06-11 02:27:08.691894
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    class MockedModule:
        def run_command(self, cmd, **kwargs):
            if cmd == "/usr/sbin/lsdev -Cc processor":
                return (0, 'proc0 Available 00-00 Processor\nproc1 Defined   00-01 Processor', '')
            if cmd == "/usr/sbin/lsattr -El proc0 -a type":
                return (0, 'type PowerPC_POWER7', '')
            if cmd == "/usr/sbin/lsattr -El proc0 -a smt_threads":
                return (0, 'smt_threads 8', '')

    mymodule = MockedModule()

    hw = AIXHardware(mymodule)
    results = hw.get_cpu_facts()
    assert results['processor'] == 'PowerPC_POWER7'

# Generated at 2022-06-11 02:27:20.347838
# Unit test for method get_vgs_facts of class AIXHardware

# Generated at 2022-06-11 02:27:29.725343
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    """
    Test for method - get_vgs_facts
    """
    test_hardware = AIXHardware()
    test_hardware.module = MagicMock()

# Generated at 2022-06-11 02:27:38.073774
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    """
    Unit test for the method get_mount_facts of the class AIXHardware
    """
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector


# Generated at 2022-06-11 02:28:49.395380
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    """
    Validate that the hardware facts returned by get_dmi_facts() are
    accurate
    """
    # Setup of AIXHardware object using a mocked module
    module = MockAnsibleModule()
    hardware_obj = AIXHardware(module)
    # Run tests for get_dmi_facts()
    dmi_facts = hardware_obj.get_dmi_facts()
    assert dmi_facts['firmware_version'] == '1.0.0'
    assert dmi_facts['product_name'] == 'System Model'
    assert dmi_facts['product_serial'] == 'Serial Number'
    assert dmi_facts['lpar_info'] == 'LPAR Info'
    module.cleanup()


# Generated at 2022-06-11 02:28:53.309069
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = AIXHardware(module)
    data = hardware.get_dmi_facts()
    assert 'product_name' in data
    assert 'firmware_version' in data

# Generated at 2022-06-11 02:29:00.204813
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    hardware = AIXHardware()

    hardware.module = AnsibleModuleMock()


# Generated at 2022-06-11 02:29:06.192165
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    # Setup a test module
    module = AnsibleModule({'ANSIBLE_MODULE_ARGS': {'gather_subset': 'all'}})
    AIXHardware.module = module
    # Set the return value of the ls command to mimic a real example
    module.run_command.return_value = (0, mount_example_out, None)
    # Do actual call
    mount_facts = AIXHardware.get_mount_facts()
    # Test the results
    assert mount_facts == mount_example_result

# Generated at 2022-06-11 02:29:16.681864
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    # Create the AIXHardware instance
    hardware = AIXHardware()

    # Create the aix_hardware_facts
    aix_hardware_facts = {
        'processor': [],
        'processor_cores': None,
        'processor_count': 0,
        'memfree_mb': None,
        'memtotal_mb': None,
        'firmware_version': None,
        'product_name': None,
        'product_serial': None,
        'lpar_info': None,
        'swapfree_mb': None,
        'swaptotal_mb': None,
        'vgs': {},
        'mounts': [],
        'devices': {}
    }

    # Test with "lsdev" and "lsattr" commands that retrieve empty values
    # lsdev: Empty output


# Generated at 2022-06-11 02:29:26.715395
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    hardware = AIXHardware(module=module)
    hardware_facts = hardware.populate()

    # Test that processor facts were added
    assert hardware_facts['processor']
    assert hardware_facts['processor_count']
    assert hardware_facts['processor_cores']

    # Test that memory facts were added
    assert hardware_facts['memtotal_mb']
    assert hardware_facts['memfree_mb']
    assert hardware_facts['swaptotal_mb']
    assert hardware_facts['swapfree_mb']

    # Test that dmi facts were added
    assert hardware_facts['firmware_version']
    assert hardware_facts['product_name']
    assert hardware_facts['product_serial']

# Generated at 2022-06-11 02:29:37.869716
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    # fake module
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    # fake facts
    collected_facts = {
        'ansible_architecture': 'powerpc',
        'ansible_system': 'AIX',
        'ansible_distribution': 'AIX',
    }

    # populate hardware facts
    hardware = AIXHardware(module)
    facts = hardware.populate(collected_facts=collected_facts)

    # processor facts
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts

    # memory facts
    assert 'swapfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'memfree_mb' in facts

# Generated at 2022-06-11 02:29:44.359003
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = MagicMock()


# Generated at 2022-06-11 02:29:48.500477
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    hardware = AIXHardware()
    cpu_facts = hardware.get_cpu_facts()

    assert 'processor' in cpu_facts
    assert cpu_facts['processor']
    assert 'processor_count' in cpu_facts
    assert cpu_facts['processor_count']
    assert 'processor_cores' in cpu_facts
    assert cpu_facts['processor_cores']


# Generated at 2022-06-11 02:29:54.022779
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    test_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    test_module.run_command = MagicMock(return_value=(0, out_lsdev, err_lsdev))
    test_module.get_bin_path = MagicMock(return_value='/usr/sbin/lsdev')

    test_hw = AIXHardware(test_module)
    cpu_facts = test_hw.get_cpu_facts()
    assert cpu_facts['processor'] == 'PowerPC_POWER8'
    assert cpu_facts['processor_cores'] == 4
    assert cpu_facts['processor_count'] == 8

