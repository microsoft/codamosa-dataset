

# Generated at 2022-06-11 02:22:37.006339
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    facts = hardware.get_dmi_facts()
    keys = ['firmware_version', 'product_serial', 'lpar_info', 'product_name']
    for key in keys:
        assert key in facts


# Generated at 2022-06-11 02:22:42.193864
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    from ansible.module_utils.facts.collector import Collector
    obj = Collector()
    hw_col = AIXHardwareCollector(obj)
    assert hw_col._platform == 'AIX'
    assert hw_col._fact_class == AIXHardware


# Generated at 2022-06-11 02:22:48.087069
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )

    hardware = AIXHardware(module=module)
    (cpu_facts) = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'PowerPC_POWER8'
    assert cpu_facts['processor_cores'] == 4
    assert cpu_facts['processor_count'] == 2



# Generated at 2022-06-11 02:22:52.408957
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hw = AIXHardwareCollector()
    assert hw._platform == 'AIX'
    assert hw._fact_class == AIXHardware
    assert isinstance(hw._fact_class({}), AIXHardware)


# Generated at 2022-06-11 02:23:01.046979
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_collector = AIXHardwareCollector(module=module)
    facts = hardware_collector.collect()
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'memfree_mb' in facts
    assert 'memtotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'dmi' in facts
    assert 'vgs' in facts
    assert 'devices' in facts
    assert 'mounts' in facts


# Generated at 2022-06-11 02:23:05.963181
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    hardware = AIXHardware(module)
    hardware.get_cpu_facts()
    assert module.cpu_data == {
        'processor': [u'series'],
        'processor_cores': 2,
        'processor_count': 2}



# Generated at 2022-06-11 02:23:12.910979
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    test_data = """
rootvg:
    PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
    hdisk0            active            546         0           00..00..00..00..00
    hdisk1            active            546         113         00..00..00..21..92
realsyncvg:
    PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
    hdisk74           active            1999        6           00..00..00..00..06
testvg:
    PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
    hdisk105          active            999         838         200..39..199..200..200
    hdisk106          active            999         599         200..00..00..199..200
"""
    aixhard

# Generated at 2022-06-11 02:23:20.635693
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    aix_hardware = AIXHardware({})


# Generated at 2022-06-11 02:23:30.419322
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(
        argument_spec=dict(
            filter=dict(required=False),
            gather_subset=dict(required=False),
        ),
    )
    hardware = AIXHardware(module)

    # Test get_device_facts for path /usr/bin/lsdev
    lsdev_cmd = hardware.module.get_bin_path('lsdev', True)

    rc, out_lsdev, err = hardware.module.run_command(lsdev_cmd)

    device_facts = hardware.get_device_facts()
    assert len(device_facts['devices']) > 0

    # For each device in device_facts verify the attributes and state
    for device_name in device_facts['devices']:
        assert len(device_facts['devices'][device_name]['attributes']) > 0


# Generated at 2022-06-11 02:23:40.999968
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware

    hardware = AIXHardware(dict(module=dict()))


# Generated at 2022-06-11 02:24:02.321004
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )

    hardware = AIXHardware(module)
    facts = hardware.get_mount_facts()

    assert 'mounts' in facts

# Generated at 2022-06-11 02:24:13.422298
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    # Use empty module as dummy class
    class TestModule(object):
        def run_command(self, command, use_unsafe_shell=False):

            # Run command
            if "lsattr -El sys0 -a fwversion" in command:
                # Return code, output, error
                return (0, "System Firmware Version: IBM,ASM12300 ", "")

            elif "lsconf -b sys0" in command:
                # Return code, output, error
                return (0, "Machine Serial Number: S4A4K4", "")

            # Run command
            if "bootinfo -b" in command:
                # Return code, output, error
                return (0, "FIRMWARE=IBM,ASM12300", "")

# Generated at 2022-06-11 02:24:22.924997
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    class _AIXHardwareModule(object):
        def __init__(self):
            self.params = None

        def get_bin_path(self, binary):
            return binary

        def run_command(self, cmd, use_unsafe_shell=False):
            p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=False)
            out, err = p.communicate()
            return 0, out, err

    ah = AIXHardware(_AIXHardwareModule())

    vgs_facts = ah._get_vgs_facts()
    assert 'vgs' in vgs_facts
    assert 'rootvg' in vgs_facts['vgs']
    assert 'testvg' in vgs_facts['vgs']
    assert vgs_facts

# Generated at 2022-06-11 02:24:32.642130
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    # Prepare for test
    test_class = AIXHardware()
    test_class.module = MockModule()
    test_class.module.get_bin_path = Mock()
    test_class.module.run_command = MockModule.run_command

# Generated at 2022-06-11 02:24:44.057118
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModuleMock(dict(ANSIBLE_MODULE_ARGS=dict(gather_subset='all')))
    ansible_facts = AIXHardware(module).populate()
    assert isinstance(ansible_facts['ansible_devices'], list)
    assert isinstance(ansible_facts['ansible_devices'][0], str)
    assert isinstance(ansible_facts['ansible_machine'], str)
    assert isinstance(ansible_facts['ansible_machine_id'], str)
    assert isinstance(ansible_facts['ansible_system'], str)
    assert isinstance(ansible_facts['ansible_system_vendor'], str)
    assert isinstance(ansible_facts['ansible_userspace_architecture'], str)

# Generated at 2022-06-11 02:24:45.279895
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    my_module = AIXHardware()
    assert my_module is not None

# Generated at 2022-06-11 02:24:53.964478
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    lsvg_path = module.get_bin_path('lsvg')
    xargs_path = module.get_bin_path('xargs')
    cmd = "%s -o | %s %s -p" % (lsvg_path, xargs_path, lsvg_path)
    rc, out, err = module.run_command(cmd, use_unsafe_shell=True)

    ah = AIXHardware(module)


# Generated at 2022-06-11 02:24:56.073502
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    collector = AIXHardwareCollector()
    assert collector.__class__ == AIXHardwareCollector

# Generated at 2022-06-11 02:25:09.402963
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    sample_out_lsdev = ('proc0 Available 00-00 Processor\n'
                        'proc4 Available 00-04 Processor\n'
                        'proc6 Available 00-06 Processor\n'
                        'proc8 Available 00-08 Processor\n'
                        'proc10 Available 00-10 Processor\n')
    sample_out_lsattr = 'type PowerPC_POWER8'

    module = AnsibleModule(argument_spec=dict())
    module.run_command = Mock(return_value=(0, sample_out_lsdev, None))
    module.get_bin_path = Mock(return_value='/usr/sbin/lsdev')

    aixhw = AIXHardware(module)
    results = aixhw.get_cpu_facts()

    assert results['processor_count'] == 2

# Generated at 2022-06-11 02:25:11.748635
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware_obj = AIXHardware(module)
    hardware_obj.get_device_facts()

# Generated at 2022-06-11 02:25:37.669464
# Unit test for method get_dmi_facts of class AIXHardware

# Generated at 2022-06-11 02:25:40.601278
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    obj = AIXHardware(module)
    obj.populate()
    module.exit_json(ansible_facts={"ansible_hardware": obj.get_device_facts()})


# Generated at 2022-06-11 02:25:47.609566
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    #set up test environment
    module = AnsibleModule(argument_spec={})
    m_open = mock_open()

# Generated at 2022-06-11 02:25:59.521895
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec={}
    )

    aixhardware = AIXHardware(module)

    FAKE_OUT_LSDEV = 'proc0 Available 00-00 Processor\n' \
                     'proc1 Available 00-01 Processor\n' \
                     'proc2 Available 00-02 Processor\n' \
                     'proc3 Available 00-03 Processor\n' \
                     'proc4 Available 00-04 Processor\n' \
                     'proc5 Available 00-05 Processor\n' \
                     'proc6 Available 00-06 Processor\n' \
                     'proc7 Available 00-07 Processor\n' \
                     'proc8 Available 00-08 Processor\n'
    module.run_command = MagicMock(return_value=(0, FAKE_OUT_LSDEV, ''))

    FAKE_OUT_LS

# Generated at 2022-06-11 02:26:09.495758
# Unit test for method get_vgs_facts of class AIXHardware

# Generated at 2022-06-11 02:26:12.181833
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardwareCollector = AIXHardwareCollector()
    assert hardwareCollector._platform == 'AIX'
    assert hardwareCollector._fact_class == AIXHardware



# Generated at 2022-06-11 02:26:25.947419
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec=dict())
    fake_lsdev_cmd = '/usr/bin/lsdev'
    fake_lsattr_cmd = '/usr/bin/lsattr'

# Generated at 2022-06-11 02:26:37.631233
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModuleMock()

# Generated at 2022-06-11 02:26:47.521752
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)

    hardware.populate()

    # Currently have only those facts reported by AIX
    # aix facts
    assert hardware.facts['processor']
    assert hardware.facts['processor_count']
    assert hardware.facts['processor_cores']
    assert hardware.facts['memtotal_mb']
    assert hardware.facts['memfree_mb']
    assert hardware.facts['swaptotal_mb']
    assert hardware.facts['swapfree_mb']
    assert hardware.facts['firmware_version']
    assert hardware.facts['product_serial']
    assert hardware.facts['lpar_info']
    assert hardware.facts['product_name']
    assert hardware.facts['vgs']
    assert hardware.facts['mounts']

# Generated at 2022-06-11 02:26:58.140532
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    class_mock = AIXHardware({}, {})
    class_mock.module.run_command = lambda x: (0, 'rs232 0 Available 00-08', '')

    assert {'devices': {'rs232': {'attributes': {}, 'type': '0', 'state': 'Available'}}} == class_mock.get_device_facts()

    class_mock = AIXHardware({}, {})
    class_mock.module.run_command = lambda x: (0, 'rs232 0 Available 00-08\nrs232 0 Available 00-21\n', '')

    assert {'devices': {'rs232': {'attributes': {}, 'type': '0', 'state': 'Available'}}}, class_mock.get_device_facts()


# Generated at 2022-06-11 02:27:45.509270
# Unit test for method get_mount_facts of class AIXHardware

# Generated at 2022-06-11 02:27:55.782674
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(gather_subset=dict(default=['all'], type='list'))
    )

    hardware_collector = AIXHardwareCollector(module=module)
    hardware_collector.collect()

    hardware = module.exit_json['ansible_facts']['hardware']
    assert hardware['processor_count'] == 2
    assert hardware['processor'] == 'PowerPC_POWER7'
    assert hardware['processor_cores'] == 1
    assert hardware['memtotal_mb'] == 20331
    assert hardware['memfree_mb'] == 1864
    assert hardware['swaptotal_mb'] == 0
    assert hardware['swapfree_mb'] == 0
    assert hardware['firmware_version'] == 'V7R1M0.D002031'

# Generated at 2022-06-11 02:28:06.248561
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    # Mock the function run_command, then the function get_device_facts will return
    # attributes of device ent0.
    def run_command_mock(module, args, check_rc=True, close_fds=True, executable=None,
                         use_unsafe_shell=False, data=None, binary_data=False):
        class Commands:
            def __init__(self, args):
                self.args = args

            def __call__(self, *args, **kwargs):
                if self.args[0] == 'lsdev':
                    out = 'ent0 Available 01-08-00                Ethernet IVE\n'
                    rc = 0
                    err = None

# Generated at 2022-06-11 02:28:13.689546
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_collector = AIXHardwareCollector(module=module)
    hardware = hardware_collector.collect(module=module, collected_facts=dict())
    assert hardware.memfree_mb == 0
    assert hardware.memtotal_mb == 0
    assert hardware.swaptotal_mb == 0
    assert hardware.swapfree_mb == 0
    assert hardware.processors == ['']
    assert hardware.processor_cores == 0
    assert hardware.processor_count == 0
    assert hardware.firmware_version is None
    assert hardware.product_serial is None
    assert hardware.lpar_info is None
    assert hardware.product_name is None
    assert hardware.devices is {}
    assert hardware.mounts == []
    assert hardware.vgs == {}

# Generated at 2022-06-11 02:28:25.165896
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    from ansible.module_utils.facts import ModuleExitException
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch

    class TestAIXHardware:
        def __init__(self):
            pass

        def get_bin_path(self, command, required=False):
            if command == 'lsvg':
                return '/usr/sbin/lsvg'
            elif command == 'xargs':
                return '/usr/bin/xargs'

        def run_command(self, cmd, use_unsafe_shell=False):
            rc = 0
            err = ''

# Generated at 2022-06-11 02:28:29.375901
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():

    module = AnsibleModule(argument_spec={})
    facts = AIXHardware(module).get_dmi_facts()
    assert 'firmware_version' in facts
    assert 'product_serial' in facts


# Generated at 2022-06-11 02:28:38.828394
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    class ModuleStub(object):
        @staticmethod
        def run_command(*args, **kwargs):
            if args[0][-12:] == '/lsdev -Cc cpu':
                return 0, 'proc0 Available 64-bit Processor  (dlpar) \nproc1 Defined   64-bit Processor  (dlpar)', ''
            elif args[0] == '/usr/sbin/lsattr -El proc0 -a smt_threads':
                return 0, 'smt_threads 8 True', ''
            elif args[0][-12:] == '/lsattr -El proc0 -a type':
                return 0, 'type PowerPC_POWER8', ''

    class HardwareStub(object):
        platform = 'AIX'

        def __init__(self):
            self.module = ModuleStub()

# Generated at 2022-06-11 02:28:46.738097
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    """Unit test for method get_mount_facts of class AIXHardware"""
    # normal mount
    line = "/dev/hd1 on / (jfs, NFS exported, local) "
    fields = line.split()
    assert re.match('^/', fields[0])
    mount = fields[1]
    mount_info = {'mount': mount,
                  'device': fields[0],
                  'fstype': fields[2],
                  'options': fields[6],
                  'time': '%s %s %s' % (fields[3], fields[4], fields[5])}
    # check calling get_mount_size
    assert mount_info.update(get_mount_size(mount)) == None
    mounts = [mount_info]

    # nfs mount

# Generated at 2022-06-11 02:28:54.169996
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    from ansible_collections.misc.not_a_real_collection.tests.unit.compat import unittest
    from ansible_collections.misc.not_a_real_collection.tests.unit.compat.mock import MagicMock, patch

    class TestAIXHardware(unittest.TestCase):

        def setUp(self):
            self.test_AIX = AIXHardware()

        def tearDown(self):
            pass


# Generated at 2022-06-11 02:29:03.781883
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    from ansible.module_utils.facts.aix.hardware import AIXHardware
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import FactsParseException
    from ansible.module_utils._text import to_bytes
    class CollectedFacts(dict):
        def __init__(self):
            self['ansible_facts'] = {}

    result = CollectedFacts()
    a = AIXHardware({})
    module = BaseFactCollector(
        {
            '_ansible_no_log': False,
            '_ansible_facts': result
        },
        {},
        {}
    )

    module.get_bin_path = lambda x: x

# Generated at 2022-06-11 02:30:44.669297
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    class DummyModule():
        def __init__(self):
            self.params = dict()
            self.params['base_facts_dir'] = os.path.dirname(__file__)
        def get_bin_path(self, arg, opt_dirs=[]):
            return "%s/bin/%s" % (self.params['base_facts_dir'], arg)
        def run_command(self, cmd, use_unsafe_shell=False):
            file_read = open("%s/files/%s" % (self.params['base_facts_dir'], cmd.split()[-1]), 'r').read()
            return 0, file_read, None
    module = DummyModule()

    test_object = AIXHardware()
    devices = test_object.get_device_facts()

   

# Generated at 2022-06-11 02:30:54.926049
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    aix_hardware = AIXHardware()
    aix_hardware.module = MockModule()
    aix_hardware.module.run_command.return_value = (0, test_data, '')
    test_data = """node             mounted        mounted over    vfs   date        options
----------------  --------------  ---------------  -----  ----------  ---------------
/dev/hd4          /usr            /home            jfs2   May 13 10:42  rw,log=/dev/hd8
/dev/hd2          /               /usr             jfs2   May 13 10:42  rw,log=/dev/hd8"""
    result = aix_hardware.get_mount_facts()
    assert result['mounts'][0]['mount'] == '/usr'
    assert result['mounts'][0]['device']

# Generated at 2022-06-11 02:31:04.480729
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    test_module = AnsibleModule(argument_spec=dict())
    test_AIXHardware = AIXHardware(test_module)

    # Test lsdev command
    test_lsdev_cmd = test_AIXHardware.module.get_bin_path('lsdev', True)
    test_lsattr_cmd = test_AIXHardware.module.get_bin_path('lsattr', True)

    # Test aix deviceless devices
    devices = {
        "hdisk2": {
            "state": "Available",
            "type": "Device was dynamically defined."
        }
    }


# Generated at 2022-06-11 02:31:10.321863
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    aix_hardware = AIXHardware()
    memory_facts = aix_hardware.get_memory_facts()
    assert 'memtotal_mb' in memory_facts
    assert 'memfree_mb' in memory_facts
    assert 'swaptotal_mb' in memory_facts
    assert 'swapfree_mb' in memory_facts



# Generated at 2022-06-11 02:31:19.506679
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    hardware = AIXHardware()
    hardware.module = MagicMock()
    hardware.module.run_command.return_value = (0, 'IBM,8233-E8B hello', '')
    hardware.module.get_bin_path.return_value = '/usr/sbin/lsconf'
    dmi_facts = hardware.get_dmi_facts()

    assert dmi_facts['firmware_version'] == '8233-E8B'
    assert dmi_facts['product_serial'] == 'hello'
    assert dmi_facts['lpar_info'] == '1'
    assert dmi_facts['product_name'] == 'POWER8'

# Generated at 2022-06-11 02:31:22.370219
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    f = AIXHardware()

    # test method get_mount_facts
    mounts = f.get_mount_facts()
    assert 'mounts' in mounts

    for m in mounts['mounts']:
        for key in m.keys():
            assert len(m[key]) > 0



# Generated at 2022-06-11 02:31:29.461680
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    ahw = AIXHardware(module)

    # Test with data
    vgs_facts = ahw.get_vgs_facts()
    assert 'vgs' in vgs_facts
    assert 'PV_NAME' in vgs_facts['vgs']['rootvg'][0]

    # Test without data
    ahw.module.run_command = MagicMock(return_value=(1, '', ''))
    vgs_facts = ahw.get_vgs_facts()
    assert 'vgs' in vgs_facts

# unit test for method get_mount_facts of class AIXHardware

# Generated at 2022-06-11 02:31:36.132015
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import get_collector_for_platform

    class TestModule:
        def __init__(self):
            self.run_command = run_command_mock

        def get_bin_path(self, executable, required=False):
            return executable

        def fail_json(self, *args, **kwargs):
            pass


# Generated at 2022-06-11 02:31:41.405362
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
        ),
        supports_check_mode=False,
    )

    if not HAS_AIXTOOLS:
        module.fail_json(msg="AIXTOOLS not found")

    aixhw = AIXHardware(module)
    vgs_facts = aixhw.get_vgs_facts()
    module.exit_json(ansible_facts=vgs_facts)



# Generated at 2022-06-11 02:31:48.344084
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    """ Unit test for method get_dmi_facts of class AIXHardware """
