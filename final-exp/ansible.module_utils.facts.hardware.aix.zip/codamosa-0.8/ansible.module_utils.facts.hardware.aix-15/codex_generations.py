

# Generated at 2022-06-11 02:22:41.185159
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    test_class = AIXHardware()

# Generated at 2022-06-11 02:22:46.541498
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    args = ({"PATH": "/usr/bin"},)
    set_module_args(args)

    ah = AIXHardware(module=AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    ))

    mounts = ah.get_mount_facts()

    assert mounts['mounts'] != []

# Generated at 2022-06-11 02:22:48.790213
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    hardware = AIXHardware('testmodule')
    hardware.get_mount_facts()

# Generated at 2022-06-11 02:23:00.796803
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    class MockModule:
        def __init__(self):
            self.check_mode = False
            self.run_command_return_value = None

        def run_command(self, command, use_unsafe_shell=False):
            return self.run_command_return_value

        def get_bin_path(self, path, opt_dirs=[]):
            return path

        def set_run_command_return_value(self, value):
            self.run_command_return_value = value

    mock_module = MockModule()

# Generated at 2022-06-11 02:23:05.720649
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    assert hardware.get_memory_facts() == {'swapfree_mb': 0, 'memtotal_mb': 4024, 'memfree_mb': 0, 'swaptotal_mb': 0}


# Generated at 2022-06-11 02:23:06.343197
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    pass

# Generated at 2022-06-11 02:23:10.456491
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector.platform == 'AIX'
    assert hardware_collector.fact_class == AIXHardware


# Generated at 2022-06-11 02:23:15.092115
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    hardware = AIXHardware(module)
    result = hardware.get_cpu_facts()
    assert result == {'processor_cores': 1,
                     'processor_count': 2,
                     'processor': 'PowerPC_POWER9'}



# Generated at 2022-06-11 02:23:22.993663
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    import sys
    import os
    sys.path.append(os.path.realpath(os.path.dirname(os.path.realpath(__file__)) + '/../..'))
    from ansible.module_utils.facts.collector import TestModule

    tm = TestModule('/dev/null')
    hinfo = AIXHardwareCollector(tm).collect()

    assert hinfo["processor"]
    assert hinfo["processor_cores"] in (1, 2, 4, 8)
    assert hinfo["processor_count"] > 0


# Generated at 2022-06-11 02:23:29.418862
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)

    dmi_facts_output = hardware.get_dmi_facts()

    assert dmi_facts_output["firmware_version"] == "7.2.0.0.1"
    assert dmi_facts_output["product_serial"] == "06A0620C00"
    assert dmi_facts_output["lpar_info"] == "lpar:0:rootvg:"


# Generated at 2022-06-11 02:23:50.940242
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False)
    ah = AIXHardware(module=module)
    out = ah.get_memory_facts()
    assert out['memtotal_mb'] == 3584

# Generated at 2022-06-11 02:24:02.980695
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # setup a default system with some dmi facts
    dmi_facts_dict = {
        "firmware_version": "IBM,M1.1.1.1",
        "lpar_info": "001-001",
        "product_name": "IBM,8286-41A",
        "product_serial": "YM0011111111"
    }
    # create an AIXHardware object
    hardware_module = AIXHardware(module)

    # create a system that has the dmi facts
    class DMI_System(object):
        pass
    dmi_system = DMI_System()

# Generated at 2022-06-11 02:24:13.571959
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    # Setup
    class TestAIXModule:
        def __init__(self):
            self.run_command_results = [0, '/:', '', '']
            self.run_command_calls = []
            self.params = dict(gather_subset='!all,!min,!virtual')

        def get_bin_path(self, name):
            return name

        def run_command(self, args, use_unsafe_shell=False):
            self.run_command_calls.append(args)
            return self.run_command_results

    class TestAIXHardware(AIXHardware):
        def __init__(self, module):
            self.module = module
            self.facts = {}

    ah = TestAIXHardware(TestAIXModule())

    # Exercise
    ah.get_mount

# Generated at 2022-06-11 02:24:16.705655
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    """
    Unit test for constructor of class AIXHardwareCollector
    """
    module = AnsibleModuleMock()
    my_obj = AIXHardwareCollector(module)
    assert my_obj


# Generated at 2022-06-11 02:24:27.637909
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    test_module_argv = "--types hardware"
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)

    module.exit_json = mock.MagicMock()
    fd, tmpfile = mkstemp()

    test_out = """fwversion IBM,8233-E8B
Machine Serial Number                IBM,9900012345
Part Number                          43X9251
System Model                         IBM,8233-E8B"""
    with open(tmpfile, 'w') as file:
        file.write(test_out)

    chmod(tmpfile, 0o755)

    module.run_command = mock.Mock(return_value=(0, test_out, ""))
    module.get_bin_path = mock.Mock(return_value=tmpfile)

    dmi_

# Generated at 2022-06-11 02:24:35.181446
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    '''
    This test compares the result of get_vgs_facts with the expected value.
    '''
    from ansible.module_utils.facts.hardware.aix import AIXHardware as aixhw
    from ansible.module_utils.facts import FactCollector

    aixhw_instance = aixhw()
    aixhw_instance.module = FactCollector()
    vgs_facts = aixhw_instance.get_vgs_facts()
    # Expected dict returned by get_vgs_facts

# Generated at 2022-06-11 02:24:37.694741
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    facts = AIXHardware().get_cpu_facts()
    assert 'processor_count' in facts
    assert 'processor' in facts

# Generated at 2022-06-11 02:24:43.557173
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)

    hardware.get_memory_facts()
    assert hardware.memory["memfree_mb"] >= 0
    assert hardware.memory["memtotal_mb"] >= 0
    assert hardware.memory["swapfree_mb"] >= 0
    assert hardware.memory["swaptotal_mb"] >= 0


# Generated at 2022-06-11 02:24:47.518459
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(
        argument_spec=dict(
            filters=dict(type='dict', default=dict())
        )
    )
    device_facts = _get_devices_facts()
    module.exit_json(ansible_facts=dict(devices=device_facts))



# Generated at 2022-06-11 02:24:55.223628
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    facts_list = []

    # Test 1: use test device #1 with following structure
    # rootvg:
    # PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
    # hdisk0            active            546         0           00..00..00..00..00
    # hdisk1            active            546         113         00..00..00..21..92
    # realsyncvg:
    # PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
    # hdisk74           active            1999        6           00..00..00..00..06
    # testvg:
    # PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
    # hdisk105          active            999         838         200..39..199..200..200
   

# Generated at 2022-06-11 02:25:42.352002
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_facts = AIXHardware(module).populate()
    assert hardware_facts['firmware_version'] == 'IBM,8233-E8B'
    assert hardware_facts['lpar_info'] == '1 System partition'
    assert hardware_facts['product_name'] == 'IBM,8233-E8B'
    assert hardware_facts['product_serial'] == 'YKRN0706'
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['processor'] == 'POWER9'
    assert hardware_facts['processor_cores'] > 0

# Generated at 2022-06-11 02:25:48.654477
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    import tempfile

    lsdev_data = '''
hdisk0 Available 09-08-10-4,0          Other FC SCSI Disk Drive
cd0    Available 0580-082              CD-ROM Drive
        N/A
'''


# Generated at 2022-06-11 02:25:54.437357
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module=module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-11 02:25:58.234459
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    '''
    Initialize and test constructor
    '''
    aix_hw_c = AIXHardwareCollector()

    assert(isinstance(aix_hw_c, AIXHardwareCollector))


# Generated at 2022-06-11 02:26:06.691299
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts.utils import get_file_content

    testdevice = AIXHardware({})

    lsconf_stdout = get_file_content('utils/fixtures/lsconf_stdout.txt')
    testdevice.module.run_command = mock.MagicMock(return_value=(0, lsconf_stdout, None))
    expected_firmware_version = '0'
    expected_lpar_info = '1'
    expected_product_name = '2'
    expected_product_serial = '3'

    lsdev_stdout = get_file_content('utils/fixtures/dmi_stdout.txt')
    test

# Generated at 2022-06-11 02:26:14.492209
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    if not AIXHardwareCollector.test(module, 'AIXHardware'):
        module.fail_json(msg='Could not load AIXHardwareCollector')
    hardware_collector = AIXHardwareCollector(module=module)
    hardware = hardware_collector.collect(None, [])

    assert hardware.get('firmware_version') is not None
    assert hardware.get('product_serial') is not None
    assert hardware.get('product_name') is not None

# Generated at 2022-06-11 02:26:17.515710
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    test_obj = AIXHardwareCollector()
    assert test_obj
    assert test_obj._platform == 'AIX'
    assert test_obj._fact_class == AIXHardware

# Generated at 2022-06-11 02:26:30.187300
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    from ansible.compat.tests.mock import MagicMock
    test_module = MagicMock()
    test_module.run_command.return_value = (0, 'hdisk0 Available 04-08-00-1,0  8192MB 8192MB 8192MB', None)
    test_module.get_bin_path.return_value = 'command_path'

    aixhw = AIXHardware(test_module)
    aixhw.get_device_facts()

    assert test_module.run_command.call_args[0][0] == 'command_path -o'
    assert test_module.run_command.call_args[0][1] == True
    assert test_module.run_command.call_args[1]['use_unsafe_shell'] == True

# Generated at 2022-06-11 02:26:40.680503
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    class AIXHardware(AIXHardware):
        @staticmethod
        def module_run_command(cmd):
            if cmd == "/usr/sbin/lsattr -El sys0 -a fwversion":
                return 0, "fwversion IBM,9110-51A-MP-SN0511", ""
            elif cmd == "/usr/bin/lsconf":
                return 0, "System Model: IBM,9110-51A-MP-SN0511\nMachine Serial Number: 0511\nLPAR info:\n  LPAR Name: foo\n  Max. Processors in system: 1\n  Max. Virtual CPUs in system: 1\n  Processor Mode: Shared\n  Processor Pool ID: 0\n  Boot Mode: SMS\n  Alternate Boot Modes: Normal", ""
            return 1, "", ""
    hw = AIXHardware

# Generated at 2022-06-11 02:26:42.904229
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    collector = AIXHardwareCollector()
    assert collector.platform == 'AIX'
    assert collector.fact_class == AIXHardware


# Generated at 2022-06-11 02:28:08.030526
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    test_AIXHw = AIXHardware()
    test_AIXHw.module = AnsibleModule(argument_spec={'path': dict(required=False, type='str')})

# Generated at 2022-06-11 02:28:17.876129
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    hardware_facts_class = AIXHardware()
    hardware_facts_class.populate()
    hardware_facts_class.module.run_command = run_command_generic
    dmi_facts = hardware_facts_class.get_dmi_facts()

    assert dmi_facts['firmware_version'] == '2.2'
    assert dmi_facts['product_serial'] == '8A1D0D5A7C00'
    assert dmi_facts['lpar_info'] == '"None"'
    assert dmi_facts['product_name'] == 'IBM,8286-41A'



# Generated at 2022-06-11 02:28:26.977583
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    mock_module = type('AnsibleModule', (object,), {
        'run_command': lambda *_: (0, _[1], '')
    })
    hardware = AIXHardware(mock_module)
    facts = hardware.get_dmi_facts()

    assert facts['firmware_version'] == "IBM,6200"
    assert facts['product_serial'] == "02V7Y13"
    assert facts['lpar_info'] == "01-C99C4C4B4C4C4C4C"
    assert facts['product_name'] == "8231-E2D"


# Generated at 2022-06-11 02:28:37.341939
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    test_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    test_module.run_command = MagicMock()

    lsdev_cmd = '/usr/bin/lsdev'
    lsattr_cmd = '/usr/bin/lsattr'

    lsdev_out = """
name  status  description
hdisk0  Available  none
hdisk1  Available  none
hdisk2  Defined    none
    """
    lsattr1_out = """
attribute value description user_settable
dev_size    136    Size in MB  False
"""

# Generated at 2022-06-11 02:28:38.040765
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()

# Generated at 2022-06-11 02:28:41.290305
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    x = AIXHardwareCollector()
    assert x.platform == 'AIX'
    assert x._platform == 'AIX'
    assert x._fact_class == AIXHardware

# Generated at 2022-06-11 02:28:54.604228
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    from ansible.actions.module_utils import basic

    class FakeModule(object):
        def __init__(self, **kwargs):
            self.run_command = basic.run_command

        def get_bin_path(self, executable, required=False):
            cmd_path = basic.find_executable(executable)
            if not cmd_path:
                raise Exception("%s not found" % executable)
            return cmd_path

    my_module = FakeModule()

    class AIXHardwareTest(object):
        platform = 'AIX'

    if AIXHardwareTest.platform == 'AIX':
        device_facts = AIXHardware(my_module).get_device_facts()
        assert 'devices' in device_facts
        assert 'cpu0' in device_facts['devices']

# Generated at 2022-06-11 02:29:04.058399
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    """Unit tests for get_device_facts() method of AIXHardware class.
    The test plays with a dictionary of devices that are defined to be returned
    by output of lsdev command. Method get_device_facts() should return a
    dictionary that contains information about all devices. The test is checking
    whether method get_device_facts() is able to return an expected output for
    given input.
    """
    import sys
    import types
    import pytest


# Generated at 2022-06-11 02:29:10.506758
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    test_module = AnsibleModule(argument_spec={'bin_path': dict(type='str')})
    test_module_params = test_module.params
    test_module.params = {}
    test_AIXHardware = AIXHardware(test_module)
    test_AIXHardware.module.params = test_module_params
    vgs_facts = test_AIXHardware.get_vgs_facts()
    assert 'vgs' in vgs_facts



# Generated at 2022-06-11 02:29:14.411500
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    facts = hardware.get_cpu_facts()
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts