

# Generated at 2022-06-11 02:22:32.227766
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    collector = AIXHardwareCollector()
    assert collector._platform == 'AIX'
    assert collector._fact_class == AIXHardware

# Generated at 2022-06-11 02:22:35.836632
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    """ Unit test for constructor of class AIXHardwareCollector """
    aix_hardware_collector = AIXHardwareCollector()
    assert aix_hardware_collector._platform == 'AIX'
    assert aix_hardware_collector._fact_class == AIXHardware

# Generated at 2022-06-11 02:22:47.828992
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    """ Unit test on aix.py:AIXHardware.get_mount_facts()
    """


# Generated at 2022-06-11 02:22:59.946951
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    h_obj = AIXHardware()


# Generated at 2022-06-11 02:23:06.055032
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    '''Unit test for method get_cpu_facts of class AIXHardware'''
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    if hardware.get_cpu_facts() == {'processor': ['POWER8'],
                                    'processor_count': 2,
                                    'processor_cores': 8}:
        return True
    else:
        return False



# Generated at 2022-06-11 02:23:10.243157
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    aix_hw = AIXHardware({})
    dmi_facts = aix_hw.get_dmi_facts()
    assert dmi_facts['firmware_version'] is not None
    assert dmi_facts['product_serial'] is not None
    assert dmi_facts['lpar_info'] is not None
    assert dmi_facts['product_name'] is not None

# Generated at 2022-06-11 02:23:18.307359
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    class FakeModule(object):
        """ Class to mock a module. """
        def __init__(self):
            self.params = {}
            self.args = {}
            self.run_command = self._run_command

        def get_bin_path(self, name, required=True):
            """ Fake class to mock out get_bin_path. """
            return '/usr/bin/' + name

        def _run_command(self, command, use_unsafe_shell=False, check_rc=False):
            """ Fake method to mock run_command. """
            if command.startswith('/usr/sbin/lsattr'):
                out = 'fwversion IBM,8233-E8B'
                return 0, out, ''

# Generated at 2022-06-11 02:23:27.008148
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    aix = AIXHardware()

    out = ("proc0 Available 00-00 Processor\n"
           "proc1 Available 00-01 Processor\n"
           "proc2 Available 00-02 Processor\n"
           "proc3 Available 00-03 Processor\n"
           "proc4 Available 00-04 Processor\n"
           "proc5 Available 00-05 Processor")

    facts = aix.get_cpu_facts(out)

    assert facts['processor_count'] == 6
    assert facts['processor'] == 'PowerPC_POWER5'
    assert facts['processor_cores'] == 1


# Generated at 2022-06-11 02:23:38.526995
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    # Get aix Hardware instance
    aix_hw = AIXHardware()

    # Some information from lsdev command to test
    # the availability of the cpu.
    #
    # sys0 Available 00-00 Processor
    # proc0 Available 00-00 Processor
    # proc4 Available 00-04 Processor
    lsdev_stdout = 'sys0 Available 00-00 Processor\n' \
                   'proc0 Available 00-00 Processor\n' \
                   'proc4 Available 00-04 Processor\n'

    # Because of the -Cc option of lsdev command,
    # we need to return the class
    def lsdev_fake_command(self, *args, **kwargs):
        # Get the class
        for arg in args:
            if '-Cc' in arg:
                return (0, lsdev_stdout, None)

# Generated at 2022-06-11 02:23:49.943817
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    fake_module = type('AnsibleModule', (), {'run_command': run_command})
    fake_module.get_bin_path = lambda _: '/bin/lsvg'

# Generated at 2022-06-11 02:24:14.159749
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module=module)

    # Prepare end result
    end_result = {'firmware_version': 'IBM,SF240_122',
                  'product_name': 'PowerNV 8408-E8D',
                  'lpar_info': '1 Maximum Entitled Capacity: 0.50 Partition Name: p7aix1',
                  'product_serial': '06B143A'}

    # Call method
    result = hardware.get_dmi_facts()

    # Check result
    assert result == end_result



# Generated at 2022-06-11 02:24:23.105256
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    class MockModule():

        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = []
            self.params['gather_timeout'] = 10

        def get_bin_path(self, binary, required=False):
            if binary == "mount":
                return "/usr/sbin/mount"

# Generated at 2022-06-11 02:24:27.590237
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    module = AnsibleModule(argument_spec={})
    hw_collector = module.params['collector']
    assert hw_collector._platform == 'AIX', 'Expect to receive AIX platform'
    assert type(hw_collector._fact_class()) is AIXHardware, 'Expect to receive AIXHardware class'


# Generated at 2022-06-11 02:24:33.291738
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = type('module', (object,), {
        'run_command': lambda self, cmd: (0, "TestProductName\n", ""),
        'get_bin_path': lambda self, cmd, required: '/bin/true'})()
    h = AIXHardware(module)
    v = h.get_dmi_facts()
    assert 'firmware_version' not in v
    assert 'product_serial' not in v
    assert 'lpar_info' not in v
    assert 'product_name' not in v

# Generated at 2022-06-11 02:24:34.867676
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()

    assert hardware_collector._platform == 'AIX'
    assert hardware_collector._fact_class == AIXHardware

# Generated at 2022-06-11 02:24:40.026951
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():

    options = {'format': 'aix', 'config': ''}

# Generated at 2022-06-11 02:24:41.811038
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector.platform == 'AIX'
    assert hardware_collector.fact_class == AIXHardware


# Generated at 2022-06-11 02:24:50.093074
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = MockAnsibleModule()
    aixhardware = AIXHardware(module=module)

    # test vg with 1 PV and no free PPs

# Generated at 2022-06-11 02:25:00.640198
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    # set up class instance to test methods
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    ah = AIXHardware(module)

# Generated at 2022-06-11 02:25:05.428996
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    facts_collector = AIXHardware()
    facts = facts_collector.populate()
    assert facts['vgs']['rootvg'][0]['free_pps'] == '113'

# Generated at 2022-06-11 02:25:55.606812
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = module.get_bin_path('hardware')
    df = AnsibleFile(hardware)
    lines = df.readlines()
    # If a device has attributes print output for lsattr
    for line in lines:
        if line[1] == "Available":
            fields = line.split()
            device_name = fields[0]
            device_state = fields[1]
            device_type = ' '.join(fields[2:])
            device_attrs = {}
            lsattr_cmd = module.get_bin_path('lsattr')
            rc, out_lsattr, err = module.run_command([lsattr_cmd, '-E', '-l', device_name])
            for attr in out_lsattr.splitlines():
                att

# Generated at 2022-06-11 02:26:05.533809
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    """ Unit test for method get_vgs_facts of class AIXHardware """
    aixhw = AIXHardwareCollector()

    assert(aixhw.facts['vgs']['rootvg'] == [{'pv_state': 'active',
                                             'total_pps': '546',
                                             'pv_name': 'hdisk0',
                                             'free_pps': '0',
                                             'pp_size': '4 megabytes'},
                                            {'pv_state': 'active',
                                             'total_pps': '546',
                                             'pv_name': 'hdisk1',
                                             'free_pps': '113',
                                             'pp_size': '4 megabytes'}])



# Generated at 2022-06-11 02:26:13.375033
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})

    cpu_facts = AIXHardware(module).get_cpu_facts()
    if not cpu_facts['processor']:
        raise AssertionError("processor is not defined")
    if cpu_facts['processor_count'] == 0:
        raise AssertionError("processor_count is zero")
    if cpu_facts['processor_cores'] == 0:
        raise AssertionError("processor_cores is zero")

    module.exit_json(ansible_facts=cpu_facts)


# Generated at 2022-06-11 02:26:26.060388
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    import io
    import unittest.mock

    # create a mock of class for all method calls
    mocked_module_class = unittest.mock.MagicMock()
    mocked_module_class.run_command.return_value = (0, '', '')

    # create a mock of module for only the os.path.exists call
    mocked_module_run_command = unittest.mock.MagicMock()
    mocked_module_run_command.return_value = (0, 'sys0  Firmware: IBM,E1B2 10/20/2011', '')

    # create a mock of module for only the os.path.exists call
    mocked_module_get_bin_path = unittest.mock.MagicMock()
    mocked_module_get_bin_path.return_value

# Generated at 2022-06-11 02:26:32.241113
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    import platform
    import pwd
    import os

    # get current user
    current_user = pwd.getpwuid(os.getuid())[0]

    # create AIXHardware object

# Generated at 2022-06-11 02:26:41.857409
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    class FakeAnsibleModule(object):
        def __init__(self):
            self.run_command = self._run_command

        def _run_command(self, cmd):
            if cmd == '/usr/bin/vmstat -v':
                out = """memory pages:                           1061456
huge pages:                               0
free pages:                               1050073
                                           free               huge                    memory
pages:                           1050073      0                                 1050073

EOA memory pages:                           2022912
free EOA memory pages:                      11415
"""
                return (0, out, '')

# Generated at 2022-06-11 02:26:52.504915
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    class AIXHardwareTester(AIXHardware):
        def __init__(self, module):
            super(AIXHardwareTester, self).__init__(module)

    class ModuleTester:
        def __init__(self):
            self.params = {}
            self.run_command_str = ''
            self.run_command_rc = 0
            self.run_command_out = ''
            self.run_command_err = ''

        def run_command(self, cmd, use_unsafe_shell=False):
            self.run_command_str = cmd
            return self.run_command_rc, self.run_command_out, self.run_command_err

    obj = AIXHardwareTester(ModuleTester())

    # Test case 1: no cpu
    obj.module.run_command_out

# Generated at 2022-06-11 02:27:03.325431
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    # Mock the module object
    module = MockModule()
    # Mock the Hardware class
    hardware = MockHardware()
    # Create an instance of AIXHardware and assign module object to it
    aix_hardware = AIXHardware(module=module)
    # Call method populate
    aix_hardware.populate()
    # Assert that method run_command of module object was called
    module.run_command.assert_called()
    # Assert that method get_bin_path of module object was called
    module.get_bin_path.assert_called()
    # Assert that method get_cpu_facts of class AIXHardware was called
    aix_hardware.get_cpu_facts.assert_called()
    # Assert that method get_memory_facts of class AIXHardware was called
    aix_hardware.get

# Generated at 2022-06-11 02:27:08.393993
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModuleMock()
    hardware = AIXHardware(module=module)
    hardware.get_memory_facts = MagicMock(return_value={'memtotal_mb': 10, 'memfree_mb': 1, 'swaptotal_mb': 10, 'swapfree_mb': 2})
    result = hardware.get_memory_facts()
    assert result['memtotal_mb'] == 10
    assert result['memfree_mb'] == 1
    assert result['swaptotal_mb'] == 10
    assert result['swapfree_mb'] == 2



# Generated at 2022-06-11 02:27:19.991251
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    # initialize test
    m = ModuleStub({})
    m.run_command = run_command_stub

    hw = AIXHardware(m)
    hw_output = hw.get_device_facts()

# Generated at 2022-06-11 02:28:39.681414
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)

    # Test case with output of mount command without options

# Generated at 2022-06-11 02:28:41.271128
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    collector = AIXHardwareCollector()
    assert collector._platform == 'AIX'

# Generated at 2022-06-11 02:28:51.062663
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    facts = AIXHardware('module').populate()
    assert facts['firmware_version']
    assert facts['product_name']
    assert facts['product_serial']
    assert facts['lpar_info']
    assert facts['processor_count']
    assert facts['processor']
    assert facts['processor_cores']
    assert facts['memtotal_mb']
    assert facts['memfree_mb']
    assert facts['swaptotal_mb']
    assert facts['swapfree_mb']
    assert facts['vgs']
    assert facts['devices']
    assert facts['mounts']

# Generated at 2022-06-11 02:28:54.958762
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    hostname = "hostname"
    args = [hostname]
    module = FakeAnsibleModule(args)
    hw = AIXHardware(module)
    result = hw.get_dmi_facts()
    assert result['firmware_version'] == 'AIX,'
    assert result['product_serial'] == 'SERIAL'
    assert result['lpar_info'] == 'lpar_info'
    assert result['product_name'] == 'model'



# Generated at 2022-06-11 02:29:00.756286
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    # testcase 0:
    module = AnsibleModuleMock()
    module.run_command = MagicMock()
    module.run_command.return_value = (0, "memory pages\n986480\nfree pages\n369152", "")
    hw_module = AIXHardware(module)
    hw_module.get_memory_facts()
    module.exit_json.assert_called_with(
        changed=False,
        ansible_facts={'memtotal_mb': 3840, 'swapfree_mb': 0, 'swaptotal_mb': 0, 'memfree_mb': 1440}
    )

    # testcase 1:
    module = AnsibleModuleMock()
    module.run_command = MagicMock()

# Generated at 2022-06-11 02:29:08.627298
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    import sys
    import ansible.module_utils
    aix_hw_collector = AIXHardwareCollector(ansible.module_utils.facts.__file__)
    if sys.version_info >= (3,):
        assert isinstance(aix_hw_collector._platform, str)
        assert isinstance(aix_hw_collector._fact_class.platform, str)
    else:
        assert isinstance(aix_hw_collector._platform, basestring)
        assert isinstance(aix_hw_collector._fact_class.platform, basestring)
    assert isinstance(aix_hw_collector._fact_class, AIXHardware)

# Generated at 2022-06-11 02:29:19.155045
# Unit test for method get_cpu_facts of class AIXHardware

# Generated at 2022-06-11 02:29:28.634444
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    import ansible.module_utils.facts.hardware.aix as aix
    class CustomModule(object):
        def __init__(self):
            self.run_command_calls = []
            self.run_command_responses = []
            self.get_bin_path_returns = []
            self.get_bin_path_dirs = []

        def run_command(self, cmd, **kwargs):
            self.run_command_calls.append(cmd)
            return self.run_command_responses.pop(0)

        def get_bin_path(self, cmd, **kwargs):
            self.get_bin_path_dirs.append(kwargs.get('required', False))
            return self.get_bin_path_returns.pop(0)

    module = CustomModule

# Generated at 2022-06-11 02:29:30.524832
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    assert isinstance(AIXHardwareCollector(), AIXHardwareCollector)


# Generated at 2022-06-11 02:29:37.829456
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    fixture = AIXHardware()
    fixture.module = None
    fixture.module_set_args = None
    fixture.module_set_fact = None
    vgs_facts = fixture.get_vgs_facts()
    assert 'vgs' in vgs_facts
    assert isinstance(vgs_facts['vgs'], dict)
    assert 'rootvg' in vgs_facts['vgs']
    assert 'realsyncvg' in vgs_facts['vgs']
    assert 'testvg' in vgs_facts['vgs']
