

# Generated at 2022-06-11 02:22:34.968310
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    test_module = AnsibleModule(
        argument_spec=dict(gather_subset=dict(required=True, type='list')))

    test_module.params['gather_subset'] = ['devices']

    test_obj = AIXHardware(test_module)
    facts = test_obj.populate()
    assert facts is not None
    assert len(facts['devices']) > 0



# Generated at 2022-06-11 02:22:40.654626
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    test_module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(test_module)

    result = hardware.get_memory_facts()

    assert 'swaptotal_mb' in result
    assert 'swapfree_mb' in result
    assert 'memtotal_mb' in result
    assert 'memfree_mb' in result

# Generated at 2022-06-11 02:22:42.496156
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    assert AIXHardwareCollector._platform == 'AIX'
    assert AIXHardwareCollector._fact_class == AIXHardware

# Generated at 2022-06-11 02:22:51.549610
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts.utils import get_file_content

    aixhardware_instance = AIXHardware()

    # Generate test data
    lsdev_output_for_method_lsdev = get_file_content('tests/unit/module_utils/facts/hardware/aix/lsdev.txt')
    lsattr_output_for_method_lsattr = get_file_content('tests/unit/module_utils/facts/hardware/aix/lsattr.txt')

    test_data = {}
    test_data['lsdev'] = lsdev_output_for_method_lsdev
    test_data['lsattr'] = lsattr_output_for_method_lsattr

    # Generate expected results
   

# Generated at 2022-06-11 02:23:01.128885
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    mock = [
        'proc0 Available 00-00 Processor',
        'proc1 Available 00-02 Processor',
        'proc2 Available 00-04 Processor',
        'proc3 Available 00-06 Processor',
    ]
    module = Mock()
    module.run_command.return_value = (0, '\n'.join(mock), None)
    ah = AIXHardware(module)

    # Call the method under test
    result = ah.get_cpu_facts()

    # Assert
    assert result['processor_count'] == 4
    assert result['processor'] == 'PowerPC_POWER7'
    assert result['processor_cores'] == 1



# Generated at 2022-06-11 02:23:07.134533
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hw = AIXHardware(module)
    facts = hw.get_dmi_facts()
    assert 'firmware_version' in facts
    assert 'product_serial' in facts
    if module.get_bin_path('lsconf'):
        assert 'lpar_info' in facts
        assert 'product_name' in facts



# Generated at 2022-06-11 02:23:16.734694
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    # prep
    module = MagicMock()

# Generated at 2022-06-11 02:23:27.478500
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    """Test get_cpu_facts method of class AIXHardware."""
    try:
        from ansible.module_utils.facts.hardware.aix import AIXHardware
    except ImportError:
        pytest.skip('Failed to import: ansible.module_utils.facts.hardware.aix')
    hardware = AIXHardware({})
    hardware.module.run_command = MagicMock(return_value=(0, 'test', ''))
    hardware.module.get_bin_path = MagicMock(return_value='/bin')

    hardware.get_cpu_facts()
    assert hardware.facts['processor'] == 'test'
    assert hardware.facts['processor_cores'] == 1
    assert hardware.facts['processor_count'] == 1



# Generated at 2022-06-11 02:23:39.036756
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule({})

    hardware = AIXHardware(module)

    # Create an example file with command output for lsdev
    filename = 'mock_lsdev_output'
    lsdev_example_output = \
"""name  status  description
proc0  Available  Processor
proc4  Available  Processor
proc8  Available  Processor
hdisk0  Available  VSCSI Disk Drive
hdisk1  Available  VSCSI Disk Drive
hdisk2  Available  VSCSI Disk Drive
hdisk3  Available  VSCSI Disk Drive
hdisk4  Available  VSCSI Disk Drive"""
    lsdev_example_file = open(filename, 'w')
    lsdev_example_file.write(lsdev_example_output)
    lsdev_example_file.close()

    # Create an example file with command output for

# Generated at 2022-06-11 02:23:50.508851
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():

    module = AnsibleModule(argument_spec=dict())
    hardware = AIXHardware(module)
    hardware_facts = hardware.populate()
    # Processors facts
    assert hardware_facts['processor_count'] == 2
    assert hardware_facts['processor'] == 'PowerPC_POWER8'
    assert hardware_facts['processor_cores'] == 4
    # Memory facts
    assert hardware_facts['memtotal_mb'] == 32752
    assert hardware_facts['memfree_mb'] == 30468
    assert hardware_facts['swaptotal_mb'] == 8193
    assert hardware_facts['swapfree_mb'] == 8182
    # DMI facts
    assert hardware_facts['firmware_version'] == '8233-E8B'

# Generated at 2022-06-11 02:24:12.935944
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    import tests.utils
    module = tests.utils.MockModule('/usr/sbin/lsps -s')
    hardware = AIXHardware(module=module)
    hardware_facts = hardware.get_memory_facts()
    assert hardware_facts['memtotal_mb'] == 8192
    assert hardware_facts['memfree_mb'] == 5120
    assert hardware_facts['swaptotal_mb'] == 5120
    assert hardware_facts['swapfree_mb'] == 5120


# Generated at 2022-06-11 02:24:22.339342
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    from ansible.module_utils.facts.hardware import AIXHardware
    import os
    import shutil
    import tempfile
    import yaml
    test_dir = tempfile.mkdtemp()
    test_files_dir = os.path.join(test_dir, 'test_files')
    os.mkdir(test_files_dir)
    module = FakeModule(test_files_dir)
    hardware_obj = AIXHardware(module)
    shutil.copy(os.path.join(os.path.dirname(__file__), "../../unit/data/facts_extraction_data/aix_lsvg.out"), test_files_dir)

# Generated at 2022-06-11 02:24:30.640924
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware

# Generated at 2022-06-11 02:24:35.159409
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    hardware_collector.collect()
    fact_class = hardware_collector.get_fact_class()
    assert fact_class == AIXHardware

# Generated at 2022-06-11 02:24:40.365144
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():

    class TestModule(object):
        @staticmethod
        def get_bin_path(arg):
            return None

        @staticmethod
        def run_command(arg):
            if arg == '/usr/sbin/lsdev -Cc processor':
                return 0, 'proc0\nAvailable 05-080 Processor\nproc1\nAvailable 05-080 Processor', ''
            if arg == '/usr/sbin/lsattr -El proc0 -a type':
                return 0, 'type PowerPC_POWER7', ''
            if arg == '/usr/sbin/lsattr -El proc0 -a smt_threads':
                return 0, 'smt_threads 2\n', ''
            if arg == '/usr/sbin/lsps -s':
                return 0, 'PAGE SPACE INFORMATION (in MB)\n'
                         

# Generated at 2022-06-11 02:24:49.479864
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    data = {
        'ansible_facts': {
            'ansible_processor': [
                'PowerPC_POWER9'
            ],
            'ansible_processor_cores': 2,
            'ansible_processor_count': 2
        }
    }
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    ah = AIXHardware(module)
    ah.module.run_command = lambda x: (0, 'Available 00-00 Processor', '')
    ah.module.run_command = lambda x: (0, 'PowerPC_POWER9', '')
    ah.module.run_command = lambda x: (0, 'smt_threads 2', '')
    assert data == ah.populate()


# Generated at 2022-06-11 02:24:59.973360
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(gather_subset=dict(default=['all'], type='list'))
    )

    if not HAS_AIX_MODULES:
        module.fail_json(msg='aixtools/sys-utils is required for gathering facts')


# Generated at 2022-06-11 02:25:11.225292
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    mock_module = Mock()
    mock_module.run_command = mock_run_command
    mock_module.get_bin_path = mock_get_bin_path

    aix_hardware = AIXHardware(mock_module)
    dmi_facts = aix_hardware.get_dmi_facts()

    assert dmi_facts['firmware_version'] == 'V7R1M0'
    assert dmi_facts['product_serial'] == '07AC45D'
    assert dmi_facts['lpar_info'] == '1 Type=Shared'
    assert dmi_facts['product_name'] == 'PowerNV 8408-E8D'


# Generated at 2022-06-11 02:25:17.462468
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    import tempfile

    # Generate some fake data
    filename = tempfile.mktemp()
    with open(filename, 'w') as f:
        f.write('#Defines firmware version\n')
        f.write('fwversion IBM,9117-575_V7.6.0.0\n')
        f.write('#Defines Serial Number\n')
        f.write('serial0 AAAA100100100100\n')
        f.write('#Defines LPAR information\n')
        f.write('lpar_name AAAA1\n')
        f.write('#Defines Partition name\n')
        f.write('sys_name AAAA1\n')
        f.write('#Defines System name\n')

# Generated at 2022-06-11 02:25:28.995565
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    vgs_facts = hardware.get_vgs_facts()
    assert vgs_facts['vgs']['rootvg'][0]['free_pps'] == '0', "test free_pps failed"
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0', "test pv_name failed"
    assert vgs_facts['vgs']['rootvg'][0]['pv_state'] == 'active', "test pv_state failed"
    assert vgs_facts['vgs']['rootvg'][0]['total_pps'] == '546', "test total_pps failed"


# Generated at 2022-06-11 02:26:11.372451
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    # Test cases with different output of mount
    test_mounts = []

# Generated at 2022-06-11 02:26:24.764762
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = AIXHardware()
    hardware.module = module
    vgs_facts = hardware.get_vgs_facts()
    assert 'vgs' in vgs_facts
    assert 'rootvg' in vgs_facts['vgs']
    assert len(vgs_facts['vgs']['rootvg']) == 2
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs_facts['vgs']['rootvg'][0]['total_pps'] == '546'
    assert vgs_facts['vgs']['rootvg'][1]['pv_name'] == 'hdisk1'

# Generated at 2022-06-11 02:26:34.640076
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module=module)
    vgs_facts = hardware.get_vgs_facts()
    assert vgs_facts['vgs']['realsyncvg'][0]['free_pps'] == 6
    assert vgs_facts['vgs']['testvg'][0]['pp_size'] == '256 megabyte(s)'
    assert vgs_facts['vgs']['testvg'][1]['pv_state'] == 'active'
    assert vgs_facts['vgs']['rootvg'][1]['pv_name'] == 'hdisk1'



# Generated at 2022-06-11 02:26:39.065441
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    m = AIXHardware(None)
    facts = m.get_dmi_facts()
    assert 'firmware_version' in facts
    assert 'product_serial' in facts
    assert 'lpar_info' in facts
    assert 'product_name' in facts


# Test AIXHardwareCollector

# Generated at 2022-06-11 02:26:49.793527
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)

    hardware._module.run_command = MagicMock(return_value=(0, '', ''))
    hardware._module.get_bin_path = MagicMock(return_value='/usr/sbin')
    hardware.get_cpu_facts = MagicMock(return_value={'processor': [], 'processor_cores': 1, 'processor_count': 1})
    hardware.get_memory_facts = MagicMock(return_value={'memtotal_mb': 1, 'memfree_mb': 1, 'swaptotal_mb': 1, 'swapfree_mb': 1})
    hardware.get_dmi_facts = MagicMock(return_value={'product_name': '', 'product_serial': ''})

# Generated at 2022-06-11 02:26:53.209792
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    """
    Constructor of AIXHardwareCollector:
    """
    hardware_collector = AIXHardwareCollector()
    assert (hardware_collector._platform == 'AIX')
    assert (hardware_collector._fact_class == AIXHardware)

# Generated at 2022-06-11 02:27:03.929291
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    class Options:
        def __init__(self, no_log):
            self.no_log = no_log

    my_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
        check_invalid_arguments=False,
    )
    my_module.run_command = Mock()
    my_module.run_command.side_effect = [
        (0, "proc0          Available 00-00 Processor\n", ''),
        (0, "type PowerPC_POWER8\n", ''),
        (0, "smt_threads: 2\n", '')
    ]
    hardware = AIXHardware(my_module)
    rc, cpu_facts = hardware.get_cpu_facts()
    assert rc == 0

# Generated at 2022-06-11 02:27:08.840439
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)

    outdict = hardware.populate()

    assert 'processor' in outdict.keys()
    assert 'processor_count' in outdict.keys()
    assert 'processor_cores' in outdict.keys()
    assert 'memtotal_mb' in outdict.keys()
    assert 'memfree_mb' in outdict.keys()
    assert 'swaptotal_mb' in outdict.keys()
    assert 'swapfree_mb' in outdict.keys()


# Generated at 2022-06-11 02:27:19.138785
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module=module)
    device_facts = hardware.get_device_facts()
    assert 'devices' in device_facts
    assert isinstance(device_facts['devices'], dict)
    assert isinstance(device_facts['devices']['hdisk0'], dict)
    assert 'state' in device_facts['devices']['hdisk0']
    assert 'type' in device_facts['devices']['hdisk0']
    assert 'attributes' in device_facts['devices']['hdisk0']
    assert isinstance(device_facts['devices']['hdisk0']['attributes'], dict)


# Generated at 2022-06-11 02:27:30.232591
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    from ansible_collections.ansible.community.plugins.modules.system import aix_hostname
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils._text import to_bytes
    import json
    import os

    current_path = os.path.dirname(os.path.realpath(__file__))
    json_file = open(current_path + "/lsvg_output.json", 'r')
    ls_vg_output = json.load(json_file)

    fact_module = aix_hostname.AIXHostname(None, None, None, None, None)
    fact_module.run_command = lambda cmd, sudoable=None: (0, ls_vg_output, None)

# Generated at 2022-06-11 02:28:40.791161
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    # Create a class
    aix_hw = AIXHardware()
    # Call method get_dmi_facts
    dmi_facts = aix_hw.get_dmi_facts()
    # Check the result
    assert 'product_name' in dmi_facts
    assert 'lpar_info' in dmi_facts
    assert 'firmware_version' in dmi_facts
    assert 'product_serial' in dmi_facts

# Generated at 2022-06-11 02:28:45.685528
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector_obj = AIXHardwareCollector()
    assert hardware_collector_obj.platform == 'AIX'
    assert hardware_collector_obj.fact_class == AIXHardwareCollector._fact_class

# Unit test to test the constructor of the AIXHardware class

# Generated at 2022-06-11 02:28:53.159924
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    aix = AIXHardware()
    memory_facts = aix.get_memory_facts()
    assert(memory_facts['memfree_mb'] > 0)
    assert(memory_facts['memtotal_mb'] > 0)
    assert('swaptotal_mb' in memory_facts)
    assert('swapfree_mb' in memory_facts)



# Generated at 2022-06-11 02:28:59.039877
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    """
    Unit test for AIXHardwareCollector constructor.
    """
    module = AnsibleModule(argument_spec={})
    facts_collector = AIXHardwareCollector(module)
    assert facts_collector._platform == 'AIX'
    assert isinstance(facts_collector._fact_class(module), AIXHardware)


# Generated at 2022-06-11 02:29:03.022384
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    from ansible.module_utils.facts.hardware import AIXHardwareCollector
    from ansible.module_utils.facts.hardware.base import Hardware
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    assert issubclass(AIXHardwareCollector, Hardware)
    assert AIXHardwareCollector._platform == 'AIX'
    assert AIXHardwareCollector._fact_class == AIXHardware


# Generated at 2022-06-11 02:29:13.331943
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)

    # mount command is only one source of truth on AIX
    # aix_mount_facts_stub_out is stubbed output of mount command
    with open("/tmp/aix_mount_facts_stub_out", "r") as f:
        module.run_command = MagicMock(return_value=(0, f.read(), ''))


# Generated at 2022-06-11 02:29:16.440978
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule()
    hardware_facts_class = AIXHardware(module)
    device_facts = hardware_facts_class.get_device_facts()
    assert device_facts['devices']



# Generated at 2022-06-11 02:29:26.530349
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    hardware = AIXHardware()
    hardware.module.run_command = lambda command, use_unsafe_shell=None: (0, "", "")
    hardware.module.get_bin_path = lambda command, required=None: '/usr/bin/' + command
    hardware.module.exit_json = lambda **kwargs: exit(0)

    vmstat_real = '''memory pages         =    896072
    total memory       =   670904288
    free memory        =   385036288
    real memory        =   445782016
    user memory        =   403759104
    hbuf memory        =       28672
    hbuf size          =      102400
    pbuf memory        =         736
    pbuf size          =        2096
    kernel memory      =    54426624'''


# Generated at 2022-06-11 02:29:34.683699
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    hardware = AIXHardware(module=module)
    hardware.populate()

    assert hardware.memory['memfree_mb'] > 0
    assert hardware.memory['memtotal_mb'] > 0
    assert hardware.memory['swapfree_mb'] > 0
    assert hardware.memory['swaptotal_mb'] > 0
    assert len(hardware.cpu) > 0



# Generated at 2022-06-11 02:29:43.131500
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    # Set module facter instance
    module = ModuleFacts(
        dict(
            ANSIBLE_MODULE_ARGS=dict(
                gather_subset='!all,!min'
            )
        )
    )

    facts_collector = DistributionFactCollector(module=module)
    facts_collector.populate()

    aix_hardware_collector = AIXHardware(module=module)
    mount_facts = aix_hardware_collector.get_mount_facts()
