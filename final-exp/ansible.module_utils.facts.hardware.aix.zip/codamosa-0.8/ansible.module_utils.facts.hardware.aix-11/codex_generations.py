

# Generated at 2022-06-11 02:22:34.108931
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    fact_class = AIXHardwareCollector()
    assert fact_class._fact_class == AIXHardware
    assert fact_class._platform == 'AIX'

# Generated at 2022-06-11 02:22:46.495528
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    out_lsdev = '''ent0 Available             10 Gigabit Ethernet Adapter (14108902)
ent1 Available             10 Gigabit Ethernet Adapter (14108902)
et0  Available             ETHERNET
lo0  Available             Logical Host Ethernet Port
ls0  Available             Logical Storage Ethernet Port
lo0  Available             Logical Host Ethernet Port
ls0  Available             Logical Storage Ethernet Port'''

# Generated at 2022-06-11 02:22:59.491607
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    # Create a test AnsibleModule
    class TestAIXHardware_get_dmi_facts:
        def __init__(self):
            self.params = {}

        def get_bin_path(self, arg, opt_dirs=[]):
            if arg == 'lsconf':
                return '/usr/sbin/lsconf'
            if arg == 'lsvg':
                return '/usr/sbin/lsvg'
            if arg == 'xargs':
                return '/usr/bin/xargs'

        def get_mount_size(self, mount):
            mount_size = {}
            mount_size['size_total'] = 381186
            mount_size['size_available'] = 110446
            return mount_size


# Generated at 2022-06-11 02:23:05.467220
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert 'memtotal_mb' in memory_facts
    assert 'memfree_mb' in memory_facts
    assert 'swaptotal_mb' in memory_facts
    assert 'swapfree_mb' in memory_facts


# Generated at 2022-06-11 02:23:10.347875
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    aixhw = AIXHardware(module=module)

    aixhw.populate()

    assert 'firmware_version' in aixhw.generic_facts
    assert 'product_serial' in aixhw.generic_facts
    assert 'lpar_info' in aixhw.generic_facts
    assert 'product_name' in aixhw.generic_facts



# Generated at 2022-06-11 02:23:18.358837
# Unit test for method get_mount_facts of class AIXHardware

# Generated at 2022-06-11 02:23:29.122102
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    mount_facts = {'mounts': []}
    # Test normal mounts
    mount_info = {'device': '/dev/hd4', 'fstype': 'jfs2', 'mount': '/', 'options': 'rw', 'time': 'Tue Oct 11 16:49:58 2016'}
    mount_info.update(get_mount_size('/'))
    mount_facts['mounts'].append(mount_info)

    mount_info = {'device': '/dev/hd2', 'fstype': 'jfs2', 'mount': '/usr', 'options': 'rw', 'time': 'Tue Oct 11 16:50:05 2016'}
    mount_info.update(get_mount_size('/usr'))
    mount_facts['mounts'].append(mount_info)


# Generated at 2022-06-11 02:23:40.371586
# Unit test for method get_mount_facts of class AIXHardware

# Generated at 2022-06-11 02:23:42.759968
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    x = AIXHardwareCollector()
    assert x._platform == 'AIX'
    assert x._fact_class == AIXHardware

# Generated at 2022-06-11 02:23:49.856135
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )
    facts_obj = AIXHardware(module)
    memory_facts = facts_obj.get_memory_facts()
    assert memory_facts['swaptotal_mb'] >= 0
    assert memory_facts['swapfree_mb'] >= 0
    assert memory_facts['memtotal_mb'] >= 0
    assert memory_facts['memfree_mb'] >= 0



# Generated at 2022-06-11 02:24:19.875212
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    cmd_lsdev_Cc_processor = """
Available  00-00  Processor   Processor
Available  00-01  Processor   Processor
Available  00-02  Processor   Processor
True   00-03  Processor   Processor
Available  00-04  Processor   Processor
Available  00-05  Processor   Processor
Available  00-06  Processor   Processor
Available  00-07  Processor   Processor
"""
    cmd_lsdev_Cc_processor_rc = 0
    cmd_lsdev_Cc_processor_err = ""

    cmd_lsattr_El_cpudev_a_type = """
type PowerPC_POWER8,_model_SMT4
"""
    cmd_lsattr_El_cpudev_a_type_rc = 0
    cmd_lsattr_El_cpudev_a_type_err = ""

# Generated at 2022-06-11 02:24:27.623129
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['all'], type='list'),
            filter=dict(default=None, required=False)
        ),
        supports_check_mode=True
    )
    candidate_facts = {'platform_AIX': 'AIX'}
    hardware_obj = AIXHardware(module, candidate_facts)
    hardware_obj.populate()
    memory_facts = hardware_obj.get_memory_facts()
    assert(memory_facts['memtotal_mb'] > 0)
    assert(memory_facts['memfree_mb'] >= 0)
    assert(memory_facts['swaptotal_mb'] > 0)
    assert(memory_facts['swapfree_mb'] >= 0)


# Generated at 2022-06-11 02:24:39.616683
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule({})
    module.get_bin_path = MagicMock(return_value='/usr/bin/echo')

    hardware_facts = AIXHardware(module)


# Generated at 2022-06-11 02:24:48.876646
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    class ModuleMock(object):

        def __init__(self):
            class BinPathMock(object):

                def get_bin_path(self, filename, opt_dirs=[]):
                    if filename == 'mount':
                        return '/usr/sbin/mount'
                    elif filename == 'lsvg':
                        return '/usr/sbin/lsvg'
                    elif filename == 'xargs':
                        return '/usr/sbin/xargs'
            self._bin_path = BinPathMock()

        def get_bin_path(self, filename, opt_dirs=[]):
            return self._bin_path.get_bin_path(filename, opt_dirs)


# Generated at 2022-06-11 02:24:59.438851
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    """
    This code is used to test the method get_vgs_facts of class AIXHardware.
    """

# Generated at 2022-06-11 02:25:05.427438
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    hardware = AIXHardware()
    hardware.module = AnsibleModule(argument_spec={})

    cpu_facts = hardware.get_cpu_facts()

    assert cpu_facts['processor'] == 'PowerPC_POWER8'
    assert cpu_facts['processor_cores'] == 3
    assert cpu_facts['processor_count'] == 4


# Generated at 2022-06-11 02:25:14.652530
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    import platform
    from ansible.module_utils.facts.hardware.aix import AIXHardware, AIXHardwareCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils._text import to_bytes

    class AIXHardwareTest(AIXHardware):

        def __init__(self):
            self.module = AnsibleModuleTest()
            self.populate()

    test_platform = platform.linux_distribution()[0] + '-' + platform.linux_distribution()[1]

    class AnsibleModuleTest(object):
        def __init__(self):
            self.params = {}
            self.exit_json = lambda x: x

        def fail_json(self, *args, **kwargs):
            pass


# Generated at 2022-06-11 02:25:27.033777
# Unit test for method get_mount_facts of class AIXHardware

# Generated at 2022-06-11 02:25:36.116313
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    import sys
    import os
    import tempfile

    # Create temp directory
    tmpdir = tempfile.mkdtemp()
    os.environ['ANSIBLE_LOCAL_TMP'] = tmpdir
    module = os.path.join(tmpdir, 'ansible_module_facts_hardware_test.py')

    # Create temp module file
    handler = open(module, 'w+')

# Generated at 2022-06-11 02:25:43.300923
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    # Unit test for method get_device_facts of class AIXHardware
    module = AnsibleModule(argument_spec={})
    facts = AIXHardware(module)
    rc, out, err = module.run_command("/usr/bin/lsdev -Cc")
    devices_facts = facts.get_device_facts()

    assert(isinstance(devices_facts['devices'], dict))
    assert(devices_facts['devices'] != {})
    # Check device 'fcs0' and its attributes
    assert(devices_facts['devices']['fcs0']['state'] == 'Available')
    assert(devices_facts['devices']['fcs0']['type'] == 'FIBRE CHANNEL Adapter  ')

# Generated at 2022-06-11 02:26:30.822789
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    import platform, sys, os
    import re
    import textwrap
    
    # this is the minimal path needed to use the ansible module_utils
    # and module_utils/facts directory
    # the test need to be run from the tests/units directory
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
    
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.system.hardware import AIXHardware
    from ansible.module_utils.facts.utils import get_file_content, get_mount_size
    

# Generated at 2022-06-11 02:26:41.047362
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import Collector
    from ansible.module_utils._text import to_bytes
    module = basic.AnsibleModule(argument_spec={}, supports_check_mode=True, check_invalid_arguments=False)
    hardware_collector = Collector(module=module, command_trace_data={}, check_mode=True)
    hardware = AIXHardware(module)

    device_facts = hardware.get_device_facts()

# Generated at 2022-06-11 02:26:51.698946
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    out = """
rootvg:
PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
hdisk0            active            546         0           00..00..00..00..00
hdisk1            active            546         113         00..00..00..21..92
realsyncvg:
PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
hdisk74           active            1999        6           00..00..00..00..06
testvg:
PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
hdisk105          active            999         838         200..39..199..200..200
hdisk106          active            999         599         200..00..00..199..200
"""
    ah = AIXHardware()

# Generated at 2022-06-11 02:26:53.336557
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    assert AIXHardwareCollector._platform == 'AIX'
    assert AIXHardwareCollector._fact_class == AIXHardware

# Generated at 2022-06-11 02:27:03.931595
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    # create an instance of AIXHardware class
    myTestAIXHardware = AIXHardware()

    # a dictionary with facts
    explicit_facts = {
        'processor': [],
        'memtotal_mb': 10,
        'memfree_mb': 10,
        'swaptotal_mb': 10,
        'swapfree_mb': 10,
        'processor_cores': 4,
        'firmware_version': 'IBM,8233-E8B',
        'product_serial': '06AC8W6',
        'lpar_info': '1 Tenant 2 Partitions',
        'product_name': '8233-E8B'
    }

    # this method populates the AIXHardware class
    myTestAIXHardware.populate(explicit_facts)

    # verify that processor, mem

# Generated at 2022-06-11 02:27:15.131706
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    """ Unit test for method get_mount_facts of class AIXHardware """

    test_fact = AIXHardware()

    # test case 1: valid /etc/mtab and 'mount' command

# Generated at 2022-06-11 02:27:26.805531
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    """
    Unit test for method get_vgs_facts of class AIXHardware
    """
    module = FakeModule()
    hardware = AIXHardware(module)
    vgs_facts = hardware.get_vgs_facts()

# Generated at 2022-06-11 02:27:32.155889
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    AH = AIXHardware(module)
    result = AH.get_memory_facts()
    assert result['memtotal_mb'] > 0
    assert result['memfree_mb'] > 0

    #  test swap
    assert result['swaptotal_mb'] > 0
    assert result['swapfree_mb'] > 0

# Generated at 2022-06-11 02:27:36.124359
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hw_collector = AIXHardwareCollector()
    assert hw_collector._platform == 'AIX'
    assert hw_collector._fact_class == AIXHardware


# Generated at 2022-06-11 02:27:44.456592
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    """ Unit test for method get_memory_facts of class AIXHardware """

    # Setup
    import sys
    import os
    import os.path
    import tempfile
    import shutil
    import subprocess
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts.utils import get_file_content

    test_dir = tempfile.mkdtemp()

    # Create the test input files
    os.mkdir(os.path.join(test_dir, 'bin'))
    os.mkdir(os.path.join(test_dir, 'usr', 'bin'))
    vmstat_path = os.path.join(test_dir, 'usr', 'bin', 'vmstat')

# Generated at 2022-06-11 02:29:03.947437
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModuleFake({'command': '/path/to/lsdev'})
    hardware = AIXHardware(module)
    device_facts = hardware.get_device_facts()
    # Test device_facts
    assert 'devices' in device_facts

    device_facts = device_facts['devices']
    # Test devices
    assert 'ent0' in device_facts
    device_ent0 = device_facts['ent0']
    assert device_ent0['state'] == 'Available'
    assert device_ent0['type'] == '16/4'
    assert 'attributes' in device_ent0
    assert 'network_addr' in device_ent0['attributes']
    assert 'physical_location' in device_ent0['attributes']

# Generated at 2022-06-11 02:29:13.561102
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    result = AIXHardware._get_vgs_facts(module)
    assert result.get('vgs') is not None
    for lvg, pvs in result['vgs'].items():
        for pv in pvs:
            assert len(pv) == 5
            for k, v in pv.items():
                assert k in ('pv_name', 'pv_state', 'total_pps', 'free_pps', 'pp_size') and v is not None
        assert lvg not in ('PV_NAME', 'FREE DISTRIBUTION')


if __name__ == '__main__':
    from ansible.module_utils.basic import *
    main()

# Generated at 2022-06-11 02:29:16.343295
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector = AIXHardwareCollector()
    assert hardware_collector._platform == 'AIX'
    assert hardware_collector._fact_class == AIXHardware

# Generated at 2022-06-11 02:29:26.445978
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    # Set up test data
    lsdev_output = "ent0          Available 00-00         IEEE 802.3ad Link Aggregation"

# Generated at 2022-06-11 02:29:33.922191
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts.get('memtotal_mb', None)
    assert memory_facts.get('memfree_mb', None)
    assert memory_facts.get('swaptotal_mb', None)
    assert memory_facts.get('swapfree_mb', None)



# Generated at 2022-06-11 02:29:42.655340
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():

    class FakeModule(object):
        def __init__(self, command, output=''):
            self.command = command
            self.output = output
            self.rc = 0
            self.err = ''

        def run_command(self, command, use_unsafe_shell=False):
            return (self.rc, self.output, self.err)

        def get_bin_path(self, path, required=False):
            return self.command

    hardware_obj = AIXHardware({})

    hardware_obj.module = FakeModule('/usr/sbin/lsdev')


# Generated at 2022-06-11 02:29:50.282179
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    from units.compat.mock import patch
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    m = patch.object(basic.AnsibleModule, 'run_command')
    m.start()
    basic.AnsibleModule.run_command.return_value = (0, to_bytes('''memory pages
883521
free pages
819601'''), '')
    aixhw_fact_obj = AIXHardware(dict())
    aixhw_fact_obj.populate()
    assert aixhw_fact_obj.memtotal_mb == 3482
    assert aixhw_fact_obj.memfree_mb == 3239
    m.stop()



# Generated at 2022-06-11 02:29:52.045242
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    obj = AIXHardwareCollector()
    assert obj._platform == 'AIX'
    assert obj._fact_class == AIXHardware

# Generated at 2022-06-11 02:29:59.316616
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    class AIXHardware_test(AIXHardware):
        def run_command(self, cmd, **kwargs):
            return (0, 'proc0 Available 00-00 Processor\nproc1 Available 00-01 Processor\n', '')

        def get_bin_path(self, cmd, opt_dirs=[]):
            return cmd
    r = AIXHardware_test()
    r.populate()
    r.get_cpu_facts()
    assert r.facts['processor_count'] == 2
    assert r.facts['processor'] == 'Processor'
    assert r.facts['processor_cores'] == 2


# Generated at 2022-06-11 02:30:01.146562
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    aix_hw = AIXHardwareCollector()
    assert aix_hw._platform == 'AIX'
    assert aix_hw._fact_class == AIXHardware
