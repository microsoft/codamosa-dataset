

# Generated at 2022-06-11 02:22:40.242325
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)

    mount_facts = hardware.get_mount_facts()
    ansible_mount_facts = []

    # AIX does not have mtab but mount command is only source of info (or to use
    # api calls to get same info)
    mount_path = module.get_bin_path('mount')
    rc, mount_out, err = module.run_command(mount_path)
    if mount_out:
        for line in mount_out.split('\n'):
            fields = line.split()

# Generated at 2022-06-11 02:22:50.267246
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():

    # setup module args
    module_args = {'gather_subset': ['all'], 'gather_timeout': 10}

    # setup

# Generated at 2022-06-11 02:23:01.571528
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    my_module = DummyAnsibleModule()
    my_module.run_command = mock_run_command
    # Create an instance of AIXHardware class
    aix_facts = AIXHardware(my_module)

# Generated at 2022-06-11 02:23:11.121356
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    class AIXHardwareMock(AIXHardware):
        def __init__(self):
            self.module = None


# Generated at 2022-06-11 02:23:19.560412
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    facts = {}
    module = AnsibleModule(argument_spec=dict())
    ah = AIXHardware(module)

    ah.module.run_command = Mock(return_value=(0, '', ''))
    ah.populate()
    assert ah.get_memory_facts() == {'memfree_mb': 0, 'memtotal_mb': 0, 'swaptotal_mb': 0, 'swapfree_mb': 0}
    ah.module.run_command = Mock(return_value=(0, 'cpu0 Available 00-00 Processor', ''))
    ah.module.get_bin_path = Mock(return_value='/usr/sbin/lsattr')
    ah.module.run_command = Mock(return_value=(0, 'type PowerPC_POWER5 foo', ''))
    ah.populate()
   

# Generated at 2022-06-11 02:23:29.886939
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    import json
    import re
    # create some test data for vgs

# Generated at 2022-06-11 02:23:40.821630
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    import os
    import tempfile
    from ansible.module_utils.facts.collector.test_utils import mock_module

    module = mock_module(content='''
    class AIXHardware:

      def __init__(self, module):
          self.module = module

    ''')


# Generated at 2022-06-11 02:23:43.473053
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    args = 'module_name'
    ahc = AIXHardwareCollector(args)
    assert ahc._platform == 'AIX'
    assert ahc._fact_class == AIXHardware

# Generated at 2022-06-11 02:23:53.361376
# Unit test for method get_device_facts of class AIXHardware

# Generated at 2022-06-11 02:24:03.991737
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    from ansible.module_utils._text import to_bytes
    hardware_obj = AIXHardware()


# Generated at 2022-06-11 02:24:31.249764
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    hardware = AIXHardware({'ANSIBLE_MODULE_ARGS': {}})
    hardware.module.run_command = lambda cmd: (0, '''
memory pages:              48620
pinned pages:               1466
unpinned pages:            47154
transition pages:             240
free pages:                36755
page steal:                   29
page scan rate:               35
page steal rate:              40
page daemons running:        3
pinned wait:                  7   unpinned wait:               0
''', '')
    assert hardware.get_memory_facts() == {'memtotal_mb': 195, 'memfree_mb': 145, 'swaptotal_mb': None, 'swapfree_mb': None}


# Generated at 2022-06-11 02:24:42.771476
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    # Initialize the module class
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    # Create an instance of AIXHardware class
    hardware = AIXHardware(module)
    # initialize dmi facts
    dmi_facts = {}
    dmi_facts['firmware_version'] = 'IBM,8247-22L'
    dmi_facts['product_serial'] = '000FAKE000'
    dmi_facts['lpar_info'] = '1 FVT'
    dmi_facts['product_name'] = '8247-22L'
    # Call get_dmi_facts and test if returned values are same as expected
    assert hardware.get_dmi_facts() == dmi_facts


# Generated at 2022-06-11 02:24:52.794619
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    module = FakeAnsibleModule()
    hardware = AIXHardware()
    hardware.module = module
    hardware.mount_cmd = "/mount"

# Generated at 2022-06-11 02:25:02.761254
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    """
    Unit test for AIXHardware.get_vgs_facts()
    """


# Generated at 2022-06-11 02:25:08.867038
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    test_module = AnsibleModule(argument_spec={})

    test_AIXHardware = AIXHardware(test_module)
    test_vg_facts = test_AIXHardware.get_vgs_facts()

    assert 'vgs' in test_vg_facts
    assert test_vg_facts['vgs']


# Generated at 2022-06-11 02:25:16.528041
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    """unit test for method AIXHardware.get_memory_facts"""
    module = AnsibleModule(argument_spec={})
    module.run_command = Mock(return_value = (0, """memory pages      =     2987656
free               =         582
pinned             =          63
virtual            =     2987656
persistent         =           0
pmem               =           0""", ""))

    hardware = AIXHardware(module)
    result = hardware.get_memory_facts()
    assert result.get('memtotal_mb') == 2987656 * 4 / 1024 / 1024
    assert result.get('memfree_mb') == 582 * 4 / 1024 / 1024
    assert result.get('swaptotal_mb') is None
    assert result.get('swapfree_mb') is None


# Generated at 2022-06-11 02:25:22.941123
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    aix_hardware = AIXHardware(module)
    output_cpu_facts = aix_hardware.get_cpu_facts()
    assert 'processor_cores' in output_cpu_facts
    assert 'processor_count' in output_cpu_facts
    assert 'processor' in output_cpu_facts


# Generated at 2022-06-11 02:25:30.905782
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    # Basic testing
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert 'memtotal_mb' in memory_facts
    assert 'memfree_mb' in memory_facts
    assert 'swaptotal_mb' in memory_facts
    assert 'swapfree_mb' in memory_facts
    assert memory_facts['memtotal_mb'] >= memory_facts['memfree_mb']
    assert memory_facts['swaptotal_mb'] >= memory_facts['swapfree_mb']


# Generated at 2022-06-11 02:25:39.639009
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    hw = AIXHardware(module=module)
    hw.populate()

    assert "memfree_mb" in hw.facts
    assert "memtotal_mb" in hw.facts
    assert "swapfree_mb" in hw.facts
    assert "swaptotal_mb" in hw.facts
    assert "processor" in hw.facts
    assert "processor_cores" in hw.facts
    assert "processor_count" in hw.facts
    assert "firmware_version" in hw.facts
    assert "product_serial" in hw.facts
    assert "lpar_info" in hw.facts
    assert "product_name" in hw.facts


# Generated at 2022-06-11 02:25:41.560265
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    testobj = AIXHardwareCollector()
    assert testobj.platform == 'AIX'
    assert testobj.fact_class == AIXHardware


# Generated at 2022-06-11 02:26:30.406320
# Unit test for method get_dmi_facts of class AIXHardware

# Generated at 2022-06-11 02:26:32.484507
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    aixhardware = AIXHardware()
    assert aixhardware.get_dmi_facts() is not None

# Generated at 2022-06-11 02:26:34.526062
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    assert AIXHardwareCollector._platform == 'AIX'
    assert AIXHardwareCollector._fact_class == AIXHardware

# Generated at 2022-06-11 02:26:43.075389
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    class module_mock():
        def run_command(self, command, use_unsafe_shell=False):
            if command == "/usr/sbin/lsattr -El sys0 -a fwversion":
                out = "fwversion IBM,8233-E8B"
            elif command == "/usr/sbin/lsconf -q sys":
                out = "chassis_serial: YM02329"
            elif command == "/usr/sbin/lsconf -q sys":
                out = "chassis_serial: YM02329System Model: 9113-550"
            elif command == "/usr/sbin/lsconf -q sys":
                out = "chassis_serial: YM02329System Model: 9113-550LPAR Info: 1 ENABLED"
            else:
                out = ""
           

# Generated at 2022-06-11 02:26:53.656943
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    import sys
    import subprocess

    module = sys.modules['ansible.module_utils.facts.hardware.aix']
    hardware = module.AIXHardware()
    # emulate "lsattr -El sys0 -a fwversion" command output
    hardware.module.run_command = lambda cmd, use_unsafe_shell=False: (0, 'sys0 fwversion IBM,8233-E8B', '')
    # emulate "lsconf -q sys0" command output
    hardware.module.get_bin_path = lambda cmd, opt_dirs=[] : 'test_lsconf'

# Generated at 2022-06-11 02:27:04.109075
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    test_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )

    mocker_open = mocker.mock_open(read_data='cpu')
    mocker.patch('os.path.exists', return_value=True)
    mocker.patch('__builtin__.open', mocker_open)

    hardware = AIXHardware(test_module, gather_subset=['!all', '!min'])
    hardware.populate()

    assert hardware.facts['mounts'][0]['device'] == '/dev/hd4'
    assert hardware.facts['mounts'][0]['fstype'] == 'jfs2'
    assert hardware.facts['mounts'][0]['mount'] == '/'

# Generated at 2022-06-11 02:27:10.153459
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModuleMock()
    aix_hardware = AIXHardware(module)
    lsdev_path = "/usr/sbin/lsdev"
    lsattr_path = "/usr/sbin/lsattr"
    commands = {lsdev_path: (0, CPU_OUT, ""), lsattr_path + " -El " + "proc0" + " -a type": (0, PROC_TYPE_OUT, ""), lsattr_path + " -El " + "proc0" + " -a smt_threads": (0, CPU_SMT_OUT, "")}
    with mock.patch.dict(aix_hardware.module.run_command.commands, commands):
        cpu_facts = aix_hardware.get_cpu_facts()
        assert cpu_facts["processor_count"] == 2

# Generated at 2022-06-11 02:27:12.669714
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_object = AIXHardware(module)
    hardware_object.populate()

# Generated at 2022-06-11 02:27:23.986146
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    class TestAIXHardware(AIXHardware):
        def __init__(self, *args, **kwargs):
            self.module = args[0]

    class TestModule(object):
        def __init__(self):
            self.params = {'gather_subset': 'all'}

        def run_command(self, cmd, use_unsafe_shell=False):
            if cmd.startswith('/usr/sbin/lsattr -El sys0 -a fwversion'):
                out = """fwversion IBM,8233-E8B"""
                return 0, out, None

# Generated at 2022-06-11 02:27:34.890254
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    test_module = AnsibleModule(argument_spec=dict(
        filter=dict(default='*', type='str')
    ))
    hw = AIXHardware(test_module)
    facts = hw.get_vgs_facts()
    assert 'vgs' in facts
    assert 'rootvg' in facts['vgs']
    assert 'hdisk0' in facts['vgs']['rootvg']
    assert facts['vgs']['rootvg']['hdisk0']['pv_name'] == 'hdisk0'
    assert facts['vgs']['rootvg']['hdisk0']['pv_state'] == 'active'
    assert facts['vgs']['rootvg']['hdisk0']['total_pps'] == '546'

# Generated at 2022-06-11 02:28:51.576181
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = AIXHardware(module=module)
    vgs_facts = hardware.get_vgs_facts()

    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs_facts['vgs']['rootvg'][1]['pv_name'] == 'hdisk1'



# Generated at 2022-06-11 02:29:02.414169
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    mod = AnsibleModule({})
    aixhardware = AIXHardware(mod)

# Generated at 2022-06-11 02:29:05.819877
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    # Init AIXHardwareCollector
    hw_collector = AIXHardwareCollector()

    # Check it's value with expected values
    assert hw_collector._platform == 'AIX'
    assert hw_collector._fact_class == AIXHardware


# Generated at 2022-06-11 02:29:16.392488
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    # Create fake module
    module = AnsibleModule(argument_spec={})

    # Create fake collector
    collector = AIXHardwareCollector(module=module)

    # Create fake hardware class
    hardware = AIXHardware(module)

    # We now test the populate method of class AIXHardware.

    # Mocking the module.run_command method to force it to return the needed
    # values for the processor facts for this specific AIX version
    lines = ["proc0 Available 00-00 Processor", "proc1 Available 00-01 Processor"]

# Generated at 2022-06-11 02:29:20.743811
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModuleMock({})
    hardware = AIXHardware(module)
    assert 'firmware_version' in hardware.get_dmi_facts()
    assert 'product_name' in hardware.get_dmi_facts()
    assert 'product_serial' in hardware.get_dmi_facts()



# Generated at 2022-06-11 02:29:29.788417
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = FakeModule()
    lsdev_cmd = module.get_bin_path('lsdev', True)
    lsattr_cmd = module.get_bin_path('lsattr', True)
    rc, out_lsdev, err = module.run_command(lsdev_cmd)

    aix_hardware = AIXHardware(module)
    device_facts = aix_hardware.get_device_facts()
    result = device_facts.get('devices')

    for line in out_lsdev.splitlines():
        field = line.split()
        device_name = field[0]

        device_attrs = {}
        lsattr_cmd_args = [lsattr_cmd, '-E', '-l', device_name]

# Generated at 2022-06-11 02:29:39.895670
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    """
    Function to test get_vgs_facts method of AIXHardware class
    return:
    input: module
    """
    # Create a class instance
    test = AIXHardware()
    # Create a Mock module instance to pass to get_vgs_facts method

# Generated at 2022-06-11 02:29:45.924676
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    # pylint: disable=unused-argument,invalid-name
    module = AnsibleModule(
        argument_spec={},
        # pylint: disable=unused-variable,unused-argument,invalid-name
        supports_check_mode=True,
    )
    ah = AIXHardware(module=module)

    assert ah.get_memory_facts() == {'memfree_mb': 512, 'memtotal_mb': 1028, 'swapfree_mb': 100, 'swaptotal_mb': 400}


# Generated at 2022-06-11 02:29:54.014956
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    def run_mock(module, *args, **kwargs):
        args = list(args)
        for k, v in kwargs.items():
            if k == 'use_unsafe_shell':
                args.append('use_unsafe_shell=False')
            else:
                args.append('%s=%s' % (k, v))

        if '_raw_params' in kwargs:
            args.append('_raw_params="%s"' % kwargs['_raw_params'])

        cmd = '%s.run_command(%s)' % (module, ','.join(args))
        return exec_command_mock(cmd)

    module = 'ansible_collections.not_a_real_collection.plugins.modules.hardware.aix'
    out_lsdev

# Generated at 2022-06-11 02:30:01.495557
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    hd = AIXHardware()
    hd.module = MockModule()
    hd.module.add_cmd_output([('/usr/sbin/lsattr -El sys0 -a fwversion', 'firmware_version IBM,8233-E8B', 0, ''),
                              ('/usr/sbin/lsconf',
                               '\n'
                               'Machine Serial Number          AIX10P7\n'
                               'LPAR Info                      008-0C1\n'
                               'System Model                   IBM,8233-E8B\n'
                               '\n',
                               0, '')])
    dmi_facts = hd.get_dmi_facts()
    assert dmi_facts['firmware_version'] == 'IBM,8233-E8B'
