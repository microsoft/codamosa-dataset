

# Generated at 2022-06-11 02:22:32.671747
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware_collector_obj = AIXHardwareCollector()
    assert hardware_collector_obj._platform == "AIX"
    assert hardware_collector_obj._fact_class == AIXHardware


# Generated at 2022-06-11 02:22:37.718089
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    test_module = AnsibleModule(argument_spec={})
    test_module.run_command = MagicMock(return_value=(0, "", ""))
    ahw = AIXHardware(module=test_module)
    ahw.get_cpu_facts()
    test_module.run_command.assert_any_call("/usr/sbin/lsattr -El " + cpudev + " -a smt_threads")


# Generated at 2022-06-11 02:22:49.090698
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    class ModuleMock(object):
        # mock class to mimic module
        def __init__(self):
            self.run_command_calls = []

        def run_command(self, cmd, use_unsafe_shell=False):
            self.run_command_calls.append(cmd)
            # mock output from command lsps -s
            return 0, "4194304\t1\t4194303", ""

        def get_bin_path(self, cmd, opt_dirs=[]):
            if cmd == "lsvg":
                return "/usr/sbin/lsvg"
            if cmd == "xargs":
                return "/usr/bin/xargs"

    module = ModuleMock()
    aix_hw_class = AIXHardware(module)
    test_vgs_facts = aix_hw

# Generated at 2022-06-11 02:22:50.452438
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec=dict())

# Generated at 2022-06-11 02:22:54.480147
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    collector = AIXHardwareCollector()
    assert collector._platform == 'AIX'
    assert collector._fact_class is AIXHardware
    assert collector._fact_class.platform == 'AIX'

# Generated at 2022-06-11 02:23:03.131146
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand(
        rc=0,
        out="proc1 Available 02-00 Processor\n" +
        "proc2 Available 02-01 Processor\n" +
        "proc3 Available 02-02 Processor\n" +
        "proc4 Available 02-03 Processor",
        err=''
    )
    module.get_bin_path = FakeGetBinPath("/usr/sbin/lsdev")
    hw = AIXHardware()
    hw.populate(module)
    assert hw.processor_count == 4
    assert hw.processor == 'PowerPC_POWER5'
    assert hw.processor_cores == 1



# Generated at 2022-06-11 02:23:07.980174
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = MockAnsibleModule()
    module.run_command = Mock(return_value=(0, "Machine Model: IBM,8205-E6B", ""))
    module.get_bin_path = Mock(return_value="/usr/sbin/lsattr")
    module.IS_AIX = True

    ah = AIXHardware(module=module)
    facts = ah.get_dmi_facts()
    assert facts['firmware_version'] == '8205-E6B'
    assert facts['product_serial'] is None
    assert facts['product_name'] is None


# Generated at 2022-06-11 02:23:11.394637
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})

    hardware = AIXHardware(module)
    cpu_facts = hardware.get_cpu_facts()

    assert cpu_facts['processor_cores'] == 4
    assert cpu_facts['processor_count'] == 8


# Generated at 2022-06-11 02:23:19.737758
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    if not HAVE_PYTHON26:
        module.fail_json(msg='python >= 2.6 is required for this module')

    if not module.get_bin_path('lsattr'):
        module.fail_json(msg="'lsattr' command not found")

    if not module.get_bin_path('lsconf'):
        module.fail_json(msg="'lsconf' command not found")

    hp = AIXHardware()
    dmi_facts = hp.get_dmi_facts()

    module.exit_json(ansible_facts=dict(dmi=dmi_facts))


# Generated at 2022-06-11 02:23:22.535710
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    hardware = AIXHardwareCollector({})
    assert hardware.fact_class.platform == AIXHardware.platform


# Generated at 2022-06-11 02:23:51.850217
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    test_data = """rootvg:
PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
hdisk0            active            546         0           00..00..00..00..00
hdisk1            active            546         113         00..00..00..21..92
realsyncvg:
PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
hdisk74           active            1999        6           00..00..00..00..06
testvg:
PV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION
hdisk105          active            999         838         200..39..199..200..200
hdisk106          active            999         599         200..00..00..199..200
"""

# Generated at 2022-06-11 02:24:03.312073
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    output = 'rootvg:\nPV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION\nhdisk0            active            546         0           00..00..00..00..00\nhdisk1            active            546         113         00..00..00..21..92\nrealsyncvg:\nPV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION\nhdisk74           active            1999        6           00..00..00..00..06\ntestvg:\nPV_NAME           PV STATE          TOTAL PPs   FREE PPs    FREE DISTRIBUTION\nhdisk105          active            999         838         200..39..199..200..200\nhdisk106          active            999         599         200..00..00..199..200'
    obj = AIXHardware

# Generated at 2022-06-11 02:24:13.717025
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    lsdev_cmd = "/usr/sbin/lsdev -Cc processor"
    vmstat_cmd = "/usr/bin/vmstat -v"
    lsps_cmd = "/usr/sbin/lsps -s"

    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module=module)

    hardware.module.run_command = MagicMock(return_value=(0, "-------------------------------------------------------------------------------\nAvailable\nAvailable\nAvailable\nAvailable", ""))
    processor_count = hardware.get_cpu_facts().get('processor_count')
    assert processor_count == 4

    hardware.module.run_command = MagicMock(return_value=(0, "type PowerPC_POWER5+", ""))
    processor = hardware.get_cpu_facts().get('processor')

# Generated at 2022-06-11 02:24:22.820951
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    # Create a AnsibleModule object
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )

    # Create a AIXHardware object
    aix = AIXHardware(module)

    # Get the dmi facts - a new module should always be created when calling a method
    rc, out, err = aix_module.run_command("/usr/sbin/lsattr -El sys0 -a fwversion")
    data = out.split()
    fwversion = data[1].strip('IBM,')
    lsconf_path = aix_module.get_bin_path("lsconf")
    if lsconf_path:
        rc, out, err = aix_module.run_command(lsconf_path)

# Generated at 2022-06-11 02:24:26.975382
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    aix_hardware = AIXHardware()
    assert 'processor' in aix_hardware.get_cpu_facts()
    assert 'processor_cores' in aix_hardware.get_cpu_facts()
    assert 'processor_count' in aix_hardware.get_cpu_facts()


# Generated at 2022-06-11 02:24:38.711742
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module=module)
    vgs_facts = hardware.get_vgs_facts()

# Generated at 2022-06-11 02:24:48.351242
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    import sys
    import os
    import tempfile

    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

    # Setup temp facts file
    TEST_FACTS_FILE = os.path.join(tempfile.mkdtemp(prefix='ansible_fact_tests.'), 'ansible_facts.yaml')

    # Create a HardwareCollector object
    aix_hc = AIXHardwareCollector(None)
    output = aix_hc.collect(TEST_FACTS_FILE)

    # Call create_fact_file method
    assert output == TEST_FACTS_FILE, "Invalid return value"

    # Remove the temp facts file
    os.remove(TEST_FACTS_FILE)
    os.rmdir

# Generated at 2022-06-11 02:24:59.393207
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    test_module = AnsibleModule(
        argument_spec=dict()
    )

    test_obj = AIXHardware(module=test_module)
    test_obj.populate()


# Generated at 2022-06-11 02:25:11.705825
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils.facts import FactCollector
    import os
    import re
    import collections
    import unittest
    import sys

    # Mock class to control and simulate the behavior of module class of AnsibleModule
    class MyAnsibleModule:
        def __init__(self):
            self.run_command_results = collections.defaultdict(lambda: (0, "", ""))
            self.fail_json_results = collections.defaultdict(lambda: False)
            self.exit_json_results = collections.defaultdict(lambda: False)

        def get_bin_path(self, app, required=False):
            path = "/usr/bin/%s" % app
            return path


# Generated at 2022-06-11 02:25:15.224191
# Unit test for method get_cpu_facts of class AIXHardware
def test_AIXHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    hardware = AIXHardware(module)
    expected_cpu_facts = {'processor': 'PowerPC_POWER6',
                          'processor_count': 2,
                          'processor_cores': 1}
    assert hardware.get_cpu_facts() == expected_cpu_facts


# Generated at 2022-06-11 02:25:43.272637
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    # For test we need to mocked module.run_command and module.get_bin_path methods
    # for this create a mock class to mock them
    class Test():
        def run_command(self, cmd, use_unsafe_shell):
            return 0, 'test_out', ''

        def get_bin_path(self, bin_name, required):
            return 'test_path'
    test = Test()
    h = AIXHardware(test)
    vgs_facts = h.get_vgs_facts()
    assert vgs_facts['vgs']['rootvg'][0]['pv_name'] == 'hdisk0'
    assert vgs_facts['vgs']['rootvg'][0]['pv_state'] == 'active'

# Generated at 2022-06-11 02:25:53.274727
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    harware_facts = AIXHardware().populate()

    assert harware_facts['processor'] == ['POWER7']
    assert harware_facts['processor_cores'] == 8
    assert harware_facts['processor_count'] == 2
    assert harware_facts['memtotal_mb'] >= 515
    assert harware_facts['memfree_mb'] >= 515 - 1
    assert harware_facts['swaptotal_mb'] >= 318
    assert harware_facts['swapfree_mb'] >= 318 - 1
    assert harware_facts['firmware_version'] == '7.8'
    assert harware_facts['lpar_info'] in ['1 Node, 1 Partition', '1 Node, 2 Partitions']

# Generated at 2022-06-11 02:26:04.424599
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    import os
    import json
    import mock
    from ansible.module_utils.facts.hardware.aix import AIXHardware

    def run_command_mock(args, *kwargs):
        if 'lsdev' in args:
            return 0, lsdev_out, ''
        elif 'lsattr' in args:
           return 0, lsattr_out, ''

    mock_module = mock.MagicMock()
    mock_module.run_command.side_effect = run_command_mock
    mock_module.get_bin_path.return_value = '/bin/lsdev'

    test_obj = AIXHardware({})
    test_obj.module = mock_module


# Generated at 2022-06-11 02:26:10.286681
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    memory_facts_raw = {'memfree_mb': '4096', 'swapfree_mb': '4096', 'memtotal_mb': '4096', 'swaptotal_mb': '4096'}
    memory_facts = AIXHardware.get_memory_facts(memory_facts_raw)
    assert memory_facts == memory_facts_raw


# Generated at 2022-06-11 02:26:15.926002
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    """
    Unit test for method populate of class AIXHardware
    """
    module = AnsibleModule(argument_spec={})
    hardware = AIXHardware(module)
    result = hardware.populate()

    assert result['processor'] == ['PowerPC_POWER7']
    assert result['processor_cores'] == 4
    assert result['processor_count'] == 8
    assert result['memtotal_mb'] == 8192
    assert result['memfree_mb'] == 6586


# Generated at 2022-06-11 02:26:28.642442
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = AIXHardware(module)

    # test cpu facts
    cpu_facts = hardware_obj.get_cpu_facts()
    assert 'processor_count' in cpu_facts
    assert 'processor' in cpu_facts

    # test memory facts
    memory_facts = hardware_obj.get_memory_facts()
    assert 'memfree_mb' in memory_facts
    assert 'memtotal_mb' in memory_facts
    assert 'swapfree_mb' in memory_facts
    assert 'swaptotal_mb' in memory_facts

    # test dmi facts
    dmi_facts = hardware_obj.get_dmi_facts()
    assert 'firmware_version' in dmi_facts
    assert 'product_name' in dmi_facts
   

# Generated at 2022-06-11 02:26:32.140408
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    module = AnsibleModuleMock()
    hw = AIXHardwareCollector(module)
    assert hw.platform == 'AIX'
    assert hw.fact_class == AIXHardware

# Generated at 2022-06-11 02:26:40.473350
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware

    test_hardware = AIXHardware()
    test_hardware.module = FakeAnsibleModule()
    test_hardware.module.run_command.return_value = (0, vmstat_v_output, "")
    result = test_hardware.get_memory_facts()

    assert result.get('memtotal_mb') == 8192
    assert result.get('memfree_mb') == 512
    assert result.get('swaptotal_mb') == 1024
    assert result.get('swapfree_mb') == 512



# Generated at 2022-06-11 02:26:51.144477
# Unit test for method get_device_facts of class AIXHardware

# Generated at 2022-06-11 02:27:01.688886
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():
    aixHard = AIXHardware()
    aixHard.module = MagicMock()
    aixHard.module.run_command.return_value = (0, 'root@HOSTNAME:[/root]# lsattr -El sys0 -a fwversion\nfwversion IBM,XIV6620F.121 ', '')
    aixHard.module.get_bin_path.return_value = True
    dmi_facts = aixHard.get_dmi_facts()
    assert 'firmware_version' in dmi_facts
    assert 'product_serial' in dmi_facts
    assert 'lpar_info' in dmi_facts
    assert 'product_name' in dmi_facts
    assert dmi_facts['firmware_version'] == 'IBM,XIV6620F.121'

# Generated at 2022-06-11 02:27:55.262214
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    from ansible.module_utils._text import to_bytes

    aixhw = AIXHardware({})
    mount_facts = aixhw.get_mount_facts()
    assert(isinstance(mount_facts, dict))
    sample_mount_str = to_bytes("rootvg:/on/hd4    /                      jfs    2       no       no       Thu Dec 27 21:19:42 2018")
    mount_info = {'mount': "/",
                  'device': "rootvg:/on/hd4",
                  'fstype': "jfs",
                  'options': "no,no",
                  'time': "Thu Dec 27 21:19:42 2018"}

# Generated at 2022-06-11 02:28:05.713950
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    from ansible.module_utils.facts.hardware.aix import AIXHardware

# Generated at 2022-06-11 02:28:13.464295
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = AIXHardware(module)

    # Test output from: lsdev -Cc device

# Generated at 2022-06-11 02:28:15.618950
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():
    """
    Test get_mount_facts
    """
    assert True, "No unit test"

    return

# Generated at 2022-06-11 02:28:27.030255
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():

    module = AnsibleModule(argument_spec={})

    ### Start test case for normal output ###
    test_AIXHardware = AIXHardware(module)
    # Prepare test input
    test_AIXHardware.module.run_command = MagicMock(return_value=(0,
                                                                  "IBM,7043-150",
                                                                  0))

# Generated at 2022-06-11 02:28:28.420290
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec=dict()
    )

    ah = AIXHardware()

    assert ah.get_memory_facts().get('memtotal_mb') > 0

# Generated at 2022-06-11 02:28:33.210539
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    """
    Test that AIXHardwareCollector() can be instantiated.
    """

    module = AnsibleModuleMock(
        dict(
            ansible_facts=dict(
                ansible_hardware=None
            )
        )
    )
    hardware = AIXHardwareCollector(module=module)


# Generated at 2022-06-11 02:28:41.411282
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True)

    lsattr = Mock(return_value=(0, '', ''))
    module.get_bin_path = Mock(return_value='/usr/bin/')
    module.run_command = Mock(return_value=(0, '', ''))

    # Test normal output
    lsdev_out_normal = '''
Name             Status  Diagnostic
hdisk0           Available
proc0            Available
hd5              Available

'''


# Generated at 2022-06-11 02:28:54.749270
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec=dict())
    # Create a AIXHardware object
    aix_hw_facts = AIXHardware(module)

    # Create a AIXHardware instance to call method populate of class AIXHardware.
    hw_facts = aix_hw_facts.populate()

    # Unit test for method populate of class AIXHardware
    assert 'AIX' in hw_facts['platform']

    assert 'mounts' in hw_facts
    assert isinstance(hw_facts['mounts'], list)

    assert 'swaptotal_mb' in hw_facts
    assert isinstance(hw_facts['swaptotal_mb'], int)

    assert 'swapfree_mb' in hw_facts
    assert isinstance(hw_facts['swapfree_mb'], int)

   

# Generated at 2022-06-11 02:29:04.133012
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():

    import pytest

    from ansible.module_utils.facts.hardware.aix import AIXHardware


# Generated at 2022-06-11 02:30:47.800781
# Unit test for method get_device_facts of class AIXHardware
def test_AIXHardware_get_device_facts():
    # Load module spec
    module_spec = dict(
        argument_spec=dict(),
        supports_check_mode=True
    )

    module = AnsibleModule(
        argument_spec=module_spec['argument_spec'],
        supports_check_mode=module_spec['supports_check_mode']
    )

    # For testing get_device_facts of class AIXHardware, just call
    # this method of class AIXHardware
    aix_hardware_obj = AIXHardware(module=module)
    device_facts = aix_hardware_obj.get_device_facts()
    assert module.exit_json.called

# Generated at 2022-06-11 02:30:57.048547
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    hardware = AIXHardware()


# Generated at 2022-06-11 02:31:05.917742
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    # Create mock module object
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.collector import BaseFactCollector
    module = ModuleFacts(BaseFactCollector())

    # Create mock module object
    from ansible.module_utils.facts.hardware.aix import AIXHardware
    mock_hardware = AIXHardware(module)

    # Create test mock lsvg output

# Generated at 2022-06-11 02:31:17.934409
# Unit test for method get_vgs_facts of class AIXHardware
def test_AIXHardware_get_vgs_facts():
    from ansible.module_utils import basic
    test_module = basic.AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False
    )
    test_module.params = {}

# Generated at 2022-06-11 02:31:24.773270
# Unit test for method get_mount_facts of class AIXHardware
def test_AIXHardware_get_mount_facts():

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    hardware = AIXHardware(module=module)

    # mock lsdev command

# Generated at 2022-06-11 02:31:28.405735
# Unit test for method get_memory_facts of class AIXHardware
def test_AIXHardware_get_memory_facts():
    facts = AIXHardware().get_memory_facts()
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0

# Generated at 2022-06-11 02:31:30.236653
# Unit test for constructor of class AIXHardwareCollector
def test_AIXHardwareCollector():
    x = AIXHardwareCollector()
    assert type(x) == AIXHardwareCollector


# Generated at 2022-06-11 02:31:36.505757
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    import sys
    import os
    import tempfile
    import platform

    from ansible.module_utils.facts.hardware import aix_hardware as aix_hw
    from ansible.module_utils.facts.utils import AnsiblePythonAPI

    aix_hw_obj = aix_hw.AIXHardware()

    if platform.system() != 'AIX':
        sys.exit('TEST RUN ON NON AIX PLATFORM')

    # Create a temporary file to store our test output
    tmp_fd, tmp_path = tempfile.mkstemp()

    # Create an AnsiblePythonAPI object
    api = AnsiblePythonAPI()
    api.run_command = run_command

    # Assign the method run_command to the object api
    aix_hw_obj.module = api

    aix_hw_obj

# Generated at 2022-06-11 02:31:43.301232
# Unit test for method get_dmi_facts of class AIXHardware
def test_AIXHardware_get_dmi_facts():

    module = AnsibleModule(
        argument_spec = dict(
            filter = dict(default=None, required=False)
        ),
        supports_check_mode=True
    )

    if not HAS_AIX_MODULES:
        module.fail_json(msg=missing_required_lib('ibm_zos_core'),
                         exception=IBM_ZOS_CORE_IMP_ERR)

    results = {}

    # Initialize the AIXHardware class
    aix_hw = AIXHardware(module)

    # Get the dmi_facts
    dmi_facts = aix_hw.get_dmi_facts()
    results.update({'dmi': dmi_facts})

    # Return the results
    module.exit_json(ansible_facts=results)

# Generated at 2022-06-11 02:31:47.075755
# Unit test for method populate of class AIXHardware
def test_AIXHardware_populate():
    module = AnsibleModule(argument_spec={})
    facts = AIXHardware(module=module).populate()
    assert "firmware_version" in facts
    assert "product_serial" in facts
    assert "lpar_info" in facts
    assert "product_name" in facts
    assert "processor_count" in facts
    assert "processor_cores" in facts
    assert "processor" in facts
