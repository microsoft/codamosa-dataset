

# Generated at 2022-06-16 22:01:22.712081
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory = InventoryManager(loader=None, sources=None)
    inventory.subset('all')
    assert inventory._subset == None
    inventory.subset('foo')
    assert inventory._subset == ['foo']
    inventory.subset('foo,bar')
    assert inventory._subset == ['foo', 'bar']
    inventory.subset('foo:bar')
    assert inventory._subset == ['foo:bar']
    inventory.subset('foo:bar,baz')
    assert inventory._subset == ['foo:bar', 'baz']
    inventory.subset('foo:bar,baz:qux')
    assert inventory._subset == ['foo:bar', 'baz:qux']
    inventory.subset('foo:bar,baz:qux,quux')

# Generated at 2022-06-16 22:01:23.544935
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # FIXME: implement
    pass


# Generated at 2022-06-16 22:01:24.517777
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # FIXME: implement
    pass


# Generated at 2022-06-16 22:01:31.127102
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory = InventoryManager(loader=None, sources=None)

# Generated at 2022-06-16 22:01:33.551161
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-16 22:01:43.740171
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory = InventoryManager(loader=None, sources=None)

# Generated at 2022-06-16 22:01:53.448488
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory_manager = InventoryManager(loader=None, sources=None)
    assert inventory_manager.parse_source('localhost,') == ['localhost']
    assert inventory_manager.parse_source('localhost,') == ['localhost']
    assert inventory_manager.parse_source('localhost,') == ['localhost']
    assert inventory_manager.parse_source('localhost,') == ['localhost']
    assert inventory_manager.parse_source('localhost,') == ['localhost']
    assert inventory_manager.parse_source('localhost,') == ['localhost']
    assert inventory_manager.parse_source('localhost,') == ['localhost']
    assert inventory_manager.parse_source('localhost,') == ['localhost']
    assert inventory_manager.parse_source('localhost,') == ['localhost']
    assert inventory_manager.parse_source('localhost,') == ['localhost']

# Generated at 2022-06-16 22:01:58.808005
# Unit test for function split_host_pattern
def test_split_host_pattern():
    assert split_host_pattern('a,b[1], c[2:3] , d') == ['a', 'b[1]', 'c[2:3]', 'd']
    assert split_host_pattern('a:b:c') == ['a', 'b', 'c']
    assert split_host_pattern('a:b[1]:c[2:3]') == ['a', 'b[1]', 'c[2:3]']
    assert split_host_pattern('a:b[1]:c[2:3]') == ['a', 'b[1]', 'c[2:3]']
    assert split_host_pattern('[2001:db8::1]') == ['[2001:db8::1]']

# Generated at 2022-06-16 22:02:10.373874
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.ini import InventoryParser
    from ansible.inventory.script import ScriptInventory
    from ansible.inventory.yaml import InventoryYAML
    from ansible.inventory.dir import InventoryDirectory
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_bytes, to_text
    import os
    import pytest

    # Create the object
    im = InventoryManager(loader=DataLoader(), variable_manager=VariableManager())
    # Create a group
    g = Group('test_group')
    # Create

# Generated at 2022-06-16 22:02:22.499362
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory = InventoryManager(loader=None, sources=None)
    inventory.subset(None)
    assert inventory._subset == None
    inventory.subset('all')
    assert inventory._subset == ['all']
    inventory.subset('all:!foo')
    assert inventory._subset == ['all', '!foo']
    inventory.subset('all:&foo')
    assert inventory._subset == ['all', '&foo']
    inventory.subset('all:foo')
    assert inventory._subset == ['all', 'foo']
    inventory.subset('all:foo:bar')
    assert inventory._subset == ['all', 'foo', 'bar']
    inventory.subset('all:foo:bar:baz')
    assert inventory._subset == ['all', 'foo', 'bar', 'baz']
