

# Generated at 2022-06-20 15:08:13.888645
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    print("")
    print("##### list_hosts #####")
    print("")

    inventory = InventoryManager(loader=DataLoader())
    inventory.add_host("hostname.example.com")
    inventory.add_group("groupname")
    inventory.add_host(host="group_hostname.example.com", group="groupname")
    inventory.add_group("subgroupname", group="groupname")
    inventory.add_host(host="subgroup_hostname.example.com", group="subgroupname")
    inventory.add_child("childname", "subgroupname")
    inventory.add_host(host="child_hostname.example.com", group="childname")

    print("all")

# Generated at 2022-06-20 15:08:20.314155
# Unit test for method clear_pattern_cache of class InventoryManager
def test_InventoryManager_clear_pattern_cache():
    hostvars = dict()
    groups = dict()
    loader = None
    variable_manager = VariableManager(loader=loader, inventory=None)
    inventory = Inventory(host_list=[], groups=groups, loader=loader, variable_manager=variable_manager)
    inventory_manager = InventoryManager(loader, variable_manager, hostvars=hostvars)
    inventory_manager._inventory = inventory
    inventory_manager.clear_pattern_cache()
    assert inventory_manager._pattern_cache == dict()

# Generated at 2022-06-20 15:08:26.981421
# Unit test for constructor of class InventoryManager
def test_InventoryManager():
    def p(p):
        print("%s: %s" % (p, m.get_hosts(p)))
    m = InventoryManager('inventory')
    p('all')
    p('*')
    p('notthere')
    p('test_group')
    p('test_*')
    p('test*')


if __name__ == '__main__':
    test_InventoryManager()

# Generated at 2022-06-20 15:08:37.711264
# Unit test for function split_host_pattern
def test_split_host_pattern():
    assert split_host_pattern(["host1", "host2"]) == ["host1", "host2"]
    assert split_host_pattern("host1,host2") == ["host1", "host2"]
    assert split_host_pattern("host1[1:2],host2[3:4]") == ["host1[1:2]", "host2[3:4]"]
    assert split_host_pattern("host1,host2:host3,host4") == ["host1", "host2:host3", "host4"]
    assert split_host_pattern("host1,host2:host3,host4[1:2]") == ["host1", "host2:host3", "host4[1:2]"]


# Generated at 2022-06-20 15:08:50.463769
# Unit test for function split_host_pattern
def test_split_host_pattern():
    assert split_host_pattern("a,b[1], c[2:3] , d") == ['a', 'b[1]', 'c[2:3]', 'd']
    assert split_host_pattern("a:b:c:d:e") == ['a:b:c:d:e']
    assert split_host_pattern("a:b:c:d:e[1:2]") == ['a:b:c:d:e[1:2]']
    assert split_host_pattern("a:b:c[1:2]") == ['a:b:c[1:2]']
    assert split_host_pattern("a:b:c:d[1:2]") == ['a:b:c:d[1:2]']

# Generated at 2022-06-20 15:08:57.536819
# Unit test for method list_groups of class InventoryManager
def test_InventoryManager_list_groups():
  from collections import OrderedDict
  inventory = OrderedDict()
  inventory[('group1', 'all')] = []
  inventory[('group1', 'children')] = ['group2', 'group3']
  inventory[('group2', 'vars')] = {'gvar1': 'bar'}
  inventory[('group3', 'vars')] = {'gvar2': 'foo'}
  inventory[('group3', 'hosts')] = ['host1', 'host2']
  inventory[('host1', 'vars')] = {'hvar1': 'var1'}
  inventory[('host1', 'group_names')] = ['group1', 'group2', 'group3']
  inventory[('host2', 'vars')] = {'hvar2': 'var2'}

# Generated at 2022-06-20 15:09:03.751946
# Unit test for method restrict_to_hosts of class InventoryManager
def test_InventoryManager_restrict_to_hosts():
    h = MagicMock()
    h.name = 'localhost'
    inv = InventoryManager(h)
    assert inv.restrict_to_hosts(None) == None
    assert inv.restrict_to_hosts(['localhost']) == None
    assert inv.restrict_to_hosts(['example.org']) == None
    assert inv.restrict_to_hosts(['localhost', 'example.org']) == None
    assert inv.restrict_to_hosts(['localhost', 'example.org']) == None


# Generated at 2022-06-20 15:09:15.596712
# Unit test for function split_host_pattern
def test_split_host_pattern():
    assert split_host_pattern("a,b[1], c[2:3] , d") == ['a', 'b[1]', 'c[2:3]', 'd']
    assert split_host_pattern("a,b[1], c[2:3] , d") != ['a', 'b[1]', 'c[2:3]', 'dX']
    assert split_host_pattern("a,b,c.d") == ['a', 'b', 'c.d']
    assert split_host_pattern("a,b,c:d") == ['a', 'b', 'c:d']
    assert split_host_pattern("a,b,c,d") == ['a', 'b', 'c', 'd']

# Generated at 2022-06-20 15:09:19.036386
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
  inv_mgr = InventoryManager()
  inv_mgr.subset('')
  inv_mgr.subset(None)

test_InventoryManager_subset()

# Generated at 2022-06-20 15:09:26.985866
# Unit test for method refresh_inventory of class InventoryManager
def test_InventoryManager_refresh_inventory():

    # Initialise inventory with hosts and groups
    inventory = InventoryManager(Loader(), VariableManager())
    inventory.add_host('localhost')
    inventory.add_group('nodes')
    inventory.add_child('nodes', 'localhost')

    hosts = inventory.get_hosts()
    assert 'localhost' in hosts
    assert len(hosts) == 1

    groups = inventory.get_groups()
    assert 'nodes' in groups

    # Add a new host to the inventory
    display.verbosity = 4
    inventory.add_host('localhost_other')
    inventory.add_group('nodes_other')
    inventory.add_child('nodes_other', 'localhost_other')
    display.verbosity = 0

    # Test that the new hosts have been added to the inventory
    inventory.clear_pattern_cache()
   