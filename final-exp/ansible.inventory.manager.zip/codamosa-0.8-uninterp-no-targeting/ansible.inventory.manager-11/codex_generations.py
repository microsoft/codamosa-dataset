

# Generated at 2022-06-20 15:09:40.536319
# Unit test for method get_groups_dict of class InventoryManager
def test_InventoryManager_get_groups_dict():
    import json
    inventory_manager_obj = InventoryManager()
    groups_dict = inventory_manager_obj.get_groups_dict()
    print(json.dumps(groups_dict, indent=4))


# Generated at 2022-06-20 15:09:53.281243
# Unit test for function split_host_pattern
def test_split_host_pattern():
    assert split_host_pattern('127.0.0.1') == ['127.0.0.1']
    assert split_host_pattern(['127.0.0.1']) == ['127.0.0.1']
    assert split_host_pattern('127.0.0.1:1234') == ['127.0.0.1:1234']
    assert split_host_pattern('127.0.0.1:1234,') == ['127.0.0.1:1234']
    assert split_host_pattern('[::1], [::2]') == ['[::1]', '[::2]']
    assert split_host_pattern('[::1]:22,[::2]:22') == ['[::1]:22', '[::2]:22']

# Generated at 2022-06-20 15:09:55.734027
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    manager = InventoryManager('inventory_file')
    manager.get_hosts()

# Generated at 2022-06-20 15:10:03.603983
# Unit test for method get_groups_dict of class InventoryManager
def test_InventoryManager_get_groups_dict():
    inventory = {
        "all": {
            "children": [
                "ungrouped",
                "local"
            ]
        },
        "local": {
            "hosts": [
                "127.0.0.1",
                "localhost"
            ]
        },
    }
    inven = InventoryManager(inventory)
    a_cache = None
    assert inven.get_groups_dict(a_cache, "hosts") == {'local': {'hosts': ['127.0.0.1', 'localhost']}, 'all': {'children': ['ungrouped', 'local']}}


# Generated at 2022-06-20 15:10:11.594461
# Unit test for method reconcile_inventory of class InventoryManager
def test_InventoryManager_reconcile_inventory():

    from ansible.utils.display import Display
    from ansible.errors import AnsibleError
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VarManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    display = Display()
    loader = DataLoader({})

    # create a simple inventory
    inv_data = {
        'all': {
            'hosts': ['foo'],
            'vars': {'var1': 'foo'},
        },
        'host_vars': {
            'foo': {'var2': 'foo'},
        },
    }
    inv_data_copy = copy.deepcopy(inv_data)

    # create a vars manager

# Generated at 2022-06-20 15:10:15.922564
# Unit test for method reconcile_inventory of class InventoryManager
def test_InventoryManager_reconcile_inventory():
    inven = InventoryManager(loader=DictDataLoader({}), sources='localhost,')
    inven.reconcile_inventory()
    assert inven._inventory.hosts.keys() == ['localhost']
    assert inven._inventory.groups.keys() == ['all', 'ungrouped']



# Generated at 2022-06-20 15:10:20.756273
# Unit test for function split_host_pattern
def test_split_host_pattern():
    assert split_host_pattern('first,second') == ['first','second']
    assert split_host_pattern('first:second') == ['first:second']
    assert split_host_pattern('first[1]:second') == ['first[1]:second']
    assert split_host_pattern('first,second[2]') == ['first','second[2]']
    assert split_host_pattern(['first,second','third']) == ['first','second','third']



# Generated at 2022-06-20 15:10:22.205827
# Unit test for method get_groups_dict of class InventoryManager
def test_InventoryManager_get_groups_dict():
    # FIXME: implement this unit test
    pass


# Generated at 2022-06-20 15:10:23.852364
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():

    # FIXME: Test this method
    assert(True)


# Generated at 2022-06-20 15:10:28.480705
# Unit test for method refresh_inventory of class InventoryManager
def test_InventoryManager_refresh_inventory():
    im = InventoryManager()
    im._inventory = MagicMock()
    assert im.refresh_inventory() is im._inventory
    im._inventory.refresh_inventory.assert_called_once_with()


# Generated at 2022-06-20 15:10:57.266379
# Unit test for method get_groups_dict of class InventoryManager
def test_InventoryManager_get_groups_dict():
    import os
    import pytest
    from units.script.template import fake_ansible_module

    fake_ansible_module().exit_json = lambda **kwargs: 0

    fake_loader = DictDataLoader({
        'hosts': """
[foo]
127.0.0.1

[bar]
127.0.0.1
""",
    })

    im = InventoryManager(loader=fake_loader, sources='hosts')

    assert im.groups == {'bar': Group(name='bar'),
                         'foo': Group(name='foo'),
                         'all': Group(name='all'),
                         'ungrouped': Group(name='ungrouped')}

    # testing hostvars inclusion

# Generated at 2022-06-20 15:10:59.627337
# Unit test for method clear_caches of class InventoryManager
def test_InventoryManager_clear_caches():
    obj = InventoryManager()
    obj.clear_pattern_cache()

# Generated at 2022-06-20 15:11:04.022034
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory = InventoryManager(host_list=host_list,
                                 loader=Mock())
    # check disk bytes from df command
    vm = InventoryManager(host_list=host_list,
                          loader=Mock())
    assert InventoryManager.get_hosts(vm) == []



# Generated at 2022-06-20 15:11:09.983324
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory = Inventory('localhost')
    inventory_manager = InventoryManager(inventory=inventory)
    subset_pattern = None
    inventory_manager.subset(subset_pattern)
    assert inventory_manager._subset == None
    assert inventory_manager._restriction == None


# Generated at 2022-06-20 15:11:16.825105
# Unit test for method get_host of class InventoryManager
def test_InventoryManager_get_host():
    """
    Test normal case and case where host does not exist
    """
    host_name = 'test_host'
    host = Host(host_name)
    inventory = Inventory()
    inventory.hosts.update({host_name: host})

    inventory_manager = InventoryManager(inventory)
    assert(host == inventory_manager.get_host(host_name))
    assert(host == inventory_manager.get_host(host))

    non_existant_host = 'this_host_does_not_exist'
    assert(None == inventory_manager.get_host(non_existant_host))


# Generated at 2022-06-20 15:11:24.384203
# Unit test for method remove_restriction of class InventoryManager
def test_InventoryManager_remove_restriction():
    manager = inventory_manager.InventoryManager('localhost')
    manager.restrict_to_hosts(['myhost'])
    assert manager._restriction == set(['myhost'])
    manager.remove_restriction()
    assert manager._restriction is None


# Generated at 2022-06-20 15:11:28.017391
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    import doctest
    from ansible.parsing.dataloader import DataLoader
    mgr = InventoryManager(loader=DataLoader(), sources="localhost,")
    results = doctest.testmod(mgr)
    assert results.failed == 0

# Generated at 2022-06-20 15:11:34.435135
# Unit test for method get_host of class InventoryManager
def test_InventoryManager_get_host():
    # Create the mock inventory file
    inv_path = 'test/inventory'
    inv = MockInventory(host_list=[{'hostname': '127.0.0.1'},
                                   {'hostname': 'localhost'},
                                   {'hostname': 'example.org'}])
    inv.dump(inv_path)

    # Create an inventory manager
    inventory = InventoryManager(loader=DataLoader())
    inventory.add_inventory(inv_path)

    # Run the test
    assert inventory.get_host('127.0.0.1').get_vars() == {'hostname': '127.0.0.1'}
    assert inventory.get_host('localhost').get_vars() == {'hostname': 'localhost'}
    assert inventory.get_host('example.org').get_v

# Generated at 2022-06-20 15:11:46.536417
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():

    inventory = InventoryManager(loader=None, sources=['tests/inventory/simple_hosts', 'tests/inventory/ansible_hosts.yml'])
    # tests/inventory/simple_hosts:
    # localhost
    # other1
    # machine1
    # machine2
    # group1:
    #   host1
    #   host2
    # group2:
    #   host3
    #   host4
    # group3:
    #   group4:
    #     host5
    #   group5:
    #     host6

    # tests/inventory/ansible_hosts.yml:
    # all:
    #   hosts:
    #     localhost:
    #       ansible_host: localhost
    #   children:
    #     webservers:
    #

# Generated at 2022-06-20 15:11:54.735788
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory = AnsibleInventory(host_list=[Host('test-host1'), Host('test-host2'), Host('test-host3')], group_list=[Group('test-group1', hosts=['test-host1', 'test-host2']), Group('test-group2', hosts=['test-host2', 'test-host3'])], source='unittest')
    m = InventoryManager(inventory=inventory)
    hosts = []
    groups = []
    for host in inventory.hosts:
        m.add_host(host)
        hosts.append(host.name)
    for group in inventory.groups:
        m.add_group(group)
        groups.append(group.name)
    # subset
    m.subset('test-host1,test-host2')

# Generated at 2022-06-20 15:16:03.044327
# Unit test for method add_host of class InventoryManager
def test_InventoryManager_add_host():
    im = InventoryManager(None, loader=None)
    im.loader = Mock()
    host = Mock()
    im.add_host(host)
    assert host in im.hosts



# Generated at 2022-06-20 15:16:12.098338
# Unit test for method add_group of class InventoryManager
def test_InventoryManager_add_group():
    inventory_manager = InventoryManager(loader, sources=["test/test_inventory.yml"])

    assert isinstance(inventory_manager, InventoryManager) is True
    assert len(inventory_manager._groups) == 4
    assert inventory_manager.groups != {}

    inventory_manager.add_group('test_group')

    assert isinstance(inventory_manager, InventoryManager) is True
    assert len(inventory_manager._groups) == 5
    assert inventory_manager.groups != {}


# Generated at 2022-06-20 15:16:18.037089
# Unit test for constructor of class InventoryManager
def test_InventoryManager():
    inventory = InventoryManager(Inventory(loader=DictDataLoader({})))

    assert isinstance(inventory._inventory, Inventory)
    assert isinstance(inventory._loader, DataLoader)
    assert isinstance(inventory._pattern_cache, dict)
    assert isinstance(inventory._hosts_patterns_cache, dict)
    assert inventory._subset is None
    assert inventory._restriction is None


# Generated at 2022-06-20 15:16:25.820135
# Unit test for method remove_restriction of class InventoryManager
def test_InventoryManager_remove_restriction():
    from ansible.inventory.manager import InventoryManager

    im = InventoryManager('localhost,')
    im.restrict_to_hosts("localhost")
    expected = None
    im.remove_restriction()
    actual = im._restriction
    assert actual == expected


# Generated at 2022-06-20 15:16:34.223708
# Unit test for method restrict_to_hosts of class InventoryManager
def test_InventoryManager_restrict_to_hosts():
    inventory = InventoryManager(loader=None, variable_manager=None)
    hosts = None
    inventory.restrict_to_hosts(hosts)
    assert inventory._restriction is None
    assert inventory.host_filter is not None
    hosts = []
    inventory.restrict_to_hosts(hosts)
    assert inventory._restriction == set()



# Generated at 2022-06-20 15:16:42.994544
# Unit test for function split_host_pattern
def test_split_host_pattern():
    assert split_host_pattern("somehost") == ['somehost']
    # test with IPv6
    assert split_host_pattern("somehost:22") == ['somehost:22']
    assert split_host_pattern("somehost:22:33") == ["somehost:22:33"]
    # test with IPv6 address
    assert split_host_pattern("fe80:cd00:1:0:0:0:24:d0ff") == ['fe80:cd00:1:0:0:0:24:d0ff']
    # test range
    assert split_host_pattern("somehost[0:3:2]") == ['somehost[0:3:2]']
    # test with some IPv6 and range mixed in

# Generated at 2022-06-20 15:16:44.162695
# Unit test for method clear_caches of class InventoryManager
def test_InventoryManager_clear_caches():
    inventory_manager = InventoryManager()
    inventory_manager.clear_caches()



# Generated at 2022-06-20 15:16:50.075243
# Unit test for method clear_caches of class InventoryManager
def test_InventoryManager_clear_caches():
    test_class = InventoryManager(inventory=BaseInventory())
    expected = True
    result = test_class.clear_caches()
    post_condition = test_class._hosts_patterns_cache.__len__() == 0
    assert expected == result and post_condition



# Generated at 2022-06-20 15:16:58.132050
# Unit test for method list_groups of class InventoryManager
def test_InventoryManager_list_groups():
    env = {'ANSIBLE_INVENTORY': data_path + '/host_vars/hostvars_inventory.ini'}
    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    assert len(inventory.list_groups()) == 6
    assert inventory.list_groups() == ['all', 'blorp', 'flim', 'flimsy', 'group1', 'group2']


# Generated at 2022-06-20 15:17:02.559913
# Unit test for constructor of class InventoryManager
def test_InventoryManager():
    """
    Basic unit test to see if the InventoryManager returns hosts and groups in
    a usable way.
    """

    # This is the simplest way to create a host and group.
    # Groups are containers for hosts.
    inventory = InventoryManager(loader=None, sources=None)
    inventory.add_group('test_group')
    inventory.add_host(host=Host(name='test_host'))
    inventory.groups['test_group'].add_host(inventory.get_host('test_host'))

    # get a host from the inventory
    some_test_host = inventory.get_host('test_host')
    assert some_test_host.name == 'test_host'

    # get a group from the inventory
    some_test_group = inventory.get_group('test_group')
    assert some_test