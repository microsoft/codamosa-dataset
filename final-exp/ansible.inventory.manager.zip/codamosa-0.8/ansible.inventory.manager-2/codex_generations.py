

# Generated at 2022-06-11 00:18:37.300082
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    import pytest
    import textwrap

    inventory = InventoryManager(host_list=[])
    inventory.subset(None)
    inventory.subset("")
    inventory.subset('all')
    inventory.subset("@/tmp/does_not_exist")
    inventory.subset("@/dev/null")

    # Test Unix style @filename enventory
    with pytest.raises(AnsibleError):
        inventory.subset("@/tmp/")
    with pytest.raises(AnsibleError):
        inventory.subset("@/not/a/file")

    inventory = InventoryManager(host_list=[])
    # Test error handling

# Generated at 2022-06-11 00:18:48.204569
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    from ansible.utils.unsafe_proxy import UnsafeProxy, wrap_var
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    passwords = dict(vault_pass='secret')
    vault = VaultLib(passwords)
    inv_datastructure = {u'all': {u'children': [u'ungrouped']}, u'ungrouped': {u'hosts': [u'192.168.56.2']}}
    inventory = wrap_var(loader.load(vars=dict(all=dict(children=['ungrouped']),
                                              ungrouped=dict(hosts=['192.168.56.2'])),
                                    vault_password='secret'))

    inv_m

# Generated at 2022-06-11 00:18:59.845818
# Unit test for function split_host_pattern
def test_split_host_pattern():
    assert split_host_pattern('') == []
    assert split_host_pattern('a') == ['a']
    assert split_host_pattern('a,') == ['a']
    assert split_host_pattern(',a') == ['a']
    assert split_host_pattern(',a,') == ['a']
    assert split_host_pattern('a,b,c') == ['a', 'b', 'c']
    assert split_host_pattern(' a , b , c ') == ['a', 'b', 'c']
    assert split_host_pattern(' a,b[1] ,,c[ 2 : 3 ] ') == ['a', 'b[1]', 'c[ 2 : 3 ]']

# Generated at 2022-06-11 00:19:11.669328
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    p = InventoryManager()
    assert p.parse_source('localhost,') == ['localhost']
    assert p.parse_source(",") == ['localhost']
    assert p.parse_source('localhost,,127.0.0.1') == ['localhost', '127.0.0.1']
    assert p.parse_source('localhost,127.0.0.1') == ['localhost', '127.0.0.1']
    assert p.parse_source('foo:bar:baz') == ['foo', 'bar', 'baz']
    assert p.parse_source('foo:bar:baz,') == ['foo', 'bar', 'baz', 'localhost']
    assert p.parse_source('localhost,') == ['localhost']
test_InventoryManager_parse_source()

# Generated at 2022-06-11 00:19:19.184237
# Unit test for function order_patterns
def test_order_patterns():
    assert ['all', '&child', '&parent'] == order_patterns(['&parent', '&child'])
    assert ['all', '&child', '&parent'] == order_patterns(['&child', '&parent'])
    assert ['all', '&child', '&parent'] == order_patterns(['&child', '&parent', 'all'])
    assert ['all', '&child', '&parent', '!nonexistent'] == order_patterns(['&child', '&parent', '!nonexistent'])
    assert ['all', '!nonexistent', '&child', '&parent'] == order_patterns(['!nonexistent', '&child', '&parent'])



# Generated at 2022-06-11 00:19:29.136081
# Unit test for function split_host_pattern
def test_split_host_pattern():
    assert split_host_pattern('a,b[1], c[2:3] , d') == ['a', 'b[1]', 'c[2:3]', 'd']
    assert split_host_pattern('a') == ['a']
    assert split_host_pattern('[::1]') == ['[::1]']
    assert split_host_pattern('a:b') == ['a', 'b']
    assert split_host_pattern('  a  :[ b ]  , c[2] ') == ['a', '[ b ]', 'c[2]']
    assert split_host_pattern(['a', 'b,c', 'd:e']) == ['a', 'b', 'c', 'd', 'e']



# Generated at 2022-06-11 00:19:30.257037
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():
    # TODO: write
    pass

# Generated at 2022-06-11 00:19:41.613360
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources='')

    assert inv.list_hosts(pattern='all') == ['localhost'], inv.list_hosts(pattern='all')

    inv = InventoryManager(loader=loader, sources=[])
    assert inv.list_hosts(pattern='all') == ['localhost'], inv.list_hosts(pattern='all')

    inv = InventoryManager(loader=loader, sources=['localhost,'])
    assert inv.list_hosts(pattern='all') == ['localhost'], inv.list_hosts(pattern='all')

    inv = InventoryManager(loader=loader, sources=['localhost,', 'localhost,'])

# Generated at 2022-06-11 00:19:43.898534
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():
    # FIXME: Need to create a test for this method
    # TODO: Implement this test
    pass


# Generated at 2022-06-11 00:19:46.118272
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    manager = InventoryManager()
    # FIXME: this test is not very useful
    manager.subset(["none"])
    assert manager._subset == ["none"]


# Generated at 2022-06-11 00:20:03.096155
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory = InventoryManager(loader=None, sources=None)
    # FIXME: do something useful with this test
    assert True

# Generated at 2022-06-11 00:20:08.965920
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inv_manager = InventoryManager()
    assert inv_manager.get_hosts() == []
    assert inv_manager.get_hosts('all') == []

    inv_manager.inventory.add_host('localhost')
    assert inv_manager.get_hosts() == ['localhost']
    assert inv_manager.get_hosts('all') == ['localhost']

# Generated at 2022-06-11 00:20:18.446778
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    from units.mock.loader import Loader
    from units.mock.inventory import Inventory

    loader = Loader()
    inventory = Inventory(loader=loader)

    manager = InventoryManager(inventory)

    assert manager.list_hosts() == []

    inventory._hosts = {'host1': 'host1'}

    assert manager.list_hosts() == ['host1']

    inventory._hosts = {'host1': 'host1', 'host2': 'host2'}

    assert set(manager.list_hosts()) == set(['host1', 'host2'])

    inventory._hosts = {'host1': 'host1', 'host2': 'host2', '127.0.0.1': 'localhost'}
    manager.clear_pattern_cache()


# Generated at 2022-06-11 00:20:22.677735
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory_manager = InventoryManager(inventory='test/unit/ansible_test_inventory')
    assert inventory_manager.get_hosts()

    #test pattern all
    assert 'host1' in inventory_manager.get_hosts()
    assert 'host4' in inventory_manager.get_hosts()

    #test simple pattern
    assert 'host1' in inventory_manager.get_hosts(pattern='host1')
    assert 'host4' in inventory_manager.get_hosts(pattern='host4')

    #test simple pattern
    assert 'host1' in inventory_manager.get_hosts(pattern='*')
    assert 'host4' in inventory_manager.get_hosts(pattern='*')

    #test simple pattern

# Generated at 2022-06-11 00:20:23.348010
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
  pass

# Generated at 2022-06-11 00:20:30.386473
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    cond_name = 'InventoryManager_parse_source'
    cond_data = {}

    def get_data(cond_data):
        host_pattern, source, vary_data, result = cond_data['data']
        cond_data['host_pattern'] = host_pattern
        cond_data['source'] = source
        cond_data['vary_data'] = vary_data
        cond_data['result'] = result
        return (cond_data)

    def do_test(cond_data):
        (host_pattern, source, vary_data, result) = (cond_data['host_pattern'], cond_data['source'], cond_data['vary_data'], cond_data['result'])
        im = InventoryManager(inventory = TestInventoryV2(vary_data), sources = host_pattern) 
       

# Generated at 2022-06-11 00:20:42.398202
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources=['localhost,127.0.0.2,'])
    inv.clear_pattern_cache()

    # Test invalid input
    for test_string in [None, '', 'one , ,, ,two']:
        inv.subset(test_string)
        assert inv._subset is None

    # Test empty input
    test_string = ''
    inv.subset(test_string)
    assert inv._subset == ['']

    # Test one host input
    test_string = 'one'
    inv.subset(test_string)
    assert inv._subset == ['one']

    # Test two host input
    test_string = 'one, two'
    inv

# Generated at 2022-06-11 00:20:50.570848
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    log_dir = os.path.join(os.path.dirname(__file__), 'logs')
    os.makedirs(log_dir, exist_ok=True)
    log_file = os.path.join(log_dir, 'test_InventoryManager_parse_source.log')
    logging.basicConfig(level=logging.DEBUG, filename=log_file)

    cache = InventoryCache()
    manager = InventoryManager(cache=cache)
    sources = [{'hosts': 'localhost', 'vars': {'key': 'value'}}]
    manager.parse_sources(sources, "localhost")

    results = [{"localhost": [{"key": "value"}]}]
    assert cache.data == results

    cache = InventoryCache()
    manager = InventoryManager(cache=cache)

# Generated at 2022-06-11 00:20:55.624151
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():

    im = InventoryManager()

    # FIXME: finish this
    #im.add_host('test')
    #im.add_group('all')
    #im.add_group('test')
    #im.get_hosts('test')

    try:
        im.add_group('test')
    except AnsibleError:
        pass
    else:
        raise AssertionError("Failed to detect duplicate group 'test'")

    try:
        im.add_host('test')
    except AnsibleError:
        pass
    else:
        raise AssertionError("Failed to detect duplicate host 'test'")

    try:
        im.get_host('test')
    except AnsibleError:
        pass
    else:
        raise AssertionError("Failed to detect missing host 'test'")



# Generated at 2022-06-11 00:20:59.388763
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager = InventoryManager()
    inventory_manager.subset(["host1", "host2"])
    assert inventory_manager._subset == ["host1", "host2"]

# Generated at 2022-06-11 00:21:10.271997
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    im = InventoryManager()
    im.subset(None)



# Generated at 2022-06-11 00:21:22.143035
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():

    # inventory_manager.get_hosts(pattern="all", ignore_limits=False, ignore_restrictions=False, order=None)

    # Example: hosts_list_from_inventory_file() will be executed with common arguments

    example_hosts_list_from_inventory_file = dict(
        all="""
        localhost ansible_connection=local ansible_python_interpreter="{{ ansible_playbook_python }}" ansible_host=127.0.0.1
        localhost ansible_connection=local ansible_host=127.0.0.1
        """)

    hosts_list_from_inventory_file = example_hosts_list_from_inventory_file


# Generated at 2022-06-11 00:21:30.029467
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory = InventoryManager('sample_1.yaml')

    hosts = inventory.get_hosts('all')
    assert hosts is not None
    assert len(hosts) == 4

    hosts = inventory.get_hosts('app')
    assert hosts is not None
    assert len(hosts) == 2

    hosts = inventory.get_hosts('db')
    assert hosts is not None
    assert len(hosts) == 1

    hosts = inventory.get_hosts('all:!app')
    assert hosts is not None
    assert len(hosts) == 2

    hosts = inventory.get_hosts('all:!app:!db')
    assert hosts is not None
    assert len(hosts) == 1


# Generated at 2022-06-11 00:21:38.235620
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    l = [{'hostname':'HOST1','foo':'bar','bar':'baz','group_names':['foo','bar']},
         {'hostname':'HOST2','foo':'bar','bar':'baz','group_names':['foo','bar']}] # FIXME duplicate
    inventory = InventoryManager(loader=None, sources=None)
    inventory.add_host(Host(name='HOST1', variables={'foo': 'bar', 'bar': 'baz'}, groups=tuple(['foo','bar'])))
    inventory.add_host(Host(name='HOST2', variables={'foo': 'bar', 'bar': 'baz'}, groups=tuple(['foo','bar'])))
    inventory.add_group(Group(name='foo'))

# Generated at 2022-06-11 00:21:49.001626
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader)
    # Can use get_hosts() when we have groups in inventory
    group = Group('all')
    inv_manager.inventory._groups['all'] = group
    host_1 = Host('localhost')
    host_1.vars = {'ansible_python_interpreter': u'/usr/bin/python2.7'}
    inv_manager.inventory._hosts['localhost'] = host_1
    group.add_host(host_1)
    host_2 = Host

# Generated at 2022-06-11 00:21:53.700823
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    """
    Tests for inventory/manager.py::InventoryManager::subset
    """
    args = {}
    kwargs = {"subset_pattern":None}
    inventory_manager = InventoryManager(**kwargs)
    got = inventory_manager.subset(**kwargs)
    assert got == []


# Generated at 2022-06-11 00:22:05.236306
# Unit test for function split_host_pattern

# Generated at 2022-06-11 00:22:17.013092
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    data = "host1 host2 host3 host4 host5"
    with open(default_local_tmp_dir('hosts'), 'w') as f:
        f.write(data)

    inventory = InventoryManager(loader=DataLoader(), sources="%s,%s" % (
        default_local_tmp_dir('hosts'),
        MOCK_ORIGIN_HOSTS_FILE,
    ))
    # When no pattern is given all hosts should be returned
    assert inventory.get_hosts() == inventory.get_hosts('all')

    # When a valid pattern is given matching hosts should be returned
    assert inventory.get_hosts('host1') == [Host(name='host1', port=22)]

    # When an invalid pattern is given an empty list should be returned

# Generated at 2022-06-11 00:22:24.439003
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory_manager = InventoryManager()
    inventory_manager._inventory = InventoryMock()
    inventory_manager._subset = None
    inventory_manager._restriction = None
    result = inventory_manager.get_hosts()
    assert result == ['host1']
    inventory_manager._subset = ['host2']
    result = inventory_manager.get_hosts()
    assert result == []
    inventory_manager._restriction = ['host2']
    result = inventory_manager.get_hosts()
    assert result == []

# Generated at 2022-06-11 00:22:34.345425
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    inventory = InventoryManager(loader=None, sources="inventory/hosts")
    res = inventory.list_hosts()
    print(res)
    res = inventory.list_groups()
    print(res)
    res = inventory.list_hosts(pattern="all")
    print(res)
    res = inventory.list_hosts(pattern="linux")
    print(res)
    res = inventory.list_hosts(pattern="win")
    print(res)
    res = inventory.list_hosts(pattern="linux:win")
    print(res)
    res = inventory.list_hosts(pattern="ubuntu:win")
    print(res)
    res = inventory.list_hosts(pattern="win[1:3]")
    print(res)

# Generated at 2022-06-11 00:22:50.191860
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    from ansible.inventory.manager import InventoryManager
    inventory_manager = InventoryManager(None)
    # FIXME: Do something with this test
    assert inventory_manager.subset(None) is None

# Generated at 2022-06-11 00:22:57.881141
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():

    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    inventory = InventoryManager(loader=None)

    # create two groups
    g1 = Group('g1')
    g2 = Group('g2')
    g3 = Group('g3', subgroups=[g1, g2])

    # create four hosts
    h1 = Host('h1')
    h2 = Host('h2')
    h3 = Host('h3')
    h4 = Host('h4')

    # put them together
    inventory.add_group(g1)
    inventory.add_group(g2)
    inventory.add_group(g3)

    inventory.add_host(h1)
    inventory.add_host(h2)
    inventory.add_host(h3)

# Generated at 2022-06-11 00:23:07.179308
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    '''
    inventory_manager.py: InventoryManager().parse_source()
    '''

    inventory_manager = InventoryManager(loader=DictDataLoader())
    # test_parse_source_1
    pattern = './test/test_data/test_inventory_manager/test_parse_source_1/example.ini'

    expected = OrderedDict()
    expected['all'] = {'hosts': [u'localhost', u'other'], u'vars': {u'ansible_ssh_user': u'root'}}
    expected[u'webservers'] = {'hosts': [u'www1', u'www2'], u'vars': {u'group_name': u'web_servers'}}

# Generated at 2022-06-11 00:23:13.331317
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    im = InventoryManager(loader=None, sources=['foo/bar.cfg'])
    im._read_config_data('foo/bar.cfg')
    assert isinstance(im._read_config_data('foo/bar.cfg'), dict)
    assert not isinstance(im._read_config_data('foo/bar.cfg'), list)


# Generated at 2022-06-11 00:23:23.268907
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host

    pb_ctx = PlayContext()
    my_inv = Inventory("")
    t_local = Host("t.unix.local", my_inv, port=22)
    t1_local = Host("t1.unix.local", my_inv, port=22)
    t2_local = Host("t2.unix.local", my_inv, port=22)
    t3_local = Host("t3.unix.local", my_inv, port=22)
    t4_local = Host("t4.unix.local", my_inv, port=22)
    t_vid = Inventory("")

# Generated at 2022-06-11 00:23:35.372536
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    from ansible.parsing.dataloader import DataLoader
    results = []
    # Allow Unix style @filename data
    for x in ['@/usr/local/ansible/foo.txt']:
        if x[0] == "@":
            b_limit_file = to_bytes(x[1:])
            if not os.path.exists(b_limit_file):
                raise AnsibleError(u'Unable to find limit file %s' % b_limit_file)
            if not os.path.isfile(b_limit_file):
                raise AnsibleError(u'Limit starting with "@" must be a file, not a directory: %s' % b_limit_file)

# Generated at 2022-06-11 00:23:44.989354
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():
    inv_manager = InventoryManager('inventory', os.environ, os.getcwd())
    assert inv_manager._parse_sources('localhost,') == (['inventory'], ['localhost'])
    assert inv_manager._parse_sources('localhost,,') == (['inventory'], ['localhost'])
    assert inv_manager._parse_sources('host_list,') == (['inventory', 'host_list'], [])
    assert inv_manager._parse_sources(',host_list') == (['inventory', 'host_list'], [])
    assert inv_manager._parse_sources('host_list,,host_list2') == (['inventory', 'host_list', 'host_list2'], [])

# Generated at 2022-06-11 00:23:49.427333
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
  try:
    im = InventoryManager(loader=None, sources="nonexistent")
    im.parse_sources()
    assert False, "AnsibleError exception should be raised"
  except AnsibleError as e:
    assert "Unable to open or parse 'nonexistent'" in str(e)

# Generated at 2022-06-11 00:24:00.131831
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    '''
    This is an autospec for InventoryManager class
    method get_hosts
    '''
    # for coverage
    import multiprocessing
    multiprocessing.get_context('fork')

    from ansible_collections.testns.testcoll.plugins.inventory.test_data import MockInventory
    from ansible_collections.testns.testcoll.plugins.inventory import test_data
    from ansible_collections.testns.testcoll.plugins.inventory.test_data import MockHost
    import random
    import string

    inventory = MockInventory()
    inventory.hosts = {}

    # test that _evaluate_patterns works
    pattern = ['all']
    inventory.patterns._evaluate_patterns(pattern)
    inventory.patterns._evaluate_patterns(pattern)

    # test simple patterns

# Generated at 2022-06-11 00:24:05.023482
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    manager = InventoryManager()
    assert manager.parse_source("host1,host2", []) == ["host1", "host2"]

    display.verbosity = 2
    assert manager.parse_source("host1,host2:~[a-z]", []) == ["host1", "host2:~[a-z]"]
    display.verbosity = 0


# Generated at 2022-06-11 00:24:46.502027
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    import pytest
    from ansible.executor.host_manager import InventoryManager

    # Test call with positional arguments
    # find all hosts with a specific attribute
    im = InventoryManager(inventory=None)
    im.subset("attribute:value")
    assert im._subset == ['attribute:value']

    # test call with keyword arguments
    im = InventoryManager(inventory=None)
    im.subset(subset_pattern=None)
    assert im._subset == None

# Generated at 2022-06-11 00:24:49.567506
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    # There is no return from this method, so we're not testing it directly
    # We will test it indirectly in other tests
    pass

# Generated at 2022-06-11 00:25:01.043979
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory = InventoryManager(loader=FakeLoader())
    hostvars = inventory.hostvars
    subset = inventory.subset
    remove_restriction = inventory.remove_restriction
    clear_pattern_cache = inventory.clear_pattern_cache
    get_hosts = inventory.get_hosts
    restriction = inventory._restriction
    subset_patterns = inventory._subset
    hosts_patterns_cache = inventory._hosts_patterns_cache

    # subset is None
    subset(subset_pattern=None)
    assert subset_patterns is None
    assert hosts_patterns_cache == {}
    assert restriction is None

    # subset is a string
    subset(subset_pattern='group')
    assert subset_patterns == ['group']
    assert restriction is None

# Generated at 2022-06-11 00:25:02.209111
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    pass

# Generated at 2022-06-11 00:25:09.693691
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    pattern = "all"
    x = InventoryManager()
    x.set_inventory(Inventory())

    # check for "all"
    if pattern == "all":
        return sorted([h.name for h in x._inventory.hosts.values() if h.name not in x._inventory.groups])

    # FIXME: need better tests
    get_hosts_results = sorted(['localhost', '127.0.0.1'])
    assert x.get_hosts(pattern=pattern) == get_hosts_results

    item = 'localhost'
    assert item in ['localhost', '127.0.0.1']

    x._hosts_patterns_cache = {}
    assert x._hosts_patterns_cache == {}

    if not (x._subset or x._restriction):
        return get_hosts

# Generated at 2022-06-11 00:25:21.988993
# Unit test for method list_hosts of class InventoryManager

# Generated at 2022-06-11 00:25:22.744768
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    assert True == True

# Generated at 2022-06-11 00:25:35.243605
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    from string import ascii_letters
    from collections import defaultdict
    from itertools import product

    from ansible.module_utils._text import to_bytes, to_text

    def generate_inventory(num_hosts, num_groups, group_size):
        hs = [to_text(h) for h in ascii_letters[:num_hosts]]
        gs = [to_text(g) for g in ascii_letters[:num_groups]]
        gs = set(gs + [to_text(g) + 'group' for g in gs])

        inv = defaultdict(lambda: defaultdict(set))
        inv['_meta']['hostvars'] = defaultdict(dict)

        # create host entries

# Generated at 2022-06-11 00:25:40.130939
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    # Execute code to be tested
    source = u"host1\nhost2\nhost3"
    options = Options()
    inventory_manager = InventoryManager(loader=None, sources=source, options=options)
    inv_source = inventory_manager.parse_sources()

    # Test assertions
    assert len(inv_source.hosts) == 3

# Generated at 2022-06-11 00:25:50.693246
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory_path = os.path.join(os.getcwd(), 'test/integration/inventory/hosts.yml')
    options = Options(listtags=False, listtasks=False, listhosts=False, syntax=False, connection='ssh',
                      module_path=None, forks=100, private_key_file=None,
                      ssh_common_args=None, ssh_extra_args=None,
                      sftp_extra_args=None, scp_extra_args=None, become=False,
                      become_method=None, verbosity=None, check=False, extra_vars=[],
                      diff=False, inventory=inventory_path, subset=None, module_paths=None, test=False)