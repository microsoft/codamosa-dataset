

# Generated at 2022-06-11 00:18:20.741998
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory_file = {'all': {'hosts': ['localhost', 'server1'],
                              'vars': {'group_var': 5}}}

    # Test: with cache
    cache_row = dict()
    for pattern in ['*', 'all', 'server*', 'server?', 'server*[1]']:
        cache_row[pattern] = ['localhost', 'server1']

    inventory = InventoryManager(inventory_file)
    inventory.get_hosts(pattern='*')
    inventory.get_hosts(pattern='all')
    inventory.get_hosts(pattern='server*')
    inventory.get_hosts(pattern='server?')
    inventory.get_hosts(pattern='server*[1]')

    assert cache_row == inventory._hosts_patterns_cache

    # Test: with empty

# Generated at 2022-06-11 00:18:31.338729
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory = InventoryManager(inventory=dict(hosts=dict(host1=dict(ansible_ssh_host="10.0.0.1", ansible_ssh_port=22), host2=dict(ansible_ssh_host="10.0.0.2", ansible_ssh_port=22), host3=dict(ansible_ssh_host="10.0.0.3", ansible_ssh_port=22)), groups=dict(group1=dict(hosts=["host1", "host2"]), group2=dict(hosts=["host2", "host3"]))), loader=DataLoader())
    inventory_manager = InventoryManager(loader=DataLoader(), sources="host1")
    pattern = "all"
    ignore_limits = False
    ignore_restrictions = False
    order = None

# Generated at 2022-06-11 00:18:31.931436
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    pass


# Generated at 2022-06-11 00:18:36.811349
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    # loop to test all known hosts and groups
    for host_name, host_data in inventory_hosts.items():
        if host_name == "localhost":
            continue
        host_list = InventoryManager._get_hosts(host_name)
        if len(host_list) > 1:
            print("More than one host found in the inventory for host: %s" % host_name)
        # assert host is found
        assert(len(host_list) == 1)
        # assert host has the wanted name
        assert(host_list[0].name == host_name)
        # assert host is found in the right group
        assert(host_list[0].groups == host_data['groups'])
    # compare the number of hosts and the number of host in the inventory

# Generated at 2022-06-11 00:18:46.322355
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    Host.set_vars_from_file = lambda self: None
    Group.set_vars_from_file = lambda self: None
    inventory = Inventory('.')
    manager = InventoryManager(inventory)

    subset = ['localhost', 'foo']
    manager.subset(subset)
    assert manager._subset == subset

    subset = ['~/my_hosts']
    manager.subset(subset)
    assert manager._subset

    subset = [None]
    manager.subset(subset)
    assert manager._subset == subset

# Generated at 2022-06-11 00:18:58.615268
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory = InventoryManager(loader=DictDataLoader(), sources=['/dev/null'])
    eq_(inventory.parse_source(), [])
    eq_(inventory.loaders, {})

    inventory = InventoryManager(loader=DictDataLoader(), sources=['localhost'])
    eq_(inventory.parse_source(), [{}])


# Generated at 2022-06-11 00:19:10.889921
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    #sample test functions
    source_file = os.path.join(
        os.path.dirname(__file__),
        '..', '..', '..', 'plugins', 'inventory', 'test_inventory.yml'
    )

    inv_manager = InventoryManager(
        loader=DataLoader(),
        sources=source_file
    )
    #call get_hosts method
    all_hosts = sorted(h.name for h in inv_manager.get_hosts(pattern="all"))
    assert all_hosts == ['group_a', 'group_b', 'group_c_all', 'group_c_even', 'group_c_odd', 'group_d', 'group_e', 'ungrouped']

# Generated at 2022-06-11 00:19:19.448989
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    data = """
    [all:vars]
    foo = bar
    [some_host]
    some_host
    [some_other_host]
    some_other_host
    [some_group]
    some_host
    [some_other_group]
    some_other_host
    """
    b_data = to_bytes(data, errors='surrogate_or_strict')
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    fake_loader = DataLoader()
    fake_loader.set_basedir(DATA_PATH)
    fake_inventory = InventoryManager(loader=fake_loader, sources=b_data)
    fake_inventory.parse_sources(fake_inventory._sources)

# Generated at 2022-06-11 00:19:22.337155
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    from ansible.inventory.manager import InventoryManager

    # FIXME: test InventoryManager.parse_source
    # FIXME: is there a way to test this without a lot of mocking or
    #        extra file creation?



# Generated at 2022-06-11 00:19:34.095142
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():

    inv = InventoryManager("")

    inv.subset(None)

    inv.subset("")

    inv.subset("one")

    inv.subset("one two")

    inv.subset("one two three")

    inv.subset("one two three @/file")

    assert True

    # use sys.stdout to suppress output of 'process_subset_pattern'
    old_out = sys.stdout
    sys.stdout = io.BytesIO()

    # Test failure parameters
    try:
        inv.subset("@test_invalid_file")
    except AnsibleError:
        pass
    else:
        assert False

    try:
        inv.subset("@/path/that/does/not/exist/test_invalid_file")
    except AnsibleError:
        pass
   

# Generated at 2022-06-11 00:21:00.277417
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    results = []

    # Simple test, basic pattern
    results.append(InventoryManager('localhost,').list_hosts(pattern='localhost'))

    # Test ungrouped hosts
    results.append(InventoryManager('localhost,').list_hosts(pattern='ungrouped'))

    # Test array of patterns
    patterns = ['localhost', 'ungrouped']
    results.append(InventoryManager('localhost,').list_hosts(pattern=patterns))

    # Test glob pattern
    results.append(InventoryManager('local*').list_hosts(pattern='local*'))
    results.append(InventoryManager('localhost,').list_hosts(pattern='local*'))

    # Test regex pattern
    results.append(InventoryManager('~l*').list_hosts(pattern='~l*'))
    results

# Generated at 2022-06-11 00:21:04.663911
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    data = {
        'all': {
            'hosts': [
                'localhost',
            ],
        }
    }

    # FIXME: this should be mocked out, not read from the filesystem
    inventory = InventoryManager(
        None,  # loader
        None,  # variable_manager
        loader.load_from_file('test/test_inventory_manager.yml'),
        True,  # host_list
        cache=False,
    )

    inventory.subset(None)
    assert inventory._subset is None

    inventory.subset('foo*')
    assert inventory._subset == ['foo*']

    inventory.subset('@test/test_inventory_manager_subset.txt')
    assert inventory._subset == ['foo*', 'bar*']


# Generated at 2022-06-11 00:21:05.277171
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    pass

# Generated at 2022-06-11 00:21:16.975570
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inv = InventoryManager(loader=DictDataLoader({}))
    # TODO: this test might fail on case insensitive filesystem
    #       or system with different path separator
    subset = ['host1', 'host2']
    limits = 'host[1:2]'

    inv.subset(initial_subset)
    assert inv._subset == subset
    assert inv.list_hosts('all') == subset
    inv.subset(limits)
    assert inv._subset == subset
    assert inv.list_hosts('all') == subset
    inv.remove_restriction()
    assert inv._subset == subset
    assert inv.list_hosts('all') == subset

if __name__ == '__main__':
    pytest.main([__file__, '-v'])

# Code for DataLoader --------------------------------------------------------

# Generated at 2022-06-11 00:21:20.327606
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
  inventory = InventoryManager("inventory.txt")
  hosts = inventory.get_hosts("all")
  for host in hosts:
    print(host)
  return

# Generated at 2022-06-11 00:21:22.833888
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # set up
    inv = InventoryManager(loader=DictDataLoader({}), sources=['localhost,'])

    # test
    subset_pattern=None
    inv.subset(subset_pattern)


# Generated at 2022-06-11 00:21:34.892525
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    print('In test_InventoryManager_subset')

    # If the following fails - replace the contents with the previous contents

# Generated at 2022-06-11 00:21:43.286585
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    i = InventoryManager(inventory=Inventory(loader=DataLoader()))
    i.parse_inventory(host_list=[{"name": "localhost"}])

    hosts = i.list_hosts()
    assert hosts == ["localhost"]
    # not a valid Inventory object
    i.parse_inventory(host_list=[])
    with pytest.raises(AssertionError):
        hosts = i.list_hosts()



# Generated at 2022-06-11 00:21:53.370023
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    inventory = InventoryManager([
        InventoryHost(name="foo", port=22),
        InventoryHost(name="bar", port=22)
    ])
    inventory._subset = ['bar']
    assert inventory.list_hosts("all") == ["bar"]
    assert inventory.list_hosts("all", ignore_limits=True) == ["foo", "bar"]
    assert inventory.list_hosts("foo") == ["foo"]
    assert inventory.list_hosts("bar") == ["bar"]
    assert inventory.list_hosts("foo,bar") == ["foo", "bar"]
    assert inventory.list_hosts("f*") == ["foo"]
    assert inventory.list_hosts("b*") == ["bar"]
    assert inventory.list_hosts("*") == ["bar"]

# Generated at 2022-06-11 00:21:59.285858
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
        i = InventoryManager("hosts", [])
        i.subset("group1, group2")
        expected = ['group1', 'group2']
        try:
            assert i._subset == expected
        except AssertionError:
            print("\nExpected inventory subset to be: %s, but instead got %s" % (expected, i._subset))
