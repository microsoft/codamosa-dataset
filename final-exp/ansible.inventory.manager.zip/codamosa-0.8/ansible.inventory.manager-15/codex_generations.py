

# Generated at 2022-06-11 00:18:45.431039
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # Setup
    manager = InventoryManager(loader=None, sources=None)
    # Test
    manager.subset(subset_pattern = None)
    # Validate
    # Tear Down


# Generated at 2022-06-11 00:18:49.997942
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    print("Test subset")
    test_subset_patterns = ["all", "1 2 3 4 5 6 7 8 9", "a b c d e"]
    test_subset_result = {
        "all": None,
    }


# Generated at 2022-06-11 00:19:03.054941
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    data = dict(
        ansible_connection='mock',
        ansible_ssh_user='mockuser',
        ansible_ssh_pass='pass',
        ansible_sudo_pass='sudo',
        mock_path = os.path.join(os.path.dirname(__file__), '..', 'unittests', 'fixtures', 'mock_data')
    )

    im = InventoryManager(host_list=[])
    im.parse_sources('localhost,')
    im.subset(['foo1', 'foo2'])
    assert len(im.get_hosts()) == 0

    im = InventoryManager(host_list=[])
    im.parse_sources('localhost,')
    im.subset(['all'])
    assert len(im.get_hosts()) == 1

   

# Generated at 2022-06-11 00:19:13.893200
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    m = InventoryManager()
    fd, p = tempfile.mkstemp(prefix='ansiballz_')
    os.close(fd)
    with open(p, 'w') as foo:
        foo.write('[all:vars]\n')
        foo.write('foo=bar\n')
        foo.write('bar=foo\n')
        foo.write('[hostgroup]\n')
        foo.write('localhost\n')
    inventory = m.parse_source(p)
    assert inventory['all']['vars'] == {'foo': 'bar', 'bar': 'foo'}
    assert inventory['hostgroup'] == {'hosts': ['localhost'], 'vars': {}}
    os.unlink(p)


# Generated at 2022-06-11 00:19:20.956898
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory = TestInventory()
    all_hosts = inventory.get_hosts()
    assert len(all_hosts) == 3

    inv_mgr = InventoryManager(loader=None, sources=['localhost,'])
    host = inv_mgr.get_host("localhost")
    assert host
    assert host.get_vars()["ansible_connection"] == "local"
    host = inv_mgr.get_host("unknown")
    assert not host
    host = inv_mgr.get_host("unknown", ignore_errors=True)
    assert not host
    try:
        host = inv_mgr.get_host("unknown", ignore_errors=False)
        assert False, "An error should have been raised"
    except AnsibleError:
        pass


# Generated at 2022-06-11 00:19:31.425098
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory = Mock()
    inventory._hosts = {'1.2.3.4': ansible.inventory.host.Host}
    inventory._vars = {'1.2.3.4': {'ansible_host': '1.2.3.4'}}
    inventory._groups = {'all': ansible.inventory.group.Group}
    inventory._inventory = inventory

    inventory_mgr = InventoryManager(inventory)
    # Clear cache for testing
    inventory_mgr._pattern_cache = {}

    inventory_mgr.subset('1.2.3.4')
    assert inventory_mgr._subset == ['1.2.3.4']

    inventory_mgr.remove_restriction()
    assert inventory_mgr._restriction is None



# Generated at 2022-06-11 00:19:42.572185
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    # Setup arguments needed by the Ansible Inventory
    connection_manager = ConnectionManager()
    loader_class = DataLoader()
    variable_manager = VariableManager(loader_class)
    inventory_manager = InventoryManager(loader_class, variable_manager, connection_manager)
    inventory_manager.set_inventory(Inventory())
    pattern = ['test1', 'test2']

    # The Ansible Inventory need a module_name argument, so a _Task(namedtuple) must be created
    task = Task(
                action =  dict(
                            module = 'test_module'
                )
    )

    # The Ansible Inventory need a _Variable(namedtuple) object

# Generated at 2022-06-11 00:19:54.145776
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    '''
    Unit test for method parse_source of class InventoryManager
    '''
    print('Testing parse_source...')
    # initializing inventory
    filename = os.path.join(os.path.dirname(__file__), 'hosts')
    inventory = InventoryManager(loader=MockLoader({}))
    # load inventory
    inventory.load_inventory(filename)
    inventory.parse_sources('hosts')
    # test parse_sources()
    assert 'foo' in inventory.hosts
    assert 'bar' in inventory.hosts
    assert 'baz' in inventory.hosts
    assert 'all' in inventory.groups
    assert 'ungrouped' in inventory.groups
    assert 'foos' in inventory.groups
    assert 'bars' in inventory.groups
    assert 'bazs' in inventory

# Generated at 2022-06-11 00:19:56.817020
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager = InventoryManager()
    assert not inventory_manager.subset('foo')
    assert not inventory_manager.subset('foo')


# Generated at 2022-06-11 00:19:57.884588
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    pass


# Generated at 2022-06-11 00:20:34.607883
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    from argparse import Namespace
    from ansible.cli.arguments import optparse_helpers as opt_help
    from ansible.errors import AnsibleError
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    import ansible.constants as C
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.inventory.data import InventoryData

    # Create an argument parser
    args = Namespace()
    opt_help.add_vault_options(args)
    opt_help.add_vault_password_options(args)

# Generated at 2022-06-11 00:20:42.304207
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory = InventoryManager('localhost,')
    inventory.subset(None)
    inventory.subset('host1')
    inventory.subset('host1,host2')
    inventory.subset('host1:host2')
    inventory.subset('@limit_file')

    # The following will raise an exception
    try:
        inventory.subset('@/non/existing/limit/file')
    except AnsibleError:
        pass
    try:
        inventory.subset('@/home/user/')
    except AnsibleError:
        pass

# Generated at 2022-06-11 00:20:47.721971
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory = InventoryManager(loader, sources='localhost,')

    # Test when subset_pattern is None.
    subset_pattern = None
    assert inventory._subset is None
    inventory.subset(subset_pattern)
    assert inventory._subset is None

    # Test when subset_pattern is a list.
    subset_pattern = ['www[2:4]']
    inventory.subset(subset_pattern)
    assert inventory._subset == subset_pattern


# Generated at 2022-06-11 00:20:53.664055
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    import os
    import tempfile
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultEditor
    import json
    import sys


# Generated at 2022-06-11 00:20:58.488521
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():

    i = InventoryManager(None)
    assert i._subset is None
    i.subset(None)
    assert i._subset is None
    i.subset('host1,host2')
    assert i._subset == ['host1', 'host2']
    i.subset('@/tmp/subset')
    assert i._subset == ['host1', 'host2', '/tmp/subset']
    i.subset('@subset_file')
    assert i._subset == ['host1', 'host2', '/tmp/subset', 'subset_file']
    i.subset('@subset_file1,subset_file2')

# Generated at 2022-06-11 00:20:59.896085
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager = InventoryManager(loader=None, sources=[])
    pattern = None
    inventory_manager.subset(pattern)

    # verify that the subclass methods have been executed
    assert True



# Generated at 2022-06-11 00:21:04.268468
# Unit test for method get_hosts of class InventoryManager

# Generated at 2022-06-11 00:21:16.231476
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # test valid options
    # @@@ TODO: assert()
    i = InventoryManager(loader, sources=["/dev/null"])
    i.subset("a")
    i.subset("a,b")
    i.subset("a,b,c")
    i.subset("a,b,c,")
    i.subset("a,b,c,   ")
    i.subset("  a,b,c")

    # test valid options with implicit localhost
    i = InventoryManager(loader, sources=["/dev/null"], implicit_localhost=True)
    i.subset("a")
    i.subset("a,b")
    i.subset("a,b,c")
    i.subset("a,b,c,")

# Generated at 2022-06-11 00:21:26.561717
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    import pytest
    from ansible import constants as C

    # inventory = InventoryManager(loader, sources=inventory_hosts_path)
    inventory = InventoryManager(loader, sources='./test/test_inventory')
    # print(inventory.list_hosts())
    # ['test_test_1', 'test_test_2', 'test_test_3']

    assert inventory.list_groups() == []

    result = inventory.get_hosts()
    # print(result)
    # [ <Host test_test_1>, <Host test_test_2>, <Host test_test_3> ]

    result = inventory.list_hosts()
    # print(result)
    # ['test_test_1', 'test_test_2', 'test_test_3']


# Generated at 2022-06-11 00:21:36.944422
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    # see if we can parse sources of host variables for localhost
    for source in ['', 'localhost', '127.0.0.1', '::1', '::1 127.0.0.1']:
        im = InventoryManager(host_list=[])
        assert im.parse_source(source)[0] == 'localhost'
        assert im.parse_source(source)[1] == 'ssh'

    # see if we can parse sources of host variables for non-localhost
    for source in ['1.2.3.4', '1.2.3.4 ansible_connection=ssh']:
        im = InventoryManager(host_list=[])
        assert im.parse_source(source)[0] == source
        assert im.parse_source(source)[1] == 'ssh'

    # see if we can parse sources of host variables for non

# Generated at 2022-06-11 00:22:10.999354
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    hosts_list = ['one', 'two', 'three']
    host_vars = ['ansible_connection=local']
    host_pattern = ['two', 'three']
    inventory = Inventory(host_list=hosts_list, host_vars=host_vars)
    inventory_manager = InventoryManager(loader=None, inventory=inventory)
    hosts = inventory_manager.get_hosts(pattern=host_pattern)
    assert hosts == inventory.get_hosts(pattern=host_pattern)

# Generated at 2022-06-11 00:22:16.243676
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory = InventoryManager("localhost")
    assert inventory.parse_source("file", "./test/lib/ansible_test/_data/hosts") == dict(host_list="./test/lib/ansible_test/_data/hosts", cache=None, plugin=None, cache_min=0, cache_max=0)

# Generated at 2022-06-11 00:22:26.642405
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    import unittest
    from ansible.inventory.manager import InventoryManager
    from __main__ import display
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.vars_plugin.yaml import VarsModule
    display.verbosity = 3

    class TestInventoryManager(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_get_hosts(self):
            inventory = InventoryManager(loader=None, sources=[])
            inventory.groups['all'] = Group('all')
            inventory.groups['all']._vars = VarsModule({'foo': 'bar'})
            inventory.groups['ungrouped']

# Generated at 2022-06-11 00:22:36.705014
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    from collections import namedtuple
    from ansible.module_utils.six import string_types

    Settings = namedtuple('Settings', ['host_list'])

    class Inventory(object):
        def __init__(self, inventory):
            if isinstance(inventory, string_types):
                self.hosts = inventory.split(',')
            else:
                self.hosts = inventory
            self.groups = {}
        def get_host(self, hostname):
            if hostname in self.hosts:
                return hostname
            else:
                return None

    class Host(object):
        def __init__(self, hostname):
            self.name = hostname

    class Runner(object):
        pass

    inventory = Inventory(['localhost', 'foosball', 'foobaz'])
    runner = Runner()

# Generated at 2022-06-11 00:22:39.358459
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    # Check host_list variable is define
    print(host_list)
    # Check host_list variable is not empty
    assert (len(host_list) > 0)
test_InventoryManager_list_hosts()

# Generated at 2022-06-11 00:22:40.485449
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # TODO
    assert True



# Generated at 2022-06-11 00:22:41.693168
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    pass


# Generated at 2022-06-11 00:22:43.936793
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory = InventoryManager("localhost")
    result = inventory._parse_source("localhost", True)



# Generated at 2022-06-11 00:22:55.900827
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inv = InventoryManager([], [])

# Generated at 2022-06-11 00:23:05.808140
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():

    class InventoryMock():

        def __init__(self, groups):
            self.groups = groups

        def get_host(self, hostname):
            if hostname in self.groups:
                return self.groups[hostname]

    groups = {
        'all': {
            'hosts': ['example.org', 'cpantesters.org', 'foofoo.org'],
        },
        'web': {
            'hosts': ['foofoo.org'],
        },
    }

    inventory = InventoryMock(groups)
    inv_mgr = InventoryManager(inventory)
    inv_mgr.subset(None)
    assert inv_mgr.list_hosts() == ['example.org', 'cpantesters.org', 'foofoo.org']

# Generated at 2022-06-11 00:23:28.243632
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    assert True

# Generated at 2022-06-11 00:23:32.177283
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    im = InventoryManager(host_list='')
    im._inventory = FakeInventory()
    im.subset('foo')
    assert im._subset == ['foo']


# Generated at 2022-06-11 00:23:43.302592
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():

    # host inventory
    inventory_hosts = {
        "test_host": {
            "hostname": "test_host",
            "vars": {
                "ansible_connection": "local",
                "ansible_python_interpreter": "python"
            },
            "groups": [
                "test_group"
            ]
        }
    }

    # group inventory
    inventory_groups = {
        "test_group": {
            "hosts": [
                "test_host"
            ],
            "vars": {}
        }
    }

    # create inventory
    inventory = Inventory(loader=None, host_list=[], groups=inventory_groups, sources=[])

    # create cache for inventory
    inventory.hosts = inventory_hosts

    # create inventory manager object
    im = InventoryManager

# Generated at 2022-06-11 00:23:45.908940
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    """Test InventoryManager.subset"""
    x = InventoryManager()
    assert x.subset == x._subset


# Generated at 2022-06-11 00:23:49.203097
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    groups = {
        'group1': [],
    }
    im = InventoryManager(groups)
    hosts = im.list_hosts(pattern='group1')
    assert len(hosts) == 0


# Generated at 2022-06-11 00:23:59.874023
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():
    '''Parse inventory sources provided as command line options'''
    # Test all options
    source_cli = ','.join(['host1', 'host2', 'host3', 'host4', 'host5'])
    inventory = InventoryManager(loader=DictDataLoader({}), sources=source_cli)

    assert inventory.hosts_list == [['host1', 'host2', 'host3', 'host4', 'host5']]

    # Test inventory directory with subdirectories
    inventory_dir = tempfile.mkdtemp()
    inv_file = os.path.join(inventory_dir, 'test')
    subinv_dir = tempfile.mkdtemp(dir=inventory_dir)
    subinv_file = os.path.join(subinv_dir, 'test2')

# Generated at 2022-06-11 00:24:09.813593
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    '''
    Make a fake inventory, parse it.
    '''
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.utils.shlex import shlex_split

    fake_loader = DataLoader()
    fake_loader.set_basedir(".")
    fake_h = Host(name="fake_host")
    fake_g = Group(name="fake_group")
    # Test a simple string
    mocked_lines = ['fake_host', 'fake_group']
    mocked_variables = dict(vars={'var1': '1', 'var2': '2'})
    mocked_hosts = dict(hosts={'fake_host': fake_h})

# Generated at 2022-06-11 00:24:16.576731
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    """ InventoryManager.subset() """
    # initialize InventoryManager object
    m = InventoryManager(loader=DictDataLoader({}))

    # add arguments to method
    subset_pattern = "all"

    m.subset(subset_pattern)

    # check result from InventoryManager.subset
    assert m._subset == 'all'



# Generated at 2022-06-11 00:24:23.922129
# Unit test for function split_host_pattern
def test_split_host_pattern():
    assert split_host_pattern('a, b[1], c[2:3] , d') == ['a', 'b[1]', 'c[2:3]', 'd']
    assert split_host_pattern('a[1,2],b, c[2:3], d') == ['a[1,2]', 'b', 'c[2:3]', 'd']

    # This is valid ansible, but will be misinterpreted by this function.
    # The final ':' must be escaped in this case.
    assert split_host_pattern('a,b:2,c\\:2,d') == ['a', 'b:2', 'c\\:2', 'd']

# Generated at 2022-06-11 00:24:33.714092
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    class MockPattern(object):
        def __init__(self, name):
            self.name = name

        def match(self, name):
            if self.name == 'foo' and name == 'ok':
                return True
            elif self.name == 'bar' and name == 'nok':
                return True
            else:
                return False

    results = [MockPattern('foo'), MockPattern('bar')]
    items = ['ok', 'nok', 'nook']
    im = InventoryManager()
    im._evaluate_patterns = Mock(return_value=results)
    res = im._match_one_pattern('foo')
    assert (len(res) == 1) and (res[0] == results[0])

    # Test immediate return

# Generated at 2022-06-11 00:26:25.509958
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    m_Inventory = MagicMock()
    m_Inventory.get_host.side_effect = [('localhost', None), ('somename', None)]
    
    m_InventoryManager = MagicMock(spec=InventoryManager)
    m_InventoryManager._inventory = m_Inventory
    m_InventoryManager._pattern_cache = {}
    
    result = m_InventoryManager.list_hosts('localhost')
    assert result == ['localhost']
    
    result = m_InventoryManager.list_hosts(None)
    assert result == []

# Generated at 2022-06-11 00:26:36.909115
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    manager = InventoryManager(loader=None, sources=None)
    examples = (
        ('simple', 'hostlist', 'hostlist', None),
        ('with_args', 'hostlist:key=value', 'hostlist', 'key=value'),
        ('simple_quote', '"hostlist"', 'hostlist', None),
        ('no_quote', 'hostlist', 'hostlist', None),
        ('double_quote', '"hostlist:key=value"', 'hostlist:key=value', None),
        ('double_quote_with_args', '"hostlist:key=value" key2=value2', 'hostlist:key=value', 'key2=value2'),
    )

# Generated at 2022-06-11 00:26:45.871773
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inv = InventoryManager(None)
    assert inv.get_hosts() == []
    inv.parse_inventory(None)
    assert inv.get_hosts(pattern="all") != []
    assert inv.get_hosts(pattern="invalid") == []
    assert inv.get_hosts(pattern="localhost") == []
    # TODO : the result of inv.get_hosts(pattern="foobar") depends on the
    # inventory provided, so we cannot test it.
    assert inv.get_hosts(pattern="foobar") == []
    assert inv.get_hosts(pattern="all") != []
    assert inv.get_hosts(pattern="all:!localhost") != []
    assert inv.get_hosts(pattern="all") != []



# Generated at 2022-06-11 00:26:54.145091
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    host1 = Host('host1', groups=['group1', 'group2'])
    host2 = Host('host2', groups=['group1'])
    host3 = Host('host3', groups=['group2'])
    host4 = Host('host4', groups=['group3'])
    inventory = Inventory([host1, host2, host3, host4], {})

    result = InventoryManager(inventory).get_hosts('all')
    assert len(result) == 4
    assert all(h in [host1, host2, host3, host4] for h in result)

    result = InventoryManager(inventory).get_hosts('group1')
    assert len(result) == 2
    assert all(h in [host1, host2] for h in result)

    result = InventoryManager(inventory).get_hosts

# Generated at 2022-06-11 00:27:04.488024
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory = InventoryManager(Loader(), VariableManager(), None)
    im = InventoryModule(inventory)
    im.clear_pattern_cache()
    im.subset('')
    im.host_list = ['foo', 'bar']
    assert im.get_hosts('foo') == ['foo']
    assert im.get_hosts('foo*') == ['foo']
    assert im.get_hosts('*') == ['foo', 'bar']
    assert im.get_hosts(['*']) == ['foo', 'bar']
    assert im.get_hosts('foo:bar') == ['foo', 'bar']
    assert im.get_hosts(['foo', 'bar']) == ['foo', 'bar']
    assert im.get_hosts('[foo:bar]') == ['foo', 'bar']

# Generated at 2022-06-11 00:27:14.924764
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    # The json below is not the actual json generated for the inventory, but
    # it is sufficient for testing the parse_source function.
    json_inventory = '''
    {
        "all": {
            "hosts": {"host1": {"vars": {"a": "b"}}, "host2": {}}
        },
        "_meta": {
            "hostvars": {
                "host1": {"c": "d"},
                "host2": {"e": "f"}
            }
        }
    }
    '''
    inventory_manager = InventoryManager(playbook_basedir='/path/to/playbook')
    inventory = inventory_manager.parse_source(inventory_from='dynamic/script/path', source=json_inventory)

# Generated at 2022-06-11 00:27:17.403916
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    # todo: implement proper unit tests
    # constructor arguments don't seem to be used
    # assert False, "TODO: implement me"
    assert True

# Generated at 2022-06-11 00:27:19.910300
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    load_fixture("hosts")

    im = InventoryManager("hosts", loader=DataLoader())
    im.subset("test")

    assert im._subset == ['test']


# Generated at 2022-06-11 00:27:25.689834
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    """
    parse_source()
    """
    # Test case 1, parse_source(self, host_list, source, cache=False)
    # Test case 2, parse_source(self, host_list, source, cache=False)

    print("Test #1, parse_source(self, host_list, source, cache=False)")
    inventory = Inventory("/tmp")
    inventory_manager = InventoryManager(inventory)
    inventory_manager.parse_sources("", "")

    print("Test #2, parse_source(self, host_list, source, cache=False)")
    inventory = Inventory("/tmp")
    inventory_manager = InventoryManager(inventory)
    inventory_manager.parse_sources("", "")


# Generated at 2022-06-11 00:27:27.871477
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    pass
# Unit tests for method get_hosts of class InventoryManager