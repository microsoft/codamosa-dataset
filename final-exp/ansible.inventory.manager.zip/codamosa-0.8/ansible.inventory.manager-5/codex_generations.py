

# Generated at 2022-06-11 00:18:29.451546
# Unit test for function split_host_pattern
def test_split_host_pattern():
    assert split_host_pattern(u'a,b[1], c[2:3] , d') == ['a', 'b[1]', 'c[2:3]', 'd']
    assert split_host_pattern(u'a:b:c:d') == ['a:b:c:d']
    assert split_host_pattern('') == []
    assert split_host_pattern([]) == []
    assert split_host_pattern('[2001:db8::1]') == ['[2001:db8::1]']
    assert split_host_pattern(u'[2001:db8::1]:22') == ['[2001:db8::1]:22']
    assert split_host_pattern('[db8::1]:22') == ['[db8::1]:22']

# Generated at 2022-06-11 00:18:30.436625
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    obj = InventoryManager()
    assert isinstance(obj.parse_source("/tmp/foo","some_kind"), Inventory) == True


# Generated at 2022-06-11 00:18:37.752219
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    class TestInventoryManager(InventoryManager):
        def __init__(self, host_list, group_list=None):
            self.my_inventory = BaseInventory(host_list, group_list)
            super(TestInventoryManager, self).__init__()
            self.set_inventory(self.my_inventory)
    
    # Test-case 1: Test get_hosts against a non-empty inventory
    test_host_list = ['web1', 'web2', 'web3', 'web4', 'web5', 'db1', 'db2', 'db3', 'db4', 'db5']
    test_group_list = ['webservers', 'dbservers']
    test_patterns = ['webservers']

# Generated at 2022-06-11 00:18:44.092081
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # initialize inventory, play, etc.
    inventory = InventoryManager(loader=None, sources=None)
    fake_subset = [u'one', u'two', u'three']
    inventory.subset(fake_subset)
    # get subset
    mysubset = inventory.subset()
    assert mysubset == fake_subset




# Generated at 2022-06-11 00:18:54.374688
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    host1 = Host("host1")
    host2 = Host("host2")
    host3 = Host("host3")
    hosts = [host1, host2, host3]

    def mock_match_one_pattern(pattern):
        if pattern == 'yes':
            return [host1]
        elif pattern == 'no':
            return []
        elif pattern == 'all':
            return hosts
        elif pattern == 'no_exist':
            return None

    inv_manager = InventoryManager(None)
    inv_manager._match_one_pattern = mock_match_one_pattern

    result_list = inv_manager.get_hosts('yes')
    assert len(result_list) == 1
    assert result_list[0].name == 'host1'

    result_list = inv_manager.get_hosts

# Generated at 2022-06-11 00:19:07.131007
# Unit test for method get_hosts of class InventoryManager

# Generated at 2022-06-11 00:19:16.940243
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():

    # Mock AnsibleOptions, AnsibleLoader and data
    ansible_loader = MagicMock()
    ansible_loader.get_basedir.return_value = '/home/ansible'
    ansible_options = MagicMock()
    ansible_options.inventory = ['/home/ansible/inventory']
    # data uses a list of dicts to represent the inventory
    data = [{u'hosts': [u'localhost'], u'vars': {u'var2': u'value2'}, u'name': u'my_group'}, {u'hosts': [u'localhost', u'other'], u'vars': {u'var1': u'value1'}, u'name': u'all'}]
    ansible_loader.load_from_file.return_value = data
    # Mocked

# Generated at 2022-06-11 00:19:27.880216
# Unit test for function order_patterns
def test_order_patterns():

    assert(order_patterns(['!webservers', '&loadbalancers', 'all']) == ['all', '&loadbalancers', '!webservers'])
    assert(order_patterns(['!webservers', '&loadbalancers']) == ['all', '&loadbalancers', '!webservers'])
    assert(order_patterns(['webservers', 'loadbalancers']) == ['webservers', 'loadbalancers'])
    assert(order_patterns(['webservers', '&loadbalancers']) == ['webservers', '&loadbalancers'])
    assert(order_patterns(['!webservers', 'loadbalancers']) == ['loadbalancers', '!webservers'])

# Generated at 2022-06-11 00:19:39.434815
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    mock_obj = AnsibleMock(name='mock_obj')
    mock_cls = AnsibleMock(return_value=mock_obj)

    results = []
    results.append(mock_obj)
    results.append(mock_obj)
    results.append(mock_obj)
    mock_obj.get_hosts.return_value = results

    with patch.multiple(InventoryManager, __init__=mock_cls, _evaluate_patterns=mock_cls):
        # Test with invalid subset
        targets = InventoryManager('mock', 'mock')
        targets.subset(None)
        assert targets._evaluate_patterns.call_count == 0
        # Test with subset and default parameters
        targets = InventoryManager('mock', 'mock')
        targets.subset

# Generated at 2022-06-11 00:19:46.790878
# Unit test for method subset of class InventoryManager

# Generated at 2022-06-11 00:20:15.323743
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    # Initialize InventoryManager
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory_manager = InventoryManager(loader=loader, variable_manager=variable_manager)
    # Create hosts
    new_host = Host(name="localhost")
    inventory_manager.inventory.add_host(new_host)
    # Test InventoryManager.get_hosts(pattern="localhost")
    get_hosts_method_test = inventory_manager.get_hosts(pattern="localhost")
    assert "localhost" in get_hosts_method_test

# Generated at 2022-06-11 00:20:17.784475
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    '''
    InventoryManager: Parse source list of hosts
    '''
    inventory = InventoryManager(loader=None, sources=['localhost'])
    assert inventory.list_hosts('all') == ['localhost']

# Generated at 2022-06-11 00:20:25.448970
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    m = Mock()
    m.list_hosts = lambda pattern = 'all': []
    m.list_groups = lambda: []
    m.groups = dict()
    m.hosts = dict()

    inv = InventoryManager(m, 'localhost')
    assert inv.parse_source('foo') == [('localhost', 'foo')], 'Could not parse source'

    if HAVE_YAML:
        inv = InventoryManager(m, 'localhost', vault_password='bar')
        assert inv.parse_source('foo') == [('localhost', 'foo')], 'Could not parse source'


# Generated at 2022-06-11 00:20:31.160892
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    """
    Test to parse the inventory source file and returns a list of inventory
    objects.
    """
    mock_inventory = MagicMock()
    mock_inventory.parse_inventory_sources.return_value = 'ok'
    inventory_manager = InventoryManager(mock_inventory)
    assert inventory_manager.parse_source('source', 'test_host') == 'ok'
    assert mock_inventory.parse_inventory_sources.call_count == 1


# Generated at 2022-06-11 00:20:43.025685
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    hosts = [
        "a",
        "b",
    ]
    host1 = Host("a")
    host2 = Host("b")
    host_objs = [
        host1,
        host2,
    ]
    inv = InventoryManager(hosts = hosts, host_objs = host_objs)
    inv._hosts_patterns_cache = {}
    inv._restriction = None
    inv._subset = None
    inv.clear_pattern_cache()
    assert inv.get_hosts(ignore_restrictions=True) == ["a", "b"]
    assert inv.get_hosts() == ["a", "b"]
    inv._restriction = ["a"]
    assert inv.get_hosts(ignore_restrictions=True) == ["a", "b"]

# Generated at 2022-06-11 00:20:50.961875
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    '''
    Unit test for method subset of class InventoryManager
    '''
    import os
    import tempfile
    from io import StringIO

    inventory_manager = InventoryManager()

    print(u'Unmatched limit')
    subs1 = ["test"]
    inventory_manager.subset(u'@test')
    assert subs1 == inventory_manager._subset

    print(u'matched limit')
    subs2 = ["test1", "test2"]
    with tempfile.NamedTemporaryFile() as f:
        f.write(b"%s\n" % subs2[0])
        f.write(b"%s\n" % subs2[1])
        f.flush()
        inventory_manager.subset(u'@%s' % f.name)
        assert subs2 == inventory_manager._sub

# Generated at 2022-06-11 00:21:03.359112
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    inv = InventoryManager([])
    for host in [Host(x) for x in TEST_DATA]:
        inv.add_host(host)
    inv.subset(None)
    inv.restrict_to_hosts(None)

    inv.clear_pattern_cache()
    inv._hosts_patterns_cache = {}

    cmp_lists(inv.list_hosts("all"), ['bsmith', 'bjones', 'cjones', 'jdoe', 'jsmith', 'jsmith2', 'jsmith3', 'jsmith4', 'alice1', 'alice2', 'alice3', 'alice4'])
    cmp_lists(inv.list_hosts("bsmith"), ['bsmith'])
    cmp_lists(inv.list_hosts("bsm*"), ['bsmith'])

# Generated at 2022-06-11 00:21:09.429616
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    o = InventoryManager()
    o.parse_source({
        'localhost': {
            'hosts': ['127.0.0.1']
        },
        'glob': {
            'hosts': ['127.0.0.1']
        }
    })
    assert o._inventory.groups['glob'].vars['ansible_host'] == '127.0.0.1'

# Generated at 2022-06-11 00:21:10.104789
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    pass

# Generated at 2022-06-11 00:21:21.857928
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory_manager = InventoryManager(None)
    hosts = inventory_manager.get_hosts('all')
    assert(hosts != None)
    print("Get hosts - all", hosts)

    hosts = inventory_manager.get_hosts('ungrouped')
    assert(hosts != None)
    print("Get hosts - ungrouped", hosts)

    hosts = inventory_manager.get_hosts('test_host')
    assert(hosts != None)
    print("Get hosts - test_host", hosts)

    hosts = inventory_manager.get_hosts(['test_host', 'all'])
    assert(hosts != None)
    print("Get hosts - [test_host, all]", hosts)
    
    hosts = inventory_manager.get_hosts(['test_host', '!test_host'])


# Generated at 2022-06-11 00:21:49.929068
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    pattern = 'example.com'
    list_targets = [pattern]
    dict_targets = dict(hosts=pattern)
    set_targets = set(pattern)
    json_targets = json.dumps(dict_targets)
    list_of_dicts_targets = [dict_targets]
    #list_of_list_targets = [list_targets]
    #list_of_set_targets = [set_targets]
    #list_of_json_targets = [json_targets]
    list_of_different_types_targets = [pattern, dict_targets, set_targets, json_targets, list_of_dicts_targets]
    malformed_json_t

# Generated at 2022-06-11 00:22:01.787853
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory = InventoryManager(host_list=[])
    inventory.hosts = {
        'host01': MockHost('host01'),
        'host02': MockHost('host02'),
        'host03': MockHost('host03')
    }
    inventory._inventory.hosts = inventory.hosts
    inventory.hosts['host01'].groups = ['group1', 'group2']
    inventory.hosts['host02'].groups = ['group2']
    inventory.hosts['host03'].groups = ['group1']
    inventory.groups = {
        'group1': MockGroup('group1'),
        'group2': MockGroup('group2')
    }
    inventory.groups['group1'].child_groups = []

# Generated at 2022-06-11 00:22:08.252802
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    c = InventoryManager()
    td = tempfile.mkdtemp()
    try:
        path = os.path.join(td, 'test')
        with open(path, 'w') as f:
            f.write('a\nb\nc\n')
        c.subset('@%s' % path)
    finally:
        shutil.rmtree(td)
    eq_(path, c._subset[0])

# Generated at 2022-06-11 00:22:20.008106
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    test_inventory = Inventory(loader=DictDataLoader({"host_list": [{"hostname": "localhost"}]}))
    test_inventory.parse_inventory(host_list=["localhost"])
    test_inventory_manager = InventoryManager(test_inventory)

    assert test_inventory_manager.get_hosts() == [test_inventory.get_host("localhost")]
    assert test_inventory_manager.get_hosts(pattern="all") == [test_inventory.get_host("localhost")]
    assert test_inventory_manager.get_hosts(pattern="all") == test_inventory_manager.get_hosts(pattern="localhost")
    assert test_inventory_manager.get_hosts(pattern="localhost") == test_inventory_manager.get_hosts(pattern="localhost")
    assert test_inventory_manager.get_

# Generated at 2022-06-11 00:22:29.974024
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    import shutil
    from ansible.utils.path import unfrackpath
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch


# Generated at 2022-06-11 00:22:39.927858
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    hostvars = {}
    hostvars['ak.example.com'] = {}
    hostvars['ak.example.com']['ansible_ssh_host'] = 'ak.example.com'
    hostvars['ak.example.com']['ansible_ssh_port'] = 22
    hostvars['ak.example.com']['ansible_ssh_user'] = 'sammy'
    hostvars['ak.example.com']['ansible_ssh_pass'] = 'password123'
    hostvars['ak.example.com']['ansible_become_pass'] = 'password123'
    hostvars['ak.example.com']['ansible_python_interpreter'] = '/usr/bin/python2.7'

# Generated at 2022-06-11 00:22:43.244169
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    
    # Create the object under test.
    inventory_manager = InventoryManager()

    # FIXME: Implement this test

    # Return the results
    return True

# Generated at 2022-06-11 00:22:52.823883
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    loader = DataLoader()
    inv = Inventory(loader=loader, variable_manager=VariableManager(loader=loader), host_list='ansible_hosts')

    im = InventoryModule(loader=loader, inventory=inv, variable_manager=VariableManager(), include_path=[])
    assert not im.subset('host1')
    assert im.subset(None) is None
    assert not im.subset([])


# Generated at 2022-06-11 00:23:02.632508
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    invm = host.InventoryManager()
    assert_equal(('', ''), invm._parse_source('/etc/ansible/hosts'))
    assert_equal(('static', ''), invm._parse_source('static'))
    assert_equal(('static', ''), invm._parse_source('static,'))
    assert_equal(('static', 'ec2.yml'), invm._parse_source('static,ec2.yml'))
    assert_equal(('static', 'ec2.yml'), invm._parse_source('static,ec2.yml,'))
    assert_equal(('yaml', '/etc/ansible/hosts'), invm._parse_source('yaml,/etc/ansible/hosts'))

# Generated at 2022-06-11 00:23:07.072841
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory = InventoryManager(loader=None, sources=[])
    im = InventoryModule(inventory)
    im.parse_inventory()
    assert im.get_hosts() == [u'192.168.56.101', u'192.168.56.102', u'192.168.56.103']


# Generated at 2022-06-11 00:23:38.424522
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    results_file = 'test/integration/results/ansible_inventory_manager_subset.json'
    results_file_path = os.path.join(ansible_path, results_file)
    options = {'verbosity': 4}
    def side_effect_get_host(host_name):
        return mocked_host(host_name)
    ansible_play_fakes.inventory.get_host.side_effect = side_effect_get_host
    with open(results_file_path) as data_file:
        data = json.load(data_file)
        source = data['source']
        expected = data['expected']
        result = ansible_play_fakes.inventory.subset(source)
        assert result == expected


# Generated at 2022-06-11 00:23:40.655596
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory = InventoryManager(["localhost"], None, None, None)
    inventory.subset("all")
    assert inventory._subset == ["all"]

# Generated at 2022-06-11 00:23:49.997702
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    # Please format your test cases as a list of command line argument
    # locations and expected return values. For example:
    # PlaybookCLI(['-n', '-v'])
    # [
    #     (['-n', '-v'], '1'),
    #     (['-n', '-v', 'bar'], '2'),
    # ]

    #testcases = [
    #    (['-n', '-v', 'bar'], '2'),
    #]

    # for args, expected_value in testcases:
    #     cli = PlaybookCLI(args)
    #     value = cli.run()
    #     assert value == expected_value, "%s != %s" % (value, expected_value)
    pass



# Generated at 2022-06-11 00:23:54.255639
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    im = InventoryManager("/tmp/ansible_inventory")
    im.subset("foo")
    assert im._subset == "foo"
    im.subset("bar")
    assert im._subset == "bar"
    im.subset(None)
    assert im._subset is None


# Generated at 2022-06-11 00:23:59.452644
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory = Inventory("tests/inventory/")
    inventory.subset("foobar")
    assert len(inventory.hosts_list) == 3
    assert inventory.groups["ungrouped"] == inventory.hosts_list[0:2]
    assert inventory.groups["group1"] == inventory.hosts_list[2:3]

# Generated at 2022-06-11 00:24:02.977620
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    """
    # InventoryManager.subset
    """
    d = {}
    d["one"] = "two"
    d["three"] = "four"
    d["five"] = "six"
    assert d == {}


# Generated at 2022-06-11 00:24:03.629341
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    pass

# Generated at 2022-06-11 00:24:13.173248
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    fake_loader = DictDataLoader({})
    fake_inventory = InventoryManager(loader=fake_loader, sources=[])

    # Return all hosts
    inventory_manager = InventoryManager(loader=fake_loader, sources=[])
    inventory_manager._inventory = fake_inventory
    assert inventory_manager.get_hosts("all") == []

    fake_inventory = InventoryManager(loader=fake_loader, sources=[])

    # Return all hosts, with subset
    inventory_manager = InventoryManager(loader=fake_loader, sources=[])
    inventory_manager._inventory = fake_inventory
    inventory_manager.subset(["foo"])
    assert inventory_manager.get_hosts("all") == []

    fake_inventory = InventoryManager(loader=fake_loader, sources=[])

    # Return all hosts, with subset and restriction
    inventory_manager

# Generated at 2022-06-11 00:24:18.093561
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    myManager = InventoryManager()
    myManager.parse_source("cub")
    assert myManager.hosts == False
    assert myManager._hosts_patterns_cache == {}
    assert myManager._pattern_cache == {}
    assert myManager._subset == None


# Generated at 2022-06-11 00:24:24.131003
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inv_obj = InventoryManager()
    inv_file = "inventory"
    inv_obj._inventory = Inventory(loader=DataLoader(), variable_manager=VariableManager())
    inv_obj._inventory.parse_inventory(inv_file)
    inv_obj.subset("all")
    eq_(inv_obj._subset, ["all"])

# Generated at 2022-06-11 00:24:39.520980
# Unit test for function split_host_pattern
def test_split_host_pattern():
    assert split_host_pattern(u'foo[1],bar[2]:baz') == [u'foo[1]', u'bar[2]:baz']
    assert split_host_pattern([u'foo[1],bar[2]:baz']) == [u'foo[1]', u'bar[2]:baz']

    # It should accept non-ascii characters
    assert split_host_pattern('café') == ['café']
    assert split_host_pattern(['café']) == ['café']

    # It should accept non-comma-separated patterns
    assert split_host_pattern('foo[1]') == ['foo[1]']
    assert split_host_pattern(['foo[1]']) == ['foo[1]']

    # It should accept IPv6 addresses


# Generated at 2022-06-11 00:24:43.940608
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    inventory = InventoryManager(loader=DataLoader())
    inventory.set_inventory(InventoryModule(loader=None, resource_list=['test_host']))
    inventory.parse_inventory()

    hosts = inventory.list_hosts()
    print(hosts)


# Generated at 2022-06-11 00:24:54.922839
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    # _subset
    # _restriction
    # _hosts_patterns_cache

    mock_inventory = Mock()
    mock_inventory.hosts = {"host1", "host2", "host3", "host4", "host5"}
    mock_inventory.groups = {"group1", "group2", "group3"}

    mock_inventory.get_host.return_value = "host"

    for option in ['inventory', 'sorted', 'reverse_sorted', 'reverse_inventory', 'shuffle']:
        inventory_manager = InventoryManager(mock_inventory)
        inventory_manager.subset("all")
        inventory_manager.restrict_to_hosts("all")
        hosts = inventory_manager.get_hosts("all", order=option)
        # because the results are not sorted, we can't check the

# Generated at 2022-06-11 00:24:58.070124
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inven = InventoryManager('all')
    inven.subset('all')
    assert inven._subset == ['all']


# Generated at 2022-06-11 00:25:04.737380
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
  _loader = DataLoader()
  _conf_vars = {'foo': 'bar'}
  _inventory = Inventory(_loader, variable_manager=VariableManager(_loader, _conf_vars))
  _host_list = [Host(name=u'foo')]

  inventory_manager = InventoryManager(_loader, _inventory, variable_manager=VariableManager(_loader, _conf_vars))
  result = inventory_manager.parse_source(u'foo', 'bar', _host_list)


# Generated at 2022-06-11 00:25:06.022912
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    # Check list_hosts()
    pass

# Generated at 2022-06-11 00:25:12.705549
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    # TODO: config data, hosts, src
    im = InventoryManager(loader, variable_manager)
    assert im is not None

    with pytest.raises(AnsibleParserError) as exinfo:
        im.parse_source(None)
    assert "Expected a string or list of strings" in str(exinfo.value)

    with pytest.raises(AnsibleParserError) as exinfo:
        im.parse_source([])
    assert "Expected a string or list of strings" in str(exinfo.value)

    with pytest.raises(AnsibleParserError) as exinfo:
        im.parse_source(1)
    assert "Expected a string or list of strings" in str(exinfo.value)


# Generated at 2022-06-11 00:25:25.577887
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    im = InventoryManager()
    im.parse_source("localhost,")
    assert im._hosts_patterns_cache == {}

    im.parse_source("")
    assert im._hosts_patterns_cache == {}

    im.parse_source("localhost")
    assert im._hosts_patterns_cache == {tuple(['localhost']): [localhost]}

    im.parse_source("localhost,localhost")
    assert im._hosts_patterns_cache == {tuple(['localhost']): [localhost]}

    im.parse_source("foo.bar,localhost")
    assert im._hosts_patterns_cache == {tuple(['foo.bar']): ['foo.bar'], tuple(['localhost']): [localhost]}

    im.parse_source("foo.bar,localhost,")
    assert im._hosts_

# Generated at 2022-06-11 00:25:32.085280
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    import sys
    import unittest
    import warnings
    import ansible
    from units.mock.loader import DictDataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    class TestInventoryManagerSubset(unittest.TestCase):

        def test_subset(self):
            dl = DictDataLoader({
                '/etc/ansible/hosts': '''
                    [foos]
                    foo1
                    foo2

                    [bars]
                    bar[1:3]

                    [bazs]
                    baz[1:2]
                    ''',
            })
            im = InventoryManager(loader=dl, sources=['/etc/ansible/hosts'])

# Generated at 2022-06-11 00:25:32.736432
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    pass

# Generated at 2022-06-11 00:25:53.382088
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory = InventoryManager()
    inventory.add_host(Host('test-ip', inventory=inventory))
    # Test 1: Test with pattern 'all' and ignore_limits False and ignore_restrictions False, 'all' is default pattern and default ignore_limits and ignore_restrictions
    assert len(inventory.get_hosts()) == 1
    assert isinstance(inventory.get_hosts(), list)
    assert inventory.get_hosts(pattern='test*') == inventory.get_hosts(pattern='test*', ignore_limits=False, ignore_restrictions=False)
    # Test 2: Test with pattern 'test*', ignore_limits=False and ignore_restrictions=False

# Generated at 2022-06-11 00:25:56.568056
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    im = InventoryManager(loader=None, sources='localhost')
    im.subset('all')
    assert im._subset == None



# Generated at 2022-06-11 00:26:07.479831
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    self = InventoryManager()
    subset_pattern = None
    self.subset(subset_pattern)
    subset_pattern = 'all'
    self.subset(subset_pattern)
    subset_pattern = 'webservers:dbservers'
    self.subset(subset_pattern)
    subset_pattern = '@/tmp/hosts'
    self.subset(subset_pattern)
    subset_pattern = '@../test/test_inventory_manager/test_inventory.py'
    self.subset(subset_pattern)
    subset_pattern = ''
    self.subset(subset_pattern)
    subset_pattern = '@../test/test_inventory_manager/test_inventory.py'
    self.subset(subset_pattern)


# Generated at 2022-06-11 00:26:09.071869
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    pass # TODO


# Generated at 2022-06-11 00:26:10.176912
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    pass


# Generated at 2022-06-11 00:26:19.109632
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    c = C()
    c.update({
        'inventory': 'inventory/hosts'
    })
    h = Hosts()
    h.parse_hosts(c, 'inventory/hosts')
    im = InventoryManager(h, c)

    # Check if all hosts are returned
    assert set(['host1', 'host2', 'host3']) == set(im.get_hosts())

    # Check if one host is returned
    assert set(['host1']) == set(im.get_hosts(pattern="host1"))

    # Check if one host is returned using regex pattern
    assert set(['host1']) == set(im.get_hosts(pattern="hos[0-9]"))

    # Check if two hosts are returned using regex pattern
    assert set(['host1', 'host2'])

# Generated at 2022-06-11 00:26:26.700743
# Unit test for method parse_source of class InventoryManager

# Generated at 2022-06-11 00:26:28.956421
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    # There are no tests like this for InventoryManager.parse_source because this is utility function.
    assert True == True

# Generated at 2022-06-11 00:26:39.717617
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    from collections import namedtuple
    FakeHost = namedtuple('FakeHost', 'name')
    FakeGroup = namedtuple('FakeGroup', 'name')

    # Test:
    #     InventoryManager._subset = None
    #     InventoryManager._pattern_cache = {}
    #     InventoryManager._evaluate_patterns()
    #     InventoryManager.list_hosts()
    #     InventoryManager.list_groups()
    #     InventoryManager.get_hosts()
    #     InventoryManager.get_hosts(pattern="all")
    #     InventoryManager.get_hosts(pattern="master")
    #     InventoryManager.get_hosts(pattern="~^master")
    #     InventoryManager.get_hosts(pattern="~^{}$".format("master"))
    #     InventoryManager.get_hosts(pattern="

# Generated at 2022-06-11 00:26:50.116464
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    fake_system_info_func = lambda x, y, z: dict(
        redhat=dict(distribution_major_version='6'),
        centos=dict(distribution_major_version='6'),
        ubuntu=dict(distribution_major_version='14'),
        fedora=dict(distribution_major_version='18'),
        suse=dict(distribution_major_version='11'),
        debian=dict(distribution_major_version='8'),
    ).get(x.lower(), dict()).get(y.lower(), None)

# Generated at 2022-06-11 00:27:14.043363
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    #
    # file: ../../.././test/units/inventory/test_manager.yml
    #
    # These tests cover legacy subsetting of the inventory using a string,
    # and new subsetting using a list of patterns, like --limit.
    # When subsetting with a list, you can use any pattern which matches
    # hosts in the inventory.
    #
    # Our inventory contains the host group "all", and other host groups
    # like "foos" and "bars" which contain hosts.  We'll use "all" before
    # each test to initialize the inventory subset to all hosts, then
    # restrict it, then print the resulting subset.
    #
    im = InventoryManager()
    im.set_inventory('../../.././test/units/inventory/test_manager.yml')
    #
    # subsection

# Generated at 2022-06-11 00:27:22.386753
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    im = InventoryManager(loader=None, sources='')
    assert im.list_hosts(pattern="all") == []
    assert im.list_hosts(pattern="localhost") == ['localhost']
    assert im.list_hosts(pattern="localhost,") == ['localhost']
    assert im.list_hosts(pattern=",") == []
    assert im.list_hosts(pattern="foo") == []
    assert im.list_hosts(pattern="foo,bar") == []
    assert im.list_hosts(pattern="foo*") == []
    assert im.list_hosts(pattern="*") == []
    assert im.list_hosts(pattern="~[abc]*") == []
    assert im.list_hosts(pattern="~[a*") == []

# Generated at 2022-06-11 00:27:27.299691
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
       subset_pattern = '2'
       inventory_manager = InventoryManager('/usr/local/lib/python2.7/dist-packages/ansible-1.9.4-py2.7.egg/ansible/inventory')
       inventory_manager.subset(subset_pattern)

# Generated at 2022-06-11 00:27:38.238606
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory = InventoryManager(loader=None, sources='127.0.0.1,')
    im = InventoryModule(inventory=inventory)
    im.parse_hosts("127.0.0.1")
    hosts = im.get_hosts()
    assert hosts
    assert_equal(im.get_hosts("127.0.0.1"), hosts)
    assert_equal(im.get_hosts("!127.0.0.1"), [])
    assert_equal(im.get_hosts("!127.0.0.1", ignore_restrictions=True), hosts)
    assert_equal(im.get_hosts("all"), hosts)
    assert_equal(im.get_hosts("all", ignore_restrictions=True), hosts)