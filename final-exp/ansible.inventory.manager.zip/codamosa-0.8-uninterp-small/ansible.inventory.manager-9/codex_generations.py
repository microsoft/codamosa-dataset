

# Generated at 2022-06-24 19:49:38.979838
# Unit test for function split_host_pattern
def test_split_host_pattern():
    pattern = "test,test2"
    patterns = split_host_pattern(pattern)
    assert patterns == ['test', 'test2']
    pattern = "test:test2"
    patterns = split_host_pattern(pattern)
    assert patterns == ['test', 'test2']
    pattern = "test,test2,test3"
    patterns = split_host_pattern(pattern)
    assert patterns == ['test', 'test2', 'test3']
    pattern = "test:test2:test3"
    patterns = split_host_pattern(pattern)
    assert patterns == ['test', 'test2', 'test3']


# Generated at 2022-06-24 19:49:45.871580
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    # test_with_good_file_name
    str_1 = "inventory"
    inventory_manager_0 = InventoryManager(str_1)
    str_2 = "inventory"
    boolean_1 = inventory_manager_0.parse_source(str_2)
    assert boolean_1 == True
    # test_with_bad_file_name
    str_3 = "bad_inventory"
    inventory_manager_0 = InventoryManager(str_3)
    str_4 = "bad_inventory"
    boolean_2 = inventory_manager_0.parse_source(str_4)
    assert boolean_2 == False
    # test_with_empty_file_name
    str_5 = "inventory"
    inventory_manager_0 = InventoryManager(str_5)
    str_6 = ""
    boolean_3 = inventory

# Generated at 2022-06-24 19:49:55.264366
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    # This test tests that the get_host method fails when the regex it is
    # passed is invalid.
    str_0 = "K\u0007P{+\u0006\r\rU\u0012\u0014]5\u0016\u0000\u0013aiv\u0013x\u0001\\\u0010"
    inventory_manager_0 = InventoryManager(str_0)
    bool_0 = False
    str_1 = "~"
    inventory_manager_0.clear_pattern_cache()
    try:
        inventory_manager_0.get_hosts(str_1)
    except:
        bool_0 = True
    assert bool_0


# Generated at 2022-06-24 19:50:04.421656
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():

    inventory_manager_1 = InventoryManager("Bt|3'#f!Gt{=Pt")
    str_1 = "4M-L(n1%pfh_|x,SgS\n&eHX.jgg[-NTg"
    list_pattern_1 = split_host_pattern(str_1)
    list_1 = inventory_manager_1.get_hosts(list_pattern_1)

    str_2 = "V7,u]^9$z7K"
    inventory_manager_2 = InventoryManager(str_2)
    str_3 = "u,vA8z7Vg1"
    list_pattern_2 = split_host_pattern(str_3)
    list_2 = inventory_manager_2.get_hosts(list_pattern_2)



# Generated at 2022-06-24 19:50:10.989079
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    source = "+/+///"
    inventory_manager = InventoryManager(source)
    result = inventory_manager.parse_source(source)
    assert isinstance(result, tuple)
    assert len(result) == 3
    assert result[0] == "file"
    assert result[1].endswith(os.path.join("+", "+", "", "", ""))
    assert result[2] == "auto"


# Generated at 2022-06-24 19:50:12.891275
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    try:
        test_case_0()
    except Exception as exception_0:
        with pytest.raises(AnsibleOptionsError):
            raise exception_0


# Generated at 2022-06-24 19:50:17.959135
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    str_0 = "3\x17!\x0e\x02\x1a\x1c\x1d\x18\x03\x17\x0f\x0e\x11+"
    str_1 = "3\x17!\x0e\x02\x1a\x1c\x1d\x18\x03\x17\x0f\x0e\x11+"
    inventory_manager_0 = InventoryManager(str_0)
    try:
        result = inventory_manager_0.list_hosts(str_1)
        assert result != None
    except:
        assert False


# Generated at 2022-06-24 19:50:19.049036
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager_0 = InventoryManager()
    inventory_manager_0.subset(None)


# Generated at 2022-06-24 19:50:25.059393
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    pattern_0 = '*z'
    inventory_manager_0 = InventoryManager('localhost,')
    inventory_manager_0.subset(pattern_0)
    assert_equal(type(inventory_manager_0), InventoryManager, 'assert_equal failed((ret) type(inventory_manager_0) == InventoryManager)')


# Generated at 2022-06-24 19:50:34.115091
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():
    str_0 = ""
    inventory_manager_0 = InventoryManager(str_0)

    # test empty source list
    source_list_0 = []
    result_dict_0 = inventory_manager_0.parse_sources(source_list_0)

    # test_empty_src
    str_1 = ""
    inventory_manager_1 = InventoryManager(str_1)
    source_list_1 = []
    result_dict_1 = inventory_manager_1.parse_sources(source_list_1)
    assert result_dict_1 == {}

    # test_single_alias
    str_2 = ""
    inventory_manager_2 = InventoryManager(str_2)
    source_list_2 = [{'origin': '@all', 'names': [u'web']}]
    result_dict_

# Generated at 2022-06-24 19:51:00.681293
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    # TODO: validate unit test
    str_0 = "?),'47\tJkh|j_$!L_("
    inventory_manager_0 = InventoryManager(str_0)
    pattern_0 = "all"
    ignore_restrictions_0 = False
    ignore_limits_0 = False
    order_0 = "inventory"
    hosts_0 = inventory_manager_0.get_hosts(pattern_0, ignore_limits_0, ignore_restrictions_0, order_0)

    # TODO: validate output
    #print(hosts_0)
    for host in hosts_0:
        print(host)


# Generated at 2022-06-24 19:51:05.707965
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    # type: () -> None
    """
    Test for method parse_source
    """
    str_0 = "none"
    str_1 = "inventory_manager_" + str_0
    inventory_manager_1 = InventoryManager(str_1)
    try:
        inventory_manager_1.parse_source(str_0)
        assert False
    except AnsibleError:
        pass

    # assert False  # TODO: Fix the testcase



# Generated at 2022-06-24 19:51:07.703787
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    str_0 = ">%c"
    inventory_manager_0 = InventoryManager(str_0)
    str_0 = "01+w"
    assert_equal(inventory_manager_0.get_hosts(str_0), inventory_manager_0)


# Generated at 2022-06-24 19:51:18.612897
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory_manager_0 = InventoryManager()
    inventory_manager_0.clear_pattern_cache()
    str_0 = "10.0.0.1"
    pattern_0 = "all"
    bool_0 = False
    bool_1 = False
    order_0 = "sorted"
    assert inventory_manager_0.get_hosts(pattern_0, bool_0, bool_1, order_0) == list()
    pattern_0 = "all"
    order_0 = "sorted"
    assert inventory_manager_0.get_hosts(pattern_0, bool_0, bool_1, order_0) == list()


# Generated at 2022-06-24 19:51:27.708736
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    # Test with valid arguments
    str_0 = ")"
    inventory_manager_0 = InventoryManager(str_0)
    str_0 = "&"
    result_0 = inventory_manager_0.list_hosts(str_0)
    assert result_0 == []
    # Test with valid arguments
    str_1 = "~"
    inventory_manager_0 = InventoryManager(str_1)
    str_1 = "~"
    result_1 = inventory_manager_0.list_hosts(str_1)
    assert result_1 == []
    # Test with valid arguments
    str_2 = ")"
    inventory_manager_0 = InventoryManager(str_2)
    str_2 = ")"
    result_2 = inventory_manager_0.list_hosts(str_2)
    assert result

# Generated at 2022-06-24 19:51:31.185477
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # assert inventory_manager_0.subset(True) == None
    assert True # TODO: implement your test here


# Generated at 2022-06-24 19:51:35.748879
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    str_0 = "=1W8\t&'wP\td(e~p%sR"
    str_1 = "=1W8\t&'wP\td(e~p%sR"
    inventory_manager_0 = InventoryManager(str_0)
    str_2 = "=1W8\t&'wP\td(e~p%sR"
    str_3 = "=1W8\t&'wP\td(e~p%sR"
    str_4 = "=1W8\t&'wP\td(e~p%sR"
    results_0 = inventory_manager_0.subset(str_1)
    assert results_0 == None


# Generated at 2022-06-24 19:51:39.174241
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager_0 = InventoryManager()
    try:
        inventory_manager_0.subset(1)
        assert False, 'Expected exception: AnsibleOptionsError'
    except AnsibleOptionsError as e:
        assert True


# Generated at 2022-06-24 19:51:50.214063
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    str_0 = "~\x12\x7f\x0f\x7f\x1e\x7f\x1f\x7f"
    str_1 = "N\x01\x7f\x14\x7f\x1c\x7f\x0c\x7f"
    str_2 = ":+6(z=6\x7f\x1f\x7f\x0f\x7f\x11\x7f"
    str_3 = "v\x03\x7f\x0c\x7f\x1e\x7f\t\x7f"
    str_4 = "w\x1d\x7f\x0c\x7f\x1c\x7f\x03\x7f"


# Generated at 2022-06-24 19:52:01.172891
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    str_0 = "&'#"
    inventory_manager_0 = InventoryManager(str_0)
    str_0 = "http://www.example.org/index.html"
    str_1 = "?"
    str_2 = "ZmyRkZ_"
    str_3 = "~"
    int_0 = 0
    int_1 = 0
    int_2 = 0
    int_3 = -2
    bool_0 = False
    bool_1 = False
    bool_2 = False
    inventory_manager_0.clear_pattern_cache(int_0, int_1, bool_0, bool_1, bool_2)
    inventory_manager_0.get_hosts(str_2, str_3, str_0, str_1)
    inventory_manager_0.get_host

# Generated at 2022-06-24 19:52:30.922442
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inv_mgr = InventoryManager()
    inv_path = "/etc/ansible/hosts"
    inv_mgr.parse_source("localhost", inv_path, None)


# Generated at 2022-06-24 19:52:31.820633
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    test_case_0()

# Generated at 2022-06-24 19:52:39.694623
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inv_file_name = "/etc/ansible/hosts"
    with open(inv_file_name, "w") as f:
        f.write("""
[test_group_1]
test_host1
test_host2

[test_group_2:children]
test_group_1
""")

    im_0 = InventoryManager(None, [inv_file_name])
    im_0.parse_sources()
    # --- Testing result at line 44 ---
    assert len(im_0._inventory.groups) == 2
    # --- Testing result at line 45 ---
    assert "test_group_1" in im_0._inventory.groups
    # --- Testing result at line 46 ---
    assert len(im_0._inventory.groups["test_group_1"].get_hosts()) == 2
   

# Generated at 2022-06-24 19:52:47.894175
# Unit test for function split_host_pattern

# Generated at 2022-06-24 19:52:50.316777
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    inventory_manager_inst = InventoryManager(None) # FIXME: mock Inventory and Host objects
    # FIXME: mock list_hosts to test it
    var_0 = inventory_manager_inst.list_hosts()


# Generated at 2022-06-24 19:52:51.876955
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager = InventoryManager(None)
    subset_pattern = ""
    inventory_manager.subset(subset_pattern)


# Generated at 2022-06-24 19:52:55.950549
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    host_name_0 = 'host_name_0'
    pattern_0 = 'pattern_0'
    pattern_1 = 'pattern_1'
    pattern_2 = 'pattern_2'
    pattern_3 = 'pattern_3'
    inventory = InventoryManager()
    var_0 = inventory.get_hosts(host_name_0)
    var_1 = inventory.get_hosts(pattern_0)
    var_2 = inventory.get_hosts([pattern_1, pattern_2, pattern_3])


# Generated at 2022-06-24 19:52:57.627939
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():

    # Create an instance of InventoryManager
    tuple_1 = ()
    obj_2 = InventoryManager(tuple_1)

    pattern = "all"

    # Execute method
    obj_2.list_hosts(pattern)



# Generated at 2022-06-24 19:53:00.953394
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inv_man = InventoryManager()
    subset_pattern = ""
    inv_man.subset(subset_pattern)


# Generated at 2022-06-24 19:53:04.828179
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    var_0 = InventoryManager()
    tuple_0 = ('all',)
    var_1 = var_0.list_hosts(tuple_0)

    assert var_1 == ['all'], "InventoryManager.list_hosts() did not return the expected value"

# Generated at 2022-06-24 19:53:37.700077
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # expected_result should be a list of hostnames
    # (or groups) where you want to restrict the results
    # of operations on the inventory to.
    expected_result = None
    i = InventoryManager("foo")
    i.subset(expected_result)
    # If we get here, no exception was raised and
    # that means the method returned None, which is
    # an incorrect result.
    raise Exception(u"Incorrect return value %s" % repr(i._subset))


# Generated at 2022-06-24 19:53:40.371262
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    inventory = Inventory(loader=None)
    inventory.parse_inventory(["[some_group]", "host0", "host1"])

    im = InventoryManager(inventory)

    host_0 = im.list_hosts("some_group")
    assert len(host_0) == 2
    host_0 = im.list_hosts()
    assert len(host_0) == 1


# Generated at 2022-06-24 19:53:46.328045
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():

    # Test case data
    tuple_0 = ()
    pattern = tuple_0
    var_0 = split_host_pattern(tuple_0)


# Generated at 2022-06-24 19:53:48.074153
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    # test_cases
    tuple_0 = ()
    var_0 = InventoryManager(tuple_0).parse_source(tuple_0)

# Generated at 2022-06-24 19:53:50.829569
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    src = """
    pattern = "all"
    subset_pattern = None
    """
    # Initialize InventoryManager instance
    im = InventoryManager(src)

    # Invoke method
    subset_pattern = None
    im.subset(subset_pattern)



# Generated at 2022-06-24 19:53:55.640472
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    tuple_2 = ()
    tuple_0 = ()
    obj_1 = InventoryManager(tuple_0, tuple_2)
    tuple_1 = ()
    obj_1.list_hosts(tuple_1)



# Generated at 2022-06-24 19:53:58.184275
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    print("Testing InventoryManager.subset()")
    inventory = Inventory()
    manager = InventoryManager(inventory, loader)
    manager.subset(None)
    assert manager._subset == None


# Generated at 2022-06-24 19:54:01.106811
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager_1 = InventoryManager()
    subset_pattern = "test"
    print("Unit test case 0 of InventoryManager::subset")
    try:
        inventory_manager_1.subset(subset_pattern)
    except Exception as e:
        var_1 = e


# Generated at 2022-06-24 19:54:11.793057
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    # unit tests for get_hosts
    # Get hosts matching a pattern or list of patterns

    # Tests for get_hosts
    # Get hosts matching a pattern or list of patterns
    # Validate the results
    assert_equal(InventoryManager.get_hosts(self, pattern="all", ignore_limits=False, ignore_restrictions=False, order=None))
    # Validate the results
    assert_equal(InventoryManager.get_hosts(self, pattern="all", ignore_limits=False, ignore_restrictions=False, order=None))
    # Validate the results
    assert_equal(InventoryManager.get_hosts(self, pattern="all", ignore_limits=False, ignore_restrictions=False, order=None))
    # Validate the results

# Generated at 2022-06-24 19:54:13.170811
# Unit test for function split_host_pattern
def test_split_host_pattern():
    print('Testing: split_host_pattern')
    test_case_0()


# Generated at 2022-06-24 19:54:26.328419
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory = InventoryManager(loader=DataLoader())
    inventory.clear_pattern_cache()
    pattern = "all"
    try:
        var_0 = inventory.get_hosts(pattern)
    except AnsibleError as e:
        raise AssertionError(e)


# Generated at 2022-06-24 19:54:30.170303
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    tuple_0 = ()
    var_0 = InventoryManager(tuple_0)
    tuple_1 = ()
    var_1 = var_0.list_hosts(tuple_1)


# Generated at 2022-06-24 19:54:32.866249
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    var_0 = InventoryManager()
    var_1 = None
    subset_pattern = var_1
    var_0.subset(subset_pattern)


# Generated at 2022-06-24 19:54:35.786953
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    tuple_1 = ()
    var_1 = InventoryManager(tuple_1)
    subset_pattern = None
    var_1.subset(subset_pattern)


# Generated at 2022-06-24 19:54:37.697884
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():

    inventory_manager = InventoryManager()
    inventory_manager.subset(None)


# Generated at 2022-06-24 19:54:40.383542
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    print("Method list_hosts")
    var_1 = InventoryManager(C.DEFAULT_HOST_LIST, True)
    test_case_0()


# Generated at 2022-06-24 19:54:42.085943
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    tuple_0 = ()
    var_0 = split_host_pattern(tuple_0)


# Generated at 2022-06-24 19:54:52.308505
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    im = InventoryManager(None)
    im.add_group('group1')
    im.add_host('host1')
    h = im.get_host('host1')
    h.set_variable('var1', 'val1')
    h.set_variable('var2', 'val2')
    im.add_child('group1', 'host1')
    im.add_group('group2')
    im.add_host('host2')
    h = im.get_host('host2')
    h.set_variable('var1', 'val3')
    h.set_variable('var2', 'val4')
    im.add_child('group2', 'host2')

    # Testing basic groups with hosts in them
    hosts1 = im.get_hosts("group1")

# Generated at 2022-06-24 19:54:58.959593
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():

    host_pattern = ''
    tuple_0 = (host_pattern,)
    sources = ('/etc/ansible/hosts',)
    ansible_hosts_dir = '/etc/ansible'
    ansible_host_pattern_cache = {}
    host_list_path = {}
    group_list_path = {}
    group_pattern = ''
    group_vars = {}
    group_vars_files = {}
    host_vars = {}
    host_vars_files = {}
    all_group_var_files = ()
    var_0 = InventoryManager(sources, ansible_hosts_dir, ansible_host_pattern_cache, host_list_path, group_list_path, host_vars, host_vars_files)

# Generated at 2022-06-24 19:55:00.706128
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    var_0 = InventoryManager()
    var_1 = None
    var_0.subset(var_1)



# Generated at 2022-06-24 19:55:13.253273
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    assert False


# Generated at 2022-06-24 19:55:25.474564
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["hosts_testcase_inventory_manager_subset"])
    inventory._inventory = inventory
    inventory._loader = loader
    inventory._sources = ["hosts_testcase_inventory_manager_subset"]
    inventory._vars_cache = {}
    inventory._hosts_patterns_cache = {}
    inventory._groups_list = {}
    inventory._pattern_cache = {}
    inventory._restriction = None
   

# Generated at 2022-06-24 19:55:31.710067
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    # initialize inventory
    inv_mgr = InventoryManager(loader=DictDataLoader({}))

    # test with a valid pattern ( 'all' )
    pattern = 'all'
    test_get_hosts = inv_mgr.get_hosts(pattern)
    assert isinstance(test_get_hosts, list)
    assert len(test_get_hosts) > 0

    # test with an invalid pattern ( 'foobar' )
    pattern = 'foobar'
    test_get_hosts = inv_mgr.get_hosts(pattern)
    assert isinstance(test_get_hosts, list)
    assert len(test_get_hosts) == 0

# Generated at 2022-06-24 19:55:35.438100
# Unit test for function split_host_pattern
def test_split_host_pattern():
    print("testing function split_host_pattern with input", "'tuple_0'", "and expected output", "[]")
    test_case_0()
    assert split_host_pattern('tuple_0') == []
    print("PASSED TEST CASE: split_host_pattern")


# Generated at 2022-06-24 19:55:37.006948
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():
    inventory = InventoryManager(loader=None, sources='foo')
    assert inventory.sources == 'foo'


# Generated at 2022-06-24 19:55:42.793722
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager = InventoryManager()
    test_value = inventory_manager.subset('test')

if __name__ == "__main__":
    test_InventoryManager_subset()

# Generated at 2022-06-24 19:55:49.254720
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    tuple_0 = ()
    tuple_1 = ('foo[1:3] bar')
    tuple_2 = ('foo[1:3]')
    tuple_3 = ('foo[1:3]', 'bar')
    tuple_4 = ('foo[1:3]', 'bar', 'baz[1:3]')
    tuple_5 = ('foo[1:3]', 'bar', 'baz[1:3]', 'qux')
    tuple_6 = ('bar', 'baz[1:3]', 'qux', 'foo[1:3]')
    tuple_7 = ('bar[1:3]', 'foo[1:3]')
    tuple_8 = ('foo[1:3]', 'bar', 'baz[1:3]', 'qux', 'quux[1:3]')

# Generated at 2022-06-24 19:55:54.594866
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    # create an instance of InventoryManager
    im = InventoryManager('localhost,')
    hosts_list_0 = im.get_hosts()


import os
import sys

print("test_InventoryManager")
test_InventoryManager_get_hosts()



# Generated at 2022-06-24 19:55:58.432049
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    tuple_0 = ()
    var_0 = InventoryManager(tuple_0)
    pattern = None
    var_0.list_hosts(pattern)


# Generated at 2022-06-24 19:56:02.860858
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    ansible_play_inventory = AnsiblePlayInventory(loader=None)
    tuple_0 = ('~.*',)
    var_0 = ansible_play_inventory.get_hosts(tuple_0)
    assert var_0 == []
    val_0 = ansible_play_inventory.get_hosts()
    assert val_0 == []


# Generated at 2022-06-24 19:58:38.519746
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    tuple_0 = (u'h*',)
    test_InventoryManager_0 = InventoryManager(uuid.uuid4())
    expected_0 = []
    assert expected_0 == test_InventoryManager_0.get_hosts(tuple_0)

    tuple_1 = (u'h*')
    test_InventoryManager_1 = InventoryManager(uuid.uuid4())
    assert [] == test_InventoryManager_1.get_hosts(tuple_1)

    tuple_2 = (u'h*',)
    test_InventoryManager_2 = InventoryManager(uuid.uuid4())
    assert [] == test_InventoryManager_2.get_hosts(tuple_2)

    tuple_3 = (u'h*')
    test_InventoryManager_3 = InventoryManager

# Generated at 2022-06-24 19:58:40.620774
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    # Test variables
    var_0 = InventoryManager()
    var_1 = "test0"
    var_2 = True
    var_3 = True


# Generated at 2022-06-24 19:58:49.553266
# Unit test for function split_host_pattern
def test_split_host_pattern():
    assert split_host_pattern(()) == [], \
        'split_host_pattern(()) → [""], expected []'
    assert split_host_pattern((1,2,3)) == ['1','2','3'], \
        'split_host_pattern((1,2,3)) → ["1","2","3"], expected ["1","2","3"]'