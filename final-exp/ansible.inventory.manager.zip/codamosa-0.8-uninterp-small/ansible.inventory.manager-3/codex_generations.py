

# Generated at 2022-06-24 19:49:37.972228
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    print('Test case 0')
    test_case_0()

# Generated at 2022-06-24 19:49:46.968916
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    str_0 = '{4TI=r,2'
    var_0 = order_patterns(str_0)
    str_1 = '{4TI=r,2'
    var_1 = InventoryManager(str_1)
    str_2 = '{4TI=r,2'
    var_1.subset(str_2)
    str_3 = '{4TI=r,2'
    var_1.restrict_to_hosts(str_3)
    str_4 = '{4TI=r,2'
    var_1.restrict_to_hosts(str_4)
    str_5 = '{4TI=r,2'
    var_1.restrict_to_hosts(str_5)
    str_6 = '{4TI=r,2'

# Generated at 2022-06-24 19:49:53.275733
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    inv = InventoryManager(loader=None, sources=['/playbooks/test.txt'])
    assert isinstance(inv.list_hosts(), list)
    assert len(inv.list_hosts()) == 0
    assert isinstance(inv.list_hosts(), list)
    assert len(inv.list_hosts()) == 0


# Generated at 2022-06-24 19:49:55.532524
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    # Test import
    buffer = StringIO()
    inventory = InventoryManager(host_list=[], inventory=None)
    result_0 = inventory.list_hosts()
    # Test output
    buffer.close()


# Generated at 2022-06-24 19:49:57.292790
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    mgr = InventoryManager()
    mgr.get_hosts()


# Generated at 2022-06-24 19:49:59.883263
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory_manager_obj = InventoryManager(1)
    # Order will be affected by this test
    # Order is expected to be 'shuffle'
    order_value = inventory_manager_obj.get_hosts(pattern="all", ignore_limits=False, ignore_restrictions=False, order='shuffle')


# Generated at 2022-06-24 19:50:03.501043
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    var_0 = InventoryManager(x=1,y=2)

    str_0 = '@/'
    var_0.subset(str_0)


# Generated at 2022-06-24 19:50:05.424019
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    im = InventoryManager(None, '/path/to/file')
    assert im.get_hosts('all') == []


# Generated at 2022-06-24 19:50:06.498766
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    i = InventoryManager()
    i.subset(None)


# Generated at 2022-06-24 19:50:09.076642
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    from ansible.inventory.manager import InventoryManager
    source = '/tmp/ansible/inventory'
    source_options = ''
    i_m = InventoryManager()
    new_group = i_m.parse_source(source, source_options)
    print(new_group)



# Generated at 2022-06-24 19:57:38.580007
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    pattern = 'b,c,d*'
    test_inventory_manager = InventoryManager()
    #test_inventory_manager.subset(pattern)
    if test_inventory_manager.subset(pattern) is None:
        print("test_InventoryManager_remove_restriction success")
    else:
        print("test_InventoryManager_remove_restriction failure")


# Generated at 2022-06-24 19:57:46.012351
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():

    #test with subset_param is None
    inventory_manager_1 = InventoryManager()
    inventory_manager_1.subset(None)
    assert inventory_manager_1._subset is None

    #test with subset_param is not None
    inventory_manager_2 = InventoryManager()
    subset_patterns = ['localhost', 'other_pattern']
    inventory_manager_2.subset(subset_patterns)
    assert inventory_manager_2._subset == subset_patterns


# Generated at 2022-06-24 19:57:48.021528
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager_0 = InventoryManager()
    inventory_manager_0.subset('all')
    assert inventory_manager_0._subset == ['all']


# Generated at 2022-06-24 19:57:52.781043
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager_0 = InventoryManager()
    result = inventory_manager_0.subset('subset_pattern')
    assert isinstance(result, NoneType)


# Generated at 2022-06-24 19:57:55.843117
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager_0 = InventoryManager()
    subset_pattern_0 = None
    assert inventory_manager_0.subset(subset_pattern_0) == None


# Generated at 2022-06-24 19:58:05.608326
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    is_e = isinstance
    inventory_manager = InventoryManager()

    # Unknown source
    ####################################################################
    #
    # Result = [{}]
    #
    source = 'not_a_file.aaa'
    result = inventory_manager.parse_sources(source)
    assert len(result) == 1
    assert is_e(result[0], dict)

    # Existence of variable
    ####################################################################
    #
    #   Result = [{'n': 'localhost'}]
    #
    source = 'localhost'
    result = inventory_manager.parse_sources(source)
    assert is_e(result[0], dict)
    assert 'n' in result[0]
    assert result[0]['n'] == 'localhost'



# Generated at 2022-06-24 19:58:09.972935
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    # Prepare test data
    pattern = 'all'
    ignore_limits = False
    ignore_restrictions = False
    order = None
    inventory_manager_0 = InventoryManager()

    # Call test_case
    test_case_0(inventory_manager_0)

    # Remove test_file after test is finished
    # os.remove(test_file)


# Generated at 2022-06-24 19:58:13.413785
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():

    inventory_manager_1 = InventoryManager()
    hosts_1 = inventory_manager_1.get_hosts('all')
    inventory_manager_1.subset('test_host_1')
    hosts_2 = inventory_manager_1.get_hosts('all')
    assert len(hosts_1) == len(hosts_2)


# Generated at 2022-06-24 19:58:15.362200
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    test_case_0()

if __name__ == "__main__":
    test_InventoryManager_list_hosts()

# Generated at 2022-06-24 19:58:21.179006
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory_manager_get_hosts = InventoryManager()
    pattern = "all"
    ignore_limits = False
    ignore_restrictions = False
    order = None
    inventory_manager_get_hosts.get_hosts(pattern, ignore_limits, ignore_restrictions, order)
