

# Generated at 2022-06-24 19:49:58.914600
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    """
    Test_case_1: unit test for method subset of class InventoryManager
    """
    inventory_manager_0 = InventoryManager(0)
    subset_pattern_0 = "all"
    var_0 = inventory_manager_0.subset(subset_pattern_0)
    int_0 = 0
    var_1 =  inventory_manager_0.subset(int_0)
    str_0 = "host"
    var_2 = inventory_manager_0.subset(str_0)
    str_1 = "@/etc/file"
    var_3 = inventory_manager_0.subset(str_1)


# Generated at 2022-06-24 19:50:03.559846
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    int_0 = -841
    inventory_manager_0 = InventoryManager(int_0)
    int_0 = -69
    # Test for exception in InventoryManager.list_hosts
    try:
        var_0 = inventory_manager_0.list_hosts(int_0)
    except TypeError:
        pass
    pattern_0 = '-'
    # Test for exception in InventoryManager.list_hosts
    try:
        var_0 = inventory_manager_0.list_hosts(pattern_0)
    except TypeError:
        pass
    int_0 = -13
    inventory_manager_1 = InventoryManager(int_0)
    int_0 = -20
    # Test for exception in InventoryManager.list_hosts

# Generated at 2022-06-24 19:50:05.753101
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory_manager_1 = InventoryManager(1)
    var_1 = inventory_manager_1.get_hosts('all')
    assert var_1 == ['1']


# Generated at 2022-06-24 19:50:12.320165
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():

    inventory = InventoryManager(inventory=None,
                                 variable_manager=None,
                                 loader=None)
    results_0 = inventory.get_hosts()
    assert_equal(results_0, [])
    results_1 = inventory.get_hosts(pattern="all", order="inventory")
    assert_equal(results_1, [])
    results_2 = inventory.get_hosts(pattern="all", order="sorted")
    assert_equal(results_2, [])
    results_3 = inventory.get_hosts(pattern="all", order="reverse_sorted")
    assert_equal(results_3, [])
    results_4 = inventory.get_hosts(pattern="all", order="shuffle")
    assert_equal(results_4, [])
    results_5 = inventory.get_host

# Generated at 2022-06-24 19:50:22.823045
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    int_0 = -440
    inventory_manager_0 = InventoryManager(int_0)
    inventory_manager_0.clear_caches()
    str_0 = '#I_F[BQZ'
    boolean_0 = True
    boolean_1 = False
    str_1 = '6M5U6@'
    str_2 = '5EQ2UG'
    var_0 = inventory_manager_0.get_hosts(str_0, boolean_0, boolean_1, str_1, str_2)
    var_1 = inventory_manager_0.get_hosts(str_1, boolean_1, boolean_0, str_2, boolean_1)
    str_3 = '3!_9ZW'

# Generated at 2022-06-24 19:50:26.060995
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    pattern = 'all'
    inventory_manager_0 = InventoryManager()
    int_0 = 1
    inventory_manager_0.subset(pattern)


# Generated at 2022-06-24 19:50:28.507216
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    q_obj = InventoryManager(0)
    subset_pattern = 'host1'
    q_obj.subset(subset_pattern)


# Generated at 2022-06-24 19:50:31.324666
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    # Setup
    inventory_manager_0 = InventoryManager()

    # Test
    var_0 = inventory_manager_0.list_hosts()

    # Verification
    assert var_0


# Generated at 2022-06-24 19:50:35.752979
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # unit test for subset of class InventoryManager
    # this function tests whether the method subset of class InventoryManager correctly removes the subset limit
    int_0 = -440
    inventoryManager1 = InventoryManager(int_0)
    int_1 = -277
    inventoryManager1.subset(int_1)
    var_0 = inventoryManager1.subset(int_0)
    return var_0


# Generated at 2022-06-24 19:50:38.958119
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    int_0 = -440
    inventory_manager_0 = InventoryManager(int_0)
    subset_pattern_0 = 'ansible_ssh_host'
    inventory_manager_0.subset(subset_pattern_0)
    var_0 = inventory_manager_0.clear_pattern_cache()


# Generated at 2022-06-24 19:51:13.819951
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager_0 = InventoryManager()
    var_0 = inventory_manager_0.subset("[0]")
    assert isinstance(var_0, str)
    assert var_0 == "[0]"


# Generated at 2022-06-24 19:51:18.471477
# Unit test for function split_host_pattern
def test_split_host_pattern():
    # Case 1, str
    pattern = 'ansible01, ansible02[1:2], [::1], [::2]'
    result = split_host_pattern(pattern)
    if result == ['ansible01', 'ansible02[1:2]', '[::1]', '[::2]']:
        print("Case 1, str is passed.")
    else:
        print("Case 1, str is failed.")
    # Case 2, list
    pattern = ['ansible01', 'ansible02[1:2]', '[::1]', '[::2]']
    result = split_host_pattern(pattern)
    if result == ['ansible01', 'ansible02[1:2]', '[::1]', '[::2]']:
        print("Case 2, list is passed.")

# Generated at 2022-06-24 19:51:25.575526
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
  from ansible.inventory.manager import InventoryManager
  from ansible.module_utils._text import to_text
  n = InventoryManager()
  p = None
  n.subset(p)
  p1 = "host1"
  p2 = "host2"
  n.subset(p1)
  n.subset(p2)
  try:
      n.subset(p1,p2)
  except TypeError:
      pass

# Generated at 2022-06-24 19:51:26.390981
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    test_case_0()


# Generated at 2022-06-24 19:51:29.023257
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    iov = [{'inventory' : './pytest/units/inventory'}]
    inventory_manager_0 =  InventoryManager(iov)
    inventory_manager_0.list_hosts();


# Generated at 2022-06-24 19:51:31.269871
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    try:
        inventory_manager_0 = InventoryManager()
        var_0 = inventory_manager_0.list_hosts()
    except Exception:
        print("Failed to run unit test for method list_hosts of class InventoryManager")
        raise


# Generated at 2022-06-24 19:51:32.557188
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    inventory_manager_0 = InventoryManager()
    var_0 = inventory_manager_0.list_hosts()


# Generated at 2022-06-24 19:51:33.958069
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    try:
        test_case_0()
    except Exception as exception:
        print(exception)
        assert False



# Generated at 2022-06-24 19:51:37.764759
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager_0 = InventoryManager()
    result_1 = inventory_manager_0.subset('127.0.0.1')
    assert result_1 == None, "inventory_manager_0.subset() did not return expected result (None)"


# Generated at 2022-06-24 19:51:39.562559
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory_manager_0 = InventoryManager()
    inventory_manager_0.parse_sources('/etc/ansible/hosts')


# Generated at 2022-06-24 19:53:25.271395
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager = InventoryManager()
    # Test the subset of InventoryManager
    inventory_manager.subset(u'test_host')

    inventory_manager = InventoryManager()
    # Test the subset of InventoryManager
    inventory_manager.subset(u'test_host')



# Generated at 2022-06-24 19:53:31.465354
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    yaml_path = os.path.join(os.path.dirname(__file__), '../../../lib/ansible')
    json_path = os.path.join(yaml_path, 'inventory.json')
    yaml_path = os.path.join(yaml_path, 'inventory.yml')

    display.verbosity = 4
    inventory_manager = InventoryManager()

    # Test YAML source
    with open(yaml_path) as fd:
        yaml_data = to_text(fd.read())
    source_yaml = SourceData(host_list=[], group_list=[], index=[], vars_list=[])
    source_yaml_1 = inventory_manager.parse_source(source=yaml_data, source_type='yaml')
    assert source_yaml

# Generated at 2022-06-24 19:53:40.803454
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager = InventoryManager()
    # Project: test_inventory_manager
    # Test case: test_case_0

    #
    # Testing string split_host_pattern with input 'group1:group2'
    #

    #
    # Testing string split_host_pattern with input 'host1:host2'
    #

    #
    # Testing string split_host_pattern with input 'host1:group2'
    #

    #
    # Testing string split_host_pattern with input 'group1:host2'
    #

    #
    # Testing string split_host_pattern with input 'host1'
    #

    #
    # Testing string split_host_pattern with input 'group1'
    #

    #
    # Testing string split_host_pattern with input '192.168.0.0/16'

# Generated at 2022-06-24 19:53:42.695771
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager_0 = InventoryManager()
    pattern = "@/home/user/ansible/ansible/inventory"
    inventory_manager_0.subset(pattern)


# Generated at 2022-06-24 19:53:49.950852
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory_manager = InventoryManager()
    os.environ['ANSIBLE_INVENTORY_ENABLED'] = 'foobar'
    inventory_manager.parse_inventory(os.path.join(os.path.dirname(__file__), "./inventory_test.yml"), cache=False)
    os.environ['ANSIBLE_INVENTORY_ENABLED'] = '1'


# Generated at 2022-06-24 19:53:51.952424
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():

    print("InventoryManager_parse_sources: Running test case")

    inventory = InventoryManager()
    inventory.parse_sources(inventory_sources=['/dev:null'])


# Generated at 2022-06-24 19:53:55.135600
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager_0 = InventoryManager()
    subset_pattern = 'all'
    inventory_manager_0.subset(subset_pattern)


# Generated at 2022-06-24 19:54:04.789608
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
   inventory_manager = InventoryManager()
   inventory_manager.load_inventory_from_file("/home/pallav/ansible/hosts")
   #inventory_manager.add_host("src","ip1")
   #inventory_manager.add_child("src","child","ip2")
   #inventory_manager.add_group("dst")
   #inventory_manager.add_child("dst","child","ip3")
   #all_groups=inventory_manager.get_groups_dict()
   #childList=inventory_manager.get_groups_dict()
   #print inventory_manager.list_hosts("src")
   #inventory_manager.remove_group("src")
   #print inventory_manager.list_hosts("src")
   #print inventory_manager.list_hosts("dst")
   #print inventory

# Generated at 2022-06-24 19:54:11.498445
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory_manager_get_hosts = InventoryManager()
    print(inventory_manager_get_hosts.get_hosts())
    print(inventory_manager_get_hosts.get_hosts('all'))
    print(inventory_manager_get_hosts.get_hosts(pattern='all'))
    print(inventory_manager_get_hosts.get_hosts(pattern=['all']))
    print(inventory_manager_get_hosts.get_hosts(pattern=['all','all']))
    print(inventory_manager_get_hosts.get_hosts(pattern=['all','all','all']))


# Generated at 2022-06-24 19:54:16.915255
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager_1 = InventoryManager()
    assert inventory_manager_1.subset == None
    inventory_manager_1.subset('all')
    assert inventory_manager_1.subset == ['all']


# Generated at 2022-06-24 19:55:24.777545
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory_manager_0 = InventoryManager()
    sources = "localhost"
    result = inventory_manager_0.parse_source(sources)
    print(result)


# Generated at 2022-06-24 19:55:26.989333
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    hosts = InventoryManager.list_hosts()
    print(hosts)

if __name__=="__main__":
    test_InventoryManager_list_hosts()

# Generated at 2022-06-24 19:55:29.758823
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    # FIXME: write unit test for InventoryManager.parse_source
    return


# Generated at 2022-06-24 19:55:34.179058
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    inventory_manager = InventoryManager()

    host_list = inventory_manager.list_hosts("all")
    print(host_list)

if __name__ == "__main__":
    test_InventoryManager_list_hosts()

# Generated at 2022-06-24 19:55:36.888651
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    inventory_manager_1 = InventoryManager()
    inventory_manager_1.get_hosts("redis_server")
    inventory_manager_1.list_hosts("redis_server")

# InventoryManager._evaluate_patterns

# Generated at 2022-06-24 19:55:46.967852
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    # Initialize inventory manager
    inventory_manager = InventoryManager()

    # Define inventory name
    inventory = 'environments/test/test.inventory.cfg'
    
    # Load inventory
    inventory_manager.load_inventory(inventory)
    assert inventory_manager._inventory.hosts['bastion'].vars['foo'] == 'bar'
    
    # Test InventoryManager.list_hosts
    assert inventory_manager.list_hosts('bastion') == ['bastion']
    assert inventory_manager.list_hosts() == ['bastion']
    assert inventory_manager.list_hosts('all') == ['bastion']
    
    # Test InventoryManager.list_hosts
    assert inventory_manager.list_hosts('invalid_host') == []
    assert inventory_manager.list_hosts

# Generated at 2022-06-24 19:55:51.989446
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    inventory_manager_1 = InventoryManager()
    results = inventory_manager_1.list_hosts("all")
    assert len(results) == 0


# Generated at 2022-06-24 19:55:54.595877
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    inventory_manager = InventoryManager()
    result = inventory_manager.list_hosts()
    assert result == ['localhost']


# Generated at 2022-06-24 19:55:58.223335
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager_0 = InventoryManager()
    subset_pattern_0 = None
    inventory_manager_0.subset(subset_pattern_0)
    subset_pattern_1 = "all"
    inventory_manager_0.subset(subset_pattern_1)


# Generated at 2022-06-24 19:56:04.435416
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():

    # pre-run
    global C
    C = AnsibleConfig(parser=CLIARGS._get_parser())
    global inventory_manager_1
    inventory_manager_1 = InventoryManager()

    # empty subset
    subset = None
    inventory_manager_1.subset(subset)
    assert inventory_manager_1._subset == subset

    # non-empty subset
    subset = ["host_4", "host_5", "host_6"]
    subset_pattern = ",".join(subset)
    inventory_manager_1.subset(subset_pattern)
    assert inventory_manager_1._subset == subset


# Generated at 2022-06-24 19:57:03.306881
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():
    str_0 = 'U6'
    path_0 = '.'
    obj_1 = InventoryManager(path_0)
    path_1 = './inventory.cfg'
    obj_1.parse_sources(str_0, path_1)
    obj_2 = InventoryManager(path_0)
    path_2 = './inventory.cfg'
    obj_2.parse_sources(str_0, path_2)
    obj_3 = InventoryManager(path_0)
    path_3 = './inventory.cfg'
    obj_3.parse_sources(str_0, path_3)
    bool_0 = obj_1 == obj_2
    bool_1 = obj_1 == obj_3
    bool_2 = obj_2 == obj_3



# Generated at 2022-06-24 19:57:09.311656
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory_manager_0 = InventoryManager()

    string_0 = 'srv04'
    list_0 = ['icinga']
    set_0 = {u'[2]', u'web*', u'srv04'}
    bool_0 = inventory_manager_0.get_hosts(string_0) == list_0
    assert bool_0
    bool_0 = inventory_manager_0.get_hosts(list_0) == set_0
    assert bool_0

test_InventoryManager_get_hosts()

# Generated at 2022-06-24 19:57:13.123515
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    str_host_list = '1HSpKc@MA8Ck.\t\\'
    expected_result = []
    inventory_manager = InventoryManager(loader, sources='')
    inventory_manager.subset(str_host_list)
    assert inventory_manager._subset == expected_result, u'Expected and obtained results do not match'


# Generated at 2022-06-24 19:57:24.588170
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    f = 'ansible/inventory/__init__.py'
    # In: 'banner:&|ansible-4*.\t\\'
    str_0 = 'banner:&|ansible-4*.\t\\'
    # In: str_0
    var_0 = split_host_pattern(str_0)
    # In: 'ansible-4*.\t\\'
    str_1 = 'ansible-4*.\t\\'
    # In: 'banner:&|'
    str_2 = 'banner:&|'
    # In: '~[abc]*'
    str_3 = '~[abc]*'
    # In: '.\t\\'
    str_4 = '.\t\\'
    # In: 'ansib*'

# Generated at 2022-06-24 19:57:26.247433
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    i = InventoryManager(loader=DataLoader())
    i.subset("all")


# Generated at 2022-06-24 19:57:32.466707
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():
    # Test call with args
    # 1. test_sources: List[str] = [
    #                                   'localhost',
    #                                   'localhost,',
    #                                   'localhost,  , '
    #                               ]
    sources_source = [
        'localhost',
        'localhost,',
        'localhost,  , '
    ]

    # 2. source_vars: Optional[Dict[str, Any]] = None
    source_vars_source = None
    # Private method call
    # InventoryManager.test_InventoryManager_parse_sources(test_sources, source_vars)
    # Mocked return values
    # 1. '\\'  # return value from call 1
    # 2. '[]'  # return value from call 2
    # 3. '~'  # return value from

# Generated at 2022-06-24 19:57:34.548522
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    i = InventoryManager(loader=None, sources=C.DEFAULT_HOST_LIST)
    i.clear_pattern_cache()
    i.parse_sources()


# Generated at 2022-06-24 19:57:36.716558
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inv = InventoryManager('/etc/ansible/hosts')
    inv.parse_sources()

test_case_0()
test_InventoryManager_parse_source()

# Generated at 2022-06-24 19:57:39.922580
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    str_0 = '1HSpKc@MA8Ck.\t\\'
    var_0 = split_host_pattern(str_0)
    str_1 = 'jz'
    var_1 = TestAnsibleCoreCLI.yaml_file.get_option(str_0)


# Generated at 2022-06-24 19:57:42.065355
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    str_0 = '}U.X]Z_D6'
    var_0 = InventoryManager.get_hosts(str_0)


# Generated at 2022-06-24 19:58:12.485635
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager_obj = InventoryManager()
    inventory_manager_obj.subset(subset_pattern = None)


# Generated at 2022-06-24 19:58:20.065706
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # inventory is of type ansible.parsing.dataloader.DataLoader
    inventory = get_file_loader(loader_type='auto')
    inventory = inventory.load_from_file('test/integration/inventory.ini')
    # subset_pattern is of type str
    subset_pattern = 'all'
    manager = InventoryManager(loader=inventory)
    result = manager.subset(subset_pattern)
    assert isinstance(result, list)


# Generated at 2022-06-24 19:58:21.704257
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    var_0 = 'file_name'
    var_1 = InventoryManager(var_0)
    var_2 = None
    var_1.subset(var_2)


# Generated at 2022-06-24 19:58:29.387372
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    str_0 = '1HSpKc@MA8Ck.\t\\'
    manager_0 = InventoryManager(str_0)
    assert manager_0.get_hosts() == []
    manager_0 = InventoryManager(str_0)
    str_1 = '1HSpKc@MA8Ck.\t\\'
    assert manager_0.get_hosts(str_1) == []
    manager_0 = InventoryManager(str_0)
    str_2 = ''
    assert manager_0.get_hosts(str_2) == []
    manager_0 = InventoryManager(str_0)
    bool_0 = False
    bool_1 = False
    str_3 = ''
    assert manager_0.get_hosts(str_3, bool_0, bool_1) == []

# Generated at 2022-06-24 19:58:38.523039
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():

    # From test/units/inventory/test_inventory.py
    inv = Inventory(loader=DataLoader())
    inv.add_group('group_0')
    inv.add_group('group_1')
    inv.add_group('group_2')
    inv.add_host('host0')
    inv.add_host('host1')
    inv.add_host('host2')
    inv.add_host('host3')

    inv.add_child('group_0', 'host0')
    inv.add_child('group_0', 'host1')
    inv.add_child('group_0', 'host2')
    inv.add_child('group_0', 'host3')

    inv.add_child('group_1', 'host1')