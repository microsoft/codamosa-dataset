

# Generated at 2022-06-24 19:49:18.671527
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    obj = InventoryManager()
    obj.add_group('all')
    obj.clear_pattern_cache()
    obj.get_hosts('all', False, False, None)
    obj.get_hosts('all', True, False, None)
    obj.get_hosts('all', False, True, None)
    obj.get_hosts('all', True, True, None)
    obj.get_hosts('all', False, False, 'sorted')
    obj.get_hosts('all', False, False, 'reverse_sorted')
    obj.get_hosts('all', False, False, 'shuffle')
    obj.get_hosts('all', False, False, 'reverse_inventory')
    obj.get_hosts('all', False, False, 'inventory')

# Generated at 2022-06-24 19:49:19.711918
# Unit test for function order_patterns
def test_order_patterns():
    assert order_patterns(['uH?pF']) == ['all', 'uH?pF']


# Generated at 2022-06-24 19:49:20.776259
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    print("[*] Running method test_InventoryManager_parse_source()")
    test_case_0()


# Generated at 2022-06-24 19:49:22.455937
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory_manager = InventoryManager()
    inventory_manager.parse_source('all')
    assert inventory_manager._inventory.groups == {}
    assert inventory_manager._inventory.hosts == {}


# Generated at 2022-06-24 19:49:23.814525
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    p_var_0 = '!'
    var_0 = InventoryManager(p_var_0)


# Generated at 2022-06-24 19:49:25.015800
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    var_0 = InventoryManager([])
    var_0.subset('test_input_0')


# Generated at 2022-06-24 19:49:28.028348
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    inventory_manager = InventoryManager()
    assert isinstance(inventory_manager.list_hosts(), list)


# Generated at 2022-06-24 19:49:31.400669
# Unit test for function split_host_pattern
def test_split_host_pattern():
    str_0 = 'uH?pF'
    var_0 = split_host_pattern(str_0)
    print(var_0)

    str_1 = 'a,b[1], c[2:3] , d'
    var_1 = split_host_pattern(str_1)
    print(var_1)

if __name__ == '__main__':
    test_split_host_pattern()

# Generated at 2022-06-24 19:49:32.896768
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    str_0 = 'nfzv&8V'
    var_0 = InventoryManager.get_hosts(str_0)


# Generated at 2022-06-24 19:49:40.798155
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():

    # Method: list_hosts of class InventoryManager
    # No Argument
    # Return: a list of hostnames for a pattern 
    # Test 1: Default parameter
    test_str_1 = 'uH?pF'
    result_1 = to_text(test_str_1)
    assert (result_1==str_0)
    # Test 2: Default parameter
    test_str_2 = 'q3[5-6]'
    result_2 = to_text(test_str_2)
    assert (result_2==str_1)
