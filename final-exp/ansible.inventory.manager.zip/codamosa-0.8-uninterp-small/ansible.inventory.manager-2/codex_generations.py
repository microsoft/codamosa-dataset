

# Generated at 2022-06-24 19:50:06.128605
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # uncomment to use logging in tests
    # logging.basicConfig(level=logging.DEBUG)
    inventory_manager = test_case_0()
    # subset call on line 399
    inventory_manager.subset(None)


# Generated at 2022-06-24 19:50:10.734940
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    inventory_manager_1 = InventoryManager(float())
    # Invalid test
    inventory_manager_1.list_hosts()


# Generated at 2022-06-24 19:50:13.500939
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():
    # create inventory manager instance
    inventory_manager_0 = InventoryManager(3508.4461)
    # assert if inventory manager instance is created
    assert inventory_manager_0 is not None, "Failed to create inventory_manager_0 instance"



# Generated at 2022-06-24 19:50:23.149294
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    b_arg = to_bytes('/test/test_ansible/inventory/hosts.txt')
    float_0 = 3508.4461
    inventory_manager_0 = InventoryManager(float_0)
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case

# Generated at 2022-06-24 19:50:24.178313
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory_manager_0 = InventoryManager()

    inventory_manager_0.parse_source()


# Generated at 2022-06-24 19:50:30.477304
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    float_0 = 3508.4461
    inventory_manager_0 = InventoryManager(float_0)
    float_1 = 3508.4461
    inventory_manager_1 = InventoryManager(float_1)
    float_2 = 3508.4461
    inventory_manager_2 = InventoryManager(float_2)
    inventory_manager_2.get_hosts()
    inventory_manager_1.get_hosts(inventory_manager_2)
    inventory_manager_0.get_hosts(inventory_manager_1)


# Generated at 2022-06-24 19:50:35.556870
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    # setup
    inventory_manager_0 = InventoryManager(None)

# Generated at 2022-06-24 19:50:38.504376
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager_0 = InventoryManager()
    subset_pattern = ''
    assert inventory_manager_0.subset(subset_pattern) == None



# Generated at 2022-06-24 19:50:42.567070
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    logger_0 = logging.getLogger()
    inventory_manager_0 = InventoryManager('/etc/ansible/hosts')
    inventory_manager_0.parse_source('/etc/ansible/hosts', 'script', 'x', logger_0)


# Generated at 2022-06-24 19:50:46.348901
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    string_0 = 'ZpE8'
    inventory_manager_0 = InventoryManager(string_0)

    target_0 = '<3q'
    inventory_manager_0.subset(target_0)


# Generated at 2022-06-24 19:51:12.574889
# Unit test for function split_host_pattern
def test_split_host_pattern():
    print ("\n\nStart testing function split_host_pattern")

# Generated at 2022-06-24 19:51:19.830980
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    # Setup
    inventory = ansible.parsing.dataloader.DataLoader()
    inventory = ansible.inventory.manager.InventoryManager(loader=inventory, sources=None)
    inventory = InventoryManager(inventory)
    pattern = None
    ignore_limits = None
    ignore_restrictions = None
    order = None

    # Invoke method
    result = inventory.get_hosts(pattern, ignore_limits, ignore_restrictions, order)

    # Check result
    assert(result == [])

    # Setup
    inventory = ansible.parsing.dataloader.DataLoader()
    inventory = ansible.inventory.manager.InventoryManager(loader=inventory, sources=None)
    inventory = InventoryManager(inventory)
    pattern = "test"
    ignore_limits = None
    ignore_restrict

# Generated at 2022-06-24 19:51:22.196151
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    var_0 = InventoryManager()
    var_1 = var_0.parse_source("/etc/ansible/hosts")
    assert var_1 == None


# Generated at 2022-06-24 19:51:23.138630
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    var_0 = None


# Generated at 2022-06-24 19:51:23.745465
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    var_0 = None

# Generated at 2022-06-24 19:51:28.977686
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    var_0 = InventoryManager()
    var_1 = list_hosts()


# Generated at 2022-06-24 19:51:32.559425
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    var_0 = None
    var_0 = InventoryManager(var_0)
    var_0.list_hosts("all")


# Generated at 2022-06-24 19:51:33.763695
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    var_1 = InventoryManager()

    var_0 = var_1.subset(None)


# Generated at 2022-06-24 19:51:38.649973
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    var_1 = InventoryManager(loader=None, variables={'ansible_connection': _ConnectionWrapper(), 'ansible_playbook_python': ['default', '/usr/bin/python']}, host_list=['localhost'])
    var_2 = 'test_connection'
    var_1.parse_source(var_2)
    

# Generated at 2022-06-24 19:51:47.312286
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    # Instantiate mock object
    inventory_plugin = InventoryModule()
    inventory_manager = InventoryManager(inventory_plugin=inventory_plugin)

    #Intitialize data
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None

    # Invoke method
    inventory_manager.get_hosts(pattern=var_0)
    inventory_manager.get_hosts(pattern=var_1)
    inventory_manager.get_hosts(pattern=var_2)
    inventory_manager.get_hosts(pattern=var_3)


# Generated at 2022-06-24 19:52:10.078113
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    var_0 = None
    # Initialization
    test_class_0 = InventoryManager()
    test_case_0()
    # Testing if an exception is thrown and if the exception message contains all the given messages
    try:
        test_class_0.subset(var_0)
    except Exception as e:
        assert all([s in str(e) for s in ['self._subset=None']])


# Generated at 2022-06-24 19:52:17.207472
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():

    # InventoryManager(...) -> InventoryManager
    inventory_manager = InventoryManager([])

    # SOURCE_PATH -> str
    source_path = "/path/to/dir"

    # SOURCE_NAME -> str
    source_name = "dir"

    # SOURCE_CONFIG -> dict
    source_config = {"key": "value"}

    # InventoryData -> InventoryData
    # dict -> dict
    result = inventory_manager.parse_source(source_path, source_name, source_config)


# Generated at 2022-06-24 19:52:19.248039
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    var_0 = InventoryManager()
    var_1 = var_0.get_hosts()
    assert var_1 == []


# Generated at 2022-06-24 19:52:22.442311
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    global var_0

    var_0 = InventoryManager(inventory=None, variable_manager=None)

    var_0.list_hosts(pattern="all")

if __name__ == '__main__':
    var_0 = None

    test_case_0()

# Generated at 2022-06-24 19:52:24.742908
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
   inventory_manager = InventoryManager()
   # test for: inventory_manager.parse_source(path, cache=True, vault_password=None, export='inventory')
   test_case_0()

if __name__ == "__main__":
   test_InventoryManager_parse_source()

# Generated at 2022-06-24 19:52:30.841442
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    """
    Tests parse_source(self, source_name, source_path, source_data, private_data)
    """

    # Setup
    inventory_manager = mock.Mock()
    source_name = None
    source_path = None
    source_data = None
    private_data = None

    # Invoke method
    result = inventory_manager.parse_source(source_name, source_path, source_data, private_data)

    # Setup
    inventory_manager = mock.Mock()
    source_name = None
    source_path = None
    source_data = None
    private_data = None

    # Invoke method
    result = inventory_manager.parse_source(source_name, source_path, source_data, private_data)

    # Setup
    inventory_manager = mock.Mock()

# Generated at 2022-06-24 19:52:31.749138
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    var_0 = None


# Generated at 2022-06-24 19:52:35.522899
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    src = 'example.yml'
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=src)
    var_0 = inventory.parse_source(src, None)
    var_1 = inventory.parse_source(src)


# Generated at 2022-06-24 19:52:41.021087
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    var_0 = InventoryManager(loader=None, sources=['/etc/ansible/hosts'], groups_cache_path=None)
    if isinstance(var_0, InventoryManager):
        var_0._loader
        var_0.groups_cache_path
    return var_0



# Generated at 2022-06-24 19:52:44.482751
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    var_0 = AnsibleHost('fakeserver', 'fakeserver.ansible.com')
    var_1 = InventoryManager(var_0)

    var_2 = None
    ret_1 = var_1.get_hosts(var_2)

    assert ret_1 == []


# Generated at 2022-06-24 19:53:10.692761
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    from inventory_manager import InventoryManager
    from ansible.module_utils.six.moves import shlex_quote
    import ansible.inventory.manager

    var_1 = InventoryManager(ansible_file=None, cache_dir=None, cache_name=None, loader=None, inventory=None, variable_manager=None, sources=None, enable_plugins=True)
    var_2 = u'all'
    var_3 = None
    var_3 = var_1.subset(subset_pattern=var_2)
    var_6 = u'all'
    var_5 = shlex_quote(var_6)
    var_4 = u'"' + var_5 + u'"'
    var_7 = var_1.get_host(host_pattern=var_4)
    # assert that set of var

# Generated at 2022-06-24 19:53:18.333106
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():
    options = Dict()
    inventory = Inventory(loader=Mock(), variable_manager=Mock())
    host_list = ['localhost']
    vault_password = None
    subset = None
    module_name = 'setup'
    module_args = 'filter="ansible_distribution_version"'
    timeout = 10
    forks = 100
    pattern = 'all'
    become = None
    become_method = None
    become_user = None
    check = None
    difference = None

    argspec = inspect.getfullargspec(InventoryManager.parse_sources)
    # noinspection PyTypeChecker
    inventory_manager = InventoryManager(loader=Mock(), variable_manager=Mock(), host_list=host_list)

# Generated at 2022-06-24 19:53:20.328927
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    var_0 = None

test_case_0()
test_InventoryManager_subset()

# Generated at 2022-06-24 19:53:30.846796
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    var_0 = InventoryManager(loader, sources=["hosts"], vault_password=["$ANSIBLE_VAULT;1.1;AES256;ansible@ansible-VirtualBox"], sources_from_inventory=False, inventory_loader=None, variable_manager=VariableManager())
    # Call method list_hosts of class InventoryManager
    #   Result of method list_hosts of class InventoryManager is null
    var_tmp = var_0.list_hosts()
    # AssertionError if var_tmp is not null
    if var_tmp is not None:
        err_msg = "Failed: var_tmp == 'list_hosts'"
        logger.debug(err_msg)
        raise AssertionError(err_msg)
    return var_tmp


# Generated at 2022-06-24 19:53:33.561869
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    test_case = InventoryManager(Inventory("localhost"))
    assert test_case.list_hosts() == ["localhost"]

# Generated at 2022-06-24 19:53:36.393166
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    var_1 = None
    i_2 = InventoryManager(var_1)
    var_3 = "all"
    i_4 = i_2.list_hosts(var_3)


# Generated at 2022-06-24 19:53:46.580348
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    var_1 = 'var'
    var_2 = 'var'
    var_3 = 'var'
    var_4 = 'var'
    var_5 = 'var'
    var_6 = 'var'
    var_7 = 'var'
    var_8 = 'var'
    var_9 = 'var'
    var_10 = 'var'
    var_11 = 'var'
    var_12 = 'var'
    var_13 = 'var'
    var_14 = 'var'
    var_15 = 'var'
    var_16 = 'var'
    var_17 = 'var'
    var_18 = 'var'
    var_19 = 'var'
    var_20 = 'var'
    var_21 = 'var'
    var_22 = 'var'
   

# Generated at 2022-06-24 19:53:49.435473
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    print('\n*** Testing InventoryManager.get_hosts() ***')
    var_0 = None
    var_0 = InventoryManager.get_hosts()
    assert var_0 != None
    assert type(var_0) == type([])


# Generated at 2022-06-24 19:53:57.987817
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # Initialize host_list and configure variables
    host_list = [
        "localhost",
        "other1",
        "other2"
    ]
    b_host_list = [to_bytes(i, errors='surrogate_or_strict') for i in host_list]
    inventory = InventoryManager(loader=DataLoader(), sources=b_host_list)
    pattern = "localhost"
    subset_pattern = "loc"

    im = InventoryManager(loader=None, sources=[])
    im._inventory = inventory
    # Test method with pattern that matches a single host and
    # subset_pattern that does not match anything
    im.subset(subset_pattern=subset_pattern)
    assert im._subset is None
    # Test method with pattern that matches a single host and
    # subset_pattern that matches the

# Generated at 2022-06-24 19:53:59.766439
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    global var_0
    test = InventoryManager(var_0)
    test.subset(var_0)


# Generated at 2022-06-24 19:54:16.870940
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    manager = InventoryManager()
    pattern = None
    manager.subset(pattern)



# Generated at 2022-06-24 19:54:26.424124
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():

    var_1 = {}
    var_2 = []
    for i0 in range(10):
        x0 = i0 % 13 + random.randint(-186909, -164878)
        var_2.append(x0)
    var_1['I'] = var_2
    var_1['R'] = None
    var_1['A'] = ['Z']
    var_1['o'] = [0]
    var_1['Y'] = [0]
    var_1['M'] = [0]
    var_1['r'] = False
    var_1['F'] = 0
    var_1['h'] = {}
    var_1['T'] = ['S']
    test_case_0()


# Generated at 2022-06-24 19:54:29.788601
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    var_0 = InventoryManager(
        loader=DictDataLoader({}),
        sources=['localhost'])
    var_0.subset('')
    pass


# Generated at 2022-06-24 19:54:33.816886
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    var_0 = InventoryManager()
    var_1 = u'host1,host2,host3'
    var_0.subset(var_1)


# Generated at 2022-06-24 19:54:36.200050
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    var_0 = InventoryManager()
    var_1 = None
    var_0.subset(var_1)
    assert True


# Generated at 2022-06-24 19:54:41.747086
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    # Source: InventoryManager.py line 384
    var_0 = InventoryManager()
    var_1 = None
    var_2 = 'localhost'
    var_3 = '127.0.0.1'
    if var_0.parse_source(var_1, var_2, var_3, var_3):
        return(True)
    return(False)


# Generated at 2022-06-24 19:54:44.972350
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    var_0 = None
    var_1 = None
    var_2 = None


# Generated at 2022-06-24 19:54:46.964832
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    assert True


# Generated at 2022-06-24 19:54:50.488284
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    var_1 = None
    var_2 = None
    inventory_1 = InventoryManager(var_1)
    var_3 = inventory_1.get_hosts(var_2)
    return var_3


# Generated at 2022-06-24 19:54:54.967075
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():

    inventory_manager = InventoryManager(loader=None, sources=[])
    source = ""
    group_pattern = ""
    source_type = ""
    var_1 = inventory_manager.parse_source(source, group_pattern, source_type)
    try:
        assert var_1 == None
    except AssertionError as e:
        raise e


# Generated at 2022-06-24 19:55:13.018845
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    var_0 = AnsibleOptions()
    var_0.host_key_checking = False
    var_0.private_key_file = 'test/test_data/test_key'
    var_0.connection = 'local'
    options = var_0
    loader = None
    var_1 = InventoryManager(loader, options)
    var_2 = var_1._parse_source(None)


# Generated at 2022-06-24 19:55:20.831065
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    # Test case 0
    bool_0 = False
    var_0 = split_host_pattern(bool_0)
    bool_1 = True
    var_1 = split_host_pattern(bool_1)
    bool_2 = False
    var_2 = split_host_pattern(bool_2)
    bool_3 = False
    var_3 = split_host_pattern(bool_3)
    bool_4 = False
    var_4 = split_host_pattern(bool_4)


# Generated at 2022-06-24 19:55:26.094602
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    inventory = InventoryManager(host_list=[])
    inventory.parse_inventory({
        'all': {
            'hosts': ['X']
        }
    })
    pattern = 'all'
    res = inventory.list_hosts(pattern) # should return ['X'] 

# Generated at 2022-06-24 19:55:27.299200
# Unit test for function split_host_pattern
def test_split_host_pattern():
    try:
        test_case_0()
    except:
        print(traceback.format_exc())


# Generated at 2022-06-24 19:55:38.339799
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    bool_0 = False
    str_0 = 'dymLL'
    str_1 = '6'
    str_2 = 'zJ'
    str_3 = ')'
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    var_0 = 'beD[m'
    var_1 = ',Jry'
    var_2 = 'QyN0s'
    var_3 = '3'
    var_4 = 'a'
    var_5 = '7e'
    var_6 = 'x'
    var_7 = ','
    var_8 = '_:gf'
    var_9 = 'Hh'
    var_10 = '-,'
    var_11 = 'Xy'
    var_12 = 'D:*'
   

# Generated at 2022-06-24 19:55:39.337069
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory = InventoryManager()
    inventory.subset('123')


# Generated at 2022-06-24 19:55:46.029754
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    p_test_subset_1 = """foo*[1:5]"""
    p_test_subset_2 = """foo*[1:5]"""
    inventory = TestInventory()
    result = TestInventoryManager(inventory).subset(p_test_subset_1)
    assert result == TestInventoryManager(inventory).subset(p_test_subset_2)
    assert TestInventoryManager(inventory).subset(p_test_subset_1) == TestInventoryManager(inventory).subset(p_test_subset_2)


# Generated at 2022-06-24 19:55:51.286165
# Unit test for function split_host_pattern
def test_split_host_pattern():
    var_0 = True
    var_0_repr = repr(var_0)
    expect_val_0 = [True]
    actual_val_0 = split_host_pattern(var_0)
    assert actual_val_0 == expect_val_0
    var_2 = 3
    var_2_repr = repr(var_2)
    expect_val_2 = [3]
    actual_val_2 = split_host_pattern(var_2)
    assert actual_val_2 == expect_val_2
    var_3 = 'foo'
    var_3_repr = repr(var_3)
    expect_val_3 = ['foo']
    actual_val_3 = split_host_pattern(var_3)
    assert actual_val_3 == expect_val_3
    var

# Generated at 2022-06-24 19:55:56.598087
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # Test with the default.
    inventory_0 = InventoryManager()
    inventory_0.subset(None)
    # Test with a default value and arg.
    inventory_1 = InventoryManager()
    inventory_1.subset(None)
    inventory_1.subset("bogus")
    # Test with no arg.
    inventory_2 = InventoryManager()
    inventory_2.subset()


# Generated at 2022-06-24 19:56:05.652672
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    var_0 = InventoryManager('ansible/inventory')
    var_0.parse_inventory(None)
    var_1 = var_0.get_hosts("all")
    var_2 = var_0.get_hosts("local")
    var_3 = var_0.get_hosts("hostvars[\'all\']")
    var_4 = var_0.get_hosts("hostvars[\'all\'][\'v_0\']")
    var_5 = var_0.get_hosts("all:!local")
    var_6 = var_0.get_hosts("all:&local")
    var_7 = var_0.get_hosts("all:!hostvars[\'all\']")

# Generated at 2022-06-24 19:56:29.743361
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():

    #FIXME: this test needs to be re-written
    im = InventoryManager(loader=None)
    sources = C.DEFAULT_INVENTORY_ENABLED
    sources.append('/path/to/inventory')

    def create_loader(inventory_manager, path):
        loader = InventoryLoader(inventory_manager, path)
        loader.load_from_source = MagicMock()
        return loader

    with patch('ansible.inventory.InventoryLoader') as mock:
        mock.side_effect = create_loader
        im.parse_sources(sources)

    assert mock.call_count == len(sources)



# Generated at 2022-06-24 19:56:32.557018
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    var_0 = InventoryManager()
    var_1 = u'foo'
    var_0.subset(var_1)
    var_2 = subset_inventories(var_0, var_1)
    pass


# Generated at 2022-06-24 19:56:42.805404
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    logging.basicConfig(level=logging.DEBUG)
    # NOTE: created Inventory is not thread-safe because it uses static variables
    # NOTE: some methods do not work (inventory/construct_inventory.py:819)
    i = Inventory()
    i.parse_inventory('./ansible/test/units/inventory_case_0.yaml')
    hostvars = i.get_host('127.0.0.1').get_vars()
    im = InventoryManager(i)
    im.subset('127.0.0.1')
    var_1 = im._subset
    assert var_1 == ['127.0.0.1']


# Generated at 2022-06-24 19:56:46.953695
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    var_0 = InventoryManager()
    var_0.subset("test_pattern")


# Generated at 2022-06-24 19:56:53.653698
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory_manager_0 = InventoryManager(loader=None)
    bool_0 = False
    string_0 = "s3://foo/bar"
    list_0 = [bool_0, string_0]

    # Invoke method
    inventory_manager_0.parse_source(list_0)


# Generated at 2022-06-24 19:57:02.424902
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    # Initialize class
    inventory_manager_0 = InventoryManager()

    # Set instance var '_inventory' of class 'InventoryManager' object
    inventory_manager_0._inventory = { }

    # Invoke method 'list_hosts' of class 'InventoryManager' object
    try:
        inventory_manager_0.list_hosts()
    except (AnsibleOptionsError, AnsibleParserError, AnsibleError) as exception:
        traceback.print_exc()
        # AssertionError
        if type(exception).__name__ == 'AssertionError':
            pass
        else:
            raise exception
    else:
        pass


# Generated at 2022-06-24 19:57:10.792168
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    print("Testing test_parse_source")

    inv_mgr = InventoryManager(loader=None, sources=["test/unit/test_inventory/test_inventory_0"])
    print("Parsing test_inventory_0...")
    inv_mgr.parse_sources()
    
    # Print out the groups
    print(inv_mgr._inventory.groups)
    for key in inv_mgr._inventory.groups:
        print("%s: %s" % (key, inv_mgr._inventory.groups[key].vars))
    
    
    # Print out the hosts
    print(inv_mgr._inventory.hosts)

# Generated at 2022-06-24 19:57:20.509269
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    i = InventoryManager(Loader(), variable_manager=VariableManager())

    hosts = [Host(name='foo'), Host(name='bar')]
    groups = {'all': Group(name='all'), 'group_0': Group(name='group_0')}
    # Run the list_hosts method with a mock object
    with patch.object(Inventory, 'list_hosts', return_value=hosts), patch.object(Inventory, 'get_groups', return_value=groups):
        result = i.list_hosts()
    assert result == ['foo', 'bar']

    # Test with no hosts
    with patch.object(Inventory, 'list_hosts', return_value=[]), patch.object(Inventory, 'get_groups', return_value=groups):
        result = i.list_hosts()

# Generated at 2022-06-24 19:57:28.406853
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_1 = dict()
    inventory_1[u'all'] = Host(name=u'all')
    inventory_1[u'all'].set_variable(u'ansible_connection',u'local')
    inventory_1[u'all'].set_variable(u'ansible_python_interpreter',u'/usr/bin/python')
    inventory_1[u'all'].set_variable(u'ansible_become_method',u'sudo')
    inventory_1[u'all'].set_variable(u'ansible_become_user',u'root')
    inventory_1[u'all'].set_variable(u'ansible_user',u'root')
    inventory_1[u'all'].set_variable(u'group_names',[u'ungrouped'])

# Generated at 2022-06-24 19:57:32.472287
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():
    var_0 = InventoryManager()
    var_1 = safe_load(var_0.parse_sources(("[1, 2, 3]", "[4, 5, 6]")).serialize())
    assert var_1 == [1, 2, 3, 4, 5, 6]


# Generated at 2022-06-24 19:58:04.366958
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory_manager_0 = InventoryManager()
    var_0 = inventory_manager_0.parse_source('localhost')
    assert var_0 == u'localhost'


# Generated at 2022-06-24 19:58:07.135985
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    # Initialize inventory.
    inventory = InventoryManager(loader=DataLoader())
    inventory.parse_sources('localhost,')
    inventory.parse_sources('localhost,')


# Generated at 2022-06-24 19:58:10.301156
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # Assign the args to temporary variables
    args_0 = {}
    self_1 = InventoryManager()
    self_1.subset(args_0)
    try:
        self_2 = method_0(self_1)
    except:
        pass


# Generated at 2022-06-24 19:58:13.340303
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    print('Testing InventoryManager.subset()')
    var_0 = InventoryManager()
    var_1 = None
    var_0.subset(var_1)
    print('InventoryManager.subset() passed')


# Generated at 2022-06-24 19:58:24.157017
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    """
        Test case for get_hosts
    """

    bool_0 = False
    bool_1 = True
    test_case_0()
    test_Inventory_get_host_0()
    test_Inventory_get_host_1()
    test_Inventory_get_host_2()
    test_Inventory_get_host_3()
    test_match_0()
    test_match_1()

    # Get the data to use in the inventory.
    # This should be generated by the ansible-inventory command.
    plugin_data = {}
    plugin_data["localhost"] = ["group_1", "group_2"]
    plugin_data["127.0.0.1"] = ["group_2", "group_3"]

# Generated at 2022-06-24 19:58:28.635227
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    # String to test the method get_hosts of class InventoryManager
    var_0 = 'all'
    var_1 = True
    var_2 = False
    var_3 = None
    # Object of class InventoryManager
    object_0 = InventoryManager(var_1, var_2, var_3)
    # Test method get_hosts of class InventoryManager
    var_4 = object_0.get_hosts(var_0)
    # Test the results
    # Test if the output is of the correct class
    isinstance_0 = isinstance(var_4, list)


# Generated at 2022-06-24 19:58:36.029692
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():

    inventory_manager = InventoryManager()


    # Case 0
    bool_0 = False
    items_0 = [
        'ansible',
        False
    ]
    tuple_0 = (
        'ansible',
        False
    )
    host_0 = Host(name=tuple_0[0], port=22, variables=items_0[1])
    inventory_manager.add_group('all')
    result_0 = inventory_manager.parse_source(bool_0)

    assert result_0 == None
    assert host_0 in inventory_manager.groups['all'].get_hosts()


# Generated at 2022-06-24 19:58:38.482987
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    var_1 = InventoryManager()
    var_2 = False
    var_1.subset(var_2)
    var_2 = False
    var_1.subset(var_2)


# Generated at 2022-06-24 19:58:41.027672
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    manager = InventoryManager()
    manager.subset(u"ubuntu", group=u"test_group")
    assert manager._subset == [u"ubuntu"], "Manager's subset did not update properly"
