

# Generated at 2022-06-24 19:49:14.877636
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    str_0 = "ml$ p\x0bB5N|*'s\nR"
    inventory_manager_0 = InventoryManager(str_0)
    # Test with positional argument
    str_1 = "ml$ p\x0bB5N|*'s\nR"
    result_1 = inventory_manager_0.list_hosts(str_1)


# Generated at 2022-06-24 19:49:22.582113
# Unit test for function order_patterns
def test_order_patterns():
    '''
    def order_patterns(patterns):
        '''

    # These are all equivalent
    equals = [
        [ 'foo', '!bar', '!baz', 'qux' ],
        [ 'foo', '!baz', '!bar', 'qux' ],
        [ '!bar', 'qux', 'foo', '!baz' ],
        [ '!baz', '!bar', 'qux', 'foo' ],
        [ 'foo', '!bar', 'qux', '!baz' ],
    ]

    for p in equals:
        order_patterns(p)
        assert p == equals[0], "order was incorrect"


# Generated at 2022-06-24 19:49:26.116539
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    inv_path = os.path.join(os.path.dirname(__file__), '../../../lib/ansible/inventory/')
    pattern = 'all'
    expected_result = ['localhost']
    inventory_manager_0 = InventoryManager(inv_path)
    result = inventory_manager_0.list_hosts(pattern)
    assert result == expected_result


# Generated at 2022-06-24 19:49:34.342515
# Unit test for function split_host_pattern
def test_split_host_pattern():
    str_0 = "m\x0e"
    str_1 = "2\""
    str_2 = "\x0e\x0bS"
    str_3 = "l"
    str_4 = "l\x0c\x15\x0f\x0f\x0bS"
    str_5 = "l\x0c\x13\x0f\x10\x0bS"
    str_6 = "l\x0c\x12\x0f\x0e\x0bS"
    str_7 = "l\x0c\x14\x0f\x0f\x0bS"
    str_8 = "l\x0c\x18\x0f\x12\x0bS"

# Generated at 2022-06-24 19:49:37.973284
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    str_0 = "ml$ p\x0bB5N|*'s\nR"
    inventory_manager_0 = InventoryManager(str_0)
    r = inventory_manager_0.get_hosts()


# Generated at 2022-06-24 19:49:45.425765
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    try:
        b_pattern = to_bytes('/etc/ansible/hosts')
        b_pattern2 = to_bytes('/etc/ansible/hosts')
        inventory_manager_0 = InventoryManager(b_pattern)
        inventory_manager_0.subset(b_pattern2)
    except Exception as err:
        print(err)
        ret_0 = False
    else:
        ret_0 = True
    assert ret_0
    try:
        inventory_manager_1 = InventoryManager(u'\x00')
        inventory_manager_1.subset(u'\x00')
    except Exception as err:
        print(err)
        ret_1 = False
    else:
        ret_1 = True
    assert ret_1


# Generated at 2022-06-24 19:49:51.843856
# Unit test for function order_patterns
def test_order_patterns():
    print ("Unit test for order_patterns")
    try:
        order_patterns(['!', '!'])
        print ("[OK]   test_order_patterns")
    except Exception as e:
        print ("[ERROR]test_order_patterns")
        raise e


# Generated at 2022-06-24 19:49:56.537508
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    str_0 = "G|>\x1aP"
    inventory_manager_0 = InventoryManager(str_0)
    inventory_manager_0.subset("M\x1f")
    


# Generated at 2022-06-24 19:50:05.192490
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory_manager_1 = InventoryManager("ml$ p\x0bB5N|*'s\nR")
    source_inventory_1 = "ml$ p\x0bB5N|*'s\nR"
    config_inventory_1 = "ml$ p\x0bB5N|*'s\nR"
    vault_password_1 = "$6$Z1dQSlF/48Jq3X/a$yq/gogfukrNrNlxH1eZRWHfOg4p4KsHs9OboRktcT2bS.tEq3t.wZGMhEKvYwu"
    cache = False
    vault_password_file_1 = ""
    loader_1 = DataLoader()

# Generated at 2022-06-24 19:50:13.984562
# Unit test for method subset of class InventoryManager

# Generated at 2022-06-24 19:50:43.717494
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    pattern_0 = re.compile("N")
    ignore_limits_0 = True
    ignore_restrictions_0 = True
    order_0 = 'sorted'
    inventory_manager_0 = InventoryManager('ansible_0')
    result_0 = inventory_manager_0.get_hosts(pattern_0, ignore_limits_0, ignore_restrictions_0, order_0)
    assert isinstance(result_0, list)


# Generated at 2022-06-24 19:50:45.988759
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    inventory_manager_0 = InventoryManager('test/ansible/inventory')

    assert(inventory_manager_0.list_hosts() == ['localhost'])


# Generated at 2022-06-24 19:50:57.557901
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()

    inventory_manager_0 = InventoryManager(loader)
    inventory_manager_0.__class__.parse_source = lambda s, x, y: (Group('all'), Group('ungrouped'), [Host(name='localhost', port=None)])

    group_0 = Group('all')
    group_1 = Group('ungrouped')
    host_0 = Host(name='localhost', port=None)

    assert inventory_manager_0.parse_source('default') == (group_0, group_1, [host_0])


# Generated at 2022-06-24 19:51:04.298137
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    str_0 = "ml$ p\x0bB5N|*'s\nR"
    inventory_manager_0 = InventoryManager(str_0)


# Generated at 2022-06-24 19:51:08.275856
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    # Setup
    inventory_manager_0 = InventoryManager("~D?O|FFXGH8s")
    inventory_manager_0.clear_pattern_cache()

    # Test
    inventory_manager_0.get_hosts("C!Kjz?E_l[a\$:4Z~]")

    # Teardown
    display.display('.', log_only=True)


# Generated at 2022-06-24 19:51:18.670320
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    str_0 = "ml$ p\x0bB5N|*'s\nR"
    inventory_manager_0 = InventoryManager(str_0)
    str_1 = "ml$ p\x0bB5N|*'s\nR"
    str_2 = "ml$ p\x0bB5N|*'s\nR"
    str_3 = "ml$ p\x0bB5N|*'s\nR"
    # This call to method get_hosts of class InventoryManager is not needed.
    inventory_manager_0.get_hosts(str_1, str_2, str_3)
    str_4 = "ml$ p\x0bB5N|*'s\nR"

# Generated at 2022-06-24 19:51:27.755497
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    host_file_0 = "--inventory-file=/etc/ansible/hosts"
    str_0 = "ml$ p\x0bB5N|*'s\nR"
    group_vars_path_0 = "/etc/ansible/group_vars/all"
    vault_password_file_0 = "--vault-password-file=/etc/ansible/group_vars/all"
    inventory_manager_0 = InventoryManager(str_0)

    # Test case for method parse_source
    inventory_manager_0.parse_source(host_file_0, group_vars_path_0, vault_password_file_0)
    str_1 = "foo.example.com"
    str_2 = "s"
    host_file_1 = "../playbooks/inventory"


# Generated at 2022-06-24 19:51:32.762890
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    marker = object()
    # Create an instance of InventoryManager
    inventory_manager_0 = InventoryManager("a2!Mn")
    # '<string>' has type 'str'
    inventory_manager_0._parse_source("<string>", marker)


# Generated at 2022-06-24 19:51:41.076193
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory_manager_0 = InventoryManager('test')
    inventory_manager_0.inventory = Inventory(host_list=[])
    inventory_manager_0.vault_password = password

    inventory_manager_0._inventory.hosts = dict()
    for host in HOSTS:
        h = Host(host)
        h.set_variable('ansible_password',password)
        inventory_manager_0._inventory.hosts[host] = h

    groups = inventory_manager_0.groups

    inventory_manager_0.parse_source('test/units/ansible/inventory/test_inventory_manager_file', 'test-file')
    assert len(inventory_manager_0.groups) == len(groups) + 2
    assert inventory_manager_0.groups.get('atlanta') is not None
    assert inventory_manager_0

# Generated at 2022-06-24 19:51:48.583798
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    str_0 = "ml$ p\x0bB5N|*'s\nR"
    inventory_manager_0 = InventoryManager(str_0)
    inventory_manager_0.parse_source("'w\x1a\x03\x1a\x1e", None, "alv\x1c\x07\x1e\x12\r")


test_case_0()
test_InventoryManager_parse_source()

import logging
import unittest

from ansible.module_utils.six import PY3



# Generated at 2022-06-24 19:52:16.543698
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    # Test case 0
    kwargs_0 = {'pattern': 'all'}
    iM_0 = test_case_0()
    iM_0.list_hosts(**kwargs_0)


# Generated at 2022-06-24 19:52:21.159557
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    str_1 = 'vv'
    inventory_manager_1 = InventoryManager(str_1)
    inventory_manager_1.get_hosts(pattern = 'abc')


# Generated at 2022-06-24 19:52:25.556742
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
	# Setup data for testing
	str_0 = "ml$ p\x0bB5N|*'s\nR"
	hostname_0 = 'all'
	# Execute the SUT
	inventory_manager_0 = InventoryManager(str_0)
	hostname_1 = inventory_manager_0.list_hosts(hostname_0)
	# Verify test results
	assert type(hostname_1) is list


# Generated at 2022-06-24 19:52:30.956482
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    str_0 = "ml$ p\x0bB5N|*'s\nR"
    inventory_manager_0 = InventoryManager(str_0)
    str_1 = "|>\n)4"
    inventory_manager_0.subset(str_1)

    # Check if the exception has been risen
    did_catch_exception = False
    try:
        inventory_manager_0.subset(str_1)
    except:
        did_catch_exception = True
    assert did_catch_exception


# Generated at 2022-06-24 19:52:34.126107
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    pattern = sys.argv[1]
    inventory_manager_0 = InventoryManager()
    hosts = inventory_manager_0.get_hosts(pattern)

    print("Pattern: %s" % pattern)
    print("Output: ")
    print(hosts)


# Generated at 2022-06-24 19:52:41.603169
# Unit test for method parse_source of class InventoryManager

# Generated at 2022-06-24 19:52:44.956996
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory_manager_parse_source_0 = InventoryManager("inventory_manager_parse_source_0")
    str_0 = "inventory_manager_parse_source_0"
    inventory_manager_parse_source_1 = InventoryManager("inventory_manager_parse_source_1")
    list_0 = ["inventory_manager_parse_source_1"]
    p.parse_source(dict_0, list_0)


# Generated at 2022-06-24 19:52:46.005688
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    test_case_0()


# Generated at 2022-06-24 19:52:47.413208
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    try:
        test_case_0()
    except:
        print("test_case_0 failed")
        raise


# Generated at 2022-06-24 19:52:51.177504
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    str_0 = ":U6i\x0b\x0b~\x0b\x0b"
    inventory_manager_0 = InventoryManager(str_0)
    str_0 = "&a'ZP\x0b\x0bqr\x0b\x0b"
    bool_0 = inventory_manager_0.subset(str_0)


# Generated at 2022-06-24 19:53:33.090160
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory_manager_1 = InventoryManager("", "", "")
    inventory_manager_1.parse_source(None)


# Generated at 2022-06-24 19:53:41.442790
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    str_0 = "ml$ p\x0bB5N|*'s\nR"
    inventory_manager_0 = InventoryManager(str_0)
    subset_pattern_0 = "b\x017\x1c"
    inventory_manager_0._subset = subset_pattern_0
    subset_pattern_1 = "a"
    inventory_manager_0.subset(subset_pattern_1)


# Generated at 2022-06-24 19:53:45.538236
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    method = InventoryManager.get_hosts
    pattern_0 = "hostname"
    ignore_limits_0 = True
    ignore_restrictions_0 = False
    order_0 = 'sorted'
    inventory_manager_0 = InventoryManager('test')
    result = method(inventory_manager_0, pattern_0, ignore_limits_0, ignore_restrictions_0, order_0)


# Generated at 2022-06-24 19:53:56.474375
# Unit test for method list_hosts of class InventoryManager

# Generated at 2022-06-24 19:54:04.462611
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    str_1 = "ml$ p\x0bB5N|*'s\nR"
    inventory_manager_0 = InventoryManager(str_1)
    str_2 = "all"
    inventory_manager_0.list_groups()
    # ***Do not use str_3, it will make test case fail
    # str_3 = "ml$ p\x0bB5N|*'s\nR"
    # inventory_manager_0.subset(str_3)
    # inventory_manager_0.get_hosts(str_2)
    # inventory_manager_0.restrict_to_hosts(str_2)
    str_4 = "host_list"
    inventory_manager_0.remove_restriction()
    str_5 = "host_list"
    # inventory_manager

# Generated at 2022-06-24 19:54:12.535243
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    src_0 = 'localhost'
    inventory_manager_0 = InventoryManager(src_0)
    src_1 = 'ansible_connection=chroot'
    inventory_manager_1 = InventoryManager(src_1)
    src_2 = 'ansible_port=873'
    inventory_manager_2 = InventoryManager(src_2)
    src_3 = 'ansible_host=chroot://foo.bar/'
    inventory_manager_3 = InventoryManager(src_3)
    src_4 = 'ansible_user=root'
    inventory_manager_4 = InventoryManager(src_4)
    src_5 = 'ansible_ssh_pass=pass'
    inventory_manager_5 = InventoryManager(src_5)

# Generated at 2022-06-24 19:54:21.590023
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    str_0 = "ml$ p\x0bB5N|*'s\nR"
    inventory_manager_0 = InventoryManager(str_0)
    str_1 = "all"
    bool_0 = True
    bool_1 = True
    str_2 = None
    str_3 = inventory_manager_0.get_hosts(str_1, bool_0, bool_1, str_2)

    # AssertionError: Expected <str> to equal <str>
    # assert str_3==str_4
    return str_3


# Generated at 2022-06-24 19:54:25.437279
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    str_0 = "xJt\x0eT\r7r<"
    inventory_manager_0 = InventoryManager(str_0)
    pattern_0 = "all"
    assert inventory_manager_0.list_hosts(pattern_0) == []


# Generated at 2022-06-24 19:54:32.816853
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # inventory = InventoryManager("[hosts]\nhost0\nhost1")
    inventory = InventoryManager()
    # Test 1: the subset was not set.
    assert inventory.subset(None) is None
    # Test 2: the subset is set to one item.
    assert inventory.subset("[group1]") is not None
    # Test 3: the subset is set to multiple items.
    assert inventory.subset("[group1]\n[group2]") is not None


# Generated at 2022-06-24 19:54:42.951516
# Unit test for function split_host_pattern
def test_split_host_pattern():
    assert not split_host_pattern("")
    assert split_host_pattern("foo") == ["foo"]
    assert split_host_pattern("foo:") == ["foo:"]
    assert split_host_pattern("foo,[1]") == ["foo", "[1]"]
    assert split_host_pattern("foo,[1]:") == ["foo", "[1]:"]
    assert split_host_pattern("foo,[1]:bar") == ["foo", "[1]:bar"]
    assert split_host_pattern("foo:[1]:bar") == ["foo:[1]:bar"]
    assert split_host_pattern("foo::bar") == ["foo::bar"]
    assert split_host_pattern("foo::[1]:bar") == ["foo::[1]:bar"]

# Generated at 2022-06-24 19:55:01.490640
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager_0 = InventoryManager('test_case_0')
    try:
        inventory_manager_0.subset(str_0)
        assert False
    except AnsibleError:
        assert True

# Generated at 2022-06-24 19:55:05.132623
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # Test case
    InventoryManager0 = InventoryManager('res/ansible_inventory')
    InventoryManager0.subset("all")


# Generated at 2022-06-24 19:55:14.466828
# Unit test for method subset of class InventoryManager

# Generated at 2022-06-24 19:55:18.727403
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory_manager_0 = InventoryManager("localhost,")
    inventory_manager_0.parse_source("~`*/\x1c(\"#][@-#\x0c\x00~C\t", True)
    return


# Generated at 2022-06-24 19:55:25.262829
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    # Setup
    test_InventoryManager_list_hosts_pattern = "test_InventoryManager_list_hosts_pattern"

    # Exercise
    inventory_0 = InventoryManager(test_InventoryManager_list_hosts_pattern)
    result_0 = inventory_0.list_hosts()

    # Verify
    assert result_0 == []

    # Cleanup - none necessary


# Generated at 2022-06-24 19:55:32.415042
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    str_1 = "T\x0c\x17\x11\x0e\x0f\x04[ \x1b\x16\x1d\x1f\x07\x10\x1a\x1c\x0e\x10\x1a\x1c]"
    inventory_manager_1 = InventoryManager(str_1)
    str_2 = (
        "m<\x15\x0f\x16\x1d\x0f\x0e ,\x1e\x1a\x19\x16\x0e\x1d\x1f\x1e\x1d\x03\x02\x03\x02\x0e"
    )
    inventory_manager_1.subset(str_2)


# Generated at 2022-06-24 19:55:34.231433
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    str_0 = "ml$ p\x0bB5N|*'s\nR"
    inventory_manager_0 = InventoryManager(str_0)


# Generated at 2022-06-24 19:55:35.476947
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():
    inventory_manager_0 = InventoryManager()


# Generated at 2022-06-24 19:55:39.454103
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():
    str_0 = "ml$ p\x0bB5N|*'s\nR"
    inventory_manager_0 = InventoryManager(str_0)

    sources = ('hosts', '/etc/ansible/hosts')
    sources = to_text(sources)
    populate_inventory = None
    cache = False

    inventory_manager_0.parse_sources(sources, cache, populate_inventory)


# Generated at 2022-06-24 19:55:48.402271
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    global inventory_manager_0
    inventory_manager_0 = InventoryManager("ml$ p\x0bB5N|*'s\nR")
    str_0 = "ml$ p\x0bB5N|*'s\nR"
    str_1 = "ml$ p\x0bB5N|*'s\nR"
    boolean_0 = inventory_manager_0.get_hosts("ml$ p\x0bB5N|*'s\nR")
    boolean_1 = inventory_manager_0.get_hosts("ml$ p\x0bB5N|*'s\nR")


# Generated at 2022-06-24 19:56:04.383942
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager_0 = InventoryManager()

    subset_pattern = 'example'
    inventory_manager_0.subset(subset_pattern)


# Generated at 2022-06-24 19:56:08.280169
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    inventory_manager_0 = InventoryManager()
    inventory_manager_0.list_hosts()


# Generated at 2022-06-24 19:56:11.044171
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager_1 = InventoryManager()
    inventory_manager_1.subset('test')
    assert inventory_manager_1._subset == ['test']


# Generated at 2022-06-24 19:56:11.966214
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    test_case_0()


# Generated at 2022-06-24 19:56:13.872210
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    print('')
    ansible_test_0 = InventoryManager()
    result = ansible_test_0.subset('all')


# Generated at 2022-06-24 19:56:16.688600
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager_0 = InventoryManager()
    # Note: Testing invalid value for subset_pattern
    inventory_manager_0.subset("subset_pattern")


# Generated at 2022-06-24 19:56:20.420347
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory_manager = InventoryManager()
    assert isinstance(inventory_manager, InventoryManager)
    # Check the values of InventoryManager.parse_source
    inventory_manager.parse_source([".", "./playbooks/library"], "test_inventory_manager")
    assert isinstance(inventory_manager, InventoryManager)


# Generated at 2022-06-24 19:56:29.279452
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():

    inventory_manager = InventoryManager()

    # Test case 1:
    # load the test inventory file
    print("\n================================================================")
    print("Test case 1:\n")
    try:
        inventory_manager.load_inventory(inventory_path="./test/test_resources/test_inventory_1", loader=None)
    except AnsibleError as e:
        print("Failed loading test inventory file.\n")

    # Test get_hosts by pattern given in test case
    print("Expected: ['host1']\n")
    print("Actual: " + str(inventory_manager.get_hosts(pattern="host1")) + "\n")
    assert inventory_manager.get_hosts(pattern="host1") == ['host1']

# Generated at 2022-06-24 19:56:31.443845
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager_1 = InventoryManager()
    pattern = 'all'
    inventory_manager_1.subset(pattern)
    assert inventory_manager_1._subset == None


# Generated at 2022-06-24 19:56:35.324972
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    test_case_0()
    test_case_1()


# Generated at 2022-06-24 19:58:07.390324
# Unit test for function split_host_pattern
def test_split_host_pattern():
    assert ['a'] == split_host_pattern(u'a')
    assert ['a', 'b'] == split_host_pattern(u'a, b')
    assert ['a', 'b', 'c'] == split_host_pattern(u'a,b,c')
    assert ['a', 'b', 'c'] == split_host_pattern(u'a, b, c')
    assert ['a', 'b', 'c'] == split_host_pattern(u'a,  b,  c')
    assert ['a', 'b', 'c'] == split_host_pattern(u'a,\tb,\tc')
    assert ['a', 'b', 'c'] == split_host_pattern(u'a\t,b\t,c')
    assert ['a', 'b', 'c'] == split_host_

# Generated at 2022-06-24 19:58:12.357267
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory_manager_0 = InventoryManager()
    test_pattern_pattern="all"
    test_ignore_limits_ignore_limits="False"
    test_ignore_restrictions_ignore_restrictions="False"
    test_order_order="None"
    result_result = inventory_manager_0.get_hosts(test_pattern_pattern,test_ignore_limits_ignore_limits,test_ignore_restrictions_ignore_restrictions,test_order_order)
    return result_result


# Generated at 2022-06-24 19:58:14.697936
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    # FIXME: change this test to something that works, this seems to be a duplicate
    # of Inventory.parse
    inventory = Inventory(host_list=[])
    inventory_manager = InventoryManager(inventory)
    inventory_manager.parse_sources()


# Generated at 2022-06-24 19:58:19.378406
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():
    inventory_manager_1 = InventoryManager()
    inventory_manager_1.parse_sources()
    assert len(inventory_manager_1._inventory.hosts.keys()) > 0


# Generated at 2022-06-24 19:58:19.940073
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    pass


# Generated at 2022-06-24 19:58:28.160447
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    #test case 1
    inventory_manager_1 = InventoryManager()
    inventory_manager_1.subset(['all'])
    assert inventory_manager_1._subset is not None
    assert len(inventory_manager_1._subset) == 1
    assert inventory_manager_1._subset[0] == 'all'
    print("SUCCESS: test_InventoryManager_subset test case 1 passed")

    #test case 2
    inventory_manager_2 = InventoryManager()
    inventory_manager_2.subset(['host1'])
    assert inventory_manager_2._subset is not None
    assert len(inventory_manager_2._subset) == 1
    assert inventory_manager_2._subset[0] == 'host1'

# Generated at 2022-06-24 19:58:37.204310
# Unit test for function split_host_pattern
def test_split_host_pattern():
    assert split_host_pattern('a, b, c') == ['a', 'b', 'c']
    assert split_host_pattern('a,b,c') == ['a', 'b', 'c']
    assert split_host_pattern('a,b,c,') == ['a', 'b', 'c']
    assert split_host_pattern(' a , b , c ') == ['a', 'b', 'c']
    assert split_host_pattern('[a]:1, [b]:2') == ['[a]:1', '[b]:2']
    assert split_host_pattern('[a]:1,[b]:2') == ['[a]:1', '[b]:2']
    assert split_host_pattern('[a]:1,[b]:2,') == ['[a]:1', '[b]:2']
    assert split_host

# Generated at 2022-06-24 19:58:38.343880
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    inventory_manager = InventoryManager()
    assert inventory_manager.list_hosts() == []

# Generated at 2022-06-24 19:58:44.252728
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():
    inventory_manager_1 = InventoryManager()
    inventory_manager_1.parse_sources('static;nested2;yaml_jinja2')
    inventory_manager_1.parse_sources('static,nested2,yaml_jinja2')
    inventory_manager_1.parse_sources('static')
    inventory_manager_1.parse_sources(['static','nested2','yaml_jinja2'])

test_case_0()
test_InventoryManager_parse_sources()