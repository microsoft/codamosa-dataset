

# Generated at 2022-06-24 19:49:51.844689
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    result = InventoryManager._parse_source("8.39")
    assert result == "8.39"
    result = InventoryManager._parse_source("9.63")
    assert result == "9.63"
    result = InventoryManager._parse_source("8.87")
    assert result == "8.87"
    result = InventoryManager._parse_source("2.78")
    assert result == "2.78"
    result = InventoryManager._parse_source("8.75")
    assert result == "8.75"
    result = InventoryManager._parse_source("0.57")
    assert result == "0.57"
    result = InventoryManager._parse_source("7.48")
    assert result == "7.48"
    result = InventoryManager._parse_source("5.20")
    assert result == "5.20"

# Generated at 2022-06-24 19:49:58.173606
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    float_0 = 1886.0
    inventory_manager_0 = InventoryManager(float_0)
    str_0 = '/home/jmcasey/projects/internal/ansible/v2/lib/ansible/inventory/ini.py'
    str_1 = '/home/jmcasey/projects/internal/ansible/v2/lib/ansible/inventory/script.py'
    str_2 = '/home/jmcasey/projects/internal/ansible/v2/lib/ansible/inventory/yaml.py'
    str_3 = '/home/jmcasey/projects/internal/ansible/v2/lib/ansible/inventory/dir.py'
    str_4 = '/home/jmcasey/projects/internal/ansible/v2/lib/ansible/inventory/auto.py'

# Generated at 2022-06-24 19:50:01.189896
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    hosts = [u'localhost']
    groups = dict()
    vars = dict()
    vars[u'ansible_ssh_host'] = u'localhost'
    vars[u'ansible_ssh_port'] = u'2222'
    inventory_manager_0 = InventoryManager(hosts, groups, vars)
    host = u"localhost"
    src = u"localhost"
    result = inventory_manager_0.parse_source(host, src)
    assert result is None


# Generated at 2022-06-24 19:50:04.791218
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # input parameter is of type float
    float_0 = float(0)
    inventory_manager_0 = InventoryManager(float_0)
    pattern='host1,host2'

    # call method
    inventory_manager_0.subset(pattern)


# Generated at 2022-06-24 19:50:10.939826
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    float_1 = 1841.0
    inventory_manager_1 = InventoryManager(float_1)
    str_1 = 'all'
    bool_1 = False
    bool_2 = True
    str_2 = 'sorted'
    inventory_manager_1.get_hosts(str_1, bool_1, bool_2, str_2)


# Generated at 2022-06-24 19:50:13.103376
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    int_0 = 1296
    inventory_manager_1 = InventoryManager(int_0)
    str_0 = 'foo'
    inventory_manager_1.subset(str_0)


# Generated at 2022-06-24 19:50:16.593921
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    float_0 = 1886.0
    inventory_manager_0 = InventoryManager(float_0)
    ignore_limits_0 = True
    ignore_restrictions_0 = True
    order_0 = 'reverse_sorted'
    # result is class 'list'
    result_0 = inventory_manager_0.get_hosts(ignore_limits_0, ignore_restrictions_0, order_0)


# Generated at 2022-06-24 19:50:17.728401
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    float_0 = 186.0
    inventory_manager_0 = InventoryManager(float_0)


# Generated at 2022-06-24 19:50:19.785558
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    pass


# Generated at 2022-06-24 19:50:22.182295
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    inventory_manager_1 = InventoryManager()
    result_0 = inventory_manager_1.list_hosts()
    assert result_0 == []


# Generated at 2022-06-24 19:50:44.037674
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    # First create an instance of the class
    inventory_manager_0 = InventoryManager(C.DEFAULT_HOST_LIST)
    # Now run the code with different input values
    # FIXME: Add test cases here
    #inventory_manager_0.parse_source()


# Generated at 2022-06-24 19:50:48.712600
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    hosts = dict(all=dict(hosts=dict(foo=dict(vars=dict(ansible_host='127.0.0.1')))))
    inventory = InventoryManager(hosts).inventory
    host = inventory.get_host('foo')
    assert host.vars['ansible_host'] == '127.0.0.1'


# Generated at 2022-06-24 19:50:55.240607
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory_manager_0 = InventoryManager()
    source_0 = get_test_config('tree/hosts')
    config_options_0 = {}
    # Calling method parse_source of inventory_manager_0 object
    result_0 = inventory_manager_0.parse_source(source_0, config_options_0)
    # Comparing actual and expected output
    assert result_0 == {}, "test_InventoryManager_parse_source failed"


# Generated at 2022-06-24 19:50:57.138554
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    obj = InventoryManager()
    try:
        obj.subset()
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-24 19:51:03.013271
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    float_0 = 1.0
    inventory_manager_0 = InventoryManager(float_0)
    float_1 = float_0
    inventory_manager_0.subset(float_1)


# Generated at 2022-06-24 19:51:05.816137
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager_0 = InventoryManager(float_0)
    float_0 = 1886.0
    inventory_manager_0 = InventoryManager(float_0)
    str_0 = 'foo'
    test_result = inventory_manager_0.subset(str_0)
    assert test_result is None


# Generated at 2022-06-24 19:51:17.476135
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory_manager_0 = InventoryManager()
    inventory_manager_0.set_inventory(inventory_manager_0._inventory)

    inventory_manager_0.clear_pattern_cache()

    try:
        inventory_manager_0.parse_source(None)
    except TypeError:
        pass
    else:
        assert(False)

    inventory_manager_0.parse_source("test_hostname=localhost")
    inventory_manager_0.parse_source(None)
    inventory_manager_0.parse_source("localhost")
    inventory_manager_0.parse_source("*")
    try:
        inventory_manager_0.parse_source("test_hostname=localhost", groups=None)
    except TypeError:
        pass
    else:
        assert(False)



# Generated at 2022-06-24 19:51:26.572421
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():

    # create an instance of the class
    inventory_manager_0 = InventoryManager(None, None)

    # create mock object
    data = MagicMock()

    # assign all parameters as attributes of the mock object
    moved = {}
    data.__setitem__ = MagicMock(side_effect = lambda name, value: moved.__setitem__(name, value))
    data.__getitem__ = MagicMock(side_effect = lambda name: moved.__getitem__(name))
    data.__delitem__ = MagicMock(side_effect = lambda name: moved.__delitem__(name))

    # call method
    result = inventory_manager_0.parse_source(data)
    assert result is None

    # check if test was called as expected
    data.__setitem__.assert_not_called()
   

# Generated at 2022-06-24 19:51:28.520058
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory_manager_0 = InventoryManager("./inventory")
    inventory_manager_0.get_hosts(inventory = "./inventory")


# Generated at 2022-06-24 19:51:38.839998
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    float_0 = 1886.0
    inventory_manager_0 = InventoryManager(float_0)
    inventory_manager_0._inventory = Mock()
    inventory_manager_0._hosts_patterns_cache = {}
    subset_pattern_0 = 'dev-wms-sec'
    inventory_manager_0.subset(subset_pattern_0)
    subset_pattern_1 = 'prod-wms-sec'
    inventory_manager_0.subset(subset_pattern_1)
    subset_pattern_2 = 'prod-wms-sec'
    inventory_manager_0.subset(subset_pattern_2)
    subset_pattern_3 = 'dev-wms-sec'
    inventory_manager_0.subset(subset_pattern_3)

# Generated at 2022-06-24 19:52:02.655783
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    float_0 = 1861.0
    inventory_manager_0 = InventoryManager(float_0)
    assert inventory_manager_0 != None


# Generated at 2022-06-24 19:52:04.506109
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager_0 = InventoryManager(0.0)
    inventory_manager_0.subset('foo')


# Generated at 2022-06-24 19:52:10.227015
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    set_0 = set()
    # "None" is a test case for list_hosts of class InventoryManager
    set_0.add(None)
    # "red" is a test case for list_hosts of class InventoryManager
    set_0.add("red")
    inventory_manager_0 = InventoryManager(set_0)
    # Test case for method list_hosts of class InventoryManager
    assert inventory_manager_0.list_hosts() == []

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 19:52:14.275525
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # Creating InventoryManager instance
    inventory_manager_0 = InventoryManager(host_list)

    # Calling method subset of skeleton InventoryManager
    subset = [hosts]
    inventory_manager_0.subset(subset_pattern = subset)


# Generated at 2022-06-24 19:52:19.629795
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    # create an instance of the class InventoryManager and call the method list_hosts
    inventory_manager_0 = InventoryManager(inventory_path=None)
    inventory_manager_0.set_inventory(inventory=None)
    result = inventory_manager_0.list_hosts()
    assert type(result) is list


# Generated at 2022-06-24 19:52:29.283749
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    float_0 = 4281.0
    inventory_manager_0 = InventoryManager(float_0)
    str_0 = 'foo:bar:baz'
    str_1 = ' :'
    # Method parse_source called with 1 parameters
    # parse_source called with 3 parameters
    # str.split called with 1 parameters
    # list.__getitem__ called with 2 parameters
    # len called with 1 parameters
    # len called with 1 parameters
    # len called with 1 parameters
    # len called with 1 parameters
    # len called with 1 parameters
    # len called with 1 parameters
    # len called with 1 parameters
    # len called with 1 parameters
    # len called with 1 parameters
    # len called with 1 parameters
    # len called with 1 parameters
    # len called with 1 parameters
    # len called with 1 parameters
    # len

# Generated at 2022-06-24 19:52:32.793852
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    # test get_hosts
    float_0 = 1886.0
    inventory_manager_0 = InventoryManager(float_0)
    pattern_0 = "all"
    ignore_limits_0 = False
    ignore_restrictions_0 = False
    order_0 = None
    result_0 = inventory_manager_0.get_hosts(pattern_0, ignore_limits_0, ignore_restrictions_0, order_0)


# Generated at 2022-06-24 19:52:34.839181
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory_manager_0 = InventoryManager(None)
    inventory_manager_0.parse_source(None, None, None)


# Generated at 2022-06-24 19:52:41.280475
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    float_0 = 1539.8546594285
    inventory_manager_0 = InventoryManager(float_0)
    # parameter subset_pattern is a string
    subset_pattern_0 = "71~f?d`3qm4`:j^w"
    inventory_manager_0.subset(subset_pattern_0)


# Generated at 2022-06-24 19:52:49.237156
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    from ansible.utils.shlex import shlex_split

    float_0 = 1886.0
    inventory_manager_0 = InventoryManager(float_0)
    str_0 = "."
    str_1 = "^"
    str_2 = "^9"
    str_3 = "^8"
    str_4 = "^7"
    str_5 = "^6"
    str_6 = "^5"

# Generated at 2022-06-24 19:53:33.795394
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    float_0 = 0.8
    inventory_manager_0 = InventoryManager(float_0)
    subset_pattern_0 = "restriction"
    inventory_manager_0.subset(subset_pattern_0)


# Generated at 2022-06-24 19:53:40.510425
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    float_0 = float()
    inventory_manager_0 = InventoryManager(float_0)
    dict_0 = dict()
    dict_1 = dict()
    dict_1[u'file'] = 0
    dict_0[u'data'] = dict_1
    dict_0[u'path'] = u'string'
    dict_0[u'host_list'] = u'string'
    dict_0[u'groups'] = dict()
    dict_0[u'hosts'] = dict()
    return inventory_manager_0.parse_source(dict_0)


# Generated at 2022-06-24 19:53:47.677350
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    """
    Tests if the method get_hosts of class InventoryManager is working properly
    """
    float_0 = 1886.0
    inventory_manager_0 = InventoryManager(float_0)
    # test if the method get_hosts works as expected
    assert 'test_' == inventory_manager_0.get_hosts('test_')


# Generated at 2022-06-24 19:53:53.506604
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    float_0 = 1660.0
    inventory_manager_0 = InventoryManager(float_0)
    subset_pattern = "foo.example.com"
    inventory_manager_0.subset(subset_pattern)
    assert inventory_manager_0 is not None


# Generated at 2022-06-24 19:53:56.771526
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    # FIXME: how to get proper type information?
    # FIXME: we need a real test here
    inventory_manager_0 = InventoryManager(Host(''))
    assert isinstance(inventory_manager_0.get_hosts(), list), "Expected 'get_hosts()' to return a list"


# Generated at 2022-06-24 19:54:00.012500
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    string_0 = 'Could not load inventory source with script plugin'
    string_1 = 'files'
    string_2 = 'files'
    integer_0 = -403928277
    double_0 = 0.39189705000501586
    # Nothing to test


# Generated at 2022-06-24 19:54:00.785145
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    pass


# Generated at 2022-06-24 19:54:07.922342
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    float_0 = 1886.0
    inventory_manager_0 = InventoryManager(float_0)
    subset_pattern_0 = 'all'
    inventory_manager_0.subset(subset_pattern_0)
    subset_pattern_0 = ''
    inventory_manager_0.subset(subset_pattern_0)


# Generated at 2022-06-24 19:54:11.424659
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager_0 = InventoryManager()
    inventory_manager_0.subset(None)


# Generated at 2022-06-24 19:54:18.486356
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    from test.unit.inventory_manager import test_data

    inv_manager = test_data.get_fake_inv_manager()
    subset_patterns = ['all', 'foo:bar[1:3]', 'foo[1:3]']
    inv_manager.subset(subset_patterns)
    exp = subset_patterns[1:]
    assert inv_manager._subset == exp

# Generated at 2022-06-24 19:54:30.320995
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():
    # TODO: missing test case
    pass


# Generated at 2022-06-24 19:54:40.850695
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():
    template_0 = tempfile.NamedTemporaryFile(delete=False)
    template_0.close()
    template_1 = tempfile.NamedTemporaryFile(delete=False)
    template_1.close()

    # Create inventory file
    inv_contents_0 = "[all:vars]\nfoo=bar\n"
    inv_contents_1 = "[all:vars]\nbar=baz\n"
    inv_contents_2 = "[all:vars]\nfoo=baz\n"
    inv_0 = tempfile.NamedTemporaryFile(delete=False)
    inv_0.write(inv_contents_0.encode('utf-8'))
    inv_0.close()
    inv_1 = tempfile.NamedTemporaryFile(delete=False)

# Generated at 2022-06-24 19:54:45.125125
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager_obj = InventoryManager()
    subset_pattern = None
    inventory_manager_obj.subset(subset_pattern)


# Generated at 2022-06-24 19:54:51.827520
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    pattern = u'all'
    p1 = b'subset_pattern'
    if isinstance(subset_pattern, binary_type):
        subset_pattern = to_text(subset_pattern)

    pattern = re.sub(u'\[(.*?)\]', u'', pattern)
    (expr, slice) = self._split_subscript(pattern)
    hosts = self._enumerate_matches(expr)
    return self._apply_subscript(hosts, slice)


# Generated at 2022-06-24 19:54:53.550052
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    # Setup
    inventory = InventoryManager(loader=None, sources=None)
    test_pattern = 'all'
    inventory.list_hosts(test_pattern)


# Generated at 2022-06-24 19:54:54.555945
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    i = InventoryManager()
    i.subset(['foo'])


# Generated at 2022-06-24 19:55:00.635951
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    # Test when source is a list
    source_list = ['192.0.2.1,192.0.2.2']
    im = InventoryManager(loader=None, sources=source_list)
    res = im.parse_source('192.0.2.1,192.0.2.2')
    assert res == set(['192.0.2.1', '192.0.2.2'])

    # Test when source is a string
    im = InventoryManager(loader=None, sources='192.0.2.1,192.0.2.2')
    res = im.parse_source('192.0.2.1,192.0.2.2')
    assert res == set(['192.0.2.1', '192.0.2.2'])

# Generated at 2022-06-24 19:55:01.863726
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    # TODO: update tests when inventory plugin is used
    pass


# Generated at 2022-06-24 19:55:07.119702
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    set_0 = set()
    var_0 = split_host_pattern(set_0)
    set_1 = set()
    var_1 = InventoryManager(set_1, set_1)
    var_2 = var_1.subset(set_0)


# Generated at 2022-06-24 19:55:09.920738
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    inventory = Inventory("test/test_hosts")

    manager = InventoryManager(inventory)

    # FIXME: add a test case
    InventoryManager.list_hosts()



# Generated at 2022-06-24 19:55:25.639250
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    inventory_manager_obj = InventoryManager()
    ansible_inventory_obj = ansible_inventory.Inventory()
    inventory_manager_obj.set_inventory(ansible_inventory_obj)
    pattern = "all"
    result = inventory_manager_obj.list_hosts(pattern)
    assert result == []


# Generated at 2022-06-24 19:55:32.623558
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():
    import unittest
    import os.path
    from io import StringIO
    TEST_INVENTORY = """
# comment
[unix:children]
bsd
debian
linux

[bsd]
freebsd
openbsd

[debian]
debian1
debian2

[linux]
linux1
linux2

[unix:vars]
ansible_ssh_user=root

[ungrouped]
localhost
"""
    host_vars_dir = os.path.join(os.path.dirname(__file__), 'data')

    class TestInventoryManager(unittest.TestCase):
        def test_inventory_manager_parse_sources(self):
            inventory = InventoryManager(host_vars_dir=host_vars_dir)
            inventory.parse_sources

# Generated at 2022-06-24 19:55:35.014337
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # prepare arguments
    subset_pattern = None
    # Call method
    InventoryManager().subset(subset_pattern)


# Generated at 2022-06-24 19:55:41.391157
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inv_path = C.DEFAULT_HOST_LIST

    if not os.path.exists(inv_path):
        raise AnsibleError("Inventory file not found: %s" % inv_path)
    if not os.path.isfile(inv_path):
        raise AnsibleError("Inventory directory not found: %s" % inv_path)

    b_inventory_filename = to_bytes(inv_path, errors='surrogate_or_strict')

    inventory = InventoryManager(loader=C.DEFAULT_LOADER, sources=b_inventory_filename)
    inventory.subset(None)
    inventory.subset(['bad_value'])


# Generated at 2022-06-24 19:55:48.600453
# Unit test for method parse_source of class InventoryManager

# Generated at 2022-06-24 19:55:52.082410
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # Initialize test object
    inventory = InventoryManager()

    # Test subset method
    inventory.subset(None)


# Generated at 2022-06-24 19:55:57.383158
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    var_mgr = VariableManager()
    inventory = InventoryManager(loader=loader, sources="inventory/hosts")
    subset_pattern = "all"
    var_mgr.add_inventory(inventory)
    i_mgr = PlaybookExecutor(loader=loader, inventory=inventory, variable_manager=var_mgr, loader_basedir="")
    hosts = i_mgr.get_hosts(pattern=subset_pattern)

    hosts = i_mgr.get_hosts(pattern=subset_pattern)
    assert hosts == []


# Generated at 2022-06-24 19:56:06.119428
# Unit test for method parse_source of class InventoryManager

# Generated at 2022-06-24 19:56:14.433207
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    # Set up test inventory
    inv = InventoryManager(inventory='hosts')
    inv.parse_inventory(host_list=['foo', 'bar', 'baz'])

    # Test all hosts
    inv.subset(['all'])
    assert len(inv.get_hosts('all')) == 3
    assert inv.get_hosts('all') == ['foo', 'bar', 'baz']

    # Test single host
    assert inv.get_hosts('foo') == ['foo']

    # Test single host by UUID
    assert inv.get_hosts(inv.get_host('foo').get_uuid()) == ['foo']

    # Test multiple hosts
    assert inv.get_hosts(['foo', 'bar', 'baz']) == ['foo', 'bar', 'baz']

    # Test multiple

# Generated at 2022-06-24 19:56:17.299097
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    inventory_manager = InventoryManager()
    pattern = "all"
    result = inventory_manager.list_hosts(pattern)
    print(result)


# Generated at 2022-06-24 19:56:39.997156
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    set_0 = set()
    f = StringIO()
    print(str(set_0), file=f)
    f.seek(0)
    var_0 = InventoryManager.parse_source(f)

if __name__ == "__main__":
    test_case_0()
    test_InventoryManager_parse_source()

# Generated at 2022-06-24 19:56:50.476052
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    """
    Ensure we can list hosts given a pattern and a subset restriction
    """
    mgr = InventoryManager(loader=DataLoader(), sources='localhost,')
    assert mgr.list_hosts() == ["localhost"]
    mgr = InventoryManager(loader=DataLoader(), sources='localhost,')
    assert mgr.list_hosts("all") == ["localhost"]
    mgr = InventoryManager(loader=DataLoader(), sources='localhost,')
    assert mgr.list_hosts("") == []
    mgr = InventoryManager(loader=DataLoader(), sources='localhost,')
    assert mgr.list_hosts("*") == ["localhost"]
    mgr = InventoryManager(loader=DataLoader(), sources='localhost,')
    mgr.subset("all")
    assert mgr.list_hosts("") == ["localhost"]


# Generated at 2022-06-24 19:56:53.977339
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    set_0 = set()
    var_1 = InventoryManager()
    var_2 = var_1.list_hosts()
    var_3 = var_1.list_hosts(set_0)
    var_4 = var_1.list_hosts(set_0)
    var_5 = var_1.list_groups()


# Generated at 2022-06-24 19:56:59.294594
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory_manager = InventoryManager()
    try:
        inventory_manager.parse_source('all', 'localhost', 'ansible_connection=local')
    except SystemExit as exception:
        if exception.code == 0:
            pass  # Expected, do nothing
        else:
            raise  # Unexpected


# Generated at 2022-06-24 19:57:07.980689
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    hosts_0 = {}
    groups_0 = {}
    inventory_0 = Inventory(hosts_0, groups_0)
    inventory_0._vars = {}
    sources_0 = None
    vault_password_0 = 'W_As8i'
    loader_0 = DataLoader()

    # the real inventory_manager call will not be done until later
    # because we are using a getter object for the inventory, but
    # calling the .get() method should fail as we have not
    # supplied any valid sources
    inventory_manager = InventoryManager(loader_0, vault_password_0)
    inventory_manager.add_group('all')
    for hostname in loader_0.get_basedir('/opt/ansible'):
        inventory_manager.add_host(hostname, group='all')

    # build the

# Generated at 2022-06-24 19:57:10.901779
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    pattern = "all"
    var_0 = InventoryManager(pattern)
    var_1 = var_0.list_hosts()
    var_2 = var_0.list_hosts(pattern)



# Generated at 2022-06-24 19:57:14.214725
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():

    obj = InventoryManager()

    str_0 = "all"
    bool_0 = True
    bool_1 = True
    str_1 = "all"
    # Call method get_hosts of InventoryManager
    result = obj.get_hosts(str_0, bool_0, bool_1, str_1)


# Generated at 2022-06-24 19:57:19.832306
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    inm = InventoryManager(None)
    inm.list_hosts("localhost")
    inm.list_hosts(u"localhost")
    inm.list_hosts(None)


# Generated at 2022-06-24 19:57:22.485061
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    inv = InventoryManager(Loader())
    inv.clear_pattern_cache()
    host_patterns = []
    ret = inv.list_hosts(host_patterns)
    assert ret is None


# Generated at 2022-06-24 19:57:25.113337
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory_manager_0 = InventoryManager(host_list=None)

    inventory_manager_0.get_hosts(pattern="all", ignore_limits=False, ignore_restrictions=False, order=None)



# Generated at 2022-06-24 19:58:03.319272
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    # Test with source = 'A:\ansible\test_cases\test_case_0.yml'
    # set_0 = set()
    # var_0 = split_host_pattern(set_0)
    # var_1 = var_0.next()
    # var_2 = InventoryManager()
    # var_3 = var_2.parse_source('A:\ansible\test_cases\test_case_0.yml', var_1)
    assert True


# Generated at 2022-06-24 19:58:08.790892
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    print("\n*** test_InventoryManager_get_hosts: START ***\n")
    host_pattern = 'all'
    ignore_limits = False
    ignore_restrictions = False
    order = None
    InventoryManager = InventoryManager()
    InventoryManager.get_hosts(host_pattern, ignore_limits, ignore_restrictions, order)
    print("\n*** test_InventoryManager_get_hosts: END ***\n")


# Generated at 2022-06-24 19:58:13.718654
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # Test that calling subset causes the subset to be cached and the cache size to be incremented.
    i = InventoryManager(host_list=[])
    assert i._subset is None
    assert i._subset_cache_size == 0

    i.subset('test_subset')
    assert i._subset is not None
    assert i._subset_cache_size == 1


# Generated at 2022-06-24 19:58:23.830597
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    '''
    # Parse source into host patterns and generate inventory
    '''
    host_list = ['foo1', 'foo2', 'bar1', 'bar2']
    # Parse source into host patterns and generate inventory
    im = InventoryManager(loader(), sources=['localhost, foo[1:2]', 'localhost, bar[1:2]'])
    test_result = im.patterns_cache
    expected_result = {'bar[1:2]': 'bar1,bar2', 'localhost, foo[1:2]': 'foo1,foo2', 'localhost, bar[1:2]': 'bar1,bar2', 'foo[1:2]': 'foo1,foo2'}

    assert test_result == expected_result


# Generated at 2022-06-24 19:58:25.999423
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    myInventoryManager = InventoryManager()
    var_0 = InventoryManager.parse_source
    var_0(myInventoryManager, inventory_data = None, filename = None)
    var_0(myInventoryManager, inventory_data = None, filename = None, cache = None)


# Generated at 2022-06-24 19:58:30.690318
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory = Inventory(loader=DummyLoader())
    manager = InventoryManager(inventory)
    assert manager.parse_sources(['host1', 'host2']) == 2
    assert manager.parse_sources('host1,host2') == 2
    assert manager.parse_sources(['host1:host2']) == 1
    assert manager.parse_sources({ 'hosts': ['host1', 'host2'] }) == 1
    assert manager.parse_sources({ 'multihost': ['host1:host2', 'host3:host4'] }) == 1
    assert manager.parse_sources('file1') == 1
    assert manager.parse_sources('file1,host1') == 2
    assert manager.parse_sources(['file1,host1']) == 2

# Generated at 2022-06-24 19:58:33.162777
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    var_0 = InventoryManager(None)
    var_1 = None
    var_2 = var_0.list_hosts(var_1)
    assert var_2 is not None


# Generated at 2022-06-24 19:58:41.973076
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    #subset_pattern = None
    #subset_pattern = ""
    #subset_pattern = "all"
    #subset_pattern = "group1"
    #subset_pattern = "group[1-9]"
    #subset_pattern = "host1"
    subset_pattern = "host[1-9]"
    #subset_pattern = "@group1"
    #subset_pattern = "@group[1-9]"
    #subset_pattern = "@host1"
    #subset_pattern = "@host[1-9]"

    inventory = InventoryManager(loader=None, sources=subset_pattern)
    subset = inventory.subset(subset_pattern)
    print("subset=%s" % subset)
