

# Generated at 2022-06-24 19:49:37.927316
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    # get_hosts: Takes a pattern or list of patterns and returns a list of matching inventory host names, taking into account any active restrictions or applied subsets
    # 
    # Try simple case
    list_0 = []
    inventory_manager_0 = InventoryManager(list_0)
    str_0 = "all"
    assert inventory_manager_0.get_hosts(str_0) == []
    # Try simple case
    list_0 = []
    inventory_manager_0 = InventoryManager(list_0)
    str_0 = "all"
    assert inventory_manager_0.get_hosts(str_0) == []
    # Try simple case
    list_0 = []
    inventory_manager_0 = InventoryManager(list_0)
    str_0 = "all"
    assert inventory_manager_0.get

# Generated at 2022-06-24 19:49:46.768714
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    global test_inventory_dir

    list_1 = [[1, 'test_inventory', [['test_config_dir', 'relative'], [2, 'test_hosts_file']]],
              [1, 'test_inventory', [['test_config_dir', 'relative'], [2, 'test_hosts_file']]]]
    inventory_manager_1 = InventoryManager(list_1)

    # Test case 0
    test_config_dir = '/test_config_dir'
    test_hosts_file = 'test_hosts_file'
    inventory_manager_1._inventory_loader.set_options('ansible_config_path', test_config_dir)
    inventory_manager_1._inventory_loader.set_options('host_file', test_hosts_file)
    inventory_manager_1.clear

# Generated at 2022-06-24 19:49:54.902898
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    # Root cause: if isinstance(args.inventory or [], list) returns False.
    list_1 = simplejson.dumps({u'ansible_ssh_host': u'10.0.2.2', u'ansible_ssh_port': u'22', u'myvar': [u'bar'], u'ansible_ssh_pass': u'passw0rd', u'ansible_ssh_user': u'vagrant'})
    inventory_manager_1 = InventoryManager(list_1)
    inventory_manager_1._parse_source(list_1)


# Generated at 2022-06-24 19:50:00.553897
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    inventory_manager_0 = InventoryManager(None)
    pattern_0 = "www[1:10].example.org"
    result = inventory_manager_0.list_hosts(pattern_0)
    assert len(result) == 10
    assert result[0] == 'www1.example.org'
    assert result[5] == 'www6.example.org'
    assert result[9] == 'www10.example.org'


# Generated at 2022-06-24 19:50:03.660066
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    filename = "inventory-s014"
    inventory_manager_0 = InventoryManager(filename)
    destination = inventory_manager_0.parse_source("inventory", filename)
    assert destination == "inventory"

# Test case for class InventoryManager
# Test case for method put_host

# Generated at 2022-06-24 19:50:06.376583
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():
    list_0 = []
    inventory_manager_0 = InventoryManager(list_0)
    pattern_0 = 'all'
    # No exception raised
    inventory_manager_0.parse_sources(pattern_0)


# Generated at 2022-06-24 19:50:08.466652
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    # Create object
    list_1 = []
    inventory_manager_1 = InventoryManager(list_1)

    assert isinstance(inventory_manager_1.get_hosts(), list)


# Generated at 2022-06-24 19:50:20.113487
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    list_0 = []
    inventory_manager_0 = InventoryManager(list_0)
    # Test for the following cases:
    #  get_hosts()
    #  get_hosts(pattern='all')
    #  get_hosts(pattern=[])
    #  get_hosts(ignore_limits=False, ignore_restrictions=False)
    #  get_hosts(pattern='all', ignore_limits=False, ignore_restrictions=False)
    #  get_hosts(pattern=[], ignore_limits=False, ignore_restrictions=False)
    #  get_hosts(ignore_limits=True, ignore_restrictions=True)
    #  get_hosts(pattern='all', ignore_limits=True, ignore_restrictions=True)
    #  get_hosts(

# Generated at 2022-06-24 19:50:21.584462
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    test_case_0()
    test_case_1()


# Generated at 2022-06-24 19:50:26.642171
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory = InventoryManager.from_file(C.INVENTORY_PATH)
    for subset_pattern in ['all', 'some_pattern', 'another_pattern']:
        inventory.subset(subset_pattern)



# Generated at 2022-06-24 19:50:49.219193
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    # Print output of test case
    print("### unit test for method InventoryManager.get_hosts ###")
    list_0 = []
    inventory_manager_0 = InventoryManager(list_0)
    list_1 = ['all']
    host_pattern = 'all'
    ignore_limits = False
    ignore_restrictions = False
    order = None
    print("hosts: {hosts}".format(hosts=inventory_manager_0.get_hosts(host_pattern, ignore_limits, ignore_restrictions, order)))


# Generated at 2022-06-24 19:50:55.031856
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    list_1 = []
    inventory_manager_1 = InventoryManager(list_1)
    pattern_2 = "all"
    ignore_limits_2 = False
    ignore_restrictions_2 = False
    order_2 = None
    hosts_3 = inventory_manager_1.get_hosts(pattern_2, ignore_limits_2, ignore_restrictions_2, order_2)

# Generated at 2022-06-24 19:50:59.347851
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    list_0 = []
    inventory_manager_0 = InventoryManager(list_0)
    test_string_0 = "localhost"
    test_result = inventory_manager_0.list_hosts(test_string_0)
    assert('localhost' in test_result)

if __name__ == '__main__':
    test_InventoryManager_list_hosts()

# Generated at 2022-06-24 19:51:06.448174
# Unit test for function split_host_pattern
def test_split_host_pattern():
    # Return value of split_host_pattern
    # when input is [u'a,b[1], c[2:3] , d']
    print(split_host_pattern([u'a,b[1], c[2:3] , d']))
    # Return value of split_host_pattern
    # when input is u'a,b[1], c[2:3] , d'
    print(split_host_pattern(u'a,b[1], c[2:3] , d'))
    # Return value of split_host_pattern
    # when input is u'a:b[1], c[2:3] , d'
    print(split_host_pattern(u'a:b[1], c[2:3] , d'))
    # Return value of split_host_pattern
   

# Generated at 2022-06-24 19:51:10.753542
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    # Not implemented (yet)
    pass


# Generated at 2022-06-24 19:51:13.862132
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    list_0 = []
    inventory_manager_0 = InventoryManager(list_0)
    assert inventory_manager_0.list_hosts() == []


# Generated at 2022-06-24 19:51:17.981539
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    print('Testing list_hosts - Unit Test:')
    list_hosts_0 = "foo"
    inventory_manager_0 = InventoryManager(list_hosts_0)
    list_hosts_1 = inventory_manager_0.list_hosts(list_hosts_0)
    print(list_hosts_1)
    print('Finished testing list_hosts - Unit Test:')


# Generated at 2022-06-24 19:51:26.877894
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    # Create a dummy inventory
    inventory_manager_0 = InventoryManager()
    host_list = [
        {'_ansible_host': 'host_0'},
        {'_ansible_host': 'host_1'},
        {'_ansible_host': 'host_2'}
    ]
    inventory_manager_0.inventory = Inventory(None)
    inventory_manager_0._inventory.hosts = dict(zip(map(to_text, host_list),
                                                   [Host(h) for h in host_list]))

    # Call the parse_source method with a list of hosts
    host_list_0 = [
        'host_0',
        'host_1',
        'host_2'
    ]

# Generated at 2022-06-24 19:51:33.235386
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():

    inventory = InventoryManager(["foo"])

    # The host 'foo' should be returned since it matches the pattern.
    one = inventory.list_hosts("foo")
    # The pattern should not match any known hosts.
    two = inventory.list_hosts("bar")

    assert(one[0] == "foo")
    assert(one)
    assert(two == [])


# Generated at 2022-06-24 19:51:37.469878
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    """
    unittest for InventoryManager.subset method
    """
    inventory_manager_0 = InventoryManager([])
    subset_pattern_0 = None
    try:
        inventory_manager_0.subset(subset_pattern_0)
    except Exception as exception:
        print(exception)


# Generated at 2022-06-24 19:52:12.328023
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory = InventoryManager(host_list='hosts')
    assert isinstance(inventory.parse_source(u'foo', None), dict) == True
    assert inventory.parse_source(u'foo', None) == {}
    assert isinstance(inventory.parse_source(u'foo', False), dict) == True
    assert inventory.parse_source(u'foo', False) == {}
    if not isinstance(inventory.parse_source(u'foo', True), dict):
        assert False
    try:
        assert inventory.parse_source(u'foo', True) == {}
    except:
        pass
    assert isinstance(inventory.parse_source(u'foo', 'bar'), dict) == True
    assert inventory.parse_source(u'foo', 'bar') == {}

# Generated at 2022-06-24 19:52:21.221718
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    # Params for get_hosts
    pattern = None
    ignore_limits = None
    ignore_restrictions = None
    order = None

    im = InventoryManager(loader=DataLoader(), sources='localhost')
    im.hosts = '127.0.0.1'
    res = im.get_hosts(pattern, ignore_limits, ignore_restrictions, order)
    print(' get_hosts, res is type: ', type(res))
    print(' get_hosts, res is: ', res)

    # print ' get_hosts_vars, res: ', res.get_host_variable('127.0.0.1','ansible_connection')

# Unit Test for hostname_regex_map

# Generated at 2022-06-24 19:52:22.163531
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    i = InventoryManager('localhost,')


# Generated at 2022-06-24 19:52:24.027356
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    manager = InventoryManager()
    assert manager.subset('hosta') == ['hosta']
    assert manager.subset(['hosta', 'hostb']) == ['hosta', 'hostb']


# Generated at 2022-06-24 19:52:33.897541
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # Check that verifies that the 'subset' private method is present in the class
    # Find 'subset' private method in class
    assert hasattr(InventoryManager, '_subset')
    # Get signature of 'subset' private method
    subset_signature = inspect.signature(InventoryManager._subset)
    # Check number of parameters
    assert len(subset_signature.parameters) == 2
    # Check type of first parameter
    assert list(subset_signature.parameters)[0] == 'self'
    subset_self_parameter = subset_signature.parameters['self']
    assert subset_self_parameter.kind == inspect.Parameter.POSITIONAL_OR_KEYWORD
    assert subset_self_parameter.default == inspect.Parameter.empty

# Generated at 2022-06-24 19:52:37.264610
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    method_list_hosts_0 = InventoryManager()
    pattern_list_hosts_0 = "all"
    result_list_hosts_0 = method_list_hosts_0.list_hosts(pattern_list_hosts_0)
    assert result_list_hosts_0


# Generated at 2022-06-24 19:52:39.551931
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory_manager_0 = InventoryManager(Inventory())
    inventory_manager_0.clear_pattern_cache()
    var_0 = inventory_manager_0.get_hosts()


# Generated at 2022-06-24 19:52:41.060150
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    manager = InventoryManager(host_list='hosts')
    manager.subset('patterns')


# Generated at 2022-06-24 19:52:43.297021
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    # Assert if InventoryManager class has non zero inventory

    assert(len(test_inventory.InventoryManager.get_inventory_manager().get_inventory().hosts) > 0)


# Generated at 2022-06-24 19:52:45.510636
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    src = '@test_inventory'
    inventory = InventoryManager(loader=None)
    result = inventory.parse_source(src)
    expected = 'test_inventory'
    assert result == expected

test_cases = [ (test_case_0, ())]


# Generated at 2022-06-24 19:53:04.371756
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # FIXME: add more tests here
    inventory = Inventory("/tmp/ansible_test/test_hosts.inventory_manager")
    manager = InventoryManager(inventory)
    result = manager.subset(None)


# Generated at 2022-06-24 19:53:08.120878
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    bool_0 = True
    inventory_manager_0 = InventoryManager(bool_0)
    obj_0 = inventory_manager_0.get_hosts()
    assert isinstance(obj_0, list), u'value is %s' % type(obj_0)


# Generated at 2022-06-24 19:53:16.648762
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    manager = InventoryManager()
    pattern = str()
    ignore_limits = bool()
    ignore_restrictions = bool()
    order = str()
    hosts_patterns_cache = dict()
    manager.set_hosts_patterns_cache(hosts_patterns_cache)
    pattern_list = [pattern]
    manager.set_subset(pattern_list)
    manager.set_restriction(pattern_list)
    pattern_hash = tuple(pattern_list)
    pattern_hash in hosts_patterns_cache
    manager.get_hosts(pattern, ignore_limits, ignore_restrictions, order)
    patterns = split_host_pattern(pattern)
    hosts = manager._evaluate_patterns(patterns)

# Generated at 2022-06-24 19:53:28.169942
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    # Test with multiple sources of same type
    # Test settings and options
    file_0 = 'test_inventory_file'
    settings = {'allow_duplicates': False}
    test = InventoryManager(loader=None, sources=[file_0, file_0],
                            settings=settings)
    parser = Parser()
    result = test._parse_inventory_source(parser=parser.parse_from_file,
                                            source=file_0)
    assert result == {'inventory_sources': [file_0], 'test': True}
    # Test with non-existent source
    test = InventoryManager(loader=None, sources='test_inventory_file')

# Generated at 2022-06-24 19:53:30.606673
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inv = InventoryManager()
    inv.clear_pattern_cache()
    inv.get_hosts("all")


# Generated at 2022-06-24 19:53:39.912110
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # Setup
    hosts = [
        Host(name="test01", port=22),
        Host(name="test02", port=22),
        Host(name="test03", port=22)
    ]
    groups = {
        "app": Group(name="app", hosts=hosts),
        "database": Group(name="database", hosts=hosts)
    }
    inventory = Inventory(hosts=hosts, groups=groups)
    subset_patterns = None
    expected = set()
    manager = InventoryManager(inventory)
    manager.clear_pattern_cache()

    # Exercise
    manager.subset(subset_patterns)

    # Verify
    assert manager._subset == expected
    assert manager._pattern_cache == {}



# Generated at 2022-06-24 19:53:42.273869
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    # our test objects
    test_inventory = InventoryManager("localhost,")
    test_pattern = 'example_pattern'
    # test_ignore_limits = False
    # test_ignore_restrictions = False
    # test_order = 'inventory'
    # call the method
    test_inventory.get_hosts(test_pattern)
    # assert



# Generated at 2022-06-24 19:53:45.199553
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory = InventoryManager()
    assert inventory is not None

    var_0 = inventory.get_hosts(True, True, True)
    var_1 = inventory.get_hosts(True, True, True)
    assert var_0 is not var_1


# Generated at 2022-06-24 19:53:52.359496
# Unit test for function order_patterns
def test_order_patterns():
    print("unit test order_patterns")
    pattern_1 = "&test_case_0"
    pattern_2 = "!test_case_0"
    pattern_list = [pattern_1, pattern_2]
    pattern_result = order_patterns(pattern_list)
    assert pattern_result == ['test_case_0', '&test_case_0', '!test_case_0']


# Generated at 2022-06-24 19:53:56.065227
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    # Create a new instance of class InventoryManager
    obj_1 = InventoryManager()
    print("obj_1", obj_1)
    # Call method get_hosts of class InventoryManager
    result = obj_1.get_hosts("abc-DENT-2")
    print("result", result)


# Generated at 2022-06-24 19:54:23.810640
# Unit test for method get_hosts of class InventoryManager

# Generated at 2022-06-24 19:54:28.692792
# Unit test for function split_host_pattern
def test_split_host_pattern():
    '''
    A basic test to ensure that split_host_pattern operates correctly.
    '''
    pattern = "test[0:5]"
    assert split_host_pattern(pattern) == ["test[0:5]"]
    assert split_host_pattern([pattern]) == ["test[0:5]"]



# Generated at 2022-06-24 19:54:35.050220
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    try:
        # Init
        global_parser = GlobalParser()
        global_parser.parse([''])

        inventory = Inventory(global_parser)
        inventory_manager = InventoryManager(inventory, global_parser)

        var_0 = 'all'
        inventory_manager.subset(var_0)
    except Exception as e:
        print(e)


# Generated at 2022-06-24 19:54:41.657891
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    bool_0 = True
    str_0 = '~^'
    str_1 = 'all'
    var_0 = split_host_pattern(str_0)
    var_1 = InventoryManager(bool_0)
    var_2 = ((var_0) or (str_1))
    var_3 = var_1.get_hosts(var_2)

if __name__ == '__main__':
    test_case_0()
    test_InventoryManager_get_hosts()

# Generated at 2022-06-24 19:54:44.660830
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # Instance of class InventoryManager
    inventory_manager = InventoryManager('y')


# Generated at 2022-06-24 19:54:48.085596
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    host = "localhost"
    var_1 = InventoryManager()
    var_2 = var_1._parse_source(host)
    assert var_2.hosts is None
    assert var_2.vars is None
    assert var_2.groups is None
    assert var_2.filename is None
    assert var_2.type_ is None
    assert var_2.cache is None


# Generated at 2022-06-24 19:54:52.510890
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    try:
        inventory_manager_0 = get_default_inventory_manager()
        # Initialize InventoryManager object
        subset_pattern_0 = None
        # Call method to initialize inventory manager
        inventory_manager_0.subset(subset_pattern_0)
    except Exception as error:
        raise error


# Generated at 2022-06-24 19:54:56.324675
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    # Basic test
    m = InventoryManager(Loader(), host_list=['localhost', 'otherhost'], sources=["/dev/null"])
    result = m.list_hosts(pattern='all')
    assert result == ['localhost', 'otherhost']
    # Test if pattern is a list
    pattern = ['localhost']
    result = m.list_hosts(pattern=pattern)
    assert result == ['localhost']


# Generated at 2022-06-24 19:54:58.143927
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    test = InventoryManager(inventory=None) # Declare an object of class InventoryManager
    res = test.list_hosts() # Run the method and receive the output


# Generated at 2022-06-24 19:55:01.331406
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    s = 'host[0:2]'
    parser = InventoryParser(s, 'localhost', None)
    im = InventoryManager()
    im.parse_source(parser)
    assert(im._pattern_cache[s] == parser.hosts)
    assert(im._enabled_parsers[0] == parser)



# Generated at 2022-06-24 19:55:17.625039
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager = InventoryManager()
    subset_pattern = "test"
    inventory_manager.subset(subset_pattern)


# Generated at 2022-06-24 19:55:25.973922
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    # host = 'localhost'
    # pattern = ("all",)
    # ignore_limits = False
    # ignore_restrictions = False
    # order = None
    pattern = None
    inventory_manager = InventoryManager(pattern)
    pattern = "all"
    ignore_limits = None
    ignore_restrictions = None
    order = None
    try:
        result = inventory_manager.get_hosts(pattern, ignore_limits, ignore_restrictions, order)
    except Exception as e:
        raise e
    else:
        print(result)


# Generated at 2022-06-24 19:55:30.555809
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory_manager = InventoryManager()
    inventory_source = ""
    # setting up expectation
    mock_callback = MagicMock()
    mock_result = MagicMock()
    with patch('ansible.plugins.loader.find_plugin', return_value=mock_callback):
        inventory_manager.parse_source(inventory_source, host_list=mock_result, cache=True, vault_password=None, yield_content=None)
        assert mock_callback.call_count == 1


# Generated at 2022-06-24 19:55:40.247751
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory_manager_0 = InventoryManager(None)
    inventory_manager_1 = InventoryManager(None)
    inventory_manager_2 = InventoryManager(None)
    bool_0 = inventory_manager_0.get_hosts()
    bool_1 = inventory_manager_0.get_hosts()
    bool_2 = inventory_manager_0.get_hosts()
    bool_3 = inventory_manager_0.get_hosts()
    bool_4 = inventory_manager_0.get_hosts()
    bool_5 = inventory_manager_0.get_hosts()
    bool_6 = inventory_manager_0.get_hosts()
    bool_7 = inventory_manager_0.get_hosts()
    bool_8 = inventory_manager_1.get_hosts()
    bool_9 = inventory_

# Generated at 2022-06-24 19:55:50.214303
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    # Unit test for method parse_source of class InventoryManager
    # Tests that the parse_source method fails when given a prohibited source
    var_0 = InventoryManager(None, None)

    with pytest.raises(AnsibleError) as e:
        pass_var_0 = False
        var_0.parse_source(pass_var_0)

    with pytest.raises(AnsibleError) as e:
        pass_var_0 = True
        var_0.parse_source(pass_var_0)

    with pytest.raises(AnsibleError) as e:
        pass_var_0 = "~/my/home"
        var_0.parse_source(pass_var_0)


# Generated at 2022-06-24 19:55:51.659286
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    pass


# Generated at 2022-06-24 19:56:00.796239
# Unit test for method restrict_to_hosts of class InventoryManager
def test_InventoryManager_restrict_to_hosts():
    # FIXME: it would be nice to be able to mock a InventoryManager,
    # but we can't since it's not a class.
    im = InventoryManager()
    im._restriction = None
    im.restrict_to_hosts(['foo'])
    assert im._restriction == set(['foo'])

    im._restriction = None
    im.restrict_to_hosts(['foo', 'bar'])
    assert im._restriction == set(['foo', 'bar'])

    im._restriction = None
    im.restrict_to_hosts(None)
    assert im._restriction is None

    im._restriction = None
    im.restrict_to_hosts([])
    assert im._restriction == set([])

    # Regression test for #22267
    im._rest

# Generated at 2022-06-24 19:56:04.817595
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    inventory = InventoryManager(None)
    var_1 = inventory.list_hosts()
    var_2 = inventory.list_hosts(pattern=True)
    var_3 = inventory.list_hosts(True)


# Generated at 2022-06-24 19:56:08.688317
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    # FIXME: add tests to verify that parse_source is working properly
    pass


# Generated at 2022-06-24 19:56:14.413996
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():

    # Variables
    config_file = "inventory.ini"
    #case_0 = config_file == "inventory.ini"
    #if case_0:
    #    var_0 = to_text(config_file)

    config_data = "[dev]\nlocalhost\n"
    #case_1 = config_data == "[dev]\nlocalhost\n"
    #if case_1:
    #    var_1 = to_text(config_data)

    host_list = ["dev"]
    #case_2 = host_list == ["dev"]
    #if case_2:
    #    var_2 = to_text(host_list[0])

    new_inventory = Inventory(host_list)
    #case_3 = new_inventory == Inventory(host_list)
    #if case_3

# Generated at 2022-06-24 19:56:39.300643
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    # Create instance of class InventoryManager
    var_5 = InventoryManager()
    # Test method list_hosts
    test_case_0()

if __name__ == '__main__':
    test_InventoryManager_list_hosts()

# Generated at 2022-06-24 19:56:43.620387
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    # No error or warning message should be raised
    bool_0 = True
    var_0 = InventoryManager(bool_0)
    var_1 = var_0.parse_source(bool_0)
    assert var_1 is None


# Generated at 2022-06-24 19:56:46.114255
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # Test with False as input for predicate
    inventory = InventoryManager()
    pattern = False
    inventory.subset(pattern)
    # Test with True as input for predicate
    inventory = InventoryManager()
    pattern = True
    inventory.subset(pattern)


# Generated at 2022-06-24 19:56:48.680280
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # Test parameters and expected return values.
    InventoryManager.subset([])

if __name__ == "__main__":
    import sys

    import pytest
    sys.exit(pytest.main(['-x', __file__]))

# Generated at 2022-06-24 19:56:54.317427
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    # set up objects used in the test
    inventory_manager = InventoryManager(loader=None, sources=None)
    source = "test source"
    cache = "test cache"

    # invoke the method
    result = inventory_manager.parse_source(source, cache=cache)

    # check the results
    assert isinstance(result, bool)
    assert result == False


# Generated at 2022-06-24 19:57:03.285908
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    r'''InventoryManager.parse_source() is broken'''

    manager = InventoryManager()

    # test invalid parameters
    sample_pattern_0 = '''foo*'''
    # Try the following line:
    sample_pattern_0 = sample_pattern_0.encode('utf-8')
    source_0 = '''[foo]
foo1 ansible_host=/nope
bar1 ansible_host=/nope'''
    expected_0 = None
    try:
        # Try the following line:
        result_0 = manager.parse_source(source_0, sample_pattern_0)
    except:
        result_0 = None
    assert result_0 == expected_0


    # test invalid parameters
    sample_pattern_1 = '''foo*'''
    # Try the following line:
    sample

# Generated at 2022-06-24 19:57:07.679622
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    manager = InventoryManager()
    # Test cases for get_hosts
    # Call get_hosts() on an empty pattern and empty hosts
    assert (manager.get_hosts() == [])
    # Call get_hosts() on a non-empty pattern and empty hosts
    assert (manager.get_hosts(pattern="all") == [])


# Generated at 2022-06-24 19:57:10.160360
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    var_1 = InventoryManager(["test_data/test_inventory_manager.yml"])
    var_1.parse_sources()
    var_1.get_hosts()


# Generated at 2022-06-24 19:57:17.426056
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory_manager = InventoryManager()
    pattern0 = "all"
    boolean0 = False
    boolean1 = False
    string0 = ""
    inventory_manager.get_hosts(pattern0)
    inventory_manager.get_hosts(pattern0, boolean0)
    inventory_manager.get_hosts(pattern0, boolean0, boolean1)
    inventory_manager.get_hosts(pattern0, boolean0, boolean1, string0)


# Generated at 2022-06-24 19:57:27.072496
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    inv = InventoryManager(loader=DictDataLoader({'hosts': {'host1': {}, 'host2': {}}}))
    inventory = Inventory(loader=DictDataLoader({'hosts': {'host1': {}, 'host2': {}}}), sources=[])
    inv_mgr = InventoryManager(loader=inventory.loader, sources=inventory.sources)

    assert sorted(inv_mgr.list_hosts()) == ["host1", "host2"]
    assert inv_mgr.list_hosts(pattern="all") == ["host1", "host2"]
    assert inv_mgr.list_hosts(pattern="nonexistent") == []


# Generated at 2022-06-24 19:57:47.516941
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    var_0 = InventoryManager()
    var_1 = var_0.get_hosts()


# Generated at 2022-06-24 19:57:52.309005
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    # Create an empty InventoryManager object
    inventory_manager_obj = InventoryManager()

    # Create arguments for the method
    inventory_source = [
        "test_inventory",
        "test_loader",
        None,
        "test_cache_timeout",
        "test_host_list",
        "test_groups",
        "test_plugin_options",
        "test_enable_plugins",
        ]

    # Call the method
    inventory_manager_obj.parse_source(*inventory_source)

    # Output the result
    display.info("Test case 0 finished")


# Generated at 2022-06-24 19:57:55.260534
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # simple test to ensure this compiles and runs
    mgr = InventoryManager()
    mgr.subset('localhost')
    print('Test complete.')



# Generated at 2022-06-24 19:57:59.154704
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    int_0 = 1
    int_1 = 1
    str_0 = "abc"
    inventoryMgr_0 = InventoryManager(int_0, int_1, str_0)
    inventoryMgr_0.subset(bool_0)


# Generated at 2022-06-24 19:58:00.849938
# Unit test for function split_host_pattern
def test_split_host_pattern():

    try:
        test_case_0()
        print('PASS')
    except Exception as e:
        print('FAIL: {0}'.format(e))




# Generated at 2022-06-24 19:58:06.782492
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inv_mgr = InventoryManager()
    # FIXME:
    # Test if parse_source is able to parse following json data format.
    # {'hosts': ['host1', 'host2'], 'vars': {'var1': 'foo', 'var2': 'bar'}}
    pass

if __name__ == "__main__":
    # execute unit test
    test_case_0()
    test_InventoryManager_parse_source()
    display.info("Unit tests for InventoryManager passed.")

# Generated at 2022-06-24 19:58:15.200890
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    inventory_manager_0 = InventoryManager()
    inventory_manager_0.add_host('host-0')
    inventory_manager_0.add_host('host-1')
    inventory_manager_0.add_host('host-2')
    inventory_manager_0.add_host('host-3')
    inventory_manager_0.add_host('host-4')
    inventory_manager_0.add_host('host-5')
    inventory_manager_0.add_host('host-6')
    inventory_manager_0.add_host('host-7')
    inventory_manager_0.add_host('host-8')
    inventory_manager_0.add_host('host-9')
    inventory_manager_0.list_hosts()


# Generated at 2022-06-24 19:58:25.929355
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    argument0 = mock.Mock()
    argument0.get_option.return_value = True
    argument0.display.return_value = None
    argument0.get_host_list.return_value = ["ansible", "ansible"]
    argument0.subset.return_value = None
    argument0.is_file.return_value = False
    argument0.is_dir.return_value = False
    argument0.is_inventory.return_value = False

    argument1 = "ansible"

    # Invoke method
    (host_vars, group_vars, new_inventory) = InventoryManager.parse_source(argument0, argument1)

    # Check if mock was called
    argument0.get_option.assert_called_with('host_pattern', 'all')

    # Check call count of mock
   

# Generated at 2022-06-24 19:58:30.696043
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():

    # Using a fixture to a create Inventory.

    result = test_inventory_manager.get_hosts("all")
    assert len(result) == 3

    result = test_inventory_manager.get_hosts("somerole")
    assert len(result) == 2

    result = test_inventory_manager.get_hosts("somerole:somehost")
    assert len(result) == 1

    result = test_inventory_manager.get_hosts(["somerole", "a_second_role"])
    assert len(result) == 3


# Generated at 2022-06-24 19:58:39.618551
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory = InventoryManager(loader=DummyLoader())
    sources = [
        "localhost,",
        "localhost",
        "localhost,",
        "localhost",
        "localhost,",
        "localhost",
        "localhost,",
        "localhost",
        "localhost,",
        "localhost",
        "localhost,",
        "localhost",
        "localhost,",
        "localhost",
        "localhost,",
        "localhost",
        "localhost,",
        "localhost",
        "localhost,",
        "localhost",
        "localhost,",
        "localhost"
    ]

    # It is possible that a single source is given as a comma separated list in sources
    source_list = inventory.parse_source(sources)