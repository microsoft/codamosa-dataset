

# Generated at 2022-06-24 19:50:13.811917
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory_manager_0 = InventoryManager(None)
    bytes_0 = None
    bytes_1 = None
    var_0 = inventory_manager_0.get_hosts(bytes_0, bytes_1)


# Generated at 2022-06-24 19:50:16.486424
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory_manager = InventoryManager()
    path = b'/path/to/file'
    var_2 = inventory_manager.parse_source(path)


# Generated at 2022-06-24 19:50:18.905072
# Unit test for function order_patterns
def test_order_patterns():
    try:
        test_case_0()
    except Exception as e:
        print(e.message)
        raise e


# Generated at 2022-06-24 19:50:20.297368
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    pytest.skip("unimplemented")


# Generated at 2022-06-24 19:50:22.069658
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    pattern = None
    im = InventoryManager(loader=None, sources=None)
    im.subset(pattern)

# Generated at 2022-06-24 19:50:32.312751
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    bytes_0 = b''
    var_0 = InventoryManager(bytes_0)
    bytes_1 = None
    var_1 = var_0.list_hosts(bytes_1)
    assert repr(var_1) == "[{'_ansible_ssh_pass': 'pass', '_ansible_ssh_user': 'user', 'ansible_ssh_host': '127.0.0.1', 'ansible_ssh_port': '1234', 'name': 'host-a'}, {'_ansible_ssh_pass': 'pass', '_ansible_ssh_user': 'user', 'ansible_ssh_host': '127.0.0.1', 'ansible_ssh_port': '1234', 'name': 'host-b'}]"


# Generated at 2022-06-24 19:50:35.753332
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory = InventoryManager(loader=None, sources="")
    pattern = "all"
    ignore_limits = False
    ignore_restrictions = False
    order = None
    InventoryManager_get_hosts = inventory.get_hosts(pattern, ignore_limits, ignore_restrictions, order)


# Generated at 2022-06-24 19:50:40.372837
# Unit test for function split_host_pattern
def test_split_host_pattern():
    bytes_0 = b'horst[1]'
    var_0 = split_host_pattern(bytes_0)
    # var_0 == ['horst[1]']
    bytes_1 = b'horst:durst'
    var_1 = split_host_pattern(bytes_1)
    # var_1 == ['horst', 'durst']
    bytes_2 = b'horst,durst'
    var_2 = split_host_pattern(bytes_2)
    # var_2 == ['horst', 'durst']


# Generated at 2022-06-24 19:50:43.316144
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    im = InventoryManager(Loader())
    im.subset(['test'])
    im.subset(['test1','test2','test3'])


# Generated at 2022-06-24 19:50:51.259350
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    # load file into inventory
    inventory = InventoryManager(loader=C.DEFAULT_LOADER_CLASS, sources='./test/vars_plugin/host_vars')

    # run the list_hosts method
    # test a pattern that exists in both groups and hosts
    list_result = inventory.list_hosts("test_host_")
    assert list_result == ["test_host_01", "test_host_02", "test_host_03", "test_host_04"], "inventory.list_hosts should return list of matching hosts"

    # test a pattern that exists in only groups
    list_result = inventory.list_hosts("test_group_")

# Generated at 2022-06-24 19:51:04.160126
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    # FIXME: This is broken. For now just disable it.
    return
    inventoryManager = InventoryManager()
    test_case_0()


# Generated at 2022-06-24 19:51:05.392888
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    str_0 = 'unimplemented'


# Generated at 2022-06-24 19:51:09.917212
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    # Create an instance of InventoryManager class
    inventory_manager_inst = InventoryManager()

    # Call the create_inventory method of inventory_manager_inst
    InventoryManager.create_inventory(inventory_manager_inst, str_0)

    # Call the get_hosts method of inventory_manager_inst
    InventoryManager.get_hosts(inventory_manager_inst, str_0)

    # Call the list_hosts method of inventory_manager_inst
    InventoryManager.list_hosts(inventory_manager_inst)



# Generated at 2022-06-24 19:51:11.596028
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    str_1 = 'unimplemented'


# Generated at 2022-06-24 19:51:12.991560
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    str_0 = 'unimplemented'


# Generated at 2022-06-24 19:51:15.457619
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    '''(str) -> NoneType
    '''
    inventory_manager_0 = InventoryManager()
    inventory_manager_0.subset(str_0)


# Generated at 2022-06-24 19:51:21.106629
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory = Inventory('test/inventory')
    host = Host('test', port=22, inventory=inventory)
    inv_mgr = InventoryManager(host)
    inv_mgr.subset('test')

    assert inv_mgr._subset == None


# Generated at 2022-06-24 19:51:25.328546
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    inventory = InventoryManager(loader=None, sources='/dev/null')
    inventory.parse_sources(None)
    pattern = "test_InventoryManager_list_hosts"
    if inventory.list_hosts(pattern):
        print("Method list_hosts of class InventoryManager works well")
    else:
        test_case_0()


# Generated at 2022-06-24 19:51:26.452434
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    str_0 = 'unimplemented'


# Generated at 2022-06-24 19:51:28.367793
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    with pytest.raises(NotImplementedError):
        manager = InventoryManager()
        manager.list_hosts()


# Generated at 2022-06-24 19:51:48.995494
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    # NOTE: test data should be a str
    test_data = ['TEST', 'TEST1', 'TEST2']
    pattern_0 = 'TEST'

    # Initialize inventory module
    inventory_manager = InventoryManager()

    # Case 1: test with pattern = TEST
    print('Testing case 1')
    assert inventory_manager.list_hosts(pattern_0) == test_data, 'test_case_1 failed'

    # Case 2: test with pattern = TEST1
    print('Testing case 2')
    pattern_1 = 'TEST1'
    assert inventory_manager.list_hosts(pattern_1) == ['TEST1'], 'test_case_2 failed'

    # Case 3: test with pattern = TEST2
    print('Testing case 3')
    pattern_2 = 'TEST2'
   

# Generated at 2022-06-24 19:51:59.792489
# Unit test for method parse_source of class InventoryManager

# Generated at 2022-06-24 19:52:04.033117
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    host_pattern = 'all'
    inventory_manager = InventoryManager(loader=None, sources=str())
    list_hosts = inventory_manager.list_hosts(host_pattern=host_pattern)

# Generated at 2022-06-24 19:52:06.776470
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    obj = InventoryManager()
    obj.subset()

# Generated at 2022-06-24 19:52:08.758866
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    subset_pattern =  __ANSIBLE_TMP__ + "test_InventoryManager_subset.txt"

    # TODO


# Generated at 2022-06-24 19:52:15.369868
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager_0 = InventoryManager('unimplemented')
    subset_pattern = u'unimplemented'
    inventory_manager_0.subset(subset_pattern)


# Generated at 2022-06-24 19:52:15.991049
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    assert (True)


# Generated at 2022-06-24 19:52:17.624294
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
	man = InventoryManager()
	man.subset('a subset pattern')
		

# Generated at 2022-06-24 19:52:21.301806
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    if not is_property():
        if len(p1) > 1:
            for i, arg in enumerate(p1):
                if str(arg) == p2[i]:
                    return True
                else:
                    return False
    else:
        return p2 == p1


# Generated at 2022-06-24 19:52:24.085121
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    pattern = "all"
    ignore_restrictions=False
    ignore_limits=False
    order=None
    obj_InventoryManager = InventoryManager(pattern, ignore_restrictions, ignore_limits, order)



# Generated at 2022-06-24 19:52:38.595083
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    my_InventoryManager = InventoryManager(
        loader = None,
        sources = 'localhost,'
    )

    my_subset_pattern = 'regex'
    my_InventoryManager.subset(
        my_subset_pattern
    )

    my_subset_pattern = None
    my_InventoryManager.subset(
        my_subset_pattern
    )


# Generated at 2022-06-24 19:52:40.390309
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    bytes_0 = None
    var_0 = InventoryManager(bytes_0)
    bytes_1 = None
    var_0.subset(bytes_1)


# Generated at 2022-06-24 19:52:43.220512
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    bytes_0 = None
    var_0 = InventoryManager(bytes_0)
    var_1 = None
    var_0.subset(var_1)
    var_0.remove_restriction()


# Generated at 2022-06-24 19:52:45.639043
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory_manager = AnsibleInventory()
    
    inventory_manager.parse_source(["first", "second"], "test_file")
    # print inventory_manager._get_host_variables(u"first")
    
if __name__ == "__main__":
    test_InventoryManager_parse_source()

# Generated at 2022-06-24 19:52:47.526359
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    obj_0 = InventoryManager(bytes_0)
    obj_1 = obj_0.list_hosts("demo_host_*")
    print("hosts: ", obj_1)


# Generated at 2022-06-24 19:52:54.211093
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    display.vvv(u'TEST: list_hosts()')
    # Make a mock inventory source
    class FakeInventory(object):
        def __init__(self):
            self.hosts = [u'localhost']
        def get_host(self, hostname):
            return hostname
    inventory = FakeInventory()
    # Make an InventoryManager
    im = InventoryManager(inventory, cache=False)
    # Test various cases
    # 1) Test that a simple pattern works
    test_pattern_0 = u'localhost'
    display.vvv(u'Pattern: %s' % test_pattern_0)
    result = im.list_hosts(test_pattern_0)
    assert isinstance(result, list)
    assert len(result) == 1

# Generated at 2022-06-24 19:52:57.054408
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    bytes_0 = None
    var_0 = InventoryManager(bytes_0)
    var_1 = None
    var_0.restrict_to_hosts(var_1)
    var_2 = None
    var_0.subset(var_2)
    var_3 = None
    var_3 = var_0.list_hosts(var_3)
    assert var_3 == None


# Generated at 2022-06-24 19:52:59.779485
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    obj_0 = InventoryManager(bytes("Test"))
    var_0 = obj_0.subset("Test")


# Generated at 2022-06-24 19:53:10.589948
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    j = to_bytes('"{}", "' + 'This is a test' + '"' + '', 'utf-8')
    e = os.environ.get(to_bytes('ANSIBLE_INVENTORY', 'utf-8'), to_bytes('ANSIBLE_INVENTORY'))
    if j in e:
        var_0 = InventoryManager(loader=None) # do we want to really use the default?
        i = var_0._inventory.groups
        h = var_0._hosts_patterns_cache
        subset_pattern = to_bytes(var_0._subset, 'utf-8')
        subset_patterns = split_host_pattern(subset_pattern)
        results = []
        # allow Unix style @filename data

# Generated at 2022-06-24 19:53:11.461203
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    bytes_0 = None
    list_hosts(bytes_0)


# Generated at 2022-06-24 19:53:34.591114
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    pattern_0 = None
    ignore_limits_0 = None
    ignore_restrictions_0 = None
    order_0 = None
    inventory = Inventory(loader='loader_name')
    inventory.hosts = {}
    inventory_manager = InventoryManager(loader=None, sources='sources_name', inventory=inventory)
    expect_result = []
    result = inventory_manager.get_hosts(pattern=pattern_0, ignore_limits=ignore_limits_0, ignore_restrictions=ignore_restrictions_0, order=order_0)
    assert result == expect_result


# Generated at 2022-06-24 19:53:44.854411
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    from collections import namedtuple
    from ansible.inventory.loader import InventoryLoader
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    AnsibleOptions = namedtuple('AnsibleOptions', ['host_pattern'])

    options = AnsibleOptions('localhost')
    test_loader = DataLoader()
    inventory_loader = InventoryLoader(test_loader, variable_manager=None, host_list=options.host_pattern)
    inventory = inventory_loader.inventory
    manager = InventoryManager(inventory=inventory, loader=test_loader)

    try:
        manager.parse_source(b'broken-source')
    except Exception as e:
        assert type(e) == AnsibleParserError


# Generated at 2022-06-24 19:53:49.169442
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager_instance = InventoryManager()
    subset_pattern = "abc"
    inventory_manager_instance.subset(subset_pattern)


# Generated at 2022-06-24 19:53:51.721953
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    try:
        var_0 = InventoryManager(bytes_1=None)
        var_0.subset(bytes_2=None)
        assert True
    except:
        assert False


# Generated at 2022-06-24 19:53:55.404589
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    hosts = [u'foo', u'bar']
    i_m = InventoryManager(hosts=hosts)
    pattern = 'all'
    r_l_h = i_m.list_hosts(pattern)
    assert r_l_h == [u'foo', u'bar']


# Generated at 2022-06-24 19:54:01.915097
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    # Create an inventory manager
    manager = InventoryManager()
    
    # Create a pattern
    pattern = "all"
    
    # Get result
    host = manager.get_hosts(pattern)
    
    # Print result
    print (host)


# Generated at 2022-06-24 19:54:06.400213
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    manager = InventoryManager(loader=None, sources='')
    manager.subset('')


# Generated at 2022-06-24 19:54:09.872047
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    test_inv = InventoryManager(Loader())
    test_inv.subset('172.16.0.8')

    # test with list
    test_host = Host(Inventory(), 'test_host')
    test_inv.subset([test_host])

    # test with None
    test_inv.subset(None)


# Generated at 2022-06-24 19:54:15.455424
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    if is_py3:
        ansible_module = None
    else:
        ansible_module = None
    var_0 = InventoryManager(ansible_module)
    bytes_0 = None
    var_0.subset(bytes_0)
    var_0.restrict_to_hosts(None)
    pattern = None
    ignore_limits = None
    ignore_restrictions = None
    order = None
    results = var_0.get_hosts(pattern, ignore_limits, ignore_restrictions, order)
    assert isinstance(results, list)


# Generated at 2022-06-24 19:54:20.295725
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    bytes_0 = None
    var_0 = InventoryManager(bytes_0)
    bytes_1 = "test_value"
    var_1 = var_0.get_hosts(bytes_1)


# Generated at 2022-06-24 19:55:32.461801
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    dict_0 = dict()
    dict_1 = dict()
    dict_1['hostvars'] = dict_0
    dict_2 = dict()
    dict_1['_meta'] = dict_2
    dict_3 = dict()
    dict_3['host_specific_var'] = 'value'
    dict_2['hostvars'] = dict_3
    dict_2['hostnames'] = list()
    dict_2['all'] = dict_3
    dict_3 = dict()
    dict_3['g1'] = dict_1
    dict_4 = dict()
    dict_4['groups'] = dict_3
    dict_5 = dict()
    dict_5['inventory_manager'] = dict_4
    dict_5['requirement_set'] = dict()

# Generated at 2022-06-24 19:55:34.220788
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # FIXME: Add Unit test
    pass


# Generated at 2022-06-24 19:55:35.739542
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inv = InventoryManager(loader=None, sources='localhost,')
    inv.subset('hosts')


# Generated at 2022-06-24 19:55:37.070587
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # FIXME: Implementation of test.
    assert True # TODO: implement your test here


# Generated at 2022-06-24 19:55:43.375549
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    bytes_0 = None
    var_0 = InventoryManager(bytes_0)
    bytes_0 = None
    bytes_1 = None
    var_0.parse_source(bytes_0, bytes_1)


# Generated at 2022-06-24 19:55:44.536349
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    m = InventoryManager(loader=None, sources=None)
    m.get_hosts()

# Generated at 2022-06-24 19:55:47.990172
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    bytes_0 = b"all"
    my_invent = InventoryManager(bytes_0)
    pattern ="all"
    my_invent.list_hosts(pattern)


# Generated at 2022-06-24 19:55:49.710060
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inv_manager = InventoryManager(None)
    subset_pattern = "subset_pattern"
    inv_manager.subset(subset_pattern)


# Generated at 2022-06-24 19:56:00.789738
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():

    i = InventoryManager(inventory=Inventory('testhosts'))
    i.add_host(Host('host1'))
    i.add_group(Group('group1'))
    g1 = Group('group2')
    g2 = Group('group3')
    g1.add_child_group(g2)
    i.add_group(g1)
    h1 = Host('host2')
    g1.add_host(h1)
    i.console().subset('all')
    i.console().subset(None)
    var_0 = i.list_groups()
    assert var_0 == ['all', 'group1', 'group2', 'group3', 'ungrouped']
    var_1 = i.list_hosts()
    assert var_1 == ['host1', h1]

# Generated at 2022-06-24 19:56:09.277881
# Unit test for function order_patterns
def test_order_patterns():
    from test.unit.inventory.test_patterns import TestPatterns


# Generated at 2022-06-24 19:56:21.752476
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    assert InventoryManager.subset('subset_pattern') == 'subset_pattern'


# Generated at 2022-06-24 19:56:24.513224
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():

    bytes_str = None
    var_str = InventoryManager(bytes_str)
    var_str.subset(bytes_str)


# Generated at 2022-06-24 19:56:26.663296
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager = InventoryManager(loader=None)
    subset_pattern = [b'foo', b'bar']
    inventory_manager.subset(subset_pattern)


# Generated at 2022-06-24 19:56:28.823321
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory_manager = InventoryManager(Loader(), None, None)
    source = None
    var_0 = inventory_manager.parse_source(source, "test-pattern")


# Generated at 2022-06-24 19:56:31.255107
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    inventory_manager = InventoryManager('localhost,', 'localhost,')
    pattern = 'localhost,'
    result = inventory_manager.list_hosts(pattern)
    assert result == ['localhost,'], "Return value of list_hosts is incorrect"


# Generated at 2022-06-24 19:56:38.723360
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory_obj = InventoryManager(None)
    # No arguments
    result = inventory_obj.get_hosts()
    assert type(result) == list
    # One argument
    #pattern = "all"
    #result = inventory_obj.get_hosts(pattern)
    #assert type(result) == list
    # Two arguments
    #pattern = "all"
    #ignore_limits = False
    #result = inventory_obj.get_hosts(pattern, ignore_limits)
    #assert type(result) == list
    # Three arguments
    #pattern = "all"
    #ignore_limits = False
    #ignore_restrictions = True
    #result = inventory_obj.get_hosts(pattern, ignore_limits, ignore_restrictions)
    #assert type(result) == list
    # Four arguments

# Generated at 2022-06-24 19:56:40.819882
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager_0 = InventoryManager()
    subset_pattern_0 = None
    # Call method of InventoryManager
    inventory_manager_0.subset(subset_pattern_0)


# Generated at 2022-06-24 19:56:42.307930
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    ansible_0 = InventoryManager(dict())
    ansible_0.subset(None)


# Generated at 2022-06-24 19:56:44.253054
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # inventory = AnsibleInventory()
    inventory_manager = InventoryManager(inventory)
    subset_pattern = None
    var_1 = inventory_manager.subset(subset_pattern)


# Generated at 2022-06-24 19:56:49.248510
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # Define a args and kwargs for your test
    pattern = ''

    # Initialize and populate your class
    your_class = InventoryManager()

    # Run your code
    your_class.subset(pattern)

    # Test the results
    # assert()
    # self.assertEqual([], your_class.subset(pattern))


# Generated at 2022-06-24 19:57:02.731464
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    eval = to_bytes("test")
    var_0 = InventoryManager(eval)
    var_1 = to_bytes("test")
    var_2 = var_0.get_hosts(var_1)


# Generated at 2022-06-24 19:57:11.072559
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    h = InventoryManager(loader=None, sources=None, variable_manager=None)
    #

# Generated at 2022-06-24 19:57:19.684213
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory = InventoryManager(loader=None)

    # Test with bad value for source
    pattern = None
    for x in [None, '', ' ', '   ', b'', b' ', b'   ']:
        results = inventory.parse_source(pattern)

    # Test with bad value for ignore_errors
    pattern = None
    for ignore_errors in [True, False]:
        results = inventory.parse_source(pattern)

    # Test with bad value for  for cache
    pattern = None
    for cache in [True, False]:
        results = inventory.parse_source(pattern)

    # Test with bad value for index_var
    pattern = None
    for index_var in [True, False]:
        results = inventory.parse_source(pattern)

    # Test with bad value for  for add_group
    pattern = None


# Generated at 2022-06-24 19:57:22.766498
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # We are clearing the cache and recalculating it every time the subset
    # method is called, so no need to run here.
    pass


# Generated at 2022-06-24 19:57:29.967631
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory = Inventory("/tmp/test_ansible_inven_test_InventoryManager_get_hosts/inventory_file")
    hostname = "foo"
    fqdn = "foo"
    host_state = None
    var_result = hostname
    host_state = HostState(hostname, fqdn, inventory)
    var_result = Host(hostname, inventory)
    inventory.hosts[hostname] = var_result
    var_result = "(?i)^" + re.escape(hostname) + "$"
    var_result = re.compile(var_result)
    var_result = hostname
    var_result = set(var_result)
    var_result = [var_result]
    var_result = set(var_result)

# Generated at 2022-06-24 19:57:31.404701
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    # Test case 0
    bytes_0 = None
    var_0 = inventory_manager.get_hosts(bytes_0)
    assert var_0 is not None


# Generated at 2022-06-24 19:57:39.044142
# Unit test for function order_patterns
def test_order_patterns():
    assert order_patterns(b'!foo:bar &foo:baz web01') == [b'web01', b'&foo:baz', b'!foo:bar']
    assert order_patterns(b'!foo:bar web01 &foo:baz') == [b'web01', b'&foo:baz', b'!foo:bar']
    assert order_patterns(b'web01 !foo:bar &foo:baz') == [b'web01', b'&foo:baz', b'!foo:bar']
    assert order_patterns(b'web01 foo:bar &foo:baz') == [b'web01', b'&foo:baz', b'foo:bar']
    assert order_patterns(b'web01 foo:bar &foo:baz !foo:baz')

# Generated at 2022-06-24 19:57:47.059953
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    bytes_0 = None
    order_patterns(bytes_0)
    bytes_1 = None
    var_0 = InventoryManager(bytes_1)
    var_1 = 'all'
    var_2 = None
    var_3 = None
    var_4 = None
    # get_hosts(self, pattern=b'all', ignore_limits=None, ignore_restrictions=None, order=None)
    var_5 = var_0.get_hosts(var_1, var_2, var_3, var_4)


# Generated at 2022-06-24 19:57:49.476278
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # Create instance
    inventory_manager_0 = InventoryManager()
    # Create variable
    subset_pattern_0 = None
    # Call function
    inventory_manager_0.subset(subset_pattern_0)


# Generated at 2022-06-24 19:57:52.838818
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    """
    Check that InventoryManager is callable
    """
    inv = InventoryManager(None)

    test_case_0()
