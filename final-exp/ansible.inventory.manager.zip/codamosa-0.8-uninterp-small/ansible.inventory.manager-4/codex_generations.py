

# Generated at 2022-06-24 19:49:20.130033
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    bytes_0 = b'\xce\xcb\x0e'
    var_0 = split_host_pattern(bytes_0)


# Generated at 2022-06-24 19:49:24.699534
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    p = create_parser()
    (options, args) = p.parse_args(args=['-i', splits, '--list-hosts'])
    options = p.parse_known_args(args=['-i', splits, '--list-hosts'])[0]
    if options.list_hosts:
        display.display('\n')
        display.display('playbooks/inventory --list-hosts (1)\n')
        im = InventoryManager(loader, sources=options.inventory)
        im.subset(options.subset)
        groups = im.list_groups()
        groups.sort()
        for group in groups:
            display.display('  %s\n' % group)
            hosts = im.list_hosts(group)
            hosts.sort()

# Generated at 2022-06-24 19:49:27.996749
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    test_case_0()

# call to test method
test_InventoryManager_list_hosts()

# Generated at 2022-06-24 19:49:38.154874
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    # FIXME: This unittest is broken.
    # The InventoryManager is not in a state to be used correctly in a test environment.
    # https://github.com/ansible/ansible/issues/13611
    return
    # Setup
    inventory = _create_inventory(dict(
        all=dict(
            hosts=dict(
                a=dict(ansible_host='hostvalue_1'),
                b=dict(ansible_host='hostvalue_2'),
            )
        )
    ))
    inventory_mgr = inventory
    inventory_mgr._restriction = None

    # Exercise

    # Verify
    assert inventory_mgr.get_hosts(pattern="all") == ['a', 'b']

# Generated at 2022-06-24 19:49:41.825329
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    var_1 = InventoryManager(var_1)
    var_2 = var_1.get_hosts(var_2)
    assert var_2 == True


# Generated at 2022-06-24 19:49:48.478221
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    var_0 = InventoryManager(None)
    bytes_0 = b'b\x98\x07\xfcl\xb2v\xf8\x82'
    var_0.subset(bytes_0)


# Generated at 2022-06-24 19:50:00.315260
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    # Imports
    import random
    
    random.seed(0)
    
    # TODO: Auto-generated method stub
    # pattern = string type
    # ignore_limits = boolean type
    # ignore_restrictions = boolean type
    
    
    inventory = InventoryManager(loader=None, sources="my_hosts")
    inventory.clear_pattern_cache()
    # Var to store __init__ return value
    var_0 = inventory.get_hosts(pattern = "all", ignore_limits = False, ignore_restrictions = False)
    # Var to store __init__ return value
    var_1 = inventory.get_hosts(pattern = "linux[3:5]", ignore_limits = False, ignore_restrictions = False)
    # Var to store __init__ return value
    var_2 = inventory

# Generated at 2022-06-24 19:50:02.296729
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    assert test_case_0() == None

# Generated at 2022-06-24 19:50:12.024366
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():

    # FIXME: 'test_case_0', needs to be implemented
    bytes_0 = b'b\x98\x07\xfcl\xb2v\xf8\x82'
    bytes_1 = b'\x8b)\x81i\x9b\xbb\xd9\xce\x90\xcc\xa3\xdd\xb8\xf3\x98'

# Generated at 2022-06-24 19:50:14.898646
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # Test case 0
    bytes_0 = b'b\x98\x07\xfcl\xb2v\xf8\x82'
    obj_0 = InventoryManager()
    obj_0.subset(bytes_0)


# Generated at 2022-06-24 19:51:27.884490
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    bytes_0 = b'o\xe4W\xf8\x1c\xbb\x14\xfd\x97'
    bytes_1 = b'\x9d\x02\xd0\xc1\x0b\x8c\xbf\xbf'
    bytes_2 = b'>\x16\xa7v\xc2\x1e\x8b(\xee\xd9'
    str_0 = '\x98\xf7c\x0f\xbf\x1b\xdc\x0e\x02'
    str_1 = '\x88\xfa\r\x86\x82\x1dV\xf9\x9f'

# Generated at 2022-06-24 19:51:36.310313
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    fixture_path = os.path.join(os.path.dirname(__file__), '../../lib/ansible/inventory/')
    content_path = os.path.join(fixture_path, 'hosts')
    source = "localhost ansible_connection=local," + content_path
    manager = InventoryManager(loader=None, sources=source)

    assert isinstance(manager._inventory, Inventory)

    (host_list, group_list, _) = manager.parse_source(unquote(source))

    assert host_list == ['localhost']
    assert group_list == ['ungrouped']



# Generated at 2022-06-24 19:51:37.649261
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    # TODO: Implement tests for InventoryManager.parse_source()
    assert False



# Generated at 2022-06-24 19:51:47.362430
# Unit test for function split_host_pattern
def test_split_host_pattern():
    byte_string = 'b\x98\x07\xfcl\xb2v\xf8\x82'
    list_string = ['b\x98\x07\xfcl\xb2v\xf8\x82']
    var_0 = split_host_pattern(byte_string)
    #var_1 = split_host_pattern(list_string)
    #print var_0
    #print var_1
    assert var_0 == ['b\x98\x07\xfcl\xb2v\xf8\x82']
    #assert var_1 == ['b\x98\x07\xfcl\xb2v\xf8\x82']


# Generated at 2022-06-24 19:51:51.490477
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory = InventoryManager()
    pattern = "test"
    ignore_limits = True
    ignore_restrictions = True
    order = "order_test"
    result = inventory.get_hosts(pattern, ignore_limits, ignore_restrictions, order)
    assert result == []


# Generated at 2022-06-24 19:51:54.378224
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():
    v0 = InventoryManager()
    var_2 = v0.parse_sources('host_list', 'host_list')
    assert var_2 == 'host_list'


# Generated at 2022-06-24 19:52:01.006080
# Unit test for method parse_source of class InventoryManager

# Generated at 2022-06-24 19:52:10.267211
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    bytes_0 = b'\x0c\xce\x91\xfc\x8e'
    bytes_1 = b'\xca\x8b\xf6\xc2^\xd1\x17\xea'
    bytes_2 = b'\xed\x8b\xb3\xbc\xe3\xcc'

    inventory_manager_0 = InventoryManager(bytes_0, bytes_1, bytes_2, bytes_2)
    bytes_3 = b'\x9f\x01\xfa\xde\x8f\x01\x07\x80\x93\x00\x1a\x9c\xe1\xff\x8c\xbf\x98'

# Generated at 2022-06-24 19:52:14.276189
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager_0 = InventoryManager()
    bytes_0 = b'b\x98\x07\xfcl\xb2v\xf8\x82'
    inventory_manager_0.subset(bytes_0)


# Generated at 2022-06-24 19:52:21.261987
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():
    inventory = InventoryManager(loader=None, sources=None)
    inventory.parse_sources(cache=True)
    inventory.parse_sources(cache=True)
    inventory.parse_sources(cache=True)
    inventory.parse_sources(cache=True)
    inventory.parse_sources(cache=True)
    inventory.parse_sources(cache=False)
    inventory.parse_sources(cache=False)
    inventory.parse_sources(cache=False)
    inventory.parse_sources(cache=False)
    inventory.parse_sources(cache=False)

# Generated at 2022-06-24 19:52:39.053587
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager = InventoryManager()
    string_0 = "host1,host2"
    inventory_manager.subset(string_0)
    string_1 = "host3,host4"
    inventory_manager.subset(string_1)
    string_2 = "host5,host6"
    inventory_manager.subset(string_2)
    string_3 = "host7,host8"
    inventory_manager.subset(string_3)
    string_4 = "host9,host10"
    inventory_manager.subset(string_4)
    string_5 = "host11,host12"
    inventory_manager.subset(string_5)
    string_6 = "host13,host14"
    inventory_manager.subset(string_6)

# Generated at 2022-06-24 19:52:41.253762
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    float_0 = float('inf')
    # test with string
    inventory_manager_0 = InventoryManager(float_0)
    var_0 = inventory_manager_0.subset("test_string")


# Generated at 2022-06-24 19:52:43.192563
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory_manager_0 = InventoryManager()
    inventory_manager_0.parse_sources('test_case_0')

test_case_0()
test_InventoryManager_parse_source()

# Generated at 2022-06-24 19:52:49.037095
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    print("Calling: test_InventoryManager_subset()")

    # method subset() using inventory
    print("InventoryManager.subset() using inventory")
    my_inventory = Inventory('hosts')
    my_inventory.set_hosts([])
    my_inventory.set_hosts([])
    my_inventory.set_hosts([])

    # with simple string
    my_host = Host('host')
    my_inventory.add_host(my_host)
    my_inventory.set_variable(my_host.name, 'group', 'group')
    my_inventory.set_variable(my_host.name, 'group', 'group')
    my_inventory.set_variable(my_host.name, 'group', 'group')

# Generated at 2022-06-24 19:52:53.199899
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    # Erase InventoryManager._hosts_patterns_cache
    InventoryManager._hosts_patterns_cache = dict()

    inv_manager = InventoryManager()
    var_0 = inv_manager.get_hosts('pattern_0')

    # Return type assertion
    assert isinstance(var_0, list), "Return type is not list"

    # Test with empty cache
    var_1 = inv_manager.get_hosts('pattern_1')

    # Assertion
    assert var_0 == var_1, "Value did not match"


# Generated at 2022-06-24 19:52:58.537416
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # Example 0 - Single list element
    inventory = InventoryManager("foo")
    subset_patterns = "foo"
    inventory.subset(subset_patterns)

    # Example 1 - Multiple list elements
    inventory = InventoryManager("bar")
    subset_patterns = ["foo", "bar"]
    inventory.subset(subset_patterns)

    # Example 2 - List of dictionaries
    inventory = InventoryManager("bar")
    subset_patterns = [{"foo": "bar"}, "bar"]
    inventory.subset(subset_patterns)

    # Example 3 - Empty subset
    inventory = InventoryManager("bar")
    subset_patterns = []
    inventory.subset(subset_patterns)

    # Example 4 - None subset
    inventory = InventoryManager("bar")
    subset_patterns = None
    inventory

# Generated at 2022-06-24 19:53:03.318073
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory_mgr = InventoryManager("")
    source = ""
    filename = ""
    config_file = ""
    loader = ""
    cache = ""
    inventory_mgr.parse_source(source, filename, config_file, loader, cache)

# Generated at 2022-06-24 19:53:06.896214
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    float_0 = 2739.321
    float_1 = float_0
    var_0 = InventoryManager(float_1)

    float_0 = 2739.321
    float_1 = float_0
    var_0.subset(float_1)


# Generated at 2022-06-24 19:53:13.698360
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    host_list = [{u'test': u'dict'}, 'notadict']
    host_list_0 = list()
    float_0 = 2.389
    var_0 = InventoryManager(host_list_0, float_0)
    bool_0 = bool()
    bool_1 = bool()
    var_3 = var_0.parse_source(host_list, bool_0, bool_1)
    assert var_3 == [{u'test': u'dict'}, {u'test': u'notadict'}]


# Generated at 2022-06-24 19:53:15.147584
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():

    obj = InventoryManager(inventory=None)

    subset_pattern = None
    obj.subset(subset_pattern)


# Generated at 2022-06-24 19:53:40.620840
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory = FakeInventory()
    subset_pattern = "all"
    inventory.subset(subset_pattern)


# Generated at 2022-06-24 19:53:48.439328
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    # Create an instance of InventoryManager
    inventory_manager_0 = InventoryManager()

    # Create an instance of DataLoader
    data_loader_0 = DataLoader()

    # Create an instance of InventorySource
    inventory_source_0 = InventorySource()

    # Create an instance of Inventory
    inventory_0 = Inventory()

    # Create an instance of Group
    group_0 = Group()

    # Create an instance of Host
    host_0 = Host()

    # Create an instance of Host
    host_1 = Host()

    # Create an instance of VariableManager
    variable_manager_0 = VariableManager()

    # Create an instance of AnsibleModule
    ansible_module_0 = AnsibleModule()

    # Set properties of var_parser
    ansible_module_0.var_parser = VariableParser()

    # Set properties of vars

# Generated at 2022-06-24 19:53:53.222122
# Unit test for function split_host_pattern
def test_split_host_pattern():
    float_0 = 2739.321
    var_0 = split_host_pattern(float_0)
    assert var_0 is None


# Generated at 2022-06-24 19:53:56.953537
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    # Setup
    sources = None
    cache = None
    inventory = InventoryManager(sources)
    inventory.subset("localhost")
    # Operation
    result = inventory.parse_source("localhost")
    # Verification
    assert result is not None
    # Cleanup
    cleanup(cache)


# Generated at 2022-06-24 19:54:00.623943
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    a = InventoryManager()
    a._evaluate_patterns(ansible.utils.patterns.Pattern.create_from_list([u'foo*']))
    a.get_hosts(pattern="all", ignore_limits=False, ignore_restrictions=False, order=None)
    a.remove_restriction()
    a.clear_pattern_cache()


# Generated at 2022-06-24 19:54:02.937363
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    # Arrange
    inventoryManager = InventoryManager('hosts')

    # Act and Assert
    for result in inventoryManager.get_hosts('all'):
        assert isinstance(result, Host)


# Generated at 2022-06-24 19:54:07.131577
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventoryManager = InventoryManager()
    inventoryManager.subset(set())
    assert 0


# Generated at 2022-06-24 19:54:13.396112
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    pattern = 2739.321
    ignore_limits = True
    ignore_restrictions = True
    order = None
    obj_InventoryManager = InventoryManager(pattern, ignore_limits, ignore_restrictions, order)
    obj_InventoryManager.get_hosts(pattern, ignore_limits, ignore_restrictions, order)


# Generated at 2022-06-24 19:54:15.141105
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory_manager = InventoryManager(loader=None)
    inventory_manager.parse_source()


# Generated at 2022-06-24 19:54:17.290520
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():
    # Testcase 0
    manager_0 = InventoryManager()
    manager_0.clear_pattern_cache()


# Generated at 2022-06-24 19:54:59.968080
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    hosts = {u'127.0.0.1': Group([Host(name=u'127.0.0.1')])}
    groups = {u'all': Group(name=u'all', hosts=hosts.values(), vars={u'foo': u'bar'}, child_groups=hosts.values())}
    inventory = Inventory(hosts=hosts, groups=groups)
    cache = vars_cache.VarsCache(inventory)
    loader = DataLoader()
    inventory_manager = InventoryManager(None, loader, sources=u'')


# Generated at 2022-06-24 19:55:06.954138
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # Create an object of InventoryManager to test
    float_0 = 2739.321
    float_1 = float_0
    int_0 = -1
    str_0 = 'pylint_test'
    inventory_manager_0 = InventoryManager(float_0, float_1, int_0, str_0)

    # Call method subset with a basic argument
    inventory_manager_0.subset(str_0)


# Generated at 2022-06-24 19:55:09.356273
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    try:
        print(get_application_path())
    except:
        print(traceback.format_exc()) 

# Generated at 2022-06-24 19:55:12.459194
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    float_0 = 2739.321
    inv_mgr = InventoryManager(float_0)
    float_1 = 2739.321
    var_0 = inv_mgr.subset(float_1)


# Generated at 2022-06-24 19:55:14.160330
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    temp_10 = [None, 2739.321]
    temp_11 = split_host_pattern(temp_10)


# Generated at 2022-06-24 19:55:16.493825
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inv_mgr = InventoryManager()
    raw_data = "file.txt"
    inv_mgr.parse_source(raw_data)
    assert inv_mgr.source == "file.txt"


# Generated at 2022-06-24 19:55:27.400053
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # Dummy inventory, does not have to do anything but load
    class DummyInventory(object):
        def __init__(self, host_list=['dummy_host0', 'dummy_host1', 'dummy_host2']):
            self.host_list = host_list

        def get_host(self, host_name):
            if host_name in self.host_list:
                return host_name
            else:
                return None

    # Test to see if a number of hosts is filtered to a subset
    dummy_inventory = DummyInventory()
    test_case = InventoryManager(loader=None, sources='./library/inventory/test_cases/plugins/inventory/')
    subset_pattern = 'dummy_host[0:1]'

    # Should return a list with two results

# Generated at 2022-06-24 19:55:34.296742
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager_0 = InventoryManager("/etc/ansible/hosts")
    inventory_manager_0.subset("/etc/ansible/hosts")

    # should raise an error because it is expecting a string
    with pytest.raises(TypeError):
        inventory_manager_0.subset(2739.321)



# Generated at 2022-06-24 19:55:37.557348
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():

    test_dir = os.path.dirname(os.path.realpath(__file__))
    inventory_file = os.path.join(test_dir, 'hosts.sample')

    inv_data = InventoryManager(inventory=inventory_file).get_inventory()
    assert type(inv_data) == Inventory


# Generated at 2022-06-24 19:55:41.140595
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    test_case_0()


# Generated at 2022-06-24 19:56:07.147785
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    import unittest
    import data
    got = data.got
    var_0 = InventoryManager(data.to_text(None))
    var_1 = data.to_text('enp0s8')
    var_2 = data.to_text('0.0.0.0')
    var_3 = data.to_text('static')
    var_4 = data.to_text('netmask')
    var_5 = data.to_text('255.255.255.0')
    var_6 = data.to_text('gateway')
    var_7 = data.to_text('192.168.56.1')
    var_8 = data.to_text('domain')
    var_9 = data.to_text('local')
    var_10 = data.to_text('broadcast')


# Generated at 2022-06-24 19:56:14.635053
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    float_0 = 568.0
    float_0 = float_0 - float(0)
    float_1 = float_0 + float(0)
    float_1 = float(0) / float_0
    float_2 = float(0) * float(0)
    float_3 = float_1 * float_1
    float_1 = float_0 - float_0
    float_1 = float_0 * float_0
    float_2 = float_1 - float_1
    float_1 = float_0 - float_0
    float_2 = float(0) / float(0)
    float_2 = float_1 + float_1
    float_3 = float_1 * float_1
    float_0 = float_0 + float(0)
    float_1 = float_0 + float_0

# Generated at 2022-06-24 19:56:18.412708
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory_manager_0 = InventoryManager(None)
    string_0 = 'str'
    boolean_0 = False
    var_0 = inventory_manager_0.get_hosts(string_0, boolean_0, boolean_0, string_0)


# Generated at 2022-06-24 19:56:21.752470
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager_object = InventoryManager()
    subset_pattern = "ev er yth in g "
    result = inventory_manager_object.subset(subset_pattern)
    assert result == None, "'subset' test failed."


# Generated at 2022-06-24 19:56:27.596670
# Unit test for method get_hosts of class InventoryManager

# Generated at 2022-06-24 19:56:35.587191
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    params_0 = ['var_0']
    b_var_0 = to_bytes('var_0')
    b_var_1 = to_bytes('var_1')
    b_var_2 = to_bytes('var_2')

    # Setup inventory manager
    inventory = InventoryManager(loader=get_loader(), sources=b_var_0)

    # Setup used inventory
    inventory.hosts = {b_var_1: dict(name=b_var_1), b_var_2: dict(name=b_var_2)}

    # Setup subset
    subset = []

    # Setup expected results
    expected = []

    # Test run
    inventory.subset(subset)
    results = inventory._subset

    # Assert result
    assert expected == results


# Generated at 2022-06-24 19:56:37.603371
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():
    assert False


# Generated at 2022-06-24 19:56:42.507361
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    obj = 'obj' # Inject variable
    var_1 = InventoryManager(obj) # Instantiate InventoryManager
    source = 'source'
    cache = 'cache'
    var_1.parse_source(source, cache)


# Generated at 2022-06-24 19:56:44.464157
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    class DummyClass(object):
        self = object()
        subset_pattern = object()
    obj = DummyClass()
    InventoryManager.subset(obj, obj.subset_pattern)


# Generated at 2022-06-24 19:56:45.965122
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():
    inventory = InventoryManager()
    config = None
    sources = ','
    inventory.parse_sources(sources, config)
    return 0


# Generated at 2022-06-24 19:57:15.463379
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory = Inventory(host_list=C.DEFAULT_HOST_LIST)
    inventory.parse_inventory(inventory.host_list)
    manager = InventoryManager(inventory=inventory)
    pattern = "all"
    ignore_limits = False
    ignore_restrictions = False
    order = None
    result = manager.get_hosts(pattern=pattern, ignore_limits=ignore_limits, ignore_restrictions=ignore_restrictions, order=order)
    assert result is None


# Generated at 2022-06-24 19:57:18.248676
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    float_0 = 7073.1
    var_0 = InventoryManager(float_0)
    float_1 = 806.84
    var_0.subset(float_1)


# Generated at 2022-06-24 19:57:19.684945
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    assert callable(InventoryManager.parse_source)


# Generated at 2022-06-24 19:57:27.661924
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    assert InventoryManager().parse_source("localhost.yml") == "localhost"
    assert InventoryManager().parse_source("localhost.ini") == "localhost"
    assert InventoryManager().parse_source("/path/to/playbook/inventory/localhost.yml") == "localhost"
    assert InventoryManager().parse_source("/path/to/playbook/inventory/localhost.ini") == "localhost"
    assert InventoryManager().parse_source("/path/to/playbook/inventory/plugins/inventory/localhost.yml") == "localhost"
    assert InventoryManager().parse_source("/path/to/playbook/inventory/plugins/inventory/localhost.ini") == "localhost"
    assert InventoryManager().parse_source("/path/to/custom_inventory.yml") == "custom_inventory.yml"

# Generated at 2022-06-24 19:57:28.882682
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory = InventoryManager()
    inventory.parse_source('ec2.py', cache=False)


# Generated at 2022-06-24 19:57:31.888631
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    random_host = 'random_host'
    inventory_instance = InventoryManager(random_host)
    source = None
    result = inventory_instance.parse_source(source)
    assert result == False


# Generated at 2022-06-24 19:57:36.791847
# Unit test for function split_host_pattern
def test_split_host_pattern():
    print("Testing split_host_pattern")

    assert split_host_pattern('a') == ['a']
    assert split_host_pattern(['a']) == ['a']

    assert split_host_pattern(':a:b:') == ['a', 'b']
    assert split_host_pattern([':a:', ':b:c:d:']) == ['a', 'b', 'c', 'd']

    assert split_host_pattern('a:b:c') == ['a:b:c']
    assert split_host_pattern(['a:b:c', 'd:e:f']) == ['a:b:c', 'd:e:f']

    assert split_host_pattern('a,b') == ['a', 'b']

# Generated at 2022-06-24 19:57:42.845853
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():
    logger = logging.getLogger()
    logger.info(" ")
    logger.info(" ############################################################################## ")
    logger.info(" #               TESTING - InventoryManager.parse_sources                    # ")

    # Initialize
    host_list = ['lucky', 'ranger', 'clint', 'jolly', 'hondo', 'william', 'josey', 'josie']
    group_mapping = dict()
    group_mapping['hosts'] = [host_list]
    group_mapping['vars'] = dict()

    inventory_manager = InventoryManager('/root/ansible/inventory')
    logger.info(inventory_manager)
    logger.info("inventory_manager.list_groups(): ")
    logger.info(inventory_manager.list_groups())

# Generated at 2022-06-24 19:57:52.485687
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    float_1 = 0.52
    if float_1 < float_1:
        var_0 = float_1
    else:
        var_0 = None
    var_1 = u'1'
    var_2 = u'2'
    var_3 = u'3'
    var_4 = u'4'
    var_5 = u'5'
    var_6 = u'6'
    var_7 = u'7'
    var_8 = u'8'
    var_9 = InventoryManager(var_0, var_1, var_2, var_3, var_4, var_5, var_6, var_7, var_8)
    var_10 = u'test'
    var_9.subset(var_10)


# Generated at 2022-06-24 19:57:53.747140
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():
    inv_manager = InventoryManager()
    inv_manager.parse_sources()


# Generated at 2022-06-24 19:58:26.894450
# Unit test for function split_host_pattern
def test_split_host_pattern():
    class TestCase:
        def __init__(self, arg_pattern, arg_expect):
            self.pattern = arg_pattern
            self.expect = arg_expect

    test_cases = [
        TestCase('a,b[1], c[2:3] , d',['a', 'b[1]', 'c[2:3]', 'd']),
        TestCase('a,b[1], c[2:3] , d,',['a', 'b[1]', 'c[2:3]', 'd']),

    ]
    for tc_idx, tc in enumerate(test_cases, start=1):
        res_0 = split_host_pattern(tc.pattern)
        res_1 = (tc.expect == res_0)

# Generated at 2022-06-24 19:58:30.026606
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    display.display("*** Testing parse_source ***", verbosity=1)
    manager = InventoryManager(loader=DictDataLoader(), sources='hosts')
    result = manager.parse_source()
    assert result == (manager, 'hosts')


# Generated at 2022-06-24 19:58:37.240991
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    float_0 = 1437.35
    var_0 = split_host_pattern(float_0)
    float_1 = -90.8005
    var_1 = InventoryManager(float_1)
    float_2 = -28.9
    var_1.subset(float_2)
    str_0 = 'all'
    float_3 = -2.9e-05
    var_2 = var_1.get_hosts(str_0, float_3)
    float_4 = -13.7
    var_1.subset(float_4)


# Generated at 2022-06-24 19:58:38.988743
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    float_0 = 2739.321
    var_0 = InventoryManager(float_0).subset(float_0)


# Generated at 2022-06-24 19:58:39.877754
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    # FIXME: implement
    pass
