

# Generated at 2022-06-24 19:49:15.064959
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    inventory = InventoryManager(loader=CLI.get_default_cli_loader().get_loader(inventory=None))
    inventory.parse_inventory(host_list=[u'host0', u'host1'])
    host_pattern = u'all'
    result = inventory.list_hosts(pattern=host_pattern)

    # Test if result equals expected result
    assert result == [u'host0', u'host1']


# Generated at 2022-06-24 19:49:23.842819
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory = Inventory()
    inventory.add_host(Host(name="test"))
    inventory_manager = InventoryManager(inventory)
    (parsed, starting_port) = inventory_manager.parse_source('localhost=10.0.0.1', False, False)
    assert parsed == [('localhost', '10.0.0.1')]
    assert starting_port == ''
    (parsed, starting_port) = inventory_manager.parse_source('localhost=10.0.0.1:50', False, False)
    assert parsed == [('localhost', '10.0.0.1')]
    assert starting_port == '50'
    (parsed, starting_port) = inventory_manager.parse_source('localhost ansible_connection=docker', False, True)

# Generated at 2022-06-24 19:49:29.490775
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    manager = InventoryManager(loader=DataLoader())
    source = 'host_list'
    plugin_name = None
    config = dict()
    inventory = Inventory(loader=manager._loader)
    cache = dict()
    var_0 = manager.parse_source(source, plugin_name, config, inventory, cache)


# Generated at 2022-06-24 19:49:33.199700
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    bytes_0 = b'\x8bY&\r\n\x81\xcd{\xa7\r\x8d\xc3d\x92'
    var_0 = split_host_pattern(bytes_0)
    assert var_0


# Generated at 2022-06-24 19:49:42.687393
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager_0 = InventoryManager(loader=None, sources=u'[hosts]\nlocalhost\n')
    bytes_0 = b'\x8bY&\r\n\x81\xcd{\xa7\r\x8d\xc3d\x92'
    res = inventory_manager_0.subset(bytes_0)
    assert res is None
    var_0 = split_host_pattern(bytes_0)
    res_1 = inventory_manager_0.subset(var_0)
    assert res_1 is None
    res_2 = inventory_manager_0.subset(res_1)
    assert res_2 is None
    res_3 = inventory_manager_0.subset(var_0)
    assert res_3 is None


# Generated at 2022-06-24 19:49:46.403621
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager_instance = InventoryManager()
    subset_pattern_0 = b'\x88\x13\x8d\xa6\xa1\x19'
    var_0 = inventory_manager_instance.subset(subset_pattern_0)
    if (var_0 is not None):
        raise Exception("Variable 'var_0' is not None")


# Generated at 2022-06-24 19:49:56.318097
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    """
    Testcase for method _InventoryManager.parse_source
    """
    from ansible.errors import AnsibleParserError

    source_data, source_type, source_path = (None, None, None)
    im = InventoryManager(loader=object)
    result = im._parse_source(source_data, source_type, source_path)
    assert result == (None, {})

    source_data, source_type, source_path = (None, "string", None)
    im = InventoryManager(loader=object)
    with pytest.raises(AnsibleParserError) as e_info:
        result = im._parse_source(source_data, source_type, source_path)
    assert e_info.value.message.startswith("Please specify a string to use with the string inventory plugin")

   

# Generated at 2022-06-24 19:50:01.749842
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    # Test the 'parse_source_data' method of the InventoryManager class
    # inventory_manager = InventoryManager()
    # ret = inventory_manager.parse_source()
    # print(ret)

    bytes_0 = b'\x8bY&\r\n\x81\xcd{\xa7\r\x8d\xc3d\x92'
    var_0 = split_host_pattern(bytes_0)
    return var_0


# Generated at 2022-06-24 19:50:06.192038
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    b_var_0 = b"J"
    inventory_manager_0 = InventoryManager(b_var_0)
    bytes_0 = b'\x8bY&\r\n\x81\xcd{\xa7\r\x8d\xc3d\x92'
    result_0 = inventory_manager_0.parse_source(bytes_0)


# Generated at 2022-06-24 19:50:11.068913
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager_0 = InventoryManager()
    subset_pattern_0 = b'localhost,'
    inventory_manager_0.subset(subset_pattern_0)


# Generated at 2022-06-24 19:50:37.491478
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    inventory_0 = InventoryManager(loader=None)
    inventory_0.list_hosts(None)


# Generated at 2022-06-24 19:50:39.651257
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager = InventoryManager()
    inventory_manager.subset(True)
    assert inventory_manager._subset == True


# Generated at 2022-06-24 19:50:44.442696
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    bytes_0 = b'P\x07'
    inventory_manager_0 = InventoryManager(bytes_0)
    pattern_0 = b'\x06\x17\x8b\x1ff\xe9\x18\xcf\x88'
    inventory_manager_0.subset(pattern_0)


# Generated at 2022-06-24 19:50:50.417851
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    bytes_0 = b'\x8bY&\r\n\x81\xcd{\xa7\r\x8d\xc3d\x92'

    # test for exception
    try:
        var_0 = InventoryManager(bytes_0)
    except Exception as e:
        pass

    # test for attribute type
    var_1 = InventoryManager(bytes_0)
    assert isinstance(var_1.hosts, dict)
    assert isinstance(var_1.patterns, dict)


# Generated at 2022-06-24 19:50:56.579628
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    print("test_InventoryManager_parse_source()")
    var_args = dict()
    var_args['src'] = b'\x8bY&\r\n\x81\xcd{\xa7\r\x8d\xc3d\x92'
    var_args['group_name'] = 'foo'
    var_args['playbook_basedir'] = 'foo'
    var_args['basedir'] = 'foo'
    var_args['vars'] = 'foo'
    print("call InventoryManager.parse_source(**var_args)")
    var_obj = InventoryManager(**var_args)
    var_args = dict()

# Generated at 2022-06-24 19:50:58.275709
# Unit test for method get_hosts of class InventoryManager

# Generated at 2022-06-24 19:51:06.096269
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    ansible = Ansible()
    ansible.options = Options()
    ansible.options.verbosity = 0
    ansible.options.inventory = None
    ansible.playbooks.playbook = "./test/playbooks/ansible/test_playbook.yml"
    ansible.inventory.load_inventory(ansible.options.inventory)
    manager = InventoryManager(ansible.inventory)
    host_list = manager.list_hosts()
    assert "jenkins_master" in host_list
    assert "jenkins_master" in manager.list_hosts()
    assert "jenkins_slave" in host_list

if __name__ == "__main__":
    # test_case_0()
    test_InventoryManager_list_hosts()

# Generated at 2022-06-24 19:51:18.618381
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    bytes_0 = b'#\x05\xad\xad\xa5\x0e\x90\xdb\x0b\xf4\x9a\xd4'

    # Create a temp file for the inventory
    inventory_temp_file = tempfile.NamedTemporaryFile(mode='w', delete=False)
    inventory_temp_file.write('[foo]\nlocalhost ansible_connection=local')
    inventory_temp_file.close()

    # Create an inventory plugin
    inventory_plugin = InventoryModule()
    inventory_plugin.parse(inventory_temp_file.name, bytes_0, None)

    # Create an inventory
    inventory = Inventory(inventory_temp_file.name)
    inventory.set_inventory_basedir("./")
    inventory.parse_inventory(inventory_plugin)
   

# Generated at 2022-06-24 19:51:24.560591
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    var_1 = '[foo]\nbar\n[group1]\nhost1\nhost2'
    var_2 = u'group1'
    var_3 = InventoryManager(loader=DataLoader(), sources=var_1)
    var_3.subset(var_2)
    pass


# Generated at 2022-06-24 19:51:25.720997
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory = InventoryManager(loader=None, sources='')
    subset_pattern = 'local'
    inventory.subset(subset_pattern)


# Generated at 2022-06-24 19:51:47.078440
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    inv = InventoryManager(loader=DataLoader())
    inv.add_host(host='foobar', group='test_group')
    inv.add_host(host='barbaz', group='test_group')
    inv.add_host_group(group='test_group')
    assert inv.list_hosts(pattern='test_group') == ['barbaz', 'foobar']
    inv.add_group(group='test_group2')
    assert inv.list_hosts(pattern='test_group,test_group2') == ['barbaz', 'foobar']
    assert inv.list_hosts(pattern='test_group:test_group2') == ['barbaz', 'foobar']
    assert inv.list_hosts(pattern='all') == ['barbaz', 'foobar']
    assert inv.list

# Generated at 2022-06-24 19:51:57.528240
# Unit test for method list_hosts of class InventoryManager

# Generated at 2022-06-24 19:52:04.818463
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    var_0 = InventoryManager(Inventory())
    var_1 = to_bytes('"\xce\x99\xce\xbe\xce\xb4\xce\xb9\xce\xbf\xcf\x85"')
    try:
        var_0.subset(var_1)
    except:
        pass


# Generated at 2022-06-24 19:52:10.319996
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    args_0 = {u'pattern': b'\x9c\x0b\xdct\x1e\x94\xc0\x8b1r\xcf'}
    obj_0 = InventoryManager()
    func_0 = obj_0.list_hosts
    assert func_0(**args_0) == [b'\x9c\x0b\xdct\x1e\x94\xc0\x8b1r\xcf']


# Generated at 2022-06-24 19:52:20.346581
# Unit test for function order_patterns
def test_order_patterns():
    assert order_patterns(['!*']) == ['*']
    assert order_patterns(['!*', '*']) == ['*', '*']
    assert order_patterns(['!*', '*', 'a']) == ['*', '*', 'a']
    assert order_patterns(['&a', '*', 'a']) == ['*', 'a', 'a']
    assert order_patterns(['&a', '*', '!a']) == ['*', 'a', '!a']
    assert order_patterns(['!*', '!a', '&a', '*', 'a']) == ['*', '*', 'a', 'a', '!a']


########################################
# add_host can be used to add a host from one of the following:
#    - a

# Generated at 2022-06-24 19:52:24.152043
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():

    # Call the method of the class InventoryManager
    var_0 = subset(var_0)


# Generated at 2022-06-24 19:52:31.468206
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    bytes_0 = b'\x8bY&\r\n\x81\xcd{\xa7\r\x8d\xc3d\x92'
    bytes_1 = b'\xaf\x0c\x12\xff\xe9\\\xdb'
    bytes_2 = b'\xff\x0c\x12\xff\xe9\\\xdb'
    var_0 = False
    var_1 = 1
    var_2 = False
    if var_0:
        var_3 = b'\x8bY&\r\n\x81\xcd{\xa7\r\x8d\xc3d\x92'
        var_3 = bytes_0[var_1:len(bytes_0)]

# Generated at 2022-06-24 19:52:35.397135
# Unit test for function order_patterns
def test_order_patterns():
    pattern_list = order_patterns(['web[0:2]', '&app[0]', 'db[1:2]'])
    assert pattern_list == ['web[0:2]', 'app[0]', 'db[1:2]']


# Generated at 2022-06-24 19:52:40.509119
# Unit test for method list_hosts of class InventoryManager

# Generated at 2022-06-24 19:52:46.645978
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    bytes_0 = b'\x8bY&\r\n\x81\xcd{\xa7\r\x8d\xc3d\x92'
    var_0 = split_host_pattern(bytes_0)
    var_1 = InventoryManager(var_0)
    bytes_1 = b'\x8bY&\r\n\x81\xcd{\xa7\r\x8d\xc3d\x92'
    var_2 = InventoryManager.list_hosts(var_1, bytes_1)


# Generated at 2022-06-24 19:53:05.913137
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # Initialize a TestInventoryManager object named TestInventoryManager
    TestInventoryManager = InventoryManager(loader=None, sources='localhost')

    # Test subset(subset_pattern)
    TestInventoryManager.subset(subset_pattern='localhost')


# Generated at 2022-06-24 19:53:15.128805
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    mgr = InventoryManager()
    var_0 = random.randint(1, 5)
    var_1 = bytes(var_0)
    mgr.subset(var_1)
    var_2 = random.randint(1, 4)
    var_3 = bytes(var_2)
    mgr.subset(var_3)
    var_4 = random.randint(1, 3)
    var_5 = bytes(var_4)
    mgr.subset(var_5)
    var_6 = random.randint(1, 2)
    var_7 = bytes(var_6)
    mgr.subset(var_7)
    var_8 = random.randint(1, 1)
    var_9 = bytes(var_8)

# Generated at 2022-06-24 19:53:18.393977
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager = InventoryManager()
    subset_pattern = '127.0.0.1'
    inventory_manager.subset(subset_pattern)


# Generated at 2022-06-24 19:53:23.458834
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    bytes_0 = b'\x8bY&\r\n\x81\xcd{\xa7\r\x8d\xc3d\x92'
    var_0 = split_host_pattern(bytes_0)

    # test subset
    x = InventoryManager(None)
    x.subset(var_0)


# Generated at 2022-06-24 19:53:27.097118
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory = InventoryManager()
    assert inventory.parse_source('localhost', 'localhost') == 'localhost'


# Generated at 2022-06-24 19:53:28.951187
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory_manager = InventoryManager()
    display.vvv('TEST: inventory_manager.parse_source()')
    assert len(inventory_manager.sources) == 0


# Generated at 2022-06-24 19:53:39.110543
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():

    # If a relative file path is given, it is expected that the default
    # directory will be based on the playbook directory or current working
    # directory

    # Directory is not given and we use a relative path
    yaml_file_path = "../../tests/inventory/test_inventory_manager/parse-source/hosts"
    inventory_manager = InventoryManager(loader=None, sources=yaml_file_path)
    inventory_manager._read_inventory_from_cache = True
    inventory_manager.parse_sources()

    # Directory is not given and we use a relative path
    yaml_file_path = "./tests/inventory/test_inventory_manager/parse-source/hosts"
    inventory_manager = InventoryManager(loader=None, sources=yaml_file_path)
    inventory_manager._read_inventory_from_

# Generated at 2022-06-24 19:53:43.139574
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory_file = './test_data/inventory_file_0'
    inventory_file_content = get_file_content(inventory_file)
    inventory_file_obj = StringIO(inventory_file_content)

    inventory = InventoryFile(inventory_file_obj)
    inventory_manager = InventoryManager(inventory)

    assert inventory_manager.get_hosts() == ['localhost']


# Generated at 2022-06-24 19:53:50.041805
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory = InventoryManager(loader=FileLoader, sources='/mnt/c/Users/micha/Desktop/ansible-tower-setup-bundle-3.6.1-1.el7.tar.gz/ansible-tower-setup-bundle-3.6.1-1.el7/inventory')
    string_0 = b'\x00\x00\x00i\x00\x00\x00\x00\x00\x00\t'
    string_1 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    inventory.subset(string_0 + string_1)


# Generated at 2022-06-24 19:53:55.939857
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_file = './test/unit/inventory/ansible_inventory'
    subset = '~(?P<match>.*)\.example\.com'

    inventory = BaseInventory.parse_inventory(inventory_file)
    inventory = InventoryManager(loader=None, sources=inventory_file)

    # using limit
    inventory.subset(subset)
    hosts = inventory.get_hosts()
    assert hosts == ['host.example.com', 'host2.example.com'], 'hosts should be filtered by the subset pattern'

    # using all
    inventory.subset('all')
    hosts = inventory.get_hosts()
    assert hosts == ['localhost', 'host.example.com', 'host2.example.com'], 'hosts should include all hosts in inventory'

    # using empty subset
    inventory.subset

# Generated at 2022-06-24 19:54:13.457988
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    str_1 = './test_data/inventory_file_0'
    inv = InventoryManager(loader=DataLoader(), sources=str_1)
    print(inv.list_hosts())
    print(inv.list_hosts(pattern='win'))
    print(inv.list_hosts(pattern='all'))
    print(inv.list_hosts(pattern='all:children'))
    print(inv.list_hosts(pattern='all:!win'))
    print(inv.list_hosts(pattern="~^(w.*)?$"))



# Generated at 2022-06-24 19:54:21.239977
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    # get the current time for time measurement
    start_time = time.time()

    # get the inventory object
    im = InventoryManager('.')
    im.parse_inventory('./test_data/inventory_file_0')

    # do the test
    im.list_hosts("node?")

    # get the elapsed time
    elapsed_time = time.time() - start_time

    # file's name of the test case
    file_name = sys._getframe().f_code.co_name

    # print out the test results
    write_test_result(elapsed_time, file_name)



# Generated at 2022-06-24 19:54:23.897933
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory = InventoryManager(str_0)
    # TODO: fix this test
    subset_pattern = 'all'
    inventory.subset(subset_pattern)


# Generated at 2022-06-24 19:54:27.385442
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    print('>>> Start test InventoryManager::list_hosts')
    print('>>> Load inventory file')
    inventory_file_0 = './test_data/inventory_file_0'
    inventory_manager_0 = InventoryManager(loader=None, sources=inventory_file_0)
    inventory_manager_0.parse_inventory(inventory_file_0)
    print(inventory_manager_0.get_hosts())
    print('>>> Stop test InventoryManager::list_hosts')

test_InventoryManager_list_hosts()


# Generated at 2022-06-24 19:54:31.969767
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    # arrange
    str_0 = './test_data/inventory_file_0'
    inventory_manager = InventoryManager(loader=None, sources=str_0)
    # act
    res_0 = inventory_manager.list_hosts()

# Generated at 2022-06-24 19:54:33.005736
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory = InventoryManager(str_0)


# Generated at 2022-06-24 19:54:43.154631
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    #######################################################################
    #
    # Test get_hosts method of class InventoryManager
    #
    #######################################################################
    inventory_str = './test_data/inventory_file_0'
    inventory_manager = InventoryManager(inventory_str)
    #pattern='all', ignore_limits=False, ignore_restrictions=False, order=None
    hosts = inventory_manager.get_hosts(pattern="all")
    print("hosts: %s" % hosts)
    hosts = inventory_manager.get_hosts(pattern="all", ignore_limits=True, ignore_restrictions=True, order='sorted')
    print("hosts: %s" % hosts)


if __name__ == "__main__":
    test_InventoryManager_get_hosts()

# Generated at 2022-06-24 19:54:53.369986
# Unit test for function split_host_pattern
def test_split_host_pattern():
    str_0 = './test_data/inventory_file_0'

# Generated at 2022-06-24 19:54:59.351180
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    ##########################################################################
    # Arrange:
    input_0 = './test_data/inventory_file_0'
    h = InventoryManager(loader=DataLoader())
    h.parse_inventory(host_list=input_0)

    ##########################################################################
    # Act:
    actual = h.list_hosts()
    expected = ['localhost', 'webservers', 'dbservers']

    ##########################################################################
    # Assert:
    assert actual == expected, '%s != %s' % (actual, expected)


# Generated at 2022-06-24 19:55:10.399529
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    iv = InventoryManager(loader=DataLoader())
    iv.add_source('hosts', './test_data/hosts_file_0')

    # set a inventory reader pattern specific vars
    iv.get_host('all').set_variable('ansible_connection', 'ssh')
    iv.get_group('all').set_variable('test_key', 'test_value')
    iv.get_group('all').set_variable('test_key', 'test_value_override')
    iv.get_group('all').set_variable('test_key_1', 'test_value_1')
    iv.get_host('host_0').set_variable('ansible_ssh_pass', '123456')

    # get all
    all_hosts = iv.get_host('all')

# Generated at 2022-06-24 19:55:24.554063
# Unit test for method subset of class InventoryManager

# Generated at 2022-06-24 19:55:34.383737
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    str_0 = './test_data/inventory_file_0'
    str_1 = './test_data/inventory_file_1'
    str_2 = './test_data/inventory_file_2'
    str_3 = './test_data/inventory_file_3'
    str_4 = './test_data/inventory_file_4'
    str_5 = './test_data/inventory_file_5'
    str_6 = './test_data/inventory_file_6'
    str_7 = './test_data/inventory_file_7'
    str_8 = './test_data/inventory_file_8'
    str_9 = './test_data/inventory_file_9'
    str_10 = './test_data/inventory_file_10'
   

# Generated at 2022-06-24 19:55:35.892322
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():
    def _case_0():
        str_0 = './test_data/inventory_file_0'



# Generated at 2022-06-24 19:55:37.953645
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    with open(str_0, 'r') as f:
        inventory = InventoryManager(loader=DataLoader())
        inventory.parse_inventory(f)
        inventory.subset('all')


# Generated at 2022-06-24 19:55:42.867584
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager = InventoryManager(loader = None, sources = str_0)
    subset_pattern = 'sub'
    inventory_manager.subset(subset_pattern)


# Generated at 2022-06-24 19:55:49.266837
# Unit test for function split_host_pattern
def test_split_host_pattern():
    # case 0:
    # str_0 = './test_data/inventory_file_0'
    # result = split_host_pattern(str_0)
    # print(result)
    # assert result == [str_0]
    # case 1:
    str_1 = 'a,b[1],c[2:3],d'
    result = split_host_pattern(str_1)
    print(result)
    assert result == ['a','b[1]','c[2:3]','d']
    # case 2:
    str_2 = 'a:b:c:d'
    result = split_host_pattern(str_2)
    print(result)
    assert result == ['a:b:c:d']
    # case 3:

# Generated at 2022-06-24 19:55:56.118721
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    manager = None
    items = ['foo', 'bar', 'baz']
    pattern = 'foo*'
    ignore_limits = 0
    ignore_restrictions = 0
    order = None
    # Call method
    ret = manager.get_hosts(pattern, ignore_limits, ignore_restrictions, order)
    assert ret == items
if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 19:56:01.758393
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():

    inv_manager = InventoryManager(inventory_class)

    sources = [
        '/tmp/inventory_file_0',
        '/tmp/inventory_file_1',
        '/tmp/inventory_file_2',
        '/tmp/inventory_file_3',
        '/tmp/inventory_file_4',
        '/tmp/inventory_file_5',
    ]
    inv_manager.parse_sources(sources)


# Generated at 2022-06-24 19:56:04.983327
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    print('test_InventoryManager_subset')
    inventory_file = './test_data/inventory_file_0'
    inventory_manager = InventoryManager(inventory_file)
    subset_pattern = None
    inventory_manager.subset(subset_pattern)


# Generated at 2022-06-24 19:56:10.186240
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    str_0 = './test_data/inventory_file_0'
    inventory_manager = InventoryManager(str_0)
    print(inventory_manager.list_hosts())


# Generated at 2022-06-24 19:56:30.449134
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()
    bool_10 = bool()
    bool_11 = bool()
    bool_12 = bool()
    bool_13 = bool()
    bool_14 = bool()
    bool_15 = bool()
    bool_16 = bool()
    bool_17 = bool()
    bool_18 = bool()
    bool_19 = bool()
    bool_20 = bool()
    bool_21 = bool()
    bool_22 = bool()
    coords_0 = coords()
    coords_1

# Generated at 2022-06-24 19:56:41.519943
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    # set up inventory
    inventory = InventoryManager(loader=DataLoader())
    inventory.add_host(Host(name='localhost', groups=['ungrouped']))
    inventory.add_host(Host(name='host_0', groups=['group_0', 'group_1']))
    inventory.add_host(Host(name='host_1', groups=['group_1']))
    inventory.add_host(Host(name='host_2', groups=['group_0']))

    # do tests
    assert inventory.get_hosts('all') == [inventory.get_host(name) for name in ['localhost', 'host_0', 'host_1', 'host_2']]
    assert inventory.get_hosts('localhost') == [inventory.get_host('localhost')]

# Generated at 2022-06-24 19:56:46.473622
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    var_1 = InventoryManager(['[', ".", "]"])
    var_1.subset('test_0')

# Disabled because this test can not be run without loading the inventory

# Generated at 2022-06-24 19:56:49.678127
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    # initialize
    inventoryManager_0 = InventoryManager()

    # setup
    inventoryManager_0._inventory = magicMock()

    # test
    try:
        inventoryManager_0.parse_source('foobar')
        assert False
    except AnsibleError:
        assert True
    except:
        assert False


# Generated at 2022-06-24 19:56:57.075020
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():
    display.display(u'dot1')
    test_0 = InventoryManager([])
    # Variables
    _0 = DataLoader()
    _1 = Inventory(loader=_0, host_list=[])
    # Test
    display.display(u'dot2')
    test_0.parse_sources([])
    display.display(u'dot3')
    test_0.parse_sources(["host_list"])
    display.display(u'dot4')
    test_0.parse_sources(["host_list", "auto"])
    display.display(u'dot5')
    test_0.parse_sources(["auto"])
    display.display(u'dot6')


# Generated at 2022-06-24 19:57:04.067976
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    """ list_hosts function unit tests."""

    # inventory manager creation for testing
    inv_mgr = InventoryManager(inventory="test/test_inv.ini")

    ######################################
    # Test with no args
    ######################################
    inventory_result = inv_mgr.list_hosts()
    expected_host = ['host2', 'host1', 'host3', 'host4']
    assert inventory_result == expected_host

    ######################################
    # Test with args (pattern)
    ######################################
    inventory_result = inv_mgr.list_hosts(pattern="host1")
    expected_host = ['host1']
    assert inventory_result == expected_host

    ######################################
    # Test with args (negated_pattern)
    ######################################
    inventory_result = inv

# Generated at 2022-06-24 19:57:07.174283
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # Test type-specific method arguments and return values
    inventory_manager_0 = InventoryManager()
    subset(inventory_manager_0, None)
    subset(inventory_manager_0, '')
    subset(inventory_manager_0, '')



# Generated at 2022-06-24 19:57:13.963660
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # Inject a fake inventory and a data structure for testing
    inventory_manager = InventoryManager(
        loader=None,
        sources=['/dev/null']
    )
    inventory_manager._inventory = FakeInventory()
    inventory_manager._subset = None

    # Test calling the method with no arguments
    # Note: This appears to be a non-standard use of "subset" in Python.
    # I believe the expected call signature is:
    # inventory_manager.subset(subset=None)
    inventory_manager.subset()
    assert not inventory_manager._subset

    # Test calling with a list. This should override previous settings and
    # results should be in sorted order
    inventory_manager.subset(['c', 'a', 'b'])

# Generated at 2022-06-24 19:57:18.121547
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    inventory = InventoryManager(loader=DataLoader())
    # test InventoryManager.list_hosts with default args
    hosts = inventory.list_hosts()
    # test InventoryManager.list_hosts with pattern 'all'
    hosts = inventory.list_hosts(pattern='all')

if __name__ == '__main__':
    test_case_0()
    test_InventoryManager_list_hosts()

# Generated at 2022-06-24 19:57:25.373530
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    host_0 = Mock()
    host_0.name = "host_0"
    host_1 = Mock()
    host_1.name = "host_1"
    _inventory = Mock()
    _inventory._hostname_cache = [host_0, host_1]
    var_0 = InventoryManager(_inventory)
    bool_0 = True
    var_1 = var_0.get_hosts(bool_0)


# Generated at 2022-06-24 19:58:02.679290
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    var_0 = 'all'
    var_1 = InventoryManager().list_hosts(var_0)
    return var_1


# Generated at 2022-06-24 19:58:10.756780
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory = InventoryManager(loader=None, sources=[])
    test_case_0()


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print('Usage: inventory_manager.py ACTION [-t]\n' +
              '\tACTION is one of the following values: ' +
              'test_case_0')

    if len(sys.argv) > 2 and sys.argv[2] == '-t':
        enableTraces = True
    else:
        enableTraces = False

    if enableTraces:
        display.verbosity = 2

    action = sys.argv[1]

    if action == 'test_case_0':
        test_case_0()

# Generated at 2022-06-24 19:58:16.853281
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    bool_0 = True
    bool_1 = False
    int_0 = 0
    int_1 = 0
    int_2 = 0
    int_3 = 0
    int_4 = 0
    int_5 = 0
    int_6 = 1
    int_7 = 0
    int_8 = 1
    int_9 = 0
    str_0 = 'string'
    str_1 = 'string'
    str_2 = 'string'
    str_3 = 'string'

    # Test case for func

    # initialize inventory
    inventory = InventoryManager(loader=DataLoader(), sources=['tests/inventory/test_inventory.yaml'])
    inventory.parse_inventory(inventory.loader.load_from_file('.'))
    test_case_0()

    # Asserts

# Generated at 2022-06-24 19:58:22.607657
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory = InventoryManager()
    hosts = {u'localhost': {u'ansible_connection': u'local'}}
    groups = {u'all': {u'hosts': [u'localhost']}}
    display.verbosity = 3

    # Call method
    result = inventory.parse_source(hosts, groups)

    # Assertions
    assert result == False


# Generated at 2022-06-24 19:58:30.014798
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    import os
    inv_mgr = InventoryManager(loader=None, sources='foobar')

    # Test if right source was found
    find_source = os.path.join(os.path.dirname(__file__), 'test-data/test_inventory.ini')
    find_source = inv_mgr._find_needle_in_haystack(haystack=['foobar'], needle=find_source)
    assert find_source == 'foobar'

    # Test if inventory was implicitly created
    find_source = os.path.join(os.path.dirname(__file__), 'test-data/test_inventory.ini')
    find_source = inv_mgr._find_needle_in_haystack(haystack=[find_source], needle=find_source)

# Generated at 2022-06-24 19:58:32.319274
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    input_0 = InventoryManager()
    input_1 = 'all'
    output_0 = input_0.list_hosts(input_1)


# Generated at 2022-06-24 19:58:35.919680
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # Setup the InventoryManager
    im_0 = InventoryManager(None, to_text('/dev/null'))

    assert im_0.subset(None) is None

    # Teardown the InventoryManager
    del im_0


# Generated at 2022-06-24 19:58:41.400103
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():

    # Cleanup Inventory Manager instance
    InventoryManager._clear_instance_ptr()

    # Setup Inventory Manager instance
    # inventory_manager = InventoryManager()
    inventory_manager = InventoryManager(loader)

    # Setup args required for the test method
    args = (inventory_manager)

    # Setup return value for the test method
    retval = ()

    # Execute test method
    retval = InventoryManager.parse_source(*args)

    # Check for side effects
    # assert_true(bool(0))
