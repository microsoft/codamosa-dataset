

# Generated at 2022-06-24 19:49:30.966510
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    import builtins

    # Set up mock inventory, options and ansible
    mock_inventory = MagicMock()
    mock_options = MagicMock()
    mock_ansible = MagicMock()
    #mock_options.__dict__ = {'inventory_short': False or '', 'force_host_specific': False, 'force_cache': False, 'subset': None or '', 'list_hosts': 'smart', 'limit': None or 'default', 'inventory': 'localhost,' or '', 'list': False, 'module_path': '', 'list_tags': False, 'ask_sudo_pass': False, 'limit_active_invocation': False, 'list_tasks': False, 'list_groups': False, 'module_name': '', 'verbosity': 0, 'ask_pass': False}
    mock_options.__

# Generated at 2022-06-24 19:49:34.862500
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    # AssertionError
    try:
        int_1 = 8391
        var_0 = InventoryManager(int_1)
        int_1 = -1514
        var_1 = var_0.get_hosts(int_1)

        assert var_1 == None
    except AssertionError:
        print("Test Case: T0021 FAIL")
    else:
        print("Test Case: T0021 PASS")


# Generated at 2022-06-24 19:49:37.980216
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    var_0 = InventoryManager()
    subset_pattern = [0, 'a', 5.0, int]
    var_0.subset(subset_pattern)

# Generated at 2022-06-24 19:49:42.480864
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():
    inventory_manager = InventoryManager('/tmp/ansible_InventoryManager_sources', [], True)
    assert inventory_manager.parse_sources('/tmp/ansible_InventoryManager_sources') == inventory_manager._inventory.parse_inventory(['/tmp/ansible_InventoryManager_sources'])

# Generated at 2022-06-24 19:49:53.029380
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    import data_structure
    import group

    i = data_structure.Inventory(host_list=['foo'], group_list=['all', 'ungrouped', 'foo'])
    i.get_host('foo').set_variable('bar', 'baz')
    g = group.Group('foo')
    g.add_host(i.get_host('foo'))
    g.add_host(i.get_host('bar'))
    i.add_group(g)
    g = group.Group('all')
    g.add_host(i.get_host('foo'))
    g.add_host(i.get_host('bar'))
    i.add_group(g)

    h = i.get_host('bar')
    h.set_variable('foo', 'bar')

# Generated at 2022-06-24 19:49:55.552649
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    # Setup test data
    pattern = "all"
    ignore_limits = False
    ignore_restrictions = False
    order = None

    # Invoke method
    results = InventoryManager(pattern, ignore_limits, ignore_restrictions, order)
    return results



# Generated at 2022-06-24 19:50:02.074075
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    """
    Test if inventory source parsing works properly.
    """
    inventory = InventoryManager(None)
    host_list = inventory.parse_source('[webservers]\nfoo\nbar\n')
    assert type(host_list) == list, 'Host list has to be of type list.'
    assert len(host_list) == 2, 'Host list has to contain 2 elements.'
    assert len(inventory.hosts) == len(host_list), 'Host list and inventory host list have to be the same length.'


# Generated at 2022-06-24 19:50:11.777816
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():

    # Set up test instance for InventoryManager
    yaml_data = load_data_from_file('test/yaml/inventory_manager_status.yml')
    inventory_manager_status = yaml_data[0]['inventory_manager_status']

    inventory_manager_status_obj = InventoryManager(inventory_manager_status)

    # Set up test parameters
    inventory_file_path = "/etc/ansible/hosts"
    cache = False
    cache_timeout = None
    sources = None
    vault_password = None
    loader = None
    play_context = None

    # Run method to be tested
    test_result = inventory_manager_status_obj.parse_source(inventory_file_path, cache, cache_timeout, sources, vault_password, loader, play_context)

    # Verify test results
    assert type

# Generated at 2022-06-24 19:50:17.035623
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
        # Apparently pytest tests are run in alphabetical order,
        # hack around this so that we are able to run this test first
        # otherwise it will be run second and will try to load a
        # non-existent config file.
        global __test__
        __test__ = True
        inv = InventoryManager(loader=DataLoader(), sources='')
        assert inv.hosts == {}



# Generated at 2022-06-24 19:50:20.046427
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    int_0 = -1514
    var_0 = InventoryManager(int_0)
    int_1 = -1514
    var_1 = var_0.parse_source(int_1)


# Generated at 2022-06-24 19:50:34.940866
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    mock_path = MagicMock()
    mock_path.exists.return_value = False
    manager = InventoryManager(mock_path)
    assert isinstance(manager, InventoryManager)


# Generated at 2022-06-24 19:50:45.360056
# Unit test for function split_host_pattern
def test_split_host_pattern():
    str_0 = 'group1:group2[0:1], group3, group4[0] -f ansible.cfg'
    var_0 = split_host_pattern(str_0)
    assert var_0 == ['group1', 'group2[0:1]', 'group3', 'group4[0]', '-f', 'ansible.cfg']

    str_0 = [':']
    var_0 = split_host_pattern(str_0)
    assert var_0 == []

    str_0 = 'group1,group2,group3,group4'
    var_0 = split_host_pattern(str_0)
    assert var_0 == ['group1', 'group2', 'group3', 'group4']

    str_0 = 'group1, group2, group3, group4'


# Generated at 2022-06-24 19:50:51.582681
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    global inventory_manager_0
    int_0 = -1514
    var_0 = inventory_manager_0.get_hosts(int_0)


# Generated at 2022-06-24 19:50:52.996647
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    int_0 = 490
    var_0 = InventoryManager()
    up_3 = var_0.subset(int_0)


# Generated at 2022-06-24 19:50:54.187286
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    test_case_0() # +

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


# Generated at 2022-06-24 19:50:54.682204
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():
    pass

# Generated at 2022-06-24 19:51:03.188917
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    # Note: If you change the string data value for this test, you will need
    # to also change the matching assert in the test.
    data = '''
    [foobar]
    foo1
    foo2
    foo3
    [barfoo:children]
    bar1
    bar2
    bar3
    '''
    inventory = InventoryManager(loader=DataLoader())
    inventory.add_group("foobar")
    inventory.add_host(Host("foo1"), group="foobar")
    inventory.add_host(Host("foo2"), group="foobar")
    inventory.add_host(Host("foo3"), group="foobar")
    inventory.add_group("barfoo")
    inventory.add_host(Host("bar1"), group="barfoo")

# Generated at 2022-06-24 19:51:04.679666
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    # Create the object
    obj = InventoryManager()
    # Call the method
    obj.get_hosts()


# Generated at 2022-06-24 19:51:06.649015
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager = InventoryManager()
    subset_pattern = to_text(u'all')
    inventory_manager.subset(subset_pattern)


# Generated at 2022-06-24 19:51:09.159932
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    print("Testing list_hosts")
    get_playbook_path('vault_id.py')
    var_0 = InventoryManager()
    var_1 = 'all'
    result = var_0.list_hosts(var_1)
    print(result)

# Generated at 2022-06-24 19:51:27.378288
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    var_3 = [u'@test_playbook_dir/inventory']
    var_4 = InventoryManager(var_3)
    var_5 = u'@test_playbook_dir/inventory'
    var_4.subset(var_5)
    var_6 = u'localhost'
    var_7 = var_4.get_hosts(var_6)
    assert len(var_7) == 1
    var_8 = var_7[0]
    var_9 = var_8.name
    assert var_9 == u'localhost'


# Generated at 2022-06-24 19:51:32.764241
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    pattern = 'all'
    int_0 = InventoryManager()
    var_0 = int_0.list_hosts(pattern)
    var_1 = var_0
    var_2 = type(var_1)
    var_3 = list
    var_4 = var_2 is var_3


# Generated at 2022-06-24 19:51:38.390192
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    int_0 = -1514
    var_0 = InventoryManager(int_0)
    var_1 = "all"
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = var_0.get_hosts(var_1, var_2, var_3, var_4)
    print(str(var_5))

if __name__ == '__main__':
    test_case_0()
    test_InventoryManager_get_hosts()

# Generated at 2022-06-24 19:51:47.850402
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    print("**** UNIT TEST: test_InventoryManager_parse_source() ****")

    # arr_0 will be passed to method parse_source of class InventoryManager
    arr_0 = [0]

    # obj_0 will be passed to method parse_source of class InventoryManager
    obj_0 = InventoryManager()

    # call to method parse_source of class InventoryManager
    ret_0 = obj_0.parse_source(arr_0)

    # check if method parse_source returns a value
    if ret_0 is not None:
        print("Return value: " + str(ret_0))
    else:
        print("Method parse_source returned None")


# Generated at 2022-06-24 19:51:58.807017
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    in_0 = "source_0"
    in_1 = "source_1"
    in_2 = "source_2"
    in_3 = "source_3"
    in_4 = "source_4"
    in_5 = "source_5"
    in_6 = "source_6"
    in_7 = "source_7"
    in_8 = "source_8"
    in_9 = "source_9"
    in_10 = "source_10"
    in_11 = "source_11"
    in_12 = "source_12"
    in_13 = "source_13"
    in_14 = "source_14"
    in_15 = "source_15"
    in_16 = "source_16"
    in_17 = "source_17"
   

# Generated at 2022-06-24 19:52:02.557046
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # FIXME: Stub for test for subset
    #assert False # FIXME: implement your test here
    raise NotImplementedError()


# Generated at 2022-06-24 19:52:06.325272
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # get a test inventory
    inven = build_inventory('''
localhost ansible_connection=local
foohost
barhost
    ''')
    imgr = InventoryManager(inven)
    imgr.subset("~[ABC]*")
    hosts = imgr.get_hosts()
    assert hosts == []


# Generated at 2022-06-24 19:52:16.300127
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    int_0 = -1468
    int_1 = 2
    int_2 = -1545
    int_3 = 2
    int_4 = -1541
    int_5 = 2
    int_6 = -1473
    int_7 = 2
    int_8 = -1553
    int_9 = 2
    int_10 = -1550
    int_11 = 2
    int_12 = -1554
    int_13 = 2
    int_14 = -1501
    int_15 = 2
    int_16 = -1517
    int_17 = 2
    int_18 = -1469
    int_19 = 2
    int_20 = -1478
    int_21 = 2
    int_22 = -1508
    int_23 = 2
    int_24 = -15

# Generated at 2022-06-24 19:52:23.708206
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():

    # TODO: check the Inventory manager against a real inventory
    # and populate the expected_result with those results
    expected_result = None

    inventory_manager = InventoryManager(None)
    test_result = inventory_manager.get_hosts(pattern, ignore_limits, ignore_restrictions, order)

    if expected_result == test_result:
        print("Bingo!")
    else:
        print("Expected: {}".format(expected_result))
        print("Actual  : {}".format(test_result))
        assert False


# Generated at 2022-06-24 19:52:28.697162
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    from ansible.inventory.manager import InventoryManager

    obj_0 = InventoryManager()
    var_0 = obj_0.list_hosts("all")
    var_1 = obj_0.get_hosts("[1]")
    var_2 = obj_0.get_hosts("all")
    var_3 = obj_0.list_hosts()
    var_4 = obj_0.get_hosts(obj_0)
    var_5 = obj_0.list_hosts("all")


# Generated at 2022-06-24 19:52:57.716778
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():
    int_0 = '/etc/ansible/hosts'
    str_0 = 'INI'
    str_1 = 'Script'
    str_2 = '/usr/lib/python2.7/site-packages/ansible/plugins/inventory/my_custom.py'
    str_3 = 'Script'
    str_4 = '/usr/lib/python2.7/site-packages/ansible/plugins/inventory/ec2.py'
    str_5 = 'Script'
    str_6 = 'YAML'
    str_7 = 'Script'
    str_8 = 'Script'
    str_9 = 'Script'
    str_10 = 'Script'
    str_11 = 'Script'
    str_12 = 'Script'
    str_13 = 'Script'
    str_14 = 'Script'

# Generated at 2022-06-24 19:53:01.653657
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    arg_0 = InventoryManager()

    with pytest.raises(AnsibleError):
        arg_0.subset(None)
        arg_0.subset(None)
        # No error



# Generated at 2022-06-24 19:53:05.838356
# Unit test for method subset of class InventoryManager

# Generated at 2022-06-24 19:53:10.690264
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    int_0 = -3
    var_0 = InventoryManager(int_0)
    int_1 = 1519828576
    var_0.subset(int_1)
    int_2 = 4
    var_1 = var_0.subset(int_2)
    var_2 = (var_1 == var_0._subset)


# Generated at 2022-06-24 19:53:11.958082
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    # inventory_manager.parse_source()
    pass

if __name__ == '__main__':
    # test_case_0()
    test_InventoryManager_parse_source()

# Generated at 2022-06-24 19:53:13.551036
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    i = InventoryManager(None, None)
    i.list_hosts()


# Generated at 2022-06-24 19:53:18.237437
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    print("TESTING parse_source")

    # source being a string
    source = "~/ansible/ansible-examples/ec2.py"
    load_callback = None

    # load_callback being a function
    load_callback = lambda: 0

    # options being a list of items
    options = []
    for i in range(15):
        options.append("some_string")

    # options being a list of dictionaries
    options = []
    for i in range(15):
        options.append({"some_key": "some_value"})

    # options being a list of tuples
    options = []
    for i in range(15):
        options.append(("some_key", "some_value"))

    # options being a set of strings
    options = set()

# Generated at 2022-06-24 19:53:20.240750
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    inventory = InventoryManager()
    assert inventory.list_hosts() == []


# Generated at 2022-06-24 19:53:26.648697
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    # init data
    inventory = "testabc.yml"
    inventory_loader = InventoryLoader(inventory, False)
    inventory = inventory_loader.get_inventory(None)
    runner = PlaybookExecutor()
    manager = InventoryManager(inventory, runner)

    # method invoke
    res = manager.list_hosts()
    assert res == []

if __name__ == "__main__":
    test_case_0()

    pytest.main()

# Generated at 2022-06-24 19:53:29.906349
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    int_0 = InventoryManager("test_0", "test_1")
    string_0 = "test_2"
    int_0.subset(string_0)


# Generated at 2022-06-24 19:53:48.755116
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():
    ansible_inventory_mock = ansible_mock.mock_ansible_inventory()
    host_mock = ansible_mock.mock_ansible_host()
    ansible_group_mock = ansible_mock.mock_ansible_group()
    ansible_group_mock.get_hosts = ansible_mock.mock_ansible_get_hosts(host_mock)
    ansible_host_mock = ansible_mock.mock_ansible_host_mock(ansible_group_mock)
    ansible_inventory_mock.get_host = ansible_mock.mock_ansible_get_host(ansible_host_mock)
    ansible_inventory_mock.get_groups_dict = ansible_mock

# Generated at 2022-06-24 19:53:57.322679
# Unit test for method list_hosts of class InventoryManager

# Generated at 2022-06-24 19:53:59.403737
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    source = InventoryManager('/tmp/ansible_InventoryManager_1/')
    source.parse_source('/tmp/ansible_InventoryManager_1/')


# Generated at 2022-06-24 19:54:01.788811
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    var_0 = InventoryManager()
    var_1 = u'foo.bar'
    var_2 = var_0.list_hosts(var_1)
    assert var_2 == u'foo.bar'


# Generated at 2022-06-24 19:54:07.340093
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    int_0 = -1514
    var_0 = InventoryManager(int_0)
    int_1 = -1514
    var_0.subset(int_1)


# Generated at 2022-06-24 19:54:09.208350
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():
    int_0 = -1514
    var_0 = InventoryManager(int_0)
    var_0.parse_sources(int_0)


# Generated at 2022-06-24 19:54:12.746928
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    arg1 = ""
    arg2 = ""
    arg3 = ""
    arg4 = ""
    arg5 = ""
    return InventoryManager(arg1, arg2, arg3, arg4, arg5).subset(arg1)


# Generated at 2022-06-24 19:54:16.502783
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    int_0 = 0
    var_0 = InventoryManager()
    int_1 = -1334
    var_0.subset(int_1)
    return None


# Generated at 2022-06-24 19:54:18.847031
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    int_0 = 168
    var_0 = InventoryManager(int_0)
    var_1 = var_0.list_hosts()


# Generated at 2022-06-24 19:54:23.120262
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    int_0 = 18583
    var_0 = InventoryManager(int_0)

    int_0 = -9157
    var_0.subset(int_0)

    int_0 = -7128
    var_0.subset(int_0)

    int_0 = -1684
    var_0.subset(int_0)


# Generated at 2022-06-24 19:54:38.165284
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    this = InventoryManager()
    this._inventory = InventoryManager()
    # assert test_case_0() == 0


if __name__ == '__main__':
    test_InventoryManager_list_hosts()

# Generated at 2022-06-24 19:54:40.136375
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    inventory_manager = InventoryManager()
    inventory_manager.list_hosts()

# Generated at 2022-06-24 19:54:47.659218
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():

    # Testing inventory parser plugin loading
    test_src = '/tmp/test_inventory.ini'
    test_data = '[test]\nlocalhost ansible_connection=local\n[test:vars]\nfoo=bar\n'
    display.display("Testing inventory parser plugin loading:")

    with open(test_src, 'w') as f:
        f.write(test_data)
    mgr = InventoryManager()
    mgr.add_sources(test_src)

    assert mgr.get_hosts() == ['localhost']
    print("PASS")

    # Testing inventory plugin loading
    test_path = 'inventory_plugins/test/'
    display.display("Testing inventory plugin loading:")
    shutil.rmtree(test_path, ignore_errors=True)

# Generated at 2022-06-24 19:54:57.180233
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    int_0 = -1514
    int_1 = -1514
    int_2 = -1514
    int_3 = -1514
    # Test case 0
    # TODO: Test if ansible-playbook is present
    # TODO: Test if ansible is present
    # TODO: Test if ansible-config is present
    # TODO: Test if virtualenv is present
    # TODO: Test if ansible-inventory is present
    # TODO: Test if ansible-connection is present
    # TODO: Test if ansible-vault is present
    # TODO: Test if ansible-console is present
    # TODO: Test if ansible-doc is present
    # TODO: Test if ansible-galaxy is present
    # TODO: Test if ansible-pull is present
    # TODO

# Generated at 2022-06-24 19:55:01.059016
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    int_0 = -20136
    for var_0 in range(321):
        test_InventoryManager_list_hosts_0(var_0, int_0)
    for var_0 in range(363):
        test_InventoryManager_list_hosts_1(var_0, int_0)
    for var_0 in range(364):
        test_InventoryManager_list_hosts_2(var_0, int_0)


# Generated at 2022-06-24 19:55:08.633755
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    for i in range(100):
        tmp_0 = uuid.uuid4()
        assert tmp_0.hex == tmp_0.hex

    int_0 = -19
    var_0 = order_patterns(int_0)
    int_1 = 10
    var_1 = order_patterns(int_1)
    obj_0 = InventoryManager(var_0, var_1)
    # TODO: Add some tests here.



# Generated at 2022-06-24 19:55:11.170837
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    int_0 = 13582
    var_0 = InventoryManager(int_0)
    int_0 = -18394
    var_0.subset(int_0)


# Generated at 2022-06-24 19:55:14.972098
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    def inventory_generator():
        inventory_dict = {}
        inventory_dict['hostvars'] = {}
        inventory_dict['ungrouped'] = {}
        return inventory_dict
    inventory = Inventory(inventory_generator)
    inventory_manager = InventoryManager(inventory)
    print(inventory_manager.list_hosts("pattern"))


# Generated at 2022-06-24 19:55:24.292700
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():
    # Test case for the InventoryManager parse_sources method
    options = DummyOptions()
    options.inventory = "/path/to/inventory"
    inventory = Inventory(options=options)

    inventory_manager = InventoryManager(inventory=inventory)

    # Initialize parameters of the test case
    sources = ",".join([
        "localhost",
        "localhost:3333",
        "{}/path/to/inventory".format(inventory_manager.get_script_path()),
        "localhost,",
        ",",
    ])
    inventory_manager.parse_sources(sources=sources)


# Generated at 2022-06-24 19:55:29.186490
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    print('\nRunning test case 0')
    test_case_0()


if __name__ == '__main__':
    test_InventoryManager_list_hosts()

# Generated at 2022-06-24 19:55:58.040820
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # FIXME: test case
    assert False


# Generated at 2022-06-24 19:56:00.762358
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    # Test if method 'parse_source' raises a exception when given 1 parameters
    # Test if method 'parse_source' raises a exception when given 2 parameters
    assert True


# Generated at 2022-06-24 19:56:03.838377
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory = InventoryManager([])
    pattern = "all"
    ignore_limits = "False"
    ignore_restrictions = "False"
    order = None
    result = inventory.get_hosts(pattern, ignore_limits, ignore_restrictions, order)


# Generated at 2022-06-24 19:56:11.206536
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    print('In test_InventoryManager_parse_source')
    var_1 = InventoryManager([], None)
    if var_1 is not None:
        var_2 = var_1.parse_source('test_value_1', 'test_value_2', 'test_value_3', 'test_value_4')


# Generated at 2022-06-24 19:56:12.131602
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    obj_0 = InventoryManager()


# Generated at 2022-06-24 19:56:15.512067
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    b_source = 'ec2.py'
    var_0 = InventoryManager(b_source)
    var_1 = var_0.parse_source(b_source)
    assert(var_1 == None)


# Generated at 2022-06-24 19:56:21.549610
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    int_0 = -3532
    host_0 = Host(u'host_0')
    host_1 = Host(u'host_1')
    host_2 = Host(u'host_2')
    hosts_0 = [host_1, host_2]
    hosts_1 = [host_0, host_1, host_2]
    var_0 = InventoryManager(hosts_1)
    var_0.parse_source(hosts_0, int_0, int_0)


# Generated at 2022-06-24 19:56:30.623262
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    assert InventoryManager.parse_source('foo') == ('static', 'foo')
    assert InventoryManager.parse_source('http://foo') == ('httpapi', 'http://foo')
    assert InventoryManager.parse_source('https://foo') == ('httpapi', 'https://foo')
    assert InventoryManager.parse_source('plugin/foo') == ('plugin', 'foo')
    assert InventoryManager.parse_source('plugin/foo/') == ('plugin', 'foo')
    assert InventoryManager.parse_source('plugin/foo/bar') == ('plugin', 'foo/bar')
    assert InventoryManager.parse_source('plugin/foo/bar/') == ('plugin', 'foo/bar')
    assert InventoryManager.parse_source('yaml') == ('static', 'yaml')

# Generated at 2022-06-24 19:56:32.950832
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    im = InventoryManager("")
    src = "localhost"
    in_data = "localhost ansible_connection=local"
    res = im._parse_source(src, in_data)
    assert res is True


# Generated at 2022-06-24 19:56:44.158089
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    data = '''
    foo1 ansible_ssh_host=10.20.30.41 ansible_ssh_port=22
    foo2 ansible_ssh_host=10.20.30.42 ansible_ssh_port=22
    foo3 ansible_ssh_host=10.20.30.43 ansible_ssh_port=22
    foo4 ansible_ssh_host=10.20.30.44 ansible_ssh_port=22
    '''
    hosts = make_hosts(data)
    im = InventoryManager(hosts)

    hosts_list = im.list_hosts('all')
    assert len(hosts_list) == 4
    assert hosts_list[0] == 'foo1'
    assert hosts_list[1] == 'foo2'

# Generated at 2022-06-24 19:57:53.177740
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    int_0 = -1514
    var_0 = InventoryManager(int_0, False)
    test_pattern = 'test'
    var_0.subset(test_pattern)


# Generated at 2022-06-24 19:57:55.926758
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    test_case_0()
    # Method get_hosts has no return value
    # FIXME: test not implemented
    return True


# Generated at 2022-06-24 19:58:00.253977
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    '''
    unit_tests/unit/utils/test_inventory_manager.py:test_InventoryManager_subset
    '''
    int_0 = -1514
    # function call
    var_0 = InventoryManager(int_0).subset(int_0)


# Generated at 2022-06-24 19:58:09.335784
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    # FIXME: this test will fail until the inventory is loaded
    inventory_manager_0 = InventoryManager(None)
    inventory_manager_0._restriction = set([u'var'])
    inventory_manager_0._subset = set([u'@b'])
    inventory_manager_0.get_hosts(set([u'a', u'b', u'c']), True, True)
    inventory_manager_0.get_hosts()
    inventory_manager_0.get_hosts(None)
    inventory_manager_0.get_hosts(None, False, False)
    inventory_manager_0.get_hosts(None, True, False)
    inventory_manager_0.get_hosts(None, False, True)

# Generated at 2022-06-24 19:58:13.037638
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inv = Inventory(loader=None)
    inv.parse_source('[all:vars]\nxyz=foo\n[ungrouped]\nfoo: ansible_user=root')
    assert 'xyz' in inv.get_group('all').get_variables()


# Generated at 2022-06-24 19:58:14.450977
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    # FIXME: needs implementation
    pass


# Generated at 2022-06-24 19:58:20.823215
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory = InventoryManager(loader=None, sources='localhost,')
    pattern = inventory.get_hosts(pattern='localhost,')
    if pattern == ['localhost']:
        print('Pass: Method: get_hosts()')
    else:
        print('Failed: inventory1.get_hosts(pattern="localhost,") != ["localhost"]')


# Generated at 2022-06-24 19:58:23.142118
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    b_dummy_subset = b'2'
    obj_0 = InventoryManager()
    obj_0.subset(b_dummy_subset)


# Generated at 2022-06-24 19:58:27.752175
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    from units.compat import mock

    _config = ConfigParser.ConfigParser()
    _config.read('test/ansible.cfg')

    mock_config = mock.Mock()
    mock_config.filename = 'test/ansible.cfg'
    mock_config.parser = _config

    im = InventoryManager(mock_config)

    a = im.list_hosts('all')

# Generated at 2022-06-24 19:58:31.166733
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    manager_2 = InventoryManager()
    instance_0 = InventoryManager()
    instance_0.subset(manager_2)
    bool_var = bool_0 = bool()
    bool_1 = bool()
    bool_0 = bool_var
    bool_var = bool_0
