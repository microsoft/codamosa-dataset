

# Generated at 2022-06-24 19:49:44.233757
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    float_0 = 2477.0
    inventory_manager_0 = InventoryManager(float_0)
    subset_pattern_0 = None

    inventory_manager_0.subset(subset_pattern_0)


# Generated at 2022-06-24 19:49:46.263312
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager_0 = InventoryManager(2477.0)
    inventory_manager_0.subset(subset_pattern=InventoryManager(2477.0))


# Generated at 2022-06-24 19:49:47.295668
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    assert True


# Generated at 2022-06-24 19:49:52.044074
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    float_0 = 2477.0
    inventory_manager_0 = InventoryManager(float_0)
    inventory_manager_0.subset(None)


# Generated at 2022-06-24 19:49:54.424211
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():
    # params: sources, loader
    # return: data
    inventory_manager_0 = InventoryManager("foobar")
    inventory_manager_0.parse_sources("foobar", "foobar")


# Generated at 2022-06-24 19:49:55.772158
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():
    inventory_manager_0 = InventoryManager()


# Generated at 2022-06-24 19:49:58.522605
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    float_0 = 2477.0
    inventory_manager_0 = InventoryManager(float_0)
    inventory_manager_0.parse_sources()


# Generated at 2022-06-24 19:49:59.493912
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    print("test_InventoryManager_list_hosts")
    test_case_0()


# Generated at 2022-06-24 19:50:01.749547
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    float_0 = 2477.0
    inventory_manager_0 = InventoryManager(float_0)
    assert inventory_manager_0.list_hosts("all") == []


# Generated at 2022-06-24 19:50:10.320003
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():
    """
    Test for the errors that can happen when you pass in a bad host_list
    """
    inventory_manager_0 = InventoryManager(None)
    float_0 = 192.0
    int_0 = 213
    bool_0 = bool(3)
    hosts_dict_0 = dict()
    hosts_dict_0[u'host_list'] = [u'host_list_0']
    hosts_dict_0[u'inventory'] = [u'inventory_0']
    hosts_dict_0[u'dynamic_inventory'] = [u'dynamic_inventory_0']
    hosts_dict_0[u'source_script'] = [u'source_script_0']
    hosts_dict_0[u'yaml_inventory'] = [u'yaml_inventory_0']

# Generated at 2022-06-24 19:50:29.529735
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    # Initialization of mock object
    _inventory = MagicMock()

    # Creation of an instance of the class to be tested
    inventory_manager = InventoryManager(_inventory)

    # Initialization of the variables which will be used in subsequent call of the tested method
    pattern = set()

    # Call of the method to be tested
    result = inventory_manager.list_hosts(pattern)

    # Verification of the method performance
    assert result == ['all']


# Generated at 2022-06-24 19:50:30.188431
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    pass


# Generated at 2022-06-24 19:50:32.882456
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory = InventoryManager([])
    x = 'fake_path'
    assert inventory._subset is None
    inventory.subset(x)
    assert inventory._subset == [x]


# Generated at 2022-06-24 19:50:37.490408
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inv_mgr = InventoryManager()
    subset = 'foobar'

    result = inv_mgr.subset(subset)

    # Check if the result is correct
    assert result == None
    assert inv_mgr._subset == subset


# Generated at 2022-06-24 19:50:40.001249
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    hosts = InventoryManager()
    assert(type(hosts.get_hosts()) == type([]))

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 19:50:48.941198
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    """
    Test that _parse_source() produces expected results when given known input.
    """
    inventory = InventoryManager(host_list='hosts')
    try:
        result = inventory._parse_source(b'[group1]\nhost1\nhost2:2222\n[group2]\nhost2\nhost3')
    except:
        exc_info = sys.exc_info()
        if C.DEFAULT_DEBUG == True:
            traceback.print_exception(*exc_info)
        raise Exception()

# Generated at 2022-06-24 19:50:56.003663
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory_manager_0 = InventoryManager(None, None)

    for i in range(0,10):
        host_pattern_0 = HashableHostPattern(choice(string.ascii_letters), {})
        list_0 = []
        for j in range(0,10):
            list_0.append(choice(string.ascii_letters))
        inventory_manager_0.get_hosts(host_pattern_0, choice([True, False]), choice([True, False]), choice(list_0))



# Generated at 2022-06-24 19:50:58.395359
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory_manager = InventoryManager(loader=None, sources=None)
    pattern = 'pattern'
    test_source = inventory_manager.parse_source(pattern)
    # source should be parsed and converted to tuple
    assert isinstance(test_source, tuple)


# Generated at 2022-06-24 19:51:06.462063
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    import os
    import tempfile

    # Create test files
    plugin_path = None
    tmp_path = None
    script_path = None

# Generated at 2022-06-24 19:51:12.992393
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    pattern = 'webservers'
    inventory = get_default_inventory()
    manager = InventoryManager(inventory=inventory)
    manager.subset(pattern)
    assert manager._subset[0]._pattern == pattern


# Generated at 2022-06-24 19:51:28.640445
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    var_0 = InventoryManager()
    var_0.set_inventory(None)


# Generated at 2022-06-24 19:51:38.952873
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():

    import os
    import tempfile

    with tempfile.TemporaryDirectory() as tmp_dir:

        inv = InventoryManger(os.path.join(tmp_dir, "hosts.ini"))
        inventory = Inventory(host_list=inv)
        inventory.subset("@" + os.path.join(tmp_dir, "hosts_subset.ini"))

        with open(os.path.join(tmp_dir, "hosts_subset.ini"), 'wb') as f:
            f.write(b'awesome_vm\n')

        assert inventory.subset("@" + os.path.join(tmp_dir, "hosts_subset.ini")) == ['awesome_vm']


# Generated at 2022-06-24 19:51:44.041094
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    var_0 = InventoryManager(None)
    var_1 = 'r$k|\x13\t\xc8\xda\xc0\x08\xbd'
    var_2 = var_0.subset(var_1)
    assert var_2 is None


# Generated at 2022-06-24 19:51:54.057235
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():
    # FIXME: placeholder to make pyflakes happy
    if False:
        print(InventoryManager(pattern='foo'))

    INVENTORY_PATH = b'/tmp/ansible-InventoryManager/'
    INVENTORY_PATH_CONTENT = b'\n    [all:vars]\n    ansible_connection=local\n' + b'    [local]\n    localhost\n\n'
    INVENTORY_HOSTS_CONTENT = b'\n    [all:vars]\n    ansible_connection=local\n' + b'    [local]\n    localhost\n\n'

    # Create a temporary directory where we're going to place the file
    # FIXME: replace mkdtemp() with a contextmanager
    tmp_path = tempfile.mkdtemp()
   

# Generated at 2022-06-24 19:52:02.851413
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():

    # Create an instance of class InventoryManager
    im = InventoryManager(Loader(), VariableManager())

    # This is your test case
    pattern = "all"
    result = im.list_hosts(pattern)

    # Verify the result
    if not isinstance(result, list):
        print("expected: %s" % type(list))
        print("got: %s" % type(result))
        raise TypeError()
    
    # test cases
    try:
        test_case_0()
    except AnsibleError as e:
        print(e)

if __name__ == '__main__':
    test_InventoryManager_list_hosts()

# Generated at 2022-06-24 19:52:07.360663
# Unit test for function split_host_pattern
def test_split_host_pattern():
    v = split_host_pattern(b'a,b[1], c[2:3] , d')
    print('v is ', v)
    print('v is ', type(v), to_text(v))

# Generated at 2022-06-24 19:52:13.000398
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    # setup
    manager = InventoryManager(None)
    # Run
    var_0 = manager.get_hosts(pattern='pattern_0')
    var_1 = manager.get_hosts(pattern='pattern_1')
    var_2 = manager.get_hosts(pattern='pattern_2')
    var_3 = manager.get_hosts(pattern='pattern_3')
    var_4 = manager.get_hosts(pattern='pattern_4')
    var_5 = manager.get_hosts(pattern='pattern_5')
    var_6 = manager.get_hosts(pattern='pattern_6')
    var_7 = manager.get_hosts(pattern='pattern_7')
    var_8 = manager.get_hosts(pattern='pattern_8')
    var_9 = manager.get_hosts

# Generated at 2022-06-24 19:52:15.197288
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory_manager = InventoryManager('/foo/bar')
    test_param_0 = 'inventory'
    test_param_1 = 'source'
    test_param_2 = dict()
    inventory_manager.parse_source(test_param_0, test_param_1, test_param_2)


# Generated at 2022-06-24 19:52:17.047582
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    my_inventory = InventoryManager()
    assert my_inventory.get_hosts("all")


# Generated at 2022-06-24 19:52:25.232308
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # Logic path 1
    bytes_0 = b'\xd4&T<G\x89)\xf7\xf7\x80\x1f'
    var_0 = order_patterns(bytes_0)
    bytes_1 = b'\x93\xef\x1c\x1fU6\x93\xef\x1c'
    var_1 = order_patterns(bytes_1)
    var_2 = InventoryManager(var_1, var_0)

# Generated at 2022-06-24 19:52:47.514606
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    var_1 = InventoryManager()
    bytes_0 = b'\xc2\xec\x0e\x8e\x9a\x13\x1e\x8c\x8b\xc7\xf5\xa0\xd7\x9d\xec\x19\xcd\xfa\x10\xbe\xe2\x86\xa8\xb5\x9d\xfd\x19\x8d\x1e\x8a\xfe\xe9\x15\xa2\x8c\xb6\x84\x13\xfe\x8c\x9f\x7f\x15}\xa4\x93\x0f\xbf\x01\x15\xfa\x9be\xe7\x00'

# Generated at 2022-06-24 19:52:48.828374
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager = InventoryManager()
    inventory_manager.subset('subset_pattern')


# Generated at 2022-06-24 19:52:50.711323
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inv_mgr = InventoryManager()
    inv_patterns = split_host_pattern('all')
    inv_mgr.subset(inv_patterns)


# Generated at 2022-06-24 19:52:53.004530
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    test_inventory = InventoryManager(loader=None, sources=None)
    assert len(test_inventory._sources) == 0
    assert test_inventory._vars == {}
    assert test_inventory._hosts == {}
    assert test_inventory._groups == {}


# Generated at 2022-06-24 19:52:56.074551
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    bytes_0 = b'T\xd2\xba\xba\x8a\xef\x1f\xcf\xfe\x0b\xdc\x9eS\x13'
    var_0 = order_patterns(bytes_0)

    var_1 = get_hosts(var_0)
    assert isinstance(var_1, list)


# Generated at 2022-06-24 19:53:01.077544
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    bytes_0 = b'\xd4&T<G\x89)\xf7\xf7\x80\x1f'
    bytes_1 = b'\xd4&T<G\x89)\xf7\xf7\x80\x1f'
    bytes_2 = b'\xd4&T<G\x89)\xf7\xf7\x80\x1f'
    bytes_3 = b'\xd4&T<G\x89)\xf7\xf7\x80\x1f'
    bytes_4 = b'\xd4&T<G\x89)\xf7\xf7\x80\x1f'
    bytes_5 = b'\xd4&T<G\x89)\xf7\xf7\x80\x1f'

# Generated at 2022-06-24 19:53:10.842238
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    bytes_1 = b'\xd4&T<G\x89)\xf7\xf7\x80\x1f'
    bytes_2 = b'^\x0c\xeb\xb9\x97\x9e\x1b4'
    bytes_3 = b'\x92\xfd\xf8\xfd\x07\xfd\xb4\xfc\xe7'
    bytes_4 = b'\xa0\x8a\x80\xf3\xa7\xed\x1a'
    bytes_5 = b'\xdd\x8f!\x9f\x90\x97\x8b\xc1'
    bytes_6 = b'W\x8c9\x0e-\x92\x0f\x18'
    bytes_

# Generated at 2022-06-24 19:53:13.512964
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    ansible_playbook_main(["-l", "localhost", "--inventory", "localhost,", "ansible_playbook_executor.py"], "/tmp", "/tmp", "/tmp")


# Generated at 2022-06-24 19:53:16.308534
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    bytes_0 = b'\xd4&T<G\x89)\xf7\xf7\x80\x1f'
    obj_0 = InventoryManager(bytes_0)
    bytes_1 = b'/\x8a\x94\x07\x11\x80\x84\xdc\xf1N\x1a\x98\xc8\x93'
    obj_0.subset(bytes_1)


# Generated at 2022-06-24 19:53:22.398148
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory = InventoryManager(b"")

    # Test with None value, expected:None
    inventory.subset(None)
    var_0 = inventory._subset

    # Test with valid value, expected:Subset
    subset_pattern_1 = "a,b"
    inventory.subset(subset_pattern_1)
    var_1 = inventory._subset


# Generated at 2022-06-24 19:53:37.596905
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # FIXME: Implement test for method subset of class InventoryManager
    raise SkipTest("Not yet implemented")


# Generated at 2022-06-24 19:53:44.831882
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    # Test to verify inventory matches host patterns at every depth. The pattern
    # 'all' should match every host. The pattern 'web' should match only hosts
    # that belong to that group. The pattern 'web[01]' should match only hosts
    # belonging to that group up to the first level.
    # The pattern 'web[01:1]' should match only hosts belonging to that group
    # up to the second level.

    var_0 = InventoryManager(to_bytes('inventory2.ini'))
    assert var_0._inventory.hosts.keys() == [to_text('host01'), to_text('host02'), to_text('host03'), to_text('host04')]

# Generated at 2022-06-24 19:53:55.807230
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # Find the current path of this script
    path, filename = os.path.split(os.path.abspath(__file__))
    # Get the inventory file af_inventory.yml from test directory
    inv_file = open(os.path.join(path, '../../', 'test/integration/inventory/af_inventory.yml'))
    inv_data = yaml.safe_load(inv_file)
    inv_file.close()

    # Create Inventory object with the data and hosts
    inv_obj = InventoryManager(loader=DataLoader())
    inv_obj.add_group(Group('all'))
    inv_obj._inventory.parser.groups = {}
    inv_obj.parse_inventory(inv_data)
    inv_obj.reconcile_inventory()

    # Get the InventoryManager object


# Generated at 2022-06-24 19:54:00.012336
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    string_0 = '16\x00\x00\x00\x00\x00\x00\x00'
    var_0 = InventoryManager(string_0)
    string_1 = '\x00\x00\n\x00\x00\x00\x00\x00'
    var_1 = var_0.parse_source(string_1)


# Generated at 2022-06-24 19:54:03.536349
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    # Testing variable inventory_manager of type InventoryManager
    inventory_manager = InventoryManager()

    # Testing variable str_0 of type string
    str_0 = "all"

    # Testing method list_hosts with pattern=str_0
    var_0 = inventory_manager.list_hosts(pattern=str_0)


# Generated at 2022-06-24 19:54:12.488820
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    bytes_0 = b'\xd4&T<G\x89)\xf7\xf7\x80\x1f'
    bytes_1 = b'\x0f}\x8e\x02\xa9\x9f\x92\x8f\x03\x13l\x05\x8b\xea'
    bytes_2 = b"\xd8\x8cw\x13\x1a\x92\x95'\xb4\x9a\x0c\xb8\x03"
    var_0 = InventoryManager(bytes_0, bytes_1, bytes_2)
    var_1 = var_0.list_hosts()
    if var_1 == []:
        return True
    else:
        return False


# Generated at 2022-06-24 19:54:19.697743
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    inventory = InventoryManager(loader=None, sources=[])
    inventory.clear_pattern_cache()
    inventory.set_inventory(inventory._inventory)
    inventory.subset('all')
    inventory.remove_restriction()

    # function was invoked with the correct number of arguments
    # (1 given and 2 expected)
    # test is failing; this is obviously wrong, need to fix this
    # test_case_0()

# Generated at 2022-06-24 19:54:22.968854
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    bytes_0 = b'\xd4&T<G\x89)\xf7\xf7\x80\x1f'
    var_0 = order_patterns(bytes_0)


# Generated at 2022-06-24 19:54:30.321150
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    inventory = InventoryManager(loader, None)
    inventory.load_inventory_from_list(test_inventory)
    assert inventory.list_hosts('all') == sorted(['testhost1', 'testhost2', 'testhost3', 'testhost4', 'testhost5', 'testhost6', 'testhost7', 'testhost8', 'testhost9', 'testhost10', 'testhost11', 'testhost12', 'testhost13', 'testhost14', 'testhost15'])


# Generated at 2022-06-24 19:54:37.901063
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory = InventoryManager(None)
    inventory._inventory.get_host('TEST')
    inventory._inventory.get_host('TEST_SUCCESS')
    inventory._inventory.get_host('TEST_SUCCESS_2')
    inventory._inventory.add_group('GROUP')
    inventory._inventory.get_host('GROUP.localhost')
    inventory._inventory.add_child('GROUP', 'TEST_SUCCESS')
    inventory._inventory.add_child('GROUP', 'TEST_SUCCESS_2')
    assert inventory.get_hosts('TEST') == [inventory._inventory.hosts['TEST']]
    assert inventory.get_hosts('TEST_SUCCESS') == [inventory._inventory.hosts['TEST_SUCCESS']]

# Generated at 2022-06-24 19:55:33.290621
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    bytes_0 = b'/\x83\xf8\xbf\x9a\xcb\x05"\x1e\xda'
    obj_0 = InventoryManager(bytes_0)
    bytes_1 = b'P\x8c\xcd\xcc\x0e\xac\xfe\x0f\x0f\x80'
    obj_0.subset(bytes_1)

if __name__ == "__main__":
    test_case_0()
    test_InventoryManager_subset()

# Generated at 2022-06-24 19:55:37.847290
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    instance = InventoryManager(loader, sources=None)
    var_2 = instance.list_hosts()
    assert var_2 == []
    var_3 = instance.list_hosts("all")
    assert var_3 == []


# Generated at 2022-06-24 19:55:42.567813
# Unit test for function split_host_pattern
def test_split_host_pattern():
    split_host_pattern(b'\xd4&T<G\x89)\xf7\xf7\x80\x1f')


# Generated at 2022-06-24 19:55:48.403215
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    inv = InventoryManager(loader=DictDataLoader({
        "group": {
            "hosts": ["h1", "h2", "h3"],
        }
    }, vault_password='test'))
    inv.clear_pattern_cache()
    results = inv.list_hosts("all")
    assert results == ['h1', 'h2', 'h3']



# Generated at 2022-06-24 19:55:50.147530
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    assert False, "Test not implemented"


# Generated at 2022-06-24 19:55:55.358919
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    bytes_0 = b'\xd4&T<G\x89)\xf7\xf7\x80\x1f'
    inventory_manager_0 = InventoryManager(bytes_0)
    str_0 = 'V\x1f'
    var_0 = inventory_manager_0.list_hosts(str_0)


# Generated at 2022-06-24 19:55:59.202941
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # Setup fixture
    inventory_manager = InventoryManager(loader=None, sources='')

    # Exercise SUT
    subset_pattern = object
    inventory_manager.subset(subset_pattern)

    # Verify postconditions


# Generated at 2022-06-24 19:56:06.044249
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    parser = InventoryParser()
    with open(os.path.join(os.path.dirname(__file__),'test_inventory_manager.yml'), 'r') as fh:
        parser.parse_inventory_file(fh)
    inventory = InventoryData(host_list=[])
    inventory.parser = parser
    inven = InventoryManager(inventory=inventory)
    inven.parse_sources('test_inventory_manager.yml')

    # Verify if the pattern_cache is properly populated
    assert list(inven._pattern_cache) == ['normal', '!redhat', '!redhat,normal', 'redhat', 'redhat,normal']

    # Verify if the _hosts_patterns_cache is properly populated
    assert 'all' in inven._hosts_patterns_cache['all']

    # Verify

# Generated at 2022-06-24 19:56:12.324399
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    """ list_hosts test"""

    # TODO: create test inventory

    test_pattern = b''
    test_inventory = b'../../ansible_test/test_inventory'
    inventory_manager = InventoryManager(loader=C.DEFAULT_INVENTORY_LOADER, sources=test_inventory)
    inventory_manager.clear_pattern_cache()
    hosts = inventory_manager.list_hosts(pattern=test_pattern)
    print(hosts)


# Generated at 2022-06-24 19:56:15.427965
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():
    print('Testing method InventoryManager.parse_sources')
    obj_var_1 = []
    var_0 = InventoryManager(obj_var_1)
    var_0.parse_sources()


# Generated at 2022-06-24 19:56:30.318574
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    pattern = '~[abc]*'
    var_0 = InventoryManager(pattern)
    subset_0 = '@foo.txt'
    var_0.subset(subset_0)


# Generated at 2022-06-24 19:56:38.009125
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    with pytest.raises(AnsibleOptionsError) as y:
        InventoryManager()
    # Check if the exception message is correct
    assert y.value.args[0] == "Host pattern cannot be empty"
    with pytest.raises(RuntimeError) as y:
        InventoryManager(host_list=[])
    # Check if the exception message is correct
    assert y.value.args[0] == "Empty or unreadable inventory or plugin configuration file provided"
    with pytest.raises(AttributeError) as y:
        InventoryManager(host_list=[])
    # Check if the exception message is correct
    assert y.value.args[0] == "InventoryManager instance has no attribute '_inventory'"
    var_0 = 'ansible_star'

# Generated at 2022-06-24 19:56:38.929294
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    pass


# Generated at 2022-06-24 19:56:43.462940
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    try:
        InventoryManager.subset('\xd4&T<G\x89)\xf7\xf7\x80\x1f')
    except TypeError as e:
        raise AssertionError("Wrong exception raised: '%s'" % e)

    try:
        InventoryManager.subset('\xd4&T<G\x89)\xf7\xf7\x80\x1f')
    except TypeError as e:
        raise AssertionError("Wrong exception raised: '%s'" % e)


# Generated at 2022-06-24 19:56:52.928557
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory = InventoryManager(loader=None, sources='localhost,')
    inventory.parse_inventory(host_pattern='localhost,')
    inventory._evaluate_patterns(['foo*'])
    inventory._evaluate_patterns(['foo*', 'bar*'])
    inventory._evaluate_patterns(['foo*', 'bar*', '&foo*'])
    inventory._evaluate_patterns(['foo*[1:2]'])
    subset = inventory._evaluate_patterns(['foo*'])
    restricted = inventory._evaluate_patterns(['foo*', 'bar*'])
    inventory._restriction = set('bar*')
    inventory._subset = subset
    assert inventory.get_hosts() == subset
    assert inventory.get_hosts(ignore_restrictions=True) == subset
    assert inventory.get_host

# Generated at 2022-06-24 19:57:00.049051
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    pattern = 'all'
    subset_pattern = None
    inventory = DataFactory.make_inventory()
    inventory_manager = InventoryManager(loader=None, sources=str(DataFactory.make_simple_dir()))
    inventory_manager.subset(subset_pattern)
    hosts = inventory_manager.get_hosts(pattern=pattern)
    assert hosts == ['localhost']


# Generated at 2022-06-24 19:57:08.748961
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():

    """
    get_hosts function tested with mocked Inventory
    """

    # we setup a inventory and a manager
    inventory = Inventory(host_list=[])

    inventory.hosts = {
        'host_0': host_0,
        'host_1': host_1,
        'host_2': host_2,
    }

    inventory.groups = {
        'group_0': group_0,
        'group_1': group_1,
        'all': all_group,
    }

    inventory.patterns = {
        'pattern_0': pattern_0,
        'pattern_1': pattern_1,
    }

    inventory.get_host = MagicMock(return_value=host_0)

    manager = InventoryManager(inventory=inventory)

    # for each test, we first call the get_

# Generated at 2022-06-24 19:57:10.456177
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    var_0 = InventoryManager()
    var_0.subset('.')


# Generated at 2022-06-24 19:57:12.768219
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    
    data = InventoryManager()
    subset_pattern = None
    var_0 = data.subset(subset_pattern)
    assert not var_0, "return value of InventoryManager::subset is not used"



# Generated at 2022-06-24 19:57:17.393923
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    pattern_0 = 'v'
    var_0 = InventoryManager(pattern_0)
    var_0.get_hosts()



# Generated at 2022-06-24 19:57:52.602061
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    obj = InventoryManager()
    assert obj.list_hosts() == []


# Generated at 2022-06-24 19:57:56.042315
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    b_pattern = to_bytes('all')
    var_0 = InventoryManager()
    var_1 = var_0.get_hosts(pattern=b_pattern)
    return var_1


# Generated at 2022-06-24 19:58:05.756705
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    import random
    import types
    import copy
    import os
    import sys
    import ansible.constants as C
    save_C_HOST_PATTERN_MISMATCH = C.HOST_PATTERN_MISMATCH
    C.HOST_PATTERN_MISMATCH = 'ignore'
    fail = False
    im = InventoryManager(loader=DataLoader())
    im.add_group("atlanta")
    im.add_host("atlanta", "foo", port=22)
    host_list = [im.get_host("foo")]
    im.clear_pattern_cache()

    subset_pattern = 'all'
    im.subset(subset_pattern)
    assert im._subset == None
    #assert im._restriction == None

    subset_pattern = 'foo'
   

# Generated at 2022-06-24 19:58:07.871450
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
  # test for obj: InventoryManager
  testObj = InventoryManager()
  testObj.subset('test_value')


# Generated at 2022-06-24 19:58:18.170445
# Unit test for method subset of class InventoryManager

# Generated at 2022-06-24 19:58:19.368353
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory_manager = InventoryManager()
    # InventoryManager.parse_source(source, cache=True)
    inventory_manager.parse_source(source=None)


# Generated at 2022-06-24 19:58:27.721047
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory_0 = Inventory(host_list=[])
    inventory_1 = Inventory(host_list=[])
    inventory_2 = Inventory(host_list=[])
    inventory_3 = Inventory(host_list=[])
    inventory_4 = Inventory(host_list=[])
    inventory_5 = Inventory(host_list=[])
    inventory_6 = Inventory(host_list=[])
    inventory_7 = Inventory(host_list=[])
    source_0 = "[{u'_meta': {u'hostvars': {u'www.example.com': {u'foo': True, u'bar': False}}}, u'group1': {u'hosts': [u'www.example.com']}}]"
    var_1 = InventoryManager(inventory_0, source_0)

# Generated at 2022-06-24 19:58:28.669799
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    test_case_0()


# Generated at 2022-06-24 19:58:37.726207
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    # test fixture:
    inv_path = os.path.join(C.DEFAULT_LOCAL_TMP, 'test_InventoryManager_list_hosts.yml')
    inventory_content = '''
    # Inventory file
    all:
      hosts:
        localhost:
        127.0.0.1:
        server1:
        server2:
        server3:
        group1:
          hosts:
            server1:
            server2:
          children:
            group1a:
              hosts:
                server2:
        group2:
          hosts:
            server3:
      children:
        local:
          hosts:
            localhost:
            127.0.0.1:
    '''

# Generated at 2022-06-24 19:58:41.875802
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # pattern_cache = self._pattern_cache = {}
    # hosts = self._enumerate_matches(pattern)

    # Arguments:
    subset_pattern = None

    # Execution of the method:
    # result = self.subset(subset_pattern)

    # Unit test example
    # print(result)
    # assert True
