

# Generated at 2022-06-24 19:50:00.355503
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():

    # Create instance of class InventoryManager
    inv_vars = dict()
    inv_instance = InventoryManager(inv_vars)

    # Create mock of 'dict' data type
    mock_data = mock.MagicMock()

    # Set return value of method 'get' to '1'
    mock_data.get.return_value = '1'

    # Call method parse_sources with parameters:
    # mock_data
    inv_instance.parse_sources(mock_data)

    # Check if method 'get' of object 'mock_data' was called
    assert mock_data.get.called

    # Check if method 'get' of object 'mock_data' was called with parameters:
    assert mock_data.get.call_args_list[0] == mock.call('plugin')
    assert mock_data

# Generated at 2022-06-24 19:50:01.629374
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    manager = InventoryManager()
    manager.list_hosts()


# Generated at 2022-06-24 19:50:08.716488
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    var_0 = Host(name='foo', port=22)
    var_1 = Group(name='bar')
    var_2 = Inventory(hosts=[var_0], groups=[var_1])
    var_3 = InventoryManager(var_2)
    var_4 = True
    var_5 = u'localhost'
    var_6 = u'foo.yml'
    var_7 = 'foo'
    var_8 = u'bar'
    var_9 = var_3.parse_source(var_4, var_5, var_6, var_7, var_8)


# Generated at 2022-06-24 19:50:12.417790
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    manager = InventoryManager(loader=None)
    source = './tests/data/test_inventory_manager/test_inventory.yml'
    manager.parse_source(source)
    # Test case 0
    assert manager.inventory.get_host('test_inventory_manager') is not None


# Generated at 2022-06-24 19:50:14.655485
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # test for non boolean type for parameter subset_pattern
    bool_0 = True
    var_0 = InventoryManager(bool_0)
    bool_0 = False
    var_0.subset(bool_0)
    bool_0 = True



# Generated at 2022-06-24 19:50:18.537600
# Unit test for method list_hosts of class InventoryManager

# Generated at 2022-06-24 19:50:26.115213
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory = Inventory("/Users/richard/src/ansible/test/integration/inventory-manager/test_inventory")
    inventory.set_variable("test_key", "test_value")
    inventory.reconcile_inventory()
    inventory.clear_pattern_cache()
    inventory.get_host("test_host")
    inventory.get_host("test_host_0")
    inventory.get_host("test_host_0:test_host_0")
    inventory.get_host("test_host_1")
    inventory.get_host("test_host_1:test_host_1")
    inventory.get_host("test_host_2")
    inventory.get_host("test_host_3")
    inventory.get_group("test_group_0")

# Generated at 2022-06-24 19:50:32.054904
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    # Instantiate a mock inventory plugin.
    class MockInventoryPlugin(object):
        def parse(self, inventory, loader, path, cache=True):
            return [(u'host_1', 'group_1'), (u'host_2', 'group_2')]

    # Instantiate an InventoryManager.
    im = InventoryManager(loader=MockDataLoader(), sources=u'inventory_file')
    # Setup the inventory file.
    temp_dir = tempfile.mkdtemp()
    inventory_file = os.path.join(temp_dir, u'inventory_file')
    with open(inventory_file, u'w') as f:
        f.write('inventory_value\n')

    # Setup a mock inventory plugin.
    im.inventory_plugins = {u'auto': MockInventoryPlugin()}

    # Create a

# Generated at 2022-06-24 19:50:38.302974
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    a_inv = InventoryManager(host_list=['a', 'b', 'c', 'd', 'e'])

    test_data = [
        (None, None),
        (['a', 'c', 'e'], ['a', 'c', 'e']),
        (['a', 'c', 'e', 'g'], ['a', 'c', 'e']),
        (['a', 'a', 'a'], ['a']),
        (['not_in_inv'], []),
    ]

    for args, expected in test_data:
        actual = a_inv.subset(*args)
        assert actual == expected


# Generated at 2022-06-24 19:50:43.845347
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    inventory = InventoryManager(loader=DictDataLoader({}))
    inventory._inventory = inventory.loader.load_from_file("/home/centos/workspace/test-ansible/contrib/inventory/test_inventory.yml")
    inventory.subset(None)
    pattern = "all"
    inventory.clear_pattern_cache()
    inventory.list_hosts(pattern)


# Generated at 2022-06-24 19:51:28.326281
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    pass # we do not test the subset method


# Generated at 2022-06-24 19:51:33.319390
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    var_1 = InventoryManager()
    var_2 = {'_uuid': 'uuid'}
    var_3 = var_2['_uuid']
    bool_0 = True
    var_1.parse_source(var_3, bool_0)


# Generated at 2022-06-24 19:51:44.147299
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    # Test the following cases:
    #       pattern='all'
    inventory = {'_meta': {'hostvars': {}, 'host_pattern_cache': {}, 'vars': {}, 'group_pattern_cache': {}}, 'ungrouped': {'hosts': ['localhost']}, 'all': {'children': ['ungrouped']}, 'localhost': {}}

    # Unit test for InventoryManager.list_hosts without args
    inv = InventoryManager(loader=DictDataLoader({}), sources=[])
    inv.parse_inventory('test_inventory', inventory)
    inv.subset(None)
    hosts = inv.list_hosts()
    assert hosts == ['localhost']

    # Unit test for InventoryManager.list_hosts with args
    hosts = inv.list_hosts('all')

# Generated at 2022-06-24 19:51:50.402038
# Unit test for function split_host_pattern

# Generated at 2022-06-24 19:51:53.719377
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    bool_0 = True
    str_0 = "AnsibleError"
    var_0 = InventoryManager(bool_0)
    var_1 = "a"
    var_0.subset(var_1)


# Generated at 2022-06-24 19:51:59.635451
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():
    try:
        bool_1 = True
        str_0 = "test_inventory"
        obj_0 = InventoryManager(bool_1, str_0)
        bool_0 = True
        obj_0.parse_sources(bool_0)
    except Exception as err:
        print(err)
        assert False
    else:
        assert True



# Generated at 2022-06-24 19:52:09.606282
# Unit test for method parse_sources of class InventoryManager

# Generated at 2022-06-24 19:52:12.923258
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    inventory_manager = InventoryManager('/')
    assert isinstance(inventory_manager.list_hosts(), list)


# Generated at 2022-06-24 19:52:15.125950
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    # FIXME:
    # 0) Generate a random test-case
    # 1) Create an instance of InventoryManager
    # 2) Call method get_hosts with the test-case as input
    # 3) Verify that the output is as expected
    failed_test_cases.append(0)


# Generated at 2022-06-24 19:52:17.012650
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    var_0 = InventoryManager(to_text(""))
    var_0.subset("foo")


# Generated at 2022-06-24 19:53:09.306282
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    inv = InventoryManager(loader=None, sources=[])
    assert inv.list_hosts("all") == []

# Generated at 2022-06-24 19:53:10.589569
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    result = InventoryManager().subset()
    assert result is None


# Generated at 2022-06-24 19:53:18.277091
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()
    bool_10 = bool()
    bool_11 = bool()
    bool_12 = bool()
    bool_13 = bool()
    bool_14 = bool()
    bool_15 = bool()
    bool_16 = bool()

    # Creation of inventory object
    var_1 = InventoryManager()

    # Method list_hosts using default values
    var_2 = var_1.list_hosts()

    # Method list_hosts using default values, with_argument and without_argument
    var

# Generated at 2022-06-24 19:53:28.992554
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    # Initialize hosts and inventory
    hosts = {'foo': Host(name='foo'), 'bar': Host(name='bar'), 'baz': Host(name='baz')}
    inventory = Inventory()
    inventory._hosts = hosts
    inventory._hosts_cache = hosts

    # Put inventory and hosts in manager
    manager = InventoryManager(inventory=inventory)

    # Test patterns

    # Should return all hosts
    pattern_1 = '*'
    # Should return 'foo' and 'bar'
    pattern_2 = 'foo*'
    # Should return 'baz'
    pattern_3 = 'baz'
    # Should return 'baz'
    pattern_4 = '*z'
    # Should return all hosts
    pattern_5 = ['*', '*']
    # Should return 'foo' and 'bar'


# Generated at 2022-06-24 19:53:31.104713
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager_0 = InventoryManager()
    inventory_manager_0.subset(None)


# Generated at 2022-06-24 19:53:35.324244
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():
    def test_case_0():
        args = object()
        ansible_inventory = object()
        var_0 = InventoryManager(args, ansible_inventory)
        var_1 = var_0.parse_src('localhost')
        assert var_1 is None


# Generated at 2022-06-24 19:53:43.267348
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    class Test_Inventory_0:
        hosts = {"test_host_0": Test_Host_0(), "test_host_1": Test_Host_1()}

    class Test_Inventory_1:
        groups = {"test_group_0": Test_Group_0()}

    test_inventory_0 = Test_Inventory_0()
    test_inventory_1 = Test_Inventory_1()
    test_manager_1 = InventoryManager(loader=None, sources=["test_inventory_0", "test_inventory_1"])

    # Test 1
    # Invalid arg
    # Expect AnsibleOptionsError from exception handling
    try:
        test_manager_1.list_hosts(pattern="test_pattern_0")
    except AnsibleOptionsError:
        test_result_0 = True

# Generated at 2022-06-24 19:53:50.977587
# Unit test for method subset of class InventoryManager

# Generated at 2022-06-24 19:53:57.360527
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    t = InventoryManager("./plugins/inventory/test/inventory")
    result = t.list_hosts("[0:20]")
    if len(result) != 20:
        assert False
    result = t.list_hosts()
    if len(result) != 199:
        assert False
    result = t.list_hosts("group2")
    if len(result) != 2:
        assert False


# Generated at 2022-06-24 19:53:58.889909
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    inventory = InventoryManager(loader=DataLoader())
    assert inventory.list_hosts() == []


# Generated at 2022-06-24 19:54:41.613585
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager_0 = InventoryManager([], [])
    # set
    subset_0 = [
        "abc",
        "bc"
    ]
    inventory_manager_0.subset(subset_0)
    # get
    subset_1 = inventory_manager_0.subset
    assert subset_0 == subset_1


# Generated at 2022-06-24 19:54:45.848778
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory_management = InventoryManager()

    inventory_management.parse_source('')

    assert_equal(inventory_management._inventory, '')


# Generated at 2022-06-24 19:54:49.128667
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # FIXME: Add test logic
    assert(False), "Not implemented"


# Generated at 2022-06-24 19:54:51.041632
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager = InventoryManager()
    inventory_manager.subset("inventory_hostname")


# Generated at 2022-06-24 19:54:54.511692
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    inventory = InventoryManager(loader=None, sources=None)
    pattern = "all"
    assert len(inventory.list_hosts(pattern=pattern)) == 0
    assert not any(x is None for x in inventory.list_hosts(pattern=pattern))


# Generated at 2022-06-24 19:55:00.789351
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    # Simple test case
    mgr = InventoryManager(loader, sources="dummy_inventory")
    assert mgr.get_hosts(pattern="all") == [u'localhost'], 'get_hosts should return [u\'localhost\']'
    assert mgr.get_hosts(pattern=u'all') == [u'localhost'], 'get_hosts should return [u\'localhost\']'
    assert mgr.get_hosts(pattern="!localhost") == [], 'get_hosts should return []'
    assert mgr.get_hosts(pattern=b"all") == [u'localhost'], 'get_hosts should return [u\'localhost\']'

# Generated at 2022-06-24 19:55:04.681895
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory_manager = InventoryManager()
    if True:
        # FIXME: unit test of method InventoryManager.get_hosts
        assert False, "Test not implemented"


# Generated at 2022-06-24 19:55:07.266816
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # Make a number or pattern is specified
    var_0 = InventoryManager([])
    var_1 = None
    var_0.subset(var_1)


# Generated at 2022-06-24 19:55:11.828482
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    # testing the following case:
    # Input: ()
    # Expected Output: ()

    inventory_manager = InventoryManager()
    actual = inventory_manager.list_hosts()
    expected = ()
    print('Expected: %s' % expected)
    print('Actual: %s' % actual)
    assert actual == expected


# Generated at 2022-06-24 19:55:13.714510
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    # FIXME: Replace this with a test using a mocked inventory
    inventory = InventoryManager(Loader())
    test_case_0()



# Generated at 2022-06-24 19:57:51.688991
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    import pytest_ansible_playbook_test

    # FIXME: test that get_hosts obtains a list of patterns from a pattern and
    # removes duplicates (and preserves order)
    # FIXME: test that get_hosts enforces limits and restrictions if requested
    # FIXME: test that get_hosts does not enforce limits or restrictions if
    # requested not to
    # FIXME: test that get_hosts returns a list of hosts matching the pattern(s)
    # (without duplicates)
    # FIXME: test that get_hosts caches the result of the first call per pattern
    # FIXME: test that get_hosts returns the cached result when called on
    # already-cached pattern
    # FIXME: test that get_hosts correctly applies the 'order' option to the
    # cached result when requested
    #

# Generated at 2022-06-24 19:57:53.030480
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory = InventoryManager(loader=None, sources='localhost,')
    inventory.subset('second')


# Generated at 2022-06-24 19:57:54.696437
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    test_case_0()



# Generated at 2022-06-24 19:58:00.083196
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    sub_patterns = [
        (None, None),
        ('', None),
        ('foo', ['foo']),
        ('@/tmp/file', ['/tmp/file'])
    ]
    inv = InventoryManager(loader=None, sources=[])
    for pattern, expected in sub_patterns:
        inv.subset(pattern)
        assert expected == inv._subset


# Generated at 2022-06-24 19:58:05.720134
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():

    # Variables build up to provide the expected inventory structure
    test_host = Host("host", "test")
    test_host.vars = dict({"test_var": "test_value"})
    test_host_2 = Host("host_2", "test")
    test_host_2.vars = dict({"test_var_2": "test_value_2"})
    test_subgroup = Group("subgroup", "test")
    test_subgroup.add_host(test_host_2)
    test_subgroup.vars = dict({"test_subgroup_var": "test_subgroup_value"})
    test_group = Group("group", "test")
    test_group.add_host(test_host)
    test_group.add_group(test_subgroup)
    test_

# Generated at 2022-06-24 19:58:07.493488
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    var_0 = InventoryManager()
    var_1 = var_0.list_hosts()


# Generated at 2022-06-24 19:58:08.926762
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    assert callable(getattr(InventoryManager, 'list_hosts', None))


# Generated at 2022-06-24 19:58:11.449835
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    params = ([], 'all')
    InventoryManager_ref_0 = make_InventoryManager(params)
    var_0 = InventoryManager_ref_0.list_hosts();
    return


# Generated at 2022-06-24 19:58:13.765375
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    pattern = "all"
    obj_1 = InventoryManager()
    obj_1.subset(pattern)


# Generated at 2022-06-24 19:58:19.419802
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory_manager_0 = InventoryManager(loader=None, sources=None)
    var_0 = inventory_manager_0.parse_source(var_0=None, var_1=None)
    return_value = inventory_manager_0.parse_sources(var_0=None)
