

# Generated at 2022-06-24 19:50:51.802946
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    test_case_0()


# Generated at 2022-06-24 19:50:54.560689
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():
    sources_list_0 = list()
    sources_list_0.append("test")
    inventory_manager_0 = InventoryManager(False)
    result = inventory_manager_0.parse_sources(sources_list_0)
    assert result == [], "'%s' must be equal to '%s'" % (result, [])


# Generated at 2022-06-24 19:50:59.269019
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    # create a dummy set of variables
    # create the inventory manager
    im = InventoryManager(host_list=HOSTS_LIST)
    # test 1, pattern all
    #assert im.get_hosts(pattern="all") == HOSTS_LIST
    # test 2, pattern host1
    assert im.get_hosts(pattern="host1") == ['host1']


# Generated at 2022-06-24 19:51:07.190347
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    def test_function_0(x_0, y_0):
        if x_0:
            raise AnsibleParserError
        return y_0.parse_source(x_0)

    def test_function_1(x_0, y_0):
        return y_0.parse_source(x_0, fail_on_error=False)

    ansible_0 = Mock()

# Generated at 2022-06-24 19:51:11.636256
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():
    sources = ['default']
    inventory_manager_0 = InventoryManager(sources)
    pass


# Generated at 2022-06-24 19:51:19.555587
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory_manager_0 = InventoryManager(False)
    inventory_manager_1 = InventoryManager(False)
    inventory_manager_2 = InventoryManager(False)
    inventory_manager_3 = InventoryManager(False)
    inventory_manager_4 = InventoryManager(False)
    inventory_manager_5 = InventoryManager(False)
    inventory_manager_6 = InventoryManager(False)
    inventory_manager_7 = InventoryManager(False)
    inventory_manager_8 = InventoryManager(False)
    inventory_manager_9 = InventoryManager(False)
    inventory_manager_10 = InventoryManager(False)
    # Testing with real data
    inventory_manager_11 = InventoryManager(False)
    inventory_manager_11.parse_source(None)
    inventory_manager_12 = InventoryManager(False)
    inventory_manager_12.parse_

# Generated at 2022-06-24 19:51:24.943305
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    '''
    1 test, pass
    '''
    # Setup
    input_arg_bool = True
    inventory_manager_0 = InventoryManager(input_arg_bool)

    # Exercise
    inventory_manager_0.list_hosts()

    # Verify
    assert inventory_manager_0._inventory.hosts == {}


# Generated at 2022-06-24 19:51:27.112688
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    bool_0 = False
    inventory_manager_0 = InventoryManager(bool_0)
    str_0 = "i"
    inventory_manager_0.subset(str_0)


# Generated at 2022-06-24 19:51:37.572785
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    # Setup
    pattern_0 = "YHkDL"
    ignore_limits_0 = False
    ignore_restrictions_0 = False
    order_0 = ""
    inventory_manager_0 = InventoryManager(bool_0)
    pattern_1 = "YHkDL"
    ignore_limits_1 = False
    ignore_restrictions_1 = False
    order_1 = ""
    inventory_manager_1 = InventoryManager(bool_0)
    pattern_2 = "YHkDL"
    ignore_limits_2 = False
    ignore_restrictions_2 = False
    order_2 = ""
    inventory_manager_2 = InventoryManager(bool_0)

    # Test
    # result_0 =

# Generated at 2022-06-24 19:51:41.398832
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    inventory_manager_0 = InventoryManager(None)
    hosts_0 = inventory_manager_0.list_hosts("all")

    assert hosts_0 is not None

# Generated at 2022-06-24 19:52:38.990207
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    print("### testing InventoryManager.subset")
    inventory_manager_0 = InventoryManager()
    assert inventory_manager_0 != None


# Generated at 2022-06-24 19:52:45.172431
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    # Init InventoryManager instance
    inventory_manager = InventoryManager(loader, host_list=['all'])
    # Test method list_hosts of InventoryManager
    inventory_manager.list_hosts(pattern="all")
    # Test case 0
    test_case_0()

if __name__ == "__main__":
    # For convenience, install the DebugLogger globally
    # so that it can be imported and used elsewhere.
    #  display.debug.setLevel(logging.DEBUG)
    display.display.DEBUG_LOG_FORMAT = '%(name)s %(message)s'
    display.display.verbosity = 4
    # Import the plugin
    #  from ansible.plugins.inventory import ini

    # Make a DebugLogger instance
    log = logging.getLogger(__name__)
   

# Generated at 2022-06-24 19:52:47.126259
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # Initial Code for this method
    subset = None
    # We call the method
    InventoryManager().subset(subset)


# Generated at 2022-06-24 19:52:49.325307
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():

    im = InventoryManager()
    im.parse_source('/tmp/test_InventoryManager_parse_source.tmp', 'yaml')
    assert(str(im.sources).find('/tmp/test_InventoryManager_parse_source.tmp') != -1)


# Generated at 2022-06-24 19:52:52.995162
# Unit test for method parse_sources of class InventoryManager
def test_InventoryManager_parse_sources():
    # Testing that by_pattern is set to True by default,
    # and to False when the 'by_pattern' is set to False in the kwargs.
    # These check the default param in __init__
    inventory_manager = InventoryManager()
    assert inventory_manager.by_pattern
    inventory_manager = InventoryManager(by_pattern=True)
    assert inventory_manager.by_pattern


# Generated at 2022-06-24 19:52:58.005050
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    objInstance = InventoryManager()
    
    # Test setter
    try:
        with pytest.raises(AnsibleError)  as error:
            objInstance.subset(None)
    except AnsibleError as e:
        print('Raise AnsibleError')
        print(str(e))
        bool_0 = False
    except Exception as e:
        print(str(e))
        bool_0 = False

    # Test case for method subset of class InventoryManager
    try:
        set_0 = {"a", "b"}
        assert objInstance.subset(set_0) == set_0
    except AssertionError:
        print('AssertionError')
        bool_0 = False
    except Exception as e:
        print(str(e))
        bool_0 = False
    
    #

# Generated at 2022-06-24 19:53:01.581542
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # subset method with string as input parameter (test case 0)
    test_InventoryManager = InventoryManager()
    test_InventoryManager.subset(test_case_0)

# Generated at 2022-06-24 19:53:02.816643
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    pass


# Generated at 2022-06-24 19:53:08.643894
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory = InventoryManager("/Users/huanghong/Downloads/ansible/ansible-2.7.2/lib/ansible/inventory")
    subset_pattern = 'all'
    exc = None
    try:
        inventory.subset(subset_pattern)
    except Exception as err:
        exc = err

    if exc:
        #print(exc)
        assert exc.args[0] == u'this is a error'


# Generated at 2022-06-24 19:53:13.937231
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    # FIXME: these test vars are not real and will not result in getting an
    # actual inventory from being parsed from file or from dir.
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=['one', 'two', 'three'])
    variable_manager.set_inventory(inventory)
    context = PlayContext(variable_manager=variable_manager)

    # Call parse_source method

# Generated at 2022-06-24 19:53:40.721403
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    i = InventoryManager(loader=None, sources='')
    i.subset(None)
    i.subset('')


# Generated at 2022-06-24 19:53:43.802577
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory_manager_instance = InventoryManager()
    var_0 = inventory_manager_instance.parse_source(b'b\x10\x00\x00\x00\x00\x00\x00\x00\x00')
    assert isinstance(var_0, dict)


# Generated at 2022-06-24 19:53:45.574313
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inv_mgr_0 = InventoryManager()
    inv_mgr_0.subset(None)
    # Verify results match expectations


# Generated at 2022-06-24 19:53:52.756831
# Unit test for method list_hosts of class InventoryManager
def test_InventoryManager_list_hosts():
    dict_0 = dict(a=1, b=2, c=3)
    bytes_0 = b'bop:bop'
    bool_1 = dict_0.__contains__(bytes_0)
    bytes_0 = b'a'
    int_1 = dict_0.get(bytes_0)
    int_2 = dict_0.get(bytes_0, 6)
    print(int_2)


# Generated at 2022-06-24 19:53:53.809166
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    test_case_0()


# Generated at 2022-06-24 19:53:56.715886
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():

    # Test case 1
    b_inventory_string_0 = b'----'
    inventory_obj_0 = InventoryManager(b_inventory_string_0)
    inventory_obj_0.subset(None)



# Generated at 2022-06-24 19:53:59.566595
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # test_InventoryManager_subset
    # GIVEN
    subset_pattern = None
    # WHEN
    i = InventoryManager()
    i.subset(subset_pattern)
    # THEN
    assert i._subset == None


# Generated at 2022-06-24 19:54:02.512906
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    manager = InventoryManager()
    subset_pattern = 'subset_pattern'
    manager.subset(subset_pattern)


# Generated at 2022-06-24 19:54:12.439845
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    b_executable_file = to_bytes(os.path.dirname(os.path.realpath(__file__)), errors='surrogate_or_strict')
    b_executable_file += b'/'
    b_executable_file += to_bytes(os.path.basename(__file__), errors='surrogate_or_strict')
    b_executable_file += b'.py'
    b_executable_file_1 = '/etc/ansible/hosts'
    b_executable_file_2 = 'f\x8f\x1c'
    b_executable_file_3 = '\x92\x99}\x0b'

# Generated at 2022-06-24 19:54:16.202889
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory = InventoryManager(['localhost, 127.0.0.1'])
    inventory.subset('localhost')


# Generated at 2022-06-24 19:55:47.456372
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    bytes_1 = b'cut'

# Generated at 2022-06-24 19:55:59.387410
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    bytes_0 = b't\x18'
    bytes_1 = b'\x9b\x1c\xfa\x8d'
    bytes_2 = b'\x86\xf8\xeb\x9c'
    bytes_3 = b'\x10\x00\x00'
    bytes_4 = b'\x9a\xea^'
    bytes_5 = b'\xa4\xd1b'
    bytes_6 = b'\x18\x00\x00'
    bytes_7 = b'\x00\x00\x00'
    bytes_8 = b'\x00\x00\x00'
    bytes_9 = b'\x00\x00\x00'
    bytes_10 = b'\x00\x00\x00'


# Generated at 2022-06-24 19:56:06.170391
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    # get_hosts() default args test, can further expand if necessary
    # Import data from inventory file
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Variables initialization
    pattern = 'all'
    ignore_limits = False
    ignore_restrictions = False
    order = None
    loader = DataLoader()

    inventory_file_path = 'test_fixtures/inventory_file_0'
    inventory_file_data = loader.load_from_file(inventory_file_path)

    obj = InventoryManager(loader=loader, sources=inventory_file_path)
    obj.parse_inventory(inventory_file_data)

    # Test get_hosts()

# Generated at 2022-06-24 19:56:11.512814
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    manager = InventoryManager(loader=None)
    hosts = manager.get_hosts()
    assert hosts == []

    hosts = manager.get_hosts(pattern='all')
    assert hosts == ['all']

    hosts = manager.get_hosts(pattern='*')
    assert hosts == []

    hosts = manager.get_hosts(pattern='all', ignore_limits=True)
    assert hosts == ['all']

    hosts = manager.get_hosts(pattern='all', ignore_restrictions=True)
    assert hosts == ['all']

    hosts = manager.get_hosts(pattern='all', order='sorted')
    assert hosts == ['all']



# Generated at 2022-06-24 19:56:14.364828
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    i_m = InventoryManager(loader=None, sources='/etc/ansible/hosts')
    var_0 = i_m.get_hosts(pattern='all')
    assert(var_0 is not None)


# Generated at 2022-06-24 19:56:21.053670
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    manager = InventoryManager()
    
    def subset(subset_pattern):
        return manager.subset(subset_pattern)
    
    subset_pattern = None
    expected = None
    subset(subset_pattern)
    assert manager._subset == expected
    
    subset_pattern = "subset_pattern"
    subset(subset_pattern)
    assert manager._subset is not None
    
    subset_pattern = "subset"
    subset(subset_pattern)
    assert manager._subset is not None

# Generated at 2022-06-24 19:56:23.755846
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory_manager = InventoryManager()
    pattern = b't\x18'
    inventory_manager.get_hosts(pattern)


# Generated at 2022-06-24 19:56:31.653597
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    """
    Restrict results to a subset of inventory that matches a given
    pattern, such as to select a given geographic or numeric slice amongst
    a previous 'hosts' selection that only select roles, or vice versa.
    Corresponds to --limit parameter to ansible-playbook.
    """
    bytes_0 = b'\t'
    bytes_1 = b'*'
    bytes_2 = b'[1-3]'
    bytes_3 = b'[2-5]'
    bytes_4 = b'[4-6]'
    bytes_5 = b'[5-7]'
    bytes_6 = b'[6-8]'
    bytes_7 = b'[7-9]'
    bytes_8 = b'[8-10]'
    bytes_9 = b'[9-11]'

# Generated at 2022-06-24 19:56:36.705161
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # Create a new inventory manager
    inventory_manager = InventoryManager()

    # Create a subset of hosts from the inventory manager
    inventory_manager.subset("all")


# Generated at 2022-06-24 19:56:38.847104
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    inventory = InventoryManager(host_list=['localhost'])
    # Test with bad arg 1
    arg_1 = {}
    rc = inventory.parse_source(arg_1)
    assert rc == False


# Generated at 2022-06-24 19:57:15.803272
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    # Initialization and setup of test case
    inventory_manager = InventoryManager()

    # Test case and assertion
    inventory_manager.get_hosts('all')


# Generated at 2022-06-24 19:57:22.789767
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():

    # Use case 1: Test the function when provided a path to a directory
    inventory_list = InventoryManager('tests/inventory/test_inventory_manager/valid_inventory_dir')
    inventory_list.parse_sources('host_list')

    # Use case 2: Test the function when provided an existing empty file
    inventory_list = InventoryManager('tests/inventory/test_inventory_manager/valid_inventory_file')
    inventory_list.parse_sources('host_list')

    # Use case 3: Test the function for the case where provided a directory that does not exist
    try:
        inventory_list = InventoryManager('tests/inventory/test_inventory_manager/invalid_inventory_file')
        inventory_list.parse_sources('host_list')
    except AnsibleError:
        pass
    else:
        assert False

    #

# Generated at 2022-06-24 19:57:29.957431
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    bytes_1 = b'[defaults]\na\tb\n'
    bytes_2 = b'c\n'
    bytes_3 = b'[misc]\n'
    bytes_4 = b'a\tb\n'
    bytes_5 = b'c\n'
    ansible_hosts = io.BytesIO()
    ansible_hosts.writelines([bytes_1, bytes_2, bytes_3, bytes_4, bytes_5])
    ansible_hosts.seek(0)
    inv = InventoryManager(loader=None, sources=ansible_hosts)

    assert type(inv) == InventoryManager
    assert inv.vars_cache == {'a': 'b', 'c': None}

# Generated at 2022-06-24 19:57:31.155242
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    # FIXME: write unit test
    pass


# Generated at 2022-06-24 19:57:36.230496
# Unit test for function split_host_pattern
def test_split_host_pattern():
    cases = {
        "test_case_0": ["t\x18", ['t\x18']]
    }
    for case in cases:
        if case != "test_case_0":
            bytes_0 = b'test'
            in_0 = [bytes_0, bytes_0]
            var_0 = split_host_pattern(in_0)
            assert var_0 == ["t\x18", "t\x18"]
            assert var_0 == cases[case][1]



# Generated at 2022-06-24 19:57:38.023565
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_manager = InventoryManager()
    subset_pattern = ""
    inventory_manager.subset(subset_pattern)


# Generated at 2022-06-24 19:57:47.958111
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    bytes_0 = b't\x18'
    var_0 = order_patterns(bytes_0)
    bytes_1 = b'\x0b'
    var_1 = order_patterns(bytes_1)
    bytes_2 = b'\x11'
    var_2 = order_patterns(bytes_2)
    inventory = InventoryManager('/home/centos/inventory/ansible_hosts')
    subset_pattern = None
    inventory.subset(subset_pattern)
    subset_pattern = 'all'
    inventory.subset(subset_pattern)
    subset_pattern = var_0
    inventory.subset(subset_pattern)
    subset_pattern = var_1
    inventory.subset(subset_pattern)
    subset_pattern = var_2
    inventory.subset

# Generated at 2022-06-24 19:57:50.698226
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    hosts = [Host(name='foo'), Host(name='bar'), Host(name='baz')]
    i = Inventory(hosts)
    i.subset('all')
    im = InventoryManager(inventory=i)
    assert im.get_hosts(pattern='*') == hosts


# Generated at 2022-06-24 19:58:00.728485
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    inventory_path = "/home/tyler/code/ansible/test/units/inventory"
    inv = Inventory(inventory_path)
    manager = InventoryManager(inv, host_list=[])
    manager.clear_pattern_cache()
    var_0 = manager.get_hosts()
    var_1 = manager.get_hosts(pattern=["all"])
    var_2 = manager.get_hosts(pattern="all", ignore_limits=False, ignore_restrictions=False, order="sorted")
    var_3 = manager.get_hosts(pattern="all", ignore_limits=False, ignore_restrictions=False, order="reverse_sorted")
    var_4 = manager.get_hosts(pattern="all", ignore_limits=False, ignore_restrictions=False, order="reverse_inventory")

# Generated at 2022-06-24 19:58:03.631908
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    mgr = InventoryManager(loader=None, sources='/tmp/ansible_TkDbpX/test_inventory')
    subset_pattern = 'all'
    mgr.subset(subset_pattern)


# Generated at 2022-06-24 19:58:37.763675
# Unit test for method subset of class InventoryManager
def test_InventoryManager_subset():
    inventory_0 = InventoryManager()
    subset_pattern = None
    inventory_0.subset(subset_pattern)
    var_0 = inventory_0._subset


# Generated at 2022-06-24 19:58:38.617322
# Unit test for method parse_source of class InventoryManager
def test_InventoryManager_parse_source():
    assert False


# Generated at 2022-06-24 19:58:47.446525
# Unit test for method get_hosts of class InventoryManager
def test_InventoryManager_get_hosts():
    bytes_0 = b'\x9a'
    bytes_1 = b'\x1d'
    bytes_2 = b'\x84'
    bytes_3 = b'L'
    bytes_4 = b'\x14'
    bytes_5 = b'\x0f'
    bytes_6 = b'\x07'
    bytes_7 = b'\r'
    bytes_8 = b'\x0e'
    bytes_9 = b'\x1c'
    bytes_10 = b'\x1f'
    bytes_11 = b'\t\x10\x15'