

# Generated at 2022-06-11 12:28:44.970391
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule('/some/path', dict(), True)
    mod.runner = dict()
    mod.runner['connection_plugins'] = dict()
    mod.runner['connection_plugins']['chroot'] = 'chroot connection plugin'
    return mod

# Generated at 2022-06-11 12:28:54.331764
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Initialization of a test object
    # --------------------------------
    def initialize_test_obj():
        import ansible.plugins.action
        class test_task(ansible.plugins.action.ActionBase):
            TRANSFERS_FILES = False
            def task(*args, **kwargs):
                return None

        class test_play(object):
            class play(object):
                class test_task(object):
                    name = 'test_task'
                    action = 'test_task'

        class test_ds(object):
            class play(object):
                test_task = test_play.play.test_task

            class _task(object):
                ds = test_ds.play

            class task_ds(object):
                task = test_ds._task()


# Generated at 2022-06-11 12:29:04.327907
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule(
        task=dict(action=dict(module_name='set_fact', args=dict(a=1, b=2))))
    ansible_facts = {}
    assert am.run(task_vars=dict(ansible_facts=ansible_facts)) == \
        dict(ansible_facts=dict(a=1, b=2), _ansible_facts_cacheable=False)
    assert ansible_facts == dict(a=1, b=2)
    assert am.run(task_vars=dict(ansible_facts=ansible_facts)) == \
        dict(ansible_facts=dict(a=1, b=2), _ansible_facts_cacheable=False)
    assert ansible_facts == dict(a=1, b=2)

# vim: set et

# Generated at 2022-06-11 12:29:07.597641
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task

    t = Task()
    t.args = {}
    am = ActionModule(t, {}, C.DEFAULT_LOADER_PLUGINS_PATH)

    assert am is not None

# Generated at 2022-06-11 12:29:15.599048
# Unit test for constructor of class ActionModule
def test_ActionModule():
    users = {'testuser': {'id': 1, 'name': 'testuser', 'state': 'absent', 'groups': ['testgroup'], 'password': 'testpassword', 'update_password': 'always'},
             'testuser2': {'id': 2, 'name': 'testuser2', 'state': 'present', 'groups': ['testgroup'], 'update_password': 'always'}}
    test_module = ActionModule(1, users, 'test_module_name')
    assert isinstance(test_module, ActionModule)

# Generated at 2022-06-11 12:29:22.579046
# Unit test for constructor of class ActionModule
def test_ActionModule():
    fake_loader = DictDataLoader({})

    module = ActionModule(
        task=dict(action=dict(module_name='debug', args=dict(msg='hello'))),
        connection=None,
        play_context=False,
        loader=fake_loader,
        templar=None,
        shared_loader_obj=False
    )

    assert module._task.args == dict(msg='hello')
    assert module._task.action == 'debug'
    assert module._play_context == False

# Generated at 2022-06-11 12:29:26.210076
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # mocks
    # pylint: disable=W0613
    from ansible.module_utils.parsing.convert_bool import boolean as boolean_mock
    def boolean_mock_side_effect(x, y):
        if x == 'y':
            return True
        elif x == 'n':
            return False
        else:
            return x
    # pylint: enable=W0613

    # inputs
    _task = MockTask()
    tmp = None
    task_vars = {}
    args = {
        'foo': 'bar',
        'baz': 'qux',
    }

    # prepare mocks
    boolean_mock.side_effect = boolean_mock_side_effect

    # run tests
    action = ActionModule(task=_task)

    # test

# Generated at 2022-06-11 12:29:33.457403
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Use `ansible-playbook --tags=test_ActionModule` with the following playbook:
    ---
    - hosts: all
      gather_facts: False
      tasks:
        - name: Constructor of class ActionModule
          my_action:
            key1: value1
            key2: value2
          tags:
          - test_ActionModule
    ...
    """
    o = ActionModule(dict(action=dict(key1='value1', key2='value2')))
    print("ActionModule.run() returned: %s" % o.run())



# Generated at 2022-06-11 12:29:34.199857
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 12:29:41.079832
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert boolean("Yes") == True
    assert boolean("No") == False
    assert boolean("YES") == True
    assert boolean("NO") == False
    assert boolean("yes") == True
    assert boolean("no") == False
    assert boolean("True") == True
    assert boolean("False") == False
    assert boolean("TRUE") == True
    assert boolean("FALSE") == False
    assert boolean("true") == True
    assert boolean("false") == False


# Generated at 2022-06-11 12:29:46.652555
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ac = ActionModule(None, {}, None, None)
    assert ac is not None

# Generated at 2022-06-11 12:29:54.031212
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {"test_var": "test_value"}
    tmp = None
    task = {"args": {"fact1": 1, "fact2": 2, "fact3": 3}}
    task_copy = {"args" : {"fact1": 1, "fact2": 2, "fact3": 3}}
    action_module = ActionModule(task_copy, tmp)
    action_module._task = task
    action_module._templar = task
    action_module.task_vars = task_vars
    result = action_module.run(tmp, task_vars)
    assert(result["ansible_facts"]["fact1"] == 1)
    assert(result["ansible_facts"]["fact2"] == 2)
    assert(result["ansible_facts"]["fact3"] == 3)

# Generated at 2022-06-11 12:30:04.563879
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # We need to fake methods task and run of class ActionModule
    # We fake method task by creating class FakeTask, which have
    # the same method run of class Task.
    # We fake method run of class ActionModule by creating
    # class FakeRun, which have the same method run of class ActionModule.
    # In this way we can perform test on method run of class ActionModule
    # without having to build a complicated task object.

    # We also need class AnsibleVars, which is fake class of class AnsibleVars
    # that way we can test without having to create a complicated ansibleVars
    # object.

    class FakeTask:
        def __init__(self):
            self.args = dict()
            self.args['a'] = 'b'


# Generated at 2022-06-11 12:30:13.457649
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a dummy config file for the test
    config = dict(ANSIBLE_HOST_KEY_CHECKING='False',
                  ANSIBLE_KEEP_REMOTE_FILES='0',
                  ANSIBLE_REMOTE_TMP='/tmp/ansible-tmp-1',
                  ANSIBLE_PERSISTENT_CONNECT_TIMEOUT='30')
    configfile = open('/tmp/ansible_test_config.cfg', 'w')
    for key, value in config.items():
        configfile.write('%s=%s\n' % (key, value))
    configfile.close()

    # Run the test
    assert(True)

# Generated at 2022-06-11 12:30:18.194242
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(connection=None, module_name="action_module", task=None, loader=None, templar=None, shared_loader_obj=None)
    params = {"facts":{"property1":"value1","property2":"value2"}}
    result = action_module.run(params)
    assert result["ansible_facts"] == {"property1":"value1","property2":"value2"}

# Generated at 2022-06-11 12:30:20.121179
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None)

    assert isinstance(action, ActionModule)

# Generated at 2022-06-11 12:30:21.903638
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule, type)
    assert issubclass(ActionModule, ActionBase)

# Generated at 2022-06-11 12:30:33.090861
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Test run method of class ActionModule. """
    import ansible.constants as C

    # Setup
    ansible.constants.DEFAULT_JINJA2_NATIVE = False
    action = ActionModule()
    cacheable = False
    tmp = "no effect"
    task_vars = {}
    result = {}
    action._task = {'args': {'a': '1', 'b': '2'}}
    action._templar = play_context()

    action._task.args['cacheable'] = cacheable
    # Expected results
    expected_result = {}
    expected_result['ansible_facts'] = {'a': '1', 'b': '2'}
    expected_result['_ansible_facts_cacheable'] = False
    # Execution

# Generated at 2022-06-11 12:30:42.585938
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    mock_loader = None
    mock_play = None
    mock_play_context = PlayContext()
    mock_task = Task()
    mock_task_vars = dict()

    # use constructor to create an instance of ActionModule
    action_module = ActionModule(mock_loader, mock_play, mock_task, mock_task_vars)
    # Assert class imported above is the class of action_module instead of some subclass
    assert(ActionModule == type(action_module))
    # Assert object created by constructor is an instance of ActionModule
    assert(isinstance(action_module, ActionModule))

# Generated at 2022-06-11 12:30:51.150284
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.constants as C

    module = ActionModule(dict(ACTION=dict(default='test')), None)

    # Initialise the task object with a null loader, so that the class can perform the tests without any
    # dependency on file location
    task = type('AnsibleTask', (object,), dict())
    task.args = {}
    task._ansible_no_log = C.DEFAULT_NO_LOG_VALUE
    task._ansible_module_name = 'test'
    task._ansible_ignore_errors = C.DEFAULT_IGNORE_ERRORS_VALUE
    task._ansible_verbosity = C.DEFAULT_VERBOSITY_VALUE
    task._ansible_version = C.ANSIBLE_VERSION
    task._ansible_module_name = 'test'
    task._ansible_index

# Generated at 2022-06-11 12:31:02.138796
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.set_fact
    class ModuleArgs(object):
        args = {}
    module = ModuleArgs()
    ansible.plugins.action.set_fact.ActionModule(module, "test")

# Generated at 2022-06-11 12:31:03.949450
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, 'set_fact', {'cacheable': False})
    print(action)

# Generated at 2022-06-11 12:31:06.970470
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class_ = ActionModule(action_plugin_config=dict(), task=dict(), connection=None, play_context=dict(), loader=None, templar=None, shared_loader_obj=None)
    assert class_ is not None

# Generated at 2022-06-11 12:31:07.473565
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-11 12:31:10.260608
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert 'TRANSFERS_FILES' in dir(action)
    assert 'run' in dir(action)

# Generated at 2022-06-11 12:31:11.798383
# Unit test for constructor of class ActionModule
def test_ActionModule():
    c = ActionModule(None, None, None)
    assert c is not None


# Generated at 2022-06-11 12:31:12.411878
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule({})

# Generated at 2022-06-11 12:31:14.984821
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=None)
    assert action_module

# Generated at 2022-06-11 12:31:18.983874
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.set_fact
    fact_action = ansible.plugins.action.set_fact.ActionModule(None, dict())
    fact_action.run(None, dict())

# Generated at 2022-06-11 12:31:29.868289
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Unit test for method run of class ActionModule')
    module = __import__('ansible.plugins.action', fromlist=['ActionModule'])
    action_module = getattr(module, 'ActionModule')
    action_module_instance = action_module()

    # test case #1
    print('\nCase #1')
    try:
        print('Case #1, result = ', action_module_instance.run('tmp', 'task_vars'))
    except Exception as e:
        print(e)

    # test case #2
    print('\nCase #2')
    try:
        print('Case #2, result = ', action_module_instance.run('tmp', 'task_vars', 'cacheable'))
    except Exception as e:
        print(e)



# Generated at 2022-06-11 12:31:47.396904
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    my_module = ActionModule()

    my_module.run(tmp='/tmp', task_vars={})

# Generated at 2022-06-11 12:31:48.497446
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print(ActionModule.run.__doc__)

# Generated at 2022-06-11 12:31:52.309085
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.set_fact as set_fact

    action_module = set_fact.ActionModule(None, None, None, None)

    assert action_module is not None
    assert hasattr(action_module, 'run')


# Generated at 2022-06-11 12:31:59.938327
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Get action module
    set_action = ActionModule(None, None, None, None, None, dict(a=1, b=2))

    # Check attributes
    assert set_action._supports_check_mode is False
    assert set_action._supports_async is False
    assert set_action.TRANSFERS_FILES is False
    assert set_action.action_loader._action_plugins is not None
    assert set_action._loaded_plugins is not None
    assert set_action.action is None
    assert set_action.action_args is None
    assert set_action.namespace is None
    assert set_action.connection is None
    assert set_action.play is None
    assert set_action.task is not None
    assert set_action._display is not None


# Generated at 2022-06-11 12:32:00.458138
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 12:32:02.605168
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(dict(Foo='Bar'))
    assert action is not None

# Generated at 2022-06-11 12:32:04.008064
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(0, 0, 0, 0)
    assert module is not None

# Generated at 2022-06-11 12:32:13.313418
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule()
    actionModule._task.args = {}

    # with no argument, should fail
    try:
        actionModule.run()
        assert False
    except AnsibleActionFail:
        pass

    # with valid arguments, should succeed
    for k in ('foo', 'foo_bar', '_foo', 'FOO', 'foo42'):
        actionModule._task.args = {k: 42}
        assert actionModule.run()['ansible_facts'][k] == 42

    # with invalid arguments, should fail
    for v in (42, '42', None):
        actionModule._task.args = {v: 42}
        try:
            actionModule.run()
            assert False
        except AnsibleActionFail:
            pass

# Generated at 2022-06-11 12:32:13.900678
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-11 12:32:17.840167
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Instance of class ActionModule
    class_instance = ActionModule(None, None)

    # check if the variable '_templar' of class ActionModule is set.
    if hasattr(class_instance, "_templar"):
        assert True
    else:
        assert False

# Generated at 2022-06-11 12:32:59.961469
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.vars import merge_hash

    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play


# Generated at 2022-06-11 12:33:01.236795
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 12:33:08.851725
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    def mock_templatetask():
        return dict()

    class MockBase(object):
        def __init__(self):
            self.task = mock_templatetask()

    def test_action__variable_name_not_identifier():
        from ansible.plugins.action.set_fact import ActionModule
        import ansible.utils.sphinx
        from ansible.module_utils.parsing.convert_bool import boolean
        from ansible.module_utils._text import to_text
        from ansible.utils.vars import isidentifier

        task_vars = dict()
        set_fact = dict()
        cacheable = boolean(False)
        task_vars = dict()
        base = MockBase()
        set_fact['a&'] = 'foo'

# Generated at 2022-06-11 12:33:09.831802
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(ActionBase(), {})
    assert module is not None

# Generated at 2022-06-11 12:33:19.345172
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    import os
    import imp
    module_utils_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'module_utils')
    sys.path.append(module_utils_path)
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_FALSE

    test_module = imp.load_source('test_module_name', os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                                                   'test_module_name.py'))
    action_module = test_module.ActionModule()

    # test is

# Generated at 2022-06-11 12:33:24.221731
# Unit test for constructor of class ActionModule
def test_ActionModule():
    cwd = "something"
    module_name = "test_module"
    task_var = dict()
    am = ActionModule(cwd=cwd, task_vars=task_var, module_name=module_name)
    assert am.module_name == module_name
    assert am.task_vars == task_var
    assert am.task_vars == task_var

# Generated at 2022-06-11 12:33:26.746996
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor of class ActionModule
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module

# Generated at 2022-06-11 12:33:34.981176
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.errors import AnsibleActionFail

    class FakeAction(ActionModule):
        def __init__(self, *args, **kwargs):
            super(FakeAction, self).__init__(*args, **kwargs)

        # pylint: disable=unused-argument
        def run(self, tmp=None, task_vars=None):
            self.result['invocation']['module_args'] = self._task.args
            return super(FakeAction, self).run(tmp, task_vars)

    class FakeTask(object):
        def __init__(self, args=dict()):
            self.args = args

    class FakePlayContext(object):
        def __init__(self, remote_addr='127.0.0.1'):
            self.remote_addr = remote_addr

   

# Generated at 2022-06-11 12:33:41.384395
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.vars import AnsibleUnsafe
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    import ansible.plugins.action.set_fact

    test_host = 'host.example.com'
    test_vars = {
        'test_host': {
            'ansible_facts': {
                'test_var': 'test_value'
            }
        }
    }

    task_vars = {
        'hostvars': test_vars
    }

    module_args = {
        'my_var': 123
    }

    tmp_path = "/tmp/ansible-module-set_fact"

    task = {"name": "set_fact", "args": module_args}
    result = {}


# Generated at 2022-06-11 12:33:49.931390
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule()

    # Test with empty `args`
    task = {'args': {}}
    result = mod.run(task_vars={}, task=task)
    assert 'ansible_facts' not in result

    # Test with `args` with invalid variable name
    task = {'args': {'`a': 1}}
    try:
        mod.run(task_vars={}, task=task)
        assert False
    except AnsibleActionFail as e:
        assert "The variable name '`a' is not valid. Variables must start with a letter or underscore character, " in str(e)

    # Test with `args` with valid variable name
    task = {'args': {'a': 1}}
    result = mod.run(task_vars={}, task=task)

# Generated at 2022-06-11 12:35:10.670610
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from collections import namedtuple
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    Options = namedtuple('Options', ['connection','module_path','forks','become','become_method','become_user','check','private_key_file'])
    variable_manager = VariableManager()
    loader = DataLoader()

    variable_manager.extra_vars = {
        'hostvars': {},
        'group_names': [],
        'groups': {},
    }


# Generated at 2022-06-11 12:35:12.211934
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule = ActionModule(None, None, None, None, None, None, None)
    assert actionmodule is not None

# Generated at 2022-06-11 12:35:21.792766
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # these imports are only required when running this test
    import ansible.constants as C
    import ansible.module_utils.parsing.convert_bool as convert_bool
    import ansible.utils.vars as vars

    task_vars = dict(Foo='bar')
    expected_results = dict(Foo='bar')
    tmp = None
    task_args = dict(Foo='bar')
    task_args = convert_bool.booleanize(task_args, strict=False)

# Generated at 2022-06-11 12:35:22.570655
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO
    pass

# Generated at 2022-06-11 12:35:31.484991
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(task=dict(args={}))
    try:
        action.run()
        assert False, "Failed to raise AnsibleActionFail."
    except AnsibleActionFail:
        pass

    action = ActionModule(task=dict(args={"_ansible_foo": "bar"}))
    try:
        action.run()
        assert False, "Failed to raise AnsibleActionFail."
    except AnsibleActionFail:
        pass

    action = ActionModule(task=dict(args={"$ansible": "bar"}))
    try:
        action.run()
        assert False, "Failed to raise AnsibleActionFail."
    except AnsibleActionFail:
        pass

    action = ActionModule(task=dict(args={"ansible": "bar"}))
    result = action.run()
   

# Generated at 2022-06-11 12:35:40.469395
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest
    from ansible.executor.task_result import TaskResult
    from ansible.module_utils.ansible_modlib.text.template import Templar

    class TestActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            return super(TestActionModule, self).run(tmp, task_vars)

    class TestTaskResult(TaskResult):
        def __init__(self):
            super(TestTaskResult, self).__init__()

    task_result = TestTaskResult()

# Generated at 2022-06-11 12:35:42.660100
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(load_plugins=False)
    assert a

# Generated at 2022-06-11 12:35:50.802257
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(action=dict(module_name='debug', args=dict(msg='- test'))),
        connection=None,
        play_context=dict(remote_addr='127.0.0.1', password='password'),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module is not None
    assert action_module.task == dict(action=dict(module_name='debug', args=dict(msg='- test')))
    assert action_module.connection is None
    assert action_module.play_context == dict(remote_addr='127.0.0.1', password='password')
    assert action_module.loader is None
    assert action_module.templar is None

# Generated at 2022-06-11 12:35:53.649711
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.TRANSFERS_FILES == False

# Generated at 2022-06-11 12:36:02.993480
# Unit test for method run of class ActionModule