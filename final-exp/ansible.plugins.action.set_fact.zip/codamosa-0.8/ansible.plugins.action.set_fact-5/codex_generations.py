

# Generated at 2022-06-11 12:28:49.675410
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule(load_name='test', task=dict(args=dict(somearg=dict(somekey='somevalue'))))
    result = actionModule.run()
    assert result['ansible_facts']['somearg'] == dict(somekey='somevalue')
    assert isinstance(result['ansible_facts'], dict)

# Generated at 2022-06-11 12:28:57.162570
# Unit test for constructor of class ActionModule
def test_ActionModule():
    t = dict(
        connection='local',
        DEFAULT_MODULE_ARGS=dict(
            cacheable='yes',
            param1='value1',
            param2='value2',
            param3='value3',
        ),
    )
    action_module = ActionModule(t)

    assert action_module._templar is not None
    assert action_module.connection == 'local'
    assert action_module._task.args == dict(
        cacheable='yes',
        param1='value1',
        param2='value2',
        param3='value3',
    )

# Generated at 2022-06-11 12:28:58.617172
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # We can't test this one. It is an abstract class
    pass

# Generated at 2022-06-11 12:28:59.246643
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-11 12:29:00.656118
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Verify that a ActionModule can be created without issue
    """
    ActionModule()

# Generated at 2022-06-11 12:29:06.903164
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(load_fn=lambda *args, **kwargs: dict(ANSIBLE_ANSIBLE_MODULE_ARGS=dict(hello="world")))
    setattr(module, '_task', lambda: None)
    setattr(module._task, 'args', lambda: dict(value="hello"))
    results = module.run()
    assert isinstance(results, dict)
    assert results.get('ansible_facts')
    assert results.get('_ansible_facts_cacheable')

# Generated at 2022-06-11 12:29:08.454089
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module.run()

# Generated at 2022-06-11 12:29:18.378795
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    test case for ansible facts action module
    '''
    result = {'ansible_facts': {'os_version': '2.4', 'os_name': 'Ubuntu'}}
    task = {'args': {'os_name': 'Ubuntu', 'os_version': '2.4'}}
    host = 'test_host'
    hostvars = {'test_host': {'hostvars': dict()}}
    loader = 'test_loader'
    templar = 'test_templar'
    am = ActionModule(task, host, hostvars, loader, templar)
    assert am.run() == result

# Generated at 2022-06-11 12:29:27.368782
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test ActionModule.run method
    """
    from ansible.plugins.loader import action_loader
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    # Create a new ActionModule object
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    am.BYPASS_HOST_LOOP = True

    # Create a new Host object
    h = Host(name='test')

    # Create a new VariableManager object
    v = VariableManager()

    # Create a new HostVars object

# Generated at 2022-06-11 12:29:33.761946
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_args = {"cacheable":True, "my_fact":"my_value"}
    mock_task = type('task', (object,), module_args)
    action_module = ActionModule(mock_task, mock_task.module_args)
    assert action_module._task.args == module_args
    assert action_module._task.action == "set_fact"
    assert action_module.name == "set_fact"
    assert action_module.action == 'set_fact'

# Generated at 2022-06-11 12:29:48.202508
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    "Test ActionModule.run"
    # no args
    args = {}
    result = ActionModule({}, {}, {}, {}, "", "", args).run()
    assert isinstance(result, AnsibleActionFail)

    # vars dictionary
    args = {
        'var1': 1,
        'var2': [2, 3]
    }
    result = ActionModule({}, {}, {}, {}, "", "", args).run()
    assert isinstance(result, dict)
    assert 'ansible_facts' in result
    assert '_ansible_facts_cacheable' in result
    assert result['ansible_facts'] == args
    assert result['_ansible_facts_cacheable'] == False

    # vars with cacheable

# Generated at 2022-06-11 12:29:54.891520
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from collections import namedtuple
    from ansible.plugins.action import ActionBase

    Options = namedtuple('Options', ['connection', 'module_path', 'forks', 'become', 'become_method', 'become_user', 'check', 'diff'])
    options = Options(connection='smart', module_path=None, forks=10, become=None, become_method=None, become_user=None, check=False, diff=False)
    action = ActionBase(None, None, None, None, options, None)
    assert action._templar.template('{{ "foo" }}') == 'foo'

    try:
        result = action.run(None, dict())
    except AnsibleActionFail as e:
        assert isinstance(e, AnsibleActionFail)


# Generated at 2022-06-11 12:29:57.980280
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module is not None


# Generated at 2022-06-11 12:30:09.110344
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    # Create the object under test

# Generated at 2022-06-11 12:30:10.287667
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actions = ActionModule()

    assert actions is not None

# Generated at 2022-06-11 12:30:17.743867
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import ansible.constants as C
    import ansible.playbook.play as play
    import ansible.playbook.task as task
    import ansible.utils.vars as vs
    import ansible.utils.template as t
    import ansible.utils.var_processor as vp

    # set defaults for testing
    C.DEFAULT_TASK_VARS = False
    C.DEFAULT_JINJA2_NATIVE = False

    # build the proxy for templating
    template_ds = dict(template='', searchpath='')
    template = t.AnsibleTemplate(template_ds)

    # build the proxy for variable processing
    variable_manager = vs.VariableManager()

# Generated at 2022-06-11 12:30:28.666161
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from mock import patch

    a = ActionModule(None, {'set_fact': {'one': 1, 'two': '2'}})
    a._task = {'args': {}}
    a._task_vars = {}
    a._templar = patch()

    assert a._templar().template.call_count == 0
    assert a._templar().template().call_count == 0
    assert a.run() == {'ansible_facts': {'one': 1, 'two': '2'}, '_ansible_facts_cacheable': False}
    assert a._templar().template.call_count == 2
    assert a._templar().template().call_count == 2

    b = ActionModule(None, {'set_fact': {'one': 1}})

# Generated at 2022-06-11 12:30:33.681816
# Unit test for constructor of class ActionModule

# Generated at 2022-06-11 12:30:44.604550
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Load up required modules
    import ansible.constants as C
    import importlib
    import ansible.utils.module_docs_fragments
    module_utils_loader = importlib.import_module(C.MODULE_UTILS_PATH[0])

    # Set up a task and action
    module_utils_loader.basic._ANSIBLE_ARGS = None
    task = {'args': {'cacheable': False, 'foo1': 'bar1', 'foo2': 'bar2'}}
    action_class = ActionModule(task, None, tmp=None, task_vars=None)
    action = action_class.run(tmp=None, task_vars=None)

    # Validate the results

# Generated at 2022-06-11 12:30:49.461421
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test fix for https://github.com/ansible/ansible/issues/1647
    assert ActionModule.run(
        None, # tmp
        {
            'hostvars': {},
            'hostvars[inventory_hostname]': {},
        },
        task_vars = {},
    ) == {
        '_ansible_facts_cacheable': False,
        'ansible_facts': {},
    }

# Generated at 2022-06-11 12:31:06.612908
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import FactsModule

    def dummy_module_args():
        return dict(
            test_variable="test value",
            other_variable="other value"
        )
    def dummy_module_kwargs():
        return dict(
            argument_spec=dict(),
            supports_check_mode=False,
            bypass_checks=False
        )
    module = FactsModule(dummy_module_args(), **dummy_module_kwargs())

    am = ActionModule(module)
    module.run()
    assert module.exit_args['test_variable'] == "test value"
    assert module.exit_args['other_variable'] == "other value"

# Generated at 2022-06-11 12:31:12.370966
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.constants as C
    module_name = os.path.basename(__file__)
    if module_name == "test_action_set_fact.py":
        module_name = "action_set_fact"
    module_args = {"foo": "bar", "baz": "quux"}
    my_action_module = ActionModule(dict(ANSIBLE_MODULE_ARGS=module_args, ANSIBLE_MODULE_NAME=module_name, ANSIBLE_MODULE_CONSTANTS=C))
    assert my_action_module is not None

# Generated at 2022-06-11 12:31:23.915206
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.called = False

    class MockTask(object):
        def __init__(self):
            self.args = {}

    class MockTemplar(object):
        def __init__(self):
            self.called = False
            self.template = lambda x: x

    class MockVars(dict):
        def get_vars(self):
            return self

    task_vars = MockVars({})
    action = ActionModule()
    action._task = MockTask()
    action._task.args = {'fact1': 'value1', 'fact2': 'value2'}
    action._templar = MockTemplar()
    result = action.run(None, task_vars)
    assert result

# Generated at 2022-06-11 12:31:33.602555
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create object of ActionModule class
    am = ActionModule()

    # Create object of Task class, which is defined in ActionBase class
    t = am.Task()

    # Create an object of given class and create a dictionary
    dict = {'key1':'val1','key2':'val2','key3':'val3','key4':'val4','key5':'val5'}

    # Set task variable to dictionary object
    t.set_task_vars(dict)

    # Verify task variable has been set to dictionary
    assert t.task_vars == dict

    # Create dictionary for result variable
    result = {'is_ok': True,
              'rest': {}}

    # Check the result variable is empty
    assert result == t.result

    # Set result variable to dictionary

# Generated at 2022-06-11 12:31:43.591059
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Okay, this test is not great, because there is no easy way to set ansible.constants.DEFAULT_JINJA2_NATIVE
    # to a true/false value here.  And that value affects the code logic, so it's semi-fundamental.
    # I think a better way to test this is to create a "test" or "dev" or "demo" ansible.cfg file in this directory
    # that would take precedence over the one in /etc.  That would allow us to specify the jinja2_native option,
    # and no need to mess with ansible.constants.DEFAULT_JINJA2_NATIVE itself.  This will have to do for now.

    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-11 12:31:44.143738
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()

# Generated at 2022-06-11 12:31:54.284593
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-11 12:32:03.376278
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json

    facts = dict()

    results = dict()
    results['ansible_facts'] = facts
    results['_ansible_facts_cacheable'] = False

    success = True
    results['changed'] = success

    failed = False
    results['failed'] = failed

    results_json = json.loads(json.dumps(results, sort_keys=True, indent=4, separators=(',', ': ')))

    action = ActionModule()
    action._task.args = dict()

    action._task.args['a'] = 'b'
    action._templar.template.return_value = 'a'

    result = action.run(None)

    assert result == results_json

# Generated at 2022-06-11 12:32:11.572049
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins
    import ansible.plugins.action
    assert issubclass(ansible.plugins.action.ActionModule,
                      ansible.plugins.ActionBase)
    assert issubclass(ansible.plugins.action.ActionModule,
                      object)
    action_module = ansible.plugins.action.ActionModule(
        task=mock_task(), connection=mock_connection(), play_context=mock_play_context())
    assert isinstance(action_module, ansible.plugins.action.ActionModule)
    assert isinstance(action_module, ansible.plugins.ActionBase)
    assert isinstance(action_module, object)


# Generated at 2022-06-11 12:32:21.579141
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor import task_result
    from ansible.executor.task_result import TaskResult
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE, BOOLEANS_FALSE
    from ansible.playbook.task_include import TaskInclude

    # Creates a fake task
    task = TaskInclude()
    task.action = 'set_fact'
    task.args = {
        'foo': 'bar',
        'spam': True,
        'eggs': False,
        'baz': 'True',
        'qux': 'False',
        'dict': {'nested': 'object'},
    }
    task.action = 'set_fact'

    # Creates a fake result

# Generated at 2022-06-11 12:32:47.084839
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest

    from collections import namedtuple
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor

    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import isidentifier
    from ansible.module_utils.six import iteritems

    from test_plugins.action.mock_action_modules import TestModule

    mock_loader = DataLoader()

    mock_tqm = None

    mock_variable_manager = VariableManager()
    mock_inventory = InventoryManager(loader=mock_loader, sources=['localhost,'])
    mock_variable_manager.set_inventory(mock_inventory)

   

# Generated at 2022-06-11 12:32:51.848522
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.plugins.action import ActionModule
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    play_source =  dict(
            name = "Ansible Play",
            hosts = 'webservers',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='set_fact', cacheable='yes', k1='v1', k2='v2')),
            ]
        )

    play = Play().load(play_source, variable_manager={}, loader=None)
    play._included_paths = ['/etc/ansible/plays']
    tqm = None

# Generated at 2022-06-11 12:32:55.378733
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit test for method run of class ActionModule

    :return:
    '''
    module = ActionModule()
    print(module)
    assert False


if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-11 12:32:57.715987
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.set_fact import ActionModule
    assert isinstance(ActionModule(), ActionModule)
    assert isinstance(ActionModule.TRANSFERS_FILES, bool)

# Generated at 2022-06-11 12:33:06.097281
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import sys
    import core.types_cache
    from core.vars_cache import VarsCache
    from core.loader import Loader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory import Inventory


# Generated at 2022-06-11 12:33:12.068073
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Testing method run of class ActionModule")
    # Test with invalid variable names

# Generated at 2022-06-11 12:33:21.715590
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    t = Task()
    t.action = 'set_fact'
    t.args = {'a': 1}
    t._ds = {'a': 1}
    h = Host('localhost')
    g = Group('all')
    g.add_host(h)
    h.set_variable('inventory_hostname', 'localhost')
    t._variable_manager = VariableManager()
    t._variable_manager.set_inventory(g)

    am = ActionModule(t, h, t._variable_manager, loader=None, templar=None, shared_loader_obj=None)
    assert am is not None

# Generated at 2022-06-11 12:33:29.398092
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Check if method run() of class ActionModule,
    returns the correct result.
    """
    class Task():
        def __init__(self, args):
            self.args = args

    class DataResult():
        ansible_facts = {}
        _ansible_facts_cacheable = {}


    result = DataResult()
    class ActionModule():

        def run(self, tmp=None, task_vars=None):
            return result

    tmp_module = ActionModule()
    task = Task({'k': 'v'})
    tmp_module._task = task
    tmp_module.run()
    assert result == tmp_module.run()

# Generated at 2022-06-11 12:33:37.331689
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule()
    assert hasattr(x, 'TRANSFERS_FILES')
    assert hasattr(x, '_config_module')
    assert hasattr(x, '_connection')
    assert hasattr(x, '_display')
    assert hasattr(x, '_loader')
    assert hasattr(x, '_module_compression')
    assert hasattr(x, '_supports_check_mode')
    assert hasattr(x, '_supports_async')
    assert hasattr(x, '_supports_terminal_phase')
    assert hasattr(x, '_templar')
    assert hasattr(x, '_task')
    assert hasattr(x, '_templar')
    assert hasattr(x, '_shared_loader_obj')

    assert has

# Generated at 2022-06-11 12:33:38.394429
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    obj = ActionModule()

    # Teardown
    pass

# Generated at 2022-06-11 12:34:20.753261
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule(None, None)
    
    # Call the method run of class ActionModule
    result = action_module.run({'tmp':''}, {})
    assert result == {'ansible_facts': {'k': 'v'}, '_ansible_facts_cacheable': False, 'changed': False}

    # Call the method run of class ActionModule
    result = action_module.run({'tmp':''}, {})
    assert result == {'ansible_facts': {'k': 'v'}, '_ansible_facts_cacheable': False, 'changed': False}

# Generated at 2022-06-11 12:34:28.080249
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Just checking exception is raised
    # because _ansible_facts_cacheable is a property with no setter.
    # Its value is calculated in _execute() method of class ActionBase
    class MockActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            #tmp no longer has any effect
            del tmp 
            #task_vars no longer has any effect
            del task_vars

            # NOTE: We could mock _execute method of class ActionBase,
            # but it requires more mocking.
            result = {
                'changed' : False,
                '_ansible_facts_cacheable': False,
            }

            return result

    class MockTask(object):
        def __init__(self, args):
            self._args = args # simulate self.args = args


# Generated at 2022-06-11 12:34:37.619820
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.ansible_modlib.tmp_module import TmpModule
    from ansible.parsing.vault import VaultLib
    from ansible.vars.unsafe_proxy import UnsafeProxy, wrap_var

    play_context = dict(
        port=5309,
        remote_addr='127.0.0.1',
        password='VaultPasswordHere',
        become=False,
        become_method=None,
        become_user=None,
        become_ask_pass=False,
        connection='local',
        module_name='command',
        module_args=dict(),
        module_vars=dict()
    )


# Generated at 2022-06-11 12:34:42.508844
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(None, None, None)
    action_module._task.args = {'my_var':'my_value'}
    action_module._templar.template = lambda x: x
    result = action_module.run()
    assert result['ansible_facts']['my_var'] == 'my_value'
    assert '_ansible_facts_cacheable' not in result

# Generated at 2022-06-11 12:34:43.094509
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()

# Generated at 2022-06-11 12:34:47.614722
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task

    t = Task()
    t.action = 'core.none'
    t.args = {'key': 'value'}
    am = ActionModule(t, {})
    assert am.name == 'core.none'
    assert am._task.args['key'] == 'value'


# Generated at 2022-06-11 12:34:53.170920
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule()

    # test for valid argument
    arguments = {'facts': {'test': 1}}
    assert actionModule._execute_module(module_args=arguments) == {'ansible_facts': arguments['facts'],
                                                                    '_ansible_facts_cacheable': False}

    # test for invalid argument
    arguments = {'invalid-_arg': 1}
    with pytest.raises(AnsibleActionFail):
        actionModule._execute_module(module_args=arguments)

# Generated at 2022-06-11 12:34:59.212595
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Run the constructor tests for the class ActionModule
    """
    print('Constructor tests')
    print('------------------')
    result = dict()
    a = dict()
    t = dict()
    action_module = ActionModule(a, t)
    #assert result == action_module.run
    #assert a == action_module._task.args
    #assert t == action_module._task.action
    print('Constructor tests Complete')


# Generated at 2022-06-11 12:35:07.706725
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  
    # Create an instance of the class under test
    am = ActionModule()

    # A valid set of arguments
    arguments = {"key1":"value1","key2":"value2"}
    # A valid set of ansible_facts
    ansible_facts = {"key1":"value1","key2":"value2"}
    # A valid set of task_vars
    task_vars = {}
    # An empty set of arguments
    empty = {}

    # Test the case of valid arguments and valid ansible_facts
    res = am.run(arguments,ansible_facts)
    res_facts = res["ansible_facts"]
    if res_facts == ansible_facts:
        print ("TEST 1 - SUCCESSFUL")
    else:
        print ("TEST 1 - FAIL")
    # Test the case of valid

# Generated at 2022-06-11 12:35:15.221831
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import ansible.utils.template as templating
    from ansible.playbook.play_context import PlayContext

    from ansible.plugins.loader import action_loader
    action = action_loader.get('set_fact', class_only=True)()

    action._templar = templating.Templar(loader=None)

    action._task = type('Task', (object,), dict(action=dict(vars=dict())))
    action._task.args = dict(test=dict(test_key='test_value'))

    action.run()


if __name__ == '__main__':
    import sys
    import doctest
    sys.exit(doctest.testmod()[0])

# Generated at 2022-06-11 12:36:52.852769
# Unit test for constructor of class ActionModule
def test_ActionModule():
    data = dict(
        ansible_connection="local",
        ansible_ssh_user="user",
        ansible_ssh_pass="pass",
        module_name="test",
        module_args=dict(a=1, b=2),
        task_vars=dict(x=1, y=2)
    )

    action = ActionModule(None, data)

    assert action
    assert action.ansible
    assert action.runner
    assert action._task
    assert action._loader
    assert action._shared_loader_obj
    assert action._templar
    assert action._connection

# Generated at 2022-06-11 12:36:58.434721
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    a = ActionModule()

    args = {
    "cacheable": "true",
    "key1": "val1",
    "key2": "val2"
    }

    a._task = MockTask(args)

    a._templar = MockTemplar()

    tmp, task_vars = None, None

    ret = a.run(tmp, task_vars)

    assert ret is not None
    assert ret['_ansible_facts_cacheable'] is True
    assert ret['ansible_facts']['key1'] == "val1"
    assert ret['ansible_facts']['key2'] == "val2"

    # Invalid variable name should fail
    args = {
    "cacheable": "true",
    "key#": "val"
    }


# Generated at 2022-06-11 12:37:00.737937
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create an object of class ActionModule
    s = ActionModule()

    # call run method
    result = s.run()

    # check if result is correct
    assert False

# Generated at 2022-06-11 12:37:01.267449
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  assert True

# Generated at 2022-06-11 12:37:09.307338
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # stubs
    class ModuleStub(object):
        def __init__(self, task_vars=None, no_log=False, become_method=False, become_user=False, check_mode=False):
            self._task_vars = task_vars
            self._no_log = no_log
            self._become_method = become_method
            self._become_user = become_user
            self._check_mode = check_mode

    class TaskStub(object):
        def __init__(self, args=None):
            self.args = args or {}

    class PlayContextStub(object):
        def __init__(self, become_method=False, become_user=False, check_mode=False):
            self.become_method = become_method
            self.become_

# Generated at 2022-06-11 12:37:17.415611
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json

    task_vars = {
        'ansible_python_interpreter': '',
        'ansible_facts': {},
        'ansible_variable_prefix': '',
        'ansible_play_hosts_all': [],
        'ansible_play_hosts': ['host1', 'host2']
    }
    task = {
        'args': {
            'k1': 'v1',
            'k2': 2,
            'k3': True,
            'k4': [{'subk1': 'subv1'}],
            'k5': {'subk2': 'subv2'},
        }
    }

    # Execute method
    action = ActionModule(task, task_vars, 1)

# Generated at 2022-06-11 12:37:25.143456
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    task = Task()
    task_vars = dict(
        debug = dict(
            msg = 'I love Ansible!'
        )
    )

    # Test the case of non-cacheable ansible_facts.
    task._load_args(dict(
        ansible_facts = dict(
            key1 = 'value1'
        )
    ))

    action = ActionModule(task, PlayContext())
    result = action.run(task_vars=task_vars)

    assert result is not None
    assert result.get('ansible_facts') is not None
    assert result.get('_ansible_facts_cacheable') is False

    # Test the case of cacheable ansible_facts.
   

# Generated at 2022-06-11 12:37:26.208742
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule('test', 'test', 'test', 'test') is not None

# Generated at 2022-06-11 12:37:33.407831
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    module_args = dict(cacheable=True, new_value=1)
    class MockTask:
        args = module_args
    task = MockTask()
    class MockTemplar:
        def template(self, value):
            return value
    templar = MockTemplar()

    results = dict()
    class MockActionBase:
        def run(self, tmp, task_vars):
            results = dict()
            results['tmp'] = tmp
            results['task_vars'] = task_vars
            return results

    action_base = MockActionBase()
    action_module = ActionModule(action_base, task, templar)
    result = action_module.run(tmp=None, task_vars=None)


# Generated at 2022-06-11 12:37:40.922400
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()
    am._templar = 'ciao'
    am._task.args = {'debug': 'True', 'tmp': '/tmp/'}
    result = am.run()
    assert result['ansible_facts']['debug'] == 'True'
    assert result['_ansible_facts_cacheable'] == True
    assert result['ansible_facts']['tmp'] == '/tmp/'
    assert result['_ansible_facts_cacheable'] == True
    
    am._task.args = {'debug': 'false', 'tmp': '/tmp/'}
    result = am.run()
    assert result['ansible_facts']['debug'] == False
    assert result['_ansible_facts_cacheable'] == True