

# Generated at 2022-06-11 12:28:54.943680
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #Initialize an ActionModule object
    actionModule = ActionModule(action='test', task=dict(args=dict(test='test')), connection='test', play_context=dict(become='test'), loader=dict(test='test'), templar=1)
    assert actionModule.TEMPLATE_DIRS == ('templates',)
    assert actionModule.BOOLEANS_TRUE == ('yes', 'on', '1', 'true', 'True')
    assert actionModule.BOOLEANS_FALSE == ('no', 'off', '0', 'false', 'False')
    assert actionModule._play_context == dict(become='test')
    assert actionModule._task == dict(args=dict(test='test'))
    assert actionModule._loader == dict(test='test')

# Generated at 2022-06-11 12:28:55.533743
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()

# Generated at 2022-06-11 12:28:57.303522
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_action = ActionModule(None, None, None)
    assert module_action is not None

# Generated at 2022-06-11 12:29:02.448401
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(None, "")
    action_module._task = ActionModule_Task()
    action_module._templar = ActionModule_Templar()
    ansible_facts={}
    tmp={}
    action_module.run(tmp, ansible_facts)
    assert ansible_facts['testvalue'] == 'testvalue'



# Generated at 2022-06-11 12:29:04.727878
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(dict(), dict())
    assert action is not None

if __name__ == '__main__':
    pytest.main([__file__])

# Generated at 2022-06-11 12:29:10.868535
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert not hasattr(module, '_task')
    assert not hasattr(module, '_connection')
    assert not hasattr(module, '_play_context')
    assert not hasattr(module, '_loader')
    assert not hasattr(module, '_templar')
    assert not hasattr(module, '_shared_loader_obj')
    assert not hasattr(module, '_final_loader_obj')

# Generated at 2022-06-11 12:29:16.052912
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.TRANSFERS_FILES is False
    assert action_module.DEFAULT_TRANSFER_METHOD is None

# Generated at 2022-06-11 12:29:17.979153
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert 'cacheable' in ActionModule.run.__code__.co_varnames

# Generated at 2022-06-11 12:29:21.269163
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.set_fact import ActionModule
    x = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=None, templar=None, shared_loader_obj=None)
    assert x is not None

# Generated at 2022-06-11 12:29:24.898372
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pdb
    import sys

    class MyCli(object):
        def __init__(self):
            self.become_pass = 'mypass'
            self.become = True
            self.become_method = 'sudo'

    class MyRunner(object):
        def __init__(self):
            self.become_user = 'root'
            self.noop_on_check = False
            self.noop_on_check_args = None
            self.noop_on_check_vars = None
            self.become_exe = ['sudo', '-S', '-p', 'mypass']
            self.become_flags = ['-H']
            self.module_name = 'shell'
            self.inventory = 'myinventory'

# Generated at 2022-06-11 12:29:33.911911
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule({'name': 'ActionModule'}, {'a': {'b': {'c': 'd'}}})
    assert action_module.run(task_vars={'test': {'key': 'value'}}) == {'ansible_facts': {'test': {'key': 'value'}}, '_ansible_facts_cacheable': False}

# Generated at 2022-06-11 12:29:43.760051
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class MockModule(object):
        def __init__(self):
            self._task = MockTask()
            self._task.args = {'cacheable': 'true'}
    mock_module = MockModule()
    assert isinstance(mock_module._task, MockTask)
    assert mock_module._task.args == {'cacheable': 'true'}
    mock_action_module = ActionModule(mock_module, task_vars=['ansible_facts'])
    assert mock_action_module._task == mock_module._task
    assert mock_action_module._task.args == mock_module._task.args
    assert isinstance(mock_action_module, ActionModule)


# Generated at 2022-06-11 12:29:44.352481
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:29:52.757564
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Negative test_case
    # Exception should be raised if not key/value pairs provided
    try:
        obj = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
        obj.run(tmp=None, task_vars=None)
    except AnsibleActionFail as e:
        if e.message == 'No key/value pairs provided, at least one is required for this action to succeed':
            print("Failed: Correct exception raised")
        else:
            print("Failed: Wrong exception raised")

    # Positive test_case
    # If key/value pairs provided, it should not raise any exceptions

# Generated at 2022-06-11 12:30:00.384566
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_loader = None
    mock_module_name = "mock_module"
    mock_action_name = "mock_action"
    mock_task = None
    mock_inject = None
    mock_shared_loader_obj = None

    action_module = ActionModule(mock_loader, mock_module_name, mock_action_name, mock_task, mock_inject, mock_shared_loader_obj)

    assert action_module._task.action == mock_action_name
    assert action_module._task.module_name == mock_module_name
    assert action_module._task.args == {}


# Generated at 2022-06-11 12:30:10.929406
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor import task_result

    class Obj:
        def __init__(self):
            self.ansible = False
            self.changed = False
            self.result = None
            self.args = {'cacheable': False}

    obj = Obj()
    obj.args['test1'] = 'test2'
    obj.args['test3'] = 'test4'
    test_results = task_result.TaskResult(obj)

    action = ActionModule()
    action.run(None, test_results)

    assert(test_results['ansible_facts']['test1']) == 'test2'
    assert(test_results['ansible_facts']['test3']) == 'test4'

# Generated at 2022-06-11 12:30:12.263424
# Unit test for constructor of class ActionModule
def test_ActionModule():
    aa = ActionModule(None, None)
    assert isinstance(aa, ActionBase)

# Generated at 2022-06-11 12:30:21.251834
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Stub class to mimic actual AnsibleModule class to instantiate ActionModule class
    class AnsibleModuleStub:
        def __init__(self):
            self.params = dict()
            self.check_mode = False
            self.tmpdir = None
            self.tmp = None
            self.task_vars = {}

    # Create instance of ActionModule
    am = ActionModule()
    # Create instance of AnsibleModule class for am.run() to use
    ams = AnsibleModuleStub()
    # Create dict for am.run() to use as self._task.args
    task_args = dict()
    # Create dict for am.run() to use as task_vars for parameters

    # Test for invalid variable name
    task_args['xyz.case'] = 'some value'

# Generated at 2022-06-11 12:30:25.727696
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task={}).task == {}
    assert ActionModule(task={'args': {'name': 'TestName'}, 'action': 'test'}).task == {'args': {'name': 'TestName'}, 'action': 'test'}


# Generated at 2022-06-11 12:30:26.488717
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass # TODO

# Generated at 2022-06-11 12:30:39.322410
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.ansible_release import __version__ as ansible_version
    assert ansible_version >= '2.3.0.0'
    assert C.DEFAULT_JINJA2_NATIVE is True
    args = {
        'key1': 'value1',
        'key2': True
    }
    task_vars = dict()
    action_module = ActionModule(dict(module_args=args, task_vars=task_vars))
    result = action_module.run(dict(), dict())
    assert result['changed'] is False
    assert result['_ansible_facts_cacheable'] is False
    assert result['ansible_facts']['key1'] == 'value1'
    assert result['ansible_facts']['key2'] is True

# Generated at 2022-06-11 12:30:49.532126
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with all valid pairs
    module = ActionModule()
    result = module.run({},{'ansible_facts': {}, '_ansible_facts_cacheable': False,
                            'ansible_verbose_always': False},
                            {'some_value': 'vaue', 'another_value': {'complex': 'value'}})
    assert result['ansible_facts'] == {'some_value': 'vaue', 'another_value': {'complex': 'value'}}, \
            result

    # Test with no pairs
    module = ActionModule()
    result = module.run({},{'ansible_facts': {}, '_ansible_facts_cacheable': False,
                            'ansible_verbose_always': False},{})

# Generated at 2022-06-11 12:30:54.564888
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(
        {'argument_spec': {'cacheable': {'type': 'bool'}, 'name': {'required': True, 'type': 'str'}}},
        {'name': 'test', 'args': {'ansible_net_serialnum': 'SN123', 'ansible_net_version': '1.2.3', 'cacheable': 'true'}}
    )
    assert hasattr(a, 'run')

# Generated at 2022-06-11 12:30:55.832302
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()

    assert module.run({}) == {}

# Generated at 2022-06-11 12:31:05.320225
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_native

    module = ActionModule(
        {
            'task': {
                'args': {
                    'cacheable': True,
                    'var_name': 'value',
                    'var1': 'xyz',
                    'var2-name': 123,
                    'var3_name': True,
                },
            },
        },
        None,
    )

    try:
        # noinspection PyTypeChecker
        module.run()
        exit(1)
    except AnsibleActionFail as e:
        assert to_native(e) == "No key/value pairs provided, at least one is required for this action to succeed"

    module.result = {}

# Generated at 2022-06-11 12:31:12.577383
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.vars import combine_vars
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    a = ActionModule(dict(DEFAULT_JINJA2_NATIVE=False),
                     'localhost',
                     combine_vars(dict(), dict(a='b', c='d', e='f')))

# Generated at 2022-06-11 12:31:16.893367
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    import sys

    # Set up mock module argument spec
    argument_spec = dict(
        cacheable = dict(type='bool', required=False, default=False),
        foo = dict(type='str', required=False),
        bar = dict(type='str', required=False),
        baz = dict(type='str', required=False)
    )

    module = AnsibleModule(exit_json=None, fail_json=None, argument_spec=argument_spec)

    # Set up mock module object
    sys.modules['ansible.module_utils.basic'] = module
    action_module = ActionModule()
    action_module._task = dict()
    action_module._task['args'] = dict()

    # Test caching disabled

# Generated at 2022-06-11 12:31:21.206048
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_mod_obj = ActionModule(None, None, load_plugins=False)
    assert action_mod_obj.run(None, None) == {'ansible_facts': {}, '_ansible_facts_cacheable': False}


# Generated at 2022-06-11 12:31:22.245853
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-11 12:31:32.366843
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    def _create_task(task_name):
        task = Task()
        task._role = None
        task.action = 'set_fact'
        task.args = {'var1': {'key1': 'value1'}, 'var2': {'key2': 'value2'}}
        task._parent = Play()
        task.name = task_name
        return task
    def _create_host(host_name):
        host = Host()


# Generated at 2022-06-11 12:31:51.411426
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule(task=dict(args=dict()), connection=dict(), play_context=dict(), loader=None, templar=None, shared_loader_obj=None)
    assert mod.TRANSFERS_FILES == False


# Generated at 2022-06-11 12:31:59.475521
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit test for method run of class ActionModule """
    # fixtures
    task = dict(
        args = dict(
            a = 1,
            b = '{{c}}',
            c = 2,
            d = True,
            e = '{{f}}',
            f = False,
        )
    )
    templar = dict(
        template = dict(
            side_effect = lambda x: x,
        )
    )
    ansible_facts = dict()
    name = 'foo'
    split_args = dict(vars=task['args'])
    inject = dict(
        ansible_facts = ansible_facts,
    )
    # initialization of the class we test

# Generated at 2022-06-11 12:32:02.746275
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # the basic run method does not have any unit tests yet,
    # because it mostly relies on the templating engine and vars modules
    # and both have their own unit tests already.
    pass

# Generated at 2022-06-11 12:32:12.684979
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_result import TaskResult

    play = Play()
    play.connection = 'local'
    play.become = False
    play_context = PlayContext()

    task = Task()
    task.context = play_context
    task_vars = {'foo': 'bar'}

    actionModule = ActionModule(task, play_context, '/path/to/here', task_vars)

    module_args = {
        'a': 1,
        'cacheable': False,
    }

# Generated at 2022-06-11 12:32:14.411991
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ac = ActionModule()
    assert 'result' in ac.run()

# Generated at 2022-06-11 12:32:15.620281
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module

# Generated at 2022-06-11 12:32:17.639310
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-11 12:32:22.867703
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Arrange
    param_task_args = {
        "hostvars": "[ansible_eth1].macaddress"
    }
    param_task_action = 'set_fact'
    param_task_action_args = {"cacheable": "True"}
    # Act
    act_result = ActionModule(param_task_action, param_task_action_args, param_task_args)
    # Assert
    assert act_result.TRANSFERS_FILES == False

# Generated at 2022-06-11 12:32:32.939035
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    from ansible.plugins.loader import action_loader

    set_module = action_loader.get('set_fact', class_only=True)
    set_module.setup_cache()

    result = set_module.run(task_vars={})

    assert result == {'ansible_facts': {}}, result
    assert set_module.cache_key() == ''
    result = set_module.run(task_vars={})

    assert result == {'ansible_facts': {}}, result
    assert set_module.cache_key() == ''

    result = set_module.run(task_vars={}, tmp='/tmp', task_uuid='uuid')
    assert result == {'ansible_facts': {}}, result
    assert set_module.cache_key() == ''

    result = set

# Generated at 2022-06-11 12:32:38.858659
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test creation of ActionModule object
    module = ActionModule(play_context=dict(),
                          new_stdin=dict(
                              ansible_connection='ssh',
                              ansible_user='root',
                              ansible_host='localhost',
                              ansible_port=22,
                              ansible_ssh_pass='root'),
                          loader=dict(),
                          templar=dict(),
                          shared_loader_obj=dict())


# Generated at 2022-06-11 12:33:11.257462
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:33:20.916268
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    play_context = Play().set_context()

    # Initialize our class
    a = ActionModule(
        Task(),
        play_context,
        '/path/to/ansible/lib/ansible/modules',
        'testhost',
        'testuser',
        'testpass',
        '/tmp/test',
        '127.0.0.1',
        'testport',
        'testaction',
        'testname',
        'testdep',
    )

    # Check for the class of a
    assert a._task.__class__.__name__ == 'Task'
    assert a._play_context.__class

# Generated at 2022-06-11 12:33:29.963612
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule('test')

    # Test - no args
    res = m.run({})
    assert isinstance(res['failed'], bool)
    assert res['failed'] == True
    assert res['msg'] == 'No key/value pairs provided, at least one is required for this action to succeed'

    # Test - simple args
    m = ActionModule('test')
    m._task.args = {'foo': 'bar'}
    res = m.run({})
    assert isinstance(res['ansible_facts'], dict)
    assert res['ansible_facts']['foo'] == 'bar'
    assert isinstance(res['_ansible_facts_cacheable'], bool)
    assert res['_ansible_facts_cacheable'] == False

    # Test - jinja2 interpolation

# Generated at 2022-06-11 12:33:32.011493
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #TODO: Unit test for ActionModule.run()
    #      Currently this test suite is not running the run method
    #      as it is dependent on an ansible host.
    pass

# Generated at 2022-06-11 12:33:36.947355
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.set_fact import ActionModule
    import ansible.utils.vars as utils_vars
    import ansible.playbook.play_context as play_context
    utils_vars.isidentifier = lambda x: True

    am = ActionModule(play_context.PlayContext())
    setattr(am, '_templar', lambda x: x)
    assert am.run({}).get('ansible_facts', {}) == {}

# Generated at 2022-06-11 12:33:38.232578
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.set_facts import ActionModule

    assert True

# Generated at 2022-06-11 12:33:43.977191
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Test module constructor """
    action_module = ActionModule(None, None, None)
    assert action_module._task is None
    assert action_module._connection is None
    assert action_module._play_context is None
    assert type(action_module._templar) is not None
    assert action_module._loader is None
    assert action_module._shared_loader_obj is None
    assert action_module._action is None
    assert action_module._transport is None
    assert action_module._connection_loader is None
    assert type(action_module._templar) is not None


# Generated at 2022-06-11 12:33:44.784575
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionModule)

# Generated at 2022-06-11 12:33:48.128278
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """This is a sample unit test for class ActionModule.
    It just tests the run method.
    This is not a valid unit test.
    """
    import ansible.plugins.action.set_fact as action_set_fact
    action = action_set_fact.ActionModule()
    action.run()

# Generated at 2022-06-11 12:33:51.117870
# Unit test for constructor of class ActionModule
def test_ActionModule():
	action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-11 12:35:08.061199
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule()
    m.run()

# Generated at 2022-06-11 12:35:11.352950
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m_task = MagicMock()
    m_task.args = {'cacheable': 'cacheable'}
    ActionModule(m_task, MagicMock())._task.args.pop('cacheable')
    assert 'cacheable' not in ActionModule(m_task, MagicMock())._task.args

# Generated at 2022-06-11 12:35:20.883904
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)._connection is None
    assert not ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)._task
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)._play_context is None
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)._loader is None

# Generated at 2022-06-11 12:35:30.280729
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.set_fact as ActionModule
    from ansible.module_utils.six import StringIO

    # We need to bypass the _execute_module
    TaskVars = type('TaskVars', (object,), {'_templar': None})
    ActionModule.ActionModule.TaskVars = TaskVars

    # The method run of class ActionModule

# Generated at 2022-06-11 12:35:35.964514
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor import task_result
    module = ActionModule(task_result.TaskResult('fake'))
    assert module.run({}, {}) == {}
    assert module.run({}, {}, {'k': 'v'}) == {'k': 'v'}
    assert module.run({}, {}, {'k': {'k2': 'v2'}}) == {'k': {'k2': 'v2'}}



# Generated at 2022-06-11 12:35:37.006950
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am is not None

# Generated at 2022-06-11 12:35:40.178592
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(dict(ansible_facts={}), None)
    result = action.run(tmp=None, task_vars=None)
    assert result['ansible_facts'] == {}

# Unit tests for method ActionModule of class ActionModule

# Generated at 2022-06-11 12:35:41.423794
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 12:35:42.361698
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-11 12:35:50.575422
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    import copy
    import sys
    import os
    import module_utils.basic

    #HACK: Because of how ansible runs unit tests, it needs to create the temporary
    #      Ansible module needed to be tested. These pybuild files are not in the normal
    #      python path. So add path to test directory to path so the module can be found.
    sys.path.append(os.path.join(os.path.dirname(__file__), '../../../'))

    mock_AnsibleModule = module_utils.basic.AnsibleModule
    mock_templar = module_utils.basic.AnsibleTemplar()
    mock_task = module_utils.basic.AnsibleTask()
    mock_task.action = "set_fact"

    # What we are testing
    # 1