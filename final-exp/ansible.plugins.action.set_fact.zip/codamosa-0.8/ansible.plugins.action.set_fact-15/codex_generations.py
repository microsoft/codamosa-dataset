

# Generated at 2022-06-11 12:28:44.398365
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module is not None

test_ActionModule()

# Generated at 2022-06-11 12:28:53.572950
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import BOOLEANS
    from ansible.utils.vars import isidentifier
    
    am = ActionModule()
    am.log = lambda msg: None
    am._templar = type('', (), { 'template':lambda x: x })


# Generated at 2022-06-11 12:28:55.776588
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-11 12:28:58.367777
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_ = ActionModule('test', {}, {}, C.DEFAULT_LOADER)
    assert module_._task.action == 'test'
    assert module_._task.args == {}

# Generated at 2022-06-11 12:29:01.544560
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(None, None)
    results = module.run(None, dict())
    assert 'ansible_facts' in results
    assert '_ansible_facts_cacheable' in results

# Generated at 2022-06-11 12:29:04.594278
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=dict(args=dict()), connection=dict(), play_context=dict(), loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None


# Generated at 2022-06-11 12:29:07.873803
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(None)
    action._task.args = dict(a=1, b=2, c=3)
    print (action.run())

if __name__ == "__main__":
    test_ActionModule_run()

# Generated at 2022-06-11 12:29:08.698524
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:29:09.315680
# Unit test for constructor of class ActionModule

# Generated at 2022-06-11 12:29:20.803546
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def mock_super_run(self, tmp=None, task_vars=None):
        assert tmp is None
        assert task_vars == {'test_var': 'test_value'}
        return {
            'failed': False,
            'changed': False
        }

    def mock_template(self, value):
        return value

    def mock_boolean(value, strict=False):
        return {
            'true': True,
            'false': False
        }[value]

#   Variable name must be an identifier
    action_module = ActionModule(task={'args': {'var1': 'value1', 'var2': 'value2'}})
    action_module._templar = mock_template
    action_module._templar.template = mock_template
    action_module.run = mock

# Generated at 2022-06-11 12:29:25.805919
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-11 12:29:30.118458
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Construct and test initialization of an instance of the ActionModule class
    module = ActionModule(None, None, None, None, None)

    # Check if the module is of the correct class
    assert type(module) == ActionModule

    # Check if the TRANSFERS_FILES flag is correctly set to false
    assert module.TRANSFERS_FILES == False

# Generated at 2022-06-11 12:29:41.350580
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.playbook.task_include
    import ansible.playbook.block
    import ansible.playbook.play
    import ansible.playbook.role
    import ansible.playbook.role.include

    from ansible.playbook.play_context import PlayContext

    class Host:
        name = 'test'

    class CustomTask:
        name = 'custom task'
        action = 'custom'
        args = {
            'jinja2_native': True,
            'key1': 'value1',
            'key2': 'value2',
        }

        def __init__(self, play):
            self.play = play

        def get_vars(self):
            return {}


# Generated at 2022-06-11 12:29:47.322990
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = AnsibleModule(
        argument_spec=dict()
    )
    actionmodule = ActionModule(module, task=dict(args=dict(first_key='value', second_key=True)))
    result = actionmodule.run()
    assert (result == {
        'ansible_facts': {
            'first_key': 'value',
            'second_key': True,
        },
        '_ansible_facts_cacheable': False
    })



# Generated at 2022-06-11 12:29:53.901428
# Unit test for constructor of class ActionModule
def test_ActionModule():
    running_connection = {}
    task = {'action': {'__ansible_module__': 'test_module'},
            'args': {'arg1': 'val1'}}
    new_stdin = ResultCallback()
    options = {}
    loader = DictDataLoader(dict())
    templar = Templar(loader=loader, variables={}, shared_loader_obj=loader)
    shared_loader_obj = {}
    play_context = {}
    new_action = ActionModule(task, running_connection, play_context, new_stdin, templar=templar, shared_loader_obj=shared_loader_obj)
    new_action.run(None, {})
    expected = {'ansible_facts': {'arg1': 'val1'}, '_ansible_facts_cacheable': False}


# Generated at 2022-06-11 12:29:57.888626
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args = {'foo': 'bar', 'cacheable': True}
    result = ActionModule({"args": args}).run()
    assert type(result) is dict
    assert result == {'changed': False, 'ansible_facts': {'foo': 'bar'}, '_ansible_facts_cacheable': True}

# Generated at 2022-06-11 12:29:58.516271
# Unit test for constructor of class ActionModule
def test_ActionModule():
    c = ActionModule()

# Generated at 2022-06-11 12:30:09.634615
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit test for method run of class ActionModule'''

    # Create mock object for class plugin.ActionBase
    with mock.patch('ansible.plugins.action.ActionBase') as MockActionBase:
        mockactionbase = MockActionBase.return_value
        mockactionbase.result = {}
        mockactionbase.task_vars = {}

        with mock.patch("ansible.module_utils.parsing.convert_bool.boolean") as mock_boolean:
            mock_boolean.return_value = True

            # Create mock object for class templar.Templar

# Generated at 2022-06-11 12:30:15.176106
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    host = 'foobar.example.org'
    t = Task()
    t.name = 'test_action_module'
    t.hosts = host
    t._role = None    # in the real implementation _role is assigned by the TaskInclude class
    t.action = 'assert'
    t.args = {'foo': 'bar'}

    play = Play()
    play._variable_manager = VariableManager()
    play.become = False
    play.become_method = 'sudo'
    play.become_user = 'root'

# Generated at 2022-06-11 12:30:23.953134
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up mocks
    ansible_facts = {}
    _ansible_facts_cacheable = False
    result = {}
    result['ansible_facts'] = ansible_facts
    result['_ansible_facts_cacheable'] = _ansible_facts_cacheable
    tmp = None
    task_vars = None
    _templar = {}
    _task = {}
    _task.args = {}
    action_module = ActionModule(tmp, task_vars, _templar, _task)

    # Test
    assert result == action_module.run(tmp, task_vars)



# Generated at 2022-06-11 12:30:35.921871
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, task=dict(args=dict(key1='value1')))
    print(action.run()['ansible_facts'])
    #assert action.run()['ansible_facts'] == dict(key1='value1')

# Generated at 2022-06-11 12:30:36.995180
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None,{},{})
    assert a.TRANSFERS_FILES == False

# Generated at 2022-06-11 12:30:47.993780
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils import construct_ansible_module_args
    from ansible.module_utils import first_found
    from ansible.module_utils import AnsibleModule

    import os.path
    import sys

    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins

    class MockActionModule(ActionModule):

        def run(self, tmp=None, task_vars=None):
            return super(MockActionModule, self).run(tmp, task_vars)

    def _load_module(action_module_path, required_args=None):
        if required_args is None:
            required_args = []


# Generated at 2022-06-11 12:30:53.229560
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #Setup
    args = {
        'cacheable': False,
        'test_key': 'test_value',
    }

    # Execution
    action_module = ActionModule(None, None)
    result = action_module.run(args)

    # Assertions
    assert result['ansible_facts'] == {'test_key': 'test_value'}
    assert result['_ansible_facts_cacheable'] == False


# Generated at 2022-06-11 12:31:02.474702
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from units.mock.loader import DictDataLoader
    from mock import MagicMock

    loader = DictDataLoader({})
    context = PlayContext()
    play = Play.load({}, loader=loader, variable_manager=MagicMock(), loader_class=loader.__class__)
    tqm = None
    inventory = InventoryManager(loader=loader, sources=['localhost,'])


# Generated at 2022-06-11 12:31:04.287779
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(dict(a='b'), dict(action=dict()))
    assert isinstance(action, ActionModule)

# Generated at 2022-06-11 12:31:11.919233
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    from ansible.module_utils.basic import AnsibleModule
    from ansible.plugins.action import ActionModule
    from ansible.plugins.action.set_fact import ActionModule as SetFactActionModule

    # Check that ActionModule(AnsibleModule) returns a new ActionModule
    assert not isinstance(ActionModule(AnsibleModule(argument_spec={})), SetFactActionModule), \
        "ActionModule(AnsibleModule) should return a new ActionModule"

    # Check that ActionModule(AnsibleModule) returns a new class
    assert not set(ActionModule.__bases__).issubset(set(SetFactActionModule.__bases__)), \
        "ActionModule(AnsibleModule) should return a new class"

    ###########################################################################
    # ActionModule(AnsibleModule) for Action

# Generated at 2022-06-11 12:31:19.948355
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Test the constructor
    '''
    # Test with simple params
    a = ActionModule({}, task={'args': {'name': 'ansible'}})
    assert a._task.args == {'name': 'ansible'}
    a = ActionModule({}, task={'args': None})
    assert a._task.args == {}
    a = ActionModule({}, task={'args': {'a': 1, 'b': 2}})
    assert a._task.args == {'a': 1, 'b': 2}

# Generated at 2022-06-11 12:31:21.995432
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule(None, {}, {"foo": "bar"}, [])
    assert x != None

# Generated at 2022-06-11 12:31:26.867799
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action._task is None
    assert action._connection is None
    assert action._play_context is None
    assert action._loader is None
    assert action._templar is None
    assert action._shared_loader_obj is None
    assert action._connection_info is None
    assert action._loader_path is None

# Generated at 2022-06-11 12:31:53.731039
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Temporary hack to work around AnsibleActionFail not being pickable
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.yaml.objects import AnsibleUnicode
    ansible.errors.AnsibleActionFail = lambda x, *args, **kwargs: ImmutableDict().update({'failed': True, 'msg': x})

    # Create an action module object
    module = ActionModule(dict(DEFAULT_JINJA2_NATIVE=False), ImmutableDict().update({'vars': {}}))

    # Test with correct arguments
    assert True, isinstance(module.run(None, None), ImmutableDict)

    # Test with wrong arguments
    test_exception = False

# Generated at 2022-06-11 12:31:55.396482
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert len(ActionModule.template) > 0
    assert ActionModule.template is  not None
    assert isinstance(ActionModule.template, string_types)

# Generated at 2022-06-11 12:32:06.013961
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

    ansible_facts = {}
    myconfig = {}
    myconfig['DEFAULT_JINJA2_NATIVE'] = False
    tmp = None


# Generated at 2022-06-11 12:32:11.190791
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None)
    assert am.__class__.__name__ == 'ActionModule'
    assert hasattr(am, '_play_context')
    assert hasattr(am, '_task')
    assert hasattr(am, '_loader')
    assert hasattr(am, '_templar')
    assert hasattr(am, '_shared_loader_obj')

# Generated at 2022-06-11 12:32:11.986280
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 12:32:13.941280
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None, None, None, {})
    assert isinstance(a, ActionBase)

# Generated at 2022-06-11 12:32:14.737391
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:32:23.622042
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # we have to have a task before we can do anything else
    from ansible.playbook.task import Task
    task = Task()

    # we don't really have to have a play for this test case, but let's create one
    from ansible.playbook.play import Play
    play = Play().load({}, variable_manager={}, loader=None)

    # we don't really have to have a play for this test case, but let's create one
    from ansible.playbook.play_context import PlayContext
    play_context = PlayContext()

    # Create an instance of the action plugin to test
    from ansible.plugins.action.set_facts import ActionModule as amod
    a = amod(task, play_context, play, loader=None, templar=None, shared_loader_obj=None)


# Generated at 2022-06-11 12:32:29.006926
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Fill up the object with some data
    module = ActionModule({'var': {'opts': {'a':{'a1':1}},
                                   'args': ['-m','foo','bar']}})
    # Initial test
    assert(not module.needs_tmp_path())

    # Test calls
    assert(module.run()['ansible_facts'] == {'a1': 1})

# Generated at 2022-06-11 12:32:39.130148
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.utils.vars
    import ansible.module_utils.parsing.convert_bool
    import ansible.constants
    from ansible.errors import AnsibleActionFail
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.six.moves import input
    from ansible.module_utils._text import to_bytes, to_text
    import ansible.plugins.action
    action = ansible.plugins.action.ActionModule(None, None, None, False)

    assert isinstance(action, ansible.plugins.action.ActionModule)
    assert isinstance(action.run(), dict)
    assert isinstance(action.run(None, {}), dict)
    assert isinstance(action.run(None, None), dict)


# Generated at 2022-06-11 12:33:25.260472
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''
    action = {}
    action['name'] = 'test'
    action['version'] = '1'
    action['verbosity'] = 0
    action['args'] = {}
    action['args']['var1'] = 'value'
    action['delegate_to'] = 'localhost'
    action['delegate_facts'] = False
    action['no_log'] = False
    action['run_once'] = False
    action['task_uuid'] = '123456789'
    action['task_vars'] = {}

    module = ActionModule(action)
    result = module.run(None, None)
    assert (result['ansible_facts']['var1'] == 'value')


# Generated at 2022-06-11 12:33:33.620531
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a substitute for a TaskExecutor for testing ActionModule
    class TestTaskExecutor:
        def __init__(self, task, task_vars):
            self.task = task
            self.task_vars = task_vars

    # Create a substitute for a Task instance for testing ActionModule
    class TestTask:
        def __init__(self, args):
            self.args = args
	
    # Create a substitute for a PlayContext instance for testing ActionModule
    class TestPlayContext:
        def __init__(self, new_stdin, new_stdout, new_stderr, new_stdout_capture, new_stderr_capture):
            self.stdin = new_stdin
            self.stdout = new_stdout
            self.stderr = new_stderr
           

# Generated at 2022-06-11 12:33:37.941943
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from .mock import patch, Mock
    mock_module = Mock()
    mock_module.params = {}
    mock_module.run_command.return_value = (0, '', '')
    with patch.object(ActionModule, 'run') as mock_action_module_run:
        ActionModule(mock_module, 'setup').run()
        mock_action_module_run.assert_called_once_with('setup')

# Generated at 2022-06-11 12:33:43.833676
# Unit test for constructor of class ActionModule
def test_ActionModule():
    variable_manager  = 'ansible.vars.manager.VariableManager'
    loader = 'ansible.parsing.dataloader.DataLoader'

    ansible = {
        'playbook_dir': 'dir',
        'inventory': 'hosts',
        'variable_manager': variable_manager,
        'loader': loader
    }

    # Create a task that will call the constructor of ActionModule
    task = {
        'action': {
            '__ansible_module__': 'setup',
            '__ansible_arguments__': ''
        },
        'async': 4242,
        'cacheable': True,
        'delegate_to': 'localhost',
        'delegate_facts': False,
        'vars': {}
    }

# Generated at 2022-06-11 12:33:45.849667
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' Unit test for the constructor of class ActionModule '''
    action_plugin_class = ActionModule()
    assert isinstance(action_plugin_class, ActionModule)

# Generated at 2022-06-11 12:33:46.642831
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-11 12:33:52.466021
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule({'_ansible_parsed': True, '_ansible_no_log': True, '_ansible_verbosity': 0}, {'ANSIBLE_MODULE_ARGS': {'foo': 'bar', 'cacheable': True}})
    assert action.run() == {'changed': False, 'ansible_facts': {'foo': 'bar'}, '_ansible_facts_cacheable': True}


# Generated at 2022-06-11 12:33:54.340808
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule"""
    
    # TODO: add unit tests for unit test for method run of class ActionModule

# Generated at 2022-06-11 12:34:01.171452
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

    # Constructor test - all values must be set correctly
    role_name = 'test_role'
    task_name = 'test_task'
    block_name = 'test_block'
    action_name = 'test_action'

    role = Role.load(role_name)
    task = Task.load(task_name, block=Block(block_name, role=role))
    action = ActionModule(task, action_name, {}, dynamic_module_dict=dict())

    assert action._task.name == task_name
    assert action._task.block.name == block_name
    assert action._task.block.role.name == role_name
    assert action._name

# Generated at 2022-06-11 12:34:04.320155
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_ActionModule_run.__name__ = 'test_ActionModule_run'
    # TODO: These unit tests need to be updated for the new action plugin interface
    raise NotImplementedError('Unit tests for this class are currently not supported')

# Generated at 2022-06-11 12:35:44.535604
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock object for task.args
    args = {}

    # Create an instance of ActionModule for test
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    try:
        # Try to run the _execute() method of ActionModule with no arguments. It should raise an exception
        action_module.run(tmp=None, task_vars=None)
    except AnsibleActionFail:
        # This exception is expected, so pass.
        pass
    else:
        # This exception is not expected, so fail.
        assert False, "AnsibleActionFail exception not raised"

    # Try to run the _execute() method of ActionModule with one argument. It should succeed.

# Generated at 2022-06-11 12:35:52.010867
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj_am = ActionModule()
    obj_am._task = FakeTask()
    obj_am._templar = FakeTemplar()

    # test with success case
    obj_am._task.args = {'a': '1', 'b': '2'}
    result = obj_am.run()
    assert result['ansible_facts'] == {'a':'1', 'b':'2'}

    # test with failure case
    obj_am._task.args = {'a': '1', 'b': 2}
    result = obj_am.run()
    assert result == {'failed': True, 'msg': 'The variable name \'b\' is not valid. Variables must start with a letter or underscore character, and contain only letters, numbers and underscores.'}

# Fake class for AnsibleActionFail

# Generated at 2022-06-11 12:35:54.735931
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(load_attr_module=None, task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)


# Generated at 2022-06-11 12:35:56.955074
# Unit test for constructor of class ActionModule
def test_ActionModule():
    aModule = ActionModule("test_name")
    assert aModule.__class__.__name__ == "ActionModule"
    assert aModule.TRANSFERS_FILES is False

# Generated at 2022-06-11 12:36:05.875215
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import ansible.module_utils.basic

    pytest_plugins = ["pytester"]

    def fetch_result(module_name, args, host_vars={}):
        module_args = {'_ansible_module_name': module_name, '_ansible_module_args': args}
        task_vars = {'hostvars': host_vars}
        am = ActionModule(dict(ANSIBLE_MODULE_ARGS=module_args,ANSIBLE_MODULE_NAME=module_name), task_vars=task_vars)
        res = am.run()
        return res

    # test with invalid key/value pairs
    with pytest.raises(AnsibleActionFail):
        fetch_result('assert', {'msg': 'Basic test with invalid key/value pairs'}, {})

   

# Generated at 2022-06-11 12:36:11.321976
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_mod_obj = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_mod_obj._shared_loader_obj == None
    assert action_mod_obj._connection == None
    assert action_mod_obj._templar == None
    assert action_mod_obj._loader == None
    assert action_mod_obj._play_context == None
    assert action_mod_obj._task == None


# Generated at 2022-06-11 12:36:19.283329
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule.
    """
    hostname = 'web02'
    port = 22
    user = 'root'

    # Build instance of AnsibleHost with the given parameters
    host = AnsibleHost(hostname, port, user)

    # Build instance of ActionModule with the given parameters
    module = ActionModule(host, ','.join(['{"k1":"v1"}', '{"k2":"v2"}']))

    # Call method run() of class ActionModule
    result = module.run()

    # Check that the result is as expected
    assert result == {
        'ansible_facts': {'k1': 'v1', 'k2': 'v2'},
        '_ansible_facts_cacheable': False,
        '_ansible_no_log': False
    }

# Generated at 2022-06-11 12:36:26.719379
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.set_fact import ActionModule
    from ansible.utils.vars import merge_hash
    from ansible.module_utils.facts.hardware.cpu import cpu_cpustats
    from ansible.module_utils.network.common.interfaces import get_interfaces_info
    import random
    import collections

    # We can't use the actual _load_provider_plugins() method here as we don't want to import other plug-ins
    # while running tests (and they are not required).
    ActionModule._load_provider_plugins = lambda self: {'hardware': {'cpu': 'ansible.module_utils.facts.hardware.cpu'}, 'network': {'interfaces': 'ansible.module_utils.network.common.interfaces'}}

    tmp = ''
    task_v

# Generated at 2022-06-11 12:36:35.094415
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.playbook.play_context import PlayContext

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str'),
            new=dict(required=False, type='bool'),
            age=dict(required=True, type='int'),
        ),
        supports_check_mode=True,
    )

    play_context = PlayContext()
    play_context.check_mode = False
    play_context.connection = 'local'
    play_context.remote_addr = '192.168.0.5'


# Generated at 2022-06-11 12:36:37.705236
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Constructor for ActionModule should succeed for a valid action"""

    action_name = 'set_fact'
    test_action = ActionModule(action_name)

    assert action_name == test_action.name