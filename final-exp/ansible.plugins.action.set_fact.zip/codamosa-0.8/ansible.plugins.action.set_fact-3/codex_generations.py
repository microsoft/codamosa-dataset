

# Generated at 2022-06-11 12:28:51.202014
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json

    # Instantiate class
    obj = ActionModule(None, None, load_dump=False)

    # Create a result object
    result = {
        'ansible_facts': None,
        '_ansible_facts_cacheable': None,
    }

    # Change expected values
    result['ansible_facts'] = {'foo': 'bar'}
    result['_ansible_facts_cacheable'] = False

    # Execute run method and compare results
    assert result == obj.run(tmp=None, task_vars=None)

# Generated at 2022-06-11 12:29:01.350867
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # NOTE: This test is non trivial as it touches Ansible functionality. This is not a unit test.
    # See test/integration/targets/plugin/test_action_module.yml for a more complete test.
    from ansible.plugins.action.set_fact import ActionModule
    import ansible.module_utils.basic
    from ansible.module_utils.six import PY3

    set_module_args = dict(
        foo="bar",
        one="1",
        true="true",
        false="false",
        yes="yes",
        no="no",
    )

# Generated at 2022-06-11 12:29:11.054975
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.module_utils.parsing.convert_bool import boolean

    ansible_facts = dict()
    ansible_facts['ansible_local'] = dict()
    ansible_facts['ansible_local']['facts'] = dict()
    ansible_facts['ansible_local']['facts']['fact_name'] = 'fact_value'

    ansible_play_context = dict()

    ansible_play_context['playbook_dir'] = '/home/ansible/playbook_dir'

    PlayContext = type('PlayContext', (object,), ansible_play_context)

    task_vars = dict()
    task_vars['ansible_facts'] = ansible_facts

    data = dict()
    data['ansible_facts'] = dict()

# Generated at 2022-06-11 12:29:16.973929
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am=ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    print("\nTest ActionModule: ")
    print("ActionModule=",am)


if __name__=='__main__':
    test_ActionModule()

# Generated at 2022-06-11 12:29:20.021610
# Unit test for constructor of class ActionModule
def test_ActionModule():
    res = ActionModule(
        task=dict(args=dict(key1='value1', key2=2)),
        connection=dict(host='localhost', port=22)
    )

    assert res is not None

# Generated at 2022-06-11 12:29:28.295408
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Execute test as if we are executing the following playbook:
    # - name: example playbook
    #   hosts: localhost
    #   tasks:
    #     - set_fact:
    #         fact: value
    #       run_once: True
    #   tasks:
    #     - debug:
    #         msg: "{{ item }}"
    #       with_dict: "{{ ansible_facts }}"

    # Create a mock for the class ActionModule so we can mock the execute to get more control
    class mock_ActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            pass


# Generated at 2022-06-11 12:29:33.392815
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = ActionModule()
    task._templar = Dummy_Templar()
    task._task = Dummy_Task()
    task._task.args = {'one': '1'}
    result = task.run(None, None)
    assert result['ansible_facts'] == {'one': 1}

# Test for method _templar.template

# Generated at 2022-06-11 12:29:35.166921
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None, None, None, None)


# Generated at 2022-06-11 12:29:40.975613
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        task=dict(
            args=dict(
                var1='val1',
                var2='val2',
                requires_var='val3'
            )
        )
    )
    action.validate = MagicMock()
    action.run(tmp='/tmp', task_vars=dict())

    assert action.validate.call_count == 0


# Generated at 2022-06-11 12:29:43.195326
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None)
    assert action.TRANSFERS_FILES == False


# Unit tests for run method of class ActionModule

# Generated at 2022-06-11 12:29:49.063392
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None, dict(), dict())
    m = getattr(am, 'run')
    assert m is not None

# Generated at 2022-06-11 12:29:55.363481
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    import copy

    action_args = {
        'key1': 'value1',
        'key2': 'value2'
    }

    expected_result = {
        'changed': False,
        'ansible_facts': {
            'key1': 'value1',
            'key2': 'value2'
        },
        '_ansible_facts_cacheable': False
    }

    # create action object
    action = ActionModule(None, None, None)

    # mock object for class ActionModule
    class MockActionBase(object):
        def __init__(self):
            self.task_vars = {}
            self.changed = False
            self.task = {}
            self.task['args'] = copy.deepcopy(action_args)


# Generated at 2022-06-11 12:30:02.745480
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module = ActionModule(
        task=dict(args=dict(a=1, b=2)),
        connection=None,
        play_context=dict(become_method=None, become_user=None),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    expected_ansible_facts = {'a': 1, 'b': 2}
    result = action_module.run()
    assert result['ansible_facts'] == expected_ansible_facts



# Generated at 2022-06-11 12:30:13.537078
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json
    import tempfile

    sample_module_args = {
        'the_answer': 42,
        'boolean_false': 'FALSE',
        'boolean_true': 'TRUE',
        'cached': 'nocache',
        'cacheable': 'this will be removed',
        'list': [
            'Foo',
            'Bar',
            'Baz',
        ],
    }

    expected_task_args = {
        'boolean_false': False,
        'boolean_true': True,
        'cached': 'nocache',
        'list': [
            'Foo',
            'Bar',
            'Baz',
        ],
        'the_answer': 42,
    }


# Generated at 2022-06-11 12:30:23.869281
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.playbook.play_context as play_context
    from ansible.executor.task_result import TaskResult
    from ansible.module_utils.six import StringIO

    class Object(object):
        pass

    class DummyPlayContext(object):
        def __init__(self):
            self._attributes = dict()

        def __getattribute__(self, attribute):
            if attribute in self._attributes:
                return self._attributes.get(attribute)
            return super(DummyPlayContext, self).__getattribute__(attribute)

        def from_play_context(self, play_context):
            self._attributes['become_method'] = play_context.become_method
            self._attributes['become_user'] = play_context.become_user

# Generated at 2022-06-11 12:30:28.235716
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create the class to test
    am = ActionModule(None, None)
    
    # Test __init__
    assert isinstance(am, ActionModule)

# Function that tests _get_action_args() in class ActionModule
# Raises an exception if there is an error in _get_action_args()

# Generated at 2022-06-11 12:30:29.358567
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is type(ActionModule())

# Generated at 2022-06-11 12:30:30.027785
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:30:40.726400
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.utils.template
    # test calling method run with different arguments
    result = dict()
    result['ansible_facts'] = dict()
    result['_ansible_facts_cacheable'] = False
    result['ansible_facts']['foo'] = 'bar'
    assert result['ansible_facts']['foo'] == 'bar'
    tmp = '/tmp/'
    result = dict()
    result['ansible_facts'] = dict()
    result['_ansible_facts_cacheable'] = True
    result['ansible_facts']['changed_foo'] = 'changed_bar'
    assert result['ansible_facts']['changed_foo'] == 'changed_bar'
    result = dict()
    result['ansible_facts'] = dict()

# Generated at 2022-06-11 12:30:50.127459
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_obj = ActionModule(task=dict(args=dict(name="foo", host="bar")), connection=None, play_context=dict(), loader=None, templar=None, shared_loader_obj=None)
    action_module_obj._task.args = {"foo": "bar"}
    assert not action_module_obj.run()
    assert action_module_obj.run()["ansible_facts"] == {"foo": "bar"}
    action_module_obj._task.args = {"foo": "bar", "baz": "forty two"}
    assert action_module_obj.run()["ansible_facts"] == {"baz": "forty two", "foo": "bar"}

# Generated at 2022-06-11 12:31:06.488025
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    xa = ActionModule()
    xa.runner = object()
    xa.runner._connection = object()
    xa._task = object()
    xa._task.args = {
        'cacheable': 'yes',
        'foo': 'bar',
        'baz_': 10,
    }
    xa._templar = object()
    xa._templar.template = lambda x: x
    assert xa.run() == {
        '_ansible_facts_cacheable': True,
        'ansible_facts': {
            'foo': 'bar',
            'baz_': 10,
        },
    }


# Generated at 2022-06-11 12:31:08.877614
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, _load_name='foo', play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-11 12:31:09.650859
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__name__ == 'ActionModule'

# Generated at 2022-06-11 12:31:20.588340
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Creating a AnsibleModule with Parameters
    m = AnsibleModule(
        argument_spec=dict(
            cacheable=dict(default=False, type='bool'),
            key_one=dict(type='str', default="default_value"),
            key_two=dict(type='int', default=123),
            key_three=dict(type='bool', default=True),
            invalid_key_one=dict(type='unsupported_type')
        )
    )
    # Creating an ActionModule object with the module reference as parameter
    a = ActionModule(m)

    # Define some temporary data
    tm = tempfile.NamedTemporaryFile(suffix='.retry')
    fd, tmp_path = tempfile.mkstemp()

# Generated at 2022-06-11 12:31:31.127702
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock ansible.module_utils.parsing.convert_bool.boolean that always returns True
    mock_action_base = ActionBase()
    mock_action_base._task = { 'args': {'cacheable': False, 'ansible_version': '2.6.2', 'ansible_facts': { 'nameservers': ['8.8.8.8'], 'kernel': 'Linux'}}}
    mock_action_base._templar = { 'template': lambda x: x }
    result = mock_action_base.run()
    assert result['ansible_facts']['ansible_version'] == '2.6.2'
    assert result['ansible_facts']['kernel'] == 'Linux'

# Generated at 2022-06-11 12:31:31.893187
# Unit test for constructor of class ActionModule
def test_ActionModule():

        action = ActionModule(None, None)
        assert(type(action) == ActionModule)

# Generated at 2022-06-11 12:31:41.390914
# Unit test for constructor of class ActionModule
def test_ActionModule():
    yaml = '''
- hosts: localhost
  tasks:
    - set_fact:
      cacheable: False
      not_prompt: This is a test
      uid: 1001
      gid: 1002
      prompt: "Create a new datacenter?"
      ci_job_url: 'https://jenkins.example.com/job/ci-test-production/7/'
    - debug:
        msg: "{{ ci_job_url | regex_findall('http.*/(.*)/') }}"
    '''
    hosts = [{'hostname': 'localhost', 'ansible_connection': 'local'}]

# Generated at 2022-06-11 12:31:42.468547
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-11 12:31:52.527850
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os

    module_name = 'ActionModule'

    # prep
    test_dir = os.path.join('test', 'units', 'plugins', 'action', module_name)
    sys.path.append(test_dir)
    from test_utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase, set_module_args

    # Args for test_run_with_no_key_value_pairs_provided
    args = dict(
        cacheable=False
    )
    set_module_args(args)
    module_test_case_class_instance = ModuleTestCase(module_name, test_dir)
    with module_test_case_class_instance.assertRaises(AnsibleActionFail) as exc:
        module_test_case_class_instance.run_

# Generated at 2022-06-11 12:31:57.096399
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        task={
            'action': 'set_fact',
        },
        connection=True,
        in_play_context=True,
        play_context={
            'check_mode': False,
        })

    assert action._connection is True
    assert action._play_context['check_mode'] is False
    assert action._task['action'] == 'set_fact'


# Generated at 2022-06-11 12:32:17.925779
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None, 'actionmodule_test_module', '127.0.0.1')
    assert a.action == 'actionmodule_test_module'
    assert a.transport == 'smart'
    assert a.connection == 'local'
    assert a._connection is None
    assert a.delegate_to == '127.0.0.1'

# Generated at 2022-06-11 12:32:25.467872
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.include import RoleInclude

    set_module_args(dict(
        key1="value1",
        key2="value2"
    ))

    #construct a task
    task = Task()

    #create a play
    play_context = PlayContext()
    play_context._play = RoleInclude()

    #construct a task with play
    task._play = play_context

    #construct an ActionModule
    action_module = ActionModule(task, DictModule(), DictModuleArgs())

    # test the properties of ActionModule
    assert action_module._task == task
    assert action_module._connection == DictModule()
    assert action_module._loader == None

# Generated at 2022-06-11 12:32:27.337727
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=dict(args=dict(hostname='hostname.example.com')))

# Generated at 2022-06-11 12:32:37.551503
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    class TestActionModule(ActionModule):
        def __init__(self, *args, **kwargs):
            super(TestActionModule, self).__init__(*args, **kwargs)

        def _task(self):
            return self

        def get_basedir(self):
            return self

    class TestActionModule_Task:
        def __init__(self, args):
            self.args = args

    # Test ActionModule.run() with no arguments
    action_module = TestActionModule()
    action_module._task = TestActionModule_Task(
        {})
    result = action_module.run(None, None)
    assert result == {}, "action_module.run() failed with no arguments"

    # Test ActionModule.run() with arguments
    action_module = TestActionModule()
    action_module._task

# Generated at 2022-06-11 12:32:38.162879
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-11 12:32:45.992334
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = { "a":1, "b":2 }
    b = { "d":3, "e":4 }
    c = { "e":5, "f":6 }

    assert ActionModule._merge_kv(a, b) == { "a":1, "b":2, "d":3, "e":4 }
    assert ActionModule._merge_kv(a, c) == { "a":1, "b":2, "e":5, "f":6 }
    assert ActionModule._merge_kv(a, b, c) == { "a":1, "b":2, "d":3, "e":5, "f":6 }

# Generated at 2022-06-11 12:32:48.597025
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = ActionModule.run({"tmp": None}, {"result": {}, "cacheable": False})
    # Should we raise an exception if no key/value pairs are provided?
    print(result)
    if result.get('ansible_facts') or result.get('_ansible_facts_cacheable'):
        raise Exception("ActionModule run method test failed")

# Generated at 2022-06-11 12:32:58.433282
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # pylint:disable=unused-argument
    def inner_run(task_vars=dict()):
        facts_dict = {u'my_var_1':u'val_1', u'my_var_2':u'val_1'}
        for k, v in facts_dict.items():
            if k.upper() != k:
                raise Exception("Keys in facts dictionary must be UPPERCASE")
        return facts_dict

    am = ActionModule(None, {})
    am._templar = am._templar.unwrap()
    am._task.args = {
        u'my_var_1':u'val_1',
        u'my_var_2':u'val_1'}
    am.run(task_vars=dict())
    # pylint:enable

# Generated at 2022-06-11 12:32:59.329639
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-11 12:33:03.168437
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dummy_task_t = type('dummy_task_t', (object,), dict())
    dummy_task = dummy_task_t()
    dummy_task.args = dict(a=1, b=2)
    am = ActionModule(dummy_task, dict())
    assert am.TRANSFERS_FILES == False

# Generated at 2022-06-11 12:33:44.285746
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.modules.system import set_fact
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.six import string_types

    module = set_fact.ActionModule(basic.AnsibleModule(
        argument_spec = dict(
            a = dict(type='int', required=False),
            b = dict(type='bool', required=False),
            c = dict(type='float', required=False),
            d = dict(type='str', required=False),
            e = dict(type='list', required=False),
        ),
    ))

    result = module.run(task_vars={})
    assert (result['ansible_facts']['c'] == 3.14)

# Generated at 2022-06-11 12:33:45.416028
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None)
    assert action is not None

# Generated at 2022-06-11 12:33:46.174818
# Unit test for constructor of class ActionModule
def test_ActionModule():
  am = ActionModule()
  assert(am)

# Generated at 2022-06-11 12:33:55.577301
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.ansible_release import __version__ as ansible_version
    from ansible.module_utils._text import to_text

    m = ActionModule(None, None, None, task=None)

    # test no key/value pairs provided
    try:
        m.run()
    except AnsibleActionFail as e:
        assert 'No key/value pairs provided, at least one is required for this action to succeed' in to_text(e)

    # test variable name not valid
    try:
        m.run(task_vars={}, tmp=None, args={'set1': 'value1', '2': 'value2'})
    except AnsibleActionFail as e:
        assert 'The variable name \'2\' is not valid' in to_text(e)

    # test invalid cacheable value provided

# Generated at 2022-06-11 12:34:00.337945
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule()
    a.set_loader(None)
    a._task = {
            'action': {
                '__ansible_module__': 'test'
                },
            'args': {
                'var1': 'foo',
                'var2': 'bar'
                }
            }
    assert a.run() == {'ansible_facts': {'var1': 'foo', 'var2': 'bar'}, '_ansible_facts_cacheable': False}


# Generated at 2022-06-11 12:34:02.010624
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None, None, None, None)
    assert a is not None


# Generated at 2022-06-11 12:34:10.203721
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule(None, None)

    # set task
    task = {}
    task['args'] = {}
    task['args']['myvar1'] = 'value1'
    task['args']['myvar2'] = 'value2'
    actionModule._task = task

    # set task_vars
    task_vars = {}
    task_vars['hostvars'] = {}
    actionModule._templar = {"template": lambda x: x}
    result = actionModule.run(None, task_vars)

    # check values
    assert result['ansible_facts'] == {'myvar1': 'value1', 'myvar2': 'value2'}
    assert result['_ansible_facts_cacheable'] == False

    # check invalid identifer
    task = {}
   

# Generated at 2022-06-11 12:34:20.870792
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  # Instantiate the module class to be tested
  # Module class instantiation is performed outside the test
  # to reduce execution time
  module_class = ActionModule()

  # Content of the task variables
  task_vars = {
    'ansible_facts': {},
    'ansible_check_mode':False,
    'ansible_debug':False,
    'debug_level':0,
    '_original_file':'/root/ansible-2.8.2/lib/ansible/plugins/action/raw.py',
    'action':'raw'
  }

  # Content of the ansible temporary directory
  tmpdir = {
    'msg':'Unable to create any variables with provided arguments'
  }

  # Content of the module arguments

# Generated at 2022-06-11 12:34:23.009117
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None, None, None, None, 'set_fact', None, None, None, None, None, None, None)
    assert a._templar is not None

# Generated at 2022-06-11 12:34:28.464568
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # setup
    name = 'name'
    args = None
    action = ActionModule(name, args, 'local')
    action.runner = MockRunner(None)
    action.task_vars = {
        'ansible_facts': {
            'name': 'bob',
            'surname': 'jones'
        }
    }

    # assert
    #AFAIL - no params are passed in the args.
    # assert action.run()['ansible_facts']['name'] == 'bob'
    # assert action.run()['ansible_facts']['surname'] == 'jones'


# Generated at 2022-06-11 12:36:02.528759
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from __builtin__ import setattr
    from ansible.module_utils.six import iteritems

    action_module = ActionModule()

    # setup required fields for action object
    setattr(action_module, '_task', object())

    # test run without raise exception
    task_vars = { 'test_key': 'test_value' }
    result = action_module.run(task_vars=task_vars)
    assert result['ansible_facts']['test_key'] == 'test_value'

    # test run with raise exception
    task_vars = None
    try:
        action_module.run(task_vars=task_vars)
    except AnsibleActionFail:
        pass
    else:
        raise Exception('Expected "AnsibleActionFail" exception to be raised.')

# Generated at 2022-06-11 12:36:03.628828
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None, {})
    assert a



# Generated at 2022-06-11 12:36:04.822196
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert isinstance(action, ActionBase)

# Generated at 2022-06-11 12:36:05.597452
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, "Test not implemented"

# Generated at 2022-06-11 12:36:13.492284
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys, os
    sys.path.insert(0, 'lib')
    sys.path.insert(0, os.path.join(os.getcwd(),'lib'))

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    variable_manager = VariableManager()
    loader = DataLoader()

    play_context = PlayContext()

    result = {}

    variable_manager.extra_vars = {'hostvars': {'testhost': {}}}

    task = Task()
    task._role = None
    task._role_path = os.getcwd()
    task._task.action = 'set_fact'

    module = ActionModule

# Generated at 2022-06-11 12:36:16.120114
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_args = dict(
        key1 = 'value1',
    )
    action_module = ActionModule(dict(mock_task=True, mock_args=module_args))
    action_module.run()

# Generated at 2022-06-11 12:36:23.506353
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import sys
    import inspect
    import copy
    sys.path.append(os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe()))))
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.errors import AnsibleActionFail
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping, AnsibleUnicode
    from ansible.utils.vars import isidentifier
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play

# Generated at 2022-06-11 12:36:31.322052
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_action = {
        'ANSIBLE_MODULE_ARGS': {
            'cacheable': 'False',
            'var1': 'value1',
            'var2': 'value2',
        },
    }
    mock_task = {
        'action': mock_action,
        'args': {
            'cacheable': False,
            'var1': 'value1',
            'var2': 'value2',
        },
    }
    result, object = ActionModule._execute_module(
        tmp = None,
        task_vars = None,
        args = mock_task['args'],
        persist_files = True,
        task = mock_task
    )

    assert type(result) is dict

# Generated at 2022-06-11 12:36:36.088731
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(
            name='test',
            action=dict(module='set_fact'),
            args=dict(one=1, two=2, three=3),
        ),
        connection=dict(),
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    assert module is not None

# Generated at 2022-06-11 12:36:37.222256
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None, {}, True)
    a.run(None, None)