

# Generated at 2022-06-11 12:28:55.261411
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # (pipeline, target_host, connection, task_uuid, loader, templar, shared_loader_obj)
    action = ActionModule(None, None, None, None, None, None, None)
    assert action.run({}) == {'_ansible_facts_cacheable': False, 'ansible_facts': {}}
    assert action.run({'cacheable': 'hello'}) == {'_ansible_facts_cacheable': True, 'ansible_facts': {}}
    assert action.run({'cach': 'hello'}) == {'_ansible_facts_cacheable': False, 'ansible_facts': {'cach': 'hello'}}

# Generated at 2022-06-11 12:29:05.226049
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest.mock as mock
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host
    from ansible.playbook.task import Task
    from ansible.module_utils.parsing.convert_bool import boolean

    # Create an instance of the ActionModule class
    action_module = ActionModule(mock.Mock(), mock.Mock())

    # Add data to the task_vars dictionary
    task_vars = dict()

    # Create a dictionary containing the parameters that were passed to AnsibleModule.__init__
    params = dict(
        facts=dict(
            x=1,
            y='true'
        ),
        cacheable=True
    )

    # Create an instance of the AnsibleTask class

# Generated at 2022-06-11 12:29:05.831375
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 12:29:08.558955
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a ActionModule object
    action = ActionModule()

    # Check whether required attributes exist
    assert hasattr(action, 'TRANSFERS_FILES')

# Generated at 2022-06-11 12:29:09.908049
# Unit test for constructor of class ActionModule
def test_ActionModule():
    my_module = ActionModule()
    assert my_module


# Generated at 2022-06-11 12:29:17.502363
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # rule 1:
    # if ansible_facts_cacheable key exists in result then ansible_facts key should not be empty
    d = ActionModule()
    result = dict(
        _ansible_facts_cacheable=True,
        ansible_facts={},
        changed=False
    )
    d._task.args = dict(a='a', b='b', cacheable=True)
    assert d.run(None, {}) == result



# Generated at 2022-06-11 12:29:25.028195
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Fixtures
    len_dict = 2
    mock_self = type('', (), {})()
    mock_self.run = lambda f, t: {}
    mock_self.run.__name__ = 'run'

    mock_self._task = type('', (), {})()
    mock_self._task.args = {'name': 'dag', 'age': '42'}

    mock_self._templar = type('', (), {})()
    mock_self._templar.template = lambda s: s

    # Test
    assert len(ActionModule.run(mock_self).items()) == len_dict

# Generated at 2022-06-11 12:29:28.138376
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a._templar is None
    assert a._task is None

    #def run(self, tmp=None, task_vars=None):
    b = a.run(tmp='tmp', task_vars={'test_var': 'test'})
    assert b is not None

# Generated at 2022-06-11 12:29:29.587971
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert(am.TRANSFERS_FILES == False)

# Generated at 2022-06-11 12:29:40.732547
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.vars import combine_vars

    module = ActionModule(None, None)
    module._templar.template = lambda value: value
    module._task.args = {'a': 'b'}
    module.run()

    assert isidentifier('a')
    assert not isidentifier(' ')
    assert not isidentifier('1a')
    assert not isidentifier('a-')

    module = ActionModule(None, None)
    module._templar.template = lambda value: ' '
    module._task.args = {'a': 'b'}

# Generated at 2022-06-11 12:29:51.474422
# Unit test for constructor of class ActionModule
def test_ActionModule():
    host = "localhost"
    task = {"args": {"ansible_os_family": "RedHat", "ansible_python_version": "2.7.5"}}
    tmp = "/tmp"
    task_vars = {"hostvars": {host: {}}}
    action = ActionModule(task, tmp, host, task_vars)
    assert action.args["ansible_os_family"] == "RedHat"
    assert action.args["ansible_python_version"] == "2.7.5"
    assert action.task_vars == task_vars


# Generated at 2022-06-11 12:29:54.345766
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule({'name': 'myaction', 'args': {'name': 'test','age': 28}}, {})
    facts = am.run(None,None)['ansible_facts']
    assert facts['name'] == 'test'
    assert facts['age'] == 28

# Generated at 2022-06-11 12:29:57.653982
# Unit test for constructor of class ActionModule
def test_ActionModule():
    d = {
        'name': 'add_facts',
        'args': {
            'foo': 'bar',
        },
    }
    a = ActionModule(d, None)
    assert d == a._task.args



# Generated at 2022-06-11 12:29:59.548505
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Create an ActionModule object
    am = ActionModule(Task('action_module', {}))

    assert am is None

# Generated at 2022-06-11 12:30:00.117498
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-11 12:30:11.399680
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()


# Generated at 2022-06-11 12:30:18.252098
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class ExecuteResult(object):
        def __init__(self):
            self.rc = 0
            self.stdout = ''
            self.stderr = ''

    class ModuleResult(object):
        def __init__(self):
            self.result = ExecuteResult()

    class ActionModule(object):
        def __init__(self):
            self.tmp = None

# Generated at 2022-06-11 12:30:19.758720
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None).TRANSFERS_FILES == False

# Generated at 2022-06-11 12:30:27.532388
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.facts import FactCache
    from ansible.utils.listify import listify_lookup_plugin_terms

    module_args = "a = 1"
    module = 'setup'
    action = ActionModule(dict(), load_listify=listify_lookup_plugin_terms, task_vars=dict(), tmp=None, module_args=module_args)
    assert action._task.action == module
    assert action._task.args == dict(a=1)
    assert action._action == 'setup'

# Generated at 2022-06-11 12:30:31.142445
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule({'foo': 'bar'}, {'bar': 'baz'})
    assert action.run() == {'ansible_facts': {'foo': 'bar'}, '_ansible_facts_cacheable': False}

# Generated at 2022-06-11 12:30:40.991986
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-11 12:30:41.759878
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:30:45.856444
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(action=dict(module_name='include_vars', args=dict(file='./some_vars_file.yml', cacheable=False))))
    assert not action_module.TRANSFERS_FILES

# Generated at 2022-06-11 12:30:52.584650
# Unit test for constructor of class ActionModule
def test_ActionModule():
    s = ActionModule(
        task=dict(args=dict(one=1, two=2, three=3, four=4, five=5)),
        connection=None,
        play_context=dict(basedir='/foo/bar'),
        loader=None,
        templar=None,
        shared_loader_obj=None)

    facts = s.run(tmp='/tmp', task_vars=dict())

    assert facts['ansible_facts']['two'] == 2, 'Facts not set correctly'
    assert facts['ansible_facts']['five'] == 5, 'Facts not set correctly'

# Generated at 2022-06-11 12:30:59.271800
# Unit test for constructor of class ActionModule
def test_ActionModule():
  # Simple test for constructor of class ActionModule
  action = ActionModule({}, {}, '1', '2', '3')

  assert action.task_vars == {}, "task_vars should be empty"
  assert action.tmpdir == '3', "tmpdir value should be '3'"
  assert action._task.args == {}, "args should be empty"
  assert action.task_include_variables == '2', \
    "task_include_variables value should be '2'"
  assert action._task.action == '1', "task action should be '1'"

# Generated at 2022-06-11 12:31:08.433341
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.ansible_modlib import DummyModule
    module_args = { "foo": "bar", 
                    "bool_value_true": "true", 
                    "bool_value_false": "false" }
    module_name = "DummyModule"
    tmp = None
    task_vars = {"ansible_verbosity": 0}
    actm = ActionModule(task=DummyModule(module_args=module_args, module_name=module_name),
                       connection=None,
                       play_context=None,
                       loader=None,
                       templar=None,
                       shared_loader_obj=None)

# Generated at 2022-06-11 12:31:10.257265
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # If no argument is specified, at least one is required for this action to succeed
    a = ActionModule()
    assert isinstance(a.run(), dict)

# Generated at 2022-06-11 12:31:13.608420
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase) == True
    assert ActionModule.TRANSFERS_FILES == False

    module_args = {'cacheable':False}
    am = ActionModule(None, module_args)
    assert isinstance(am, ActionModule)

# Generated at 2022-06-11 12:31:20.418393
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Unit-test class constructor of class ActionModule
    """
    am = ActionModule('test', dict(a=1), True)
    assert am._attributes['a'] == 1
    assert am._attributes['action'] == 'test'
    assert am._attributes['delegate_to'] == '127.0.0.1'
    assert am._attributes['delegate_facts'] == False

# Generated at 2022-06-11 12:31:20.730623
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-11 12:31:46.437381
# Unit test for constructor of class ActionModule
def test_ActionModule():
    
    # same as in unit test for constructor of class ActionModule
    class FakeAction(object):

        def __init__(self, data=dict()):
            self.data = data

    # same as in unit test for constructor of class ActionModule
    class FakeTask(object):

        def __init__(self, data=dict()):
            self.args = data

    # same as in unit test for constructor of class ActionModule
    class FakePlay(object):

        def __init__(self, data=dict()):
            self.options = data

    # same as in unit test for constructor of class ActionModule
    class FakePlayContext(object):

        def __init__(self, data=dict()):
            self.options = data

    # same as in unit test for constructor of class ActionModule

# Generated at 2022-06-11 12:31:47.311752
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, 'run')

# Generated at 2022-06-11 12:31:48.314643
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    return am is not None

# Generated at 2022-06-11 12:31:51.822036
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(None, None, None, None)
    assert action_module.run(None, None) == {'_ansible_facts_cacheable': None, 'ansible_facts': {}}


# Generated at 2022-06-11 12:31:59.739883
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import ansible.utils.template as template

    class TestActionModule(ActionModule):
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            super(TestActionModule, self).__init__(task, connection, play_context, loader, templar, shared_loader_obj)
            self.results = {}
            self.call_count = 0

        def v2_runner_on_ok(self, res, *args, **kwargs):
            self.results[self.call_count] = res
            self.call_count += 1


# Generated at 2022-06-11 12:32:10.273290
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import json
    import os

    # We want to run unit tests on this module without it being installed,
    # so we add the path to this module to the pythonpath.
    sys.path = [os.path.dirname(__file__)] + sys.path
 
    # We need to mock a few things before we can import and instantiate
    # our class under test.
    import ansible.module_utils
    import ansible.module_utils.basic
    import ansible.module_utils.parsing.convert_bool
    import ansible.plugins.action

    ansible.module_utils.basic.AnsibleModule = ansible.module_utils.basic.AnsibleModuleMock

    def ansible_facts_template(self, var):
        return var

    ansible.plugins.action.Action

# Generated at 2022-06-11 12:32:15.900023
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    Mod = ActionModule('some_task_name', 'some_play_context', '/some/loader', '/some/path', 'some_action_name', {})
    assert Mod.run({'some_key': 'some_value'}) == {'ansible_facts': {'some_key': 'some_value'}, '_ansible_facts_cacheable': False}

# Generated at 2022-06-11 12:32:24.275833
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    options = {'verbosity': 0}
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory, version_info=C.__version__)
    play_context = PlayContext(variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-11 12:32:29.844672
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create ActionModule instance
    module = ActionModule()

    # create incomplete task for testing
    task = {'args': {'key1': 'value1', 'key2': 'value2'}}
    try:
        module.run(task)
    except AnsibleActionFail as e:
        if "No key/value pairs provided, at least one is required for this action to succeed" not in str(e):
            raise e

# Generated at 2022-06-11 12:32:39.933847
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    class FakePlaybookExecutor(PlaybookExecutor):
        def __init__(self, *args, **kwargs):
            self.playbook = None
        def get_loader(self):
            return None
        def get_playbook(self):
            return self.playbook
    class FakePlayContext(PlayContext):
        def __init__(self):
            self.prompt = None
            self.passwords = {}
            self.become = None
            self.connection = None
            self.remote_addr = None
            self.port = None
            self.remote_user = None
            self.private

# Generated at 2022-06-11 12:33:16.616277
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None)
    assert not action._play_context.become
    assert not action.C.DEFAULT_BECOME
    assert not action.C.DEFAULT_BECOME_METHOD
    assert not action.C.DEFAULT_BECOME_USER

# Generated at 2022-06-11 12:33:18.462115
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule(None, None, None, None)
    assert isinstance(actionModule, ActionBase)

# Generated at 2022-06-11 12:33:27.690832
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager

    class MockTask(Task):
        def __init__(self):
            pass

    class MockRole(object):
        def __init__(self):
            self._task = MockTask()

    class MockPlay(object):
        def __init__(self):
            self.hosts = dict()
            self.roles = [MockRole()]

    class MockPlayContext(PlayContext):
        def __init__(self):
            pass

    class MockOptions(object):
        def __init__(self):
            self.connection = 'smart'
            self.module_path = list()
            self.forks = 10

# Generated at 2022-06-11 12:33:28.196726
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:33:36.224982
# Unit test for constructor of class ActionModule
def test_ActionModule():
  import os
  import copy
  from ansible.playbook.play_context import PlayContext
  from ansible.executor.task_result import TaskResult

  # init class
  j2_template = "{{ '90' }}"
  task_vars = {}
  play_context = PlayContext()
  new_stdin = None
  loader = None
  templar = None


# Generated at 2022-06-11 12:33:44.355048
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for method run of class ActionModule
    """

    import mock

    mock_task_vars = dict()
    mock_dict = dict()
    mock_dict['test'] = 'test'
    mock_dict['test_string'] = 'test_string'
    mock_dict['test_numeric'] = '10'
    mock_task_vars['ansible_facts'] = {}

    am = ActionModule(mock_task_vars)
    mock_task = mock.MagicMock()
    mock_task.args = mock_dict
    am._task = mock_task
    mock_templar = mock.MagicMock()
    mock_templar.template.return_value = 'test'
    am._templar = mock_templar


# Generated at 2022-06-11 12:33:53.607698
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.debug import ActionModule
    from ansible.utils.vars import AnsibleVars
    from ansible.utils.vars import AnsibleHostVars
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    play_context = PlayContext()
    play_context._task.action = dict(__name__='set_fact')
    play_context._task.args = dict(foo='bar')

    play_context.become = False
    play_context.become_method = None

# Generated at 2022-06-11 12:33:58.188098
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    action.__dict__['_task'] = {}
    action.__dict__['_task'].__dict__ = {'args': {'fact1': 'value1', 'fact2': 'value2'}}

    tmp = 'fact1=value1'
    task_vars = {}

    ret = action.run(tmp, task_vars)
    assert ret['ansible_facts'] == {'fact1': 'value1', 'fact2': 'value2'}
    assert ret['_ansible_facts_cacheable'] is False

# Generated at 2022-06-11 12:33:59.861376
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of class ActionModule
    action_module = ActionModule(None, None, None, None, None)
    assert action_module is not None

# Generated at 2022-06-11 12:34:08.408377
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule(load_fragment=lambda x: dict())

    class FakeTask(object):
        def __init__(self):
            self.args = dict(a="1", b=2)

    task_vars = dict(ansible_facts=dict(oldfact="oldvalue"))
    fake_task = FakeTask()
    # test creation of new variables and overwriting of old ones

# Generated at 2022-06-11 12:35:34.587391
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    host1 = {'hostname': 'host1'}

    # case 1: invalid variable name
    task1 = {
        'action': {
            'module': 'set_fact',
            'args': {
                'invalid_var_name%': 'This variable name is invalid'
            }
        },
        'host': host1
    }
    action1 = ActionModule(task1, dict())
    try:
        action1.run(task_vars = dict())
    except AnsibleActionFail as e:
        assert(e.exception.args[0] == "The variable name 'invalid_var_name%' is not valid. Variables must start with a letter or underscore character, and contain only letters, numbers and underscores.")
    else:
        assert(False)

    # case 2: no key/value pairs provided

# Generated at 2022-06-11 12:35:44.578783
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    import ansible.constants as C
    test_dir = os.path.join('lib', 'ansible', 'modules', 'test', 'units')
    test_src = os.path.join(C.DEFAULT_LOCAL_TMP, 'test.py')
    test_dst = os.path.join(C.DEFAULT_LOCAL_TMP, 'test.pyc')
    test_arg1 = 'arg1'
    test_arg2 = 'arg2'

    test_task = {
        'action': {
            '__ansible_module__': test_src,
        },
        'args': {
            test_arg1: test_arg1,
            test_arg2: test_arg2,
        },
    }

    test_task_vars = {}

    test

# Generated at 2022-06-11 12:35:52.038189
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule(task=dict(args={'test_key1': 'test_value1', 'test_key2': 'test_value2'}), inject=dict(task_vars={}))
    am._templar = Templar(loader=DictDataLoader(dict(test_key='test_value')))
    facts_vars = am.run()['ansible_facts']
    assert isinstance(facts_vars, dict)
    assert len(facts_vars) == 2
    assert 'test_key1' in facts_vars
    assert 'test_key2' in facts_vars
    assert facts_vars['test_key1'] == 'test_value1'
    assert facts_vars['test_key2'] == 'test_value2'


# Generated at 2022-06-11 12:36:01.615768
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    if sys.version_info[0] == 2:
        from ansible.modules.system import sysctl
        from ansible.compat.six import text_type
    else:
        from ansible.modules.system import sysctl
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.utils.vars import combine_vars

    task_args = dict(
        one=1,
        two=2,
        three=3,
    )
    module_name = sysctl.__name__
    task_vars = dict()
    tmp = None
    add_host_vars = True

# Generated at 2022-06-11 12:36:02.100748
# Unit test for constructor of class ActionModule
def test_ActionModule():

    obj = ActionModule()

# Generated at 2022-06-11 12:36:09.976788
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts import ansible_virtualization_type
    from ansible.module_utils import basic
    from ansible.plugins.action import ActionModule

    module_name = 'testmodule'
    module_args = 'test1=hello test2=world'
    module_path = 'testmodule_path'
    module_static_path = 'testmodule_static_path'

    basic._ANSIBLE_ARGS = None
    task = {
      'action': {
         '__ansible_module__': module_name,
         '__ansible_arguments__': module_args,
         '__ansible_action_module_static_path__': module_static_path,
         '__ansible_action_module_path__': module_path,
      }
    }


# Generated at 2022-06-11 12:36:18.009352
# Unit test for constructor of class ActionModule
def test_ActionModule():
    my_vars = {
        'foo': 'bar',
    }

    action = ActionModule(task=dict(action=dict(module='set_fact')), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action.run(task_vars=my_vars)

    assert 'foo' in result
    assert result['foo'] == 'bar'

    action = ActionModule(task=dict(action=dict(module='set_fact', args=dict(foo='bar'))), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action.run(task_vars=my_vars)

    assert 'foo' in result

# Generated at 2022-06-11 12:36:18.511037
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:36:19.564696
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None


# Generated at 2022-06-11 12:36:20.150839
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass