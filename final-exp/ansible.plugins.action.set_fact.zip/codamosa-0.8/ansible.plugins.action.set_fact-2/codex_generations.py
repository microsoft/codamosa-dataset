

# Generated at 2022-06-11 12:28:49.499592
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    my_env = {
        'ANSIBLE_MODULE_ARGS': {
            'key1': 'value1',
            'key2': 'value2'
        },
        'TASK_VARS': {
            'key3': 'value3',
            'key4': 'value4'
        }
    }
    my_args = dict(ANSIBLE_MODULE_ARGS=dict(key1="value1", key2='value2'))
    ansible_task = MagicMock()
    ansible_task._role = None
    task_vars = dict(key3="value3", key4='value4')
    tmp = None

    am = ActionModule(ansible_task, tmp, my_env)
    am.transfers_files = False


# Generated at 2022-06-11 12:28:59.448101
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    fake_loader = DictDataLoader({})

    fake_variable_manager = VariableManager()
    fake_inventory = Inventory(loader=fake_loader, variable_manager=fake_variable_manager, host_list='localhost')
    fake_variable_manager.set_inventory(fake_inventory)

    fake_play_context = PlayContext()

# Generated at 2022-06-11 12:29:02.112146
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(task=dict(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am is not None

# Generated at 2022-06-11 12:29:12.246429
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_modules = {
        'x': {
            'x': '1',  # <-- this is the first argument, ie. the key
            'y': '2',  # <-- this is ignored
            'z': '3',  # <-- this is ignored
        }
    }
    test_options = {
        'forks': 10,
        'become': True,
        'become_method': 'sudo',
        'become_user': 'root',
        'check': False,
        'diff': False,
    }
    test_vars = {
        'x': 'foo',
        'y': 'bar',
    }

    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)


# Generated at 2022-06-11 12:29:20.649729
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_dict={'a': 5, 'b': 7, 'c': 'test'}
    test_ansible_facts={'a': 5, 'b': 7, 'c': 'test'}
    test_ansible_facts_cacheable=True
    test_result=dict(ansible_facts=test_ansible_facts, _ansible_facts_cacheable=test_ansible_facts_cacheable)
    x = ActionModule()
    assert(x.run(None, test_dict)==test_result)
# Test for isidentifier

# Generated at 2022-06-11 12:29:28.603584
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Unit test to test if the module is producing the expected variables
    # instantiate the module class
    am = ActionModule(load_local_actions=False)

    # instantiate a task to pass to the module
    task = MockTask()

    # set args for the module
    task.args = {
        'a': '1',
        'b': '2',
        'name': 'ansible',
        'version': '2.7.0',
        'cacheable': True,
    }

    # set templates for the module
    am._templar.set_available_variables(task_vars=dict())

    # run the module
    results = am.run(tmp=None, task_vars=None)

    # validate results

# Generated at 2022-06-11 12:29:32.436781
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Instantiate module
    module = ActionModule()

    # Instantiate task
    module._task = AnsibleTask()

    # Run method and assert result
    assert module.run() == {'ansible_facts': {'_ansible_facts_cacheable': False}}



# Generated at 2022-06-11 12:29:43.515683
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # instantiate action module
    action_module_instance = ActionModule(load_args=dict())

    # set task class instance
    action_module_instance._task = lambda: None
    action_module_instance._task.args = dict()

    # set connection class instance
    action_module_instance._connection = lambda: None

    # set templar class instance
    action_module_instance._templar = lambda: None
    action_module_instance._templar.template = lambda x: x

    # set module class instance
    action_module_instance._module = lambda: None

    # set loader class instance
    action_module_instance._loader = lambda: None

    # set shared class instance
    action_module_instance._shared_loader_obj = lambda: None

    # call run method
    action_module_instance.run()

# Generated at 2022-06-11 12:29:52.076499
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 12:29:52.889247
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert 'ActionModule' == ActionModule.__name__

# Generated at 2022-06-11 12:30:07.991028
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = dict(
        name='add_host',
        args=dict(
            name='localhost',
            groups='localhost',
            port=22,
            host_group_name='localhost',
            inventory_dir='/etc/ansible/hosts',
            force_reload=False,
        ),
    )

    action_obj = ActionModule(action, dict(
        connection='local',
        tmpdir='/tmp',
    ))

    assert action_obj.action == action
    assert action_obj.connection == 'local'
    assert action_obj.tmpdir == '/tmp'
    assert action_obj.delegate_to == 'localhost'
    assert action_obj.delegate_facts == True
    assert action_obj.name == 'add_host'

# Generated at 2022-06-11 12:30:10.407496
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_loader = "loader_mock"
    actionmodule = ActionModule(mock_loader)
    assert actionmodule._loader == mock_loader

# Generated at 2022-06-11 12:30:11.351297
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: Create unit test
    pass

# Generated at 2022-06-11 12:30:18.231439
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class TestModule:
        def __init__(self, args):
            self.args = args

    class TestConnection:
        def __init__(self, module):
            self.module = module

    class TestTask:
        def __init__(self, templar, connection, args, module=None):
            self.args = args
            self.connection = connection
            self.module = module
            self.templar = templar

    class TestTemplar:
        def __init__(self, conn):
            self.connection = conn

        def template(self, content):
            return content

    class TestPlayContext:
        def __init__(self, changed, diff):
            self._changed = changed
            self._diff = diff

        def check_mode(self):
            return self._changed


# Generated at 2022-06-11 12:30:19.307889
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None, None)

# Generated at 2022-06-11 12:30:30.443849
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # creating a dummy task for test
    task = {}
    test_task = {}
    test_task['args'] = {'foo': 'bar', 'cacheable': False}
    test_task['action'] = 'set_fact'
    task['action'] = 'set_fact'
    task['args'] = {}

    # create a new ActionModule with task defined above
    action_module_test_class = ActionModule(task=task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # run a method test of run for ActionModule
    result = action_module_test_class.run(task_vars=test_task)

    # test assertion
    assert result['ansible_facts']['foo'] == 'bar'

# Generated at 2022-06-11 12:30:33.276966
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule({'name': 'test_host', 'host_type': 'test_host_type'}, 'test_task')
    assert action is not None

# Generated at 2022-06-11 12:30:39.807936
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # change this test to suit your specific class
    action = ActionModule(dict(in_options={'action': dict(name='test_name'), 'task': dict()}, in_runner_ident='test_host', in_random_ident=123456789, in_task_vars=dict(), in_loader=None, in_inventory=None, in_variable_manager=None, in_loader_cache=None))
    print(action, action.run(tmp=None, task_vars=dict()))

# Generated at 2022-06-11 12:30:40.654722
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-11 12:30:48.991166
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # create a task for testing
    class TestActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            return super(TestActionModule, self).run(tmp, task_vars)

    # mock arguments to the task
    args = dict(name=dict(key1='value1', key2='value2'))

    # init the task with mock arguments
    action_module = TestActionModule(task=dict(args=args), connection=None, play_context=dict(), loader=None, templar=None)

    # perform the work
    action_module.run()


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-11 12:31:00.771017
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule({}, {}, {}, {}, {})
    # assert
    try:
        am.run()
    except AnsibleActionFail as e:
        assert 'No key/value pairs provided, at least one is required for this action to succeed' in e.message

# Generated at 2022-06-11 12:31:02.856191
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Quick test to make sure this class can be instantiated
    action = ActionModule()
    assert action.__class__.__name__ == "ActionModule"

# Generated at 2022-06-11 12:31:07.271329
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import types
    import unittest

    class Dummy(object):
        pass

    class DummyModule(object):
        pass

    class DummyTerm(object):
        pass

    class DummyTask(object):
        pass

    class DummyPlayContext(object):
        pass

    class DummyExecutor(object):
        pass

    class DummyConnection(object):
        pass

    class DummyTemplar(object):
        def __init__(self):
            self.template = None

        def template(self, data):
            return self.template

    class TestActionModule(unittest.TestCase):
        def test_constructor(self):
            am = ActionModule(DummyModule())
            #self.assertEqual(am.CHECK_MODE_HOST_CHECK_DEFAULT, True)
            #

# Generated at 2022-06-11 12:31:08.194489
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(Task(dict()), dict())


# Generated at 2022-06-11 12:31:11.236223
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert module is not None

# Generated at 2022-06-11 12:31:12.141213
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionBase)

# Generated at 2022-06-11 12:31:23.683891
# Unit test for constructor of class ActionModule

# Generated at 2022-06-11 12:31:26.909645
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task={'args': {'user': 'bob'}}, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-11 12:31:35.152936
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from .mock import patch
    from .unit_test import AnsibleFailJson
    from .unit_test import AnsibleExitJson
    from .unit_test import ActionModule
    from .unit_test import ModuleTestCase

    class TestCase(ModuleTestCase):

        def setUp(self):
            super(TestCase, self).setUp()
            self.action = self.get_action_class()
            self.action.display.verbosity = False

        def get_action_class(self):
            class MyActionModule(ActionModule):
                def run(self, tmp=None, task_vars=None):
                    return super(MyActionModule, self).run(tmp, task_vars)
            return MyActionModule


# Generated at 2022-06-11 12:31:40.568806
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule('test', {'key': 'value'}, False, None)
    assert not mod is None
    result = mod.run(None, {})
    assert 'ansible_facts' in result
    assert '_ansible_facts_cacheable' in result
    assert result['ansible_facts']['key'] == 'value'
    assert not result['_ansible_facts_cacheable']

# Generated at 2022-06-11 12:32:01.021723
# Unit test for constructor of class ActionModule
def test_ActionModule():

    task_args = dict()
    action_module = ActionModule(load_module_spec=False, task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module.task_vars = task_args
    result = action_module.run(task_args, task_vars=task_args)

    expected_result = {
        'ansible_facts': {},
        '_ansible_facts_cacheable': False,
        '_ansible_no_log': False,
    }

    assert result == expected_result

# Generated at 2022-06-11 12:32:05.428012
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule(
        task=dict(action=dict(module_name='action', module_args='')),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert actionModule is not None

# Generated at 2022-06-11 12:32:13.610094
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = dict(
        test_key='test_value',
    )
    task = dict(
        action=dict(
            module='set_fact',
            args=dict(
                test_new_key='{{ test_key }}',
            ),
        ),
        name='task-name',
    )
    task_args = dict()
    action = ActionModule(task, task_args, task_vars)
    assert action._task.args['test_new_key'] == '{{ test_key }}'
    assert action._task._ds['action']['args']['test_new_key'] == '{{ test_key }}'

# Generated at 2022-06-11 12:32:22.944555
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.playbook.play as play
    import ansible.playbook.task as task
    import ansible.playbook.role as role
    import ansible.playbook.block as block
    import ansible.playbook.handler as handler
    import ansible.playbook.role_include as role_include
    import ansible.inventory.host as host
    import ansible.inventory.group as group
    import ansible.inventory.ini as ini
    import ansible.template as template
    import ansible.vars.manager as varmanager

    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    from ansible.utils.vars import combine_vars
    from ansible.parsing.dataloader import DataLoader

    play

# Generated at 2022-06-11 12:32:26.451791
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert 'action_' in ActionModule.__module__
    assert 'ActionModule' == ActionModule.__name__
    assert ActionModule.TRANSFERS_FILES is False
    assert dict() == ActionModule.BYPASS_HOST_LOOP


# Generated at 2022-06-11 12:32:36.810562
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Construct a mock representation of a task_vars dictionary
    task_vars = {}

    # Construct a mock representation of a AnsibleModule object
    # Note that the first argument to all method calls is the name of the method, so all calls should use the exact same name
    class AnsibleModule:
        def __init__(self, argument_spec, supports_check_mode=False, bypass_checks=False):
            pass

        def fail_json(self, msg, **kwargs):
            return dict(failed=True, msg=msg)

        def exit_json(self, **kwargs):
            return dict(**kwargs)

        def set_fact(self, k, v):
            pass

        def get_bin_path(self, arg, required=False, opt_dirs=[]):
            return None


# Generated at 2022-06-11 12:32:38.108219
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule('setup.py')
    assert action.action == 'setup.py'

# Generated at 2022-06-11 12:32:41.025287
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=dict(action=dict(module_name='set_fact', module_args=dict(foo='bar'))))
    assert action.TRANSFERS_FILES is False

# Generated at 2022-06-11 12:32:41.916796
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert type(ActionModule) == type

# Generated at 2022-06-11 12:32:50.979335
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    from ansible.module_utils.facts.system.network import NetworkCollector
    from ansible import utils

    module = ActionModule(
        task=dict(args=dict(cacheable=True)),
        connection=dict(),
        play_context=dict(become=False, become_user='root'),
        loader=utils.plugins.action_loader,
        templar=utils.plugins.template_loader,
        shared_loader_obj=None,
    )

    d = {'ansible_all_ipv4_addresses': ['172.17.0.3'], 'ansible_all_ipv6_addresses': [], 'module_setup': True}
    nc = NetworkCollector(module)
    nc.collect(d)

   

# Generated at 2022-06-11 12:33:31.108794
# Unit test for constructor of class ActionModule
def test_ActionModule():
    constructor = ActionModule(dict(ANSIBLE_MODULE_ARGS=dict(
                            randomkey1='randomvalue1',
                            randomkey2='randomvalue2',
                            randomkey3='randomvalue3'
    )))

    assert constructor._task.args['randomkey1'] == 'randomvalue1'
    assert constructor._task.args['randomkey2'] == 'randomvalue2'
    assert constructor._task.args['randomkey3'] == 'randomvalue3'

# Generated at 2022-06-11 12:33:38.822285
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys, os
    sys.path.append(os.path.join(os.path.dirname(os.path.realpath(__file__)), '../../'))

    from ansible.utils.vars import combine_vars
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.plugins.loader import action_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.display import Display

    # Initialize some variables
    connection_plugin = 'local'
    display = Display()
    dataloader = DataLoader()


# Generated at 2022-06-11 12:33:41.396635
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = dict(action=dict(module_name='set_fact', module_args=dict(cacheable='True', foo='bar')))
    action = ActionModule(task, dict())
    assert action.__class__.__name__ == 'ActionModule'

# Generated at 2022-06-11 12:33:46.704988
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # When arguments dictionary is empty, raise error
    no_argument_module = FakeActionModule('', '', '')
    no_argument_result = no_argument_module.run()
    assert no_argument_result['failed'] is True
    assert no_argument_result['ansible_facts'] is None
    assert no_argument_result['_ansible_facts_cacheable'] is None
    assert no_argument_result['msg'] == 'No key/value pairs provided, at least one is required for this action to succeed'
    
    # When arguments dictionary has more than one key pair entries, then facts are created
    has_argument_module = FakeActionModule('', '', '', 'name=test_name', 'version=test_version')
    has_argument_result = has_argument_module.run()

# Generated at 2022-06-11 12:33:56.092353
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 12:33:56.510244
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert 1 == 1

# Generated at 2022-06-11 12:33:59.932375
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    facts_dict = {'test_facts': {'test_arg1': 'test_value1',
                                 'test_arg2': 'test_value2'}}
    test_action = ActionModule(None, facts_dict)

    assert(test_action.run()['ansible_facts'] == facts_dict['test_facts'])

# Generated at 2022-06-11 12:34:08.516084
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import errors
    from ansible.module_utils.six import PY3

    from units.mock.loader import DictDataLoader
    from ansible.parsing.dataloader import DataLoader
    from units.mock.path import mock_unfrackpath_noop

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    def load_data(self, filepath):
        data = dict()
        data['action'] = 'test'
        data['test_var'] = 'test'

        return data


# Generated at 2022-06-11 12:34:18.770091
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils import basic
    import ansible.plugins.action.set_fact as set_fact

    task_vars = {
        "v1": "foo",
        "v2": "bar",
        "v3": "baz"
    }

    class TestModule(object):
        def __init__(self, task_vars):
            self.fail_json = basic.AnsibleFailJson
            self.task_vars = task_vars

    class TestActionModule(set_fact.ActionModule):
        def __init__(self, task_vars):
            super(TestActionModule, self).__init__(TestModule(task_vars))


# Generated at 2022-06-11 12:34:23.797334
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test 1: default inputs
    am = ActionModule('module.name')
    assert am._task.args == {}
    assert am._task.action == 'module.name'

    # Test 2: custom inputs
    am = ActionModule('module.name', task=dict(action='module.name', args=dict()))
    assert am._task.args == {}
    assert am._task.action == 'module.name'


# Generated at 2022-06-11 12:36:01.557180
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule._ActionBase__shared_loader_obj == None
    assert ActionModule._ActionBase__tmp_path == None
    assert ActionModule._ActionBase__remote_tmp == None
    assert ActionModule._ActionBase__connection._shell == None
    assert ActionModule._ActionBase__loader == None
    assert ActionModule._ActionBase__action_name == None
    assert ActionModule._ActionBase__action_wrapper == None
    assert ActionModule._ActionBase__connection_info == None
    assert ActionModule._ActionBase__task_vars == {}
    assert ActionModule._ActionBase__task_vars_params == {}
    assert ActionModule._ActionBase__task_vars_prompt == {}
    assert ActionModule._ActionBase__play_context == None
    assert ActionModule._ActionBase__task == None
    assert ActionModule._ActionBase__task_fields

# Generated at 2022-06-11 12:36:09.284366
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod_arg_spec = dict(
        name=dict(default=dict(), type='dict'),
        cacheable=dict(default=False, type='bool'),
    )

    def mock_task_load(self):
        self.action = 'set_fact'
        self.args = dict(name=dict(foo='bar'), cacheable=False)

    patcher = patch.object(ActionModule, '_task_load')
    patcher.start()
    ActionModule._task_load = mock_task_load
    am = ActionModule(task=dict(action='set_fact'), connection=None, play_context=dict(), loader=None, templar=None, shared_loader_obj=None)
    assert am._task.action == 'set_fact'

# Generated at 2022-06-11 12:36:17.432911
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    import tempfile

    def _test_actionmodule(expected, args):
        (fd, filename) = tempfile.mkstemp(prefix='test_actionmodule_')
        os.close(fd)
        fd = open(filename, 'w+')
        fd.write('''
- hosts: localhost
  tasks:
    - name: test
      actionmodule: ''' + args + '''
''')
        fd.close()
        try:
            actionmodule = ActionModule(None, filename, None)
            assert actionmodule.args == expected, 'test failed for args: "%s"' % args
        finally:
            os.unlink(filename)

    _test_actionmodule({'foo': 'bar', 'bar': True}, '''
foo=bar bar=true
''')
    _test

# Generated at 2022-06-11 12:36:20.857492
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=dict(args=dict(a='a', b='b', c='c')))
    assert module.run(task_vars=dict()) == {'ansible_facts': {'a': 'a', 'b': 'b', 'c': 'c'}, '_ansible_facts_cacheable': False}



# Generated at 2022-06-11 12:36:21.348269
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	pass

# Generated at 2022-06-11 12:36:29.044667
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up mocks
    task_vars = dict()
    task_vars['ansible_facts'] = dict()

    ansible_facts_cacheable = False
    ansible_facts = dict()
    ansible_facts['foo'] = 'bar'

    # Set up action
    action = ActionModule(None, None, None, None)

    # Set up action args
    action._task.args = {'cacheable': 'True', 'foo': 'bar'}

    # Call method under test
    result = action.run(tmp=None, task_vars=task_vars)

    # Assert result
    assert result
    assert result['ansible_facts'] == ansible_facts
    assert result['_ansible_facts_cacheable'] == ansible_facts_cacheable



# Generated at 2022-06-11 12:36:29.532624
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-11 12:36:32.033878
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    module = ActionModule()

    result = module.run(tmp='', task_vars=dict())

    assert result.get('ansible_facts') is None
    assert result.get('_ansible_facts_cacheable') is None

# Generated at 2022-06-11 12:36:35.976321
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    test ActionModule without parameters
    '''
    import ansible.plugins.action.set_fact as set_fact
    variables = dict()
    task = dict(args=dict())
    set_fact_action = set_fact.ActionModule(task, variables)

    assert set_fact_action is not None

# Generated at 2022-06-11 12:36:44.028623
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    action._task = {}
    action._task.args = {}
    result = action.run(tmp=None, task_vars=None)
    assert result['failed'] == True
    assert result['_ansible_verbose_always'] == True
    assert result['msg'] == 'No key/value pairs provided, at least one is required for this action to succeed'

    # Test that the method with the correct argument returns the correct result
    action._task.args = {'first': 1, 'second': 2}
    result = action.run(tmp=None, task_vars=None)
    assert result['failed'] == False
    assert result['changed'] == False
    assert result['_ansible_verbose_always'] == True
    assert result['_ansible_facts_cacheable'] == False