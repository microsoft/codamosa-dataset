

# Generated at 2022-06-11 12:28:42.857909
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 12:28:43.606953
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module

# Generated at 2022-06-11 12:28:45.558156
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert ActionModule().run() == {
        'ansible_facts': {},
        '_ansible_facts_cacheable': False,
        'changed': False,
    }

# Generated at 2022-06-11 12:28:49.410875
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule(None, dict(foo="bar", cacheable="true"))
    results = actionModule.run()

    assert (results.get('ansible_facts').get('foo') == 'bar')
    assert (results.get('ansible_facts').get('cacheable') == True)

# Generated at 2022-06-11 12:28:50.737516
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None, None)

# Generated at 2022-06-11 12:28:52.141411
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None, None)

# Generated at 2022-06-11 12:29:02.248496
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.executor.module_common import TaskResult as ActionModuleResult

    # A basic task representing the one that would be built by ansible-playbook
    task = Task()
    task._role = None
    task._ds = dict(action=dict(module='set_fact', args=dict(test='test')))

    # We mock a minimal TaskResult that would be returned by the strategy in execute_taks method
    task_result = TaskResult(host=None, task=task, return_data=ActionModuleResult(host=None, task=task, result=dict()))

    # We build an action module instance
    action_module = ActionModule

# Generated at 2022-06-11 12:29:08.604356
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action = ActionModule({'cacheable': False, 'name': 'setup'}, {'name': 'setup'}, False, False, 5)

    # Case #1: No key/value pairs provided
    try:
        args = {}
        action.run(args)
        assert False
    except AnsibleActionFail:
        pass

    # Case #2: key/value pairs provided
    args = {'k1': 'v1', 'k2': 'v2'}
    action.run(args)
    assert True

# Generated at 2022-06-11 12:29:14.260585
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    myObj = ActionModule("test_name", "test_action_plugin.py", "test_action.yml", None, None, None)
    myObj._task = {"args":{"test_key":"test_value"}}
    myObj._templar = "test_templar"
    myObj.run("test_tmp", "test_task_var")


# Generated at 2022-06-11 12:29:21.850048
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.loader
    action = ansible.plugins.loader.get('action', 'set_facts')
    assert action is not None, 'Failed to load plugin: action.set_facts'
    tmp = None
    task_vars = None
    action = action(tmp, task_vars)
    assert action is not None, 'Failed to instantiate plugin class action.set_facts'
    assert type(action) == ActionModule, 'Failed to instantiate object of plugin class action.set_facts'
    return

# Generated at 2022-06-11 12:29:36.607106
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)
    assert hasattr(ActionModule, 'run')
    assert hasattr(ActionModule, '_handle_warnings')
    assert hasattr(ActionModule, 'transport')
    assert hasattr(ActionModule, 'normalize_module_name')
    assert hasattr(ActionModule, 'get_module_path')
    assert hasattr(ActionModule, '_copy_module')
    assert hasattr(ActionModule, '_remove_tmp_path')
    assert hasattr(ActionModule, '_low_level_execute_command')
    assert hasattr(ActionModule, '_fixup_perms2')
    assert hasattr(ActionModule, '_fixup_perms')
    assert hasattr(ActionModule, '_executor_internal')

# Generated at 2022-06-11 12:29:43.563273
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task={'args': {'key': 'value'}}, connection={}, play_context={}, loader={}, templar={}, shared_loader_obj={})

    assert action.TRANSFERS_FILES is False
    assert action._task.args['key'] == 'value'
    assert action.connection == {}
    assert action._play_context == {}
    assert action._loader == {}
    assert action._templar == {}
    assert action._shared_loader_obj == {}


# Generated at 2022-06-11 12:29:46.460381
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert isinstance(m, ActionModule)


# Generated at 2022-06-11 12:29:47.711356
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, dict(ansible_facts=dict(foo='bar')))

# Generated at 2022-06-11 12:29:54.419616
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    action.set_runner(RunnerMock())
    task_vars = { 'test_variable_name': 'test_variable_value' }

    # test with no args provided
    try:
        action.run(None, task_vars)
        assert False
    except AnsibleActionFail as e:
        assert str(e) == 'No key/value pairs provided, at least one is required for this action to succeed'

    # test with one arg provided
    try:
        action.run(None, task_vars, args={ 'test_variable_name': 'test_variable_value' })
        assert False
    except AnsibleActionFail as e:
        assert str(e) == 'No key/value pairs provided, at least one is required for this action to succeed'

    # test with two args provided


# Generated at 2022-06-11 12:30:05.063062
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook import Playbook
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    play = Play().load(dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='set_fact', cacheable=False, k="v", v="y"))
        ]
    ), loader=loader, variable_manager=dict())

    tqm

# Generated at 2022-06-11 12:30:15.043464
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(dict(action='setup'), dict(connection='local', play_context=dict(vars=dict())))
    action._templar = action._loader.get_basedir()
    action.set_loader(action._loader)
    # Setup test data
    test_data = dict(
        tmp=None,
        task_vars=dict(),
    )

    # Test run() result
    expected_result = dict(
        ansible_facts=dict(
            ansible_local=dict(
                path_info=dict(
                    cwd=C.DEFAULT_LOCAL_TMP,
                    path=C.DEFAULT_LOCAL_TMP,
                )
            )
        ),
        changed=False,
    )

    result = action.run(**test_data)

# Generated at 2022-06-11 12:30:17.343385
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(
        task=dict(action=dict(module_name='set_fact', module_args=dict(key='value'))))

# Generated at 2022-06-11 12:30:27.441079
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    the_vars = dict(test_var=dict(test_key='test_value'))
    the_templar = Templar(loader=None, variables=the_vars)
    the_task = Task()
    the_task._role = None
    the_task.args = dict(first_key='first_value')
    the_variable_manager = VariableManager(loader=None, inventory=None, version_info=None)

    am = ActionModule(the_task, the_templar, the_variable_manager)
    assert am is not None
    assert isinstance(am, ActionModule)

# Generated at 2022-06-11 12:30:37.489722
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Here we test it with cacheable set to False
    # Also with no arguments, which ActionModule doesn't allow
    action = ActionModule({'cacheable': False})
    assert action.run() == {'_ansible_facts_cacheable': False, 'ansible_facts': {}}

    # Here we test it with cacheable set to True
    # Also with no arguments, which ActionModule doesn't allow
    action = ActionModule({'cacheable': True})
    assert action.run() == {'_ansible_facts_cacheable': True, 'ansible_facts': {}}

    # Here we test it with cacheable set to False and a list of keys and values
    action = ActionModule({'cacheable': False, 'a': 1, 'b': 2, 'c': 3})

# Generated at 2022-06-11 12:30:46.810778
# Unit test for constructor of class ActionModule
def test_ActionModule():
    t = ActionModule({})
    assert t is not None

# Generated at 2022-06-11 12:30:56.007120
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from collections import Mapping

    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='')

    pbex = PlaybookExecutor(playbooks='', inventory=inventory, variable_manager=variable_manager, loader=loader,
                            passwords={})

    variable_manager.set_inventory(inventory)


# Generated at 2022-06-11 12:31:05.515755
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create a test object (instance of class ActionModule)
    obj = ActionModule(task=dict(args=dict(cacheable=True)))

    # Call method run with empty arguments
    out = obj.run()

    assert out['ansible_facts'] == {}
    assert out['_ansible_facts_cacheable']
    assert out['failed']
    assert out['changed'] == False

    # Create a test object (instance of class ActionModule)
    obj = ActionModule(task=dict(args=dict(var1='value1')))

    # Call method run with empty arguments
    out = obj.run()

    assert out['ansible_facts']['var1'] == 'value1'
    assert out['_ansible_facts_cacheable']
    assert out['changed'] == True



# Generated at 2022-06-11 12:31:12.684471
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    # Create play object, playbook objects use .load instead

# Generated at 2022-06-11 12:31:20.007503
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # create mock action
    action = ActionModule({'name': "test", 'action': {'module': "set_fact"}})

    # mock the method _execute_module so we can test the action without actually running it
    action._execute_module = lambda tmp: {'test': 'results'}

    # test action module with all parameters
    result = action.run(tmp=None, task_vars=None)
    assert result == {'test': 'results'}

# Generated at 2022-06-11 12:31:22.500309
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test for instantiating a class
    my_action_module = ActionModule()
    assert isinstance(my_action_module, ActionModule)

# Generated at 2022-06-11 12:31:26.100488
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_queue_manager import TaskQueueManager

    vm = ActionModule(TaskQueueManager('/tmp'), 'ping', {'foo': 'bar'}, {}, 0, '')

    assert vm is not None

# Generated at 2022-06-11 12:31:34.742287
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    
    # some test data
    data_0=dict()

    # data_1 is when a dict of variables is given
    data_1=dict()
    data_1['ansible_facts']={"foo":"bar","bar":"foo"}
    data_1['_ansible_facts_cacheable']=True

    # data_2 is when no variables are given
    data_2=dict()
    data_2['failed']=True
    data_2['parsed']=False

    # data_0 is when no input args are given
    data_0['failed']=True
    data_0['parsed']=False
    
    # data_3 is when an non-identifier variable name is given
    data_3=dict()
    data_3['failed']=True
    data_3['parsed']

# Generated at 2022-06-11 12:31:44.803556
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager

    role_path = os.path.join(C.DEFAULT_ROLES_PATH, 'test_role')
    role_defs = {'role1': dict(name='test_role', paths=[role_path])}
    host = "testhost"
    play = Play().load('test_play',
                       None,
                       None,
                       loader=None)
    tqm = None
    play_context = PlayContext()
    var_manager = VariableManager()
    loader = DataLoader()
    display = Display()
    task = Task()
    args = {}

    test_

# Generated at 2022-06-11 12:31:46.010791
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule({})
    assert module is not None

# Generated at 2022-06-11 12:31:55.711107
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None)
    assert action is not None

# Generated at 2022-06-11 12:32:03.862524
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create an instance
    am = ActionModule()

    # test passing an empty dict as args
    task_vars = dict()

    assert am.run(task_vars) == dict(failed=True, msg="No key/value pairs provided, at least one is required for this action to succeed")

    # test passing a dict with a valid key but no value
    task_vars = dict(args_dict=dict(key1='value1'))

    assert am.run(task_vars) == dict(failed=True, msg="No key/value pairs provided, at least one is required for this action to succeed")

# Generated at 2022-06-11 12:32:04.480231
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-11 12:32:14.825193
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext  # TODO: remove dependency on PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    # Setup the context that gets the results passed to it.
    context = PlayContext()
    context._diff = False
    context._log_only = False

    # Setup the host that the results will be applied to
    host = InventoryManager(loader=None, sources=["localhost"]).get_host(host_name='localhost')

    # Setup the task results to be passed in
    task

# Generated at 2022-06-11 12:32:15.133517
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-11 12:32:23.781552
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup test data
    setattr(C, 'DEFAULT_JINJA2_NATIVE', False)
    tmp = None
    task_vars = dict(ansible_user='test_ansible_user',
                     ansible_connection='test_ansible_connection')

    task_vars['ansible_facts'] = dict(test_ansible_fact=True)
    host_vars = dict()
    result = dict()

    tmp = dict()
    tmp['args'] = dict()
    tmp['args']['test_key1'] = True
    tmp['args']['test_key2'] = False
    tmp['args']['test_key_template'] = 'test_{{ ansible_user }}'
    tmp['args']['cacheable'] = True


# Generated at 2022-06-11 12:32:24.299922
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:32:29.426655
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Constructor of ActionModule called with default arguments """
    action = ActionModule(
        task = dict(),
        connection = dict(),
        play_context = dict(),
        loader = None,
        templar = None,
        shared_loader_obj = None
    )

    assert action is not None, \
        "ActionModule constructor should have returned a valid object reference"


# Generated at 2022-06-11 12:32:39.547925
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    from ansible.module_utils.six import PY3

    # Python3 renamed dict.iteritems to dict.items
    # This is a list of all ways to get an interator for a dictionary in python
    if PY3:
        try:
            iteritems = 'items'
        except Exception:
            try:
                iteritems = 'iteritems'
            except Exception:
                try:
                    iteritems = 'viewitems'
                except:
                    iteritems = None
    else:
        iteritems = 'iteritems'

    def get_action_module(action_args=None):
        """
        Returns an instance of ActionModule()
        """
        module_loader, connection_loader, _, _ = pipeline_loader.find_plugin(pipeline, 'action', None)
        action_

# Generated at 2022-06-11 12:32:41.834748
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am is not None

# Generated at 2022-06-11 12:33:06.945198
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = dict(
        args = dict(
            a = 1,
            b = 2,
            c = 3,
        ),
    )
    def mock_load_vars(self, *args, **kwargs):
        results = dict(
            d = 'D',
        )
        return results
    def mock_template(self, template):
        results = template
        return results
    module = ActionModule(task, dict())
    module._load_vars = mock_load_vars
    module._templar.template = mock_template

# Generated at 2022-06-11 12:33:12.450428
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test args came in empty
    class TestActionModule(ActionModule):
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            self._task = task
            self._connection = connection
            self._play_context = play_context
            self._loader = loader
            self._templar = templar
            self._shared_loader_obj = shared_loader_obj

    class TestTask:
        def __init__(self, args, task_vars=None):
            self.args = args
            self.task_vars = task_vars if task_vars else {}

    class TestConnection:
        pass

    class TestPlayContext:
        pass

    class TestLoader:
        pass


# Generated at 2022-06-11 12:33:15.114671
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    # Test the constructor
    assert isinstance(am, ActionModule)
    # Test the run method
    assert am.run() == {'msg': 'Successfully executed action module.'}

# Generated at 2022-06-11 12:33:18.150204
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None, None)
    print(am)
    assert(am is not None)

# Unit test of run method of class ActionModule

# Generated at 2022-06-11 12:33:20.955637
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    task = Task()
    module = ActionModule(task, dict(a='b'))
    module.block = Block()
    return module

# Generated at 2022-06-11 12:33:25.414873
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test with empty task, notice how the defaults are used
    action = ActionModule({})
    assert action.TRANSFERS_FILES == False
    assert action._task == {}
    assert action._templar == None
    assert action._loader == None
    assert action._connection == None
    assert action._play_context == None

# Generated at 2022-06-11 12:33:29.289547
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(dict(task=dict(args=dict(a=1))))
    result = action_module.run()
    assert 'ansible_facts' in result
    assert result['ansible_facts']['a'] == 1
    assert result['_ansible_facts_cacheable'] == False



# Generated at 2022-06-11 12:33:37.265211
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor import task_executor
    from ansible.playbook.task import Task

    # Test 1: set_fact from task
    task = Task()
    task.action = 'set_fact'
    task.args['myvar'] = 'myval'
    action = task_executor.get_action_plugin(task)
    state = action.run(task_vars=dict())
    assert state['ansible_facts']['myvar'] == 'myval'
    assert state['_ansible_facts_cacheable'] is False

    # Test 2: set_fact from task with cacheable
    task = Task()
    task.action = 'set_fact'
    task.args['myvar2'] = 'myval2'
    task.args['cacheable'] = True
    action = task_exec

# Generated at 2022-06-11 12:33:37.850182
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule()

# Generated at 2022-06-11 12:33:38.404217
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:34:23.051205
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create a ansible.module_utils.facts.Facts object
    # ansible.module_utils.facts.Facts object has a attribute initialized named _cache
    # The _cache attribute was initialized to an empty dictionary
    # Create a fake ansible.module_utils.facts.Facts object
    # The fake object should be an object of class Facts
    # The internal attribute _cache of the fake Facts object
    # should be initialized to a dictionary
    fake_Facts = type('', (), {'__init__': lambda self: setattr(self, '_cache', {})})()

    # Create a mocked AnsiblePlugin
    mocked_AnsiblePlugin = type('MockedAnsiblePlugin', (),
                                {'run': lambda self, *args, **kwargs: 'MockedRunResult'})

    # Create a mocked AnsibleModule


# Generated at 2022-06-11 12:34:23.769203
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    assert action.run() == None

# Generated at 2022-06-11 12:34:32.419595
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.playbook.task
    args = dict()
    args['cacheable'] = True
    args['test'] = 'test'
    args['test_1'] = 'test_1'
    test_task = ansible.playbook.task.Task()
    test_task.action = 'set_fact'
    test_task.args = args
    am = ActionModule(task=test_task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am.run(tmp=None, task_vars=None)['_ansible_facts_cacheable']
    assert am.run(tmp=None, task_vars=None)['ansible_facts']['test'] == 'test'
    args.pop('cacheable')
    test

# Generated at 2022-06-11 12:34:34.995338
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(None, None)
    assert module.run(None, None) == {'ansible_facts': {}, '_ansible_facts_cacheable': False}


# Generated at 2022-06-11 12:34:36.360726
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: write unit tests
    pass

# Generated at 2022-06-11 12:34:44.574988
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts import ansible_local

    # GIVEN: a task that sets a variable
    task = dict(
        ansible_facts=dict(
            ansible_local=ansible_local(loader=None, templar=None)
        ),
        args=dict(
            test=True
        )
    )

    # WHEN: The method run is called
    actionModule = ActionModule(task, dict())
    result = actionModule.run(tmp='/tmp', task_vars=dict())

    # THEN: The result contains a fact with the same name as the task argument
    assert result['ansible_facts']['test'] == True

# Generated at 2022-06-11 12:34:46.116624
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule({},{})
    assert bool(x) is True

# Generated at 2022-06-11 12:34:54.477007
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.module_utils.basic
    import ansible.module_utils.parsing.convert_bool

    import sys
    import unittest

    class TestActionModule(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_run_without_args(self):
            a = ansible.module_utils.basic.AnsibleModule(
                argument_spec={},
                supports_check_mode=True,
                check_invalid_arguments=False,
                bypass_checks=True,
            )
            i = ansible.plugins.action.ActionModule(a, {}, "test")

# Generated at 2022-06-11 12:34:56.101641
# Unit test for constructor of class ActionModule
def test_ActionModule():
  action_mod = ActionModule(None, None, None, {})

# Generated at 2022-06-11 12:35:04.931976
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arrange
    class AnsibleActionFailStub(ActionBase):
        def run(self, tmp, task_vars):
            return True
    class AnsibleActionSuccessStub(ActionBase):
        def run(self, tmp, task_vars):
            return True
    class Modules:
        def __init__(self, actionfail, actionsuccess):
            self.actionfail = actionfail
            self.actionsuccess = actionsuccess
    class Plugins:
        def __init__(self, modules):
            self.modules = modules
    class Runner:
        def __init__(self, plugins):
            self.plugins = plugins

# Generated at 2022-06-11 12:36:42.152433
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test action module when 'cacheable' is set by user ,
    # when cacheable is true result['_ansible_facts_cacheable'] should also be true.
    obj = ActionModule()
    task_vars = dict()
    tmp = None

    module_args = {
        'cacheable': True
    }
    obj._task = ActionModule._task_class(dict(action=dict(module_args=module_args, module_name='setup')))
    result = obj.run(tmp, task_vars)
    assert result['_ansible_facts_cacheable'] is True


# Generated at 2022-06-11 12:36:42.640343
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-11 12:36:51.613406
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    am = ActionModule(None, dict(a=1,b=2), None)
    assert am is not None, "Failed to instantiate ActionModule"
    assert isinstance(am.action, basestring), am.action
    assert isinstance(am.module_name, basestring), am.module_name
    assert isinstance(am.task_vars, Mapping), am.task_vars
    assert isinstance(am.task_vars, dict), type(am.task_vars)
    assert isinstance(am.module_args, dict), am.module_args
    am = ActionModule(None, dict(), None)

# Generated at 2022-06-11 12:36:52.123511
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:36:58.335182
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(task=dict(args=dict(a=1, b=2, c=3)), connection=None, play_context=dict(), loader=None, templar=None, shared_loader_obj=None)
    # Test action with cacheable=False and non-templated args
    result = dict(changed=False, ansible_facts=dict(a=1, b=2, c=3), _ansible_facts_cacheable=False)
    assert action_module.run() == result
    # Test action with cacheable=True and non-templated args
    action_module._task['args']['cacheable'] = True
    result['_ansible_facts_cacheable'] = True
    assert action_module.run() == result
    # Test action with cacheable=False, non-templ

# Generated at 2022-06-11 12:37:06.749912
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 12:37:14.360182
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = AnsibleModule(
        argument_spec = dict(
            cacheable=dict(default=False, type='bool'),
            new_fact=dict(type='str')
        ),
        supports_check_mode=True
    )
    fake_task = namedtuple('_FakeTask', ['args'])
    am = ActionModule(fake_task(dict(new_fact='some_fact')), module.params)

    assert am.run() == dict(ansible_facts=dict(new_fact='some_fact'), _ansible_facts_cacheable=False)

# Generated at 2022-06-11 12:37:16.528343
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test class constructor.
    '''
    am = ActionModule('test', {}, {}, False)
    assert am._templar

# Generated at 2022-06-11 12:37:24.232500
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import context
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts
    import ansible.module_utils
    import ansible
    import sys
    import tempfile
    import json
    import os
    import sham

    context.CLIARGS = type('args', (), {'module_path': None})

    def get_collector():
        return DistributionFactCollector()

    old_get_collector = ansible.module_utils.facts.get_collector
    ansible.module

# Generated at 2022-06-11 12:37:27.048157
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(task=dict(args=dict(test=42)), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert a is not None
    assert isinstance(a, ActionModule)