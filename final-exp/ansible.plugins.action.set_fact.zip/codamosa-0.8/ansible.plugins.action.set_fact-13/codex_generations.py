

# Generated at 2022-06-11 12:28:55.563333
# Unit test for constructor of class ActionModule
def test_ActionModule():
    args = dict(
        name='/tmp/foo',
        state='absent',
        src='/tmp/foo',
        path='/tmp/bar',
        dest='/tmp/foo',
        user='nobody',
        group='nobody',
        mode='0600',
        force=False,
        link=False,
        recurse=False,
        directory=False,
        recurse_depth=None,
        remote_src=False,
        validate='checksum',
        follow=False,
        sets=None,
        try_directory=False,
        unsafe_writes=False,
    )

    # ActionModule attempts to resolve variable names using the following:
    #   - Jinja2 native (C.DEFAULT_JINJA2_NATIVE)
    #   - Jinja2 (C.DE

# Generated at 2022-06-11 12:29:05.560806
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    import os.path

    # Insert path to module into sys.path
    test_dir = os.path.dirname(os.path.abspath(__file__))
    module_path = os.path.join(test_dir, '../../../')
    sys.path.insert(0, module_path)

    # Construct class
    action_mod = ActionModule()

    # Check for class attributes
    if action_mod.DEPRECATED_PATH is not True:
        print('Expected True for ActionModule.DEPRECATED_PATH, was: %s' % action_mod.DEPRECATED_PATH)
        return False

# Generated at 2022-06-11 12:29:06.948498
# Unit test for constructor of class ActionModule
def test_ActionModule():
  action = ActionModule(None, None, None, None, None)
  assert action

# Generated at 2022-06-11 12:29:18.628505
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Constructor for class ActionModule
    """
    from ansible.plugins import action_loader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader, variable_manager, host_list=[])
    play_context = PlayContext(variable_manager=variable_manager, inventory=inventory)
    new_stdin = {}

    # Create new instance of ActionModule
    action_plugin_instance = action_loader.get('set_fact',
                                               play_context=play_context,
                                               new_stdin=new_stdin)
    assert action

# Generated at 2022-06-11 12:29:19.212985
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:29:23.866557
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor of the class
    obj = ActionModule(
        task=dict(args=dict(Foo="Bar")),
        connection=None,
        play_context=dict(remote_addr=None),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    # Check if the instance has been created
    assert obj is not None

# Generated at 2022-06-11 12:29:24.359077
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), object)

# Generated at 2022-06-11 12:29:34.012452
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(None, None)

    class M(object):
        def __init__(self):
            self.args = {}
            self.module_args = {}
            self.params = {}
            self.module_name = 'M'
            self.task = self
            self.noop_task = False
            self.delegate_to = None
            self.task_vars = {}
            self.templar = None

            self.tmp = None

        def set_tmp(self, tmp):
            self.tmp = tmp

    m = M()

    # test valid and invalid names
    try:
        action.run(m, None)
    except AnsibleActionFail as e:
        assert e.message == 'No key/value pairs provided, at least one is required for this action to succeed'


# Generated at 2022-06-11 12:29:37.049915
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(task={}, connection={}, play_context={}, loader=None, templar=None, shared_loader_obj=None)


# Generated at 2022-06-11 12:29:47.322356
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.strategy.linear import StrategyModule

    play_context = PlayContext()
    play_context.connection = 'local'
    play_context.timeout = 120
    play_context._play = None
    play_context._play_context = None

    action_module = ActionModule(play_context, play_context.connection, play_context._play, play_context._play_context, StrategyModule, None)

    with pytest.raises(AnsibleActionFail) as err:
        facts = {
            "myvar": "myval"
        }
        action_module.run(task_vars=facts)
    assert err.value.args[0] == 'No key/value pairs provided, at least one is required for this action to succeed'



# Generated at 2022-06-11 12:30:00.781734
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_task_vars = dict()
    test_task_vars['ansible_user'] = 'user'
    test_task_vars['ansible_password'] = 'pw'
    test_task_vars['ansible_port'] = '22'
    test_task_vars['ansible_ssh_private_key_file'] = 'path_to_private_key'

    test_args = dict()
    test_args['var1'] = 'val1'
    test_args['var2'] = 'val2'

    test_action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Testing the run method with success
    test_action_module._task.args = test_args


# Generated at 2022-06-11 12:30:12.027004
# Unit test for constructor of class ActionModule
def test_ActionModule():

    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.parsing.dataloader import DataLoader

    # Prepare arguments to test construct of ActionModule
    class Task(object):
        def __init__(self, args=None):
            if isinstance(args, dict):
                self.args = args
            else:
                self.args = {}

        def get_args(self):
            pass

    # Test by setting args value to True
    task = Task(args={'cacheable':True})

    class PlayContext(object):
        def __init__(self, args=None):
            if isinstance(args, dict):
                self.args = args
            else:
                self.args = {}

    pc = PlayContext(args={'become':False})


# Generated at 2022-06-11 12:30:15.032219
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    params = dict(name='test')
    task_vars = dict()
    t = ActionModule(params=params, task_vars=task_vars)
    assert t.run() == dict(ansible_facts=dict(name='test'), _ansible_facts_cacheable=False)

# Generated at 2022-06-11 12:30:17.940003
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule( {}, { 'action': 'set_fact', 'ansible_facts': {'a': 1}, 'cacheable': False } )
    assert mod._task.args['a'], 1

# Generated at 2022-06-11 12:30:22.753179
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    sys.modules['os'] = sys.modules['ansible.module_utils.basic']
    a = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    del sys.modules['os']

# Generated at 2022-06-11 12:30:24.798920
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule.run(
        ActionModule(),
        tmp=None,
        task_vars=None)

# Generated at 2022-06-11 12:30:35.290051
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleMapping, AnsibleSequence
    import os

    class MockTaskInclude(TaskInclude):
        def __init__(self):
            pass

    class MockTemplar(object):
        def __init__(self):
            pass


# Generated at 2022-06-11 12:30:40.104991
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task # import here to avoid circular import
    from ansible.playbook.play_context import PlayContext # import here to avoid circular import
    from ansible.playbook.block import Block # import here to avoid circular import

    block_1 = Block()
    block_1._parent = Task()
    play_context_1 = PlayContext()
    task_1 = Task()
    task_1._block = block_1
    task_1.action = 'setup'
    task_1.args = {'filter': 'ansible_distribution'}
    task_1.set_loader(None)
    action_module_1 = ActionModule(task_1, play_context_1, '/path/to/ansible/lib/ansible/modules/system')

# Generated at 2022-06-11 12:30:40.927177
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:30:50.217524
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os.path
    import sys
    my_dir = os.path.dirname(__file__)
    sys.path.append(os.path.join(my_dir, '../..'))
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.utils.vars import isidentifier

    def mock_task_vars_lookup_plugin(name):
        return dict()

    def mock_templar_template(value):
        return value

    class TestActionModule(ActionModule):
        def __init__(self):
            self._task = dict()
            self._task['args'] = dict()
            self._task['args']['cacheable'] = 'True'
            self._task['args']['param1'] = 'False'
            self._task

# Generated at 2022-06-11 12:31:02.217271
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Without parameters
    action_module = ActionModule(dict(action=dict(set_fact=dict())))

    # With parameters
    action_module = ActionModule(dict(action=dict(set_fact=dict(
        foo="bar",
        bam="baz"
    ))))

# Generated at 2022-06-11 12:31:10.640096
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test ActionModule.run()
    """
    class MockActionModule(ActionModule):
        """
        Mock ActionModule
        """
        def __init__(self, *args, **kwargs):
            super(MockActionModule, self).__init__(*args, **kwargs)
            self.test_vars = None

        def run(self, tmp=None, task_vars=None):
            self.test_vars = task_vars
            return super(MockActionModule, self).run(tmp=None, task_vars=task_vars)

    mock_module = MockActionModule(task=dict(args=dict(cacheable=True, var1='value1', var2='value2')))

# Generated at 2022-06-11 12:31:21.846306
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys, os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))

    print("Testing ActionModule")
    print("====================")

    am = ActionModule()
    # _task is a Task that was created by PlaybookExecutor and is passed to the ActionModule constructor by calling it
    # This Task includes a copy of the Play which is passed to the PlaybookExecutor
    #
    # Play is a class in ansible/playbook/play.py that includes the entry for the 'action' that is the name
    # of the class of the ActionModule followed by the args that were passed to the module
    #
    # Task is a class in ansible/playbook/task.py that includes a copy of the play and a variable _role
    # which is an instance

# Generated at 2022-06-11 12:31:32.106093
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Testing dynamic variable name resolution with boolean values,
    # strings and integers.
    from ansible.module_utils.parsing.convert_bool import BOOLEANS, boolean

# Generated at 2022-06-11 12:31:33.914671
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-11 12:31:36.900834
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ansible.plugins.action.ActionModule({})
    results = action.run(tmp='/tmp', task_vars={})

    assert not isinstance(results, dict)
    assert isinstance(results, dict)

# Generated at 2022-06-11 12:31:43.421330
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    target = ActionModule(load_name='test_loadname', task=dict(args=dict(cacheable=WrongType, a=WrongType, b=WrongType, c=WrongType, d=WrongType)))
    result = target.run(None, dict())
    assert result['failed']
    assert result['msg'] == 'The variable name \'WrongType\' is not valid. Variables must start with a letter or underscore character, and contain only letters, numbers and underscores.'



# Generated at 2022-06-11 12:31:46.010884
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule()
    assert 'ansible.plugins.action.set_fact' == x.__module__
    assert 'ActionModule' == x.__class__.__name__

# Generated at 2022-06-11 12:31:47.228286
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule(None, None)


# Generated at 2022-06-11 12:31:56.839998
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest

    # function code in module action.py of plugin action_plugins
    #class ActionModule(ActionBase):
    #    def run(self, tmp=None, task_vars=None):
    #        ...

    # If the test mode is enabled, then we have to monkey patch the module logger
    # of the action plugin and the action module.
    # The test module logger will be set in the fixture.
    # The module logger of action plugin and action module will be set in the fixture.
    if 'ANSIBLE_TEST_MODE' in os.environ:

        # monkey patch module logger of action plugin
        #os.environ['ANSIBLE_DEBUG'] = 'True'
        from ansible import constants as C
        from ansible.color import ANSIBLE_COLOR, stringc

# Generated at 2022-06-11 12:32:14.065306
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False


# Generated at 2022-06-11 12:32:23.199842
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # A simple method to create an __dict__ instance with the provided items
    def dictify(**kwargs): return kwargs

    # Basic class with a fake run instance method
    class FakeActionModule:
        def __init__(self, action=None, task=None, templar=None, connection=None, play_context=None, loader=None, shared_loader_obj=None, variable_manager=None):
            self.ACTION = action
            self.task = task
            self.templar = templar
            self.connection = connection
            self.play_context = play_context
            self.loader = loader
            self.shared_loader_obj = shared_loader_obj
            self.variable_manager = variable_manager

        def run(self, tmp=None, task_vars=None): return


# Generated at 2022-06-11 12:32:33.584780
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible import play
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import action_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    import ansible.constants as C
    import ansible.utils.display as display
   

# Generated at 2022-06-11 12:32:41.328093
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    m = ActionModule(dict(), 'blah',
                dict(ansible_included_var_files=['/path/to/vars'], ansible_included_var_file='/path/to/vars'),
                'fakehost', 'blah', 'fakeplaybook')

    # TODO: This test is incomplete (because the run does not implement everything yet) and should be completed

    assert m is not None

    assert m._task.args == dict(ansible_included_var_files=['/path/to/vars'], ansible_included_var_file='/path/to/vars')


# Generated at 2022-06-11 12:32:41.878399
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(ActionModule)

# Generated at 2022-06-11 12:32:47.242382
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_task = dict(args=dict(a=1, b=2, c=3))
    test_templar = 'templar'
    am = ActionModule(test_templar, test_task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am.args == test_task['args']
    assert am.task == test_task
    assert am._templar == test_templar

# Generated at 2022-06-11 12:32:51.943862
# Unit test for constructor of class ActionModule
def test_ActionModule():
    data = dict()
    data['action_plugin_path'] = '/path/to/plugins'
    data['action_plugin_name'] = 'action_plugin'
    data['action_plugin_class'] = 'ActionModule'
    data['action_plugin_args'] = dict()
    data['action_plugin_args']['action_name'] = 'action_plugin'
    data['action_plugin_args']['task_name'] = 'task_name'
    data['action_plugin_args']['task_args'] = dict()
    data['action_plugin_args']['task_args']['arg1'] = 'value1'
    data['action_plugin_args']['task_args']['arg2'] = 'value2'
    action_plugin = ActionModule(data)
    assert action_plugin

# Generated at 2022-06-11 12:32:52.942283
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert bool(ActionModule) is True

# Generated at 2022-06-11 12:32:54.433250
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# vim: set sw=4 ts=4 expandtab:

# Generated at 2022-06-11 12:32:56.009479
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    #
    # Unit test for run method of class ActionModule
    #
    pass

# Generated at 2022-06-11 12:33:38.707373
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import isidentifier
    import ansible.constants as C
    import time

    module_args = {'a': 'b', 'cacheable': True}
    task = Task()
    task.action = 'set_fact'
    task.args = module_args
    task.name = 'set_fact test'
    task.tags = []
    task.curdir = '.'

    play_context = PlayContext()
   

# Generated at 2022-06-11 12:33:46.209994
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # unit tests for module action
    import ansible.plugins.action.set_fact

    module = ansible.plugins.action.set_fact.ActionModule(None, dict(foo='bar'), None, None)
    # Check module.run()
    result = module._execute_module(dict(foo='bar'), 'fake_task', 1)
    assert result == dict(ansible_facts=dict(foo='bar'), _ansible_facts_cacheable=True)

    module = ansible.plugins.action.set_fact.ActionModule(None, dict(one=1, two=2, three=3), None, None)
    # Check module.run()
    result = module._execute_module(dict(one=1, two=2, three=3), 'fake_task', 1)

# Generated at 2022-06-11 12:33:55.613546
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    t = Task()
    tqm = None
    h = HostVars(inventory=None, host_name='testhost')
    v = VariableManager(loader=None, inventory=None)
    u = UnsafeProxy({}, hostvars=h)
    a = ActionModule(t, tqm, u, v)

    # Put in some facts
    a._task.args = {'fact1': 'value1', 'fact2': 'value2'}
    assert a._task.args == {'fact1': 'value1', 'fact2': 'value2'}

    t

# Generated at 2022-06-11 12:33:56.274251
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionBase)

# Generated at 2022-06-11 12:33:59.718891
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Tests for action.ActionModule and action.Module
    """
    module = ActionModule(task={"args": {"a": "b"}}, connection={"host": "c"})
    assert module._task.args['a'] == "b"
    assert module._connection.host == "c"
    assert module._task.action == "set_fact"

# Generated at 2022-06-11 12:34:00.478599
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-11 12:34:01.489533
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict())

# Generated at 2022-06-11 12:34:09.844175
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json
    import sys
    import os
    import tempfile

    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # create a temp file vault secret
    tfv = tempfile.NamedTemporaryFile()
    tfv.write(b'testing')
    tfv.flush()

    # create a vault secret
    vault_secret = VaultSecret(b'testing', tfv.name)
    vault_secrets = [vault_secret]

    # create a vault password
    vault_password = VaultSecret(b'testing')
    vault_passwords = [vault_password]

    test_actionmodule = ActionModule

# Generated at 2022-06-11 12:34:13.020323
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # pass an empty dict because of the templar/variable stuff
    am = ActionModule({})
    assert (type(am) == ActionModule)


# Generated at 2022-06-11 12:34:19.752813
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import unittest
    from ansible.plugins.loader import action_loader

    my_task = action_loader._create_task_from_action('set_fact',{'key': 'value'})
    module = my_task.action
    assert module._task == my_task
    assert module.name == 'set_fact'
    assert module.short_description == 'set host facts from a task'
    assert module.TRANSFERS_FILES == False
    assert module.VALID_ARGS == []
    assert module.run({}, {})

# Generated at 2022-06-11 12:35:56.250381
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class Task():
        def __init__(self):
            self.args = dict()
            self.action = 'setup'
    class Play_Context():
        def __init__(self):
            self.become = False
            self.become_method = None
            self.become_user = None

    a = ActionModule(Task(), Play_Context())
    if a is not None:
        print("ActionModule OK")

# Generated at 2022-06-11 12:36:01.003773
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    y = {
      'changed': False,
      'failures': [
        'No key/value pairs provided, at least one is required for this action to succeed'
      ]
    }

    test = ActionModule()
    test.setup_task({})
    res = test.run()
    assert (res == y)


# Generated at 2022-06-11 12:36:08.754689
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = {
        'args': {
        },
        'delegate_to': 'localhost',
        'name': 'set',
        'register': 'somevar',
    }

    am = ActionModule(None, action, None, None)
    assert not hasattr(am, 'module_name')
    assert hasattr(am, '_task')
    assert hasattr(am, '_connection')
    assert hasattr(am, '_play_context')
    assert hasattr(am, '_loader')
    assert hasattr(am, '_templar')
    assert hasattr(am, '_shared_loader_obj')
    assert hasattr(am, '_task_vars')
    assert hasattr(am, '_templar')
    assert hasattr(am, '_tmp')

    a = am

# Generated at 2022-06-11 12:36:10.257788
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None, {})
    assert action_module is not None

# Generated at 2022-06-11 12:36:18.255689
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.cache import setup_facts_cache_definitions

    module_name = 'set_fact'

    # Dummy class for module
    class DummyModule:
        class DummyConnection:
            def __init__(self):
                self.connection = None
        connection = DummyConnection()

    # Create dummy module object
    module = DummyModule()
    module.params = {'cacheable': False}

    # Create a fake task, since this is what we normally get
    class DummyTask:
        def __init__(self):
            self.args = {'a': 1, 'b': 2}
    task = DummyTask()

    # Create a fake play context
    class DummyPlayContext:
        def __init__(self):
            self.connection = 'local'
            self

# Generated at 2022-06-11 12:36:25.665185
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Test case for method run of class ActionModule """
    action_module = ActionModule()
    # Input parameters
    task_vars = {}
    action_module._task.args = {}
    # expected result

# Generated at 2022-06-11 12:36:26.413786
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Test ActionModule_run not implemented")

# Generated at 2022-06-11 12:36:27.931493
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None, None, None)
    assert action_module

# Generated at 2022-06-11 12:36:29.699853
# Unit test for constructor of class ActionModule
def test_ActionModule():
   action = ActionModule(None, None, None, None, None, None)
   print('Successfully instantiated ActionModule!')


# Generated at 2022-06-11 12:36:31.086117
# Unit test for constructor of class ActionModule
def test_ActionModule():

    from ansible.plugins.action.set_fact import ActionModule as set_fact_module

    set_fact_module()