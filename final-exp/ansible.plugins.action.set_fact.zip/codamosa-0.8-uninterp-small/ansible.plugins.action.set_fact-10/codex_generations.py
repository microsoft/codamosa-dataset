

# Generated at 2022-06-25 07:31:20.609497
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = None
    set_0 = {bool_0, bool_0, bool_0}
    bool_1 = False
    list_0 = None
    int_0 = None
    action_module_0 = ActionModule(bool_0, set_0, bool_1, bool_0, list_0, int_0)


# Generated at 2022-06-25 07:31:23.028430
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = test_case_0()
    test_case_0 = None
    assert action_module_0 != test_case_0

# Generated at 2022-06-25 07:31:30.919889
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = None
    set_0 = {bool_0, bool_0, bool_0}
    bool_1 = False
    list_0 = None
    int_0 = None
    action_module_0 = ActionModule(bool_0, set_0, bool_1, bool_0, list_0, int_0)


# Generated at 2022-06-25 07:31:31.771155
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:31:35.264583
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = None
    set_0 = {bool_0, bool_0, bool_0}
    bool_1 = False
    list_0 = None
    int_0 = None
    action_module_0 = ActionModule(bool_0, set_0, bool_1, bool_0, list_0, int_0)


# Generated at 2022-06-25 07:31:42.386127
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = None
    set_0 = {bool_0, bool_0, bool_0}
    bool_1 = False
    list_0 = None
    int_0 = None
    action_module_0 = ActionModule(bool_0, set_0, bool_1, bool_0, list_0, int_0)

    # Parameters
    task_vars = {}

    # Call the run method
    result = action_module_0.run(None, task_vars)

    # Test the result
    assert result['ansible_facts'] == {}

# Generated at 2022-06-25 07:31:47.109679
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    set_0 = {'UTF-8', 'BINARY'}
    bool_1 = None
    bool_2 = True
    list_0 = []
    int_0 = 0
    action_module_0 = ActionModule(bool_1, set_0, bool_0, bool_2, list_0, int_0)
    action_module_0.run()
    # Run method in class ActionModule was not detected

# Generated at 2022-06-25 07:31:54.152563
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # No inputs
    set_0 = {False, True, True, True}
    list_0 = None
    int_0 = True
    action_module_0 = ActionModule(False, set_0, True, True, list_0, int_0)
    dict_0 = dict()

    # Invoke method
    result = action_module_0.run(dict_0, dict_0)

    # Check for correct result
    assert result == dict()

# Generated at 2022-06-25 07:31:56.419398
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print ('Testing constructor of class ActionModule')
    test_case_0()

if __name__ == '__main__':
    print ('Testing the module')
    test_ActionModule()

# Generated at 2022-06-25 07:32:02.162210
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = None
    set_0 = {bool_0, bool_0, bool_0}
    bool_1 = False
    list_0 = None
    int_0 = None
    action_module_0 = ActionModule(bool_0, set_0, bool_1, bool_0, list_0, int_0)
    tmp_0 = None
    task_vars_0 = dict()
    dict_0 = action_module_0.run(tmp_0, task_vars_0)
    assert False

# Generated at 2022-06-25 07:32:16.713755
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None

    # run the test with no arguments and assert that it raises the appropriate exceptions
    try:
        var_0 = ActionModule().run()
    except:
        pass

    assert_type_mismatch(var_0, 'AnsibleActionFail')

    # run the test with no arguments and assert that it raises the appropriate exceptions
    try:
        var_1 = ActionModule.run()
    except:
        pass

    assert_type_mismatch(var_1, 'AnsibleActionFail')

    # run the test with no arguments and assert that it raises the appropriate exceptions

# Generated at 2022-06-25 07:32:19.275229
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case = ActionModule(task=test_case_0(), connection=test_case_0(), play_context=test_case_0(), loader=test_case_0(), templar=test_case_0(), shared_loader_obj=test_case_0())
    test_case.TRANSFERS_FILES = False


# Generated at 2022-06-25 07:32:25.841986
# Unit test for constructor of class ActionModule
def test_ActionModule():
    d = dict()
    tmp = None
    task_vars = None
    module_stdin_path = None
    module_name = 'register'
    args = None
    task_vars = dict()
    tmp = None
    am = ActionModule(d, module_stdin_path, module_name, args, task_vars, tmp)
    assert am.tmp == tmp, "Failed to create ActionModule"


# Generated at 2022-06-25 07:32:32.028541
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Note: The following code uses the same variables as defined in the test template
    var_0 = None
    # A test for valgrind ./system/lib/lib64/an_action_module.so --leak-check=full --track-origins=yes --suppressions=./system/lib/lib64/an_action_module.supp --error-exitcode=1 ./system/lib/lib64/an_action_module.so ./test/test_ActionModule.py
    test_case_0()

# Generated at 2022-06-25 07:32:32.563280
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False


# Generated at 2022-06-25 07:32:37.025792
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = ActionModule(var_0)
    var_2 = ActionModule(var_0)
    var_3 = ActionModule(var_0)

    var_4 = ActionModule(var_3)
    var_5 = ActionModule(var_3)
    var_6 = ActionModule(var_3)

    var_7 = ActionModule(var_6)
    var_6 = var_6
    var_7 = var_7
    var_8 = ActionModule(var_7)
    var_9 = ActionModule(var_8)
    var_10 = ActionModule(var_9)
    var_11 = ActionModule(var_10)
    var_12 = ActionModule(var_11)
    var_13 = ActionModule(var_12)

# Generated at 2022-06-25 07:32:40.787735
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule()
    var_1 = None
    var_2 = None
    var_2 = var_0.run(var_1)
    assert var_2 is None, var_2


# Generated at 2022-06-25 07:32:42.022299
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing ActionModule")
    assert(isinstance(ActionModule(), ActionModule))


# Generated at 2022-06-25 07:32:44.158662
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test empty constructor
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None


# Generated at 2022-06-25 07:32:48.538287
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create an instance of the class
    A = ActionModule()
    # call run()
    A.run()

# Generated at 2022-06-25 07:32:55.545029
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass



# Generated at 2022-06-25 07:33:02.705784
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # case 0
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0]
    float_0 = -1985.665
    set_0 = {bool_0}
    action_module_0 = ActionModule(bool_0, list_0, float_0, list_0, set_0, list_0)
    action_module_0.run()


# Generated at 2022-06-25 07:33:03.871957
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:33:11.636331
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # See if a provided key/value pair is set as host fact
    var_0 = dict()
    var_0['set_fact'] = dict()
    var_0['set_fact']['one'] = 2
    tmp = None
    task_vars = dict()
    res = run(tmp, task_vars)
    assert res['ansible_facts']['one'] == 2
    assert res['_ansible_facts_cacheable'] == False


# Generated at 2022-06-25 07:33:17.168328
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0]
    float_0 = -1985.665
    set_0 = set()
    action_module_0 = ActionModule(bool_0, list_0, float_0, list_0, set_0, list_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:33:25.558340
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0]
    float_0 = -1985.665
    set_0 = {bool_0}
    action_module_0 = ActionModule(bool_0, list_0, float_0, list_0, set_0, list_0)

    # Invocation
    var_0 = action_module_0.run()

    # Verification
    assert type(var_0) == dict


if __name__ == '__mai__':
    test_case_0()

# Generated at 2022-06-25 07:33:26.057476
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-25 07:33:36.578735
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule(bool_0, list_0, float_0, list_0, set_0, list_0)
    assert action_module_1.module == 'set_fact'
    assert action_module_1.module_name == 'set_fact'
    assert action_module_1.module_args == {}
    assert action_module_1.module_lang == 'C'
    assert action_module_1.module_style == 'old'
    assert action_module_1.no_log == bool_0
    assert action_module_1.async_jid == float_0
    assert action_module_1.async_seconds == list_0
    assert action_module_1.async_poll_interval == list_0
    assert action_module_1.async_status_

# Generated at 2022-06-25 07:33:44.348514
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0]
    float_0 = -1985.665
    set_0 = {bool_0}
    action_module_0 = ActionModule(bool_0, list_0, float_0, list_0, set_0, list_0)
    assert isinstance(action_module_0, ActionModule)
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0]
    float_0 = -1985.665
    set_0 = {bool_0}
    action_module_0 = ActionModule(bool_0, list_0, float_0, list_0, set_0, list_0)
    # test if @classmethod run from class ActionModule calls super.run from class ActionBase

# Generated at 2022-06-25 07:33:46.575821
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:33:59.781038
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_1 = False
    list_1 = [bool_1, bool_1, bool_1]
    float_1 = -24.132
    set_1 = {bool_1, bool_1}
    action_module_1 = ActionModule(bool_1, list_1, float_1, list_1, set_1, list_1)
    var_1 = action_module_1.run()
    assert( var_1 == {} )

# Generated at 2022-06-25 07:34:05.887659
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0]
    float_0 = -1985.665
    set_0 = {bool_0}
    action_module_0 = ActionModule(bool_0, list_0, float_0, list_0, set_0, list_0)

# Generated at 2022-06-25 07:34:07.860436
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()


# Generated at 2022-06-25 07:34:09.807491
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(dict(), dict())
    ansible_facts = None
    assert ansible_facts == action_module_0.run()

# Generated at 2022-06-25 07:34:16.249542
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_1 = True
    bool_2 = False
    str_1 = 'cd'
    bool_3 = True
    list_1 = [bool_1, bool_1, bool_1]
    float_1 = -1702.625
    list_2 = [bool_2, bool_3, str_1]
    set_1 = {bool_1}
    list_3 = [bool_3, bool_3, bool_2]
    action_module_1 = ActionModule(bool_1, list_1, float_1, list_2, set_1, list_3)
    assert action_module_1._connection == bool_1
    assert action_module_1._task_vars == list_1
    assert action_module_1._loader == float_1
    assert action_module_1._templ

# Generated at 2022-06-25 07:34:21.251109
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    list_0 = [bool_0]
    float_0 = -878.7
    set_0 = {bool_0}
    action_module_0 = ActionModule(bool_0, list_0, float_0, list_0, set_0, list_0)
    assert (action_module_0._task.action == 'set_fact')
    assert (action_module_0._task.args['a'] == '{{a}}')
    assert (action_module_0._task.args['b'] == '{{b}}')


# Generated at 2022-06-25 07:34:25.761160
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0]
    float_0 = -1985.665
    set_0 = {bool_0}
    action_module_0 = ActionModule(bool_0, list_0, float_0, list_0, set_0, list_0)


# Generated at 2022-06-25 07:34:31.134406
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0]
    float_0 = -1985.665
    set_0 = {bool_0}
    action_module_0 = ActionModule(bool_0, list_0, float_0, list_0, set_0, list_0)
    assert action_module_0.task.action == 'set_fact'
    assert action_module_0.transfers_files == False

# Generated at 2022-06-25 07:34:34.962201
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    if action_module_0.default_vars is None:
        print("Failed in constructor of class: ActionModule")
        return False
    return True


# Generated at 2022-06-25 07:34:38.009400
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:35:06.001510
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = dict()
    dict_0['test'] = 'test'
    dict_0['test1'] = 'test1'
    dict_0['test2'] = 'test2'
    dict_0['test3'] = 'test3'
    dict_0['test4'] = 'test4'
    dict_0['test5'] = 'test5'
    dict_0['test6'] = 'test6'
    dict_0['test7'] = 'test7'
    dict_0['test8'] = 'test8'
    dict_0['test9'] = 'test9'
    list_0 = [dict_0, dict_0]
    set_0 = {dict_0}

# Generated at 2022-06-25 07:35:11.884705
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0]
    float_0 = -1985.665
    set_0 = {bool_0}
    action_module_0 = ActionModule(bool_0, list_0, float_0, list_0, set_0, list_0)
    dict_0 = dict()
    dict_1 = dict()
    dict_0.update(dict_1)
    any_0 = action_module_0.run(dict_0)
    # {'_ansible_facts_cacheable': False, 'ansible_facts': {}}
    # {'_ansible_facts_cacheable': False, 'ansible_facts': {}}


if __name__ == "__main__":
    test_ActionModule_run()

# Generated at 2022-06-25 07:35:23.027180
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0]
    float_0 = -1985.665
    set_0 = {bool_0}
    action_module_0 = ActionModule(bool_0, list_0, float_0, list_0, set_0, list_0)
    bool_0 = action_module_0.tqm
    # assert bool_0 ==
    list_0 = action_module_0.loader
    # assert list_0 ==
    float_0 = action_module_0.variable_manager
    # assert float_0 ==
    list_0 = action_module_0.inventory
    # assert list_0 ==
    set_0 = action_module_0.playbook
    # assert set_0 ==
    list_0 = action_

# Generated at 2022-06-25 07:35:24.928649
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:35:30.156124
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0]
    float_0 = -1985.665
    set_0 = {bool_0}
    action_module_0 = ActionModule(bool_0, list_0, float_0, list_0, set_0, list_0)
    var_0 = action_run(tmp=None, task_vars=None)
    return

# Generated at 2022-06-25 07:35:35.541175
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0]
    float_0 = -1985.665
    set_0 = {bool_0}
    action_module_0 = ActionModule(bool_0, list_0, float_0, list_0, set_0, list_0)


# Generated at 2022-06-25 07:35:40.490476
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    list_0 = [False, False, False]
    float_0 = -0.0426906
    set_0 = set([1, 2, 3, 4, 5])
    action_module_0 = ActionModule(bool_0, list_0, float_0, list_0, set_0, list_0)
    var_0 = action_module_0.run()
    return var_0

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:35:40.864300
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-25 07:35:42.186198
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print()



# Generated at 2022-06-25 07:35:48.628224
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_id = True
    int_id = 1
    float_id = 1.0
    list_id = []
    set_id = {}
    str_id = ""
    obj_id = ActionModule(bool_id, int_id, float_id, list_id, set_id, str_id)
    for item in obj_id.hostvars:
        input = raw_input("\nEnter: ")
        if input == 'y':
            var = item
            break
    obj_id.action_run(var)

# Generated at 2022-06-25 07:36:22.949188
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # generating random input for testing constructor of class ActionModule
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:36:23.743517
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        raise Exception
    except:
        test_case_0()

# Generated at 2022-06-25 07:36:29.870873
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0]
    float_0 = -1985.665
    set_0 = {bool_0}
    action_module_0 = ActionModule(bool_0, list_0, float_0, list_0, set_0, list_0)
    bool_0 = False
    list_0 = [bool_0, bool_0, bool_0]
    float_0 = -1985.665
    set_0 = {bool_0}
    action_module_0 = ActionModule(bool_0, list_0, float_0, list_0, set_0, list_0)
    bool_0 = False
    list_0 = [bool_0, bool_0, bool_0]
    float_0 = -1985.665

# Generated at 2022-06-25 07:36:35.023038
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0]
    float_0 = -1985.665
    set_0 = {bool_0}
    action_module_0 = ActionModule(bool_0, list_0, float_0, list_0, set_0, list_0)
    assert action_module_0._task.action == 'set_fact'
    assert action_module_0._plugin_name == 'set_fact'
    assert action_module_0.action_loader.action_paths == [bool_0]

# Generated at 2022-06-25 07:36:41.164816
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True is True
    assert False is False

    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0]
    float_0 = -1985.665
    set_0 = {bool_0}
    action_module_0 = ActionModule(bool_0, list_0, float_0, list_0, set_0, list_0)
    var_0 = action_module_0.run()
    print(var_0)

# Generated at 2022-06-25 07:36:42.738299
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Note: all generated methods are in the module of the class

# EOF

# Generated at 2022-06-25 07:36:48.424259
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert callable(ActionModule)
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0]
    float_0 = -1985.665
    set_0 = {bool_0}
    action_module_0 = ActionModule(bool_0, list_0, float_0, list_0, set_0, list_0)
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:36:54.457402
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Constructor of class ActionModule
    """
    #bool_0 = 
    #list_0 = 
    #float_0 = 
    #list_1 = 
    #set_0 = 
    #list_2 = 
    #action_module_0 = ActionModule(bool_0, list_0, float_0, list_1, set_0, list_2)
    var_0 = ActionModule(True, [True, True, True], -1985.665,
        [True, True, True], {True}, [True, True, True])


# Generated at 2022-06-25 07:36:55.260239
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print(ActionModule.__doc__)


# Generated at 2022-06-25 07:37:00.860875
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0]
    float_0 = -1985.665
    set_0 = {bool_0}
    action_module_0 = ActionModule(bool_0, list_0, float_0, list_0, set_0, list_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:38:12.156111
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0.TRANSFERS_FILES == False

# Generated at 2022-06-25 07:38:17.472477
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0]
    float_0 = -1985.665
    set_0 = {bool_0}
    action_module_0 = ActionModule(bool_0, list_0, float_0, list_0, set_0, list_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:38:22.928697
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0]
    float_0 = -1985.665
    set_0 = {bool_0}
    action_module_0 = ActionModule(bool_0, list_0, float_0, list_0, set_0, list_0)


# Generated at 2022-06-25 07:38:33.070600
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0]
    float_0 = -1985.665
    set_0 = {bool_0}
    action_module_0 = ActionModule(bool_0, list_0, float_0, list_0, set_0, list_0)
    var_0 = [bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, float_0, float_0, float_0, float_0, float_0, float_0, float_0, float_0, float_0, float_0]
    var_1 = {'list': list_0, 'set': set_0}
    # test case
    var_2 = action_run()



# Generated at 2022-06-25 07:38:40.245141
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0]
    float_0 = -1985.665
    dict_0 = {'list_0': list_0, 'bool_0': bool_0, 'float_0': float_0}
    set_0 = {bool_0}
    action_module_0 = ActionModule(bool_0, list_0, float_0, list_0, set_0, list_0)
    dict_1 = dict_0.copy()
    dict_1['list_0'] = list(dict_0['list_0'])
    dict_1['bool_0'] = dict_0['bool_0']
    dict_1['float_0'] = dict_0['float_0']
    dict_1['list_0'] = list

# Generated at 2022-06-25 07:38:45.314005
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0]
    float_0 = -1985.665
    set_0 = {bool_0}
    action_module_0 = ActionModule(bool_0, list_0, float_0, list_0, set_0, list_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:38:49.536551
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # mock the actions and just call action_module_0.run() to test the output of
    # action_module_0.action. 
    action_run.return_value = {}
    # test the case where the action_module_0 is to be executed
    test_case_0()
    # test the case where the action_module_0 is not to be executed


# Generated at 2022-06-25 07:38:52.974229
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # set up
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0]
    float_0 = -1985.665
    set_0 = {bool_0}
    action_module_0 = ActionModule(bool_0, list_0, float_0, list_0, set_0, list_0)
    # test the run function
    action_module_0.run()
    assert True



# Generated at 2022-06-25 07:38:56.338810
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0]
    float_0 = -1985.665
    set_0 = {bool_0}
    action_module_0 = ActionModule(bool_0, list_0, float_0, list_0, set_0, list_0)
    var_0 = ActionModule.run(action_module_0, None, None)

# verify that the results are correct

# Generated at 2022-06-25 07:38:59.711047
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action_module_0 = ActionModule()
    except TypeError:
        print("TypeError")
    else:
        print("Exception was not raised")
