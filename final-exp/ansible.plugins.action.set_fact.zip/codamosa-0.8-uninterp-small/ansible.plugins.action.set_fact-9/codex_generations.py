

# Generated at 2022-06-25 07:31:24.724089
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils._text import to_text
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from units.mock.plugins.action import ActionModule as ActionModuleMock
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.plugins.loader import action_loader

# Generated at 2022-06-25 07:31:34.604049
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ansible_facts = dict()
    ansible_facts['ansible_search_path'] = '/tmp'
    ansible_facts['ansible_kernel'] = 'Linux'
    ansible_facts['env'] = dict()
    ansible_facts['env']['HOME'] = '/root'
    ansible_facts['env']['PATH'] = '/usr/bin:/bin:/usr/sbin:/sbin'
    ansible_facts['env']['LOGNAME'] = 'root'

    parameters = dict()
    parameters['cacheable'] = True
    parameters['ansible_kernel'] = 'Linux'
    parameters['ansible_search_path'] = '/tmp'
    parameters['env'] = dict()
    parameters['env']['HOME'] = '/root'

# Generated at 2022-06-25 07:31:43.561488
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:31:48.320264
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'ansible_search_path'
    action_module_1 = ActionModule(0, {}, str_0, 0, 0, str_0)
    action_module_2 = ActionModule(0, {}, str_0, 0, 0, str_0)
    str_1 = 'ansible_search_path'
    action_module_1.run(0, str_1)
    action_module_2.run(0, str_1)

# Generated at 2022-06-25 07:31:54.196660
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -687.23
    dict_0 = {float_0: float_0}
    str_0 = 'ansible_search_path'
    action_module_0 = ActionModule(float_0, dict_0, str_0, float_0, float_0, str_0)
    action_module_0.run()


# Generated at 2022-06-25 07:31:58.162897
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_1 = 0.095984299
    dict_1 = {float_1: float_1}
    str_1 = 'connection'
    action_module_1 = ActionModule(float_1, dict_1, str_1, float_1, float_1, str_1)
    action_module_1.run()


# Generated at 2022-06-25 07:32:02.200606
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -687.23
    dict_0 = {float_0: float_0}
    str_0 = 'ansible_searh_path'
    action_module_0 = ActionModule(float_0, dict_0, str_0, float_0, float_0, str_0)
    action_module_0.run()



# Generated at 2022-06-25 07:32:05.697797
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 154
    dict_0 = {'t': 'fact'}
    str_0 = 'lookup'
    action_module_0 = ActionModule(float_0, dict_0, str_0, float_0, float_0, str_0)
    test_case_0()

# Generated at 2022-06-25 07:32:07.390351
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = test_case_0()
    assert action_module_0 is not None

# Generated at 2022-06-25 07:32:17.726498
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = dict()
    dict_0 = dict()
    str_0 = 'ansible_search_path'
    action_module_0 = ActionModule(dict_0, dict_0, str_0, dict_0, dict_0, str_0)
    dict_0 = dict()
    dict_0 = dict()
    str_0 = 'ansible_search_path'
    action_module_1 = ActionModule(dict_0, dict_0, str_0, dict_0, dict_0, str_0)
    dict_0 = dict()
    dict_0 = dict()
    str_0 = 'ansible_search_path'
    action_module_2 = ActionModule(dict_0, dict_0, str_0, dict_0, dict_0, str_0)
    dict_0

# Generated at 2022-06-25 07:32:25.307196
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(None, None, None, None, None, None)
    var_1 = {'ansible_facts': None, '_ansible_facts_cacheable': None}
    assert var_1 == action_module_0.run(None, None)


# Generated at 2022-06-25 07:32:30.803947
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    dict_0 = dict()
    dict_0['ansible_search_path'] = -687.23
    dict_1 = dict()
    dict_1['ansible_search_path'] = -687.23
    dict_0['ansible_user_dir'] = dict_1
    dict_2 = dict()
    dict_2['ansible_search_path'] = -687.23
    dict_0['ansible_playbook_python'] = dict_2
    dict_3 = dict()
    dict_3['ansible_search_path'] = -687.23
    dict_0['ansible_role_names'] = dict_3
    dict_4 = dict()
    dict_4['ansible_search_path'] = -687.23

# Generated at 2022-06-25 07:32:34.199972
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -541.23
    dict_0 = {float_0: float_0}
    str_0 = 'ansible_user_dir'
    action_module_0 = ActionModule(float_0, dict_0, str_0, float_0, float_0, str_0)

# Generated at 2022-06-25 07:32:41.611291
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -982.5
    dict_0 = {float_0: float_0}
    str_0 = 'http_port'
    action_module_0 = ActionModule(float_0, dict_0, str_0, float_0, float_0, str_0)
    # Unit test for run function of class ActionModule
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 07:32:47.325336
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -687.23
    dict_0 = {float_0: float_0}
    str_0 = 'ansible_search_path'
    action_module_0 = ActionModule(float_0, dict_0, str_0, float_0, float_0, str_0)
    str_1 = '?{*#{"Y|1gW"}'
    dict_1 = {'ansible_facts': {str_1: str_1}, '_ansible_facts_cacheable': str_0}
    dict_2 = {str_0: str_0}
    assert (dict_1 == action_module_0.run(dict_2, dict_2))

if __name__ == "__main__":
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:32:50.894590
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -687.23
    dict_0 = {float_0: float_0}
    str_0 = 'ansible_search_path'
    action_module_0 = ActionModule(float_0, dict_0, str_0, float_0, float_0, str_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:32:56.000677
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -687.23
    dict_0 = {float_0: float_0}
    str_0 = 'ansible_search_path'
    action_module_0 = ActionModule(float_0, dict_0, str_0, float_0, float_0, str_0)
    var_0 = action_module_0.static_run(None, None)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:33:02.970190
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -687.23
    dict_0 = {float_0: float_0}
    str_0 = 'ansible_search_path'
    action_module_0 = ActionModule(float_0, dict_0, str_0, float_0, float_0, str_0)
    assert action_module_0.run()



# Generated at 2022-06-25 07:33:10.853026
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  action_module_0 = ActionModule()
  float_0 = -687.23
  dict_0 = {float_0: float_0}
  str_0 = 'ansible_search_path'
  var_0 = action_run(float_0, dict_0, str_0, float_0, float_0, str_0)
  assert var_0 == False

# Generated at 2022-06-25 07:33:17.380116
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # ============== Variables
    float_0 = -687.23
    dict_0 = {float_0: float_0}
    str_0 = 'ansible_search_path'
    action_module_0 = ActionModule(float_0, dict_0, str_0, float_0, float_0, str_0)
    print(action_module_0)


if __name__ == "__main__":
    pass

# Generated at 2022-06-25 07:33:29.115629
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -687.23
    dict_0 = {float_0: float_0}
    str_0 = 'ansible_search_path'
    str_1 = 'ansible_search_path'
    float_1 = 3409.18
    float_2 = -687.23
    action_module_0 = ActionModule(float_2, dict_0, str_0, float_1, float_0, str_1)


# Generated at 2022-06-25 07:33:29.688963
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:33:30.760637
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:33:42.673383
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -687.23
    dict_0 = {float_0: float_0}
    str_0 = 'ansible_search_path'
    action_module_0 = ActionModule(float_0, dict_0, str_0, float_0, float_0, str_0)
    dict_1 = {}
    dict_2 = {}
    dict_2['ansible_facts'] = dict_1
    dict_2['_ansible_facts_cacheable'] = False
    assert action_module_0.run(dict_1, dict_1) == dict_2
    dict_2['_ansible_facts_cacheable'] = False
    dict_1 = dict_0
    assert action_module_0.run(dict_0, dict_1) == dict_2

# Generated at 2022-06-25 07:33:53.550882
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float0, float1 = -687.23, 237.85
    dict0 = {float0: float0}
    str0, str1 = 'ansible_search_path', 'c'
    actionModule0 = ActionModule(float0, dict0, str0, float0, float1, str1)
    float2 = -452.58
    actionModule0.action_run(tmp=float2)
    float3 = -385.06
    dict1 = {float2: float1, float0: float1, float3: float0, float1: float0}
    str2 = 'action'
    actionModule1 = ActionModule(float2, dict1, str2, float2, float3, str2)
    actionModule1.action_run(var=float3)
    dict2 = {float3: float2}


# Generated at 2022-06-25 07:33:59.496748
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        float_0 = 21
        dict_0 = {
            'long_opt': None,
            'short_opt': '-v',
            'option_args': [
                'version'
            ]
        }
        str_0 = 'ansible_play_hosts_all'
        action_module_0 = ActionModule(float_0, dict_0, str_0, float_0, float_0, str_0)
    except BaseException as err_0:
        assert False


# Generated at 2022-06-25 07:34:04.176683
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("ansible_facts: ",result['ansible_facts'])
    assert result['ansible_facts'] == expected_result
    print("changed: ",result['changed'])
    assert result['changed'] == True


# Generated at 2022-06-25 07:34:09.728717
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -862.48
    dict_0 = {'ec7': 'X', 'uHZt': 'Wbj'}
    str_0 = 'module'
    action_module_0 = ActionModule(float_0, dict_0, str_0, float_0, float_0, str_0)
    assert type(action_module_0) == ActionModule

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 07:34:16.208092
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars_0 = dict
    tmp_0 = None
    action_module_1 = ActionModule(task_vars_0, tmp_0)
    del tmp_0
    del task_vars_0
    try:
        result = action_module_1.run()
        try:
            raise Exception("expected failure")
        except:
            pass
    except:
        result = None
    task_vars_0 = dict
    action_module_2 = ActionModule(task_vars_0, None)
    del task_vars_0
    tmp_0 = '~r'
    bool_0 = True
    float_1 = -0.31397
    str_1 = 'ansible_kernel'
    var_0 = task_vars_0[tmp_0] # get the value of ans

# Generated at 2022-06-25 07:34:21.187782
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor test
    # Input parameters: self, tmp, task_vars
    action_module_0 = ActionModule(None, None, None)
    if (not (action_module_0._task.args == {})):
        raise RuntimeError("Argument _task.args of constructor of class action.ActionModule is not set to an empty dictionary")
    if (action_module_0.TRANSFERS_FILES == True):
        raise RuntimeError("Argument TRANSFERS_FILES of constructor of class action.ActionModule is not set to False by default")


# Generated at 2022-06-25 07:34:40.482302
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -687.23
    dict_0 = {float_0: float_0}
    str_0 = 'ansible_search_path'
    action_module_0 = ActionModule(float_0, dict_0, str_0, float_0, float_0, str_0)


# Generated at 2022-06-25 07:34:44.921908
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Input parameters: [0,1,2,3,4,5]
    # Output parameters: [6,7]
    var_1 = ActionModule()
    # Input parameters: [8,9]
    # Output parameters: [10]
    var_2 = run()


# Generated at 2022-06-25 07:34:48.193027
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = dict()
    obj_ActionModule = ActionModule(tmp, task_vars)
    _var_ActionModule = obj_ActionModule.run()


# Generated at 2022-06-25 07:34:51.503238
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an object of the class ActionModule
    action_module_0 = ActionModule()
    assert(isinstance(action_module_0, ActionModule))


# Generated at 2022-06-25 07:34:54.964752
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    action_module_0 = ActionModule(bool_0, bool_0, bool_0, bool_0, bool_0, bool_0)
    del bool_0


# Generated at 2022-06-25 07:34:57.378457
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 07:35:00.545133
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:35:02.658705
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # not sure if we need to test these as they are quite trivial functions
    # or if we should replace them with a generic helper function test_ActionBase
    # TODO: refactor into test_ActionBase
    return

# Generated at 2022-06-25 07:35:06.539141
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -866.82
    dict_0 = {float_0: float_0}
    str_0 = 'ansible_search_path'
    action_module_0 = ActionModule(float_0, dict_0, str_0, float_0, float_0, str_0)
    action_module_0 = ActionModule()
    # Verify that result of constructor is of type ActionModule
    assert(type(action_module_0) == ActionModule)



# Generated at 2022-06-25 07:35:09.420649
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -687.23
    dict_0 = {float_0: float_0}
    str_0 = 'ansible_search_path'
    action_module_0 = ActionModule(float_0, dict_0, str_0, float_0, float_0, str_0)
    return (action_module_0)

# Generated at 2022-06-25 07:35:43.393834
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -687.23
    dict_0 = {float_0: float_0}
    str_0 = 'ansible_search_path'
    action_module_0 = ActionModule(float_0, dict_0, str_0, float_0, float_0, str_0)
    assert action_module_0._task.args == {float_0: float_0}
    assert action_module_0._result == dict_0
    assert action_module_0._task.args == {float_0: float_0, str_0: float_0}
    assert action_module_0._task.args == {'cacheable': float_0}

# Generated at 2022-06-25 07:35:48.190567
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -687.23
    dict_0 = {float_0: float_0}
    str_0 = 'ansible_search_path'
    action_module_0 = ActionModule(float_0, dict_0, str_0, float_0, float_0, str_0)
    assert type(action_module_0) == ActionModule


# Generated at 2022-06-25 07:35:51.264307
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Test for signature of constructor
    action_module_0 = ActionModule(dict)


# Generated at 2022-06-25 07:35:55.643508
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Unit test is executed only if there is a command line argument --testtest
    # Constructor of class ActionModule
    # test case 0
    float_0 = -687.23
    dict_0 = {float_0: float_0}
    str_0 = 'ansible_search_path'
    action_module_0 = ActionModule(float_0, dict_0, str_0, float_0, float_0, str_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:35:56.373758
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-25 07:36:02.732510
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 0.709
    dict_0 = {float_0: float_0}
    str_0 = 'ansible_connection'
    action_module_0 = ActionModule(float_0, dict_0, str_0, float_0, float_0, str_0)
    func_0 = action_module_0.run()

test_case_0()
test_ActionModule()

# Generated at 2022-06-25 07:36:07.261411
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    float_0 = -687.23
    dict_0 = {float_0: float_0}
    str_0 = 'ansible_search_path'
    action_module_0 = ActionModule(float_0, dict_0, str_0, float_0, float_0, str_0)
    action_module_0.run()

# Generated at 2022-06-25 07:36:08.724063
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        raise RuntimeError
    except RuntimeError:
        pass
    else:
        raise AssertionError
    finally:
        pass


# Generated at 2022-06-25 07:36:09.327953
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('test_ActionModule')


# Generated at 2022-06-25 07:36:17.931121
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Source: '../../lib/ansible/plugins/action/set_fact.py'
    # The module uses the following call to initialize the object:
    # action_module_0 = ActionModule(float_0, dict_0, str_0, float_0, float_0, str_0)
    float_0 = -687.23
    dict_0 = {float_0: float_0}
    str_0 = 'ansible_search_path'
    action_module_0 = ActionModule(float_0, dict_0, str_0, float_0, float_0, str_0)


# Generated at 2022-06-25 07:37:29.925868
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-25 07:37:30.444533
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:37:37.108069
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(None, None, None, None, None, None)
    assert(action_module_0._default_vars == {})
    assert(action_module_0._remote_tmp == C.DEFAULT_REMOTE_TMP)
    assert(action_module_0._task.syntax == 'yaml')
    assert(action_module_0.action == 'set_fact')
    assert(action_module_0.action_loader.get('set_fact').action == '/home/shenbin/Ansible/local/lib/python2.7/site-packages/ansible/plugins/action/set_fact.py')
    assert(action_module_0.action_loader.get('set_fact').action_type == 'normal')

# Generated at 2022-06-25 07:37:47.924808
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    
    class TestModule:
        def __init__(self):
            self._task = type('', (), {})()
            self._task.args = dict()
            self._task.args['cacheable'] = False
            self._task.args['fail'] = True
            self._task.args['test1'] = 'success'
            self._task.args['test2'] = 'failure'
            self._task.args['test3'] = 'success'
            self._task.args['test4'] = 'failure'
            self._task.args['test5'] = 'success'
            self._task.args['test6'] = 'failure'
            self._task.args['test7'] = 'success'
            self._task.args['test8'] = 'failure'
            self._task.args['test9']

# Generated at 2022-06-25 07:37:52.135172
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -687.23
    dict_0 = {float_0: float_0}
    str_0 = 'ansible_search_path'
    action_module_0 = ActionModule(float_0, dict_0, str_0, float_0, float_0, str_0)
    return action_module_0

# Generated at 2022-06-25 07:37:56.540401
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -687.23
    dict_0 = {float_0: float_0}
    str_0 = 'ansible_search_path'
    var_0 = test_ActionModule_0(float_0, dict_0, str_0)



# Test Global Variables
# Test Local Variables
# Test Function
# Test Class

# Generated at 2022-06-25 07:38:01.039695
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(None, None, 'ansible_search_path', None, None, 'ansible_search_path')
    assert action_module_0.TRANSFERS_FILES == False

# Generated at 2022-06-25 07:38:01.805533
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    err, actual_result, result = ActionModule().run()

# Generated at 2022-06-25 07:38:06.572452
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing constructor of class ActionModule")
    float_0 = -687.23
    dict_0 = {float_0: float_0}
    str_0 = 'ansible_search_path'
    action_module_0 = ActionModule(float_0, dict_0, str_0, float_0, float_0, str_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:38:15.090610
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tm = -687.23
    task_vars = {tm: tm}
    tmp = 'ansible_search_path'
    play_context = tm
    loader = tm
    templar = tmp
    shared_loader_obj = tmp
    action_module_0 = ActionModule(tmp, task_vars, tmp, play_context, loader, templar, shared_loader_obj)
    var_0 = action_module_0.run(tmp, task_vars)
    if (var_0 != None):
        test_case_0()