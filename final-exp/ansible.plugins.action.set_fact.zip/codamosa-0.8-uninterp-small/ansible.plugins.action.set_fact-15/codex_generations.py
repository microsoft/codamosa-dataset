

# Generated at 2022-06-25 07:31:24.779639
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Zq\x14\x07'
    str_1 = '\t\x06'
    str_2 = '\x1a3'
    str_3 = 'b\x11'
    str_4 = '\x1f'
    int_0 = 1
    str_5 = '\x0c'
    str_6 = '0\x19\x045\x11'
    str_7 = '\x07'
    str_8 = '\x16\x07\x12\x05'
    set_0 = set()
    list_0 = [str_0, str_1, str_2, str_3, str_4, int_0, str_5, str_6, str_7, str_8, set_0]
    action_module_

# Generated at 2022-06-25 07:31:32.642075
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = ''
    str_1 = 'O\x1a\\Oj\x14'
    set_0 = set()
    list_0 = [str_1]
    set_1 = {str_0}
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, str_0, set_0, list_0, set_1, tuple_0)

if __name__ == '__main__':
    action_module_0 = None
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 07:31:42.201399
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'ABSTRACT_METHOD'
    set_0 = set()
    list_0 = ['A\x1cL\x0b^\x0c\x0fY\x18C']
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, str_0, set_0, list_0, set_0, tuple_0)
    assert action_module_0._task.action == 'ABSTRACT_METHOD'
    assert action_module_0._connection is None
    assert action_module_0._play_context is None
    action_module_0._task.action = 'A\x1cL\x0b^\x0c\x0fY\x18C'

# Generated at 2022-06-25 07:31:49.853598
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '<QmFvdHMh>\x15\x00\x00\x00/\x00\x00\x00'
    set_0 = set()
    list_0 = [str_0]
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, str_0, set_0, list_0, set_0, tuple_0)
    action_module_0._use_shell = False

# Generated at 2022-06-25 07:31:55.049644
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'v6`u[`'
    set_0 = set()
    list_0 = [str_0]
    tuple_0 = (str_0,)
    action_module_0 = ActionModule(str_0, str_0, set_0, list_0, set_0, tuple_0)
    action_module_0.run()

# Generated at 2022-06-25 07:32:01.271874
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'S*2y`*I\x0c[+ogV/uMYg@'
    set_0 = set()
    list_0 = ['wrr:`rWSZn.IGe*\x7f\\x0b']
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, str_0, set_0, list_0, set_0, tuple_0)
    int_0 = tempfile.NamedTemporaryFile()
    action_module_0.run(int_0)
    int_0.close()

# Generated at 2022-06-25 07:32:02.151415
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = test_case_0()
    assert a == None

# Generated at 2022-06-25 07:32:05.703988
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'n-kYa2OKT46dD@\t*H'
    set_0 = set()
    list_0 = [str_0]
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, str_0, set_0, list_0, set_0, tuple_0)


# Generated at 2022-06-25 07:32:16.178322
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  str_0 = 'Hq\x1b5J5\x0b?Q\x01?\x1d\x05'
  set_0 = set()
  list_0 = [str_0]
  tuple_0 = ()
  action_module_0 = ActionModule(str_0, str_0, set_0, list_0, set_0, tuple_0)
  str_1 = ''
  dict_0 = {'test_key4': 'test_value4', 'test_key3': 'test_value3', 'test_key5': 'test_value5', 'test_key2': 'test_value2', 'test_key1': 'test_value1', 'test_key0': 'test_value0'}
  action_module_0.run(str_1, dict_0)

# Generated at 2022-06-25 07:32:17.984605
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp = None
    task_vars = None
    action_module_0 = ActionModule(tmp, task_vars)


# Generated at 2022-06-25 07:32:23.697746
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-25 07:32:27.846820
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    action_module_0 = ActionModule(var_0, var_0)
    tmp_0 = None
    task_vars_0 = None
    # Testing exception
    try:
        action_module_0.run(tmp_0, task_vars_0)
    except AnsibleActionFail as e:
        print(e)
    # Testing exception
    try:
        action_module_0.run(tmp_0, task_vars_0)
    except AnsibleActionFail as e:
        print(e)

# Generated at 2022-06-25 07:32:29.927923
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = None
    var_2 = None
    action_module_1 = ActionModule(var_1, var_2)



# Generated at 2022-06-25 07:32:35.731402
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # init
    var_0 = None
    var_0 = None
    var_1 = None
    Task = type('Task', (object,), {})
    task = Task()
    action_module = ActionModule(var_0, task)

    result_mock = Mock()
    result_mock.reset_mock()
    action_module.run = Mock(return_value=result_mock)

    # perform test
    result = action_module.run(var_0, var_1)

    # assert return type
    assert isinstance(result, Mock)


# Generated at 2022-06-25 07:32:40.621508
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    obj = ActionModule(var_1, var_2)


# Generated at 2022-06-25 07:32:43.511663
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = None
    var_2 = None
    action_module_0 = ActionModule(var_0, var_1)
    action_module_0.run(var_0, var_2)

# Generated at 2022-06-25 07:32:45.594818
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    action_module_0 = ActionModule(var_0, var_0)
    var_1 = None
    var_2 = action_module_0.run(var_1, var_0)


# Generated at 2022-06-25 07:32:50.941672
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = None
    var_2 = dict()
    obj_0 = action_module_0.run(var_1, var_2)
    assert(obj_0['ansible_facts'] == {})
    assert(obj_0['_ansible_facts_cacheable'] == False)

# Generated at 2022-06-25 07:32:56.591947
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionModule()
    assert (isinstance(var_0, ActionModule))
    assert (var_0._action == None)
    assert (var_0._connection == None)
    assert (var_0._play_context == None)
    assert (var_0._task == None)
    assert (var_0._loader == None)
    assert (var_0._templar == None)
    assert (var_0._shared_loader_obj == None)
    assert (var_0._task_vars == None)
    assert (var_0._action_vars == None)
    assert (var_0._tmp == None)
    assert (var_0._module_name == 'setup')
    assert (var_0._module_args == None)
    assert (var_0._result == None)
   

# Generated at 2022-06-25 07:33:02.517722
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = None
    var_2 = None
    action_module_0 = ActionModule(var_0, var_1)
    assert not action_module_0.run(var_1, var_2)

# Generated at 2022-06-25 07:33:14.274204
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    input_0 = 0
    input_1 = 0
    str_0 = 'S*2yw`vI\x0c[+ogV/uMYg{'
    set_0 = set()
    list_0 = [input_0,input_0,input_1]
    tuple_0 = (input_0,)
    action_module_0 = ActionModule(str_0, str_0, set_0, list_0, set_0, tuple_0)
    var_0 = action_run()
    return var_0

# Generated at 2022-06-25 07:33:23.089670
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, 'run'), 'has a run method'

    tmp = None
    task_vars = None
    result = super(ActionModule, self).run(tmp, task_vars)
    tmp = None
    task_vars = None
    result = super(ActionModule, self).run(tmp, task_vars)
    tmp = None
    task_vars = None
    result = super(ActionModule, self).run(tmp, task_vars)
    tmp = None
    task_vars = None
    result = super(ActionModule, self).run(tmp, task_vars)
    tmp = None
    task_vars = None
    result = super(ActionModule, self).run(tmp, task_vars)
    tmp = None
    task_vars = None

# Generated at 2022-06-25 07:33:24.662451
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-25 07:33:29.782359
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'S*2yw`vI\x0c[+ogV/uMYg{'
    set_0 = set()
    list_0 = [str_0]
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, str_0, set_0, list_0, set_0, tuple_0)
    # Exception: 'KeyError' object is not subscriptable
    try:
        var_0 = action_module_0.run()
    except Exception:
        var_0 = None
    finally:
        assert var_0 is None


# Generated at 2022-06-25 07:33:38.488372
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    dict_1 = {'v': '1.1.1'}
    str_0 = '.'
    set_0 = set()
    list_0 = ['.']
    tuple_0 = ()
    dict_2 = dict_1
    dict_1 = dict_1
    dict_1 = dict_1
    dict_3 = dict_1
    dict_1 = dict_1
    dict_1 = dict_1
    dict_3 = dict_2
    dict_1 = dict_2
    dict_3 = dict_3
    action_module_0 = ActionModule(str_0, str_0, set_0, list_0, set_0, tuple_0)
    var_0 = action_module_0.run(dict_0, dict_1)
    var_1

# Generated at 2022-06-25 07:33:44.913814
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'S*2yw`vI\x0c[+ogV/uMYg{'
    set_0 = set()
    list_0 = [str_0]
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, str_0, set_0, list_0, set_0, tuple_0)
    var_0 = action_run()
    assert isinstance(var_0, dict) or isinstance(var_0, bool)


# Generated at 2022-06-25 07:33:54.394102
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'S*2yw`vI\x0c[+ogV/uMYg{'
    str_1 = 'S*2yw`vI\x0c[+ogV/uMYg{'
    set_0 = set()
    list_0 = [str_0]
    set_1 = set()
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, str_1, set_0, list_0, set_1, tuple_0)
    assert action_module_0.action == str_0

# Generated at 2022-06-25 07:34:01.223852
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'S*2yw`vI\x0c[+ogV/uMYg{'
    value_0 = 'T\\1a;@!X\x0bf|k"F}[My`2'
    list_0 = [value_0]
    dict_0 = {}
    dict_0[value_0] = str_0
    dict_0[value_0] = list_0
    tuple_0 = ()
    tuple_0 = (str_0,)
    action_module_0 = ActionModule(str_0, str_0, dict_0, tuple_0, dict_0, tuple_0)
    assert(action_module_0)


# Generated at 2022-06-25 07:34:11.946761
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:34:14.936440
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    list_0 = [str_0]
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, str_0, set_0, list_0, set_0, tuple_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:34:27.867110
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionModule()



# Generated at 2022-06-25 07:34:31.948776
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert var_0 == result_0

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:34:37.201326
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'S*2yw`vI\x0c[+ogV/uMYg{'
    set_0 = set()
    list_0 = [str_0]
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, str_0, set_0, list_0, set_0, tuple_0)
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:34:41.572602
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = ':dM~X1K\r'
    list_0 = []
    set_0 = {str_0}
    tuple_0 = (list_0, )
    list_1 = []
    set_1 = {list_1, }
    tuple_1 = (list_0, )
    action_module_0 = ActionModule(str_0, str_0, set_0, list_0, set_1, tuple_0)
    action_module_0.run(list_1, tuple_1)

# Generated at 2022-06-25 07:34:42.211560
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 07:34:45.257899
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 's'
    set_0 = iter(())
    list_0 = iter(())
    tuple_0 = iter(())
    action_module_0 = ActionModule(str_0, str_0, set_0, list_0, set_0, tuple_0)
    var_0 = action_module_0.run()
    assert var_0 == None


# Generated at 2022-06-25 07:34:51.803378
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    v_0 = None
    v_1 = None
    v_2 = None
    v_3 = None
    v_4 = ActionModule(v_0, v_1, v_2, v_3, v_2, v_3)
    v_2 = v_4
    v_3 = v_4
    v_3 = v_4
    v_4.run(v_4, v_4)


# Generated at 2022-06-25 07:34:56.761221
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 't/z*5|.uAG\r_Vr'
    set_0 = set()
    list_0 = [str_0]
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, str_0, set_0, list_0, set_0, tuple_0)
    action_module_0.run()


# Generated at 2022-06-25 07:35:02.237452
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\r'
    set_0 = set()
    list_0 = []
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, str_0, set_0, list_0, set_0, tuple_0)
    action_module_0.run()

# Generated at 2022-06-25 07:35:05.513414
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Expected call
    # AnsibleActionRun(self, tmp, task_vars)
    action_module_0 = ActionModule('5` W\t', ' gi[y', set(), [], {}, (1, ))
    action_module_0.run(str_0, 'o#g"y')



# Generated at 2022-06-25 07:35:29.131542
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'cY\n;=|A)x0\x0e\x0b'
    set_0 = set()
    list_0 = []
    tuple_0 = tuple(list_0)
    action_module_0 = ActionModule(str_0, str_0, set_0, list_0, set_0, tuple_0)
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:35:32.316215
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO - test the definition
    pass


# Generated at 2022-06-25 07:35:36.529925
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'e][p'
    set_0 = set()
    list_0 = [str_0]
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, str_0, set_0, list_0, set_0, tuple_0)
    assert isinstance(action_module_0, object)

# Generated at 2022-06-25 07:35:37.344656
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 07:35:38.146026
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 07:35:44.264198
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'oj?W'
    set_0 = set()
    list_0 = ['c']
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, str_0, set_0, list_0, set_0, tuple_0)
    var_0 = action_run()
    # test case 1
    str_0 = 'n3]LH\rYvC,WRCz8t9'
    set_0 = set()
    list_0 = [str_0]
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, str_0, set_0, list_0, set_0, tuple_0)
    var_0 = action_run()
    # test case 2

# Generated at 2022-06-25 07:35:48.191544
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # global default values
    # calling constructor of ActionModule
    action_module_0 = ActionModule()
    # testing attributes of object
    # assert str(action_module_0) == '<ansible.plugins.action.ActionModule object at 0x000000000000>'


# Generated at 2022-06-25 07:35:57.029101
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # First parameter is tmp
    # Second parameter is task_vars
    # Returns a list of results
    from ansible.constants import DEFAULT_JINJA2_NATIVE
    assert isidentifier('__var_0__') is True
    assert isidentifier('var0') is True
    assert isidentifier('var-1') is False
    assert isidentifier('var 1') is False
    assert isidentifier('var 1') == False
    assert isidentifier('1~~~%%%') is False
    assert isidentifier('_1~~~%%%') is False
    assert isidentifier('1var~~~%%%') is False
    assert isidentifier('_1var~~~%%%') is False
    assert isidentifier('var_') is False
    assert isidentifier('1') is False
    assert isident

# Generated at 2022-06-25 07:36:03.256949
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'S*2yw`vI\x0c[+ogV/uMYg{'
    set_0 = set()
    list_0 = [str_0]
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, str_0, set_0, list_0, set_0, tuple_0)
    # ActionModule.run()


# Generated at 2022-06-25 07:36:06.642117
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule('module', 'module', set(), [module], set(), ()), ActionModule)
    assert isinstance(ActionModule.__module__, str)
    assert isinstance(ActionModule.run(), dict)


# Generated at 2022-06-25 07:36:54.277543
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\x0b\x85\xe0\x81\x0766]\x84\xca\xd6[V\x87\xdb'

# Generated at 2022-06-25 07:37:00.235255
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'S*2yw`vI\x0c[+ogV/uMYg{'
    set_0 = set()
    list_0 = [str_0]
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, str_0, set_0, list_0, set_0, tuple_0)
    assert type(action_module_0) == action_module_0

# Generated at 2022-06-25 07:37:03.100337
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 07:37:04.476570
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    if action_module_0.run() is None:
        var_0 = action_run()


# Generated at 2022-06-25 07:37:10.803093
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initializes an instance of the class to be tested
    action_module_0 = ActionModule()

    # Invokes the method under test
    result_0 = action_module_0.run()

    # Verifies the result
    assert result_0 == (None, None, None, None)


# Generated at 2022-06-25 07:37:19.997928
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '!Nqc%^V\nj]#Z[)'
    set_0 = set()
    list_0 = [str_0]
    tuple_0 = ()
    str_1 = 'S*2yw`vI\x0c[+ogV/uMYg{'
    str_2 = 'S*2yw`vI\x0c[+ogV/uMYg{'
    set_1 = set()
    list_1 = [str_1]
    set_2 = set()
    tuple_1 = ()
    action_module_0 = ActionModule(str_1, str_2, set_1, list_1, set_2, tuple_1)

# Generated at 2022-06-25 07:37:24.227879
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'S*2yw`vI\x0c[+ogV/uMYg{'
    set_0 = set()
    list_0 = [str_0]
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, str_0, set_0, list_0, set_0, tuple_0)
    var_0 = action_module_0.run()



# Generated at 2022-06-25 07:37:25.476936
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of ActionModule
    # action_module_0 = ActionModule()
    assert False # TODO: implement your test here


# Generated at 2022-06-25 07:37:30.029475
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Tested method run
    str_0 = 'c'
    set_0 = set()
    list_0 = [str_0]
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, str_0, set_0, list_0, set_0, tuple_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:37:33.431444
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'S*2yw`vI\x0c[+ogV/uMYg{'
    set_0 = set()
    list_0 = [str_0]
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, str_0, set_0, list_0, set_0, tuple_0)

# Generated at 2022-06-25 07:38:51.250970
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '#'
    str_1 = '!Z=j\nh&mH?#-$a'
    set_0 = set()
    list_0 = [str_0]
    set_1 = set(list_0)
    tuple_0 = ()
    action_module_0 = ActionModule(str_1, str_0, set_0, list_0, set_1, tuple_0)
    # Test attribute task
    # Test attribute injection
    # Test attribute only_if
    # Test attribute when
    # Test attribute async_seconds
    # Test attribute job_id
    # Test attribute poll


# Generated at 2022-06-25 07:38:58.944050
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test the existence of attributes
    assert hasattr(ActionModule, '_templar')
    assert hasattr(ActionModule, '_task')
    assert hasattr(ActionModule, '_connection')
    assert hasattr(ActionModule, '_loader')
    assert hasattr(ActionModule, '_play_context')
    assert hasattr(ActionModule, '_task_vars')
    assert hasattr(ActionModule, '_loader_cache')
    # Test the invokation of constructor
    object_0 = ActionModule()
    assert object_0 is not None

# Generated at 2022-06-25 07:39:02.347497
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'S*2yw`vI\x0c[+ogV/uMYg{'
    set_0 = set()
    list_0 = [str_0]
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, str_0, set_0, list_0, set_0, tuple_0)


# Generated at 2022-06-25 07:39:06.998439
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'B7\x06b\x00\x1d\x00\x1f'
    set_0 = set(['b'])
    list_0 = []
    tuple_0 = (set_0,)
    action_module_0 = ActionModule(str_0, str_0, set_0, list_0, set_0, tuple_0)
    var_0 = action_run()
    assert isinstance(var_0, dict)
    assert 'ansible_facts' in var_0
    assert isinstance(var_0['ansible_facts'], dict)
    assert '_ansible_facts_cacheable' in var_0


# Generated at 2022-06-25 07:39:07.697236
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:39:13.235913
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'S*2yw`vI\x0c[+ogV/uMYg{'
    set_0 = set()
    list_0 = [str_0]
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, str_0, set_0, list_0, set_0, tuple_0)
    assert action_module_0._task == None
    assert action_module_0._connection == None
    assert action_module_0._loader == None
    assert action_module_0._templar == None
    assert action_module_0._shared_loader_obj == None
    assert action_module_0._display == None
    assert action_module_0._task_vars == None


# Generated at 2022-06-25 07:39:19.759142
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'S*2yw`vI\x0c[+ogV/uMYg{'
    set_0 = set()
    list_0 = [str_0]
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, str_0, set_0, list_0, set_0, tuple_0)
    action_module_0.action = 'set_fact'
    action_module_0.tmp = '/var/folders/nf/sq5l8gjn343dv7f1m9n9p8xh0000gn/T/tmpmYMZbD'

# Generated at 2022-06-25 07:39:22.580634
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert (ActionModule.run)() == None


# Generated at 2022-06-25 07:39:22.944363
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True == False

# Generated at 2022-06-25 07:39:26.380887
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule('/etc/ansible/ansible.cfg', 't', set(), list(), set(), tuple())
    assert not isinstance(action_module_0, object)
    assert not isinstance(action_module_0, ActionBase)
