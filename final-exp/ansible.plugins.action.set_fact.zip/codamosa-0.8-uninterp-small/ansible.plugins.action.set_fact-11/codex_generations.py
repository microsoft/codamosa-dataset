

# Generated at 2022-06-25 07:31:23.607599
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = None
    set_0 = set()
    str_0 = '0>2Y'
    action_module_0 = ActionModule(bool_0, bool_0, set_0, str_0, str_0, bool_0)
    task_vars_0 = dict()
    action_module_0._task.args = dict()
    tmp_0 = None
    action_module_0.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 07:31:31.235739
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars_0 = dict()
    action_module_0 = ActionModule(None, None, None, None, None, None)
    str_0 = 'b,#'
    action_module_0._templar.template(str_0)
    result_0 = action_module_0.run(None, task_vars_0)
    assert result_0['ansible_facts']

# Generated at 2022-06-25 07:31:34.377702
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = None
    set_0 = set()
    str_0 = '3qo-<'
    action_module_0 = ActionModule(bool_0, bool_0, set_0, str_0, str_0, bool_0)


# Generated at 2022-06-25 07:31:36.433797
# Unit test for constructor of class ActionModule
def test_ActionModule():

    bool_0 = None
    set_0 = set()
    str_0 = '0>2Y'
    action_module_0 = ActionModule(bool_0, bool_0, set_0, str_0, str_0, bool_0)

# Generated at 2022-06-25 07:31:41.391280
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = None
    set_0 = set()
    str_0 = '0>2Y'
    action_module_0 = ActionModule(bool_0, bool_0, set_0, str_0, str_0, bool_0)

    # Call method run
    #assert action_module_0.run() == None



# Generated at 2022-06-25 07:31:49.408690
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = None
    set_0 = set()
    str_0 = '0>2Y'
    action_module_0 = ActionModule(bool_0, bool_0, set_0, str_0, str_0, bool_0)
    str_1 = 'f'
    action_module_1 = action_module_0.run(str_1)
    assert action_module_1 is not None
    assert action_module_1['_ansible_verbose_always'] == False
    assert action_module_1['_ansible_version'] == 52
    assert action_module_1['_ansible_verbosity'] == 2
    assert action_module_1['changed'] == False
    assert action_module_1['_ansible_no_log'] == False

# Generated at 2022-06-25 07:31:50.879945
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:31:54.240337
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert (isinstance(action_module_0, ActionModule))
    assert (isinstance(action_module_0, ActionBase))
    assert (isinstance(action_module_0, object))


# Generated at 2022-06-25 07:31:57.514859
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = None
    set_0 = set()
    str_0 = 't'
    action_module_0 = ActionModule(bool_0, bool_0, set_0, str_0, str_0, bool_0)



# Generated at 2022-06-25 07:32:05.346889
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import tempfile
    tmp_0 = tempfile.mkdtemp()
    tmp_1 = tempfile.mkdtemp()
    tmp_0_0 = tempfile.mkdtemp()
    tmp_1_0 = tempfile.mkdtemp()
    task_vars_0 = tempfile.mkdtemp()
    task_vars_1 = tempfile.mkdtemp()
    task_vars_0_0 = tempfile.mkdtemp()
    task_vars_1_0 = tempfile.mkdtemp()
    bool_0 = None
    set_0 = set()
    str_0 = '0>2Y'
    action_module_0 = ActionModule(bool_0, bool_0, set_0, str_0, str_0, bool_0)
    action_module_1 = Action

# Generated at 2022-06-25 07:32:18.893604
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:32:25.812761
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args_0 = 'kwargs'
    str_0 = 't'
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, str_0, str_0)
    dict_0 = dict()
    dict_1 = dict()
    result_0 = action_module_0.run(dict_0, dict_1)
    assert isinstance(result_0, dict)



# Generated at 2022-06-25 07:32:29.603940
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'n'
    str_1 = 'e'
    str_2 = 't'
    action_module_0 = ActionModule(str_0, str_1, str_2, str_1, str_0, str_2)


# Generated at 2022-06-25 07:32:36.006572
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    global str_0
    action_module_0 = ActionModule('t', str_0, 't', 't', 't', 't')
    tmp_0 = 't'
    task_vars_0 = {}
    result = action_module_0.run(tmp_0, task_vars_0)
    assert result == {'ansible_facts': {}, '_ansible_facts_cacheable': False, 'failed': True, 'msg': 'No key/value pairs provided, at least one is required for this action to succeed'}

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:32:43.511608
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tp_0 = ''
    task_vars_0 = {}
    action_module_0 = ActionModule(tp_0, tp_0, tp_0, tp_0, tp_0, tp_0)

    assert(action_module_0.run(tp_0, task_vars_0) == {'changed': False, 'ansible_facts': {u'foo': True, u'bar': False}, '_ansible_facts_cacheable': False})

# Generated at 2022-06-25 07:32:50.842442
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Inside testing, we can't create local plugins, just import them
    # TODO: fix this in Ansible
    import sys
    import os
    import imp
    import ansible.plugins.action

    MODULE_PATH = os.path.join(os.path.dirname(os.path.realpath(__file__)), "action_module_test.py")
    # Add the path of the test module to the import path
    sys.path.append( os.path.dirname( MODULE_PATH ) )
    module_obj = imp.load_source('ansible.plugins.action', MODULE_PATH)
    action_module_class = getattr(module_obj, 'ActionModule')
    test_case_0()

# Generated at 2022-06-25 07:32:55.966271
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Parameter tmp has its default value None
    # Parameter task_vars has its default value None
    try:
        ActionModule.run(None, None)
    except Exception as e:
        print('test_ActionModule_run Error:', e)
        assert False
    else:
        assert True

if __name__ == '__main__':
    test_case_0()

    # Test method run of class ActionModule
    test_ActionModule_run()

# Generated at 2022-06-25 07:33:05.713948
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_data = {
        '_ansible_remote_tmp': "tmp",
        '_ansible_no_log': False,
        '_ansible_keep_remote_files': False,
        '_ansible_verbosity': 1,
        '_ansible_version': 'v2.0.0.0.0.dev0',
        '_ansible_module_name': 'test',
        '_ansible_module_args': 'hello',
        '_ansible_socket_path': 'socket_path'
    }

    expected_result = {
        'ansible_facts': {
            'greeting': 'hello'
        },
        '_ansible_facts_cacheable': False
    }

    tr_temp = []
    tr_temp.append(str(0))
    tr_

# Generated at 2022-06-25 07:33:12.673843
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 't'
    str_1 = 't'
    str_2 = 't'
    str_3 = 't'
    str_4 = 't'
    str_5 = 't'
    tmp_0 = None
    task_vars_0 = None
    action_module_0 = ActionModule(str_0, str_1, str_2, str_3, str_4, str_5)
    result_0 = action_module_0.run(tmp_0, task_vars_0)
    assert (result_0 == {'_ansible_verbose_always': True, '_ansible_no_log': False, 'ansible_facts': {}, '_ansible_facts_cacheable': False})

# Generated at 2022-06-25 07:33:21.632329
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    from ansible.parsing.dataloader import DataLoader

    # check ActionBase.__init__()
    from ansible.plugins.action.normal import ActionModule
    assert ActionModule != None
    # check ActionBase.__init__()
    import os
    from ansible.parsing.dataloader import DataLoader
    str_0 = 't'
    dataloader_0 = DataLoader()
    str_1 = 'd'
    str_2 = 'a'
    action_module_0 = ActionModule(str_0, dataloader_0, str_1, str_2, str_1, str_1)

    assert action_module_0 != None

# unit test for method __init__

# Generated at 2022-06-25 07:33:29.986577
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass_0 = ActionModule()
    assert(pass_0) == None



# Generated at 2022-06-25 07:33:33.731588
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True == True

# Generated at 2022-06-25 07:33:41.805617
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(task=dict(args=dict(a=5, b=6, c='{{test_0}}', d='{{test_1}}', e=7)), connection=None)
    action_module._templar = Templar(loader=DataLoader())
    action_module._templar._available_variables = dict(test_0='aa', test_1='bb')
    result = action_module.run(tmp=None, task_vars=dict())
    assert result == dict(ansible_facts=dict(a=5, b=6, c='aa', d='bb', e=7), _ansible_facts_cacheable=False)


# Generated at 2022-06-25 07:33:47.224792
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None
    var_20 = None
    var_21 = None
    var_22 = None
    var_23 = None
    var_24 = None
    var_25 = None
    var_26 = None
    var_27 = None
    var_28 = None
    var_

# Generated at 2022-06-25 07:33:51.079452
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Verify that the method run does not fail
    class DummyVars(object):
        def __init__(self):
            self.value = None
    x = DummyVars()
    y = DummyVars()
    x.value = y
    y.value = 10
    ActionModule(x).run()
    assert True

# Generated at 2022-06-25 07:33:58.151258
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    v = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    var_1 = [None, None, None, None, None, None]
    var_2 = {}
    var_3 = {}
    var_1[0] = var_2
    var_1[1] = var_3
    var_1[2] = None
    var_1[3] = None
    var_1[5] = None
    var_4 = v.run(var_0, (*var_1[0:4], var_1[5]))

# Generated at 2022-06-25 07:34:01.284715
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_2 = None
    var_1 = ActionModule(var_2)


# Generated at 2022-06-25 07:34:08.391569
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = None
    var_2 = None
    test_instance = ActionModule(var_1, var_2)
    try:
        assert test_instance.run() == None
    except AssertionError as e:
        print(e)
        raise AssertionError("AssertionError")

if __name__ == "__main__":
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 07:34:14.999442
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # (1) Test: No arguments as dictionary k,v pairs.
    # Expected result: raise AnsibleActionFail('No key/value pairs provided, at least one is required for this action to succeed')
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None

    try:
        test_case_0()
    except AnsibleActionFail as e:
        assert str(e) == "No key/value pairs provided, at least one is required for this action to succeed", "should be: %s" % "No key/value pairs provided, at least one is required for this action to succeed"
    except:
        raise
    else:
        raise Exception("Malformed exception")

# Generated at 2022-06-25 07:34:17.968175
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(loader=None, templar=None, shared_loader_obj=None)
    assert action_module_0 is not None


# Generated at 2022-06-25 07:34:32.937713
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'J\x7fO\x1d\x84\xac~A\x8c\x1a\xf6\x16\x8c\x16\x17\x1f\r'
    str_0 = 'p^/cY\x0f\x8b'
    tuple_0 = (str_0,)
    bytes_1 = b'\x1a\x7f\x9a\x1e\x9e\x81\x19\xcc\x06\xb4\xdf\xf3\x9dI'
    float_0 = 3238.0233
    str_1 = 'b\x02\x14\xcc\x8c\x17\xcb'

# Generated at 2022-06-25 07:34:34.084158
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-25 07:34:37.582209
# Unit test for constructor of class ActionModule
def test_ActionModule():
    instance_0 = ActionModule()
    assert instance_0.run() == None


# Generated at 2022-06-25 07:34:48.155817
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xddk\x84\xae\x0e\x1d\xb1\xeb\xa0\x8a\x18C'
    str_0 = 'vK8@\xcb\x0eV\xec\x86'
    tuple_0 = (str_0,)
    bytes_1 = b'\xc3\xdf\xde\xe1J\x88\xbe\x02\x0e\x8c\xc4\xec\xad\x02\xd8\xad\xab\x96'
    float_0 = 889.260036
    str_1 = 'NQ\xfe\x17\x86\x9f\x80'

# Generated at 2022-06-25 07:34:53.459693
# Unit test for constructor of class ActionModule
def test_ActionModule():
	bytes_0 = b"D\x17'\xe6\xe1\x84</\x1e)?%\x89"
	str_0 = 'z^^CM}t\x0bUuw'
	tuple_0 = (str_0,)
	bytes_1 = b'8?6\x1ciS\xb5\xf6OO\x82\xec\xab\xdc\xd4>'
	float_0 = 3210.0304
	action_module_0 = ActionModule(bytes_0, tuple_0, bytes_1, float_0, str_0, str_0)
	assert action_module_0.transfers_files == False

# Generated at 2022-06-25 07:34:59.160874
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b"D\x17'\xe6\xe1\x84</\x1e)?%\x89"
    str_0 = 'z^^CM}t\x0bUuw'
    tuple_0 = (str_0,)
    bytes_1 = b'8?6\x1ciS\xb5\xf6OO\x82\xec\xab\xdc\xd4>'
    float_0 = 3210.0304
    action_module_0 = ActionModule(bytes_0, tuple_0, bytes_1, float_0, str_0, str_0)
    assert isinstance(action_module_0, ActionModule)

# Generated at 2022-06-25 07:35:00.568921
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # args
    tmp = None
    task_vars = None
    # ActionModule.run(tmp, task_vars)
    print('Not implemented yet')
    # return None
    return

# Generated at 2022-06-25 07:35:11.051540
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '#\x07\x85\xa4\xd8\xe4Ey\xc7'
    str_1 = '\x85\x1bfi\x1c\xb3\x9f\xdb\x06\x98\x94\xe8'
    bytes_0 = b"|\xbe\xc2\xf3\x18'\x0c\x04\xd1\xee\xcf\x97\x1f\xc9"
    dict_0 = {}
    dict_0['foo'] = 'bar'
    dict_0['baz'] = 'qux'
    dict_0['corge'] = None
    dict_0['grault'] = False
    dict_0['waldo'] = True
    dict_0['fred'] = 42
    dict_0

# Generated at 2022-06-25 07:35:12.722433
# Unit test for constructor of class ActionModule
def test_ActionModule():
  # test case, constructor of class ActionModule, should just pass
  test_case_0()


# Generated at 2022-06-25 07:35:20.986721
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(b"D\x17'\xe6\xe1\x84</\x1e)?%\x89", ('z^^CM}t\x0bUuw',), b'8?6\x1ciS\xb5\xf6OO\x82\xec\xab\xdc\xd4>', 3210.0304, 'z^^CM}t\x0bUuw', 'z^^CM}t\x0bUuw')


# Generated at 2022-06-25 07:35:40.122063
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b"D\x17'\xe6\xe1\x84</\x1e)?%\x89"
    str_0 = 'z^^CM}t\x0bUuw'
    tuple_0 = (str_0,)
    bytes_1 = b'8?6\x1ciS\xb5\xf6OO\x82\xec\xab\xdc\xd4>'
    float_0 = 3210.0304
    action_module_0 = ActionModule(bytes_0, tuple_0, bytes_1, float_0, str_0, str_0)
    assert action_module_0.input_file == bytes_0
    assert action_module_0.task_vars == tuple_0
    assert action_module_0.play_context == bytes_1


# Generated at 2022-06-25 07:35:41.513169
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:35:49.742428
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xc7\x00\x1b\xdd\x95'
    str_0 = 'r'
    float_0 = -1.0
    str_1 = 'c\x00\x14\x9c\xf5\x19\xb5\x14\xcf\x97#\x18\xca\x1e\x9f'
    action_module_0 = ActionModule(bytes_0, str_0, float_0, str_0, str_0, str_1)
    assert isinstance(action_module_0, ActionModule) == True
    assert str(action_module_0) == 'ActionModule'

if __name__ == "__main__":
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 07:35:50.667381
# Unit test for constructor of class ActionModule
def test_ActionModule():
  action_module_0 = ActionModule()

# Generated at 2022-06-25 07:35:51.308480
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:35:58.125754
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  args = {'cacheable': False}

  action = {}
  action['module_name'] = 'set_fact'
  action['module_args'] = args

  ansible = {}
  ansible['connection'] = 'connection'
  ansible['playbook_dir'] = 'playbook_dir'
  ansible['remote_user'] = 'remote_user'

  task = {}
  task['action'] = action
  task['ansible'] = ansible
  task['name'] = 'name'
  task['playbook_filename'] = 'playbook_filename'

  action_module = ActionModule(None, None, None, None, None, None)
  action_module._task = task
  action_module.task_vars = task_vars


# Generated at 2022-06-25 07:36:06.277629
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b"D\x17'\xe6\xe1\x84</\x1e)?%\x89"
    str_0 = 'z^^CM}t\x0bUuw'
    tuple_0 = (str_0,)
    bytes_1 = b'8?6\x1ciS\xb5\xf6OO\x82\xec\xab\xdc\xd4>'
    float_0 = 3210.0304
    action_module_0 = ActionModule(bytes_0, tuple_0, bytes_1, float_0, str_0, str_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:36:16.816613
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'F-\xd6\x1000\x1f\xe7\x8d\x85\x9c'
    str_0 = '\x03|\x1c\x87\x14\xcd\xdd\x9a\xcd\x96;'
    tuple_0 = (str_0,)
    bytes_1 = b'3\x9at\xe0\x01e\xb6\xe7\x1aC\x95\xa8\x96'
    float_0 = 7042.1
    str_1 = '\x06'
    action_module_0 = ActionModule(bytes_0, tuple_0, bytes_1, float_0, str_0, str_1)
    action_run(action_module_0)

# Unit test

# Generated at 2022-06-25 07:36:26.919024
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_2 = b"\xeav\xfc\x03\x84\xf8\xac\x13\xc0\xe0\x9e<\xab"
    str_1 = 'z^^CM}t\x0bUuw'
    tuple_1 = (str_1,)
    bytes_3 = b'8?6\x1ciS\xb5\xf6OO\x82\xec\xab\xdc\xd4>'
    float_1 = 3210.0304
    action_module_1 = ActionModule(bytes_2, tuple_1, bytes_3, float_1, str_1, str_1)


# Generated at 2022-06-25 07:36:31.286782
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:37:09.209423
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b"\x1a\x1c\x9d\x8a\xbc\xc5\xb7\x04\xa1\xbb\x17\x92\xe9\x8e\xbe\xc4\xd4\xbe\x0c\xa0"
    str_0 = '\x9a\x8an\x96\xbbJu\x01]\x8a\x0e\x93\x9f\xca\x14jq\x12\x82\x0c\x16'
    tuple_0 = (str_0,)

# Generated at 2022-06-25 07:37:19.397850
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  bytes_0 = b"D\x17'\xe6\xe1\x84</\x1e)?%\x89"
  str_0 = 'z^^CM}t\x0bUuw'
  tuple_0 = (str_0,)
  bytes_1 = b'8?6\x1ciS\xb5\xf6OO\x82\xec\xab\xdc\xd4>'
  float_0 = 3210.0304
  action_module_0 = ActionModule(bytes_0, tuple_0, bytes_1, float_0, str_0, str_0)
  var_0 = action_run()
  assert var_0 == 'success'

# Generated at 2022-06-25 07:37:21.653141
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True == True

# Unit test code for class ActionModule
if __name__ == '__main__':
    unittest.main()
    exit(0)

# Generated at 2022-06-25 07:37:32.870161
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x1c\xc1\x9b+\xddQ\x9c\x7f\x8c\x1f\x04\xbb\x9a\xdc"\x16\xbe\xf6'
    bytes_1 = b"\xcb\x04\x91\x97\x0b'\x82\x0c\x8b\x18\xe5\x0e_a\xfb\xd3\x9e\xb7"
    str_0 = 'f\x80r\xda\x97\x01\x1c\xba\xd1\xe8\x8c\x0f\x82\x97'
    int_0 = 0
    float_0 = 0.36
    action_module_0 = Action

# Generated at 2022-06-25 07:37:42.393730
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\x1d,\x0e\x87\x14\xb4\xa1\xb7\xaa\x0c\xfd$'
    tuple_0 = (str_0,)
    bytes_0 = b'z5\xb3\xde\xd2\xca\x7f\xcd\xeb\xfc\xd9\xe5'
    str_1 = 'z5\xb3\xde\xd2\xca\x7f\xcd\xeb\xfc\xd9\xe5'
    bytes_1 = b'\x19\xcc\x9f\x9a\xa4\xe4z\xd4\x1a\xea\x87\xbe\x89'
    float_0 = 7.9871
    str_

# Generated at 2022-06-25 07:37:52.461055
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b";i\xd6\xf8\x15\xe1\xdb\x05\xfd\xbb\xdd\x13\xf9\x95"
    str_0 = '\xde\x0f\x16Phl\xce\x95\x9bm\x1cY'
    tuple_0 = (str_0,)
    bytes_1 = b"k\x9c?\x1d\x8d\xfe\x00\x95\x16\x84\x90'\x11<\xde"
    float_0 = 71.24
    action_module_0 = ActionModule(bytes_0, tuple_0, bytes_1, float_0, str_0, str_0)
    tmp_0 = None
    task_vars_0

# Generated at 2022-06-25 07:37:55.148909
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    temp = tempfile_gettempdir()
    task_vars = dict()
    action_module_0 = ActionModule()
    var_0 = action_module_0.run(temp, task_vars)

# Generated at 2022-06-25 07:38:03.821523
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'RuX\x7f\x0b\xa4\x19\x1e\x1b\xb2\x92\xb4\x9f\xfdi\x98'
    str_0 = '+5\xd3,\xa3\x9cF\x9a\xee\xc4\x06'
    tuple_0 = (str_0,)
    bytes_1 = b'(tfJ\xee'
    float_0 = 1998.46
    action_module_0 = ActionModule(bytes_0, tuple_0, bytes_1, float_0, str_0, str_0)
    action_module_0.run()


# Generated at 2022-06-25 07:38:05.405316
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: Write a test for each branch of ActionModule.__init__
    assert False


# Generated at 2022-06-25 07:38:16.576398
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b"D\x17'\xe6\xe1\x84</\x1e)?%\x89"
    str_0 = 'z^^CM}t\x0bUuw'
    tuple_0 = (str_0,)
    bytes_1 = b'8?6\x1ciS\xb5\xf6OO\x82\xec\xab\xdc\xd4>'
    float_0 = 3210.0304
    action_module_0 = ActionModule(bytes_0, tuple_0, bytes_1, float_0, str_0, str_0)
    var_0 = {}
    var_0 = action_module_0.run(var_0)

if __name__ == '__main__':
    test_case_0()
    test_Action

# Generated at 2022-06-25 07:39:31.445440
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
    str_0 = 'ga~\x18f\xdf\xeb\x04}\xb9\xc9\x97m!\x13\x04\xe1\x00\r'
    tuple_0 = (str_0,)

# Generated at 2022-06-25 07:39:31.949611
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True == True

# Generated at 2022-06-25 07:39:40.037715
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Prepare test
    bytes_0 = b"D\x17'\xe6\xe1\x84</\x1e)?%\x89"
    str_0 = 'z^^CM}t\x0bUuw'
    tuple_0 = (str_0,)
    bytes_1 = b'8?6\x1ciS\xb5\xf6OO\x82\xec\xab\xdc\xd4>'
    float_0 = 3210.0304
    action_module_0 = ActionModule(bytes_0, tuple_0, bytes_1, float_0, str_0, str_0)
    var_0 = action_run()

    #
    #Run the code to be tested
    #

# Generated at 2022-06-25 07:39:42.946351
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Init a ActionModule obj
    var_0 = ActionModule(action_loader, connection, play_context, loader, templar, shared_loader_obj)
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()

# unit test for class ActionModule

# Generated at 2022-06-25 07:39:52.560287
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b"D\x17'\xe6\xe1\x84</\x1e)?%\x89"
    str_0 = 'z^^CM}t\x0bUuw'
    tuple_0 = (str_0,)
    bytes_1 = b'8?6\x1ciS\xb5\xf6OO\x82\xec\xab\xdc\xd4>'
    float_0 = 3210.0304
    action_module_0 = ActionModule(bytes_0, tuple_0, bytes_1, float_0, str_0, str_0)
    tmp = None
    task_vars = {'ansible_facts': {'fact_a': 'Default value'}}

# Generated at 2022-06-25 07:39:58.320334
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule('', '', '', 213.3, '', '')
    str_0 = 'A-q3\x13\xba\xeb\x04\x12\x11M\xf5\x06\xc9'
    dict_0 = dict()
    dict_0[str_0] = str_0
    var_1 = ActionModule.run('', dict_0)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:40:01.012733
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #Call to action_run module
    action_module_0 = ActionModule()
    #Checks if the action_run module is isinstance of class ActionModule
    assert isinstance(action_module_0, ActionModule)

# Generated at 2022-06-25 07:40:04.718127
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = bytes()
    var_1 = tuple()
    var_2 = bytes()
    float_0 = float()
    str_0 = str()
    str_1 = str()
    action_module_0 = ActionModule(var_0, var_1, var_2, float_0, str_0, str_1)


# Generated at 2022-06-25 07:40:09.667803
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'g\x88\xba\xab\xe8\xd7\xed\x9d\x9c\xf8?\xd6'
    str_0 = 'os.W8&vU6g]{:SX'
    tuple_0 = (str_0,)
    bytes_1 = b'\xeb#\xf5\xc5\x9d\x04\xb5\x06\x18\x94\xa5\x8d\xe4\x9f'
    float_0 = 2512.0592
    action_module_0 = ActionModule(bytes_0, tuple_0, bytes_1, float_0, str_0, str_0)
    dict_0 = dict()
    dict_0['cacheable'] = False

# Generated at 2022-06-25 07:40:18.484789
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_2 = b"D\x17'\xe6\xe1\x84</\x1e)?%\x89"
    str_1 = 'z^^CM}t\x0bUuw'
    tuple_1 = (str_1,)
    bytes_3 = b'8?6\x1ciS\xb5\xf6OO\x82\xec\xab\xdc\xd4>'
    float_1 = 3210.0304
    action_module_1 = ActionModule(bytes_2, tuple_1, bytes_3, float_1, str_1, str_1)
    assert action_module_1._play_context.remote_addr == str_1
    assert action_module_1._task.action == str_1