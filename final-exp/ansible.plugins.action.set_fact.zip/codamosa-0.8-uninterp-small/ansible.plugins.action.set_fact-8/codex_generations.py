

# Generated at 2022-06-25 07:31:17.431094
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True
#test_ActionModule()


# Generated at 2022-06-25 07:31:21.073664
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = dict()
    dict_1 = dict()

    action_module_0 = ActionModule(tmp=dict_0, task_vars=dict_1)

    task_vars = dict()

    result = action_module_0.run(tmp=None, task_vars=task_vars)
    assert result == {}
    assert result == {}

test_ActionModule_run()

# Generated at 2022-06-25 07:31:24.611349
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = None
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    int_0 = None
    float_0 = None
    str_0 = 'ran %s:'
    action_module_0 = ActionModule(bool_0, dict_0, bool_0, int_0, float_0, str_0)
    task_vars = {bool_0: bool_0, bool_0: bool_0}
    tmp = None
    assert action_module_0.run(task_vars=task_vars, tmp=tmp) == dict_0


# Generated at 2022-06-25 07:31:34.604041
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = None
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    int_0 = None
    float_0 = None
    str_0 = 'ran %s:'
    action_module_0 = ActionModule(bool_0, dict_0, bool_0, int_0, float_0, str_0)
    action_module_0.module_name = bool_0
    dict_4 = dict_0
    action_module_0.module_default_args = dict_0
    action_module_0.action = bool_0
    action_module_0.action_loader = bool_0
    action_module_0.display = bool_0
    action_module_0.task = bool_0
    action_module_0.task_vars = dict_

# Generated at 2022-06-25 07:31:36.636819
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = dict()

    # Test with empty dict for 'tmp' parameter
    test_case_0(dict_0)

    # Test with empty dict for 'task_vars' parameter
    test_case_0(dict_0)

# Generated at 2022-06-25 07:31:45.420375
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = int(False)
    dict_0 = {bool_0: bool_0}
    int_0 = 0
    float_0 = int(0.7)
    str_0 = 'p'
    action_module_0 = ActionModule(bool_0, dict_0, bool_0, int_0, float_0, str_0)
    result = action_module_0.run('/tmp/ansible_test/c', {'dict_0': 0})
    assert result['ansible_facts'] == {}
    assert result['_ansible_facts_cacheable'] == False
    assert result['_ansible_no_log'] == False

# Generated at 2022-06-25 07:31:48.005204
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(None, None, False, None, None, None)
    action_module_0.run(None, None)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:31:49.981195
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:31:59.184593
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test_case_0
    (bool_0, dict_0, int_0, float_0, str_0) = (None, {None: None, None: None}, None, None, 'ran %s:')
    action_module_0 = ActionModule(bool_0, dict_0, bool_0, int_0, float_0, str_0)
    #assert action_module_0.task == dict_0
    #assert action_module_0.connection == bool_0
    #assert action_module_0.play_context == bool_0
    #assert action_module_0.loader == int_0
    #assert action_module_0.templar == float_0
    #assert action_module_0.shared_loader_obj == str_0

# Generated at 2022-06-25 07:32:04.704072
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = None
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    int_0 = None
    float_0 = None
    str_0 = 'ran %s:'
    # __init__(self, connection=C.DEFAULT_TRANSPORT, tmp=C.DEFAULT_LOCAL_TMP, sudo_user=C.DEFAULT_SUDO_USER, sudoable=C.DEFAULT_SUDOABLE, become_user=C.DEFAULT_BECOME_USER, verbosity=C.DEFAULT_VERBOSITY)
    action_module_0 = ActionModule(bool_0, dict_0, bool_0, int_0, float_0, str_0)



# Generated at 2022-06-25 07:32:16.712575
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = None
    int_0 = -2534
    list_0 = [int_0, int_0, int_0, int_0]
    list_1 = [list_0]
    int_1 = 864
    float_0 = 875.617593
    tuple_0 = (float_0, list_1)
    str_0 = 'bash'
    set_0 = set()
    action_module_0 = ActionModule(list_1, int_1, int_0, tuple_0, str_0, set_0)

# Generated at 2022-06-25 07:32:18.902916
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # no input, test with zero and non zero values
    action_module_0 = ActionModule()

if __name__ == '__main__':
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 07:32:28.021688
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -2534
    list_0 = [int_0, int_0, int_0, int_0]
    list_1 = [list_0]
    int_1 = 864
    float_0 = 875.617593
    tuple_0 = (float_0, list_1)
    str_0 = 'bash'
    set_0 = set()
    action_module_0 = ActionModule(list_1, int_1, int_0, tuple_0, str_0, set_0)
    action_module_1 = ActionModule(list_0, int_0, int_1, tuple_0, str_0, set_0)
    action_module_2 = ActionModule(list_0, int_0, int_1, tuple_0, str_0, set_0)


# Generated at 2022-06-25 07:32:35.928444
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create instance of class
    action_module_0 = ActionModule()
    # Attribute '_task' of class ActionModule has wrong type
    assert isinstance(action_module_0._task, Task)
    # Attribute '_connection' of class ActionModule has wrong type
    assert isinstance(action_module_0._connection, LocalConnection)
    # Attribute '_play_context' of class ActionModule has wrong type
    assert isinstance(action_module_0._play_context, PlayContext)
    # Attribute '_loader' of class ActionModule has wrong type
    assert isinstance(action_module_0._loader, DataLoader)
    # Attribute '_templar' of class ActionModule has wrong type
    assert isinstance(action_module_0._templar, Templar)
    # Attribute '_shared_loader_

# Generated at 2022-06-25 07:32:38.964830
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print(ActionModule.run())


# Generated at 2022-06-25 07:32:39.921678
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert 1 == 1

# Generated at 2022-06-25 07:32:46.954046
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test case 0
    list_0 = [str_0, str_1, str_2, str_3, str_4]
    int_0 = 553
    int_1 = 553
    tuple_0 = (str_4, list_0, list_1, int_1, str_3)
    str_0 = 'apt-get'
    str_1 = '-y'
    str_2 = 'install'
    str_3 = 'doxygen'
    str_4 = 'name'
    set_0 = set()
    int_2 = -1238
    list_1 = [int_2, int_2, int_2]
    action_module_0 = ActionModule(list_0, int_0, int_0, tuple_0, str_0, set_0)

# Generated at 2022-06-25 07:32:48.686954
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert isinstance(ActionModule.run(), dict)


# Generated at 2022-06-25 07:32:49.654597
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert test_ActionModule_run() == 3


# Generated at 2022-06-25 07:32:56.101114
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -2534
    list_0 = [int_0, int_0, int_0, int_0]
    list_1 = [list_0]
    int_1 = 864
    float_0 = 875.617593
    tuple_0 = (float_0, list_1)
    str_0 = 'bash'
    set_0 = set()
    action_module_0 = ActionModule(list_1, int_1, int_0, tuple_0, str_0, set_0)
    assert action_module_0 != None


# Generated at 2022-06-25 07:33:04.666397
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:33:05.851308
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
    print("OK")
    
test_ActionModule()

# Generated at 2022-06-25 07:33:09.018228
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    assert action_module_1.action_name == 'action_module'


# Generated at 2022-06-25 07:33:17.498191
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -2534
    list_0 = [int_0, int_0, int_0, int_0]
    list_1 = [list_0]
    int_1 = 864
    float_0 = 875.617593
    tuple_0 = (float_0, list_1)
    str_0 = 'bash'
    set_0 = set()
    action_module_0 = ActionModule(list_1, int_1, int_0, tuple_0, str_0, set_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:33:22.979750
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = [float_0, float_0, float_0]
    int_0 = -1195
    int_1 = 538
    tuple_0 = (str_0, bool_0)
    str_0 = 'eK$'
    set_0 = set()
    action_module_0 = ActionModule(list_0, int_0, int_1, tuple_0, str_0, set_0)
    var_0 = test_case_0()
    assert(var_0 == var_0)
    

# Generated at 2022-06-25 07:33:28.436436
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -2534
    list_0 = [int_0, int_0, int_0, int_0]
    list_1 = [list_0]
    int_1 = 864
    float_0 = 875.617593
    tuple_0 = (float_0, list_1)
    str_0 = 'bash'
    set_0 = set()
    action_module_0 = ActionModule(list_1, int_1, int_0, tuple_0, str_0, set_0)
    var_0 = action_module_0.run()
    assert var_0 is None

# Generated at 2022-06-25 07:33:31.769187
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -2534
    list_0 = [int_0, int_0, int_0, int_0]
    list_1 = [list_0]
    int_1 = 864
    float_0 = 875.617593
    tuple_0 = (float_0, list_1)
    str_0 = 'bash'
    set_0 = set()
    action_module_0 = ActionModule(list_1, int_1, int_0, tuple_0, str_0, set_0)
    return action_module_0


# Generated at 2022-06-25 07:33:41.493516
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = ['var_0', 'var_0', 'var_0', 'var_0']
    int_0 = 676
    int_1 = 703
    float_0 = 775.556672
    tuple_0 = (float_0, list_0)
    str_0 = 'bash'
    set_0 = set()
    action_module_0 = ActionModule(list_0, int_0, int_1, tuple_0, str_0, set_0)
    var_0 = action_module_0.run()
    var_0 = action_module_0.run()
    var_0 = action_run()


# Generated at 2022-06-25 07:33:42.638405
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()
    return


# Generated at 2022-06-25 07:33:49.704984
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -2147483648
    list_0 = [int_0, int_0, int_0, int_0]
    int_1 = 0
    list_1 = [int_1]
    str_0 = 'home'
    action_module_0 = ActionModule(list_1, int_1, int_0, list_0, str_0, list_0)


# Generated at 2022-06-25 07:34:08.733453
# Unit test for constructor of class ActionModule
def test_ActionModule():
    with pytest.raises(AnsibleActionFail):
        _args = [[0,0,0,0], 0, 0, (0, [[0,0,0,0]]), 'bash',set()]
        assert isinstance(ActionModule(*_args), ActionModule) == True

# Generated at 2022-06-25 07:34:10.488917
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except Exception as err:
        exception_holder.exception = err


# Generated at 2022-06-25 07:34:17.885122
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -2534
    list_0 = [int_0, int_0, int_0, int_0]
    list_1 = [list_0]
    int_1 = 864
    float_0 = 875.617593
    tuple_0 = (float_0, list_1)
    str_0 = 'bash'
    set_0 = set()
    action_module_0 = ActionModule(list_1, int_1, int_0, tuple_0, str_0, set_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:34:27.543307
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -202
    list_0 = [int_0, int_0, int_0, int_0]
    list_1 = [list_0]
    int_1 = 593
    float_0 = 557.762647
    tuple_0 = (float_0, list_1)
    str_0 = 'bash'
    set_0 = set()
    action_module_0 = ActionModule(list_1, int_1, int_0, tuple_0, str_0, set_0)
    var_0 = action_module_run()



# Generated at 2022-06-25 07:34:28.903232
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	test_case_0()

# Generated at 2022-06-25 07:34:29.415363
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case from above
    test_case_0()

# Generated at 2022-06-25 07:34:36.498871
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -2534
    list_0 = [int_0, int_0, int_0, int_0]
    list_1 = [list_0]
    int_1 = 864
    float_0 = 875.617593
    tuple_0 = (float_0, list_1)
    str_0 = 'bash'
    set_0 = set()
    action_module_0 = ActionModule(list_1, int_1, int_0, tuple_0, str_0, set_0)
    action_module_0.run()

# Generated at 2022-06-25 07:34:37.260435
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement this test
    pass

# Generated at 2022-06-25 07:34:47.851075
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -3816
    list_0 = [int_0, int_0, int_0, int_0]
    list_1 = [list_0]
    int_1 = 738
    float_0 = 759.826377
    tuple_0 = (float_0, list_1)
    str_0 = 'python'
    set_0 = set()
    action_module_0 = ActionModule(list_1, int_1, int_0, tuple_0, str_0, set_0)
    bool_0 = test_case_0()
    bool_1 = boolean(bool_0)
    bool_2 = test_case_0()
    bool_3 = boolean(bool_2)
    bool_4 = test_case_0()

# Generated at 2022-06-25 07:34:51.976494
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = True
    var_1 = 3.8242082
    var_2 = []
    var_3 = (var_1, var_2)
    var_4 = 'opqrs'
    var_5 = set()
    # Test default
    action_module_0 = ActionModule(var_2, var_1, var_0, var_3, var_4, var_5)
    assert action_module_0.TRANSFERS_FILES == False



# Generated at 2022-06-25 07:35:31.461598
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Define some variables
    tmp = None
    task_vars = None
    # Assign values for the variables
    tmp = None
    task_vars = None
    try:
        # Call the run() method
        result = action_module_0.run(tmp=tmp, task_vars=task_vars)
        # Check if the expected result is obtained
        assert result in [True, False]
    except Exception:
        # In case of exception, check if the corresponding exception is raised
        raise
    finally:
        # Destroy the objects
        del(action_module_0)
        del(tmp)
        del(task_vars)

# Generated at 2022-06-25 07:35:32.402127
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:35:40.704522
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Variable: list_0
    int_0 = -2534
    list_0 = [int_0, int_0, int_0, int_0]
    # Variable: list_1
    list_1 = [list_0]
    # Variable: int_1
    int_1 = 864
    # Variable: float_0
    float_0 = 875.617593
    # Variable: tuple_0
    tuple_0 = (float_0, list_1)
    # Variable: str_0
    str_0 = 'bash'
    # Variable: set_0
    set_0 = set()
    # -------------------------------------------------------------
    # This test makes sure that the constructor is callable without error.

# Generated at 2022-06-25 07:35:49.645018
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_2 = -611
    list_2 = [int_2, int_2, int_2, int_2]
    list_3 = [list_2]
    int_3 = 723
    float_1 = 728.672394
    tuple_1 = (float_1, list_3)
    str_1 = 'sh'
    set_1 = set()
    action_module_1 = ActionModule(list_3, int_3, int_2, tuple_1, str_1, set_1)
    assert isinstance(action_module_1, ActionModule)


# Generated at 2022-06-25 07:35:57.128974
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -2534
    list_0 = [int_0, int_0, int_0, int_0]
    list_1 = [list_0]
    int_1 = 864
    float_0 = 875.617593
    tuple_0 = (float_0, list_1)
    str_0 = 'bash'
    set_0 = set()
    action_module_0 = ActionModule(list_1, int_1, int_0, tuple_0, str_0, set_0)
    action_module_0.run(None, None)
    action_module_0.debug = False
    action_module_0.run(None, None)
    action_module_0.run(None, None)
    action_module_0.run(None, None)
    action_

# Generated at 2022-06-25 07:36:05.290558
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -2534
    list_0 = [int_0, int_0, int_0, int_0]
    tuple_0 = (int_0, int_0, list_0)
    list_1 = [list_0]
    int_1 = 864
    float_0 = 875.617593
    tuple_1 = (float_0, list_1)
    str_0 = 'bash'
    set_0 = set()
    action_module_0 = ActionModule(list_1, int_1, int_0, tuple_1, str_0, set_0)

# Generated at 2022-06-25 07:36:11.344547
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    cacheable = False
    tmp = None
    task_vars = None
    int_0 = -2534
    list_0 = [int_0, int_0, int_0, int_0]
    list_1 = [list_0]
    int_1 = 864
    float_0 = 875.617593
    tuple_0 = (float_0, list_1)
    str_0 = 'bash'
    set_0 = set()
    action_module_0 = ActionModule(list_1, int_1, int_0, tuple_0, str_0, set_0)
    action_module_0.run(tmp, task_vars)
    assert_equal(action_module_0._task.args, cacheable)

# Generated at 2022-06-25 07:36:13.645681
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0.ACTION_VERSION == '2.0'
    assert action_module_0.BYPASS_HOST_LOOP == False
    assert action_module_0.BYPASS_SAFE_PATHS == True
    assert action_module_0.NO_LOG == False
    assert action_module_0.TRANSFERS_FILES == False
    assert action_module_0.VALID_ARGS == {}


# Generated at 2022-06-25 07:36:18.728577
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -2534
    list_0 = [int_0, int_0, int_0, int_0]
    list_1 = [list_0]
    int_1 = 864
    float_0 = 875.617593
    tuple_0 = (float_0, list_1)
    str_0 = 'bash'
    set_0 = set()
    action_module_0 = ActionModule(list_1, int_1, int_0, tuple_0, str_0, set_0)

# Generated at 2022-06-25 07:36:19.678695
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:37:37.094106
# Unit test for constructor of class ActionModule
def test_ActionModule():
  try:
    action_module_0 = ActionModule()
  except:
    var_0 = False
    var_0 = True
  return var_0


# Generated at 2022-06-25 07:37:46.495990
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -2534
    list_0 = [int_0, int_0, int_0, int_0]
    list_1 = [list_0]
    int_1 = 864
    float_0 = 875.617593
    tuple_0 = (float_0, list_1)
    str_0 = 'bash'
    set_0 = set()
    action_module_0 = ActionModule(list_1, int_1, int_0, tuple_0, str_0, set_0)
    var_0 = action_run()



# Generated at 2022-06-25 07:37:55.463454
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_2 = -2534
    list_2 = [int_2, int_2, int_2, int_2]
    list_3 = [list_2]
    int_3 = 864
    float_1 = 875.617593
    tuple_1 = float_1, list_3
    str_1 = 'bash'
    set_1 = set()
    action_module_1 = ActionModule(list_3, int_3, int_2, tuple_1, str_1, set_1)
    # Calls method run of class ActionModule, with parameters tmp=None, task_vars=None, then returns value of attribute _ansible_parsed_results
    int_4 = -2534
    list_4 = [int_4, int_4, int_4, int_4]
    list

# Generated at 2022-06-25 07:37:56.037344
# Unit test for constructor of class ActionModule
def test_ActionModule():
  pass

# Generated at 2022-06-25 07:38:03.208205
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test method run from class ActionModule
    # Case 1

    list_0 = [0, 0, 0, 0]
    list_1 = [list_0]
    str_0 = 'bash'
    tuple_0 = (291.634014, list_1)
    set_0 = set()
    action_module_0 = ActionModule(list_1, 864, -2534, tuple_0, str_0, set_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 07:38:05.181097
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    action_module_0 = ActionModule(tmp, task_vars)
    tmp = None  # tmp no longer has any effect
    var_0 = action_run()


# Generated at 2022-06-25 07:38:07.120242
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:38:17.887486
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -2534
    list_0 = [int_0, int_0, int_0, int_0]
    list_1 = [list_0]
    int_1 = 864
    float_0 = 875.617593
    tuple_0 = (float_0, list_1)
    str_0 = 'bash'
    set_0 = set()
    action_module_0 = ActionModule(list_1, int_1, int_0, tuple_0, str_0, set_0)
    var_0 = action_module_0.run()
    for key in var_0:
        print(key,end=" : ")
        try:
            print(key.getter())
        except:
            print("None")
    return var_0

# Generated at 2022-06-25 07:38:26.153368
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -2534
    list_0 = [int_0, int_0, int_0, int_0]
    list_1 = [list_0]
    int_1 = 864
    float_0 = 875.617593
    tuple_0 = (float_0, list_1)
    str_0 = 'bash'
    set_0 = set()
    action_module_0 = ActionModule(list_1, int_1, int_0, tuple_0, str_0, set_0)
    result = action_module_0.run()
    assert isinstance(result, dict), "Return type of ActionModule.run() is not a dictionary"
    assert len(result) == 2, "Size of dictionary returned from ActionModule.run() is incorrect"

# Generated at 2022-06-25 07:38:31.128898
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -8545
    list_0 = [int_0]
    int_1 = 3159
    float_0 = 5384.46
    tuple_0 = (float_0)
    str_0 = 'bash'
    set_0 = set()
    action_module_0 = ActionModule(list_0, int_1, int_0, tuple_0, str_0, set_0)
    assert action_module_0 is not None
