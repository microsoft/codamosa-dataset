

# Generated at 2022-06-25 07:31:22.586760
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -657
    set_0 = {int_0, int_0}
    list_0 = [int_0]
    str_0 = 'ppc8260'
    bytes_0 = None
    dict_0 = {set_0: bytes_0, bytes_0: bytes_0, str_0: int_0}
    name = 'X'
    action_module_0 = ActionModule(set_0, int_0, set_0, list_0, str_0, dict_0)
    tmp = None
    task_vars = dict()
    result = action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 07:31:27.722714
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(list_0, int_0, set_0, list_0, str_0, dict_0)
    assert action_module_0._templar.template(str_0) == 'ppc8260'

# Generated at 2022-06-25 07:31:35.120339
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -963854461624833617

# Generated at 2022-06-25 07:31:43.279373
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -657
    set_0 = {int_0, int_0}
    list_0 = [int_0]
    str_0 = 'ppc8260'
    bytes_0 = None
    dict_0 = {set_0: bytes_0, bytes_0: bytes_0, str_0: int_0}
    action_module_0 = ActionModule(set_0, int_0, set_0, list_0, str_0, dict_0)
    del set_0
    del list_0
    (tmp, task_vars) = action_module_0.run(dict_0, dict_0)
    
    

# Generated at 2022-06-25 07:31:48.920641
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -657
    set_0 = {int_0, int_0}
    list_0 = [int_0]
    str_0 = 'ppc8260'
    bytes_0 = None
    dict_0 = {set_0: bytes_0, bytes_0: bytes_0, str_0: int_0}
    action_module_0 = ActionModule(set_0, int_0, set_0, list_0, str_0, dict_0)

    # call the method
    action_module_0.run(set_0, dict_0)

# Generated at 2022-06-25 07:31:51.169840
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:31:52.199201
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not test_case_0()


# Generated at 2022-06-25 07:31:58.409868
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -657
    set_0 = {int_0, int_0}
    list_0 = [int_0]
    str_0 = 'ppc8260'
    bytes_0 = None
    dict_0 = {set_0: bytes_0, bytes_0: bytes_0, str_0: int_0}
    action_module_0 = ActionModule(set_0, int_0, set_0, list_0, str_0, dict_0)


# Generated at 2022-06-25 07:32:04.144504
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import os
    import sys
    from ansible.module_utils.six import PY3
    from ansible.module_utils.basic import AnsibleModule

    if PY3 or os.environ.get('TEST_ANSIBLE_PYTHON_VERSION', '2.7') != '2.6':
        from ansible.module_utils.six import iteritems

    test_cases = [0]
    for test_case in test_cases:
        func = globals().get('test_case_{0}'.format(test_case))
        if func:
            func()

# Generated at 2022-06-25 07:32:06.065384
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except ActionFail as exception_0:
        ret = False
    else:
        ret = True
    assert ret

# Generated at 2022-06-25 07:32:14.598837
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None

    task_vars = dict()


# Generated at 2022-06-25 07:32:21.490851
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -963854461624833617
    int_1 = -9187806074236151431
    int_2 = -3158185829951642192
    int_3 = -9087176430441974476
    int_4 = -9007199254740990
    int_5 = -9207298452766174768
    int_6 = -9007199254740992
    int_7 = -9187806074236151431
    int_8 = -9087176430441974476
    int_9 = -9007199254740990
    dict_0 = {}
    int_10 = -3158185829951642192
    int_11 = -9207298452766174768

# Generated at 2022-06-25 07:32:23.501421
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actModule = ActionModule()
    int_0 = -963854461624833617


# Generated at 2022-06-25 07:32:29.552713
# Unit test for constructor of class ActionModule
def test_ActionModule():
    my_dict = {}
    a_int = 17
    my_dict["a_int"] = a_int
    ansible_module_path = "ansible.module_utils.basic.AnsibleModule"
    module_args = {}
    module_args["module_path"] = ansible_module_path
    ansible_module = ActionModule(my_dict, module_args)

    ansible_facts = my_dict
    ansible_module._task = ansible_facts
    ansible_module._task.args = {}
    ansible_module._task.args["module_path"] = ansible_module_path
    ansible_module._task.args["condition"] = "condition"
    ansible_module._task.args["fail_key"] = "fail_key"

# Generated at 2022-06-25 07:32:39.056190
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -8909046846392874751
    int_1 = -55
    int_2 = 0
    int_3 = -15
    str_0 = 'GvV8Wk1Tp9@TfT{Zo'
    str_1 = 'TAwQo!s~s?1YdY\'JX'
    str_2 = '}PQa4:q'
    str_3 = '\t`|'
    str_4 = 'xRd4m'
    str_5 = 'Hello World!'
    str_6 = 'Y'
    str_7 = 'T'
    str_8 = '#0/z|'
    str_9 = 'Y'
    str_10 = 'a'

# Generated at 2022-06-25 07:32:41.125921
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    if isinstance(action_module_0, object):
        assert True
    else:
        assert False


# Generated at 2022-06-25 07:32:41.840671
# Unit test for constructor of class ActionModule
def test_ActionModule():
    instance0 = ActionModule()


# Generated at 2022-06-25 07:32:44.007539
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -963854461624833617
    dict_0 = dict()
    module_0 = ActionModule(dict_0, int_0)
    module_0.run()

# Generated at 2022-06-25 07:32:49.656636
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Input parameters
    tmp = None
    task_vars = dict()

    # Execute the run method
    test_instance = ActionModule()
    test_instance.run(tmp, task_vars)

# Generated at 2022-06-25 07:32:52.237895
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -963854461624833617
    ActionModule_run_instance = ActionModule()

    assert(ActionModule_run_instance.run(int_0) == None)


# Generated at 2022-06-25 07:33:06.081722
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    arg_dict_0 = {'color': 'green', 'time': 'now', 'timestamp': 'today'}
    arg_bool_0 = True
    jinja2_native_0 = 'hello world'
    bool_0 = False
    template_0 = 'hello world'
    action_module_0 = ActionModule()
    bool_1 = True
    action_base_0 = ActionBase()
    k0 = 'hello world'
    template_1 = 'hello world'
    v0 = 'hello world'
    action_module_1 = ActionModule()
    action_module_2 = ActionModule()
    arg_dict_1 = {}
    bool_3 = False
    bool_4 = False
    int_0 = -963854461624833617

# Generated at 2022-06-25 07:33:10.462491
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False # WIP


# Generated at 2022-06-25 07:33:12.157619
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a module.
    test_case_0()


# Generated at 2022-06-25 07:33:21.572772
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -77
    int_1 = 1
    int_2 = 1
    int_3 = 1
    int_4 = 1
    int_0 = -926203947995977315
    action_module_object = ActionModule(None, None, None, None, None)
    int_1 = -1
    int_0 = -547
    int_0 = -6
    str_0 = '6c9>6'
    str_1 = 'Qe'
    int_2 = -3
    int_3 = -2
    int_4 = 2
    int_5 = -1
    int_6 = -791
    int_0 = action_module_object.run(None, None)
    int_1 = -1
    str_0 = '8Z'
    str

# Generated at 2022-06-25 07:33:24.810547
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -963854461624833617


# Generated at 2022-06-25 07:33:31.221548
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test 1 - with correct args
    test_args_1 = {'foo': 'bar'}
    test_obj_1 = ActionModule(test_args_1)
    int_1 = test_obj_1.run()

    # Test 2 - with extra args
    test_args_2 = {'baz': 50}
    test_args_2['foo'] = 'bar'
    test_obj_2 = ActionModule(test_args_2)
    int_2 = test_obj_2.run()

    # Test 3 - with proper inputs to get method
    test_args_3 = {'foo': 'bar'}
    test_obj_3 = ActionModule(test_args_3)
    str = 'ayy'
    bool = True
    str_2 = 'lmao'
    int = 3


# Generated at 2022-06-25 07:33:33.880110
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-25 07:33:34.982098
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()


# Generated at 2022-06-25 07:33:43.709921
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -5468152984452034761
    int_1 = -1839791326231710253
    int_2 = -4695712851059371547
    int_3 = -125256523824302964
    template_data_0 = {}
    template_data_0['key'] = 'value'
    template_data_1 = {}
    template_data_1['key'] = 'othervalue'
    template_data_2 = {}
    template_data_2['key'] = 1024
    template_data_3 = {}
    template_data_3['key'] = True
    template_data_4 = {}
    template_data_4['key'] = 'value'
    template_data_5 = {}
    template_data_5['key'] = 'othervalue'

# Generated at 2022-06-25 07:33:45.898280
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 07:33:58.953861
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "z\tMjobb'1 f"
    tuple_0 = ()
    float_0 = -291.0
    str_1 = '>K&\tWx+PS+{v'
    str_2 = 'dest'
    int_0 = 250
    float_1 = 0.5
    dict_0 = {tuple_0: str_0, tuple_0: str_1, tuple_0: str_2}
    action_module_0 = ActionModule(str_1, str_2, int_0, float_1, str_0, dict_0)
    var_0 = action_run()
    complex_0 = None
    action_module_1 = ActionModule(str_0, tuple_0, tuple_0, float_0, str_0, complex_0)

# Generated at 2022-06-25 07:34:08.470195
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test for constructor of class ActionModule
    str_0 = "p\nP)tN'Y"
    tuple_0 = (str_0,)
    float_0 = 546.0
    str_1 = 'r\r,nPm$RX"\r'
    str_2 = 'url'
    int_0 = 1
    float_1 = 0.5
    dict_0 = {tuple_0: str_0, tuple_0: str_1, tuple_0: str_2}
    tuple_1 = ()
    # test for class constructor
    action_module_0 = ActionModule(str_1, str_2, int_0, float_1, str_0, dict_0)


# Generated at 2022-06-25 07:34:15.449110
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'ruP|7,>G2c}a'
    tuple_0 = (56.0, '0')
    float_0 = -39.75
    str_1 = 'z;!*'
    str_2 = 'should be a dictionary'
    int_0 = -45
    float_1 = 1.5
    dict_0 = {tuple_0: str_0, tuple_0: str_1, tuple_0: str_2, tuple_0: str_0}
    action_module_0 = ActionModule(str_1, str_2, int_0, float_1, str_0, dict_0)
    assert action_module_0.module_name == 'debug'
    assert action_module_0.module_args == 'should be a dictionary'
    assert action_module

# Generated at 2022-06-25 07:34:20.799620
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'P4yf`'
    tuple_0 = ()
    str_1 = '*W8\t9`'
    str_2 = 'src'
    int_0 = 352
    float_0 = 0.0
    dict_0 = {tuple_0: str_0, tuple_0: str_1, tuple_0: str_2}
    action_module_0 = ActionModule(str_1, str_2, int_0, float_0, str_0, dict_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:34:24.102938
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = dict()
    dict_1 = dict()
    int_0 = 74
    float_0 = 0.2
    str_0 = 'k$zdCVB'
    str_1 = 'I!MPh9Y'
    dict_2 = dict()
    action_module_0 = ActionModule(dict_0, dict_1, int_0, float_0, str_0, str_1)
    return None


# Generated at 2022-06-25 07:34:32.928565
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = ''
    tuple_0 = ()
    float_0 = 0.0
    str_1 = ''
    int_0 = 0
    float_1 = 0.0
    dict_0 = {}
    action_module_0 = ActionModule(str_1, str_0, int_0, float_1, str_0, dict_0)
    action_module_0.set_task_vars(tuple_0)
    action_module_0.set_loader(str_1)
    action_module_0.set_shared_loader_obj(str_0)
    action_module_0.set_variable_manager(float_0)
    str_2 = 'dest'
    action_module_0.set_play_context(str_2)
    action_module_0.set_loader

# Generated at 2022-06-25 07:34:41.151499
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "ek1^B55'6"
    str_1 = 'F=L\tIz$o'
    tuple_0 = (complex(0, 6), int(46), str_0, str_1)
    complex_0 = 2.0173727893764708
    tuple_1 = (str_0, tuple_0, str_1, tuple_0, str_1, int(46))
    tuple_2 = (str_0, tuple_0, str_1, tuple_0, str_1, int(46))
    tuple_3 = ('O]o\r7r',)
    tuple_4 = ((str_1, tuple_2, str_0), int(191), complex(0, 7), str_1, str_0)

# Generated at 2022-06-25 07:34:50.878992
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "^\tYD;Bx*%'!l"
    tuple_0 = ()
    tuple_1 = ()
    float_0 = -76.0
    str_1 = 'p 4&{'
    str_2 = 'dest'
    int_0 = 70
    float_1 = 0.1
    dict_0 = {tuple_1: str_0, tuple_1: str_1, tuple_1: str_2}
    action_module_0 = ActionModule(str_0, tuple_0, int_0, float_1, str_0, dict_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:34:59.983457
# Unit test for constructor of class ActionModule
def test_ActionModule():

    dict_0 = dict()
    dict_1 = dict()
    int_0 = 250
    float_0 = 0.5
    str_0 = "z\tMjobb'1 f"
    str_1 = '>K&\tWx+PS+{v'
    str_2 = 'dest'
    tuple_0 = ()
    tuple_1 = ()
    tuple_2 = ()
    # Note: the local variable 'dict_0' is declared but never used. It has been kept for consistency with the other unit test(s)

    class_0 = None
    class_1 = None
    dict_0 = {tuple_0: str_0, tuple_0: str_1, tuple_0: str_2}

# Generated at 2022-06-25 07:35:01.705496
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_1 = {'bool_0': True}
    dict_0 = {'dict_0': dict_1}
    action_module_0 = ActionModule(dict_1, dict_1, dict_0, dict_0, dict_0, dict_0)


# Generated at 2022-06-25 07:35:15.283546
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "z\tMjobb'1 f"
    tuple_0 = ()
    float_0 = -291.0
    str_1 = '>K&\tWx+PS+{v'
    str_2 = 'dest'
    int_0 = 250
    float_1 = 0.5
    dict_0 = {tuple_0: str_0, tuple_0: str_1, tuple_0: str_2}
    action_module_0 = ActionModule(str_1, str_2, int_0, float_1, str_0, dict_0)
    var_0 = action_run()
    complex_0 = None
    action_module_1 = ActionModule(str_0, tuple_0, tuple_0, float_0, str_0, complex_0)



# Generated at 2022-06-25 07:35:24.533915
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "1"
    str_1 = 'dest'
    int_0 = 348
    float_0 = 0.011270626539
    str_2 = 'MSUT9|0Ik<_/'
    list_0 = []
    action_module_0 = ActionModule(str_2, str_1, int_0, float_0, str_0, list_0)
    action_module_0.run()

    tuple_0 = ()
    str_3 = "z\tMjobb'1 f"
    tuple_1 = (0,)
    dict_0 = {tuple_0: str_3, tuple_0: str_3, tuple_1: str_2}

# Generated at 2022-06-25 07:35:32.809180
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "z\tMjobb'1 f"
    tuple_0 = ()
    float_0 = -291.0
    str_1 = '>K&\tWx+PS+{v'
    str_2 = 'dest'
    int_0 = 250
    float_1 = 0.5
    dict_0 = {tuple_0: str_0, tuple_0: str_1, tuple_0: str_2}
    action_module_0 = ActionModule(str_1, str_2, int_0, float_1, str_0, dict_0)
    var_0 = action_run()
    complex_0 = None
    action_module_1 = ActionModule(str_0, tuple_0, tuple_0, float_0, str_0, complex_0)



# Generated at 2022-06-25 07:35:40.902003
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Input arguments testing
    str_0 = ">|U6QZ"
    str_1 = 'T\\"@!\t{w'
    str_2 = 'tmp'
    float_0 = 0.2
    dict_0 = {str_1: str_2, str_1: float_0, str_2: float_0}
    float_1 = 0.6
    tuple_0 = ()
    int_0 = -217
    action_module_0 = ActionModule(str_2, str_2, int_0, float_1, str_1, dict_0)
    # Output testing
    assert(action_module_0)
    str_3 = "2hx$~G"
    str_4 = 'tmp'

# Generated at 2022-06-25 07:35:49.741574
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with valid parameters
    action_module_0 = ActionModule('foo', 'bar', 1, 120.0, 'baz', {'foo': 'bar'})
    result = action_module_0.run()
    assert result['ansible_facts'] == {'foo': 'bar'}
    assert result['_ansible_facts_cacheable'] is False
    assert result['changed'] is False

    # Test with cacheable
    action_module_1 = ActionModule('foo', 'bar', 1, 120.0, 'baz', {'foo': 'bar'})
    result = action_module_1.run(cacheable=True)
    assert result['ansible_facts'] == {'foo': 'bar'}
    assert result['_ansible_facts_cacheable'] is True
    assert result['changed'] is False

# Generated at 2022-06-25 07:35:52.167486
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert issubclass(ActionModule, ActionBase)
    action_module_0 = ActionModule(None, None, None, None, None, None)
    int_0 = action_module_0.run()

# Generated at 2022-06-25 07:35:55.195014
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('\n[Test]')
    print('[Test]', 'id_0' in globals(), 'module' in globals())
    if 'id_0' in globals():
        test_case_0()

if __name__ == '__main__':
    test()

# Generated at 2022-06-25 07:35:57.152221
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing ActionModule")

    print("Testing constructor")
    test_case_0()

# Unit tests for methods of class ActionModule

# Generated at 2022-06-25 07:35:58.947877
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()



# Generated at 2022-06-25 07:36:08.000076
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "impossible"
    tuple_1 = (241.0, '#,~', 1.3888349999999999e+270, 0.0, int_0)
    dict_0 = {'b': str_2, str_2: 'b', str_1: int_0, tuple_0: '\u0004h'}
    tuple_0 = (None, 1, tuple_1)
    str_1 = 'Pc]'
    tuple_2 = (float_0, 0.1, float_0, float_0, float_0, float_0, float_0, float_0, float_1)
    action_module_1 = ActionModule('module_name', tuple_0, int_0, float_1, str_0, dict_0)
    assert action_module_1._find

# Generated at 2022-06-25 07:36:36.492478
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_1 = ':r\r,MZ\r5M5m,l'
    str_2 = 'source'
    int_0 = -2
    float_0 = -1.0
    str_0 = "N(y+D(_.K'n"
    list_0 = [1.0, 2.0]
    action_module_0 = ActionModule(str_2, str_0, int_0, float_0, str_0, list_0)
    assert action_module_0._task.args["cacheable"] == 1
    action_module_1 = ActionModule(str_2, str_0, int_0, float_0, str_1, list_0)
    assert action_module_1._task.args["cacheable"] == 1

# Generated at 2022-06-25 07:36:38.927825
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # No exception raised, then the test passes
    try:
        test_case_0()
    except Exception as e:
        assert False, e.message
    else:
        assert True

# Generated at 2022-06-25 07:36:42.271747
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Unit tests for run() of class ActionModule

# Generated at 2022-06-25 07:36:50.122072
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_2 = -67.0
    float_3 = -44.0
    str_4 = '+;m'
    dict_0 = {}
    action_module_0 = ActionModule(dict_0, dict_0, dict_0, dict_0, dict_0, dict_0)
    str_5 = ',<wG7W'
    int_1 = -111
    dict_1 = {}
    str_6 = 'K@'
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {str_6: float_2, str_6: float_2, str_6: float_3}

# Generated at 2022-06-25 07:36:59.268431
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:37:09.863075
# Unit test for constructor of class ActionModule
def test_ActionModule():
    
    # Run test_case_0
    test_case_0()
    # _run() method : test_case_0()
    
    # Run test_case_1
    test_case_1()
    # _run() method : test_case_1()
    
    # Run test_case_2
    test_case_2()
    # _run() method : test_case_2()
    
    # Run test_case_3
    test_case_3()
    # _run() method : test_case_3()
    
    # Run test_case_4
    test_case_4()
    # _run() method : test_case_4()
    
    # Run test_case_5
    test_case_5()

# _run() method : test_case_0()

# Generated at 2022-06-25 07:37:19.941698
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = ">K&\tWx+PS+{v"
    tuple_0 = ()
    float_0 = 3.0
    complex_0 = None
    str_1 = 'dest'
    str_2 = 'z\tMjobb\'1 f'
    int_0 = 250
    float_1 = 0.5
    dict_0 = {tuple_0: str_2, tuple_0: str_0, tuple_0: str_1}
    action_module_0 = ActionModule(str_0, str_1, int_0, float_1, str_2, dict_0)
    action_module_1 = ActionModule(str_0, tuple_0, tuple_0, float_0, str_2, complex_0)

# Generated at 2022-06-25 07:37:30.280103
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "z\tMjobb'1 f"
    tuple_0 = ()
    float_0 = -291.0
    str_1 = '>K&\tWx+PS+{v'
    str_2 = 'dest'
    int_0 = 250
    float_1 = 0.5
    dict_0 = {tuple_0: str_0, tuple_0: str_1, tuple_0: str_2}
    action_module_0 = ActionModule(str_1, str_2, int_0, float_1, str_0, dict_0)
    str_3 = "{'_ansible_tmpdir': 'tmp', 'ansible_facts': {'_ansible_parsed': True, 'changed': True, 'failed': False}}"

# Generated at 2022-06-25 07:37:30.775733
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-25 07:37:31.202579
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  pass

# Generated at 2022-06-25 07:38:12.592683
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "*"
    str_1 = "A"
    int_0 = -11
    float_0 = -2.23
    dict_0 = {str_0: str_1, str_0: str_1, str_0: str_1}
    action_module_0 = ActionModule(str_1, str_1, int_0, float_0, str_1, dict_0)


# Generated at 2022-06-25 07:38:16.214259
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '2iOKHxq3b^v`'
    int_0 = -232
    action_module_0 = ActionModule(str_0, int_0)


# Generated at 2022-06-25 07:38:19.028343
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {'a': 'b', 'c': 'd'}
    action_module_0 = ActionModule('a', 'b', 100, 0.0, 'c', dict_0)
    assert action_module_0.run() == 'ok'

# Generated at 2022-06-25 07:38:27.739001
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '_0'
    tuple_0 = ()
    float_0 = 20.9
    str_1 = 'VpH5Rkz@+p!1Y.'
    str_2 = 'exists'
    int_0 = 79
    float_1 = -73.7
    dict_0 = {str_0: tuple_0, str_0: tuple_0, str_0: tuple_0}
    action_module_0 = ActionModule(str_0, str_2, int_0, float_1, str_0, dict_0)
    var_0 = action_run()
    list_0 = []
    action_module_1 = ActionModule(tuple_0, str_1, int_0, float_0, str_1, list_0)
    action_module_1

# Generated at 2022-06-25 07:38:28.543771
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:38:36.840618
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "z\tMjobb'1 f"
    tuple_0 = ()
    float_0 = -291.0
    str_1 = '>K&\tWx+PS+{v'
    str_2 = 'dest'
    int_0 = 250
    float_1 = 0.5
    dict_0 = {tuple_0: str_0, tuple_0: str_1, tuple_0: str_2}
    action_module_0 = ActionModule(str_1, str_2, int_0, float_1, str_0, dict_0)
    action_module_0.run()
    action_module_0.run(action_module_0._task.args)
    str_3 = '_raw_params'

# Generated at 2022-06-25 07:38:44.573791
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    float_0 = 0.07273306684798078
    str_0 = 'tIdB\t=\x7f}#tdbj>|'
    str_1 = '4-k\n'
    action_module_0 = ActionModule(str_0, tuple_0, tuple_0, float_0, str_1, str_0)
    assert type(action_module_0) == ActionModule


# Generated at 2022-06-25 07:38:47.213399
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1.0
    str_0 = "fzp7V J\x00"
    action_module_0 = ActionModule(str_0, float_0, str_0, str_0, str_0, str_0)

# Generated at 2022-06-25 07:38:52.640962
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_3 = "1dMt1\t{\tM"
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()
    bool_10 = bool()
    bool_11 = bool()
    bool_12 = bool()
    bool_13 = bool()
    bool_14 = bool()
    bool_15 = bool()
    bool_16 = bool()
    bool_17 = bool()
    bool_18 = bool()
    bool_19 = bool()
    bool_20 = bool()
    bool_21 = bool()

# Generated at 2022-06-25 07:38:57.957488
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '_\x1a1\tT$gW'
    tuple_1 = (())
    int_0 = 0
    dict_0 = {}
    str_1 = ''
    dict_1 = {str_0: tuple_1, str_1: int_0}
    action_module_0 = ActionModule(str_1, str_0, int_0, tuple_1, (()), dict_1)
    tmp = "J"
    task_vars = {'A': str_1, str_0: tuple_1, str_1: tuple_1}
    var_0 = action_module_0.run(tmp, task_vars)
    str_2 = ''
    str_3 = ''

# Generated at 2022-06-25 07:40:48.985521
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "KHN:d-}"
    tuple_0 = ()
    float_0 = 2.12
    str_1 = "TeR\t=E)|Db1h"
    str_2 = "Y\"'{X*xH^"
    int_0 = 375
    float_1 = -0.0
    dict_0 = {str_1: float_0, tuple_0: float_1, tuple_0: float_0}
    action_module_0 = ActionModule(str_1, str_2, int_0, float_1, str_0, dict_0)
    action_module_0.run()


# Generated at 2022-06-25 07:40:55.496155
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "host"
    tuple_0 = ()
    float_0 = -291.0
    str_1 = '>K&\tWx+PS+{v'
    str_2 = 'dest'
    int_0 = 250
    float_1 = 0.5
    dict_0 = {tuple_0: str_0, tuple_0: str_1, tuple_0: str_2}
    dict_1 = {str_0: tuple_0}
    action_module_0 = ActionModule(str_1, str_2, int_0, float_1, str_0, dict_0)
    action_module_0.run(dict_1, dict_0)
    str_3 = "dest"

# Generated at 2022-06-25 07:41:02.032583
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'x\x03\x1d6Mw^\x1b'
    int_0 = 250
    tuple_0 = ()
    float_1 = 0.5
    str_1 = ''
    str_2 = 'src'
    float_0 = -291.0
    str_3 = '[=6\x10%P&^]W'
    str_4 = 'dest'
    complex_0 = None
    action_module_1 = ActionModule(str_0, tuple_0, int_0, float_1, str_1, complex_0)
    action_module_0 = ActionModule(str_3, str_0, tuple_0, float_0, str_2, str_4)
    var_0 = action_run()


# Generated at 2022-06-25 07:41:09.344387
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "4c%'{Z76L*<F"
    str_1 = 'R/y\x7fY`n&t'
    int_0 = 447
    float_0 = -0.3
    str_2 = 'T.T\r'
    dict_0 = {str_0: str_1, str_1: int_0, str_2: float_0}
    # call constructor
    action_module_0 = ActionModule(str_2, str_0, int_0, float_0, str_2, dict_0)
    del action_module_0
    action_module_1 = ActionModule(str_0, str_0, float_0, float_0, str_0, float_0)


# Generated at 2022-06-25 07:41:15.522262
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # NOTE: test case 0 is a special value, needed to make the tests run on Python 2 & 3
    global action_run, dict_0, int_0, float_0, float_1, str_0, str_1, str_2, tuple_0, complex_0
    if test_case_0 == 0:
        # Set action_run
        action_run = ActionModule.run
        # Set dict_0
        dict_0 = dict()
        # Set int_0
        int_0 = 0
        # Set float_0
        float_0 = 0.0
        # Set float_1
        float_1 = 0.0
        # Set str_0
        str_0 = str()
        # Set str_1
        str_1 = str()
        # Set str_2
        str_2 = str()