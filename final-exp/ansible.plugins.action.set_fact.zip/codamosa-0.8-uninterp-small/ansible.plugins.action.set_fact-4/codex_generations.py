

# Generated at 2022-06-25 07:31:24.240010
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'I'
    set_0 = {str_0, str_0}
    bool_0 = True
    action_module_0 = ActionModule(str_0, str_0, str_0, set_0, bool_0, set_0)
    str_1 = 'I'
    str_2 = 'I'
    action_module_0.module_vars = {str_1: str_2}
    str_3 = '`'
    str_4 = '`'
    dict_0 = {str_3: str_4}
    set_1 = {str_3, str_3}
    bool_1 = True
    action_module_0 = ActionModule(str_3, str_3, str_3, set_1, bool_1, dict_0)
    set_

# Generated at 2022-06-25 07:31:28.837498
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert callable(ActionModule)

if __name__ == "__main__":
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 07:31:32.964470
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '`7<uH~'
    set_0 = {str_0, str_0}
    bool_0 = True
    action_module_0 = ActionModule(str_0, str_0, str_0, set_0, bool_0, set_0)


# Generated at 2022-06-25 07:31:37.946407
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = {'e', '', 'bk_l'}
    str_0 = '0Wx!vHy>w'
    # str_1 = ''
    action_module_0 = ActionModule(str_0, str_0, str_0, set_0, False, set_0)
    set_0 = {'tm`Y9i', 'fL#', 'NQ1-'}
    bool_0 = True
    action_module_0 = ActionModule(str_0, str_0, str_0, set_0, bool_0, set_0)
    # test_case_0()

test_ActionModule()

# Generated at 2022-06-25 07:31:46.624932
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'X'
    set_0 = {str_0, str_0}
    bool_0 = False
    action_module_0 = ActionModule(str_0, str_0, str_0, set_0, bool_0, set_0)
    str_1 = '7W1-ZTvw7oi'
    dict_0 = action_module_0.run(str_1)
    assert(dict_0['ansible_facts'] == {})

# Generated at 2022-06-25 07:31:50.974669
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {'values': 'False', 'X': 'False', 'Y': 'False'}
    action_module_0 = ActionModule('test', dict_0, dict_0)
    dict_1 = {'Y': 'False', 'X': 'False'}
    str_0 = 'Hello World'
    action_module_0.run(str_0, dict_1)

# Generated at 2022-06-25 07:31:56.678287
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # setUp
    str_0 = '\rs[s`s2E'
    set_0 = {str_0, str_0}
    bool_0 = True
    action_module_0 = ActionModule(str_0, str_0, str_0, set_0, bool_0, set_0)
    # tearDown
    del action_module_0

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:32:00.568568
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\rs[s`s2E'
    set_0 = {str_0, str_0}
    bool_0 = True
    action_module_0 = ActionModule(str_0, str_0, str_0, set_0, bool_0, set_0)

test_case_0()
test_ActionModule()

# Generated at 2022-06-25 07:32:07.471234
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # str_0 is defined in the enclosing scope
    set_0 = {str_0, str_0}
    bool_0 = True
    action_module_0 = ActionModule(str_0, str_0, str_0, set_0, bool_0, set_0)
    assert True

if __name__ == "__main__":
    # Unit test for constructor of class ActionModule
    test_ActionModule()

    # Unit test for method run of class ActionModule
    def test_run():
        str_0 = '\rs[s`s2E'
        set_0 = {str_0, str_0}
        bool_0 = True
        action_module_0 = ActionModule(str_0, str_0, str_0, set_0, bool_0, set_0)
        action_

# Generated at 2022-06-25 07:32:13.483446
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '<q_!Sv!8Ep'
    set_0 = {str_0, str_0}
    bool_0 = True
    action_module_0 = ActionModule(str_0, str_0, str_0, set_0, bool_0, set_0)
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 07:32:21.999366
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = bool()
    bool_0 = test_case_0()
# End of unit test for method run of class ActionModule

# Generated at 2022-06-25 07:32:33.952886
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    assert action_module.action == 'set_fact'
    assert action_module.TRANSFERS_FILES == False
    assert action_module.args == {}
    assert action_module.delegate_to == 'localhost'
    assert action_module.delegate_facts == False
    assert action_module.notify == []
    assert action_module.poll == 0
    assert action_module.run_once == False
    assert action_module.set_fact == {}
    assert action_module.sudo == False
    assert action_module.sudo_user == None
    assert action_module.tags == ['always']
    assert action_module.transport == 'smart'
    assert action_module.when == []
    assert action_module.warn == True

    # This is for multi-task testing


# Generated at 2022-06-25 07:32:45.480862
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # what goes in returns another_thing
    input_dict = {"what": "goes", "in": "returns", "another_thing": "fooba"}
    test_module = ActionModule()
    test_module._task = {"args": input_dict, "cacheable": True}
    test_module._templar = input_dict

    # what will go in as expected
    expected_dict = {"what": "goes", "in": "returns", "another_thing": "fooba"}

    # The result is the same as expected
    assert (test_module.run(None, None)["ansible_facts"] == expected_dict)

    # The is_change result is the same as expected
    assert (test_module.run(None, None)["is_changed"] == False)

    # The ansible_facts_cache

# Generated at 2022-06-25 07:32:47.981625
# Unit test for constructor of class ActionModule
def test_ActionModule():
  assert True == True


# Generated at 2022-06-25 07:32:49.249114
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert test_case_0()

# Generated at 2022-06-25 07:32:50.164624
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:32:51.067901
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 07:32:54.957940
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class_instance = ActionModule()
    passed = "passed"
    tmp = "tmp"
    task_vars = {passed: passed}
    result = class_instance.run(tmp, task_vars)
    assert result["ansible_facts"] == {passed: passed}
    assert result["_ansible_facts_cacheable"] == False

# Generated at 2022-06-25 07:32:59.465665
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a Mock object from the class defined above
    mock_ActionModule = MockActionModule()

    # add_host expects 3 arguments: task, tmp and task_vars
    result = mock_ActionModule.run("/tmp/ansible_test", "{'ansible_ssh_user': 'testuser', 'ansible_python_interpreter': '/usr/bin/python2.7'}")

    assert result['ansible_facts'] == {'test_var': 'Hello world'}
    assert result['_ansible_facts_cacheable'] == True


# Generated at 2022-06-25 07:32:59.958536
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True

# Generated at 2022-06-25 07:33:14.611357
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'users'
    str_1 = 'ansible_os_family=RedHat'
    str_2 = 'distributor_id'
    str_3 = 'E\rs[8s`s2E'
    set_0 = {str_2, str_2}
    bool_0 = False
    action_module_0 = ActionModule(str_0, str_1, str_3, set_0, bool_0, set_0)
    assert_equals(action_module_0.task, str_0)
    assert_equals(action_module_0.task_vars, str_1)
    assert_equals(action_module_0.module_args, str_3)
    assert_equals(action_module_0.module_name, set_0)

# Generated at 2022-06-25 07:33:23.270806
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule('my_action')
    assert isinstance(action_module_0, ActionModule)
    # TODO need to change action_module_0 to right type
    # assert action_module_0.name == 'my_action'
    # assert action_module_0.connection == 'local'
    # assert action_module_0.async_val == 0
    # assert action_module_0.poll == 0
    # assert action_module_0.transport == 'smart'
    # assert action_module_0.noop_on_check(True) is True
    # assert action_module_0.validate(None, None) is False
    # assert action_module_0.succeeded is True
    # assert action_module_0.add_cleanup_task() is None
   

# Generated at 2022-06-25 07:33:24.696362
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:33:28.287708
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'distributor_id'
    str_1 = 'E\rs[8s`s2E'
    set_0 = {str_0, str_0}
    bool_0 = False
    action_module_0 = ActionModule(str_0, str_0, str_1, set_0, bool_0, set_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:33:31.494313
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  str_0 = 'cQvC^s{sP'
  str_1 = 'iO~OriOb'
  set_0 = {str_0, str_1}
  bool_0 = False
  action_module_0 = ActionModule(str_0, str_0, str_0, set_0, bool_0, set_0)
  var_0 = action_run()

# Generated at 2022-06-25 07:33:39.430044
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'distributor_id'
    str_1 = 'E\rs[8s`s2E'
    set_0 = {str_0, str_0}
    bool_0 = False
    action_module_0 = ActionModule(str_0, str_0, str_1, set_0, bool_0, set_0)
    var_1 = action_run()
    assert var_1 == None


# Generated at 2022-06-25 07:33:42.734109
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'distributor_id'
    str_1 = 'E\rs[8s`s2E'
    set_0 = {str_0, str_0}
    bool_0 = False
    action_module_0 = ActionModule(str_0, str_0, str_1, set_0, bool_0, set_0)

# Generated at 2022-06-25 07:33:44.747691
# Unit test for constructor of class ActionModule
def test_ActionModule():
  assert 1 == 1

# Generated at 2022-06-25 07:33:47.404928
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print()
    print('Default Arguments:')
    test_case_0()
    print()
    print('All Cases:')

# Generated at 2022-06-25 07:33:51.809758
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'distributor_id'
    str_1 = 'E\rs[8s`s2E'
    set_0 = {str_0, str_0}
    bool_0 = False
    action_module_0 = ActionModule(str_0, str_0, str_1, set_0, bool_0, set_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:34:08.562006
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    str_0 = 'module_name'
    str_1 = 'E\rs[8s`s2E'
    bool_0 = False
    set_0 = {str_0, str_0}
    action_module_0.ActionBase(str_0, str_0, str_1, set_0, bool_0, set_0)
    str_2 = 'compiled_templar'
    str_3 = 'E\rs[8s`s2E'
    str_4 = 'task_vars'
    map_0 = {str_4, str_3}
    str_5 = 'env'
    map_1 = {str_5, str_3}
    str_6 = 'task_include_vars'

# Generated at 2022-06-25 07:34:09.757244
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:34:19.778143
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    def _run(self, tmp=None, task_vars=None):

        if task_vars is None:
            task_vars = dict()

        result = super(ActionModule, self).run(tmp, task_vars)
        del tmp  # tmp no longer has any effect

        facts = {}
        cacheable = boolean(self._task.args.pop('cacheable', False))

        if self._task.args:
            for (k, v) in iteritems(self._task.args):
                k = self._templar.template(k)

                if not isidentifier(k):
                    raise AnsibleActionFail("The variable name '%s' is not valid. Variables must start with a letter or underscore character, "
                                            "and contain only letters, numbers and underscores." % k)

                # NOTE: this

# Generated at 2022-06-25 07:34:28.939970
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'distributor_id'
    str_1 = 'E\rs[8s`s2E'
    set_0 = {str_0, str_0}
    bool_0 = False
    action_module_0 = ActionModule(str_0, str_0, str_1, set_0, bool_0, set_0)
    if 'ansible_facts' in action_module_0._task.args:
        raise AssertionError()
    if 'distributor_id' not in action_module_0._task.args:
        raise AssertionError()
    str_2 = ':c%|<(b&{mm>d=Mh~M'
    str_3 = '?'
    set_1 = {str_1, str_2, str_2}
   

# Generated at 2022-06-25 07:34:38.339973
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'x'
    str_1 = ':e'
    str_2 = 'centos'
    set_0 = {str_0, str_0}
    bool_0 = False
    action_module_0 = ActionModule(str_0, str_0, str_1, set_0, bool_0, set_0)
    tmp = {}
    task_vars = {}
    num_0 = action_module_0.run(tmp=tmp, task_vars=task_vars)
    tmp = {}
    task_vars = {str_0: str_2}
    num_1 = action_module_0.run(tmp=tmp, task_vars=task_vars)
    tmp = {}
    task_vars = {str_0: str_2}
    num

# Generated at 2022-06-25 07:34:41.997440
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'C\x1a,'
    str_1 = 'C\x1a,'
    set_0 = {str_0, str_0}
    bool_0 = False
    action_module_0 = ActionModule(str_0, str_0, str_1, set_0, bool_0, set_0)
    result_1 = ActionModule_run()

# Python code to parse test case descriptions

# Generated at 2022-06-25 07:34:48.635299
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test for constructor of ActionModule
    str_0 = 'distributor_id'
    str_1 = 'E\rs[8s`s2E'
    set_0 = {str_0, str_0}
    bool_0 = False
    action_module_0 = ActionModule(str_0, str_0, str_1, set_0, bool_0, set_0)


# Generated at 2022-06-25 07:34:57.471512
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '`s4s1s9s@s#s#s#s%s'
    str_1 = '_s]s2s2s8sTs~s\s0s2s2s7s~s1s+s1sAsAs'
    set_0 = {str_0, '`s4s1s9s@s#s#s#s%s', '`s4s1s9s@s#s#s#s%s'}
    bool_0 = True
    action_module_0 = ActionModule(str_0, '`s4s1s9s@s#s#s#s%s', str_1, set_0, bool_0, set_0)


# Generated at 2022-06-25 07:34:58.867494
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True == True

# Generated at 2022-06-25 07:35:03.568385
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'distributor_id'
    str_1 = 'E\rs[8s`s2E'
    set_0 = {str_0, str_0}
    bool_0 = False
    action_module_0 = ActionModule(str_0, str_0, str_1, set_0, bool_0, set_0)



# Generated at 2022-06-25 07:35:32.307486
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '$!@8!9*c%Q!\x1bx\x1d\x0e\x1cC%c!' # not a valid identifier
    dict_0 = {str_0: 'some-value'}
    str_0 = 'playbook.yml'
    str_1 = 'u\x1d\x1a\x0ft\x1f\x1d\x0e\x1e'
    set_0 = {str_0, str_0}
    bool_0 = False
    action_module_0 = ActionModule(str_0, str_0, str_1, set_0, bool_0, set_0)
    ansible_action_fail_0 = None

# Generated at 2022-06-25 07:35:37.457178
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '0[sVs6>s\x1dEsSsEsSs'
    str_1 = 'E\rs[8s`s2E'
    set_0 = {str_0, str_0}
    bool_0 = False
    action_module_0 = ActionModule(str_0, str_0, str_1, set_0, bool_0, set_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:35:44.080518
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_arg_spec = {}
    action_module_0 = ActionModule(action_module_arg_spec)
    task_vars_value = None
    action_module_0.run(task_vars=task_vars_value)


# Generated at 2022-06-25 07:35:50.704512
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'E\rs[8s`s2E'
    str_1 = 'E\rs[8s`s2E'
    str_2 = 'E\rs[8s`s2E'
    set_0 = {str_0, str_1}
    bool_0 = False
    set_1 = {str_2, str_1}
    action_module_0 = ActionModule(str_0, str_1, str_2, set_0, bool_0, set_1)


# Generated at 2022-06-25 07:35:52.755533
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # This test is executed only if the constructor does not fail (this is not an expected behavior)
    action_module_0 = ActionModule("", {}, {}, {}, {}, True)

# Generated at 2022-06-25 07:35:56.724489
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'distributor_id'
    str_1 = 'E\rs[8s`s2E'
    set_0 = {str_0, str_0}
    bool_0 = False
    action_module_0 = ActionModule(str_0, str_0, str_1, set_0, bool_0, set_0)
    var_0 = action_run()

if __name__ == "__main__":
    main()

# Generated at 2022-06-25 07:36:06.662474
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'distributor_id'
    str_1 = 'E\rs[8s`s2E'
    str_2 = 'ansible_facts'
    tuple_0 = ()
    set_0 = {str_0, str_0}
    bool_0 = False
    set_1 = {str_0}
    action_module_0 = ActionModule(str_0, str_0, tuple_0, set_0, bool_0, set_1)
    assert action_module_0.TRANSFERS_FILES == False
    bool_1 = action_module_0.bypass_checks()
    assert bool_1 == True
    str_3 = 'system'
    str_4 = 'redhat'

# Generated at 2022-06-25 07:36:12.022906
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  assert type(result) is dict
  assert result == {'ansible_facts': {u'distributor_id': u'E\rs[8s`s2E'}, '_ansible_facts_cacheable': False}

# Generated at 2022-06-25 07:36:12.585270
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 07:36:15.038011
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO
    return None

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 07:37:03.965981
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {}
    ansible_facts = ActionModule(task_vars)
    assert ansible_facts.run()

# Generated at 2022-06-25 07:37:08.252331
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'distributor_id'
    str_1 = 'E\rs[8s`s2E'
    set_0 = {str_0, str_0}
    bool_0 = False
    action_module_0 = ActionModule(str_0, str_0, str_1, set_0, bool_0, set_0)
    var_0 = action_run()
    assert var_0 == 'E\rs[8s`s2E'


# Generated at 2022-06-25 07:37:14.943504
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '{'
    set_0 = {str_0, str_0, str_0}
    action_module_0 = ActionModule(str_0, str_0, str_0, set_0, True, set_0)
    action_module_0.name = str_0
    action_module_0.action = str_0
    action_module_0.display = str_0
    action_module_0.args = set_0
    var_0 = set_0
    set_1 = set_0
    action_module_0.task_vars = set_1
    action_module_0.module_vars = set_0
    action_module_0.module_vars = var_0
    action_module_0.module_vars = set_1
    var_1

# Generated at 2022-06-25 07:37:23.290043
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Zs\n,sEs2[s<sEs4sRs@s/sAs;s!s/sBs'
    str_1 = 's[s2s'
    set_0 = {str_0, str_0, str_1}
    bool_0 = False
    action_module_0 = ActionModule(str_0, str_0, str_1, set_0, bool_0, set_0)
    var_0 = action_run(task_vars)

# Generated at 2022-06-25 07:37:32.108169
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class MockEmptyClass:
        class MockActionBase:
            def run(self, *args):
                return self.run(*args)
        class MockActionModule:
            def __init__(self, *args):
                return self.__init__(*args)
    action_module_0 = MockEmptyClass.MockActionModule()
    action_run = MockEmptyClass.MockActionBase()
    run_1 = action_run.run
    run_1 = action_module_0.run
    action_module_0_1 = type(action_module_0)
    the_type = str
    assert isinstance(action_module_0, action_module_0_1) == True
    assert isinstance(action_module_0, the_type) == False

# Generated at 2022-06-25 07:37:42.314956
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_3 = 'pkg\x7f_identifier'
    str_4 = 'y\x1a\x1a\x1a'
    bool_1 = False
    set_1 = {str_3, str_4, bool_1}
    set_2 = {str_4, str_4, str_4}
    action_module_1 = ActionModule(str_4, str_3, str_3, set_1, str_3, set_2)
    var_0 = action_run()
    if action_module_1._task.args:
        str_2 = '<module>'
        str_5 = 'False'
        str_6 = 'False'
        str_7 = 'False'
        str_8 = 'False'
        str_9 = 'False'
        str_

# Generated at 2022-06-25 07:37:43.374831
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    del action_module_0


# Generated at 2022-06-25 07:37:48.485983
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    name = 'var_0'
    value = 'foo'
    action_module_0 = ActionModule(name, value, name, set(), False, set())
    assert action_module_0._task.args == name

# Generated at 2022-06-25 07:37:59.208478
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_1 = 'f%&(n'
    str_2 = '$aA{2'
    str_3 = '~.d64'
    str_4 = '[~*p3Z'
    set_0 = {str_2, str_2}
    char_0 = 'z'
    str_5 = 'ZH'
    set_1 = {str_5, str_5}
    set_2 = {str_4, str_4}
    str_6 = 'S#_'
    set_3 = {str_4, str_4}
    set_4 = {str_6, str_6}
    set_5 = {str_3, str_3}
    set_6 = {str_5, str_5}
    bool_0 = bool()

# Generated at 2022-06-25 07:38:05.130157
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # There are two steps to test the constructor of class ActionModule
    # 1. Make an object ActionModule and assign it to variable t
    # 2. Verify that the variable t refers to an object of type ActionModule

    # Step 1
    # We expect the constructor to throw an exception with improper inputs
    # We will cover the cases where it does not first
    try:
        t = ActionModule(str_0, str_0, str_1, set_0, bool_0, set_0)
    except:
        pass

    # Step 2
    # We will use the isinstance method to verify the type of the object
    assert(isinstance(var_0, ActionModule))


# Generated at 2022-06-25 07:39:56.472317
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'el7.x86_64'
    str_1 = '2.7.11'
    str_2 = '2.7.9'
    str_3 = '7.3.1611'
    str_4 = '7.6.1810'
    str_5 = 'CentOS'
    str_6 = '7.6.1810'
    set_0 = {str_0, str_0}
    bool_0 = False
    action_module_0 = ActionModule(str_0, str_0, set_0, set_0, bool_0, set_0)

# Generated at 2022-06-25 07:40:00.724144
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'distributor_id'
    str_1 = 'E\rs[8s`s2E'
    set_0 = {str_0, str_0}
    bool_0 = False
    action_module_0 = ActionModule(str_0, str_0, str_1, set_0, bool_0, set_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:40:10.267793
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'host_name'
    str_1 = 'description'
    str_2 = 'k}A7Vh#C%;bZ'
    set_0 = {str_1, str_1}
    bool_0 = True
    action_module_0 = ActionModule(str_0, str_1, str_2, set_0, bool_0, set_0)
    str_3 = 'dnsdomain'
    str_4 = 'id'
    str_5 = 'salt-master'
    set_1 = {str_3, str_3}
    bool_1 = False
    set_2 = {str_4, str_4}
    action_module_1 = ActionModule(str_3, str_4, str_5, set_1, bool_1, set_2)

# Generated at 2022-06-25 07:40:16.293910
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'distributor_id'
    str_1 = 'E\rs[8s`s2E'
    set_0 = {str_0, str_0}
    bool_0 = False
    action_module_0 = ActionModule(str_0, str_0, str_1, set_0, bool_0, set_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:40:18.740032
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    # Calling run() method of ActionModule class
    str_0 = 'test_string'
    result_0 = action_module_0.run(str_0)


# Generated at 2022-06-25 07:40:22.835301
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'distributor_id'
    str_1 = 'E\rs[8s`s2E'
    set_0 = {str_0, str_0}
    bool_0 = False
    action_module_0 = ActionModule(str_0, str_0, str_1, set_0, bool_0, set_0)
    # AssertionError: unexpected failure: AttributeError 
    # ('ActionModule' object has no attribute 'run')
    # assert action_module_0.run() == var_0

# Generated at 2022-06-25 07:40:23.704180
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert type(action_module) is ActionModule

# Generated at 2022-06-25 07:40:28.811639
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'distributor_id'
    str_1 = 'E\rs[8s`s2E'
    set_0 = {str_0, str_0}
    bool_0 = False
    action_module_0 = ActionModule(str_0, str_0, str_1, set_0, bool_0, set_0)
    action_module_0.get_name()
    
if __name__ == '__main__':
    test_ActionModule()
    test_case_0()

# Generated at 2022-06-25 07:40:30.978259
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_1 = 'distributor_id'
    str_2 = 'E\rs[8s`s2E'
    set_2 = {str_1, str_1}
    bool_2 = False
    action_module_2 = ActionModule(str_1, str_1, str_2, set_2, bool_2, set_2)
    var_1 = action_module_2.run()


# Generated at 2022-06-25 07:40:36.477614
# Unit test for constructor of class ActionModule