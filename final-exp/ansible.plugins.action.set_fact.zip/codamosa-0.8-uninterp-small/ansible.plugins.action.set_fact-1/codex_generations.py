

# Generated at 2022-06-25 07:31:27.521000
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    str_0 = '\x89\x1ct\xac\xd6\xce\xb7\x83\xdd\x11\x19\x84\x04Z\xcf\x1a\x8d\x1c\x86\x9d\x9c\x07\x91\xb4\xdf\x1d\x1c&N\x08\x9d\xf0\x04\xb4\xaf\t'
    action_module_0 = ActionModule(False, False, str_0, str_0, set_0, str_0)
    # If you access a class property, you should not get an error message.
    str_1 = action_module_0.DSL_NAME
    set_1 = set()
    # If

# Generated at 2022-06-25 07:31:36.015914
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize class attributes
    tmp = None
    task_vars = None

    # Setup mocks
    action_base_0 = ActionBase(None, None, None, None)
    setattr(action_base_0, 'run', lambda x, y: (x, y))
    action_base_1 = ActionBase(None, None, None, None)
    setattr(action_base_1, 'run', lambda x, y: (x, y))

    # Generate test cases
    case_0_args = (tmp, task_vars)
    case_0_kwargs = {}
    cases = [((action_base_0, tmp, task_vars), case_0_kwargs), ((action_base_1, tmp, task_vars), case_0_kwargs)]


    # Perform the tests


# Generated at 2022-06-25 07:31:45.041243
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test 1:
    # No parameters, no task vars
    # Expect AnsibleActionFail raised
    action_module_0 = ActionModule()

# Generated at 2022-06-25 07:31:49.952351
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    str_0 = 'sga`+'
    set_0 = set()
    bytes_0 = b'\x06\x95\nx\xbb\xcb\xa5\xcb\x83o\xf5\xc2\xf2\x82B\x8e\x12\x9a'
    action_module_0 = ActionModule(bool_0, bool_0, str_0, str_0, set_0, bytes_0)
    action_module_0.run()



# Generated at 2022-06-25 07:31:52.536944
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# This function is used for the main function of the unit test.
# If you want to test the unit, you can add your test function here.

# Generated at 2022-06-25 07:32:01.569105
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    str_0 = '0<=J3\xeb\x0f\x06'
    set_0 = set()
    bytes_0 = b'X\xf9\x8a~\x08\x00'
    action_module_0 = ActionModule(bool_0, bool_0, str_0, str_0, set_0, bytes_0)
    dict_0 = dict()
    dict_0['kwargs'] = dict()
    dict_0['kwargs']['task_vars'] = dict()
    dict_0['tmp'] = '/tmp/ansible_ZSkDVZ'
    dict_0['module_name'] = 'set_fact'
    dict_0['module_args'] = dict()

# Generated at 2022-06-25 07:32:06.568258
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    str_0 = 'H`j\x89'
    set_0 = set('^\x01\xbe\x12\x9b\x13\xd6\x89\x1e')
    bytes_0 = b'\xb7\x18\x9b\x16\xd3\x89\x14\x8e\xcb\x03'
    action_module_0 = ActionModule(bool_0, bool_0, str_0, str_0, set_0, bytes_0)
    action_module_1 = ActionModule(bool_0, bool_0, str_0, str_0, set_0, bytes_0)
    action_module_1.run()

# Generated at 2022-06-25 07:32:07.389794
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert test_case_0() == 'TestCase passed'

# Generated at 2022-06-25 07:32:11.247997
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # The test is done with a boolean value and a boolean string
    # and tuples
    expected = True
    result = True
    assert result == expected


# Generated at 2022-06-25 07:32:19.417051
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    bool_1 = True
    bool_2 = False
    str_0 = ')lX{A<K'
    str_1 = 'b@(Dg6j'
    set_0 = set()
    bytes_0 = b'\x16-\x84\xcf\x91\x16\xee'
    action_module_0 = ActionModule(bool_0, bool_1, str_0, str_1, set_0, bytes_0)
    str_2 = '#cJ\x83\x08\xbf'
    str_3 = 'T0T0T0T0T0T0'
    tmp = None # TODO
    task_vars = None # TODO

# Generated at 2022-06-25 07:32:25.841240
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    try:
        assert type(action_module_1) == ActionModule
    except AssertionError:
        raise AssertionError("Invalid object constructor")


# Generated at 2022-06-25 07:32:34.737800
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(action_module_0._task.action == 'set_fact')
    assert(action_module_0._task.any_errors_fatal is True)
    assert(action_module_0._task.args == {})
    assert(action_module_0._task.async_val == 0)
    assert(action_module_0._task.async_seconds is None)
    assert(action_module_0._task.background == 0)
    assert(action_module_0._task.become is False)
    assert(action_module_0._task.become_method == 'sudo')
    assert(action_module_0._task.become_user == None)
    assert(action_module_0._task.check_mode is False)

# Generated at 2022-06-25 07:32:42.325935
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #action_module_0 = ActionModule( , )

    # Variable assignment
    #action_module_0.TRANSFERS_FILES = None
    #action_module_0.TRANSFERS_FILES = False
    #action_module_0.TRANSFERS_FILES = True

    # Test the return code of function run
    # test_case_0()

    pass # Nothing has been implemented for this test case


# Generated at 2022-06-25 07:32:43.257344
# Unit test for constructor of class ActionModule
def test_ActionModule():
  print("test_ActionModule")
  test_case_0()
  print("")

# Generated at 2022-06-25 07:32:50.636875
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_results = {}
    action_module_0 = ActionModule()

    # initialize test results
    test_results['test_case_0'] = False
    test_results['test_case_1'] = False
    test_results['test_case_2'] = False
    test_results['test_case_3'] = False
    test_results['test_case_4'] = False
    test_results['test_case_5'] = False
    test_results['test_case_6'] = False
    test_results['test_case_7'] = False
    test_results['test_case_8'] = False
    test_results['test_case_9'] = False
    test_results['test_case_10'] = False
    test_results['test_case_11'] = False

# Generated at 2022-06-25 07:32:52.196240
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    return 'unit test: pass'


# Generated at 2022-06-25 07:32:54.483168
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    tmp = None
    task_vars = None

    action_module_1.run(tmp, task_vars)


# Generated at 2022-06-25 07:32:57.289409
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp = action_module_0._make_tmp_path()
    task_vars = dict()

    with pytest.raises(AnsibleActionFail) as excinfo:
        action_module_0.run(tmp, task_vars)
    assert str(excinfo.value) == 'No key/value pairs provided, at least one is required for this action to succeed'

# Generated at 2022-06-25 07:33:00.975987
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:33:10.589703
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create instance
    action_module_0 = ActionModule()

    # create mocks
    tmp = 'ansible_module_ActionModule_run_tmp'
    task_vars = {'ansible_module_ActionModule_run_task_vars': 'ansible_module_ActionModule_run_task_vars'}

    # apply the patch
    with patch.object(ActionModule, 'run', return_value='ansible_module_ActionModule_run_return_value') as patched_ActionModule_run:
        # execute
        ansible_module_ActionModule_run_result = action_module_0.run(
            tmp=tmp,
            task_vars=task_vars
        )

    # validate

# Generated at 2022-06-25 07:33:23.390118
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'lO,a\x01\x1f%c'
    float_0 = 0.12
    int_0 = 0
    set_0 = {float_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, float_0, int_0, set_0)
    assert action_module_0.TRANSFERS_FILES == False
    str_1 = 'Mx|}(F"~Z1'
    float_1 = 1.5
    list_0 = []
    action_module_1 = ActionModule(action_module_0, str_0, str_1, list_0, action_module_0, list_0)
    assert action_module_1.TRANSFERS_FILES == False


# Generated at 2022-06-25 07:33:26.336712
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_2 = ActionModule()
    tmp = 'T=Tz?HA3_I'
    task_vars = {}
    # Call method run of action_module_2
    result = action_module_2.run(tmp, task_vars)
    assert result is None


# Generated at 2022-06-25 07:33:34.565727
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    str_0 = 'to count backwards make stride negative'
    float_0 = -1200.2
    int_0 = -1236
    set_0 = {float_0}
    action_module_1 = ActionModule(str_0, float_0, int_0, float_0, int_0, set_0)
    str_1 = 'FtlqS){|im#\rKI8_q,q'
    list_0 = []
    action_module_2 = ActionModule(action_module_0, str_0, str_1, list_0, action_module_0, list_0)
    var_0 = action_module_2.run()

# Generated at 2022-06-25 07:33:43.543032
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '8'
    float_0 = -1200.2
    int_0 = -1236
    set_0 = {-1200.2}
    # constructed instance of class ActionModule
    action_module_0 = ActionModule(str_0, float_0, int_0, float_0, int_0, set_0)
    # test attributes
    assert action_module_0.name == str_0
    assert action_module_0.short_description == float_0
    assert action_module_0.version_added == int_0
    assert action_module_0.deprecated_since == float_0
    assert action_module_0._deprecated_since == int_0
    assert action_module_0._deprecation_warnings == set_0

# Generated at 2022-06-25 07:33:48.107698
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_2 = ActionModule(action_module_1, str_0, str_0, list_0, int_0, set_0)
    assert(action_module_2._task.action == 'include_vars')


# Generated at 2022-06-25 07:33:52.324565
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'SbM5'
    float_0 = -84.4
    int_0 = 8
    set_0 = {float_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, float_0, int_0, set_0)
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:33:53.442132
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

    # Return a boolean success flag
    return True


# Generated at 2022-06-25 07:33:56.780859
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize an ActionModule object with test data
    action_module = ActionModule('test_var', 'test_var')

    # Invoke run() method of ActionModule
    result = action_module.run()
    print(result)


# Generated at 2022-06-25 07:34:02.333482
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_3 = '1#[gBfJ\r=oR'
    list_1 = []
    float_1 = -2353.0
    action_module_2 = ActionModule(str_3, float_1, float_1, float_1, float_1, list_1)
    var_0 = action_module_2.run()

# Generated at 2022-06-25 07:34:07.208317
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'f_b41=yG\x7f'
    float_0 = -1000.5
    int_0 = -1229
    set_0 = {float_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, float_0, int_0, set_0)
    str_1 = '{f3q6_'
    str_2 = '0T0=.@R'
    float_1 = float_0
    int_1 = int_0
    float_2 = float_1
    int_2 = int_0
    set_1 = {int_2}

# Generated at 2022-06-25 07:34:21.823008
# Unit test for constructor of class ActionModule
def test_ActionModule():
  str_0 = 'to count backwards make stride negative'
  float_0 = -1200.2
  int_0 = -1236
  set_0 = {float_0}
  action_module_0 = ActionModule(str_0, float_0, int_0, float_0, int_0, set_0)
  str_1 = 'FtlqS){|im#\rKI8_q,q'
  list_0 = []
  action_module_1 = ActionModule(action_module_0, str_0, str_1, list_0, action_module_0, list_0)

if __name__ == "__main__":
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 07:34:28.211869
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'to count backwards make stride negative'
    float_0 = -1200.2
    int_0 = -1236
    set_0 = {float_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, float_0, int_0, set_0)
    tmp_0 = None
    task_vars_0 = None
    # Call method run of class ActionModule with tmp_0, task_vars_0
    test_case_0()

if __name__ == '__main__':
    # Run method in class ActionModule
    test_ActionModule_run()

# Generated at 2022-06-25 07:34:36.256574
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'o-/!J^1NW%f1~b?p+'
    str_1 = 'zDP^'
    list_0 = []
    float_0 = -548.8
    float_1 = -443.6
    set_0 = {float_0}
    action_module_0 = ActionModule(str_0, float_0, float_0, float_1, float_1, set_0)
    var_0 = action_module_0.run(str_1, list_0)
    var_1 = action_module_0.run()


# Generated at 2022-06-25 07:34:42.411187
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'j\x1e\x1eWF\x0b\x14\x01\x15\x1f\x0b\x1b\x1eP\x0c\x1a\x1e\n'
    int_1 = -1236
    str_1 = 'BR\x11\x0f\x14\x1a\x1d'
    int_2 = -1236
    str_2 = 'to count backwards make stride negative'
    float_0 = -1200.2
    set_0 = {float_0}

    action_module_0 = ActionModule(str_0, int_1, str_1, int_2, str_2, float_0, set_0)
    action_module_0.run()

# Generated at 2022-06-25 07:34:54.858296
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:35:06.001435
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    del tmp  # tmp no longer has any effect
    result = super(ActionModule, self).run(tmp, task_vars)
    del tmp  # tmp no longer has any effect
    facts = {}
    cacheable = boolean(self._task.args.pop('cacheable', False))
    if self._task.args:
        for (k, v) in iteritems(self._task.args):
            k = self._templar.template(k)
            if not isidentifier(k):
                raise AnsibleActionFail("The variable name '%s' is not valid. Variables must start with a letter or underscore character, "
                                        "and contain only letters, numbers and underscores." % k)

# Generated at 2022-06-25 07:35:11.880417
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_1 = 'Command d$s#Ynzs~P'
    str_2 = 'L'
    str_3 = 'x,Zu&0@p+7z:h:D'
    str_4 = 'pGJu\x1d'
    int_0 = -1236
    action_module_1 = ActionModule(str_1, str_2, str_3, str_4, int_0)
    str_5 = 'Kp9b?]f\x1c'
    str_6 = '-o'
    int_1 = -1236
    str_7 = '_nas=S&'
    set_0 = {str_2}

# Generated at 2022-06-25 07:35:14.284045
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test case 1: Call constructor without any parameters.
    test_case_0()



# Generated at 2022-06-25 07:35:23.392113
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'lx@TccT^r'
    float_0 = 12.30
    int_0 = 1230
    set_0 = {float_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, float_0, int_0, set_0)
    str_1 = 't\r(wMf8G&<*Yp'
    action_module_1 = ActionModule(action_module_0, str_0, str_1, action_module_0, action_module_0, action_module_0)
    assert(isinstance(action_module_1, ActionModule))

# Example test for the run method

# Generated at 2022-06-25 07:35:26.503365
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        assert False



# Generated at 2022-06-25 07:35:52.392839
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'dvO<o!\x18%c!M?1|@[I'
    float_0 = -1300.89
    int_0 = 1422
    set_0 = {str_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, float_0, int_0, set_0)
    set_1 = set()
    str_1 = str()
    str_2 = '#>w@|7x{6n/R6;zh`6v}8e'
    int_1 = -1256
    float_1 = -1143.64
    action_module_0.run(str_1, int_1, str_2, float_1)

# Generated at 2022-06-25 07:35:58.886466
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Z'
    float_0 = 6.127873564
    int_0 = 13485
    set_0 = {str_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, float_0, int_0, set_0)
    str_1 = 'mfGlrq6U'
    list_0 = []
    action_module_1 = ActionModule(action_module_0, str_0, str_1, list_0, action_module_0, list_0)
    var_0 = action_module_1.run()
    assert '_ansible_facts_cacheable' in var_0.keys()
    assert var_0['_ansible_facts_cacheable'] == False
    assert 'ansible_facts' in var_

# Generated at 2022-06-25 07:36:07.111061
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'to count backwards make stride negative'
    float_0 = -1200.2
    int_0 = -1236
    set_0 = {float_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, float_0, int_0, set_0)
    str_1 = 'FtlqS){|im#\rKI8_q,q'
    list_0 = []
    action_module_1 = ActionModule(action_module_0, str_0, str_1, list_0, action_module_0, list_0)
    var_0 = action_module_1.run()
    assert var_0 == None

# Generated at 2022-06-25 07:36:11.833388
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()


# Generated at 2022-06-25 07:36:14.961811
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:36:18.514519
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '9W'
    float_0 = -58.20
    int_0 = -8
    set_0 = {float_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, float_0, int_0, set_0)
    assert isinstance(action_module_0, ActionModule)

# Generated at 2022-06-25 07:36:22.755637
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '.v^U6mmS'
    float_0 = -2500.66
    int_0 = -1237
    str_1 = 'to count backwards make stride negative'
    action_module_0 = ActionModule(str_0, float_0, int_0, float_0, int_0, float_0, int_0, float_0, str_1)


# Generated at 2022-06-25 07:36:26.612140
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'to count backwards make stride negative'
    float_0 = -1200.2
    int_0 = -1236
    set_0 = {float_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, float_0, int_0, set_0)
    str_1 = 'FtlqS){|im#\rKI8_q,q'
    list_0 = []
    action_module_1 = ActionModule(action_module_0, str_0, str_1, list_0, action_module_0, list_0)
    var_0 = action_module_1.run()

# Generated at 2022-06-25 07:36:36.243417
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'C}uO?l`d'
    int_0 = -60
    set_0 = {int_0, str_0}
    action_module_0 = ActionModule(int_0, str_0, int_0, set_0, str_0, str_0)
    str_1 = '9px:s&s=L2$cN,4'
    dict_0 = dict(action_module_0=action_module_0, str_0=str_0, str_1=str_1, list_0=dict_0.keys())
    var_0 = action_module_0.run(dict_0)
    assert var_0 == dict_0


# Generated at 2022-06-25 07:36:42.055356
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = ';{j$1<q3?)r0+JXg*!)j*'
    float_0 = -12.5
    int_0 = -12
    set_0 = {int_0, float_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, float_0, int_0, set_0)
    action_module_0.test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:37:31.795834
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'to count backwards make stride negative'
    float_0 = -1200.2
    int_0 = -1236
    set_0 = {float_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, float_0, int_0, set_0)
    str_1 = 'FtlqS){|im#\rKI8_q,q'
    list_0 = []
    action_module_1 = ActionModule(action_module_0, str_0, str_1, list_0, action_module_0, list_0)
    var_0 = action_module_1.run()

# Generated at 2022-06-25 07:37:39.121100
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'MC@(J?H^x-}&_'
    float_0 = -1700.6
    int_0 = -1101
    set_0 = {str_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, float_0, int_0, set_0)
    assert action_module_0._task.action == 'SET_FACTS'


# Generated at 2022-06-25 07:37:48.053362
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Initializing var_0
    str_0 = 'to count backwards make stride negative'
    float_0 = -1200.2
    int_0 = -1236
    set_0 = {float_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, float_0, int_0, set_0)
    # Initializing var_1
    str_1 = 'FtlqS){|im#\rKI8_q,q'
    list_0 = []
    action_module_1 = ActionModule(action_module_0, str_0, str_1, list_0, action_module_0, list_0)
    # Assigning parameter 'tmp'
    str_2 = 'to count backwards make stride negative'
    # Assigning parameter 'task_vars'

# Generated at 2022-06-25 07:37:58.527309
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '#_t'
    float_0 = -23.16301
    int_0 = -1295
    action_module_0 = ActionModule(str_0, float_0, int_0, float_0, int_0)
    float_1 = -55.2
    str_1 = 'K&:Z[i|7A,(p'
    int_1 = -4253
    action_module_1 = ActionModule(action_module_0, str_0, str_1, int_1, float_1, int_1)
    assert action_module_1._task.args == {} and action_module_1._task.action == 'set_fact', 'Expected value did not match, actual: %s' % action_module_1._task.action
    assert action_module_1._

# Generated at 2022-06-25 07:38:06.977863
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'u,Y_U&7L-{hWdVl"K$/M|'
    float_0 = -1244.5
    int_0 = -1235
    set_0 = {float_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, float_0, int_0, set_0)
    assert action_module_0._task.action == str_0
    list_0 = [float_0, float_0]
    action_module_0.load_list_of_tasks(list_0)
    assert len(action_module_0._tasks) == 2


# Generated at 2022-06-25 07:38:12.868253
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        str_0 = 'M'
        float_0 = -1200.2
        int_0 = -1236
        set_0 = {float_0}
        action_module_0 = ActionModule(str_0, float_0, int_0, float_0, int_0, set_0)
        assert action_module_0
    except Exception:
        assert False


# Generated at 2022-06-25 07:38:18.028981
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'J.fPVg4[~m9.'
    float_0 = -1358.8
    int_0 = -1000
    set_0 = {int_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, float_0, int_0, set_0)


# Generated at 2022-06-25 07:38:18.756244
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:38:21.784887
# Unit test for constructor of class ActionModule
def test_ActionModule():
  try:
    assert True
  except:
    print('FAILED: test_ActionModule')

ValueError = ValueError()


# Generated at 2022-06-25 07:38:30.491173
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = ','
    float_0 = 2.18281828459045
    int_0 = 3
    set_0 = {float_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, float_0, int_0, set_0)
    str_1 = ''
    list_0 = []
    action_module_1 = ActionModule(action_module_0, str_0, str_1, list_0, action_module_0, list_0)
    var_0 = action_module_1.run()

# Generated at 2022-06-25 07:40:13.259224
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'VxgW2@,w&*`}f-^`K"9$'
    float_0 = 0.4
    int_0 = -1236
    action_module_0 = ActionModule(str_0, float_0, int_0, float_0, int_0)
    str_1 = 'vrVz1}FNX@f40\x0c`Z3'
    float_1 = -1200.2
    float_2 = 0.4
    int_1 = -1236
    int_2 = 1236
    set_0 = {float_2}
    action_module_1 = ActionModule(action_module_0, str_0, float_1, int_1, float_2, int_2, set_0)

# Generated at 2022-06-25 07:40:14.590390
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var = ActionModule()
    var.run()


# Generated at 2022-06-25 07:40:22.645125
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    task_vars = {
        'some_var': 'foo',
        'some_list': ['aaa', 'bbb'],
        'some_num': 42,
    }

    def _task_execution(action_module, test_vars=None, task_vars=task_vars, tmpdir='/tmp'):
        args = dict(
            _ansible_remote_tmp=tmpdir,
            _ansible_no_log=False,
            _ansible_debug=False,
            _ansible_check_mode=False,
            _ansible_keep_remote_files=False,
            _ansible_diff=False,
            _ansible_verbosity=0,
            _ansible_tmp=None,
        )

# Generated at 2022-06-25 07:40:29.947300
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'oCwz*jB2e#YO9{1<;+'
    float_0 = 2.12
    int_0 = 6
    set_0 = {float_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, float_0, int_0, set_0)
    str_1 = '7b@5jwvz!+:}3LoY'
    int_1 = -1
    action_module_1 = ActionModule(action_module_0, str_0, str_1, int_1, action_module_0, int_1)
    str_2 = '4n0MmiWiA'

# Generated at 2022-06-25 07:40:35.501324
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '%c1&TG7MzZcu2Sb}_F'
    str_1 = ':y~=kRJ'
    action_module_0 = ActionModule(str_0, str_1)
    str_0 = 'hi '
    list_0 = [str_0]
    action_module_1 = ActionModule(action_module_0, list_0, str_0)
    var_0 = action_module_1.run()
    assert var_0 == (True, False)

if __name__ == '__main__':
    test_case_0()
    # test_ActionModule_run()

# Generated at 2022-06-25 07:40:36.521601
# Unit test for constructor of class ActionModule
def test_ActionModule():

    with pytest.raises(TypeError):
        ActionModule()

# Generated at 2022-06-25 07:40:43.090828
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'to count backwards make stride negative'
    float_0 = -1200.2
    int_0 = -1236
    set_0 = {float_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, float_0, int_0, set_0)
    str_1 = 'FtlqS){|im#\rKI8_q,q'
    list_0 = []
    action_module_1 = ActionModule(action_module_0, str_0, str_1, list_0, action_module_0, list_0)
    str_2 = 'to count backwards make stride negative'
    float_1 = -1200.2
    int_1 = -1236
    set_1 = {float_1}
    action_module_2

# Generated at 2022-06-25 07:40:44.434786
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'L'
    float_0 = 0.9
    int_0 = -1999
    action_module_0 = ActionModule(str_0, float_0, int_0, float_0, int_0)


# Generated at 2022-06-25 07:40:53.621800
# Unit test for constructor of class ActionModule
def test_ActionModule():
  str_0 = 'to count backwards make stride negative'
  float_0 = -1200.2
  int_0 = -1236
  set_0 = {float_0}
  action_module_0 = ActionModule(str_0, float_0, int_0, float_0, int_0, set_0)
  assert_equal(action_module_0._file_local_action, False)
  assert_equal(action_module_0._supports_async, False)
  assert_equal(action_module_0._supports_check_mode, False)
  assert_equal(action_module_0._supports_rewind, False)
  assert_equal(action_module_0._uses_atomic_demand_loading, None)

# Generated at 2022-06-25 07:41:01.929109
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'K{w^N@NU@$;N"K#9%%'
    float_0 = -1207.0
    int_0 = -1221
    set_0 = {-1247, float_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, float_0, int_0, set_0)
    str_1 = 'K{w^N@NU@$;N"K#9%%'
    list_0 = []
    action_module_1 = ActionModule(action_module_0, str_0, str_1, list_0, action_module_0, list_0)