

# Generated at 2022-06-25 07:31:25.947611
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_2['Tv!(s!MkKj8X'] = dict_1
    dict_2['U6f8G6Wx.v'] = dict_0
    dict_2['2*r/f>N/Fn'] = dict_1
    dict_2['w,E0Yq3`y='] = dict_0
    dict_2['i>uZ>V<BfC'] = dict_1
    dict_2['XoGK^!kAtO'] = dict_0
    dict_2['&_<a5/5H/]'] = dict_1
    dict_2['(VuZNtN|7l'] = dict_1

# Generated at 2022-06-25 07:31:33.627364
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''
    tuple_0 = ()
    bool_0 = False
    str_0 = "'$e&Pk-LT8%wAz"
    int_0 = 1
    action_module_0 = ActionModule(tuple_0, bool_0, bool_0, str_0, int_0, tuple_0)
    dict_0 = {'#C=D6*sB6wfT': 'j+;R@^*(_Yf', '%302zd@QfjF': '.rG`?', ';aHp:^l-': '0[h'}
    dict_1 = {'J>Ft+1': '|]m<'}
    action_module_0._task.args = dict_0
   

# Generated at 2022-06-25 07:31:34.165523
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:31:37.438156
# Unit test for constructor of class ActionModule
def test_ActionModule():
  tuple_0 = ()
  bool_0 = False
  str_0 = "g"
  float_0 = 4016.5692396
  action_module_0 = ActionModule(tuple_0, bool_0, bool_0, str_0, float_0, tuple_0)
  action_module_0.run()

if __name__ == '__main__':
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 07:31:45.260335
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    bool_0 = True
    str_0 = "dXt1R:t>OemtT?oNxD_F"
    float_0 = 4991.413408
    action_module_0 = ActionModule(tuple_0, bool_0, bool_0, str_0, float_0, tuple_0)
    action_module_0.run()


if __name__ == '__main__':
    import time
    start_time = time.time()

    test_case_0()
    test_ActionModule_run()

    elapsed_time = time.time() - start_time
    print("Finished in %.3f seconds." % elapsed_time)

# Generated at 2022-06-25 07:31:51.409846
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    bool_0 = True
    str_0 = "sNv`"
    float_0 = 5768.205116
    action_module_0 = ActionModule(tuple_0, bool_0, bool_0, str_0, float_0, tuple_0)
    dict_0 = dict()
    dict_0['vars_prompt'] = dict()
    dict_0['vars_prompt']['username'] = 'param'
    dict_0['vars_prompt']['groupname'] = 'param'
    dict_0['module_name'] = 'param'
    dict_0['debug'] = 'param'
    dict_0['params'] = dict()
    dict_0['params']['date'] = 'param'

# Generated at 2022-06-25 07:31:58.743245
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('')
    print('Test for constructor of class ActionModule')

    tuple_0 = ()
    bool_0 = True
    str_0 = "(GM<%2'6Bh#dR6?AJDpc"
    float_0 = 1322.639201
    action_module_0 = ActionModule(tuple_0, bool_0, bool_0, str_0, float_0, tuple_0)
    assert isinstance(action_module_0, ActionModule)

    print('Test for constructor of class ActionModule: Done')
    print('')


# Generated at 2022-06-25 07:32:06.247283
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    bool_0 = True
    str_0 = "EApRb}#jy&r1z9TU'q6U"
    tuple_1 = ()
    action_module_0 = ActionModule(tuple_0, bool_0, bool_0, str_0, float('inf'), tuple_1)
    action_module_0.run()
    action_module_0.run()
    action_module_0.run()
    tuple_2 = ()
    action_module_1 = ActionModule(tuple_2, bool_0, bool_0, str_0, 0.0, tuple_2)
    action_module_1.run()
    action_module_1.run()
    action_module_1.run()
    action_module_1.run()
    action

# Generated at 2022-06-25 07:32:09.034508
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    action_module_1 = ActionModule(str_0 = "(GM<%2'6Bh#dR6?AJDpc")


# Generated at 2022-06-25 07:32:17.116034
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    bool_0 = True
    str_0 = "EW/nP'e~K9mi}$e"
    float_0 = 5595.543801
    action_module_0 = ActionModule(tuple_0, bool_0, bool_0, str_0, float_0, tuple_0)

    # Call method run of object action_module_0 with arguments: tmp=None and task_vars=None
    result_0 = action_module_0.run(tmp=None, task_vars=None)
    assert(result_0 == None)

# Generated at 2022-06-25 07:32:23.339371
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:32:28.780092
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'alOk}"G)/VuCd]o{7Q.F'
    str_1 = 'P'
    str_2 = '>8Nl)$j1E'
    str_3 = '8'
    str_4 = '0H'
    str_5 = '2f>'
    str_6 = 'Zj'
    str_7 = 'C'
    str_8 = '-@EAzB'
    str_9 = '{xn-'
    str_10 = '$j2'
    str_11 = '%sx%sX.*M;b'
    str_12 = '*'
    str_13 = '0h'
    str_14 = 'fzF(QgSM,N'
    str_15 = '$j'
   

# Generated at 2022-06-25 07:32:29.642973
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:32:39.120397
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "[Vj,"
    str_1 = "vpHUmBjz2)#?b%c1}iH"
    assert action_module_0._execute_module() == False
    assert action_module_0.get_parsed_results() == False
    assert action_module_0.get_results() == None
    assert action_module_0.get_nonpersistent_connection() == None
    assert action_module_0.get_terminal() == False
    assert action_module_0.check_mode() == None
    assert action_module_0.set_terminal() == None
    assert action_module_0.async_poll() == None
    assert action_module_0.async_wait() == None
    assert action_module_0.async_seconds() == None
   

# Generated at 2022-06-25 07:32:45.727899
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "5K1-5"
    str_1 = "h5;K"
    str_2 = "2,=h"
    str_3 = "`^n"
    str_4 = ";lA"
    str_5 = "f,q3G"
    str_6 = "e'a+"
    str_7 = "U@,8TZ"
    str_8 = "$%O"
    str_9 = "HTV]g"
    str_10 = "GjZ~"
    str_11 = "X#)x{#"
    ansible_action_fail_0 = AnsibleActionFail(str_7)
    action_module_0 = ActionModule()

    with pytest.raises(SystemExit):
        action_module_0.run()



# Generated at 2022-06-25 07:32:48.835289
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    del action_module_1


# Generated at 2022-06-25 07:32:56.174170
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test case given in problem statement
    # Prepare test case 0
    str_0 = "(GM<%2'6Bh#dR6?AJDpc"
    cacheable_0 = 0
    action_module_0 = ActionModule()
    action_module_0.run(str_0, cacheable_0)

# Generated at 2022-06-25 07:33:04.297384
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Arguments:
    #   task (Task): The task object.
    #   connection (Connection): The connection to use.
    #   play_context (PlayContext): The play context to use.
    #   loader (TaskLoader): The task loader to use.
    #   templar (Templar): The templar to use.
    #   shared_loader_obj (Any): The shared loader object, if any.

    assert True

# Would like to test 
# def _execute_module(self, result, tmp=None)
# but it requires more test setup


# Generated at 2022-06-25 07:33:05.323664
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert action_module_0.__init__() == 'ActionModule'


# Generated at 2022-06-25 07:33:09.321481
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "z}cKYwdXk)r1qd3Z@[$+e"
    action_module_0 = ActionModule()
    assert action_module_0.TRANSFERS_FILES == False


# Generated at 2022-06-25 07:33:18.905447
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = dict({'1':'1', '2':'2'})
    action_module_0 = ActionModule(false, float(), str_0, true, float(), str_0)
    action_module_0.run(dict_0)


# Generated at 2022-06-25 07:33:20.006947
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert func_callable(ActionModule)


# Generated at 2022-06-25 07:33:28.190527
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:33:31.038662
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 60.0
    str_0 = 'osversion'
    float_1 = -4587.55
    action_module_0 = ActionModule(bool_0, float_0, str_0, bool_0, float_1, str_0)
    action_module_0.run()

# Generated at 2022-06-25 07:33:42.265560
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_2 = True
    float_2 = 60.0
    str_2 = 'osversion'
    float_3 = -4587.55
    str_3 = 'ansible_facts'
    action_module_1 = ActionModule(bool_2, float_2, str_2, bool_2, float_3, str_3)
    assert get_action_args() == {'osversion': 'ansible_facts'}
    assert get_task_vars() == {'ansible_facts' : {'osversion': 'ansible_facts'}}
    assert get_ansible_facts('') == {'osversion': 'ansible_facts'}
    assert get_ansible_facts() == {'osversion': 'ansible_facts'}


# Generated at 2022-06-25 07:33:51.154191
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# A more comprehensive test case.
# 
# def test_case_1():
#     print('Not implemented')
# 
# # Unit test for method run of class ActionModule
# def test_ActionModule_run():
#     test_case_1()
# 
# # A more comprehensive test case.
# # 
# def test_case_2():
#     print('Not implemented')
# 
# # Unit test for method run of class ActionModule
# def test_ActionModule_run():
#     test_case_2()

# Generated at 2022-06-25 07:33:59.389051
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    float_0 = 60.0
    str_0 = 'osversion'
    float_1 = -4587.55
    action_module_0 = ActionModule(bool_0, float_0, str_0, bool_0, float_1, str_0)
    assert not hasattr(action_module_0, 'var_0')
    assert not hasattr(action_module_0, 'var_1')
    assert not hasattr(action_module_0, 'var_2')
    assert not hasattr(action_module_0, 'var_3')
    assert not hasattr(action_module_0, 'var_4')
    assert not hasattr(action_module_0, 'var_5')


# Generated at 2022-06-25 07:34:02.494753
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    float_0 = 60.0
    str_0 = 'osversion'
    bool_1 = True
    float_1 = -4587.55
    str_1 = 'osversion'
    action_module_0 = ActionModule(bool_0, float_0, str_0, bool_1, float_1, str_1)
    return action_module_0

if __name__ == '__main__':
    action_module_0 = test_ActionModule()
    var_0 = action_run()

# Generated at 2022-06-25 07:34:07.108929
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  print()
  # Test that the module runs without errors.
  test_case_0()
  # Test with real data.
  test_case_1()

# Main function to call when this .py file is called from the command line.
if __name__ == '__main__':
  test_ActionModule_run()

# Generated at 2022-06-25 07:34:08.514994
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert action_module_0.run(arg_1, arg_2) == arg_3

# Generated at 2022-06-25 07:34:22.194366
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False


# Generated at 2022-06-25 07:34:29.276883
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    float_0 = 87.878
    str_0 = 'system'
    bool_1 = True
    float_1 = 989.32
    str_1 = 'ansible_facts'
    action_module_0 = ActionModule(bool_0, float_0, str_0, bool_1, float_1, str_1)
    dict_0 = dict()
    dict_0['tasks'] = list()
    dict_0['tasks'].append(dict())
    dict_0['tasks'][0]['tasks'] = list()
    dict_0['tasks'][0]['tasks'].append(dict())
    dict_0['tasks'][0]['tasks'][0]['action'] = dict()

# Generated at 2022-06-25 07:34:34.081089
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    float_0 = 60.0
    str_0 = 'osversion'
    float_1 = -4587.55
    action_module_0 = ActionModule(bool_0, float_0, str_0, bool_0, float_1, str_0)


# Generated at 2022-06-25 07:34:37.202974
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:34:43.561609
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import StringIO
    import contextlib
    import sys
    current_dir = os.getcwd()
    test_dir = os.path.dirname(os.path.realpath(__file__))
    os.chdir(test_dir)
    try:
        with contextlib.redirect_stdout(StringIO.StringIO()) as buf:
            test_case_0()
            output = buf.getvalue()
            assert output == ''
    finally:
        os.chdir(current_dir)

# Generated at 2022-06-25 07:34:49.582260
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'ops'
    bool_1 = False
    float_1 = 0.5
    str_1 = 'ha'
    bool_2 = False
    float_2 = 0.1
    str_2 = 'linux_version'
    action_module_0 = ActionModule(bool_1, float_1, str_1, bool_2, float_2, str_2)
    return

# Generated at 2022-06-25 07:34:55.336946
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 60.0
    str_0 = 'osversion'
    bool_1 = False
    float_1 = -4587.55
    action_module_0 = ActionModule(bool_0, float_0, str_0, bool_0, float_1, str_0)
    action_module_0.run()


# Generated at 2022-06-25 07:35:06.045881
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible import context
    from ansible.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.process.worker import WorkerProcess
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import PluginLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-25 07:35:09.758759
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Declaration of arguments
    tmp = None
    task_vars = None
    # Call to run
    action_module_0 = ActionModule(str_0, bool_0, float_0, bool_0, float_1, str_0)
    result = action_module_0.run(tmp, task_vars)
    # Checking if returned value is equal to expected one
    assert result == None


# Generated at 2022-06-25 07:35:10.267210
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-25 07:35:36.228128
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 310.0
    str_0 = 'network'
    bool_1 = True
    float_1 = -1162.55
    str_1 = 'version'
    action_module_0 = ActionModule(bool_0, float_0, str_0, bool_1, float_1, str_1)
    result = action_module_0.run()

# Generated at 2022-06-25 07:35:39.775680
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    float_0 = 60.0
    str_0 = 'osversion'
    float_1 = -4587.55
    action_module_0 = ActionModule(bool_0, float_0, str_0, bool_0, float_1, str_0)
    pass



# Generated at 2022-06-25 07:35:46.247344
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Action run
    test_case_0()

#if __name__ == "__main__":
    #test_ActionModule_run()
    #test_case_0()
    #print(action_run())

# Generated at 2022-06-25 07:35:49.999003
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("test_ActionModule")
    bool_2 = False
    float_2 = 67.0
    str_3 = 'rebootreq'
    action_module_1 = ActionModule(bool_2, float_2, str_3)
    var_1 = action_run()


# Generated at 2022-06-25 07:35:53.830489
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    float_0 = 90.0
    str_0 = 'version'
    bool_1 = False
    float_1 = -4335.96
    str_1 = 'facts'
    action_module_0 = ActionModule(bool_0, float_0, str_0, bool_1, float_1, str_1)


# Generated at 2022-06-25 07:35:59.901501
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 60.0
    str_0 = 'osversion'
    bool_1 = True
    float_1 = 4950.25
    str_1 = 'distribution'
    action_module_0 = ActionModule(bool_0, float_0, str_0, bool_1, float_1, str_1)
    float_2 = -300.0
    float_3 = 7888.6
    float_4 = -1737.0
    float_5 = -8303.16
    float_6 = 2677.4
    float_7 = 8060.86
    float_8 = -8241.75
    float_9 = -4721.09
    float_10 = -9498.3
    float_11 = -4072.13

# Generated at 2022-06-25 07:36:01.169723
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# TODO: Add remaining code

# Generated at 2022-06-25 07:36:09.220668
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  # no arguments
  action_module_0 = ActionModule("str_0")
  var_0 = action_run("dict_0")
  var_0 = action_run("dict_0", "dict_1")
  var_0 = action_run("dict_0", "dict_1", "dict_2")
  var_0 = action_run("dict_0", "dict_1", "dict_2", "dict_3")
  var_0 = action_run("dict_0", "dict_1", "dict_2", "dict_3", "dict_4")
  var_0 = action_run("dict_0", "dict_1", "dict_2", "dict_3", "dict_4", "dict_5")

# Generated at 2022-06-25 07:36:13.260324
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 42.14
    str_0 = 'auto'
    bool_1 = False
    float_1 = -46.3
    str_1 = 'true'
    action_module_0 = ActionModule(bool_0, float_0, str_0, bool_1, float_1, str_1)
    task_vars_0 = Dict
    tmp_0 = 'tmp'
    var_0 = action_module_0.run(tmp_0, task_vars_0)
    assert 'changed' in var_0


# Generated at 2022-06-25 07:36:21.769899
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    float_0 = 60.0
    str_0 = 'osversion'
    bool_1 = True
    float_1 = -4587.55
    str_1 = 'osversion'
    action_module_0 = ActionModule(bool_0, float_0, str_0, bool_1, float_1, str_1)
    assert_equal(action_module_0.ansible_module_name, 'set_fact')
    assert_equal(action_module_0.connection, 'local')
    assert_equal(action_module_0.no_log, False)
    assert_equal(action_module_0.service_names, [])

# Generated at 2022-06-25 07:37:25.436521
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    float_0 = 5.0
    str_0 = 'osversion'
    bool_1 = True
    float_1 = 60.0
    str_1 = 'osversion'
    action_module_0 = ActionModule(bool_0, float_0, str_0, bool_1, float_1, str_1)
    print("Failed test:")
    try:
        assert action_module_0 and action_module_0.run() != None
    except Exception as err:
        print("Test Failed:", err)
    else:
        print("Test Passed")


if __name__ == '__main__':
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 07:37:26.362765
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:37:30.812009
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test for constructor of class ActionModule with params:
    main_0 = main(bool_0, bool_0, bool_0)

# Generated at 2022-06-25 07:37:39.855763
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host_name = 'host'
    task_name = 'dummy'

    task_vars = { host_name: {} }

    args = {'guest_facts': {'guest_attr_0': 'guest_attr_0_value'}}

    local_action = ActionModule(task=dict(args=args, name='guest'), conn=None, tmp=None, task_vars=task_vars)

    action_run = local_action.run(task_vars=task_vars)

    # Check cacheability
    assert action_run['_ansible_facts_cacheable'] is False

# Generated at 2022-06-25 07:37:45.974232
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_1 = False
    float_2 = 44.0
    str_1 = 'testing'
    bool_2 = True
    float_3 = -2.9
    str_2 = 'action'
    action_module_1 = ActionModule(bool_1, float_2, str_1, bool_1, float_3, str_2)

if __name__ == "__main__":
    if bool(True):
        test_case_0()
    if bool(True):
        test_ActionModule()

# Generated at 2022-06-25 07:37:48.106429
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Run action

    # Print output
    print(var_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:37:49.365469
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert test_case_0() is None


# Generated at 2022-06-25 07:37:54.470796
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    
    # example values for optional params
    tmp = 60.0
    task_vars = 'osversion'

    # action_module_0 = ActionModule()
    # try:
    #     action_module_0.run(tmp, task_vars)
    # except NotImplementedError:
    #     pass
    if tmp == 60.0 and task_vars == 'osversion':
        return
    else:
        raise AssertionError

# Generated at 2022-06-25 07:37:58.931463
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Test run")
    var_0 = ActionModule()
    var_1 = None
    var_2 = var_0.run(var_1)
    print("Test run complete")


# Generated at 2022-06-25 07:38:05.317778
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    float_0 = -1561.58
    str_0 = 'version'
    bool_1 = False
    float_1 = -8957.48
    str_1 = 'provider'
    action_module_0 = ActionModule(bool_0, float_0, str_0, bool_1, float_1, str_1)
    # returns none of 2


# Generated at 2022-06-25 07:40:15.512357
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    float_0 = 60.0
    str_0 = 'osversion'
    float_1 = -4587.55
    action_module_0 = ActionModule(bool_0, float_0, str_0, bool_0, float_1, str_0)


# Generated at 2022-06-25 07:40:17.025314
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-25 07:40:19.727594
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    float_0 = 60.0
    str_0 = 'osversion'
    float_1 = -4587.55
    action_module_0 = ActionModule(bool_0, float_0, str_0, bool_0, float_1, str_0)


# Generated at 2022-06-25 07:40:24.957867
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    float_0 = 60.0
    str_0 = 'osversion'
    bool_1 = True
    float_1 = -4587.55
    str_1 = 'osversion'
    action_module_0 = ActionModule(bool_0, float_0, str_0, bool_1, float_1, str_1)

# Generated at 2022-06-25 07:40:28.779563
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    float_0 = 60.0
    str_0 = 'osversion'
    float_1 = -4587.55
    action_module_0 = ActionModule(bool_0, float_0, str_0, bool_0, float_1, str_0)
    method_0 = action_run()
    var_0 = method_0()
    return var_0



# Generated at 2022-06-25 07:40:31.777096
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    float_0 = 60.0
    str_0 = '3468.7'
    float_1 = -4587.55
    action_module_0 = ActionModule(bool_0, float_0, str_0, bool_0, float_1, str_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:40:39.175578
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 60.0
    str_0 = 'osversion'
    float_1 = -4587.55
    action_module_0 = ActionModule(bool_0, float_0, str_0, bool_0, float_1, str_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:40:39.889216
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert result == test_case_0()

# Generated at 2022-06-25 07:40:46.033953
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    float_0 = 60.0
    str_0 = 'osversion'
    bool_1 = True
    float_1 = -4587.55
    str_1 = 'osversion'
    #TODO: self.assertIsNone(self._task.args, None)
    #TODO: self.assertIsNone(self._task.delegate_to, None)
    #TODO: self.assertIsNone(self._task.notify, None)
    #TODO: self.assertIsNone(self._task.poll, None)
    #TODO: self.assertIsNone(self._task.tags, None)
    #TODO: self.assertIsNone(self._task.when, None)

# Generated at 2022-06-25 07:40:47.632659
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Test: ActionModule.run")
    # for key, value in iteritems(self._task.args):
    #     k = self._templar.template(key)
    pass

if __name__ == "__main__":
    test_case_0()