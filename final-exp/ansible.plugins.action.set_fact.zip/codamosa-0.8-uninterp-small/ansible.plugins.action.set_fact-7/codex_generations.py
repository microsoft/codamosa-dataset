

# Generated at 2022-06-25 07:31:17.112154
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'l]uXh'
    bool_0 = True
    action_module_0 = ActionModule(str_0, bool_0, str_0, bool_0, str_0, str_0)
    action_module_0.run()


# Generated at 2022-06-25 07:31:21.168513
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule('YsYsYsYsYsYs', True, 'YsYsYsYsYsYs', True, 'YsYsYsYsYsYs', 'YsYsYsYsYsYs')
    action_module_0.run('YsYsYsYsYsYs', 'YsYsYsYsYsYs')

# Generated at 2022-06-25 07:31:26.481592
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'oTzT'
    bool_0 = True
    action_module_0 = ActionModule(str_0, bool_0, str_0, bool_0, str_0, str_0)


# Generated at 2022-06-25 07:31:29.115160
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '3'
    bool_0 = True
    action_module_0 = ActionModule(str_0, bool_0, str_0, bool_0, str_0, str_0)
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:31:33.527073
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'l]uXh'
    bool_0 = True
    action_module_0 = ActionModule(str_0, bool_0, str_0, bool_0, str_0, str_0)
    str_1 = 'l]uXh'
    dict_0 = {}
    action_module_0.run(str_1, dict_0)
    action_module_0.run()

# Generated at 2022-06-25 07:31:42.351216
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 0
    str_0 = 'V@'
    str_1 = '@!8D'
    int_1 = -4
    action_module_0 = ActionModule(int_0, int_0, int_0, int_1, str_1, str_0)
    dict_0 = dict()
    dict_0['ansible_facts'] = dict()
    dict_0['_ansible_facts_cacheable'] = True

    action_module_0.run(str_1, dict_0)
    dict_1 = dict()
    dict_1['ansible_facts'] = dict()
    dict_1['_ansible_facts_cacheable'] = False

    action_module_0.run(str_1, dict_1)

# Generated at 2022-06-25 07:31:46.164246
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    dict_0 = dict()
    str_0 = '|n{v[8Zk'
    action_module_0 = ActionModule(str_0, bool_0, str_0, bool_0, str_0, str_0)
    action_module_0.run(str_0, dict_0)

# Generated at 2022-06-25 07:31:49.407222
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'YJ_'
    action_module_0 = ActionModule(str_0, bool, str_0, bool, str_0, str_0)
    assert len(action_module_0.TRANSFERS_FILES) == 1
    assert len(action_module_0.var_spec) == 4


# Generated at 2022-06-25 07:31:50.839881
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except:
        assert False

# Generated at 2022-06-25 07:32:00.240237
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'mX4YVB0'
    bool_0 = True
    action_module_0 = ActionModule(str_0, bool_0, str_0, bool_0, str_0, str_0)
    ans_0 = 'ZAj'
    ans_1 = True
    ans_2 = bool_0
    ans_3 = 'R,TB+'
    ans_4 = 'nG6'
    str_1 = 'd^o6'
    bool_1 = False
    ans_5 = str_1
    ans_6 = bool_1
    ans_7 = bool_0
    ans_8 = 'p'
    ans_9 = 'Y!R'

# Generated at 2022-06-25 07:32:08.275605
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {}
    tmp = {}
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action.run(tmp=tmp, task_vars=task_vars)
    assert result['ansible_facts'] == {}
    assert result['_ansible_facts_cacheable'] == False



# Generated at 2022-06-25 07:32:15.985147
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup:
    obj_ActionModule = ActionModule('action_plugin')
    list_0 = [random.randrange(1,10), random.randrange(1,10)]
    tmp = random.randrange(1,10)
    task_vars = {random.randrange(1,10): random.randrange(1,10), random.randrange(1,10): random.randrange(1,10)}
    result = {}

    # Test:
    result = obj_ActionModule.run(tmp, task_vars)


# Generated at 2022-06-25 07:32:18.629983
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = ansible.constants.DEFAULT_HOST_LIST
    obj_1 = ansible.plugins.action.ActionBase()
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 07:32:23.872775
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Input parameters for the method run
    tmp = None
    task_vars = dict()

    # Call the method under test
    testObj = ActionModule()
    testObj.run(tmp, task_vars)

# Generated at 2022-06-25 07:32:24.653423
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj_0 = ActionModule()

# Generated at 2022-06-25 07:32:29.523237
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    obj_0 = ActionModule(tmp, task_vars)
    obj_0.run(tmp, task_vars)
    test_case_0()

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 07:32:31.508608
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

if __name__ == '__main__':
    import pytest
    pytest.main(["-s", __file__])

# Generated at 2022-06-25 07:32:40.822030
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule()
    str_0 = 'YJ_'
    str_1 = 'Ei@'
    str_2 = 'z&I'
    str_3 = 'Uc{'
    str_4 = 'D1x'
    str_5 = 'z!#'
    str_6 = '^uZ'
    str_7 = 'Tm'
    str_8 = 'S'
    str_9 = '.'
    str_10 = '4'
    str_11 = 'nf'
    str_12 = '|'
    str_13 = 'h*Z'
    str_14 = '!b0'
    str_15 = '!'
    str_16 = '7'
    str_17 = '_'
    str_18 = 'I'
    str

# Generated at 2022-06-25 07:32:42.052265
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj_0 = ActionModule()
    assert isinstance(obj_0, ActionModule)
    assert True


# Generated at 2022-06-25 07:32:45.349255
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'JfV'
    str_1 = 'Y_B'
    str_2 = 't_f'
    str_3 = 'DtC'
    str_4 = 'Ytn'
    ans_0 = ActionModule()
    # Test pf_t
    assert(ans_0._task.args['args'] == 'DtC')


# Generated at 2022-06-25 07:32:51.225824
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    return str(type(module))


# Generated at 2022-06-25 07:32:52.786503
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test ActionModule.__init__()
    action_module = ActionModule()


# Generated at 2022-06-25 07:32:56.111761
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    result = action.run()


# Generated at 2022-06-25 07:33:01.264273
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Must have the same names and values as those of the utility
    bool_0 = isidentifier('_')
    bool_0 = isidentifier('9')
    bool_0 = isidentifier('_')
    str_0 = ''
    AM_0 = ActionModule(str_0)
    assert AM_0.TRANSFERS_FILES is False


# Generated at 2022-06-25 07:33:03.850790
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:33:05.683904
# Unit test for constructor of class ActionModule
def test_ActionModule():
    kwargs = {}
    test_case_0()
    x = ActionModule(**kwargs)

test_ActionModule()

# Generated at 2022-06-25 07:33:09.452504
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(str_0, any_0)
    return action_module_0

if __name__ == '__main__':
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 07:33:17.213990
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'YJ_'
    task_vars = dict()
    tmp = None
    action_module_obj_0 = ActionModule(tmp, task_vars)
    assert action_module_obj_0.run(tmp, task_vars) == None, 'abort'
    assert action_module_obj_0.run(tmp, task_vars) == None, 'abort'
    assert action_module_obj_0.run(tmp, task_vars) == None, 'abort'

test_ActionModule()

# Generated at 2022-06-25 07:33:23.160230
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("test_ActionModule")
    _task = 0
    _connection = 0
    _templar = 0
    action_module = ActionModule(_task, _connection, _templar)
    if not isinstance(action_module, ActionModule):
        print("ERROR1")


# Generated at 2022-06-25 07:33:25.170811
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp_0 = None
    task_vars_0 = None
    action_module_0 = ActionModule(tmp_0, task_vars_0)


# Generated at 2022-06-25 07:33:38.007984
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # 'task_vars' is an optional keyword argument (default: None)
    # of type: NoneType
    # 'tmp' is an optional keyword argument (default: None)
    # of type: NoneType
    assert True

# Generated at 2022-06-25 07:33:45.015345
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class MockModuleReturn:
        def __init__(self, value):
            self.value = value

        def __nonzero__(self):
            return self.value

    class MockModule:
        def __init__(self):
            self.params = {}

    class MockTask:
        def __init__(self):
            self.args = {}

    class MockTemplar:
        def template(self, value):
            return value

    class MockTaskVars:
        def __init__(self):
            self.value = {}

    return_value = MockModuleReturn(True)

    obj = ActionModule()

    task_vars = MockTaskVars()

    obj.run(None, task_vars)

if __name__ == "__main__":
    test_case_0()
    test_ActionModule

# Generated at 2022-06-25 07:33:54.443549
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:33:56.400536
# Unit test for constructor of class ActionModule
def test_ActionModule():
    fix_0 = ActionModule(task={}, connection={}, play_context={}, loader={}, templar={}, shared_loader_obj={})

# Generated at 2022-06-25 07:34:00.134156
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        # test if the constructor raises an exception when x is a string
        am = ActionModule('a')
    except TypeError:
        pass
    else:
        raise Exception('Falied to raise an exception when x is a string')

# testing methods: run
# ----------------------------------------------------------------------------------------------

# test_case_1: empty action, should be an exception

# Generated at 2022-06-25 07:34:02.424796
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var = ActionModule.run(ActionModule(), tmp = 'tmp_0', task_vars = {'int': int, 'map': map, 'None': None, 'str': str, 'isinstance': isinstance, 'dict': dict, 'len': len})


# Generated at 2022-06-25 07:34:06.918774
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.TRANSFERS_FILES == False

# Generated at 2022-06-25 07:34:09.330386
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("\n#### RUNNING test_ActionModule_run ####\n")
    str_0 = 'YJ_'
    test_case_0()


# Generated at 2022-06-25 07:34:11.802262
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert callable(ActionModule)

# Generated at 2022-06-25 07:34:18.528724
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ansible_facts = {}
    ansible_facts['logical_disk_free_space_percent'] = {}
    ansible_facts['logical_disk_free_space_percent']['C:'] = 76.54
    task_vars = {}
    task_vars['ansible_facts'] = ansible_facts
    tmp = ''
    actionModule = ActionModule(task_vars = task_vars, tmp = tmp)
    task_vars = {}
    actionModule.run(tmp = tmp, task_vars = task_vars)

# Generated at 2022-06-25 07:34:37.878175
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'P;oQm'
    str_1 = ')}v@H]Aj'
    str_2 = ':!I|'
    str_3 = '~S<'
    bool_0 = True
    action_module_0 = ActionModule(str_0, bool_0, str_1, bool_0, str_2, str_3)
    assert action_module_0.CHANGED_WHEN == '"'
    assert str_0 == "P;oQm"
    assert str_1 == ")}v@H]Aj"
    assert str_2 == ":!I|"
    assert str_3 == "~S<"
    assert bool_0 == True
    assert not action_module_0.CHECK_MODE

# Generated at 2022-06-25 07:34:41.702496
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'q=cKN@e'
    bool_0 = True
    str_1 = 'MPmk(@sI'
    str_2 = 'g\'F_6'
    action_module_0 = ActionModule(str_0, bool_0, str_1, bool_0, str_2, str_2)
    test_case_0(action_module_0)

# Generated at 2022-06-25 07:34:49.500906
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_1 = 'fS]gYY'
    str_2 = '_s?;C'
    str_0 = '[xjE,Tw'
    bool_2 = False
    str_3 = 'AnsibleActionFail'
    str_4 = '0EK{#'
    action_module_1 = ActionModule(str_0, bool_2, str_1, bool_2, str_2, str_3)
    var_1 = action_run()
    return var_1

# Generated at 2022-06-25 07:34:55.000746
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'Vv~F\x0c'
    bool_0 = True
    str_1 = 'QP5\r!'
    str_2 = '}(`?M`'
    action_module_0 = ActionModule(str_0, bool_0, str_1, bool_1, str_2, str_2)

# Generated at 2022-06-25 07:35:02.819763
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'p'
    bool_0 = True
    str_1 = 'kv?\r'
    str_2 = 'luXh'
    str_3 = 'kv?\r'
    action_module_0 = ActionModule(str_0, bool_0, str_1, bool_0, str_2, str_3)


test_case_0()

# Generated at 2022-06-25 07:35:12.105228
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Parameters: task, connection, play_context, loader, templar, shared_loader_obj
    str_0 = 'l.uXh'
    bool_0 = True
    str_1 = 'V`cESp#`h'
    str_2 = 'kv?\r'
    str_3 = 'ZHW!rljMv?\t'
    action_module_0 = ActionModule(str_0, bool_0, str_1, bool_0, str_2, str_3)
    # Parameters: task, connection, play_context, loader, templar, shared_loader_obj
    str_0 = '$N(DA/^5/B'
    str_1 = '@XZ(,b7'

# Generated at 2022-06-25 07:35:23.185041
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'l.uXh'
    bool_0 = True
    str_1 = 'V`cESp#`h'
    str_2 = 'kv?\r'
    action_module_0 = ActionModule(str_0, bool_0, str_1, bool_0, str_2, str_2)
    assert isinstance(action_module_0, ActionModule)
    assert action_module_0.run == ActionModule.run
    assert isinstance(action_module_0.TRANSFERS_FILES, bool)
    assert action_module_0._task.args == {'facts': {'a': 'b', 'c': True}}
    assert action_module_0._task.action == 'set_fact'

# Generated at 2022-06-25 07:35:28.984615
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\x01\x0cxh'
    bool_0 = True
    str_1 = '{@F2g^|'
    str_2 = '$p=q_4I'
    action_module_0 = ActionModule(str_0, bool_0, str_1, bool_0, str_2, str_2)

# Generated at 2022-06-25 07:35:31.611012
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-25 07:35:32.530257
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = test_case_0()

# Generated at 2022-06-25 07:35:52.060160
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:35:56.032017
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '|j:g'
    bool_0 = True
    str_1 = 'Ib^#x[z'
    str_2 = 'a|R.\x1f'
    action_module_0 = ActionModule(str_0, bool_0, str_1, bool_0, str_2, str_2)
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:35:58.805048
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'l.uXh'
    bool_0 = True
    str_1 = 'V`cESp#`h'
    str_2 = 'kv?\r'
    action_module_0 = ActionModule(str_0, bool_0, str_1, bool_0, str_2, str_2)

# Generated at 2022-06-25 07:36:05.365336
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'l.uXh'
    bool_0 = True
    str_1 = 'V`cESp#`h'
    str_2 = 'kv?\r'
    action_module_0 = ActionModule(str_0, bool_0, str_1, bool_0, str_2, str_2)
    tmp_0 = None
    task_vars_0 = None
    action_module_0.run(tmp_0, task_vars_0)


# Generated at 2022-06-25 07:36:08.837024
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '*o`n'
    bool_0 = True
    str_1 = '*o`n'
    str_2 = '*o`n'
    action_module_0 = ActionModule(str_0, bool_0, str_1, bool_0, str_2, str_2)
    var_0 = action_run()


# Generated at 2022-06-25 07:36:15.810721
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'x&6L9Zm'
    bool_0 = True
    str_1 = 'Y0/8h|'
    str_2 = 'oRDZ,i'
    action_module_0 = ActionModule(str_0, bool_0, str_1, bool_0, str_2, str_2)
    var_0 = action_module_0.run()
    print(var_0)

# Generated at 2022-06-25 07:36:22.583902
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'l.uXh'
    bool_0 = True
    str_1 = 'V`cESp#`h'
    str_2 = 'kv?\r'
    action_module_0 = ActionModule(str_0, bool_0, str_1, bool_0, str_2, str_2)
    assert action_module_0 is not None


# Generated at 2022-06-25 07:36:25.199709
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Du{=!|'
    bool_0 = True
    str_1 = 'TnT<'
    str_2 = 'K4g4'
    action_module_0 = ActionModule(str_0, bool_0, str_1, bool_0, str_2, str_2)
    var_0 = action_run()

# Generated at 2022-06-25 07:36:28.851265
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '^oVZ{L/j"'
    bool_0 = True
    str_1 = 'J}'
    str_2 = '"<'
    action_module_2 = ActionModule(str_0, bool_0, str_1, bool_0, str_2, str_2)

# Generated at 2022-06-25 07:36:33.570419
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_1 = '=D'
    bool_1 = False
    str_2 = '$:k'
    bool_2 = False
    str_3 = '^!\rv'
    str_4 = 'liL\\a'



# Generated at 2022-06-25 07:37:28.985573
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'l.uXh'
    bool_0 = True
    str_1 = 'V`cESp#`h'
    str_2 = 'xSX]T@'
    action_module_0 = ActionModule(str_0, bool_0, str_1, bool_0, str_2, str_2)
    action_module_0.run()


# Generated at 2022-06-25 07:37:36.407082
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    global C
    C.DEFAULT_JINJA2_NATIVE = 'false'
    C.DEFAULT_KEEP_REMOTE_FILES = 'false'
    C.DEFAULT_LOOP_WARNINGS = 'false'
    C.DEFAULT_TRANSPORT = 'ssh'
    C.DEFAULT_COLLECT_FACTS = 'false'
    C.DEFAULT_SYSLOG_FACILITY = 'LOG_USER'
    C.DEFAULT_BECOME = 'false'
    C.DEFAULT_BECOME_METHOD = 'sudo'
    C.DEFAULT_BECOME_USER = 'root'
    C.DEFAULT_FORKS = '5'
    C.DEFAULT_SUDO = 'false'
    C.DEFAULT_SUDO_USER = 'root'


# Generated at 2022-06-25 07:37:37.591726
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('\n')
    print('No unit tests found')

# Generated at 2022-06-25 07:37:47.980164
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '#'
    bool_0 = False
    str_1 = 'jk^'
    str_2 = 'R\x1e'
    str_3 = 'o'
    action_module_0 = ActionModule(str_0, bool_0, str_1, bool_0, str_2, str_2, str_3)
    str_4 = 'W'
    str_5 = 'A'
    str_6 = 'B'
    str_7 = 'A'
    str_8 = 'm'
    str_9 = 'm'
    str_10 = '/'
    str_11 = 'r'
    str_12 = 'v'
    str_13 = 'u'
    str_14 = 'i'
    str_15 = 't'
    str_16

# Generated at 2022-06-25 07:37:52.855500
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "`/F\x14^"
    bool_0 = True
    str_1 = 'P{&(@'
    str_2 = 'anae6z'
    action_module_0 = ActionModule(str_0, bool_0, str_1, bool_0, str_2, str_0)
    var_0 = action_module_0.run(None)


# Generated at 2022-06-25 07:37:59.278234
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'l.uXh'
    bool_0 = True
    str_1 = 'V`cESp#`h'
    str_2 = 'kv?\r'
    action_module_0 = ActionModule(str_0, bool_0, str_1, bool_0, str_2, str_2)
    assert action_module_0 is not None


# Generated at 2022-06-25 07:38:01.076412
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:38:06.421954
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'O[O9'
    bool_0 = True
    str_1 = 'yQ2G*w'
    str_2 = 'aX9vQ\x0c'
    action_module_0 = ActionModule(str_0, bool_0, str_1, bool_0, str_2, str_2)
    var_0 = action_run()


# Generated at 2022-06-25 07:38:12.250355
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '#!@BzPp'
    bool_0 = False
    str_1 = 'p!j'
    str_2 = '/hw?k'
    str_3 = '82u='
    action_module_0 = ActionModule(str_0, bool_0, str_1, bool_0, str_2, str_3)
    test_case_0()

# Generated at 2022-06-25 07:38:15.188236
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # call constructor and check return type is of class ActionModule
    action = ActionModule()
    assert(type(action) == ActionModule)

# Generated at 2022-06-25 07:40:18.755197
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # tmp: None
    # task_vars: None
    str_1 = 'l.uXh'
    bool_0 = True
    str_0 = 'V`cESp#`h'
    str_2 = 'kv?\r'
    str_3 = 'kv?\r'
    action_module_0 = ActionModule(str_1, bool_0, str_0, bool_0, str_2, str_3)

    # set_type: None -> None
    # set_name: None -> None
    # set_loader: None -> None
    # set_templar: None -> None
    # set_shared_loader_obj: None -> None
    # set_args: None -> None
    # set_task_type: None -> None
    # set_task: None -> None

# Generated at 2022-06-25 07:40:22.443785
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '.'
    bool_0 = True
    str_1 = '|'
    bool_1 = False
    str_2 = '!'
    str_3 = '!'
    action_module_0 = ActionModule(str_0, bool_0, str_1, bool_1, str_2, str_3)
    action_module_0.run()
    assert();  # TODO: whatever is necessary to make assert do what we want

# Generated at 2022-06-25 07:40:25.680945
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    # Assert the type of instance is ActionModule
    action_module_0 = ActionModule()
    # Compare the class of the instance to the expected value
    assert_equal(type(action_module_0), ActionModule, message='Invalid type for ActionModule class')
    # Assert the type of the returned value is dict
    assert_equal(type(action_module_0.run()), dict, message='Invalid return type for run() method')


# Generated at 2022-06-25 07:40:29.061319
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'l.uXh'
    bool_0 = True
    str_1 = 'V`cESp#`h'
    str_2 = 'kv?\r'
    action_module_0 = ActionModule(str_0, bool_0, str_1, bool_0, str_2, str_2)
    var_0 = action_run()

# Generated at 2022-06-25 07:40:30.942374
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'X6H'
    bool_0 = True
    str_1 = '&f`hEc#(+?'
    str_2 = 'JkM'
    action_module_0 = ActionModule(str_0, bool_0, str_1, bool_0, str_2, str_2)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:40:35.877303
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Given
    test_case_0()

    # When
    # Then

# Generated at 2022-06-25 07:40:36.741969
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = action_run()


# Generated at 2022-06-25 07:40:42.825733
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('###### In test_ActionModule_run() ######')
    action_module_0 = ActionModule()
    action_module_0._task.args = 'cacheable=true'
    action_module_0._task.action = 'set_fact'
    action_module_0._task.action = 'set_fact'
    action_module_0._task.action = 'set_fact'
    action_module_0._task.args = 'cacheable=true'
    action_module_0._task.action = 'set_fact'
    action_module_0._task.action = 'set_fact'
    action_module_0.run()
    print('###### End test_ActionModule_run() ######')

# Generated at 2022-06-25 07:40:48.643143
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(None, None, None, None, None, None)
    assert action_module_0.name == 'value-0'
    assert action_module_0.args == 'value-1'
    assert action_module_0.connection == 'value-2'
    assert action_module_0.delegate_to == 'value-3'
    assert action_module_0.no_log == 'value-4'
    assert action_module_0.transport == 'value-5'
    assert action_module_0.notified_by == 'value-6'


# Generated at 2022-06-25 07:40:49.665079
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()