

# Generated at 2022-06-25 07:31:17.525444
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj_ActionModule = ActionModule(task=None)
    if not obj_ActionModule:
        raise Exception('Object is null')
    # AnsibleModule object used to exit or fail, exception raised
    # ansible.utils.vars.isidentifier method call expected
    # result = obj_ActionModule.run(tmp=None, task_vars=None)


# Generated at 2022-06-25 07:31:19.078162
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # create instance for class ActionModule
    action_module = ActionModule()

    test_case_0()


# Generated at 2022-06-25 07:31:27.569169
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = test_case_0
    str_1 = str
    str_2 = 'gYa |I9n'
    str_3 = ' zrA QI3'
    str_4 = '6iEAz'
    str_5 = 'l-<aF=2'
    int_0 = 0
    int_1 = 4
    int_2 = 2
    int_3 = 5
    list_0 = [int_0, int_0, int_0, int_1]
    list_1 = [int_0, str_3, str_4, str_0]
    int_4 = 2
    set_0 = {int_4, int_4, int_4}
    set_1 = {int_2, int_2, int_1}
    int_5 = 7

# Generated at 2022-06-25 07:31:29.414450
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule()


# Generated at 2022-06-25 07:31:31.100687
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_ActionModule_run_0()
    test_ActionModule_run_1()
    test_ActionModule_run_2()


# Generated at 2022-06-25 07:31:32.437625
# Unit test for constructor of class ActionModule
def test_ActionModule():
  assert test_case_0()

test_ActionModule()

# Generated at 2022-06-25 07:31:42.179920
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = bool()
    bool_1 = bool()
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_4 = dict()
    dict_4['_ansible_parsed'] = dict_4
    dict_4['_ansible_no_log'] = dict_4
    dict_4['_ansible_check_mode'] = dict_4
    dict_4['_ansible_debug'] = dict_4
    dict_4['_ansible_diff'] = dict_4
    dict_3['_ansible_syslog_facility'] = dict_4
    dict_3['_task'] = dict_4
    dict_5 = dict()
    dict_5[''] = dict_5
    dict_5

# Generated at 2022-06-25 07:31:44.799444
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert type(action_module_0) == ActionModule

if __name__ == "__main__":

    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 07:31:48.771860
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()

test_ActionModule()
test_case_0()

# Generated at 2022-06-25 07:31:57.969546
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_2 = 'Kj*'
    str_0 = 'W#<A_H'
    str_1 = 'z@wQ\tl'
    list_0 = [str_2]
    list_1 = [str_2]
    list_1.append(str_0)
    list_1.append(str_1)
    list_1.append(str_2)
    list_1.append(str_2)
    assert list_0 != list_1
    tuple_0 = (str_0,)
    dict_0 = {}
    dict_0[str_1] = tuple_0
    ActionModule(list_1, dict_0)


# Generated at 2022-06-25 07:32:03.540521
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except:
        return 1
    else:
        return 0

# Generated at 2022-06-25 07:32:04.828960
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0.TRANSFERS_FILES == False

# Generated at 2022-06-25 07:32:06.993280
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, 'run')
    assert hasattr(ActionModule, 'TRANSFERS_FILES')
    action_module_0 = ActionModule()
    action_module_1 = ActionModule()


# Generated at 2022-06-25 07:32:11.810818
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Unit test for constructor of class ActionModule")
    try:
        test_case_0()
        print("Passtest_case_0")
    except:
        print("test_case_0 fails")

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 07:32:12.953775
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-25 07:32:15.747557
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    tmp = AnsibleActionFail
    task_vars = ActionBase()
    action_module_0 = ActionModule()
    result = action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 07:32:16.622179
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert type(action_module_0) == ActionModule


# Generated at 2022-06-25 07:32:19.553420
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule(
        task=dict(
            args=dict(
                A=123,
                B=456,
                C='test'
            ),
            action='set_fact'
        )
    )
    assert type(action_module_1) is ActionModule


# Generated at 2022-06-25 07:32:25.332696
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_obj = ActionModule()

    # Call via the v2 API
    action_result_0 = action_module_obj.run(task_vars={})

    exp_op_0 =  dict(
        ansible_facts=dict(),
        _ansible_facts_cacheable=False
    )

    assert action_result_0 == exp_op_0

# Generated at 2022-06-25 07:32:26.515810
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:32:31.626399
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()



# Generated at 2022-06-25 07:32:33.728340
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action_module_0 = ActionModule()
    except Exception as err:
        assert False, "Constructor of class ActionModule throws exception"
        print(err)

# Generated at 2022-06-25 07:32:40.705708
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_run = ActionModule()
    args = dict(cacheable=True, one=True, two=True)
    task_vars = dict()
    res = action_module_run.run(task_vars=task_vars, **args)
    assert res['ansible_facts']['one'] == True


# Generated at 2022-06-25 07:32:42.164115
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    print('Test case 1: action_module is not null')
    assert action_module is not None


# Generated at 2022-06-25 07:32:43.319823
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    assert action_module_1 != None


# Generated at 2022-06-25 07:32:46.027710
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = dict()
    action_module_1 = ActionModule()
    assert isinstance(action_module_1, ActionModule)
    action_module_1.run(None, task_vars)


# Generated at 2022-06-25 07:32:48.834876
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        _ = ActionModule()
        assert True
    except:
        assert False


# Generated at 2022-06-25 07:32:51.518721
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {}
    action_module_0 = ActionModule()
    result = action_module_0.run(task_vars=task_vars)
    assert 'failed' in result


# Generated at 2022-06-25 07:32:55.385221
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:33:00.261888
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    assert_repr = assert_repr_compare_factory(action_module_0.run())
    assert_repr({'ansible_facts': {'y': '1', 'x': '2'}, '_ansible_facts_cacheable': False})


# Generated at 2022-06-25 07:33:13.948360
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'ansible_delegated_host'
    int_0 = -1049
    dict_0 = {int_0: str_0, str_0: int_0}
    bytes_0 = b'\x98\xa2\xf0\xf9\x04\xb8wi\x1d$'
    bytes_1 = b"\xa6']\xa4\xc6D\x93\xf1\xfd\x1a\x88:\x1cm\x88\xbb;C"
    assert ActionModule(str_0, int_0, dict_0, bytes_0, int_0, bytes_1)


# Generated at 2022-06-25 07:33:22.937068
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = ['var_0', 'var_1', 'var_2', 'var_3', 'var_4', 'var_5']
    str_0 = 'ansible.module_utils.parsing.convert_bool'
    int_0 = -1046
    dict_0 = {int_0: str_0, str_0: int_0}
    bytes_0 = b'\x98\xa2\xf0\xf9\x04\xb8wi\x1d$'
    bytes_1 = b"\xa6']\xa4\xc6D\x93\xf1\xfd\x1a\x88:\x1cm\x88\xbb;C"

# Generated at 2022-06-25 07:33:29.844768
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'ansible_delegated_host'
    int_0 = -1049
    dict_0 = {int_0: str_0, str_0: int_0}
    bytes_0 = b'\x98\xa2\xf0\xf9\x04\xb8wi\x1d$'
    bytes_1 = b"\xa6']\xa4\xc6D\x93\xf1\xfd\x1a\x88:\x1cm\x88\xbb;C"
    action_module_0 = ActionModule(str_0, int_0, dict_0, bytes_0, int_0, bytes_1)


# Generated at 2022-06-25 07:33:34.082301
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  str_0 = '.'
  str_1 = '\x00\x13\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
  str_2 = '\x00\x13\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xa8'
  dict_0 = {str_0: str_2, str_2: str_0, str_1: str_1}
  bool_0 = bool()
  bool_1 = bool()

# Generated at 2022-06-25 07:33:35.436923
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 07:33:40.041691
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        dict_0 = dict()
        str_0 = 'g\x8f\xc5\xd1\x18\x16p!\x99\xef'
        str_1 = '\xee\xb5Q\x85\xf6\x06\x07\x9d\xfe\x82\x9f\xf4\xce\xb6\x1a\x7f'
        action_module_0 = ActionModule(str_0, dict_0, dict_0, str_1, dict_0, dict_0)
    except TypeError as err:
        print('Exception calling constructor of class ActionModule: ' + str(err))


# Generated at 2022-06-25 07:33:46.846218
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'test_repo'
    int_0 = 1708147126
    dict_0 = {int_0: str_0, str_0: int_0}
    bytes_0 = b'\x83\x82\xaeU\x0c,\xeb\x81\x9cX\xc6d'
    int_1 = -966431651
    bytes_1 = b'u!\xec\x9aeV\x8b\x1b\xff\xbe\x01\x83\x06'
    action_module_0 = ActionModule(str_0, int_0, dict_0, bytes_0, int_1, bytes_1)
    var_0 = action_module_0._task
    # var_0 = action_module_0._templar

# Generated at 2022-06-25 07:33:55.770256
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'ansible_delegated_host'
    int_0 = -1049
    dict_0 = {int_0: str_0, str_0: int_0}
    bytes_0 = b'\x98\xa2\xf0\xf9\x04\xb8wi\x1d$'
    bytes_1 = b"\xa6']\xa4\xc6D\x93\xf1\xfd\x1a\x88:\x1cm\x88\xbb;C"
    action_module_0 = ActionModule(str_0, int_0, dict_0, bytes_0, int_0, bytes_1)
    var_0 = action_module_0.run()

test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 07:34:02.722001
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  # define a local var for storing var_0
  var_0 = None
  # call method to test
  result = var_0.run()
  # assert the result
  assert result == (None, "No key/value pairs provided, at least one is required for this action to succeed")


if __name__ == '__main__':
  test_case_0()
  test_ActionModule_run()

# Generated at 2022-06-25 07:34:11.759191
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'ansible_delegated_host'
    int_0 = -1049
    dict_0 = {int_0: str_0, str_0: int_0}
    bytes_0 = b'\x98\xa2\xf0\xf9\x04\xb8wi\x1d$'
    bytes_1 = b"\xa6']\xa4\xc6D\x93\xf1\xfd\x1a\x88:\x1cm\x88\xbb;C"
    assert isinstance(ActionModule(str_0, int_0, dict_0, bytes_0, int_0, bytes_1), ActionModule)


# Generated at 2022-06-25 07:34:28.979608
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Testing for exception in [[action_module_0.run()]]. Arguments: tmp=None, task_vars=None

    str_0 = 'ansible_delegated_host'
    int_0 = -1049
    dict_0 = {int_0: str_0, str_0: int_0}
    bytes_0 = b"\x0b3\xe6\xe8\xa0\xb0\x9b\x03\xc5'k\x0c\xaa\x12\x8f\xbe"
    bytes_1 = b'\x98\xa2\xf0\xf9\x04\xb8wi\x1d$'

# Generated at 2022-06-25 07:34:38.596924
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'f\xe3-\x16\x96\x99\x17\xce\xb0\x8a\xbe\x91\xf2\x85\x9a\xde'
    int_0 = 9
    set_0 = {str_0, int_0}
    bytes_0 = b'\x1c\x19\x81\x98\x07\xde\x88\x89\xed\x90\xb2\xd2\x18\xf0'
    action_module_0 = ActionModule(int_0, str_0, set_0, bytes_0)
    action_run_0 = action_module_0.run(tmp=None)
    assert action_run_0 != False


# Generated at 2022-06-25 07:34:48.195227
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'ansible_delegated_host'
    int_0 = -1049
    dict_0 = {int_0: str_0, str_0: int_0}
    bytes_0 = b'\x98\xa2\xf0\xf9\x04\xb8wi\x1d$'
    bytes_1 = b"\xa6']\xa4\xc6D\x93\xf1\xfd\x1a\x88:\x1cm\x88\xbb;C"
    action_module_0 = ActionModule(str_0, int_0, dict_0, bytes_0, int_0, bytes_1)
    # assert action_module_0.TRANSFERS_FILES == False


# Generated at 2022-06-25 07:34:57.776328
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'ansible_delegated_host'
    int_0 = -1049
    dict_0 = {int_0: str_0, str_0: int_0}
    bytes_0 = b'\x98\xa2\xf0\xf9\x04\xb8wi\x1d$'
    bytes_1 = b"\xa6']\xa4\xc6D\x93\xf1\xfd\x1a\x88:\x1cm\x88\xbb;C"
    action_module_0 = ActionModule(str_0, int_0, dict_0, bytes_0, int_0, bytes_1)
    dict_1 = {'ansible_facts': dict_0, '_ansible_facts_cacheable': int_0}
    del str_

# Generated at 2022-06-25 07:35:06.110783
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'ansible_delegated_host'
    int_0 = -1049
    dict_0 = {int_0: str_0, str_0: int_0}
    bytes_0 = b'\x98\xa2\xf0\xf9\x04\xb8wi\x1d$'
    bytes_1 = b"\xa6']\xa4\xc6D\x93\xf1\xfd\x1a\x88:\x1cm\x88\xbb;C"
    action_module_0 = ActionModule(str_0, int_0, dict_0, bytes_0, int_0, bytes_1)
    var_0 = action_run()

# Generated at 2022-06-25 07:35:12.508905
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "8x\xbf\xf0\x13\x0f\xe6\x1a\xc2\x89N!\x81\x82\xe6\x13\xd9\xf8/\x02\xce\xc1\xe8'\x97\x15\xf6\xe6\x1eu\xebj\x92>\x17\x06\x08`"
    int_0 = -1049
    dict_0 = {int_0: str_0, str_0: int_0}
    bytes_0 = b'\x98\xa2\xf0\xf9\x04\xb8wi\x1d$'

# Generated at 2022-06-25 07:35:23.367712
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'ansible_delegated_host'
    int_0 = -1049
    dict_0 = {int_0: str_0, str_0: int_0}
    bytes_0 = b'\x98\xa2\xf0\xf9\x04\xb8wi\x1d$'
    bytes_1 = b"\xa6']\xa4\xc6D\x93\xf1\xfd\x1a\x88:\x1cm\x88\xbb;C"
    action_module_0 = ActionModule(str_0, int_0, dict_0, bytes_0, int_0, bytes_1)

    action_module_0.run()
    print("Unit test for method run of class ActionModule: OK")


# Generated at 2022-06-25 07:35:32.482136
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'e\xd3\xd9\x16\xb7+E\xfa'
    int_0 = -1049
    dict_0 = {int_0: str_0, str_0: int_0}
    bytes_0 = b'\x98\xa2\xf0\xf9\x04\xb8wi\x1d$'
    bytes_1 = b"\xa6']\xa4\xc6D\x93\xf1\xfd\x1a\x88:\x1cm\x88\xbb;C"
    action_module_0 = ActionModule(str_0, int_0, dict_0, bytes_0, int_0, bytes_1)
    action_run(*args,**kwargs)


# Generated at 2022-06-25 07:35:40.222127
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'ansible_delegated_host'
    int_0 = -1049
    dict_0 = {int_0: str_0, str_0: int_0}
    bytes_0 = b'\x98\xa2\xf0\xf9\x04\xb8wi\x1d$'
    bytes_1 = b"\xa6']\xa4\xc6D\x93\xf1\xfd\x1a\x88:\x1cm\x88\xbb;C"
    action_module_0 = ActionModule(str_0, int_0, dict_0, bytes_0, int_0, bytes_1)
    print(action_module_0)


# Generated at 2022-06-25 07:35:49.043352
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'ansible_delegated_host'
    int_0 = -1049
    dict_0 = {int_0: str_0, str_0: int_0}
    bytes_0 = b'\x98\xa2\xf0\xf9\x04\xb8wi\x1d$'
    bytes_1 = b"\xa6']\xa4\xc6D\x93\xf1\xfd\x1a\x88:\x1cm\x88\xbb;C"
    action_module_0 = ActionModule(str_0, int_0, dict_0, bytes_0, int_0, bytes_1)
    var_0 = action_run()

# Generated at 2022-06-25 07:36:17.062673
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert_equal(action_module_0.action_name, '', 'wrong action_name in ActionModule')
    assert_equal(action_module_0.action_loaded, False, 'wrong action_loaded in ActionModule')
    assert_equal(action_module_0.action_enabled, False, 'wrong action_enabled in ActionModule')
    assert_true('_debugger' in vars(action_module_0), '_debugger variable not present in ActionModule')
    assert_true('task_vars' in vars(action_module_0), 'task_vars variable not present in ActionModule')
    assert_true('play_context' in vars(action_module_0), 'play_context variable not present in ActionModule')

# Generated at 2022-06-25 07:36:27.477647
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Case 0
    str_0 = 'ansible_delegated_host'
    int_0 = -1049
    dict_0 = {int_0: str_0, str_0: int_0}
    bytes_0 = b'\x98\xa2\xf0\xf9\x04\xb8wi\x1d$'
    bytes_1 = b"\xa6']\xa4\xc6D\x93\xf1\xfd\x1a\x88:\x1cm\x88\xbb;C"
    action_module_0 = ActionModule(str_0, int_0, dict_0, bytes_0, int_0, bytes_1)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:36:31.231244
# Unit test for constructor of class ActionModule
def test_ActionModule():

  print("Test ActionModule class constructor")


# Generated at 2022-06-25 07:36:32.523887
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:36:35.179427
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 07:36:42.937903
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xfa\x9f@g\x8a\xdc\xaa\x90\x1c\x0e\x9b\xe5'

    # Testing with args
    tmp = None
    task_vars = None

    result = ActionModule.run(tmp, task_vars)
    assert result == 'ActionBase.run() not implemented in this class'

    # Testing with kwargs
    kwargs = {'tmp': None, 'task_vars': None}
    result = ActionModule.run(**kwargs)
    assert result == 'ActionBase.run() not implemented in this class'

# Unit tests for class utils.vars isidentifier

# Generated at 2022-06-25 07:36:48.791740
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('unit test start')
    action_module_0 = ActionModule()
    assert True, "Failed in <test_ActionModule_run>"
    print('unit test end')


# Generated at 2022-06-25 07:36:49.169287
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:36:55.310225
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Input parameters
    tmp = string_types('')
    task_vars = dict()

    # Output parameters
    ansible_delegated_host = string_types()
    ansible_facts = dict()

    # type annotation return value
    action_run_retval_0: dict

    # type annotation local variables
    str_0: str
    int_0: int
    dict_0: dict
    bytes_0: bytes
    bytes_1: bytes
    action_module_0: ansible.plugins.action.ActionModule

    # type annotation callable target
    if (not (tmp)):
        raise AnsibleActionFail('No key/value pairs provided, at least one is required for this action to succeed')
    else:
        action_run_retval_0 = dict()

    # type annotation return value
   

# Generated at 2022-06-25 07:37:04.247152
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test_case_0
    str_0 = 'ansible_delegated_host'
    int_0 = -1049
    dict_0 = {int_0: str_0, str_0: int_0}
    bytes_0 = b'\x98\xa2\xf0\xf9\x04\xb8wi\x1d$'
    bytes_1 = b"\xa6']\xa4\xc6D\x93\xf1\xfd\x1a\x88:\x1cm\x88\xbb;C"
    action_module_0 = ActionModule(str_0, int_0, dict_0, bytes_0, int_0, bytes_1)
    var_0 = action_module_0.run()


# Interface for generating ActionModule
ActionModuleInterface = named

# Generated at 2022-06-25 07:37:46.664369
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'md5_sum'
    str_1 = 'md5_sum'
    var_0 = bytes(b'\xfd\x12\x7f\x95\xd2\xa0\x88\xd2\x16\x96\x1e\xb4\x83\x8b\x90\x16\x01')
    var_1 = -1558
    var_2 = dict({var_0: var_1, str_1: var_0})
    var_3 = bytes(b'\xd7\x8c\x17\x1c\xd5\x95\xba\x91\x1e\x81\x1e\xcd\x8b\x90\xc2\x96\x90')
    var_4 = -1097
   

# Generated at 2022-06-25 07:37:54.510300
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'ansible_delegated_host'
    int_0 = -1049
    dict_0 = {int_0: str_0, str_0: int_0}
    bytes_0 = b'\x98\xa2\xf0\xf9\x04\xb8wi\x1d$'
    bytes_1 = b"\xa6']\xa4\xc6D\x93\xf1\xfd\x1a\x88:\x1cm\x88\xbb;C"
    action_module_0 = ActionModule(str_0, int_0, dict_0, bytes_0, int_0, bytes_1)


# Generated at 2022-06-25 07:37:55.908782
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Testing constructor')
    obj = ActionModule()
    assert True


# Generated at 2022-06-25 07:37:57.140026
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-25 07:38:05.454414
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'ansible_delegated_host'
    int_0 = -1049
    dict_0 = {int_0: str_0, str_0: int_0}
    bytes_0 = b'\x98\xa2\xf0\xf9\x04\xb8wi\x1d$'
    bytes_1 = b"\xa6']\xa4\xc6D\x93\xf1\xfd\x1a\x88:\x1cm\x88\xbb;C"
    action_module_0 = ActionModule(str_0, int_0, dict_0, bytes_0, int_0, bytes_1)
    assert isinstance(action_module_0, ActionModule)

    str_0 = 'ansible_delegated_host'
    int_0

# Generated at 2022-06-25 07:38:06.873684
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    var_0 = ActionModule.run(dict_0)

# Generated at 2022-06-25 07:38:17.781209
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'ansible_delegated_host'
    int_0 = -1049
    dict_0 = {int_0: str_0, str_0: int_0}
    bytes_0 = b'\x98\xa2\xf0\xf9\x04\xb8wi\x1d$'
    bytes_1 = b"\xa6']\xa4\xc6D\x93\xf1\xfd\x1a\x88:\x1cm\x88\xbb;C"
    action_module_0 = ActionModule(str_0, int_0, dict_0, bytes_0, int_0, bytes_1)

if __name__ == '__main__':
    main(verbosity=2)

# vim: lline tabstop=4 shiftwidth=4

# Generated at 2022-06-25 07:38:18.640293
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert_equals(1, 1)


# Generated at 2022-06-25 07:38:22.974220
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:38:27.636699
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isidentifier(str_0)
    assert len(dict_0)
    assert var_0 == {'ansible_facts': dict_0, '_ansible_facts_cacheable': bool_0}



# Generated at 2022-06-25 07:40:22.050032
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_1 = 'ansible_delegated_host'
    int_1 = -1049
    dict_1 = {int_1: str_1, str_1: int_1}
    bytes_2 = b'\x98\xa2\xf0\xf9\x04\xb8wi\x1d$'
    bytes_3 = b"\xa6']\xa4\xc6D\x93\xf1\xfd\x1a\x88:\x1cm\x88\xbb;C"
    action_module_1 = ActionModule(str_1, int_1, dict_1, bytes_2, int_1, bytes_3)

# Generated at 2022-06-25 07:40:23.994696
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = ActionModule.run(parameter_7)
    str_1 = ActionModule.run(parameter_7, parameter_1)

# Generated at 2022-06-25 07:40:25.137646
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert (ActionModule.TRANSFERS_FILES == False)

# Generated at 2022-06-25 07:40:31.671483
# Unit test for constructor of class ActionModule
def test_ActionModule():
	str_0 = 'ansible_delegated_host'
	int_0 = -1049
	dict_0 = {int_0: str_0, str_0: int_0}
	bytes_0 = b'\x98\xa2\xf0\xf9\x04\xb8wi\x1d$'
	bytes_1 = b"\xa6']\xa4\xc6D\x93\xf1\xfd\x1a\x88:\x1cm\x88\xbb;C"
	action_module_0 = ActionModule(str_0, int_0, dict_0, bytes_0, int_0, bytes_1)

	#TODO: check if there is a suitable assert to check this test case
	assert true


# Generated at 2022-06-25 07:40:39.592587
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ansible_facts = {'not': False, 'yes': True,
                     'no': False, 'false': False, 'true': True}
    bool_val = ''
    # Run method of the class
    action_module_0 = ActionModule.run(bool_val)
    # Check the output
    assert action_module_0 == ansible_facts, "test_ActionModule_run: "

# Generated at 2022-06-25 07:40:45.363158
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'ansible_delegated_host'
    int_0 = -1049
    dict_0 = {int_0: str_0, str_0: int_0}
    bytes_0 = b'\x98\xa2\xf0\xf9\x04\xb8wi\x1d$'
    bytes_1 = b"\xa6']\xa4\xc6D\x93\xf1\xfd\x1a\x88:\x1cm\x88\xbb;C"
    action_module_0 = ActionModule(str_0, int_0, dict_0, bytes_0, int_0, bytes_1)
    var_0 = action_run(None, dict_0)

# Generated at 2022-06-25 07:40:53.984401
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'ansible_delegated_host'
    int_0 = -1049
    dict_0 = {int_0: str_0, str_0: int_0}
    bytes_0 = b'\x98\xa2\xf0\xf9\x04\xb8wi\x1d$'
    bytes_1 = b"\xa6']\xa4\xc6D\x93\xf1\xfd\x1a\x88:\x1cm\x88\xbb;C"
    action_module_0 = ActionModule(str_0, int_0, dict_0, bytes_0, int_0, bytes_1)
    var_0 = action_run()

# Generated at 2022-06-25 07:41:01.951140
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'ansible_delegated_host'
    int_0 = -1049
    dict_0 = {int_0: str_0, str_0: int_0}
    bytes_0 = b'\x98\xa2\xf0\xf9\x04\xb8wi\x1d$'
    bytes_1 = b"\xa6']\xa4\xc6D\x93\xf1\xfd\x1a\x88:\x1cm\x88\xbb;C"
    int_2 = 134
    dict_1 = {int_0: int_2, str_0: int_0}

# Generated at 2022-06-25 07:41:04.177486
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    # Exception should be raised for invalid argument
    try:
        action_module_0.run(None)
    except AnsibleActionFail:
        pass

# Generated at 2022-06-25 07:41:10.712293
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_2 = 'ansible_delegated_host'
    int_2 = -1049
    dict_2 = {int_2: str_2, str_2: int_2}
    bytes_2 = b'\x98\xa2\xf0\xf9\x04\xb8wi\x1d$'
    bytes_3 = b"\xa6']\xa4\xc6D\x93\xf1\xfd\x1a\x88:\x1cm\x88\xbb;C"
    action_module_0 = ActionModule(str_2, int_2, dict_2, bytes_2, int_2, bytes_3)
