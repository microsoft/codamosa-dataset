

# Generated at 2022-06-25 07:31:25.178255
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    int_0 = -675
    str_0 = '""'
    tuple_0 = (int_0,)
    bytes_0 = b'\xbe\x1a\x00'
    action_module_0 = ActionModule(set_0, int_0, str_0, tuple_0, bytes_0, tuple_0)
    result = action_module_0.run()
    assert result is None


# Generated at 2022-06-25 07:31:32.675519
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        set_0 = set()
        int_0 = -1438
        str_0 = '%d{k,'
        tuple_0 = (int_0,)
        bytes_0 = b'\xcaH'
        action_module_0 = ActionModule(set_0, int_0, str_0, tuple_0, bytes_0, tuple_0)
    except TypeError as e:
        print(e)
        print(traceback.format_exc())
        assert True
    else:
        assert False



# Generated at 2022-06-25 07:31:42.249650
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # attempt to make the actual command
    self._task.args = self._templar.template(self._task.args)
    if isinstance(self._task.args, dict):
        # convert the action args from a dict to an argv string
        self._task.args = ' '.join(["%s=%s" % (k, quote(v)) for (k, v) in iteritems(self._task.args)])
    elif not isinstance(self._task.args, string_types):
        # if it's not a string, we don't know how to make it into a command
        raise AnsibleActionFail('Unable to convert arguments to a command: %s' % self._task.args)

    # mark the command as being run in the shell, if that's how this action is
    # running commands

# Generated at 2022-06-25 07:31:49.904906
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Input Parameters
    tmp = None
    task_vars = dict()

    result = super(ActionModule, self).run(tmp, task_vars)
    del tmp  # tmp no longer has any effect

    facts = {}
    cacheable = boolean(self._task.args.pop('cacheable', False))

    if self._task.args:
        for (k, v) in iteritems(self._task.args):
            k = self._templar.template(k)

            if not isidentifier(k):
                raise AnsibleActionFail("The variable name '%s' is not valid. Variables must start with a letter or underscore character, "
                                        "and contain only letters, numbers and underscores." % k)

            # NOTE: this should really use BOOLEANS from convert_bool, but only in the k=v case

# Generated at 2022-06-25 07:31:57.809870
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        set_0 = set()
        int_0 = -1438
        str_0 = '%d{k,'
        tuple_0 = (int_0,)
        bytes_0 = b'\xcaH'
        action_module_0 = ActionModule(set_0, int_0, str_0, tuple_0, bytes_0, tuple_0)
        var_0 = action_module_0.run()
        var_1 = action_run()
        assert var_0 == var_1

    except AssertionError:
        print('AssertionError raised in test_ActionModule_run')



# Generated at 2022-06-25 07:32:03.934551
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test init and init._initialize_module_args

    result = action_module_0.run(None, None)
    assert result == None, "action_module_0._initialize_module_args did not return expected result"

    result = action_module_0.run(None, None)
    assert result == None, "action_module_0._initialize_module_args did not return expected result"
    # Test _execute_module

    result = action_module_0.run(None, None)
    assert result == None, "action_module_0._execute_module did not return expected result"


# Generated at 2022-06-25 07:32:13.482531
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    int_0 = -1177
    str_0 = '$dP'
    tuple_0 = (int_0,)
    bytes_0 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    action_module_0 = ActionModule(set_0, int_0, str_0, tuple_0, bytes_0, tuple_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:32:15.707755
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test that action_module_0 have the correct value
    assert action_module_0
    # Test that return the correct value
    var_0 = action_run()
    assert var_0

# Generated at 2022-06-25 07:32:20.012592
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    int_0 = -1095
    str_0 = 'NF@$!0'
    tuple_0 = (int_0,)
    bytes_0 = b'\xcb]'
    action_module_0 = ActionModule(set_0, int_0, str_0, tuple_0, bytes_0, tuple_0)
    action_module_0.run()
    var_0 = action_run()
    assert var_0 == var_0

# Generated at 2022-06-25 07:32:20.618267
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_run()


# Generated at 2022-06-25 07:32:28.129579
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    my_obj = ActionModule()
    tmp = None
    task_vars = None

    # Calling run() method
    my_obj.run(tmp, task_vars)

# Generated at 2022-06-25 07:32:29.117430
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None


# Generated at 2022-06-25 07:32:32.349150
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    arg_0 = None
    arg_1 = None
    action_module = ActionModule(arg_0, arg_1)
    arg_2 = None
    arg_3 = None
    var_0 = action_module.run(arg_2, arg_3)

# Generated at 2022-06-25 07:32:34.099107
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule()
    var_1 = None
    var_2 = None
    var_0.run(var_1, var_2)

# Generated at 2022-06-25 07:32:35.507478
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert var_0


# Generated at 2022-06-25 07:32:45.165767
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = None

    # This is a hack to make it work with Ansible 2.6
    # "result" is attribute of "self" in module_utils.basic.AnsibleModule, which is absent in module_utils.basic.AnsibleModule
    # Hence, this test case will only work for Ansible 2.5

    #temp_dict = {"task_vars": var_0}
    #am = ActionModule(var_0,var_0)
    #assert am.run(None,var_0) == temp_dict

    am = ActionModule(var_0,var_0)
    assert am.run(None,var_0) == {}

# Generated at 2022-06-25 07:32:47.987289
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:32:54.698157
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule()
    var_1 = dict()
    var_2 = None
    var_3 = dict()
    var_1['cacheable'] = False
    var_1['http_proxy'] = None
    var_1['no_log'] = False
    var_1['https_proxy'] = None
    var_1['force_basic_auth'] = False
    var_1['async'] = 0
    var_1['validate_certs'] = True
    var_1['follow'] = False
    var_1['url_password'] = None
    var_1['module_path'] = None
    var_1['forks'] = 5
    var_1['become'] = False
    var_1['become_method'] = 'sudo'
    var_1['become_user']

# Generated at 2022-06-25 07:32:55.795017
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    act = ActionModule()
    act.run()
    return

# Generated at 2022-06-25 07:33:05.786246
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    fixture_path = os.path.join(C.DEFAULT_LOCAL_TMP, 'ansible_ActionModule_run.yml')
    with open(fixture_path) as fixture:
        output = yaml.load(fixture)
    fixture_path = os.path.join(C.DEFAULT_LOCAL_TMP, 'ansible_ActionModule_run.json')
    with open(fixture_path) as fixture:
        output_json = json.load(fixture)

    tmp = None

    task_vars = None

    m_super = MagicMock()
    m_super.return_value = output
    m_task = MagicMock()
    m_task._task.args = {}
    m_task.args = {}

# Generated at 2022-06-25 07:33:14.285136
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:33:18.071150
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert callable(getattr(ActionModule, "run", None))
    set_0 = set()
    int_0 = -424
    str_0 = 'an'
    tuple_0 = ()
    bytes_0 = b'\x82\x9e\xda<mr'

# Generated at 2022-06-25 07:33:23.981868
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    int_0 = 9187
    str_0 = 'J*n'
    tuple_0 = (int_0,)
    bytes_0 = b'M(<'
    action_module_0 = ActionModule(set_0, int_0, str_0, tuple_0, bytes_0, tuple_0)


# Generated at 2022-06-25 07:33:33.917384
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    int_0 = -1438
    str_0 = '%d{k,'
    tuple_0 = (int_0,)
    bytes_0 = b'\xcaH'
    action_module_0 = ActionModule(set_0, int_0, str_0, tuple_0, bytes_0, tuple_0)
    int_1 = -1270
    str_1 = 'W'
    dict_0 = dict()
    list_0 = []
    dict_1 = dict()
    dict_2 = dict()
    dict_2['x'] = dict_1
    dict_2['x']['x'] = dict_1['x']
    dict_0['x'] = dict_2
    dict_0['x']['x']['x'] = dict_2

# Generated at 2022-06-25 07:33:43.168898
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    int_0 = -11308
    str_0 = '|'
    tuple_0 = (int_0,)
    bytes_0 = b'\xab\xf34'
    action_module_0 = ActionModule(set_0, int_0, str_0, tuple_0, bytes_0, tuple_0)
    assert type(action_module_0._task) == type(set_0)
    assert action_module_0._task is set_0
    assert type(action_module_0._connection) == type(int_0)
    assert action_module_0._connection is int_0
    assert type(action_module_0._play_context) == type(str_0)
    assert action_module_0._play_context is str_0

# Generated at 2022-06-25 07:33:53.584966
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    int_0 = -1438
    str_0 = '%d{k,'
    tuple_0 = (int_0,)
    bytes_0 = b'\xcaH'
    action_module_0 = ActionModule(set_0, int_0, str_0, tuple_0, bytes_0, tuple_0)
    var_0 = action_module_0.run(int_0, int_0)
    int_0 = -5462
    set_1 = set([int_0, True, int_0])
    list_0 = []
    for int_1 in set_1:
        list_0.extend([int_1, True, int_0])
    for int_2 in list_0:
        var_1 = int_2

# Generated at 2022-06-25 07:34:00.323806
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        var_0 = ActionModule()
        var_1 = var_0.run(((14, True), {12: '\xcaH'}))
        yield var_1,
        assert var_1 == 12, 'assertion failed'
    except ActionFail:
        yield None
    finally:
        yield var_0,

if __name__ == '__main__':
    import sys
    import logging
    logging.basicConfig(stream=sys.stderr)
    logging.getLogger(__name__).setLevel(logging.DEBUG)
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:34:07.902108
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_1 = set()
    int_0 = -1438
    str_0 = '%d{k,'
    tuple_0 = (int_0,)
    bytes_0 = b'\xcaH'
    action_module_0 = ActionModule(set_1, int_0, str_0, tuple_0, bytes_0, tuple_0)
    assert(action_module_0.run() == 'ansible_facts')


# Generated at 2022-06-25 07:34:08.862997
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_action_0 = ActionModule()


# Generated at 2022-06-25 07:34:14.463173
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    int_0 = -558
    str_0 = 'lQ&'
    tuple_0 = (int_0,)
    bytes_0 = b'\x0f\xd8\x92\x9ck\x87\x97'
    action_module_0 = ActionModule(set_0, int_0, str_0, tuple_0, bytes_0, tuple_0)

    # test constructor
    assert isinstance(action_module_0, ActionModule)

    # test action_run method
    assert action_module_0.action_run() == None


# Generated at 2022-06-25 07:34:27.867116
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert var_0 is False
    

# Generated at 2022-06-25 07:34:33.730711
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    if not var_0:
        if var_0:
            var_0 = -867
        else:
            var_0 = None
            var_1 = 0
            var_0 = var_1 + var_0
        # Fixme
        # var_0 = var_0 + var_0
    return var_0

# Generated at 2022-06-25 07:34:41.111308
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    int_0 = -1438
    str_0 = '%d{k,'
    tuple_0 = (int_0,)
    bytes_0 = b'\xcaH'
    action_module_0 = ActionModule(set_0, int_0, str_0, tuple_0, bytes_0, tuple_0)
    assert action_module_0 != None


# Generated at 2022-06-25 07:34:51.204568
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    int_0 = -1901
    str_0 = 'G`ce#)E'
    tuple_0 = (int_0,)
    bytes_0 = b'\t\xa2\xe2\x89\xd5\x84\xc4\x95\xed\x8a\xbf\xf4'
    action_module_0 = ActionModule(set_0, int_0, str_0, tuple_0, bytes_0, tuple_0)
    # assert call.data['args'] == set_0
    result = action_module_0.run(set_0, result)
    assert result == result

# Generated at 2022-06-25 07:34:53.842613
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 07:34:57.351138
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    int_0 = -92
    str_0 = 'bX;'
    tuple_0 = (set_0,)
    bytes_0 = b'/6f'
    action_module_0 = ActionModule(set_0, int_0, str_0, tuple_0, bytes_0, tuple_0)


# Generated at 2022-06-25 07:35:01.386804
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args_0 = dict()
    action_module_0 = ActionModule(args_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:35:02.506914
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 07:35:06.317738
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    int_1 = -1438
    str_1 = '%d{k,'
    tuple_0 = (int_1,)
    bytes_0 = b'\xcaH'
    tuple_1 = (int_1, )
    action_module_0 = ActionModule(set_0, int_1, str_1, tuple_0, bytes_0, tuple_1)
    var_0 = action_run()

# Generated at 2022-06-25 07:35:10.106064
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    int_0 = -7224
    str_0 = '$ZzM'
    tuple_0 = (int_0,)
    bytes_0 = b'\t!e'
    action_module_0 = ActionModule(set_0, int_0, str_0, tuple_0, bytes_0, tuple_0)
    action_module_0.main()
    var_0 = action_module_0.run()


# Generated at 2022-06-25 07:35:37.570152
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set(['9', '%'])
    int_1 = -61
    str_0 = '-u'
    tuple_0 = (int_1,)
    bytes_0 = b'\x8a'
    action_module_1 = ActionModule(set_0, int_1, str_0, tuple_0, bytes_0, tuple_0)
    tuple_1 = ()
    dict_0 = dict()
    var_0 = action_module_1.run(tuple_1, dict_0)
    assert var_0 == dict()


# Generated at 2022-06-25 07:35:42.047377
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print(ActionModule.run.__name__)



# Generated at 2022-06-25 07:35:45.948689
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_1 = set()
    int_1 = -1493
    str_1 = '%d{M,'
    tuple_1 = (int_1,)
    bytes_1 = b'\xcaH'
    action_module_1 = ActionModule(set_1, int_1, str_1, tuple_1, bytes_1, tuple_1)


# Generated at 2022-06-25 07:35:52.967665
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    int_0 = -11110
    str_0 = 'kSS\x1f'
    tuple_0 = (int_0,)
    bytes_0 = b'{;{\x81'
    dict_0 = {'rotor_count': int_0, 'missions': 'T\x00j', 'targets': int_0, 'squadron': dict_0, 'name': int_0}
    action_module_0 = ActionModule(set_0, int_0, str_0, tuple_0, bytes_0, dict_0)
    var_0 = action_module_0.run()
    assert var_0 == dict_0


# Generated at 2022-06-25 07:35:56.841420
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        set_0 = set()
        int_0 = -1438
        str_0 = '%d{k,'
        tuple_0 = (int_0,)
        bytes_0 = b'\xcaH'
        ActionModule(set_0, int_0, str_0, tuple_0, bytes_0, tuple_0)
    except Exception as exception_0:
        print(str(exception_0))


# Generated at 2022-06-25 07:36:03.752357
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  try:
    set_0 = set()
    int_0 = -1438
    str_0 = '%d{k,'
    tuple_0 = (int_0,)
    bytes_0 = b'\xcaH'
    action_module_0 = ActionModule(set_0, int_0, str_0, tuple_0, bytes_0, tuple_0)
    action_module_0.run()
  except:
    assert False



# Generated at 2022-06-25 07:36:04.593580
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:36:08.436605
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    int_0 = -1438
    str_0 = '%d{k,'
    tuple_0 = (int_0,)
    bytes_0 = b'\xcaH'
    action_module_0 = ActionModule(set_0, int_0, str_0, tuple_0, bytes_0, tuple_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:36:11.418374
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    int_0 = -1438
    str_0 = '%d{k,'
    tuple_0 = (int_0,)
    bytes_0 = b'\xcaH'
    action_module_0 = ActionModule(set_0, int_0, str_0, tuple_0, bytes_0, tuple_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:36:16.824712
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create an instance of the class with set of values to test with
    instance = ActionModule(set(), -1438, '%d{k,', (int_0,), b'\xcaH', int_0,)

    # run and check the output
    result = instance.run()
    assert result == True

# Generated at 2022-06-25 07:37:09.844413
# Unit test for constructor of class ActionModule
def test_ActionModule():
    templar_0 = Templar(dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict())
    tuple_0 = (dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), templar_0, dict(), dict(), dict())
    int_0 = -1438
    str_0 = 'n@u<7'
    tuple_1 = (int_0,)
    bytes_0 = b'\xcaH'
    action_module_0 = ActionModule(tuple_0, int_0, str_0, tuple_1, bytes_0, tuple_1)
    action_module_1 = Action

# Generated at 2022-06-25 07:37:17.663734
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    int_0 = 1243
    str_0 = 'R'
    tuple_0 = (int_0,)
    bytes_0 = b'\xa0'
    action_module_0 = ActionModule(set_0, int_0, str_0, tuple_0, bytes_0, tuple_0)
    action_module_0.run()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:37:18.461858
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module_0 = ActionModule()
    test_case_0()

# Generated at 2022-06-25 07:37:22.797532
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    int_0 = 42
    str_0 = '%d{k,'
    tuple_0 = (int_0,)
    bytes_0 = b'6'
    action_module_0 = ActionModule(set_0, int_0, str_0, tuple_0, bytes_0, tuple_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:37:25.867408
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing ActionModule() constructor:")
    set_0 = set()
    int_0 = -1438
    str_0 = '%d{k,'
    tuple_0 = (int_0,)
    bytes_0 = b'\xcaH'
    action_module_0 = ActionModule(set_0, int_0, str_0, tuple_0, bytes_0, tuple_0)


# Generated at 2022-06-25 07:37:26.492815
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:37:33.286925
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    int_0 = 0
    str_0 = '%b|#~'
    tuple_0 = (int_0, int_0)
    bytes_0 = b'V\x81'
    action_module_0 = ActionModule(set_0, int_0, str_0, tuple_0, bytes_0, tuple_0)
    var_0 = action_module_0.run(None)
    var_1 = action_module_0.run(None, None)
    assert var_0 == var_1

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 07:37:42.412956
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Test case where 'ansible_version' object is None
    set_0 = set()
    int_0 = -1438
    str_0 = '%d{k,'
    tuple_0 = (int_0,)
    bytes_0 = b'\xcaH'
    action_module_0 = ActionModule(set_0, int_0, str_0, tuple_0, bytes_0, tuple_0)

    # Test case where 'runner' object is None
    set_1 = set()
    int_1 = 22316
    str_1 = '`Q'
    tuple_1 = (int_1,)
    bytes_1 = b'\xeb\x0c'

# Generated at 2022-06-25 07:37:47.091304
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args_0 = {'name': 'uuid', 'uuid': '0xffff', 'register': 'muffin'}
    task_vars_0 = {'mushroom': 'fetch'}
    result_0 = dict()
    result_0['ansible_facts'] = {'muffin': '0xffff'}
    result_0['_ansible_facts_cacheable'] = False
    action_module_0 = ActionModule(args_0, task_vars_0)
    var_0 = action_module_0.run()
    assert var_0 == result_0

    args_1 = {'name': 'name', 'register': 'foo', 'name': 'meow'}
    task_vars_1 = {}
    result_1 = dict()

# Generated at 2022-06-25 07:37:52.339973
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    int_0 = -1438
    str_0 = '%d{k,'
    tuple_0 = (int_0,)
    bytes_0 = b'\xcaH'
    action_module_0 = ActionModule(set_0, int_0, str_0, tuple_0, bytes_0, tuple_0)
    var_0 = action_run()
    assert var_0 == None

# Generated at 2022-06-25 07:39:36.035094
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    int_0 = 1438
    str_0 = '<'
    tuple_0 = (int_0,)
    bytes_0 = b'[\x14\xbb\xf7'
    action_module_0 = ActionModule(set_0, int_0, str_0, tuple_0, bytes_0, tuple_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:39:38.779828
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:39:45.325249
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    int_0 = 579
    str_0 = '_!c/'
    tuple_0 = (str_0,)
    bytes_0 = b'r}>pqn'
    action_module_0 = ActionModule(set_0, int_0, str_0)
    action_module_1 = ActionModule(set_0, int_0, str_0, tuple_0)
    action_module_2 = ActionModule(set_0, int_0, str_0, tuple_0, bytes_0)
    action_module_3 = ActionModule(set_0, int_0, str_0, tuple_0, bytes_0, tuple_0)
    assert type(action_module_0) == ActionModule
    assert type(action_module_1) == ActionModule
   

# Generated at 2022-06-25 07:39:49.325857
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # testing constructor
    set_0 = set()
    int_0 = -1438
    str_0 = '%d{k,'
    tuple_0 = (int_0,)
    bytes_0 = b'\xcaH'
    action_module_0 = ActionModule(set_0, int_0, str_0, tuple_0, bytes_0, tuple_0)



# Generated at 2022-06-25 07:39:55.219869
# Unit test for constructor of class ActionModule
def test_ActionModule():
  set_0 = set()
  int_0 = -1438
  str_0 = '%d{k,'
  tuple_0 = (int_0,)
  bytes_0 = b'\xcaH'
  action_module_0 = ActionModule(set_0, int_0, str_0, tuple_0, bytes_0, tuple_0)
  assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:39:59.435590
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    int_0 = -1438
    str_0 = '%d{k,'
    tuple_0 = (int_0,)
    bytes_0 = b'\xcaH'
    action_module_0 = ActionModule(set_0, int_0, str_0, tuple_0, bytes_0, tuple_0)
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:40:04.935763
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_1 = set()
    int_1 = 0xab

# Generated at 2022-06-25 07:40:11.759074
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'J'
    set_0 = set()
    int_0 = -1562
    str_1 = 'v,'
    tuple_0 = (int_0,)
    bytes_0 = b'\xcdY'
    action_module_0 = ActionModule(set_0, int_0, str_1, tuple_0, bytes_0, tuple_0)
    task_vars_0 = dict()
    var_0 = action_module_0.run(int_0, task_vars_0)

# Generated at 2022-06-25 07:40:16.177003
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    int_0 = -1547
    str_0 = 'm'
    tuple_0 = (int_0,)
    bytes_0 = b'\xce\x96'
    action_module_0 = ActionModule(set_0, int_0, str_0, tuple_0, bytes_0, tuple_0)


# Generated at 2022-06-25 07:40:19.819010
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(0, 0, '', (), b'', ())
    if (action_module._task.action == ''):
        print('Error: expected action to be "set_fact", received "".')
    if (action_module._task.name == ''):
        print('Error: expected name to be "set_fact", received "".')
