

# Generated at 2022-06-25 07:31:16.896394
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert (ActionModule.__module__ == 'ansible.plugins.action')
    assert (ActionModule.__name__ == 'ActionModule')
    assert (ActionModule.TRANSFERS_FILES == False)


# Generated at 2022-06-25 07:31:21.930466
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionmodule_0 = ActionModule()
    print(actionmodule_0)

if __name__ == "__main__":
    test_ActionModule_run()

# Generated at 2022-06-25 07:31:31.884318
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # arguments
    tmp = _tmp()
    task_vars = {}

    # construct object
    obj = ActionModule(tmp, task_vars, 'mock', 'mock')

    # try calling with local params
    _obj_0 = obj.run(tmp=tmp, task_vars=task_vars)

    # try calling with state_commands_only params
    _obj_0 = obj.run(task_vars=task_vars)

    # try calling with name params
    _obj_0 = obj.run(task_vars=task_vars)

## Unit test for method run of class ActionModule
##
#def test_ActionModule_run():
#    # arguments
#    tmp = _tmp()
#    task_vars = {}
#
#    # construct object
#    obj

# Generated at 2022-06-25 07:31:39.569987
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp_0 = None
    task_vars_0 = None
    result_0 = action_module_0.run(tmp_0, task_vars_0)
    print(result_0)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:31:44.653772
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def test_case_0():
        # TODO : implement unit test
        pass

    def test_case_1():
        # TODO : implement unit test
        pass

    def test_case_2():
        # TODO : implement unit test
        pass

# Generated at 2022-06-25 07:31:52.937392
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_0 = ActionModule()
    tmp_0 = None
    task_vars_0 = dict()
    int_0 = module_0.run(tmp_0, task_vars_0)
    str_0 = 'DEFAULT_JINJA2_NATIVE'
    bool_0 = getattr(C, str_0)
    module_0.run(tmp_0, task_vars_0)
    str_1 = 'DEFAULT_JINJA2_NATIVE'
    bool_1 = getattr(C, str_1)
    str_2 = 'DEFAULT_JINJA2_NATIVE'
    bool_2 = getattr(C, str_2)

# Generated at 2022-06-25 07:31:56.263814
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    actionmodule = ActionModule()
    # Execution
    actionmodule.run(None, None)
    # Verification
    assert (actionmodule.TRANSFERS_FILES == False)
# test_ActionModule_run()


# Generated at 2022-06-25 07:31:57.808013
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:32:00.031539
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Class instantiation
    obj = ActionModule("key_value_0")
    obj.run("tmp_0", "task_vars_0")


# Generated at 2022-06-25 07:32:01.195758
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        ActionModule()
    except:
        assert False


# Generated at 2022-06-25 07:32:12.269705
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Setup
    args_0 = {}
    ansible_facts_0 = {}
    tmp_0 = None
    task_vars_0 = {}

    # ActionModule tests
    action_module_0 = ActionModule(tmp_0, task_vars_0)
    result_0 = action_module_0.run(tmp_0, task_vars_0)
    assert result_0 == {}

    # Teardown
    clean_up_0()


# Generated at 2022-06-25 07:32:12.783929
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:32:17.232710
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    tuple_0 = ()
    str_0 = 'normal'
    int_0 = 32
    action_module_0 = ActionModule(str_0, int_0, set_0, int_0, tuple_0)
    str_1 = 'X^T=m+x'

test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 07:32:27.939535
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # variables
    var_0 = 'normal'
    var_1 = False
    var_2 = True
    var_3 = 'normal'
    var_4 = False
    var_5 = 'normal'
    var_6 = True
    var_7 = 'normal'
    var_8 = False
    var_9 = 'normal'
    var_10 = True
    var_11 = 'normal'
    var_12 = False
    var_13 = 'normal'
    var_14 = True
    var_15 = 'normal'
    var_16 = False
    var_17 = 'normal'
    var_18 = True
    var_19 = 'normal'
    # testing
    assert False == False
    assert False != True
    assert True == True
    assert True != False
    assert False == False
   

# Generated at 2022-06-25 07:32:33.916183
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    action_module_0 = ActionModule(tmp, task_vars)
    action_module_1 = action_module_0.run(tmp, task_vars)
    assert action_module_1.__class__.__name__ == 'dict'
    assert action_module_1 == {'ansible_facts': {}, '_ansible_facts_cacheable': None, '_ansible_no_log': False, 'changed': False}


test_case_0()

# Generated at 2022-06-25 07:32:35.766545
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Only set up if first time run
    test_case_0()

# Generated at 2022-06-25 07:32:46.346103
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    exp_0 = "Unable to create any variables with provided arguments"
    str_0 = "'c9o^&xtx|l!wo"
    str_1 = 'normal'
    int_0 = 32
    set_0 = {int_0, str_1, str_1, str_1}
    tuple_0 = ()
    bool_0 = True
    action_module_0 = ActionModule(str_1, int_0, set_0, int_0, tuple_0, bool_0)
    # Ensure that this test fails with the expected exception
    with pytest.raises(AnsibleActionFail, match=r'^%s$' % re.escape(exp_0, re.IGNORECASE)):
        action_module_0.run(str_0)


# Generated at 2022-06-25 07:32:54.846192
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print(">> Being test_ActionModule_run ...")
    str_0 = 'h9{j@4a2'
    str_1 = 'normal'
    int_0 = 32
    set_0 = {str_1, int_0, str_1, str_1}
    tuple_0 = ()
    bool_0 = True
    action_module_0 = ActionModule(str_1, int_0, set_0, int_0, tuple_0, bool_0)
    var_0 = action_module_0.run('tmp', 'task_vars')
    print(">> End of test_ActionModule_run ...")


# Generated at 2022-06-25 07:33:00.785713
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with a scalar value
    set_0 = set()
    str_0 = 'vf8*^me*dic%'
    action_module_0 = ActionModule(str_0, set_0)
    var_0 = action_module_0.run(str_0)
    assert var_0 == 'vf8*^me*dic%'
    assert set_0 == {'vf8*^me*dic%'}

    # Test with a list value
    set_0 = set()
    str_0 = ()
    action_module_0 = ActionModule(str_1, set_0)
    var_0 = action_module_0.run(str_0)
    assert var_0 == ()
    assert set_0 == {()}

    # Test with a dict value
   

# Generated at 2022-06-25 07:33:08.888189
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Test constructor for class ActionModule", end="")
    str_0 = "b2*h9c%^b&54z"
    str_1 = 'normal'
    int_0 = 62
    set_0 = {int_0, str_1, str_1, str_1}
    int_1 = 39
    tuple_0 = ()
    bool_0 = True
    action_module_0 = ActionModule(str_1, int_0, set_0, int_0, tuple_0, bool_0)
    print("Done.")


# Generated at 2022-06-25 07:33:25.569082
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = ')'
    str_1 = 'v&iz,a$0ljg'
    int_0 = 37
    set_0 = {int_0, str_1, str_1, str_1}
    tuple_0 = ()
    bool_0 = True
    action_module_0 = ActionModule(str_1, int_0, set_0, int_0, tuple_0, bool_0)
    tmp = None
    task_vars = None
    var_0 = action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 07:33:36.187860
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_2 = 'ansible_facts'
    str_0 = 'action'
    str_3 = 'ansible_facts'
    bool_0 = False
    str_2 = 'module_name'
    int_0 = 32
    set_0 = set()
    int_1 = 32
    dict_0 = dict()
    dict_0['task'] = dict()
    dict_0['task']['args'] = dict()
    dict_0['_ansible_version'] = '2.2.0.0'
    dict_0['_ansible_no_log'] = False
    dict_0['task_vars'] = dict()
    dict_0['play_context'] = dict()
    dict_0['play_context']['password'] = 'password'

# Generated at 2022-06-25 07:33:44.168982
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:33:50.891474
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "&h*#_e+z%!no"
    str_1 = 'normal'
    int_0 = 32
    set_0 = {int_0, str_1, str_1, str_1}
    tuple_0 = ()
    bool_0 = True
    action_module_0 = ActionModule(str_1, int_0, set_0, int_0, tuple_0, bool_0)
    var_0 = action_run(str_0)


# Generated at 2022-06-25 07:33:57.930884
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Pass
    str_0 = "'c9o^&xtx|l!wo"
    str_1 = 'normal'
    int_0 = 32
    set_0 = {str_1, str_1, str_1}
    tuple_0 = ()
    bool_0 = True
    action_module_0 = ActionModule(str_1, int_0, set_0, int_0, tuple_0, bool_0)
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    


# Generated at 2022-06-25 07:34:04.317275
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "'c9o^&xtx|l!wo"
    str_1 = 'normal'
    int_0 = 32
    set_0 = {int_0, str_1, str_1, str_1}
    tuple_0 = ()
    bool_0 = True
    action_module_0 = ActionModule(str_1, int_0, set_0, int_0, tuple_0, bool_0)
    var_0 = action_module_0.run(str_0)
    print(var_0)

# Generated at 2022-06-25 07:34:10.968627
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "'c9o^&xtx|l!wo"
    str_1 = 'normal'
    int_0 = 32
    set_0 = {int_0, str_1, str_1, str_1}
    tuple_0 = ()
    bool_0 = True
    action_module_0 = ActionModule(str_1, int_0, set_0, int_0, tuple_0, bool_0)
    var_0 = action_module_0.run()
    print(var_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:34:15.718819
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "j.k9-zqufp^,kg"
    str_1 = '_ansible_facts_cacheable'
    int_0 = 52
    set_0 = {str_1, str_0, str_0}
    int_1 = 83
    tuple_0 = (str_1, int_0, set_0)
    bool_0 = False
    action_module_0 = ActionModule(str_1, int_0, set_0, int_0, tuple_0, bool_0)

test_case_0()

# Generated at 2022-06-25 07:34:20.222864
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "'c9o^&xtx|l!wo"
    str_1 = 'normal'
    int_0 = 32
    set_0 = {int_0, str_1, str_1, str_1}
    tuple_0 = ()
    bool_0 = True

    # Constructor test
    action_module_0 = ActionModule(str_1, int_0, set_0, int_0, tuple_0, bool_0)

# Generated at 2022-06-25 07:34:20.700529
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-25 07:34:47.641054
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Start to test ActionModule...')
    str_0 = "'c9o^&xtx|l!wo"
    str_1 = 'normal'
    int_0 = 32
    set_0 = {int_0, str_1, str_1, str_1}
    tuple_0 = ()
    bool_0 = True
    action_module_0 = ActionModule(str_1, int_0, set_0, int_0, tuple_0, bool_0)
    
    if action_module_0._task != str_1:
        raise ValueError('task incorrect')
    if action_module_0._connection != int_0:
        raise ValueError('connection incorrect')
    if action_module_0._play_context != set_0:
        raise ValueError('play_context incorrect')

# Generated at 2022-06-25 07:34:53.900077
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'dduk-bz'
    str_1 = 'normal'
    int_0 = 35
    set_0 = {str_1, int_0, int_0, int_0, int_0}
    int_1 = 2
    tuple_0 = (str_0, int_0)
    bool_0 = False
    action_module_0 = ActionModule(str_1, int_0, set_0, int_1, tuple_0, bool_0)
    dict_0 = dict()

# Generated at 2022-06-25 07:35:01.050189
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_2 = "'c9o^&xtx|l!wo"
    str_3 = 'normal'
    int_1 = 32
    set_1 = {int_1, str_3, str_3, str_3}
    tuple_1 = ()
    bool_1 = True
    action_module_1 = ActionModule(str_3, int_1, set_1, int_1, tuple_1, bool_1)
    str_4 = 'normal'
    list_0 = [action_module_1]
    str_5 = 'normal'
    set_2 = {str_4, str_5, action_module_1}
    str_6 = 'normal'
    int_2 = 77
    float_0 = 2.7
    int_3 = 15

# Generated at 2022-06-25 07:35:08.715230
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "'c9o^&xtx|l!wo"
    str_1 = 'normal'
    int_0 = 32
    set_0 = {int_0, str_1, str_1, str_1}
    tuple_0 = ()
    bool_0 = True
    action_module_0 = ActionModule(str_1, int_0, set_0, int_0, tuple_0, bool_0)

# Generated at 2022-06-25 07:35:20.361969
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'UoD6U@<R~p'
    set_0 = set()
    tuple_0 = ()
    bool_0 = False
    action_module_0 = ActionModule(str_0, set_0, tuple_0, bool_0, bool_0, bool_0)
    str_1 = '4xnE|HW8nA{'
    str_2 = 'lQmU6DvU6m'
    str_3 = '5q5q5q5q5q'
    str_4 = '<!:c|!Y7'
    str_5 = 'O*^&M}y7#'
    tuple_1 = (str_2, str_3, str_4, str_5)
    str_6 = ';'

# Generated at 2022-06-25 07:35:22.959616
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    action_module_0 = ActionModule(str, int, set, int, tuple, bool)
    var_0 = action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 07:35:32.355301
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "'c9o^&xtx|l!wo"
    str_1 = 'normal'
    int_0 = 32
    set_0 = {int_0, str_1, str_1, str_1}
    tuple_0 = ()
    bool_0 = True
    action_module_0 = ActionModule(str_1, int_0, set_0, int_0, tuple_0, bool_0)
    var_0 = action_module_0.run(str_1)
    if var_0 is None:
        print('test_ActionModule_run returned None')
    else:
        print('test_ActionModule_run returned ', var_0)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:35:40.686612
# Unit test for constructor of class ActionModule
def test_ActionModule():
  ctor_args_0 = "str_0"
  ctor_args_1 = "str_1"
  ctor_args_2 = "str_2"
  ctor_args_3 = "str_3"
  ctor_args_4 = "str_4"
  action_module_0 = ActionModule(ctor_args_0, ctor_args_1, ctor_args_2, ctor_args_3, ctor_args_4)

  assert action_module_0 is not None
  assert action_module_0.VALID_ARGS == "test"
  assert action_module_0.BYPASS_HOST_LOOP != "str_0"
  assert action_module_0.BYPASS_HOST_LOOP != "str_1"
  assert action_module_0.BY

# Generated at 2022-06-25 07:35:41.270249
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:35:46.503968
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_1 = "'c9o^&xtx|l!wo"
    str_2 = 'normal'
    int_1 = 32
    set_1 = {str_1, str_2, str_2, str_2}
    tuple_1 = ()
    bool_1 = True
    action_module_1 = ActionModule(str_2, int_1, set_1, int_1, tuple_1, bool_1)
    var_1 = action_run(str_1)


# Generated at 2022-06-25 07:36:23.404824
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'n>|lxm+j`'
    str_1 = 'normal'
    int_0 = 24
    set_0 = {int_0, str_1, str_1, int_0}
    int_1 = 24
    tuple_0 = ()
    bool_0 = True
    action_module_0 = ActionModule(str_1, int_0, set_0, int_0, tuple_0, bool_0)


# Generated at 2022-06-25 07:36:29.176927
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'i'
    str_1 = 'wz&'
    int_0 = 32
    set_0 = {int_0, str_1, str_1, str_1}
    tuple_0 = ()
    bool_0 = False
    action_module_0 = ActionModule(str_1, int_0, set_0, int_0, tuple_0, bool_0)
    var_0 = action_module_0.run(str_0)

# Generated at 2022-06-25 07:36:38.186744
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "B^p?~<S,`_$=OF"
    str_1 = 'normal'
    int_0 = 32
    set_0 = {int_0, str_1, str_1, str_1, str_0}
    int_1 = 10
    tuple_0 = ()
    bool_0 = True
    action_module_0 = ActionModule(str_0, int_0, set_0, int_1, tuple_0, bool_0)
    assert(action_module_0.action_name == "normal")
    assert(action_module_0.included_filters == {'template', 'json', 'to_yaml'})
    assert(action_module_0.transfer_files == False)


# Generated at 2022-06-25 07:36:42.206443
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:36:48.794383
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "'c9o^&xtx|l!wo"
    str_1 = 'normal'
    str_2 = 'normal'
    int_0 = 32
    set_0 = {int_0, str_1, str_1, str_1}
    tuple_0 = ()
    bool_0 = True
    action_module_0 = ActionModule(str_1, int_0, set_0, int_0, tuple_0, bool_0)
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:36:57.960778
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    _arg_0 = "ll>o0(*ah<f1^8m" # expected type: str
    _arg_1 = "8!@2%rm-sz)v2$0t" # expected type: str
    _arg_2 = 40 # expected type: int
    _arg_3 = {'true', 'true', 'nan', 'nan', 'nan', '', '', '', } # expected type: set
    _arg_4 = 46 # expected type: int
    _arg_5 = () # expected type: tuple
    _arg_6 = True # expected type: bool
    _args = (_arg_0, _arg_1, _arg_2, _arg_3, _arg_4, _arg_5, _arg_6)
    _retval = ""
    _func = ActionModule
    _args

# Generated at 2022-06-25 07:37:01.888753
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "'c9o^&xtx|l!wo"
    str_1 = 'normal'
    int_0 = 32
    set_0 = {int_0, str_1, str_1, str_1}
    tuple_0 = ()
    bool_0 = True
    action_module_0 = ActionModule(str_1, int_0, set_0, int_0, tuple_0, bool_0)
    str_2 = "normal"
    str_3 = "normal"
    bool_1 = True
    dict_0 = {str_2: bool_1, str_3: bool_1}
    dict_1 = action_module_0.run(dict_0)

# Generated at 2022-06-25 07:37:03.028255
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert run() == None, 'ERR: returns unexpected value'

# Generated at 2022-06-25 07:37:04.071629
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:37:10.236492
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '6$DSo^H=@'
    str_1 = 'normal'
    int_0 = 37
    set_0 = {str_0, str_1, str_0, str_1}
    str_2 = 'normal'
    int_1 = 39
    set_1 = {str_1, int_1, str_0, str_0}
    tuple_0 = (str_2,)
    bool_0 = False
    test_case_0(str_2, str_1, int_0, set_0, int_1, tuple_0, bool_0)

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:38:21.454965
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:38:30.267578
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '3g+1'
    int_0 = 20
    tuple_0 = (str_0, str_0, str_0)
    list_0 = ['S!m@']
    str_1 = 'normal'
    set_0 = {str_0, int_0, int_0, list_0}
    int_1 = 12
    bool_0 = True
    action_module_0 = ActionModule(str_1, int_1, set_0, int_1, tuple_0, bool_0)
    action_module_0.run()

# Generated at 2022-06-25 07:38:30.949291
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print(ActionModule.run)


# Generated at 2022-06-25 07:38:35.143857
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'normal'
    int_0 = 7
    set_0 = {str_0, str_0}
    int_1 = 11
    tuple_0 = ()
    bool_0 = True
    action_module_0 = ActionModule(str_0, int_0, set_0, int_1, tuple_0, bool_0)
    action_module_0.run()

# Generated at 2022-06-25 07:38:41.270106
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "'c9o^&xtx|l!wo"
    str_1 = 'normal'
    int_0 = 32
    set_0 = {int_0, str_1, str_1, str_1}
    tuple_0 = ()
    bool_0 = True

    # Test with valid arguments
    action_module_0 = ActionModule(str_1, int_0, set_0, int_0, tuple_0, bool_0)

    # Test with invalid arguments
    # arguments = [str_1, int_0, set_0, int_0, tuple_0, bool_0]
    # arguments_invalid_0 = {"abc", -1}
    # action_module_1 = ActionModule(str_1, *arguments_invalid_0)


# Generated at 2022-06-25 07:38:42.189626
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert action_module_0.__class__ is ActionModule

# Generated at 2022-06-25 07:38:49.394938
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Declarations
    str_0 = 'f#_8|0+jz'
    str_1 = 'test'
    int_0 = -37
    set_0 = {int_0, str_1, str_1}
    tuple_0 = (str_0, str_0, str_1)
    bool_0 = False
    action_module_0 = ActionModule(str_1, int_0, set_0, int_0, tuple_0, bool_0)
    # Setup
    # Teardown
    # Assertions
    assert tmp == 'tmp'
    assert task_vars == 'task_vars'

# Generated at 2022-06-25 07:38:54.781838
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "w2kyg03#0"
    str_1 = 'false'
    set_0 = {}
    int_0 = 82
    bool_0 = False
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, int_0, set_0, int_0, tuple_0, bool_0)
    var_0 = action_module_0.run()
    str_2 = "j8(h]2c%0"
    str_3 = 'true'
    set_1 = {str_3}
    int_1 = 92
    bool_1 = False
    tuple_1 = ()
    action_module_1 = ActionModule(str_2, int_1, set_1, int_0, tuple_1, bool_1)

# Generated at 2022-06-25 07:39:00.840838
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 0
    str_0 = 'xyz'
    str_1 = 'normal'
    int_1 = 32
    set_0 = {int_1, str_1, str_1, str_1}
    tuple_0 = ()
    bool_0 = True
    action_module_0 = ActionModule(str_1, int_0, set_0, int_0, tuple_0, bool_0)

    assert action_module_0.run().get('ansible_facts').get('foo') == 'bar'

# Generated at 2022-06-25 07:39:07.718718
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "t*#-s^g=9n"
    str_1 = 'module_name'
    int_0 = 24
    set_0 = {int_0, str_1, str_1, str_1}
    int_1 = 40
    tuple_0 = ()
    bool_0 = True
    action_module_0 = ActionModule(str_1, int_0, set_0, int_1, tuple_0, bool_0)
    action_module_0.action_run(str_0)