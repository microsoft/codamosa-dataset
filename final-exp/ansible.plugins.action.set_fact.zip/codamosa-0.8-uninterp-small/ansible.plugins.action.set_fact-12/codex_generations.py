

# Generated at 2022-06-25 07:31:27.521148
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 296
    dict_0 = {
        'overflow': 'b\'D,\\xa2>O',
        'deferred': 'Eu<H3=V7',
        'client': '-\\xc9>',
        'alert': '1e\\x1f\\x98\\x96\\x85',
    }
    list_0 = ['A', None, '', False, '1', '$', 'Z', 242, '']
    str_0 = 'hA,\\xf7{/'
    action_module_0 = ActionModule(list_0, int_0, dict_0, True, list_0, str_0)
    str_1 = 'f_\\x1a\\xf5\\xcc'

# Generated at 2022-06-25 07:31:31.538069
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 242
    list_0 = [int_0]
    dict_0 = {}
    bool_0 = False
    str_0 = 'w^pyU)/g\r'
    action_module_0 = ActionModule(list_0, int_0, dict_0, bool_0, list_0, str_0)
    assert action_module_0.TRANSFERS_FILES == False



# Generated at 2022-06-25 07:31:37.821417
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 241
    list_0 = [int_0]
    dict_0 = {}
    bool_0 = False
    str_0 = '7p)_$&u'
    action_module_0 = ActionModule(list_0, int_0, dict_0, bool_0, list_0, str_0)

    try:
        result_0 = action_module_0.run(None, dict_0)
    except AnsibleActionFail as e:
        assert type(e) == AnsibleActionFail
    else:
        raise Exception('Expected AnsibleActionFail exception from ActionModule.run()')


# Generated at 2022-06-25 07:31:46.012294
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = []
    int_0 = 0
    dict_0 = {}
    bool_0 = True
    str_0 = str()
    # creation
    action_module_0 = ActionModule(list_0, int_0, dict_0, bool_0, list_0, str_0)
    # attributes verification


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:31:50.691196
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -104
    dict_0 = {}
    list_0 = [int_0]
    bool_0 = False
    int_1 = -98
    str_0 = 'W8b]`j\x0c'
    action_module_0 = ActionModule(list_0, int_1, dict_0, bool_0, list_0, str_0)
    # TODO: Replace these with proper unit tests
    action_module_0.run()
    action_module_0.run()
    action_module_0.run()

# Generated at 2022-06-25 07:31:54.713883
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 88
    dict_0 = {}
    bool_0 = True
    bool_1 = True
    str_0 = 'z'
    test_case_0(int_0, dict_0, bool_0, bool_1, str_0)


# Generated at 2022-06-25 07:31:55.589093
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Do constructor test
    test_case_0()

# Generated at 2022-06-25 07:31:58.535051
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    bool_0 = False
    list_0 = []
    action_module_0 = ActionModule(dict_0, bool_0, dict_0, list_0, dict_0)


# Generated at 2022-06-25 07:32:05.347156
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 242
    list_0 = [int_0]
    dict_0 = {}
    bool_0 = False
    str_0 = 'w^pyU)/g\r'
    action_module_0 = ActionModule(list_0, int_0, dict_0, bool_0, list_0, str_0)
    var___class__ = action_module_0.__class__
    spec_0 = inspect.getargspec(var___class__.run)
    int_1 = len(spec_0.args) - len(spec_0.defaults)
    assert int_1 == 2, 'Wrong number of args, expected 2, got %d' % int_1

# Generated at 2022-06-25 07:32:12.577689
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -1447054383
    str_0 = '<_ZB`}#'
    dict_0 = {str_0: int_0}
    list_0 = [str_0, str_0, str_0]
    bool_0 = True
    action_module_0 = ActionModule(list_0, int_0, dict_0, bool_0, list_0, str_0)

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:32:20.472085
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_2 = {}
    bool_2 = True
    reference_0 = {}
    reference_1 = {}
    copy_reference_0 = {}
    copy_reference_1 = {}
    bool_0 = True
    action_module_0 = ActionModule(var_2, bool_2, reference_0, bool_0, reference_1)
    assert action_module_0.run(copy_reference_0, copy_reference_1) is None


# Generated at 2022-06-25 07:32:22.959793
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

if __name__ == '__main__':
    # Unit test for method run of class ActionModule
    test_ActionModule_run()

# Generated at 2022-06-25 07:32:25.454362
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp_0 = None
    task_vars_0 = None
    action_module_0 = ActionModule(tmp_0, task_vars_0)
    assert action_module_0.ACTION_WARNINGS == 'always'

test_case_0()
test_ActionModule()

# Generated at 2022-06-25 07:32:29.034159
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = {}
    bool_1 = True
    action_module_1 = ActionModule(var_1, bool_1, var_1, bool_1, var_1)
    assert action_module_1.TRANSFERS_FILES == False

# Generated at 2022-06-25 07:32:30.944922
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp_0 = None
    task_vars_0 = None
    obj_0 = ActionModule(tmp_0, task_vars_0)

# Generated at 2022-06-25 07:32:35.561916
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    action_module_0 = ActionModule(tmp, task_vars)
    tmp = None
    task_vars = None
    # Testing if the exception was raised
    with pytest.raises(AnsibleActionFail) as excinfo:
        action_module_0.run(tmp, task_vars)
    assert 'No key/value pairs provided, at least one is required for this action to succeed' in str(excinfo.value)

# Generated at 2022-06-25 07:32:38.623832
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:32:39.529952
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:32:40.550924
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 07:32:45.219417
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = {}
    bool_0 = True
    action_module_0 = ActionModule(var_0, bool_0, var_0, bool_0, var_0)
    tmp_0 = None
    task_vars_0 = {}

    # Call method run with arguments tmp_0, task_vars_0
    assert action_module_0.run(task_vars_0) == dict()

# Generated at 2022-06-25 07:32:57.249571
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(True, 'task_vars', None)
    bool_0 = True
    bool_1 = False
    str_0 = 'dict'
    str_1 = 'action_plugin'
    str_2 = 'M'
    str_3 = 'ansible_facts'
    str_4 = 'x'
    str_5 = 'cacheable'
    str_6 = 'changed'
    str_7 = 'The variable name \'%s\' is not valid. Variables must start with a letter or underscore character, and contain only letters, numbers and underscores.'
    str_8 = 'cacheable'
    str_9 = 'Unable to create any variables with provided arguments'
    str_10 = 'x'

# Generated at 2022-06-25 07:33:05.237743
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_2 = True
    bool_3 = True
    ansible_facts_1 = dict()
    tmp_1 = None
    task_vars_1 = dict()
    bool_4 = False
    action_module_1 = ActionModule(bool_2, bool_2, bool_2, bool_2, bool_2)
    result = action_module_1._execute_module(tmp_1, task_vars_1, bool_3, bool_4)
    result['ansible_facts']
    result['_ansible_facts_cacheable']
    result['ansible_facts'] = ansible_facts_1

# Generated at 2022-06-25 07:33:14.824470
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    str_0 = '1'
    dict_0 = dict()
    dict_1 = dict()
    dict_1['ansible_facts'] = dict_0
    dict_0['ANSIBLE_JINJA2_NATIVE'] = bool_0
    dict_0['ANSIBLE_FACTS_CACHEABLE'] = bool_0
    dict_1['_ansible_facts_cacheable'] = bool_0
    dict_2 = dict()
    dict_2['_ansible_no_log'] = False
    dict_1['_ansible_verbose_always'] = False
    dict_1['_ansible_verbosity'] = 0
    dict_1['ansible_loop_var'] = 'item'
    dict_1['_ansible_item_result'] = True
   

# Generated at 2022-06-25 07:33:20.663251
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test 1
    actionModule = ActionModule(false, false, false, false, false)
    assert actionModule.TRANSFERS_FILES == false
    assert actionModule.SUPPORTED_FILTERS == ['bool']

    # test 2
    actionModule = ActionModule(true, true, true, true, true)
    assert actionModule.TRANSFERS_FILES == true
    assert actionModule.SUPPORTED_FILTERS == ['bool']


# Generated at 2022-06-25 07:33:26.460436
# Unit test for constructor of class ActionModule
def test_ActionModule():

  # Create a new instance of ActionModule
  action_module_0 = ActionModule()

  # Test function run()
  action_module_0.run()

  # Test function run()
  action_module_0.run(tmp = None, task_vars = None)

# Generated at 2022-06-25 07:33:30.692302
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    action_module_0 = ActionModule(bool_0, bool_0, bool_0, bool_0, bool_0)

test_case_0()
test_ActionModule()

# Generated at 2022-06-25 07:33:42.642223
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    action_module_0 = ActionModule(bool_0, bool_0, bool_0, bool_0, bool_0)

    # Test #0: Expected exception
    str_0 = ''
    try:
        action_module_0.run(str_0)
    except AnsibleActionFail as e:
        assert(True)
    except Exception as e:
        assert(False)

    # Test #1: Expected exception
    try:
        action_module_0.run()
    except AnsibleActionFail as e:
        assert(True)
    except Exception as e:
        assert(False)

    # Test #2: Expected exception
    dict_0 = {}

# Generated at 2022-06-25 07:33:46.575161
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Tests for the static method to_unsafe_native

# Generated at 2022-06-25 07:33:47.374821
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
    print("All tests passed")

# Generated at 2022-06-25 07:33:51.487870
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(None, None)
    tmp_0 = None
    task_vars_0 = None
    try:
        action_module_0.run(tmp_0, task_vars_0)
    except Exception as inst:
        if isinstance(inst, AnsibleActionFail):
            assert False
        else:
            assert True



# Generated at 2022-06-25 07:34:02.560628
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    action_module_0 = ActionModule(bool_0, bool_0, bool_0, bool_0, bool_0)
    action_module_0.setup = True
    action_module_0._task = {}
    action_module_0._task.args = {}
    action_module_0._task.args['cacheable'] = False
    action_module_0._task.args['k'] = 'v'
    action_module_0._task.args['k2'] = 'a'
    action_module_0._task.args['k3'] = 'a'
    action_module_0._task.args['k4'] = 'a'
    action_module_0._task.args['k5'] = 'a'

# Generated at 2022-06-25 07:34:12.020773
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    dict_0 = {}
    str_0 = ActionBase.RUN_DATA_PRE_RESPONSE
    str_1 = "S1aXMf1O2"
    str_2 = "placeholder"
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    str_3 = "action_module"
    task_vars_0 = {str_0: dict_0, str_1: dict_1, str_2: dict_2, str_3: dict_3}
    action_module_0 = ActionModule(bool_0, bool_0, bool_0, bool_0, bool_0)
    action_module_0.run(task_vars=task_vars_0)

# Generated at 2022-06-25 07:34:17.015071
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    action_module_0 = ActionModule(bool_0, bool_0, bool_0, bool_0, bool_0)
    result = action_module_0.run(None, None)
    assert result == None

if __name__ == "__main__":
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:34:20.914321
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("test_ActionModule_run")
    bool_0 = True
    action_module_0 = ActionModule(bool_0, bool_0, bool_0, bool_0, bool_0)
    tmp_0 = None
    task_vars_0 = dict()
    action_module_0.run(tmp_0, task_vars_0)


# Generated at 2022-06-25 07:34:24.656449
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args_0 = {}
    args_0['foo'] = 'bar'
    args_0['spam'] = 'eggs'
    bool_0 = True
    action_module_0 = ActionModule(bool_0, bool_0, bool_0, bool_0, bool_0)
    task_vars_0 = {}
    action_module_0.run(args_0, task_vars_0)
    action_module_0.run(args_0)
    args_0['cacheable'] = False
    action_module_0.run(args_0)

# Generated at 2022-06-25 07:34:30.866691
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    action_module_0 = ActionModule(bool_0, bool_0, bool_0, bool_0, bool_0)
    bool_1 = action_module_0._shared_loader_obj().module_loader.module_exists('collection')
    assert bool_1 == False
    assert issubclass(ActionModule, object) == True
    assert issubclass(ActionModule, ActionBase) == True


# Generated at 2022-06-25 07:34:36.542214
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    tmp = None
    bool_0 = True
    action_module_0 = ActionModule(bool_0, bool_0, bool_0, bool_0, bool_0)
    result = action_module_0.run(tmp, task_vars)
    assert type(result) == dict
    assert 'ansible_facts' in result
    assert '_ansible_facts_cacheable' in result

# Generated at 2022-06-25 07:34:39.894819
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create test fixture
    a_dict = {"hello" : "world"}
    task = {"name" : "test", "args" : a_dict}
    # Unit test
    obj = ActionModule(task, "/tmp", "/tmp", "/tmp", False)
    # Verification
    assert obj is not None
    assert isinstance(obj, ActionModule)


# Generated at 2022-06-25 07:34:50.973795
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_1 = True
    action_module_1 = ActionModule(bool_1, bool_1, bool_1, bool_1, bool_1)

    # set up object attributes
    action_module_1.basepath = None
    action_module_1.async_val = 0
    action_module_1.task_vars = {}
    action_module_1.create_task_vars = {}
    action_module_1.play_context = {}
    action_module_1.connection = {}

    # testing against an action that is known to return False
    string_0 = '1'
    string_1 = '0'
    string_2 = 'file'
    string_3 = 'test'
    string_4 = '1'
    string_5 = '0'

# Generated at 2022-06-25 07:34:57.120334
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    "test_ActionModule_run"
    bool_0 = True
    action_module_0 = ActionModule(bool_0, bool_0, bool_0, bool_0, bool_0)
    tmp_0 = None
    task_vars_0 = {}
    result = action_module_0.run(tmp_0, task_vars_0)

    assert type(result) == dict
    assert 'ansible_facts' in result
    assert '_ansible_facts_cacheable' in result



# Generated at 2022-06-25 07:35:12.202475
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import tempfile
    import shutil

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmp_file = tempfile.mkstemp()

    # Write data to the temporary file
    try:
        os.write(fd, "foobar")
    finally:
        os.close(fd)

    # This set of args will make the module fail
    args_0 = {
        'var2': 'bar',
        'var1': 'foo',
    }

# Generated at 2022-06-25 07:35:23.233023
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True

    def test_var_args_0(self):
        bool_0 = True
        bool_1 = True
        str_0 = ":http"
        bool_2 = True
        bool_3 = False
        str_1 = "."

        action_module_0 = ActionModule(bool_0, bool_1, bool_2, bool_3, bool_0)
        action_module_0.test_var_args_0()
        assert_equal(action_module_0._supports_async, str_0, "action_module_0._supports_async")
        assert_true(action_module_0._supports_check_mode, "action_module_0._supports_check_mode")

# Generated at 2022-06-25 07:35:32.481808
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    bool_0 = True
    bool_1 = False
    dict_0 = dict()
    dict_1 = dict()
    dict_1['ansible_facts'] = dict_0
    dict_1['_ansible_facts_cacheable'] = bool_0
    dict_2 = dict()
    dict_2['cacheable'] = bool_0
    dict_3 = dict()
    str_0 = 'ansible_facts'
    list_0 = list()
    action_module_0 = ActionModule(bool_0, bool_0, bool_0, bool_0, bool_0)
    # Use python api to test the method run of class ActionModule
    result = action_module_0.run(None, dict_2)
    dict_3[str_0] = list_0

# Generated at 2022-06-25 07:35:34.131419
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement this method
    raise NotImplementedError()

# Generated at 2022-06-25 07:35:37.160306
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = test_case_0()
    print(result)

test_ActionModule()

# Generated at 2022-06-25 07:35:38.366169
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    action_module_0 = ActionModule(bool_0, bool_0, bool_0, bool_0, bool_0)


# Generated at 2022-06-25 07:35:43.658704
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # First test case
    test_case_0()

if __name__ == '__main__':
    import sys
    print(test_ActionModule_run())
    #sys.exit(test_ActionModule_run())

# Generated at 2022-06-25 07:35:46.320574
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    bool_1 = False
    action_module_0 = ActionModule(bool_0, bool_0, bool_0, bool_0, bool_0)
    assert action_module_0.TRANSFERS_FILES == bool_1


# Generated at 2022-06-25 07:35:50.618919
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    action_module_1 = ActionModule(bool_0, bool_0, bool_0, bool_0, bool_0)

# This is needed to declare 'action_module_1' as a global variable for the test function 'test_case_0'.
action_module_1 = ActionModule()

if __name__ == '__main__':
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 07:35:52.744610
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(bool, bool, bool, bool, bool)
    assert action_module_0.TRANSFERS_FILES == False


# Generated at 2022-06-25 07:36:05.625592
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        # Create an instance of class ActionModule
        test_case_0()
        test_ActionModule()
    except Exception as e:
        Traceback.print_exc()
        if isinstance(e, SystemExit):
            sys.exit(0)
        else:
            raise e

if __name__ == __main__:
    test_ActionModule()

# Generated at 2022-06-25 07:36:07.751827
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None


# Generated at 2022-06-25 07:36:09.859157
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = ActionModule()
    var_2 = ActionModule()
    try:
        assert var_1 == var_2
    except AssertionError as ae:
        raise AssertionError(ae)


# Generated at 2022-06-25 07:36:12.359732
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_0 = ActionModule()
    assert module_0.run(tmp=None, task_vars=None) == {'ansible_facts': {}, '_ansible_facts_cacheable': False, 'changed': False}

# Generated at 2022-06-25 07:36:15.393516
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible import errors
    with pytest.raises(errors.AnsibleActionFail):
        test_case_0()

# Generated at 2022-06-25 07:36:19.194586
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionModule()



# Generated at 2022-06-25 07:36:20.667857
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert bool(test_case_0).__err__ == None


# Generated at 2022-06-25 07:36:24.073509
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:36:25.719056
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule(task={"action": {"__ansible_module__": "set_fact"}, "args": {}})


# Generated at 2022-06-25 07:36:31.173132
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # setup
    action_module = ActionModule(name=None, play=None, task=None, iterable=None, iterator=None, private_action=None, loader=None, templar=None, shared_loader_obj=None)

    global tmp
    tmp = NotImplementedError()

    global task_vars
    task_vars = NotImplementedError()

    # execute the method we are testing
    result = action_module.run(tmp, task_vars)

    # verify that method returned expected result
    assert result == {"ansible_facts": {"k": "v"}, "_ansible_facts_cacheable": False}

test_cases = [
    test_case_0, #Unit test for method run of class ActionModule
]

# import os
# import sys
# import unittest
# import

# Generated at 2022-06-25 07:36:47.361060
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = NotImplementedError()


# Generated at 2022-06-25 07:36:50.298446
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = NotImplementedError()

    # test case
    vars_2 = None

    # test case
    vars_3 = None

    # test case
    vars_4 = None

# Generated at 2022-06-25 07:36:51.126347
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()


# Generated at 2022-06-25 07:37:00.156711
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Initialization of class instance
    test_class = ActionModule()

    # Test for instance attributes
    # Check for instance attribute TRANSFERS_FILES
    assert hasattr(test_class, 'TRANSFERS_FILES')

    # Test for private attributes
    # Check for instance attribute _ActionBase__lineage
    assert hasattr(test_class, '_ActionBase__lineage')

    # Check for instance attribute _ActionBase__task
    assert hasattr(test_class, '_ActionBase__task')

    # Check for instance attribute _ActionBase__templar
    assert hasattr(test_class, '_ActionBase__templar')

    # Check for instance attribute _ActionBase__loader
    assert hasattr(test_class, '_ActionBase__loader')

    # Check for instance attribute _ActionBase__shared_loader_

# Generated at 2022-06-25 07:37:04.167317
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test_case_0
    try:
        var_0 = ActionModule()
    except NameError:
        raise AssertionError('test_case_0 error')



# Generated at 2022-06-25 07:37:07.161052
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        var_0 = ActionModule()
    except:
        var_0 = NotImplementedError()


# Generated at 2022-06-25 07:37:12.727735
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = {}
    var_1 = {}
    obj = ActionModule(var_0, var_1)
    var_2 = {}
    var_3 = {}
    var_4 = {'cacheable': False}
    result = obj.run(var_2, var_3, var_4)
    print(result)
    if not isinstance(result, dict):
        raise AssertionError('Expected None, got %s' % (type(result)))


# Generated at 2022-06-25 07:37:18.623078
# Unit test for constructor of class ActionModule
def test_ActionModule():
    runner, host, all_vars = setup('setup')
    module = ActionModule(runner=runner, host=host, task=all_vars['tasks'][0], connection=runner.connection, play_context=runner.play_context, loader=runner._loader, templar=runner._templar, shared_loader_obj=runner._shared_loader_obj)
    var_name = 'ansible_facts'
    del all_vars['tasks'][0]
    all_vars['tasks'][0]['action']['__ansible_arguments__'] = u'msg=debug'
    all_vars['tasks'][0]['action']['__ansible_arguments__'] = u'cacheable=yes'
    print(dir(module))

# Generated at 2022-06-25 07:37:23.387162
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_options = {
        'ansible_facts': {},
        '_ansible_facts_cacheable': None,
    }
    var_0 = ActionModule()
    var_1 = var_0.run(tmp=None, task_vars=None)
    assert var_1 == set_options

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()
    print('All tests completed')

# Generated at 2022-06-25 07:37:26.598219
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Constructor Test for ActionModule')
    test_case_0()


# Unit tests for methods of class ActionModule

# Generated at 2022-06-25 07:37:48.116599
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # For no argument action
    try:
        test_case_0()
    except NotImplementedError as e:
        assert str(e) == "No value for required argument: 'action'"



# Generated at 2022-06-25 07:37:49.047980
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Unit test me
    pass

# Generated at 2022-06-25 07:37:50.391690
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = NotImplementedError()


# Generated at 2022-06-25 07:37:52.770572
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = NotImplementedError()
    tmp = NotImplementedError()
    ActionModule.run(tmp,task_vars)


# Generated at 2022-06-25 07:37:53.691449
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var = NotImplementedError()


# Generated at 2022-06-25 07:37:55.729579
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    if not hasattr(__loader__, '_test_module'):
        assert ActionModule.run() == NotImplementedError()


# Generated at 2022-06-25 07:37:56.297204
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:37:58.901479
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:38:00.430352
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = NotImplementedError()


# Generated at 2022-06-25 07:38:01.098499
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = ActionModule()


# Generated at 2022-06-25 07:38:27.367796
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    str_0 = 'dP}eA^'
    list_0 = [str_0, str_0, str_0]
    tuple_0 = (str_0,)
    set_0 = {tuple_0, str_0}
    dict_0 = {tuple_0: str_0, str_0: str_0}
    str_1 = '7DZ6J'
    str_2 = 'qmVx+Ur'
    action_module_0 = ActionModule(set_0, dict_0, str_1, str_2, dict_0, list_0)
    assert action_module_0.DSM_0 == set_0, 'Field should be set to value given in constructor argument.'


# Generated at 2022-06-25 07:38:30.101544
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # stub(ActionModule.__init__, return_value=bool_0)
    try:
        test_case_0()
    finally:
        # unstub()
        pass


# Generated at 2022-06-25 07:38:33.924311
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {'&W': 'TCO'}
    str_0 = '=5$"h1K'
    str_1 = 'EKPj7|OrT8po'
    str_2 = 'TCO'
    dict_1 = {'&W': 'TCO'}
    list_0 = ['TCO', 'TCO', 'TCO']
    action_module_0 = ActionModule(dict_0, dict_0, str_0, str_1, dict_1, list_0)


# Generated at 2022-06-25 07:38:40.509548
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:38:44.400755
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    str_0 = '8'
    list_0 = [str_0, str_0]
    action_module_0 = ActionModule(None, None, None, None, None, list_0)


# Generated at 2022-06-25 07:38:51.624510
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    str_0 = ',*>!_K'
    tuple_0 = (str_0,)
    set_0 = {tuple_0, str_0}
    dict_0 = {tuple_0: str_0, str_0: str_0}
    str_1 = '7,Q@'
    str_2 = '`'
    dict_1 = {tuple_0: str_0, str_0: str_0}
    list_0 = [str_0, str_0, str_0]
    str_3 = 'R'
    tuple_1 = (str_1, dict_0, str_2)
    action_module_0 = ActionModule(set_0, dict_1, str_1, str_2, dict_0, list_0)
   

# Generated at 2022-06-25 07:38:56.673083
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    str_0 = '&W'
    tuple_0 = (str_0,)
    set_0 = {tuple_0, str_0}
    dict_0 = {tuple_0: str_0, str_0: str_0}
    str_1 = 'EKPj7|OrT8po'
    str_2 = 'TCO'
    list_0 = [str_0, str_0, str_0]
    action_module_0 = ActionModule(set_0, dict_0, str_1, str_2, dict_0, list_0)
    var_0 = action_module_0.constructor(set_0)


# Generated at 2022-06-25 07:39:02.835790
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    str_0 = '&W'
    tuple_0 = (str_0,)
    set_0 = {tuple_0, str_0}
    dict_0 = {tuple_0: str_0, str_0: str_0}
    str_1 = 'EKPj7|OrT8po'
    str_2 = 'TCO'
    list_0 = [str_0, str_0, str_0]
    action_module_0 = ActionModule(set_0, dict_0, str_1, str_2, dict_0, list_0)
    action_module_0.run(None, None)
    action_module_0.run()


# Generated at 2022-06-25 07:39:05.709603
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = 'M1K}vT'
    var_1 = '&W'
    var_2 = [var_0, var_1]
    var_3 = (var_0,)
    var_4 = {var_0, var_1}
    action_module_0 = ActionModule(var_0, var_1, var_2, var_3, var_4, var_2)


# Generated at 2022-06-25 07:39:12.227161
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test 1
    bool_0 = False
    str_0 = '&W'
    tuple_0 = (str_0,)
    set_0 = {tuple_0, str_0}
    dict_0 = {tuple_0: str_0, str_0: str_0}
    str_1 = 'EKPj7|OrT8po'
    str_2 = 'TCO'
    list_0 = [str_0, str_0, str_0]
    action_module_0 = ActionModule(set_0, dict_0, str_1, str_2, dict_0, list_0)
    var_0 = action_run(bool_0)
    if bool_0:
        for str_3 in list_0:
            str_4 = str_3
            action_

# Generated at 2022-06-25 07:40:08.411742
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()


# Generated at 2022-06-25 07:40:13.444199
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    str_0 = 'f&]'
    tuple_0 = (str_0,)
    set_0 = {tuple_0, str_0}
    dict_0 = {tuple_0: str_0, str_0: str_0}
    str_1 = '='
    str_2 = '3$>-4=6QM*_'
    list_0 = [str_0, str_0, str_0]
    action_module_0 = ActionModule(set_0, dict_0, str_1, str_2, dict_0, list_0)
    var_0 = action_run(bool_0)


# Generated at 2022-06-25 07:40:14.988088
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: doesn't work:
    # action_module_0 = ActionModule()
    pass


# Generated at 2022-06-25 07:40:22.203140
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    str_0 = 'v7gW-?8r5d'
    set_0 = {str_0}
    dict_0 = {str_0: str_0}
    str_1 = '6+C%PJ'
    str_2 = 'o'
    dict_1 = {str_2: str_1}
    list_0 = [str_1, str_0, str_0]
    action_module_0 = ActionModule(set_0, dict_0, str_1, str_2, dict_1, list_0)
    result = action_module_0.run(bool_0)
    assert isinstance(result, dict)

# Generated at 2022-06-25 07:40:25.556296
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    raise Exception("Cannot call protected methods in unittests")
    # action_module_0 = ActionModule(set_0, dict_0, str_0, str_1, dict_0, list_0)
    # var_0 = action_module_0.run()

# Generated at 2022-06-25 07:40:27.411792
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    dict_0 = {}
    str_0 = 'J>'
    str_1 = 'kx+'
    test_case_0()

# Generated at 2022-06-25 07:40:32.887240
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    dict_0 = dict()
    str_0 = 'cNlhN'
    str_1 = 'Kw6B>'
    dict_1 = dict()
    list_0 = list()
    action_module_0 = ActionModule(set_0, dict_0, str_0, str_1, dict_1, list_0)
    return action_module_0


# Generated at 2022-06-25 07:40:41.263895
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    str_0 = "W"
    tuple_0 = (str_0,)
    set_0 = {tuple_0, str_0}
    dict_0 = {tuple_0: str_0, str_0: str_0}
    str_1 = "L"
    str_2 = "P>X"
    list_0 = [str_0, str_0, str_0]

    # Test of constructor of ActionModule
    action_module_0 = ActionModule(set_0, dict_0, str_1, str_2, dict_0, list_0)



# Generated at 2022-06-25 07:40:47.949066
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {
        'v': 'w',
        'y': 'z',
    }
    mock_tgt = 'hostname'
    mock_task = {'args': dict_0}
    mock_ansible_vars = {'inventory_hostname': mock_tgt}
    result = ActionModule.run(mock_task, mock_ansible_vars)['ansible_facts']['ansible_' + mock_tgt]
    assert result == dict_0

# Generated at 2022-06-25 07:40:51.918188
# Unit test for constructor of class ActionModule
def test_ActionModule():
    arg_0 = {('V', 0), ('F', 's', 'G'), ('k', '_'), ('x',)}