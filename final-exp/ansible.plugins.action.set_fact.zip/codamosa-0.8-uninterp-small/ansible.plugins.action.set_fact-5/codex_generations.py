

# Generated at 2022-06-25 07:31:22.514090
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # None as argument
    task_vars = None
    result = ActionModule(task_vars)


# Generated at 2022-06-25 07:31:32.574623
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Hr}2Gd_ '
    str_1 = 'nKxBJ'
    float_0 = -822.094
    float_1 = -1602.869
    tuple_0 = (str_1, bool_0, bool_0, bool_0, bool_0, bool_0)
    dict_0 = dict()
    str_2 = '_*j'
    str_3 = '?('
    int_0 = 572
    str_4 = 'R+M'
    int_1 = 497
    float_2 = 317.691
    bool_0 = True
    bool_1 = True
    tuple_1 = (float_1, float_0)
    float_3 = 3742.7678
    str_5 = 'X'
    float_

# Generated at 2022-06-25 07:31:39.681556
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = ''
    float_0 = 0.0
    float_1 = 0.0
    list_0 = []
    list_1 = []
    float_2 = 0.0
    action_module_0 = ActionModule(str_0, float_0, float_1, list_0, list_1, float_2)


# Generated at 2022-06-25 07:31:44.654628
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  pass

if __name__ == '__main__':
    n = 0
    # test_case_0(n)
    # test_ActionModule_run(n)
    # print("TOTAL TESTS RUN: ", n)

# Generated at 2022-06-25 07:31:51.116284
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  str_1 = 'p'
  float_2 = 2267.0
  float_3 = -2283.0
  list_1 = []
  list_2 = []
  float_4 = -1140.0
  action_module_1 = ActionModule(str_1, float_2, float_3, list_1, list_2, float_4)
  str_2 = '1'
  dict_0 = {}
  # 3 arguments expected
  try:
    action_module_1.run()
    assert False
  except TypeError:
    assert True
  # 1, 2 arguments expected
  try:
    action_module_1.run(dict_0)
    assert False
  except TypeError:
    assert True
  # 1, 2 arguments expected

# Generated at 2022-06-25 07:31:55.761329
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '(fIm`Z@ '
    float_0 = 1759.0
    list_0 = []
    float_1 = -2878.306
    action_module_0 = ActionModule(str_0, float_0, float_0, list_0, list_0, float_1)


# Generated at 2022-06-25 07:32:02.210027
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  str_0 = '`-J^7o'
  float_0 = 1633.894
  float_1 = -2928.9
  list_0 = []
  list_1 = []
  float_2 = -2478.26
  action_module_0 = ActionModule(str_0, float_0, float_1, list_0, list_1, float_2)
  result = action_module_0.run()
  print(result == dict)
  print(result == None)
  print(result == None)
  print(result == '@J')

test_ActionModule_run()

# Generated at 2022-06-25 07:32:12.423363
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '%!Q<g@mCm'
    int_0 = 1368816252
    int_1 = 304501058
    list_0 = []
    list_1 = ['8F', 'Uw=-/Ux', '&Q']
    float_0 = -2779.29
    float_1 = -1299.0
    action_module_0 = ActionModule(str_0, int_0, int_1, list_0, list_1, float_1)
    str_1 = 'ya'
    int_2 = -408612592
    int_3 = -1183
    list_2 = []

# Generated at 2022-06-25 07:32:16.912128
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '(fIm`Z@ '
    float_0 = 1759.0
    list_0 = []
    float_1 = -2878.306
    # call constructor
    action_module_0 = ActionModule(str_0, float_0, float_0, list_0, list_0, float_1)
    assert action_module_0


# Generated at 2022-06-25 07:32:23.455825
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except Exception as err:
        print("Exception thrown in constructor of class ActionModule")
        print(err)


# Generated at 2022-06-25 07:32:35.649027
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 150
    list_0 = [int_0]
    float_0 = 56.134
    tuple_0 = ()
    tuple_1 = (list_0, float_0, tuple_0)
    int_1 = 1000
    dict_0 = {int_1: int_1, int_1: int_1}
    set_0 = {int_1}
    str_0 = '2a1\x1b\x1a\x9a3\xfc\xcb\x8f\x91\xdc\x1d\xcf\xd1\x9e~\xda'
    bytes_0 = b"\xb1n\xce\xed\x0f\xa9\x9c\x98\xaf\xaf"
    action_module_0 = Action

# Generated at 2022-06-25 07:32:46.290521
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = 119.486
    float_0 = var_0
    list_0 = [float_0]
    int_0 = 500
    var_0 = int_0
    int_1 = var_0
    var_0 = int_1
    int_2 = var_0
    dict_0 = {int_1: int_1, int_2: int_1}
    bytes_0 = b"\xf5c\x95\x8f'/\x83\x1ex\xf6'\xe3\x10"
    str_0 = 'm*rRF.&Mw'
    set_0 = {int_1}
    tuple_0 = ()
    tuple_1 = (list_0, float_0, tuple_0)
    int_3 = 15
    action_module_0

# Generated at 2022-06-25 07:32:56.001527
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 15
    list_0 = [int_0]
    float_0 = 119.486
    tuple_0 = ()
    tuple_1 = (list_0, float_0, tuple_0)
    int_1 = 500
    dict_0 = {int_1: int_1, int_1: int_1}
    set_0 = {int_1}
    str_0 = 'm*rRF.&Mw'
    bytes_0 = b"\xf5c\x95\x8f'/\x83\x1ex\xf6'\xe3\x10"
    action_module_0 = ActionModule(dict_0, int_1, set_0, str_0, bytes_0, bytes_0)

# Generated at 2022-06-25 07:33:00.572273
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:33:10.390712
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_1 = 15
    list_0 = [int_1]
    float_0 = 119.486
    tuple_0 = ()
    tuple_1 = (list_0, float_0, tuple_0)
    int_2 = 500
    dict_0 = {int_2: int_2, int_2: int_2}
    set_0 = {int_2}
    str_0 = 'm*rRF.&Mw'
    bytes_0 = b"\xf5c\x95\x8f'/\x83\x1ex\xf6'\xe3\x10"
    action_module_0 = ActionModule(dict_0, int_2, set_0, str_0, bytes_0, bytes_0)

# Generated at 2022-06-25 07:33:16.328135
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    int_0 = 1
    set_0 = set()
    str_0 = ''
    bytes_0 = b''
    action_module_0 = ActionModule(dict_0, int_0, set_0, str_0, bytes_0, bytes_0)


if __name__ in ('__main__', '__builtin__', 'builtins'):
    test_case_0()

# Generated at 2022-06-25 07:33:27.636206
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # This is a test of the bacic run method of this class.
    # Our test cases will try to run the run method on the ActionModule class multiple times with
    # different inputs. For this we will need at least one instace of the ActionModule class and
    # it will be the action_module_0 instace.

    # Input for the first case: int_0 = 15, tuple_1 = (list_0, float_0, tuple_0)
    # The code that constructs the input:
    int_0 = 15
    list_0 = [int_0]
    float_0 = 119.486
    tuple_0 = ()
    tuple_1 = (list_0, float_0, tuple_0)
    # The code that constructs our action_module_0 instace:
    int_1 = 500

# Generated at 2022-06-25 07:33:37.369188
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 23
    list_0 = [int_0]
    float_0 = 88.67
    tuple_0 = ()
    tuple_1 = (list_0, float_0, tuple_0)
    int_1 = 500
    dict_0 = {int_1: int_1, int_1: int_1}
    set_0 = {int_1}
    str_0 = 'Z)7z^+\xf2\x9fE6\xac'
    bytes_0 = b"\xf5c\x95\x8f'/\x83\x1ex\xf6'\xe3\x10"
    action_module_0 = ActionModule(dict_0, int_1, set_0, str_0, bytes_0, bytes_0)
    assert action_module_

# Generated at 2022-06-25 07:33:42.368225
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 15
    list_0 = [int_0]
    float_0 = 119.486
    tuple_0 = ()
    tuple_1 = (list_0, float_0, tuple_0)
    int_1 = 500
    dict_0 = {int_1: int_1, int_1: int_1}
    set_0 = {int_1}
    str_0 = 'm*rRF.&Mw'
    bytes_0 = b"\xf5c\x95\x8f'/\x83\x1ex\xf6'\xe3\x10"
    action_module_0 = ActionModule(dict_0, int_1, set_0, str_0, bytes_0, bytes_0)


# Generated at 2022-06-25 07:33:45.340993
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 07:34:00.877981
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 15
    list_0 = [int_0]
    float_0 = 119.486
    tuple_0 = ()
    tuple_1 = (list_0, float_0, tuple_0)
    int_1 = 500
    dict_0 = {int_1: int_1, int_1: int_1}
    set_0 = {int_1}
    str_0 = 'm*rRF.&Mw'
    bytes_0 = b"\xf5c\x95\x8f'/\x83\x1ex\xf6'\xe3\x10"
    action_module_0 = ActionModule(dict_0, int_1, set_0, str_0, bytes_0, bytes_0)
    test_case_0()

# Generated at 2022-06-25 07:34:01.349107
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-25 07:34:12.331055
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  int_0 = 15
  list_0 = [int_0]
  float_0 = 119.486
  tuple_0 = ()
  tuple_1 = (list_0, float_0, tuple_0)
  int_1 = 500
  dict_0 = {int_1: int_1, int_1: int_1}
  set_0 = {int_1}
  str_0 = 'm*rRF.&Mw'
  bytes_0 = b"\xf5c\x95\x8f'/\x83\x1ex\xf6'\xe3\x10"
  action_module_0 = ActionModule(dict_0, int_1, set_0, str_0, bytes_0, bytes_0)
  tmp_0 = int_0
  task_vars_0

# Generated at 2022-06-25 07:34:17.631597
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 15
    list_0 = [int_0]
    float_0 = 119.486
    tuple_0 = ()
    tuple_1 = (list_0, float_0, tuple_0)
    int_1 = 500
    dict_0 = {int_1: int_1, int_1: int_1}
    set_0 = {int_1}
    str_0 = 'm*rRF.&Mw'
    bytes_0 = b"\xf5c\x95\x8f'/\x83\x1ex\xf6'\xe3\x10"
    action_module_0 = ActionModule(dict_0, int_1, set_0, str_0, bytes_0, bytes_0)
    assert action_module_0._connection == None
    assert action_

# Generated at 2022-06-25 07:34:28.618793
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 15
    list_0 = [int_0]
    float_0 = 119.486
    tuple_0 = ()
    tuple_1 = (list_0, float_0, tuple_0)
    int_1 = 500
    dict_0 = {int_1: int_1, int_1: int_1}
    set_0 = {int_1}
    str_0 = 'm*rRF.&Mw'
    bytes_0 = b"\xf5c\x95\x8f'/\x83\x1ex\xf6'\xe3\x10"

    action_module_0 = ActionModule(dict_0, int_1, set_0, str_0, bytes_0, bytes_0)


# Generated at 2022-06-25 07:34:31.472164
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:34:38.602242
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 15
    list_0 = [int_0]
    float_0 = 119.486
    tuple_0 = ()
    tuple_1 = (list_0, float_0, tuple_0)
    int_1 = 500
    dict_0 = {int_1: int_1, int_1: int_1}
    set_0 = {int_1}
    str_0 = 'm*rRF.&Mw'
    bytes_0 = b"\xf5c\x95\x8f'/\x83\x1ex\xf6'\xe3\x10"
    action_module_0 = ActionModule(dict_0, int_1, set_0, str_0, bytes_0, bytes_0)


# Generated at 2022-06-25 07:34:39.532635
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, 'Unimplemented test'

# Generated at 2022-06-25 07:34:50.488488
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 40
    list_0 = [int_0]
    float_0 = 85.907
    tuple_0 = ()
    tuple_1 = (list_0, float_0, tuple_0)
    int_1 = 500
    dict_0 = {int_1: int_1, int_1: int_1}
    set_0 = {int_1}
    str_0 = 'y\x03\x0b\x05.\xb3\xbf\x86\xe1\xcb\xbe\x9c\xbd\x18'
    bytes_0 = b"C\xfd\x85\xc4\x9b\x9f\xb6E\xdd\xe2\x1e6\xea\xc0"
    action_module_0 = Action

# Generated at 2022-06-25 07:34:59.771359
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 15
    list_0 = [int_0]
    float_0 = 119.486
    tuple_0 = ()
    tuple_1 = (list_0, float_0, tuple_0)
    int_1 = 500
    dict_0 = {int_1: int_1, int_1: int_1}
    set_0 = {int_1}
    str_0 = 'm*rRF.&Mw'
    bytes_0 = b"\xf5c\x95\x8f'/\x83\x1ex\xf6'\xe3\x10"
    action_module_0 = ActionModule(dict_0, int_1, set_0, str_0, bytes_0, bytes_0)

# Generated at 2022-06-25 07:35:24.573829
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1
    str_0 = 'B`F^,OV'
    str_1 = 'DjzR(~Xt'
    str_2 = 'q3l'
    list_0 = []
    int_1 = 1
    list_1 = [1, 2, 3]
    float_0 = 3.0
    list_2 = [1, 2, 3]
    float_1 = 3.0
    list_3 = [1, 2, 3]
    float_2 = 3.0
    tuple_0 = (list_2, float_1, list_3)
    str_3 = 'iF&3'
    list_4 = [int_1]
    list_5 = [1, 2, 3]
    float_3 = 3.0

# Generated at 2022-06-25 07:35:29.168743
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        assert (issubclass(ActionModule, ActionBase) == 1)
    except:
        print('Class ActionModule is not a subclass of ActionBase')
    try:
        assert (issubclass(ActionModule, ActionModule) == 1)
    except:
        print('Class ActionModule is not a subclass of ActionModule')


# Generated at 2022-06-25 07:35:39.371981
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 15
    list_0 = [int_0]
    float_0 = 119.486
    tuple_0 = ()
    tuple_1 = (list_0, float_0, tuple_0)
    int_1 = 500
    dict_0 = {int_1: int_1, int_1: int_1}
    set_0 = {int_1}
    str_0 = 'm*rRF.&Mw'
    bytes_0 = b"\xf5c\x95\x8f'/\x83\x1ex\xf6'\xe3\x10"
    action_module_0 = ActionModule(dict_0, int_1, set_0, str_0, bytes_0, bytes_0)


# Generated at 2022-06-25 07:35:44.976784
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 15
    list_0 = [int_0]
    float_0 = 119.486
    tuple_0 = ()
    tuple_1 = (list_0, float_0, tuple_0)
    int_1 = 500
    dict_0 = {int_1: int_1, int_1: int_1}
    set_0 = {int_1}
    str_0 = 'm*rRF.&Mw'
    bytes_0 = b"\xf5c\x95\x8f'/\x83\x1ex\xf6'\xe3\x10"
    action_module_0 = ActionModule(dict_0, int_1, set_0, str_0, bytes_0, bytes_0)

# Generated at 2022-06-25 07:35:53.844666
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 15
    list_0 = [int_0]
    float_0 = 119.486
    tuple_0 = ()
    tuple_1 = (list_0, float_0, tuple_0)
    int_1 = 500
    dict_0 = {int_1: int_1, int_1: int_1}
    set_0 = {int_1}
    str_0 = 'm*rRF.&Mw'
    bytes_0 = b"\xf5c\x95\x8f'/\x83\x1ex\xf6'\xe3\x10"
    action_module_0 = ActionModule(dict_0, int_1, set_0, str_0, bytes_0, bytes_0)

# Generated at 2022-06-25 07:35:57.333377
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print(ActionModule.__doc__)
    # test args
    print('\nTest args')
    test_case_0()
    # test var_args
    print('\nTest var_args')
    test_case_0()

#Unit test for method run

# Generated at 2022-06-25 07:36:06.242422
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(dict_0, int_1, set_0, str_0, bytes_0, bytes_0)
    var_0 = action_module_0.run(tmp=int_0, task_vars=tuple_1)
    assert isinstance(var_0, dict)
    assert str(var_0) == "{'ansible_facts': {}, 'changed': False, 'changed_when_result': False, 'failed': False, 'failed_when_result': False, 'rc': 0, 'skip_reason': 'Conditional result was False', 'skipped': True, 'skip_when_result': True, '_ansible_no_log': False}"


# Generated at 2022-06-25 07:36:14.324694
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    cacheable = False
    ansible_facts = {'int_0': int_0, 'list_0': list_0, 'float_0': float_0, 'tuple_0': tuple_0, 'tuple_1': tuple_1, 'int_1': int_1, 'dict_0': dict_0, 'set_0': set_0}
    facts = {int_1: int_1, int_1: int_1}
    _ansible_facts_cacheable = cacheable
    ansible_facts_2 = {'_ansible_facts_cacheable': _ansible_facts_cacheable, 'ansible_facts': ansible_facts}
    assert var_0 == ansible_facts_2

# Generated at 2022-06-25 07:36:22.193210
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("########## Constructor test for class ActionModule ##########")
    mux_0 = {2: 3, 3: 4, 4: 3}
    mux_1 = {2: 3, 3: 4, 4: 3}
    mux_2 = {2: 3, 3: 4, 4: 3}
    mux_3 = {2: 3, 3: 4, 4: 3}
    mux_4 = {2: 3, 3: 4, 4: 3}
    print(str(ActionModule(mux_0, mux_1, mux_2, mux_3, mux_4, mux_0)))
print("########## Constructor test ends ##########")

# Test case for method run

# Generated at 2022-06-25 07:36:26.687346
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 15
    list_0 = [int_0]
    float_0 = 119.486
    tuple_0 = ()
    tuple_1 = (list_0, float_0, tuple_0)
    int_1 = 500
    dict_0 = {int_1: int_1, int_1: int_1}
    set_0 = {int_1}
    str_0 = 'm*rRF.&Mw'
    bytes_0 = b"\xf5c\x95\x8f'/\x83\x1ex\xf6'\xe3\x10"
    action_module_0 = ActionModule(dict_0, int_1, set_0, str_0, bytes_0, bytes_0)


# Generated at 2022-06-25 07:37:14.504317
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 15
    list_0 = [int_0]
    float_0 = 119.486
    tuple_0 = ()
    tuple_1 = (list_0, float_0, tuple_0)
    int_1 = 500
    dict_0 = {int_1: int_1, int_1: int_1}
    set_0 = {int_1}
    str_0 = 'm*rRF.&Mw'
    bytes_0 = b"\xf5c\x95\x8f'/\x83\x1ex\xf6'\xe3\x10"
    action_module_0 = ActionModule(dict_0, int_1, set_0, str_0, bytes_0, bytes_0)

# Generated at 2022-06-25 07:37:22.183454
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 15
    list_0 = [int_0]
    float_0 = 119.486
    tuple_0 = ()
    tuple_1 = (list_0, float_0, tuple_0)
    int_1 = 500
    dict_0 = {int_1: int_1, int_1: int_1}
    set_0 = {int_1}
    str_0 = 'm*rRF.&Mw'
    bytes_0 = b"\xf5c\x95\x8f'/\x83\x1ex\xf6'\xe3\x10"
    action_module_0 = ActionModule(dict_0, int_1, set_0, str_0, bytes_0, bytes_0)

# Generated at 2022-06-25 07:37:30.697962
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = AnsibleModule(
        argument_spec=dict(
            a=dict(type='int', required=True),
            b=dict(type='list', required=True),
        ),
        supports_check_mode=True
    )
    int_0 = module.params['a']
    list_0 = module.params['b']

    run_result = ActionModule.run(int_0, list_0)
    assert run_result == 15

if __name__=='__main__':

    test_case_0()

# Generated at 2022-06-25 07:37:37.272789
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    cacheable = boolean(self._task.args.pop('cacheable', False))

    if self._task.args:
        for (k, v) in iteritems(self._task.args):
            k = self._templar.template(k)

            if not isidentifier(k):
                raise AnsibleActionFail("The variable name '%s' is not valid. Variables must start with a letter or underscore character, and contain only letters, numbers and underscores." % k)

            # NOTE: this should really use BOOLEANS from convert_bool, but only in the k=v case,
            # right now it converts matching explicit YAML strings also when 'jinja2_native' is disabled.

# Generated at 2022-06-25 07:37:47.952611
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 15
    list_0 = [int_0]
    float_0 = 119.486
    tuple_0 = ()
    tuple_1 = (list_0, float_0, tuple_0)
    int_1 = 500
    dict_0 = {int_1: int_1, int_1: int_1}
    set_0 = {int_1}
    str_0 = 'm*rRF.&Mw'
    bytes_0 = b"\xf5c\x95\x8f'/\x83\x1ex\xf6'\xe3\x10"
    action_module_0 = ActionModule(dict_0, int_1, set_0, str_0, bytes_0, bytes_0)
    assert list_0 == list_0

# Generated at 2022-06-25 07:37:51.428964
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # mock up the values
    tmp = None
    task_vars = None

    action_module_0 = ActionModule(tmp, task_vars)
    assert isinstance(action_module_0, ActionModule)

# Test that the module returns the desired value

# Generated at 2022-06-25 07:38:01.942409
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:38:05.922422
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule({}, 493, {}, '&F*', b'\xd7\xba\xee\xae\xb9g\xc7\x1f\x1a\x0e\xf6\xcc\x8b', b'\xd7\xba\xee\xae\xb9g\xc7\x1f\x1a\x0e\xf6\xcc\x8b')
    var_0 = action_module_0.run()


# Generated at 2022-06-25 07:38:16.892307
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 15
    list_0 = [int_0]
    float_0 = 119.486
    tuple_0 = ()
    tuple_1 = (list_0, float_0, tuple_0)
    int_1 = 500
    dict_0 = {int_1: int_1, int_1: int_1}
    set_0 = {int_1}
    str_0 = 'm*rRF.&Mw'
    bytes_0 = b"\xf5c\x95\x8f'/\x83\x1ex\xf6'\xe3\x10"
    action_module_0 = ActionModule(dict_0, int_1, set_0, str_0, bytes_0, bytes_0)
    assert len(action_module_0.ds) == 0
   

# Generated at 2022-06-25 07:38:22.288809
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ansible_facts_cacheable_0 = False
    dict_1 = {"ansible_facts": dict(), "_ansible_facts_cacheable": ansible_facts_cacheable_0}
    return dict_1



# Generated at 2022-06-25 07:40:00.391374
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 15
    list_0 = [int_0]
    float_0 = 119.486
    tuple_0 = ()
    tuple_1 = (list_0, float_0, tuple_0)
    int_1 = 500
    dict_0 = {int_1: int_1, int_1: int_1}
    set_0 = {int_1}
    str_0 = 'm*rRF.&Mw'
    bytes_0 = b"\xf5c\x95\x8f'/\x83\x1ex\xf6'\xe3\x10"
    action_module_0 = ActionModule(dict_0, int_1, set_0, str_0, bytes_0, bytes_0)
    assert isinstance(action_module_0, ActionModule)



# Generated at 2022-06-25 07:40:04.395212
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = []
    int_0 = 0
    set_0 = set()
    str_0 = ''
    action_module_0 = ActionModule(list_0, int_0, set_0, str_0, str_0, str_0)
    return int_0


# Generated at 2022-06-25 07:40:09.417859
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Test for ActionModule constructor')
    int_2 = 20
    list_1 = [int_2]
    float_1 = 119.486
    tuple_2 = ()
    tuple_3 = (list_1, float_1, tuple_2)
    int_3 = 500
    dict_1 = {int_3: int_3, int_3: int_3}
    set_1 = {int_3}
    str_1 = 'm*rRF.&Mw'
    bytes_1 = b"\xf5c\x95\x8f'/\x83\x1ex\xf6'\xe3\x10"
    action_module_1 = ActionModule(dict_1, int_3, set_1, str_1, bytes_1, bytes_1)


# Generated at 2022-06-25 07:40:18.663050
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 15
    list_0 = [int_0]
    float_0 = 119.486
    tuple_0 = ()
    tuple_1 = (list_0, float_0, tuple_0)
    int_1 = 500
    dict_0 = {int_1: int_1, int_1: int_1}
    set_0 = {int_1}
    str_0 = 'm*rRF.&Mw'
    bytes_0 = b"\xf5c\x95\x8f'/\x83\x1ex\xf6'\xe3\x10"
    action_module_0 = ActionModule(dict_0, int_1, set_0, str_0, bytes_0, bytes_0)
    assert(action_module_0 != None)


# Unit test

# Generated at 2022-06-25 07:40:22.579628
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule('GkGr%', 'i(', '|O8#v', '>^', 'o', 'D#')
    assert action_module_0._task.action == 'set_fact'
    assert action_module_0._task.args == dict()
    assert action_module_0._templar is None
    assert action_module_0._loader is None
    assert action_module_0._shared_loader_obj is None
    assert action_module_0._connection is None
    assert action_module_0._play_context is None
    assert action_module_0._task_vars is None
    assert action_module_0._templar is None
    assert action_module_0._tmp is None
    assert action_module_0._templar.basedir is None

# Generated at 2022-06-25 07:40:24.674990
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    tuple_1 = (m,)
    assert 8 == action_run('\x97\\\xa6\x9c\x8a\xa2\xed\xceL\xd2', tuple_1)

# Generated at 2022-06-25 07:40:31.460719
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = [1, 2, 3]
    float_0 = 119.486
    tuple_0 = ()
    tuple_1 = (list_0, float_0, tuple_0)
    int_0 = 500
    dict_0 = {int_0: int_0, int_0: int_0}
    set_0 = {int_0}
    str_0 = 'm*rRF.&Mw'
    bytes_0 = b"\xf5c\x95\x8f'/\x83\x1ex\xf6'\xe3\x10"
    action_module_0 = ActionModule(dict_0, int_0, set_0, str_0, bytes_0, bytes_0)
    print(action_module_0.get__task())


# Generated at 2022-06-25 07:40:42.083930
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    cacheable_0 = isidentifier(str_0)

    int_0 = 15
    list_0 = [int_0]
    float_0 = 119.486
    tuple_0 = ()
    tuple_1 = (list_0, float_0, tuple_0)
    int_1 = 500
    dict_0 = {int_1: int_1, int_1: int_1}
    set_0 = {int_1}
    str_0 = 'm*rRF.&Mw'
    bytes_0 = b"\xf5c\x95\x8f'/\x83\x1ex\xf6'\xe3\x10"
    action_module_0 = ActionModule(dict_0, int_1, set_0, str_0, bytes_0, bytes_0)

   

# Generated at 2022-06-25 07:40:45.760194
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp=None
    task_vars=None
    action_module_0 = ActionModule()
    action_run(tmp, task_vars)


# Generated at 2022-06-25 07:40:53.592741
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 15
    list_0 = [int_0]
    float_0 = 119.486
    tuple_0 = ()
    tuple_1 = (list_0, float_0, tuple_0)
    set_0 = {}
    str_0 = 'm*rRF.&Mw'
    int_1 = 500
    dict_0 = {int_1: int_1, int_1: int_1}
    action_module_0 = ActionModule(dict_0, int_1, set_0, str_0, str_0, str_0)
    action_module_0.run(int_0, tuple_1)