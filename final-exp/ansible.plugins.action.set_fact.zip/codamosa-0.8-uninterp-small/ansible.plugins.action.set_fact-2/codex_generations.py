

# Generated at 2022-06-25 07:31:27.545079
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    cacheable = True
    dict_0 = dict()
    dict_0['ansible_facts'] = dict()
    dict_0['_ansible_facts_cacheable'] = cacheable
    dict_1 = dict()
    dict_1['foo'] = 'bar'
    dict_1['baz'] = 'qux'
    str_0 = 'fake_action'
    dict_2 = dict()
    dict_2['cacheable'] = cacheable
    dict_2['baz'] = 'qux'
    dict_2['foo'] = 'bar'
    set_0 = frozenset()
    float_0 = 66.40
    str_1 = 'n1b~^PlN<|[nN'
    set_1 = frozenset()

# Generated at 2022-06-25 07:31:32.015217
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = None
    float_0 = 214.99
    str_0 = '_E{fF-nj;V\rJxR*w!rD'
    action_module_0 = ActionModule(str_0, set_0, float_0, str_0, set_0, set_0)


# Generated at 2022-06-25 07:31:42.247802
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp_0 = 'X'

# Generated at 2022-06-25 07:31:47.290539
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = None
    float_0 = 214.99
    str_0 = '_E{fF-nj;V\rJxR*w!rD'
    action_module_0 = ActionModule(str_0, set_0, float_0, str_0, set_0, set_0)
    assert type(action_module_0) == ActionModule
    assert action_module_0.TRANSFERS_FILES is False


# Generated at 2022-06-25 07:31:57.969543
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

    task = dict(
        args = dict(
            key = 'value',
            key2 = 2,
            key3 = '3',
        ),
    )
    actions = dict(
        name = 'setup',
        action = dict(),
        args = dict(),
        loader = None,
        templar = None,
    )
    task_vars = dict()
    tmp = None
    tmp_path = None
    delegate_to = None

    action_module_0._task = task
    action_module_0._task_fields = actions
    action_module_0._connection = action_module_0
    action_module_0._play_context = action_module_0
    action_module_0._loader = action_module_0
    action_module_0._

# Generated at 2022-06-25 07:32:01.718357
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = None
    float_0 = 214.99
    str_0 = '_E{fF-nj;V\rJxR*w!rD'
    action_module_0 = ActionModule(str_0, set_0, float_0, str_0, set_0, set_0)


# Generated at 2022-06-25 07:32:03.788794
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('\n test for constructor of class ActionModule')
    try:
        test_case_0()
    except:
        print('unit test for constructor of class ActionModule is failed')
    else:
        print('unit test for constructor of class ActionModule is passed')


# Generated at 2022-06-25 07:32:12.501720
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = None
    float_0 = 214.99
    str_0 = '_E{fF-nj;V\rJxR*w!rD'
    action_module_0 = ActionModule(str_0, set_0, float_0, str_0, set_0, set_0)
    task_vars = dict()
    assert action_module_0.run(str_0, task_vars) == {'ansible_facts': {}, '_ansible_facts_cacheable': False}, "Test case 0 failed"

if __name__ == "__main__":
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:32:13.602465
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()



# Generated at 2022-06-25 07:32:18.334735
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = None
    float_0 = 214.99
    str_0 = '_E{fF-nj;V\rJxR*w!rD'
    action_module_0 = ActionModule(str_0, set_0, float_0, str_0, set_0, set_0)
    # Run method of ActionModule
    action_module_0.run(None, None)


# Generated at 2022-06-25 07:32:26.229175
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'X'

    act = ActionModule()

# Generated at 2022-06-25 07:32:27.245941
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # TBD: Work on the test_case_0
    assert False

# Generated at 2022-06-25 07:32:31.175689
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test the exception-raising case
    try:
        ActionModule.run()
        assert 0 == 1
    except:
        pass

    # Test the non-exception-raising case
    raise NotImplementedError

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:32:40.597702
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test Variable
    tmp = None
    task_vars = {}

    # Test case 0
    test_obj = ActionModule("test_task", "test_file", None, None)
    test_obj._task = {}
    test_obj._task.args = {'test': 'test_value'}
    test_obj._templar = {}
    test_obj._templar.template = lambda x: x
    test_obj.run(tmp, task_vars)

    # Test case 1
    test_obj = ActionModule("test_task", "test_file", None, None)
    test_obj._task = {}
    test_obj._task.args = {'test': 'test_value'}
    test_obj._templar = {}

# Generated at 2022-06-25 07:32:47.970921
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test cases from issue https://github.com/ansible/ansible/issues/19395

    # Run test for method run of class ActionModule with args {"a": "b"} and values of return_value of mocked function _execute_module equal to "ret": {"failed": false, "invocation": {"module_name": "setup", "module_args": {"filter": "ansible_hostname"}, "module_complex_args": {}, "module_lang": "en_US.UTF-8", "module_set_locale": true}, "item": {"any": "test"}, "ansible_facts": {"ansible_hostname": "test"}} and None as tmp
    ret_obj = ActionModule(task={"args": {"a": "b"}, "action": "setup", "delegate_to": "all"})

# Generated at 2022-06-25 07:32:55.727024
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # action = ActionModule({'action': 'test_name_0', 'name': 'test_name_1'}, 'test_connection_0', {'play_context': 'test_play_context_0', 'Port': '22'}, 'test_loader_0', 'test_templar_0', 'test_shared_loader_obj_0')
    assert action != None

# Generated at 2022-06-25 07:32:56.983743
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule(None, None)
    assert isinstance(m, ActionModule)


# Generated at 2022-06-25 07:33:00.647123
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()


# Generated at 2022-06-25 07:33:10.409119
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    ansible_facts = dict()
    ansible_facts['hostvars'] = dict()
    task_vars = dict()

    # all fine, no data specified
    res = action_module._execute_module()
    assert(res['ansible_facts'] == ansible_facts)

    # all fine, data specified
    tmp = dict()
    tmp['x'] = dict()
    task_vars['ansible_facts'] = dict()
    task_vars['ansible_facts']['var_name'] = 'var_value'
    action_module = ActionModule()
    res = action_module._execute_module(tmp=tmp, task_vars=task_vars)
    assert(res['ansible_facts']['var_name'] == 'var_value')


# Generated at 2022-06-25 07:33:20.696383
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    str_0 = '/'
    dict_0 = dict()
    dict_1 = dict()
    dict_0['foo'] = 'bar'
    dict_1['foo'] = dict_0
    dict_1['ansible_check_mode'] = False
    dict_1['ansible_facts'] = dict()
    dict_2 = dict()
    dict_1['ansible_facts']['hardware'] = dict_2
    dict_3 = dict()
    dict_1['ansible_facts']['version'] = dict_3
    dict_2 = dict()
    dict_1['ansible_facts']['vars'] = dict_2
    dict_1['_ansible_facts_cacheable'] = False

# Generated at 2022-06-25 07:33:33.505145
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    set_0 = {'', '1LJB7JU5G5ZIJ7X9', 'n\'2+1"nJ*!q3Dyi'}
    str_0 = "hQ 'G3"
    int_0 = 6293
    int_1 = 6293
    dict_0 = {}
    action_module_0 = ActionModule(bool_0, set_0, str_0, int_0, int_1, dict_0)
    assert action_module_0 is not None


# Generated at 2022-06-25 07:33:38.605132
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    dict_0['group'] = 'guest'
    dict_0['action'] = 'user'
    dict_0['name'] = 'guest'
    dict_0['user'] = 'guest'
    dict_0['_ansible_check_mode'] = False
    dict_0['_ansible_verbosity'] = 0
    dict_0['_ansible_syslog_facility'] = None
    dict_0['_ansible_debug'] = False
    dict_0['_ansible_no_log'] = False
    dict_0['_ansible_diff'] = False
    dict_0['_ansible_user'] = 'guest'
    dict_0['_ansible_user_id'] = 'guest'

# Generated at 2022-06-25 07:33:45.343438
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    set_0 = {bool_0, bool_0, bool_0}
    str_0 = "hQ 'G3"
    int_0 = 2696
    dict_0 = {}
    action_module_0 = ActionModule(bool_0, set_0, str_0, int_0, int_0, dict_0)
    assert isinstance(action_module_0, ActionModule) == True
    assert action_module_0._task == {'action': 'set_fact', 'args': {'c': '3', 'b': '2', 'a': '1'}}
    assert isinstance(action_module_0._play_context, PlayContext) == True

# Generated at 2022-06-25 07:33:48.536828
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit tests for ansible.modules.files.set_fact.ActionModule
    '''
    assert test_case_0() == False, "Check if you have checked the  constructor in class 'ActionModule' correctly"

# Generated at 2022-06-25 07:33:50.705211
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_run_0 = action_module_0.run("N,lNdEH", "|R:+}@,/")


# Generated at 2022-06-25 07:33:57.556456
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_1 = False
    set_1 = {bool_1}
    str_1 = "+<8[(2,D^gtw}"
    int_1 = 662
    int_2 = 2216
    dict_1 = {}
    action_module_1 = ActionModule(bool_1, set_1, str_1, int_1, int_2, dict_1)
    tmp_0 = None
    task_vars_0 = {}
    var_1 = action_module_1.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 07:34:01.425060
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule class
    action_module_0 = ActionModule()
    # Call the run method
    assert 'success' in action_module_0.run()

# Generated at 2022-06-25 07:34:04.484846
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 07:34:06.154798
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.run(tmp=None, task_vars=None)

# Generated at 2022-06-25 07:34:08.584454
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action_module_0 = ActionModule()
    except NameError as e_0:
        assert False, "Failed to create instance of Class 'ActionModule'"


# Generated at 2022-06-25 07:34:19.592697
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_module_0.run()
    assert var_0 == None


# Generated at 2022-06-25 07:34:27.024289
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # setup
    bool_0 = True
    set_0 = {bool_0, bool_0, bool_0}
    str_0 = "hQ 'G3"
    int_0 = 2696
    dict_0 = {}
    action_module_0 = ActionModule(bool_0, set_0, str_0, int_0, int_0, dict_0)

    # test
    test_case_0()

    # teardown
    action_module_0 = None


# Generated at 2022-06-25 07:34:28.363348
# Unit test for constructor of class ActionModule
def test_ActionModule():
  pass

# Generated at 2022-06-25 07:34:31.910184
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    if action_module_0:
        print("PASSED")
    else:
        print("FAILED")

# Generated at 2022-06-25 07:34:38.918819
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    set_0 = {bool_0, bool_0, bool_0}
    str_0 = "hQ 'G3"
    int_0 = 2696
    dict_0 = {}
    action_module_0 = ActionModule(bool_0, set_0, str_0, int_0, int_0, dict_0)
    tmp = "9u2 "
    task_vars = "Y?z-:>P"
    action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 07:34:42.242438
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    set_0 = {bool_0, bool_0, bool_0}
    str_0 = ":F T9"
    int_0 = 215
    int_1 = 212
    dict_0 = {}
    action_module_0 = ActionModule(bool_0, set_0, str_0, int_0, int_1, dict_0)


# Generated at 2022-06-25 07:34:48.939271
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    set_0 = {bool_0, bool_0, bool_0}
    str_0 = "hQ 'G3"
    int_0 = 2696
    dict_0 = {}
    action_module_0 = ActionModule(bool_0, set_0, str_0, int_0, int_0, dict_0)
    print(vars(action_module_0))

# Generated at 2022-06-25 07:34:54.894076
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    set_0 = set()
    str_0 = "Y0]|&b `"
    int_0 = -8
    float_0 = 8.69
    dict_0 = {}
    action_module_0 = ActionModule(bool_0, set_0, str_0, int_0, float_0, dict_0)


# Generated at 2022-06-25 07:35:06.000295
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_0 = __import__('ansible.errors',  globals(), locals(), ['AnsibleActionFail'], -1)
    module_1 = __import__('ansible.constants', globals(), locals(), ['DEFAULT_JINJA2_NATIVE'], -1)
    module_2 = __import__('ansible.module_utils.parsing.convert_bool',  globals(), locals(), ['boolean'], -1)
    module_3 = __import__('ansible.utils.vars', globals(), locals(), ['isidentifier'], -1)
    module_4 = __import__('ansible.plugins.action',  globals(), locals(), ['ActionBase'], -1)

# Generated at 2022-06-25 07:35:07.421604
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:35:32.960940
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:35:36.639207
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_1 = "y6"
    str_2 = "L2f"
    dict_1 = {}
    action_module_1 = ActionModule(str_1, dict_1, str_2, dict_1, dict_1, dict_1)
    action_module_1.run()


# Generated at 2022-06-25 07:35:43.242910
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import random
    import string
    import sys
    import traceback

    #define static class variables
    static_var_0 = ""
    static_var_0 = "X_Wg1V7$6"
    static_var_1 = 0
    static_var_1 = 1291
    # Create randomized input values
    bool_0 = random.choice([True, False])
    set_0 = {random.randrange(sys.maxsize) for i0 in range(0, random.randrange(5, 10))}
    str_0 = ''.join([random.choice(string.ascii_letters + string.digits) for n in range(32)])
    int_0 = random.randrange(sys.maxsize) 
    int_1 = random.randrange(sys.maxsize) 
    dict_

# Generated at 2022-06-25 07:35:49.547303
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        arg_0 = False
        arg_1 = set()
        arg_2 = ""
        arg_3 = 0
        arg_4 = 0
        arg_5 = {}
        action_module_0 = ActionModule(arg_0, arg_1, arg_2, arg_3, arg_4, arg_5)
        print(action_module_0.run())
    except Exception:
        assert False

# Generated at 2022-06-25 07:35:54.322850
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    set_0 = {bool_0, bool_0, bool_0}
    str_0 = "hQ 'G3"
    int_0 = 2696
    dict_0 = {}
    action_module_0 = ActionModule(bool_0, set_0, str_0, int_0, int_0, dict_0)
    assert action_module_0 is not None


# Generated at 2022-06-25 07:36:04.883041
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = dict()

    # No bool_0 argument passed to constructor of ActionModule
    bool_0 = True
    set_0 = {bool_0, bool_0, bool_0}
    str_0 = "hQ 'G3"
    int_0 = 2696
    dict_0 = {}
    action_module_0 = ActionModule(bool_0, set_0, str_0, int_0, int_0, dict_0)

    # No set_0 argument passed to constructor of ActionModule
    bool_0 = True
    set_0 = {bool_0, bool_0, bool_0}
    str_0 = "hQ 'G3"
    int_0 = 2696
    dict_0 = {}

# Generated at 2022-06-25 07:36:05.631290
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert not False


# Generated at 2022-06-25 07:36:07.609462
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a test ActionModule object
    actionModule_obj = ActionModule(null, null, null, null, null, null)
    # test method run with arguments: (null)
    actionModule_obj.run(null)



# Generated at 2022-06-25 07:36:11.412210
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Set Execution Parameters
    set_0 = ()

    # Set Instantiation Parameters
    str_0 = "WV '9C"
    int_0 = 8787
    list_0 = [int_0, int_0]
    int_1 = 2062
    dict_0 = {str_0: list_0}
    action_module_0 = ActionModule(str_0, int_0, list_0, int_1, int_0, dict_0)

    # Call method run on object
    var_0 = action_run()

# Generated at 2022-06-25 07:36:18.784312
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    set_0 = {True, True, True}
    str_0 = ""
    int_0 = 5
    int_1 = 5
    dict_0 = {}
    action_module_0 = ActionModule(bool_0, set_0, str_0, int_0, int_1, dict_0)
    try:
        rc = action_module_0.run(None)
    except:
        # This is expected, it will fail because of no args in the task
        rc = None
    assert not rc


# Generated at 2022-06-25 07:37:09.959685
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    set_0 = {bool_0, bool_0, bool_0}
    str_0 = "hQ 'G3"
    int_0 = 2696
    dict_0 = {}
    action_module_0 = ActionModule(bool_0, set_0, str_0, int_0, int_0, dict_0)
    bool_1 = False
    set_1 = {bool_0, bool_0, bool_0}
    str_1 = '$'
    int_1 = 714
    dict_1 = {}
    action_module_1 = ActionModule(bool_1, set_1, str_1, int_1, int_1, dict_1)
    bool_2 = True
    set_2 = {bool_0, bool_0, bool_0}

# Generated at 2022-06-25 07:37:17.418714
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    set_0 = {bool_0, bool_0, bool_0}
    str_0 = "hQ 'G3"
    int_0 = 2696
    dict_0 = {}
    action_module_0 = ActionModule(bool_0, set_0, str_0, int_0, int_0, dict_0)
    action_run()
    var_0 = action_run()
    return var_0

# Generated at 2022-06-25 07:37:22.693265
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = {}
    int_0 = 1626
    str_0 = "A"
    dict_0 = {}
    bool_0 = True
    action_module_0 = ActionModule(bool_0, set_0, str_0, int_0, int_0, dict_0)
    var_0 = action_run()
    print(var_0)


# Generated at 2022-06-25 07:37:32.926103
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        set_0 = {False, True, True}
        str_0 = "S1 x"
        int_0 = 200
        dict_0 = {}
        action_module_0 = ActionModule(True, set_0, str_0, int_0, int_0, dict_0)
        var_0 = action_module_0.run(False, False)
        print("Output from test_ActionModule_run:")
        print("Variable var_0 is:", var_0)
        print("Type of variable var_0 is:", type(var_0))
        print("End of output from test_ActionModule_run")
    except SystemExit:
        print("Error in test_ActionModule_run: SystemExit")
    except ValueError:
        print("Error in test_ActionModule_run: ValueError")

# Generated at 2022-06-25 07:37:35.855372
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionModule()
    var_0.run()


# Generated at 2022-06-25 07:37:39.887019
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    set_0 = set()
    str_0 = "NtKhQ;7*SSGu~Ou!"
    int_0 = 6236
    int_0 = 8176
    dict_0 = {}
    action_module_0 = ActionModule(bool_0, set_0, str_0, int_0, int_0, dict_0)



# Generated at 2022-06-25 07:37:46.976433
# Unit test for constructor of class ActionModule
def test_ActionModule():
  
  # Test Error
  str_0 = 'p'
  str_1 = 'v'
  test_case_0 = {str_0 : str_0, str_0 : str_1, str_1 : str_1, str_1 : str_0}
  bool_0 = True
  set_0 = {bool_0, bool_0, bool_0}
  str_2 = "hQ 'G3"
  int_0 = 2696
  dict_0 = {}
  action_module_0 = ActionModule(bool_0, set_0, str_2, int_0, int_0, dict_0)

# Generated at 2022-06-25 07:37:48.201700
# Unit test for constructor of class ActionModule
def test_ActionModule():
    constructor_0 = test_case_0()


test_ActionModule()

# Generated at 2022-06-25 07:37:53.741146
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    set_0 = {bool_0, bool_0, bool_0}
    str_0 = ", d"
    int_0 = 2742
    int_1 = 3486
    dict_0 = {}
    action_module_0 = ActionModule(bool_0, set_0, str_0, int_0, int_1, dict_0)
    var_0 = action_module_0.run()
    print(var_0)


# Generated at 2022-06-25 07:38:03.615035
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    param_0 = dict()
    param_0['_ansible_no_log'] = True
    param_0['_ansible_verbosity'] = 1
    param_0['_ansible_check_mode'] = False
    param_0['_ansible_diff'] = False
    param_0['ansible_module_name'] = 'setup'
    param_0['ansible_version'] = {'string': '2.5.2', 'version': (2, 5, 2), 'full': '2.5.2', 'major': 2, 'minor': 5, 'revision': 2}
    param_0['ansible_modulest_dir'] = '/usr/lib/python3.6/site-packages/ansible/modules'

# Generated at 2022-06-25 07:39:46.096834
# Unit test for constructor of class ActionModule
def test_ActionModule():
    act_3 = ActionModule(None, None, None, None)
    assert act_3


# Generated at 2022-06-25 07:39:47.815107
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except:
        print('test_ActionModule failed')
        raise

# Generated at 2022-06-25 07:39:53.816366
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    set_0 = {bool_0, bool_0, bool_0}
    str_0 = "hQ 'G3"
    int_0 = 2696
    dict_0 = {}
    action_module_0 = ActionModule(bool_0, set_0, str_0, int_0, int_0, dict_0)
    action_module_0.run()
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:39:55.319990
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

if __name__ == "__main__":
    test_ActionModule_run()

# Generated at 2022-06-25 07:40:01.807335
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "v=g>*hQ'G3|({@+l$v=g>*hQ'G3|({@+l$v=g>*hQ'G3|({@+l$v=g>*hQ'G3|({@+l$v=g>*hQ'G3|({@+l$"
    dict_0 = {}
    dict_0['flag'] = 1
    dict_0['foo'] = int_0
    dict_0['flag'] = 'foo'
    dict_1 = dict()
    dict_0['foo'] = dict_1
    dict_0['foo'] = True
    dict_0['bar'] = 0
    dict_0['foo'] = 0
    dict_0['foo'] = int_0

# Generated at 2022-06-25 07:40:02.613451
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:40:03.501615
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assertEqual(test_case_0(), None)

# Generated at 2022-06-25 07:40:04.319638
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:40:05.153580
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        assert True
    except AssertionError:
        raise AssertionError

# Generated at 2022-06-25 07:40:08.115836
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    set_0 = {bool_0, bool_0, bool_0}
    str_0 = "hQ 'G3"
    int_0 = 2696
    dict_0 = {}
    action_module_0 = ActionModule(bool_0, set_0, str_0, int_0, int_0, dict_0)
    assert isinstance(action_module_0, ActionModule)
