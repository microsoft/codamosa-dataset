

# Generated at 2022-06-21 02:49:59.403263
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:50:05.501705
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import mock

    m_actionbase = mock.MagicMock(spec=ActionBase)
    mod_action_module = ActionModule()

    # case where no variables are provided
    module_args = dict()
    result = mod_action_module.run(tmp="", task_vars=dict(), **module_args)
    assert result['failed'] == True

    # case where invalid variable names are provided
    module_args = dict(A1='a')
    result = mod_action_module.run(tmp="", task_vars=dict(), **module_args)
    assert result['failed'] == True

    # case where valid variable names are provided
    module_args = dict(A1='a', A_1='a')

# Generated at 2022-06-21 02:50:09.739502
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule('test_name', 'test_remote_user', 'test_connection', 'test_module_name', 'test_module_args', 'test_pipelining', None, None)


# Generated at 2022-06-21 02:50:10.814775
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 02:50:12.745130
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not ActionModule(None, {}).run()

# Generated at 2022-06-21 02:50:23.726921
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(task=dict(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action.setup()
    result = action.run()
    assert result['failed']
    assert result['_ansible_verbose_always']
    assert result['msg'] == 'No key/value pairs provided, at least one is required for this action to succeed'

    # Make sure we raise an error when a variable name is invalid
    action = ActionModule(task=dict(args={'foo*bar': 'foobar'}), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action.setup()
    result = action.run()
    assert result['failed']

# Generated at 2022-06-21 02:50:33.459526
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create instances of the class under test
    am = ActionModule(None, None, None, None, None)
    tmp_dir = None
    task_vars = {"key": "value"}

    # Create test class for AnsibleModule
    class FakeAnsibleModule(object):
        def __init__(self, argument_spec, supports_check_mode, bypass_checks):
            self.params = {}

    fake_ansible_module = FakeAnsibleModule(None, None, None)

    # Create test class for Templar
    class FakeTemplar(object):
        def __init__(self, variables):
            self.variables = variables

        def template(self, template):
            return template

    fake_templar = FakeTemplar(None)

    # Create test class for Task

# Generated at 2022-06-21 02:50:37.956954
# Unit test for constructor of class ActionModule
def test_ActionModule():
    AM = ActionModule(  
        task     = None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert AM

# Generated at 2022-06-21 02:50:44.952361
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test setup
    test_Task_args = dict()
    test_Task_args['cacheable'] = 'False'
    test_Task_args['test_key_1'] = 'test_val_1'
    test_Task_args['test_key_2'] = 'test_val_2'
    test_Task_args['test_key_3'] = 'test_val_3'
    test_Task_args['test_key_4'] = 'test_val_4'
    test_Task_args['test_key_5'] = 'test_val_5'

    test_Task_vars = dict()
    test_Task_vars['test_var_1'] = 'test_var_1'
    test_Task_vars['test_var_2'] = 'test_var_2'
    test

# Generated at 2022-06-21 02:50:54.398101
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.module_utils._text import to_bytes

    from ansible.playbook.play_context import PlayContext

    from ansible.plugins.action import ActionBase

    from ansible.utils.display import Display
    display = Display()

    from ansible.plugins.loader import PluginLoader
    loader = PluginLoader(
        'ansible.plugins.action',
        'ActionModule',
        C.DEFAULT_ACTION_PLUGIN_PATH,
        'action_plugins',
        required_base_class=ActionBase
    )

    action = loader.get('set_fact', task=dict(action='set_fact'))
    action._display = display

# Generated at 2022-06-21 02:50:59.462956
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()

# Generated at 2022-06-21 02:51:06.686680
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  module_args = {'cacheable': False, 'ansible_os_family': 'RedHat'}
  action_module = ActionModule(None, module_args, load_plugins=False, templar=None, shared_loader_obj=None)

  expected_result = {
    'ansible_facts': {'ansible_os_family': 'RedHat'},
    '_ansible_facts_cacheable': False,
    '_ansible_no_log': False
  }
  result = action_module.run(tmp=None, task_vars=None)
  assert result == expected_result

  module_args = {'ansible_os_family': 'RedHat'}

# Generated at 2022-06-21 02:51:16.292688
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_subject = {}
    test_subject['any_string'] = 'any value'
    test_subject['_ansible_verbose_always'] = False
    test_subject['_ansible_version'] = '2.0.0.2'
    test_subject['_ansible_no_log'] = False
    test_subject['_ansible_debug'] = False
    test_subject['_ansible_diff'] = False
    test_subject['_ansible_keep_remote_files'] = False
    test_subject['_ansible_selinux_special_fs'] = ['fuse', 'nfs', 'vboxsf', 'ramfs']
    test_subject['_ansible_socket'] = None
    test_subject['_ansible_shell_executable'] = '/bin/sh'

# Generated at 2022-06-21 02:51:17.134329
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:51:21.277129
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, dict(a=2,b=3), None, '/path/to/nowhere')

    assert module.task.args == dict(a=2,b=3)
    assert module.basedir == '/path/to/nowhere'

# Generated at 2022-06-21 02:51:30.216033
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    assert ActionModule.run(
        tmp      =  'tmp',
        task_vars=  dict(
            key1=  'val1',
            key2=  'val2',
        ),
    ) == {
        'ansible_facts':   dict(
            key1=  'val1',
            key2=  'val2',
        ),
        '_ansible_facts_cacheable':   False,
    }

# Generated at 2022-06-21 02:51:42.403380
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Input data
    module = {"version": "v2"}
    tmp = None
    task_vars = {}
    plugins = {}
    def load_plugin(cls):
        plugin = cls()
        plugins[cls.__name__] = plugin
        return plugin


    # Set name and type for test
    task_vars['ansible_facts'] = dict()
    task_vars['ansible_facts']['test_custom'] = None
    task_vars['ansible_facts']['test_cacheable'] = None
    task_vars['ansible_facts']['test_default'] = None
    task_vars['ansible_facts']['cacheable'] = None
    task_vars['ansible_facts']['test_bool'] = None

# Generated at 2022-06-21 02:51:47.017678
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    module = ActionModule()

    # NOTE: this will raise an exception if any of the arg key/value pairs are not valid
    module.run(task_vars=None, tmp=None)


# Generated at 2022-06-21 02:51:48.874145
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None)
    assert am is not None

# Generated at 2022-06-21 02:51:55.849060
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create DummyActionModule
    class DummyActionModule(ActionModule):
        def __init__(self, task, connection, play_context, loader, templar,
                     shared_loader_obj):
            self._task = task
            self._connection = connection
            self._play_context = play_context
            self._loader = loader
            self._shared_loader_obj = shared_loader_obj
            self._templar = templar

            self._supports_check_mode = False
            self._supports_async = False
            self._supports_wait_for = False
            self._supports_async_poll = False
            self._supports_become = False
            self._supports_become_methods = None
            self._supports_test = False
            self._become = None


# Generated at 2022-06-21 02:52:14.443278
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None
    ansible_module_args = dict(key1=dict(key2="value"),
                               cacheable=True,
                               key3="value3")
    action_module = ActionModule(dict(), ansible_module_args)

    # test _task_vars
    assert action_module._task_vars is not None

    # test _templar
    assert action_module._templar is not None

    # test _load_name
    assert action_module._load_name == 'set_fact'

    # test _attributes
    assert action_module._attributes == dict(
        cacheable=True,
        key1=dict(key2="value"),
        key3="value3")



# Generated at 2022-06-21 02:52:16.211678
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print(ActionModule().run(None, {}))

# Generated at 2022-06-21 02:52:25.996994
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # declar some variables to test the method run
    tmp = None
    task_vars = None

    # create an object of class ActionModule
    tester = ActionModule(tmp, task_vars)

    # test for a string for set fact
    tester._task.args = {'var1': 'val1'}
    result = tester.run(tmp, task_vars)
    assert result['ansible_facts']['var1'] == 'val1'
    assert result['_ansible_facts_cacheable'] == False

    # test for a string for set fact
    tester._task.args = {'var1': 'val1', 'cacheable': True}
    result = tester.run(tmp, task_vars)

# Generated at 2022-06-21 02:52:29.040304
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    atm = ActionModule( { "args": { "var1": "val1", "var2": "val2" } }, {}, None, None, None)
    returned_value = atm.run({}, {})
    assert returned_value['ansible_facts'] == {'var1': 'val1', 'var2': 'val2'}


# Generated at 2022-06-21 02:52:30.737707
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(dict(), dict())
    assert am is not None

# Generated at 2022-06-21 02:52:42.630281
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a temp dir
    test_dir = tempfile.TemporaryDirectory()

    # Create a playbook
    playbook_path = os.path.join(test_dir.name, 'test.yml')

    with open(playbook_path, 'w') as fp:
        fp.write("""---
- hosts: localhost
  gather_facts: false
  tasks:
    - my_action:
        fact1: value1
        fact2: value2
""")

    # Initialize a runner
    runner = Runner(playbook_path, os.path.join(test_dir.name, 'test.retry'), [], None, None, None, None, None)

    # Run the action module: ansible.plugins.action.my_action
    result = runner.run()

    # Check that the action module succeeded

# Generated at 2022-06-21 02:52:54.227351
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play

    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultLib

    class Playbook:
        hostvars = dict()

    class PlayContext:
        playbook = Playbook()
        def __init__(self):
            self._host = Host(name='host')
            self._host.get_group = lambda: Group(name='group')

    # construct a task
    variable_manager = VariableManager()
    loader = DataLoader()

# Generated at 2022-06-21 02:53:05.249130
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Test the method run
    """
    # Initialize the class ActionModule
    action_module = ActionModule(load_args=dict())

    # Create a mock task
    mock_task = type('MockTask', (object,), {'args': {'cacheable': False}})()
    mock_task.args['var1'] = 'value1'
    mock_task.args['var2'] = 'value2'

    # Create a mock templar
    mock_templar = type('MockTemplar', (object,), {'template': lambda: True})()

    # Override the _templar and _task variables of class ActionModule
    action_module._templar = mock_templar
    action_module._task = mock_task

    # Test the run method
    result = action_module.run

# Generated at 2022-06-21 02:53:05.813301
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:53:15.304543
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    query = "dirname"
    action_module = ActionModule()
    task_vars = {
        'domain_name': 'example.org',
        'query': 'dirname'
    }
    task_vars['ansible_facts'] = {
      'domain_name': 'example.org'
    }
    action_module._task = {
        'args': {
            query: "{{ ansible_facts.domain_name }}"
        }
    }
    action_module._templar = {
        'template': (lambda x: x)
    }
    result = action_module.run(
        task_vars=task_vars
    )
    assert 'ansible_facts' in result
    assert result['ansible_facts'][query] == 'example.org'

# Generated at 2022-06-21 02:53:37.110127
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert (actionmodule is not None)

# Generated at 2022-06-21 02:53:44.179206
# Unit test for constructor of class ActionModule
def test_ActionModule():
    host = dict()
    host['hostname'] = 'localhost'
    host['port'] = 8000

    task_vars = dict()

    task = dict()
    task['args'] = dict()
    task['args']['var1'] = 'hello'
    task['args']['var2'] = 'world'

    tmp = 'fake'

    am = ActionModule(task, host, task_vars, tmp)
    assert am.task is task
    assert am.host is host
    assert am.task_vars is task_vars
    assert am.tmp is tmp
    assert am._task is task
    assert am._host is host
    assert am._task_vars is task_vars
    assert am._tmp is tmp

    action_results = am.run(tmp, task_vars)

# Generated at 2022-06-21 02:53:52.696930
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    import os
    from units.mock.loader import DictDataLoader

    # prepare mock environment
    mock_loader = DictDataLoader({
        os.path.join(C.DEFAULT_MODULE_PATH, 'Setup.py'): '#!/usr/bin/python',
    })
    mock_task_vars = dict(
        ansible_facts=dict(
            ansible_distribution='RedHat',
            ansible_distribution_major_version='7',
            ansible_distribution_version='7.2',
            ansible_distribution_release='7.2.1511',
        ),
    )

    # prepare arguments
    args = dict(
        ansible_os_family='RedHat',
        ansible_pkg_mgr='yum',
    )

    expected_

# Generated at 2022-06-21 02:54:02.368141
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args = {'errors': [], "warnings": []}
    task_vars = dict()
    tmp = None
    task = dict()
    task_vars["loop_var"] = range(0, 7)
    task_vars["loop_var1"] = range(0, 3)
    task['args'] = {'key_': 'value1'}
    fact = FactCollector.ActionModule(task=task, templar=Templar(templar=None), connection=None, play_context=None, loader=None, templar_args=None, shared_loader_obj=None)

    results = fact.run(tmp, task_vars)

    assert results["_ansible_facts_cacheable"] is False
    assert len(results["ansible_facts"].keys()) == 1

# Generated at 2022-06-21 02:54:11.648308
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.set_fact import ActionModule
    from ansible.errors import AnsibleActionFail
    import ansible.constants as C

    test_args = {'one': 1, 'true': True, 'false': False, 'none': None}

    test_task = {'args': test_args, 'register': 'fact_register'}

    test_task_vars = {'hostvars': {},
                      'vars': {'hostvars': {}, 'vars': {}}}

    test_config = {}

    test_action = ActionModule(None, None, test_task, None, test_task_vars, None, None, test_config)

    # test truthy returns
    test_task['args'].pop('none')

# Generated at 2022-06-21 02:54:12.188217
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-21 02:54:23.561530
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    module_name = 'ping'

    # Test when no arguments are passed (should fail)
    action = ActionModule(dict(), task_vars, module_name)
    result = action.run(tmp='/tmp', task_vars=task_vars)
    assert result['failed'] is True
    assert 'No key/value pairs provided, at least one is required for this action to succeed' in result['msg']

    # Test when invalid name is passed as key (should fail)
    action = ActionModule(dict(['invalid name', 'value']), task_vars, module_name)
    result = action.run(tmp='/tmp', task_vars=task_vars)
    assert result['failed'] is True
    assert 'The variable name \'invalid name\' is not valid' in result

# Generated at 2022-06-21 02:54:27.397990
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create ActionModule instance with Basic module arguments and no connection.
    am = ActionModule(task=dict(), connection=None, play_context=dict(), loader=None, templar=None, shared_loader_obj=None)
    assert len(am.SUPPORTED_FILTERS) > 0



# Generated at 2022-06-21 02:54:38.677014
# Unit test for constructor of class ActionModule
def test_ActionModule():
    fixture = dict(
        ANSIBLE_MODULE_ARGS=dict(
            foo='bar',
            answer=42,
            baz=True,
            qux=False,
            cacheable=True,
        ),
    )

    (action_module, args) = ActionModule._configure_module(fixture)
    assert action_module.run(task_vars=dict(ansible_facts=dict())) == dict(
        ansible_facts=dict(
            foo='bar',
            answer=42,
            baz=True,
            qux=False,
        ),
        _ansible_facts_cacheable=True,
    )

# Generated at 2022-06-21 02:54:50.176821
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.vars import merge_hash
    from ansible.module_utils.parsing.convert_bool import boolean
    import os

    fake_loader = DictDataLoader({
        "tests/ansible/test_action_module/test_set_fact.yml": b"",
    })
    fake_stdin = FakeInputStream()
    fake_stdout = FakeOutputStream()
    fake_stderr = FakeOutputStream()
    module_args = {'test_1': 'value_1', 'test_2': 'value_2'}
    task_vars = {'test_0': 'value_0'}
    loader = DataLoader()
    templar = Templar(loader=loader, variables=task_vars)

# Generated at 2022-06-21 02:55:43.620571
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action =  {
            'setup' : {
                'gather_subset' : [ 'all' ],
                'gather_timeout' : 10
            }
    }
    datastructure = {
        'ansible_facts' : {
            'local' : {
                'test' : 1
            },
            'remote' : {
            }
        },
        'changed' : False,
        'failed' : False,
        '_ansible_facts_cacheable' : True
    }

    result = ActionModule(action, datastructure, 'localhost', '/tmp/ansible').run()

    assert(result['ansible_facts']['local']['test'] == 1)

# Generated at 2022-06-21 02:55:47.678996
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 02:55:54.012292
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.process.worker import WorkerProcess
    from ansible.utils.vars import AnsibleVars

    test_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'unit', 'modules', 'script')

    class WorkerMock(WorkerProcess):
        def __init__(self, *args, **kwargs):
            super(WorkerMock, self).__init__(*args, connection='mock', su=None, su_user=None, su_pass=None, su_exe=None, become_method='root', become_user='bot', **kwargs)

# Generated at 2022-06-21 02:55:57.624271
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = AnsibleModule(argument_spec={})
    module.exit_json({'src': 'ansible.modules.action.facts'})


# Generated at 2022-06-21 02:56:00.424029
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  am = ActionModule()

  # Test idempotency with input that is not a dictionary
  am.run(1)

  # Test proper behavior with input that is a dictionary
  am.run(1, {'hello': 'world'})

# Generated at 2022-06-21 02:56:08.598746
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = {'args': {'a': 'b'}}
    tmp = None
    task_vars = {}
    action_module = ActionModule()
    result = action_module.run(tmp, task_vars)
    assert result['ansible_facts'] == {'a': 'b'}
    assert result['_ansible_facts_cacheable'] == False

# Generated at 2022-06-21 02:56:10.549974
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule()
    assert isinstance(x, ActionBase)
    assert hasattr(x, '_templar')
    assert hasattr(x, 'run')

# Generated at 2022-06-21 02:56:23.490365
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # mock objects for testing
    class MockActionBase(ActionBase):
        def run(self, tmp=None, task_vars=None):
            pass

    class MockTemplar(object):
        def template(name):
            return name

    class MockTask(object):
        def __init__(self):
            self.args = dict(k=v)

    module = dict(k=v)
    tmp = None
    task_vars = dict()
    myaction = MockActionBase(module, tmp, task_vars)
    action = ActionModule(module, tmp, task_vars)

    # don't allow passing cacheable
    task = MockTask()
    task.args = dict(cacheable=True)
    action = ActionModule(module, tmp, task_vars)

# Generated at 2022-06-21 02:56:33.058707
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.vars import combine_vars
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types

    test_dict = { 'ansible_facts': {'foo': 'bar', 'fiz': 'buz'}, 'changed': False, 'failed': False}
    test_bool = { 'ansible_facts': {'foo': 'false', 'fiz': 'true', 'bin': True, 'bun': False}, 'changed': False, 'failed': False}

    test_args = {}
    test_args_nested = {'ansible_facts': {'foo': 'bar', 'fiz': 'buz'}}

# Generated at 2022-06-21 02:56:38.833419
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.module_utils import basic
    import ansible.plugins
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch
    from ansible.playbook.play_context import PlayContext

    class FakeTask:
        def __init__(self):
            self.args = {}

    class FakeActionBase(ActionBase):
        def __init__(self):
            self._task = FakeTask()
            self._templar = basic.AnsibleModule(argument_spec={})

    module = FakeActionBase()

    # test string variables
    module.run({}, {})

    module.run({}, {'ansible_facts': {'k1': 'v1'}})


# Generated at 2022-06-21 02:58:22.085784
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(argument_spec={'cacheable': {'default': False, 'type': 'bool'}})
    # this should not raise an exception, only a failure
    try:
        am.run(task_vars={})
    except AnsibleActionFail:
        pass

    # Check that we raise the exception we expect when the facts are bad
    try:
        am.run(task_vars={}, tmp={}, args={'blah':'blah!'})
        raise RuntimeError("No exception raised for bad facts")
    except AnsibleActionFail as e:
        if not str(e).startswith("The variable name 'blah' is not valid."):
            raise RuntimeError("Wrong exception raised.")

# Generated at 2022-06-21 02:58:23.006211
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:58:26.081573
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 02:58:33.788632
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    from ansible.module_utils.six import PY2
    from ansible.module_utils.basic import AnsibleModule
    from ansible.executor.task_queue_manager import TaskQueueManager

    if PY2:
        mod_utils = AnsibleModule(
            argument_spec=dict(
                name=dict(type='str', required=True),
                new=dict(type='bool', required=True),
                cacheable=dict(type='bool', required=False),
            ),
            supports_check_mode=False,
        )

# Generated at 2022-06-21 02:58:35.816757
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None, dict(), dict())
    assert a is not None

# Generated at 2022-06-21 02:58:36.705844
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:58:41.379972
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Execute the constructor of class ActionModule
    class_inst = ActionModule()
    # Validate the values of instance variables TRANSFERS_FILES and BYPASS_HOST_LOOP
    assert class_inst.TRANSFERS_FILES == False
    assert class_inst.BYPASS_HOST_LOOP == True

# Generated at 2022-06-21 02:58:51.385083
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(task=dict(args={'java_home': '/usr/lib/jvm/java-8-openjdk-amd64/jre/'}),
                          connection=None,
                          play_context=None,
                          loader=None,
                          templar=None,
                          shared_loader_obj=None)
    result = module.run()
    assert result['_ansible_facts_cacheable'] == False
    assert len(result['ansible_facts']) == 1
    assert result['ansible_facts']['java_home'] == '/usr/lib/jvm/java-8-openjdk-amd64/jre/'

# Generated at 2022-06-21 02:58:54.782759
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None)
    assert isinstance(action, ActionModule)


# Generated at 2022-06-21 02:59:03.382598
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert not hasattr(action, '_variables')
    assert not hasattr(action, '_shared_loader_obj')

    action = ActionModule(task=dict(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert not hasattr(action, '_connection')
    assert not hasattr(action, '_task')
    assert not hasattr(action, '_loader')
    assert not hasattr(action, '_templar')
    assert not hasattr(action, '_loader_name')
    assert not hasattr(action, '_shared_loader_obj')


# Unit test