

# Generated at 2022-06-21 02:50:05.501873
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest2 as unittest

    # Unit test for method run of class ActionModule
    # For example:
    #   class ActionModule:
    #     def run(self, tmp=None, task_vars=None):
    #         return super(ActionModule, self).run(tmp, task_vars)

# Generated at 2022-06-21 02:50:08.251276
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert a

# Generated at 2022-06-21 02:50:11.219370
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        x = ActionModule(None, None)
    except:
        assert True
    else:
        assert False, 'ActionModule constructor should fail without arguments'

# Generated at 2022-06-21 02:50:19.510894
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.plugins.action.set_fact import ActionModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C
    # https://github.com/ansible/ansible/issues/20302
    import sys
    import os
    global __file__
    __file__ = os.path.realpath(__file__)
    if sys.version_info[0] <= 2:
        open = __builtins

# Generated at 2022-06-21 02:50:29.176635
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    original_task_vars = {
        "testvar1": "5",
        "testvar2": "true",
        "testvar3": "10",
        "testvar4": "false",
    }
    module = ActionModule(
        task={"args": {"testvar1": "{{ testvar3 }}", "_ansible_tmpdir": "/tmp"}, "action": "set_fact"},
        connection=None,
        task_vars=original_task_vars)
    result = module.run(task_vars=original_task_vars)
    expected_result = {
        "ansible_facts": {"testvar1": 10},
        "changed": False,
    }
    assert result == expected_result
    result = module.run(task_vars=original_task_vars)
    expected

# Generated at 2022-06-21 02:50:33.313374
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, None, None, None, None, None, None)
    assert 'ansible_facts' in module.run()
    assert '_ansible_facts_cacheable' in module.run()
    assert 'failed' not in module.run()

# Generated at 2022-06-21 02:50:43.040026
# Unit test for constructor of class ActionModule
def test_ActionModule():
  import unittest
  from mock import MagicMock
  from ansible.module_utils.six import iteritems

  class TaskMock:
      def __init__(self):
          self.__args = {}
          self.__action = None

      @property
      def args(self):
          return self.__args

      @property
      def action(self):
          return self.__action

      def set_args(self, args):
          self.__args = args

      def set_action(self, action):
          self.__action = action

  class ModuleUtilsVarsMock:
      @staticmethod
      def isidentifier(arg):
          return True



# Generated at 2022-06-21 02:50:44.388605
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert ActionModule(dict(), dict()).run() == {}

# Generated at 2022-06-21 02:50:45.257279
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:50:49.517720
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #from ansible.plugins.action.set_fact import ActionModule

    test_ActionModule = ActionModule(
            task=dict(vars=dict()),
            connection=dict(),
            play_context=dict(become_method=None),
            loader=None,
            templar=None,
            shared_loader_obj=None)
    assert test_ActionModule != None

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-21 02:50:54.998108
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, {}, [], [], '')
    assert module is not None

# Generated at 2022-06-21 02:50:58.229773
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, None, None, None, 'set_fact', None, None)
    assert module

# Generated at 2022-06-21 02:51:03.397954
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    This function will test if the constructor of a class ActionModule
    works properly.
    """
    arguments = {u'cacheable': u'false'}
    task = {}
    task['action'] = {}
    task['action']['args'] = arguments
    action_module = ActionModule(task, {})
    assert action_module._task.args['cacheable'] == 'false'

# Generated at 2022-06-21 02:51:14.575557
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.playbook.task_include
    import ansible.playbook.role.include

    class MockPlayContext(object):

        def __init__(self, loader=None):
            self.connection = "local"
            self.network_os = "default"
            self.remote_addr = None
            self.port = None
            self.remote_user = 'ansible'
            self.password = None
            self.private_key_file = None
            self.timeout = 10
            self.shell = None
            self.become = False
            self.become_method = None
            self.become_user = None
            self.become_pass = None
            self.no_log = False
            self.verbosity = 0
            self.only_tags = []
            self.skip_tags = []


# Generated at 2022-06-21 02:51:14.993770
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:51:23.529161
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test changeable variable
    variable = {'k': 'v'}
    resolve_variable(variable, 'k', 'new v')
    assert variable['k'] == 'new v', 'The variable must be changeable.'

    # Test variable is not changeable
    variable = {'k': 'v'}
    resolve_variable(variable, 'k', 'new v', is_changeable=False)
    assert variable['k'] == 'v', 'The variable should not be changeable.'

    # Test variable already in arguments
    variable = {'k': 'v'}
    resolve_variable(variable, 'k', 'new v', is_changeable=False, args={'k': 'v'})
    assert variable['k'] == 'v', 'The variable should not overwrite the argument.'

    # Test variable already in arguments, with changeable

# Generated at 2022-06-21 02:51:34.768138
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.module_utils.facts.virtual.base
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.processor

    # Include necessary classes, since this test file is not run through ansible
    class FakeLoader:
        pass

    # Include necessary classes, since this test file is not run through ansible
    class FakeVarsManager:
        @staticmethod
        def _get_vars():
            return {}

    class FakePlayContext:
        # Provide necessary data
        def __init__(self):
            self.remote_addr = 'localhost'
            self.connection = 'local'
            self.network_os = 'localhost'
            self.remote_user = 'root'
            self.port = 0
            self.become = False
            self.become_user = ''

# Generated at 2022-06-21 02:51:35.685532
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Constructor of class ActionModule")
    print(ActionModule)

# Generated at 2022-06-21 02:51:37.174156
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-21 02:51:45.725857
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import sys
    from ansible.plugins.loader import action_loader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    context = PlayContext()

    variable_manager = VariableManager()
    variable_manager.set_inventory(os.path.join(os.path.dirname(os.path.realpath(__file__)), '../../../'))

    a = action_loader.get('set_fact', variable_manager=variable_manager, loader=None)
    a._task.register_template_loader(variable_manager._loader)

    class MyTask():
        def __init__(self):
            self.args = dict()
            self.args['var1'] = 'value info'
            self.args['var2'] = 'value info'

# Generated at 2022-06-21 02:52:04.230212
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = dict()
    task_vars = dict()

    import ansible.plugins.action.set_fact
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role


# Generated at 2022-06-21 02:52:12.692864
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json
    from collections import namedtuple

    mock_loader = namedtuple('mock_loader', ['get_basedir'])
    mock_play_context = namedtuple('mock_play_context', ['remote_addr', 'connection', 'network_os', 'become_method', 'become_user'])
    action = ActionModule(mock_loader, "/path/to/nowhere", "test.yml", 1, [], "/tmp", "/tmp", mock_play_context, False)

    assert type(action) == ActionModule

# Generated at 2022-06-21 02:52:16.268025
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule({'cacheable': True})
    assert am.TRANSFERS_FILES is False

# Generated at 2022-06-21 02:52:18.205547
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=dict()) is not None


# Generated at 2022-06-21 02:52:21.852160
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Only test constructor. This is a private interface
    # which is tested implicitly by the rest of the code.
    m = ActionModule('/', {}, {}, {}, 'test')
    assert m is not None

# Generated at 2022-06-21 02:52:30.693564
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import copy

    action_module = ActionModule(task=dict(action=dict(module='set_fact', args=dict(a='b'))))

    # TODO(dtan4): assertEqual?
    assert action_module.run(task_vars={'a': 'b'}) == dict(ansible_facts={'a': 'b'},
                                                           _ansible_facts_cacheable=False,
                                                           _ansible_no_log=False)

# Generated at 2022-06-21 02:52:36.261498
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Dummy object to wrap
    class DummyHost:
        pass

    class DummyTask:
        pass

    module = ActionModule(DummyHost(), DummyTask())
    assert module.supports_check_mode == False

# Generated at 2022-06-21 02:52:41.939882
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import pytest
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import combine_vars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.executor.process.result import Result
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types

    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.set_fact import ActionModule
    from tests.units.library.subclass_module_utils_module import FakeModuleUtilsModule

    module_utils_module = FakeModuleUtilsModule
    context = PlayContext()
    qm

# Generated at 2022-06-21 02:52:42.766804
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:52:54.260031
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Instantiate an object of class ActionModule
    module_1 = ActionModule()
    print('type(module_1): {0}'.format(type(module_1)))

    module_2 = ActionModule()
    print('type(module_2): {0}'.format(type(module_2)))

    # Unit test for ActionBase.run()
    task_vars = {'host_1': {'hostname': 'host_1', 'port': 2222},
                 'host_2': {'hostname': 'host_1', 'port': 2222}}

    print('type(task_vars): {0}'.format(type(task_vars)))
    print('type(task_vars.items()): {0}'.format(type(task_vars.items())))


# Generated at 2022-06-21 02:53:17.262604
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest

    # Import a plugin module (module_utils/facts.py) that is in the same directory as the
    # Ansible plugin under test (plugins/action/set_fact.py) to test that the correct
    # module_utils directories are used.
    from ansible.module_utils.facts import Facts
    # Import a module_utils function (path_dwim) that is in a subdirectory of the
    # Ansible plugin under test (plugins/action/set_fact.py) to test that the correct
    # module_utils directories are used.
    import ansible.module_utils.shell.basic
    from ansible.module_utils.shell.basic import path_dwim

    # Mock the module_utils functions used in the plugin under test (plugins/action/set_fact.py).

# Generated at 2022-06-21 02:53:18.528033
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Arrange
    actionModule = ActionModule()

    # Act
    # Assert

# Generated at 2022-06-21 02:53:30.825010
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action = ActionModule(dict(module_name='test_module'))
    action._task = dict(args=dict(a=1, b='c'))
    action._templar = None
    assert action.run() == dict(ansible_facts=dict(a=1, b='c'),
                                _ansible_facts_cacheable=False)

    action = ActionModule(dict(module_name='test_module'))
    action._task = dict(args=dict(cacheable='yes', a=1, b='c'))
    action._templar = None
    assert action.run() == dict(ansible_facts=dict(a=1, b='c'),
                                _ansible_facts_cacheable=True)

    action = ActionModule(dict(module_name='test_module'))
    action

# Generated at 2022-06-21 02:53:41.448331
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    module = ActionModule(None, None)
    # 1. test happy path
    result = module.run(None, {'foo':'bar'})
    assert result is not None
    assert result['failed'] == False
    assert result['ansible_facts'] == {'foo':'bar'}
    assert result['_ansible_facts_cacheable'] == False

    # 2. test negative examples
    #   a. no argument provided
    result = module.run(None, {'foo':'bar'})
    assert result is not None
    assert result['failed'] == True
    assert result['msg'] == 'No key/value pairs provided, at least one is required for this action to succeed'
    #   b. invalid identifier used
    result = module.run(None, {'foo':'bar'})
    assert result is not None

# Generated at 2022-06-21 02:53:42.307790
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:53:44.366456
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None, "Class ActionModule should be defined."

# Generated at 2022-06-21 02:53:52.768772
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create empty Task object
    task = {}

    # Create empty TaskResult object
    taskresult = {}

    # Create empty ActionModule object
    am = {}

    # Set task["action"] to ActionModule
    task["action"] = "ActionModule"

    # Set task["args"] to a dictionary of Ansible facts

# Generated at 2022-06-21 02:53:54.296273
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    result = action.run()
    assert result

# Generated at 2022-06-21 02:54:03.431284
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create the debug task to be executed
    task = dict()
    task['args'] = dict()

    # The variables to set
    task['args']['foo'] = "bar"
    task['args']['bar'] = "baz"

    # The debugging to enable
    task['args']['debug'] = False
    task['args']['verbosity'] = 0

    # The module meta
    task['action'] = 'debug'
    task['name'] = 'test'

    # The task vars
    task_vars = dict()
    task_vars['debug'] = True
    task_vars['verbosity'] = 2

    module = ActionModule(task, task_vars)
    result = module.run()

    # Check the result
    assert result['ansible_facts']['foo']

# Generated at 2022-06-21 02:54:05.130216
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule({})
    assert {} == module.run()



# Generated at 2022-06-21 02:54:39.458788
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize the unit test
    module = ActionModule(dict())

    # Initialize data
    args = {}
    k = 'key'
    v = 'value'
    args[k] = v
    args['cacheable'] = False
    module._task.args = args
    tmp = None
    task_vars = {}
    result = {'ansible_facts': {}, '_ansible_facts_cacheable': False}

    # Test with proper data
    try:
        module.run(tmp, task_vars)
        assert True
    except AnsibleActionFail as e:
        print('test_ActionModule_run.raise exception: %s' % (e.message,))
        assert False

    # Test with improper data, empty args
    args = {}
    module._task.args = args

# Generated at 2022-06-21 02:54:48.164152
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    if sys.version_info[0] == 2:
        # Need to patch this method because it makes use of both iteritems and six.string_types
        from ansible.plugins.action.set_fact import ActionModule
        def iteritems(d, **kw):
            return d.iteritems(**kw)
        ActionModule.TRANSFERS_FILES = False
        from ansible.module_utils import six
        six.string_types = basestring
        six.iteritems = iteritems

# Generated at 2022-06-21 02:54:59.782979
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json
    import tempfile
    import shutil
    import unittest

    class Constructor(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.loader = DictDataLoader({})
            self.variable_manager = VariableManager()
            self.inventory = Inventory(
                loader=self.loader, variable_manager=self.variable_manager,
                host_list=[])
            self.playbook = Playbook.load(
                'test.yml', variable_manager=self.variable_manager, loader=self.loader)
            self.play = Play().load(
                self.playbook[0], variable_manager=self.variable_manager, loader=self.loader)


# Generated at 2022-06-21 02:55:02.602081
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = dict()
    templar = dict()
    action = ActionModule(task, templar)
    assert action.run() == dict()

# Generated at 2022-06-21 02:55:05.414041
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule()
    m.run()


# Generated at 2022-06-21 02:55:09.519944
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule(task=dict(action=dict(module_name=''), args=dict(cacheable=False, vars=dict(a='1', b='2'))))
    assert actionModule.run(None, None) == {'ansible_facts': {'a': '1', 'b': '2'}, '_ansible_facts_cacheable': False}

# Generated at 2022-06-21 02:55:18.860473
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actmod_obj = ActionModule(load_module_spec=False,argument_spec={},supports_check_mode=False)
    actmod_obj.datastructure = {'cacheable': False}
    actmod_obj._task = {'args': {'test_value':'test_value'}}
    result = actmod_obj.run()
    if result.get('ansible_facts') != {'test_value': 'test_value'}:
        raise AssertionError(result)

# Generated at 2022-06-21 02:55:20.205039
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True, "Unit test not yet implemented"

# Generated at 2022-06-21 02:55:24.464308
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 02:55:33.656449
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Test run method"""
    from ansible.plugins.action.set_fact import ActionModule
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_executor import TaskExecutor
    import sys

    parameters = {
        'cacheable': False,
        '_ansible_loop_var': 'item',
        '_ansible_no_log': True,
        '_ansible_item_label': 'useless_string',
        'ansible_loop_var': 'item',
        'ansible_no_log': True,
        'ansible_item_label': 'useless_string',
    }

    task = Task()

# Generated at 2022-06-21 02:56:37.859075
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:56:46.286689
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create an action module and call its run method with some test data
    am = ActionModule({})
    result = am.run(tmp='/tmp', task_vars={'hostvars': {'host01': {'my_facter_fact': 'fact01'}}})
    assert result == {'ansible_facts': {}, 'changed': False, 'failed': True}


if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-21 02:56:52.667520
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule({}, {})

    # Unset temporary variables
    am._task.args = {}
    am._task.args['group_name'] = 'admins'
    am._task.args['group_id'] = '17'
    am._task.args['cacheable'] = True
    am.run()

    am._task.args = {}
    am._task.args['group_name'] = 'admins'
    am._task.args['group_id'] = '17'
    am._task.args['cacheable'] = False
    am.run()

    am._task.args = {}
    am._task.args['group_name'] = 'admins'
    am._task.args['group_id'] = '17'
    am._task.args['cacheable'] = 'yes'

# Generated at 2022-06-21 02:56:56.891486
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(action='ActionModule', task=dict())
    module._configure_instance()
    return module

# Test:
#   Verify set_fact returns true and stores variable

# Generated at 2022-06-21 02:57:04.139244
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test the memoize decorator
    ActionModule.run._clear_cache()
    expected_tasks_vars = {'ansible_facts': {'x': 'y'}}
    with pytest.raises(AnsibleActionFail) as excinfo:
        action_module = ActionModule({'x': 'y'}, {})
        action_module.run()
    assert str(excinfo.value) == 'Unable to create any variables with provided arguments'

    # test the memoize decorator
    ActionModule.run._clear_cache()
    expected_tasks_vars = {'ansible_facts': {'x': 'y'}}
    action_module = ActionModule({'x': 'y'}, {})
    action_module.run()

# Generated at 2022-06-21 02:57:12.065860
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup

    task = dict(
        action = dict(
            module = 'set_fact',
            args = dict(
                a = '1',
                b = '2',
                c = '3',
            )
        )
    )

    # Test
    a = ActionModule(task, dict())
    res = a.run(None, dict(ansible_facts=dict(foo='bar')))

    # Assert
    assert res, "Result should not be empty"
    assert res['ansible_facts']['a'] == '1', "Fact 'a' should be 1"
    assert res['ansible_facts']['b'] == '2', "Fact 'b' should be 2"
    assert res['ansible_facts']['c'] == '3', "Fact 'c' should be 3"
   

# Generated at 2022-06-21 02:57:21.497335
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.playbook.play_context import PlayContext

    display = Display()
    play_context = PlayContext()
    play_context._task = dict(action=dict(module_name='set_fact'))

    module = ActionModule(
        task=dict(vars=dict()),
        connection=None,
        play_context=play_context,
        loader=None,
        templar=None,
        shared_loader_obj=None)
    # intentionally using the same module as above to trigger the AnsibleActionFail in run()

# Generated at 2022-06-21 02:57:25.660818
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_module_loader = None
    test_task = None
    print(ActionModule(test_task, test_module_loader))
    assert action_module()

# Generated at 2022-06-21 02:57:31.342837
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Init the ActionModule object
    actmod = ActionModule(None, None, None, None)

    # Test run
    facts = {'firstfact': 'value1', 'secondfact': 'value2'}
    cacheable = False
    result = actmod.run({}, {}, facts=facts, cacheable=cacheable)
    assert result['ansible_facts'] == facts
    assert result['_ansible_facts_cacheable'] == cacheable
    assert result['changed'] == False

# Generated at 2022-06-21 02:57:34.013902
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

if __name__ == '__main__':
    test_ActionModule_run()