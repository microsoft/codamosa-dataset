

# Generated at 2022-06-21 02:50:03.028177
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_mod = ActionModule(
        task=dict(
            action=dict(
                module_name='facter', args=dict(FACTER_name='dag')
            ),
            args=dict(FACTER_name='dag')
        ),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert action_mod

# Generated at 2022-06-21 02:50:14.387119
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args_vars = {'cacheable': True, 'var1': 'value'}
    args_no_vars = {}
    action1 = ActionModule(None, args_vars, None, None)
    action1._task.module_vars = {}
    action2 = ActionModule(None, args_no_vars, None, None)
    action2._task.module_vars = {}
    result1 = action1.run(None, None)
    result2 = action2.run(None, None)
    assert(result1['ansible_facts']['var1'] == 'value')
    assert(result1['_ansible_facts_cacheable'] == True)
    assert('ansible_facts' not in result2)
    assert('_ansible_facts_cacheable' not in result2)

# Generated at 2022-06-21 02:50:16.385553
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructing a class object
    am = ActionModule(None, dict())
    # Asserting that the object instance is created successfully
    assert am is not None


# Generated at 2022-06-21 02:50:26.281779
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.constants as C
    import ansible.module_utils.vars as V
    from ansible.errors import AnsibleActionFail
    action_module = ActionModule(None, None, None, {})
    action_module._task = V.VarsModule('task')
    action_module._task.args = {'a': 'A', 'b': 'B', 'c': 'C'}
    facts = action_module.run({}, None)
    assert facts['ansible_facts'] == {'a': 'A', 'b': 'B', 'c': 'C'}
    assert facts['_ansible_facts_cacheable'] == False

    # try to set invalid variable names
    action_module._task.args = {'1a': 'A', '?': 'B'}

# Generated at 2022-06-21 02:50:27.108316
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 02:50:34.520404
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    spec = {
        'playbook_dir': '..',
        'inventory_dir': '..',
        'groups': {},
        'vars': {},

        'hostvars': {},
        'DEFAULT_HOST_LIST': [],
        'DEFAULT_HOST': '',
        'DEFAULT_SUBSET': '',
        'DEFAULT_SUBSET': '',
        'inventory_basedirs': [],
    }

    action = ActionModule(None)
    action._task = {'args': {'ansible_os_family': 'RedHat'}}


# Generated at 2022-06-21 02:50:35.293465
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:50:38.037941
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.TRANSFERS_FILES == False
    assert callable(ActionModule.run)

# Generated at 2022-06-21 02:50:44.975834
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: fix this test
    pass
    #from ansible.plugins.action.set_fact import ActionModule
    #from ansible.utils.vars import combine_vars
    #from ansible.utils.vars import isidentifier
    #
    #from ansible.module_utils.basic import AnsibleModule
    ##from ansible.module_utils.parsing.convert_bool import boolean
    #
    #from ansible.module_utils.six import string_types
    #
    #from ansible.playbook.task_include import TaskInclude
    #from ansible.playbook.play_context import PlayContext
    #from ansible.playbook.play import Play

    # FIXME: this test does not work, see https://github.com/ansible/ansible/pull/24410#issuecomment

# Generated at 2022-06-21 02:50:48.595201
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.facts.system.cpu import cpuinfo

    class SystemCpuinfo(cpuinfo):
        def __init__(self):
            pass

    facts = {'system_cpu':SystemCpuinfo}
    action = ActionModule(task=None, connection=None, action_loader=None, play_context=None, new_stdin=None)
    action.facts = facts
    action.run()

# Generated at 2022-06-21 02:50:55.987620
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = dict(
        args=dict(a=1, b=2),
    )
    assert ActionModule.run(task)['ansible_facts'] == dict(a=1, b=2)


# Generated at 2022-06-21 02:51:02.197156
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Note that this mock is actually overkill since we are only using the
    # run method.  However, it is a good start for future tests.

    # mock the _templar object
    templar = MockTempler()

    # mock the _task object
    task = MockTask()
    task.args = dict(one=1, two=2, three=3)

    # mock the action plugin
    action = ActionModule(task, templar)
    result = action.run(None, None)

    assert result["ansible_facts"] == dict(one=1, two=2, three=3)

# Mock class for _templar object

# Generated at 2022-06-21 02:51:14.093779
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict(
            param1=dict(required=True, type='str', default=None),
            param2=dict(required=True, type='str', default=None),
            param3=dict(required=False, type='str', default=None)
        )
    )

    # from ansible.utils.vars import combine_vars
    # task_vars = combine_vars(module.params, self._templar._available_variables)

    action = ActionModule(module.params, module.check_mode, module)
    action._task = dict(args=dict(param3=True))
    action._task_vars = dict()
    result = action.run()


# Generated at 2022-06-21 02:51:23.809156
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Instantiate action class
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    loader = DataLoader()
    play_context = PlayContext()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    task_queue_

# Generated at 2022-06-21 02:51:34.861265
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.modules.system.setup as setup
    import ansible.plugins.action.set_fact as set_fact
    from ansible.playbook.task import Task
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-21 02:51:41.545143
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule(dict(action='SET_FACT', ansible_facts={}, ansible_fqdn='localhost', tags=['test'], tasks=[]), dict(play=dict(name='foo')), '/home/me/ansible')
    result = a.run()
    assert result['failed']
    assert_equal(result['msg'], 'No key/value pairs provided, at least one is required for this action to succeed')


# Generated at 2022-06-21 02:51:53.105221
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    from ansible.executor.task_result import TaskResult

    task_vars = {
        "var1": "value1",
    }

    action = ActionModule()

    # Check run method with empty list
    result = action.run(task_vars=task_vars)
    assert isinstance(result, TaskResult)
    assert result.result.get('changed')
    assert result.result.get('ansible_facts') is None
    assert result.result.get('_ansible_facts_cacheable') is None

    # Check run method with valid key/value pairs
    task_vars = {
        "var1": "value1",
    }
    result = action.run(task_vars=task_vars, tmp='/home/ansible/tmp')

# Generated at 2022-06-21 02:51:55.874568
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert 'ansible_facts' in ActionModule.run(ActionModule('debug'), '', '')

# Generated at 2022-06-21 02:52:04.915919
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create a simple mock task, and mock the AnsibleModule
    import ansible.module_utils.basic
    class AnsibleModuleMock(ansible.module_utils.basic.AnsibleModule):
        def __init__(self, *args, **kwargs):
            super(AnsibleModuleMock, self).__init__(*args, **kwargs)

            self._result = dict(
                ansible_facts=dict(),
            )

    class ActionModuleMock(ActionModule):
        def __init__(self, *args, **kwargs):
            super(ActionModuleMock, self).__init__(*args, **kwargs)

            self._templar = ansible.template.Templar()


# Generated at 2022-06-21 02:52:15.003942
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import collections
    import ansible.modules.system.setup

    # declaring ActionModule class and initialize its _task variable
    a = ActionModule()
    a._task = collections.namedtuple("test_setup", [])
    a._task.args = {}
    a._task.args['cacheable'] = False
    a._task.args['var1'] = 'redhat'
    a._task.args['var2'] = 'oracle'
    a._task.args['var3'] = 'microsoft'

    # declaring and initialize TaskVars class
    task_vars = collections.namedtuple("test_setup", [])
    task_vars.ansible_version = {}
    task_vars.ansible_version['full'] = '2.7.0'

    # execute run method of class ActionModule

# Generated at 2022-06-21 02:52:24.098193
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(None, None)

# Generated at 2022-06-21 02:52:25.994642
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    # Test for method run will be here later

# Generated at 2022-06-21 02:52:30.645853
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert 'cacheable' == module.get_default_vars('cacheable')

# Generated at 2022-06-21 02:52:42.604330
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule()
    mod._templar = DictTemplar()
    task = DictObj(dict(args=dict(k1='u1', k2='u2')))

    result = mod.run(task_vars=dict())
    assert isinstance(result, dict)
    assert 'ansible_facts' in result
    assert '_ansible_facts_cacheable' in result
    assert isinstance(result['ansible_facts'], dict)
    assert not result['_ansible_facts_cacheable']
    assert len(result['ansible_facts'].keys()) == 2
    assert result['ansible_facts']['k1'] == 'u1'
    assert result['ansible_facts']['k2'] == 'u2'


# Generated at 2022-06-21 02:52:51.876499
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create dummy action_module class
    class Dummy:
        def __init__(self):
            pass
    am = Dummy()
    am.task_vars = dict()
    am._ds = dict()
    am._ds['_ansible_facts_cacheable'] = True

    # Check if facts cacheable is set correctly
    am._ds['ansible_facts'] = dict()
    assert am._ds['ansible_facts'] == dict()
    assert am._ds['_ansible_facts_cacheable'] is True

# Generated at 2022-06-21 02:53:00.669629
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(task=dict(action=dict(module_name='set_fact'), args=dict(my_var='my_value')), connection=dict(host='127.0.0.1'), task_vars={})
    action.run(tmp=None, task_vars={}) == dict(ansible_facts=dict(my_var='my_value'))



# Generated at 2022-06-21 02:53:03.179753
# Unit test for constructor of class ActionModule
def test_ActionModule():
    facts = ActionModule(dict(ansible_facts=dict(a=1, b=2)), dict())
    assert type(facts) == ActionModule

# Generated at 2022-06-21 02:53:12.916061
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.set_fact import ActionModule as am
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.six import BytesIO
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    class TestTask():
        @classmethod
        def load(cls, ds):
            pass
        def __init__(self, *args, **kwargs):
            self.args = {}
        def _get_loop_items(self):
            return None

    class TestModule():
        def __init__(self, *args, **kwargs):
            self.result = {}
            self.params = {}
            self.async_sleep = 5
        def run(self, *args, **kwargs):
            pass

# Generated at 2022-06-21 02:53:24.004254
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {}
    tmp = None

    #create instance of ActionModule
    action_module = ActionModule(None, None, task_vars=task_vars)

    # create a valid task arguments
    task_args = {'foo': 'bar'}
    action_module._task.args = task_args

    # method run of class ActionModule should return a valid AnsibleResult
    valid_ansible_result = action_module.run(tmp=tmp, task_vars=task_vars)
    assert isinstance(valid_ansible_result, dict)

    # create an invalid task arguments
    task_args = {}
    action_module._task.args = task_args

    # method run of class ActionModule should raise a AnsibleActionFail exception

# Generated at 2022-06-21 02:53:25.087214
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(None, None, None, {}), ActionModule)

# Generated at 2022-06-21 02:53:52.388311
# Unit test for constructor of class ActionModule
def test_ActionModule():

    class MockTemplate:
        def __init__(self):
            self.template = ""

        def template(self, value):
            self.template = value
            return value

    class MockTask:
        def __init__(self):
            self.args = {}
            self.no_log = False

    class MockPlayContext:
        def __init__(self):
            self.network_os = ''

    module = ActionModule()

    templar = MockTemplate()
    module._templar = templar
    task = MockTask()
    module._task = task
    module._play_context = MockPlayContext()

    # test with no key-value pairs provided

# Generated at 2022-06-21 02:53:54.175087
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Just to test if class is accessible
    object = ActionModule()
    pass

# Generated at 2022-06-21 02:53:59.001950
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_loader = 'test'
    mock_task = 'test'
    mock_connection = 'test'
    mock_play_context = 'test'
    mock_shared_loader_obj = 'test'

    a = ActionModule(mock_loader, mock_task, mock_connection, mock_play_context, mock_shared_loader_obj)
    assert type(a) == ActionModule

# Generated at 2022-06-21 02:54:08.059256
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def side_effect(self, tmp=None, task_vars=None):
        assert self._task.args == {'test1': 'test'}
        return 0
    # set up the mocks
    mocked_self = Mock()
    mocked_self._templar = Mock()
    mocked_self._task = Mock()
    mocked_self._task.args = {'test1': 'test'}
    mocked_self.run = Mock(side_effect=side_effect)

    # call the run() method
    ActionModule().run('tmp', 'task_vars')

# Generated at 2022-06-21 02:54:20.597208
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a temp action plugin
    module_name = 'test_action_plugin'
    plugin = type(
        'ActionModule',
        (ActionModule,),
        {'run': lambda s, t: {'ansible_facts': s._task.args, '_ansible_facts_cacheable': False}}
    )
    C.action_loader.add(module_name, plugin())

    # Test
    loader, inventory, variable_manager = C.loader, C.inventory, C.variable_manager
    variable_manager.set_inventory(inventory)
    task = C.Task.load(dict(action=dict(module=module_name, args=dict(first='one', second='two'))), loader=loader)
    result = task.execute(variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-21 02:54:28.460588
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    import json
    import unittest
    import __builtin__
    import copy
    import ast
    import time

    import ansible
    from ansible.constants import DEFAULT_HASH_BEHAVIOUR
    from ansible import errors
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.six import iteritems, string_types
    from ansible.utils.vars import isidentifier

    from ansible.module_utils.parsing.convert_bool import boolean, boolean_or_string
    from ansible.plugins.action import ActionBase
    from ansible.utils.unicode import to_unicode

    # the unit tests, need to be able to set the task_vars

# Generated at 2022-06-21 02:54:35.540212
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext

    action_module_class = ActionModule(
        {'play': {'playbook': [], 'play_no': 1}},
        PlayContext(play_context={'play': {'playbook': [], 'play_no': 1}})
    )

# Generated at 2022-06-21 02:54:42.561290
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule for testing purpose
    obj_ActionModule = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # As ActionModule.run() is a method with parameter,
    # need to create some mock data to call the method under test.
    # The mock data is a dictionary with following keys:
    #     tmp:
    #     task_vars:
    #     result :
    #     cacheable:
    mock_data = {}
    mock_data['task_vars'] = None
    mock_data['tmp'] = None
    mock_data['result'] = {}
    mock_data['cacheable'] = False

    # call the run method of class ActionModule

# Generated at 2022-06-21 02:54:51.311174
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.utils.vars import AnsibleVars

    module_args_sentinel = 'module_arguments'
    action_plugins_sentinel = 'action_plugins'
    module_utils_sentinel = 'module_utils'
    task_vars_sentinel = 'task_vars'
    connection_info_sentinel = 'connection_info'
    play_context_sentinel = 'play_context'

    # Create instance
    instance = ActionModule(
        action_plugins_sentinel,
        task_vars_sentinel,
        connection_info_sentinel,
        play_context_sentinel,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    # Assert constructor
    assert instance._task is None

# Generated at 2022-06-21 02:54:55.528915
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.set_fact import ActionModule

    # Action module instance
    action_module_instance = ActionModule(task = None, connection = None, play_context = None, loader = None, templar = None, shared_loader_obj = None)

    # Unit test for method run of class ActionModule: 'cacheable' set to False
    result = {'ansible_facts': {'test_variable': 5}, '_ansible_facts_cacheable': False}
    assert result == action_module_instance.run(tmp = None, task_vars = dict(test_variable = 5), cacheable = False)
    assert result == action_module_instance.run(tmp = None, task_vars = dict(test_variable = 5), cacheable = '')

    # Unit test for method run of class ActionModule: '

# Generated at 2022-06-21 02:55:38.693727
# Unit test for method run of class ActionModule
def test_ActionModule_run():
   assert True

# Generated at 2022-06-21 02:55:45.789791
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(ActionBase._connection, ActionBase._play_context, {'a': 1, 'b': 2}, {})
    assert am is not None
    assert am.__class__.__name__ == 'ActionModule'
    assert am._task.args.get('a') == 1
    assert am._task.args.get('b') == 2

# Generated at 2022-06-21 02:55:53.895250
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    import sys
    import textwrap
    import unittest
    from ansible.errors import AnsibleActionFail
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from units.mock.loader import DictDataLoader

    # Python 2.6 doesn't have module `mock`
    from mock import patch

    # FIXME: refactor to use the ansible mock
    class AnsibleModule_Mock:
        def __init__(self):
            self.params = dict()


# Generated at 2022-06-21 02:56:01.484396
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(load_module_spec=False, task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    result = {}
    facts = {
        'a': '1',
        'b': '2',
        'c': '3',
    }

    result = module.run(task_vars=None, tmp=None)
    assert result['failed']

    try:
        result = module.run(task_vars=None, tmp=None, a='1', b='2')
    except Exception as e:
        assert str(e) == 'No key/value pairs provided, at least one is required for this action to succeed'

    

# Generated at 2022-06-21 02:56:11.342011
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(None, None)
    task = {
        'action': {
            '__ansible_module__': 'debug',
            'msg': 'foo'
        },
        'args': {
            'cacheable': 'yes'
        }
    }
    module._task = task
    tmp = None
    task_vars = {
        'ansible_VAR': 'ansible'
    }
    result = module.run(tmp, task_vars)
    assert result['ansible_facts'] == {'ansible_VAR': 'ansible'}
    assert result['_ansible_facts_cacheable']


# Generated at 2022-06-21 02:56:20.522959
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a fake task that would create a variable testvar with value True
    args_dict = {'testvar': 'True'}
    task = get_fake_task(args_dict)

    # Create an ActionModule object (fake_modulemanager) with fake_task
    action_module = ActionModule(task, get_fake_modulemanager())

    # Call method run of ActionModule objects
    result = action_module.run(None, None)
    assert result['ansible_facts']['testvar'] is True

# Dummy Base Class for modulemanager interface

# Generated at 2022-06-21 02:56:27.120065
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, dict(action=dict(module_name='foo', module_args=dict())))
    assert action.name == 'foo'
    assert action.module_name == 'foo'
    assert action.action_args == dict()
    assert action.args == dict()

# Generated at 2022-06-21 02:56:28.426381
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test for run
    pass

# Generated at 2022-06-21 02:56:40.848714
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    class TestTask(object):
        def __init__(self):
            self.args = dict()

    # Test with empty args
    test_task = TestTask()
    test_action_module = ActionModule(test_task, dict())
    try:
        test_action_module.run(None, None)
    except AnsibleActionFail as e:
        assert "No key/value pairs provided, at least one is required for this action to succeed" == str(e)

    # Test when a key does not begin with an alphanumeric or an underscore (_)

# Generated at 2022-06-21 02:56:45.299977
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule(dict(name='test_ActionModule'))
    result = am.run(dict(cacheable=False, foo='bar'), dict())
    assert result.get('ansible_facts').get('foo') == 'bar'

# Generated at 2022-06-21 02:58:24.141421
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_plugin = ActionModule('setup', 'testhost')
    assert action_plugin.name == 'setup'
    assert action_plugin.host == 'testhost'

# Generated at 2022-06-21 02:58:25.545127
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, None)
    assert module

# Generated at 2022-06-21 02:58:33.635637
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test _templar.template method
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    _templar = Templar(loader=loader, variables=variable_manager)

    # create mock task
    import ansible.utils.template as template
    template.get_available_variables = lambda x: list()
    # mock template_uid:
    import ansible.utils.unsafe_proxy

# Generated at 2022-06-21 02:58:38.169003
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-21 02:58:44.319844
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_data = {'aryan': 'hello'}
    action_module = ActionModule(
        task=dict(
            args=test_data,
        ),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    test_result = action_module.run()
    del test_result['ansible_facts']['ansible_local']
    assert test_result == {'changed': False, 'failed': False, 'ansible_facts': {'aryan': 'hello'}}

# Generated at 2022-06-21 02:58:46.981302
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	# insert here the code you want to test
	print("Test 1")
	print("Test 2")

# Generated at 2022-06-21 02:58:47.837662
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 02:58:54.014500
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test when no key/value pairs are passed
    class Task:
        args = {}
    test_obj = ActionModule(Task(), {}, {}, {})
    assert not test_obj.run()

    # Test when dict with one key/value pair with cacheable is passed
    class Task:
        args = {"key": "value", "cacheable": True}

    test_obj = ActionModule(Task(), {}, {}, {})
    assert 'key' in test_obj.run()['ansible_facts']
    assert test_obj.run()['ansible_facts']['key'] == "value"
    assert test_obj.run()["_ansible_facts_cacheable"]

    # Test when dict with one invalid key/value pair with cacheable is passed

# Generated at 2022-06-21 02:58:59.273101
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up arguments used by AnsibleModule
    argument_spec = dict()

# Generated at 2022-06-21 02:59:00.385157
# Unit test for constructor of class ActionModule
def test_ActionModule():
    fixture = {}
    action = ActionModule()
    assert action is not None