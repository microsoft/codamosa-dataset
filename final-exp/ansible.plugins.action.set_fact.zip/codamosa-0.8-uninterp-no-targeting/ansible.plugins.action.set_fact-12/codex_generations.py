

# Generated at 2022-06-21 02:50:04.183624
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    print(action)

# Generated at 2022-06-21 02:50:08.573915
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_loader, mock_templar, mock_shared_loader_obj = ActionBase._pre_normalize_args('', dict())
    a = ActionModule(mock_loader, mock_templar, '', {}, share_loader_obj=mock_shared_loader_obj)
    assert a is not None

# Generated at 2022-06-21 02:50:20.738374
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # initialize
    test_class_instance_ActionModule = ActionModule()

    # checks if action plugin is initialized with expected attributes
    assert test_class_instance_ActionModule.action == 'set_fact'
    assert test_class_instance_ActionModule.action_loader == None
    assert test_class_instance_ActionModule.action_plugins == None
    assert test_class_instance_ActionModule.action_processors == None
    assert test_class_instance_ActionModule.action_queue == None
    assert test_class_instance_ActionModule.action_stash == None
    assert test_class_instance_ActionModule.action_templar == None
    assert test_class_instance_ActionModule.action_wrapper == None
    assert test_class_instance_ActionModule.aliases == None

# Generated at 2022-06-21 02:50:24.765323
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # execute the constructor of our class
    module = ActionModule()
    # this test case is to ensure that the class is constructed correctly
    assert module != None

# Generated at 2022-06-21 02:50:26.752011
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule.TRANSFERS_FILES = False
    assert ActionModule.TRANSFERS_FILES == False

# Generated at 2022-06-21 02:50:35.738080
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Testing empty task_vars
    task_vars = {}

    # Testing empty tmp
    tmp = None

    # Testing empty args
    args = {}

    action_module = ActionModule(None, None, task_vars, tmp, args)
    assert action_module is not None

    # Testing args
    args = {
        'test_key1': 'test_value1',
        'test_key2': 'test_value2'
    }
    action_module = ActionModule(None, None, task_vars, tmp, args)
    assert action_module is not None

    # Testing args with invalid key

# Generated at 2022-06-21 02:50:36.333914
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 02:50:44.301406
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # This is a stub to do automated testing of your module. Replace all of
    # this code with real tests and remove these lines.
    module = ActionModule({
        'ANSIBLE_MODULE_ARGS': {
            "cacheable": "True",
            "welcome": "hello world",
            "pi": 3.14159265359,
            "list_type": ["somelist", "in", "a", "list"],
            "dict_type": {"some": "dict", "with": ["keys", "in"]},
        },
    }, {})

    assert module.__class__.__name__ == 'ActionModule'


# Generated at 2022-06-21 02:50:54.888122
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(task=DummyTask(), connection=DummyConnection(), play_context=DummyPlayContext(), loader=DummyLoader(), templar=DummyTemplar(), shared_loader_obj=None)
    assert module.run(task_vars={'some_key':'some_value'}) == {'ansible_facts':{},'_ansible_facts_cacheable':False}
    assert module.run(task_vars={'some_key':'some_value'}, tmp='/tmp/tmp1') == {'ansible_facts':{},'_ansible_facts_cacheable':False}


# Generated at 2022-06-21 02:51:02.586688
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    play = Play()
    playcontext = PlayContext()
    playcontext.remote_addr = "test"
    play._play_context = playcontext

    task = Task()
    task._role = None
    task._role_name = None
    task._task_deps = None
    task._block = None
    task._play = play
    task._loader = None
    task._variable_manager = None
    task._parent = None
    task.name = 'action'
    task.args = dict()

    action = ActionModule(task, dict())
    action.run(task_vars = dict())

# Generated at 2022-06-21 02:51:08.449333
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_task = {'args': {'file': 'foo.txt'}}
    x = ActionModule(mock_task, {})
    assert x.TRANSFERS_FILES == False

# Generated at 2022-06-21 02:51:08.980210
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert(module.run())

# Generated at 2022-06-21 02:51:19.879417
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module.task_vars = {'ansible_distribution': 'Ubuntu'}

    module._task.args = {'cacheable': False, 'key': 'value'}
    module._task.env = {}
    module._templar = Templar()

    result = module.run(tmp=None, task_vars=module.task_vars)
    assert 'ansible_facts' in result
    assert result['ansible_facts']['key'] == 'value'
    assert result['ansible_facts']['ansible_distribution'] == 'Ubuntu'


# Generated at 2022-06-21 02:51:33.113388
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit testing for method run of class ActionModule"""
    # ######################
    # Initialize objects
    # from ansible.playbook.task_include import TaskInclude
    # from ansible.vars import VariableManager
    # from ansible.parsing.dataloader import DataLoader
    # from ansible.template import Templar
    # from ansible.inventory import Inventory
    #
    # variable_manager = VariableManager()
    # loader = DataLoader()
    # inventory = Inventory(loader=loader, variable_manager=variable_manager)
    # variable_manager.set_inventory(inventory)
    #
    # task = TaskInclude(
    #     action='set_fact',
    #     args={'a': '123'}
    # )
    #
    # #tqdm.tqdm =

# Generated at 2022-06-21 02:51:39.346740
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule({})
    assert isinstance(m, ActionBase)
    assert m.TRANSFERS_FILES is False

    m = ActionModule({'foo': 'bar'})
    assert m.ACTION_OPTIONS == {'foo': 'bar'}

# Generated at 2022-06-21 02:51:42.224508
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    MOCK_ACTION_MODULE = ActionModule(None, None, None, {})
    MOCK_ACTION_MODULE.run(None, {'ansible_facts': {'test1':'test1', 'test2':'test2'}})



# Generated at 2022-06-21 02:51:43.614450
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, 'run')

# Generated at 2022-06-21 02:51:47.514235
# Unit test for constructor of class ActionModule
def test_ActionModule():
    myActionModule = ActionModule(task='dummy', connection='local', play_context={}, loader=None, templar=None, shared_loader_obj=None)
    assert myActionModule

# Generated at 2022-06-21 02:51:48.114696
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert callable(ActionModule)

# Generated at 2022-06-21 02:51:51.936925
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create an instance of the module
    mod = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=None, templar=dict(), shared_loader_obj=None)
    # compare it to an instance of the actual class
    assert isinstance(mod, ActionModule)

# Generated at 2022-06-21 02:52:01.545216
# Unit test for constructor of class ActionModule
def test_ActionModule():
  a = ActionModule()


# Generated at 2022-06-21 02:52:13.647634
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json
    import pytest
    from ansible.module_utils._text import to_bytes

    module_args = {'cacheable': 'false',
                   'var_name_1': 'test_var_value_1',
                   'var_name_2': 'test_var_value_2',
                   'var_name_3': 'test_var_value_3'}

    fake_task = type('Task', (), {'args': module_args})

    fake_ansible_module = type('AnsibleModule', (), {'exit_json': lambda x: None,
                                                     'fail_json': lambda x, msg: pytest.fail("Task execution failed due to: %s" % msg)})


# Generated at 2022-06-21 02:52:25.379763
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import os

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager._extra_vars = {}
    variable_manager.set_inventory(loader.load_from_file(os.path.join(C.DEFAULT_INVENTORY_PATH, "hosts")))


# Generated at 2022-06-21 02:52:35.440582
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    import ansible.constants as C
    import ansible.utils.vars as ans_vars

    gvars = dict(foo='foo', bar='bar')
    vvars = dict(baz='baz')
    pvars = dict(qux="qux")

    pc = PlayContext()
    pc.remote_user = 'remote_user'
    pc.connection = 'local'
    pc.network_os = 'default'
    pc.port = 0
    pc.become = False
    pc.become_method = 'sudo'
    pc.become_user = 'root'

# Generated at 2022-06-21 02:52:36.264418
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:52:38.767750
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule('test', {}, {})
    assert action_module._templar

# Generated at 2022-06-21 02:52:41.454985
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, {})
    assert isinstance(action, ActionModule)

# Generated at 2022-06-21 02:52:42.207394
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 02:52:53.530886
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(dict(args={'cacheable': 'yes', 'foo': 'bar'}), task=dict(async_val=50, run_once=False, delegate_to='localhost', vars={'foo': 'bar'}))
    assert action.action_args == {'cacheable': 'yes', 'foo': 'bar'}
    assert action.async_val == 50
    assert action.run_once is False
    assert action.delegate_to == 'localhost'
    assert action.task_vars == {'foo': 'bar'}

# Generated at 2022-06-21 02:53:04.984781
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for run method of ActionModule
    """

    mod = ActionModule()

    # Check with one key value pair
    mod.run(task_vars=dict(var2='value2'))

    # Check with multiple key value pair
    mod.run(task_vars=dict(var1='value1', var2='value2'))

    # Check with no key value pair
    mod.run(task_vars=dict())

    # Check with one key value pair and cacheable
    mod.run(task_vars=dict(var2='value2'), cacheable=True)

    # Check with multiple key value pair and cacheable
    mod.run(task_vars=dict(var1='value1', var2='value2'), cacheable=True)

    # Check with no key value pair and cacheable


# Generated at 2022-06-21 02:53:31.987639
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    action.__class__.TRANSFERS_FILES = False
    action._task = {}
    action._task.args = {}
    action._task.args['cacheable'] = False
    action._task.args['ansible_fqdn'] = 'test.example.com'
    action._task.args['ansible_distribution'] = 'Debian'
    action._task.args['ansible_distribution_release'] = "jessie"
    action._task.args['ansible_distribution_version'] = '8.0'
    action._task.args['ansible_distribution_major_version'] = '8'
    action._task.args['ansible_machine'] = 'x86_64'
    action._task.args['ansible_kernel'] = 'Linux'
   

# Generated at 2022-06-21 02:53:41.885858
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils import basic
    from ansible.vars import Manager
    from ansible.plugins.loader import callback_loader

    # Set the module_utils/basic.py MODULE_REQUIRED variable to False
    basic.MODULE_REQUIRED = False
    # Create a callback plugin loader
    cl = callback_loader.CallbackModuleLoader(None, 'random_plugins_path')
    # Add a few callback plugins to the loader
    cl.add("test1", None)
    cl.add("test2", None)
    # Create a Manager
    manager = Manager()
    # Create the set_fact action plugin

# Generated at 2022-06-21 02:53:51.237822
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_mock = ActionModule.run
    module_mock.return_value = dict()
    module_mock.run.return_value = dict()
    args = dict()
    args['test'] = 'test'
    #badargs = dict()
    #badargs['test_1'] = 'test_1'
    task_mock = dict()
    task_mock['args'] = args
    #task_mock['args'] = badargs
    module_mock.run.return_value = dict()
    print(module_mock.run(args, task_mock))


if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-21 02:54:01.672672
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host = dict()

    module = dict()
    module = dict(name='Test', args=dict())

    task = dict()
    task = dict(action=dict(module='assert_fact'), delegate_to='localhost', register='result', module_name='Test')

    task['action']['args'] = dict()
    task['action']['args'] = dict(one='1')

    t = ActionModule(task, host)
    result = t.run(module_name='Test', tmp='', task_vars=dict())
    assert result['ansible_facts']['one'] == '1'
    assert result['_ansible_facts_cacheable'] == False

    task['action']['args'] = dict(one='1', two='2')
    t = ActionModule(task, host)
    result = t

# Generated at 2022-06-21 02:54:11.314200
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Test with valid facts
    category = 'network'
    facts = {'ip4_address': '10.0.0.1'}
    tmp = None
    task_vars = None
    result = {'changed': False, 'ansible_facts': facts}
    cacheable = True
    assert(module.run(tmp=tmp, task_vars=task_vars) == result)

    # Test with one empty fact
    category = None
    facts = {'ip4_address': '10.0.0.1', 'ip6_address': ''}
    tmp = None
    task_vars = None

# Generated at 2022-06-21 02:54:22.274970
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import ansible.constants as C

    # Mock class
    class MockActionModule:
        def __init__(self, tmp, task_vars):
            self.tmp = tmp
            self.task_vars = task_vars

    # Mock class
    class MockActionBase:
        def __init__(self, tmp, task_vars):
            self._task = MockActionModule(tmp, task_vars)

        def run(self, tmp, task_vars):
            return task_vars

    # Test with parameters
    task_vars = {'foo': 'bar'}
    tmp = 'test'
    task = MockActionBase(tmp, task_vars)
    task.args = {'key': 'value'}

# Generated at 2022-06-21 02:54:23.332869
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:54:27.807429
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Dummy object
    class X(object):
        pass
    # Dummy variable for initializing object of class ActionModule
    x = X()
    x.module_name = 'test'
    # Test object of class ActionModule
    action_module = ActionModule(x, {})
    assert action_module._task.action == 'test'
    assert action_module.name == 'test'

# Generated at 2022-06-21 02:54:30.808745
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test Name
    assert(ActionModule.__name__ == 'ActionModule')


# Generated at 2022-06-21 02:54:33.409299
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None)
    assert action is not None

# Generated at 2022-06-21 02:55:23.539274
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts import Facts
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.copy import ActionModule as copyActionModule
    from ansible.plugins.action.facts import ActionModule as factsActionModule

    # Create a fake AnsibleModule object
    module = AnsibleModule(argument_spec=dict(test=dict(required=True, type='str')), supports_check_mode=True)

    # Create a fake AnsibleModule object with facts
    factsModule = AnsibleModule(
        argument_spec={
            'gather_subset': {'default': [], 'type': 'list', 'aliases': ['subset']},
            'gather_timeout': {'default': 10, 'type': 'int'}
        },
        supports_check_mode=True
    )



# Generated at 2022-06-21 02:55:24.134456
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, dict(), dict())

# Generated at 2022-06-21 02:55:26.501236
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(dict(), dict())
    assert isinstance(action, ActionBase)

# Generated at 2022-06-21 02:55:27.965382
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, {})

# Generated at 2022-06-21 02:55:35.138965
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook import Play


# Generated at 2022-06-21 02:55:38.150744
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = {}
    task.update({'args': {'matrix': {'service': ['a', 'b', 'c']}}})
    tmplar = {}
    tmp = None
    task_vars = {}
    actm = ActionModule(task, tmplar, tmp, task_vars)
    assert actm.run(tmp, task_vars) == {'ansible_facts': {'matrix': {'service': ['a', 'b', 'c']}}, '_ansible_facts_cacheable': False}

# Generated at 2022-06-21 02:55:42.771884
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils._text import to_bytes

    class ActionModuleMock(ActionModule):
        _templar = None

        def run(self, tmp=None, task_vars=None):
            return super(ActionModuleMock, self).run(tmp, task_vars)

        def _templar_compile(self, value):
            return value

        def _templar_template(self, value):
            return value

        def get_task_vars(self):
            return {}

    class AnsibleModuleMock:
        def __init__(self, **kwargs):
            self.params = kwargs

    class AnsibleTaskMock:
        def __init__(self, **kwargs):
            self.args = kwargs


# Generated at 2022-06-21 02:55:52.870606
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' test_ActionModule_run
        test method run of class ActionModule
    '''
    print('test_ActionModule_run')
    print()

    import os, sys

    sys.stdout = write = open('test_ActionModule_run.log', 'w')

    # test method run of class ActionModule

    # TestCase: no given key/value pairs

    print()
    print()
    print('TestCase: no given key/value pairs')
    print('----------------------------------')
    print()

    # create ansible task
    import json


# Generated at 2022-06-21 02:55:55.754347
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
         # test for missing/unexpected arguments
        my_test = ActionModule({'a': 1})
        assert False , 'expected error'
    except:
        assert True
    try:
        # test for missing/unexpected arguments
        my_test = ActionModule({'a': 1}, {'b': 2})
        assert False , 'expected error'
    except:
        assert True

# Generated at 2022-06-21 02:56:02.496399
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.utils.template as template
    import ansible.utils.vars as vars

    runner_args = {}

    ################################################################################
    #
    # Test case no. 1: no key/value pairs provided, action must fail
    #
    ################################################################################

    runner_obj = RunnerMock(runner_args, FAILED, 'No key/value pairs provided, at least one is required for this action to succeed')

    action_obj = ActionModule(runner_obj)
    result = action_obj.run(task_vars={})

    assert action_obj._templar is not None
    assert action_obj._task.args == {}
    assert result['failed']
    assert result['msg'] == 'No key/value pairs provided, at least one is required for this action to succeed'

    #

# Generated at 2022-06-21 02:57:31.420761
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils import basic
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins import module_loader
    import os
    import sys

    module_loader.add_directory(os.path.join(os.path.dirname(__file__), '../../../lib/ansible/modules/extras'))

    global_args = dict(
        connection='local',
        run_once=True,
    )

    task_args = dict(
        ansible_python_interpreter='/usr/bin/env python',
        # cacheable=True,
        debug=True
    )

    defaults = dict(
        ansible_python_interpreter='/usr/bin/env python',
    )

    kwargs = global_args.copy()
    kw

# Generated at 2022-06-21 02:57:38.520815
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(action=dict(module_name='new_module', args=dict(k1='val1'))),
        connection=dict(),
        play_context=dict(remote_addr='127.0.0.1', port=22),
        loader=None,
        templar=None,
        shared_loader_obj=None)

    assert action_module is not None

# Generated at 2022-06-21 02:57:39.387730
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule('setup', {}) is not None

# Generated at 2022-06-21 02:57:42.491046
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None)
    assert action_module != None

# Generated at 2022-06-21 02:57:48.133500
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    plugin = ActionModule(dict(task=dict(args=dict(test="test"))))
    result = plugin.run(task_vars=dict())
    assert result['ansible_facts']['test'] == "test"


# Generated at 2022-06-21 02:57:51.727063
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Unit test for constructor of ActionModule
    """
    am = ActionModule(None, None, None, None)
    assert am._play_context is None
    assert am._task is None
    assert am._loader is None
    assert am._templar is None

# Generated at 2022-06-21 02:57:55.970335
# Unit test for constructor of class ActionModule
def test_ActionModule():

    try:
        test_ActionModule.action_module = ActionModule(dict(), {}, {})
    except Exception as e:
        print(e)
        test_ActionModule.action_module = None

    assert test_ActionModule.action_module is not None

# Generated at 2022-06-21 02:57:56.858491
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #TODO
    pass

# Generated at 2022-06-21 02:57:59.269984
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert a is not None


# Generated at 2022-06-21 02:58:02.365064
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule(None, None, None, {})
    assert isinstance(x._templar, object)