

# Generated at 2022-06-21 02:50:04.256443
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: write this unit test
    pass

# Generated at 2022-06-21 02:50:05.646724
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict()) is not None

# Generated at 2022-06-21 02:50:16.800972
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test constructor with args and no kwargs
    my_obj = ActionModule(1, 2, 3)
    # Check that the object is of the right class
    assert(isinstance(my_obj, ActionModule))
    # Check that the correct object attributes are set
    assert(my_obj._task == 1)
    assert(my_obj._connection == 2)
    assert(my_obj._play_context == 3)
    # Test constructor with args and kwargs
    my_obj = ActionModule(4, 5, 6, a=7, b=8, c=9)
    # Check that the object is of the right class
    assert(isinstance(my_obj, ActionModule))
    # Check that the correct object attributes are set
    assert(my_obj._task == 4)

# Generated at 2022-06-21 02:50:26.716654
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import mock
    import sys
    from ansible.module_utils._text import to_bytes
    from ansible.playbook import Playbook
    from ansible.plugins.action import ActionModule

    # Create the action base class
    action_base = ActionModule(
        task=mock.Mock(),
        connection=mock.Mock(),
        play_context=mock.Mock(),
        loader=mock.Mock(),
        templar=mock.Mock(),
        shared_loader_obj=None
    )

    # Create the action module instance

# Generated at 2022-06-21 02:50:35.703451
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 02:50:40.636692
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = dict(action=dict(module="setup", args=dict(filter="ansible_eth*", ansible_distribution='Fedora')))
    am = ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    am.run(tmp=None, task_vars=None)
    print(str(am))

# Generated at 2022-06-21 02:50:43.076434
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert (action_module is not None)

# Generated at 2022-06-21 02:50:47.683400
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    import pytest
    from ansible.executor.task_queue_manager import TaskQueueManager    
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager.extra_vars = combine_vars(loader=loader, variables=['ansible_distribution_version=7.0', 'ansible_distribution=CentOS'])


# Generated at 2022-06-21 02:50:58.456081
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Testing method run of class ActionModule...")
    task_vars = { 'ansible_check_mode':False, 'ansible_verbosity':0 }
    mock_task = {'async':0,'args':{'cacheable':False, 'var_name':"hello"}}
    mock_self = {'_task':mock_task, '_templar':None}
    result = ActionModule.run(mock_self,None,task_vars)
    print("method run of class ActionModule returned: " + str(result))
    if result == {'ansible_facts': {'var_name': 'hello'}, '_ansible_facts_cacheable': False, '_ansible_no_log': False}:
        print("method run of class ActionModule passed unit test")
    else:
        print

# Generated at 2022-06-21 02:51:01.068973
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test for actionmodule constructor
    am = ActionModule(None, None, None, None)
    assert am.TRANSFERS_FILES == False

# Generated at 2022-06-21 02:51:12.281873
# Unit test for constructor of class ActionModule
def test_ActionModule():
        action_module = ActionModule(
            task=dict(action=dict(module_name='set_fact', args=dict(a='a',
                b='b'))),
            connection=None,
            play_context=None,
            loader=None,
            templar=None,
            shared_loader_obj=None
        )
        assert isinstance(action_module, ActionModule)

# Generated at 2022-06-21 02:51:23.196472
# Unit test for constructor of class ActionModule
def test_ActionModule():
    inp = dict(
        action=dict(module_name="debug", args=dict(msg="Hi")),
        host=dict(name="localhost"),
        play_context=dict(
            port=None,
            remote_addr=None,
            remote_user=None,
            password=None,
            private_key_file=None,
            connection="ssh",
        ),
        loader=dict(),
        _ansible_selinux_special_fs=None,
        _ansible_keep_remote_files=False,
        _ansible_no_log=False,
    )
    am = ActionModule(inp, task_vars=dict())
    print(am)
    assert am is not None
    return am

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-21 02:51:30.561224
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Testing ActionModule.run() ...')
    action = ActionModule()
    tmp = None
    task_vars = dict()
    result = action.run(tmp, task_vars)
    assert isinstance(result, dict)
    assert 'ansible_facts' in result
    assert '_ansible_facts_cacheable' in result
    print('ActionModule.run() works')

# Generated at 2022-06-21 02:51:42.613107
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Dummy class for testing purposes
    class DummyClass(object):
        def __init__(self):
            self._templar = None
            self._task = None

    obj = DummyClass()
    obj.action_plugins = dict()

    # Dummy results
    results = dict()

    # Dummy task
    task = dict()
    task['args'] = dict()

    #############################
    # testing variable creation #
    #############################

    # 1. variable name = valid, variable value = valid
    task['args']['variable_name'] = 'a'
    task['args']['value'] = 1

    result = obj.run(None, None, task, results)
    _vars = result.get('ansible_facts', None)


# Generated at 2022-06-21 02:51:53.425522
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Given
    am = ActionModule()
    class Task():
        def __init__(self):
            self.args = {'hello': 'world'}

    class Play():
        def __init__(self):
            self.host_vars = {'ansible_ssh_host': 'localhost'}

    class PlayContext():
        def __init__(self):
            self.play = Play()
            self.connection = 'local'
            self.network_os = ''
            self.remote_addr = '127.0.0.1'
            self.remote_user = 'vagrant'
            self.port = 22
            self.become = True
            self.become_method = 'sudo'
            self.become_user = 'admin'
            self.verbosity = 0

# Generated at 2022-06-21 02:51:54.893566
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()
    am.run()

# Generated at 2022-06-21 02:51:55.704979
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:52:03.908983
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Return values for the mock function
    task_vars = {u'test_key1': u'test_value1'}
    tmp = 'test_tmp'
    args = dict()

    # Instantiate the ActionModule object
    am = ActionModule(None, {})

    # set the return values for the mock function
    am.run = MagicMock(return_value=dict())

    # call run with the required arguments
    am.run(tmp, task_vars)

    # assert that the run() method of ActionModule was called with the required arguments
    am.run.assert_called_with(tmp, task_vars)

# Generated at 2022-06-21 02:52:11.394876
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(task=dict(action=dict(module_name='set_fact', module_args=dict(name='foo', value='bar'))))
    result = module.run()
    assert 'ansible_facts' in result
    assert result['ansible_facts']['name'] == 'foo'
    assert result['ansible_facts']['value'] == 'bar'

# Generated at 2022-06-21 02:52:12.206808
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 02:52:23.541186
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert a

# Generated at 2022-06-21 02:52:34.564115
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class TestVarsModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            super(TestVarsModule, self).run(tmp, task_vars)

            self._task.args['key'] = 'value'
            return super(TestVarsModule, self).run(tmp, task_vars)

    tvm = TestVarsModule('/tmp', '/tmp', {}, [], {})
    tvm._play = Play()
    tvm._play._play_ds = DATA[0]
    tvm._play._play_ds['tasks'][0] = DATA[0]['tasks'][0]
    tvm._task = DATA[0]['tasks'][0]
    tvm._task['task_args'] = {}

# Generated at 2022-06-21 02:52:39.504907
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule(load_module_spec=True, argument_spec={})

    test_args = {'foo': 'Foo', 'bar': 'Bar'}
    test_task_vars = {'ansible_facts': {'foo': 'Foo', 'bar': 'Bar'}, '_ansible_facts_cacheable': False}

    assert mod._templar is None
    assert mod._task.args == test_args

    mod.run(task_vars=test_task_vars)

    assert mod._templar is not None
    assert mod._task.args == test_args

# Generated at 2022-06-21 02:52:42.069442
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test the constructor
    assert ActionModule((0,), {}, {}, {})._module_name == 'set_fact'

# Generated at 2022-06-21 02:52:53.971883
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    class FakeAnsibleTask:
        def __init__(self, args):
            self.args = args

    class FakeAnsiblePlay:
        def __init__(self, vars):
            self.vars = vars

    class FakeAnsibleModule:
        def __init__(self, vars):
            self.params = vars
            self.ansible_version = '2.8.6'

    class FakeAnsibleTemplar:
        def __init__(self):
            self.hostvars = {}

        def template(self, k):
            return k

    class FakeModule:
        def __init__(self, params):
            self.params = params


# Generated at 2022-06-21 02:52:55.897548
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # verify the constructor works without failure
    assert ActionModule(None, None, {})

# Generated at 2022-06-21 02:53:03.813655
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = dict()
    task['args'] = dict()
    task['args']['cacheable'] = False
    task['args']['ans_var'] = 'val'

    tmp = None
    task_vars = dict()

    result = ActionModule("", task, tmp, task_vars).run()
    assert result['ansible_facts'], "ansible facts are missing from the module result"
    assert result['ansible_facts']['ans_var'] == 'val', "ansible facts missing expected value for ans_var"

# Generated at 2022-06-21 02:53:06.153600
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, {}, {}, {}, None)
    assert isinstance(action, ActionBase)

# Generated at 2022-06-21 02:53:09.515124
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module

# Generated at 2022-06-21 02:53:17.440809
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
        Unit test for method run of class ActionModule
    """

    action = ActionModule()
    action._task.args = dict(a=1, b=2)  # .args is in fact a dict
    result = dict(changed=False, _ansible_no_log=False, ansible_facts=dict(a=1, b=2))
    assert action.run() == result

    # Cacheable
    action_cacheable = ActionModule()
    action_cacheable._task.args = dict(a=1, b=2, cacheable=True)
    result_cacheable = dict(changed=False, _ansible_no_log=False, ansible_facts=dict(a=1, b=2), _ansible_facts_cacheable=True)
    assert action_cacheable.run() == result_cacheable

# Generated at 2022-06-21 02:53:42.862714
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.utils.template
    import ansible.vars

    my_playbook = ansible.playbook.play.Play()
    my_task = ansible.playbook.task.Task()
    my_task._role = ansible.playbook.role.Role()

    my_task.action = 'set_fact'
    my_task.args = {}

    module = ActionModule(my_task, my_playbook, ansible.utils.template.Templar(loader=None, variables=ansible.vars.VariableManager()))
    assert isinstance(module, ActionModule)


# Generated at 2022-06-21 02:53:44.462575
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' Unit test for method run of class ActionModule '''
    print('TODO: Unit test for method run of class ActionModule')

# Generated at 2022-06-21 02:53:47.727187
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.parsing.dataloader
    module = ActionModule(
          Task(Task())
        , DataLoader(ansible.parsing.dataloader.DataLoader())
        , TaskExecutor()
    )

    assert module is not None

# Generated at 2022-06-21 02:53:48.232907
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    asse

# Generated at 2022-06-21 02:53:59.129400
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import copy

    try:
        # python36
        from unittest.mock import patch
    except ImportError:
        # python2 and python3.4-
        from mock import patch

    assert hasattr(ActionModule, 'run')
    assert callable(ActionModule.run)

    # test run without parametes
    action = ActionModule(None,)
    with pytest.raises(AnsibleActionFail) as e:
        action.run(None, None)
    assert 'No key/value pairs provided' in str(e.value)

    # test run with invalid variables
    action = ActionModule(None, args={'fact': 'value'})
    with pytest.raises(AnsibleActionFail) as e:
        action.run(None, None)

# Generated at 2022-06-21 02:54:10.175912
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.template import Templar

    module = AnsibleModule(
        argument_spec = dict(
            fact1 = dict(required=True),
            fact2 = dict(required=True),
            fact3 = dict(required=True),
            fact4 = dict(required=False),
            fact5 = dict(required=False),
        ),
    )

    task = dict(action=dict(module='set_fact', args=dict(fact1='A', fact2='B', fact3='C')))
    play_context = dict()

    mock_module = dict(module_args=module.params)
    mock_module.update(module.args)

# Generated at 2022-06-21 02:54:21.776168
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # setup test module
    module = ActionModule(tmp='/tmp', task_vars=dict())

    # test invalid usage
    module._task = module._load_task_wrapper(dict(action=dict(module='set_fact')))
    try:
        module.run(None, None)
    except AnsibleActionFail as e:
        assert 'No key/value pairs provided, at least one is required for this action to succeed' in str(e)
    else:
        assert False, 'Should have error for no arguments'

    # test key name must be identifier

# Generated at 2022-06-21 02:54:24.703562
# Unit test for constructor of class ActionModule
def test_ActionModule():
	ActionModule("test_name", "test_path", "test_module_args","test_task_vars","test_loader")

# Generated at 2022-06-21 02:54:31.969040
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    This is the test for method action_module.run.
    """
    import ansible.plugins.action.set_fact
    # Create instance of action module
    action_module = ansible.plugins.action.set_fact.ActionModule(None, None)

    # Create mock object for a task
    task = object()
    setattr(task, 'args', {'foo': 'bar', 'baz': 'qux'})

    # Create mock object for tmp
    tmp = "ansible-tmp-123"

    # Create mock object for result
    result = {}

    # Call method run
    action_module.run(tmp, result)

    # Assert if facts are created
    assert result['ansible_facts'] == {
        'foo': 'bar',
        'baz': 'qux'
    }



# Generated at 2022-06-21 02:54:35.085199
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule, object)

# Test for the method run for class ActionModule

# Generated at 2022-06-21 02:55:25.081205
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class TestActionModule(object):
        pass
    class TestAnsibleModule(object):
        def __getattr__(self, name):
            if name in ('warn', 'fail_json'):
                return lambda msg, **kwargs: msg
            raise AttributeError()
    class TestJinja2(object):
        def __getattr__(self, name):
            if name == 'template':
                return lambda arg: arg
            raise AttributeError()
    class TestTask(object):
        def __init__(self):
            self.args = {}
    class TestTaskVars(object):
        pass
    class TestSelf(object):
        @staticmethod
        def run():
            pass

        _task = TestTask()
        _templar = TestJinja2()
    mytest = TestSelf()


# Generated at 2022-06-21 02:55:27.813818
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, "Need a test that verifies a method is called only when the right params are used"

# Generated at 2022-06-21 02:55:39.353303
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task

    class FakeTask(Task):
        def __init__(self, name, task_args):
            self.name = name
            self.args = task_args
            self.module_vars = dict()

    class FakePlayContext():
        def __init__(self):
            self.connection = 'local'
            self.forks = 1

    fake_play_context = FakePlayContext()

    mock_constructor_task_args = dict(
        my_var='foo',
        my_var1='bar'
    )

    AMFake = ActionModule(FakeTask('fake_task', mock_constructor_task_args), fake_play_context, [], mock_constructor_task_args)
    assert AMFake._task.args == mock_constructor_task_args


# Generated at 2022-06-21 02:55:51.692413
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test method run of class ActionModule
    """

    # Create a ActionModule object initialized with the attributes of test_playbook and test_loader
    # as used by ansible-playbook and ansible.parsing.dataloader.DataLoader respectively

    try:
        import ansible.playbook
        import ansible.parsing.dataloader
    except ImportError:
        print("Module ansible not found, module ActionModule not tested")
        return

    # Create a Host object initialized with the attributes of test_host, as used by ansible.executor.task_queue_manager.TaskQueueManager()._initialize_processes()
    test_host = "dummy_host"
    task = ansible.playbook.task.Task()
    loader = ansible.parsing.dataloader.DataLoader

# Generated at 2022-06-21 02:56:02.316380
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook import Play
    from ansible.module_utils.six import StringIO

    from collections import namedtuple
    Options = namedtuple('Options', ['become_user', 'become', 'become_ask_pass', 'remote_user', '_diff'])
    options = Options(become_user='someuser', become=True, become_ask_pass=True, remote_user='someuser', _diff=True)

# Generated at 2022-06-21 02:56:04.864512
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(ActionModule is not None)
    # What is this test testing?

# Generated at 2022-06-21 02:56:08.815070
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(dict(a=1, b=dict(), c=['c']))
    assert am.a == 1
    assert am.b == dict()
    assert am.c == ['c']

# Generated at 2022-06-21 02:56:15.000660
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    task_vars = dict()

    e = {'ansible_facts': dict(), '_ansible_facts_cacheable': False}
    result = dict()

    # test with no variables
    m = ActionModule(dict(), e, result, task_vars)
    with pytest.raises(AnsibleActionFail):
        m.run(tmp=None, task_vars=None)

    # test with no facts
    m = ActionModule(dict(foo=1), e, result, task_vars)
    with pytest.raises(AnsibleActionFail):
        m.run(tmp=None, task_vars=None)

    # test with facts
    m = ActionModule(dict(cacheable=0, foo=1), e, result, task_vars)

# Generated at 2022-06-21 02:56:16.770605
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(dict(), dict())
    assert action_module is not None

# Generated at 2022-06-21 02:56:23.486439
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    from ansible.utils.vars import merge_hash
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.include import Include
    import ansible.inventory.manager
    import ansible.inventory.host
    import ansible.parsing.dataloader
    import ansible.vars.manager

    # test_name=This is a variable name
    # task_args={'key1': {'test_name': 'Value1'}}
    # task_vars={'var1': 'value1'}
    # run_args={'task': {'args': task_

# Generated at 2022-06-21 02:58:00.331389
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    facts = dict(
        apple='fruit',
        banana='fruit',
        cherry='fruit',
        grape='fruit',
    )
    action_module = ActionModule()
    # From the run method above, we can deduce this
    action_module._task_vars = dict()
    action_module._task = dict()
    action_module._task['args'] = dict(
        cacheable='True',
    )
    action_module._task['args'].update(facts)
    action_module._connection = 'local'
    action_module.runner_support_interface_copy = dict()
    action_module._templar = AnsibleMock()
    result = action_module.run(tmp=dict(), task_vars=dict())
    assert result == dict(
        ansible_facts=facts,
    )



# Generated at 2022-06-21 02:58:10.841992
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.modules.test.test_module import ActionModule as TestActionModule
    from ansible.template import Templar

    class ActionModule(TestActionModule):

        def run(self, tmp=None, task_vars=None):
            return TestActionModule.run(self, tmp, task_vars)

        def get_action_args(self):
            return TestActionModule.get_action_args(self)

        def get_action_args_with_templating(self):
            return TestActionModule.get_action_args_with_templating(self)

        @staticmethod
        def _templar():
            return Templar(loader=None)

    # Test 1
    # args:
    #   cacheable: yes
    # k=v pairs:
    #   - var_name: var_value


# Generated at 2022-06-21 02:58:14.070168
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Initialize the test class
    action = ActionModule()
    # assert the class
    assert action.TRANSFERS_FILES == False

# Generated at 2022-06-21 02:58:23.477472
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.compat.tests import unittest
    from ansible.plugins.action.set_fact import ActionModule

    class ActionModuleTestCase(unittest.TestCase):

        class AnsibleAction(object):
            def __init__(self, task_args=None, task_vars=None):
                if task_args is None:
                    task_args = dict()
                self.args = task_args

        def test_action_module_run(self):
            ''' verify that name=value,name=value,... returns a correctly populated facts dict '''
            task_args = dict(key1=dict(test=True))
            task = self.AnsibleAction(task_args=task_args)
            am = ActionModule(task, dict())
            result = am.run(task_vars=dict())


# Generated at 2022-06-21 02:58:27.230643
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert a is not None

# Generated at 2022-06-21 02:58:28.630846
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Should not throw an error
    ActionModule(None)

# Generated at 2022-06-21 02:58:30.115158
# Unit test for constructor of class ActionModule
def test_ActionModule():
    act_mod = ActionModule()
    assert type(act_mod) is ActionModule

# Generated at 2022-06-21 02:58:31.538612
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:58:42.492737
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    action._task_vars = {}
    action._templar = {}
    action._task = {}
    action._task.args = {}
    action._task.args['cacheable'] = False
    action._task.args['os'] = 'Linux'
    action._task.args['distribution'] = 'Centos'
    action._task.args['distribution_version'] = '7.5'
    result = action.run()
    assert result == {
        'ansible_facts': {
            'os': 'Linux',
            'distribution': 'Centos',
            'distribution_version': '7.5'
        },
        '_ansible_facts_cacheable': False
    }

# Generated at 2022-06-21 02:58:43.823397
# Unit test for constructor of class ActionModule
def test_ActionModule():
  am = ActionModule()
  assert(am)