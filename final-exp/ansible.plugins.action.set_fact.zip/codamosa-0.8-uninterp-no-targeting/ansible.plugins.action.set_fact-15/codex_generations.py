

# Generated at 2022-06-21 02:50:05.017898
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from unittest.mock import Mock
    from ansible.vars import VariableManager
    from ansible.plugins.strategy import ActionModule
    from ansible.template import Templar
    from test.units.compat import unittest

    fake_variable_manager = Mock()
    fake_task = Mock()
    fake_task._compute_environment_string = lambda: ''
    fake_play_context = Mock()

    fake_variable_manager.get_vars = lambda _, play=None: {}
    fake_variable_manager.extra_vars = {'ansible_facts': {'test': 'test'}}
    fake_task.action = 'setup'
    fake_task.args = {'fact1': 'value1', '_fact2': 'value2'}


# Generated at 2022-06-21 02:50:11.936011
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task

    my_var = dict(proxy=dict(http='foo.example.com:8080'), path='/tmp', bulk_files=True)
    task = Task()
    task._ds = task._entries = my_var
    am = ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am

# Generated at 2022-06-21 02:50:20.320699
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import copy
    import json
    import os
    import os.path
    import sys
    sys.path.append(os.path.abspath(os.path.join(__file__,'..','..','..','lib')))
    from ansible.compat.tests.mock import patch
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean

    facts = {}

# Generated at 2022-06-21 02:50:32.607729
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.inventory import Host, Inventory
    from ansible.playbook import Play
    from ansible.playbook.play import PlayContext
    from ansible.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    # preprare a fake host/inventory
    fake_host = Host("fake_hostname")
    fake_inventory = Inventory("localhost,")
    fake_inventory._hosts = "localhost,"
    fake_inventory.get_host = lambda host: fake_host
    fake_inventory.add_host(fake_host, "localhost")
    fake_inventory._is_safe_attr = lambda a: True

    # prepare a fake play/task/action

# Generated at 2022-06-21 02:50:42.710020
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # mock variables
    module = '/home/vagrant/ansible/lib/ansible/modules/commands/command.py'

# Generated at 2022-06-21 02:50:54.190205
# Unit test for constructor of class ActionModule
def test_ActionModule():
    at = ActionModule('a', 'b', 'c', 'd', task_vars={'a':'b', 'c':'d'})
    assert at.name == 'a'
    assert at.runner_type == 'b'
    assert at.action == 'c'
    assert at.task == 'd'
    assert at._task.args == {}

    at = ActionModule('a', 'b', 'c', 'd', task_vars={'a':'b', 'c':'d'}, tmp_path='test')
    assert at.name == 'a'
    assert at.runner_type == 'b'
    assert at.action == 'c'
    assert at.task == 'd'
    assert at._task.args == {}
    assert at.tmp_path == 'test'

# Generated at 2022-06-21 02:50:55.898115
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert len(ActionModule.__doc__) > 0

# Generated at 2022-06-21 02:51:05.872748
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 02:51:08.078771
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, {}) is not None

# Generated at 2022-06-21 02:51:10.240226
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("In test_ActionModule_run")
    # TODO
    #assert False



# Generated at 2022-06-21 02:51:22.593580
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.callback import CallbackBase
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    import ansible.constants as C
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_path_exists

    class TestCallbackModule(CallbackBase):
        pass

    C.HOST_KEY_CHECKING = False

    results = []
    task_results = []


# Generated at 2022-06-21 02:51:34.425500
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.constants as C
    import logging
    import sys
    import unittest

    # Log errors to stderr
    logging.basicConfig(stream=sys.stderr)

    # If a test fails, raise an exception instead of exiting with a return code
    unittest.TestCase.failureException = AssertionError

    # The test
    class Test(unittest.TestCase):
        def test_ActionModule_run(self):
            # Create class instance
            action_module = ActionModule()
            # Create a result
            result = {}
            # Create a task with arguments
            task = {'args': {'test': 'value'}}
            # Execute method run
            action_module.run(result=result, task_vars={}, task=task)
            # Check result

# Generated at 2022-06-21 02:51:44.834011
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # an instance of ActionModule
    import ansible.parsing.dataloader
    import ansible.playbook.task
    import ansible.vars.manager
    import ansible.inventory.manager

    loader = ansible.parsing.dataloader.DataLoader()
    tqm = None
    variables = ansible.vars.manager.VariableManager(loader=loader)
    inventory = ansible.inventory.manager.InventoryManager(loader=loader, sources='localhost,')
    variable_manager = ansible.vars.manager.VariableManager(loader=loader, inventory=inventory)

    task = ansible.playbook.task.Task()
    task._role = None

# Generated at 2022-06-21 02:51:48.535025
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=dict(), connection=None,
                        play_context=None, loader=None, templar=None,
                        shared_loader_obj=None)

# Generated at 2022-06-21 02:51:55.815907
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule

    am = ActionModule()

    # test successful run
    res = am.run(None, {"ansible_inventory_sources": ["test_playbook.yml"]})
    assert res['ansible_facts'] == dict()
    assert res['_ansible_facts_cacheable'] is False
    assert res['changed'] is False

    # test failed run
    try:
        am.run(None, {"ansible_inventory_sources": ["test_playbook.yml"]}, dict(), {"ansible_facts": {}, "ansible_fact": {}})
        assert False
    except Exception as ex:
        assert str(ex) == "No key/value pairs provided, at least one is required for this action to succeed"

    # test failed run

# Generated at 2022-06-21 02:52:04.896222
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    facts = {}
    result = ActionModule.run(facts)
    assert(result['_ansible_verbose_always'])
    assert('Unable to create any variables with provided arguments' in result['_ansible_verbose_override'])
    assert('failed' in result['_ansible_verbose_override'])
    assert(result['failed'])

    facts = { 'x': 'y' }
    result = ActionModule.run(facts)
    assert(result['_ansible_verbose_always'])
    assert('The variable name \'x\' is not valid. Variables must start with a letter or underscore character, '
           'and contain only letters, numbers and underscores.' in result['_ansible_verbose_override'])
    assert('failed' in result['_ansible_verbose_override'])

# Generated at 2022-06-21 02:52:15.003991
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action1 = dict(name='test_action1', key1='value1')
    action2 = dict(name='test_action2', key1='value1', key2=2)
    action3 = dict(name='test_action3', key1=dict(key2=dict(key3='value3')))
    action4 = dict(name='test_action4', key1='true', cacheable=True)

    action_module = ActionModule(action1, task_vars={})
    assert action_module.run() == dict(ansible_facts=dict(key1='value1'), _ansible_facts_cacheable=False)

    action_module = ActionModule(action2, task_vars={})

# Generated at 2022-06-21 02:52:20.221807
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = {
        'ansible_facts': None,
        '_ansible_facts_cacheable': None,
        '_ansible_no_log': False,
        '_ansible_parsed': None,
        '_ansible_selinux_special_fs': None,
        '_ansible_shell_executable': None,
        '_ansible_socket': None,
        '_ansible_string_conversion_action': None,
        '_ansible_verbose_always': False,
        '_ansible_version': None,
        '_ansible_version_added_features': None,
    }

    action_module = ActionModule(task={'args': {'my_var': 'cool', 'cacheable': False}})
    # cached_facts is an empty dict
    assert action

# Generated at 2022-06-21 02:52:32.442266
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.playbook
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.script import InventoryScript
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader

    loader = ansible.cli.CLI.load_file

    # Create a temporary file with some data to be loaded as a task
    test_file1 = open('test_file1', 'w')
    test_file1.write('---\n- name: test_action\n  action: set_fact x=abc a=b')
    test_file1.close()

# Generated at 2022-06-21 02:52:35.274233
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule(None, None, None)
    assert type(mod).__name__ == 'ActionModule'

# Generated at 2022-06-21 02:52:51.679179
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class mock_task():
        args = {}

    class mock_templar():
        def template(x):
            return x

    # Test no arguments
    action_module = ActionModule(mock_task, mock_templar)
    action_module.run()

    # Test args
    mock_task.args = {'arg1': 'test'}
    action_module = ActionModule(mock_task, mock_templar)
    action_module.run()

# Generated at 2022-06-21 02:52:53.453545
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:53:04.929300
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.parsing.convert_bool import BOOLEANS
    from ansible.executor.task_result import TaskResult

    class MockModule(object):
        def __init__(self):
            self.params = {}

    class MockTask(object):
        def __init__(self):
            self.action = 'setup'
            self.args = {'cacheable': False}
            self._ds = {'argspec': None}
            self.async_val = 0
            self.transport = 'ssh'
            self.become = False
            self.become_user = None
            self.no_log = False
            self.runner_on_skipped = Mock()
            self.runner_on_failed = Mock()
            self.runner_on_ok = Mock()
           

# Generated at 2022-06-21 02:53:10.089174
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.loader
    am = ansible.plugins.loader.action_loader.get('set_fact', class_only=True)
    assert am is not None
    s = ActionModule(None, {}, {}, None, None)
    assert s is not None and s.name == 'set_fact'

# Generated at 2022-06-21 02:53:11.308483
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, {}, None, None)

# Generated at 2022-06-21 02:53:24.003079
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up
    module = ActionModule()
    module._templar = AnsibleTemplar()

    my_task = AnsibleTask()
    my_task._attributes = { 'args': {'facts':{'a':'b', 'c':'d'} } }

    module._task = my_task
    module._task.args = my_task._attributes['args']

    # Test
    result = module.run()

    # Verify
    assert result is not None
    assert len(result) == 2
    assert 'ansible_facts' in result
    assert '_ansible_facts_cacheable' in result
    assert 'a' in result['ansible_facts']
    assert 'b' in result['ansible_facts']
    assert 'c' in result['ansible_facts']

# Generated at 2022-06-21 02:53:33.611418
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test: AnsibleAction plugin module ActionModule - run"""

    import sys

    if sys.version_info.major < 3:
        byte_cls = str
    else:
        byte_cls = bytes

    module_name = 'ansible.plugins.action.add_host'
    if module_name in sys.modules:
        del sys.modules[module_name]

    # Verify that a good example of the module works
    import ansible.plugins.action.add_host as module


# Generated at 2022-06-21 02:53:39.016841
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_loader=dict(
        path="some_path",
    )
    mock_task=dict(
        args=dict(
            test="blah",
        ),
    )

    am=ActionModule(mock_loader,mock_task,file_local_load=False)
    assert am

# Generated at 2022-06-21 02:53:48.070458
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system import DistributionFactRetriever
    from ansible.module_utils.facts.system import DistributionInfo

    # test to make sure the constructor works (happy path)
    assert Distribution()

    # test to make sure the constructor works (unhappy path)
    assert not DistributionInfo()

    # test to make sure the constructor works (happy path)
    assert DistributionFactRetriever()

# Generated at 2022-06-21 02:53:56.499918
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Test of method run of class ActionModule
    '''

    result1 = {
        'ansible_facts': {
            'a': 'b',
            'c': 'd',
        },
        '_ansible_facts_cacheable': True,
    }

    test_class = ActionModule()
    result2 = test_class.run({}, {}, {'a':'b', 'c':'d'})

    assert result1 == result2

# Generated at 2022-06-21 02:54:06.905017
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None) is not None

# Generated at 2022-06-21 02:54:20.022000
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule

    from ansible.module_utils import basic
    from ansible.template import Templar
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    module_args = dict(name="value")
    module = None
    templar = Templar(loader=None, variables=variable_manager)

    # Instantiate a task instance
    task = Task()
    task.action = 'debug'
    task.args = {}
    task.args.update(module_args)

    # Instantiate an action plugin
    action = ActionModule(task, connection=None, play_context=None, loader=None, templar=templar, shared_loader_obj=None)

# Generated at 2022-06-21 02:54:20.742875
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 02:54:21.299892
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # this test is skipped
    pass

# Generated at 2022-06-21 02:54:24.621497
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    assert action.run is not None, "ensure method run exists and is not None"



# Generated at 2022-06-21 02:54:27.697881
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Unit test call to function run of class ActionModule
    # Object instance of class ActionModule
    m = ActionModule()

    # Test instantiation of object instance of class ActionModule
    assert isinstance(m, ActionModule)


# Generated at 2022-06-21 02:54:34.929625
# Unit test for constructor of class ActionModule
def test_ActionModule():
    d = {'a': 'A', 'b': 'B', }

    # Check that creating an ActionModule works
    am = ActionModule(d)
    assert am

    # Check that attributaes are set
    # TODO: add better check to ensure that calling the ActionModule works
    assert am.args == d

# Generated at 2022-06-21 02:54:37.720449
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext

    c = PlayContext()
    action = ActionModule(c, {},{},{},{})

    assert(isinstance(action, ActionModule))

# Generated at 2022-06-21 02:54:49.822718
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils._text import to_native, to_bytes
    from ansible.modules.system import setup as module_setup
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'ansible_connection': 'local'}

    module = module_setup.SetupModule(loader=loader, variable_manager=variable_manager)

    task = Task()
    task.action = 'setup'
    task.args = {'cacheable': True}
    task_vars = dict()
    task_vars['hostvars'] = dict()

# Generated at 2022-06-21 02:54:51.806238
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None)
    assert action is not None

# Generated at 2022-06-21 02:55:23.873175
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.six import PY3

    from units.mock.loader import DictDataLoader
    from units.compat import unittest
    from units.mock.path import mock_unfrackpath_noop
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar

    # Mock a task with dictionary containing ansible_facts
    task_vars = dict(
        ansible_facts=dict(
            testvar0=dict(
                testvar1=dict(
                    testvar2='value'
                )
            )
        )
    )

# Generated at 2022-06-21 02:55:24.425117
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 02:55:33.634828
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.facts import Facts
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.vars import VariableManager

    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am._display.banner('TASK') == 'TASK'
    assert am._display.display('TASK', color='blue') == 'TASK'
    am._display.verbosity = 4
    assert am._display.display('TASK', color='blue') == 'TASK'
    am._display.verbosity = 3
    assert am._display.display('TASK', color='blue') == 'TASK'
    am._

# Generated at 2022-06-21 02:55:38.035592
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert a is not None

# Generated at 2022-06-21 02:55:45.432753
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = DummyTask()
    action = ActionModule(task, dict(ANSIBLE_ACTION_PLUGINS=['tests/units/modules/extras/test_action_plugin'], ANSIBLE_MODULE_UTILS=['tests/units/module_utils']))
    assert action._task.args == dict(k='v')
    result = action.run(tmp=None, task_vars=dict())
    assert result['ansible_facts'] == dict(k='v')
    assert result['_ansible_facts_cacheable'] == False
    task = DummyTask()
    action = ActionModule(task, dict(ANSIBLE_ACTION_PLUGINS=['tests/units/modules/extras/test_action_plugin'], ANSIBLE_MODULE_UTILS=['tests/units/module_utils']))

# Generated at 2022-06-21 02:55:53.808887
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arrange
    module = AnsibleModule(argument_spec=dict(a=dict(required=True, type='str'),
                                              b=dict(required=True, type='str')))
    action_module = ActionModule(task=module.params, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module._templar.template = lambda x: x

    # Act and Assert
    with pytest.raises(AnsibleActionFail) as ex:
        action_module.run(tmp=None, task_vars=None)
    assert 'No key/value pairs provided, at least one is required for this action to succeed' in str(ex.value)

    # Act and Assert

# Generated at 2022-06-21 02:55:58.381124
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test the module ActionModule of the action plugin
    """
    config = dict(SOME="VAR", OTHER="THING", NONE="", ZERO=0, CACHE=False)
    result = dict(changed=False)
    hostvars = dict(HOSTNAME="localhost", SOME="VAR", OTHER="THING", NONE="", ZERO=0, CACHE=0)
    templar = dict(template=lambda x:x)
    module = ActionModule({}, config, hostvars, templar)
    result = module.run()
    assert result['ansible_facts'] == config
    assert result['_ansible_facts_cacheable'] == False


# Generated at 2022-06-21 02:55:58.838011
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.run is ActionModule().run

# Generated at 2022-06-21 02:56:11.344705
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    assert module.run(tmp=None, task_vars=dict()) == {'ansible_facts': {}, '_ansible_facts_cacheable': False}
    assert module.run(tmp=None, task_vars=dict(), cacheable=True) == {'ansible_facts': {}, '_ansible_facts_cacheable': True}
    assert module.run(tmp=None, task_vars=dict(), key='value') == {'ansible_facts': {'key': 'value'}, '_ansible_facts_cacheable': False}
    assert module.run(tmp=None, task_vars=dict(), key='value', cacheable=True) == {'ansible_facts': {'key': 'value'}, '_ansible_facts_cacheable': True}

# Generated at 2022-06-21 02:56:15.506848
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(dict(), dict())
    assert isinstance(action, ActionModule)
    assert action.TRANSFERS_FILES == False
    

# Generated at 2022-06-21 02:57:03.316598
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-21 02:57:11.862319
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.six import StringIO

    class ActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            self.ran = True

    class PlayContext:
        def __init__(self):
            self.connection = 'local'

    class Play(Play):
        def __init__(self):
            self.context = PlayContext()

    class Task(Task):
        def __init__(self):
            self.action = 'set_fact'
            self.args = dict()
            self.args['name'] = 'test_var'
            self.args['value'] = 'test_val'
            self.play = Play()

    class Connection:
        def __init__(self, *args, **kwargs):
            pass


# Generated at 2022-06-21 02:57:15.284924
# Unit test for constructor of class ActionModule
def test_ActionModule():
    d = {}
    d['action'] = {}
    d['action']['options'] = {}
    a = ActionModule()
    a.run(d, dict())

# Generated at 2022-06-21 02:57:23.585817
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: (1) refactor in superclass and test by asserting the final result instead of stdout, (2) test with templating
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.plugins.loader import action_loader
    from ansible import context
    import os
    import sys

    display = Display()
    loader

# Generated at 2022-06-21 02:57:28.928654
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task  # noqa: F401
    assert ActionModule.run is not None

# Generated at 2022-06-21 02:57:40.346803
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task

    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_context import PlayContext
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import merge_hash

    import ansible.constants as C

    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    # Create task
    task_ds = dict(
        name = "test x",
        action = dict(module="debug", args=dict(msg="{{test_var}}"))
    )
    task = Task.load(task_ds)

    # Create variable manager
    variable_manager = VariableManager()
   

# Generated at 2022-06-21 02:57:52.857753
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    module_args = dict(
        foo='bar',
        bam='baz',
    )

    task = Task()
    task._role = None
    task.args = module_args

    play_context = PlayContext()

    variable_manager = VariableManager()
    variable_manager.extra_vars = dict()

    templar = Templar(loader=None, variables=variable_manager)

    am = ActionModule(task, play_context, variable_manager, templar)

    result = am.run(None, None)


# Generated at 2022-06-21 02:57:56.102314
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule()
    mod._task.args = {'x': '2'}
    mod.run(tmp=None, task_vars=None)


# Generated at 2022-06-21 02:57:59.365416
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' This tests that the constructor of the ActionModule class does what we expect '''
    import ansible.plugins.action
    action = ansible.plugins.action.ActionModule(None, None, None, None)
    assert action.TRANSFERS_FILES == False

# Generated at 2022-06-21 02:58:00.171796
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 02:59:40.383992
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('here')


# Generated at 2022-06-21 02:59:45.535456
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Demo the type of arguments that are passed to __init__
    task = dict()
    connection = dict()
    play_context = dict()

    # Instantiate the class
    module_hook = ActionModule(task, connection, play_context)

    # Check that the class has the members we expect
    assert hasattr(module_hook, 'task')
    assert hasattr(module_hook, 'connection')
    assert hasattr(module_hook, 'play_context')

    # Check that the task object is the type that we expect
    assert type(module_hook.task) is dict

    # Check that the null connection object is the type that we expect
    assert type(module_hook.connection) is dict

    # Check that the null play_context object is the type that we expect
    assert type(module_hook.play_context) is dict

# Generated at 2022-06-21 02:59:51.425984
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # No type checking here, if we get to the constructor it's a success
    try:
        action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    except:
        action_module = Exception("ActionModule instantiation failed!")

    assert not isinstance(action_module, Exception)