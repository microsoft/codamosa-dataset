

# Generated at 2022-06-21 02:50:01.679047
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print(ActionModule.__name__)
    assert callable(ActionModule)

# Generated at 2022-06-21 02:50:10.887193
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_data = """
        - name: test action module
          set_fact:
            foo: bar
    """
    result = ActionModule.from_str(test_data)
    assert(result is not None)
    assert(result.args == dict(foo='bar'))
    assert(result.no_log is False)
    assert(result.become is False)
    assert(result.become_user is None)
    assert(result.become_method is None)


# Generated at 2022-06-21 02:50:18.898186
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ctrl = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    task_vars = dict()
    facts = dict()
    facts['test1'] = 'one'
    facts['test2'] = 2
    facts['test3'] = 'three'
    facts['test4'] = True
    task_vars['ansible_facts'] = facts
    ans = ctrl.run(None, task_vars)
    assert ans['ansible_facts'] == {'test1': 'one', 'test2': 2, 'test3': 'three', 'test4': True}

if __name__ == "__main__":
    test_ActionModule_run()

# Generated at 2022-06-21 02:50:24.566466
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task as Task
    from ansible.playbook.play_context import PlayContext as PlayContext

    my_task = Task()
    my_task.name = "my_task"
    my_task.path = ""
    my_task.action = ""
    my_task.args = ""
    my_task._role = ""
    my_task._task_vars = dict()

    play_context = PlayContext()

    my_action_module = ActionModule(my_task, play_context, 0)
    return my_action_module

# Generated at 2022-06-21 02:50:25.382903
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 02:50:26.282268
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-21 02:50:28.696780
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Use the constructor to create a instance of ActionModule
    action_module = ActionModule(None, None, None)
    # Asserts the instance has been created
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-21 02:50:29.783911
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, "TODO: Write unit test for method run of class ActionModule"

# Generated at 2022-06-21 02:50:39.629765
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.module_utils.parsing.convert_bool import boolean


# Generated at 2022-06-21 02:50:40.765548
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    assert 1 == 1

# Generated at 2022-06-21 02:50:45.881246
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-21 02:50:50.535575
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # the following line is actually not needed for this particular class,
    # but it is in the template and cannot be deleted atm
    import ansible.plugins

    ansible.plugins.action.ActionModule(None, dict())
    # no real assertions possible
    assert True

# Generated at 2022-06-21 02:50:51.124849
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:50:54.887396
# Unit test for constructor of class ActionModule
def test_ActionModule():
  am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)


# Generated at 2022-06-21 02:50:56.926468
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 02:51:00.522374
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Given
    # a
    am = ActionModule()

    # When
    # b
    result = am.run()

    # Then
    # c
    return result

# Generated at 2022-06-21 02:51:13.255883
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.set_fact

    module = ansible.plugins.action.set_fact.ActionModule(
        task=dict(action=dict(
            module_name='set_fact',
            module_args=dict(
                facts=dict(
                    foo='foo',
                    bar='bar',
                    baz='baz',
                ),
                cacheable=False,
            ),
        ),),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None,
    )

    res = module.run(tmp=None, task_vars=dict())


# Generated at 2022-06-21 02:51:16.290620
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, None, None)
    assert isinstance(module, ActionModule)
    return module


# Generated at 2022-06-21 02:51:17.134337
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:51:23.783675
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import mock
    from ansible.module_utils.six import iteritems
    from ansible.utils import context_objects as co
    import ansible.plugins.action.set_fact as set_fact
    from ansible.plugins.loader import find_plugin

    class MockTask(object):
        def __init__(self, args):
            self.args = args

    class MockPlay(object):
        def __init__(self):
            self.vars = {}

    class MockHost(object):
        def __init__(self):
            self.name = 'host.example.com'
            self.vars = {}
            self.groups = []

    class MockPlayContext(object):
        def __init__(self, task_vars):
            self.task_vars = task_vars
            self

# Generated at 2022-06-21 02:51:38.091195
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Verify initialization defaults
    """
    m = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert m.TRANSFERS_FILES is False

# Generated at 2022-06-21 02:51:46.008271
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a test action module
    test_obj = ActionModule(None, None, None, None, None)
    test_obj._templar = test_obj._templar_deepcopy()
    test_obj._templar.available_variables = dict()
    test_obj._task = dict()
    test_obj._task['args'] = dict()

    # Create a tmp path
    import os
    tmp = os.path.join(os.path.dirname(os.path.realpath(__file__)), '.tmp')

    # Test a successful run
    test_obj._task['args']['test_key'] = 'test_value'
    test_obj._task['args']['test_key2'] = 'test_value2'
    test_obj._task['args']['cacheable'] = False

# Generated at 2022-06-21 02:51:47.445764
# Unit test for constructor of class ActionModule
def test_ActionModule():
	assert not ActionModule(None)


# Generated at 2022-06-21 02:51:52.103525
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(task=dict(action=dict(module_name='set_fact', module_args=dict(a='1'))))
    result = module.run(task_vars=dict())
    assert not result['changed']
    assert result['ansible_facts']['a'] == '1'
    assert result['_ansible_facts_cacheable'] == False

# Generated at 2022-06-21 02:52:03.735503
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    import tempfile
    import shutil
    import yaml
    import copy

    # utility function to recursively update a dict
    def deepupdate(d, u):
        for k, v in iteritems(u):
            if isinstance(v, dict):
                r = deepupdate(d.get(k, {}), v)
                d[k] = r
            else:
                d[k] = u[k]
        return d

    # mock an AnsibleModule object

# Generated at 2022-06-21 02:52:08.068384
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        a = ActionModule(None,None,None,None)
        assert False, 'ActionModule constructor to be tested'
    except:
        pass


# Generated at 2022-06-21 02:52:09.706334
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule


# Generated at 2022-06-21 02:52:13.767138
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.model_vars import ModelVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from system.units.mock.loader import DictDataLoader
    from system.units.mock.path import MockPath
    from system.units.mock.vault import MockVaultSecret
    f = Task()
    context = PlayContext()
    context.connection = 'local'

# Generated at 2022-06-21 02:52:17.082207
# Unit test for constructor of class ActionModule
def test_ActionModule():
  am = ActionModule()
  assert am.TRANSFERS_FILES == False


# Generated at 2022-06-21 02:52:26.303686
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_under_test = 'set_fact'
    playbook = [ module_under_test, 'a=1', 'b=2' ]
    action = ActionModule(
        load_plugins=False,
        role_name=None,
        task_vars={'a': 'b'},
        loader=None,
        play=None,
        new_stdin='',
        connection=None,
        connection_loader=None,
        templar=None,
        shared_loader_obj=None,
        terms=None,
        index=0,
        name=module_under_test,
        parents=[]
    )
    action.task.args = {
        'a': '1',
        'b': '2'
    }

# Generated at 2022-06-21 02:52:42.205504
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-21 02:52:43.975857
# Unit test for constructor of class ActionModule
def test_ActionModule():
    c = ActionModule(None)

# Generated at 2022-06-21 02:52:54.936485
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block

    class MockTask(object):
        def __init__(self, args):
            self.args = args

    class MockAnsibleModule(object):
        def __init__(self, args):
            self.args = args

    class MockTemplar(object):
        def __init__(self, args):
            self.template = args

    module = MockAnsibleModule({'debug': False, 'gather_facts': 'no', 'name': 'name'})
    templar = MockTemplar({'jinja2_native': 'no', 'strict': True})
    task_include = TaskInclude('fake', Block(), templar=templar)

    module_args = {}
   

# Generated at 2022-06-21 02:52:58.807554
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Make sure that constructor of ActionModule is working correctly
    """
    action_module = ActionModule(None, None, None, None)
    assert action_module is not None

# Generated at 2022-06-21 02:53:06.657471
# Unit test for constructor of class ActionModule
def test_ActionModule():

    try:
        from ansible.plugins.connection import Connection
        from ansible.module_utils.facts import ansible_proxy
        from ansible.module_utils.facts.virtual import Virtual
    except ImportError:
        print("SKIP: since this module requires the virtual, proxy and Connection plugin, which are not always available")
        raise

    # Manipulate the class to simulate the presence of a connection plugin
    connection_plugin = Connection()
    setattr(ActionModule, 'connection_plugin_class', connection_plugin)

    class MockTask(object):
        def __init__(self, args):
            self.args = args


# Generated at 2022-06-21 02:53:14.710505
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit tests for testing method run() of class ActionModule"""
    action_module = ActionModule(load_ansible_lib=False)
    task_args = {'cacheable': True, 'first': 'one', 'second': 'two'}
    task_vars = {'ansible_env': {'HOME': '/', 'PATH': '/usr/bin:/bin'}}
    result = action_module.run(task_vars=task_vars, **task_args)
    assert result['ansible_facts'] == {'first': 'one', 'second': 'two'}
    assert result['_ansible_facts_cacheable'] is True

# Generated at 2022-06-21 02:53:21.214955
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    play_context = PlayContext()
    variable_manager = VariableManager()

    m = ActionModule(loader=loader, play_context=play_context, variable_manager=variable_manager)
    assert m != None

# Generated at 2022-06-21 02:53:25.899316
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #Dummy values
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display
    from ansible.errors import AnsibleParserError
    from io import StringIO

    display = Display()
    display.verbosity = 4

    task = Task()
    task_vars = dict()
    var_manager = VariableManager()
    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources=['localhost,'])

# Generated at 2022-06-21 02:53:36.117320
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test_pass_dict
    test_pass_dict = {}
    _task = {'args': test_pass_dict}
    _task['args']['cacheable'] = False
    _templar = {}

    res = ActionModule.run(ActionModule(), tmp=None, task_vars=None, _task=_task, _templar=_templar)

    assert isinstance(res, dict)
    assert 'ansible_facts' in res
    assert len(res['ansible_facts']) == 0
    assert '_ansible_facts_cacheable' in res
    assert res['_ansible_facts_cacheable'] == False

    # test_pass_non_dict
    test_pass_non_dict = 123
    _task = {'args': test_pass_non_dict}
   

# Generated at 2022-06-21 02:53:36.799188
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:54:17.274444
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Assert that AnsibleActionFail is constructed correctly (not raising an exception)
    try:
        ansible_action_fail = AnsibleActionFail('TEST message')
    except:
        assert False, "AnsibleActionFail is not constructed correctly"

    # Assert that ActionModule is constructed correctly (not raising an exception)
    try:
        action_module = ActionModule(None, None, None, None, None, None)
    except:
        assert False, "ActionModule is not constructed correctly"


# Generated at 2022-06-21 02:54:27.067994
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json

    module = ActionModule()
    task = dict(action='set_fact', args=dict(myvar='myvalue', myvar2=False))

    # We need a task object
    action = module.load_action_plugin(task, task_vars=dict(hostvars=dict()))
    assert isinstance(action, ActionModule)

    # with default options
    res = action.run(task_vars=dict())
    res = json.loads(json.dumps(res, ensure_ascii=False))
    assert isinstance(res, dict)
    assert res['ansible_facts']['myvar'] == 'myvalue'
    assert res['ansible_facts']['myvar2'] is False

    # with cacheable=true
    task['args']['cacheable'] = True


# Generated at 2022-06-21 02:54:32.278724
# Unit test for constructor of class ActionModule
def test_ActionModule():
  # Test if a constructor of an object ActionModule can be invoked
  assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 02:54:41.148241
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.runner.RunnerHelper import RunnerHelper


# Generated at 2022-06-21 02:54:42.440446
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, "action_plugins/set_fact_test.py is not a test"

# Generated at 2022-06-21 02:54:46.083790
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create test object
    action_module = ActionModule(None, {}, {}, None)
    return action_module


# Generated at 2022-06-21 02:54:58.258519
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.vars import combine_vars

    am = ActionModule(None, None)

    task_vars = {'a': 'b'}
    am._task = {'args': {'k': 'v', }}
    am._templar = am._shared_loader_obj.environment.get_template('fake')
    results = am.run(None, task_vars=task_vars)
    assert results.get('ansible_facts') == {'k': 'v'}, results
    assert results.get('_ansible_facts_cacheable') == False, results

# Generated at 2022-06-21 02:55:09.955039
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    action_module = ActionModule({}, {}, {}, {}, {})

    # Test
    result = action_module._templar.template({'foo': 1})
    assert result == {'foo': 1}

    # Test
    result = action_module._templar.template({'foo': '1'})
    assert result == {'foo': '1'}

    # Test
    result = action_module._templar.template({'foo': 'hello'})
    assert result == {'foo': 'hello'}

    # Test
    result = action_module._templar.template({'foo': True})
    assert result == {'foo': True}

    # Test
    result = action_module._templar.template({'foo': 'True'})

# Generated at 2022-06-21 02:55:11.344038
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, task=None)

# Generated at 2022-06-21 02:55:22.039931
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Init vars
    AM_test = ActionModule()


# Generated at 2022-06-21 02:56:31.606540
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test action definition
    '''
    - name: Write facts
      set_fact:
        hello: world
    '''
    # test action with valid definition
    '''
    - set_fact:
      hello: world
    '''
    # test action with invalid definition
    '''
    - set_fact: hello: world
    '''

# Generated at 2022-06-21 02:56:33.685914
# Unit test for constructor of class ActionModule
def test_ActionModule():
    t = ActionModule(None, None)

# Generated at 2022-06-21 02:56:42.321585
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize the module
    module = ActionModule({"name": "test", "key_name": "test_key", "value_name": "test_value"}, "/dev/null", "/dev/null", '')
    
    # set up a fake ansible_facts dictionary
    ansible_facts = dict()

    # set up fake templar
    module._templar = dict()

    # set up a fake task_vars dictionary
    task_vars = dict()

    # set up a fake _task dictionary
    module._task = dict()
    module._task['args'] = {'test_key': 'test_value'}

    # Call the run method
    result = module.run("", task_vars)

    assert 'ansible_facts' in result

# Generated at 2022-06-21 02:56:43.107505
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 02:56:44.430946
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 02:56:52.050544
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a test task
    task = (dict(action=dict(module='set_fact', args=dict(a=dict(b=5), ansible_python_interpreter='/usr/bin/python'))))
    task_vars = dict()

    am = ActionModule(task, task_vars)

    # Perform assertions
    assert am._task.action['module'] == 'set_fact'

    result = am.run(task_vars=task_vars)

    # Check results
    assert result is not None
    assert result.get('ansible_facts', None) is not None
    assert result.get('ansible_facts', None).get('a', None) is not None
    assert result.get('ansible_facts', None).get('a', None).get('b', None) is not None

# Generated at 2022-06-21 02:57:02.091001
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager

    # Mock arguments to pass to the module
    module_args = {'fact1': 'val1', 'fact2': True, 'fact3': 'val3'}

    loader = None
    templar = None
    shared_loader_obj = None

    # Instantiate class object to be tested
    obj = ActionModule(loader=loader, templar=templar, shared_loader_obj=shared_loader_obj)

    # Create a task with required arguments
    task = Task()
    task.args = module_args
    task.action = 'set_fact'
    task.set_loader(loader)
    task_queue_manager = None



# Generated at 2022-06-21 02:57:11.503413
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Dummy class for testing
    class DummyActionModule(ActionBase):
        pass

    # Create a ActionModule object
    act_module= ActionModule()
    #print(vars(act_module))
    assert act_module._templar is not None,"Instantiation of _templar failed"
    assert act_module.TRANSFERS_FILES == False,"Instantiation of TRANSFERS_FILES failed"
    assert act_module.SUPPORT_CHECK_MODE == True,"Instantiation of SUPPORT_CHECK_MODE failed"
    assert act_module.DEFAULT_PROTOCOL == 'smart','Instantiation of DEFAULT_PROTOCOL failed'
    assert act_module.NO_LOG == ['ssh_password','become_password'],'Instantiation of NO_LOG failed'
    assert act_module.BYPASS_HOST

# Generated at 2022-06-21 02:57:20.332282
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = dict(
        ansible_facts=dict(),
        _ansible_facts_cacheable=False,
    )
    # This will raise AnsibleActionFail if transfer is not set to False,
    # which it should be
    assert action_module.run() != result
    assert action_module.run()['ansible_facts'] == dict()
    assert action_module.run()['_ansible_facts_cacheable'] == False

# Generated at 2022-06-21 02:57:30.972386
# Unit test for constructor of class ActionModule
def test_ActionModule():
    arg = dict(
        ansible_facts=dict(
            one=1,
            two=2,
        ),
    )
    a = ActionModule(None, arg)
    assert a._task is None
    assert a._args == arg
    assert a._play_context is None
    assert a._loader is None
    assert a._templar is None
    assert a._shared_loader_obj is None
    assert a._action is None
    assert a._connected is None
    assert a._always_run is None
    assert a._ansible_version is None
    assert a._remote_user is None
    assert a._remote_pass is None
    assert a._allow_background is None