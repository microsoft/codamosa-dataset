

# Generated at 2022-06-21 02:50:00.080676
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action.TRANSFERS_FILES is False


# Generated at 2022-06-21 02:50:02.364426
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Make sure we get an object in the first place
    assert isinstance(ActionModule, object)

    # TODO: More assertions here
    #assert ActionModule.TRANSFERS_FILES == False

# Generated at 2022-06-21 02:50:11.254653
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class _task(object):
        def __init__(self, args):
            self.args = args
    import ansible.utils
    ansible.utils.plugins.action_loader = None
    test_task = _task(dict(key=dict(subkey='value')))
    test_task.args = dict(key=dict(subkey='value'))
    test_action = ActionModule(test_task, dict())
    assert(test_action._task.args['key'] == dict(subkey='value'))

# Generated at 2022-06-21 02:50:12.111007
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement this
    assert False

# Generated at 2022-06-21 02:50:16.644295
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from .mock import patch

    module = ActionModule(task=dict(args=dict(fact1='value1', fact2='value2')))

    with patch('ansible.plugins.action.ActionBase.run') as run:
        module.run()
        assert run.call_args[0][0] == dict(ansible_facts=dict(fact1='value1', fact2='value2'), _ansible_facts_cacheable=False)

# Generated at 2022-06-21 02:50:17.445470
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 02:50:21.985585
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    We need to test if we can create an instance of class ActionModule
    """
    assertion = True
    #action = None
    try:
        action = ActionModule()
    except Exception as e:
        assertion = False
        #print(str(e))
    assert assertion, "ActionModule instance creation failed"

# Generated at 2022-06-21 02:50:32.835453
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # set a module argument and set the return value
    test_args = {'ansible_os_family': 'redhat'}
    test_return = {'ansible_facts': {'ansible_os_family': 'redhat'},
                   'changed': False,
                   '_ansible_facts_cacheable': False}

    # create an instance of the module class
    mod = ActionModule(None, None)

    # set the action arguments
    mod._task.args = test_args

    # get the run method and call it
    mod_run = getattr(mod, 'run')
    result = mod_run(None, None)

    # check the return value
    assert(result == test_return), \
        "expected {} but got {}".format(test_return, result)

# Generated at 2022-06-21 02:50:39.364393
# Unit test for constructor of class ActionModule
def test_ActionModule():
   # py.test tests/unit/plugins/action/test_set_fact.py  -v
   print('\nUnit Tests for ActionModule\n')
   # Test creation of no instance
   # Test creation with no task_vars
   test1 = ActionModule()
   test1.run(None, None)

if __name__ == '__main__':
   test_ActionModule()

# Generated at 2022-06-21 02:50:43.970857
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action
    assert isinstance(ansible.plugins.action, object)

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-21 02:50:50.697609
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Test that the super constructor is called
    action = ActionModule({}, {}, {})
    assert action._shared_loader_obj._shared_state == None

# Generated at 2022-06-21 02:51:00.202719
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize class
    module = ActionModule()
    # Construct a mock task
    task = DummyTask()
    # Construct a mock AnsibleModule
    ansible_module = DummyAnsibleModule()
    # Construct a mock AnsibleTemplar
    templar = DummyTemplar()
    # Create a mock Ansible module
    module._templar = templar
    # Create a mock AnsibleTask
    module._task = task
    # Create a mock AnsibleTaskArgs
    task_args = {'key_name': 'key_value', 'cacheable': True}
    task.args = task_args
    # Create a mock AnsibleResult
    result = DummyResult()
    # Call test method
    result = module.run()
    # Check

# Generated at 2022-06-21 02:51:02.954735
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    assert type(action.run()) == dict

test_ActionModule_run()

# Generated at 2022-06-21 02:51:10.672192
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()

    tmp = None
    task_vars = dict()

    # set a variable
    result = action.run(tmp, task_vars)

    ansible_facts = result['ansible_facts']
    assert ansible_facts and len(ansible_facts) == 1 and '_ansible_facts_cacheable' in ansible_facts and ansible_facts['_ansible_facts_cacheable']



# Generated at 2022-06-21 02:51:22.643948
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import six

    # stubs
    class TestActionModule(ActionModule): pass
    class TestActionBase(ActionBase):
        def run(self, tmp=None, task_vars=None):
            return {'ansible_facts': {}, '_ansible_facts_cacheable': False}

    test_task_vars = {}
    test_task_vars['fqdn'] = 'ansible'
    test_task_vars['ansible_hostname'] = 'ansible'
    test_task_vars['ansible_domain'] = 'local'

    test_task_vars['ansible_fqdn'] = 'ansible.local'
    test_task_vars['ansible_nodename'] = 'ansible.local'

# Generated at 2022-06-21 02:51:34.460098
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common._collections_compat import MutableMapping

    action = ActionModule()

    # Test with no arguments

# Generated at 2022-06-21 02:51:44.832534
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_task = {
        'name': 'TASK_NAME',
        'action': {
            '__ansible_module__': '__fake__',
            'args': {},
        },
        'args': {},
        'delegate_to': '127.0.0.1',
        'register': 'result_var_name',
    }
    from ansible.playbook.task_include import TaskInclude
    test_task['action']['__ansible_module__'] = ActionModule
    test_task = TaskInclude.load(test_task)
    test_result = test_task.action.run({}, {'ansible_facts': {}})

    assert test_task.action.TRANSFERS_FILES is False
    assert test_result['failed'] is True
    assert test_

# Generated at 2022-06-21 02:51:53.508378
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible
    import ansible.plugins.action
    import ansible.utils.vars
    module = ansible.plugins.action.ActionModule(
        task=dict(
            args=dict(
                b='foo',
                c='bar',
                cacheable=True,
            ),
        ),
    )

    assert 'b' in module._task.args
    assert 'c' in module._task.args
    assert 'cacheable' in module._task.args
    assert module.TRANSFERS_FILES is False
    assert module.BOOLEANS == C.BOOLEANS

    assert isinstance(ansible.utils.vars.isidentifier, type(module.isidentifier))

# Generated at 2022-06-21 02:52:04.204322
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


if __name__ == '__main__':
    import sys
    import unittest
    from ansible.utils.display import Display

    display = Display()
    display.verbosity = 2
    display.debug("Loading tests")


# Generated at 2022-06-21 02:52:05.432149
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:52:25.407606
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import context
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    action = ActionModule(task=dict(), connection=None, templar=Templar(), play_context=PlayContext(), loader=None, shared_loader_obj=None, final_loader_obj=None)

    # Test successful completion and variable creation
    assert action.run(tmp=None, task_vars=dict()) == dict(ansible_facts=dict(), _ansible_facts_cacheable=False)

    # Test using non-identifier variable names
    with context._cleanup_context():
        context.CLIARGS._store['module_vars'] = dict()
        context.CLIARGS._store['module_vars']['var1'] = True


# Generated at 2022-06-21 02:52:30.587585
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule()
    with pytest.raises(AnsibleActionFail) as errorInfo:
        actionModule.run()
    assert str(errorInfo.value) == 'No key/value pairs provided, at least one is required for this action to succeed'

# Generated at 2022-06-21 02:52:34.202658
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    # Test the case when task_vars is None
    try:
        action_module.run(task_vars=None)
    except Exception:
        pass
    else:
        raise AssertionError("Testing the run method of the ActionModule class with task_vars as None did not raise an exception")

# Generated at 2022-06-21 02:52:36.811168
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, {})
    assert isinstance(action, ActionModule)


# Generated at 2022-06-21 02:52:43.423944
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  # Create an ActionModule object
  actionModule = ActionModule(None, None)
  # Create a dict object for task_vars
  task_vars = {}
  # Create a dict object for tmp
  tmp = {}
  # Create a dict object for result
  result = {}
  # Expected result
  expectedResult = False
  # Assign true to the key 'ansible_facts' of result
  result['ansible_facts'] = True
  # Call method run of class ActionModule
  result = actionModule.run(tmp, task_vars)
  # Check if result is the same as the expected result
  assert result == expectedResult

# Generated at 2022-06-21 02:52:43.742832
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:52:54.545779
# Unit test for constructor of class ActionModule
def test_ActionModule():
    global _test_action_module_runs
    global _test_action_module_task_vars
    _test_action_module_runs = 0
    _test_action_module_task_vars = None

    class Task:
        def __init__(self):
            self.args = {'a': 1}
    class PlayContext:
        def __init__(self):
            self.remote_addr = 'localhost'
            self.network_os = 'freebsd'
            self.become = False
            self.become_method = None
            self.become_user = None
    class Runner:
        def __init__(self):
            self.connection = 'local'
            self.transport = 'local'
        def get_datastore(self):
            return None

# Generated at 2022-06-21 02:52:57.708693
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, {}, {}, {})
    assert action_module.TRANSFERS_FILES == False


# Generated at 2022-06-21 02:53:01.423453
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=None)
    assert module

# Generated at 2022-06-21 02:53:12.613235
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import copy
    from ansible.playbook.task import Task

    # Mock the ansible.constants.DEFAULT_JINJA2_NATIVE as False
    original_DEFAULT_JINJA2_NATIVE = copy.deepcopy(C.DEFAULT_JINJA2_NATIVE)
    C.DEFAULT_JINJA2_NATIVE = False

    # Mock the ansible.module_utils.parsing.convert_bool.boolean() function
    # so that it returns the input unmodified.  This is to prevent this test
    # from failing due to changes in the convert_bool.boolean() module.
    original_boolean = copy.deepcopy(boolean)
    def mock_boolean(value):
        return value

    boolean = mock_boolean

    # Successful test

# Generated at 2022-06-21 02:53:41.108997
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_args = {'cacheable': 'no', 'k1': 'v1', 'k2': 42, 'k3': ['a', 'b', 'c'], 'k4': True, 'k5': False}
    action_module = ActionModule(
        load_name = 'ActionModule',
        _task = dict(action = 'setup', args = module_args)
    )
    task_vars = dict()
    result = dict()

    # Test good input
    action_module.run(None, task_vars=task_vars)
    assert result['ansible_facts'] == module_args
    assert result['_ansible_facts_cacheable'] == False

    # Test bad input: key k2 is not of type str

# Generated at 2022-06-21 02:53:45.020752
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module

# Generated at 2022-06-21 02:53:45.870209
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 02:53:53.213036
# Unit test for constructor of class ActionModule
def test_ActionModule():

    from ansible.plugins.loader import action_loader
    loader = action_loader._create_loader()
    action = loader.get('set_fact', task=dict(), connection=None, play_context=None, loader=loader, templar=None, shared_loader_obj=None)
    assert action.__class__.__name__ == 'ActionModule'

    # assert that instance variables are defined
    assert action._shared_loader_obj
    assert action._play_context
    assert action._loader
    assert action._templar
    # _task should be defined, but the _task.args should be empty
    assert action._task
    assert not hasattr(action._task, 'args') or \
           not isinstance(action._task.args, dict) or \
           len(action._task.args) == 0

# Generated at 2022-06-21 02:54:02.554917
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 02:54:11.692650
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import datetime
    module = ActionModule()

    action = {
        'name': 'test',
        'action': 'set_fact',
        'args': {
            'test': 'It works',
            'date': datetime.date.isoformat,
        },
    }
    task = {
        'action': 'set_fact',
        'args': {
            'test': 'It works',
            'date': datetime.date.isoformat,
        }
    }
    result = module._execute_module(module_name=action, task_vars={}, task=task)

    assert result['ansible_facts'] == {'test': 'It works', 'date': datetime.date.today().isoformat()}
    assert result['_ansible_facts_cacheable'] is True


# Generated at 2022-06-21 02:54:15.790633
# Unit test for constructor of class ActionModule
def test_ActionModule():
    with pytest.raises(AnsibleActionFail) as execinfo:
        action_module = ActionModule(dict(), dict())
        action_module.run(tmp, task_vars)
    assert "No key/value pairs provided, at least one is required for this action to succeed" in str(execinfo.value)

# Generated at 2022-06-21 02:54:19.089301
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 02:54:24.307689
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=dict(args=dict()), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())
    # Do not use nose.tools.assert_true here because of the following exception message if the assertion fails
    # TypeError: '<' not supported between instances of 'NoneType' and 'bool'
    # TODO: Fix the above error message
    assert module is not None

# Generated at 2022-06-21 02:54:31.721374
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None)

    assert action_module is not None
    assert type(action_module) == ActionModule

    assert action_module.templar is not None
    assert type(action_module.templar) == type(None)

    assert action_module.task is not None
    assert type(action_module.task) == type(None)

    assert action_module._tmp is not None
    assert type(action_module._tmp) == type(None)

    assert action_module.task_vars is not None
    assert type(action_module.task_vars) == type(None)

    assert action_module._loader is not None
    assert type(action_module._loader) == type(None)

    assert action_module._connection is not None

# Generated at 2022-06-21 02:55:15.547268
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule()
    assert hasattr(m, 'run')

# Generated at 2022-06-21 02:55:20.867891
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = dict(action=dict(module='set_fact', args=dict(ansible_facts='{"vars": {"key1": "val1", "key2": "val2"}}')))
    result = ActionModule(task, dict()).run(dict(), dict())
    assert result.get('ansible_facts') == {'vars': {'key1': 'val1', 'key2': 'val2'}}

# Generated at 2022-06-21 02:55:32.723631
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.constants as C
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.action.set_fact import ActionModule

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    # ActionModule supports only module name,

# Generated at 2022-06-21 02:55:43.816931
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test for module run with empty args
    action_module = ActionModule()
    task = {'action':{'__ansible_module__':'debug', 'cacheable':'True'}}
    result = {'failed':True, 'msg':'No key/value pairs provided, at least one is required for this action to succeed'}
    assert result == action_module.run(task_vars=None, tmp=None)

    # Test for module run with valid args
    action_module = ActionModule()
    task = {'action':{'__ansible_module__':'debug',
                      'cacheable':'True',
                      'name1':'value1',
                      'name2':'value2'}}

# Generated at 2022-06-21 02:55:50.790742
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test normal case
    task = dict(name=dict(foo='bar'))
    am = ActionModule(task=task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am.ACTION_WANTS_TMPFILES == False
    assert am.ACTION_WANTS_CONNECTION == False
    assert am.ACTION_WANTS_SHARED_LOADER == True

# Generated at 2022-06-21 02:56:01.821934
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create a task using a action module
    action_module = dict(
        name='debug',
        args=dict(
            msg="Hello world!",
            cacheable=True,
            ansible_facts=dict(
                a=1,
                b=1,
                c=1,
            )
        )
    )
    task = dict(action=action_module)
    # instantiate ActionModule class
    ac = ActionModule(task, connection=None, play_context=None, loader=None, templar=None)
    ac._task.args['msg'] = "MESSAGE"
    ac._task.args['cacheable'] = True
    ac._task.args['ansible_facts'] = dict(
        a=1,
        b=1,
        c=1,
    )

# Generated at 2022-06-21 02:56:02.982573
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 02:56:07.038704
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test that the constructor will raise an exception if the first arg is not a dict
    ActionModule({}, {}, {}, test_host=[], test_play=dict(play_hosts=[]))

# Generated at 2022-06-21 02:56:14.279914
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

    # without args
    result = action_module.run()
    assert not result

    # invalid args: empty string
    result = action_module.run(task_vars={'arg1': '', 'arg2': 'blah'})
    assert 'msg' in result
    assert result['msg'] == "No key/value pairs provided, at least one is required for this action to succeed"

    # invalid args: None
    result = action_module.run(task_vars={'arg1': None, 'arg2': 'blah'})
    assert 'msg' in result
    assert result['msg'] == "No key/value pairs provided, at least one is required for this action to succeed"

    # invalid arg names: Can't be a number

# Generated at 2022-06-21 02:56:15.637380
# Unit test for constructor of class ActionModule
def test_ActionModule():

    assert(ActionModule is not None)


# Generated at 2022-06-21 02:57:51.694994
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule(None, None)
    m.run(tmp='None', task_vars=None)
    m.run(tmp=None, task_vars=None)

# Generated at 2022-06-21 02:58:00.600354
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class Mock_Task(object):
        def __init__(self):
            self.args = dict(
                    key1='value1',
                    key2='value2',
                    )

    class Mock_Templar(object):
        def __init__(self):
            self.template_data = dict(
                    )

        def template(self, value):
            return self.template_data[value]

    class Mock_ActionModule(ActionModule):
        def __init__(self):
            super(Mock_ActionModule, self).__init__(Mock_Task(), dict(), True)
            self._task = Mock_Task()
            self._templar = Mock_Templar()

    action_module = Mock_ActionModule()
    action_module._templar.template_data['key1'] = 'key1'

# Generated at 2022-06-21 02:58:05.810352
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(a, ActionBase)

# Generated at 2022-06-21 02:58:09.432637
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.set_fact import ActionModule

    t = dict(
        args = dict(
            var1=10,
            var2=20
        )
    )

    ac = ActionModule(dict(), t)

    assert ac is not None

# Generated at 2022-06-21 02:58:10.300422
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test = ActionModule()

# Generated at 2022-06-21 02:58:22.146755
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  class Object(object):
    pass

  class ModuleResult(object):
    def __init__(self):
      self.result = Object()
      self.result['ansible_facts'] = {}
      self.result['_ansible_facts_cacheable'] = False

    def __getitem__(self, name):
      return self.result[name]

    def __setitem__(self, name, value):
      self.result[name] = value

  #
  # Passing all arguments as is should work
  #
  m_args = {'key': 'value', 'otherkey': 'othervalue'}
  m_task_vars = {'test': 'test'}
  m_tmp = 'tmp'
  module = ActionModule()
  module._task = Object()
  module._task.args = m_args

# Generated at 2022-06-21 02:58:26.530727
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #import os
    #print os.path.dirname(os.path.abspath(__file__))
    #print __file__
    action = ActionModule(None, None, None, None)

# Generated at 2022-06-21 02:58:33.921276
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit test for ActionModule.run()'''
    from ansible.module_utils.ansible_f5_common import F5AnsibleModule
    import json

    module_args = {}

    # Load the ansible module

# Generated at 2022-06-21 02:58:44.116802
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = AnsibleModule()
    module.ansible_facts = dict()
    module.ansible_facts['a'] = {'a': 1, 'b': '2'}

    task = AnsibleActionModule()
    task.set_loader(DictDataLoader({
        'ansible_test': 'Playbook/test_util_vars_methods/test_action_module.py',
        'ansible_test.yaml': 'Playbook/test_util_vars_methods/ansible_test.yaml',
    }))

    task.task_vars = AnsibleVars(dict())
    task.task_vars._data.update(module.params)

    args = {'a': 1, 'b': '2', 'c': '3', 'cacheable': False}


# Generated at 2022-06-21 02:58:45.542814
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert callable(ActionModule)