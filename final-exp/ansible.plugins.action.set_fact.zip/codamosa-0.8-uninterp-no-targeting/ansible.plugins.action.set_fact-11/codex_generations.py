

# Generated at 2022-06-21 02:50:00.025595
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule"""
    module = ActionModule()
    module.run()

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-21 02:50:01.026438
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionModule)

# Generated at 2022-06-21 02:50:03.325283
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(type(ActionModule()), ActionBase)

# Generated at 2022-06-21 02:50:14.539412
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize object
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Assert if there are no arguments
    args = {}
    action_module._task.args = args
    assert action_module.run(tmp=None, task_vars=None) == dict(failed=True, msg="No key/value pairs provided, at least one is required for this action to succeed")

    # Assert if it is not valid
    args = dict(test1=[])
    action_module._task.args = args

# Generated at 2022-06-21 02:50:22.979152
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host = {
        'hostname': 'localhost',
        'ipv4': '127.0.0.1',
        'groups': ['ungrouped'],
    }

    task = {
        'args': {
            'key1': 'value1',
            'key2': 'value2',
        },
        'id': 1,
        'name': 'debug'
    }

    module_name = 'debug'

    action = ActionModule(task, host, [], module_name)

    result = action.run(task_vars=dict())
    assert 'ansible_facts' in result
    assert '_ansible_facts_cacheable' in result
    assert 'key1' in result['ansible_facts']
    assert result['ansible_facts']['key1'] == 'value1'
   

# Generated at 2022-06-21 02:50:30.710583
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    plugin = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=None, templar=None, shared_loader_obj=None)
    ## Arrange ##
    task_vars = dict()

    ## Act ##
    result = plugin.run(tmp=None, task_vars=task_vars)

    ## Assert ##
    assert result == dict(ansible_facts=dict(), _ansible_facts_cacheable=False)

# Generated at 2022-06-21 02:50:41.812163
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import ansible.constants as C
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY3

    test_dict = dict(
        test_true_yaml='yes',
        test_false_yaml='no',
        test_true_text='true',
        test_false_text='false',
        test_int_1='1',
        test_int_0='0',
        test_int_neg_1='-1',
        test_float_1='1.0',
        test_float_0='0.0',
        test_float_neg_1='-1.0',
    )
    task_vars = dict(
        ansible_facts=test_dict,
    )


# Generated at 2022-06-21 02:50:46.810171
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule()
    assert m._templar == None
    assert m._shared_loader_obj == None
    assert m._connection == None
    assert m._task == None
    assert m._loader == None
    assert m._play_context == None

# Generated at 2022-06-21 02:50:48.821448
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule(None, dict(), False)
    assert actionModule

# Generated at 2022-06-21 02:50:58.966202
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    # Define mock classes

    class MockAnsibleActionModule(ActionModule):
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            self._task = task
            self._connection = connection
            self._play_context = play_context
            self._

# Generated at 2022-06-21 02:51:09.960621
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(task=dict(args=dict(a='a', b='b', c='c'), name='name'))
    assert am.args['a'] == 'a'
    assert am.args['b'] == 'b'
    assert am.args['c'] == 'c'
    assert am.task['name'] == 'name'

# Generated at 2022-06-21 02:51:15.202313
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = dict()
    result['ansible_facts'] = dict()
    result['ansible_facts']['test_key'] = 'test_value'
    result['_ansible_facts_cacheable'] = False

    module_args = dict()
    module_args['test_key'] = 'test_value'
    module_args['cacheable'] = False

    a = ActionModule(None, {}, module_args, False, False)
    assert a.run(None, None) == result


# Generated at 2022-06-21 02:51:19.998872
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task={'args': {'ansible_os_family': 'test'}}, connection={}, play_context={}, loader={}, templar={}, shared_loader_obj={})
    assert action_module is not None

# Generated at 2022-06-21 02:51:21.954748
# Unit test for constructor of class ActionModule
def test_ActionModule():
    aa = ActionModule(None, {}, None, None)
    assert not aa

# Generated at 2022-06-21 02:51:34.217040
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    import ansible.utils.template as template
    from ansible.utils.vars import isidentifier

    fake_loader = DummyClass()

    fake_play_context = DummyClass()
    fake_play_context.become = False
    fake_play_context.become_user = 'test_user'
    fake_play_context.connection = 'test_connection'

    fake_task = DummyClass()
    fake_task.args = {'test':1, 'test1':'valid'}
    fake_task.async_val = 0
    fake_task.notify = []
    fake_task.run_once = False
    fake_task._role_name = 'test_role'

# Generated at 2022-06-21 02:51:39.936393
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Create an instance of the class with valid and invalid paramaters
    '''
    # Constructor w/o any paramaters
    test = ActionModule(None)
    assert test is not None
    test = ActionModule(None, dict())
    assert test is not None

# Generated at 2022-06-21 02:51:52.413134
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Mock the files to be used as input and output
    files = dict()

    # The temporary ansible file where the task will be written to
    files['/tmp/ansible'] = dict()
    files['/tmp/ansible']['content'] = ""
    files['/tmp/ansible']['mode'] = 0o777

    # The temporary ansible file where the facts will be written to
    files['/tmp/ansible_facts'] = dict()
    files['/tmp/ansible_facts']['content'] = ""
    files['/tmp/ansible_facts']['mode'] = 0o777

    # The module to be executed
    module_name = 'command'

    # The arguments to the module
    module_args = 'echo hello'


# Generated at 2022-06-21 02:52:03.875178
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    def get_module_name(module_path):
        return module_path.split("/")[-1].split(".py")[0]

    module_name = get_module_name(__file__)
    module_class = getattr(__import__(module_name, fromlist=['ActionModule']), 'ActionModule')

    task = {"args": {}, "register": "my_register"}
    tmp = '/tmp'
    task_vars = {}
    action_module = module_class(None, "dummy_path", task.copy(), tmp, task_vars=task_vars)

    task = {"args": {'key1': 'value1', 'key2': 'value2'}, "register": "my_register"}
    tmp = '/tmp'
    task_vars = {}
    action_module

# Generated at 2022-06-21 02:52:08.128837
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class TestModule(ActionModule):
        def __init__(self):
            super(TestModule, self).__init__()

    assert isinstance(TestModule(), ActionModule)

# Generated at 2022-06-21 02:52:10.279538
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert(isinstance(am, ActionBase))

# Generated at 2022-06-21 02:52:19.427326
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Test for method run of class ActionModule'''

    assert False # TODO: Implement your test here


# Generated at 2022-06-21 02:52:20.385912
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None, None, None)

# Generated at 2022-06-21 02:52:30.234321
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # By default, `cacheable` must not be set in '_ansible_facts_cacheable'
    # and `changed` must be set to `False`
    module = ActionModule(ActionBase())
    result = module.run()
    assert not result['_ansible_facts_cacheable']
    assert result['changed'] is False

    # Unless explicitly set
    module = ActionModule(ActionBase({'cacheable': 'yes'}))
    result = module.run()
    assert result['_ansible_facts_cacheable']
    assert result['changed'] is False

# Generated at 2022-06-21 02:52:30.877570
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()

# Generated at 2022-06-21 02:52:41.186045
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # verify that 'cacheable' defaults to False
    a = ActionModule(None, {}, {}, None)
    assert a.cacheable == False

    # verify that 'cacheable' is set when provided
    a = ActionModule(None, {'cacheable': True}, {}, None)
    assert a.cacheable == True

    # verify that 'cacheable' is not set when already set
    a = ActionModule(None, {'cacheable': True}, {}, None)
    a = ActionModule(None, {}, {}, None, cacheable=False)
    assert a.cacheable == True

# Generated at 2022-06-21 02:52:54.936693
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.hardware import Hardware
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.plugins.action.set_fact import ActionModule


# Generated at 2022-06-21 02:53:05.511301
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.removed import removed_module

    args = {
        'key1': 'value1',
        'key2': 'value2',
        'key3': 'value3'
    }
    tmp = None
    task_vars = dict()
    result = dict(skipped=False, changed=False)
    result.update(dict(skipped=False, changed=False))
    expected = dict(
        ansible_facts=dict(
            key1='value1',
            key2='value2',
            key3='value3'
        ),
        _ansible_facts_cacheable=False,
        ansible_facts_cacheable=False,
        skipped=False,
        changed=False
    )
   

# Generated at 2022-06-21 02:53:15.131343
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # unit test 1
    class MockActionModule(object):
        def __init__(self):
            self._task = Task()
            self._task.action = 'set_fact'
            self._task.args = dict(foo='bar')
            self._task._role = None

        def get_bin_path(self, arg, **kwargs):
            return arg

    mock_action_module = MockActionModule()
    action_module = ActionModule(mock_action_module, task_vars=dict())
    result = action_module.run(tmp=None, task_vars=dict())

    assert result['ansible_facts'] == dict(foo='bar')
    assert result['_ansible_facts_cacheable'] is False

    # unit test 2

# Generated at 2022-06-21 02:53:18.182979
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None, None)
    assert isinstance(action_module, ActionModule)


# Generated at 2022-06-21 02:53:24.886652
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = dict()
    act = ActionModule(task=dict(action=dict(module_name='facts', module_args=dict(name='foo')), args=dict(name='foo')),
                       connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    objresult = act.run(tmp, task_vars)
    assert objresult == dict(ansible_facts=dict(name='foo'))

    # Test for invalid variable names
    task_vars = dict()

# Generated at 2022-06-21 02:53:38.980241
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(dict(a=2, b=3))
    assert action.run(task_vars=dict(facts=dict())) == dict(ansible_facts=dict(a=2, b=3), _ansible_facts_cacheable=False)

# Generated at 2022-06-21 02:53:50.620328
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule(
        task=dict(
            args=dict(
                a=dict(
                    b='c',
                ),
                d='0',
                e=['long', 'list'],
                f=4711,
                g=0,
                h=True,
                i=False,
                j='0',
                k=0,
                l='True',
            ),
        ),
        connection=None,
        play_context=None,
    )
    result = a.run(tmp='/tmp/test', task_vars=dict())

    assert result['ansible_facts']['a']['b'] == 'c'
    assert result['ansible_facts']['d'] == 0
    assert result['ansible_facts']['e'][0] == 'long'
   

# Generated at 2022-06-21 02:53:53.417897
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule(None, None)
    assert x is not None

# Generated at 2022-06-21 02:54:02.750551
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    import ansible.executor.task_executor
    import sys

    context = PlayContext()
    context._ansible_debug = True
    queue_manager = TaskQueueManager(inventory=None, variable_manager=None, loader=None, options=None, passwords=None, stdout_callback=None, run_additional_callbacks=False, run_tree=False)
    context._queue_manager = queue_manager

# Generated at 2022-06-21 02:54:04.581548
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), False, False, None, None) is not None

# Generated at 2022-06-21 02:54:11.382350
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    my_obj = ActionModule(dict(ACTION=dict(module_name="debug", module_args=dict(msg='oh hai'))), dict(playbook_basedir="/home/testing/ansible"))
    my_action = my_obj.create_action()
    my_result = my_action.run(task_vars=dict(ansible_version=dict(full='2.5.1')))

    print(my_result)

if __name__ == '__main__':
    # test_ActionModule_run()
    raise Exception("Please run tests/units/module_utils/test_action_module.py to test this module")

# Generated at 2022-06-21 02:54:18.367462
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Basic unit test to exercise the constructor of class ActionModule.
    """
    action = ActionModule({'test': 1}, tmp='tmp', task_vars={}, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action.task_vars == {}
    assert action.tmp == 'tmp'



# Generated at 2022-06-21 02:54:27.663086
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = 'set_fact'
    module_name = 'main'
    action_loader = ActionBase._load_action_plugin(action_module, module_name=module_name)
    action_plugin = action_loader.action()

    # Random
    assert(action_plugin.run() != action_plugin.run())

    # Known
    task = dict(test = "foo", bar = "ok")
    task_vars = dict(foo = dict(bar = "baz"), baz = dict(foo = dict(bar = "baz")))
    result = action_plugin.run(task, task_vars)
    assert(result['ansible_facts']['test'] == 'foo')
    assert(result['ansible_facts']['bar'] == 'ok')

# Generated at 2022-06-21 02:54:37.301338
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.basic import AnsibleModule

    # Try to create a module with invalid task=
    module = AnsibleModule(argument_spec=dict(task=dict(type='invalid_type')))

    # Execution should fail with error message
    with pytest.raises(AnsibleActionFail) as err:
        am = ActionModule(module, {})
        am.run(None, None)

    assert 'must be of type' in to_native(err.value)



# Generated at 2022-06-21 02:54:49.707206
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task_include import TaskInclude

    # Adding some of the attributes of task object
    # We will be adding more to this as we need.
    task_obj = TaskInclude()
    task_obj._role = None
    task_obj._block = None
    task_obj._parent = None

    action = ActionModule(task=task_obj, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Assertion to verify the value of TaskInclude object task_obj
    assert (task_obj._role == None)
    assert (task_obj._block == None)
    assert (task_obj._parent == None)

    # Assertion to verify the instance of ActionModule class
    assert (isinstance(action, ActionModule))


# Generated at 2022-06-21 02:55:16.389517
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test for the constructor of ActionModule
    am = AnsibleActionModule()
    assert am is not None


# Generated at 2022-06-21 02:55:23.683922
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(
        fakeA=dict(
            action="fake_action",
            connection="fake_connection",
            delegate_to="fake_delegate_to",
            become=True,
            become_method="fake_become_method",
            become_user="fake_become_user"
        ),
        fake_action=dict(
            task=dict(
                args=dict(
                    mykey1="myvalue1",
                    mykey2="myvalue2"
                )
            ),
        )
    )

    assert am.task_vars == dict()
    assert am.tmpdir == None
    assert am._connection is not None
    assert am._low_level_terminal is not None
    assert am._shell is not None


# Generated at 2022-06-21 02:55:25.778254
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(None, None)
    assert not module.run()
    assert not module.run(task_vars={})
    assert not module.run(tmp=None, task_vars={'ansible_check_mode': True})
    assert not module.run(tmp=None, task_vars={'ansible_check_mode': False})

# Generated at 2022-06-21 02:55:29.707231
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class AnsibleModuleFake:
        def __init__(self):
            self.params = {}

    obj = ActionModule(AnsibleModuleFake(), {})
    assert(isinstance(obj, ActionModule))

# Generated at 2022-06-21 02:55:41.143107
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-21 02:55:43.218719
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__name__ == 'ActionModule'


# Generated at 2022-06-21 02:55:44.080474
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:55:53.546438
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Test correct variable name
    assert ActionModule.ActionBase(dict(name='set_fact', args=dict(name='foo'))).run()
    assert ActionModule.ActionBase(dict(name='set_fact', args=dict(name='foo_bar'))).run()
    assert ActionModule.ActionBase(dict(name='set_fact', args=dict(name='foo_123'))).run()
    assert ActionModule.ActionBase(dict(name='set_fact', args=dict(name='foo_bar_123'))).run()

    # Test incorrect variable name
    try:
        ActionModule.ActionBase(dict(name='set_fact', args=dict(name='1foo'))).run()
        assert False
    except:
        pass


# Generated at 2022-06-21 02:55:54.453349
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_a = ActionModule()
    assert module_a is not None

# Generated at 2022-06-21 02:55:56.905161
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actions = dict(setup=dict(cacheable=True))
    test = dict(test="test1")

    task = dict(action=actions, args=test)
    action_module = ActionModule(task, dict())

    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-21 02:56:40.175857
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = dict(skipped=False, msg=None)

    # Check that facts cannot have invalid name

# Generated at 2022-06-21 02:56:43.631213
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module

# Generated at 2022-06-21 02:56:47.189384
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule('task', 'play', True, {}, False, None)
    am.TRANSFERS_FILES = False
    assert am


# Generated at 2022-06-21 02:56:47.992171
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 02:56:53.139342
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.errors import AnsibleActionFail
    from ansible.plugins.action.set_fact import ActionModule
    from ansible.utils.pytest import AnsibleExitJson, AnsibleFailJson, ModuleTestCase, set_module_args
    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()
    from ansible.utils.vars import isidentifier

    #################################################
    # Test the method with no arguments provided
    #################################################
    module = ActionModule(
        task=dict(),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=None)


# Generated at 2022-06-21 02:56:55.090739
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), False, '/') is not None

# Generated at 2022-06-21 02:57:03.496477
# Unit test for constructor of class ActionModule
def test_ActionModule():
    host_vars = {'test_var': 'value'}
    task_vars = {
        'ansible_facts': {},
        'ansible_ssh_host': '127.0.0.1',
        'play_hosts': ['127.0.0.1'],
    }
    action_module = ActionModule({}, host_vars, task_vars)
    assert type(action_module) == ActionModule
    assert action_module._task == {}
    assert action_module._play_context == {}
    assert action_module._loaded_deps == {}
    assert action_module._templar == {}
    assert action_module._loader == {}
    assert action_module._connection == {}

    # Testing the run() method

# Generated at 2022-06-21 02:57:11.916692
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    To make the testing script work we need to define the following in our module:
    _task = None
    _connection = None
    _play_context = None
    _loader = None
    _templar = None
    '''

    # test lower to uppercase conversion of key names
    am = ActionModule()
    am._task = type("A", (), {})
    am._task.args = {'lower': 'lower'}
    am._task.args['equals'] = 'upper'
    am._task.args['list_arg'] = ['list_element']
    am._task.args['none_arg'] = None
    am._task.args['true_arg'] = 'True'
    am._task.args['false_arg'] = 'False'

# Generated at 2022-06-21 02:57:21.528845
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import random, string

    # Variables used in the test
    results = dict(skipped=False, failed=False, changed=False, ignored=False, meta={})
    task_vars = dict(ansible_facts={})

    # Arguments used as input of the function
    args_template_error = dict(_ansible_tmp=random.choice(string.ascii_letters), ansible_check_mode=False)
    args_facts_error = dict(_ansible_tmp=random.choice(string.ascii_letters), ansible_check_mode=False, facts_error=True)
    args_facts_no_args = dict(_ansible_tmp=random.choice(string.ascii_letters), ansible_check_mode=False, facts_no_args=True)
    args_facts_ok = dict

# Generated at 2022-06-21 02:57:31.632940
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule(
        {'action': {
            'add_host': {
                'hosts': ['hostname'],
                'groups': ['groupname'],
                'port': 1337,
                'variables': {'var_name': 'var_val'}}}},
        dict(connection='ssh'))
    assert x._connection == 'ssh'

    y = ActionModule(
        {'action': {
            'add_host': {
                'hosts': ['hostname'],
                'groups': ['groupname'],
                'port': 1337,
                'variables': {'var_name': 'var_val'}}}},
        dict(connection='ssh'))
    assert y._connection == 'ssh'

# Generated at 2022-06-21 02:59:17.082341
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import unittest

    class ActionModuleTestCase(unittest.TestCase):
        def test_filter(self):
            self.assertEqual(True, True)

    suite = unittest.TestSuite()
    suite.addTest(ActionModuleTestCase('test_filter'))
    return suite

# Generated at 2022-06-21 02:59:17.922266
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:59:24.765743
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    from ansible.plugins.action import ActionModule

    task_vars = dict()
    tmp = '/tmp'

    am = ActionModule(task=dict(action=dict(args=dict(), module_name='setup'), args=dict()),
                      connection=dict(), play_context=dict(check_mode=True), loader=dict(),
                      templar=dict(), shared_loader_obj=dict())
    try:
        result = am.run(tmp, task_vars)
        assert False
    except AnsibleActionFail as e:
        assert e.message == 'No key/value pairs provided, at least one is required for this action to succeed'

    os.makedirs('/tmp/action_plugins')

# Generated at 2022-06-21 02:59:27.183009
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule('plays/test-data/action_plugins/test_data/test_action_module.yml', C.DEFAULT_LOADER)
    task_vars = dict()
    facts = action_module.run(task_vars=task_vars)

    assert facts['ansible_facts'] == dict(key_3='value_3')
    assert 'changed' not in facts
    assert 'cacheable' not in facts

# Generated at 2022-06-21 02:59:33.783456
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        {'name': 'test', 'args': {'cacheable': 'yes', 'test1': 'test2'}},
        task_vars={'ansible_loops': 1},
        connection=None,
        play_context={'module_name': 'test1'},
        loader=TestLoader(),
        templar=TestTemplar(),
        shared_loader_obj=None)

    assert action.run() == {'ansible_facts': {'test1': 'test2'}, '_ansible_facts_cacheable': True, 'changed': False}


# Generated at 2022-06-21 02:59:37.197430
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Test for ActionModule.run()"""

    # Testing for action set_fact not having task_vars
    context = dict()
    context['has_task_vars'] = bool()
    task_vars = None
    tmp = None
    if ActionModule.run(ActionBase, tmp, task_vars):
        context['has_task_vars'] = True
    else:
        context['has_task_vars'] = False
    assert context['has_task_vars'] == False

# Generated at 2022-06-21 02:59:39.442929
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(action=dict())
    assert(am is not None)

# Generated at 2022-06-21 02:59:48.143457
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(cacheable=False)),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)

    assert action_module._task is not None
    assert action_module._task.args['cacheable'] is False
    assert action_module.TRANSFERS_FILES is False

# Generated at 2022-06-21 02:59:51.864237
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(load_config_file=False, task=get_dummy_task('test'), connection=get_dummy_connection(), play_context=get_dummy_play_context())
    assert isinstance(action_module, ActionModule)

