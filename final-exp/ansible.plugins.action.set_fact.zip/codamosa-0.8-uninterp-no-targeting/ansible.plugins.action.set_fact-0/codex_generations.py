

# Generated at 2022-06-21 02:50:02.394677
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=None)
    assert action_module

# Generated at 2022-06-21 02:50:02.896187
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.TRANSFERS_FILES == False

# Generated at 2022-06-21 02:50:14.350425
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule({}, {})
    m._task = {
        'action': 'set_fact',
        'args': {
            'fact1': 'value1',
            'fact2': 'value2',
            'fact3': '"value3"',
            'fact4': '''value4''',
            'fact5': 42,
            'fact6': 'True',
            'fact7': 'False',
            'fact8': 'Yes',
            'fact9': 'No',
            'fact10': 'YES',
            'fact11': 'NO',
            'fact12': 'yes',
            'fact13': 'no',
        }
    }


# Generated at 2022-06-21 02:50:22.720650
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor import task_executor
    from ansible.playbook.task import Task

    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    module = 'debug'

    spec = dict(
        _ansible_no_log = dict(type = 'bool'),
        _ansible_check_mode = dict(type = 'bool'),
        _ansible_debug = dict(type = 'bool'),
        _ansible_verbosity = dict(type = 'int'),
    )

    # We need a task_vars dict, so we create one.
    # It also needs a ansible_facts dict
    task_vars = dict(
        ansible_facts = dict()
    )

    # We need a loader, so we create one.
    loader

# Generated at 2022-06-21 02:50:33.183729
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible_collections.ansible.community.tests.unit.mock.loader import DictDataLoader

    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    from ansible.vars.manager import VariableManager

    # Prepare test data

# Generated at 2022-06-21 02:50:42.981313
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule(dict(a='a',b='b',c='foo: bar\n',d='null'),dict(ANSIBLE_MODULE_ARGS=dict(a='a',b='b',c='foo: bar\n',d='null'),ANSIBLE_FACTS=dict(a='a',b='b',c='foo: bar\n',d='null')))
    assert a._task.action == 'set_fact'
    assert a._task.args == {'a': 'a', 'b': 'b', 'c': 'foo: bar\n', 'd': 'null'}
    assert a.run(tmp='/private/var/folders/bd/9d97k2_92zq3sq709847wjb80000gn/T', task_vars=dict())['ansible_facts']

# Generated at 2022-06-21 02:50:47.022790
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    am = ActionModule(Task(), PlayContext(), None)
    vm = VariableManager(InventoryManager())
    result = am.run(task_vars=dict())
    assert result == dict(failed=True)

# Generated at 2022-06-21 02:50:48.457457
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(ActionModule is not None)

# Generated at 2022-06-21 02:50:51.660396
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Positive test cases
    module = ActionModule()
    assert(module)
    assert(type(module) == ActionModule)
    # Negative test cases
    # module = ActionModule(1) #TypeError: object.__new__() takes no parameters

# Generated at 2022-06-21 02:50:54.115501
# Unit test for constructor of class ActionModule
def test_ActionModule():
    fixture = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert fixture

# Generated at 2022-06-21 02:51:02.641907
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a1 = ActionModule(dict(name="test_action", action="test_action"), '')
    assert a1 is not None
    assert a1._name == "test_action"
    assert a1._action == "test_action"

# Generated at 2022-06-21 02:51:14.230439
# Unit test for constructor of class ActionModule
def test_ActionModule():

    class VariableManager():
        def __init__(self):
            self.vars = dict()

        def get_vars(self):
            return self.vars

        def set_host_variable(self, host, varname, value):
            self.vars[varname] = value

    class Task():
        def __init__(self):
            self.args = dict()

    class Play():
        def __init__(self):
            self.play_context = dict()

    class Base():
        def __init__(self):
            self.play = Play()

    class PlayContext():
        def __init__(self):
            self.args = dict()

    class FakeModule():
        def __init__(self):
            self.name = 'test'
            self.params = dict()


# Generated at 2022-06-21 02:51:23.850305
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print ("\n********************** test_ActionModule **********************\n")
    import ansible.inventory
    import ansible.playbook.task
    import ansible.utils.template
    import ansible.vars

    # This is a basic inventory for our tests.
    localhost = ansible.inventory.host.Host("localhost")
    localhost.vars = ansible.vars.VariableManager()
    localhost.vars.clear_vars()
    localhost.vars["ansible_connection"] = "local"
    localhost.vars['ansible_python_interpreter'] = '/home/brent/.pyenv/versions/ansible/bin/python'
    localhost.vars['ansible_python_interpreter'] = '/usr/bin/python'


# Generated at 2022-06-21 02:51:25.947293
# Unit test for constructor of class ActionModule
def test_ActionModule():
    cls = ActionModule()
    assert cls.TRANSFERS_FILES == False

# Generated at 2022-06-21 02:51:35.685614
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ac = dict(
        _ansible_no_log=False,
        ansible_check_mode=False,
        ansible_module_name='debug',
        ansible_version={'full': '2.0.0.2-dev', 'major': 2, 'minor': 0, 'revision': 0, 'string': '2.0.0.2-dev'},
        modified_time_command='1419097584.81467',
        path='/usr/bin:/bin:/usr/local/bin',
        remote_addr='10.0.0.1',
        remote_user='root',
        session_id='ff1a74a2-0b1d-4d4f-ae50-a04c4dd78afd'
    )


# Generated at 2022-06-21 02:51:38.969733
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    This is a test for the constructor of the class.
    """

    assert isinstance(ActionModule, object)


# Generated at 2022-06-21 02:51:40.906803
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = Dummy()
    am = ActionModule(task, {}, {}, 'dummy')
    print(am.run())


# Generated at 2022-06-21 02:51:52.909280
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    class FakeTask(object):
        def __init__(self):
            self.args = dict(var1='foo')
            self.action = 'fake_action'

    class FakeTaskVars(object):
        def __init__(self):
            self.variable_manager = None

    class FakeTemplar(object):
        def __init__(self):
            self.available_variables = dict(var1='foo', var2='bar')

        def template(self, value):
            return self.available_variables[value]

    class FakeModule_Utils(object):
        @staticmethod
        def isidentifier(value):
            return value != 'var2'


# Generated at 2022-06-21 02:52:04.070804
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # construct an instance of the ActionModule class
    am = ActionModule(dict(), dict())

    # Assert class instance variables
    assert am.action_name == 'set_fact'
    assert am.async_val == None
    assert am.become == False
    assert am.become_method == None
    assert am.become_user == False
    assert am.cacheable == False
    assert am.connection == 'smart'
    assert am.delegate_to == None
    assert am.delay == None
    assert am.delete_remote_tmp == True
    assert am.diff == False
    assert am.failed_when == None
    assert am.free_form == True
    assert am.jid == None
    assert am.name == None
    assert am.no_log == False
    assert am.notify == None

# Generated at 2022-06-21 02:52:14.878644
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit test for method run of class ActionModule
    """

    # Mock objects, needed for the unit test
    class MockActionModule(object):
        def __init__(self):
            self.action = 'setup'
            self.task_vars = dict()
            self.tmp = None
            self.runner_path = '/home/vagrant/ansible/'

# Generated at 2022-06-21 02:52:35.262356
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import tempfile
    from ansible.utils._text import to_bytes
    from ansible.plugins.action import ActionBase

    # Setup tempfile for Ansible facts
    fd, facts_path = tempfile.mkstemp(prefix='ansible_plugin_facts_')

    # Write static facts to tempfile
    with open(facts_path, 'wb') as facts_file:
        facts_file.write(b"---\n")
        facts_file.write(b"ansible_facts:\n")
        facts_file.write(b"  fact1: value1\n")

    # Setup tempfile for dynamic facts
    fd, dynamic_facts_path = tempfile.mkstemp(prefix='ansible_plugin_facts_')

    # Write dynamic facts to tempfile

# Generated at 2022-06-21 02:52:38.281699
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, None, None, None)
    assert module


if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-21 02:52:46.159882
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils._text import to_bytes

    action = ActionModule()

    class MockActionModule(object):

        def fail_json(self, *args, **kwargs):
            print(args, kwargs)

    class MockTemplar(object):

        def template(self, value):
            return value

    class MockTask(object):

        def __init__(self):
            self.args = {}

    action._task = MockTask()

# Generated at 2022-06-21 02:52:52.872180
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task

    set_command_called = False
    def set_command(value):
        global set_command_called
        set_command_called = True
    # create an ActionModule instance and call its run method
    action_module_instance = ActionModule(Task(), dict(msg='test'), set_command=set_command)
    action_module_instance.run()
    # verify the set_command() method was called
    assert(set_command_called)

# Generated at 2022-06-21 02:52:59.261667
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    print(action)

    assert(action is not None)
    assert(type(action) is ActionModule)
# end of test_ActionModule

# Generated at 2022-06-21 02:53:06.779958
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test 1
    task_1 = dict(
        args=dict(
            ansible_os_family='RedHat',
            ansible_distribution='Fedora'
        )
    )

    task_vars_1 = dict()
    templar_1 = None
    tmp_1 = None
    action1 = ActionModule(task_1, templar_1, tmp_1, task_vars_1)

    result_1 = action1.run()
    assert result_1['ansible_facts'] == {'ansible_os_family': 'RedHat', 'ansible_distribution': 'Fedora'}

    # Test 2
    task_2 = dict(args={})
    task_vars_2 = dict()
    templar_2 = None
    tmp_2 = None
    action2

# Generated at 2022-06-21 02:53:09.743724
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(
            args=dict()
        ),
        connection=dict()
    )
    assert module is not None

# Generated at 2022-06-21 02:53:12.666944
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(action=dict(module_name='foo', module_args='bar'))
    assert am._task.action == 'foo'
    assert am._task.args == 'bar'


# Generated at 2022-06-21 02:53:22.574556
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule(complex_args={'test_var1': 'test_val1', 'test_var2': 'test_val2', 'test_var3': 'test_val3'})
    result = a.run(task_vars={'test_var1': 'test_val1', 'test_var2': 'test_val2', 'test_var3': 'test_val3'})
    assert result['ansible_facts'] == {'test_var1': 'test_val1', 'test_var2': 'test_val2', 'test_var3': 'test_val3'}
    assert result['_ansible_facts_cacheable'] is False


# Generated at 2022-06-21 02:53:26.349240
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None)
    assert isinstance(action_module, ActionModule), \
        'ActionModule is not a class type of ActionModule'

# Generated at 2022-06-21 02:53:49.062331
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None)
    assert type(action).__name__ == 'ActionModule'

# Generated at 2022-06-21 02:53:51.310566
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 02:53:55.005687
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionmodule = ActionModule()
    tmp = None
    task_vars = dict()
    result = actionmodule.run(tmp, task_vars)
    assert not result['ansible_facts']


# Generated at 2022-06-21 02:53:58.232989
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class TestVarsModule(ActionModule):
        def run(self, tmp, task_vars=None):
            return super(TestVarsModule, self).run(tmp, task_vars=task_vars)

    module = TestVarsModule(dict(), dict())
    assert module

# Generated at 2022-06-21 02:53:58.886455
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-21 02:54:10.073035
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import cStringIO

    # Save the current stdout
    stdout = sys.stdout

# Generated at 2022-06-21 02:54:21.702674
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(
        task=dict(),
        connection=dict(),
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    # test run with no cacheable argument provided
    facts = dict(foo='bar')
    result = action_module.run(tmp=None, task_vars=dict(), args=facts)
    assert result['changed'] is False
    assert result['ansible_facts'] == facts
    assert result['_ansible_facts_cacheable'] is False

    # test run with cacheable argument provided
    facts = dict(foo='bar')
    result = action_module.run(tmp=None, task_vars=dict(), args=dict(cacheable=True, **facts))
    assert result['changed'] is False

# Generated at 2022-06-21 02:54:30.839244
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a dummy module for testing with
    dummy_module = dict(
        NAMESPACE='',
        MODULE_ARGS='',
    )
    # create a dummy task for testing with
    dummy_task = dict(
        ACTION='',
        MODULE_ARGS='',
        _ansible_verbosity=0,
        task_vars=dict(),
        _raw_params='',
    )
    # create a dummy args for testing with
    dummy_module_args = dict()
    # create a dummy template class for testing with
    dummy_template_class = dict()
    # create a dummy loader class for testing with
    dummy_loader_class = dict()

    # create a ActionModule object

# Generated at 2022-06-21 02:54:40.768237
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 02:54:45.402288
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils.facts
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution.alpine
    import ansible.module_utils.facts.system.distribution.arch
    import ansible.module_utils.facts.system.distribution.debian
    import ansible.module_utils.facts.system.distribution.sles
    import ansible.module_utils.facts.system.distribution.ubuntu
    import ansible.module_utils.facts.system.distribution.redhat
    import ansible.module_utils.facts.system.distribution.fedora
    import ansible.module_utils.facts.system.distribution.openbsd
    import ansible.module_

# Generated at 2022-06-21 02:55:38.437024
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:55:41.409264
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.runner import Runner
    from ansible.playbook import PlayBook
    from ansible.playbook import Play
    from ansible.playbook import Task
    from ansible.inventory import Inventory
    # Create the Runner object based on the blank class, without arguments
    am = ActionModule(task=Task())
    print("Init Action Module")
    print("Print the arguments")
    print(am)
    print("Done")


# Generated at 2022-06-21 02:55:42.885196
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, "Test not implemented"

# Generated at 2022-06-21 02:55:43.706677
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:55:53.208393
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arrange
    tmp = None
    task_vars = dict()
    action_module = ActionModule(None, None, tmp, task_vars, None)
    action_module._task.args = dict()
    # Act 1
    result = action_module.run(tmp, task_vars)
    # Assert 1
    assert not result['changed']
    assert 'ansible_facts' not in result
    assert '_ansible_facts_cacheable' not in result
    # Act 2
    action_module._task.args = dict(my_fact=dict(my_subfact=123, my_subfact_2='123'))
    result = action_module.run(tmp, task_vars)
    # Assert 2
    assert not result['changed']
    assert 'ansible_facts' in result


# Generated at 2022-06-21 02:55:54.285843
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, dict(), None, None, None).__class__.__name__ == 'ActionModule'

# Generated at 2022-06-21 02:55:55.601749
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule("_test_with_a_var=foo a=b")
    assert type(a) is ActionModule

# Generated at 2022-06-21 02:56:02.422540
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = {
        'ansible_distribution': 'Ubuntu',
        'ansible_distribution_major_version': '12'
    }

    args = {
        'g': '42',
        'h': '46'
    }

    from ansible.plugins.action import ActionModule
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Mock ActionModule.run() method to have access to local variables
    def run(tmp, task_vars):
        results = {}
        results['ansible_facts'] = locals().get('facts')
        results['_ansible_facts_cacheable'] = locals().get('cacheable')
        return results


# Generated at 2022-06-21 02:56:12.706378
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    import pytest
    
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict

    action = ActionModule()
    action._templar = basic.AnsibleModule(
        argument_spec=dict()
    )

    # Our test task
    def test_task(action, task_vars=None, result='changed'):
        if task_vars is None:
            task_vars = {}

        task = ImmutableDict(
            action=dict(
                name='setup',
                args=action
            )
        )

        # Our task's result

# Generated at 2022-06-21 02:56:21.013586
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule(task=dict(action=dict(module_name="set_fact", args=dict(a="a"))))
    actionModule._task.args.update(dict(a="a"))
    result = actionModule.run(tmp=None, task_vars=None)
    assert 'ansible_facts' in result
    assert result['ansible_facts'] == {'a':'a'}
    assert '_ansible_facts_cacheable' in result
    assert result['_ansible_facts_cacheable'] == False


# Generated at 2022-06-21 02:58:19.246604
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_mod = ActionModule()
    action_mod.set_loader()

    # test __init__ method
    assert action_mod._shared_loader_obj != None

# Generated at 2022-06-21 02:58:31.906388
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(argument_spec={}, supports_check_mode=True)
    module.add_host('host1', port=22, hostname='host1')
    module.set_task(dict(action='set_fact', args={'a':1, 'b':2, 'foo': '"bar"'}, delegate_to='host1', name='set_facts'))
    module._templar = module._shared_loader_obj.templar
    results = module.run(task_vars=dict())

    assert results['ansible_facts']['a'] == 1
    assert results['ansible_facts']['b'] == 2
    assert results['ansible_facts']['foo'] == 'bar'
    assert results['ansible_facts']['ansible_fqdn'] == 'host1'

# Generated at 2022-06-21 02:58:43.198885
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(None, {}, None, {}, None)
    declaration = dict()

    with pytest.raises(AnsibleActionFail) as excinfo:
        action.run(None, None)
    assert str(excinfo.value) == 'No key/value pairs provided, at least one is required for this action to succeed'

    declaration['fact1'] = 'value1'
    declaration['fact2'] = 'value2'
    declaration['fact3'] = 'value3'
    declaration['fact4'] = '{{ fact3 }}'
    declaration['fact5'] = [1, 2, 3, 4]
    declaration['fact6'] = {'k': 'v'}
    declaration['cacheable'] = False

    result = action.run(None, declaration)

    expected = dict()

# Generated at 2022-06-21 02:58:52.167593
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialization
    actionModule = ActionModule()

    # Test when no args is passed
    try:
        actionModule.run()
    except AnsibleActionFail as e:
        assert(e.message == 'No key/value pairs provided, at least one is required for this action to succeed')

    # Test when invalid args is passed
    try:
        actionModule.run(task_vars = dict(stdout_lines='abc'))
    except AnsibleActionFail as e:
        assert(e.message == "The variable name 'stdout_lines' is not valid. Variables must start with a letter or underscore character, "
                            "and contain only letters, numbers and underscores.")


# Generated at 2022-06-21 02:58:54.976272
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ac = ActionModule(None, {})
    assert not ac.run(None, None)

# Generated at 2022-06-21 02:59:03.475760
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    return_value_ansible_facts = {}
    return_value_ansible_facts_cacheable = False
    return_value = {'ansible_facts': return_value_ansible_facts, '_ansible_facts_cacheable': return_value_ansible_facts_cacheable}
    return_value_run = {}
    return_value_run['ansible_facts'] = return_value_ansible_facts
    return_value_run['_ansible_facts_cacheable'] = return_value_ansible_facts_cacheable

    mock_run = mocker.patch('ansible.plugins.action.setvars.ActionModule.run', return_value=return_value_run)

    tmp = 'tmp'
    task_vars = 'task_vars'

# Generated at 2022-06-21 02:59:05.358951
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert hasattr(a, 'run')

# Generated at 2022-06-21 02:59:11.052161
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule"""
    action = ActionModule()
    action._task.args = {'cacheable': False}
    action._templar.template = lambda x: x
    result = action.run()
    assert result['_ansible_facts_cacheable'] == False
    assert 'ansible_facts' in result

# Generated at 2022-06-21 02:59:22.455703
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule(None, dict(name='actionModule', src=None))
    facts = dict(foo='bar')
    actionModule._task.args = facts
    result = actionModule.run(None, dict())
    assert 'ansible_facts' in result
    assert result['ansible_facts'] == facts
    assert result['_ansible_facts_cacheable'] == False

    actionModule = ActionModule(None, dict(name='actionModule', src=None))
    facts = dict(a='foo', b='bar')
    actionModule._task.args = facts
    result = actionModule.run(None, dict())
    assert 'ansible_facts' in result
    assert result['ansible_facts'] == facts
    assert result['_ansible_facts_cacheable'] == False


# Generated at 2022-06-21 02:59:33.419339
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    try:
        res = module.run(tmp='/tmp/tmp', task_vars='task_vars')
        assert False, 'Expected AnsibleActionFail was not thrown'
    except AnsibleActionFail as e:
        assert True, 'Expected AnsibleActionFail was thrown'
        assert str(e) == 'No key/value pairs provided, at least one is required for this action to succeed'

    try:
        res = module.run(tmp='/tmp/tmp', task_vars='task_vars', invalid='invalid')
        assert False, 'Expected AnsibleActionFail was not thrown'
    except AnsibleActionFail as e:
        assert True, 'Expected AnsibleActionFail was thrown'