

# Generated at 2022-06-21 02:50:03.401454
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:50:08.370812
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Instance of class ActionModule
    actionModule = ActionModule([{'variable_name': 'variable_value'}], 'path_to_ansible_module', 'path_to_ansible_module')

    # Check if facts are set correctly
    assert actionModule.run({})['ansible_facts'] == {'variable_name': 'variable_value'}

# Generated at 2022-06-21 02:50:17.677721
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=dict(args=dict()), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)._templar is None
    assert ActionModule(task=dict(args=dict()), connection=None, play_context=None, loader=None, templar=object(), shared_loader_obj=None)._templar is not None
    assert ActionModule(task=dict(args=dict()), connection=None, play_context=None, loader=None, templar=object(), shared_loader_obj=None).loader is None
    assert ActionModule(task=dict(args=dict()), connection=None, play_context=None, loader=object(), templar=None, shared_loader_obj=None).loader is not None

# Generated at 2022-06-21 02:50:24.966951
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # given
    import ansible.plugins.action.set_fact
    module = ansible.plugins.action.set_fact.ActionModule(
        {'shell': '/bin/sh', '_uses_shell': True, 'ansible_facts': {}, 'ansible_version': {'full': 'v2.0', 'major': 2, 'minor': 0}},
        task_vars=[{}],
        runner_paths=[],
    )
    # when
    result = module.run({'first':1}, {'second':2})
    # then
    assert result['ansible_facts'] == {'first':1}

# Generated at 2022-06-21 02:50:26.892629
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, "Unit tests for ActionModule.run not implemented"

# Generated at 2022-06-21 02:50:34.472067
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils._text import to_text, to_bytes
    from ansible.module_utils.common._collections_compat import Mapping, Sequence
    from ansible.module_utils.parsing.convert_bool import boolean
    import ansible.module_utils.basic as basic
    import ansible.module_utils.legacy_vars as legacy_vars

    def run_module(*args, **kwargs):
        basic._ANSIBLE_ARGS = to_bytes(args[0])
        myargs = args[0].split()
        myargs.append('A=1')
        setattr(basic, 'ARGS', myargs)
        setattr(basic, 'MODULE_ARGS', kwargs)

# Generated at 2022-06-21 02:50:40.115523
# Unit test for constructor of class ActionModule
def test_ActionModule():
    arguments={'banner': 'BANNER', 'cacheable': False, 'name': 'NAME', 'state': 'STATE'}
    tmp=None
    task_vars={}
    action_base=ActionBase()
    action_module=ActionModule(action_base._connection, action_base._templar, action_base._loader, action_base._shared_loader_obj, arguments, tmp, task_vars)
    assert action_module.run(tmp, task_vars)

# Generated at 2022-06-21 02:50:50.094646
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(
        {'name': 'set_fact',
         'cacheable': False,
         '_ansible_no_log': False,
         'action': 'set_fact',
         'args': {'speed': 'fast'}},
        load_pickle=False,
    )
    result = module.run(None, {'ansible_user': 'dag'})
    assert result['ansible_facts']['speed'] == 'fast'
    assert '_ansible_facts_cacheable' not in result

# Generated at 2022-06-21 02:51:03.222274
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 02:51:04.063010
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:51:20.860698
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.facts import is_local

    # Create test context
    variable_manager = DictData()
    loader = DictData()
    localhost = DictData()
    localhost['hostname'] = 'localhost'
    localhost['uid'] = '0'
    localhost['user'] = 'root'
    localhost['gid'] = '0'
    localhost['group'] = 'root'
    localhost['groups'] = [ 'root' ]
    localhost['shell'] = '/bin/sh'
    localhost['system'] = 'Linux'
    localhost['environment'] = {}
    localhost['python_version'] = '2.6.9'
    localhost['python_bin'] = '/usr/bin/python'

# Generated at 2022-06-21 02:51:22.880421
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # assert that no exception is raised when the constructor is called
    assert True

# Generated at 2022-06-21 02:51:25.307585
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("test_ActionModule_run()")
    assert ActionModule().run() == None

# Generated at 2022-06-21 02:51:33.436912
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = dict(
        action=dict(
            module='set_fact',
            args=dict(
                foo='bar',
                zoo='loo',
                moo='foo',
            )
        )
    )
    tmp = dict(
        ANSIBLE_MODULE_ARGS=dict(
            foo='bar',
            zoo='loo',
            moo='foo',
        )
    )
    task_vars = dict()

    am = ActionModule(task, tmp)
    result = am.run(task_vars=task_vars)

    assert result['changed'] is False
    assert result['ansible_facts'] == dict(foo='bar', zoo='loo', moo='foo')
    assert result['_ansible_facts_cacheable'] is False

# Generated at 2022-06-21 02:51:37.056038
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.playbook_executor import PlaybookExecutor

    from ansible import context
    context._init_global_context(None)


# Generated at 2022-06-21 02:51:39.891117
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' create an instance of ActionModule() and generate sample json output '''
    action_mod = ActionModule()
    print(action_mod._get_action_args())


# Generated at 2022-06-21 02:51:51.268465
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(loader=None, task=None, connection=None, play_context=None, loader_cache=None, templar=None, shared_loader_obj=None)
    result = module.run(tmp=None, task_vars=None)
    assert result == {}

# -------------------------------------------------------------------------------------------------
# Unit: ansible.module_utils.facts.get_distribution
# -------------------------------------------------------------------------------------------------
# Unit: ansible.module_utils.facts.get_distribution_version
# -------------------------------------------------------------------------------------------------
# Unit: ansible.module_utils.facts.get_platform_subclass
# -------------------------------------------------------------------------------------------------
# Unit: ansible.module_utils.facts.get_virtual
# -------------------------------------------------------------------------------------------------

# Generated at 2022-06-21 02:51:54.026816
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action.__class__.__name__ == 'ActionModule'

# Generated at 2022-06-21 02:52:04.350287
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        import ansible.modules.system.set_fact
        ansible.modules.system.set_fact = None
    except:
        pass
    import sys
    sys.modules['ansible.modules.system.set_fact'] = None

    # Basic test:
    set_fact_action_module = ActionModule()
    assert set_fact_action_module is not None

    # Test:
    task_vars = {}
    set_fact_action_module._task.args = {}
    set_fact_action_module._task.args['key1'] = 'value1'
    set_fact_action_module._task.args['key2'] = 'value2'
    set_fact_action_module._task.args['key3'] = 'value3'
    res = set_fact_action_module.run

# Generated at 2022-06-21 02:52:08.843351
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.module_utils.basic import AnsibleModule
    import ansible.constants as C
    import os
    import sys

    C.HOST_KEY_CHECKING = False
    C.DEFAULT_JINJA2_NATIVE = False
    os.environ['ANSIBLE_HOST_KEY_CHECKING'] = 'False'
    sys.modules['ansible.module_utils.basic'] = AnsibleModule

    task_ds = dict(
        action=dict(module=dict(name='set_facts', args=dict(x=1, y=2, z=3))))
    play_context = PlayContext()
   

# Generated at 2022-06-21 02:52:20.009018
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    atm = ActionModule(TaskResult('test'), dict(test_task_vars=dict()))
    atm.run(None, dict())
    assert False, 'ActionModule.run method is not tested'

# Generated at 2022-06-21 02:52:32.440808
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader
    from ansible.playbook.play_context import PlayContext

    mock_play_context = PlayContext()
    mock_play_context.become = True
    mock_play_context.become_method = 'sudo'
    mock_play_context.become_user = 'dan'

    mod = action_loader.get('set_fact',
                            task=dict(args=dict(one=1,
                                                two=2,
                                                three=3)),
                            connection=dict(module_implementation_preferences=None),
                            play_context=mock_play_context,
                            loader=None,
                            templar=None)

    assert mod._task.args == dict(one=1, two=2, three=3)

# Generated at 2022-06-21 02:52:40.933960
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Test method run of class ActionModule"""
    errstring=None
    try:
        am = ActionModule()
        am.run(tmp=None, task_vars=None)
    except Exception as e:
        errstring = "An error occurred calling ActionModule.run: %s" % str(e)
    assert errstring is None, errstring

if __name__ == "__main__":
    import sys
    import pytest
    pytest.main(sys.argv)

# Generated at 2022-06-21 02:52:43.902524
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action =  ActionModule(load_plugins=False)
    assert action.__class__.__name__ == 'ActionModule'

# Generated at 2022-06-21 02:52:54.605112
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    results = dict(changed=False, ansible_facts={})
    results_cacheable = dict(changed=False, _ansible_facts_cacheable=True, ansible_facts={})
    action = ActionModule(task=dict(
        args=dict(x=1, y=2, z=3)
    ), tmp=None, task_vars=task_vars)
    results_cacheable.update(action.run(tmp=None, task_vars=task_vars))
    assert results_cacheable == dict(changed=False, _ansible_facts_cacheable=True, ansible_facts=dict(x=1, y=2, z=3))

# Generated at 2022-06-21 02:52:59.029483
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module is not None

# Generated at 2022-06-21 02:53:06.712180
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager)
    variable_manager.set_inventory(inventory)
    fake_loader = fixture_loader()
    pm = Play().load(fake_loader, variable_manager=variable_manager, loader=loader)
    tqm = None
    block = Block()

# Generated at 2022-06-21 02:53:09.246142
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, dict(key=1, value=2))
    assert module is not None


# Generated at 2022-06-21 02:53:17.226615
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    FAKE_ARGS = {'ansible_facts': {'first_name': 'Dummy', 'last_name': 'User'}}
    FAKE_ARGS_NO_KEY_VALUE_PAIR = {}
    FAKE_ARGS_INVALID_NAME = {'ansible_facts': {'1st_name': 'Dummy', 'last_name': 'User'}}
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.play_iterator import PlayIterator
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.role.task import Task as RoleTask

# Generated at 2022-06-21 02:53:24.638283
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import copy
    import json

    from ansible.module_utils.facts.virtual.bochs import BochsFactCollector
    from ansible.module_utils.facts.virtual.bhyve import BhyveFactCollector
    from ansible.module_utils.facts.virtual.openvz import OpenvzFactCollector
    from ansible.module_utils.facts.virtual.qemu import QemuFactCollector
    from ansible.module_utils.facts.virtual.vbox import VboxFactCollector
    from ansible.module_utils.facts.virtual.vmware import VMwareFactCollector
    from ansible.module_utils.facts.virtual.xen import XenFactCollector

    class FakeVirtWhat(object):
        def __init__(self):
            self.all = []

    # make sure we

# Generated at 2022-06-21 02:53:47.043191
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # The constructor of class ActionModule takes no arguments
    # This is a very basic test to ensure it is callable
    ActionModule()
    # TODO: Add more tests


# Generated at 2022-06-21 02:53:49.875362
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arrange
    import ansible.plugins.action.set_fact

    # Act
    action = ansible.plugins.action.set_fact.ActionModule(None, None, None, None)

    # Assert
    assert action is not None

# Generated at 2022-06-21 02:53:55.166888
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Simply creating an instance of ActionModule should work
    try:
        am = ActionModule(play_context={}, connection={}, loader={}, templar={}, shared_loader_obj={})
    except:
        raise AssertionError("Unable to instantiate ActionModule")

# Generated at 2022-06-21 02:53:56.866628
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module is not None


# Generated at 2022-06-21 02:54:04.196778
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_module_args({'key': 'value'})

    module = ActionModule()

    assert module.run() == {
        'ansible_facts': {
            'key': 'value',
        },
        '_ansible_facts_cacheable': False,
        '_ansible_no_log': False,
    }

# Generated at 2022-06-21 02:54:06.527989
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, {}, {}, {})
    assert isinstance(am, ActionBase)

# Generated at 2022-06-21 02:54:16.214575
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_loader = DummyLoader()
    mock_play_context = DummyPlayContext()
    mock_task = DummyTask()

    mock_task.action = 'dict2facts'
    mock_task.args = {
        "key1": "value1",
        "key2": "value2",
    }

    action_module = ActionModule(mock_loader, mock_play_context, mock_task)

    assert action_module is not None


# Generated at 2022-06-21 02:54:23.578062
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def get_action(args):
        return ActionModule({'args': args}, {'action': 'name'})

    action = get_action({'a': 'b'})
    output = action.run()
    assert output == dict(ansible_facts=dict(a='b'), _ansible_facts_cacheable=False)

    action = get_action({'a': '{{b}}'})
    output = action.run(task_vars={'b': 'c'})
    assert output == dict(ansible_facts=dict(a='c'), _ansible_facts_cacheable=False)

    action = get_action({'a': '"{{b}}"'})
    output = action.run(task_vars={'b': 'c'})

# Generated at 2022-06-21 02:54:31.315737
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = AnsibleModule({'a': '1', 'b': '2'})
    assert ActionModule(module, {'a': '1', 'b': '2'}).run({}) == {'ansible_facts': {u'a': 1, u'b': 2}, '_ansible_facts_cacheable': False, '_ansible_no_log': False}
    assert ActionModule(module, {'a': "'a'"}).run({}) == {'ansible_facts': {u'a': u'a'}, '_ansible_facts_cacheable': False, '_ansible_no_log': False}

# Generated at 2022-06-21 02:54:40.933140
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 02:55:29.029349
# Unit test for constructor of class ActionModule
def test_ActionModule():
    my_module = ActionModule(None, dict())

    assert my_module.TRANSFERS_FILES is False

# Generated at 2022-06-21 02:55:33.565966
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create mock objects
    module = ActionModule()
    tmp = '/tmp/test'
    facts = [
        {'key': 'value'},
        {'key': 'value'},
    ]
    result = dict(
        ansible_facts=facts,
        _ansible_facts_cacheable=False,
        _ansible_no_log=False,
    )
    # Execute method run
    result_run = module.run(tmp, task_vars=facts)
    # Verify results
    assert result == result_run

# Generated at 2022-06-21 02:55:37.967051
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(task=dict(args={'k': 'v'}))
    assert module.run({})['ansible_facts'] == {'k': 'v'}


# Generated at 2022-06-21 02:55:45.414332
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import json

    from ansible.utils.vars import combine_vars

    # Construct arguments of method run
    tmp = None
    task_vars = {}

    amr = ActionModule()

    # Create instance
    am = ActionModule()
    am._task = type('', (), {})()
    am._task.args = {'cacheable': True}

    # Execute method run
    retval = am.run(tmp, task_vars)

    # Execute method run with arguments

    # Construct arguments of method run
    tmp = None
    task_vars = {}

    amr = ActionModule()

    # Create instance
    am = ActionModule()
    am._task = type('', (), {})()
    am._task.args = {'cacheable': False}

    # Execute method run
    retval

# Generated at 2022-06-21 02:55:53.810887
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit test for method run of class ActionModule'''

    ac = ActionModule(None, None, None, None)

    # Test with empty args
    with pytest.raises(AnsibleActionFail) as excinfo:
        ac.run(tmp='/tmp', task_vars={})
        assert "No key/value pairs provided, at least one is required for this action to succeed" in excinfo.value
        assert "provide_facts_dict.py:60" in excinfo.value

    # Test with some facts, but unallowed characters in variable names
    with pytest.raises(AnsibleActionFail) as excinfo:
        ac.run(tmp='/tmp', task_vars={}, args={'****':'value', '$$$':'value'})

# Generated at 2022-06-21 02:56:01.415909
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.errors import AnsibleActionFail
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import isidentifier
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    import io

    # Create a mocked task object
    class AnsibleTask():
        def __init__(self):
            self.args = {'a': '1', 'b': '2'}

        def _execute_module(self):
            pass

    # Create a mocked templar object

# Generated at 2022-06-21 02:56:12.540606
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import MacOSXDistribution
    from ansible.module_utils.facts.system.distribution import OpenBSDDistribution
    from ansible.module_utils.facts.system.distribution import SolarisDistribution
    from ansible.module_utils.facts.system.distribution import SunOSDistribution

    # Mock class
    distribution = Distribution()

    # Test linux
    facts = {}
    distribution.detect(facts)
    assert isinstance(distribution, LinuxDistribution)

    # Test macOS
    facts = {'distribution': 'Darwin'}
    distribution.detect(facts)

# Generated at 2022-06-21 02:56:18.227817
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionmodule = ActionModule()
    result = {'ansible_facts': {}, '_ansible_facts_cacheable': False}

    assert actionmodule.run(task_vars={}) == result
    assert actionmodule.run(task_vars={}) == result

# Generated at 2022-06-21 02:56:23.271493
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = { "args": { "cacheable": "yes", "myvar": "a" } }
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils import basic

    class MyModule(basic.AnsibleModule):

        def __init__(self):
            basic.AnsibleModule.__init__(self, argument_spec={})

    action = ActionModule(task, MyModule())
    result = action.run(task_vars=dict(myvar="b"))
    assert result["ansible_facts"]["myvar"] == "a"
    assert result["_ansible_facts_cacheable"] is True

# Generated at 2022-06-21 02:56:29.801528
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Test bad input
    args = dict(bad_input1 = 1)
    actionModule.run(task_vars = dict(),tmp =1,args= args)

# Generated at 2022-06-21 02:58:12.444332
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 02:58:21.798766
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a dummy task
    module_args = {'name': 'John', 'age': 21}
    class Task:
        def __init__(self):
            self.args = module_args
    task = Task()

    am = ActionModule(task, {})

    # run the module
    tmp = None
    task_vars = {}
    result = am.run(tmp, task_vars)

    # assert the result
    assert result['ansible_facts'] == module_args
    assert result['_ansible_facts_cacheable'] is False
    assert result['changed'] is False
    assert result['failed'] is False

# Generated at 2022-06-21 02:58:32.252058
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json

    module = ActionModule()
    module._task = type('task', (object, ), {'args': {'foo': 'bar'}})
    module._task.action = 'vars'
    module._task.args = {'foo': 'bar'}
    module._task.args['cacheable'] = False
    module._templar = type('templar', (object, ), {'template': lambda x: x})

    result = module.run(tmp='/tmp', task_vars={})
    print(json.dumps(result))
    assert result.get('ansible_facts')
    assert result['ansible_facts'].get('foo') == 'bar'
    assert not result['_ansible_facts_cacheable']



# Generated at 2022-06-21 02:58:33.026560
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-21 02:58:33.850343
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-21 02:58:34.978229
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_ansible_module_run()



# Generated at 2022-06-21 02:58:35.816508
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:58:36.705496
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:58:39.420454
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, None)
    assert isinstance(module, ActionModule)


# Generated at 2022-06-21 02:58:45.924162
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    from units.mock.loader import DictDataLoader
    from units.mock.inventory import MockInventory
