

# Generated at 2022-06-17 09:43:42.647894
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.set_fact import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-17 09:43:53.783217
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.module_utils.basic
    import ansible.module_utils.parsing.convert_bool
    import ansible.module_utils.six
    import ansible.module_utils.vars
    import ansible.plugins.action
    import ansible.utils.vars
    import sys
    import unittest

    class AnsibleModule(object):
        def __init__(self, argument_spec, bypass_checks=False, no_log=False,
                     check_invalid_arguments=True, mutually_exclusive=None,
                     required_together=None, required_one_of=None, add_file_common_args=False,
                     supports_check_mode=False):
            self.argument_spec = argument_spec
            self.bypass_checks = bypass_checks

# Generated at 2022-06-17 09:43:55.682021
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None, None)
    assert action is not None

# Generated at 2022-06-17 09:44:06.942898
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:44:12.187291
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict()
    task['action'] = 'set_fact'
    task['args'] = dict()
    task['args']['cacheable'] = False
    task['args']['key1'] = 'value1'
    task['args']['key2'] = 'value2'

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock tmp
    tmp = None

    # Create a mock result
    result = dict()
    result['ansible_facts'] = dict()
    result['ansible_facts']['key1'] = 'value1'
    result['ansible_facts']['key2'] = 'value2'
    result['_ansible_facts_cacheable'] = False

    # Create a mock ActionBase
    action_

# Generated at 2022-06-17 09:44:21.205676
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:44:32.865697
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict()
    task['args'] = dict()
    task['args']['cacheable'] = False

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock templar
    templar = dict()
    templar['template'] = lambda x: x

    # Create a mock action_base
    action_base = dict()
    action_base['run'] = lambda x, y: dict()

    # Create a mock action_module
    action_module = ActionModule(task, connection=None, play_context=None, loader=None, templar=templar, shared_loader_obj=None)
    action_module.__class__ = ActionModule
    action_module.__dict__ = action_base

    # Test the run method


# Generated at 2022-06-17 09:44:40.396631
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactory
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryFactCollector


# Generated at 2022-06-17 09:44:50.972594
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:44:52.464050
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:44:57.856525
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:45:01.360489
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:45:10.581753
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict()
    task['args'] = dict()
    task['args']['cacheable'] = False
    task['args']['test_key'] = 'test_value'

    # Create a mock templar
    templar = dict()
    templar['template'] = lambda x: x

    # Create a mock module
    module = dict()
    module['_templar'] = templar
    module['_task'] = task

    # Create a mock action
    action = dict()
    action['_task'] = task

    # Create a mock result
    result = dict()
    result['ansible_facts'] = dict()

    # Create a mock ActionModule
    action_module = ActionModule(action, module)

    # Run the method
    action_module.run()

# Generated at 2022-06-17 09:45:12.431412
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:45:19.818420
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    # Create a mock task

# Generated at 2022-06-17 09:45:22.243146
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:45:24.453546
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None)

# Generated at 2022-06-17 09:45:26.503772
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None)
    assert action is not None

# Generated at 2022-06-17 09:45:34.541049
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict()
    task['args'] = dict()
    task['args']['cacheable'] = False
    task['args']['test_var'] = "test_value"
    task['args']['test_var2'] = "test_value2"

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock templar
    templar = dict()
    templar['template'] = lambda x: x

    # Create a mock ActionBase
    action_base = dict()
    action_base['run'] = lambda x, y: dict()

    # Create a mock ActionModule
    action_module = dict()
    action_module['_task'] = task
    action_module['_templar'] = templar
    action_

# Generated at 2022-06-17 09:45:45.554832
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:46:05.281449
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import RedHatDistribution
    from ansible.module_utils.facts.system.distribution import RedHatDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import SuseDistribution
    from ansible.module_utils.facts.system.distribution import SuseDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import UbuntuDistribution

# Generated at 2022-06-17 09:46:16.087368
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_fact_exchange
    from ansible.module_utils.facts import default_fact_cacheable
    from ansible.module_utils.facts import default_fact_cache
    from ansible.module_utils.facts import default_fact_gathering
    from ansible.module_utils.facts import default_fact_gathering_timeout
    from ansible.module_utils.facts import default_fact_gathering_depth
    from ansible.module_utils.facts import default_fact_gathering_subset
    from ansible.module_utils.facts import default_fact_gathering_timeout
    from ansible.module_utils.facts import default_fact_gathering_

# Generated at 2022-06-17 09:46:17.953661
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None, None, None, None, None)
    assert am is not None

# Generated at 2022-06-17 09:46:20.865211
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None)
    assert action is not None

# Generated at 2022-06-17 09:46:34.103191
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import OpenBSDDistribution
    from ansible.module_utils.facts.system.distribution import SystemV
    from ansible.module_utils.facts.system.distribution import WindowsDistribution
    from ansible.module_utils.facts.system.distribution import DarwinDistribution
    from ansible.module_utils.facts.system.distribution import SunOSDistribution
    from ansible.module_utils.facts.system.distribution import FreeBSDDistribution
    from ansible.module_utils.facts.system.distribution import NetBSDDistribution
    from ansible.module_utils.facts.system.distribution import AIXDist

# Generated at 2022-06-17 09:46:36.636348
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None, None)
    assert action_module.TRANSFERS_FILES == False

# Generated at 2022-06-17 09:46:46.246573
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = dict(
        args = dict(
            foo = 'bar',
            baz = 'qux',
        ),
    )

    # Create a mock task_vars
    task_vars = dict(
        ansible_facts = dict(
            foo = 'bar',
        ),
    )

    # Create a mock play_context
    play_context = dict(
        check_mode = False,
    )

    # Create a mock connection
    connection = dict(
        _shell = None,
    )

    # Create a mock loader
    loader = dict(
        _basedir = '/path/to/basedir',
    )

    # Create a mock templar
    templar = dict(
        template = lambda x: x,
    )

    # Create a mock module_

# Generated at 2022-06-17 09:46:50.884293
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None, None, None, None, None, None, None, None, None, None, None)
    assert action is not None

# Generated at 2022-06-17 09:47:00.550668
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = dict(
        args = dict(
            cacheable = False,
            key1 = 'value1',
            key2 = 'value2',
            key3 = 'value3',
        ),
    )

    # Create a mock templar object
    templar = dict(
        template = lambda x: x,
    )

    # Create a mock action base object
    action_base = dict(
        run = lambda x, y: dict(
            ansible_facts = dict(
                key1 = 'value1',
                key2 = 'value2',
                key3 = 'value3',
            ),
            _ansible_facts_cacheable = False,
        ),
    )

    # Create a mock action module object

# Generated at 2022-06-17 09:47:09.518129
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:47:26.396653
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-17 09:47:35.416249
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module = ActionModule()

    # Create a task
    task = dict()
    task['args'] = dict()

    # Create a task_vars
    task_vars = dict()

    # Test with no key/value pairs
    result = action_module.run(task_vars=task_vars, task=task)
    assert result['failed'] == True
    assert result['msg'] == 'No key/value pairs provided, at least one is required for this action to succeed'

    # Test with key/value pairs
    task['args']['key1'] = 'value1'
    task['args']['key2'] = 'value2'
    result = action_module.run(task_vars=task_vars, task=task)

# Generated at 2022-06-17 09:47:46.563255
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict()
    task['args'] = dict()
    task['args']['cacheable'] = False
    task['args']['key1'] = 'value1'
    task['args']['key2'] = 'value2'

    # Create a mock templar
    templar = dict()
    templar['template'] = lambda x: x

    # Create a mock action
    action = dict()
    action['_task'] = task
    action['_templar'] = templar

    # Create a mock ActionModule
    action_module = ActionModule()
    action_module.__dict__ = action

    # Call method run
    result = action_module.run()

    # Assert result

# Generated at 2022-06-17 09:47:47.575548
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:47:57.730635
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import RedHatDistribution
    from ansible.module_utils.facts.system.distribution import RedHatDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import SuseDistribution
    from ansible.module_utils.facts.system.distribution import SuseDistributionFactCollector

# Generated at 2022-06-17 09:48:10.825421
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no arguments
    action_module = ActionModule(dict(ANSIBLE_MODULE_ARGS=dict()), dict())
    result = action_module.run(None, None)
    assert result['failed']
    assert result['msg'] == 'No key/value pairs provided, at least one is required for this action to succeed'

    # Test with invalid variable name
    action_module = ActionModule(dict(ANSIBLE_MODULE_ARGS=dict(foo='bar')), dict())
    result = action_module.run(None, None)
    assert result['failed']
    assert result['msg'] == "The variable name 'foo' is not valid. Variables must start with a letter or underscore character, and contain only letters, numbers and underscores."

    # Test with valid variable name

# Generated at 2022-06-17 09:48:12.194564
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:48:18.568252
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict(
        args=dict(
            test_var='test_value',
            test_var2='test_value2',
            cacheable=True
        )
    )

    # Create a mock templar
    templar = dict(
        template=lambda x: x
    )

    # Create a mock action base
    action_base = dict(
        run=lambda x, y: dict(
            ansible_facts=dict(
                test_var='test_value',
                test_var2='test_value2'
            ),
            _ansible_facts_cacheable=True
        )
    )

    # Create a mock action module
    action_module = ActionModule(task, templar, action_base)

    # Run the method
    result = action_module

# Generated at 2022-06-17 09:48:22.611365
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None, None, None, None, None, None)
    assert action is not None

# Generated at 2022-06-17 09:48:24.666250
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None)

# Generated at 2022-06-17 09:49:10.046626
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict(
        args = dict(
            key1 = 'value1',
            key2 = 'value2',
            key3 = 'value3',
        )
    )

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock tmp
    tmp = None

    # Create a mock result
    result = dict(
        ansible_facts = dict(
            key1 = 'value1',
            key2 = 'value2',
            key3 = 'value3',
        ),
        _ansible_facts_cacheable = False,
    )

    # Create a mock ActionBase
    action_base = ActionBase(task, tmp, task_vars)

    # Create a mock ActionModule

# Generated at 2022-06-17 09:49:19.988172
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict()
    task['args'] = dict()
    task['args']['cacheable'] = False
    task['args']['var1'] = 'value1'
    task['args']['var2'] = 'value2'

    # Create a mock templar
    templar = dict()
    templar['template'] = lambda x: x

    # Create a mock action module
    action_module = ActionModule(task, templar)

    # Create a mock result
    result = dict()
    result['ansible_facts'] = dict()
    result['_ansible_facts_cacheable'] = False

    # Run the method
    result = action_module.run(None, None)

    # Check the result

# Generated at 2022-06-17 09:49:35.356246
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict(
        action=dict(
            module_name='set_fact',
            module_args=dict(
                key1='value1',
                key2='value2',
            ),
        ),
    )

    # Create a mock result
    result = dict(
        ansible_facts=dict(
            key1='value1',
            key2='value2',
        ),
        _ansible_facts_cacheable=False,
    )

    # Create a mock templar
    templar = dict(
        template=lambda x: x,
    )

    # Create a mock action base

# Generated at 2022-06-17 09:49:46.791563
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.utils.vars import isidentifier
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars

    # Create a mock task
    task = MockTask()

    # Create a mock action module
    action_module = ActionModule(task, dict())

    # Create a mock templar
    templar = MockTemplar()

    # Set templar
    action_module._templar = templar

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock result
    result = dict()

    # Test with no arguments

# Generated at 2022-06-17 09:49:56.076367
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict(
        args=dict(
            test_var='test_value',
            test_var2='test_value2',
            cacheable=True,
        ),
    )

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock tmp
    tmp = None

    # Create a mock result
    result = dict(
        ansible_facts=dict(
            test_var='test_value',
            test_var2='test_value2',
        ),
        _ansible_facts_cacheable=True,
    )

    # Create a mock action_base
    action_base = ActionBase()

    # Create a mock action_module
    action_module = ActionModule(task, action_base._connection, tmp, task_vars)



# Generated at 2022-06-17 09:50:04.191556
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module = ActionModule()

    # Create a mock task
    task = dict()
    task['args'] = dict()
    task['args']['cacheable'] = False

    # Create a mock result
    result = dict()
    result['ansible_facts'] = dict()
    result['_ansible_facts_cacheable'] = False

    # Create a mock templar
    templar = dict()
    templar['template'] = lambda x: x

    # Create a mock task_vars
    task_vars = dict()

    # Set the attributes of the class
    action_module._task = task
    action_module._templar = templar

    # Test the run method

# Generated at 2022-06-17 09:50:06.141197
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:50:07.427908
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:50:08.934900
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:50:20.254218
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = dict()
    task['args'] = dict()
    task['args']['cacheable'] = False
    task['args']['key1'] = 'value1'
    task['args']['key2'] = 'value2'

    # Create a mock connection
    connection = dict()

    # Create a mock play context
    play_context = dict()

    # Create a mock loader
    loader = dict()

    # Create a mock templar
    templar = dict()

    # Create a mock action plugin
    action_plugin = dict()

    # Create a mock shared plugin
    shared_plugin = dict()

    # Create a mock display
    display = dict()

    # Create a mock options
    options = dict()

    # Create a mock variable manager
    variable_manager = dict()

# Generated at 2022-06-17 09:52:01.718820
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.utils.vars import isidentifier

    # Test case 1:
    # Test case where no key/value pairs are provided
    # Expected result:
    # The method should raise an AnsibleActionFail exception
    # with the message 'No key/value pairs provided, at least one is required for this action to succeed'
    task_vars = dict()
    tmp = None
    task = dict(
        action=dict(
            module_name='set_fact',
            module_args=dict()
        )
    )
    action_module = ActionModule(task, tmp, task_vars)

# Generated at 2022-06-17 09:52:02.881547
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:52:11.495194
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = type('MockTask', (object,), {})()
    mock_task.args = {'cacheable': False}
    mock_task.args['key1'] = 'value1'
    mock_task.args['key2'] = 'value2'

    # Create a mock templar
    mock_templar = type('MockTemplar', (object,), {})()
    mock_templar.template = lambda x: x

    # Create a mock action module
    mock_action_module = type('MockActionModule', (ActionModule,), {})()
    mock_action_module._task = mock_task
    mock_action_module._templar = mock_templar

    # Call method run of class ActionModule

# Generated at 2022-06-17 09:52:20.789419
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import RedHatDistribution
    from ansible.module_utils.facts.system.distribution import RedHatDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import SuseDistribution
    from ansible.module_utils.facts.system.distribution import SuseDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import UbuntuDistribution

# Generated at 2022-06-17 09:52:24.651633
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None, None, None, None)
    assert action_module is not None

# Generated at 2022-06-17 09:52:31.962605
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:52:33.548596
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:52:39.287205
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict(
        args = dict(
            cacheable = False,
            key1 = 'value1',
            key2 = 'value2',
        ),
    )

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock tmp
    tmp = None

    # Create a mock result
    result = dict(
        ansible_facts = dict(
            key1 = 'value1',
            key2 = 'value2',
        ),
        _ansible_facts_cacheable = False,
    )

    # Create a mock action_base
    action_base = ActionBase()

    # Create a mock action_module
    action_module = ActionModule(task, action_base._connection, tmp, task_vars)

    # Assert that the result of

# Generated at 2022-06-17 09:52:48.540443
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types


# Generated at 2022-06-17 09:52:55.210454
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import OpenBSDDistribution
    from ansible.module_utils.facts.system.distribution import OpenBSDDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import SystemReleaseFactCollector
    from ansible.module_utils.facts.system.distribution import SystemReleaseParser
    from ansible.module_utils.facts.system.distribution import SystemReleaseParserLinux