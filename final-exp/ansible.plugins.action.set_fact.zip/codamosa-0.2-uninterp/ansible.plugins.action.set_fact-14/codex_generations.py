

# Generated at 2022-06-17 09:43:32.494202
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:43:42.578299
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:43:44.267507
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None)

# Generated at 2022-06-17 09:43:54.804678
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import isidentifier

    # Test with no arguments
    action = ActionModule(dict(name='test', args=dict()))
    result = action.run(tmp=None, task_vars=None)
    assert result['failed'] == True
    assert result['msg'] == 'No key/value pairs provided, at least one is required for this action to succeed'

    # Test with invalid variable name
    action = ActionModule(dict(name='test', args=dict(foo='bar')))
    result = action.run(tmp=None, task_vars=None)
    assert result['failed'] == True

# Generated at 2022-06-17 09:44:06.907888
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:44:07.944915
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None, None, None)

# Generated at 2022-06-17 09:44:19.610651
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_vars_from_inventory

# Generated at 2022-06-17 09:44:22.423443
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:44:33.252777
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:44:36.711990
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:44:41.908367
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None, None, None, None)
    assert am is not None

# Generated at 2022-06-17 09:44:52.196883
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts import ansible_facts

    # Create a mock task
    task = dict(
        args = dict(
            cacheable = False,
            foo = 'bar',
            baz = 'qux',
        ),
    )

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock templar
    templar = dict()

    # Create a mock module_name
    module_name = 'setup'

    # Create a mock module_args
    module_args = dict()

    # Create a mock module_complex_args
    module_complex_args = dict()

    # Create a mock module_lang
    module_lang = 'python'

    # Create a mock module_style
    module_

# Generated at 2022-06-17 09:45:00.408192
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)

    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='set_fact', args=dict(ansible_python_interpreter='/usr/bin/python')))
        ]
    )


# Generated at 2022-06-17 09:45:07.762798
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'a': 'b'}

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action module
    action_module = ActionModule(task, templar)

    # Run the action module
    result = action_module.run(None, None)

    # Check the result
    assert result == {'ansible_facts': {'a': 'b'}, '_ansible_facts_cacheable': False}


# Generated at 2022-06-17 09:45:09.584692
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None, None, None, None)
    assert action_module is not None

# Generated at 2022-06-17 09:45:11.686687
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:45:13.398507
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), '/tmp/ansible_ActionModule', 'test', 'test')

# Generated at 2022-06-17 09:45:22.747203
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict()
    task['args'] = dict()
    task['args']['cacheable'] = False
    task['args']['test_key'] = 'test_value'

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock tmp
    tmp = None

    # Create a mock templar
    templar = dict()
    templar['template'] = lambda x: x

    # Create a mock action_base
    action_base = dict()
    action_base['run'] = lambda x, y: dict()

    # Create a mock ansible_constants
    ansible_constants = dict()
    ansible_constants['DEFAULT_JINJA2_NATIVE'] = True

    # Create a mock ansible_constants

# Generated at 2022-06-17 09:45:33.711155
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import OpenBSDDistribution
    from ansible.module_utils.facts.system.distribution import OpenBSDDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import SolarisDistribution
    from ansible.module_utils.facts.system.distribution import SolarisDistributionFactCollector

# Generated at 2022-06-17 09:45:44.799428
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = MockTask()

    # Create a mock action module
    action_module = ActionModule(task, dict())

    # Create a mock templar object
    templar = MockTemplar()

    # Set the templar object on the action module
    action_module._templar = templar

    # Create a mock result object
    result = MockResult()

    # Set the result object on the action module
    action_module._result = result

    # Create a mock task_vars object
    task_vars = dict()

    # Call the run method of the action module
    action_module.run(None, task_vars)

    # Check the result
    assert result.ansible_facts == {'a': 'b'}
    assert result._ansible_facts_cacheable

# Generated at 2022-06-17 09:45:53.498098
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:46:05.444902
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.utils.vars import isidentifier
    from ansible.plugins.action import ActionBase
    from ansible.module_utils.six import string_types
    from ansible.utils.vars import merge_hash
    from ansible.module_utils._text import to_text
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_FALSE
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_ALL

    # Create a mock task object
    task = type

# Generated at 2022-06-17 09:46:11.184747
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts import ansible_facts

    # Create a mock task

# Generated at 2022-06-17 09:46:13.375760
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None, None, None, None, None, None, None)
    assert action is not None

# Generated at 2022-06-17 09:46:17.253513
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module is not None

# Generated at 2022-06-17 09:46:20.036128
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None, None, None, None)
    assert action is not None

# Generated at 2022-06-17 09:46:33.755820
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict()
    task['action'] = dict()
    task['action']['__ansible_argspec'] = dict()
    task['action']['__ansible_argspec']['args'] = dict()
    task['action']['__ansible_argspec']['args']['cacheable'] = dict()
    task['action']['__ansible_argspec']['args']['cacheable']['default'] = False
    task['action']['__ansible_argspec']['args']['cacheable']['type'] = 'bool'
    task['action']['__ansible_argspec']['args']['cacheable']['choices'] = [True, False]

# Generated at 2022-06-17 09:46:42.211806
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:46:42.979377
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None)

# Generated at 2022-06-17 09:46:44.583086
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:47:03.759189
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    try:
        ActionModule()
    except Exception as e:
        assert type(e) == TypeError
    # Test with arguments
    try:
        ActionModule(None, None)
    except Exception as e:
        assert type(e) == TypeError

# Generated at 2022-06-17 09:47:11.417377
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    # Create a mock task
    task = dict(
        args = dict(
            key1 = 'value1',
            key2 = 'value2',
        ),
    )

    # Create a mock task_vars
    task_vars = dict(
        ansible_facts = dict(
            ansible_distribution = 'RedHat',
            ansible_distribution_version = '7.0',
        ),
    )

    # Create a mock templar
    templar = dict(
        template = lambda x: x,
    )

    # Create a mock module_loader

# Generated at 2022-06-17 09:47:18.648286
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files

# Generated at 2022-06-17 09:47:23.038120
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:47:25.825305
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:47:29.222184
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test
    pass

# Generated at 2022-06-17 09:47:39.332116
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict(
        action=dict(
            module_name='set_fact',
            module_args=dict(
                cacheable=False,
                foo='bar',
                baz='qux',
            ),
        ),
    )

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock tmp
    tmp = None

    # Create a mock ActionBase
    action_base = ActionBase()

    # Create a mock ActionModule
    action_module = ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Call method run of class ActionModule
    result = action_module.run(tmp, task_vars)

    # Assertions

# Generated at 2022-06-17 09:47:50.409181
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import OpenBSDDistribution
    from ansible.module_utils.facts.system.distribution import SystemV
    from ansible.module_utils.facts.system.distribution import UnknownDistribution
    from ansible.module_utils.facts.system.distribution import WindowsDistribution
    from ansible.module_utils.facts.system.distribution import WindowsServerDistribution
    from ansible.module_utils.facts.system.distribution import WindowsVersion
    from ansible.module_utils.facts.system.distribution import WindowsVersionInfo
    from ansible.module_utils.facts.system.distribution import WindowsVersionInfoEx


# Generated at 2022-06-17 09:47:52.566086
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:48:00.353478
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import OpenBSDDistribution
    from ansible.module_utils.facts.system.distribution import OpenBSDDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import SolarisDistribution
    from ansible.module_utils.facts.system.distribution import SolarisDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import SystemV

# Generated at 2022-06-17 09:48:46.794922
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:48:50.643069
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:48:52.397483
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 09:49:02.868526
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.utils.vars import isidentifier
    from ansible.plugins.action import ActionBase

    class ActionModule(ActionBase):
        def run(self, tmp=None, task_vars=None):
            if task_vars is None:
                task_vars = dict()

            result = super(ActionModule, self).run(tmp, task_vars)
            del tmp  # tmp no longer has any effect

            facts = {}
            cacheable = boolean(self._task.args.pop('cacheable', False))

            if self._task.args:
                for (k, v) in iteritems(self._task.args):
                    k = self._templar

# Generated at 2022-06-17 09:49:08.892226
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Test the constructor of the class ActionModule
    """
    action = ActionModule(None, None, None, None, None)
    assert action is not None

# Generated at 2022-06-17 09:49:12.612098
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:49:13.777904
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:49:14.942254
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:49:16.616497
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None)
    assert action is not None

# Generated at 2022-06-17 09:49:26.321233
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.utils.template as template
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import isidentifier
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import is_complex_data
    from ansible.utils.vars import is_sequence
    from ansible.utils.vars import is_scalar
    from ansible.utils.vars import is_list_of_strings
    from ansible.utils.vars import is_list_of_hashes
    from ansible.utils.vars import is_list_of

# Generated at 2022-06-17 09:50:42.733374
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:50:49.049455
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.utils.vars import isidentifier

    # Test with no args
    action = ActionModule()
    action._task = {'args': {}}
    result = action.run()
    assert result['failed']
    assert result['msg'] == 'No key/value pairs provided, at least one is required for this action to succeed'

    # Test with invalid variable name
    action = ActionModule()
    action._task = {'args': {'foo-bar': 'baz'}}
    result = action.run()
    assert result['failed']

# Generated at 2022-06-17 09:50:57.998302
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module = ActionModule()

    # Create a mock task
    task = dict()
    task['args'] = dict()

    # Create a mock result
    result = dict()
    result['ansible_facts'] = dict()
    result['_ansible_facts_cacheable'] = False

    # Create a mock task_vars
    task_vars = dict()

    # Test with no key/value pairs provided
    try:
        action_module.run(task, task_vars)
    except AnsibleActionFail as e:
        assert e.message == 'No key/value pairs provided, at least one is required for this action to succeed'

    # Test with key/value pairs provided
    task['args']['key1'] = 'value1'

# Generated at 2022-06-17 09:51:05.369541
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_vars_from_inventory

# Generated at 2022-06-17 09:51:12.099307
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_fact_exchange
    from ansible.module_utils.facts import default_fact_cacheable
    from ansible.module_utils.facts import default_fact_cache
    from ansible.module_utils.facts import default_fact_gathering
    from ansible.module_utils.facts import default_fact_gathering_timeout
    from ansible.module_utils.facts import default_fact_gathering_subset
    from ansible.module_utils.facts import default_fact_gathering_type
    from ansible.module_utils.facts import default_fact_gathering_depth
    from ansible.module_utils.facts import default_fact_gathering_

# Generated at 2022-06-17 09:51:22.045157
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:51:24.417482
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:51:26.947931
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None, None, None, None)
    assert action is not None

# Generated at 2022-06-17 09:51:30.463613
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:51:37.888538
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict()
    task['args'] = dict()
    task['args']['cacheable'] = False
    task['args']['fact1'] = 'value1'
    task['args']['fact2'] = 'value2'
    task['args']['fact3'] = 'value3'

    # Create a mock templar
    templar = dict()
    templar['template'] = lambda x: x

    # Create a mock ActionBase
    action_base = dict()
    action_base['run'] = lambda x, y: dict()

    # Create a mock ActionModule
    action_module = dict()
    action_module['_task'] = task
    action_module['_templar'] = templar
    action_module['run'] = ActionModule.run