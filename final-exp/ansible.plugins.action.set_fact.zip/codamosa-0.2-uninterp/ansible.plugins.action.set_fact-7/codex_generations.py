

# Generated at 2022-06-17 09:43:48.165999
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:43:57.126507
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict(
        args=dict(
            cacheable=False,
            test_fact='test_value'
        )
    )

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock tmp
    tmp = None

    # Create a mock templar
    templar = dict()

    # Create a mock action_base
    action_base = dict(
        _templar=templar
    )

    # Create a mock action_module
    action_module = ActionModule(task, action_base, task_vars, tmp)

    # Test the run method
    result = action_module.run(tmp, task_vars)

    # Assert the result

# Generated at 2022-06-17 09:44:01.064036
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor of class ActionModule
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module

# Generated at 2022-06-17 09:44:09.307899
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict(
        action=dict(
            module_name='set_fact',
            module_args=dict(
                foo='bar',
                baz='qux',
                cacheable=False,
            ),
        ),
    )

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock tmp
    tmp = None

    # Create a mock ansible_facts
    ansible_facts = dict()

    # Create a mock result
    result = dict(
        ansible_facts=ansible_facts,
        _ansible_facts_cacheable=False,
    )

    # Create a mock module_name
    module_name = 'set_fact'

    # Create a mock module_args

# Generated at 2022-06-17 09:44:11.084224
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None, None)
    assert action is not None

# Generated at 2022-06-17 09:44:13.862474
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None, None)
    assert action is not None

# Generated at 2022-06-17 09:44:25.042934
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:44:33.456285
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_host_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine

# Generated at 2022-06-17 09:44:36.749879
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:44:49.002431
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict()
    task['args'] = dict()
    task['args']['cacheable'] = False
    task['args']['var1'] = 'value1'
    task['args']['var2'] = 'value2'

    # Create a mock templar
    templar = dict()
    templar['template'] = lambda x: x

    # Create a mock module_utils
    module_utils = dict()
    module_utils['boolean'] = lambda x: x

    # Create a mock ActionBase
    action_base = dict()
    action_base['run'] = lambda x, y: dict()

    # Create a mock ActionModule
    action_module = dict()
    action_module['_task'] = task
    action_module['_templar'] = tem

# Generated at 2022-06-17 09:44:59.576131
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test for constructor of class ActionModule
    # Create an object of ActionModule
    action_module_obj = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # Check if the object is an instance of class ActionModule
    assert isinstance(action_module_obj, ActionModule)

# Generated at 2022-06-17 09:45:09.841154
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts import ansible_facts

    # Create a mock task
    task = dict(
        args=dict(
            cacheable=False,
            test_key='test_value',
        ),
    )

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock AnsibleModule
    am = dict(
        params=dict(
            cacheable=False,
            test_key='test_value',
        ),
    )

    # Create a mock AnsibleModule object
    mock_AnsibleModule = type('AnsibleModule', (object,), am)

    # Create a mock templar

# Generated at 2022-06-17 09:45:18.787318
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean

    # Create a mock task
    task = dict(
        args = dict(
            cacheable = False,
            foo = 'bar',
            baz = 'qux',
        )
    )

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock tmp
    tmp = None

    # Create a mock result
    result = dict(
        ansible_facts = dict(
            foo = 'bar',
            baz = 'qux',
        ),
        _ansible_facts_cacheable = False,
    )

    # Create an instance of ActionModule
    action_module = ActionModule(task, task_vars, tmp)

    # Run the method run of class ActionModule
    assert action_module

# Generated at 2022-06-17 09:45:20.648700
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:45:33.033625
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactory
    from ansible.module_utils.facts.system.distribution import RedHatDistribution
    from ansible.module_utils.facts.system.distribution import RedHatDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import SuseDistribution
    from ansible.module_utils.facts.system.distribution import SuseDistributionFactCollector

# Generated at 2022-06-17 09:45:34.208074
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:45:35.553364
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:45:36.768361
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:45:47.421934
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_host_vars
    from ansible.utils.vars import load_vars

# Generated at 2022-06-17 09:45:53.986097
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    import tempfile
    import shutil
    import json

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary playbook

# Generated at 2022-06-17 09:46:13.630729
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = dict(
        args = dict(
            foo = 'bar',
            baz = 'qux',
        ),
    )

    # Create a mock task_vars
    task_vars = dict(
        ansible_facts = dict(
            foo = 'bar',
        ),
    )

    # Create a mock templar
    templar = dict(
        template = lambda x: x,
    )

    # Create a mock loader
    loader = dict(
        get_basedir = lambda x: '/path/to/playbook',
    )

    # Create a mock display
    display = dict(
        vvv = lambda x, hostname=None: None,
    )

    # Create a mock action_base

# Generated at 2022-06-17 09:46:21.091118
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    try:
        ActionModule(dict(), dict())
    except AnsibleActionFail:
        pass
    else:
        assert False, "ActionModule() should raise AnsibleActionFail"

    # Test with arguments
    try:
        ActionModule(dict(), dict(a=1))
    except AnsibleActionFail:
        assert False, "ActionModule() should not raise AnsibleActionFail"

# Generated at 2022-06-17 09:46:31.712833
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.process.worker import WorkerProcess
    from ansible.executor.stats import AggregateStats
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_v

# Generated at 2022-06-17 09:46:34.090829
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-17 09:46:42.333418
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_vars_from_inventory

# Generated at 2022-06-17 09:46:52.256645
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import OpenBSDDistribution
    from ansible.module_utils.facts.system.distribution import SolarisDistribution
    from ansible.module_utils.facts.system.distribution import SystemV
    from ansible.module_utils.facts.system.distribution import WindowsDistribution
    from ansible.module_utils.facts.system.distribution import WindowsDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import WindowsDistributionFactCollector


# Generated at 2022-06-17 09:47:01.251293
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict()
    task['args'] = dict()
    task['args']['cacheable'] = False
    task['args']['key1'] = 'value1'
    task['args']['key2'] = 'value2'

    # Create a mock templar
    templar = dict()
    templar['template'] = lambda x: x

    # Create a mock action
    action = dict()
    action['_task'] = task
    action['_templar'] = templar

    # Create a mock action module
    action_module = ActionModule()
    action_module.__dict__ = action

    # Test the run method
    result = action_module.run(None, None)

# Generated at 2022-06-17 09:47:09.952773
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_host_vars
    from ansible.utils.vars import load_vars

# Generated at 2022-06-17 09:47:11.798746
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None, None)
    assert action is not None

# Generated at 2022-06-17 09:47:13.169632
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None, None)
    assert action is not None

# Generated at 2022-06-17 09:47:38.499764
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict()
    task['args'] = dict()
    task['args']['cacheable'] = False
    task['args']['var1'] = 'value1'
    task['args']['var2'] = 'value2'
    task['args']['var3'] = 'value3'

    # Create a mock templar
    templar = dict()
    templar['template'] = lambda x: x

    # Create a mock action
    action = dict()
    action['_task'] = task
    action['_templar'] = templar

    # Create a mock ActionModule
    action_module = ActionModule()
    action_module.__dict__ = action

    # Test the run method
    result = action_module.run()

# Generated at 2022-06-17 09:47:40.706731
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None)
    assert action is not None

# Generated at 2022-06-17 09:47:51.747771
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict()
    task['args'] = dict()
    task['args']['cacheable'] = False
    task['args']['key1'] = 'value1'
    task['args']['key2'] = 'value2'

    # Create a mock templar
    templar = dict()
    templar['template'] = lambda x: x

    # Create a mock action module
    action_module = dict()
    action_module['_task'] = task
    action_module['_templar'] = templar

    # Create a mock action module object
    action_module_object = ActionModule()
    action_module_object.__dict__ = action_module

    # Run the method
    result = action_module_object.run()

    # Check the result
   

# Generated at 2022-06-17 09:47:55.058350
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:47:59.474365
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-17 09:48:00.322820
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:48:05.687241
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict(
        args=dict(
            cacheable=False,
            foo='bar',
            baz='qux',
        ),
    )
    # Create a mock task_vars
    task_vars = dict()
    # Create a mock tmp
    tmp = None
    # Create a mock result
    result = dict(
        ansible_facts=dict(
            foo='bar',
            baz='qux',
        ),
        _ansible_facts_cacheable=False,
    )
    # Create a mock ActionBase
    action_base = ActionBase()
    # Create a mock ActionModule
    action_module = ActionModule()
    # Create a mock ActionModule._templar
    action_module._templar = dict()
    # Create a mock ActionModule._tem

# Generated at 2022-06-17 09:48:08.665811
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action = ActionModule(dict())
    assert action.TRANSFERS_FILES == False


# Generated at 2022-06-17 09:48:10.318773
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None, None, None)

# Generated at 2022-06-17 09:48:18.105676
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no arguments
    action_module = ActionModule(None, {}, None, None, None)
    try:
        action_module.run()
        assert False
    except AnsibleActionFail:
        assert True

    # Test with valid arguments
    action_module = ActionModule(None, {}, None, None, None)
    action_module._task.args = {'test': 'test'}
    result = action_module.run()
    assert result['ansible_facts']['test'] == 'test'
    assert result['_ansible_facts_cacheable'] == False

    # Test with invalid arguments
    action_module = ActionModule(None, {}, None, None, None)
    action_module._task.args = {'test': 'test', 'test-': 'test'}

# Generated at 2022-06-17 09:49:08.752607
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import isidentifier

    # Create a mock object for the module_utils/parsing/convert_bool.py
    # boolean function.
    class MockBoolean(object):
        def __init__(self, return_value):
            self.return_value = return_value

        def __call__(self, value, strict=False):
            return self.return_value

    # Create a mock object for the ansible.utils.vars.isidentifier function.

# Generated at 2022-06-17 09:49:12.612192
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:49:20.425001
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class TaskExecutor
    task_executor = TaskExecutor()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class Runner
    runner = Runner()

    # Create an instance of class Play
    play = Play()

    # Create an instance of class PlaybookExecutor
    play_executor = PlaybookExecutor()

    # Create an instance of class Playbook
    playbook = Playbook()

    # Create an instance of class PlaybookExecutor
    play_executor = PlaybookExecutor()

    # Create an instance of class Playbook
    playbook = Playbook()

    # Create an instance of class PlaybookExecutor


# Generated at 2022-06-17 09:49:35.620619
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:49:47.105764
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:49:50.616134
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:50:00.769501
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = dict(
        action=dict(
            module_name='set_fact',
            module_args=dict(
                key1='value1',
                key2='value2',
            ),
        ),
    )

    # Create a mock connection
    connection = dict(
        host='localhost',
        port=22,
        user='user',
        password='password',
        transport='ssh',
    )

    # Create a mock play
    play = dict(
        name='test',
        hosts=['localhost'],
        gather_facts='no',
        tasks=[task],
    )

    # Create a mock loader
    loader = dict(
        basedir='/path/to/playbook',
    )

    # Create a mock variable manager

# Generated at 2022-06-17 09:50:11.849405
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict()
    task['args'] = dict()
    task['args']['cacheable'] = False
    task['args']['key1'] = 'value1'
    task['args']['key2'] = 'value2'

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock templar
    templar = dict()
    templar['template'] = lambda x: x

    # Create a mock ActionModule
    action_module = ActionModule(task, templar, task_vars)

    # Test the run method
    result = action_module.run(None, task_vars)
    assert result['ansible_facts']['key1'] == 'value1'

# Generated at 2022-06-17 09:50:13.646712
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:50:15.441217
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    module = ActionModule(None, None, None, None)
    assert module is not None

# Generated at 2022-06-17 09:51:58.407860
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.utils.vars import isidentifier
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.set_fact import ActionModule
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.module_utils._text import to_text
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping

# Generated at 2022-06-17 09:52:01.386090
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:52:02.924848
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:52:11.509105
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict()
    task['args'] = dict()
    task['args']['cacheable'] = False
    task['args']['var1'] = 'value1'
    task['args']['var2'] = 'value2'

    # Create a mock templar
    templar = dict()
    templar['template'] = lambda x: x

    # Create a mock action
    action = dict()
    action['_task'] = task
    action['_templar'] = templar

    # Create a mock action module
    action_module = ActionModule()
    action_module.__dict__ = action

    # Test the run method
    result = action_module.run()
    assert result['ansible_facts']['var1'] == 'value1'

# Generated at 2022-06-17 09:52:20.789805
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files

# Generated at 2022-06-17 09:52:33.517733
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'a': '1', 'b': '2'}

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock action_base
    action_base = MockActionBase()

    # Create an instance of ActionModule
    action_module = ActionModule(task, templar, module_utils, action_base)

    # Call method run
    result = action_module.run()

    # Assert result
    assert result == {'ansible_facts': {'a': '1', 'b': '2'}, '_ansible_facts_cacheable': False}


# Generated at 2022-06-17 09:52:39.168076
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.action.set_fact import ActionModule
    from ansible.utils.vars import isidentifier
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import is_complex_data
    from ansible.utils.vars import is_list_of_strings
    from ansible.utils.vars import is_sequence
    from ansible.utils.vars import is_scalar
    from ansible.utils.vars import is_scalar_or_list
    from ansible.utils.vars import is_scalar_or_complex
    from ansible.utils.vars import is_scalar_

# Generated at 2022-06-17 09:52:40.974179
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:52:42.130738
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None)
    assert action is not None

# Generated at 2022-06-17 09:52:53.699614
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars