

# Generated at 2022-06-17 09:43:34.753847
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:43:36.095687
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:43:48.892990
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    task = Task()
    task.action = 'set_fact'
    task.args = {'ansible_facts': {'test_fact': 'test_value'}}


# Generated at 2022-06-17 09:43:51.352848
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None)
    assert action is not None

# Generated at 2022-06-17 09:44:01.823912
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import RedHatDistribution
    from ansible.module_utils.facts.system.distribution import RedHatDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import SuseDistribution
    from ansible.module_utils.facts.system.distribution import SuseDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import UbuntuDistribution

# Generated at 2022-06-17 09:44:03.175692
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:44:11.769469
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactory
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryFactCollector


# Generated at 2022-06-17 09:44:21.644174
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class VariableManager
    variable_manager = VariableManager()

    # Set the attributes of the 'task' object
    task.action = 'set_fact'
    task.args = {'ansible_facts': {'test_key': 'test_value'}}
    task.async_val = None
    task.become = False
    task.become_method = None
    task.become_user = None
    task.delegate_to = None
    task.delegate_facts = None
    task.dep_chain = None
    task.loop = None
    task.loop_

# Generated at 2022-06-17 09:44:22.458551
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:44:23.639115
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:44:31.571742
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:44:38.992798
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:44:49.133664
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_vars_from_inventory

# Generated at 2022-06-17 09:44:53.050323
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.set_fact as action_module
    action = action_module.ActionModule(None, None, None, None)
    assert isinstance(action, action_module.ActionModule)

# Generated at 2022-06-17 09:45:03.105862
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_vars_from_inventory

# Generated at 2022-06-17 09:45:06.914080
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None, None, None)
    assert action_module is not None

# Generated at 2022-06-17 09:45:16.858468
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    task = Task()
    task.action = 'set_fact'

# Generated at 2022-06-17 09:45:27.654451
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict(
        args = dict(
            foo = 'bar',
            baz = 'qux',
            cacheable = 'yes',
        ),
    )

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock tmp
    tmp = None

    # Create a mock result
    result = dict(
        ansible_facts = dict(
            foo = 'bar',
            baz = 'qux',
        ),
        _ansible_facts_cacheable = True,
    )

    # Create a mock action_base
    action_base = ActionBase()

    # Create a mock action_module
    action_module = ActionModule()

    # Assign the mock task to the action_module
    action_module._task = task

    # Assign

# Generated at 2022-06-17 09:45:28.392002
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-17 09:45:33.937908
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.set_fact as action_set_fact
    action_set_fact.ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:45:49.967022
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    task = Task()
    task._role = None
    task.args = {'cacheable': False, 'a': 'b'}
    task.action = 'set_fact'
    task.set_loader(None)
    task.set_play_context(PlayContext())

    action = ActionModule(task, None)
    result = action.run(None, None)
    assert result['ansible_facts']['a'] == 'b'
    assert result['_ansible_facts_cacheable'] == False

# Generated at 2022-06-17 09:45:52.392459
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:45:53.292278
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:46:05.115788
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict()
    task['args'] = dict()
    task['args']['cacheable'] = False
    task['args']['foo'] = 'bar'
    task['args']['baz'] = 'qux'

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock templar
    templar = dict()
    templar['template'] = lambda x: x

    # Create a mock ActionBase
    action_base = dict()
    action_base['run'] = lambda x, y: dict()

    # Create a mock ActionModule
    action_module = dict()
    action_module['_task'] = task
    action_module['_templar'] = templar

# Generated at 2022-06-17 09:46:15.980175
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:46:27.513667
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:46:37.898015
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactory
    from ansible.module_utils.facts.system.distribution import RedHatDistribution
    from ansible.module_utils.facts.system.distribution import RedHatDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import SuseDistribution
    from ansible.module_utils.facts.system.distribution import Su

# Generated at 2022-06-17 09:46:39.332514
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None)
    assert action is not None

# Generated at 2022-06-17 09:46:41.317212
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action = ActionModule(dict())
    assert action.TRANSFERS_FILES == False


# Generated at 2022-06-17 09:46:49.443990
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactory
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryFactCollector


# Generated at 2022-06-17 09:47:17.081606
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactCollector

# Generated at 2022-06-17 09:47:26.852484
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict()
    task['args'] = dict()
    task['args']['cacheable'] = False
    task['args']['test_var'] = 'test_value'

    # Create a mock templar
    templar = dict()
    templar['template'] = lambda x: x

    # Create a mock action
    action = dict()
    action['_task'] = task
    action['_templar'] = templar

    # Create a mock action module
    action_module = ActionModule()
    action_module.__dict__ = action

    # Test the run method
    result = action_module.run()
    assert result['ansible_facts']['test_var'] == 'test_value'

# Generated at 2022-06-17 09:47:37.344915
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_host_vars
    from ansible.utils.vars import load_vars_files

# Generated at 2022-06-17 09:47:49.553416
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_vars_from_inventory

# Generated at 2022-06-17 09:47:53.976914
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of the class
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # Check the instance
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-17 09:48:01.224005
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.parsing.convert_bool import boolean

    module = AnsibleModule(argument_spec={})
    action = ActionModule(module, {})
    action._task = {'args': {'cacheable': 'True'}}
    action._templar = {'template': lambda x: x}

    # Test with no arguments
    try:
        action.run()
        assert False
    except AnsibleActionFail as e:
        assert 'No key/value pairs provided' in str(e)

    # Test with invalid variable name
    action._task['args'] = {'invalid-name': 'value'}

# Generated at 2022-06-17 09:48:05.450669
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a test object
    action_module = ActionModule(None, None, None, None, None, None, None)

    # Test the run method
    action_module.run(None, None)

# Generated at 2022-06-17 09:48:14.312817
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = dict(
        action=dict(
            module_name='set_fact',
            module_args=dict(
                cacheable=False,
                foo='bar',
                baz='qux',
                _ansible_verbose_always=True,
            ),
        ),
    )

    # Create a mock result object
    result = dict(
        ansible_facts=dict(
            foo='bar',
            baz='qux',
        ),
        _ansible_facts_cacheable=False,
    )

    # Create a mock action object
    action = ActionModule(task, dict())

    # Run the action module
    assert action.run() == result

# Generated at 2022-06-17 09:48:21.374661
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create a dummy task
    task = dict(action=dict(module='set_fact', args=dict(a=1, b=2)))
    # create a dummy play
    play = dict(hosts='all', gather_facts='no', tasks=[task])
    # create a dummy play context
    play_context = dict(play=play)
    # create a dummy loader
    loader = dict()
    # create a dummy templar
    templar = dict()
    # create a dummy shared plugin loader
    shared_plugin_loader = dict()

    # create an instance of ActionModule
    action_module = ActionModule(task, play_context, loader, templar, shared_plugin_loader)

    # assert that the instance is not None
    assert action_module is not None

# Generated at 2022-06-17 09:48:32.954954
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict(
        action=dict(
            module_name='set_fact',
            module_args=dict(
                cacheable=False,
                foo='bar',
                baz='qux',
            ),
        ),
    )

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock tmp
    tmp = None

    # Create a mock ansible_facts
    ansible_facts = dict()

    # Create a mock result
    result = dict(
        ansible_facts=ansible_facts,
        _ansible_facts_cacheable=False,
    )

    # Create a mock module_name
    module_name = 'set_fact'

    # Create a mock module_args

# Generated at 2022-06-17 09:49:13.697888
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(
            args=dict(
                cacheable=False,
                foo='bar',
                baz='qux',
            ),
        ),
        connection=dict(),
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None,
    )
    assert action_module is not None

# Generated at 2022-06-17 09:49:14.853843
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None) is not None

# Generated at 2022-06-17 09:49:21.237137
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object for the module_utils.basic.AnsibleModule class
    # with return values for methods called by the run method of the
    # ActionModule class
    import ansible.module_utils.basic
    import ansible.module_utils.parsing.convert_bool
    import ansible.utils.vars
    import ansible.utils.unsafe_proxy
    import ansible.utils.unsafe_proxy.AnsibleUnsafeText
    import ansible.utils.unsafe_proxy.AnsibleUnsafeBytes
    import ansible.utils.unsafe_proxy.AnsibleUnsafeDict
    import ansible.utils.unsafe_proxy.AnsibleUnsafeText
    import ansible.utils.unsafe_proxy.AnsibleUnsafeBytes
    import ansible.utils.unsafe_proxy

# Generated at 2022-06-17 09:49:22.503066
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:49:35.986372
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:49:47.466335
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no arguments
    action_module = ActionModule(dict(ANSIBLE_MODULE_ARGS={}))
    result = action_module.run(None, None)
    assert result['failed']
    assert result['msg'] == 'No key/value pairs provided, at least one is required for this action to succeed'

    # Test with invalid variable name
    action_module = ActionModule(dict(ANSIBLE_MODULE_ARGS={'foo-bar': 'baz'}))
    result = action_module.run(None, None)
    assert result['failed']
    assert result['msg'] == "The variable name 'foo-bar' is not valid. Variables must start with a letter or underscore character, and contain only letters, numbers and underscores."

    # Test with valid variable name

# Generated at 2022-06-17 09:49:54.392077
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create a dictionary of arguments to pass to the method run
    options = {'cacheable': False, 'var1': 'value1', 'var2': 'value2'}

    # Run the method run and assert the result
    assert action_module.run(task_vars=None, tmp=None, **options) == {'ansible_facts': {'var1': 'value1', 'var2': 'value2'}, '_ansible_facts_cacheable': False}

# Generated at 2022-06-17 09:50:01.306344
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_vars_from_inventory

# Generated at 2022-06-17 09:50:12.406115
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action = ActionModule(dict(), dict())
    assert action._task.args == dict()
    assert action._task.action == 'set_fact'
    assert action._task.action_plugin_name == 'set_fact'
    assert action._task.action_plugin_type == 'action'
    assert action._task.action_plugin_load == 1
    assert action._task.action_plugin_load_prio == 10
    assert action._task.action_plugin_persistent == False
    assert action._task.action_plugin_args == dict()
    assert action._task.action_plugin_kwargs == dict()
    assert action._task.action_plugin_deps == []
    assert action._task.action_plugin_deps_opts == dict()
    assert action._task.action_plugin_dep

# Generated at 2022-06-17 09:50:22.159836
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:51:55.802641
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    try:
        ActionModule()
    except Exception as e:
        assert type(e) == TypeError
    # Test with arguments
    try:
        ActionModule(dict(), dict())
    except Exception as e:
        assert type(e) == TypeError

# Generated at 2022-06-17 09:52:07.955996
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import ansible_local
    from ansible.module_utils.facts import ansible_processor
    from ansible.module_utils.facts import ansible_processor_cores
    from ansible.module_utils.facts import ansible_processor_count
    from ansible.module_utils.facts import ansible_processor_threads_per_core
    from ansible.module_utils.facts import ansible_processor_vcpus
    from ansible.module_utils.facts import ansible_product_name
    from ansible.module_utils.facts import ansible_product_serial
    from ansible.module_utils.facts import ansible_product_uuid

# Generated at 2022-06-17 09:52:10.594105
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:52:20.286644
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.utils.vars import isidentifier
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import Play

# Generated at 2022-06-17 09:52:28.477801
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(action=dict(module_name='set_fact', args=dict(a=1, b=2))),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module is not None

# Generated at 2022-06-17 09:52:37.596753
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict()
    task['args'] = dict()
    task['args']['cacheable'] = False
    task['args']['foo'] = 'bar'
    task['args']['baz'] = 'qux'
    task['args']['one'] = 'two'
    task['args']['three'] = 'four'
    task['args']['five'] = 'six'
    task['args']['seven'] = 'eight'
    task['args']['nine'] = 'ten'
    task['args']['eleven'] = 'twelve'
    task['args']['thirteen'] = 'fourteen'
    task['args']['fifteen'] = 'sixteen'
    task['args']['seventeen'] = 'eighteen'

# Generated at 2022-06-17 09:52:46.960250
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    am = ActionModule(None, None)

    # Create a dict with the task_vars
    task_vars = dict()

    # Create a dict with the args
    args = dict()

    # Create a dict with the result
    result = dict()

    # Create a dict with the facts
    facts = dict()

    # Create a dict with the ansible_facts
    ansible_facts = dict()

    # Create a dict with the _ansible_facts_cacheable
    _ansible_facts_cacheable = dict()

    # Create a dict with the tmp
    tmp = dict()

    # Create a dict with the _task
    _task = dict()

    # Create a dict with the _templar
    _templar = dict()

    # Create a dict with the template
   

# Generated at 2022-06-17 09:52:54.432656
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:53:01.867360
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a test object
    action = ActionModule()

    # Create a test task
    task = {
        'args': {
            'cacheable': False,
            'test_variable': 'test_value',
        },
    }

    # Create a test task_vars
    task_vars = {}

    # Run the method
    result = action.run(task_vars=task_vars, task=task)

    # Check the result
    assert result['ansible_facts']['test_variable'] == 'test_value'
    assert result['_ansible_facts_cacheable'] == False

# Generated at 2022-06-17 09:53:11.517012
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict()
    task['args'] = dict()
    task['args']['cacheable'] = False
    task['args']['foo'] = 'bar'
    task['args']['baz'] = 'qux'

    # Create a mock templar
    templar = dict()
    templar['template'] = lambda x: x

    # Create a mock action
    action = dict()
    action['_task'] = task
    action['_templar'] = templar

    # Create a mock result
    result = dict()
    result['ansible_facts'] = dict()
    result['_ansible_facts_cacheable'] = False

    # Create a mock ActionModule
    action_module = ActionModule()