

# Generated at 2022-06-17 09:43:36.902212
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None, None, None, None)
    assert am is not None

# Generated at 2022-06-17 09:43:39.196159
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    module = ActionModule(None, None, None, None)
    assert module is not None
    assert module.TRANSFERS_FILES is False

# Generated at 2022-06-17 09:43:42.461859
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of class ActionModule
    action_module = ActionModule(None, None, None, None, None)
    assert action_module is not None

# Generated at 2022-06-17 09:43:53.931980
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict()
    task['args'] = dict()
    task['args']['cacheable'] = False
    task['args']['key1'] = 'value1'
    task['args']['key2'] = 'value2'

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock templar
    templar = dict()
    templar['template'] = lambda x: x

    # Create a mock ActionBase
    action_base = dict()
    action_base['run'] = lambda x, y: dict()

    # Create a mock ActionModule
    action_module = dict()
    action_module['_task'] = task
    action_module['_templar'] = templar
    action_module['run'] = Action

# Generated at 2022-06-17 09:44:02.525593
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactory
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryImpl
    from ansible.module_utils.facts.system.distribution import LinuxDistributionImpl
    from ansible.module_utils.facts.system.distribution import LinuxDistributionImplRedHat
    from ansible.module_utils.facts.system.distribution import LinuxDistributionImplSuse
    from ansible.module_utils.facts.system.distribution import LinuxDistributionImplDebian
    from ansible.module_utils.facts.system.distribution import LinuxDistributionImplAlpine

# Generated at 2022-06-17 09:44:10.221868
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.utils.vars import isidentifier

    # Test with no args
    task_vars = dict()
    action = ActionModule(dict(name='test'), task_vars=task_vars)
    result = action.run(task_vars=task_vars)
    assert result['failed']
    assert result['msg'] == 'No key/value pairs provided, at least one is required for this action to succeed'

    # Test with args
    task_vars = dict()
    action = ActionModule(dict(name='test', args=dict(a='b')), task_vars=task_vars)

# Generated at 2022-06-17 09:44:20.168617
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'a': 'b'}

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock action_base
    action_base = MockActionBase()

    # Create a mock action_module
    action_module = ActionModule(task, templar, module_utils, action_base)

    # Call method run
    result = action_module.run()

    # Assert that the result is correct
    assert result == {'ansible_facts': {'a': 'b'}, '_ansible_facts_cacheable': False}


# Generated at 2022-06-17 09:44:32.677234
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no arguments
    action = ActionModule(dict(ANSIBLE_MODULE_ARGS=dict()))
    assert action.run() == dict(failed=True, msg='No key/value pairs provided, at least one is required for this action to succeed')

    # Test with invalid variable name

# Generated at 2022-06-17 09:44:43.093217
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import RedHatDistribution
    from ansible.module_utils.facts.system.distribution import RedHatDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import SuseDistribution
    from ansible.module_utils.facts.system.distribution import SuseDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import UbuntuDistribution

# Generated at 2022-06-17 09:44:47.436595
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None, None)
    assert action is not None

# Generated at 2022-06-17 09:44:53.133732
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:44:54.626028
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None, None)

# Generated at 2022-06-17 09:45:03.206680
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.constants as C
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import isidentifier
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import is_complex_data
    from ansible.utils.vars import is_sequence
    from ansible.utils.vars import is_scalar
    from ansible.utils.vars import is_list_of_strings
    from ansible.utils.vars import is_list_of_hashes
    from ansible.utils.vars import is_list_of_

# Generated at 2022-06-17 09:45:15.371790
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import RedHatDistribution
    from ansible.module_utils.facts.system.distribution import RedHatDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import SuseDistribution
    from ansible.module_utils.facts.system.distribution import SuseDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import UbuntuDistribution

# Generated at 2022-06-17 09:45:16.547770
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None)

# Generated at 2022-06-17 09:45:19.573004
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:45:22.001936
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:45:33.061666
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task object
    task = dict(
        args=dict(
            cacheable=False,
            foo='bar',
            baz='qux',
        )
    )

    # Create a mock task object
    task_vars = dict()

    # Create a mock ansible module object
    am = ActionModule(task, task_vars)

    # Run the constructor
    am.run(task_vars=task_vars)

    # Check the result
    assert am.run(task_vars=task_vars) == dict(
        ansible_facts=dict(
            foo='bar',
            baz='qux',
        ),
        _ansible_facts_cacheable=False,
    )

# Generated at 2022-06-17 09:45:40.402347
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create a dictionary to pass as arguments to method run
    arguments = {'cacheable': False}

    # Call method run
    result = action_module.run(task_vars=None, tmp=None, **arguments)

    # Assertions
    assert result['ansible_facts'] == {}
    assert result['_ansible_facts_cacheable'] == False


# Generated at 2022-06-17 09:45:41.786453
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None)
    assert action is not None

# Generated at 2022-06-17 09:46:02.679898
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.utils.vars import isidentifier
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.set_fact import ActionModule
    from ansible.utils.vars import merge_hash
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    import ansible.constants as C

    # Create a mock task

# Generated at 2022-06-17 09:46:12.693318
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test with a valid argument
    action = ActionModule(dict(a=1, b=2), dict(c=3, d=4))
    assert action._task.args['a'] == 1
    assert action._task.args['b'] == 2
    assert action._task_vars['c'] == 3
    assert action._task_vars['d'] == 4

    # test with an invalid argument
    try:
        action = ActionModule(dict(a=1, b=2), dict(c=3, d=4), dict(e=5, f=6))
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-17 09:46:25.942088
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.constants as C

    # Create a mock task
    class MockTask:
        def __init__(self):
            self.args = dict()

    # Create a mock play context
    class MockPlayContext:
        def __init__(self):
            self.check_mode = False

    # Create a mock connection
    class MockConnection:
        def __init__(self):
            self.become = False
            self.become_method = None
            self.become_user = None
            self.no_log = False

    # Create a mock templar
    class MockTemplar:
        def __init__(self):
            pass

        def template(self, data):
            return data

    # Create a mock loader
    class MockLoader:
        def __init__(self):
            pass



# Generated at 2022-06-17 09:46:30.889818
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:46:38.512334
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict(
        action=dict(
            module_name='set_fact',
            module_args=dict(
                key1='value1',
                key2='value2',
            ),
        ),
    )

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock tmp
    tmp = None

    # Create a mock result
    result = dict(
        ansible_facts=dict(
            key1='value1',
            key2='value2',
        ),
        _ansible_facts_cacheable=False,
    )

    # Create a mock action_base
    action_base = ActionBase()

    # Create a mock action_module

# Generated at 2022-06-17 09:46:39.818652
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None)

# Generated at 2022-06-17 09:46:47.417618
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict(
        args=dict(
            cacheable=False,
            var1='value1',
            var2='value2',
            var3='value3',
        )
    )

    # Create a mock result
    result = dict(
        ansible_facts=dict(
            var1='value1',
            var2='value2',
            var3='value3',
        ),
        _ansible_facts_cacheable=False,
    )

    # Create a mock action module
    action_module = ActionModule(task, dict())

    # Run the action module
    assert action_module.run() == result

# Generated at 2022-06-17 09:46:58.809191
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action = ActionModule(dict())
    assert action.run() == {'failed': True, 'msg': 'No key/value pairs provided, at least one is required for this action to succeed'}

    # Test with arguments
    action = ActionModule(dict(a=1, b=2))
    assert action.run() == {'ansible_facts': {'a': 1, 'b': 2}, '_ansible_facts_cacheable': False}

    # Test with arguments and cacheable
    action = ActionModule(dict(a=1, b=2, cacheable=True))
    assert action.run() == {'ansible_facts': {'a': 1, 'b': 2}, '_ansible_facts_cacheable': True}

    # Test with invalid variable name

# Generated at 2022-06-17 09:47:00.589018
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:47:09.545153
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create a mock for the class ActionBase
    action_base = ActionBase()

    # Create a mock for the class dict
    dict = {}

    # Set the attributes of the mock
    action_base.noop_task = False
    action_base.noop_on_check = False
    action_base.noop_on_diff = False
    action_base.noop_action = False
    action_base.noop_action_on_skipped_hosts = False
    action_base.noop_action_on_skipped_hosts_count = 0
    action_base.noop_action_on_skipped_hosts_count_filtered = 0
    action_base.noop_action_on_skipped_hosts

# Generated at 2022-06-17 09:47:26.735756
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:47:34.266214
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import RedHatDistribution
    from ansible.module_utils.facts.system.distribution import SuseDistribution
    from ansible.module_utils.facts.system.distribution import UbuntuDistribution
    from ansible.module_utils.facts.system.distribution import DebianDistribution
    from ansible.module_utils.facts.system.distribution import AlpineDistribution
    from ansible.module_utils.facts.system.distribution import GentooDistribution
    from ansible.module_utils.facts.system.distribution import Arch

# Generated at 2022-06-17 09:47:46.120814
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:47:56.815367
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'key1': 'value1', 'key2': 'value2'}

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock action_base
    action_base = MockActionBase()

    # Create a new ActionModule
    action_module = ActionModule(task, connection=None, play_context=None, loader=None, templar=templar, shared_loader_obj=None)

    # Run the run method
    result = action_module.run(tmp=None, task_vars=None)

    # Check the result

# Generated at 2022-06-17 09:48:00.172091
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None, None)

# Generated at 2022-06-17 09:48:01.958538
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:48:04.600375
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(a=1, b=2), dict(c=3, d=4))

# Generated at 2022-06-17 09:48:05.834472
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:48:08.015529
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:48:09.250904
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:48:57.834697
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import OpenBSDDistribution
    from ansible.module_utils.facts.system.distribution import OpenBSDDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import SystemV
    from ansible.module_utils.facts.system.distribution import SystemVFactCollector
    from ansible.module_utils.facts.system.distribution import UnixDist

# Generated at 2022-06-17 09:49:08.841293
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task

    # Create a mock task
    task = Task()
    task._role = None
    task.args = {'cacheable': False, 'ansible_facts': {'a': 1, 'b': 2}}

    # Create a mock connection
    connection = Connection()

    # Create a mock module
    module = Module()

    # Create a mock templar
    templar = Templar()

    # Create a mock loader
    loader = DataLoader()

    # Create a mock variable manager
    variable_manager = VariableManager()

    # Create a mock action plugin
    action_plugin = ActionModule(task, connection, templar, loader, variable_manager)

    # Run the method
    result = action_plugin.run(None, None)

    # Check the result

# Generated at 2022-06-17 09:49:19.739169
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict()
    task['action'] = 'set_fact'
    task['args'] = dict()
    task['args']['cacheable'] = False
    task['args']['test_fact'] = 'test_value'

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock tmp
    tmp = None

    # Create a mock result
    result = dict()
    result['ansible_facts'] = dict()
    result['ansible_facts']['test_fact'] = 'test_value'
    result['_ansible_facts_cacheable'] = False

    # Create an instance of ActionModule
    action_module = ActionModule(task, task_vars, tmp)

    # Test the run method

# Generated at 2022-06-17 09:49:35.237252
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import OpenBSDDistribution
    from ansible.module_utils.facts.system.distribution import SystemV
    from ansible.module_utils.facts.system.distribution import WindowsDistribution
    from ansible.module_utils.facts.system.distribution import WindowsServerDistribution
    from ansible.module_utils.facts.system.distribution import WindowsVersion
    from ansible.module_utils.facts.system.distribution import WindowsServerVersion
    from ansible.module_utils.facts.system.distribution import WindowsUpdate
    from ansible.module_utils.facts.system.distribution import WindowsServerUpdate

# Generated at 2022-06-17 09:49:38.475257
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    This function is used to test the constructor of the class ActionModule.
    """
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action is not None

# Generated at 2022-06-17 09:49:43.889399
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    module = ActionModule(None, None, None, None, None)
    assert module is not None
    assert module.TRANSFERS_FILES is False
    assert module.run(None, None) is not None

# Generated at 2022-06-17 09:49:51.822627
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_hash
    from ansible.utils.vars import combine_facts

# Generated at 2022-06-17 09:50:01.153571
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = dict(
        args=dict(
            cacheable=False,
            test_var='test_value'
        )
    )

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock loader
    loader = dict()

    # Create a mock templar
    templar = dict()

    # Create a mock display
    display = dict()

    # Create a mock action_base
    action_base = dict()

    # Create a mock connection
    connection = dict()

    # Create a mock play_context
    play_context = dict()

    # Create a mock AnsibleModule
    ansible_module = dict()

    # Create a mock ActionModule

# Generated at 2022-06-17 09:50:12.318780
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import isidentifier
    from ansible.utils.vars import merge_hash
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.unsafe_proxy import unwrap_var

    class ActionModule(ActionBase):
        def run(self, tmp=None, task_vars=None):
            return super(ActionModule, self).run(tmp, task_vars)


# Generated at 2022-06-17 09:50:13.462141
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:51:59.069568
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a mock task
    task = dict()
    task['action'] = dict()
    task['action']['__ansible_module__'] = 'set_fact'
    task['action']['__ansible_arguments__'] = '{"key1": "value1", "key2": "value2"}'
    task['action']['__ansible_module_name__'] = 'set_fact'
    task['action']['__ansible_module_args__'] = '{"key1": "value1", "key2": "value2"}'
    task['action']['__ansible_action_name__'] = 'set_fact'
    task['action']['__ansible_action_args__'] = '{"key1": "value1", "key2": "value2"}'

# Generated at 2022-06-17 09:52:10.166237
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files

# Generated at 2022-06-17 09:52:17.042986
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'a': 'b', 'c': 'd'}

    # Create a mock action module
    action_module = MockActionModule()
    action_module._task = task

    # Run the method
    result = action_module.run()

    # Check the result
    assert result['ansible_facts'] == {'a': 'b', 'c': 'd'}
    assert result['_ansible_facts_cacheable'] == False


# Generated at 2022-06-17 09:52:24.247551
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import RedHatDistribution
    from ansible.module_utils.facts.system.distribution import RedHatDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import SuseDistribution
    from ansible.module_utils.facts.system.distribution import SuseDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import UbuntuDistribution

# Generated at 2022-06-17 09:52:25.374504
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None)
    assert action is not None

# Generated at 2022-06-17 09:52:27.439468
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:52:37.297105
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = {
        'args': {
            'cacheable': False,
            'fact1': 'value1',
            'fact2': 'value2'
        }
    }

    # Create a mock task_vars
    task_vars = {}

    # Create a mock templar
    templar = {
        'template': lambda x: x
    }

    # Create a mock ansible_facts
    ansible_facts = {}

    # Create a mock result
    result = {
        'ansible_facts': ansible_facts,
        '_ansible_facts_cacheable': False
    }

    # Create a mock ActionBase
    action_base = {
        'run': lambda x, y: result
    }

    # Create a mock ActionModule

# Generated at 2022-06-17 09:52:47.002402
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_vars_from_inventory

# Generated at 2022-06-17 09:52:54.459973
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'cacheable': False, 'my_fact': 'my_value'}

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock module_utils.parsing.convert_bool
    convert_bool = MockConvertBool()

    # Create a mock module_utils.parsing.convert_bool.boolean
    boolean = MockBoolean()

    # Create a mock module_utils.parsing.convert_bool.boolean.boolean
    boolean.boolean = MockBooleanBoolean()

    # Create a mock module_utils.parsing.convert_bool.boolean.boolean.bo

# Generated at 2022-06-17 09:53:03.572092
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.constants as C
    C.DEFAULT_JINJA2_NATIVE = True
    action = ActionModule(dict(task=dict(args=dict(a=1, b=2, c=3))))
    result = action.run(None, dict())
    assert result['ansible_facts'] == dict(a=1, b=2, c=3)
    assert result['_ansible_facts_cacheable'] is False
    C.DEFAULT_JINJA2_NATIVE = False
    action = ActionModule(dict(task=dict(args=dict(a=1, b=2, c=3))))
    result = action.run(None, dict())
    assert result['ansible_facts'] == dict(a=1, b=2, c=3)