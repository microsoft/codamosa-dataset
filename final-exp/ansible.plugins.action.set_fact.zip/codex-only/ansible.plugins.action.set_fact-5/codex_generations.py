

# Generated at 2022-06-23 08:29:06.080104
# Unit test for constructor of class ActionModule
def test_ActionModule():
    
    action_module = ActionModule()

    assert action_module.TRANSFERS_FILES is False

# Generated at 2022-06-23 08:29:16.341441
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.constants as C
    import ansible.module_utils.parsing.convert_bool as convert_bool
    # Initialize task object
    action = ActionModule({}, {}, {}, '', {})
    # Initialize result object
    result = {}
    result['ansible_facts'] = {}
    result['_ansible_facts_cacheable'] = False
    # Initialize task_vars object
    task_vars = {}

    # No key/value pairs provided
    try:
        action.run(task_vars=task_vars)
        assert False
    except AnsibleActionFail:
        pass

    # Invalid key provided

# Generated at 2022-06-23 08:29:25.585033
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = dict()
    result['ansible_facts'] = dict()
    result['ansible_facts']['a'] = 1
    result['ansible_facts']['b'] = 2
    result['_ansible_facts_cacheable'] = True
    module = ActionModule()
    action = dict()
    action['a'] = "some_value"
    action['b'] = "some_other_value"
    action['c'] = "another_value"
    action['d'] = True
    action['f'] = False
    action['g'] = "True"
    action['h'] = "False"
    action['cacheable'] = True
    module._task = dict()
    module._task.args = action
    module._templar = dict()
    module._templar.template = lambda x: x

# Generated at 2022-06-23 08:29:26.137275
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-23 08:29:36.852684
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.set_fact import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.inventory.host import Host
    from ansible.modules.plugin_loader import add_all_plugin_dirs
    import os

    # We need to mock up the create() method in order to bypass some of the code in the
    # Task base class that is dependent on loading the role or collection.  This also allows
    # us to set the args to the Task() directly.

# Generated at 2022-06-23 08:29:47.844337
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.utils.vars as ansible_vars
    import tempfile
    from ansible.playbook.task import Task

    task = Task()
    task._role = None
    task.action = 'set_fact'
    task._ds = {}
    task.args = {'fact_name':'fact_value', 'cacheable':'no'}
    task._task_vars = {'role_path': '/home/vagrant/ansible/roles', 'playbook_dir': 'playbook_file_path', 'play_hosts': 'all'}
    mytmp = tempfile.NamedTemporaryFile(mode='r')
    myAction = ActionModule(task, ansible_vars)
    result = myAction.run(tmp=mytmp, task_vars=task._task_vars)

# Generated at 2022-06-23 08:29:48.455786
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    assert True

# Generated at 2022-06-23 08:29:50.777688
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert mod is not None
    assert isinstance(mod, ActionModule)

# Generated at 2022-06-23 08:29:52.013552
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, None)
    assert isinstance(module, ActionBase)

# Generated at 2022-06-23 08:29:56.041264
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """This test case tests the constructor of the ActionModule class
    """
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    a = action
    assert a is not None, "action should not be None"

# Generated at 2022-06-23 08:30:08.174577
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    This is a simple unit test for the constructor of the class ActionModule
    """
    action = {}
    action['name'] = 'setup'
    action['action'] = {}
    action['action']['__ansible_module__'] = 'setup'
    action['action']['__ansible_arguments__'] = {}
    action['action']['__ansible_arguments__']['fact_path'] = '/etc/ansible/facts.d'
    action['action']['__ansible_arguments__']['filter'] = '*'
    action['action']['__ansible_arguments__']['gather_subset'] = ['all']
    action['action']['__ansible_arguments__']['tasks'] = []

    connection = {}

# Generated at 2022-06-23 08:30:21.729769
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialise a test action module
    test_action_module = ActionModule(dict(ANSIBLE_MODULE_ARGS=dict(a=True, b='string', c=[1,2], d=3, cacheable=True)))
    test_action_module.runner = object()
    test_action_module._task = object()
    test_action_module._task._role = object()
    test_action_module._task._role._role_path = 'role_path'
    test_action_module._templar = object()
    test_action_module._templar.template = lambda x: x
    test_action_module.run()
    # Test cacheable option
    assert test_action_module.result['changed'] == False

# Generated at 2022-06-23 08:30:30.809070
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.module_utils.basic
    import ansible.plugins.action

    action = ansible.plugins.action.ActionModule(
            {'name': 'test',
             'module_args': {'ansible_variable_1': 'value1',
                             'ansible_variable_2': 'value2'},
             'args': {'ansible_variable_1': 'value1', 'ansible_variable_2': 'value2'}},
            ansible.module_utils.basic.AnsibleModule(
                argument_spec={'ansible_variable_1': {'default': 'value1', 'type':'str'},
                               'ansible_variable_2': {'default': 'value2', 'type':'str'}}))

# Generated at 2022-06-23 08:30:33.905593
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Test case for method run of class ActionModule
    '''
    pass


# Generated at 2022-06-23 08:30:35.936277
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule()
    assert x is not None, "ActionModule() constructor failed!"

# Generated at 2022-06-23 08:30:45.829928
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    from collections import Mapping

    if sys.version_info.major >= 3:
        from unittest.mock import MagicMock
        unicode = str
    else:
        from mock import MagicMock

    module = MagicMock()
    # Set up a task with the correct spec
    task_vars = dict(foo=42, bar=dict(baz=73))
    task = MagicMock(action=dict(module='set_fact', args=dict(one=True, two=2, three='3')),
                     args=dict(one=True, two=2, three='3'),
                     _templar=MagicMock(template=lambda x, vars: x)
                     )
    action = ActionModule(task, task_vars, tmp='/tmp', module_compression=None)



# Generated at 2022-06-23 08:30:56.059258
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Assumptions:
    # no arguments, (should fail)

    #basic
    assert_equal(dict(), ActionModule().run())

    # Assumptions:
    # arguments should be "variables" for this task
    # variables need to be cacheable

    # success with cacheable variables
    assert_equal(dict({ 'ansible_facts': dict({'a': 1, 'b': 'two'}), '_ansible_facts_cacheable': True}),
        ActionModule().run({'a': 1, 'b': 'two'}, {'cacheable': True}))

    # success with noncacheable variables, but not caching them (no change)

# Generated at 2022-06-23 08:31:04.784832
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup Mock Objects for testing
    mock_args = dict()
    mock_args['key1'] = 'value1'
    mock_args['key2'] = 'value2'

    mock_self = dict()
    mock_self['_task'] = dict()
    mock_self['_task']['args'] = dict()
    mock_self['_task']['args'].update(mock_args)

    # Call run method
    result = ActionModule().run(mock_self)

    # Assert expected results
    assert result['ansible_facts'] == {'key1': 'value1', 'key2': 'value2'}
    assert result['_ansible_facts_cacheable'] is False


# Generated at 2022-06-23 08:31:05.772184
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-23 08:31:08.004533
# Unit test for constructor of class ActionModule
def test_ActionModule():
    def ActionModule(ActionBase):
        pass
    return ActionModule

# Generated at 2022-06-23 08:31:10.809407
# Unit test for constructor of class ActionModule
def test_ActionModule():
    d = {}
    d['args'] = {}
    a = ActionModule(d)
    assert a.TRANSFERS_FILES == False



# Generated at 2022-06-23 08:31:16.332260
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.virtual
    import ansible.plugins.action.set_fact

    plugin = ansible.plugins.action.set_fact.ActionModule(
        ansible.module_utils.facts.system,
        ansible.module_utils.facts.virtual,
    )

    assert type(plugin) == ansible.plugins.action.set_fact.ActionModule

# Generated at 2022-06-23 08:31:17.298670
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert isinstance(a, ActionBase)

# Generated at 2022-06-23 08:31:30.276880
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a temporary action for testing of local
    class ActionModuleTmp(ActionModule):
        def run(self, tmp=None, task_vars=None):
            super(ActionModuleTmp, self).run(tmp, task_vars)

    # create a testarguments
    testarguments = {"ansible_facts": {"an_fact": "hello"}}
    task = {"action": {"__ansible_action__": "ActionModuleTmp", "args": testarguments}}
    action = ActionModuleTmp(task, None)
    # create a taskvars
    taskvars = {"ansible_facts": {"an_fact": "hellooooo"}}

    # run the test
    action.run(None, taskvars)
    # test the result
    assert taskvars["ansible_facts"] == testarg

# Generated at 2022-06-23 08:31:32.959234
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, 'run')
    assert hasattr(ActionModule(), 'run')

# Generated at 2022-06-23 08:31:43.850258
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.module_utils.facts
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.plugins.callback import CallbackBase

    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.constants import DEFAULT_VAULTS_ENCRYPT_IDENTITY_LIST
    from ansible.executor.process.worker import WorkerProcess

# Generated at 2022-06-23 08:31:54.480404
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Constructor of class ActionModule
    '''
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    import ansible.utils.template
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    t = Task()
    t._role = None
    t.args = dict()
    ctx = PlayContext()
    ctx._play = None
    ctx._task = t
    ctx._loader = DataLoader()
    t._role = None
    ctx._inventory = InventoryManager(loader=ctx._loader, sources='localhost,')

# Generated at 2022-06-23 08:31:59.430837
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule.TRANSFERS_FILES = False
    result = super(test_ActionModule_run, ActionModule().run() )
    assert result == 'No key/value pairs provided, at least one is required for this action to succeed'

# Generated at 2022-06-23 08:32:00.378901
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:32:01.012929
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-23 08:32:02.507516
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    del action
# test_ActionModule_run()

# Generated at 2022-06-23 08:32:13.062912
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = C.config.module_config.get('set_fact')
    action_plugin_class = ActionModule()
    action_plugin_class._templar = ''
    action_plugin_class._task = ''
    action_plugin_class._connection = ''
    action_plugin_class._play_context = ''
    action_plugin_class._loader = ''
    action_plugin_class._shared_loader_obj = ''
    action_plugin_class._logger = ''
    action_plugin_class._shared_loader_obj = ''
    action_plugin_class._config_module = ''
    action_plugin_class.action = ''
    action_plugin_class.action_loader = ''
    action_plugin_class.max_fail_percentage = ''
    action_plugin_class._config = module
    action_plugin_

# Generated at 2022-06-23 08:32:23.775857
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule

    # initialize the action plugin
    action_plugin = ActionModule('test', {}, False, False, None, None, None)

    # initialize mock module
    test_action_args = {'facts': {'test': 'test'}}
    test_action_task_vars = {}
    test_action_tmp = '/tmp'
    test_action_inject = {}
    test_action_complex_args = False
    test_action_no_log = False
    test_action_play_context = {}

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    # execute the action plugin with mocked module and parameters

# Generated at 2022-06-23 08:32:35.446661
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_utils_path = os.path.join(os.path.dirname(__file__), '..', '..', 'module_utils')
    if module_utils_path not in sys.path:
        sys.path.append(module_utils_path)
    from ansible.module_utils.common.removed import removed_module
    import ansible.module_utils.common.removed as removed
    removed.warn = lambda *args, **kwargs: None
    removed.deprecate = lambda *args, **kwargs: None

    # Create a mock task and task_vars

# Generated at 2022-06-23 08:32:47.726206
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    _task = type('Task', (), {'args': {'cacheable': 'no', 'foo': 'bar', 'asdf': 'jkl'}})
    _task.args = {'cacheable': 'no', 'foo': 'bar', 'asdf': 'jkl'}

    _action = type('ActionModule', (), {'_templar': None, '_task': _task})
    _result = _action.run()
    assert _result['changed'] is False
    assert _result['ansible_facts']['foo'] == 'bar'

    _action = type('ActionModule', (), {'_templar': None, '_task': _task})
    _result = _action.run(task_vars={'foo': 'foo'})
    assert _result['changed'] is False

# Generated at 2022-06-23 08:32:53.384433
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # the following is just a testcase to make sure the constructor works,
    # we are not testing the action itself

    # this module sends no datastructure as argument
    datastructure = {}

    am = ActionModule(datastructure, {})
    print(am)

# Generated at 2022-06-23 08:32:55.582931
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None)
    assert isinstance(action, ActionModule)

# Generated at 2022-06-23 08:32:56.854994
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)


# Generated at 2022-06-23 08:33:04.646417
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext

    class MockModule:
        def __init__(self):
            self.task_vars = {'fact1':'value1'}
            self.tmp = None
            self.task_vars = {}
            self.play_context = PlayContext()

        def set_options(self, args):
            self.task_args = args

    class MockTask:
        def __init__(self):
            self.args = {}

    class MockTemplar:
        def __init__(self):
            self.vars = {}
            self.args = None

        def set_available_variables(self, vars):
            self.vars = vars


# Generated at 2022-06-23 08:33:14.188410
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.utils.vars import combine_vars
    from ansible.vars.hostvars import HostVars

    # mock object for task
    class MyTask:
        args = dict()

    # mock object for runner
    class MyRunner:
        def __init__(self, connection=None, module_name=None, module_args=None, pattern=None, forks=None):
            self._tqm = None
            self._connection = connection
            self._module_name = module_name
            self._module_args = module_args
            self._pattern = pattern
            self._forks = forks

        def _get_task_vars(self, task, play=None, host=None):
            return dict()

        @property
        def basedir(self):
            return None


# Generated at 2022-06-23 08:33:22.499360
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Test the method run of class ActionModule.
    '''

    # Replace the original module
    module = ansible.modules.system.debug

    # Create a dummy module
    class TestModule(object):
        def __init__(self, argument_spec):
            pass

    ansible.modules.system.debug = TestModule
    assert ansible.modules.system.debug == TestModule

    # Create a dummy task
    class TestTask(object):
        def __init__(self, args=None):
            self.args = args

    # Create a dummy play
    class TestPlay(object):
        def __init__(self, loader=None, variable_manager=None, options=None, passwords=None):
            pass

    play = TestPlay()

    # Initialize the  task and the play
    task = TestTask

# Generated at 2022-06-23 08:33:23.882554
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # placeholder for unit tests
    return

# Generated at 2022-06-23 08:33:35.093152
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule()
    r = m.run(tmp='/tmp', task_vars={'test_var': 'foo'})
    assert r == {'changed': False, 'ansible_facts': {}, '_ansible_facts_cacheable': False}

    r = m.run(tmp='/tmp', task_vars={'test_var': 'foo'}, ansible_facts={'old_fact': 'old_fact_value'})
    assert r == {'changed': False, 'ansible_facts': {'old_fact': 'old_fact_value'}, '_ansible_facts_cacheable': False}


# Generated at 2022-06-23 08:33:48.044591
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Arrange

    # ActionModule.run will try to import modules. Ansible modules are in a path that does not exist on this machine
    # The following code will make the importer believe it has successfully imported a module even though the module does not exist
    # https://stackoverflow.com/questions/67631/how-to-import-a-module-given-the-full-path

    import sys, imp
    class FakeModule(object):
        def __init__(self, name):
            self.name = name
    sys.modules[FakeModule.__module__] = FakeModule('traceback')

    import traceback
    sys.meta_path.append(imp.find_module(FakeModule.__module__)[0])

    class FakeModule(object):
        def __init__(self, name):
            self.name = name


# Generated at 2022-06-23 08:33:59.909489
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext

    def get_play_context(host_list, **kwargs):
        host_list = [host_list] if isinstance(host_list, string_types) else host_list

# Generated at 2022-06-23 08:34:05.483604
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # setup
    action_module = ActionModule()
    action_module._templar = None

    tmp = None
    task_vars = None

    # exercise
    result = action_module.run(tmp, task_vars)

    # verify
    assert 'ansible_facts' in result
    assert '_ansible_facts_cacheable' in result


# Generated at 2022-06-23 08:34:06.976006
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not ActionModule.TRANSFERS_FILES, 'TRANSFERS_FILES must remain False for this action'

# Generated at 2022-06-23 08:34:11.444600
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = dict(action=dict(module='set_fact', args=dict()))
    action = ActionModule(task, None, None, None)
    assert action._templar is not None
    assert action._task is not None

# Generated at 2022-06-23 08:34:20.213941
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import ansible.plugins.action.set_fact as ActionModule_set_fact
    import json

    # Create arguments for method ActionModule.run
    args = dict()
    args['cacheable'] = 'true'
    args['hostvars'] = dict()
    args['hostvars']['test01.example.com'] = dict()
    args['hostvars']['test01.example.com']['ansible_host'] = '192.168.123.21'
    args['hostvars']['test01.example.com']['ansible_ssh_host'] = '192.168.123.21'
    args['hostvars']['test01.example.com']['ansible_port'] = '22'

# Generated at 2022-06-23 08:34:22.221098
# Unit test for constructor of class ActionModule
def test_ActionModule():

    am = ActionModule()

    assert am.TRANSFERS_FILES == False

# Generated at 2022-06-23 08:34:28.082724
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(None, dict(a=dict(b=1, c=2), d="{{b}}{{c}}"))
    result = action_module.run(None, dict(b=1, c=2))
    assert result.get('ansible_facts').get('d') == "12"
    assert result.get('_ansible_facts_cacheable') == False


# Generated at 2022-06-23 08:34:32.952653
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule(None, dict(name='foo', debug=False))
    # create a fake task
    task = dict(name='foo', action=dict(module='set_fact', args=dict(cacheable=True)))
    result = am.run(task_vars={}, tmp={}, task=task)
    assert 'ansible_facts' in result
    assert result['ansible_facts']['ansible_debug'] is None

# Generated at 2022-06-23 08:34:41.286781
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # initialization mock
    mock_self = dict()

    # mock test input
    mock_self['_task'] = dict()
    mock_self['_task']['args'] = {'test_key': 'test_value', 'test_key_2': 'test_value_2'}

    # mock test output
    expected_result = dict()
    expected_result['ansible_facts'] = {'test_key': 'test_value', 'test_key_2': 'test_value_2'}
    expected_result['_ansible_facts_cacheable'] = False

    # check if output from run matches expected_result
    result = ActionModule.run(mock_self, None, None)
    assert result == expected_result


# Generated at 2022-06-23 08:34:50.733066
# Unit test for method run of class ActionModule
def test_ActionModule_run():

	# Parameters
	tmp = None
	task_vars = {'ansible_facts':{'a':'b'},'ansible_distribution':'Debian'}
	type_str = type(str())
	type_int = type(int())
	a = ActionModule()
	a._task = {'args':{'cacheable':False}}
	a._templar = {"template":lambda x:x}
	a.runner = {'connection':'local'}
	# Test fact addition
	a._task['args']['test1'] = 123
	b = a.run(tmp, task_vars)
	assert 'ansible_facts' in b
	assert type_int == type(b['ansible_facts']['test1'])

# Generated at 2022-06-23 08:34:51.549467
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-23 08:34:56.413571
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Default args
    action = ActionModule("test_name", "test_text", "test_shared", {"test_action_vars": "action_vars"})
    assert(action != None)

    # Failing args
    try:
        actionFailed = ActionModule()
        assert(False)
    except TypeError:
        assert(True)

# Generated at 2022-06-23 08:34:59.522262
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test the constructor
    # ModuleManager is an 'internal' class so it's not imported in __init__
    # and it's not available to the constructor
    module_manager = 'module_manager'
    action = ActionModule(module_manager)
    assert action.module_manager == module_manager

# Generated at 2022-06-23 08:35:02.031490
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Testing ActionModule')
    action = ActionModule()
    del action

# Generated at 2022-06-23 08:35:04.237132
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(name='test', module_args={'arg1': 'val1', 'arg2': False}) is not None

# Generated at 2022-06-23 08:35:12.248371
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class FakeTask:
        def __init__(self):
            self.args = {'k1': 'v1', 'k2': 'v2'}

    task = FakeTask()

    action_module = ActionModule(task, {'_ansible_check_mode': True, '_ansible_verbosity': 3})
    action_module._templar = {'template': lambda x: 'templated'}

    action_module.run()
    assert action_module._task.args == {}, 'args are removed'

# Generated at 2022-06-23 08:35:13.306047
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, {}, None, None)
    assert am

# Generated at 2022-06-23 08:35:16.501636
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None, None, None, None, None)
    assert a is not None

# Generated at 2022-06-23 08:35:26.069286
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Test run() method of ActionModule"""

    # Build mock module
    class MockActionModule(ActionModule):
        pass

    mock_module = MockActionModule(
        action='setup',
        task_vars={'hostvars': {}},
        connection='network_cli',
        play_context=dict(become=False),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    # Test with key/value pairs
    result = mock_module.run()
    assert 'ansible_facts' in result
    assert result['ansible_facts']['key1'] == 'value1'
    assert result['ansible_facts']['key2'] == 'value2'
    assert result['ansible_facts']['key3'] == 'value3'

# Generated at 2022-06-23 08:35:32.734908
# Unit test for constructor of class ActionModule

# Generated at 2022-06-23 08:35:42.145337
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module._templar = ''
    action_module._task = ''
    action_module._task.args = ''
    action_module._task.args = {'key1':'value1','key2':'value2','key3':'value3'}
    print("Test: ActionModule - test_ActionModule_run")
    print("Return: " + str(action_module.run()))
if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-23 08:35:46.818470
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(task=None, connection=None,
                          play_context=None, loader=None,
                          templar=None, shared_loader_obj=None)
    module._task = None
    module._templar = None

    # no key/value pairs provided
    result = module.run(tmp=None, task_vars=None)
    assert result['failed'] is True
    assert result['msg'] == 'No key/value pairs provided, at least one is required for this action to succeed'

    # no variables found
    module._task = MockTask()
    module._task.args = {}
    result = module.run(tmp=None, task_vars=None)
    assert result['failed'] is True
    assert result['msg'] == 'Unable to create any variables with provided arguments'

    # set

# Generated at 2022-06-23 08:35:52.193241
# Unit test for constructor of class ActionModule
def test_ActionModule():
    fake_task = dict(
        action=dict(
            module_name=None,
            module_args=None,
        )
    )
    action = ActionModule(fake_task, dict())
    assert action.__class__.__name__ == "ActionModule"

# Generated at 2022-06-23 08:35:53.236966
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule()
    assert m is not None

# Generated at 2022-06-23 08:36:00.330750
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()
    am._task = EasyConfig(dict(args=dict(key1='value1', key2='value2')))
    r = am.run()
    print(r)
    assert r['ansible_facts'] == dict(key1='value1', key2='value2')

# Below is an easy way to test this class alone, it works only for this class
if __name__ == '__main__':
    import sys
    import types
    import unittest
    from ansible.module_utils.six import wraps

    # Unit tests for class ActionModule
    class ActionModule_test(unittest.TestCase):

        # Unit tests for method run of class ActionModule
        def run_test(self):
            am = ActionModule()

# Generated at 2022-06-23 08:36:05.178724
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(task=dict(args=dict(test_var="test value")), connection=dict())
    results = action.run(task_vars=dict())
    assert results["ansible_facts"]["test_var"] == "test value"
    assert results["changed"] == False


# Generated at 2022-06-23 08:36:09.814461
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Empty args
    a = ActionModule()
    a.task = {'args': {}}
    a.run()

    # Single identifier with value False
    a.task = {'args': {'first': False}}
    ret = a.run()
    assert ret['ansible_facts']['first'] == False

    # Single identifier with value True
    a.task = {'args': {'first': True}}
    ret = a.run()
    assert ret['ansible_facts']['first'] == True

# Generated at 2022-06-23 08:36:22.779217
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Testing method run of class ActionModule'''

    import ansible.plugins

    args = dict(cacheable=False,
                a=1,
                b=2,
                c=True,
                d=False,
                e='a=b',
                f='{{ somevar }}')

    am = ansible.plugins.action.ActionModule(dict(), dict(), False, True, False)
    assert am.run(None, dict(), args) == {
        '_ansible_facts_cacheable': False,
        'ansible_facts': {
            'a': 1,
            'b': 2,
            'c': True,
            'd': False,
            'e': 'a=b',
            'f': '{{ somevar }}'
        }
    }


# Generated at 2022-06-23 08:36:23.911871
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action is not None

# Generated at 2022-06-23 08:36:25.102791
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()

    assert( a.run(None, None) )

# Generated at 2022-06-23 08:36:27.003806
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Test ActionModule constructor
    '''
    action = ActionModule(None, None, None, None, None, None)
    assert action.TRANSFERS_FILES is False

# Generated at 2022-06-23 08:36:33.161816
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.constants as C
    module = ActionModule(dict(a=dict(b=1), _ansible_tmpdir='/tmp', _ansible_keep_remote_files=False, _ansible_no_log=False, _ansible_debug=False, _ansible_diff=False), C.DEFAULT_LOADER)
    # TODO: find a way to verify the constructor
    assert(module is not None)


# Generated at 2022-06-23 08:36:40.074415
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # prepare mocks
    task_vars = dict()
    tmp = None
    action = ActionModule(task=dict(args=dict(name="root", uid=0, gid=0, groups=["root", "wheel"], shell="/bin/bash")), task_vars=task_vars, tmp=tmp)

    # run method to be tested
    result = action.run()

    # assert methods
    assert isinstance(result, dict)

    # check if the method ran successfully
    assert not result.get('failed', True)

    # check if the expected variables exist
    assert result['ansible_facts'].get('uid') == 0
    assert result['ansible_facts'].get('gid') == 0
    assert result['ansible_facts'].get('groups') == ["root", "wheel"]
    assert result

# Generated at 2022-06-23 08:36:48.983852
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json
    import lib.action.modules

    # The 'assert' line is commented out because the object instantiation
    # tests passes a dictionary (kwargs) by reference.  This means the
    # object is instantiated in-place and then passed to TestActionModule.
    # So, TestActionModule's self gets instantiated with TestActionModule's
    # ActionModule, and not the imported ActionModule.
    # If a regular method (not a property) is added to TestActionModule, that
    # method does not exist in _modules or self, and the assert below fails.
    # assert isinstance(TestActionModule.ActionModule, lib.action.modules.ActionModule)

    # Create an instance of TestActionModule, and test that it is of the
    # expected type.
    TestActionModule = TestActionModule()

# Generated at 2022-06-23 08:36:51.709786
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, 'run')

# Generated at 2022-06-23 08:37:01.174316
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.playbook.task
    import ansible.utils.vars
    import ansible.vars.manager

    print('Test module: %s' % __file__)

    # Create a task without the required argument
    task = ansible.playbook.task.Task()
    task.args = dict()

    # Create an action module instance
    action_module = ActionModule(task, dict())

    # Pass arguments to the constructor of the class ActionModule
    # Task containing a dict of args, a dict of variables and
    # a dict of templar
    task.args['test_valid_variable_name'] = 'foo'
    task.args['test_invalid_variable_name'] = '1foo'

    variables = dict()

# Generated at 2022-06-23 08:37:01.837099
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-23 08:37:12.386797
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.vars import combine_vars
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    loader = AnsibleCollectionLoader()
    play = Play().load({
        'name': 'test',
        'hosts': 'localhost',
        'tasks': [
            {'set_fact': {'a': 1}}
        ]
    }, loader=loader, variable_manager=None)

    play._variable_manager = None
    play._tqm = None

    t = Task()
    t.action = 'set_fact'
    t._role = None
    t.args = {'a': 1}
    t.loader = loader
    t.block = None

# Generated at 2022-06-23 08:37:24.037955
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    """
    This method tests the ActionModule._run method.
    """

    action_module = ActionModule()
    action_module._task = dict()
    action_module._task['args'] = dict()
    action_module._task['args']['test_variable'] = 'test_value'
    action_module._task['args']['test_variable2'] = 'test_value2'
    action_module._task['args']['test_variable3'] = 'test_value3'

    test_result = action_module.run()

    assert test_result['ansible_facts']['test_variable'] == 'test_value'
    assert test_result['ansible_facts']['test_variable2'] == 'test_value2'

# Generated at 2022-06-23 08:37:26.640095
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert isinstance(module, ActionModule)

# Generated at 2022-06-23 08:37:31.107995
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task

    # Create the module object that we are going to test
    action_module = ActionModule(Task(), dict())

    task_vars = dict()
    result = action_module.run(task_vars=task_vars)
    assert result['failed']

# Generated at 2022-06-23 08:37:40.775112
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    In ActionModule_run() method, the all required keyword argument is self,
    and optional keyword argument is tmp and task_vars.
    tmp must be None, task_vars must be a dictionary, or a typeerror will be raised.
    :return: None
    """
    # Fix for this test is pending on merge of PR #15691

    # Check if tmp=None, task_vars is a dictionary
    # Expected result: method return normally
    from ansible.plugins.action.normal import ActionModule
    action_module = ActionModule()
    action_module.tmp = None
    action_module.task_vars = {}
    action_module.run()

    # Check if tmp is not None, task_vars is a dictionary
    # Expected result: method raise a TypeError
    action_module.tmp = 1

# Generated at 2022-06-23 08:37:44.506186
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None)
    # calling constructor with None parameters
    assert action is not None
    # calling constructor with None parameters
    action = ActionModule(None, {})
    assert action is not None
    # todo: write more unit tests for constructor of class ActionModule

# Generated at 2022-06-23 08:37:54.160708
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arguments
    import os
    import sys

    import json
    import unittest2 as unittest

    class TestActionModuleRun(unittest.TestCase):
        """UnitTest for Ansible class ActionModule"""

        def setUp(self):
            self.actionmodule = ActionModule()

        def tearDown(self):
            del self.actionmodule

        def test_ActionModule_run(self):

            arg1 = '{"key1": "val1", "key2": "val2"}'
            arg2 = {"cacheable": "false"}
            expected = """{
                "ansible_facts": {
                    "key1": "val1",
                    "key2": "val2"
                },
                "changed": false
            }"""

            result = self.actionmodule.run(arg1, arg2)

# Generated at 2022-06-23 08:38:02.633598
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(dict(name='test',
                               task_vars={}))

    # Test basic use cases
    facts = action._execute_module(dict(name='test',
                                        args=dict(a=1, b='c')))
    assert not facts.get('failed'), 'No error should be raised.'
    assert facts['ansible_facts']['a'] == 1, 'Basic set of facts without cacheable.'
    assert not facts.get('_ansible_facts_cacheable'), 'Cacheable should not be present.'

    # Test set of facts with cacheable flag
    facts = action._execute_module(dict(name='test',
                                        args=dict(a=1, b='c', cacheable=True)))
    assert not facts.get('failed'), 'No error should be raised.'

# Generated at 2022-06-23 08:38:11.634664
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #Test with valid input
    a = ActionModule(module_name='module', task_vars={})
    assert a.TRANSFERS_FILES == False
    assert isinstance(a._task.args, dict)
    assert a._task.args == {}
    assert isinstance(a._task.action, basestring)
    assert a._task.action == 'module'
    assert isinstance(a._task.module_vars, dict)
    assert a._task.module_vars == {}

# Generated at 2022-06-23 08:38:21.879309
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.plugins.action import ActionModule
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    host_list = [
        'localhost',
    ]

    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inv)
    host = inv.get_host('localhost')
    context = PlayContext()

# Generated at 2022-06-23 08:38:26.434007
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule(task=dict(args=dict(cacheable=False)), connection=None, play_context=dict(basedir='/'), loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-23 08:38:27.735069
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule('test', task_vars=[dict()])
    assert a

# Generated at 2022-06-23 08:38:34.474642
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''Test for constructor of class ActionModule'''

    t = ActionModule(
        task=dict(args=dict(var='val')),
        connection=dict(),
        play_context=None,
        loader=dict(),
        templar=dict(),
        shared_loader_obj=None)
    assert t is not None
    assert t.name == 'set_fact'

# Generated at 2022-06-23 08:38:42.927099
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create dict that mimicks a task_vars
    task_vars = dict()

    # Create dict that mimicks the value of a variable
    variable = dict()

    # Create dict that mimicks an action module
    action_module = dict()

    # Create dict that mimicks the task of an action module
    action_module['args'] = variable

    # Create dict that mimicks a result
    result = dict()

    # Create dict that mimicks a ansible_facts
    ansible_facts = dict()

    # Set the condition to True
    variable['cacheable'] = True

    # Set the variable name as a string and the variable value as a boolean
    variable['my_variable'] = 'True'

    # Create the ActionModule instance
    action_module = ActionModule(action_module, task_vars)

    # Run the action

# Generated at 2022-06-23 08:38:50.254045
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task

    task = Task()
    am = ActionModule(task, '/path/to/ansible/test/tmp')
    assert (isinstance(am, ActionModule))

# Generated at 2022-06-23 08:38:51.549039
# Unit test for constructor of class ActionModule
def test_ActionModule():
    t = ActionModule(None, None, None, None)
    assert t is not None

# Generated at 2022-06-23 08:38:55.757598
# Unit test for constructor of class ActionModule
def test_ActionModule():
    b = ActionModule({'ANSIBLE_MODULE_ARGS':{'priority':'40','weight':'40','host':'host.domain','record':'host','type':'A'}},None) # values taken from the playbook
    assert type(b) == ActionModule,'ActionModule not created'

# Generated at 2022-06-23 08:38:59.140557
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not bool(ActionModule)

# Generated at 2022-06-23 08:39:07.877899
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest
    import main

    class TestVarsModule(unittest.TestCase):
        def test_module_run(self):
            action=main.ActionModule(dict(ANSIBLE_MODULE_ARGS={'test_run':True}),None)

            result=action.run(None, dict(ansible_facts=dict(a='1')))
            self.assertTrue('ansible_facts' in result and 'a' in result['ansible_facts'] and result['ansible_facts']['a']=='1')

            result=action.run(None, dict(ansible_facts=dict(a='1')))
            self.assertTrue('ansible_facts' in result and 'a' in result['ansible_facts'] and result['ansible_facts']['a']=='1')

