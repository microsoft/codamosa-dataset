

# Generated at 2022-06-23 08:29:07.658614
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)


# Generated at 2022-06-23 08:29:18.132785
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 08:29:25.920725
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Define the test input data
    task_vars = {}
    task_vars['ansible_facts'] = {}
    task_vars['ansible_facts']['current_user'] = 'mock_user'

    task = {
        'action': 'set_fact',
        'args': {
            'output_name': 'mock_value',
            'cacheable': True
        },
        '__ansible_vars': task_vars,
    }

    # Instantiate an ActionModule
    action_module = ActionModule(task=task)

    # Unit test the result
    result = action_module.run(task_vars=task_vars)

    assert result['ansible_facts']['output_name'] == 'mock_value'

# Generated at 2022-06-23 08:29:36.654897
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of class ActionModule
    _action_module = ActionModule(None, {}, None)

    # These are the attributes we want to test on

# Generated at 2022-06-23 08:29:47.692005
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from io import StringIO
    from ansible.executor.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultLib

    # Setup
    fake_loader = DataLoader()
    fake_play_context = PlayContext()
    fake_vault_secret = VaultLib(fake_loader)
    fake_vault_secret = fake_vault_secret.read_vault_secret_file(fake_vault_secret.unparseable_vault_secret_files[0])
    fake_variable_manager = None
    fake_host_list = [{'hostname': 'foo'}]
    fake

# Generated at 2022-06-23 08:29:55.106781
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Start of unittest for ActionModule.run()")
    # Test with empty ActionModule
    print("\tTest with empty ActionModule")
    action_module = ActionModule()
    try:
        print("\t\t--> Executing ActionModule.run()")
        action_module.run()
        print("FAILED! Should raise exception")
    except AnsibleActionFail as e:
        print("PASSED! Exception as expected: " + str(e))
    except Exception as e:
        print("FAILED! Raised unexpected exception: " + str(e))
    # Test with empty ActionModule with arguments
    print("\tTest with empty ActionModule with arguments")
    action_module = ActionModule()

# Generated at 2022-06-23 08:30:08.089602
# Unit test for constructor of class ActionModule

# Generated at 2022-06-23 08:30:11.442444
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-23 08:30:24.732342
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def ActionModule_run():
        '''
        returns a dict with the following keys:
            _ansible_parsed: object representing the Ansible module that was called
            _ansible_facts_cacheable: whether we can cache the results or not
            failed: whether the module fail or not
            module_args: arguments passed to the module
            rc: exit code of the executable
            start:  time when the module execution started
            msg: error message
            stderr: stderr output of the module
            stdout: stdout output of the module
            end: time when the module execution ended
            delta: time spent into the module execution
        '''
        # The path where the module is saved

# Generated at 2022-06-23 08:30:25.663454
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action is not None

# Generated at 2022-06-23 08:30:34.050162
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    import ansible.constants as C

    my_vars_dict = {'var1': 'value1','var2': 'value2','var3': 'value3','var4': 'value4','var5': 'value5','var6': 'value6'}

    my_inventory = InventoryManager(loader=None, sources='localhost,')
    my_variable_manager = VariableManager(loader=None, inventory=my_inventory)
    my_variable_manager._extra_

# Generated at 2022-06-23 08:30:36.110090
# Unit test for constructor of class ActionModule
def test_ActionModule():
    resp = ActionModule(dict(failed=True), dict())
    assert resp

# Generated at 2022-06-23 08:30:45.829882
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_data = [
        {
            '_task': { 'args': {'a':10, 'b':20, 'c':30} },
            'assert': { 'ansible_facts': { 'a': 10, 'b': 20, 'c': 30 }, '_ansible_facts_cacheable': False },
        },
        {
            '_task': { 'args': {'var1': 'val1', 'var2': True} },
            'assert': { 'ansible_facts': { 'var1': 'val1', 'var2': True }, '_ansible_facts_cacheable': False },
        },
    ]
    am = ActionModule({}, {})
    for test in test_data:
        am._task = test['_task']
        result = am.run()

# Generated at 2022-06-23 08:30:47.104832
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:30:56.403541
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(task=None, connection=None, new_stdin='{"a":"A"}')
    TASK_VARS = dict()

    expected_result = {'ansible_facts': {'a': 'A'}, '_ansible_facts_cacheable': False}
    assert action.run(tmp=None, task_vars=TASK_VARS) == expected_result

    action = ActionModule(task=None, connection=None, new_stdin='{"a":"A", "b":"B"}')
    TASK_VARS = dict()
    expected_result = {'ansible_facts': {'a': 'A', 'b': 'B'}, '_ansible_facts_cacheable': False}

# Generated at 2022-06-23 08:31:06.061726
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create an instance of the class
    am = ActionModule()

    # print(am._task.args.pop('cacheable', False))

    assert am._task.args.pop('cacheable', False) == ''
    assert am._task.args.pop('cacheable', False) == False
    assert am._task.args.pop('cacheable', False) == False

    assert am._templar.template('OS') == 'OS'
    assert am._templar.template('OS') == 'OS'
    assert am._templar.template('OS') == 'OS'

    assert not isidentifier('OS')
    assert not isidentifier('OS')
    assert not isidentifier('OS')

    assert C.DEFAULT_JINJA2_NATIVE
    assert not C.DEFAULT_JINJA2_NATIVE

# Generated at 2022-06-23 08:31:12.182534
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # check for invalid variable names
    for variable in [
        "invalid variable",
        "invalid-variable",
        "invalid_variable!"
    ]:
        assert isidentifier(variable) == False
    # check for valid variable names
    for variable in [
        "validVariable",
        "valid_variable",
    ]:
        assert isidentifier(variable) == True

# Generated at 2022-06-23 08:31:23.465753
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 08:31:32.790179
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    mock_module_utils = {
        'parsing.convert_bool.boolean': lambda value, strict=False: value
    }
    with patch.multiple('ansible.plugins.action.set_fact', AnsibleModule=DEFAULT, ActionBase=DEFAULT,
                        C=DEFAULT, isidentifier=DEFAULT) as mocks:
        try:
            set_fact = mocks['AnsibleModule']
        except KeyError:
            set_fact = mocks[0]

        set_fact.ANSIBLE_RETURN = Mock(return_value={'changed': False})
        set_fact.reset_mock()

        # Case 1: validate params
        # Case 1.1: no key/value pairs provided
        am = ActionModule(None, dict(ANSIBLE_MODULE_ARGS={}))

# Generated at 2022-06-23 08:31:35.729663
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    p = PlayContext()
    assert ActionModule(None, {}, p, {})

# Generated at 2022-06-23 08:31:37.492156
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 08:31:46.366597
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    unit test for method run of class ActionModule
    '''
    # pylint: disable=global-statement
    global C

    C.DEFAULT_JINJA2_NATIVE = False

    test_object = ActionModule(None, {'name': 'set_fact', 'args': {'valid_variable': 'valid_value'}}, load_plugins=False, task_uuid=None)
    assert test_object.run() == {'ansible_facts': {'valid_variable': 'valid_value'}, '_ansible_facts_cacheable': False}, 'Incorrect result from set_fact'

    test_object = ActionModule(None, {'name': 'set_fact', 'args': {'valid.variable': 'valid_value'}}, load_plugins=False, task_uuid=None)


# Generated at 2022-06-23 08:31:56.704067
# Unit test for constructor of class ActionModule
def test_ActionModule():
    global __file__
    import os
    import signal
    import shlex
    import sys

    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager

    sys.argv = ['/tmp/ansible', '-i', 'ansible/tests/inventory', '-']
    signal.signal(signal.SIGPIPE, signal.SIG_DFL)
    os.environ["ANSIBLE_CONFIG"]= "/tmp/ansible.cfg"

# Generated at 2022-06-23 08:31:57.457499
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_action = ActionModule()

# Generated at 2022-06-23 08:32:06.036025
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Setup
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    variable_manager = VariableManager()
    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    task = Task()

    action = ActionModule()
    action._templar = 'templar'
    action._loader = 'loader'
    action._task = task
    action._shared_loader_obj = 'shared_loader_obj'
    action._connection = 'connection'
    action._play_context = 'play_context'

# Generated at 2022-06-23 08:32:06.751395
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:32:07.419591
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:32:16.840567
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Unit: Fail: no arguments
    def _run_fail_no_arguments():
        am = ActionModule({}, {}, {})
        am.run()
    import pytest
    with pytest.raises(AnsibleActionFail) as exc:
        _run_fail_no_arguments()
    assert exc.value.message == 'No key/value pairs provided, at least one is required for this action to succeed'

    # Unit: Fail: non-valid key/argument
    def _run_fail_non_valid_key_argument():
        am = ActionModule({}, {}, {})
        am.task.args['a b'] = 'value'
        am.run()
    with pytest.raises(AnsibleActionFail) as exc:
        _run_fail_non_valid_key_argument()
   

# Generated at 2022-06-23 08:32:27.838088
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action = ActionModule(None, {'_ansible_verbosity': 0}, None, None, None, None)

    task_vars = dict()

    class Task(object):
        def __init__(self):
            self.args = dict()
        def set_status(self, status):
            pass

    class Play(object):
        def __init__(self):
            self.hosts = dict()

    class PlayContext(object):
        def __init__(self):
            self.play = Play()

    class TaskContext(object):
        def __init__(self):
            self.play = Play()
            self.play_context = PlayContext()

    class TaskVars(object):
        def __init__(self):
            self._templated_fields = dict()

    task = Task()
    task

# Generated at 2022-06-23 08:32:37.640670
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Unit test class variables
    # module_utils.parsing.convert_bool.boolean('yes')
    boolean_yes = True
    # module_utils.parsing.convert_bool.boolean('true')
    boolean_true = True
    # module_utils.parsing.convert_bool.boolean('false')
    boolean_false = False
    # module_utils.parsing.convert_bool.boolean('no')
    boolean_no = False
    # module_utils.parsing.convert_bool.boolean('42')
    boolean_42 = True

    # test actionmodule.ActionModule.run
    # test args:
    #   ansible_facts={}
    ansible_facts = {}
    #   cacheable=False
    cacheable = False
    #  

# Generated at 2022-06-23 08:32:45.393642
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    import sys
    import imp
    import shutil
    import tempfile

    from ansible.playbook.play_context import PlayContext

    # Create a temporary directory
    tempdir = tempfile.mkdtemp()

    # Generate a test action module

# Generated at 2022-06-23 08:32:47.268362
# Unit test for constructor of class ActionModule
def test_ActionModule():

    a = ActionModule()
    assert a.TRANSFERS_FILES == False


# Generated at 2022-06-23 08:32:48.562977
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert isinstance(am, ActionModule)

# Generated at 2022-06-23 08:33:00.369782
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.playbook.task import Task

    am = ActionModule(Task(), dict(ANSIBLE_MODULE_ARGS='{"foo":"bar"}'))

    ret = am.run(task_vars={})
    assert ret['ansible_facts']['foo'] == 'bar'
    assert ret['_ansible_facts_cacheable'] is False

    # test a Unicode value
    am = ActionModule(Task(), dict(ANSIBLE_MODULE_ARGS='{"foo":{"bar":"baz"}}'))
    ret = am.run(task_vars={})
    assert ret['ansible_facts']['foo'] == {u'bar': u'baz'}
    assert ret['_ansible_facts_cacheable'] is False

    # test

# Generated at 2022-06-23 08:33:12.438000
# Unit test for constructor of class ActionModule
def test_ActionModule():
    fixture_data = {
        'action': {
            'module_arguments': {
                'foo': 'bar',
                'baz': 'qux'
            },
            'module_name': 'constant_action',
            'module_complex_args': {}
        },
        'task': {
            'name': 'TASK_NAME'
        },
        'play': {
            'name': 'PLAY_NAME'
        },
        'default_vars': dict()
    }

    test_object = ActionModule(fixture_data, 'constant_action', play_context='CONSTANT_PLAY_CONTEXT')
    assert test_object.name() == 'constant_action'
    assert test_object.play_context == 'CONSTANT_PLAY_CONTEXT'

    test_object = ActionModule

# Generated at 2022-06-23 08:33:23.002421
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import sys
    import logging
    import unittest
    import ansible.plugins.action as action
    import ansible.plugins.action.assert_fact
    import ansible.plugins.action.assert_facts
    import ansible.plugins.action.copy
    import ansible.plugins.action.debug
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.inventory.manager import InventoryManager
   

# Generated at 2022-06-23 08:33:33.472385
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    AM = ActionModule(0, {'cacheable': False, 'name': 'test', 'foo': 'bar'})
    assert AM.run() == {'ansible_facts': {'foo': 'bar'}, '_ansible_facts_cacheable': False}

    AM = ActionModule(0, {'cacheable': 'true', 'name': 'test', 'ansible_python_version': '2.7.2'})
    assert AM.run() == {'ansible_facts': {'ansible_python_version': '2.7.2'}, '_ansible_facts_cacheable': True}

    AM = ActionModule(0, {'cacheable': 'False', 'name': 'test', 'ansible_python_version': '2.7.2'})

# Generated at 2022-06-23 08:33:36.123137
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins
    action = ansible.plugins.action.ActionModule("test", {})
    assert action.TRANSFERS_FILES == False



# Generated at 2022-06-23 08:33:38.517863
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule('', {}, {}, {})

# Generated at 2022-06-23 08:33:39.558826
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionModule)

# Generated at 2022-06-23 08:33:50.201748
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.parsing.convert_bool import boolean

    # Create a ActionModule object
    mod = ActionModule(
        {'name': 'setup', '_uses_shell': False, '_raw_params': '{}'},
        {'playbook_dir': '/playbook'},
        load_plugins=False,
        runner_queue=None,
        # FIXME: AnsibleModule object, check_mode is required by AnsibleModule
        ansible_module=None,
        check_mode=False,
        runner_path='/runner_path'
    )

    # Create a AnsibleModule object
    AnsibleModule = ActionBase._shared_loader_obj.module_loader.get_module('AnsibleModule')

# Generated at 2022-06-23 08:33:53.553353
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test when no args provided
    args = {}
    task = dict(args=args)
    action_mod = ActionModule(task, dict())
    assert not action_mod


# Generated at 2022-06-23 08:33:59.223364
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    unit test for run method of class ActionModule
    """
    actionModule = ActionModule(None, None, None, None)
    result = actionModule._execute_module(None, None, None)
    assert result['failed'] == True

    result = actionModule.run()
    assert result['failed'] == True

# Generated at 2022-06-23 08:34:09.439400
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a AnsibleTask object with a dictionary specifying some task data
    action = {
        'delegate_to': 'i-should-not-exists',
        'delegate_facts': True,
        'register': 'myvar',
        '_ansible_verbose_always': True,
        '_ansible_no_log': True,
    }

    # Create an ActionModule object to use within a with statement
    am = ActionModule(action, [])

    # Make the object a context manager so __enter__ is called
    with am:
        # Verify some values are as expected
        assert am._tmp     == '/tmp/ansible-tmp-1376898375.3-58435678823744'
        assert am._task_vars is None

# Generated at 2022-06-23 08:34:11.577336
# Unit test for constructor of class ActionModule
def test_ActionModule():

    x = ActionModule()
    try:
        assert(isinstance(x, ActionBase))
    except AssertionError as e:
        raise e

# Generated at 2022-06-23 08:34:20.303142
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(None, None)

    # Test with no arguments
    try:
        action.run(None, None)
        assert False, "AnsibleActionFail not raised"
    except AnsibleActionFail as e:
        assert "No key/value pairs provided, at least one is required for this action to succeed" in e.message

    # Test with a valid argument and cacheable = False
    task_args = dict(cacheable = False, test = 'is this a valid value')

# Generated at 2022-06-23 08:34:30.471198
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    
    from collections import namedtuple
    from ansible.module_utils.parsing.convert_bool import boolean
    
    from ansible.plugins.action.set_fact import ActionModule
    
    # Fake some data
    FakeTask = namedtuple("task", ["args", "register"])
    FakeModule = namedtuple("module", ["_templar", "jsonify"])
    FakeTemplar = namedtuple("templar", ["template"])
    
    FakeArgs = namedtuple("args", ["cacheable", "keys"])
    
    task_vars = {}
    tmp = None
    keys = {"myvar": "some value", "some_bool": "yes"}
    cacheable = "yes"
    task = FakeTask(FakeArgs(cacheable, keys), "register")
    module

# Generated at 2022-06-23 08:34:39.623076
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a temporary file
    import tempfile
    f = tempfile.NamedTemporaryFile(delete=False)

    # Initialise the class ActionModule with parameters
    action_module = ActionModule(task=dict(action=dict(module_name='debug', args={'msg': 'Hello World!'})), play_context=dict(remote_addr='127.0.0.1'), connection=None, new_stdin=None)

    # call method run
    result = action_module.run()
    import pprint
    pprint.pprint(result)

    # Remove the temporary file
    import os
    os.unlink(f.name)

# Generated at 2022-06-23 08:34:49.717163
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from collections import namedtuple
    from ansible.executor import task_queue_manager
    from ansible.plugins.action.debug import ActionModule
    from ansible.vars import VariableManager
    from ansible.utils.vars import combine_vars

    mock_loader = namedtuple('mock_loader', ['get_basedir'])
    mock_loader.get_basedir.return_value = '/'

    variable_manager = VariableManager()
    variable_manager._fact_cache = dict()
    variable_manager.extra_vars = {'ansible_verbosity': 0}

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'ansible_verbosity': 0}

# Generated at 2022-06-23 08:34:59.666143
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 08:35:01.623496
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-23 08:35:07.295467
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ac = ActionModule(dict(a=1, b=2, c='https://github.com/ansible/ansible/issues/39873'), dict())
    assert ac
    assert ac._task == dict(a=1, b=2, c='https://github.com/ansible/ansible/issues/39873')
    assert ac._connection == dict()


# Generated at 2022-06-23 08:35:09.509969
# Unit test for constructor of class ActionModule
def test_ActionModule():
    "Just to test constructor"
    module = ActionModule(None, None, None)
    assert module.TRANSFERS_FILES == False

# Generated at 2022-06-23 08:35:17.325137
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import LoadTaskResult
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.manager import VariableManager

    task = Task(dict(action=dict(module='set_fact')))
    task._role = dict(vars=dict(test=dict(a=1, b=2)))

# Generated at 2022-06-23 08:35:21.890331
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        {'delegate_to': 'localhost'},
        0, # dummy connection
        task_vars=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module

# Generated at 2022-06-23 08:35:30.239210
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = dict(a = dict(b = dict(c = dict(d = dict(e = "foo")))))

# Generated at 2022-06-23 08:35:34.441866
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class AnsibleModule:
        def __init__(self):
            self.run_command_environ_update = {}
    import sys
    sys.modules['ansible.module_utils.basic'] = Ansi

# Generated at 2022-06-23 08:35:38.493180
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule(None, None)
    assert isinstance(x, ActionModule)


# Generated at 2022-06-23 08:35:41.439411
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

if __name__ == '__main__':
    import sys
    import pytest
    sys.exit(pytest.main(['-x', __file__]))

# Generated at 2022-06-23 08:35:43.068680
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, dict())
    assert isinstance(action_module, ActionModule)


# Generated at 2022-06-23 08:35:50.673352
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Fails
    with pytest.raises(AnsibleActionFail):
        am = ActionModule(dict(a='a'), task_vars={})
        am.run()

    # Suss without cacheable
    am = ActionModule(dict(a='a', b='b'), task_vars={})
    assert am.run() == {
        'ansible_facts': {'a': 'a', 'b': 'b'},
        '_ansible_facts_cacheable': False
    }

    # Cacheable
    am = ActionModule(dict(c='c', d='d', cacheable=True), task_vars={})

# Generated at 2022-06-23 08:35:58.821493
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.yaml.objects import AnsibleUnicode

    am = ActionModule(AnsibleModule())

    am._task.args = dict()
    print('should raise:')
    am.run()

    am._task.args = dict(a='b')
    print('should not raise:')
    am.run()

    am._task.args = dict(a='b', c='d')
    print('should not raise:')
    am.run()

    am._task.args = dict(a='true')
    print('should not raise:')
    am.run()

    am._task.args = dict(a=AnsibleUnicode('true'))
    print('should not raise:')
    am.run()



# Generated at 2022-06-23 08:36:09.796628
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  # initialize test variables
  filename = "acme_users.yml"
  tmppath = "/tmp"
  tmpdir = tempfile.mkdtemp()
  data = """
---
users:
  - name: myuser
    password: mypassword
    phone: 123-123-1234
    email: myuser@acme.com
  - name: {{ ansible_hostname }}
    password: {{ lookup('pipe', 'openssl rand -base64 12') }}
    phone: 123-123-4321
    email: {{ ansible_hostname }}@acme.com
  """
  inventory = AnsibleInventory(host_list = [])

  # create the temporary YAML file
  f = open(os.path.join(tmpdir, filename), 'w')
  f.write(data)
 

# Generated at 2022-06-23 08:36:18.565996
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' test ActionModule constructor'''
    module = ActionModule(task=None, connection=None, _play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module._templar == templar
    assert module._loader == loader
    assert module._shared_loader_obj == shared_loader_obj
    assert module._task is None
    assert module._connection is None
    assert module._play_context is None


# Generated at 2022-06-23 08:36:20.034614
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-23 08:36:25.638939
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Construct an instance of ActionModule
    am = ActionModule()
    result = am.run(None, None)

    # Assert that proper output is returned
    assert result['msg'] == 'No key/value pairs provided, at least one is required for this action to succeed'
    assert result['failed'] == True
    assert result['rc'] == 256

# Generated at 2022-06-23 08:36:32.261130
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None)
    assert am
    assert am.TRANSFERS_FILES == False

    # add_cleanup_cmd to run after
    # am.add_cleanup_cmd(None, None)
    # rm the add_cleanup_cmd added
    # am.cleanup_commands.pop()

    # add_remote_tmp to run after
    # am.add_remote_tmp(None, None)
    # rm the add_remote_tmp added
    # am.remote_commands.pop()

    assert am.run(None, None)

# Generated at 2022-06-23 08:36:38.451473
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # init a mock object
    mock_object = ActionModule()

    # init action
    action = {}
    action['name'] = 'debug'
    action['args'] = 'msg=TEST MESSAGE'

    # init task
    task = {}
    task['action'] = action
    task['delegate_to'] = None
    task['become'] = False
    task['become_method'] = None
    task['become_user'] = None

    # init connection
    connection = {}
    connection['transport'] = 'connection/ssh'
    connection['host'] = '192.168.1.10'
    connection['port'] = 22
    connection['user'] = 'test'

# Generated at 2022-06-23 08:36:48.440151
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 08:36:51.167861
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule, type)

# Generated at 2022-06-23 08:37:00.831815
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    assert module.templar.template("{{ 'a' + 'b'}}") == 'ab'
    module._task.args = {'name': 'My Name is'}
    module._task.args = {'age': 'My age is'}
    module._task.args = {'great': 'My great is'}
    module._task.args = {'country': 'My country is'}
    assert module.run(task_vars={'name': 'Ansible', 'age': '25', 'great': 'Yes', 'country': 'USA'}) == {'ansible_facts': {'name': 'My Name is', 'age': 'My age is', 'great': 'My great is', 'country': 'My country is'}, '_ansible_facts_cacheable': False}

# Generated at 2022-06-23 08:37:06.562280
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Constructor of class ActionModule
    """
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module.run(None, None)

# Generated at 2022-06-23 08:37:08.028952
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, "Unimplemented test"



# Generated at 2022-06-23 08:37:12.213895
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # action_module = ActionModule(None)
    # assert action_module.run() == 'ActionModule.run'
    pass

# Generated at 2022-06-23 08:37:23.229722
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 08:37:26.206032
# Unit test for constructor of class ActionModule
def test_ActionModule():
  am = ActionModule()
  print ("ActionModule object am = %s", am)

# Generated at 2022-06-23 08:37:34.689613
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Test several values for v that should raise an exception
    for v in [[1], [1,2], 'True', 'true']:
        try:
            ActionModule('1', '2', {'v':v})
        except AnsibleActionFail:
            assert True
        else:
            assert False

    # Test valid v
    try:
        ActionModule('1', '2', {'v':'1'})
        assert True
    except AnsibleActionFail:
        assert False

    # Test valid v when DEFAULT_JINJA2_NATIVE is True
    C.DEFAULT_JINJA2_NATIVE = True
    try:
        ActionModule('1', '2', {'v':'true'})
        assert True
    except AnsibleActionFail:
        assert False

# Generated at 2022-06-23 08:37:35.689875
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    results = ActionModule.run()

# Generated at 2022-06-23 08:37:41.176341
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(is_localhost=True, task_uuid='49842cc86e2211e6b9d6b4e96dbe5c5d', task=None, connection=None,
                        play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-23 08:37:49.804308
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.utils.vars
    import ansible.errors
    import ansible.module_utils.parsing.convert_bool
    import ansible.constants

    # get_exception
    ##############
    am = ActionModule(task=dict(args=dict(a=dict(b=dict(c=dict())))))
    assert am.get_exception() == 'a.b.c not found in'
    am = ActionModule(task=dict(args=dict(a=dict(b=dict(c=99)))))
    assert am.get_exception() == 'a.b.c expected a dictionary or a list of dictionaries but got a <class \'int\'>: 99'
    am = ActionModule(task=dict(args=dict(a=dict(b=dict(c=[88])))))

# Generated at 2022-06-23 08:37:52.885302
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task={'args':{'cacheable':False}}, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.TRANSFERS_FILES == False

# Generated at 2022-06-23 08:38:03.430289
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    hostname = 'hostname'
    args = {
        'key1': 'value1',
        'key2': 'value2',
    }
    result = {
        'ansible_facts': {},
        'changed': False,
    }
    task_vars = dict()
    obj = ActionModule()
    obj._task = mock.Mock()
    obj._task.args = args.copy()
    obj._task.action = 'someaction'
    obj._task.async_val = 0
    obj._task.loop = None
    obj._task.notify = []
    obj._task.run_once = False
    obj._play_context = mock.Mock()
    obj._play_context.remote_addr = None
    obj._play_context.network_os = None
    obj._play_

# Generated at 2022-06-23 08:38:10.047395
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = __import__('ansible.plugins.action.set_fact', fromlist=list(['ActionModule']))

    actmod = module.ActionModule()
    actmod._templar = "testtmp"
    actmod._task = "task"
    actmod._task.args = dict(c=dict(a="b"))

    assert actmod.run('tmp')

# Generated at 2022-06-23 08:38:17.537849
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 08:38:18.525226
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    action.set_runner(ActionBase())
    assert isinstance(action, ActionModule)

# Generated at 2022-06-23 08:38:26.817887
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.plugins.action import ActionBase
    from ansible.plugins.loader import find_plugin

    task_args = {
        ['key']:'value',
        ['key2']:'value2'
    }
    task = {
        'action': '',
        'args': task_args,
        'delegate_to': '',
        'delegate_facts': False,
        'register': 'result',
        'run_once': False
    }

    task_vars = {}
    hostvars = {}
    play_context = {}

    # Method run() of class ActionModule
    action = find_plugin('action', 'set_fact')
    action_result = action.run

# Generated at 2022-06-23 08:38:27.652730
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:38:28.924592
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert isinstance(a, ActionModule)

# Generated at 2022-06-23 08:38:33.310652
# Unit test for constructor of class ActionModule
def test_ActionModule():
    args = dict(
    )
    a = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # This should not raise an exception
    ActionModule(task={'args':args}, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-23 08:38:42.950474
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # No exception for empty dict
    am = ActionModule({}, {}, {})
    am.run()

    # No exception for valid keys/value pairs
    am = ActionModule({'ansible_facts': {'foo': 'bar'}}, {}, {})
    am.run()

    # Exception if not all keys are valid
    try:
        am = ActionModule({'ansible_facts': {'foo,bar': 'bar'}}, {}, {})
        am.run()
    except AnsibleActionFail as e:
        assert 'not valid' in e.message

    # Exception if not all values are valid

# Generated at 2022-06-23 08:38:53.279739
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create a fake task and play context to be able to create a fake task
    # and create a fake loader to be able to create fake templar
    class FakeTask():
        def __init__(self):
            self.args = { 'cacheable': False }

    class FakePlayContext():
        def __init__(self):
            self.check_mode = False

    class FakeLoader():
        def __init__(self):
            self.basedir = None

        @staticmethod
        def get_basedir(path):
            return '/'

        @staticmethod
        def path_dwim(path):
            return path

    class FakeTemplar():
        def __init__(self):
            self._available_variables = []

        @staticmethod
        def template(key):
            return key

    # Create fake task

# Generated at 2022-06-23 08:38:53.973072
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-23 08:39:01.758807
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(dict(task=dict(args=dict(k=1, b=True, c="test"))), None)
    results = action.run(tmp=None, task_vars=dict())
    assert not results['failed']
    assert results['ansible_facts'] == dict(k=1, b=True, c="test")

    action = ActionModule(dict(task=dict(args=dict(k=1))), None)
    results = action.run(tmp=None, task_vars=dict())
    assert not results['failed']
    assert results['ansible_facts'] == dict(k=1)

    action = ActionModule(dict(task=dict(args=dict())), None)
    results = action.run(tmp=None, task_vars=dict())
    assert results['failed']

# Generated at 2022-06-23 08:39:06.166559
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule({}), ActionBase)
    assert isinstance(ActionModule({}).run({}, {}), dict)
    assert isinstance(ActionModule({'name': 'test_module'}), ActionBase)
    assert isinstance(ActionModule({'name': 'test_module'}).run({}, {}), dict)