

# Generated at 2022-06-23 08:29:12.359401
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert C.DEFAULT_JINJA2_NATIVE

    # test with a task that does not require caching
    action_module = ActionModule(
        task=dict(
            args=dict(a=1, b=2, c='true', d='no', e='{{ foo }}')
        ),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    assert action_module.run() == dict(
        changed=False,
        ansible_facts=dict(a=1, b=2, c=True, d=False, e='{{ foo }}')
    )

    # test with a task that does require caching

# Generated at 2022-06-23 08:29:14.018256
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule('setup', dict(a=dict(b=1, c=2)), False)
    assert type(actionModule).__name__ == "ActionModule"

# Generated at 2022-06-23 08:29:15.152447
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    test constructor of class ActionModule
    '''
    c = ActionModule({})

# Generated at 2022-06-23 08:29:26.179149
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create uninitialized object
    am = ActionModule()
    # Create mock objects with default values
    ansible_connection = "ssh"
    ansible_ssh_user = "ansible"
    ansible_ssh_pass = "ansible"
    ansible_become_user = "root"
    ansible_ssh_private_key_file = "ansible"
    # Initialize object
    am.setup_cache = mock.Mock()
    am.runner = mock.Mock()
    am.runner.connection = ansible_connection
    am.runner.remote_addr = ansible_connection
    am.runner.runner_config = {'transport': 'ssh'}
    am.runner.module_name = "shell"
    am.runner.module_args = "whoami"
    am._connection = am.runner

# Generated at 2022-06-23 08:29:30.790956
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m_actionBase = MagicMock(spec=ActionBase)
    ActionModule.run(m_actionBase, tmp="tempfile", task_vars={"foo":"bar"})
    m_actionBase.run.assert_called_once_with(tmp="tempfile", task_vars={"foo":"bar"})

    m_actionBase = MagicMock(spec=ActionBase)
    with patch.object(m_actionBase, 'run') as mock_run:
        mock_run.return_value = {"foo":"bar"}
        ActionModule.run(m_actionBase)
        mock_run.assert_called_once_with(tmp=None, task_vars=None)


# Generated at 2022-06-23 08:29:31.705859
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    pass

# Generated at 2022-06-23 08:29:34.355384
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-23 08:29:45.788342
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import collections
    import mock
    import unittest

    from ansible.module_utils import basic
    from ansible.playbook.play import Play

    from ansible.plugins.action.set_fact import ActionModule

    mock_task = mock.Mock(action='set_fact', args={'f': '1'})
    mock_task.async_val = 2
    mock_task.notify = ["this"]

    # Variables for the module
    module_vars = dict(ANSIBLE_MODULE_ARGS={})
    play_context = dict(foo="bar")
    connection = mock.Mock()

    # Mock the module loader to return our module

# Generated at 2022-06-23 08:29:49.371194
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, {}, {}, {})
    assert isinstance(am, ActionModule)

# Generated at 2022-06-23 08:29:53.737881
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(task={}, connection={}, play_context={}, loader={}, templar={}, shared_loader_obj={})
    assert am.name == '_j2_vars'
    assert am.short_description == 'Runs the Jinja2 variable substitution for task vars'
    assert am.cacheable is False


# Generated at 2022-06-23 08:29:54.628739
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), '/', '/') != None

# Generated at 2022-06-23 08:29:55.268932
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

test_ActionModule_run()

# Generated at 2022-06-23 08:30:08.118023
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup the data that would normally be input by the Playbook Plugin
    class Play:
        pass
    class Task:
        pass
    class Playbook:
        pass
    class PlayContext:
        def __init__(self):
            self.prompt = None
    class TaskResult:
        pass
    class Connection:
        pass
    class Defered:
        pass

    # Setup the test data
    task_result = TaskResult()
    task_result._result = dict()
    task_result._task = Task()
    task_result._task._role = None
    task_result._task._role_name = None
    task_result._task.args = dict()
    task_result._task.action = 'set_fact'
    task_result._task.delegate_to = None
    task_result._task.environment

# Generated at 2022-06-23 08:30:09.772882
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None)

    assert action_module is not None

# Generated at 2022-06-23 08:30:22.620931
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Construct necessary inputs
    fixture_tmp = None
    fixture_task_vars = {'ansible_system': 'Linux', 'ansible_distribution': 'CentOS'}
    fixture_args = {'os': '{{ ansible_system }}', 'dist': '{{ ansible_distribution }}'}
    # Construct instance of class ActionModule with fixed inputs
    actionmodule_obj = ActionModule(fixture_tmp, fixture_args, load_from_file=False)
    # execute method run of class ActionModule
    result = actionmodule_obj.run(fixture_tmp, fixture_task_vars)
    assert result['ansible_facts']['os'] == 'Linux'
    assert result['ansible_facts']['dist'] == 'CentOS'

# Generated at 2022-06-23 08:30:24.399476
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module.TRANSFERS_FILES == False

# Generated at 2022-06-23 08:30:27.753441
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Unit test for constructor of class ActionModule
    """
    action_obj = ActionModule()
    assert action_obj._connection is None
    assert action_obj._shell is None
    assert action_obj._templar is not None

# Generated at 2022-06-23 08:30:28.701212
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 08:30:40.239674
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task

    ########################################################################
    # Create a mock Role()
    ########################################################################
    role = Role()
    role._role_name = 'test_role'

    ########################################################################
    # Create a mock Block()
    ########################################################################
    block = Block()
    block._role = role
    block._parents = [Play()]
    block._initialize_safe_roles()
    block._role = role

    ########################################################################
    # Create a mock Task()
   

# Generated at 2022-06-23 08:30:47.202277
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.common.collections import ImmutableDict

    def apply_configuration(module_name, module_args, task_vars=None, injected_vars=None):
        raise AnsibleActionFail('Unreachable code')

    def fail_json(*args, **kwargs):
        raise AnsibleActionFail('Send_provider_config does not normally fail, it actually writes a config file, '
                                'invokes socket.connect and verifies the contents of the config file')


# Generated at 2022-06-23 08:30:53.168291
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(None, None, None, None)

    assert action_module.run(None, {'a': 'A'}) == {'ansible_facts': {'a': 'A'}, '_ansible_facts_cacheable': False}
    assert action_module.run(None, {'a': 'A'}) == {'ansible_facts': {'a': 'A'}, '_ansible_facts_cacheable': False}

# Generated at 2022-06-23 08:31:04.241106
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils import context_objects as co
    from ansible.vars import VariableManager
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    class ActionModuleTestVariableManager(VariableManager):

        def __init__(self):
            VariableManager.__init__(self)
            self.template_hosts = {}
            co.set(self, 'host', dict(name='localhost'))

        def set_host_variable(self, host, varname, value):
            self.template_hosts[host] = value

    # Create a test action module

# Generated at 2022-06-23 08:31:16.126677
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    host = Host()
    variable_manager = VariableManager()
    loader = action_loader._create_loader()

    task = dict(args=dict(test_foo='test_bar'))
    action = action_loader.get('set_fact', task=task, connection=None, play_context=None, loader=loader, templar=None, shared_loader_obj=None)

    assert isinstance(action._task, dict)
    assert isinstance(action._templar, type(None))

    result = action.run(task_vars=dict(), tmp=None)

    assert isinstance(result, dict)

# Generated at 2022-06-23 08:31:18.529500
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actmod = ActionModule()
    assert actmod is not None

# Generated at 2022-06-23 08:31:22.189045
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.utils.module_docs_fragments

    action = ActionModule({}, dict(ANSIBLE_MODULE_ARGS={'foo': 'bar'}))

    assert action is not None

# Generated at 2022-06-23 08:31:32.291890
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    expected_result = {'ansible_facts': {'foo': 'bar'}, '_ansible_facts_cacheable': True}
    expected_result_2 = {'ansible_facts': {'foo': 'bar', 'baz': 'quux'}, '_ansible_facts_cacheable': True, 'failed': True}
    expected_result_3 = {'ansible_facts': {'foo': 'bar', 'baz': 'quux'}, '_ansible_facts_cacheable': False}
    expected_result_4 = {'ansible_facts': {'foo': 'bar', 'baz': 1}, '_ansible_facts_cacheable': True}

# Generated at 2022-06-23 08:31:34.506352
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(dict(), dict())
    module.run(dict(), dict())

# Generated at 2022-06-23 08:31:35.532013
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionModule)

# Generated at 2022-06-23 08:31:37.780631
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        mod = ActionModule()
        assert mod is not None
    except:
        assert False

# Generated at 2022-06-23 08:31:38.376907
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:31:47.012284
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    arguments = {
        'ansible_facts': {'a_binary': True, 'booleans': True, 'strings': 'true', 'non_booleans': 'non_booleans'},
        'ansible_facts_cacheable': False,
        '_ansible_verbose_always': False
    }

    # Setup
    test = ActionModule(dict(), arguments)

    # Get result
    result = test.run(tmp=None, task_vars=None)

    # Test result
    assert result['ansible_facts'] == {'a': 'binary', 'booleans': True, 'non_booleans': 'non_booleans', 'a_binary': True, 'strings': 'true'}
    assert result['_ansible_facts_cacheable'] == False

# Generated at 2022-06-23 08:31:50.934673
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-23 08:31:58.518934
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # given
    mock_run = {}
    mock_module = "testmodule"
    mock_args = {
            "k1": "v1",
            "k2": "v2",
            "k3": "v3",
            "cacheable": False
        }

    mock_task = type(
        "MockTask",
        (object,),
        {
            "run": lambda self: mock_run,
            "args": mock_args,
            "module_name": lambda self: mock_module
        }
    )

    mock_actionBase = type(
        "MockActionBase",
        (object,),
        {
            "run": lambda self, tmp, task_vars: mock_run
        }
    )


# Generated at 2022-06-23 08:32:01.333506
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None)
    assert 'TRANSFERS_FILES' in dir(am)
    assert 'run' in dir(am)

# Generated at 2022-06-23 08:32:12.158776
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    class MockActionBase(ActionBase):
        def __init__(self, acti):
            super(MockActionBase, self).__init__(acti)
            self._task = acti._task

    class MockTask(object):
        def __init__(self, args):
            self.args = args

    class MockTemplar(object):
        def __init__(self):
            pass

        def template(self, name):
            return name

    class MockAnsibleModule(object):
        def __init__(self, action):
            self._task_vars = {}
            self.action = action

    obj = ActionModule({}, {})
    obj2 = MockActionBase(obj)
    obj2._task = MockTask({})
    obj2._templar = MockTemplar()
    assert obj

# Generated at 2022-06-23 08:32:22.804761
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Tests for constructor of class ActionModule
    """
    # Create a mock of class ActionModule and test whether the
    # constructor is called with the right parameters
    mock_arg = MagicMock()
    mock_runner = MagicMock()
    mock_runner.task = mock_arg
    mock_runner.task.action = 'set_fact'
    mock_runner.task.args = {'hello': 'world'}
    mock_runner.task.action_args.args = "{'hello': 'world'}"
    mock_runner.action = 'set_fact'

    action_module = ActionModule(mock_runner)
    assert action_module._task.action == 'set_fact'
    assert action_module.action == 'set_fact'
    assert action_module._task.args['hello'] == 'world'


# Generated at 2022-06-23 08:32:23.424368
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert 1==1

# Generated at 2022-06-23 08:32:24.389906
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, "Unit tests not implemented"

# Generated at 2022-06-23 08:32:26.833570
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, 'test_plugins/action/setup.yml') is not None

# Generated at 2022-06-23 08:32:37.200768
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Unit test for variable name validation
    action = ActionModule(dict(a=dict(b=dict(c=dict(d="hello")))))
    assert action.run(task_vars=dict())['ansible_facts']['a']['b']['c']['d'] == 'hello'

    # Unit test with invalid variable name

# Generated at 2022-06-23 08:32:47.548095
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Test with empty arguments
    a = ActionModule(None)
    assert a.run(task_vars={}) == a.RESULT_FAILED_SILENTLY

    # Test with valid argument
    a = ActionModule(None)
    a._task.args = {'varname': 'val'}
    assert a.run(task_vars={}) == a.RESULT_FAILED_SILENTLY

    # Test with invalid argument
    a = ActionModule(None)
    a._task.args = {'varname:val'}
    assert a.run(task_vars={}) == a.RESULT_FAILED_SILENTLY

# Generated at 2022-06-23 08:32:49.611183
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=dict(), connection=dict(), play_context=dict())
    assert action is not None

# Generated at 2022-06-23 08:33:00.929351
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule({'ansible_facts':{}})
    # Check whether an exception is raised if no key/value pairs are provided
    try:
        action.run(task_vars={})
    except AnsibleActionFail:
        pass
    except Exception as e:
        raise

    # Check whether an exception is raised if no key/value pairs are provided
    try:
        action.run(task_vars={'myvar': 'myval'})
    except AnsibleActionFail:
        pass
    except Exception as e:
        raise

    # Check whether an exception is raised if no key/value pairs are provided
    try:
        action.run(task_vars={'ansible_facts':{}})
    except AnsibleActionFail:
        pass
    except Exception as e:
        raise

    # Check whether an

# Generated at 2022-06-23 08:33:12.516854
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager

    task_vars = dict()

    # create a play to instantiate the task
    loader = DataLoader()
    passwords = dict()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(loader=loader, passwords=passwords), host_list='/dev/null')

# Generated at 2022-06-23 08:33:20.886901
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from units.mock.loader import DictDataLoader
    from units.mock.runner import Runner

    ldr = DictDataLoader({})
    runner = Runner(ldr)
    runner.vars = {}

    task = dict(
        action=dict(
            module='set_fact',
            args=dict(
                foo='hello',
                bar=dict(baz='world'),
            )
        ),
    )

    res = runner._execute_module(task_vars=runner.vars, task_action=task['action'])
    assert 'ansible_facts' in res
    assert 'foo' in res['ansible_facts']
    assert 'bar' in res['ansible_facts']
    assert 'baz' in res['ansible_facts']['bar']

# Generated at 2022-06-23 08:33:23.397353
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule("", "", "", "", "", "")

# Generated at 2022-06-23 08:33:34.760414
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import random
    
    class MockModule(object):
        def __init__(self):
            self.params = {}

    class MockTask(object):
        def __init__(self):
            self.args = {}

    class MockPlay(object):
        name = ''
        tasks = [MockTask()]

    action = ActionModule(MockPlay(), MockTask(), {})
    action.set_runner(ActionBase())
    action._templar = MockModule()
    cacheable = random.randint(0, 1)

    # Positive test
    action.run(task_vars={}, tmp='',
               cacheable=cacheable)

    if cacheable:
        assert action.action_results.get('ansible_facts_cacheable')

# Generated at 2022-06-23 08:33:45.945254
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest

    from collections import namedtuple
    from ansible.plugins.action import ActionBase

    Fake = namedtuple('Fake', ('name', 'args'))
    ActionBase._config_module = Fake(name='ansible.constants', args=dict())

    import sys
    sys.modules['ansible.module_utils.convert_bool'] = Fake(name='ansible.module_utils.convert_bool', args=dict())
    sys.modules['ansible.utils.vars'] = Fake(name='ansible.utils.vars', args=dict())

    tmp = None
    task_vars = None

    action_module = ActionModule(action=None, task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    result

# Generated at 2022-06-23 08:33:50.606404
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule()
    variables = dict()
    tmp = dict()

    assert actionModule.run(tmp, variables) == {'_ansible_verbose_always': True, '_ansible_no_log': False, 'ansible_version': {'full': '2.0.0.0-dev', 'major': 2, 'minor': 0}, 'changed': False}

# Generated at 2022-06-23 08:34:02.421614
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    class ActionModule_run(ActionModule):
        def __init__(self, templar):
            self._templar = templar
        def run(self, tmp=None, task_vars=None):
            if task_vars is None:
                task_vars = dict()
            facts = {}
            cacheable = False
            try:
                super(ActionModule_run, self).run(tmp, task_vars)
            except Exception as e:
                msg = "An error occurred while running the action. Error was: %s" % str(e)
                raise AnsibleActionFail(msg)
            del tmp
            facts = {}
            cacheable = False

# Generated at 2022-06-23 08:34:04.284764
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_actionmodule = ActionModule(None, None, None)
    assert test_actionmodule.__class__.__name__ == 'ActionModule'

# Generated at 2022-06-23 08:34:05.666806
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None, None, None, {})
    a


# Generated at 2022-06-23 08:34:12.055128
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host

    def _task_queue_result(host, task, result, _):
        tqm._stats[host.name] = dict(ok=bool(result.is_successful()), changed=bool(result.is_changed()))

    variable_manager = VariableManager()
    loader = variable_manager.loader = Mock()

    # create a mock of the TaskQueueManager
    tqm = TaskQueueManager(
        inventory=Mock(),
        variable_manager=variable_manager,
        loader=loader,
        options=Mock(),
        stdout_callback='default',
    )
    # create a mock

# Generated at 2022-06-23 08:34:20.597603
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.module_utils.actions
    import ansible.playbook.play_context
    import ansible.playbook.task

    # Create a context for a test.
    pc = ansible.playbook.play_context.PlayContext()
    t = ansible.playbook.task.Task()
    t._role = ansible.playbook.role.Role()
    t._role._role_path = '/tmp'

    am = ActionModule()
    am._low_level_runner_terminated = True
    am._shared_loader_obj = ansible.parsing.dataloader.DataLoader()
    # I don't want to use connections/ssh.py, so I create a stub class to replace it.
    class StubConnection:
        def __init__(self, _):
            pass
    am._shared_

# Generated at 2022-06-23 08:34:30.607812
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host = dict(hostvars = dict(ansible_hostname = 'hostname'))
    loader = dict(path_module_data = 'plugins/modules/')
    templar = dict()
    task_vars = dict(ansible_hostname = 'hostname')
    module_vars = dict()

    # test failure case: no key/value pairs provided
    task = dict(action = dict(module = 'set_fact'), args = dict())
    am = ActionModule(None, task, host, loader, templar, task_vars, module_vars)
    assert am.run()['failed']

    # test failure case: args is not dict
    task = dict(action = dict(module = 'set_fact'), args = ['notdict'])

# Generated at 2022-06-23 08:34:32.801093
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None)
    # test the constructor of ActionModule
    assert am is not None

# Generated at 2022-06-23 08:34:38.186619
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dataMap = {
        "action": {
            "__ansible_module__": "debug",
            "__ansible_arguments__": {
                "msg": "foo"
            }
        }
    }

    actionModule = ActionModule()
    actionModule.defined_elements = dataMap
    actionModule.setup()

    assert actionModule.action_vars_template == "action"

# Generated at 2022-06-23 08:34:41.594408
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Running test_ActionModule")
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action
    print("End test_ActionModule")

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-23 08:34:44.383513
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert actionModule

# Generated at 2022-06-23 08:34:46.928526
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.playbook.task

    am = ActionModule(ansible.playbook.task.Task())
    assert am is not None


# Generated at 2022-06-23 08:34:51.642096
# Unit test for constructor of class ActionModule
def test_ActionModule():
    i = ActionModule()
    assert isinstance(i,ActionModule)

# Generated at 2022-06-23 08:35:00.670311
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # arrange
    test_args = {'test_var': 'test_val'}
    test_task_vars = {}
    test_tmp = None
    test_template = 'test_template'
    test_action = ActionModule(task=None, connection=None, _play_context=None, loader=None, templar=test_template, shared_loader_obj=None)
    test_action._task = ActionModule.TaskClass()
    test_action._task.args = test_args
    test_action._templar.template = MagicMock(return_value='test_template')
    # act
    result = test_action.run(test_tmp, test_task_vars)
    # assert
    assert result['ansible_facts']['test_template'] == 'test_val'

# Generated at 2022-06-23 08:35:04.184805
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = dict()
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-23 08:35:13.165227
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.set_fact import ActionModule
    import ansible.utils.vars as tmp_vars
    import ansible.utils.template as tmp_template

    set_fact_instance = ActionModule.load_action_plugin('ansible.plugins.action.set_fact', {})

    set_fact_instance._templar = tmp_template.Templar(None)
    isidentifier = tmp_vars.isidentifier('test_identifier')
    assert isidentifier
    isidentifier_false = tmp_vars.isidentifier('test identifier')
    assert not isidentifier_false

    assert set_fact_instance._templar is not None

# Generated at 2022-06-23 08:35:18.700670
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    Task._shared_loader = None # Make sure the loader is reset

    yaml_data = '''
      - name: test_vars_action
        vars:
          test_var: "{{ inventory_hostname }}"
        gather_facts: no
    '''
    playbook = PlayBookIncludeConstructor.load(yaml_data, loader=Task.get_loader())
    print(playbook.get_tasks())
    assert playbook.__len__() == 1

    task = playbook[0]
    assert task.__name__ == 'test_vars_action'
    assert task._role is None

    task_vars = dict()
    result = task.action._execute_module(task_vars=task_vars)

# Generated at 2022-06-23 08:35:27.667148
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup test
    class VarsModule:
        def __init__(self):
            self.ansible_facts = {}
            self._ansible_facts_cacheable = True
        def run(self, **kwargs):
            self.ansible_facts.update(**kwargs)
            return self
        def get_ansible_facts(self):
            return self.ansible_facts
        def get_ansible_facts_cacheable(self):
            return self._ansible_facts_cacheable
    tmp = VarsModule()
    # test with a variables set
    ActionModule().run(tmp, task_vars={'a': {'a1': 'value_a1'}, 'b': {'b1': 'value_b1'}, 'c': {'c1': 'value_c1'}})
   

# Generated at 2022-06-23 08:35:32.365657
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # these must be imported here because they live outside the action
    # module path
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.ec2 import camel_dict_to_snake_dict
    from ansible.playbook.play_context import PlayContext

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.playbook.block import Block


# Generated at 2022-06-23 08:35:37.366133
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Fake class to allow instantiation of ActionModule
    class FakeTask():
        def __init__(self):
            # Fake task_vars
            self.task_vars = {
                'testvar': 'testval'
            }

        def get_vars(self, *args, **kwargs):
            return self.task_vars

    a = ActionModule(FakeTask())

    # Set instance variables
    a._templar = FakeTemplar()
    a._task = FakeTask()
    a._task.args = {
        'ansible_env': {
            'PATH': '/bin'
        }
    }

    # Call method run
    v = a.run()

    # Assert method run returns results

# Generated at 2022-06-23 08:35:47.030695
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule(dict(name='test_host'))
    task_vars = dict(test_var='test_value')
    am.run(task_vars=task_vars)
    assert 'ansible_facts' in am.result
    assert am.result['ansible_facts'] == dict()
    assert am.result['_ansible_facts_cacheable'] == False

    am = ActionModule(dict(name='test_host', my_fact='foo'))
    am.run(task_vars=task_vars)
    assert 'ansible_facts' in am.result
    assert am.result['ansible_facts'] == dict(my_fact='foo')
    assert am.result['_ansible_facts_cacheable'] == False


# Generated at 2022-06-23 08:35:57.254423
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # A task_vars is required to satisfy the method signature
    task_vars = {}

    # The action instance
    action_instance = ActionModule()

    # The task instance
    class MockTask():
        def __init__(self):
            self.args = {'key1': 'value1'}

    task_instance = MockTask()

    # Expected result
    expected_result = {
        'ansible_facts': {'key1': 'value1'},
        '_ansible_facts_cacheable': False
    }

    # Do the real test
    result = action_instance.run(tmp=None, task_vars=task_vars)

    assert result == expected_result

# Generated at 2022-06-23 08:36:01.143755
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()
    assert am.run(tmp=None, task_vars=None) is not None

# Generated at 2022-06-23 08:36:02.573304
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)

# Generated at 2022-06-23 08:36:04.628655
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # All this test does is make sure the constructor does not throw an exception.
    action_module = ActionModule()

# Generated at 2022-06-23 08:36:11.462088
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor import module_common

    play_context = PlayContext()
    task = Task.load(dict(action=dict(module='debug', args=dict(msg='{{ data }}'))))
    play_source = dict(name="Ansible Play", hosts='all', gather_facts='no', tasks=[task])
    play = Play().load(play_source, loader=None, variable_manager=None)
    tqm = None
    loader = None
    variable_manager = None
    shared_loader_obj = None

    ##############################################################################
    # Run module
    ##############################################################################

# Generated at 2022-06-23 08:36:23.864128
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = dict(
        name='test_ActionModule_run',
        args=dict(
            key='value',
            key2='value2',
            cacheable=True,
        ),
    )
    module = ActionModule(task=dict(action=action), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = module.run(None, task_vars=dict())
    assert result.get('ansible_facts') == dict(key='value', key2='value2')
    assert result.get('ansible_facts_cacheable') is True


# Generated at 2022-06-23 08:36:32.201183
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('test_ActionModule_run')
    am = ActionModule({'foo': 'bar'}, {})
    am._task = {'args': {'spam': "eggs"}}
    am._task_vars = {}
    result = am.run()
    assert result['_ansible_facts_cacheable'] == False
    assert result['ansible_facts']['spam'] == "eggs"

if __name__ == "__main__":
    print('Testing modules/action/set_fact.py')
    test_ActionModule_run()

# Generated at 2022-06-23 08:36:38.428664
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.module_utils.six import iteritems, string_types

    # We need to mock class _ansible_module_builtin.
    # This is because we don't need the whole class present to test the method of class ActionModule
    class MockModule(object):
        def __init__(self):
            self.params = {'my_fact': 'my_value', 'cacheable': False}

    # We need to mock class ActionBase.
    # This is because we don't need the whole class present to test the method of class ActionModule
    class MockActionBase(object):
        def __init__(self):
            # It is important for us to mock _templar property of the class.
            # It allows us to mock _templar method template.
            self._templar = MockTemplar()

    # We need

# Generated at 2022-06-23 08:36:41.031367
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None, None, None, None)
    assert isinstance(a, ActionModule)

# Generated at 2022-06-23 08:36:49.414151
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from collections import namedtuple
    
    task_vars = {}
    
    MockClass1 = namedtuple('MockClass1', ['args'])
    mockobj1 = MockClass1(
        args = {
            'cacheable': False,
            'foo': 'bar',
            'bar': 1
        }
    )
    
    MockClass2 = namedtuple('MockClass2', ['args'])
    mockobj2 = MockClass2(
        args = {
            'cacheable': False,
            'baz': '123',
            'qux': True
        }
    )
    # Case: success, args: {'foo': 'bar', 'bar': 1}

# Generated at 2022-06-23 08:37:00.626457
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    state = dict(failed=False, changed=False)
    tmp = dict(
        stderr='',
        rc=0,
        stdout='hello world',
        stdout_lines=[],
        stderr_lines=[],
    )
    task_vars = {}
    module = ActionModule()

    # Test error messages

# Generated at 2022-06-23 08:37:11.750617
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class Task(object):
        def __init__(self):
            self.action = 'setup'
            self.args = {
                'cacheable': False
            }

    class Play(object):
        def __init__(self):
            self.vars = {
                'ansible_check_mode': 'True'
            }

    class PlayContext(object):
        def __init__(self):
            self.play = Play()

    class TaskResult(object):
        def __init__(self, task_importance):
            self.task_importance = task_importance

    class ActionBaseClass(object):
        def __init__(self):
            self.task = Task()
            self.play_context = PlayContext()
            self.task_results = [TaskResult('lowest'), TaskResult('low')]

# Generated at 2022-06-23 08:37:12.724370
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:37:22.707300
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    _task = dict(action=dict(module='set_fact', args=dict(x=5, y=list(range(1, 4)))))
    _task_vars = dict()
    _result = dict(ansible_facts=dict(x=5, y=list(range(1, 4))))

    _am = ActionModule(task=_task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    _result_actual = _am.run(tmp=None, task_vars=_task_vars)

    assert _result == _result_actual

# Generated at 2022-06-23 08:37:33.746261
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.included_file import IncludedFile
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory_manager = InventoryManager(loader=loader, sources=['localhost,'])
    
    task0 = Task()
    task0.action = 'set_fact'

# Generated at 2022-06-23 08:37:41.478414
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with file module
    a = ActionModule({u'args': {u'ab': u'sc'}, u'action': u'copy'})

    # Test with shell module
    a = ActionModule({u'args': {u'ab': u'sc'}, u'action': u'shell'})

    # Test with raw module
    a = ActionModule({u'args': {u'ab': u'sc'}, u'action': u'raw'})

    # Test with setup module
    a = ActionModule({u'args': {u'ab': u'sc'}, u'action': u'setup'})

    # Test with debug module
    a = ActionModule({u'args': {u'ab': u'sc'}, u'action': u'debug'})

    # Test with include module
    a = ActionModule

# Generated at 2022-06-23 08:37:46.194891
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    This is a simple unit test for the constructor of the
    ``ActionModule`` class.

    Here we create an object of the class and just call the constructor,
    which should succeed.
    """
    am = ActionModule(task=dict(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am is not None

# Generated at 2022-06-23 08:37:54.629058
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()

    action_module = ActionModule(dict(), load_callback_plugins=False)

    # Test with no arguments
    result = action_module.run(task_vars)

    assert result == {
        'failed': True,
        'msg': 'No key/value pairs provided, at least one is required for this action to succeed',
    }

    # Test with one valid argument
    action_module = ActionModule({'test': 'value'}, load_callback_plugins=False)

    result = action_module.run(task_vars)

    assert result == {
        'ansible_facts': {'test': 'value'},
        '_ansible_facts_cacheable': False,
    }

    # Test with one invalid argument

# Generated at 2022-06-23 08:37:57.665695
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule({
        "ansible_facts": {"key": "value"},
        "_ansible_facts_cacheable": False
    })

    actionModule.run(None, {"key": "value"})

# Generated at 2022-06-23 08:38:01.359179
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(param1='value1', param2='value2')
    assert module.run() == {'ansible_facts': {'param1': 'value1', 'param2': 'value2'}, '_ansible_facts_cacheable': False}


# Generated at 2022-06-23 08:38:14.544163
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    #test1
    action_module_test1 = ActionModule()
    facts_test1 = {'test': 'test', 'test1': 'test1'}
    result_test1 = action_module_test1.run(tmp=None, task_vars=None, **facts_test1)
    assert result_test1['ansible_facts'] == facts_test1, 'test1'
    assert result_test1['_ansible_facts_cacheable'] is False, 'test1'

    #test2
    action_module_test2 = ActionModule()
    facts_test2 = {'test': 'test', 'test1': 'test1', 'cacheable': True}
    result_test2 = action_module_test2.run(tmp=None, task_vars=None, **facts_test2)
   

# Generated at 2022-06-23 08:38:24.614741
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    This test verifies that the run method will simply return the input arguments
    if no templates are required, and that the values are converted to a boolean
    when YAML native, and not converted otherwise.
    '''
    # Set up obligatory arguments
    tmp = None
    task_vars = None
    # Prepare the arguments
    set_module_args(dict(cacheable=False, Ansible=True))

    my_obj = ActionModule(self._connection, self._play_context, self._loader, self._templar, self._shared_loader_obj)

    # Set up the play_context
    self._play_context.connection = 'local'
    self._play_context.network_os = 'default'
    self._play_context.remote_addr = None
    self._play_context.port = None
   

# Generated at 2022-06-23 08:38:28.575321
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None) is not None
    assert ActionModule(None, None, None, None).run(None, None) is not None

# Test that the correct exception is raised if a invalid varname is supplied

# Generated at 2022-06-23 08:38:32.702920
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    actionmodule_instance = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # test run method
    assert actionmodule_instance.run() == '[DEPRECATED]: ActionModule is deprecated. Use ansible.plugins.action.ActionBase instead...'

# Generated at 2022-06-23 08:38:37.838373
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = dict(
        action=dict(module='set_fact'),
        ansible_facts=dict(),
        ansible_module_args=dict(testvar=True, cacheable=False),
    )

    set_fact = ActionModule(module, {})
    module['ansible_facts'].update(set_fact.run(task_vars={'testvar': True}))
    assert module['ansible_facts']['testvar'] is True
    assert module['ansible_facts']['_ansible_facts_cacheable'] is False

# Generated at 2022-06-23 08:38:48.085285
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict(
        a=dict(required=True),
        b=dict(),
        c=dict(),
        d=dict(),
        e=dict(),
    ))
    assert module.run_command('echo "hello"')[1] == 0

    module = AnsibleModule(argument_spec=dict(
        a=dict(required=True, type='int'),
        b=dict(type='bool'),
        c=dict(type='bool', default=True),
        d=dict(type='bool', default=False),
        e=dict(type='bool', default=False, required=False),
        f=dict(),
    ), supports_check_mode=True)
    assert module.run_command('echo "hello"')

# Generated at 2022-06-23 08:38:50.495436
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=dict(), connection=None, play_context=dict())
    assert module

# Generated at 2022-06-23 08:38:52.718020
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of ActionModule
    action_module = ActionModule()
    # Call the run method of ActionModule
    action_module.run()

# Generated at 2022-06-23 08:39:00.584995
# Unit test for constructor of class ActionModule
def test_ActionModule():

    import ansible.constants as C

    am = ActionModule(None, None, None)

    result = am.run(None, {'ansible_check_mode': False})
    assert result['skipped']

    result = am.run(None, {'ansible_check_mode': True, 'ansible_verbosity': 0})
    assert result['skipped']

    result = am.run(None, {'ansible_check_mode': True, 'ansible_verbosity': 1})
    assert 'cmd' in result
    assert result['cmd'] == C.DEFAULT_MODULE_REPLACEMENT
    assert 'ansible_module_args' in result
    assert result['ansible_module_args'] == 'cacheable=False'
