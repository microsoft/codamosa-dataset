

# Generated at 2022-06-23 21:09:08.782604
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TODO: Fix these unit tests and make sure they pass.
    from mimesis.enums import Gender
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person import Person
    from mimesis.providers.misc import Choice
    provider_1 = Choice()
    provider_2 = Datetime()
    provider_3 = Person('en')
    provider_4 = Choice()
    provider_5 = Person('en')
    provider_6 = Choice()
    provider_7 = Datetime()
    provider_8 = Person('en')
    provider_9 = Choice()
    provider_10 = Person('en')
    provider_11 = Choice()
    provider_12 = Datetime()
    provider_13 = Person('en')
    provider_14 = Choice()
    provider_15 = Person

# Generated at 2022-06-23 21:09:09.846930
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert isinstance(c, Choice)

# Generated at 2022-06-23 21:09:14.027667
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    items = ['a', 'b', 'c']
    print(choice(items=items))
    print(choice(items=items, length=1))
    print(choice(items='abc', length=2))

# Generated at 2022-06-23 21:09:18.872350
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    print(choice(['a','b','c']))
    print(choice(['a','b','c'],length=1))
    print(choice('abc',length=2))
    print(choice(['a','b','c'],length=5))
    print(choice('aabbbccccddddd',length=4,unique=True))

# Generated at 2022-06-23 21:09:19.501874
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-23 21:09:20.878499
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice.choice()
    assert choice.choice('', 0)

# Generated at 2022-06-23 21:09:29.345022
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice.choice(items=['a', 'b', 'c']) == 'c'
    assert choice.choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice.choice(items='abc', length=2) == 'ba'
    assert choice.choice(items=('a', 'b', 'c'),
                         length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice.choice(items='aabbbccccddddd', length=4,
                         unique=True) == 'cdba'

# Generated at 2022-06-23 21:09:37.014865
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-23 21:09:44.363685
# Unit test for method __call__ of class Choice

# Generated at 2022-06-23 21:09:54.642124
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    # test for unique
    assert choice.__call__(items='abcdefghi', length=12, unique=True) == 'abcdefghiabc'
    # test for not unique
    assert choice.__call__(items="abcdefghi", length=12, unique=False) == 'hgfdieghcigh'
    # test for length = 0
    assert choice.__call__(items=["a", "b", "c"], length=0) == "a"
    # test for negative length
    try:
        choice.__call__(items=["a", "b", "c"], length=-3)
    except ValueError as e:
        assert e.args == ('**length** should be a positive integer.',)
    # test for non-sequence item

# Generated at 2022-06-23 21:10:02.485940
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    _result = Choice()
    _result.seed(1)
    _result.random.seed(1)
    assert _result() == _result()
    assert _result(items=['a', 'b', 'c']) == 'b'
    assert _result(items=['a', 'b', 'c'], length=1) == ['a']
    assert _result(items='abc', length=2) == 'ba'
    assert _result(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert _result(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:10:05.516693
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    cho = choice(items=['a', 'b', 'c'])

    assert cho in ['a', 'b', 'c']  # equal

# Generated at 2022-06-23 21:10:08.075456
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert isinstance(c, Choice)
    assert c.Meta.name == 'choice'


# Generated at 2022-06-23 21:10:16.071841
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice(seed=1)
    assert choice(items=['a', 'b', 'c']) == 'a'
    assert choice(items=['a', 'b', 'c'], length=1) == ['c']
    assert choice(items='abc', length=2) == 'ca'
    assert choice(items=('a', 'b', 'c'), length=5) == ('b', 'b', 'c', 'c',
                                                        'a')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'bdac'
    # Error handling
    try:
        choice(items=None)   # type: ignore
    except TypeError as e:
        assert str(e) == '**items** must be non-empty sequence.'

# Generated at 2022-06-23 21:10:27.535910
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    print("test_Choice___call__")
    # Test for TypeError
    test_choice = Choice()
    args = []
    kwargs = {"length": 5}
    try:
        test_choice.__call__(*args, **kwargs)
    except TypeError as e:
        assert e.__str__() == "__call__() missing 1 required positional argument: 'items'"
    else:
        assert False, "TypeError not raised"

    args = ["item"]
    kwargs = {"length": "test_string"}
    try:
        test_choice.__call__(*args, **kwargs)
    except TypeError as e:
        assert e.__str__() == '**length** must be integer.'
    else:
        assert False, "TypeError not raised"

    args = [None]
   

# Generated at 2022-06-23 21:10:28.152685
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-23 21:10:37.479485
# Unit test for constructor of class Choice
def test_Choice():
    """
    Unit test for constructor of class Choice
    """

    choice = Choice(seed=1)

    # Test first use case
    assert choice(items=['a', 'b', 'c']) == 'c'

    # Test second use case
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']

    # Test third use case
    assert choice(items='abc', length=2) == 'ba'

    # Test fourth use case
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')

    # Test fifth use case
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:10:45.402282
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender
    from mimesis.exceptions import NonEnumerableError
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    from mimesis.enums import Gender
    from mimesis.exceptions import NonEnumerableError
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    from mimesis.exceptions import NonEnumerableError
    from mimesis.providers.datetime import Datetime

# Generated at 2022-06-23 21:10:53.003167
# Unit test for constructor of class Choice
def test_Choice():
    data = Choice()
    data.random.seed(0)
    obj1 = data(items=['a', 'b', 'c'])
    obj2 = data(items=['a', 'b', 'c'], length=1)
    obj3 = data(items='abc', length=2)
    obj4 = data(items=('a', 'b', 'c'), length=5)
    obj5 = data(items='aabbbccccddddd', length=4, unique=True)
    print(obj1, obj2, obj3, obj4, obj5)



# Generated at 2022-06-23 21:10:59.807815
# Unit test for constructor of class Choice
def test_Choice():
    # Test normal operation
    c = Choice()
    for i in range(0, 10):
        assert(c(items=[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]) in range(0, 10))

# Generated at 2022-06-23 21:11:01.997251
# Unit test for constructor of class Choice
def test_Choice():
    test_case = Choice()
    assert test_case.__class__.__name__ == 'Choice'

# Generated at 2022-06-23 21:11:09.535684
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    o = Choice()
    o.random.choices = lambda x, k: x[:k]
    assert o(items=['a', 'b', 'c']) == 'c'
    assert o(items=['a', 'b', 'c'], length=1) == ['a']
    assert o(items='abc', length=2) == 'ba'
    assert o(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert o(items='aabbbccccddddd', length=4, unique=True) == 'cdba'



# Generated at 2022-06-23 21:11:17.690997
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(['a', 'b', 'c']) == 'c'
    assert Choice().__call__(['a', 'b', 'c'], 1) == ['a']
    assert Choice().__call__('abc', 2) == 'ba'
    assert Choice().__call__(('a', 'b', 'c'), 5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__('aabbbccccddddd', 4, True) == 'cdba'

# Generated at 2022-06-23 21:11:19.168247
# Unit test for constructor of class Choice
def test_Choice():
    x = Choice()
    assert x is not None


# Generated at 2022-06-23 21:11:26.448112
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    print(c.words('female.txt', length=10))
    print(c(['a', 'b', 'c']))
    print(c(['a', 'b', 'c'], length=1))
    print(c('abc', length=2))
    print(c(('a', 'b', 'c'), length=5))
    print(c('aabbbccccddddd', length=4, unique=True))

test_Choice___call__()

# Generated at 2022-06-23 21:11:32.875132
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert (choice(items=['a', 'b', 'c']) == 'c')
    assert (choice(items=['a', 'b', 'c'], length=1) == ['a'])
    assert (choice(items='abc', length=2) == 'ba')
    assert (choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c'))
    assert (choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba')

# Generated at 2022-06-23 21:11:35.237597
# Unit test for constructor of class Choice
def test_Choice():
    """Unit test for constructor of class Choice"""
    obj = Choice()
    assert isinstance(obj, Choice)


# Generated at 2022-06-23 21:11:36.146029
# Unit test for constructor of class Choice
def test_Choice():
    """Trigger constructor of class Choice."""
    assert isinstance(Choice(), Choice)

# Generated at 2022-06-23 21:11:44.276142
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choiceClass = Choice()
    assert choiceClass(items=['a', 'b', 'c']) == 'c'
    assert choiceClass(items=['a', 'b', 'c'], length=1) == ['a']
    assert choiceClass(items='abc', length=2) == 'ba'
    assert choiceClass(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choiceClass(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-23 21:11:46.469629
# Unit test for constructor of class Choice
def test_Choice():
    # TODO: Uses Mimesis to create choice objects
    #       Check that choice is properly initialized
    assert True

# Generated at 2022-06-23 21:11:54.873369
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    for i in range(10):
        assert isinstance(choice(('a', 'b', 'c')), tuple)
        assert isinstance(choice('abc', 1), str)
        assert isinstance(choice(['a', 'b', 'c'], 10), list)
        assert len(choice(('a', 'b', 'c'), 5)) == 5
        assert len(choice('abc', 2)) == 2
        assert len(choice(['a', 'b', 'c'], 2)) == 2
        assert len(choice(('a', 'b', 'c'), 2)) == 2
        assert len(choice('abc', 3)) == 3
        assert len(choice(['a', 'b', 'c'], 5)) == 5
        assert len(choice(('a', 'b', 'c'), 5)) == 5


# Generated at 2022-06-23 21:11:55.914774
# Unit test for constructor of class Choice
def test_Choice():
    assert isinstance(Choice(), Choice)


# Generated at 2022-06-23 21:11:57.229018
# Unit test for constructor of class Choice
def test_Choice():
    """Unit tests for choice.
    """
    assert callable(Choice)

# Generated at 2022-06-23 21:12:05.171164
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    from mimesis import Choice

    choice = Choice()

    a = choice(items=['a', 'b', 'c'])
    assert a == 'c'

    a = choice(items=['a', 'b', 'c'], length=1)
    assert a == ['a']

    a = choice(items='abc', length=2)
    assert a == 'ba'

    a = choice(items=('a', 'b', 'c'), length=5)
    assert a == ('c', 'a', 'a', 'b', 'c')

    a = choice(items='aabbbccccddddd', length=4, unique=True)
    assert a == 'cdba'


# Generated at 2022-06-23 21:12:13.491598
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Run tests for function Choice.__call__."""
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'



# Generated at 2022-06-23 21:12:21.590152
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert callable(Choice)
    assert Choice.Meta.name == 'choice'

    # TODO: Test for negative length
    # callable(Choice(None, None, None))
    # callable(Choice(None, None))
    # callable(Choice)
    # callable(Choice(items=['a', 'b', 'c'], length=1), (None, None, None))
    # callable(Choice(items=['a', 'b', 'c'], length=1), (None, None))
    # callable(Choice(items=['a', 'b', 'c'], length=1))
    # callable(Choice(items=['a', 'b', 'c']), (None, None, None))
    # callable(Choice(items=['a', 'b', 'c']), (None, None))

# Generated at 2022-06-23 21:12:22.853103
# Unit test for constructor of class Choice
def test_Choice():
  ch = Choice()


# Generated at 2022-06-23 21:12:25.740886
# Unit test for constructor of class Choice
def test_Choice():
    def test_set(items, length, unique):
        choice = Choice()
        output = choice(items, length, unique)
        assert output is not None


# Generated at 2022-06-23 21:12:35.051985
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    test_data = ('a', 'b', 'c')
    length = 2

    # Without unique
    result = Choice(seed=4815162342).__call__(items=test_data, length=length)
    assert result == ('c', 'b')

    # With unique
    result = Choice(seed=4815162342).__call__(items=test_data, length=length,
                                              unique=True)
    assert result == ('b', 'c')
    # Without unique
    result = Choice(seed=4815162342).__call__(items=test_data, length=length)
    assert result == ('c', 'b')

    # With unique

# Generated at 2022-06-23 21:12:41.988847
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ab', 'ac', 'bc']
    assert choice(items=('a', 'b', 'c'), length=5) in [(
        'c', 'a', 'a', 'b', 'c'), ('c', 'b', 'b', 'a', 'c')]

# Generated at 2022-06-23 21:12:52.077207
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    d = c(items=['a', 'b', 'c'])
    s = c(items=['a', 'b', 'c'], length=1)
    t = c(items='abc', length=2)
    u = c(items=('a', 'b', 'c'), length=5)
    v = c(items='aabbbccccddddd', length=4, unique=True)
    assert d == 'c'
    assert s == ['a'] or s == ['b'] or s == ['c']
    assert t == 'ba' or t == 'bc' or t == 'ca' or t == 'cb' or t == 'ab' or t == 'ac'

# Generated at 2022-06-23 21:12:58.948881
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    
    # Generate a randomly-chosen sequence or bare element from a sequence.
    print(choice(items=['a', 'b', 'c']))
    print(choice(items=['a', 'b', 'c'], length=1))
    print(choice(items='abc', length=2))
    print(choice(items=('a', 'b', 'c'), length=5))
    print(choice(items='aabbbccccddddd', length=4, unique=True))
    print("\n")
    
    # Provide non-empty sequence (list, tuple or string) of elements.
    print(choice(items=['a', 'b', 'c', 'd']))
    print(choice(items=['a', 'b', 'c', 'd'], length=1))


# Generated at 2022-06-23 21:13:03.274423
# Unit test for constructor of class Choice
def test_Choice():
    """Test for Choice"""
    items = ['a', 'b', 'c']
    length = 1
    unique = True
    chooser = Choice()
    chooser(items=items, length=length, unique=unique)
    assert True

# Generated at 2022-06-23 21:13:04.759955
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert isinstance(c, Choice)


# Generated at 2022-06-23 21:13:15.444475
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Issue #53
    choice = Choice()
    items = list(range(10))
    length = len(items)
    unique = True
    assert len(choice(items=items, length=length, unique=unique)) == length
    assert len(set(choice(items=items, length=length, unique=unique))) == length
    assert len(choice(items=items, length=10, unique=unique)) == length
    assert len(set(choice(items=items, length=10, unique=unique))) == length
    assert len(choice(items=items, length=20, unique=unique)) == length
    assert len(set(choice(items=items, length=20, unique=unique))) == length

    choice = Choice()
    items = list(range(10))
    length = 3
    unique = True

# Generated at 2022-06-23 21:13:25.007908
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(['a', 'b', 'c']) in ['a','b','c']
    assert Choice().__call__(['a', 'b', 'c'], length=1) in [['a'],['b'],['c']]
    assert Choice().__call__('abc', length=2) in ['ba','bc','ca']

# Generated at 2022-06-23 21:13:33.421502
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-23 21:13:38.800358
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.builtins import Choice
    
    choice = Choice('en')
    print(choice(items=[1, 2, 3]))
    print(choice(items=[1, 2, 3], length=1))
    print(choice(items=[1, 2, 3], length=2, unique=True))
    print(choice(items='abc', length=3))


if __name__ == '__main__':
    test_Choice___call__()

# Generated at 2022-06-23 21:13:40.005608
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()


# Generated at 2022-06-23 21:13:47.551258
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = ['a', 'b', 'c']
    assert choice(items=items) == 'c'
    assert choice(items=items, length=1) == ['c']
    assert choice(items='abc', length=2) == 'ba'
    items = ['a', 'b', 'c']
    assert choice(items=items, length=5) == ('c', 'a', 'a', 'b', 'c')
    items = 'aabbbccccddddd'
    assert choice(items=items, length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:13:49.132489
# Unit test for constructor of class Choice
def test_Choice():
    """Unit test for constructor of class Choice."""
    choice = Choice()
    choice('abc')

# Generated at 2022-06-23 21:13:51.933586
# Unit test for constructor of class Choice
def test_Choice():
    import unittest
    class TestChoice(unittest.TestCase):
        def test_Choice(self):
            obj = Choice()
            self.assertIsInstance(obj.__init__(), None)
    
    unittest.main()

# Generated at 2022-06-23 21:13:58.097316
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    # 
    assert isinstance(choice(items=['a', 'b', 'c']), str)
    assert choice(items=['a', 'b', 'c']) == "c"
    # 
    assert isinstance(choice(items=['a', 'b', 'c'], length=1), list)
    assert choice(items=['a', 'b', 'c'], length=1) == ["a"]
    #
    assert isinstance(choice(items='abc', length=2), str)
    assert choice(items='abc', length=2) == "ba"
    #
    assert isinstance(choice(items=('a', 'b', 'c'), length=5), tuple)

# Generated at 2022-06-23 21:14:08.408583
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    res = choice(items=['a', 'b', 'c'])
    assert (res in ['a', 'b', 'c'])
    res = choice(items=['a', 'b', 'c'], length=1)
    assert (res == ['a'])
    res = choice(items='abc', length=2)
    assert (res == 'ba' or res == 'ab' or res == 'cb')
    res = choice(items=('a', 'b', 'c'), length=5)
    assert (res == ('c', 'a', 'a', 'b', 'c'))
    res = choice(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-23 21:14:18.920109
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Use this to test that class Choice works as expected
    # with the method __call__()
    o1 = Choice()
    print(o1(['a', 'b', 'c']))
    print(o1(['a', 'b', 'c'], 3))
    print(o1('abc', 2))
    print(o1(('a', 'b', 'c'), 5))
    print(o1('aabbbccccddddd', 4, True))

    # Create an object of class Choice
    o2 = Choice()

    # Test the condition where items is a non-sequence

# Generated at 2022-06-23 21:14:21.778003
# Unit test for constructor of class Choice
def test_Choice():
    """Unit test for constructor of class Choice."""
    choice = Choice()
    assert choice


# Generated at 2022-06-23 21:14:24.277508
# Unit test for constructor of class Choice
def test_Choice():
    x=Choice()
    print(x.random.choice(range(5)))
test_Choice()

# Generated at 2022-06-23 21:14:25.762109
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice.__call__(items=['a', 'b', 'c'], length=1) == ['b']

test_Choice()

# Generated at 2022-06-23 21:14:32.722705
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4) == ['c', 'd', 'a', 'b']
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    assert choice(items=[1, 2, 3, 4], length=4) == [1, 3, 3, 3]
    assert choice

# Generated at 2022-06-23 21:14:34.039758
# Unit test for constructor of class Choice
def test_Choice():
    c=Choice()
    assert c is not None


# Generated at 2022-06-23 21:14:43.187513
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice()(items=['a', 'b', 'c']) == 'c'
    assert Choice()(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice()(items='abc', length=2) == 'ba'
    assert Choice()(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice()(items='aabbbccccddddd', length=4, unique=True) == 'cdba'



# Generated at 2022-06-23 21:14:45.081377
# Unit test for constructor of class Choice
def test_Choice():
    x = Choice()
    assert x != None



# Generated at 2022-06-23 21:14:47.480986
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    i = choice(items=['a', 'b', 'c'], length=4)
    assert isinstance(i, tuple)

# Generated at 2022-06-23 21:14:48.923064
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice.__class__.__name__ == 'Choice'

# Generated at 2022-06-23 21:14:54.535570
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    choice(items=['a', 'b', 'c'])
    choice(items=['a', 'b', 'c'], length=1)
    choice(items='abc', length=2)
    choice(items=('a', 'b', 'c'), length=5)
    choice(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-23 21:15:02.948404
# Unit test for constructor of class Choice
def test_Choice():
    # Test __call__ function
    assert Choice().__call__(['a', 'b']) == 'b'
    assert Choice().__call__(items=['a', 'b'], length=2, unique=True) == 'ab'
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    assert Choice().__call__(items=('a', 'b', 'c')) == 'c'

# Generated at 2022-06-23 21:15:04.311589
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice()
    #assert Choice() is Choice()


# Generated at 2022-06-23 21:15:11.445302
# Unit test for constructor of class Choice
def test_Choice():
    test = Choice()

    # Test __call__ method
    test.random.choice = lambda items: 'a'

    assert test(items=[1]) == 1

    assert test(items=('a', 'b', 'c'), length=3) == ('a', 'b', 'c')
    assert test(items=[1, 2, 3], length=3) == [1, 2, 3]
    assert test(items='abc', length=1) == 'c'

    assert test(items=('a', 'b', 'c'), length=5) == ('a', 'b', 'c', 'a', 'b')
    assert test(items=('a', 'b', 'c'), length=5, unique=True) == ('c', 'b', 'a', 'c', 'b')

# Generated at 2022-06-23 21:15:15.887590
# Unit test for constructor of class Choice
def test_Choice():
    # pylint: disable=protected-access
    assert Choice()._seed == 1000999
    assert Choice('12345')._seed == '12345'
    provider = Choice(_seed=123)
    assert provider._seed == 123
    provider._seed = 234
    assert provider._seed == 234

# Unit tests for __call__()

# Generated at 2022-06-23 21:15:18.684469
# Unit test for constructor of class Choice
def test_Choice():
    obj = Choice()

    assert obj.random is not None

# Generated at 2022-06-23 21:15:28.615599
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import random
    import mimesis.providers.choice as jsonize
    Choice = jsonize.Choice
    Choice = Choice(seed=random.randint(0, 1000))
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ba', 'cb', 'ac']
    assert choice(items=('a', 'b', 'c'), length=5) in [('c', 'a', 'a', 'b', 'c'), ('c', 'c', 'b', 'a', 'a'), ('c', 'a', 'b', 'c', 'a')]
    assert choice

# Generated at 2022-06-23 21:15:29.956439
# Unit test for constructor of class Choice
def test_Choice():
    ch = Choice()
    assert ch is not None


# Generated at 2022-06-23 21:15:36.646910
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-23 21:15:47.317098
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method Choice.__call__."""
    # pylint: disable = protected-access
    choice = Choice()

    assert isinstance(choice(['a', 'b', 'c']), str)
    assert len(choice(['a', 'b', 'c'], length=1)) == 1
    assert isinstance(choice('abc', length=2), str)
    assert isinstance(choice(('a', 'b', 'c'), length=5), tuple)
    assert isinstance(choice('aabbbccccddddd', length=4, unique=True), str)
    assert isinstance(choice(('a', 'b', 'c', 'd', 'e', 'f'), length=0), str)

# Generated at 2022-06-23 21:15:47.926449
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice()




# Generated at 2022-06-23 21:15:52.272486
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    items = c(items=['a', 'b', 'c'], length=3, unique=True)
    print(items)
    if isinstance(items, list):
        assert items == ['b', 'a', 'c']


# Generated at 2022-06-23 21:16:02.254548
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    seed = 0
    seed_msg = "Random number generator seed value: {}".format(seed)
    provider = Choice(seed=seed)
    assert provider.choice.__call__(items=['a', 'b', 'c'], length=0, unique=False) == 'a', seed_msg
    assert provider.choice.__call__(items=['a', 'b', 'c'], length=1, unique=False) == ['c'], seed_msg
    assert provider.choice.__call__(items='abc', length=2, unique=False) == 'bc', seed_msg
    assert provider.choice.__call__(items=('a', 'b', 'c'), length=5, unique=False) == ('b', 'a', 'c', 'b', 'c'), seed_msg
    assert provider.choice.__call__

# Generated at 2022-06-23 21:16:12.572747
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis.providers.datetime import Datetime
    from mimesis.enums import Gender

    c = Choice()
    assert (c.datetime.date(start=2010) < c.datetime.date(end=2010)) == False
    assert c.lorem.word() in c.lorem.words(quantity=10)
    assert c.datetime.datetime(start=2010) < c.datetime.datetime(end=2010)
    assert c.person.full_name(gender=Gender.FEMALE) in c.person.full_name(quantity=10, gender=Gender.FEMALE)
    assert c.person.full_name(gender=Gender.MALE) in c.person.full_name(quantity=10, gender=Gender.MALE)
    assert c.person.full

# Generated at 2022-06-23 21:16:15.815021
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 1
    unique = True
    assert choice(items=items, length=length) == ['a']
    assert choice(items=items, length=length, unique=unique) == ['a']
    assert choice(items=items, length=length, unique=False) == ['a']

# Generated at 2022-06-23 21:16:17.269112
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 1
    assert choice(items, length) == ['c']

# Generated at 2022-06-23 21:16:29.199406
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import pytest

    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    person = Person('en')
    choice = Choice('en')

    # length is not an int
    with pytest.raises(TypeError):
        choice(items=['a', 'b'], length='a')

    # items must be a sequence
    with pytest.raises(TypeError):
        choice(items=None)
    with pytest.raises(TypeError):
        choice(items={})
    with pytest.raises(TypeError):
        choice(items=person)

    # items is an empty sequence
    with pytest.raises(ValueError):
        choice(items='')
    with pytest.raises(ValueError):
        choice(items=[])

    # length

# Generated at 2022-06-23 21:16:35.669612
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    ascii_letters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
    assert choice(ascii_letters) in ascii_letters
    assert choice(ascii_letters, unique=True) in ascii_letters
    assert len(choice(ascii_letters, unique=True)) == 1
    assert len(choice(ascii_letters, 3, True)) == 3
    assert len(choice(ascii_letters, 5, False)) == 5

# Generated at 2022-06-23 21:16:36.976551
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice is not None


# Generated at 2022-06-23 21:16:44.525927
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    field_1 = 'field_1'
    field_2 = 'field_2'
    field_3 = 'field_3'
    field_4 = 'field_4'
    field_5 = 'field_5'
    field_6 = 'field_6'
    field_7 = 'field_7'
    field_8 = 'field_8'
    field_9 = 'field_9'
    field_10 = 'field_10'
    field_11 = 'field_11'
    field_12 = 'field_12'
    field_13 = 'field_13'
    field_14 = 'field_14'
    field_15 = 'field_15'
    field_16 = 'field_16'
    field_17 = 'field_17'
    field_18 = 'field_18'
   

# Generated at 2022-06-23 21:16:45.685851
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass


# Generated at 2022-06-23 21:16:52.433650
# Unit test for constructor of class Choice
def test_Choice():
    """Test for constructor of class Choice."""
    from mimesis import Choice

    choice = Choice()
    # return element from a list
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    # return element from a tuple
    assert choice(items=('a', 'b', 'c')) in ['a', 'b', 'c']
    # return element from a string
    assert choice(items='abc') in ['a', 'b', 'c']


# Unit tests for non-unique selections

# Generated at 2022-06-23 21:17:01.737578
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    ret = choice(items=['a', 'b', 'c'])
    assert ret in ['a', 'b', 'c']

    ret = choice(items=['a', 'b', 'c'], length=1)
    assert ret in [['a'], ['b'], ['c']]

    ret = choice(items='abc', length=2)
    assert ret in ['ab', 'ac', 'bc']

    ret = choice(items=('a', 'b', 'c'), length=5)

# Generated at 2022-06-23 21:17:07.901798
# Unit test for constructor of class Choice
def test_Choice():
    provider = Choice()
    choice1 = provider(["a", "b", "c"], 3)
    assert isinstance(choice1, list)
    for x in choice1:
        assert isinstance(x, str)

    choice2 = provider(["a", "b", "c"], 1)
    assert isinstance(choice2, list)
    for x in choice2:
        assert isinstance(x, str)

    choice3 = provider(['a', 'b', 'c'], 1, unique=True)
    assert isinstance(choice3, list)
    for x in choice3:
        assert isinstance(x, str)
        assert len(choice3) == 1

    choice4 = provider(["a", "b", "c"], 0, unique=True)
    assert isinstance(choice4, str)


# Generated at 2022-06-23 21:17:13.866859
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    ch = Choice()
    items = ['a', 'b', 'c']
    assert ch(items) in items
    assert len(ch(items, length=5)) == 5
    assert ch(items, unique=True) not in items
    assert ch(items, unique=True, length=10) not in items



# Generated at 2022-06-23 21:17:19.265670
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    from hypothesis import assume, given, settings, strategies as st

    choice = Choice()

    # Default length of 0
    items = st.lists(st.text(st.characters(), min_size=1))
    @given(items)
    def test_choice_length_0(items):
        assume(len(items) > 0)
        item = choice(items=items)
        assert item in items

    test_choice_length_0()

    # Length >= 1
    len_1_plus = st.integers(min_value=1)
    @given(items, len_1_plus)
    def test_choice_len1(items, length):
        assume(len(items) >= length)
        chosen_items = choice(items=items, length=length)

# Generated at 2022-06-23 21:17:23.395081
# Unit test for constructor of class Choice
def test_Choice():
    """Test class Choice with constructor."""
    provider = Choice()
    # Usage __init__(self, *args, **kwargs)
    assert isinstance(provider, Choice)

# Generated at 2022-06-23 21:17:31.065366
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert isinstance(choice(items=['a', 'b', 'c']), str)
    assert isinstance(choice(items=['a', 'b', 'c'], length=1), list)
    assert isinstance(choice(items='abc', length=2), str)
    assert isinstance(choice(items=('a', 'b', 'c'), length=5), tuple)
    assert isinstance(choice(items='aabbbccccddddd', length=4, unique=True), str)
    try:
        assert isinstance(choice(items=['a', 'b', 'c'], length=0), str)
    except TypeError:
        assert '**length** must be integer.'

# Generated at 2022-06-23 21:17:35.233497
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert c.__call__(items=['a', 'b', 'c'], length=5) in (['a', 'b', 'b', 'c', 'c'], ['a', 'b', 'c', 'b', 'a'])


# Generated at 2022-06-23 21:17:45.608775
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    assert choice(items=items, length=length, unique=unique) == ['a']

    choice = Choice()
    items = 'abc'
    length = 2
    unique = False
    assert choice(items=items, length=length, unique=unique) == 'ba'

    choice = Choice()
    items = ('a', 'b', 'c')
    length = 5
    unique = False
    assert choice(items=items, length=length, unique=unique) == ('c', 'a', 'a', 'b', 'c')

    choice = Choice()
    items = 'aabbbccccddddd'
    length = 4
    unique = True

# Generated at 2022-06-23 21:17:53.383711
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    # Test a bare element
    assert choice(items=['a', 'b', 'c']) == 'c'
    # Test a single element sequence
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    # Test a str
    assert choice(items='abc', length=2) == 'ba'
    # Test a tuple
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    # Test unique elements
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:18:01.435727
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:18:03.606153
# Unit test for constructor of class Choice
def test_Choice():
    obj = Choice()
    assert obj is not None


# Generated at 2022-06-23 21:18:07.291320
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 1
    unique = True
    assert choice(items=items) == 'c'
    assert choice(items=items, length=length) == ['a']
    assert choice(items="abc", length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items="aabbbccccddddd", length=4, unique=unique) == 'cdba'


# Generated at 2022-06-23 21:18:08.614875
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert c

# Generated at 2022-06-23 21:18:10.226712
# Unit test for constructor of class Choice
def test_Choice():
    obj = Choice()
    assert obj is not None
    assert type(obj) is Choice


# Generated at 2022-06-23 21:18:18.201352
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.person import Person
    from mimesis.providers.person import Person
    from mimesis.providers.person import Person
    from mimesis.providers.person import Person
    from mimesis.providers.person import Person
    from mimesis.providers.person import Person
    from mimesis.providers.person import Person
    from mimesis.providers.person import Person
    from mimesis.providers.person import Person
    from mimesis.providers.person import Person
    from mimesis.providers.person import Person
    from mimesis.providers.person import Person

# Generated at 2022-06-23 21:18:29.075706
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    from mimesis.providers.base import BaseProvider
    from mimesis.typing import SequenceType



# Generated at 2022-06-23 21:18:38.413969
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test __call__."""

    choice = Choice()
    data_01 = ['a', 'b', 'c']
    data_02 = ['a', 'b', 'c']
    data_03 = ['a', 'b', 'c']
    assert choice(data_01, 0, False) == 'c'
    assert choice(data_02, 1, False) == ['a']
    assert choice(data_03, 2, False) == 'ba'
    assert isinstance(choice(data_01, 0, True), str)
    assert isinstance(choice(data_02, 1, True), list)
    assert isinstance(choice(data_03, 2, True), str)

    data_04 = ('a', 'b', 'c')
    data_05 = ('a', 'b', 'c')
    data_06

# Generated at 2022-06-23 21:18:46.079416
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    #Testing if this is in all cases a string or a list of strings
    assert type(c(items=['a', 'b', 'c'])) in [list, str]
    assert type(c(items=['a', 'b', 'c'], length=1)) in [list, str]
    assert type(c(items='abc', length=2)) in [list, str]
    assert type(c(items=('a', 'b', 'c'), length=5)) in [list, str]
    assert type(c(items='aabbbccccddddd', length=4, unique=True)) in [list, str]

# Generated at 2022-06-23 21:18:47.044699
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice is not None


# Generated at 2022-06-23 21:18:57.721003
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # For example, there are:
    #     items = [1, 2, 3, 4, 5], length = 0
    #     items = [1, 2, 3, 4, 5], length = 2
    #     items = [1, 2, 3, 4, 5], length = 2, unique = True
    # Testcase 1
    items = [1, 2, 3, 4, 5]
    length = 0
    choice = Choice()
    assert choice(items=items, length=length) in items
    # Testcase 2
    items = [1, 2, 3, 4, 5]
    length = 2
    choice = Choice()
    assert len(choice(items=items, length=length)) == length
    assert type(choice(items=items, length=length)) == list
    # Testcase 3

# Generated at 2022-06-23 21:18:59.815133
# Unit test for constructor of class Choice
def test_Choice():
    sequence = Choice()
    assert isinstance(sequence, Choice)

