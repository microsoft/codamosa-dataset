

# Generated at 2022-06-23 21:09:08.417137
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method __call__ of class Choice."""
    choice = Choice()

    # Test 1
    items = ['a', 'b', 'c']
    length = 1
    assert choice(items=items, length=length) == ['a']

    # Test 2
    items = 'abc'
    length = 2
    assert choice(items=items, length=length) == 'ba'

    # Test 3
    items = ('a', 'b', 'c')
    length = 5
    assert choice(items=items, length=length) == ('c', 'a', 'a', 'b', 'c')

    # Test 4
    items = 'aabbbccccddddd'
    length = 4
    assert choice(items=items, length=length, unique=True) == 'cdba'

    # Test 5

# Generated at 2022-06-23 21:09:10.705865
# Unit test for constructor of class Choice
def test_Choice():
    meta = Choice.Meta()
    # assert meta.name == 'choice'
    choice = Choice()
    assert isinstance(choice, Choice)
    assert isinstance(choice, BaseProvider)


# Generated at 2022-06-23 21:09:20.483758
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender

    class _:
        choice = Choice('en')

    assert _.choice(items=[0, 1, 2, 3], length=10) == [2, 3, 1, 3, 2, 1, 0, 0, 1, 1]
    assert _.choice(items=[0, 1, 2, 3], length=0) in [0, 1, 2, 3]
    assert _.choice(items=[0, 1, 2, 3], length=1) in [[0], [1], [2], [3]]
    assert _.choice(items=[0, 1, 2, 3], length=10, unique=True) in [[1, 2, 0, 3], [0, 1, 2, 3]]

# Generated at 2022-06-23 21:09:27.957490
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()

    # test return values
    c(items=[1, 2, 3, 4], length=1)
    c(items=[1, 2, 3, 4], length=5, unique=True)
    c(items=[1, 2, 3, 4], length=5, unique=False)

    # test exceptions
    # ValueError: **items** must be a non-empty sequence.
    c(items=[])
    # TypeError: **length** must be integer.
    c(items=[1, 2, 3, 4], length='1')
    # ValueError: **length** should be a positive integer.
    c(items=[1, 2, 3, 4], length=-1)
    # ValueError: There are not enough unique elements in **items** to provide
    # the specified **number**.

# Generated at 2022-06-23 21:09:38.240684
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    # test for items=['a', 'b', 'c']
    element = choice(items=['a', 'b', 'c'])
    assert element in ['a', 'b', 'c']
    # test for items=['a', 'b', 'c'], length=1
    sequence = choice(items=['a', 'b', 'c'], length=1)
    assert sequence == ['a']
    # test for items='abc', length=2
    sequence = choice(items='abc', length=2)
    assert sequence in ['ba', 'ab', 'cb']
    # test for items=('a', 'b', 'c'), length=5
    sequence = choice(items=('a', 'b', 'c'), length=5)

# Generated at 2022-06-23 21:09:48.605271
# Unit test for constructor of class Choice
def test_Choice():
    """Creating the object"""
    chooser = Choice()
    assert chooser

    # Ensure that the correct type is returned to the user
    # on initialization
    assert isinstance(chooser('hello'), str)
    assert isinstance(chooser(['hello','world']), str)
    assert isinstance(chooser('hello', length=3), str)
    assert isinstance(chooser(['hello','world'], length=3), list)

    # Test that errors are thrown on a bad input
    assert chooser(1.5)
    assert chooser(['Not','empty'])

    # Test that errors are thrown on a bad input
    try:
        chooser(1)
    except TypeError:
        pass
    except:
        assert False, "Unexpected error: " + sys.exc_info()[0]


# Unit

# Generated at 2022-06-23 21:09:51.500674
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test to make sure method __call__ of class Choice works as expected."""
    # make sure the unit test runs only when specifically called
    print("Running: test_Choice___call__")
    assert False

# Generated at 2022-06-23 21:09:58.608402
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(['a', 'b', 'c']) == 'c'
    assert choice(['a', 'b', 'c'], 1) == ['a']
    assert choice('abc', 2) == 'ba'
    assert choice(('a', 'b', 'c'), 5) == ('c', 'a', 'a', 'b', 'c')
    assert choice('aabbbccccddddd', 4, True) == 'cdba'
    test_Choice___call__.__doc__ = choice.__call__.__doc__
    
    

# Generated at 2022-06-23 21:10:00.302094
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)

# Generated at 2022-06-23 21:10:11.175474
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test ``Choice.__call__`` method."""
    choice = Choice()
    sequence = ['a', 'b', 'c']

    # Test with length
    result = choice(sequence, length=7)
    assert isinstance(result, list)
    assert len(result) == 7
    assert all(item in sequence for item in result)

    assert choice(sequence, length=1) == ['a']
    assert choice(sequence, length=3) == ['c', 'a', 'c']
    assert choice(sequence, length=5) == ['a', 'c', 'b', 'a', 'a']

    # Test with unique
    result = choice(sequence, length=7, unique=True)
    assert isinstance(result, list)
    assert len(result) == 7
    assert set(result) == set(sequence)



# Generated at 2022-06-23 21:10:22.031881
# Unit test for constructor of class Choice
def test_Choice():

    from mimesis import Choice
    from mimesis import Datetime
    from mimesis import Person
    person = Person()

    age = person.age('20181125')
    print(age)
    choice = Choice()
    choice = Choice(Datetime())
    print(choice.choice())

    # def __init__(self, *args, **kwargs):
    #     super().__init__(*args, **kwargs)
    print('-1 Initialize attributes.')

    print(choice.choice(['a', 'b', 'c']))
    print(choice.choice(['a', 'b', 'c'],length=1))
    print(choice.choice('abc',length=2))
    print(choice.choice(('a', 'b', 'c'),length=5))

# Generated at 2022-06-23 21:10:32.789240
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(["a", "b", "c"]) in ["a", "b", "c"]
    assert Choice().__call__(["a", "b", "c"], 1) in [["a"], ["b"], ["c"]]
    assert Choice().__call__("abc", 2) in ["ab", "bc", "ca"]
    assert Choice().__call__(("a", "b", "c"), 5) in [("a", "b", "c", "a", "b"),
                                                     ("a", "b", "c", "b", "c"),
                                                     ("a", "b", "c", "c", "a")]
    assert Choice().__call__("aabbbccccddddd", 4, True) in ["dcba", "bdca", "bacd"]

# Generated at 2022-06-23 21:10:34.497005
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice is not None
    assert isinstance(choice, Choice)


# Generated at 2022-06-23 21:10:38.001095
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Provide the data for testing method __call__ of class Choice."""
    choice = Choice()  # type: ignore
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    assert choice(items)
    assert choice(items, length)
    assert choice(items, length, unique)

# Generated at 2022-06-23 21:10:43.544113
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice(seed=42)
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:10:44.396052
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass


# Generated at 2022-06-23 21:10:50.029174
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    # Test length of zero.
    choice(items=['a', 'b', 'c']) == 'b'
    # Test length of one.
    choice(items=['a', 'b', 'c'], length=1) == ['a']
    # Test length of two.
    choice(items='abc', length=2) == 'ba'
    # Test length of five.
    choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    # Test length of four with unique elements.
    choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:10:58.692086
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    # Test __init__()
    assert choice

    # Test __call__()
    result = choice(items=['a', 'b', 'c'], length=1)
    assert result
    assert result[0] in ['a', 'b', 'c']

    result = choice(items=['a', 'b', 'c'])
    assert result
    assert result in ['a', 'b', 'c']

    result = choice(items='abc', length=2)
    assert result
    assert result[0] in ['a', 'b', 'c']

    result = choice(items=('a', 'b', 'c'), length=5)
    assert result
    assert len(result) == 5

    result = choice(items=('a', 'b', 'c'), length=5, unique=True)


# Generated at 2022-06-23 21:11:06.187993
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:11:11.796018
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice.provider == 'choice'
    assert choice.locales == ['en']
    assert isinstance(choice.seed, int)
    assert isinstance(choice.datetime, str)
    assert choice.random is not None


# Generated at 2022-06-23 21:11:15.214183
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    data = [
        'a',
        'b',
        'c'
    ]
    expected_1 = 'c'

    assert Choice('Choice').__call__(data) == expected_1

# Generated at 2022-06-23 21:11:20.517137
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:11:30.526473
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import random
    alphabet = "abcdefghijklmnopqrstuvwxyz"

    def test_1(length, unique=False):
        c = Choice(random=random.Random())
        return c(alphabet, length=length, unique=unique)

    # test_1(length, unique)
    assert test_1(1) in alphabet
    assert len(test_1(26)) == 26
    assert len(test_1(26, unique=True)) == 26
    assert len(test_1(27)) == 27
    assert len(test_1(27, unique=True)) == 27

    # test_1(items, length, unique)
    items = "abcde"
    assert test_1(items, 1) in items
    assert len(test_1(items, 5)) == 5
    assert len

# Generated at 2022-06-23 21:11:39.677242
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    _choice = Choice()

    # Case 1
    _items = ['a', 'b', 'c']
    _expected = 'c'
    _result = _choice(_items)
    assert _expected == _result

    # Case 2
    _items = ['a', 'b', 'c']
    _expected = ['a']
    _result = _choice(_items, 1)
    assert _expected == _result

    # Case 3
    _items = 'abc'
    _expected = 'ba'
    _result = _choice(_items, 2)
    assert _expected == _result

    # Case 4
    _items = ('a', 'b', 'c')
    _expected = ('c', 'a', 'a', 'b', 'c')
    _result = _

# Generated at 2022-06-23 21:11:43.658305
# Unit test for constructor of class Choice
def test_Choice():
    """Test for Choice object."""
    from mimesis.enums import Gender

    c = Choice(gender=Gender.FEMALE)
    assert c.gender == Gender.FEMALE
    assert isinstance(c(), str)

# Generated at 2022-06-23 21:11:51.856542
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis import Choice
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 1
    unique = True
    print(choice(items=['a', 'b', 'c']))
    print(choice(items=['a', 'b', 'c'], length=1))
    print(choice(items='abc', length=2))
    print(choice(items=('a', 'b', 'c'), length=5))
    print(choice(items='aabbbccccddddd', length=4, unique=True))


# Generated at 2022-06-23 21:11:53.641160
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)
    assert repr(choice) != ''

# Generated at 2022-06-23 21:11:55.321377
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TODO
    pass



# Generated at 2022-06-23 21:12:00.942650
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    print(choice.choice(items=['a', 'b', 'c']))
    print(choice.choice(items=['a', 'b', 'c'], length=1))
    print(choice.choice(items='abc', length=2))
    print(choice.choice(items=('a', 'b', 'c'), length=5))
    print(choice.choice(items='aabbbccccddddd', length=4, unique=True))

    return True

# Generated at 2022-06-23 21:12:10.002396
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(['a', 'b', 'c']) == 'c'
    assert Choice().__call__(['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__('abc', length=2) == 'ba'
    assert Choice().__call__(('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__('aabbbccccddddd', length=4, unique=True) == 'cdba'
    try:
        assert Choice().__call__(5) == '5'
    except TypeError as e:
        print(e)

# Generated at 2022-06-23 21:12:16.637480
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    print(Choice().__call__(items=['a', 'b', 'c']))
    print(Choice().__call__(items=['a', 'b', 'c'], length=1))
    print(Choice().__call__(items='abc', length=2))
    print(Choice().__call__(items=('a', 'b', 'c'), length=5))
    print(Choice().__call__(items='aabbbccccddddd', length=4, unique=True))

# test_Choice___call__()

# Generated at 2022-06-23 21:12:21.769507
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    items = ["1","2","3"]
    test_item = choice.__call__(items)
    if test_item == "1" or test_item == "2" or test_item == "3":
        return True
    else:
        return False


# Generated at 2022-06-23 21:12:32.293182
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.providers.choice import Choice
    from mimesis.types import ChoiceOrder
    from mimesis.enums import ChoiceStrategy
    from mimesis.random import Random
    from mimesis.exceptions import NonDataProviderError
    from mimesis.providers.base import BaseProvider
    r = Random()
    r.choice_strategy = ChoiceStrategy.CHOICE
    choice = Choice(random=r)
    assert choice(items=['a', 'b', 'c']) == 'c'
    # For non-sequence items
    r.choice_strategy = ChoiceStrategy.ITERABLE
    choice = Choice(random=r)
    assert choice(items='abc', length=2) == 'ba'
    r.choice_strategy = ChoiceStrategy.RANDOM_CHOICE
    choice

# Generated at 2022-06-23 21:12:40.509057
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test the method __call__ of class Choice.

    # TODO: Test all returned types

    >>> from mimesis import Choice
    >>> choice = Choice()
    >>> choice.__call__(['a', 'b', 'c'])
    'c'
    >>> choice.__call__(['a', 'b', 'c'], length=1)
    ['a']
    >>> choice.__call__('abc', length=2)
    'ba'
    >>> choice.__call__(('a', 'b', 'c'), length=5)
    ('c', 'a', 'a', 'b', 'c')
    >>> choice.__call__('aabbbccccddddd', length=4, unique=True)
    'cdba'

    """
    pass


# Generated at 2022-06-23 21:12:42.017801
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().choice(items=['a', 'b', 'c'], length=2, unique=True) == ['b', 'a']

# Generated at 2022-06-23 21:12:43.032176
# Unit test for constructor of class Choice
def test_Choice():
    print(Choice())

# Generated at 2022-06-23 21:12:52.532198
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.providers.choice import Choice
    from mimesis.exceptions import NonUniqueError
    choice = Choice()
    assert choice('abc', 0) in 'abc'
    assert choice('abc', 1) in 'abc'
    assert choice('abc', 2) in 'abc'
    assert choice('abc', 3) in 'abc'
    assert choice('abc', 3, unique=True) in 'abc'
    assert choice(('a', 'b', 'c'), 1) in ('a', 'b', 'c')
    assert choice(('a', 'b', 'c'), 2) in ('a', 'b', 'c')
    assert choice(('a', 'b', 'c'), 5) in ('a', 'b', 'c')

# Generated at 2022-06-23 21:12:56.338046
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    items = ['a', 'b', 'c']
    assert choice(items=items) != ''
    assert choice(items=items, length=1) != ''
    assert choice(items='abc', length=2) != ''
    assert choice(items=('a', 'b', 'c'), length=5) != ''
    assert choice(items='aabbbccccddddd', length=4, unique=True) != ''

# Generated at 2022-06-23 21:12:58.061462
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice is not None

# Generated at 2022-06-23 21:13:07.680942
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import pytest
    from mypy_extensions import TypedDict

    class Data(TypedDict):
        items: list
        length: int
        unique: bool

    def _test(data: Data) -> None:
        provider = Choice()
        from typing import Any, Optional, Sequence, Union

        assert isinstance(provider(data['items'],
                                   data['length'],
                                   data['unique']), Any)
        assert isinstance(provider(data['items'],
                                   data['length'],
                                   data['unique']), Union[Sequence[Any], Any])


# Generated at 2022-06-23 21:13:08.914564
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice('a') in 'a'



# Generated at 2022-06-23 21:13:17.844916
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person import Person
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.files import Files
    from mimesis.providers.science import Science
    from mimesis.providers.language import Language
    from mimesis.providers.address import Address
    from mimesis.providers.financial import Financial
    from mimesis.providers.internet import Internet
    from mimesis.providers.geo import Geo
    from mimesis.providers.person import Person
    from mimesis.enums import Gender

    mimesis = Choice(datetime=Datetime())

    # test_Choice___call__1
    items = ['a', 'b', 'c']
    length = 0

# Generated at 2022-06-23 21:13:24.101375
# Unit test for constructor of class Choice
def test_Choice():
    import pytest
    from mimesis.exceptions import NonEnumerableError
    choice = Choice()

    with pytest.raises(TypeError):
        choice(items=123, length=3)

    with pytest.raises(ValueError):
        choice(items=[], length=3)

    with pytest.raises(TypeError):
        choice(items=['1', '2', '3'], length='3')

    with pytest.raises(ValueError):
        choice(items=['1', '2', '3'], length=-3)

    with pytest.raises(NonEnumerableError):
        choice(items={'1': 1, '2': 2, '3': 3})



# Generated at 2022-06-23 21:13:24.736160
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice()


# Generated at 2022-06-23 21:13:29.492324
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:13:32.037820
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.providers.generic import choice

    choice = Choice()

    return choice(items=['a', 'b', 'c'])

# Generated at 2022-06-23 21:13:33.469592
# Unit test for constructor of class Choice
def test_Choice():
    value = Choice()
    assert value is not None


# Generated at 2022-06-23 21:13:40.226618
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert isinstance(c.__call__(items=['a', 'b', 'c']), str)
    assert isinstance(c.__call__(items=['a', 'b', 'c'], length=1), list)
    assert isinstance(c.__call__(items='abc', length=2), str)
    assert isinstance(c.__call__(items=('a', 'b', 'c'), length=5), tuple)
    assert isinstance(c.__call__(items='aabbbccccddddd', length=4, unique=True), str)

# Generated at 2022-06-23 21:13:42.042357
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']


# Generated at 2022-06-23 21:13:43.216390
# Unit test for constructor of class Choice
def test_Choice():
    d = Choice()
    assert d is not None

# Generated at 2022-06-23 21:13:44.175211
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice()
    

# Generated at 2022-06-23 21:13:46.687120
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test __call__ method of class Choice.

    This method is inherited from BaseProvider,
    and is not implemented by class Choice.
    """
    Choice.__call__


# Generated at 2022-06-23 21:13:48.035172
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    print(Choice().__call__(items=['a', 'b', 'c']))

# Generated at 2022-06-23 21:13:49.430035
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()

    assert isinstance(choice, Choice), "Did not create an instance of class Choice"


# Generated at 2022-06-23 21:13:50.798050
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice.choice._items == ['a', 'b']



# Generated at 2022-06-23 21:13:54.348341
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = [1, 2, 3]
    assert isinstance(items, collections.abc.Sequence)
    # length = 3 should be ok
    choice = Choice()
    choice_result = choice(items=items, length=3)
    assert isinstance(choice_result, list)
    assert len(choice_result) == 3

# Generated at 2022-06-23 21:13:56.321411
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)
    assert isinstance(choice, BaseProvider)


# Generated at 2022-06-23 21:14:02.898098
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    choice = Choice()
    assert isinstance(choice.__call__(items=['a', 'b', 'c']), str)
    assert isinstance(choice.__call__(items=['a', 'b', 'c'], length=1), list)
    assert isinstance(choice.__call__(items='abc', length=2), str)
    assert isinstance(choice.__call__(items=('a', 'b', 'c'), length=5), tuple)
    assert isinstance(choice.__call__(items='aabbbccccddddd', length=4, unique=True), str)

# Generated at 2022-06-23 21:14:10.415041
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice.__class__.__name__ == 'Choice'
    assert type(choice.random.choice([])) == type(None)
    assert choice(['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(['a', 'b', 'c'], 1) in ['a', 'b', 'c']
    assert choice('abc', 2) in ['ab', 'ac', 'bc']
    assert choice(('a', 'b', 'c'), 5) in [('a', 'b', 'c', 'a', 'b'), ('a', 'b', 'c', 'a', 'c'), ('a', 'b', 'c', 'a', 'b')]

# Generated at 2022-06-23 21:14:20.569533
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Docstring"""
    from typing import List, Optional, Tuple

    from mimesis.builtins import Choice

    c = Choice()
    result = c(items=['a', 'b', 'c'], length=0, unique=False)
    assert isinstance(result, str)

    result = c(items=['a', 'b', 'c'], length=5, unique=True)
    assert isinstance(result, List)
    assert len(result) == 5

    result = c(items=('a', 'b', 'c'), length=5, unique=True)
    assert isinstance(result, Tuple)
    assert len(result) == 5

    result = c(items='abc', length=5, unique=True)
    assert isinstance(result, str)
    assert len(result) == 5

    result

# Generated at 2022-06-23 21:14:22.593415
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert isinstance(c, Choice)


# Generated at 2022-06-23 21:14:30.689526
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice.__call__('abc') in 'abc'
    assert choice.__call__('abc', 1) in 'abc'
    assert choice.__call__('abc', 2) in 'abc'
    assert choice.__call__('aabbcc', 2, True) in 'abc'
    assert choice.__call__('aabbcc', 3, True) in 'abc'
    try:
        choice.__call__('')
        assert False
    except ValueError:
        assert True
    try:
        choice.__call__(['a', 'b'], -1)
        assert False
    except ValueError:
        assert True
    try:
        choice.__call__(('a', 'b', 'c'), 4)
        assert False
    except ValueError:
        assert True
   

# Generated at 2022-06-23 21:14:36.338115
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    res = choice('abc')
    assert res in ('a', 'b', 'c')
    assert choice('abc', length=1) == ['a']
    assert choice('abc', length=2) == 'ba'
    assert choice(('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice('aabbbccccddddd', length=4, unique=True) == 'cdba'



# Generated at 2022-06-23 21:14:46.096436
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    args = [
        [
            None,
            [
                'foo',
                'bar',
                'baz',
            ],
        ],
        [
            None,
            [
                'foo',
                'bar',
                'baz',
            ],
            1,
        ],
        [
            None,
            'foo',
            1,
        ],
        [
            None,
            (
                'foo',
                'bar',
                'baz',
            ),
            5,
        ],
        [
            None,
            'aabbbccccddddd',
            4,
            True,
        ],
    ]

    # TODO: Fix non-deterministic test
    # choice = Choice()

    # for

# Generated at 2022-06-23 21:14:52.462848
# Unit test for constructor of class Choice
def test_Choice():
    provider = Choice()
    result = provider.__call__(items=['a', 'b', 'c'])
    assert result == 'c'
    result = provider.__call__(items=['a', 'b', 'c'], length=1)
    assert result == ['a']
    result = provider.__call__(items='abc', length=2)
    assert result == 'ba'
    result = provider.__call__(items=('a', 'b', 'c'), length=5)
    assert result == ('c', 'a', 'a', 'b', 'c')
    result = provider.__call__(items='aabbbccccddddd', length=4, unique=True)
    assert result == 'cdba'

# Generated at 2022-06-23 21:14:53.635779
# Unit test for constructor of class Choice
def test_Choice():
    return Choice()


# Generated at 2022-06-23 21:14:56.130475
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    provider = Choice()

    # Test type error if **items** is not a sequence
    items = 123
    length = 1
    unique = True
    assert provider(items, length, unique) == 'c'


# Generated at 2022-06-23 21:15:05.246371
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice()._Choice__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice()._Choice__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice()._Choice__call__(items='abc', length=2) == 'ba'
    assert Choice()._Choice__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice()._Choice__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:15:06.735040
# Unit test for constructor of class Choice
def test_Choice():
    """Test the constructor of the class Choice."""
    choice = Choice()
    assert choice is not None


# Generated at 2022-06-23 21:15:12.386372
# Unit test for constructor of class Choice
def test_Choice():
    """Unit test for class Choice."""
    ob = Choice()
    assert ob._seed is None
    assert ob._random is not None
    assert ob._datetime is not None
    assert ob._provider is not None
    assert ob._provider.locale.code == 'en'
    assert ob._provider.category == 'choice'

    ob = Choice('ru')
    assert ob._seed is None
    assert ob._random is not None
    assert ob._datetime is not None
    assert ob._provider is not None
    assert ob._provider.locale.code == 'ru'
    assert ob._provider.category == 'choice'


# Generated at 2022-06-23 21:15:13.029512
# Unit test for constructor of class Choice
def test_Choice():
    Choice()

# Generated at 2022-06-23 21:15:14.266939
# Unit test for constructor of class Choice
def test_Choice():
    """Check constructor of class Choice."""
    assert Choice() is not None


# Generated at 2022-06-23 21:15:18.498714
# Unit test for constructor of class Choice
def test_Choice():
    _choice = Choice

    assert isinstance(Choice, type)
    assert isinstance(_choice, Choice)

    assert isinstance(_choice.random, _choice.random.__class__)
    assert isinstance(_choice.datetime.timestamp, float)

    assert isinstance(_choice.mimesis, _choice.mimesis.__class__)
    assert isinstance(_choice.random.choice, collections.abc.Callable)
    assert isinstance(_choice.random.random, collections.abc.Callable)



# Generated at 2022-06-23 21:15:21.385767
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c', 'd', 'e']
    length = 5
    answer = 'ecead'
    result = Choice().__call__(items=items, length=length, unique=True)
    assert result == answer

# Generated at 2022-06-23 21:15:24.156400
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)
    assert isinstance(choice, BaseProvider)
    assert callable(choice)



# Generated at 2022-06-23 21:15:25.158645
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=[1, 2, 3], length=100) is not None

# Generated at 2022-06-23 21:15:27.412617
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice !='Choice'
    assert choice !=None
    assert choice.Meta.name =='choice'


# Generated at 2022-06-23 21:15:28.034483
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice()

# Generated at 2022-06-23 21:15:33.801202
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-23 21:15:39.543717
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # check __call__() method
    items = ('1', '2', '3', '4')
    length = 50
    unique = True
    choice = Choice()
    result = choice(items=items, length=length, unique=unique)
    assert len(result) == length
    assert len(set(result)) == length

# Generated at 2022-06-23 21:15:40.530231
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert callable(Choice.__call__)


# Generated at 2022-06-23 21:15:42.024791
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert isinstance(c, Choice)


# Generated at 2022-06-23 21:15:44.895283
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 1
    unique = True
    assert choice(items=items, length=length, unique=unique) == ['c']

# Generated at 2022-06-23 21:15:46.580844
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice.__class__.__name__ == 'Choice'
    

# Generated at 2022-06-23 21:15:47.841128
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert isinstance(c, Choice)


# Generated at 2022-06-23 21:15:48.466350
# Unit test for constructor of class Choice
def test_Choice():
    provider = Choice()
    assert provider


# Generated at 2022-06-23 21:15:51.807074
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    items = ['a', 'b', 'c']
    assert isinstance(items, list)
    print("Test constructor of class Choice: Successful\n")


# Generated at 2022-06-23 21:15:53.813845
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Test Case 1
    # Test Case 2
    # Test Case 3
    pass

# Generated at 2022-06-23 21:16:02.935069
# Unit test for constructor of class Choice
def test_Choice():
    items = ['a', 'b', 'c']
    length = 2
    unique = False
    choice = Choice()
    test_call = choice(items=items, length=length, unique=unique)
    assert(isinstance(test_call, Sequence))
    assert(len(test_call) == length)
    assert(np.all(np.isin(test_call, items)))
    unique = True
    choice = Choice()
    test_call = choice(items=items, length=length, unique=unique)
    assert(isinstance(test_call, Sequence))
    assert(len(test_call) == length)
    assert(np.all(np.isin(test_call, items)))
    length = 1
    choice = Choice()
    test_call = choice(items=items, length=length, unique=unique)


# Generated at 2022-06-23 21:16:12.844380
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    assert type(choice(items=[1, 2, 3])) == int
    assert len(choice(items=[1, 2, 3], length=5)) == 5
    assert len(choice(items='abcde', length=5)) == 5

    # with pytest.raises(TypeError):
    #     choice(items=None, length=2)

    # with pytest.raises(TypeError):
    #     assert choice(items=[1, 2, 3], length='2')

    # with pytest.raises(ValueError):
    #     assert choice(items=[1, 2, 3], length=-1)

    # with pytest.raises(ValueError):
    #     assert choice(items=[1, 2, 3], length=5, unique=True)

# Generated at 2022-06-23 21:16:14.120405
# Unit test for constructor of class Choice
def test_Choice():
   x = Choice()
   assert x is not None


# Generated at 2022-06-23 21:16:18.819694
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choices = Choice(locale='en')

    assert choices(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert isinstance(choices(items=['a', 'b', 'c'], length=1), list)
    assert choices(items='abc', length=2) in ['ab', 'ba', 'bc']
    assert isinstance(choices(items=('a', 'b', 'c'), length=5), tuple)
    assert isinstance(choices(items='aabbbccccddddd', length=4, unique=True), str)

# Generated at 2022-06-23 21:16:26.875619
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice__call__(['a', 'b', 'c']) == 'c'
    assert Choice__call__(['a', 'b', 'c'], length=1) == ['a']
    assert Choice__call__('abc', length=2) == 'ba'
    assert Choice__call__(('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice__call__('aabbbccccddddd', length=4, unique=True) == 'cdba'



# Generated at 2022-06-23 21:16:28.309571
# Unit test for constructor of class Choice
def test_Choice():
    instance = Choice()
    assert instance is not None
    assert repr(instance) == "<Choice>"
    assert str(instance) == "<Choice>"


# Generated at 2022-06-23 21:16:29.216707
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice()


# Generated at 2022-06-23 21:16:39.295503
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender

    class Person(Choice):
        class Meta:
            name = 'person'

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.gender = Gender.MALE

        def get_first_name(self, gender: str = None) -> str:
            """Get first name."""
            return self.random.word(gender=gender)

    person = Person('en')
    assert person.get_first_name(gender=person.gender) != ''
    assert len(person(items=['a', 'b', 'c'], length=0)) == 1
    name = person(items='abc', length=1)
    assert name == 'a' or name == 'b' or name == 'c'

# Generated at 2022-06-23 21:16:43.107449
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    """
    **Example:
        >>> from mimesis import Choice
        >>> Choice().choice(["a", "b", "c"])
        'a'
    """

# Generated at 2022-06-23 21:16:47.271616
# Unit test for constructor of class Choice
def test_Choice():
    """Test for constructor of class Choice"""
    c = Choice()
    try:
        c(items=[1, 2, 3])
    except:
        c = -1
    assert c != -1


# Generated at 2022-06-23 21:16:48.687214
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)

# Generated at 2022-06-23 21:16:50.407144
# Unit test for constructor of class Choice
def test_Choice():
    """Test for Choice class."""
    assert Choice().__class__.__name__ == 'Choice'

# Generated at 2022-06-23 21:16:54.301371
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    items = ['a', 'b', 'c']
    actual = c(items=items, length=1)
    expected = ['a']
    assert actual == expected
    actual = c(items=items)
    assert actual in items

# Generated at 2022-06-23 21:17:02.396388
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    assert choice(items=('c', 'd'), length=5, unique=True) == ('d', 'c', 'c', 'd', 'd')


# Generated at 2022-06-23 21:17:04.756750
# Unit test for constructor of class Choice
def test_Choice():
    obj = Choice()
    print(obj.__class__.__name__)
    print(obj.__doc__)
    assert obj(items=[1, 2, 3, 4], length=2) == [1, 2]
    print(obj(items=[1, 2, 3, 4], length=2))


test_Choice()

# Generated at 2022-06-23 21:17:10.700645
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    if choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba':
        return True
    return False

# Generated at 2022-06-23 21:17:17.828787
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert type(choice(items=['a', 'b', 'c'])) is str
    assert type(choice(items=['a', 'b', 'c'], length=1)) is list
    assert type(choice(items='abc', length=2)) is str
    assert type(choice(items=('a', 'b', 'c'), length=5)) is tuple
    assert type(choice(items='aabbbccccddddd', length=4, unique=True)) is str

# Generated at 2022-06-23 21:17:18.562836
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert c is not None

# Generated at 2022-06-23 21:17:29.025161
# Unit test for constructor of class Choice
def test_Choice():
    import sys
    import os
    sys.path.append(os.path.dirname(__file__))
    import providers.choice.choice

    # Initializing of class Choice and all its methods
    choice = Choice(language='en')

    # Call of method __call__
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

    # Call of method

# Generated at 2022-06-23 21:17:35.181936
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert c(items=['a', 'b', 'c'], length=1, unique=False) == ['b']
    assert c(items='abc', length=2, unique=True) == 'ca'
    assert c(items=(), length=5, unique=False) == ('', '', '', '', '')

if __name__ == '__main__':
    test_Choice()

# Generated at 2022-06-23 21:17:36.971339
# Unit test for constructor of class Choice
def test_Choice():
    """Constructor of class Choice."""
    choice = Choice('en')
    assert isinstance(choice, Choice)

# Generated at 2022-06-23 21:17:38.360435
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice != None


# Generated at 2022-06-23 21:17:45.946518
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.builtins import Choice
    from mimesis.enums import Gender
    from mimesis.providers.address import Address
    aa = Address()
    cc = Choice()
    cc(items=['a', 'b', 'c'])
    cc(items=['a', 'b', 'c'], length=1)
    cc(items='abc', length=2)
    cc(items=('a', 'b', 'c'), length=5)
    cc(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-23 21:17:47.385656
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert(isinstance(choice, Choice))

# Generated at 2022-06-23 21:17:48.316987
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert c is not None

# Generated at 2022-06-23 21:17:51.743595
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    obj = Choice()
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    result = obj(items, length, unique)
    assert isinstance(result, str)
    assert result in items

# Generated at 2022-06-23 21:18:02.499224
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice([1, 2, 3]) in [1, 2, 3]
    assert choice([1, 2, 3], length=1) in [[1], [2], [3]]
    assert choice((1, 2, 3), length=2) in [(1, 2), (1, 3), (2, 3)]
    assert choice((1, 2, 3), length=3) in [(1, 2, 3)]
    assert choice('123', length=2) in ['12', '13', '21', '23', '31', '32']
    assert choice(['a', 'a', 'b', 'b', 'c', 'c', 'c', 'c'], length=4, unique=True) in ['abcc', 'bbac', 'cbac', 'cabc', 'bcac', 'bcac']

# Generated at 2022-06-23 21:18:07.525731
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from random import choice
    from mimesis import Choice
    from hypothesis import given
    from hypothesis.strategies import sampled_from, text, lists

    choice_gen = Choice()
    items = ['ab', 'a', 'abc', 'aa', 'b', 'aac', 'ca', 'ac', 'aabc', 'c']
    length = [0, 1, 2, 3, 4, 5, 10, 15, 20, 30, 40, 50, 100, 200, 300, 500]
    unique = [False, True]
    # cli.main()

# Generated at 2022-06-23 21:18:09.250706
# Unit test for constructor of class Choice
def test_Choice():
    """Test method init of class Choice."""
    c = Choice()
    assert c is not None


# Generated at 2022-06-23 21:18:17.602243
# Unit test for constructor of class Choice
def test_Choice():
    a = Choice()
    a(items=['a', 'b', 'c'])
    assert a(items=['a', 'b', 'c']) in ['a','b','c']
    a(items=['a', 'b', 'c'], length=1)
    assert a(items=['a', 'b', 'c'], length=1) == ['a']
    a(items='abc', length=2)
    assert a(items='abc', length=2) in ['aa','ab','ac','ba','bb','bc','ca','cb','cc']
    a(items=('a', 'b', 'c'), length=5)
    assert len(a(items=('a', 'b', 'c'), length=5)) == 5

# Generated at 2022-06-23 21:18:18.213685
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice is not None

# Generated at 2022-06-23 21:18:19.708452
# Unit test for constructor of class Choice
def test_Choice():
    c=Choice()
    assert c

# Generated at 2022-06-23 21:18:24.357433
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)
    assert isinstance(choice, BaseProvider)
    assert isinstance(choice.Meta, type)
    assert isinstance(choice.Meta.name, str)
    assert choice('abc', length=5) == 'acabc'


# Generated at 2022-06-23 21:18:33.424789
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method ``__call__`` of class ``Choice``.

    Use a few test cases.

    :return: ``None``
    """
    from mimesis.enums import Gender
    from mimesis.exceptions import NonEnumerableError
    from mimesis.providers.person import Person

    choice = Choice()

    # Test case #1
    items_1 = ['a', 'b', 'c']
    length_1 = 1
    unique_1 = False
    expected_1 = ['a']
    actual_1 = choice(items=items_1, length=length_1, unique=unique_1)
    assert actual_1 == expected_1

    # Test case #2
    items_2 = 'abc'
    length_2 = 2
    unique_2 = False
    expected_2 = 'ba'

# Generated at 2022-06-23 21:18:41.605992
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    print("Test for method __call__ of class Choice")
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    assert choice(items=['a', 'b', 'c'], length=2, unique=True) == ['a', 'b']


# Generated at 2022-06-23 21:18:43.589943
# Unit test for constructor of class Choice
def test_Choice():
    chooser = Choice()
    assert chooser
    assert chooser.seed
    assert chooser.random


# Generated at 2022-06-23 21:18:45.502080
# Unit test for constructor of class Choice
def test_Choice():
    result = Choice()
    assert result is not None 


# Generated at 2022-06-23 21:18:47.340798
# Unit test for constructor of class Choice
def test_Choice():
    test = Choice()
    assert 'a' == test(['a', 'b', 'c'])



# Generated at 2022-06-23 21:18:53.802850
# Unit test for constructor of class Choice
def test_Choice():
    ch = Choice()
    assert hasattr(ch, '__name__') == False
    assert hasattr(ch, '__module__') == False
    assert hasattr(ch, '__qualname__') == False
    assert callable(ch) == True
    assert hasattr(ch, '__init__') == True
    assert hasattr(ch, '__call__') == True



# Generated at 2022-06-23 21:18:55.385387
# Unit test for constructor of class Choice
def test_Choice():
    instance = Choice()
    assert isinstance(instance, Choice)

# Unit test Choice.__call__()

# Generated at 2022-06-23 21:19:03.854501
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert isinstance(c, Choice)
    assert isinstance(c.random, type(None))
    assert isinstance(c.datetime, type(None))
    assert isinstance(c.person, type(None))
    assert isinstance(c.business, type(None))
    assert isinstance(c.address, type(None))
    assert isinstance(c.numbers, type(None))
    assert isinstance(c.science, type(None))
    assert isinstance(c.codec, type(None))
    assert isinstance(c.faker, type(None))
    assert not hasattr(c, "a")
    assert not hasattr(c, "choice")
    assert not hasattr(c, "__init__")
    assert not hasattr(c, "__call__")
   