

# Generated at 2022-06-23 21:08:59.927193
# Unit test for constructor of class Choice
def test_Choice():
    """Test for constructor of class Choice."""
    choice = Choice()
    assert isinstance(choice, Choice)

# Generated at 2022-06-23 21:09:03.891258
# Unit test for constructor of class Choice
def test_Choice():
    # test Choice object with default parameters
    c = Choice()
    
    # test generating a single random choice
    choice = c(['a', 'b', 'c'])
    assert(choice == 'a' or choice == 'b' or choice == 'c')

    # test generating a list of random choices
    choices = c(['a','b','c'],length = 2)
    assert(choices == ['a','a'] or choices == ['a','b'] or choices == ['a','c'] or
           choices == ['b','a'] or choices == ['b','b'] or choices == ['b','c'] or
           choices == ['c','a'] or choices == ['c','b'] or choices == ['c','c'])

    # test generating a string of random choices
    choices = c('abc',length = 3)

# Generated at 2022-06-23 21:09:05.089210
# Unit test for constructor of class Choice
def test_Choice():
	select = Choice()
	# Initialize attributes.
	assert(select.random)

# Generated at 2022-06-23 21:09:12.184037
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method __call__ of class Choice."""
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) in ['ba', 'ab', 'cb']
    assert choice(items=('a', 'b', 'c'), length=5) in [
        ('a', 'b', 'c', 'b', 'a'), ('a', 'b', 'c', 'a', 'c'),
        ('a', 'b', 'c', 'c', 'c'), ('a', 'b', 'c', 'a', 'b')]

# Generated at 2022-06-23 21:09:18.475886
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test of method Choice.__call__"""
    c = Choice()
    assert len(c(items=['a', 'b', 'c'], length=2)) == 2
    assert c(items=['a', 'b', 'c'], length=2) == ['a', 'c']
    assert c(items=['a', 'b', 'c'], length=2) == ['a', 'c']


# Generated at 2022-06-23 21:09:29.294780
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()

    assert isinstance(choice, Choice)
    assert isinstance(choice, BaseProvider)
    assert isinstance(choice.random, Choice)
    assert isinstance(choice.random, BaseProvider)
    assert callable(choice)
    assert callable(choice.random)
    assert hasattr(choice, "Meta")
    assert hasattr(choice.random, "Meta")
    assert hasattr(choice, "__call__")
    assert hasattr(choice.random, "__call__")
    assert choice.Meta.class_name == "Choice"
    assert choice.Meta.package == "mimesis.providers.generic"
    assert choice.Meta.name == "choice"
    assert choice.Meta.class_name == "Choice"
    assert choice.Meta.package == "mimesis.providers.generic"

# Generated at 2022-06-23 21:09:34.372529
# Unit test for constructor of class Choice
def test_Choice():
    test_items = ('a', 'b', 'c')
    test_length = 5
    test_unique = True
    test_choiceInstance = Choice()
    res = test_choiceInstance(items=test_items, length=test_length, unique=test_unique)
    assert res == ('a', 'b', 'c', 'b', 'a')

# Generated at 2022-06-23 21:09:35.095715
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    print(choice)


# Generated at 2022-06-23 21:09:42.606603
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    # TODO: Add test for return type, for items of type list, tuple and str
    from mimesis import Choice

    choice = Choice()

    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-23 21:09:53.386540
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from unittest import TestCase
    from unittest.mock import patch
    from mimesis import Choice

    class ChoiceTestCase(TestCase):

        @patch('mimesis.enums.DataType.STRING')
        @patch('mimesis.enums.DataType.TEXT')
        @patch('mimesis.enums.DataType.FULL_NAME')
        @patch('mimesis.enums.DataType.FIRST_NAME')
        def test__call__(self, first_name, full_name, text, string):
            first_name.return_value = 'first_name'
            full_name.return_value = 'full_name'
            text.return_value = 'text'
            string.return_value = 'string'
            choise = Choice()
            self.assertIs

# Generated at 2022-06-23 21:10:00.673640
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """
    Unit test for method __call__ of class Choice.
    """
    choice = Choice()
    #Unit test for the method
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:10:11.551537
# Unit test for constructor of class Choice
def test_Choice():
    """
    Method for testing constructor of class Choice.
    
    """
    # variant 1
    items1 = ['example1@example.com', 'example2@example.com', 'example3@example.com'] # list
    length = 0 # int
    unique = False # bool
    c = Choice()
    assert c.__call__(items1, length, unique) in items1
    
    # variant 2
    items2 = ('a', 'b', 'c') # tuple
    c = Choice()
    assert c.__call__(items2, length, unique) in items2
    
    # variant 3
    items3 = 'abc' # str
    c = Choice()
    assert c.__call__(items3, length, unique) in items3
   
    # variant 4

# Generated at 2022-06-23 21:10:22.673309
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from random import seed
    from random import random

    from hypothesis import given
    from hypothesis import strategies

    from . import custom_strategies

    seed(random())

    # Setup
    choice = Choice()
    items = (
        custom_strategies.non_empty_sequences(
            min_size=1, max_size=5,
            elements=strategies.integers(),
        )
    )
    length = strategies.integers(min_value=0, max_value=5)

    # Execute
    @given(items, length, strategies.booleans())
    def test_Choice___call__(items, length, unique):
        choice(items, length, unique)

    # Verify
    test_Choice___call__()

    # Teardown

# Generated at 2022-06-23 21:10:24.522606
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    print(c.__class__)
    assert c.__class__ == Choice


# Generated at 2022-06-23 21:10:30.038564
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    items = ['a', 'b', 'c']
    choice.choice(items=items)
    choice.choice(items=items, length=1)
    choice.choice(items='abc', length=2)
    choice.choice(items=('a', 'b', 'c'), length=5)
    choice.choice(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-23 21:10:39.104033
# Unit test for method __call__ of class Choice

# Generated at 2022-06-23 21:10:42.424002
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    x = choice(items=['a', 'b', 'c'])
    print(x)
    print('ok')

if __name__ == '__main__':
    test_Choice()

# Generated at 2022-06-23 21:10:52.091667
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import random
    import string

    choice = Choice(random)
    assert choice.choice(string.ascii_uppercase, 6) in string.ascii_uppercase
    from_tuple = choice.choice(('a', 'b', 'c'), length=5)
    assert len(from_tuple) == 5, 'expected length 5'
    assert from_tuple[0] == 'c' or from_tuple[1] == 'c' or from_tuple[2] == 'c' or from_tuple[3] == 'c' or from_tuple[4] == 'c'
    assert len(choice.choice(['a', 'b', 'c'], length=12, unique=True)) == 12
    from_string = choice.choice('abc', 2)

# Generated at 2022-06-23 21:10:53.129603
# Unit test for constructor of class Choice
def test_Choice():
    data = Choice()
    assert data


# Generated at 2022-06-23 21:10:59.868443
# Unit test for method __call__ of class Choice

# Generated at 2022-06-23 21:11:07.855723
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    from mimesis import Choice
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-23 21:11:14.142813
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Create an instance of class Choice
    choice = Choice()

    # Test __call__ method of class Choice with parameters
    # items = ['a', 'b', 'c'], length = 1, unique = False
    assert choice(items=['a', 'b', 'c'],
                  length=1,
                  unique=False) == ['a']
    # Test __call__ method of class Choice with parameters
    # items = ['a', 'b', 'c'], length = 1, unique = True
    assert choice(items=['a', 'b', 'c'],
                  length=1,
                  unique=True) == ['c']
    # Test __call__ method of class Choice with parameters
    # items = ['a', 'b', 'c'], length = 2, unique = False

# Generated at 2022-06-23 21:11:20.077364
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-23 21:11:30.405124
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method '__call__' of class Choice.

    :return:
    """
    settings = {
        'items': ['a', 'b', 'c'],
        'length': 0,
        'unique': False,
    }
    choice = Choice(settings=settings)

    # Check type of returned value
    assert isinstance(choice(**settings), str)
    settings['items'] = ['a', 'b', 'c']
    settings['length'] = 1
    settings['unique'] = False
    # Check type of returned value
    assert isinstance(choice(**settings), list)
    settings['items'] = 'abc'
    settings['length'] = 2
    settings['unique'] = False
    assert isinstance(choice(**settings), str)
    settings['items'] = ['a', 'b', 'c']
   

# Generated at 2022-06-23 21:11:37.473616
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice.
    """
    assert Choice().__call__(['a', 'b', 'c']) == 'c'
    assert Choice().__call__(['a', 'b', 'c'], 1) == ['a']
    assert Choice().__call__('abc', 2) == 'ba'
    assert Choice().__call__(('a', 'b', 'c'), 5) == ('c', 'a', 'a', 'b','c')
    assert Choice().__call__('aabbbccccddddd', 4, True) == 'cdba'


# Generated at 2022-06-23 21:11:41.173319
# Unit test for constructor of class Choice
def test_Choice():
    print("\n\nChoice:")
    ch = Choice()
    print(ch.__doc__)
    print(ch(['a','b','c']))
    print(ch(['a','b','c'],1))
    print(ch('abc',2))
    print(ch(('a','b','c'),5))
    print(ch('aabbbccccddddd',4,True))

if __name__ == "__main__":
    test_Choice()

# Generated at 2022-06-23 21:11:51.965534
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ab', 'ac', 'bc']

# Generated at 2022-06-23 21:11:59.136592
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    #pylint: disable=import-outside-toplevel
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    choice = Choice()

    name = choice(items=(Person.MALE, Person.FEMALE))
    assert name in (Person.MALE, Person.FEMALE)
    assert isinstance(name, str)

    names = choice(items=(Person.MALE, Person.FEMALE), length=3)
    assert len(names) == 3
    assert not isinstance(names, str)
    for name in names:
        assert name in Person.MALE
        assert name in Person.FEMALE
        assert isinstance(name, str)


# Generated at 2022-06-23 21:12:03.512062
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert isinstance(choice(items='abc', length=10, unique=True), str)
    assert isinstance(choice(items=('a', 'b', 'c'), length=10, unique=True), tuple)
    assert isinstance(choice(items=['a', 'b', 'c'], length=10, unique=True), list)
    assert isinstance(choice(['a', 'b', 'c']), str)
    assert isinstance(choice(('a', 'b', 'c')), str)
    assert isinstance(choice(['a', 'b', 'c'], length=10), list)
    assert isinstance(choice(('a', 'b', 'c'), length=10), tuple)

# Generated at 2022-06-23 21:12:06.826172
# Unit test for constructor of class Choice
def test_Choice():
    items=['a', 'b', 'c']
    data = Choice()
    assert data.choice(items=['a', 'b', 'c'])== 'c'

# Generated at 2022-06-23 21:12:08.185599
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    choice('abcdefgh', length=5, unique=True)

# Generated at 2022-06-23 21:12:18.067923
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for `Choice.__call__()`."""
    # TODO: Add tests for strings
    choice = Choice()
    assert isinstance(choice(items=['a', 'b', 'c']), str)
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert isinstance(choice(items=('a', 'b', 'c'), length=5), tuple)
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:12:20.578776
# Unit test for constructor of class Choice
def test_Choice():
    """Test constructor of class Choice."""
    assert Choice() is not None
    # TODO: Improve unit testing

# Generated at 2022-06-23 21:12:22.086066
# Unit test for constructor of class Choice
def test_Choice():
    """Test class."""
    choice = Choice()
    assert choice

# Generated at 2022-06-23 21:12:23.239331
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass


# Generated at 2022-06-23 21:12:33.130765
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    _ = choice(items=['a', 'b', 'c'], length=1.2)
    _ = choice(items=['a', 'b', 'c'], length=-20)
    _ = choice(items=1, length=1)

# Generated at 2022-06-23 21:12:38.256206
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert isinstance(choice(['a', 'b', 'c']), str)
    assert isinstance(choice(['a', 'b', 'c'], length=1), list)
    assert isinstance(choice('abc', length=2), str)
    assert isinstance(choice(('a', 'b', 'c'), length=5), tuple)
    assert isinstance(choice('aabbbccccddddd', length=4, unique=True), str)

# Generated at 2022-06-23 21:12:40.568434
# Unit test for constructor of class Choice
def test_Choice():
    """Unit test for Choice class."""
    # Choice()
    c1 = Choice()
    assert c1 is not None
    assert c1.random is not None
    assert isinstance(c1.random, list)


# Generated at 2022-06-23 21:12:43.167895
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    text = 'abc'
    res = choice(text)
    assert isinstance(res, str)


# Generated at 2022-06-23 21:12:51.068029
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    provider = Choice()
    choice = provider(items=['a', 'b', 'c'])
    assert choice == 'c'
    choice = provider(items=['a', 'b', 'c'], length=1)
    assert choice == ['a']
    choice = provider(items='abc', length=2)
    assert choice == 'ba'
    choice = provider(items=('a', 'b', 'c'), length=5)
    assert choice == ('c', 'a', 'a', 'b', 'c')
    choice = provider(items='aabbbccccddddd', length=4, unique=True)
    assert choice == 'cdba'

# Generated at 2022-06-23 21:12:51.808564
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice("a") == 'a'


# Generated at 2022-06-23 21:12:56.259112
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice(lang='en')
    print(choice(items=['a', 'b', 'c']))
    print(choice(items=['a', 'b', 'c'], length=1))
    print(choice(items='abc', length=2))
    print(choice(items=('a', 'b', 'c'), length=5))
    print(choice(items='aabbbccccddddd', length=4, unique=True))


# Generated at 2022-06-23 21:13:00.921836
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'



# Generated at 2022-06-23 21:13:08.880206
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method __call__ of class Choice."""
    from mimesis.providers.text import Text

    t = Choice(Text())
    result1 = t(items=['a', 'b', 'c'])
    result2 = t(items=['a', 'b', 'c'], length=1)
    result3 = t(items='abc', length=2)
    result4 = t(items=('a', 'b', 'c'), length=5)
    result5 = t(items='aabbbccccddddd', length=4, unique=True)

    assert len(result1) == 1
    assert result1 in ['a', 'b', 'c']
    assert result2 == ['a']
    assert isinstance(result3, str)
    assert len(result3) == 2
    assert result4

# Generated at 2022-06-23 21:13:10.848157
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice('en')
    assert isinstance(choice, BaseProvider) is True

# Generated at 2022-06-23 21:13:13.440524
# Unit test for constructor of class Choice
def test_Choice():
    obj = Choice()
    assert repr(obj) == '<Choice>'
    assert str(obj) == 'Choice'
    assert isinstance(obj, Choice)


# Generated at 2022-06-23 21:13:20.916020
# Unit test for constructor of class Choice
def test_Choice():
    choice1 = Choice()
    choice2 = Choice(seed="2")

    assert choice1.choice(items=['a', 'b', 'c']) == choice2.choice(items=['a', 'b', 'c'])
    assert choice1.choice(items=['a', 'b', 'c'], length=1) == choice2.choice(items=['a', 'b', 'c'], length=1)
    assert choice1.choice(items='abc', length=2) == choice2.choice(items='abc', length=2)
    assert choice1.choice(items=('a', 'b', 'c'), length=5) == choice2.choice(items=('a', 'b', 'c'), length=5)

# Generated at 2022-06-23 21:13:31.041577
# Unit test for constructor of class Choice
def test_Choice():
    """Test for Choice constructor."""
    # RandomSeq(items=['a', 'b', 'c'])
    choice = Choice()
    items = ['a', 'b', 'c']
    assert choice(items) in items
    assert isinstance(choice(items), str)
    # RandomSeq(items=['a', 'b', 'c'], length=1)
    assert len(choice(items, length=1)) == 1
    assert isinstance(choice(items, length=1), list)
    # RandomSeq(items='abc', length=2)
    assert len(choice(items, length=2)) == 2
    assert isinstance(choice(items, length=2), str)
    # RandomSeq(items=('a', 'b', 'c'), length=5)

# Generated at 2022-06-23 21:13:40.161435
# Unit test for constructor of class Choice
def test_Choice():
    # :raises TypeError: For non-sequence items or non-integer length.
    # :raises ValueError: If negative length or insufficient unique elements.
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:13:41.440060
# Unit test for constructor of class Choice
def test_Choice():
    """Unit test for constructor of class Choice."""
    choice = Choice()


# Generated at 2022-06-23 21:13:50.901151
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.data import (
        CHOICE_NOUNS,
        CHOICE_VERBS,
        CHOICE_SAD_SMILEYS,
        CHOICE_SURPRISED_SMILEYS,
        CHOICE_VERY_SAD_SMILEYS,
    )

    choice = Choice(seed=12345)
    assert choice(items=CHOICE_NOUNS, length=1) == ['국수']
    assert choice(items=CHOICE_VERBS, length=2) == ['활동하고', '활동']
    assert choice(items=CHOICE_SAD_SMILEYS, length=3) == ['😔', '😮', '😧']

# Generated at 2022-06-23 21:13:54.163843
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis import Choice
    choice = Choice()
    assert choice.random.choice([1,3,4,5]) == 4
    assert choice.random.choice([2]) == 2
    assert choice.random.choice([3]) is not 2
    assert choice.random.choice([3]) is not None



# Generated at 2022-06-23 21:13:59.260326
# Unit test for constructor of class Choice
def test_Choice():
    class _Meta:
        name = 'choice'
    class _Choice:
        def __init__(self, *args):
            self.args = args
        def __call__(self, *args):
            return 'b'
    _choice = Choice(*_Choice.args, **{'_Meta': _Meta, '_Choice': _Choice})
    assert _choice('a', 'b', 'c') == 'b'

# Unit tests for __call__ method


# Generated at 2022-06-23 21:14:09.166663
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    provider = Choice()
    result = provider(items=['a', 'b', 'c'], length=0)
    assert result in ['a', 'b', 'c']
    result = provider(items=['a', 'b', 'c'], length=1)
    assert isinstance(result, list)
    assert result in [['a'], ['b'], ['c']]
    result = provider(items=['a', 'b', 'c'], length=3)
    assert isinstance(result, list)
    assert result in [['a', 'b', 'c'], ['a', 'c', 'b'], ['b', 'a', 'c'],
                      ['b', 'c', 'a'], ['c', 'a', 'b'], ['c', 'b', 'a']]

# Generated at 2022-06-23 21:14:17.359308
# Unit test for method __call__ of class Choice
def test_Choice___call__():  # noqa: D103
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) in ['ba', 'ab', 'ac']
    assert len(choice(items=('a', 'b', 'c'), length=5)) == 5
    assert len(choice(items='aabbbccccddddd', length=4, unique=True)) == 4

# Generated at 2022-06-23 21:14:27.749964
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for function Choice.__call__."""
    choice = Choice()
    items = ('a', 'b', 'c')
    length = 5
    unique = True
    assert isinstance(choice(items=items, length=length, unique=unique), str)
    assert len(choice(items=items, length=length, unique=unique)) == 5
    assert choice(items=items, length=length, unique=unique) != 'aaabb'
    assert choice(items=items, length=length, unique=unique) != 'aaaab'
    assert choice(items=items, length=length, unique=unique) != 'bbbaa'
    assert choice(items=items, length=length, unique=unique) != 'bbabb'
    assert choice(items=items, length=length, unique=unique) != 'bbaba'
    assert choice

# Generated at 2022-06-23 21:14:35.638279
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    item = choice('a','b','c')
    item1 = choice('a','b','c', length=1)
    item2 = choice('a','b','c', length=2)
    item3 = choice('a','b','c', length=5)
    item4 = choice('aabbbccccddddd', length=4, unique=True)
    print(item)
    print(item1)
    print(item2)
    print(item3)
    print(item4)

if __name__ == '__main__':
    test_Choice()

# Generated at 2022-06-23 21:14:43.508477
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import mimesis
    choice = mimesis.Choice()
    assert "a" in choice(["a", "b", "c"])
    assert ["a"] == choice(["a", "b", "c"], length=1)
    assert "ba" == choice("abc", length=2)
    assert ("c", "a", "a", "b", "c") == choice(("a", "b", "c"), length=5)
    assert "cdba" == choice("aabbbccccddddd", length=4, unique=True)

# Generated at 2022-06-23 21:14:44.316569
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-23 21:14:46.400877
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import doctest
    doctest.testmod(globs=globals(), verbose=False)

# Generated at 2022-06-23 21:14:53.114773
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items = ['a', 'b', 'c']) == 'c'
    assert choice(items = ['a', 'b', 'c'], length = 1) == ['a']
    assert choice(items = 'abc', length = 2) == 'ba'
    assert choice(items = ('a', 'b', 'c'), length = 5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items = 'aabbbccccddddd', length = 4, unique = True) == 'cdba'

# Generated at 2022-06-23 21:14:59.385760
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'



# Generated at 2022-06-23 21:15:08.761733
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    assert Choice().__call__(items) in items
    assert Choice().__call__(items, 0) in items
    assert isinstance(Choice().__call__(items, 0), str)
    assert Choice().__call__(items, 1) in ['a', 'b', 'c']
    assert isinstance(Choice().__call__(items, 1), list)
    assert len(Choice().__call__(items, 3)) == 3
    assert len(Choice().__call__(items, 3, True)) == 3

# Generated at 2022-06-23 21:15:16.648630
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:15:25.954452
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test Choice.__call__ method."""
    choice = Choice()
    # 1. items = ['a', 'b', 'c'], length = 0
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    # 2. items = ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    # 3. items = 'abc', length = 2
    assert choice(items='abc', length=2) in ['aa', 'bb', 'cc', 'ab', 'bc', 'ca']
    # 4. items = ('a', 'b', 'c'), length = 5

# Generated at 2022-06-23 21:15:35.788466
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method __call__ of class Choice."""
    def test(items: List, length: int = 0, unique: bool = False) -> List:
        """Test items."""
        return Choice().__call__(items, length, unique)

    assert test(['a', 'b', 'c']) in ['a', 'b', 'c']
    assert test(['a', 'b', 'c'], length=1) == ['a']
    assert test('abc', length=2) in ['ba', 'ab', 'cb']

# Generated at 2022-06-23 21:15:36.861368
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TODO: write unit test
    pass

# Generated at 2022-06-23 21:15:44.218435
# Unit test for constructor of class Choice
def test_Choice():
    print('Test Choice constructor.')
    choice = Choice()
    print(choice(items=['a', 'b', 'c']))
    print(choice(items=['a', 'b', 'c'], length=1))
    print(choice(items='abc', length=2))
    print(choice(items=('a', 'b', 'c'), length=5))
    print(choice(items='aabbbccccddddd', length=4, unique=True))

# Test function for class Choice

# Generated at 2022-06-23 21:15:51.194605
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    ret = c(items=['a', 'b', 'c'])
    assert ret == 'c'

    ret = c(items=['a', 'b', 'c'], length=1)
    assert ret == ['a']

    ret = c(items='abc', length=2)
    assert ret == 'ba'

    ret = c(items=('a', 'b', 'c'), length=5)
    assert ret == ('c', 'a', 'a', 'b', 'c')

    ret = c(items='aabbbccccddddd', length=4, unique=True)
    assert ret == 'cdba'

# Generated at 2022-06-23 21:15:52.850360
# Unit test for constructor of class Choice
def test_Choice():
    # in this case we dont need to check for args and kwargs
    # we can just create a Choice object
    _ = Choice()


# Generated at 2022-06-23 21:15:57.284478
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice,Choice)
    assert isinstance(choice.random,random.Random)
    a = choice(items=['abc', 'bcd', 'cde'])
    assert a in ['abc', 'bcd', 'cde']

# Generated at 2022-06-23 21:16:01.927612
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    seq = ['a','b','c']
    assert Choice().__call__(seq) in seq
    assert len(Choice().__call__(seq, 3)) == 3
    assert len(Choice().__call__(seq, 3, True)) == 3
    assert len(Choice().__call__(seq, 5, True)) == 5


if __name__ == '__main__':
    test_Choice___call__()

# Generated at 2022-06-23 21:16:12.263315
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    _choice = Choice()
    _items = ('a', 'b', 'c')
    seq = _choice(_items)
    assert seq in _items
    assert isinstance(seq, str)

    _items = ['a', 'b', 'c']
    seq = _choice(_items)
    assert seq in _items
    assert isinstance(seq, str)

    _items = ('a', 'b', 'c')
    seq = _choice(_items, length=1)
    assert seq in _items
    assert isinstance(seq, list)

    _items = tuple('abcdefghijk')
    seq = _choice(_items, length=3)
    assert seq in _items
    assert isinstance(seq, tuple)

    _items = 'abc'

# Generated at 2022-06-23 21:16:12.984009
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice is not None


# Generated at 2022-06-23 21:16:20.686102
# Unit test for constructor of class Choice
def test_Choice():
    a = Choice()
    assert a(items=[1,2,3]) in [1,2,3]
    assert a(items=[1,2,3],length=1) in [[1],[2],[3]]
    assert a(items="abc",length=2) in ["ab","bc","ca"]
    assert a(items=(1,2,3),length=5) in [(1,2,3,1,2),(1,2,3,1,3),(1,2,3,2,3)]
    assert a(items='aabbbccccddddd', length=4, unique=True) in ["abcd","adbc"]

# Generated at 2022-06-23 21:16:30.565468
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Test type error
    try:
        __ = Choice().__call__('text', 0.1)
        assert False
    except TypeError:
        assert True

    # Test type error
    try:
        __ = Choice().__call__(0.1, 1)
        assert False
    except TypeError:
        assert True

    # Test value error
    try:
        __ = Choice().__call__('text', -1)
        assert False
    except ValueError:
        assert True

    # Test value error
    try:
        __ = Choice().__call__('text', 1, unique=True)
        assert False
    except ValueError:
        assert True

    # Tests
    assert isinstance(Choice().__call__(['text']), str)
    assert isinstance(Choice().__call__('text'), str)


# Generated at 2022-06-23 21:16:38.465910
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method __call__ of class Choice"""
    c = Choice()
    assert isinstance(c.__call__(items=['a', 'b', 'c']), str)
    assert c.__call__(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert isinstance(c.__call__(items=['a', 'b', 'c'], length=1), list)
    assert c.__call__(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert isinstance(c.__call__(items='abc', length=2), str)

# Generated at 2022-06-23 21:16:44.953280
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ab', 'bc', 'ac']

# Generated at 2022-06-23 21:16:54.795626
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method ``__call__`` of class Choice."""
    from mimesis import Choice
    choice = Choice()

    # Assert an error is raised if the items argument is not a sequence
    try:
        choice(items=5)
    except TypeError:
        pass
    else:
        raise AssertionError('Expected TypeError to be raised.')

    # Assert an error is raised if the items argument for a negative length
    try:
        choice(items='abc', length=-2)
    except ValueError:
        pass
    else:
        raise AssertionError('Expected ValueError to be raised.')

    # Assert an error is raised if an empty sequence is provided
    try:
        choice(items=[])
    except ValueError:
        pass

# Generated at 2022-06-23 21:17:00.096332
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    x = Choice()
    assert x(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert x(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert x(items='abc', length=2) in ['ba', 'ac', 'cb']
    assert len(x(items='aabbbccccddddd', length=4, unique=True)) == 4


# Generated at 2022-06-23 21:17:01.420724
# Unit test for constructor of class Choice
def test_Choice():
    item = Choice()
    assert isinstance(item, Choice)


# Generated at 2022-06-23 21:17:07.662195
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    v = choice(items=['a', 'b', 'c'])
    print(v)
    assert v == 'c'

    v = choice(items=['a', 'b', 'c'], length=1)
    print(v)
    assert v == ['a']

    v = choice(items='abc', length=2)
    print(v)
    assert v == 'ba'

    v = choice(items=('a', 'b', 'c'), length=5)
    print(v)
    assert v == ('c', 'a', 'a', 'b', 'c')

    v = choice(items='aabbbccccddddd', length=4, unique=True)
    print(v)
    assert v == 'cdba'



# Generated at 2022-06-23 21:17:18.532672
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# class Choice(BaseProvider):
#     _provider_name = 'choice'
#
#     def __init__(self, *args, **kwargs):
#         super().__init__(*args, **kwargs)
#


# Generated at 2022-06-23 21:17:28.990838
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(1) == 1
    assert choice([1, 2, 3]) == 3
    assert choice([1, 2, 3], 2) == 2
    assert choice([1, 2, 3], 2, False) == 3
    assert choice([1, 2, 3], 2, True) == 1
    assert choice((1, 2, 3), 4) == (1, 2, 1, 2)
    assert choice((1, 2, 3), 4, False) == (1, 2, 3, 1)
    assert choice((1, 2, 3), 4, True) == (2, 3, 1, 3)
    assert choice('abc') == 'a'
    assert choice('abc', 1) == 'c'
    assert choice('abc', 2) == 'cb'

# Generated at 2022-06-23 21:17:37.173240
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-23 21:17:40.196349
# Unit test for constructor of class Choice
def test_Choice():
    # Init a fake Choice object
    choice = Choice()
    # Get some data
    data = choice('abc', length=1)
    # Check if data is correct
    assert data == ['a']

# Generated at 2022-06-23 21:17:41.574856
# Unit test for constructor of class Choice
def test_Choice():
    choice_instance = Choice(None, None)
    assert choice_instance is not None

# Generated at 2022-06-23 21:17:49.330237
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method __call__ of class Choice.

    Ensure that method __call__ of class Choice returns an expected result
    when given a sequence of items and a length to generate a sequence of
    random items.
    """
    sequence = ['a', 'b', 'c', 'd']
    length = 4
    choice = Choice()
    result = choice(items=sequence, length=length)
    result_is_sequence = isinstance(result, collections.abc.Sequence)
    assert result_is_sequence
    assert len(result) == length
    if result_is_sequence:
        assert all(x in sequence for x in result)
        
### END ###

# Generated at 2022-06-23 21:17:54.388262
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items='aabbbccccddddd', length=4,
                             unique=True) == 'cdba'

# Generated at 2022-06-23 21:18:02.085604
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice()(['a', 'b', 'c'], length=0, unique=False) == 'c'
    assert Choice()(['a', 'b', 'c'], length=1, unique=False) == ['a']
    assert Choice()('abc', length=2, unique=False) == 'ba'
    assert Choice()(('a', 'b', 'c'), length=5, unique=False) == ('c', 'a', 'a', 'b', 'c')
    assert Choice()('aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:18:04.959448
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import doctest
    doctest.testmod(verbose=True, optionflags=doctest.NORMALIZE_WHITESPACE)


# Generated at 2022-06-23 21:18:14.528893
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    from mimesis import Choice
    choice1 = Choice()
    choice2 = Choice()
    assert choice1.choice() in choice1.choice.__call__(items=['a', 'b', 'c'])
    assert choice2.choice(length=1) in choice2.choice.__call__(items=['a', 'b', 'c'], length=1)
    assert choice1.choice(length=2) in choice1.choice.__call__(items='abc', length=2)
    assert choice2.choice(length=5) in choice2.choice.__call__(items=('a', 'b', 'c'), length=5)

# Generated at 2022-06-23 21:18:16.085135
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice('en')
    assert True


# Generated at 2022-06-23 21:18:17.218262
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice is not None

# Generated at 2022-06-23 21:18:26.554361
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-23 21:18:27.169668
# Unit test for constructor of class Choice
def test_Choice():
    pass

# Generated at 2022-06-23 21:18:34.302685
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    res = c(items=['a', 'b', 'c'])
    assert res
    res = c(items=['a', 'b', 'c'], length=1)
    assert res
    res = c(items='abc', length=2)
    assert res
    res = c(items=('a', 'b', 'c'), length=5)
    assert res
    res = c(items='aabbbccccddddd', length=4, unique=True)
    assert res

# Generated at 2022-06-23 21:18:38.451234
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit Test of Choice.__call__"""
    from mimesis.exceptions import ChoiceException
    from mimesis.builtins import Choice

    choice = Choice()
    assert(choice.__call__(1) == 1)
    assert(choice.__call__([1, 2, 3]) in [1, 2, 3])


# Generated at 2022-06-23 21:18:40.519816
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis import Choice
    choice = Choice()
    assert choice('abc') in ['a', 'b', 'c']


# Generated at 2022-06-23 21:18:47.628212
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    assert choice(items=['a', 'b', 'c'], length=1, unique=True) == ['c']

# Generated at 2022-06-23 21:18:49.865723
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis import Choice

    choice = Choice()
    assert choice is not None


# Generated at 2022-06-23 21:18:52.091167
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import doctest
    doctest.testmod(extraglobs={'choice': Choice()})

# Generated at 2022-06-23 21:18:54.890358
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis import Choice
    choice = Choice()
    assert isinstance(choice, Choice)
    assert callable(choice)
    assert isinstance(choice.random, type(choice.random))

# Generated at 2022-06-23 21:18:56.657761
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis import Choice
    provider = Choice()
    assert provider.__call__(items=['a', 'b', 'c'], length=1)

# Generated at 2022-06-23 21:18:59.678304
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert isinstance(c, Choice)