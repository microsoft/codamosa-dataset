

# Generated at 2022-06-23 21:09:03.608369
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Define the items
    items = ['a', 'b', 'c']

    # Define the length
    length = 1

    # Define the unique
    unique = True

    # Define the expectation
    expectation = ['a']

    # Define the class
    c = Choice()

    # Make the assertion
    assert c(items, length, unique) == expectation


# Generated at 2022-06-23 21:09:11.155063
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice(items=['a', 'b', 'c'])
    assert choice(items=['a', 'b', 'c'], length=1)
    assert choice(items='abc', length=2)
    assert choice(items=('a', 'b', 'c'), length=5)
    assert choice(items='aabbbccccddddd', length=4, unique=True)
    try:
        assert choice(items=[1, 2, 3], length=5, unique=True)
    except Exception as e:
        assert isinstance(e, TypeError)

    try:
        assert choice(items=None, length=2, unique=True)
    except Exception as e:
        assert isinstance(e, TypeError)


# Generated at 2022-06-23 21:09:13.881791
# Unit test for constructor of class Choice
def test_Choice():
    """Testing the constructor of the class Choice."""
    choice = Choice()
    assert choice is not None


# Generated at 2022-06-23 21:09:19.819854
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()

    test_items = ['a', 'b', 'c']
    test_length = 2
    test_unique = False

    result = choice(items=test_items, length=test_length, unique=test_unique)
    assert isinstance(result, list)
    assert len(result) == test_length
    assert len([x for x in result if x not in test_items]) == 0

# Generated at 2022-06-23 21:09:25.883680
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Given:
    # Create instance of Choice
    choice = Choice()

    # When:
    # Call method Choice.__call__
    result = choice(items=['a', 'b', 'c'],
                    length=5, 
                    unique=False)

    # Then:
    # Check type of result
    assert isinstance(result, list)
    # Check result
    assert result  == ['a', 'b', 'c', 'c', 'b']

# Generated at 2022-06-23 21:09:29.637811
# Unit test for constructor of class Choice
def test_Choice():
    # test for Constructor of Class Choice
    # TODO:
    print("---Testing class constructor---")
    c = Choice()
    print(type(c))
    
    

# Generated at 2022-06-23 21:09:31.028507
# Unit test for constructor of class Choice
def test_Choice():
    super()._test_provider(Choice)


# Generated at 2022-06-23 21:09:33.848670
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)
    assert callable(choice)
    assert hasattr(choice, 'random')


# Generated at 2022-06-23 21:09:35.437008
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)

# Generated at 2022-06-23 21:09:37.101270
# Unit test for constructor of class Choice
def test_Choice():
    c=Choice()
    res=c.__init__()
    assert res is None


# Generated at 2022-06-23 21:09:43.243820
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    '''
    >>> from mimesis import Choice
    >>> choice = Choice()

    >>> choice(items=['a', 'b', 'c'])
    'c'
    >>> choice(items=['a', 'b', 'c'], length=1)
    ['a']
    >>> choice(items='abc', length=2)
    'ba'
    >>> choice(items=('a', 'b', 'c'), length=5)
    ('c', 'a', 'a', 'b', 'c')
    >>> choice(items='aabbbccccddddd', length=4, unique=True)
    'cdba'
    '''

# Generated at 2022-06-23 21:09:45.649471
# Unit test for constructor of class Choice
def test_Choice():
    assert \
    Choice().__init__(None) == Choice()
test_Choice()


# Generated at 2022-06-23 21:09:46.698018
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice() is not None

# Generated at 2022-06-23 21:09:53.990545
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-23 21:10:02.067894
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    provider = Choice()
    print(provider(items=['a', 'b', 'c'], length=0))  # ('a', 'b', 'c')
    print(provider(items=['a', 'b', 'c'], length=1))  # ['c']
    print(provider(items='abc', length=2))  # 'ba'
    print(provider(items=('a', 'b', 'c'), length=5))  # ('c', 'a', 'a', 'b', 'c')
    print(provider(items='aabbbccccddddd', length=4, unique=True))  # 'cdba'
    # TODO:
    # provider(items=[], length=0)  # ValueError
    # provider(items=[], length=1)  # ValueError
    #

# Generated at 2022-06-23 21:10:10.228611
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__([],5) == []
    assert Choice().__call__(['a', 'b', 'c']) == 'c'
    assert Choice().__call__(['a', 'b', 'c'], 1) == ['a']
    assert Choice().__call__('abc', 2) == 'ba'
    assert Choice().__call__(('a', 'b', 'c'), 5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__('aabbbccccddddd', 4, True) == 'cdba'

# Generated at 2022-06-23 21:10:19.943401
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit tests for method __call__ of class Choice.

    Arguments:
        items {Union[Sequence[Any], Any, None]} -- Sequence (list, tuple or string)
            of elements.
        length {int} -- Length of sequence (number of elements) to provide.
        unique {bool} -- If True, ensures provided elements are unique.
    """

    # Test for type error when items is not sequence
    with pytest.raises(TypeError) as exceptionInfo:
        choice = Choice()
        choice(items=123, length=2)

    assert (str(exceptionInfo.value) == '**items** must be non-empty sequence.')

    # Test for type error when length is not integer
    with pytest.raises(TypeError) as exceptionInfo:
        choice = Choice()

# Generated at 2022-06-23 21:10:29.037921
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method `__call__` of class `Choice`"""
    choice = Choice()
    assert isinstance(choice(items=[1, 2, '3', 4]), (str, float))
    assert isinstance(choice(items=[1, 2, 3], length=1), list)
    assert isinstance(choice(items=[1, 2, 3], length=1), list)
    assert isinstance(choice(items='123', length=2), str)
    assert isinstance(choice(items=(1, 2, 3), length=5), tuple)
    assert isinstance(choice(items='aabbbccccddddd', length=4, unique=True), str)

# Generated at 2022-06-23 21:10:31.011619
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = [3, 4, 5]
    length = 2
    assert Choice().__call__(items, length) != None

# Generated at 2022-06-23 21:10:33.835349
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis.providers.misc.choice import Choice
    provider = Choice()
    assert isinstance(provider, Choice)
    assert hasattr(provider, 'random')


# Generated at 2022-06-23 21:10:41.870696
# Unit test for constructor of class Choice
def test_Choice():

    choice = Choice(
        locales=["fi"]
    )
    # print(choice.random.choice(('Hello', 'World')))
    assert choice(['a','b','c']) in ['a','b','c']
    assert choice(['a','b','c'],unique=True) in ['a','b','c']
    assert choice(['a','b','c'],length=1) in [['a'],['b'],['c']]
    # unique flages means that there is only unique elements

    try:
        choice(['a','b','c'],unique=True,length=3)
    except ValueError as e:
        print("There are not enough unique elements in **items** to provide the specified **number**.")
        # assert type(e) == ValueError


# Generated at 2022-06-23 21:10:43.678704
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert c

# Unit tests for __call__ method of class Choice

# Generated at 2022-06-23 21:10:47.624325
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    print(c(['a', 'b', 'c']))
    print(c(['a', 'b', 'c'],length=1))
    print(c('abc',length=2))
    print(c(('a', 'b', 'c'),length=5))
    print(c('aabbbccccddddd',length=4, unique=True))


#test_Choice()

# Generated at 2022-06-23 21:10:48.975992
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert type(c) is Choice
    

# Generated at 2022-06-23 21:10:50.899183
# Unit test for constructor of class Choice
def test_Choice():
    data = Choice(seed=12345)
    assert data.__class__.__name__ == "Choice"


# Generated at 2022-06-23 21:10:53.819716
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 1
    unique = True
    ret = choice(items=items, length=length, unique=unique)
    assert ret in items

# Generated at 2022-06-23 21:10:58.202712
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis import Choice
    choice = Choice()
    assert choice(items=['a', 'b', 'c'])
    assert choice(items=['a', 'b', 'c'], length=1)
    assert choice(items='abc', length=2)
    assert choice(items=('a', 'b', 'c'), length=5)
    assert choice(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-23 21:10:59.695302
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    pass



# Generated at 2022-06-23 21:11:09.574531
# Unit test for constructor of class Choice
def test_Choice():
    if 'en' in Choice.localization_registry.keys():
        locales = ['en']
        for locale in locales:
            en_choice = Choice(locale=locale)
            assert en_choice.__class__.__name__ == 'Choice'
            assert en_choice.provider_name == 'choice'
            assert en_choice.locale == locale
            assert en_choice.seed is None
            assert en_choice.seed_value is None
            assert en_choice.random is not None
            assert en_choice.datetime is not None
            assert en_choice.timestamp is not None
            assert en_choice.order_by is None
            assert en_choice.special_locales is not None
            assert en_choice.localization is not None
            assert en_choice.provider_meta is not None

# Generated at 2022-06-23 21:11:12.265916
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'

# Generated at 2022-06-23 21:11:20.850209
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 1
    # result = choice(items=['a', 'b', 'c'], length=1)
    result = choice(items=items, length=length)

    assert result == ['a']
    assert type(result) == list
    assert len(result) == length

    result2 = choice(items=items)
    assert type(result2) == str
    assert result2 in items

    result3 = choice(items=items, length=2)
    assert len(result3) == 2
    assert type(result3) == list
    assert result3[0] in items
    assert result3[1] in items

    assert choice(items=items, length=length, unique=True) == ['a']

# Generated at 2022-06-23 21:11:22.704293
# Unit test for constructor of class Choice
def test_Choice():
    c1 = Choice()
    assert c1
    c2 = Choice()
    assert c1 == c2

# Generated at 2022-06-23 21:11:24.672553
# Unit test for constructor of class Choice
def test_Choice():
    # Constructor of class Choice
    choice = Choice()
    assert isinstance(choice, Choice)


# Generated at 2022-06-23 21:11:26.494238
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__([]) is None
    assert Choice().__call__(None) is None

# Generated at 2022-06-23 21:11:31.383950
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Test for __call__ method of class Choice
    choice = Choice()
    assert isinstance(choice(items=['a', 'b', 'c'], length=1), str)
    assert isinstance(choice(items=('a', 'b', 'c'), length=1), tuple)
    assert isinstance(choice(items='abc', length=1), str)

test_Choice___call__()

# Generated at 2022-06-23 21:11:32.583550
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)
    assert isinstance(choice.seed, int)
    assert choice.seed > 0


# Generated at 2022-06-23 21:11:35.415920
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert c.choice(items=['a','b','c'])

# Generated at 2022-06-23 21:11:43.103929
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    def test_Choice___call___1():
        _1 = Choice()
        _2 = _1(items=['a', 'b', 'c'], length=1, unique=False)
        assert _2 == 'a'
    def test_Choice___call___2():
        _1 = Choice()
        _2 = _1(items=['a', 'b', 'c'], length=1, unique=True)
        assert _2 == 'a'
    def test_Choice___call___3():
        _1 = Choice()
        _2 = _1(items=['a', 'b', 'c'], length=2, unique=False)
        assert _2 == 'ab'
    def test_Choice___call___4():
        _1 = Choice()

# Generated at 2022-06-23 21:11:49.842673
# Unit test for constructor of class Choice
def test_Choice():
    def test_normal_init():
        choice = Choice()
        assert choice.seed.__class__.__name__ == 'Generator'

    def test_with_seed():
        seed = '1234567890'
        choice = Choice(seed=seed)
        assert choice.seed.__class__.__name__ == 'Generator'
        assert choice.seed.rnd.__class__.__name__ == 'PCG64'


# Generated at 2022-06-23 21:11:56.489739
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    # Test: Call a `Choice` and extract a single element from a string.
    assert Choice().__call__("abc") in "abc"

    # Test: Call a `Choice` and extract a single element from a list.
    assert Choice().__call__(["a", "b", "c"]) in ["a", "b", "c"]

    # Test: Call a `Choice` and extract a single element from a tuple.
    assert Choice().__call__(("a", "b", "c")) in ("a", "b", "c")

    # Test: Call a `Choice` and extract a sequence of elements.
    assert "".join(Choice().__call__("abc", length=3)) == "abc"
    assert "".join(Choice().__call__(["a", "b", "c"], length=3)) == "abc"


# Generated at 2022-06-23 21:12:03.920968
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=[1, 2, 3], unique=False, length=1) == [2]
    assert Choice().__call__(items=[1, 2, 3], unique=True, length=1) == [1]
    assert Choice().__call__(items=(1, 2, 3), unique=False, length=1) == (1,)
    assert Choice().__call__(items=(1, 2, 3), unique=True, length=1) == (2,)
    assert Choice().__call__(items='abc', unique=False, length=1) == 'b'
    assert Choice().__call__(items='abc', unique=True, length=1) == 'c'



# Generated at 2022-06-23 21:12:05.747446
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TODO: implement test case
    raise NotImplementedError

# Generated at 2022-06-23 21:12:06.716968
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice

# Generated at 2022-06-23 21:12:08.522459
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice().random.choice(['a', 'b', 'c']) in ['a', 'b', 'c']

# Generated at 2022-06-23 21:12:09.663212
# Unit test for constructor of class Choice
def test_Choice():
    """ """
    choice = Choice()


# Generated at 2022-06-23 21:12:19.180588
# Unit test for constructor of class Choice
def test_Choice():
	from mimesis import Choice
	choice = Choice()
	print("choice(items=['a', 'b', 'c']) : ",choice(items=['a', 'b', 'c']))
	print("choice(items=['a', 'b', 'c'], length=1) : ",choice(items=['a', 'b', 'c'], length=1))
	print("choice(items='abc', length=2) : ",choice(items='abc', length=2))
	print("choice(items=('a', 'b', 'c'), length=5) : ",choice(items=('a', 'b', 'c'), length=5))

# Generated at 2022-06-23 21:12:29.853077
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    # Test with correct args
    assert isinstance(choice(items=['a', 'b', 'c']), str)
    assert isinstance(choice(items=['a', 'b', 'c'], length=1), list)
    assert isinstance(choice(items='abc', length=2), str)
    assert isinstance(choice(items=('a', 'b', 'c'), length=5), tuple)
    assert isinstance(choice(items='aabbbccccddddd', length=4, unique=True), str)

    # Test with incorrect args
    with pytest.raises(TypeError):
        choice(items=['a', 'b', 'c'], length='a')
    with pytest.raises(TypeError):
        choice(items=1, length=1)

# Generated at 2022-06-23 21:12:40.599282
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method __call__ of class Choice."""
    print("Random choice from items in a sequence.")

    choice = Choice()
    c = choice(items=['a', 'b', 'c'])
    assert isinstance(c, str) and c in "abc"
    c = choice(items=['a', 'b', 'c'], length=1)
    assert isinstance(c, list) and len(c) == 1 and c[0] in "abc"
    c = choice(items='abc', length=2)
    assert isinstance(c, str) and len(c) == 2
    c = choice(items=('a', 'b', 'c'), length=5)
    assert isinstance(c, tuple) and len(c) == 5

# Generated at 2022-06-23 21:12:50.917567
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    test_items = ['a', 'b', 'c']
    test_length = 1
    test_unique = True
    data = choice.__call__(items = test_items, length = test_length, unique = test_unique)
    assert isinstance(data, list)
    assert data in [ ['a'], ['b'], ['c'] ]
    test_items = ('a', 'b', 'c')
    test_length = 1
    test_unique = False
    data = choice.__call__(items = test_items, length = test_length, unique = test_unique)
    assert isinstance(data, tuple)
    assert data in [ ('a',), ('b',), ('c',) ]
    test_items = 'abc'
    test_length = 2
    test_unique = False

# Generated at 2022-06-23 21:12:53.253349
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    res = choice(items=['a', 'b', 'c'])
    assert res == 'c' or res == 'b' or res == 'a'



# Generated at 2022-06-23 21:13:00.635493
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import copy

    # Test with items = tuple and unique = False
    # Expected result: unique = False, items = tuple, length = 3
    # Actual result: ('c', 'a', 'a')
    choice = Choice()
    length = 3
    items = ('a', 'b', 'c')
    result = choice(items=items, length=length, unique=False)
    expected = ('c', 'a', 'a')
    assert result == expected

    # Test with items = tuple and unique = True
    # Expected result: unique = True, items = tuple, length = 3
    # Actual result: ('a', 'c', 'b')
    choice = Choice()
    length = 3
    items = ('a', 'b', 'c')
    result = choice(items=items, length=length, unique=True)
    expected

# Generated at 2022-06-23 21:13:08.751044
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.typing import Sequence

    c = Choice()
    choice_list_length_1 = c(items=['a', 'b', 'c'], length=1)
    assert type(choice_list_length_1) == list
    choice_list_length_2 = c(items=['a', 'b', 'c'], length=2)
    assert type(choice_list_length_2) == list
    choice_list_length_3 = c(items=['a', 'b', 'c'], length=3)
    assert type(choice_list_length_3) == list
    choice_list_length_4 = c(items=['a', 'b', 'c'], length=4)
    assert type(choice_list_length_4) == list

# Generated at 2022-06-23 21:13:11.989163
# Unit test for constructor of class Choice
def test_Choice():
    """Test for constructor of class Choice."""
    data = Choice()
    assert isinstance(data, Choice) is True
    assert isinstance(data, BaseProvider) is True


# Generated at 2022-06-23 21:13:13.553063
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice('abc', length=2, unique=True) == 'cb'


# Generated at 2022-06-23 21:13:16.459445
# Unit test for constructor of class Choice
def test_Choice():
    from custom_mimesis.choice import Choice
    choice = Choice()
    assert choice._meta.name == 'choice', 'Name of class must be "choice"'

# Generated at 2022-06-23 21:13:23.333858
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from hypothesis import given
    from hypothesis.strategies import integers, lists, text

    items = lists(elements=text(), min_size=1, max_size=20)
    length = integers(min_value=1, max_value=100)
    choice = Choice()

    @given(items=items, length=length)
    def test_random_choice(items: list, length: int) -> None:
        random_choice = choice(items=items, length=length, unique=False)
        assert random_choice in items, 'Random choice should be in **items**.'

    @given(items=items, length=length)
    def test_unique_random_choice(items: list, length: int) -> None:
        random_choice = choice(items=items, length=length, unique=True)

# Generated at 2022-06-23 21:13:25.910361
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    data = c(items=['a', 'b', 'c'])
    assert data == 'c'


# Generated at 2022-06-23 21:13:27.131911
# Unit test for constructor of class Choice
def test_Choice():
    # TODO: test superclass constructor
    pass


# Generated at 2022-06-23 21:13:30.749765
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice.__class__.__name__ == 'Choice'
    assert isinstance(choice, Choice)
    assert isinstance(choice, BaseProvider)


# Generated at 2022-06-23 21:13:39.934554
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # type: () -> None
    """Generate a randomly-chosen sequence or bare element from a sequence."""
    from mimesis.data import GENRES
    from mimesis.enums import Gender
    from mimesis.exceptions import NonEnumerableError
    from mimesis.providers.person import Person
    from mimesis.typing import List

    p = Person('en')
    items = GENRES[Gender.FEMALE]
    choice = Choice(p.seed)

    # Test for successful outcome

    # Test where a single element is chosen from a sequence

    # When there is a single element in items being chosen from, the choice is
    # always the unique element of that sequence.
    element = choice(items=[1])
    assert element == 1

    # When there are only two elements in items being chosen from and their


# Generated at 2022-06-23 21:13:44.404631
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    result = choice(items=['a','b','c','d','e','f'], length=9, unique=False)
    print(result)

    unique_choice = Choice().unique.choice(items=['a', 'b', 'c'], length=3)
    print(unique_choice)

# test_Choice()

# Generated at 2022-06-23 21:13:45.815889
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice,Choice)


# Generated at 2022-06-23 21:13:47.546393
# Unit test for constructor of class Choice
def test_Choice():
    """Test constructor.

    :return: None.
    """
    choice = Choice()
    assert choice


# Generated at 2022-06-23 21:13:51.185942
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    choice('abc')
    choice('abc', length=1)
    choice('abc', length=2)
    choice(('a', 'b', 'c'), length=5)
    choice('aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-23 21:13:58.721558
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    choice = Choice()
    # ['a']
    print(choice(items, length, unique))
    items = 'abc'
    length = 2
    unique = False
    # 'ba'
    print(choice(items, length, unique))
    items = ('a', 'b', 'c')
    length = 5
    unique = False
    # ('c', 'a', 'a', 'b', 'c')
    print(choice(items, length, unique))
    items = 'aabbbccccddddd'
    length = 4
    unique = True
    # 'cdba'
    print(choice(items, length, unique))

# Generated at 2022-06-23 21:14:02.551760
# Unit test for constructor of class Choice
def test_Choice():

    choice = Choice()

    assert choice.__class__.__name__ == 'Choice'
    assert choice.__doc__ == 'Class for generating a random choice from ' \
        'items in a sequence.'
    assert choice.Meta.__class__.__name__ == 'type'
    assert choice.Meta.name == 'choice'

    return None


# Generated at 2022-06-23 21:14:04.327277
# Unit test for constructor of class Choice
def test_Choice():
    obj = Choice()
    assert isinstance(obj, Choice)


# Generated at 2022-06-23 21:14:11.032766
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    print("test Choice.__call__")
    # TODO: Test with other sequences: set, etc.
    test_items_list = ['a', 'b', 'c']
    test_items_string = 'abc'
    test_items_tuple = ('a', 'b', 'c')
    test_lengths = [0, 1, 2, 5, 10]
    test_unique = [False, True]
    test_choice = Choice()


# Generated at 2022-06-23 21:14:18.722344
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:14:21.735001
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert c.random.choice('abcdefg') in 'abcdefg'

# Generated at 2022-06-23 21:14:26.928673
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test to check the function Choice.__call__"""
    choice = Choice()
    choice(items=['a', 'b', 'c'])
    choice(items=['a', 'b', 'c'], length=1)
    choice(items='abc', length=2)
    choice(items=('a', 'b', 'c'), length=5)
    choice(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-23 21:14:35.207322
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    class_ = Choice(seed=12345)
    assert class_()
    assert class_(items=['a', 'b', 'c']) == 'c'
    assert class_(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert class_(items=['a', 'b', 'c'], length=1) == ['a']
    assert class_(items='abc', length=2) == 'ba'
    assert class_(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:14:36.824056
# Unit test for constructor of class Choice
def test_Choice():
    """Test constructor of class Choice."""
    pass

# Generated at 2022-06-23 21:14:46.430397
# Unit test for constructor of class Choice
def test_Choice():
    from unittest import TestCase
    from mimesis.providers.choice import Choice
    from mimesis.enums import DataField
    from mimesis.types import Seed

    class TestChoice(TestCase):

        def setUp(self) -> None:
            self.data = Choice()

        def test__init__(self) -> None:
            result = Choice('xx')
            self.assertEqual(result, Choice('xx'))

            seed = Seed.create_from_data(
                seed_data=DataField.SEED,
                seed=DataField.SEED
            )
            result = Choice(seed_data=seed)
            self.assertEqual(result, Choice(seed_data=seed))


# Generated at 2022-06-23 21:14:48.170400
# Unit test for constructor of class Choice
def test_Choice():
    # TODO: What is the point of this test?
    assert Choice().choice('abcdef') in 'abcdef'


# Generated at 2022-06-23 21:14:48.670693
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-23 21:14:54.913242
# Unit test for constructor of class Choice
def test_Choice():
    __pragma__('skip')
    ch = Choice()
    ch(items=['a', 'b', 'c'])
    ch(items=['a', 'b', 'c'], length=1)
    ch(items='abc', length=2)
    ch(items=('a', 'b', 'c'), length=5)
    ch(items='aabbbccccddddd', length=4, unique=True)
    __pragma__('noskip')

# Generated at 2022-06-23 21:14:56.992476
# Unit test for constructor of class Choice
def test_Choice():
    c=Choice()
    res=c.__call__(items=[1,2,3])
    if (res==1 or res==2 or res==3):
        assert 1
    else:
        assert 0

# Generated at 2022-06-23 21:15:02.760080
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Test unique random choosing from items
    from random import choice
    from mimesis import Choice
    choice = Choice()
    items = list(range(10))
    value = choice(items=items, length=6, unique=True)
    assert len(set(value)) == len(value)

    # Test random choosing from items
    items = list(range(10))
    value = choice(items=items, length=6, unique=False)
    assert len(set(value)) >= len(value)

    # Test random choosing from empty sequence
    try:
        choice(items=[],length=6)
    except ValueError:
        pass
    else:
        raise AssertionError('Please check the algorithm for choosing items from empty sequence')

    # Test choosing items from non-sequence

# Generated at 2022-06-23 21:15:03.301192
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-23 21:15:11.099878
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    try:
        choice(items=['a', 'b', 'c'], length='a')
    except TypeError as e:
        assert str(e) == '**length** must be integer.'

# Generated at 2022-06-23 21:15:11.932986
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-23 21:15:16.723361
# Unit test for constructor of class Choice
def test_Choice():
    """Test constructor of class Choice.
    """
    choice = Choice()
    choice(items=['a', 'b', 'c'])
    choice(items=['a', 'b', 'c'], length=1)
    choice(items='abc', length=2)
    choice(items=('a', 'b', 'c'), length=5)
    choice(items='aabbbccccddddd', length=4, unique=True)
    try:
        choice(items=['a', 'b', 'c'], length='a')
    except TypeError:
        pass
    try:
        choice(items=object(), length=1)
    except TypeError:
        pass
    try:
        choice(items=['a', 'b', 'c'], length=-1)
    except ValueError:
        pass


# Generated at 2022-06-23 21:15:25.953770
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import pytest
    from mimesis.enums import Type

    choice = Choice()
    items = [1, 2, 3]
    length = 5
    unique = True
    with pytest.raises(TypeError):
        choice(items=items, length='1', unique=unique)
    with pytest.raises(TypeError):
        choice(items=0, length=length, unique=unique)
    with pytest.raises(ValueError):
        choice(items=items, length=-1, unique=unique)
    with pytest.raises(ValueError):
        choice(items=[], length=length, unique=unique)
    choice(items=items, length=length, unique=unique)
    choice(items=items, length=0, unique=unique)
    choice(items=items, length=0)
   

# Generated at 2022-06-23 21:15:28.890060
# Unit test for constructor of class Choice
def test_Choice():
    """Testing the constructor of class Choice."""
    try:
        assert Choice()
    except Exception as e:
        assert False, "This method should not throw an exception."

# Generated at 2022-06-23 21:15:32.906071
# Unit test for constructor of class Choice
def test_Choice():
    """Constructor of class Choice."""
    try:
        choice = Choice()
    except Exception as err:
        print('Constructor of class Choice test has failed')
        print('Error:', err)
        return None
    print('Constructor of class Choice test has passed successfully \n')
    return choice


# Generated at 2022-06-23 21:15:36.331114
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice()
    assert Choice(locale='zh')
    assert Choice(seed=1)
    assert Choice(locale='zh', seed=1)

# Generated at 2022-06-23 21:15:42.647223
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice() == '1'
    assert choice('abc') == 'c'
    assert isinstance(choice('abc', length=1), list)
    assert choice('abc', length=2) == 'ba'
    assert isinstance(choice('abc', length=5), tuple)
    assert choice('aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:15:51.419093
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice.

    :return: None.
    :rtype: None.
    """
    obj = Choice()
    # items=['a', 'b', 'c']
    assert isinstance(obj(items=['a', 'b', 'c']), str)
    # items=['a', 'b', 'c'], length=1
    assert len(obj(items=['a', 'b', 'c'], length=1)) == 1
    # items='abc', length=2
    assert len(obj(items='abc', length=2)) == 2
    # items=('a', 'b', 'c'), length=5
    assert len(obj(items=('a', 'b', 'c'), length=5)) == 5
    # items='aabbbccccddddd', length

# Generated at 2022-06-23 21:15:57.220384
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    choice = Choice()
    assert choice(items=['a', 'b', 'c'], length=1) == ['b']
    assert choice(items=[1, 2, 3], length=2) == [2, 1]
    assert choice(items='abc', length=1) == 'a'
    assert choice(items='abc', length=2) == 'ac'
    assert choice(items=(1, 2, 3), length=3) == (1, 1, 3)
    assert choice(items=(1, 2, 3), length=5) == (2, 3, 1, 2, 3)
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'abcd'

# Generated at 2022-06-23 21:16:06.269034
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    f = c.__call__
    r = 'a'
    assert len(f(items=['a', 'b', 'c'])) == 1
    assert len(f(items=['a', 'b', 'c'], length=1)) == 1
    assert len(f(items='abc', length=2)) == 2
    assert len(f(items=('a', 'b', 'c'), length=5)) == 5
    assert len(f(items='aabbbccccddddd', length=4, unique=True)) == 4
    assert f(items=['a', 'b', 'c']) == r
    assert f(items=['a', 'b', 'c'], length=1) == [r]
    assert f(items='abc', length=2) == 'ba'
   

# Generated at 2022-06-23 21:16:15.924411
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    from mimesis.builtins import Choice
    from mimesis.enums import Gender
    from mimesis.providers import Person

    from mimesis.builtins import Choice

    from mimesis.enums import Gender
    from mimesis.providers import Person

    choice = Choice()
    data = choice('abc')
    assert isinstance(data, str)
    assert data in 'abc'
    assert data != 'abc'

    choice = Choice()
    assert isinstance(choice(['a', 'b', 'c']), str)

    choice = Choice()
    assert isinstance(choice(['a', 'b', 'c'], length=1), list)

    choice = Choice()
    assert isinstance(choice('abc', length=2), str)



# Generated at 2022-06-23 21:16:20.576485
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Return value of method __call__ of class Choice
    return_value = Choice(items=('a', 'b', 'c'), length=5)
    assert return_value == ('c', 'a', 'a', 'b', 'c')

# Generated at 2022-06-23 21:16:27.856457
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    input_data = [
        ((['a', 'b', 'c'],), 'c'),
        ((['a', 'b', 'c'], 1), ['a']),
        (('abc', 2), 'ba'),
        ((('a', 'b', 'c'), 5), ('c', 'a', 'a', 'b', 'c')),
        (('aabbbccccddddd', 4, True), 'cdba')]

    for test_input, expected_result in input_data:
        assert Choice().__call__(*test_input) == expected_result


# Generated at 2022-06-23 21:16:32.389319
# Unit test for constructor of class Choice
def test_Choice():
    """Unit test for constructor of class Choice.
    """
    # Arrange
    choice = Choice()

    # Act
    result = [choice(items=['a', 'b', 'c']) for _ in range(10)]

    # Assert
    assert len(result) == 10
    for item in result:
        assert item in ['a', 'b', 'c']


# Generated at 2022-06-23 21:16:39.449228
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender
    from mimesis.enums import PersonType
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.code import Code
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person import Person
    from mimesis.providers.person import Person
    from mimesis.providers.person import Person
    from mimesis.providers.person import Person
    from mimesis.providers.misc import Misc
    from mimesis.providers.misc import Misc
    from mimesis.providers.misc import Misc

# Generated at 2022-06-23 21:16:40.325020
# Unit test for constructor of class Choice
def test_Choice():
    Choice(seed=42)

# Generated at 2022-06-23 21:16:51.832604
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    test1 = choice(items=['a', 'b', 'c'])
    test2 = choice(items=['a', 'b', 'c'], length=1)
    test3 = choice(items='abc', length=2)
    test4 = choice(items=('a', 'b', 'c'), length=5)
    test5 = choice(items='aabbbccccddddd', length=4, unique=True)

    print('type(test1):', type(test1))
    print('type(test2):', type(test2))
    print('type(test3):', type(test3))
    print('type(test4):', type(test4))
    print('type(test5):', type(test5))


# Generated at 2022-06-23 21:17:01.391477
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    result1 = choice(items=['a', 'b', 'c'])
    result2 = choice(items=['a', 'b', 'c'], length=1)
    result3 = choice(items='abc', length=2)
    result4 = choice(items=('a', 'b', 'c'), length=5)
    result5 = choice(items='aabbbccccddddd', length=4, unique=True)
    assert result1 in ['a', 'b', 'c']
    assert result2 in [['a'], ['b'], ['c']]
    assert result3 in ['ab', 'ac', 'ba', 'bc', 'ca', 'cb']

# Generated at 2022-06-23 21:17:08.078445
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice"""
    from mimesis.choice import Choice
    from mimesis.datasets.auxiliary import MIMESIS_SEQUENCES
    from mimesis.enums import Alphabet, Language
    
    # call Choice()
    choice1 = Choice()
    # call Choice(lang='en')
    choice2 = Choice(lang=Language.EN)
    
    if choice1.language == Language.EN:
        assert choice1._item.sequence(MIMESIS_SEQUENCES.NUMBERS) == choice2._itme.sequece(MIMESIS_SEQUENCES.NUMBERS)

# Generated at 2022-06-23 21:17:09.479969
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice()

# Generated at 2022-06-23 21:17:16.512722
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    errors_list = []

    #TODO: Add more test cases
    def test_Choice(items, length, unique):
        try:
            result = choice(items, length, unique)
        except Exception:
            return False
        return True

    if not test_Choice(items=['a', 'b', 'c'], length=1, unique=True):
        errors_list.append('')

    if errors_list:
        raise Exception('Error')

# Generated at 2022-06-23 21:17:21.487970
# Unit test for method __call__ of class Choice

# Generated at 2022-06-23 21:17:23.010413
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)

# Generated at 2022-06-23 21:17:30.917115
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender

    from mimesis.builtins import Address

    from mimesis.builtins import Person

    from mimesis.builtins import Team

    from mimesis.builtins import Vehicle

    from mimesis.builtins import Worker

    from mimesis.builtins import World

    from mimesis.exceptions import NonEnumerableError

    from mimesis.providers import random_choice as rc

    from mimesis.typing import GenderList, Locale, TimeZone

    # Create random choice provider

    choice = Choice()

    # Test with empty list

    assert choice(items=[]) == None

    # Test with empty tuple

    assert choice(items=()) == None

    # Test with empty string

    assert choice(items='') == None

    # Test with string


# Generated at 2022-06-23 21:17:41.331621
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) in ['aa', 'bb', 'cc', 'ab', 'bc', 'ac']

# Generated at 2022-06-23 21:17:50.611970
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Check functionality of method __call__ of class Choice."""
    from mimesis.enums import FieldCode

    choice = Choice()

    items = choice.address.address(field=FieldCode.ALL, language='en')
    assert isinstance(items, list)

    length = choice.random.randint(0, 100)
    result = choice(items, length=length)
    assert len(result) == length
    assert isinstance(result, list)

    length = 1
    result = choice(items, length=length)
    assert len(result) == length
    assert isinstance(result, list)

    length = 2
    result = choice(items, length=length, unique=True)
    assert len(result) == length
    assert isinstance(result, list)
    assert len(set(result)) == len(result)

# Generated at 2022-06-23 21:17:57.624972
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Test with empty items
    items_ = []
    length_ = 0
    unique_ = False
    choice = Choice()
    try:
        choice(items=items_, length=length_, unique=unique_)
    except ValueError as e:
        assert str(e) == '**items** must be a non-empty sequence.'

    # Test with non-sequence items
    items_ = 5
    try:
        choice(items=items_, length=length_, unique=unique_)
    except TypeError as e:
        assert str(e) == '**items** must be non-empty sequence.'

    # Test with non-integer length
    items_ = (1, 2, 3)
    length_ = 'five'

# Generated at 2022-06-23 21:17:59.214401
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice is not None


# Generated at 2022-06-23 21:18:10.743537
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    assert choice('abc') in 'abc'
    assert choice(['a', 'b', 'c']) in ['a', 'b', 'c']
    if choice(['a', 'b', 'c'], 5) in [
        ['a', 'b', 'c', 'b', 'c'],
        ['b', 'c', 'a', 'c', 'b'],
        ['c', 'a', 'b', 'b', 'c'],
        ['b', 'c', 'a', 'b', 'c'],
        ['c', 'b', 'a', 'b', 'c'],
    ]:
        assert True
    else:
        assert False


# Generated at 2022-06-23 21:18:18.274726
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    # def __call__(self, items: Optional[Sequence[Any]], length: int = 0,
    #              unique: bool = False) -> Union[Sequence[Any], Any]:
    #TODO: Get rid of the following
    #selection = ['a', 'b', 'c']
    #length = 1
    #unique = True
    #selected = []
    #while len(selected) < length:
    #    item = self.random.choice(selection)
    #    if (unique and item not in selected) or not unique:
    #        selected.append(item)
    #assert len(selected) == length
    #return selected[0] if length == 1 else selected
    #return selected[0] if length == 1 else selected

    pass

# Generated at 2022-06-23 21:18:29.153456
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method Choice.__call__."""
    choice = Choice()
    # Call with valid arguments
    expected = [('c', 'a', 'a', 'b', 'c'),
                ('b', 'a', 'c', 'c', 'a', 'b', 'a', 'c'),
                ['c'],
                'c']
    # Call with valid arguments
    for n in range(0, 100):
        result = choice(items=('a', 'b', 'c'), length=5)
        assert result in expected
        result = choice(items='aabbbccccddddd', length=8, unique=True)
        assert result in expected
        result = choice(items=['a', 'b', 'c'], length=1)
        assert result in expected
        result = choice(items='abc', length=1)

# Generated at 2022-06-23 21:18:38.458924
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    from mimesis import Choice

    choice = Choice()

    choice(items=['a', 'b', 'c'])
    choice(items=['a', 'b', 'c'], length=1)
    choice(items='abc', length=2)
    choice(items=('a', 'b', 'c'), length=5)
    choice(items='aabbbccccddddd', length=4, unique=True)

    # exception on non Sequence items
    # TypeError if **items** must be non-empty sequence.
    choice(items=[])

    # exception on non non-empty sequence of items
    # ValueError if **items** must be a non-empty sequence.
    choice(items=[], length=1)

    # exception on non non-empty sequence of items
    # TypeError if **length** must be integer.

# Generated at 2022-06-23 21:18:43.463015
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 0
    unique = False
    # TODO:
    #
    # Use 'Choice()' as instance
    #
    #   choice.test_Choice___call__()
    choice = Choice()
    assert isinstance(choice(items=items, length=length, unique=unique),
                      str)

# Generated at 2022-06-23 21:18:51.940677
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    print('choice', choice)
    # print('choice.items', choice.items) # AttributeError: 'Choice' object has no attribute 'items'
    # print('choice.length', choice.length) # AttributeError: 'Choice' object has no attribute 'length'
    # print('choice.unique', choice.unique) # AttributeError: 'Choice' object has no attribute 'unique'
    print('choice.seed', choice.seed)
    print('choice.random', choice.random) # This is the class Random


# Generated at 2022-06-23 21:18:54.851443
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)
    assert isinstance(choice.provider_name, str)
    assert isinstance(choice.locale, str)


# Generated at 2022-06-23 21:18:56.001823
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice is not None


# Generated at 2022-06-23 21:19:00.862741
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import pytest
    test_data = [
        ({'items': ['a', 'b', 'c'], 'length': 1, 'unique': False}),
        ({'items': ['a', 'b', 'c'], 'length': 0, 'unique': True}),
        ({'items': 'abc', 'length': 2, 'unique': False})
    ]
    for example in test_data:
        assert isinstance(Choice()(**example), str)