

# Generated at 2022-06-23 21:09:03.523220
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    # final_results = ['b', 'a', 'b', 'b', 'a']
    # assert Result() == final_results
    pass

# Generated at 2022-06-23 21:09:04.208676
# Unit test for constructor of class Choice
def test_Choice():
    """ Test constructor of class Choice. """
    assert Choice() != None


# Generated at 2022-06-23 21:09:05.425419
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert callable(c.__call__)


# Generated at 2022-06-23 21:09:06.284057
# Unit test for constructor of class Choice
def test_Choice():
    pass


# Generated at 2022-06-23 21:09:12.857320
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    from mimesis.enums import EnumStuff
    from mimesis.typing import Seed
    from mimesis.providers.base import BaseProvider
    from mimesis.choice import Choice
    choice = Choice()
    items_ = EnumStuff.NUMBER_SYSTEMS
    length_ = 1
    unique_ = True
    seed_ = Seed.UUID
    base_provider = BaseProvider(seed=seed_)
    seed, length, unique, choice, items_ = base_provider.get_random_seed(), base_provider.get_random_int(), base_provider.get_boolean(), Choice(seed=seed_), base_provider.get_random_choice(items=items_)
    choice(items=items_).get

# Generated at 2022-06-23 21:09:16.100033
# Unit test for constructor of class Choice
def test_Choice():
    """Constructor test."""
    choice = Choice()

    assert choice is not None
    assert choice.random is not None
    assert choice.random.seed is not None

# Generated at 2022-06-23 21:09:22.534721
# Unit test for constructor of class Choice
def test_Choice():
    """Test for constructor of class Choice."""
    choice = Choice()
    assert isinstance(choice._random, type(None))

    try:
        choice(items='abc', length=2)
    except Exception as e:
        assert str(e) == '**length** must be integer.'
        assert isinstance(e, TypeError)

    try:
        choice(items=0, length=0)
    except Exception as e:
        assert str(e) == '**items** must be non-empty sequence.'
        assert isinstance(e, TypeError)

    try:
        choice(items=[], length=0)
    except Exception as e:
        assert str(e) == '**items** must be a non-empty sequence.'
        assert isinstance(e, ValueError)


# Generated at 2022-06-23 21:09:24.085105
# Unit test for constructor of class Choice
def test_Choice():
    p = Choice()
    assert isinstance(p._random, Choice)


# Generated at 2022-06-23 21:09:25.034869
# Unit test for constructor of class Choice
def test_Choice():
    assert isinstance(Choice(), Choice)

# Generated at 2022-06-23 21:09:31.282077
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    choice(items=['a', 'b', 'c'])
    choice(items=['a', 'b', 'c'], length=1)
    choice(items='abc', length=2)
    choice(items=('a', 'b', 'c'), length=5)
    choice(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-23 21:09:40.808501
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    # Case 1: Choice from a non-empty list
    items = ['a', 'b', 'c']
    assert choice(items) in items
    # Case 2: Choice from a non-empty tuple
    items = ('a', 'b', 'c')
    assert choice(items) in items
    # Case 3: Choice from a non-empty string
    items = 'abc'
    assert choice(items) in items
    # Case 4: Should raise TypeError if item is not a sequence
    items = 1
    try:
        choice(items)
    except TypeError:
        assert True
    # Case 5: Should raise ValueError if item is an empty sequence
    items = []
    try:
        choice(items)
    except ValueError:
        assert True
    # Case 6: Should raise TypeError if length is

# Generated at 2022-06-23 21:09:42.847847
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)


# Generated at 2022-06-23 21:09:43.542611
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-23 21:09:54.329591
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    for seed in range(10):
        choice = Choice(seed=seed)
        # Check choice from list with length 1
        result = choice(['a'], 1)
        assert result == ['a']
        # Check choice from list with length > 1
        result = choice(['a', 'b', 'c'], 5)
        assert result == ['c', 'b', 'a', 'c', 'b']
        # Check choice from non-empty tuple
        result = choice(('a', 'b', 'c'), 5)
        assert result == ('a', 'b', 'b', 'a', 'c')
        # Check choice from non-empty string with length > 1
        result = choice('abc', 5)
        assert result == 'abbc'
        # Check choice from non-empty string with length 1

# Generated at 2022-06-23 21:09:54.903968
# Unit test for constructor of class Choice
def test_Choice():
    Choice()

# Generated at 2022-06-23 21:10:02.647952
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import random
    import string
    import unittest

    from mimesis.data import NUMERALS, SALUTATIONS
    from mimesis.data import SPECIAL_CHARACTERS
    from mimesis.exceptions import NonEnumerableError
    from mimesis.providers.choice import Choice

    # Set seed for reproducible tests
    random.seed(0)

    choice = Choice()

    # Error handling: invalid items
    # Non-empty sequence
    with unittest.TestCase().assertRaises(TypeError):
        choice(items=5)

    # Error handling: invalid length
    # Integer length
    with unittest.TestCase().assertRaises(TypeError):
        choice(items=[1, 2, 3], length='five')

    # Non-negative length

# Generated at 2022-06-23 21:10:08.758194
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()

    choice(items=['a', 'b', 'c'])
    choice(items=['a', 'b', 'c'], length=1)
    choice(items='abc', length=2)
    choice(items=('a', 'b', 'c'), length=5)
    choice(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-23 21:10:10.231264
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    if not c:
        raise Exception


# Generated at 2022-06-23 21:10:15.668438
# Unit test for constructor of class Choice
def test_Choice():
    """Test for class Choice."""
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:10:21.022122
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Setup
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 2
    unique = True

    # Exercise
    result = choice(items, length, unique)

    # Verify
    assert result in items

    # Cleanup - none necessary



# Generated at 2022-06-23 21:10:23.981735
# Unit test for constructor of class Choice
def test_Choice():
    c1 = Choice(locale='en')
    c2 = Choice(locale='de')
    assert c1('a,b,c') == c2('a,b,c')

# Generated at 2022-06-23 21:10:24.928819
# Unit test for constructor of class Choice
def test_Choice():
    pass



# Generated at 2022-06-23 21:10:32.178177
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:10:40.938320
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    test_data = [
        [('a', 'b', 'c'), 1, False, 'cacabacabacabacab'],
        ['abc', 4, True, 'cba'],
        ['abc', 4, False, 'baac'],
        ['abc', 4, True, 'cba'],
        ['abc', 1, False, 'c'],
        ['abc', 1, True, 'a'],
        ['abc', 3, True, 'cca'],
        ['abc', 2, True, 'bab'],
        ['abc', 2, False, 'ca'],
	]

# Generated at 2022-06-23 21:10:47.442252
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice()(items=['a', 'b', 'c']) == 'c'
    assert Choice()(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice()(items='abc', length=2) == 'ba'
    assert Choice()(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice()(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:10:55.384222
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items=['a', 'b', 'c'],
                             length=1) == ['a']
    assert Choice().__call__(items='abc',
                             length=2) == 'ba'
    assert Choice().__call__(items=('a', 'b', 'c'),
                             length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items='aabbbccccddddd',
                             length=4, unique=True) == 'cdba'
    test_list = ['a', 'b', 'c']

# Generated at 2022-06-23 21:11:06.873290
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    result = c.__call__(items=['a', 'b', 'c'])
    assert result == 'c'
    result = c.__call__(items=['a', 'b', 'c'], length=3)
    assert result == ['a','b','c']
    result = c.__call__(items=['a','b','c'], length=3, unique=True)
    assert result == ['a','b','c']
    result = c.__call__(items=['a','a','a','b','b','b','c','c','c','c'], length=4, unique=True)
    assert result == ['c','a','b','c']
    result = c.__call__(items=['a','b','c'], length=5)

# Generated at 2022-06-23 21:11:14.683424
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    range_ = len(choice(items=['a', 'b', 'c', 'd', 'e'], length=3))
    assert range_ == 3

    items = ['a', 'b', 'c', 'd', 'e']
    length = len(choice(items=items, length=3))
    assert length == 3

    items = ('a', 'b', 'c', 'd', 'e')
    length = len(choice(items=items, length=3))
    assert length == 3

test_Choice___call__()

# Generated at 2022-06-23 21:11:21.232405
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

if __name__ == '__main__':
    import sys
    sys.exit(test_Choice___call__())

# Generated at 2022-06-23 21:11:22.411681
# Unit test for constructor of class Choice
def test_Choice():
    """Tests constructor of class Choice."""
    c = Choice()
    assert c

# Generated at 2022-06-23 21:11:25.948420
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """The Choice.__call__() method should return a randomly-chosen sequence
    or bare element from a sequence."""

    choice = Choice()

    # first an example of a single item
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']

    # next a length and a sequence example
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    #
    assert choice(items='abc', length=2) in ['ab', 'ba', 'ca', 'ac']

# Generated at 2022-06-23 21:11:30.566315
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    from mimesis import Choice
    choice = Choice()

    assert isinstance(choice(items=[], length=0), str), 'Should be a str.'
    assert isinstance(choice(items=[], length=0), str), 'Should be a list.'
    assert isinstance(choice(items=[], length=0), str), 'Should be a tuple.'


# Generated at 2022-06-23 21:11:33.701585
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice()._Choice__call__(items=['a', 'b', 'c'], length=1) == 'c'
    assert Choice()._Choice__call__(items=['a', 'b', 'c'], length=1, unique=True) == 'c'


# Generated at 2022-06-23 21:11:34.926595
# Unit test for constructor of class Choice
def test_Choice():
    obj = Choice()
    assert obj is not None

# Generated at 2022-06-23 21:11:41.379204
# Unit test for constructor of class Choice
def test_Choice():
    # Create an instance of Choice()
    choice = Choice()

    # Test __call__ method
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:11:43.657898
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert c.random.choice([1, 2, 3]) == 2
    return c

# Generated at 2022-06-23 21:11:53.180638
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert len(choice(items=['a', 'b', 'c'], length=5)) == 5
    assert len(choice(items='abc', length=6)) == 6

# Generated at 2022-06-23 21:11:54.638925
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice.random.choice(['a', 'b', 'c']) in ['a', 'b', 'c']

# Generated at 2022-06-23 21:11:56.987608
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    data = choice(items = ['a', 'b', 'c'])
    assert data == 'c'


# Generated at 2022-06-23 21:12:04.973664
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    test_code_Choice___call__ = """
        >>> from mimesis import Choice
        >>> choice = Choice()
        >>> choice(items=['a', 'b', 'c'])
        'c'
        >>> choice(items=['a', 'b', 'c'], length=1)
        ['a']
        >>> choice(items='abc', length=2)
        'ba'
        >>> choice(items=('a', 'b', 'c'), length=5)
        ('c', 'a', 'a', 'b', 'c')
        >>> choice(items='aabbbccccddddd', length=4, unique=True)
        'cdba'
    """
    result = None
    exec(test_code_Choice___call__)
    if result:
        print(result)

# Code for module Choice

# Generated at 2022-06-23 21:12:15.137303
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import random
    from mimesis import Choice

    choice = Choice(random)

    items = ['a', 'b', 'c']
    assert choice(items=items) in items
    length = 1
    assert len(choice(items=items, length=length)) == length
    items = 'abc'
    length = 2
    assert len(choice(items=items, length=length)) == length
    items = ('a', 'b', 'c')
    length = 5
    assert len(choice(items=items, length=length)) == length
    items = 'aabbbccccddddd'
    length = 4
    assert len(choice(items=items, length=length, unique=True)) == length

    items = []
    length = 1

# Generated at 2022-06-23 21:12:24.171831
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method __call__ of class Choice."""

    data = [None, '', 'a', 'A', '4', '@',
            'hello world', '\n', '\t', '\\', 'abcdefghij']
    for item in data:
        c = Choice(item)
        c(item)
        c(item, length=0)
        c(item, length=10, unique=True)
        c(item, length=10, unique=False)
        c(item, length=0, unique=True)
        c(item, length=0, unique=False)



# Generated at 2022-06-23 21:12:25.698462
# Unit test for constructor of class Choice
def test_Choice():
    Choice()
    print("Constructor for Choice class is working")

# Generated at 2022-06-23 21:12:27.836962
# Unit test for constructor of class Choice
def test_Choice():
    """Unit tesr for constructor of class Choice."""
    ch=Choice()
    assert ch.choice('abcd')=='a', 'Does not work.'

# Generated at 2022-06-23 21:12:32.007480
# Unit test for constructor of class Choice
def test_Choice():
    """Check that class Choice work"""
    from mimesis import Choice
    choice = Choice()
    assert type(choice(items=['a', 'b', 'c']) == str)
    assert type(choice(items=['a', 'b', 'c'], length=1) == list)
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:12:33.097386
# Unit test for constructor of class Choice
def test_Choice():
    random_choice = Choice() # type: Choice
    print(random_choice)

# Generated at 2022-06-23 21:12:39.182279
# Unit test for constructor of class Choice
def test_Choice():
    """
    Unit test for constructor of class Choice
    """
    # create an instance of class Choice
    #
    # 1.
    #
    f1 = Choice()
    # 2.
    #
    f2 = Choice()
    # print out the value
    print(f1)
    print(f2)
    # create an instance of class Choice
    #
    # 1.
    #
    f1 = Choice()
    # 2.
    #
    f2 = Choice()
    print(f1)
    print(f2)

test_Choice()

# Generated at 2022-06-23 21:12:40.950433
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice.random.choice(['a', 'b', 'c'])
    assert choice.random.choice(items=['a', 'b', 'c'])

# Generated at 2022-06-23 21:12:44.749911
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice(0)

    print(choice(items=['a', 'b', 'c']))
    print(choice(items=('a', 'b', 'c'), length=5))
    print(choice(items='abc', length=2))

# Generated at 2022-06-23 21:12:53.529885
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    import pytest
    from mimesis.exceptions import NonEnumerableError

    with pytest.raises(TypeError):
        Choice().__call__(items=(1, 2, 3), length=1.1)
    with pytest.raises(ValueError):
        Choice().__call__(items=(1, 2, 3), length=-1)
    with pytest.raises(TypeError):
        Choice().__call__(items=100)
    with pytest.raises(TypeError):
        Choice().__call__(items=['a', 'b', 'c'], length=None)
    with pytest.raises(NonEnumerableError):
        Choice().__call__(items=1)

# Generated at 2022-06-23 21:12:54.587612
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    print("constructor:\n", c)


# Generated at 2022-06-23 21:12:55.809503
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice.random.choice('abcd') in 'abcd'

# Generated at 2022-06-23 21:13:01.524975
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    result1 = choice(['a', 'b', 'c'])
    result2 = choice(items=['a', 'b', 'c'], length=1)
    result3 = choice('abc', length=2)
    result4 = choice(('a', 'b', 'c'), length=5)
    result5 = choice('aabbbccccddddd', length=4, unique=True)

    if (result1 != 'c' or result2 != ['a'] or result3 != 'ba' or result4 != ('c', 'a', 'a', 'b', 'c') or result5 != 'cdba'):
        raise AssertionError()

# Generated at 2022-06-23 21:13:04.250882
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 1
    result = choice(items, length)
    assert result == ['a']



# Generated at 2022-06-23 21:13:15.179610
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    print("Testing Choice.__call__() ...")

    import mimesis.enums
    from mimesis.builtins import RussiaSpecProvider

    srand = "Testing Choice.__call__()"
    choice = Choice(mimesis.enums.Language.EN, seed=srand)

    print("Expect : 'b'")
    print("Actual :", choice(items=['a', 'b', 'c']))

    print("Expect : ['b']")
    print("Actual :", choice(items=['a', 'b', 'c'], length=1))

    print("Expect : 'cb'")
    print("Actual :", choice(items='abc', length=2))

    print("Expect : ('a', 'c', 'b', 'b', 'b')")

# Generated at 2022-06-23 21:13:24.823047
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    # Test for empty sequence of items
    choice = Choice()
    assert choice(items=[], length=2) == []
    assert choice(items=[], length=0) == []
    assert choice(items='', length=2) == ''
    assert choice(items='', length=0) == ''
    assert choice(items=(), length=2) == ()
    assert choice(items=(), length=0) == ()
    # Test for some sequence of items
    assert choice([0, 1, 2, 3, 4, 5]) == 2
    assert choice([0, 1, 2, 3, 4, 5], length=1) == [0]
    assert choice('012345', length=2) == '24'

# Generated at 2022-06-23 21:13:30.582301
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = ['a', 'b', 'c']
    test = choice(items=items)
    assert test in items
    test = choice(items=items, length=1)
    assert len(test) == 1
    items = "abc"
    test = choice(items=items, length=2)
    assert len(test) == 2
    items = ('a', 'b', 'c')
    test = choice(items=items, length=5)
    assert len(test) == 5
    items = 'aabbbccccddddd'
    test = choice(items=items, length=4, unique=True)
    assert len(test) == 4


# Generated at 2022-06-23 21:13:33.552608
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice"""

    from mimesis.providers.choice import Choice

    choice = Choice()

    assert isinstance(choice(items=['a', 'b', 'c']), str)
    assert isinstance(choice(items='abc', length=2), str)
    assert len(choice(items='aabbbccccddddd', length=2)) == 2
    assert len([choice(items='aabbbccccddddd', length=2)]) == 2
    assert len((choice(items='aabbbccccddddd', length=2))) == 2

# Generated at 2022-06-23 21:13:38.230822
# Unit test for constructor of class Choice
def test_Choice():
    class TestChoice():
        def __init__(self):
            self.choice = Choice()
            # print(dir(self.choice))
            # print(isinstance(self.choice, Choice))
            # print(self.choice.random.choice(['a', 'b', 'c']))

        def test_Function_call(self):
            pass

    test = TestChoice()

# Generated at 2022-06-23 21:13:48.124045
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ('c')
    assert choice(items=['a', 'b', 'c'], length=1) in (['a'])
    assert choice(items='abc', length=2) in ('ba')
    assert choice(items=('a', 'b', 'c'), length=5) in (('c', 'a', 'a', 'b', 'c'))
    assert choice(items='aabbbccccddddd', length=4, unique=True) in ('cdba')

    try:
        choice(items=['a', 'b', 'c'], length=1.0)
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-23 21:13:56.125104
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    from hypothesis import given
    from hypothesis.strategies import lists, integers, tuples

    @given(lists(integers()))
    def test_Choice___call__(value):
        choice = Choice()
        res = choice(items=[], length=5)
        assert isinstance(res, list)
        assert len(res) == 5

    @given(lists(integers()))
    def test_Choice___call__(value):
        choice = Choice()
        res = choice(items=value)
        assert isinstance(res, int)

    @given(lists(integers()))
    def test_Choice___call__(value):
        choice = Choice()
        res = choice(items=value, length=1)
        assert isinstance(res, list)
        assert len(res) == 1


# Generated at 2022-06-23 21:14:02.983878
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice('abc', 2) in ('bc', 'cb', 'ac', 'ca', 'ba', 'ab')
    assert choice('abc', 2, True) in ('bc', 'cb', 'ac', 'ca')
    assert choice(['a', 'b', 'c'], 2, True) in (['a', 'b'], ['a', 'c'],
                                               ['b', 'c'])
    assert choice(['a', 'b', 'c'], 2, False) in (['a', 'b'], ['a', 'c'],
                                                ['b', 'a'], ['b', 'c'],
                                                ['c', 'a'], ['c', 'b'])

# Generated at 2022-06-23 21:14:04.476214
# Unit test for constructor of class Choice
def test_Choice():
    x = Choice()
    x('abc')



# Generated at 2022-06-23 21:14:05.712069
# Unit test for constructor of class Choice
def test_Choice():
    b = Choice()
    assert b.items == ["a"]

# Generated at 2022-06-23 21:14:16.773119
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    # Test that a string is returned, where expectation is that the
    # underlying choice() is not invoked (i.e. the method should lead to
    # a TypeError exception)
    class TestChoice___call__0:
        def __init__(self) -> None:
            self.ran = False

        def choice(self, items: Sequence[Any]) -> Any:
            self.ran = True
            return 'a'

        def execute(self) -> None:
            choice = Choice()
            choice(items='')

        def test(self) -> bool:
            try:
                self.execute()
            except TypeError:
                return not self.ran
            return False

    assert TestChoice___call__0().test()

    # Test that a randomly-chosen element is returned, where expectation is
    # that the underlying choice() is invoked

# Generated at 2022-06-23 21:14:26.888489
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice( seed=100 )([1,2]) == Choice( seed=100 )([1,2])
    assert Choice( seed=100 )([1,2],length=1) == Choice( seed=100 )([1,2],length=1)
    assert Choice( seed=100 )([1,2],length=1,unique=True) == Choice( seed=100 )([1,2],length=1,unique=True)
    assert Choice( seed=100 )([1,2],length=2,unique=True) != Choice( seed=100 )([1,2],length=2,unique=True)
    assert Choice( seed=100 )([1,2],length=2,unique=True) != Choice( seed=101 )([1,2],length=2,unique=True)

# Generated at 2022-06-23 21:14:36.794504
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Tests for method __call__ of class Choice"""

# Generated at 2022-06-23 21:14:46.428928
# Unit test for constructor of class Choice
def test_Choice():
    # pass
    c = Choice(random_seed=4)
    items = ['a', 'b', 'c']
    length = 1
    data = c(items, length)
    assert data==['b'],'error'
    
    c = Choice(random_seed=4)
    items = 'abc'
    length = 2
    data = c(items, length)
    assert data == 'ac','error'

    c = Choice(random_seed=4)
    items = ('a', 'b', 'c')
    length = 5
    data = c(items, length)
    assert data == ('a', 'a', 'a', 'b', 'c'),'error'

    c = Choice(random_seed=4)
    items = 'aabbbccccddddd'
    length = 4
    unique = True

# Generated at 2022-06-23 21:14:51.992129
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice.choice(items=['a', 'b', 'c']) == 'c'
    assert choice.choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice.choice(items='abc', length=2) == 'ba'
    assert choice.choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c') # noqa: E501
    assert choice.choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba' # noqa: E501



# Generated at 2022-06-23 21:14:59.921553
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    import mimesis.enums
    from mimesis.enums import Locale

    choice = Choice(locale=Locale.EN)

    # `choice(items=['a', 'b', 'c'])`
    assert ''.join(choice(items=['a', 'b', 'c'])) in ['a', 'b', 'c']

    # `choice(items=['a', 'b', 'c'], length=1)`
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']

    # `choice(items='abc', length=2)`
    assert ''.join(choice(items='abc', length=2)) in ['ab', 'ba', 'ac', 'ca', 'bc', 'cb']

    # `choice(items=

# Generated at 2022-06-23 21:15:03.081778
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'



# Generated at 2022-06-23 21:15:10.965430
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from pprint import pprint
    from mimesis import Choice
    import random
    random.seed(4)

    sample_items_1 = [1, 2, 3, 4, 5]
    sample_items_2 = ['a', 'b', 'c', 'd', 'e']
    sample_items_3 = 'abcde'
    sample_items_4 = ['a', 'a', 'b', 'b', 'b']

    def _is_random(items: Optional[Sequence[Any]], length: int = 0, unique: bool = False) -> bool:
        obj = Choice()
        value = obj(items, length, unique)
        return True if value in items else False


# Generated at 2022-06-23 21:15:18.780635
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    from inspect2 import signature
    from inspect2 import Signature
    choice = Choice()
    sig = signature(choice)
    assert isinstance(sig, Signature)
    assert str(sig) == "(items=None, length=0, unique=False)"
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ba', 'ac', 'ab']

# Generated at 2022-06-23 21:15:25.119006
# Unit test for constructor of class Choice
def test_Choice():
    """Get a random value from a sequence.

    >>> from mimesis import Choice
    >>> choice = Choice()
    >>> choice(items=['a', 'b', 'c', 'd'], length=1)
    'a'
    >>> choice(items=['a', 'b', 'c', 'd'], length=4)
    ['d', 'b', 'a', 'b']
    """
if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 21:15:31.791793
# Unit test for constructor of class Choice
def test_Choice():
    assert len(Choice().__call__(items='abc', length=4, unique=False)) == 4
    assert len(Choice().__call__(items='abc', length=4, unique=True)) == 4
    assert len(Choice().__call__(items=['a', 'b', 'c'], length=1)) == 1
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) != ['b']

if __name__ == '__main__':
    test_Choice()

# Generated at 2022-06-23 21:15:40.085330
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert isinstance(choice(['a', 'b', 'c']), str)
    assert isinstance(choice(['a', 'b', 'c'], length = 1), list)
    assert isinstance(choice('abc', length = 2), str)
    assert isinstance(choice(('a', 'b', 'c'), length = 5), tuple)
    assert isinstance(choice('aabbbccccddddd', length = 4, unique = True), str)


# Generated at 2022-06-23 21:15:41.604064
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice.__class__.__name__ == "Choice"

# Generated at 2022-06-23 21:15:50.587915
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    items = ['a', 'b', 'c']
    elem = choice(items, length=1)
    assert elem in items and len(elem) == 1

    items = ['a', 'b', 'c']
    elem = choice(items, length=2)
    assert elem in items and len(elem) == 2

    from string import ascii_letters
    items = ascii_letters
    elem = choice(items, length=3)
    assert elem in items and len(elem) == 3

    elem = choice(items, length=1)
    assert elem in items and len(elem) == 1

    elem = choice(items, length=0)
    assert elem in items and len(elem) == 1

    items = ascii_letters

# Generated at 2022-06-23 21:15:54.811609
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=list('abc')) == 'c'
    assert choice(items=list('abc'), length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=tuple('abc'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-23 21:16:03.194458
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    # Generate a randomly-chosen sequence or bare element from a sequence.
    res1 = choice(items=['a', 'b', 'c'])
    assert type(res1) == str
    res2 = choice(items=['a', 'b', 'c'], length=1)
    assert type(res2) == list
    res3 = choice(items='abc', length=2)
    assert type(res3) == str
    res4 = choice(items=('a', 'b', 'c'), length=5)
    assert type(res4) == tuple
    res5 = choice(items='aabbbccccddddd', length=4, unique=True)
    assert type(res5) == str


# Generated at 2022-06-23 21:16:04.559911
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    pass

# Generated at 2022-06-23 21:16:13.661632
# Unit test for constructor of class Choice
def test_Choice():
	# Random selection from the list.
	items = ['a', 'b', 'c']
	ch = Choice()
	print(ch(items))

	# Random selection from the list of given length.
	print(ch(items, length=1))

	# Random selection from the string.
	items = 'abc'
	print(ch(items, length=2))

	# Random selection from the tuple.
	items = ('a', 'b', 'c')
	print(ch(items, length=5))

	# Random selection from the string of unique characters.
	items = 'aabbbccccddddd'
	print(ch(items, length=4, unique=True))


# Generated at 2022-06-23 21:16:20.481012
# Unit test for constructor of class Choice
def test_Choice():
    ch = Choice()
    res = ch.__call__(items=['a', 'b', 'c'], length=1)
    assert isinstance(res,list)
    assert len(res) == 1
    assert res[0] in ['a', 'b', 'c']
    res = ch.__call__(items=('a', 'b', 'c'), length=1)
    assert isinstance(res,tuple)
    assert len(res) == 1
    assert res[0] in ['a', 'b', 'c']
    res = ch.__call__(items='abc', length=1)
    assert isinstance(res,str)
    assert len(res) == 1
    assert res in ['a', 'b', 'c']

# Generated at 2022-06-23 21:16:21.272215
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice('seed')
    assert c is not None


# Generated at 2022-06-23 21:16:28.729877
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) != 'c'
    assert choice(items=['a', 'b', 'c'], length=1) != ['a']
    assert choice(items='abc', length=2) != 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) != ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) != 'cdba'

# Generated at 2022-06-23 21:16:30.013943
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert isinstance(c, Choice)

# Generated at 2022-06-23 21:16:32.941338
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    results = c(items=('a', 'b', 'c'), length=5)
    assert len(results) == 5

test = Choice()
len(test(items='abc', length=2)) == 2

# Generated at 2022-06-23 21:16:34.335827
# Unit test for constructor of class Choice
def test_Choice():
    Choice()



# Generated at 2022-06-23 21:16:41.961350
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:16:53.468360
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    expected = "**length** must be integer."
    try:
        choice(items='abc', length='a')
    except TypeError as exception:
        assert str(exception) == expected

# Generated at 2022-06-23 21:17:01.973291
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert (c(['a', 'b', 'c']) in ['a', 'b', 'c'])
    assert (c(['a', 'b', 'c'], 1) in [('a',), ('b',), ('c',)])
    assert (c(['a', 'b', 'c'], 2) in [('a', 'b'), ('a', 'c'), ('b', 'a'), ('b', 'c'), ('c', 'a'), ('c', 'b')])

# Generated at 2022-06-23 21:17:02.688512
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice is not None

test_Choice()

# Generated at 2022-06-23 21:17:07.316056
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:17:09.220883
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice.__doc__ is not None


# Generated at 2022-06-23 21:17:16.956783
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'a'
    assert choice(items=['a', 'b', 'c'], length=1) == ['b']
    assert choice(items='abc', length=2) == 'ac'
    assert choice(items=('a', 'b', 'c'), length=5) == ('b', 'c', 'c', 'c', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'dbcb'

# Generated at 2022-06-23 21:17:26.157979
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    try:
        choice = Choice()
        assert choice(items=['a', 'b', 'c']) == 'c'
        assert choice(items=['a', 'b', 'c'], length=1) == ['a']
        assert choice(items='abc', length=2) == 'ba'
        assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
        assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    except (TypeError, ValueError):
        assert False

# Generated at 2022-06-23 21:17:27.504952
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice is not None


# Generated at 2022-06-23 21:17:37.675492
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method __call__ of class Choice."""
    choice = Choice()
    result = choice(items = ['a', 'b', 'c'])
    assert result == 'c'
    result = choice(items = ['a', 'b', 'c'], length = 1)
    assert result == ['a']
    result = choice(items = 'abc', length = 2)
    assert result == 'ba'
    result = choice(items = ('a', 'b', 'c'), length = 5)
    assert result == ('c', 'a', 'a', 'b', 'c')
    result = choice(items = 'aabbbccccddddd', length = 4, unique = True)
    assert result == 'cdba'



# Generated at 2022-06-23 21:17:41.038624
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    s = ['a', 'b', 'c']
    assert choice(items=s, length=1) == ['a']
    assert not isinstance(choice(items='abc', length=2), tuple)



# Generated at 2022-06-23 21:17:50.398085
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    result = choice(items=['a', 'b', 'c'])
    assert isinstance(result, str)
    assert result in ['a','b','c']

    result = choice(items=['a', 'b', 'c'], length=1)
    assert isinstance(result, list)
    assert result in [['a'],['b'],['c']]

    result = choice(items='abc', length=2)
    assert isinstance(result, str)
    assert result in ['ab', 'ac', 'ba', 'bc', 'ca', 'cb']

    result = choice(items=('a', 'b', 'c'), length=5)
    assert isinstance(result, tuple)

# Generated at 2022-06-23 21:17:54.192936
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    _items = ['a', 'b', 'c']
    _length = 3
    _unique = 0
    c = Choice()
    _result = c(items=_items, length=_length, unique=_unique)
    if not _result:
        raise ValueError('result of choice.__call__ cannot be empty.')


# Generated at 2022-06-23 21:18:03.911731
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    assert isinstance(choice(items=['a', 'b', 'c']), str)
    assert isinstance(choice(items=['a', 'b', 'c'], length=1), list)
    assert isinstance(choice(items='abc', length=2), str)
    assert isinstance(choice(items=('a', 'b', 'c'), length=5), tuple)
    assert isinstance(choice(items='aabbbccccddddd', length=4, unique=True), str)

    with pytest.raises(TypeError):
        choice(items=['a', 'b', 'c'], length='abc')

    with pytest.raises(TypeError):
        choice(items=1, length=4)


# Generated at 2022-06-23 21:18:12.604855
# Unit test for constructor of class Choice
def test_Choice(): 
    my_choice = Choice()
    print(my_choice(items=['a', 'b', 'c']))
    print(my_choice(items=['a', 'b', 'c'], length=1))
    print(my_choice(items='abc', length=2))
    print(my_choice(items=('a', 'b', 'c'), length=5))
    print(my_choice(items='aabbbccccddddd', length=4, unique=True))
    print(my_choice('abc', 2))
    # print(my_choice(2,2)) # TypeError: choice() takes 1 positional argument but 2 were given
test_Choice()


# Generated at 2022-06-23 21:18:19.293167
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method Choice.__call__().

    Tests method Choice.__call__() with the following cases:
        * default
        * length = 1
        * length = 2
        * length = 5
        * unique = True
    """
    choice = Choice()

    items = ['a', 'b', 'c']
    items2 = ['a', 'b', 'c', 'c']
    items3 = ['a', 'b', 'c', 'a', 'b', 'c']
    items4 = ['a', 'b', 'c', 'a', 'b', 'c', 'c']

    assert choice(items) in items
    assert choice(items, length=1) == ['a']
    assert choice(items, length=2) in ['ab', 'ac', 'ba', 'bc', 'ca', 'cb']
    assert choice

# Generated at 2022-06-23 21:18:26.221004
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test __call__ of class Choice."""

    from mimesis.providers.helpers import Choice as ch
    choice = ch()
    items = ['a', 'b', 'c']
    length = 1
    unique = False 
    
    print(choice(items,length,unique))
    #print(choice(items,length,unique) == True)
    assert choice(items,length,unique) == True
    print(choice(items,length,unique) == True)

# Generated at 2022-06-23 21:18:29.381625
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    choice(items=['a', 'b', 'c'], length=1)

# Generated at 2022-06-23 21:18:33.185307
# Unit test for constructor of class Choice
def test_Choice():
    items = ['a', 'b', 'c']
    length = 1
    unique = True
    choice = Choice()
    choice_result = choice(items,length, unique)
    for i in range(len(choice_result)):
        print(choice_result[i], end='')


# Generated at 2022-06-23 21:18:41.701308
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import string
    from mimesis.enums import Gender
    from mimesis.providers.person.en import Provider as PersonEN

    choice = Choice()

    items = ['foo', 'bar', 'spam']
    assert choice(items) in items
    assert choice(items, 2) in [('foo', 'bar'), ('foo', 'spam'), ('bar', 'spam')]

    items = ['a', 'b']
    assert choice(items, 3, unique=True) in [('a', 'b', 'a'), ('a', 'b', 'b')]

    assert choice(items, 3, unique=True) not in [('a', 'a', 'a'), ('b', 'b', 'b')]

    items = string.ascii_lowercase
    assert choice(items, unique=True) in items

   

# Generated at 2022-06-23 21:18:43.371229
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)

# Generated at 2022-06-23 21:18:46.189244
# Unit test for constructor of class Choice
def test_Choice():
    cImpl = Choice()
    # Call this method for testing
    cImpl(items=['a', 'b', 'c'], length=1)

# Generated at 2022-06-23 21:18:48.316374
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    data = Choice()
    assert data("abc") in ("a", "b", "c")
    assert data("abc", 3) in (("a", "b", "c"), ("a", "b"), ("a", "c"), ("b", "c"))



# Generated at 2022-06-23 21:18:58.672413
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice.seed == 42

    # class attributes
    assert isinstance(choice.name, str)
    assert choice.name == 'choice'
    assert isinstance(choice.seed_attr_name, str)
    assert choice.seed_attr_name == 'seed'
    assert isinstance(choice.providers, dict)
    assert choice.providers == {}

    # instance attributes
    assert isinstance(choice._random, object)
    assert isinstance(choice._providers, dict)
    assert choice._providers == {}
    assert isinstance(choice._meta, object)
    assert choice._meta.name == 'choice'
    assert isinstance(choice._meta.provider_name, str)
    assert choice._meta.provider_name == 'choice'

# Generated at 2022-06-23 21:19:05.719489
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ('a', 'b', 'c')
    length = 5
    unique = False
    assert type(Choice.Meta.name) == str, "Атрибут класса не является строкой"
    assert items, "Sequence is empty!"
    assert length > 0, "Атрибут length должен быть больше нуля"
    assert unique, "Τhe attribute unique must be a boolean value"
    assert isinstance(items, collections.abc.Sequence)
    assert isinstance(length, int)
    assert isinstance(unique, bool)