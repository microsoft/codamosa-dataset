

# Generated at 2022-06-23 21:09:01.525675
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice(1)
    assert c.seed == 1

# Unit tests for __call__ of class Choice

# Generated at 2022-06-23 21:09:06.758682
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method __call__ of class Choice."""
    choice = Choice()
    assert choice('a', 'b', 'c') in ['a', 'b', 'c']
    assert choice('a', 'b', 'c', length=1) in [['a'], ['b'], ['c']]
    assert choice('a', 'b', 'c', length=2) in ['ab', 'ba', 'ac', 'ca', 'bc',
                                               'cb']
    assert choice('a', 'b', 'c', length=3) in ['abc', 'acb', 'bac', 'bca',
                                               'cab', 'cba']

# Generated at 2022-06-23 21:09:17.794381
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    try:
        Choice().__call__(items=['a', 'b', 'c'], length='3')
        assert False
    except TypeError:
        assert True
    except ValueError:
        assert False

# Generated at 2022-06-23 21:09:28.580741
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ab', 'bc', 'ac']

# Generated at 2022-06-23 21:09:31.232286
# Unit test for constructor of class Choice
def test_Choice():
    ch = Choice()
    element = ch(['a','b','c'])
    assert element == 'a' or element == 'b' or element == 'c'  

# Generated at 2022-06-23 21:09:33.177090
# Unit test for constructor of class Choice
def test_Choice():
    result = Choice.__init__(Choice, (), {},)
    assert len(result) == 0


# Generated at 2022-06-23 21:09:34.258364
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert c.__class__.__name__ == 'Choice'



# Generated at 2022-06-23 21:09:37.400692
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()

    items = c('aabbbccccddddd', 4, unique=True)
    assert len(items) == 4 and (len(set(items)) == 1 or len(set(items)) == 4)

# Generated at 2022-06-23 21:09:41.857896
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice(seed=12432)
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-23 21:09:43.588710
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)


# Generated at 2022-06-23 21:09:45.998871
# Unit test for constructor of class Choice
def test_Choice():
    """Test for Choice constructor."""
    c = Choice()
    assert c


# Generated at 2022-06-23 21:09:46.646659
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-23 21:09:56.483701
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice(items=[1, 2, 3]) in [1, 2, 3]
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) in ['ba', 'ab', 'bc']
    assert choice(items=('a', 'b', 'c'), length=5) in [
        ('c', 'a', 'a', 'b', 'c'),
        ('a', 'c', 'c', 'c', 'b'),
        ('b', 'a', 'c', 'a', 'c'),
    ]

# Generated at 2022-06-23 21:09:57.284170
# Unit test for constructor of class Choice
def test_Choice():
    a = Choice()
    assert isinstance(a, Choice)


# Generated at 2022-06-23 21:10:00.768681
# Unit test for constructor of class Choice
def test_Choice():
    x = Choice()
    assert x('foo') in ('f', 'o')
    assert x('foo', length=1) in ('f', 'o', 'fo')
    assert len(x('foo', length=3)) == 3

# Generated at 2022-06-23 21:10:11.594097
# Unit test for constructor of class Choice
def test_Choice():
    test1 = Choice()
    assert test1.random.choice(['a', 'b', 'c']) in ['a', 'b', 'c']
    assert test1.random.choice(('a', 'b', 'c')) in ('a', 'b', 'c')
    assert test1.random.choice('abc') in 'abc'
    assert test1.random.choice(['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]

# Generated at 2022-06-23 21:10:23.209808
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert c(items=['a', 'b', 'c'], length=10) == ['b', 'c', 'a', 'b', 'c', 'a', 'a', 'b', 'c', 'c']
    assert c(items=['a', 'b', 'c'], length=10, unique=True) == ['a', 'c', 'b', 'b', 'a', 'a', 'c', 'c', 'b', 'a']
    assert c(items=['a', 'b', 'c'], length=0) == 'c'
    assert c(items=['a', 'b', 'c'], length=1) == ['c']
    assert c(items='abc', length=2) == 'ba'

# Generated at 2022-06-23 21:10:25.032909
# Unit test for constructor of class Choice
def test_Choice():
    provider = Choice('en')
    print("constructor of class Choice: ", provider)


# Generated at 2022-06-23 21:10:29.433034
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert(isinstance(c(items=[1, 2, 3], length=0), int))
    assert(isinstance(c(items='abc', length=2), str))
    assert(isinstance(c(items=('a', 'b', 'c'), length=2), tuple))

# Generated at 2022-06-23 21:10:38.640087
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import pytest
    from mimesis.enums import Gender, TargetType
    from mimesis.providers.choice import Choice
    from mimesis.typing import Seed
    from mimesis.utils import get_locale

    # Initialize seed
    seed = Seed.random()

    provider = Choice(seed)
    type_ = provider.random.choice([TargetType.HOST, TargetType.PATH, TargetType.URI])
    assert isinstance(provider(items=(1, 2, 3, 4), length=0), int)
    assert isinstance(provider(items=(1, 2, 3, 4), length=1), list)
    assert isinstance(provider(items=(1, 2, 3, 4), length=3), tuple)

# Generated at 2022-06-23 21:10:44.751029
# Unit test for constructor of class Choice
def test_Choice():
    # TODO: Add asserts for tests
    choice = Choice()
    print(choice(items=['a', 'b', 'c']))
    print(choice(items=['a', 'b', 'c'], length=1))
    print(choice(items='abc', length=2))
    print(choice(items=('a', 'b', 'c'), length=5))
    print(choice(items='aabbbccccddddd', length=4, unique=True))

# Generated at 2022-06-23 21:10:54.168247
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis import Choice
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 5
    unique = False
    choice(items=items, length=length, unique=unique)
    items = ['a', 'b', 'c']
    length = 0
    unique = False
    choice(items=items, length=length, unique=unique)
    items = ['a', 'b', 'c']
    length = 0
    unique = True
    choice(items=items, length=length, unique=unique)
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    choice(items=items, length=length, unique=unique)
    items = 'abc'
    length = 1
    unique = False

# Generated at 2022-06-23 21:10:59.370445
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    c = Choice()
    assert c(items=['a', 'b', 'c']) == 'c'
    assert c(items=['a', 'b', 'c'], length=1) == ['a']
    assert c(items='abc', length=2) == 'ba'
    assert c(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert c(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:11:03.560544
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Initialize the class for testing
    choice = Choice()

    # Use the class method
    result = choice(items=['a', 'b', 'c'])
    
    # Check the result
    assert (result in ['a', 'b', 'c'])


# Generated at 2022-06-23 21:11:11.747052
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()

    items = ['a', 'b', 'c', 'd', 'e']
    length = 10
    unique = True
    choice = c(items=items, length=length, unique=unique)
    assert isinstance(choice, str)
    assert len(choice) == length
    for letter in items:
        assert letter in choice

    items = list(range(10))
    length = 20
    unique = False
    choice = c(items=items, length=length, unique=unique)
    assert isinstance(choice, list)
    assert len(choice) == length
    for item in items:
        assert item in choice

    c = Choice()
    items = 'abcd'
    length = 5
    unique = False
    choice = c(items=items, length=length, unique=unique)

# Generated at 2022-06-23 21:11:18.223772
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice(items=[1, 2, 3]) == 1
    assert choice(items=[1, 2, 3], length=1) == [1]
    assert choice(items='abc', length=2) == 'ab'
    assert choice(items=(1, 2, 3), length=5) == (1, 2, 1, 3, 2)
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'dcba'

# Generated at 2022-06-23 21:11:28.897181
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    class MyChoice(Choice):
        """Custom choice class."""

        def __init__(self, seed):
            """Initialize attributes."""
            super().__init__(seed=seed)
            self.seed = seed

        def __eq__(self, other):
            """Compare two objects."""
            return isinstance(other, self.__class__)

    seed = int(time.time())
    choice1 = MyChoice(seed)
    choice2 = MyChoice(seed)
    assert choice1 == choice2
    assert choice1.seed == choice2.seed
    assert choice1.choice() == choice2.choice()
    assert choice1.choice(['cat', 'dog']) == choice2.choice(['cat', 'dog'])

# Generated at 2022-06-23 21:11:34.741782
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-23 21:11:41.862848
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice()._Choice__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice()._Choice__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice()._Choice__call__(items='abc', length=2) == 'ba'
    assert Choice()._Choice__call__(items=('a', 'b', 'c'), length=5) == (
        'c', 'a', 'a', 'b', 'c')
    assert Choice()._Choice__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-23 21:11:49.967816
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    # case 1
    items = ['a','b','c']
    print(choice(items=items))

    # case 2
    items = ['a','b','c']
    print(choice(items=items, length=1))

    # case 3
    items = 'abc'
    print(choice(items=items, length=2))
    print(choice(items=('a', 'b', 'c'), length=5))
    print(choice(items='aabbbccccddddd', length=4, unique=True))

# Generated at 2022-06-23 21:11:54.643592
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'b'
    assert choice(items=['a', 'b', 'c'],length=1) == ['b']
    assert choice(items='abc',length=2) == 'bc'
    assert choice(items=('a', 'b', 'c'),length=5) == ('c', 'a', 'b', 'c', 'a')
    assert choice(items='aabbbccccddddd',length=4,unique=True) == 'bdca'

# Generated at 2022-06-23 21:12:00.658469
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    c0 = choice(items=['a', 'b', 'c'])
    assert c0 == 'c'
    c1 = choice(items=['a', 'b', 'c'], length=1)
    assert c1 == ['a']
    c2 = choice(items='abc', length=2)
    assert c2 == 'ba'
    c3 = choice(items=('a', 'b', 'c'), length=5)
    assert c3 == ('c', 'a', 'a', 'b', 'c')
    c4 = choice(items='aabbbccccddddd', length=4, unique=True)
    assert c4 == 'cdba'

    # Test for exception of constructor of class Choice

# Generated at 2022-06-23 21:12:01.357680
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice().__class__ == Choice

# Generated at 2022-06-23 21:12:01.941690
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choic

# Generated at 2022-06-23 21:12:04.837062
# Unit test for constructor of class Choice
def test_Choice():
    """Test for method Choice"""
    choice = Choice()
    assert callable(choice)



# Generated at 2022-06-23 21:12:09.469015
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # from mimesis import Choice
    # Get items and length
    items = [1,2,3]
    length = 1
    # Create an instance of the Choice class
    choice = Choice()
    # Run method __call__ 
    choice_result = choice.__call__(items,length)
    print(choice_result)

# Generated at 2022-06-23 21:12:11.770712
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    choices1 = choice(items=['a', 'b', 'c'])
    assert choices1


# Generated at 2022-06-23 21:12:15.097381
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    ch = Choice()
    items = 'abcdef'
    lenght = 4
    random = ''.join(ch(items=items, length=lenght))
    assert len(random) == lenght
    
test_Choice___call__()

# Generated at 2022-06-23 21:12:26.491301
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    obj = Choice()
    res = obj(items=['a', 'b', 'c'])
    assert res in ['a', 'b', 'c']

    res1 = obj(items=['a', 'b', 'c'], length=1)
    assert res1 == ['a']

    res2 = obj(items='abc', length=2)
    assert res2 in ['ba', 'ab', 'cb', 'ac', 'bc']

    res3 = obj(items=('a', 'b', 'c'), length=5)
    assert res3 == ('c', 'a', 'a', 'b', 'c')

    res4 = obj(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-23 21:12:35.664903
# Unit test for method __call__ of class Choice

# Generated at 2022-06-23 21:12:43.004175
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import random
    import string
    rand_choices = []
    for _ in range(10):
        rand_items = [random.choice(string.ascii_letters) for _ in range(10)]
        rand_choice = random.choice(rand_items)
        rand_choices.append(rand_choice)
        assert Choice()(items=rand_items) == rand_choice
        assert Choice()(items=rand_items, length=1) == [rand_choice]
        assert Choice()(items=''.join(rand_items), length=1) == rand_choice
        assert Choice()(items=tuple(rand_items), length=1) == (rand_choice,)
        assert Choice()(items=rand_items, length=1, unique=True) == [rand_choice]

# Generated at 2022-06-23 21:12:45.149763
# Unit test for constructor of class Choice
def test_Choice():
    data = "Привет"
    assert Choice.__init__(data) != None
# Test for Choice data

# Generated at 2022-06-23 21:12:52.420100
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Setup
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 1

    # Exercise
    assert choice(items=items) in ['a', 'b', 'c']
    assert choice(items=items, length=length) == ['a']
    assert choice(items='abc', length=2) in ['ab', 'bc', 'ac']
    assert len(choice(items=('a', 'b', 'c'), length=5)) == 5
    assert len(choice(items='aabbbccccddddd', length=4, unique=True)) == 4



# Generated at 2022-06-23 21:12:59.980841
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    sequence = ('a', 'b', 'c')
    length = 3
    unique = True
    result = choice.__call__(sequence, length, unique)
    assert isinstance(result, str)

    sequence = ('a', 'b', 'c')
    length = 3
    unique = False
    result = choice.__call__(sequence, length, unique)
    assert isinstance(result, tuple)

    sequence = [1, 2, 3]
    length = 3
    unique = False
    result = choice.__call__(sequence, length, unique)
    assert isinstance(result, list)

    sequence = 'abc'
    length = 3
    unique = False
    result = choice.__call__(sequence, length, unique)
    assert isinstance(result, str)


# Generated at 2022-06-23 21:13:08.607704
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    from typing import List
    itemList: List[str]
    itemList = ["a", "b", "c"]
    assert Choice().__call__(items=itemList, length=1) == itemList

    from typing import List
    itemList: List[str]
    itemList = ["a", "b", "c"]
    assert Choice().__call__(items=itemList, length=3) == itemList

    from typing import List
    itemList: List[str]
    itemList = ["a", "b", "c"]
    assert Choice().__call__(items=itemList, length=3) == itemList

    from typing import List
    itemList: List[str]
    itemList = ["a", "b", "c"]
    assert Choice().__call__(items=itemList, length=3) == itemList

# Generated at 2022-06-23 21:13:09.879490
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)


# Generated at 2022-06-23 21:13:20.310381
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    import pytest

    from mimesis.builtins import Choice, ChoiceError

    choice = Choice(seed=1)
    # Test, when items is not a sequence
    with pytest.raises(TypeError):
        choice(items=1, length=1)

    # Test, when items is empty
    with pytest.raises(ValueError):
        choice(items=[], length=1)

    # Test, when length is not a positive integer
    with pytest.raises(ValueError):
        choice(items=(0, 1), length=-1)
    with pytest.raises(TypeError):
        choice(items=(0, 1), length=None)

    # Test, when unique is True and items have no unique elements

# Generated at 2022-06-23 21:13:21.578670
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice() is not None

# Generated at 2022-06-23 21:13:23.242835
# Unit test for constructor of class Choice
def test_Choice():
    import random
    print(Choice())
    print(Choice(random.Random(2)))


# Generated at 2022-06-23 21:13:24.709673
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(['a', 'b', 'c'])


# Generated at 2022-06-23 21:13:29.826622
# Unit test for method __call__ of class Choice

# Generated at 2022-06-23 21:13:39.598952
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    test_Choice = Choice()
    test_choice_ = test_Choice(items=['a', 'b', 'c'])
    assert isinstance(test_choice_, str)
    test_choice_ = test_Choice(items=['a', 'b', 'c'], length=1)
    assert isinstance(test_choice_, list)
    test_choice_ = test_Choice(items='abc', length=2)
    assert isinstance(test_choice_, str)
    test_choice_ = test_Choice(items=('a', 'b', 'c'), length=5)
    assert isinstance(test_choice_, tuple)
    test_choice_ = test_Choice(items='aabbbccccddddd', length=4, unique=True)
    assert isinstance(test_choice_, str)
   

# Generated at 2022-06-23 21:13:46.433219
# Unit test for constructor of class Choice
def test_Choice():
    # Test length : 0
    assert Choice()(items=[1, 2, 3, 4]) in [1, 2, 3, 4]
    assert Choice()(items=[1, 2, 3, 4], length=0) in [1, 2, 3, 4]

    # Test length : positive
    assert Choice()(items=[1, 2, 3, 4], length=1) == [1]
    assert Choice()(items=[1, 2, 3, 4], length=2) == [2, 1] or [1, 2]
    assert Choice()(items=[1, 2, 3, 4], length=3) == [1, 3, 4] or [2, 1, 3] or [4, 2, 1]
    assert Choice()(items=[1, 2, 3, 4], length=4) == [4, 3, 2, 1]

# Generated at 2022-06-23 21:13:47.139802
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass



# Generated at 2022-06-23 21:13:55.841224
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    from mimesis.schema import Field
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=('a', 'b', 'c')) in ['a', 'b', 'c']
    assert choice(items='abc') in ['a', 'b', 'c']
    assert choice(items=(1, 2, 3)) in [1, 2, 3]
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=1) in ['a', 'b', 'c']

# Generated at 2022-06-23 21:14:07.170547
# Unit test for method __call__ of class Choice
def test_Choice___call__():  # TODO: Add assert for all cases.
    # TODO: Remove all such cases.
    items = [1, 2, 3, 2, 4, 2, 8, 2]
    length = 3
    unique = True

    # TODO: Add more such cases.
    data = Choice().__call__(items=items, length=length, unique=unique)
    print(data)
    assert isinstance(data, list)

    # TODO: Add more such cases.
    items = (1, 2, 3, 2, 4, 2, 8, 2)
    data = Choice().__call__(items=items, length=length, unique=unique)
    print(data)
    assert isinstance(data, tuple)

    # TODO: Add more such cases.
    items = '123242822'
    data = Choice().__

# Generated at 2022-06-23 21:14:08.198320
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice()

# Generated at 2022-06-23 21:14:18.727583
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert c(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert c(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert c(items='abc', length=2) in ['ab', 'ac', 'bc']

# Generated at 2022-06-23 21:14:21.135597
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TODO: Add unit tests for Choice.__call__
    raise NotImplementedError

# Generated at 2022-06-23 21:14:27.448201
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from hypothesis import given
    from hypothesis.strategies import integers, text
    from mimesis import Choice

    choice = Choice()
    # TODO: Fix this test
    # @given(items=text(min_size=1), length=integers(min_value=0), unique=False)
    # def test_Choice___call__(
    #    items: str, length: int, unique: bool
    # ) -> None:
    #    assert len(choice(items=items, length=length, unique=unique)) <=
    #    length
    #

# Generated at 2022-06-23 21:14:36.763701
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test class Choice to method __call__

    :return: None
    """
    print('Test class Choice to method __call__')
    choice = Choice()
    assert isinstance(choice.__call__(length=0, items=['a', 'b', 'c']), object)
    assert isinstance(choice.__call__(length=1, items=['a', 'b', 'c']), list)
    assert isinstance(choice.__call__(length=2, items='abc'), object)
    assert isinstance(choice.__call__(length=5, items=('a', 'b', 'c')), tuple)
    assert isinstance(choice.__call__(length=4, items='aabbbccccddddd', unique=True), object)


# Generated at 2022-06-23 21:14:43.772365
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice._instance_type == "Choice"
    assert choice.random._instance_type == "Random"
    choice_2 = Choice()
    assert choice_2._instance_type == "Choice"
    assert choice_2.random._instance_type == "Random"
    assert choice_2._seed is None
    assert choice_2.__class__._seed is None
    assert choice_2.random._seed is None
    assert choice_2.random.__class__._seed is None


# Generated at 2022-06-23 21:14:53.585207
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from .random import Random
    random = Random()
    choice = Choice(random)
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    assert choice(items=items, length=length, unique=unique) == ['a']
    items1 = 'abc'
    length1 = 2
    unique1 = False
    assert choice(items=items1, length=length1, unique=unique1) == 'ba'
    items2 = ('a', 'b', 'c')
    length2 = 5
    unique2 = False
    assert choice(items=items2, length=length2, unique=unique2) == ('c', 'a', 'a', 'b', 'c')
    items3 = 'aabbbccccddddd'
    length3 = 4
    unique3 = True
   

# Generated at 2022-06-23 21:15:00.669659
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert callable(c)
    assert c('test') in ['test']
    assert c(['test'], 2) in ['test']
    assert len(c(['test1', 'test2'], 4)) == 4
    assert len(c(list('test1test2'), 4)) == 4

    # test wrong types
    try:
        c([], -1)
    except ValueError:
        pass
    try:
        c([], 0.0)
    except TypeError:
        pass
    try:
        c((), 'test')
    except TypeError:
        pass
    try:
        c({}, 2)
    except TypeError:
        pass
    try:
        c('', 2)
    except TypeError:
        pass

    # test unique

# Generated at 2022-06-23 21:15:07.147108
# Unit test for constructor of class Choice
def test_Choice():
    data = Choice()
    test1 = data(items=['a', 'b', 'c'])
    test2 = data(items=['a', 'b', 'c'], length=1)
    test3 = data(items='abc', length=2)
    test4 = data(items=('a', 'b', 'c'), length=5)
    test5 = data(items='aabbbccccddddd', length=4, unique=True)
    print("Success")


# Generated at 2022-06-23 21:15:13.404095
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice('abc', 2, True), str)
    assert isinstance(choice(['a', 'b', 'c'], 3, True), list)
    assert isinstance(choice(('a', 'b', 'c'), 3, True), tuple)

    try:
        choice(items=['a', 'b', 'c'], length=1.1)
        raise AssertionError('TypeError was not raised.')
    except TypeError:
        pass

    try:
        choice(items={}, length=1)
        raise AssertionError('TypeError was not raised.')
    except TypeError:
        pass


# Generated at 2022-06-23 21:15:14.146140
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert isinstance(c, Choice)


# Generated at 2022-06-23 21:15:19.848158
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    assert type(choice('abcd'))==str
    assert type(choice(['a', 'b', 'c'], length=0))==str
    assert type(choice(['a', 'b', 'c'], length=1))==list
    assert type(choice('abc', length=2))==str
    assert type(choice(('a', 'b', 'c'), length=5))==tuple
    assert type(choice('aabbbccccddddd', length=4, unique=True))==str
    try:
        choice(items=('a', 'b', 'c'), length=5, unique=True)
    except:
        print('test_Choice___call__ 1 success.')

# Generated at 2022-06-23 21:15:21.933208
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c'], length=1) == ['b']

# Generated at 2022-06-23 21:15:32.293863
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # 1. Test for non-sequence items or non-integer length.
    choice = Choice()

    try:
        choice(items={'a': 1, 'b': 2, 'c': 3})
    except TypeError as exception:
        assert str(exception) == '**items** must be non-empty sequence.'

    try:
        choice(items=['a', 'b', 'c'], length=1.5)
    except TypeError as exception:
        assert str(exception) == '**length** must be integer.'

    # 2. Test for negative length or insufficient unique elements.
    try:
        choice(items=['a', 'b', 'c'], length=-1)
    except ValueError as exception:
        assert str(exception) == '**length** should be a positive integer.'


# Generated at 2022-06-23 21:15:44.132176
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    import pytest
    with pytest.raises(TypeError): choice(items=['a', 'b', 'c'], length=1.0)
    with pytest.raises(TypeError): choice(items={'a', 'b', 'c'})

# Generated at 2022-06-23 21:15:45.080909
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice is not None

# Generated at 2022-06-23 21:15:45.891012
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method _Choice__call of class Choice."""
    assert True

# Generated at 2022-06-23 21:15:47.186720
# Unit test for constructor of class Choice
def test_Choice():
    test = Choice()
    assert isinstance(test, Choice)

# Generated at 2022-06-23 21:15:54.505673
# Unit test for constructor of class Choice
def test_Choice():
    # constructor of Choice
    choice = Choice()

    # Generate a randomly-chosen sequence or bare element from a sequence.
    # Provide elements randomly chosen from the elements in a sequence items,
    # where when length is specified the random choices are contained in a
    # sequence of the same type of length length, otherwise a single
    # uncontained element is chosen. If unique is set to True, constrain a
    # returned sequence to contain only unique elements.
    choice(items=['a', 'b', 'c'])
    choice(items=['a', 'b', 'c'], length=1)
    choice(items='abc', length=2)
    choice(items=('a', 'b', 'c'), length=5)
    choice(items='aabbbccccddddd', length=4, unique=True)

    # TypeError

# Generated at 2022-06-23 21:15:57.375314
# Unit test for constructor of class Choice
def test_Choice():
    x = [1,2,3]
    x_length = 5
    x_unique = True
    print(Choice().__call__(x,x_length,x_unique))

# Generated at 2022-06-23 21:16:00.703429
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    choice = Choice(seed=42).choice
    result = choice(items=items, length=length, unique=unique)
    assert result == ['b']


# Generated at 2022-06-23 21:16:01.365734
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-23 21:16:10.168384
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert c(items=['a', 'b', 'c']) in ('c', 'a', 'b')
    assert c(items=['1', '2', '3'], length=1) in (['1'], ['2'], ['3'])
    assert c(items='abc', length=2) in ('ba', 'cb', 'ac')
    assert c(items=('a', 'b', 'c'), length=5) in (('c', 'a', 'a', 'b', 'c'),
                                                  ('c', 'a', 'b', 'c', 'a'),
                                                  ('c', 'b', 'a', 'c', 'a'))

# Generated at 2022-06-23 21:16:11.639145
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice().__class__.__name__ == "Choice"

# Generated at 2022-06-23 21:16:13.700618
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    result = choice(items=['a', 'b', 'c'])
    assert result == 'c'

# Generated at 2022-06-23 21:16:24.113774
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ab', 'bc', 'ac']

# Generated at 2022-06-23 21:16:32.657394
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    from hypothesis import given
    from hypothesis.strategies import integers

    @given(integers(min_value=0, max_value=3))
    def test_choice(length):
        data = choice(items=['a', 'b', 'c', 'd'], length=length)
        assert isinstance(data, list)
        assert len(data) == length
        if len(data) > 0:
            assert all(item in ['a', 'b', 'c', 'd'] for item in data)

    test_choice()
    test_choice()
    test_choice()

test_Choice___call__()

# Generated at 2022-06-23 21:16:37.988232
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    try:
        result = Choice().__call__(items=['a', 'b', 'c'], length=1)
        assert result == ['b']
    except Exception as e:
        print('Error: {}, {}, {}'.format(e.__str__(), 'test_Choice___call__', '未通过'))



# Generated at 2022-06-23 21:16:44.731315
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from io import StringIO
    import sys
    import unittest

    from mimesis import Choice

    class ChoiceTestCase(unittest.TestCase):

        def setUp(self) -> None:
            self.seed(0)
            self.choice = Choice()

        def tearDown(self) -> None:
            pass

        def seed(self, seed: int = None) -> None:
            self.choice.random.seed(seed)

        def test___call___unique(self) -> None:
            self.assertEqual(self.choice(items=['a', 'b', 'c'],
                                         length=3, unique=True),
                             'cba')

# Generated at 2022-06-23 21:16:54.654405
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) in ('a', 'b', 'c')
    assert choice(items=['a', 'b', 'c'], length=1) == ['b']
    assert choice(items='abc', length=2) in ('ab', 'ac', 'ba', 'bc', 'ca', 'cb')

# Generated at 2022-06-23 21:17:03.024446
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    result=choice(items=['a', 'b', 'c'])
    assert result in ['a', 'b', 'c'], f'{result} not in [a, b, c]'
    result=choice(items=['a', 'b', 'c'], length=1)
    assert (isinstance(result, list) and len(result)==1 and result[0] in ['a', 'b', 'c']), f'{result} not in [a, b, c]'
    result=choice(items='abc', length=2)
    assert (isinstance(result, str) and len(result)==2 and result[0] in ['a', 'b', 'c'] and result[1] in ['a', 'b', 'c']), f'{result} not in [a, b, c]'

# Generated at 2022-06-23 21:17:03.624281
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert(choice is not None)

# Generated at 2022-06-23 21:17:05.569325
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    items = ['a','b','c','d','e','f']
    item = choice(items)
    assert item in items

# Generated at 2022-06-23 21:17:16.386408
# Unit test for constructor of class Choice
def test_Choice():

    items = ['a', 'b', 'c']
    length = 2
    unique = True

    choice = Choice(items, length, unique)

    choices = choice(items=['a', 'b', 'c'])
    choices = choice(items=['a', 'b', 'c'], length=1)
    choices = choice(items='abc', length=2)
    choices = choice(items=('a', 'b', 'c'), length=5)
    choices = choice(items='aabbbccccddddd', length=4, unique=True)

    # TODO: Finish this test case
    # choices = choice(items=['a', 'b', 'c'], length=length, unique=unique)

# Generated at 2022-06-23 21:17:17.228969
# Unit test for constructor of class Choice
def test_Choice():
    pass


# Generated at 2022-06-23 21:17:27.794522
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) in ['ba', 'ab', 'cb']
    assert choice(items=('a', 'b', 'c'), length=5) in [('c', 'a', 'a', 'b', 'c'),('a', 'a', 'b', 'c', 'c'),('c', 'a', 'b', 'c', 'a')]

# Generated at 2022-06-23 21:17:29.518843
# Unit test for constructor of class Choice
def test_Choice():
    """Test Choice constructor."""
    obj = Choice()
    assert obj

# Generated at 2022-06-23 21:17:32.066593
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert c.choice(["a","b","c"],length=1) == "b"


# Generated at 2022-06-23 21:17:36.125016
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice('en')
    c('abc')
    c('abc', 1)
    c('abc', 2)
    c(['a', 'b', 'c'], 3)
    c(['a', 'b', 'c'], 3, True)

# Generated at 2022-06-23 21:17:46.355917
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from hypothesis import given
    from hypothesis.strategies import (
        text,
        frozensets,
        lists,
        tuples,
    )
    from mimesis import Choice
    c = Choice()

    @given(text())
    def test_choice(s: str) -> None:
        assert c(s) in s
        assert c(s, length=1) in (['a'], ['b'], ['c'])
        assert c(s, length=2) in ('ba', 'ac', 'cb')
        assert c(s, length=3) in ('cba', 'abc', 'bac')

    @given(lists(elements=text()))
    def test_list(l: list) -> None:
        assert c(l) in l

# Generated at 2022-06-23 21:17:51.223186
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    ch = Choice()
    items=['a','b','c']
    length=2
    unique=False
    result = ch(items,length,unique)
    print("Unit test for method __call__ of class Choice")
    print("The result is:", result)
    print("=======================================\n")

# test_Choice___call__()


# Generated at 2022-06-23 21:18:02.085873
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(['a', 'b', 'c'],'')!=''
    assert isinstance(Choice().__call__(['a', 'b', 'c'],'',''),list)

# Generated at 2022-06-23 21:18:12.204422
# Unit test for constructor of class Choice
def test_Choice():
    text = Choice()
    assert isinstance(text(), str)
    assert isinstance(text.seed, int)
    assert isinstance(text.random, object)
    assert isinstance(text.datetime, object)
    assert isinstance(text.timedelta, object)
    assert isinstance(text.uuid, object)
    assert isinstance(text.faker, object)
    assert isinstance(text.provider, object)
    assert isinstance(text.formatters, object)
    assert isinstance(text.codecs, object)
    assert isinstance(text.utils, object)

    data = ['a', 'ab', 'abc']
    assert text(data) in data
    assert text(data, length=1) == ['a']

# Generated at 2022-06-23 21:18:19.124050
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    result = choice(items=['a', 'b', 'c'], length=1)
    assert isinstance(result, list) and len(result) == 1, \
        'should be a list of length 1'
    result = choice(items=('a', 'b', 'c'), length=2)
    assert isinstance(result, tuple) and len(result) == 2, \
        'should be a tuple of length 2'
    result = choice(items='abc', length=3, unique=True)
    assert isinstance(result, str) and len(result) == 3, \
        'should be a string of length 3'
    result = choice(items=['a', 'b', 'c'])
    assert isinstance(result, str), 'should be a string'


# Generated at 2022-06-23 21:18:25.768539
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.providers import Choice
    choice = Choice()
    choice(items=['a', 'b', 'c'])
    choice(items=['a', 'b', 'c'], length=1)
    choice(items='abc', length=2)
    choice(items=('a', 'b', 'c'), length=5)
    choice(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-23 21:18:35.345660
# Unit test for constructor of class Choice
def test_Choice():
    p = Choice()
    print(p)
    # assert p.constructor(items=['a', 'b', 'c']) == 'c'
    # assert p.constructor(items=['a', 'b', 'c'], length=1) == ['a']
    # assert p.constructor(items='abc', length=2) == 'ba'
    # assert p.constructor(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    # assert p.constructor(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    # assert p.constructor(items='abcdef',length=6,unique=True) == 'abcdef'


# Generated at 2022-06-23 21:18:36.269156
# Unit test for constructor of class Choice
def test_Choice():
    a = Choice()
    print(a)


# Generated at 2022-06-23 21:18:45.552824
# Unit test for method __call__ of class Choice

# Generated at 2022-06-23 21:18:56.379114
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    for _ in range(10):
        assert (
            choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
        )
    for _ in range(10):
        assert (
            choice(items=['a', 'b', 'c'], length=1) == ['a'] or
            choice(items=['a', 'b', 'c'], length=1) == ['b'] or
            choice(items=['a', 'b', 'c'], length=1) == ['c']
        )

# Generated at 2022-06-23 21:19:01.602324
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(["a", "b", "c"], length=1) == ["a"]
    assert Choice().__call__("abc", length=2) == "ba"
    assert Choice().__call__(("a", "b", "c"), length=5) == ("c", "a", "a", "b", "c")
    assert Choice().__call__("aabbbccccddddd", length=4, unique=True) == "cdba"
