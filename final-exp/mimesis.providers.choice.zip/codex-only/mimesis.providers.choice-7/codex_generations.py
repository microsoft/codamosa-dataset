

# Generated at 2022-06-23 21:09:08.039424
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ab', 'ac', 'bc']
    assert choice(items=('a', 'b', 'c'), length=5) in [('a', 'b', 'c', 'b', 'a'),
                                                       ('a', 'b', 'c', 'c', 'b'),
                                                       ('a', 'b', 'c', 'a', 'c')]

# Generated at 2022-06-23 21:09:18.578541
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.builtins import Choice
    choice = Choice()
    assert choice(items=('a', 'b', 'c')) in ('a', 'b', 'c')

    result = choice(items=('a', 'b', 'c'), length=3)
    assert isinstance(result, list)
    assert isinstance(result, tuple)
    assert isinstance(result, str)

    assert choice(items=('a', 'b', 'c'), length=1) != choice(items=('a', 'b', 'c'), length=1)

    assert choice(items=('a', 'b', 'c'), length=3, unique=True) != choice(items=('a', 'b', 'c'), length=3, unique=True)
    # result = choice(items=('a', 'b', 'c'), length=3

# Generated at 2022-06-23 21:09:26.625852
# Unit test for constructor of class Choice
def test_Choice():
    """ It show the result of the test."""
    choice = Choice()
    choice(items=['a', 'b', 'c'])
    choice(items=['a', 'b', 'c'], length=1)
    choice(items='abc', length=2)
    choice(items=('a', 'b', 'c'), length=5)
    choice(items='aabbbccccddddd', length=4, unique=True)
# result:
#'c'
#['a']
#'ba'
#('c', 'a', 'a', 'b', 'c')
#'cdba'

# Generated at 2022-06-23 21:09:27.956808
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert isinstance(c, Choice)

# Generated at 2022-06-23 21:09:28.988303
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice() is not None


# Generated at 2022-06-23 21:09:39.057211
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from slm_lab.lib.constant import Constant
    from slm_lab.lib import util

    util.init_logger(Constant.LOG_PATH)
    test_Choice = Choice()

    random_str = util.random_str()

    items = ['a', 'b', 'c']
    length = 1
    unique = False

    choice = test_Choice(items=items, length=length, unique=unique)
    if len(choice) > 0:
        print(test_Choice(items=items, length=length, unique=unique))
    else:
        print(test_Choice(items=items))

    items = random_str
    length = 2
    unique = False

    choice = test_Choice(items=items, length=length, unique=unique)
    if len(choice) > 0:
        print

# Generated at 2022-06-23 21:09:39.881832
# Unit test for constructor of class Choice
def test_Choice():
    ch = Choice()
    assert ch



# Generated at 2022-06-23 21:09:45.703162
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    r = c(items=['a', 'b', 'c'])
    r_length = c(items=['a', 'b', 'c'], length=1)
    r_unique = c(items=['a', 'b', 'c'], unique=True)
    r_unique_length = c(items=['a', 'b', 'c'], length=1, unique=True)

    assert r in ['a', 'b', 'c']
    assert r_length == ['a']
    assert r_unique in ['a', 'b', 'c']
    assert r_unique_length == ['a'] or r_unique_length == ['b'] or r_unique_length == ['c']

# Generated at 2022-06-23 21:09:49.372418
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    choice(items=['a', 'b', 'c'])
    choice(items=['a', 'b', 'c'], length=1)
    choice(items='abc', length=2)
    choice(items=('a', 'b', 'c'), length=5)
    choice(items='aabbbccccddddd', length=4, unique=True)
    assert len(choice(items='aabbbccccddddd', length=4, unique=True)) == 4

# Generated at 2022-06-23 21:09:57.938535
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    items_1 = ['a', 'b', 'c']
    assert choice(items=items_1) in items_1
    items_2 = ['a', 'b', 'c', 'd', 'e']
    assert choice(items=items_2, length=1) in items_2
    items_3 = ('a', 'b', 'c')
    assert choice(items=items_3, length=1) in items_3
    items_4 = ('a', 'b', 'c', 'd', 'e')
    assert choice(items=items_4, length=1) in items_4
    items_5 = 'abc'
    assert choice(items=items_5, length=1) in items_5
    items_6 = 'abcdef'

# Generated at 2022-06-23 21:09:59.631352
# Unit test for constructor of class Choice
def test_Choice():
    c=Choice()
    assert c is not None

# Generated at 2022-06-23 21:10:01.069507
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice()


# Unit Test for the __call__ method of class Choice

# Generated at 2022-06-23 21:10:10.359125
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit-test Choice.__call__().

    You can run the test with pytest:
    ```bash
    pytest -v tests/test_choices.py::test_Choice___call__
    ```
    """
    choice = Choice()

    print(choice(items=['a', 'b', 'c']))
    print(choice(items=['a', 'b', 'c'], length=1))
    print(choice(items='abc', length=2))
    print(choice(items=('a', 'b', 'c'), length=5))
    print(choice(items='aabbbccccddddd', length=4, unique=True))



# Generated at 2022-06-23 21:10:17.436644
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    import random

    import pytest

    from mimesis.enums import Gender
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.misc import Misc

    seed = 0
    random.seed(seed)

    c = Choice(seed=seed)

    # ----
    # With all args.
    # ----
    # ``items`` is list
    actual = c(items=['a', 'b', 'c'], length=3, unique=False)
    expected = ['c', 'a', 'b']
    assert actual == expected

    # ``items`` is tuple
    actual = c(items=('a', 'b'), length=3, unique=False)
    expected = ('a', 'b', 'a')
    assert actual == expected

    # ``items`` is string

# Generated at 2022-06-23 21:10:21.880755
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    expected_results = [('a', 'b', 'b')]
    actual_results = []
    choice = Choice()
    actual_results.append(choice(items=['a', 'b', 'b'], length=3))
    assert expected_results == actual_results



# Generated at 2022-06-23 21:10:30.743601
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice.__call__(items=['a', 'b', 'c']) == 'c'
    assert choice.__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice.__call__(items='abc', length=2) == 'ba'
    assert choice.__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice.__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:10:39.533331
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from unittest import TestCase, main
    from unittest.mock import Mock

    mt = Mock()
    mt.choice.side_effect = ['c', ['a'], 'ba', ('c', 'a', 'a', 'b', 'c'), 'cdba']
    choice = Choice(seed=123)
    choice.random = mt
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) \
        == ('c', 'a', 'a', 'b', 'c')

# Generated at 2022-06-23 21:10:41.764871
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis import Choice
    myChoice = Choice()
    assert myChoice.choice is Choice().choice

# Generated at 2022-06-23 21:10:42.658036
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice



# Generated at 2022-06-23 21:10:48.662806
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """
    Test method Choice.__call__

    >>> choice = Choice()

    >>> choice(items=['a', 'b', 'c'])
    'c'
    >>> choice(items=['a', 'b', 'c'], length=1)
    ['a']
    >>> choice(items='abc', length=2)
    'ba'
    >>> choice(items=('a', 'b', 'c'), length=5)
    ('c', 'a', 'a', 'b', 'c')
    >>> choice(items='aabbbccccddddd', length=4, unique=True)
    'cdba'
    """

# Generated at 2022-06-23 21:10:53.205555
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice(items=['a', 'b', 'c'])
    assert choice(items=['a', 'b', 'c'], length=1)
    assert choice(items='abc', length=2)
    assert choice(items=('a', 'b', 'c'), length=5)
    assert choice(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-23 21:10:58.702519
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-23 21:10:59.744962
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert c

# Generated at 2022-06-23 21:11:01.065305
# Unit test for constructor of class Choice
def test_Choice():
    d = Choice()

# Generated at 2022-06-23 21:11:09.126978
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Test data generation
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=['a', 'b', 'c'], length=5) == ['c', 'a', 'a', 'b', 'c']
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'



# Generated at 2022-06-23 21:11:13.528356
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert c(items=['a', 'b', 'c']) == 'c'
    assert c(items=['a', 'b', 'c'], length=1) == ['a']
    assert c(items='abc', length=2) == 'ba'
    assert c(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert c(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-23 21:11:14.958432
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice is not None


# Generated at 2022-06-23 21:11:21.843639
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    
    assert choice.random.choice(items='abc', length=10, unique=True) == 'caababcaab'
    
    items = [1, 2, 3, 4, 5]
    assert choice.random.choice(items=items, length=10, unique=True) in items
    

# Generated at 2022-06-23 21:11:28.115053
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for the method __call__ of class Choice."""
    from mimesis import Choice

    items = ['a', 'b', 'c']

    choice = Choice()
    item = choice(items=items)
    assert item in items

    items = 'abc'
    item = choice(items=items)
    assert item in items

    items = ('a', 'b', 'c')
    item = choice(items=items)
    assert item in items



# Generated at 2022-06-23 21:11:29.767297
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)

# Unit tests for __call__ method of class Choice

# Generated at 2022-06-23 21:11:30.976648
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass
# Test for method __call__ of class Choice was generated

# Generated at 2022-06-23 21:11:32.063414
# Unit test for constructor of class Choice
def test_Choice():
    assert isinstance(Choice(seed=42), Choice)



# Generated at 2022-06-23 21:11:35.060558
# Unit test for constructor of class Choice
def test_Choice():
    """Test for constructor of the class Choice."""
    global choice
    choice = Choice()
    assert choice is not None
    assert isinstance(choice, Choice)
    assert isinstance(choice, BaseProvider)


# Generated at 2022-06-23 21:11:42.986868
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()

# Generated at 2022-06-23 21:11:52.854342
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from pickle import dumps
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.choice import Choice

    class CustomChoice(Choice):
        """Class for testing."""

        class Meta:
            """Class for metadata."""

            name = 'custom_provider'

    ch = CustomChoice()
    # test __call__ method
    # test with simple list items
    result1 = ch(['a', 'b', 'c'], 3)
    assert isinstance(result1, list) and len(result1) == 3
    # test with unicode string items
    result2 = ch('Выход', 10)
    assert isinstance(result2, str) and len(result2) == 10
    # test with tuple items

# Generated at 2022-06-23 21:11:58.448440
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    result = choice(items=['a', 'b', 'c'])
    assert result == 'c'
    result = choice(items=['a', 'b', 'c'], length=1)
    assert result == ['a']
    result = choice(items='abc', length=2)
    assert result == 'ba'
    result = choice(items=('a', 'b', 'c'), length=5)
    assert result == ('c', 'a', 'a', 'b', 'c')
    result = choice(items='aabbbccccddddd', length=4, unique=True)
    assert result == 'cdba'

    b1 = choice(items=['a', 'b', 'c'])
    b2 = choice(items=['a', 'b', 'c'])

# Generated at 2022-06-23 21:12:05.846774
# Unit test for constructor of class Choice
def test_Choice():
    """Testing constructor with zero arguments."""
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items=['a', 'b', 'c'], length=3) in [['a', 'b', 'c'], ['a', 'c', 'b'],
                                                       ['b', 'a', 'c'], ['b', 'c', 'a'],
                                                       ['c', 'a', 'b'], ['c', 'b', 'a']]
    assert choice(items='abc', length=2) in ['ab', 'ac', 'bc']

# Generated at 2022-06-23 21:12:14.519302
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    s = Choice()
    assert s(items=['a', 'b', 'c']) == 'c'
    assert s(items=['a', 'b', 'c'], length=1) == ['a']
    assert s(items='abc', length=2) == 'ba'
    assert s(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert s(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    try:
        s(items=None, length=1)
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-23 21:12:22.511852
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items=['a','b','c','d','e','f','g','h','i','j','k','l','m']
    length=5
    unique=True
    choice=Choice()
    result=choice(items=items,length=length,unique=unique)
    assert (len(result) == length)
    assert (len(set(result)) == length)
    for c in result:
        assert (c in items)
    for c in items:
        assert (c not in result)
        


# Generated at 2022-06-23 21:12:32.764382
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == choice.__call__(items=['a', 'b', 'c'])
    assert choice(items=['a', 'b', 'c'], length=1) == choice.__call__(items=['a', 'b', 'c'], length=1)
    assert choice(items='abc', length=2) == choice.__call__(items='abc', length=2)
    assert isinstance(choice(items='abc', length=2), str)
    assert isinstance(choice(items=('a', 'b', 'c'), length=5), tuple)
    assert isinstance(choice(items='aabbbccccddddd', length=4, unique=True), str)

# Generated at 2022-06-23 21:12:35.240943
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    choice = Choice()
    assert choice(items=items, length=length, unique=unique) == ['a']


# Generated at 2022-06-23 21:12:40.243171
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice('en')

    assert choice.__class__.__name__ == 'Choice'
    assert isinstance(choice, Choice)

    assert choice.Meta.__class__.__name__ == 'type'
    assert choice.Meta.name == 'choice'

    assert choice.seed == 'en'
    assert choice.random is not None
    assert choice.datetime is not None
    assert choice.timedelta is not None
    assert choice.uuid is not None


# Generated at 2022-06-23 21:12:43.250347
# Unit test for constructor of class Choice
def test_Choice():
    ch=Choice()
    assert ch(['a','b','c']) in ['a','b','c']
    assert type(ch(['a','b','c','d'],length=3))==list
    assert len(ch(['a','b','c','d'],length=3))==3
    assert type(ch('stam',length=2))==str

# Generated at 2022-06-23 21:12:45.708058
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 3
    data = Choice().__call__(items, length)
    assert data == ['b', 'c', 'a']

# Generated at 2022-06-23 21:12:46.667474
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """TODO"""
    pass


# Generated at 2022-06-23 21:12:49.492568
# Unit test for constructor of class Choice
def test_Choice():
    """Unit test for constructor of class Choice."""
    # Test constructor of class Choice.
    choice = Choice()
    assert choice
    assert isinstance(choice, Choice)


# Generated at 2022-06-23 21:12:56.291156
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    instance = Choice()
    assert isinstance(instance('aabbbccdde'), str)
    assert isinstance(instance('aabbbccdde', length=5), str)
    assert isinstance(instance('aabbbccdde', length=5, unique=True), str)
    assert isinstance(instance(['a', 'b', 'c']), str)
    assert isinstance(instance(['a', 'b', 'c'], length=5), list)
    assert isinstance(instance(('a', 'b', 'c')), str)
    assert isinstance(instance(('a', 'b', 'c'), length=5), tuple)



# Generated at 2022-06-23 21:13:02.871472
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis import Choice
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 1
    unique = True
    if not isinstance(length, int):
        raise TypeError('**length** must be integer.')

    if not isinstance(items, collections.abc.Sequence):
        raise TypeError('**items** must be non-empty sequence.')

    if not items:
        raise ValueError('**items** must be a non-empty sequence.')

    if length < 0:
        raise ValueError('**length** should be a positive integer.')

    if length == 0:
        assert choice(items)

    data = []  # type: ignore

# Generated at 2022-06-23 21:13:05.073390
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert (choice(['a', 'b', 'c']) in ['a', 'b', 'c'])


# Generated at 2022-06-23 21:13:15.733381
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    choice = Choice()
    assert (choice(items=['a', 'b', 'c']) in ['a', 'b', 'c'])
    assert (choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']])
    assert (choice(items='abc', length=2) in ['aa', 'ab', 'ac', 'ba', 'bb',
            'bc', 'ca', 'cb', 'cc'])

# Generated at 2022-06-23 21:13:17.230794
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice().__init__('','') == None

# Generated at 2022-06-23 21:13:18.086015
# Unit test for constructor of class Choice
def test_Choice():
    test = Choice()
    assert Choice


# Generated at 2022-06-23 21:13:20.873759
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method Choice.__call__."""
    from mimesis.enums import DataType
    choice = Choice(DataType.HEXADECIMAL)
    assert choice(items='abcd', length=1, unique=True) == 'b'


# Generated at 2022-06-23 21:13:22.755453
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    items = [1, 2, 3, 4]
    length = 2

    data = c(items, length)
    assert data in items
    assert len(data) == length


# Generated at 2022-06-23 21:13:29.856407
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Tests for the method ``__call__`` for the class ``Choice``."""
    from mimesis.enums import Gender
    from mimesis.builtins import Person
    from mimesis.builtins import Superhero

    choice = Choice(gender=Gender.MALE)
    items = ['a', 'b', 'c']
    length = 1
    unique = False

    assert choice(items, length, unique) in items

    choice = Choice(seed=42)
    items = ['1', '2', '3']
    length = 0
    unique = False

    assert choice(items, length, unique) == '2'
    assert isinstance(choice(items, length, unique), str)

    choice = Choice(seed=42)
    items = ['a', 'b', 'c']
    length = 1

# Generated at 2022-06-23 21:13:39.598887
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    data = [
        ('a', 'b', 'c'),
        ('a', 'b', 'c'),
        'abc',
        'abc',
        ('a', 'b', 'c'),
        ('a', 'b', 'c'),
        'aabbbccccddddd',
        'aabbbccccddddd',
    ]
    length = [0, 1, 0, 2, 5, 2, 4, 2]
    unique = [False, False, False, False, False, True, True, True]
    expected = [
        'b',
        ['b'],
        'c',
        'ac',
        ('c', 'b', 'b', 'b', 'a'),
        ('b', 'c', 'a'),
        'cdba',
        'bac'
    ]

    choice

# Generated at 2022-06-23 21:13:44.180055
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    choice = Choice()
    assert choice(['a', 'b', 'c']) == 'c'
    assert choice(['a', 'b', 'c'], length=1) == ['a']
    assert choice('abc', length=2) == 'ba'
    assert choice(('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice('aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:13:52.962032
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test of method __call__ of class Choice"""
    assert 'Choice.__call__(None, [\'a\', \'b\', \'c\', \'d\'], 2)'
    assert 'Choice.__call__(None, [\'a\', \'b\', \'c\', \'d\'], 2)'
    assert 'Choice.__call__(None, [\'a\', \'b\', \'c\', \'d\'], 4)'
    assert 'Choice.__call__(None, [\'a\', \'b\', \'c\', \'d\'], 3)'
    assert 'Choice.__call__(None, [\'a\', \'b\', \'c\', \'d\'], 6)'
    assert 'Choice.__call__(None, [\'a\', \'b\', \'c\', \'d\'], 1)'


# Generated at 2022-06-23 21:13:54.057519
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert not isinstance(choice, void)


# Generated at 2022-06-23 21:13:56.598221
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    result = c('abc', 5, True)
    expected = 'cba'
    assert result == expected, f'Result {result} != Expected {expected}'

# Generated at 2022-06-23 21:13:58.412034
# Unit test for constructor of class Choice
def test_Choice():
    """Test for constructor of class Choice."""
    c = Choice()
    assert c.__class__.__name__ == "Choice"


# Generated at 2022-06-23 21:14:04.935715
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""

# Generated at 2022-06-23 21:14:16.503969
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from typing import Tuple

    choice: Choice = Choice()
    for _ in range(10):
        # Return single random character from string 'abc'.
        assert isinstance(choice('abc'), str)
        assert len(choice('abc')) == 1
        assert choice('abc') in 'abc'

        # Return list of random characters from string 'abc'.
        assert isinstance(choice('abc', 3), list)
        assert len(choice('abc', 3)) == 3
        assert not set(choice('abc', 3)) - set('abc')

        # Return tuple of random characters from string 'abc'.
        assert isinstance(choice('abc', 3), Tuple[str, str, str])
        assert len(choice('abc', 3)) == 3
        assert not set(choice('abc', 3)) - set('abc')

        # Return string of random characters

# Generated at 2022-06-23 21:14:24.028466
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    _items = ['a', 'b', 'c']
    assert Choice().__call__(items=_items) in _items
    _items = 'abc'
    assert Choice().__call__(items=_items) in _items
    _items = ('a', 'b', 'c')
    assert type(Choice().__call__(items=_items, length=1)) == list
    assert type(Choice().__call__(items=_items)) == str
    assert len(Choice().__call__(items=_items, length=3)) == 3
    assert len(Choice().__call__(items='abc', length=2)) == 2
    assert len(Choice().__call__(items=_items)) == 1
    assert type(Choice().__call__(items=_items, length=5)) == tuple

# Generated at 2022-06-23 21:14:25.208675
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)


# Generated at 2022-06-23 21:14:27.409916
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    choice("abc", 3, True)
    choice("abc", 3, False)
    choice("abc")
    choice("abc", unique=True)

# Generated at 2022-06-23 21:14:36.996682
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Tests that bare item and sequence are chosen correctly."""
    choice = Choice()
    assert callable(choice)
    items = ['a', 'b', 'c']
    assert choice(items=items) in items
    assert choice(items=items, length=1)[0] in items
    assert choice(items=items, length=2)[0] in items
    assert choice(items=items, length=3)[0] in items
    assert choice(items=items, length=4)[0] in items
    assert choice(items=items, length=5)[0] in items
    assert choice(items=items, length=6)[0] in items
    assert choice(items=items, length=7)[0] in items
    assert choice(items=items, length=8)[0] in items

# Generated at 2022-06-23 21:14:39.620109
# Unit test for constructor of class Choice
def test_Choice():
    """Unit test for ``Choice()``."""
    Choice(seed=123).choice(items=['a', 'b', 'c'], length=5)

# Generated at 2022-06-23 21:14:48.520481
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test function Choice.__call__(items, length, unique)."""
    import random
    def mock_choice(seq):
        """Mock random.choice(items)."""
        return random.choice(seq)

    from mimesis.enums import DataType
    from mimesis.typing import Seed
    from mimesis.exceptions import NonDataContainerError

    choice_provider = Choice()
    choice_provider.random.choice = mock_choice

    seq = [DataType.INTEGER, DataType.FLOAT]
    assert choice_provider.__call__(items=seq) in seq

    assert isinstance(choice_provider.__call__(items=seq, length=1), list)

    assert len(choice_provider.__call__(items=seq, length=20)) == 20

   

# Generated at 2022-06-23 21:14:57.699143
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender
    from mimesis.providers.date_time import DateTime

    choice = Choice()
    # Provide elements randomly chosen from the elements in a sequence items,
    # where when length is specified the random choices are contained in a
    # sequence of the same type of length length, otherwise a single uncontained
    # element is chosen. If unique is set to True, constrain a returned
    # sequence to contain only unique elements.
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) == ['c']

# Generated at 2022-06-23 21:15:02.656389
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()

    assert(choice.random.choice(['a', 'b', 'c']) in 'abc')
    assert(choice.random.choice(('a', 'b', 'c')) in 'abc')
    assert(choice.random.choice('abc') in 'abc')


# Generated at 2022-06-23 21:15:10.540520
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c', 'd'], length=1) == ['b']
    assert choice(items=['1', '2', '3', '4', '5'], length=2, unique=True) in [['2', '4'], ['4', '2']]
    assert choice(items=('a', 'b', 'c'), length=5, unique=True) in [('b', 'a', 'c', 'a', 'c'), ('c', 'b', 'a', 'b', 'a')]
    assert choice(items='abc', length=1) in ['b', 'c', 'a']
    assert choice(items='abcd', length=2) in ['ca', 'db', 'bc', 'ad']

# Generated at 2022-06-23 21:15:11.570961
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()


# Generated at 2022-06-23 21:15:14.069634
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice.

    :param None: None.
    :return: None.
    """
    pass

# Generated at 2022-06-23 21:15:17.331570
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:15:26.168763
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    assert isinstance(choice(['a', 'b', 'c']), str)
    assert choice(['a', 'b', 'c']) in ['a', 'b', 'c']

    assert isinstance(choice(['a', 'b', 'c'], 1), list)
    assert choice(['a', 'b', 'c'], 1) in [['a'], ['b'], ['c']]

    assert isinstance(choice('abc', 2), str)
    assert choice('abc', 2) in ['ba', 'ab', 'cb', 'ac', 'bc']

    assert isinstance(choice(('a', 'b', 'c'), 5), tuple)

# Generated at 2022-06-23 21:15:27.553153
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert c != None


# Generated at 2022-06-23 21:15:34.849679
# Unit test for constructor of class Choice
def test_Choice():
    # try to create a Choice class object with some arguments
    choice = Choice()

    # exercise Choice methods with different inputs
    print(choice(items=['a', 'b', 'c']))
    print(choice(items=['a', 'b', 'c'], length=1))
    print(choice(items='abc', length=2))
    print(choice(items=('a', 'b', 'c'), length=5))
    print(choice(items='aabbbccccddddd', length=4, unique=True))

if __name__ == '__main__':
    test_Choice()

# Generated at 2022-06-23 21:15:46.042435
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice()(items=[1, 2, 3], length=1) == [1]
    assert Choice()(items=[1, 2, 3], length=5) == [3, 3, 3, 3, 3]
    assert Choice()(items=[1, 2, 3], length=5, unique=True) == [1, 2, 3]
    assert Choice()(items=('1', '2', '3'), length=1) == ('1',)
    assert Choice()(items=('1', '2', '3'), length=5) == ('3', '3', '3',
                                                          '3', '3')
    assert Choice()(items=('1', '2', '3'), length=5, unique=True) == ('1',
                                                                       '2',
                                                                       '3')
    assert Choice()

# Generated at 2022-06-23 21:15:53.851393
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method __call__ of class Choice."""
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in 'abc'
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ab', 'ac', 'ba', 'bc', 'ca', 'cb']

# Generated at 2022-06-23 21:15:56.396326
# Unit test for constructor of class Choice
def test_Choice():
    """Check for class Choice."""
    choice = Choice(seed=987654321)
    assert choice is not None


# Generated at 2022-06-23 21:16:00.191854
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    sequence = ['1', '2', '3', '4', '5']
    choice = Choice()
    choice_result = choice(items=sequence, length=0, unique=False)
    assert choice_result in sequence

if __name__ == '__main__':
    test_Choice___call__()

# Generated at 2022-06-23 21:16:10.414781
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method `__call__` of class `Choice`.
    """
    choice = Choice()

    assert isinstance(choice('abc'), str)
    assert choice('abc', length=0) in 'abc'
    assert choice('abc', length=1) in 'abc'
    assert choice('abc', length=2) in 'abc'
    assert choice('abc', length=3) in 'abc'
    assert choice('abc', length=4) in 'abc'

    assert isinstance(choice(['a', 'b', 'c']), str)
    assert choice(['a', 'b', 'c'], length=0) in ['a', 'b', 'c']
    assert choice(['a', 'b', 'c'], length=1) in ['a', 'b', 'c']

# Generated at 2022-06-23 21:16:14.678176
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TODO: Add more unit tests
    # Arguments
    items = ['a', 'b', 'c']
    length = 1

    choice = Choice()
    data = choice(items, length)
    
    #print(data)
    assert data == ['a']

    print('Success')

test_Choice___call__()

# Generated at 2022-06-23 21:16:15.874560
# Unit test for constructor of class Choice
def test_Choice():
    """Test the constructor of class Choice.
    """
    value = Choice()
    assert isinstance(value, Choice)

# Generated at 2022-06-23 21:16:16.490385
# Unit test for constructor of class Choice
def test_Choice():
    assert isinstance(Choice(), Choice)


# Generated at 2022-06-23 21:16:25.777778
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice(items = ['a', 'b', 'c']) == 'c'
    assert choice(items = ['a', 'b', 'c'], length = 1) == ['a']
    assert choice(items = 'abc', length = 2) == 'ba'
    assert choice(items = ('a', 'b', 'c'), length = 5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items = 'aabbbccccddddd', length = 4, unique = True) == 'cdba'

# Generated at 2022-06-23 21:16:28.773987
# Unit test for constructor of class Choice
def test_Choice():
    assert callable(Choice)
    c = Choice()
    assert isinstance(c, Choice)
    assert isinstance(c, BaseProvider)


# Generated at 2022-06-23 21:16:30.454202
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    result = choice(items=[1,2,3])
    assert result == 1



# Generated at 2022-06-23 21:16:38.383775
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    obj = Choice()
    assert isinstance(obj(items=['a', 'b', 'c']), str)
    assert isinstance(obj(items='abc', length=2), str)
    assert isinstance(obj(items=['a', 'b', 'c'], length=1), list)
    assert isinstance(obj(items='abc', length=2), str)
    assert isinstance(obj(items=('a', 'b', 'c'), length=5), tuple)
    assert isinstance(obj(items='aabbbccccddddd', length=4, unique=True), str)

    # Test for TypeError

# Generated at 2022-06-23 21:16:39.637387
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice.__class__.__name__ == 'Choice'

# Generated at 2022-06-23 21:16:41.154114
# Unit test for constructor of class Choice
def test_Choice():
    """Unit test for constructor of class Choice()."""

    d = Choice()
    assert d is not None



# Generated at 2022-06-23 21:16:53.141014
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from unittest import TestCase, mock
    from unittest.mock import patch
    from mimesis import Choice

    choice = Choice()

    class TestChoice(TestCase):

        @patch.object(Choice, 'random')
        def test_choice(self, mock_random):
            mock_random.choice.return_value = 'a'
            mock_random.choice.return_value = 'b'
            mock_random.choice.return_value = 'c'
            mock_random.choice.return_value = 0

            self.assertEqual(choice(items=['a', 'b', 'c']), 'c')
            self.assertEqual(choice(items=['a', 'b', 'c'], length=1), ['a'])

# Generated at 2022-06-23 21:16:57.090975
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice(seed=1998)
    # Test with length = 0
    choice(items=['a', 'b', 'c'])
    choice(items=['a', 'b', 'c'], length=1)
    choice(items='abc', length=2)
    choice(items=('a', 'b', 'c'), length=5)
    choice(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-23 21:17:05.136956
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from hypothesis import given
    from hypothesis import strategies as st
    from mimesis import Choice

    choice = Choice()
    test_items = [
        (1, 2, 3),
        [1, 2, 3],
        "123",
        (1, 2, 3, 1, 2, 3)
    ]
    test_lengths = [0, 1, 5, 10]
    test_uniques = [False, True]
    

# Generated at 2022-06-23 21:17:14.705755
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 1
    choice = Choice()
    assert choice(items, length) == ['a']
    length = 2
    items = 'abc'
    assert choice(items, length) == 'ba'
    items = ('a', 'b', 'c')
    length = 5
    assert choice(items, length) == ('c', 'a', 'a', 'b', 'c')
    items = 'aabbbccccddddd'
    length = 4
    unique = True
    assert choice(items, length, unique) == 'cdba'



# Generated at 2022-06-23 21:17:19.987067
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    with raises(TypeError):
        choice(items=[1, 2, 3], length='test')
    with raises(ValueError):
        choice(items=[1, 2, 3], length=-1)

# Generated at 2022-06-23 21:17:21.889123
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TODO: Add coverage testing of function choice
    pass

# Generated at 2022-06-23 21:17:22.869055
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass
    # TODO: Add tests

# Generated at 2022-06-23 21:17:24.183965
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert isinstance(c, Choice)


# Generated at 2022-06-23 21:17:25.497051
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()

    assert isinstance(c, Choice)


# Generated at 2022-06-23 21:17:27.251266
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)

# Unit tests for Choice.__call__()

# Generated at 2022-06-23 21:17:29.851474
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis import Choice
    choice = Choice()
    assert choice('test') in choice.choice.items
    assert choice(items=('test,test2')) in choice.choice.items

# Generated at 2022-06-23 21:17:40.550539
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    print('\nTest Choice.__call__...')

    choice = Choice()

    items = ('a', 'b', 'c')
    item = choice(items=items, unique=False)
    print('choice(items={}, unique={}) = {}'.format(items, False, item))
    assert isinstance(item, tuple)
    assert item in items

    items = ['a', 'b', 'c']
    item = choice(items=items, unique=False)
    print('choice(items={}, unique={}) = {}'.format(items, False, item))
    assert isinstance(item, list)
    assert item in items

    items = 'abc'
    item = choice(items=items, unique=False)
    print('choice(items={}, unique={}) = {}'.format(items, False, item))

# Generated at 2022-06-23 21:17:41.584281
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    return choice

# Generated at 2022-06-23 21:17:50.750409
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import unittest
    from unittest.mock import patch
    from mimesis.builtins.testtools import (
        mock_backend,
        mock_lists,
        mock_len,
    )
    class TestChoice___call__(unittest.TestCase):
        items = []
        length = 0
        unique = False
        def setUp(self):
            self.choice = Choice()
            self.choice._backend = mock_backend
        def tearDown(self):
            self.choice = None
        def test_choice___call__001(self):
            """Test the method __call__ of Choice with items = ['a', 'b', 'c'],
            length = 0 and unique = False.
            """
            self.items = ['a', 'b', 'c']
            self.length = 0

# Generated at 2022-06-23 21:17:57.664262
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(['a', 'b', 'c'], 2) == 'bc', 'A random choice failed'
    assert choice(['a', 'b', 'c'], 0) == 'c', 'A random choice failed'
    assert isinstance(choice(['a', 'b', 'c']), str), 'A random choice failed'  # type: ignore
    assert choice(['a', 'b', 'c'], 2, True) == 'ab', 'A random choice failed'
    assert choice(['a', 'b', 'c'], 1, True) == ['a'], 'A random choice failed'
    assert choice(['a', 'b', 'c'], 5) == 'caaab', 'A random choice failed'

# Generated at 2022-06-23 21:17:59.963987
# Unit test for constructor of class Choice
def test_Choice():
    # Initialize Choice()
    choice = Choice()

    # Check type of instance
    assert isinstance(choice, Choice)


# Generated at 2022-06-23 21:18:09.231584
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 1
    assert choice(items=items, length=length) == ['a']
    items = 'abc'
    length = 2
    assert choice(items=items, length=length) == 'ba'
    items = ('a', 'b', 'c')
    length = 5
    assert choice(items=items, length=length) == ('c', 'a', 'a', 'b', 'c')
    items = 'aabbbccccddddd'
    length = 4
    assert choice(items=items, length=length, unique=True) == 'cdba'

# Generated at 2022-06-23 21:18:10.183743
# Unit test for constructor of class Choice
def test_Choice():
    obj = Choice()
    assert obj


# Generated at 2022-06-23 21:18:11.624625
# Unit test for constructor of class Choice
def test_Choice():
    """Constructor class Choice."""
    provider = Choice()
    assert provider is not None

# Generated at 2022-06-23 21:18:18.856965
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pseudo = Choice()
    assert pseudo(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert pseudo(items=['a', 'b', 'c'], length=1) == ['a']
    assert pseudo(items='abc', length=2) in ['ba', 'ab', 'ca', 'cb', 'ac', 'bc']

    assert len(pseudo(items=('a', 'b', 'c'), length=5)) == 5
    assert len(pseudo(items='aabbbccccddddd', length=4, unique=True)) == 4
    try:
        pseudo(items=['a', 'b', 'c'], length=1.1)
    except TypeError:
        pass

# Generated at 2022-06-23 21:18:29.413355
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

    t = False
    try:
        choice(items=['a', 'b', 'c'], length=1.1)
    except TypeError:
        t = True
    assert t

    t = False

# Generated at 2022-06-23 21:18:30.378344
# Unit test for constructor of class Choice
def test_Choice():
    obj = Choice()
    assert obj is not None


# Generated at 2022-06-23 21:18:32.059060
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice.random.choice(['a','b','c']) in ['a','b','c']

# Generated at 2022-06-23 21:18:41.122270
# Unit test for method __call__ of class Choice

# Generated at 2022-06-23 21:18:45.825950
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice.
    """


# Generated at 2022-06-23 21:18:56.637661
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Tests for method __call__.
    """
    items = ['a', 'b', 'c']
    choice = Choice()
    assert choice(items=items) in items
    assert choice(items=items, length=1) in [[item] for item in items]
    assert choice(items="abc", length=2) in ['ba', 'ab', 'ac', 'bc']

# Generated at 2022-06-23 21:18:57.591696
# Unit test for constructor of class Choice
def test_Choice():
    Choice()


# Generated at 2022-06-23 21:18:59.528347
# Unit test for constructor of class Choice
def test_Choice():
    x = Choice()
    assert x
