

# Generated at 2022-06-23 21:09:07.612194
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()

    assert isinstance(choice(items=['a', 'b', 'c']), str)
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert isinstance(choice(items=['a', 'b', 'c'], length=1), list)
    assert choice(items=['a', 'b', 'c'], length=1) == ['a'] or ['b'] or ['c']
    assert isinstance(choice(items='abc', length=2), str)
    assert choice(items='abc', length=2) == 'ba' or 'ca' or 'ac' or 'ab' or 'bc' or 'cb'

# Generated at 2022-06-23 21:09:16.821934
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from hypothesis import given
    from hypothesis import strategies as st
    from .utils import strategy_integer
    from .utils import strategy_sequence
    from .utils import strategy_bool

    CHOICE = Choice()

    @given(st.data())
    def test_Choice___call__(data):
        length = data.draw(strategy_integer)
        unique = data.draw(strategy_bool)
        items = data.draw(strategy_sequence)
        if isinstance(items, str):
            items = tuple(items)
        CHOICE(items=items, length=length, unique=unique)

    test_Choice___call__()

# Generated at 2022-06-23 21:09:19.260712
# Unit test for constructor of class Choice
def test_Choice():
    # Initialize class
    choice = Choice()
    assert isinstance(choice, Choice)

# Generated at 2022-06-23 21:09:30.120915
# Unit test for constructor of class Choice
def test_Choice():
    # Callable class instance for generating a randomly-chosen sequence
    choice = Choice()
    result = choice(items=['a', 'b', 'c'], length=1)
    assert isinstance(result, list)
    assert result == ['a']
    result = choice(items=('a', 'b', 'c'), length=5)
    assert isinstance(result, tuple)
    assert result == ('c', 'a', 'a', 'b', 'c')
    result = choice(items='abc', length=2)
    assert isinstance(result, str)
    assert result == 'ba'
    result = choice(items='aabbbccccddddd', length=4, unique=True)
    assert isinstance(result, str)
    assert result == 'cdba'

# Generated at 2022-06-23 21:09:33.272730
# Unit test for constructor of class Choice
def test_Choice():
    provider = Choice()
    assert provider.Meta.name == 'choice'
    assert provider.Meta.provides
    assert provider.Meta.requires

# Unit tests for Choice.__call__()

# Generated at 2022-06-23 21:09:37.143948
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    items = ['a', 'b', 'c']
    # Element of the list is randomly selected 
    result = choice(items=items, length=1)
    #Test that the array only contains elements from the original list
    assert all(item in result for item in items)

# Generated at 2022-06-23 21:09:40.267511
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice('abc') in ['a', 'b', 'c']
    assert choice('abc', 3) in ['aaa', 'bbb', 'ccc']
    assert choice('abc', 2, True) in ['ab', 'ac', 'bc']

# Generated at 2022-06-23 21:09:47.868803
# Unit test for constructor of class Choice
def test_Choice():
    """Unit test for constructor of class Choice"""
    from mimesis import Choice
    choice = Choice()
    choice(items=[1,2,3])
    choice(items=[1,2,3], length=1)
    choice(items='abc', length=2)
    choice(items=[1,2,3], length=5)
    choice(items=[1,1,1,2,2,2,3,3,3,4,4,4,5,5,5], length=4, unique=True)

# Generated at 2022-06-23 21:09:48.253852
# Unit test for constructor of class Choice
def test_Choice():
    Choice()

# Generated at 2022-06-23 21:09:56.695593
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 1
    unique = False

    from mimesis import Choice
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) == 'a'
    assert choice(items=['a', 'b', 'c'], length=1) == ['b']
    assert choice(items='abc', length=2) == 'ac'
    assert choice(items=('a', 'b', 'c'), length=5) == ('a', 'b', 'c', 'a', 'a')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'dacc'

# Generated at 2022-06-23 21:10:04.987851
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

if __name__ == '__main__':
    test_Choice___call__()

# Generated at 2022-06-23 21:10:12.314042
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice(seed=123)
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-23 21:10:21.075015
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == \
        ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:10:31.797339
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    items = ('a', 'b', 'c')
    unique = False
    length = 1
    choice = Choice()
    result = choice(items, length, unique)
    if not isinstance(result, collections.abc.Sequence):
        raise AssertionError(result)
    if len(result) != length:
        raise AssertionError(result)
    for c in result:
        if not c in items:
            raise AssertionError(c)
    if isinstance(result, tuple) and result == items:
        raise AssertionError(result)
    unique = True
    result = choice(items, length, unique)
    if len(set(result)) != length:
        raise AssertionError(result)

# Generated at 2022-06-23 21:10:40.335392
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ab', 'bc', 'ac']

# Generated at 2022-06-23 21:10:42.205564
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice.Meta.name == 'choice'


# Generated at 2022-06-23 21:10:49.441570
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice(seed=1)

    # print(c(items=['a', 'b', 'c'], length=1, unique=False))
    # print(c(items=['a', 'b', 'c'], length=1, unique=True))
    # print(c(items=['a', 'b', 'c'], length=2, unique=False))
    # print(c(items=['a', 'b', 'c'], length=2, unique=True))
    # print(c(items=[], length=1, unique=False))
    # print(c(items=[], length=1, unique=True))
    # print(c(items=[], length=0, unique=False))
    # print(c(items=[], length=0, unique=True))
    # print(c(items=(),

# Generated at 2022-06-23 21:10:58.586705
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender
    from mimesis.exceptions import NonEnumerableError
    from mimesis.providers.person import Person

    choice = Choice(seed=1)
    # General use.
    choice(items=['a', 'b', 'c']) == 'c'
    choice(items=['a', 'b', 'c'], length=1) == ['a']
    choice(items='abc', length=2) == 'ba'
    choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:11:08.750728
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    obj = Choice()

    assert obj(items=['a', 'b', 'c'])
    assert obj(items=['a', 'b', 'c'], length=1)
    assert obj(items='abc', length=2)
    assert obj(items=('a', 'b', 'c'), length=5)
    assert obj(items='aabbbccccddddd', length=4, unique=True)

    try:
        obj(items=['a', 'b', 'c'], length='a')
    except Exception as e:
        assert type(e) == TypeError

    try:
        obj(items={}, length=5)
    except Exception as e:
        assert type(e) == TypeError

    try:
        obj(items=[], length=5)
    except Exception as e:
        assert type

# Generated at 2022-06-23 21:11:11.028389
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice is not None


# Generated at 2022-06-23 21:11:15.427871
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Arrange
    from mimesis import Choice

    c = Choice()
    sequence = ['a', 'b', 'c']
    # Act
    result = c(sequence)

    # Assert
    assert isinstance(result, str)
    assert result in sequence

# Generated at 2022-06-23 21:11:22.010037
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    
    choice = Choice()
    
    assert isinstance(choice(items=['a', 'b', 'c'], length=1), list)
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert isinstance(choice(items=('a', 'b', 'c'), length=5), tuple)
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-23 21:11:31.698139
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from unittest import TestCase
    from unittest.mock import patch
    from mimesis import Choice

    class TestChoice(TestCase):
        def setUp(self):
            """Prepare data for testing."""
            self.choice = Choice()

        def test_provide_one_element_from_sequence(self):
            element = self.choice(items='abc')
            self.assertIsInstance(element, str)
            self.assertEqual(1, len(element))
            self.assertIn(element, 'abc')

        def test_provide_unique_elements_from_sequence(self):
            elements_number = 5
            result = self.choice(items='aabbc', length=elements_number,
                                 unique=True)

# Generated at 2022-06-23 21:11:40.818816
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    class Data:
        """Class for test."""

        @staticmethod
        def person():
            return Person('en').create(gender=Gender.FEMALE)

        @staticmethod
        def people() -> List[str]:
            return [Person('en').create(gender=Gender.FEMALE) for _ in range(3)]

    data = Data()

    def test_choice():
        choice = Choice('en')
        assert isinstance(choice.person, Callable)
        assert isinstance(choice.people, Callable)

    def test_person():
        choice = Choice('en').person
        assert choice() != None

    def test_people():
        choice = Choice('en')


# Generated at 2022-06-23 21:11:51.748071
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    try:
        import pytest
        from pytest import raises
    except ImportError as e:
        print(e)

    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) in ['ba', 'ab', 'ac', 'bc']

# Generated at 2022-06-23 21:11:58.987796
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.providers import Provider
    from mimesis.enums import Gender
    from mimesis.enums import PersonInfo
    from mimesis.enums import NumberSystem
    from mimesis.enums import Language
    from mimesis.enums import BusinessSector

    choice = Choice()
    provider = Provider()

    # Call with items as bytes
    assert choice(items=b'abc')

    # Call with items as non-sequence
    try:
        choice(items=None)
    except TypeError:
        pass

    # Call with length as non-integer
    try:
        choice(items=b'abc', length=None)
    except TypeError:
        pass

    # Call with empty items
    try:
        choice(items=[])
    except ValueError:
        pass

    # Call

# Generated at 2022-06-23 21:12:04.718914
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert (choice(items=['a', 'b', 'c']) == 'c')
    assert (choice(items=['a', 'b', 'c'], length=1) == ['a'])
    assert (choice(items='abc', length=2) == 'ba')
    assert (choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c'))
    assert (choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba')

# Generated at 2022-06-23 21:12:14.883850
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice as c
    c = c()
    assert c(['a', 'b', 'c']) in ['a', 'b', 'c']
    assert c(['a', 'b', 'c'], 1) == ['c']
    assert c('abc', 2) in ['ba', 'ac', 'bc', 'cb', 'ab']
    assert len(c(('a', 'b', 'c'), 5)) == 5
    assert c('aabbbccccddddd', 4, True) in ['bcad', 'bcda', 'bacd', 'acbd', 'acdb', 'cabd', 'cadb', 'cdab', 'cbad', 'cdba']

# Generated at 2022-06-23 21:12:25.421555
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.exceptions import ValueError
    try:
        choice = Choice()
        choice(items=['a', 'b', 'c'], length=1)
        choice(items=['a', 'b', 'c'], unique=True)
        choice(items=['a', 'b', 'c'], unique=False)
        choice(items=['a', 'b', 'c'])
        choice(items='abc', length=2)
        choice(items=('a', 'b', 'c'),length=5)
        choice(items='aabbbccccddddd', length=4, unique=True)
    except ValueError:
        print('ValueError')
    else:
        print('OK')

# Generated at 2022-06-23 21:12:26.814763
# Unit test for constructor of class Choice
def test_Choice():
    # TODO: Test with unittest
    choice = Choice()

# Generated at 2022-06-23 21:12:29.891566
# Unit test for constructor of class Choice
def test_Choice():
    m = Choice()
    items = ['a', 'b', 'c']
    for i in range(10):
        assert m(items=items, length=i) == items[i]
        assert m(items=items) == items[i]


# Generated at 2022-06-23 21:12:40.594531
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    from mimesis.enums import Gender

    choice = Choice(gender=Gender.FEMALE)

    result = choice(items=['a', 'b', 'c'])
    assert result == 'c'
    result = choice(items=['a', 'b', 'c'], length=1)
    assert result == ['a']
    result = choice(items='abc', length=2)
    assert result == 'ba'
    result = choice(items=('a', 'b', 'c'), length=5)
    assert result == ('c', 'a', 'a', 'b', 'c')
    result = choice(items='aabbbccccddddd', length=4, unique=True)
    assert result == 'cdba'

# Generated at 2022-06-23 21:12:50.869507
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method __call__ of class Choice."""
    c = Choice()
    assert c.__call__(['a', 'b', 'c']) in ['a', 'b', 'c']
    assert c.__call__(['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert c.__call__('abc', length=2) in ['ab', 'bc', 'ca']

# Generated at 2022-06-23 21:12:58.439428
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert(choice(items=['a', 'b', 'c']) == 'c')
    assert(choice(items=['a', 'b', 'c'], length=1) == ['a'])
    assert(choice(items='abc', length=2) == 'ba')
    assert(choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c'))
    try:
        choice(items='aabbbccccddddd', length=4, unique=True)
    except ValueError:
        pass
    try:
        choice(items=['a', 'b', 'c'], length=1, unique=True)
    except TypeError:
        pass

# Generated at 2022-06-23 21:13:07.986346
# Unit test for constructor of class Choice
def test_Choice():
    """Test for Choice class."""
    from mimesis import Choice

    choice = Choice()

    assert choice.choice.__name__ == "call"
    assert choice.choice.__doc__ == Choice.__doc__
    assert choice.choice('ab', 1, True) == 'a'
    assert choice.choice(['a', 'b', 'c']) == 'c'
    assert choice.choice(['a', 'b', 'c'], 1) == ['a']
    assert choice.choice('abc', 2) == 'ba'
    assert choice.choice(('a', 'b', 'c'), 5) == ('c', 'a', 'a', 'b', 'c')
    assert choice.choice('aabbbccccddddd', 4, True) == 'cdba'
    # assert choice.choice(items=[]) ==

# Generated at 2022-06-23 21:13:09.621180
# Unit test for constructor of class Choice
def test_Choice():
    """Testing constructor of class Choice."""
    c = Choice()
    assert c.seed is not None

# Generated at 2022-06-23 21:13:18.427490
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    class Response:

        def __init__(self, unique: bool, num: int, list: list):
            self.unique = unique
            self.num = num
            self.list = list

    # Valid parameters
    number = 3
    unique = True
    falsy_list: list = []
    falsy_list.append(0)
    falsy_list.append(0)
    falsy_list.append(0)
    falsy_list.append(0)
    falsy_list.append(0)
    falsy_list.append(0)
    falsy_list.append(0)
    falsy_list.append(0)
    response: Response = Response(unique=True, num=number, list=falsy_list)

    # Invalid parameters

# Generated at 2022-06-23 21:13:27.038275
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    # Test TypeError: For non-sequence items or non-integer length
    with pytest.raises(TypeError):
        choice = Choice()
        choice(items=123, length=0)

    with pytest.raises(TypeError):
        choice = Choice()
        choice(items=[1, 2, 3], length='s')

    # Test ValueError: If negative length or insufficient unique elements
    with pytest.raises(ValueError):
        choice = Choice()
        choice(items=[1, 2, 3], length=-1)

    with pytest.raises(ValueError):
        choice = Choice()
        choice(items=[1, 2, 3], length=5, unique=True)

    # Test Choice.__call__() method with list
    choice = Choice()

# Generated at 2022-06-23 21:13:35.619668
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice() in ('a', 'b', 'c')
    assert choice(items=('a', 'b', 'c')) in ('a', 'b', 'c')
    assert choice(items=('a', 'b', 'c', 'd', 'e', 'f'), length=5) == \
        ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) in \
        ('cdba', 'dbac', 'dcab', 'dabc', 'dbca', 'dcba', 'bdac')

# Generated at 2022-06-23 21:13:41.933051
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = [1, 2, 3]
    length = 5
    examples = {
        'choice(items=items)': choice(items),
        'choice(items=items, length=length)': choice(items, length=length),
        'choice(items=items, length=length, unique=True)': choice(items, length=length, unique=True)
    }
    return examples

if __name__ == '__main__':
    print(test_Choice___call__())

# Generated at 2022-06-23 21:13:43.123977
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice


# Generated at 2022-06-23 21:13:52.125931
# Unit test for method __call__ of class Choice

# Generated at 2022-06-23 21:13:54.442976
# Unit test for constructor of class Choice
def test_Choice():
    item = Choice(items=['a', 'b', 'c'], length=1, unique=False)
    assert item == 'a'

# Generated at 2022-06-23 21:14:02.584390
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ab', 'ac', 'bc']
    assert choice(items=['a', 'b', 'c'], length=5) in [
        ['a', 'b', 'c', 'c', 'c'],
        ['a', 'b', 'b', 'c', 'c'],
        ['a', 'b', 'b', 'b', 'c'],
    ]

# Generated at 2022-06-23 21:14:10.390350
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(['a', 'b', 'c']) == 'c'
    assert choice(['a', 'b', 'c'], 1) == ['a']
    assert choice('abc', 2) == 'ba'
    assert choice(('a', 'b', 'c'), 5) == ('c', 'a', 'a', 'b', 'c')
    assert choice('aabbbccccddddd', 4, True) == 'cdba'
    try:
        choice(1)
    except TypeError:
        pass
    try:
        choice([])
    except ValueError:
        pass
    try:
        choice('abc', -1)
    except ValueError:
        pass

# Generated at 2022-06-23 21:14:20.002065
# Unit test for constructor of class Choice
def test_Choice():
    '''
    Info:
        Function for testing constructor of class Choice in mimesis.builtins.

    Parameter:
        None

    Return:
        bool: The return value. True for success, False otherwise.
    '''
    test_obj = Choice(_use_fake=True, fake_factory=None, locales=None, seed=None, custom_data=None)
    assert test_obj.meta == Choice.Meta.name
    assert callable(test_obj)
    assert test_obj._use_fake == True
    assert test_obj._fake is None
    assert test_obj.locales == None
    assert test_obj.seed == None
    assert test_obj.custom_data == None


# Generated at 2022-06-23 21:14:23.394076
# Unit test for constructor of class Choice
def test_Choice():
    """Create :class:`~mimesis.providers.choice.Choice` instance."""
    str1 = Choice()
    str2 = Choice()
    assert str1 is not str2

# Generated at 2022-06-23 21:14:31.134843
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 1
    unique = True
    choice = Choice()

    # list
    res = choice(items=items)
    assert len(res) == 1
    assert res in items

    # list
    res = choice(items=items, length=length)
    assert len(res) == length
    assert res in items

    # str
    res = choice(items=str(items), length=length)
    assert len(res) == length
    assert res in items

    # tuple
    res = choice(items=tuple(items), length=length)
    assert len(res) == length
    assert res in items

    # list
    res = choice(items=items, length=length, unique=unique)
    assert len(res) == length
    assert res in items



# Generated at 2022-06-23 21:14:37.053288
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:14:46.585778
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    provider = Choice()
    items_a = ['a', 'b', 'c']
    items_b = 'abc'
    items_c = ('a', 'b', 'c')
    items_d = 'aabbbccccddddd'

    assert (
        provider(items=items_a, length=0) ==
        provider.choice.__call__(items=items_a, length=0)
        ==
        'c'
    )
    assert (
        provider(items=items_a, length=1) ==
        provider.choice.__call__(items=items_a, length=1)
        ==
        ['a']
    )

# Generated at 2022-06-23 21:14:49.256496
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test Choice.__call__ method."""
    choice = Choice()
    sequence = ['a', 'b', 'c']
    length = 1
    unique = False
    assert choice(sequence, length, unique)


# Generated at 2022-06-23 21:14:58.284612
# Unit test for constructor of class Choice
def test_Choice():

    choice = Choice()
    items = ['a', 'b', 'c']
    length = 10
    unique = False
    data = choice(items=items, length=length, unique=unique)
    assert len(data) == length

    items = ['a', 'b', 'c']
    length = 0
    unique = False
    data = choice(items=items, length=length, unique=unique)
    assert len(data) == 1

    items = ['a', 'b', 'c']
    length = 1
    unique = False
    data = choice(items=items, length=length, unique=unique)
    assert len(data) == length

    items = 'abc'
    length = 2
    unique = False
    data = choice(items=items, length=length, unique=unique)
    assert len(data) == length

# Generated at 2022-06-23 21:14:58.941628
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()

# Generated at 2022-06-23 21:15:06.397008
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'



# Generated at 2022-06-23 21:15:12.947508
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    if choice is None:
        raise SystemError

    with pytest.raises (TypeError):
        choice(items=['a', 'b', 'c', 'd'], length=0,unique=False)

    with pytest.raises (TypeError):
        choice(items=['a', 'b', 'c', 'd'], length='0',unique=True)

    with pytest.raises (TypeError):
        choice(items=['a', 'b', 'c', 'd'], length='a',unique=False)

    with pytest.raises (TypeError):
        choice(items=['a', 'b', 'c', 'd'], length=1,unique='False')


# Generated at 2022-06-23 21:15:14.547907
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__class__().__call__(["a","b"]) == "a"


# Generated at 2022-06-23 21:15:18.877110
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    #print(c.items)
    #print(c.length)
    #print(c.unique)


# Generated at 2022-06-23 21:15:19.549811
# Unit test for constructor of class Choice
def test_Choice():
    assert callable(Choice)


# Generated at 2022-06-23 21:15:20.747729
# Unit test for constructor of class Choice
def test_Choice():
    ch = Choice()
    assert ch


# Generated at 2022-06-23 21:15:22.137150
# Unit test for constructor of class Choice
def test_Choice():
    ch = Choice()
    assert ch.meta.name == 'choice'


# Generated at 2022-06-23 21:15:28.905719
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    print(choice(items=['a', 'b', 'c']))
    print(choice(items=['a', 'b', 'c'], length=1))
    print(choice(items='abc', length=2))
    print(choice(items=('a', 'b', 'c'), length=5))
    print(choice(items='aabbbccccddddd', length=4, unique=True))

if __name__ == "__main__":
    test_Choice()

# Generated at 2022-06-23 21:15:37.551140
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.providers.choice import Choice
    choice = Choice()

    def test_items_is_not_sequence():
        assert choice(items=1)

    def test_length_is_not_integer():
        assert choice(items=[1, 2, 3], length=1.1)

    def test_items_empty_sequence():
        assert choice(items=[])

    def test_length_negative_integer():
        assert choice(items=[1, 2, 3], length=-1)

    def test_items_not_unique_and_length_0():
        assert choice(items=[1, 2, 3])

    def test_items_not_unique_and_length_1():
        assert choice(items=[1, 2, 3], length=1)


# Generated at 2022-06-23 21:15:48.015910
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Perform unit tests on Choice.__call__."""
    choice = Choice()
    assert choice(items=[1, 2, 3, 4], length=5, unique=True)
    assert choice(items=['a', 'b', 'c'], length=1)
    assert choice(items='abc', length=2)
    assert choice(items=('a', 'b', 'c'), length=5)
    assert choice(items='aabbbccccddddd', length=4, unique=True)
    try:
        choice(items=[], length=1)
    except ValueError:
        pass
    try:
        choice(items=[1, 2, 3, 4], length=-1, unique=True)
    except ValueError:
        pass

# Generated at 2022-06-23 21:15:50.140038
# Unit test for constructor of class Choice
def test_Choice():
    provider = Choice()
    assert isinstance(provider, Choice)


# Generated at 2022-06-23 21:15:58.779381
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    print(choice(items=['a', 'b', 'c', 'c']))
    print(choice(items=['a', 'b', 'c'], length=2))
    print(choice(items=('a', 'b', 'c'), length=2))
    print(choice(items='abc', length=2))
    print(choice(items=('a', 'b', 'c'), length=5))
    print(choice(items='aabbbccccddddd', length=4, unique=False))
    print(choice(items='aabbbccccddddd', length=4, unique=True))

# Generated at 2022-06-23 21:16:05.672359
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert 'c' == c(['a', 'b', 'c'])
    assert ['a'] == c(['a', 'b', 'c'], 1)
    assert 'ba' == c('abc', 2)
    assert ('c', 'a', 'a', 'b', 'c') == c(('a', 'b', 'c'), 5)
    assert 'cdba' == c('aabbbccccddddd', 4, True)

# Generated at 2022-06-23 21:16:12.796574
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert c(items=['a', 'b', 'c']) == 'c'
    assert c(items=['a', 'b', 'c'], length=1) == ['a']
    assert c(items='abc', length=2) == 'ba'
    assert c(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert c(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:16:13.701293
# Unit test for constructor of class Choice
def test_Choice():
    assert callable(Choice)


# Generated at 2022-06-23 21:16:20.939478
# Unit test for constructor of class Choice
def test_Choice():
    rand = Choice()
    rand.seed(0)
    assert rand.__call__(items=['a','b','c'],length=4,unique=True) == ['c','b','a','b'] # Why not work with set?
    assert rand.__call__(items=('a','b','c'),length=4,unique=True) == ('c','b','a','b') # Why not work with set?
    assert rand.__call__(items='abc',length=4,unique=True) == 'cbab'      # Why not work with set?
    assert rand.__call__(items=['a','b','c']) == 'a'

# Generated at 2022-06-23 21:16:30.711306
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Pre-defined data
    choices = ['a', 'b', 'c']
    choices_set = set(choices)
    unique_length = len(choices_set)
    non_unique_length = 5
    duplicate_choice = 'c'
    duplicate_choice_index = choices.index(duplicate_choice)

    # Empty choices
    items = None
    length = 0
    unique = False
    choice = Choice()
    expected = None
    assert choice(items, length, unique) == expected

    # Non-empty choices, bare element pick
    items = choices
    length = 0
    unique = False
    choice = Choice()
    expected = duplicate_choice
    assert choice(items, length, unique) == expected

    # Non-empty choices, unique sequence pick
    items = choices
    length = unique_length


# Generated at 2022-06-23 21:16:31.782608
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TODO: cover tests for choice()
    pass

# Generated at 2022-06-23 21:16:37.618926
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-23 21:16:42.938341
# Unit test for constructor of class Choice
def test_Choice():
    test = Choice()

    print(test(items=['a', 'b', 'c']))
    print(test(items=['a', 'b', 'c'], length=1))
    print(test(items='abc', length=2))
    print(test(items=('a', 'b', 'c'), length=5))
    print(test(items='aabbbccccddddd', length=4, unique=True))


if __name__ == "__main__":
    test_Choice()

# Generated at 2022-06-23 21:16:53.773115
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert c('a') in ['a']
    assert c(['a'], 1) in [['a']]
    assert c(['a'], 2) in ['aa']
    assert c(('a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'), 1) in [('a',)]
    assert c(['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'], 1) in [['a']]

# Generated at 2022-06-23 21:17:02.242237
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    producer = Choice()
    result = producer(items=['a', 'b', 'c'])
    assert result in ['a', 'b', 'c']

    result = producer(items=['a', 'b', 'c'], length=1)
    assert result == ['a'] or result == ['b'] or result == ['c']

    result = producer(items='abc', length=2)
    assert result == 'ba' or result == 'ab' or result == 'cb' or result == 'ac' or result == 'bc' or result == 'ca'

    result = producer(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-23 21:17:03.181898
# Unit test for constructor of class Choice
def test_Choice():
    obj = Choice()
    obj.__str__()
    obj.__repr__()

# Generated at 2022-06-23 21:17:09.134552
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    "Test if Choice.__call__() is working"
    from mimesis import Choice
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

    try:
        choice(items=None, length=2)
    except TypeError:
        pass
    else:
        assert False


# Generated at 2022-06-23 21:17:19.155908
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    data_1 = choice.__call__(items=['a', 'b', 'c'], length=0)
    assert data_1 == 'c'
    data_2 = choice.__call__(items=['a', 'b', 'c'], length=1)
    assert data_2 == ['a']
    data_3 = choice.__call__(items='abc', length=2)
    assert data_3 == 'ba'
    data_4 = choice.__call__(items=('a', 'b', 'c'), length=5)
    assert data_4 == ('c', 'a', 'a', 'b', 'c')
    data_5 = choice.__call__(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-23 21:17:29.459206
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import logging
    import sys
    logger = logging.getLogger('mimesis')
    logger.setLevel(logging.DEBUG)
    stream_handler = logging.StreamHandler(sys.stdout)
    logger.addHandler(stream_handler)

    # exception tests
    items = [1, 2, 3]
    length = 2
    length2 = 1
    foo = Choice()

    # logger.info("foo(items=items, length=%d)" % length)
    sequence = foo(items=items, length=length)
    # logger.info('sequence = %s' % sequence)
    assert isinstance(sequence, list)
    assert len(sequence) == length
    assert set(sequence).issubset(set(items))

    # logger.info("foo(items=items, length=%d)" % length2)

# Generated at 2022-06-23 21:17:31.167140
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)


# Generated at 2022-06-23 21:17:33.679059
# Unit test for constructor of class Choice
def test_Choice():
    """Test for Choice class."""
    try:
        Choice(10, 2, False)
    except Exception:
        assert False
    assert True

# Generated at 2022-06-23 21:17:43.830443
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    instance = Choice("en")
    assert issubclass(type(instance), Choice, msg=True)
    assert isinstance(instance, Choice, msg=True)
    assert isinstance(instance, BaseProvider, msg=True)
    assert instance.__call__(items=[0, 1], length=1, unique=True)
    assert instance.__call__(items=(0, 1), length=1, unique=True)
    assert instance.__call__(items='', length=1, unique=True)
    assert instance.__call__(items=[0, 1], length=0, unique=True)
    assert instance.__call__(items=[0, 1], length=0, unique=False)
    assert instance.__call__(items=None, length=0, unique=False)
    return True

# Generated at 2022-06-23 21:17:52.906067
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender
    # test for Choice.__call__(items=[], length=0)
    choice = Choice(gender=Gender.FEMALE)
    assert choice(items=[], length=0) == ''

    # test for Choice.__call__(items, length=0)
    assert choice(items=['a', 'b', 'c'], length=0) in ['a', 'b', 'c']

    # test for Choice.__call__(items, length=1)
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']

    # test for Choice.__call__(items, length=2)
    assert choice(items='abc', length=2) in ['ac', 'bc', 'ab']

# Generated at 2022-06-23 21:17:54.746381
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice is not None


# Generated at 2022-06-23 21:17:57.542438
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'


# Generated at 2022-06-23 21:17:59.888804
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(['a', 'b', 'c']) in ['a', 'b', 'c']


# Generated at 2022-06-23 21:18:10.952794
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    from mimesis.enums import DataField
    from mimesis.providers.generic import Generic
    from mimesis.providers.locale import Locale
    from mimesis.providers.network import Network
    from mimesis.providers.number import Number
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    from mimesis.providers.time import Time

    # Start tests for method __call__ of class Choice

    # Case: non-sequence items argument
    try:
        choice = Choice()
        choice(items=1)
    except TypeError:
        pass

    # Case: empty items argument

# Generated at 2022-06-23 21:18:16.259614
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for the Choice class."""
    choice = Choice()

#    choice(items=['a', 'b', 'c'])
#    choice(items=['a', 'b', 'c'], length=1)
#    choice(items='abc', length=2)
#    choice(items=('a', 'b', 'c'), length=5)
#    choice(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-23 21:18:23.741438
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    print( c.__call__(['a', 'b', 'c'], 1, True) )
    print( c.__call__(('a', 'b', 'c', 'd'), 2, True) )
    print( c.__call__(['a', 'b', 'c', 'd'], 2, False) )
    print( c.__call__(['a', 'b', 'c'], 1, False) )


# Generated at 2022-06-23 21:18:32.586787
# Unit test for constructor of class Choice
def test_Choice():
    """Unit test for constructor of class Choice
    """
    choice = Choice()
    assert type(choice) == Choice
    try:
        choice(items='abc', length=2.1)
        assert False
    except TypeError as e:
        assert str(e) == '**length** must be integer.'
    try:
        choice(items={})
        assert False
    except TypeError as e:
        assert str(e) == '**items** must be non-empty sequence.'
    try:
        choice(items=())
        assert False
    except ValueError as e:
        assert str(e) == '**items** must be a non-empty sequence.'

# Generated at 2022-06-23 21:18:39.583317
# Unit test for constructor of class Choice
def test_Choice():
    
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:18:42.577030
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method __call__ of class Choice."""
    c = Choice()
    d = c('abcd')
    assert isinstance(d, str)
    e = c('abcd', 2)
    assert isinstance(e, list)
    f = c('abcd', 2, True)
    assert isinstance(f, str)

# Generated at 2022-06-23 21:18:45.615721
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    print(choice(items=['a', 'b', 'c']))


# Generated at 2022-06-23 21:18:47.500483
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice('abc', 2) == 'cb'


# Generated at 2022-06-23 21:18:53.233629
# Unit test for constructor of class Choice
def test_Choice():
    """Test class for Choice"""

    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.person import Person

    person = Person('en')
    person.create(gender=Gender.MALE)

    assert person.__init__
    assert person.seed

# Generated at 2022-06-23 21:18:55.539691
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    items = ['a', 'b', 'c']
    number = 1
    unique = True
    c.__call__(items = items, length = number, unique = unique)


# Generated at 2022-06-23 21:18:59.942577
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['foo', 'bar', 'baz']
    length = 2
    choice = Choice()
    result = choice(items, length, False)
    assert isinstance(result, str)
    assert len(result) == length
    for item in result:
        assert item in items
    result = choice(items, length, True)
    assert len(result) == length
    for item in result:
        assert item in items