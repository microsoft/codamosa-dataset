

# Generated at 2022-06-23 21:09:08.637750
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # (items: Optional[Sequence[Any]],
    # length: int = 0,
    # unique: bool = False) -> Union[Sequence[Any], Any]:
    
    from mimesis import Choice
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Testing TypeError


# Generated at 2022-06-23 21:09:12.448015
# Unit test for constructor of class Choice
def test_Choice():
    rand = Choice()
    rand.choice(items=['a', 'b', 'c'], length=2)
    rand.choice(items=('a', 'b', 'c'), length=5)
    rand.choice(items='aabbbccccddddd', length=4, unique=True)



# Generated at 2022-06-23 21:09:13.942545
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-23 21:09:16.534933
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis.providers.base import BaseProvider
    from .choice import Choice
    choice = Choice()
    assert isinstance(choice, BaseProvider)

# Generated at 2022-06-23 21:09:20.152694
# Unit test for constructor of class Choice
def test_Choice():
    c1 = Choice()
    items = ['a', 'b', 'c']
    c1.__call__(items)
    assert isinstance(c1,Choice)


# Generated at 2022-06-23 21:09:26.572337
# Unit test for constructor of class Choice
def test_Choice():
    if __name__ == '__main__':
        from mimesis import Choice
        choice = Choice()
        choice(items=['a', 'b', 'c'])
        choice(items=['a', 'b', 'c'], length=1)
        choice(items='abc', length=2)
        choice(items=('a', 'b', 'c'), length=5)
        choice(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-23 21:09:36.297783
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    choice = Choice()

    result = choice(items=['a', 'b', 'c'])
    assert result == 'c'

    result = choice(items=['a', 'b', 'c'], length=1)
    assert result == ['a']

    result = choice(items='abc', length=2)
    assert result == 'ba'

    result = choice(items=('a', 'b', 'c'), length=5)
    assert result == ('c', 'a', 'a', 'b', 'c')

    result = choice(items='aabbbccccddddd', length=4, unique=True)
    assert result == 'cdba'

# Generated at 2022-06-23 21:09:37.917097
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = ['a', 'b', 'c']
    length = choice.random.randint(2, 3)
    print(choice(items=items, length=length))



# Generated at 2022-06-23 21:09:38.734669
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)


# Generated at 2022-06-23 21:09:39.140511
# Unit test for constructor of class Choice
def test_Choice():
    pass

# Generated at 2022-06-23 21:09:40.070681
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice is not None

# Generated at 2022-06-23 21:09:44.045611
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert type(Choice()._Choice__call__(items=['a', 'b', 'c'])) == str
    assert type(Choice()._Choice__call__(items=['a', 'b', 'c'], length=1)) == list
    assert type(Choice()._Choice__call__(items='abc', length=2)) == str
    assert type(Choice()._Choice__call__(items=('a', 'b', 'c'), length=5)) == tuple
    assert type(Choice()._Choice__call__(items='aabbbccccddddd', length=4, unique=True)) == str

# Generated at 2022-06-23 21:09:49.732243
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice() # initialize class
    assert choice.__call__([1, 2, 3, 4, 5]) in [1, 2, 3, 4, 5]
    assert choice.__call__([1, 2, 3, 4, 5], length=3) in [[1, 2, 3], [1, 2, 4], [1, 2, 5], [1, 3, 4], [1, 3, 5], [1, 4, 5], [2, 3, 4], [2, 3, 5], [2, 4, 5], [3, 4, 5]]

# Generated at 2022-06-23 21:09:52.684218
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method _call_ of class Choice"""
    choice = Choice()
    result = choice(items=['a', 'b', 'c'])
    assert result in ['a', 'b', 'c']


# Generated at 2022-06-23 21:09:55.481032
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert repr(choice) == 'Choice()'
    assert repr(choice()) == "Choice()()"
    assert len(repr(choice)) == len('Choice()')


# Generated at 2022-06-23 21:09:57.468616
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)
    assert isinstance(choice.random, Choice)



# Generated at 2022-06-23 21:10:05.277473
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = ['a', 'b', 'c']
    test_inputs = [
        ([items, 0, False], 'c'),
        ([items, 1, False], ['a']),
        ([items, 2, False], 'ba'),
        ([items, 5, False], ('c', 'a', 'a', 'b', 'c')),
        ([items, 4, True], 'cdba'),
    ]
    for test_input, expected_result in test_inputs:
        assert choice(*test_input) == expected_result

# Generated at 2022-06-23 21:10:14.452922
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    choice(items=['a', 'b', 'c'])
    choice(items=['a', 'b', 'c'], length=1)
    choice(items='abc', length=2)
    choice(items=('a', 'b', 'c'), length=5)
    choice(items='aabbbccccddddd', length=4, unique=True)

    try:
        choice(items=['a', 'b', 'c'], length='foo')
    except TypeError:
        pass
    else:
        raise AssertionError("TypeError expected")

    try:
        choice(items='Foo', length=1)
    except TypeError:
        pass
    else:
        raise AssertionError("TypeError expected")


# Generated at 2022-06-23 21:10:26.119357
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import DataType
    from mimesis.exceptions import NonEnumerableError
    from mimesis.typing import Code

    items = tuple(set(range(10)))
    length = 5
    unique = True
    c = Choice()
    result = c(items=items, length=length, unique=unique)

    assert isinstance(result, Code)
    assert len(result) == length

    for i in result:
        assert i in items

    result = c(items=items, length=length, unique=False)

    assert isinstance(result, Code)
    assert len(result) == length

    for i in result:
        assert i in items

    result = c(items='mimesis', length=6)

    assert isinstance(result, Code)
    assert len(result) == length

# Generated at 2022-06-23 21:10:27.489162
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice().__class__.__name__ == 'Choice'


# Generated at 2022-06-23 21:10:35.281875
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert callable(Choice)
    # Test
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'



# Generated at 2022-06-23 21:10:43.457036
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    provider = Choice()
    # test case 1
    assert provider(['a', 'b', 'c']) in ['a', 'b', 'c']
    # test case 2
    assert len(provider(['a', 'b', 'c'], length=1)) == 1
    # test case 3
    assert len(provider(items='abc', length=2)) == 2
    # test case 4
    assert len(provider(items=('a', 'b', 'c'), length=5)) == 5
    # test case 5
    assert len(provider(items='aabbbccccddddd', length=4, unique=True)) == 4


# Generated at 2022-06-23 21:10:53.106159
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.providers import Choice, Datetime
    from mimesis.providers.base import BaseProvider
    from mimesis.types import DatetimeFormat
    import pytest
    from typing import Any, Dict, List, Optional, Sequence, Union

    # Test for ValueError: If negative length or insufficient unique elements
    items = ['a', 'b', 'c']
    length = -1
    unique = True
    Choice.seed(123456789)
    with pytest.raises(ValueError) as e_info:
        Choice().__call__(items=items, length=length, unique=unique)
    assert 'There are not enough unique elements in **items** to provide the specified **number**' in str(e_info)

    # Test for TypeError: For non-sequence items or non-integer length

# Generated at 2022-06-23 21:10:58.996811
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    choice(items=['a', 'b', 'c'])
    test2 = choice(items=['a', 'b', 'c'], length=1)
    assert isinstance(test2, list)

    test3 = choice(items='abc', length=2)
    assert isinstance(test3, str)

    test4 = choice(items=('a', 'b', 'c'), length=5)
    assert isinstance(test4, tuple)

    test5 = choice(items='aabbbccccddddd', length=4, unique=True)
    assert isinstance(test5, str)

# Generated at 2022-06-23 21:11:01.173764
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert callable(choice)

# Unit tests for method __call__ of class Choice

# Generated at 2022-06-23 21:11:02.186747
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice(random=None, pseudo=None)

# Generated at 2022-06-23 21:11:10.982169
# Unit test for constructor of class Choice
def test_Choice():
    """Test class Choice."""

    # Test ability to handle string values
    assert Choice().choice('abc', 2) == 'ba'
    assert Choice().choice('abc', 5) == 'adeaa'
    assert Choice().choice('aabbbccccddddd', 4, True) == 'cdba'

    # Test ability to handle list values
    assert Choice().choice(['a', 'b', 'c'], 2) in [['a', 'b'], ['b', 'a']]

# Generated at 2022-06-23 21:11:19.128200
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    from collections.abc import Sequence
    from typing import Union
    from hypothesis import strategies
    from hypothesis import given
    import hypothesis.extra.numpy as hyp_np
    from hypothesis.strategies import composite

    # Lower bound exclusive, upper bound inclusive
    INTEGERS_IN_RANGE = strategies.integers(0, 100)
    int_ints_in_range = (strategies.integers(0, len(int_ints))
                         for int_ints in hyp_np.integer_dtypes())
    int_ints_in_range_unique = (strategies.integers(0, len(set(int_ints)))
                                for int_ints in hyp_np.integer_dtypes())


# Generated at 2022-06-23 21:11:20.641511
# Unit test for constructor of class Choice
def test_Choice():
    a = Choice()
    assert a is not None

# Generated at 2022-06-23 21:11:21.215902
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-23 21:11:26.447334
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    tester = Choice()

    assert isinstance(tester(items=['a', 'b', 'c']), str)
    assert isinstance(tester(items=('a', 'b', 'c'), length=1), tuple)
    assert isinstance(tester(items='aabbbccccddddd', length=4, unique=True), str)


# Generated at 2022-06-23 21:11:28.255907
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice(items = [1, 2, 3]) == Choice.__call__(Choice(), [1, 2, 3])

# Generated at 2022-06-23 21:11:28.914934
# Unit test for constructor of class Choice
def test_Choice():
    Choice()

# Generated at 2022-06-23 21:11:30.581496
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    provider = Choice()
    assert provider('abcd') in 'abcd'

# Generated at 2022-06-23 21:11:37.236720
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    
    items_1 = ['a', 'b', 'c']
    items_2 = 'abc'
    items_3 = ('a', 'b', 'c')
    items_4 = 'aabbbccccddddd'
    
    assert isinstance(choice, Choice)
    assert choice(items = items_1) in items_1
    assert choice(items=items_2, length=1) in ['a', 'b', 'c']
    assert choice(items=items_2, length=2) in ['aa', 'bb', 'cc']
    assert len(choice(items=items_3, length=5)) == 5
    assert len(choice(items=items_4, length=4, unique=True)) == 4
    assert choice(items='abc', length=5) not in items_1

# Generated at 2022-06-23 21:11:38.466881
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert c != None


# Generated at 2022-06-23 21:11:50.420799
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    print(str(Choice()(items=['a', 'b', 'c'], length=2)))
    print(str(Choice()(items=['a', 'b', 'c'], length=4)))
    print(str(Choice()(items=['a', 'b', 'c'], length=2, unique=True)))
    print(str(Choice()(items=['a', 'b', 'c'], length=4, unique=True)))
    print(str(Choice()(items=['a', 'b', 'c'], unique=True)))
    print(str(Choice()(items=['a', 'b', 'c'])))
    print(str(Choice()(items='abc', length=2)))
    print(str(Choice()(items='abc', length=2, unique=True)))

# Generated at 2022-06-23 21:11:57.970283
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ab', 'ba', 'cb', 'ac', 'bc', 'ca']

# Generated at 2022-06-23 21:12:00.524691
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    result = c(items=['a', 'b', 'c'], length=1, unique=True)
    expected = ['a', 'b', 'c']
    assert result in expected

# Generated at 2022-06-23 21:12:01.301964
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice.__class__.__name__ == 'Choice'

# Generated at 2022-06-23 21:12:04.186550
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    from mimesis import Person
    choice = Choice()
    person = Person()

    names = [person.name() for _ in range(10)]
    print(choice(names, length=5))
    # ['Александр', 'Александр', 'Виталий', 'Алексей', 'Андрей']

# Generated at 2022-06-23 21:12:05.789434
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert str(c) == "<Choice>"

# Generated at 2022-06-23 21:12:10.421550
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=[1, 2, 3], length=1) == [1]
    assert Choice().__call__(items=(1, 2, 3), length=1) == (1,)
    assert Choice().__call__(items=(1, 2, 3), length=0) in [1, 2, 3]


# Generated at 2022-06-23 21:12:11.258332
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis import choice
    from mimesis import Choice
    assert choice == Choice()


# Generated at 2022-06-23 21:12:20.192786
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """
    Test for method __call__ of class Choice.
    """
    seed = 0
    ch = Choice(seed=seed)
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    result = ch(items=items, length=length, unique=unique)
    assert result == ['b'], "Expected [\'b\'], got {}".format(result)

    seed = 0
    ch = Choice(seed=seed)
    items = ['a', 'b', 'c']
    length = 3
    unique = False
    result = ch(items=items, length=length, unique=unique)
    assert result == ['b', 'a', 'b'], "Expected [\'b\', \'a\', \'b\'], got {}".format(result)

    seed = 0
    ch

# Generated at 2022-06-23 21:12:22.183485
# Unit test for constructor of class Choice
def test_Choice():
    # test_Choice is not tested, as it is __init__
    assert Choice() is not None

# Generated at 2022-06-23 21:12:23.543517
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert c is not None

# Generated at 2022-06-23 21:12:31.468002
# Unit test for constructor of class Choice
def test_Choice():
    """
    Class for unit testing constructor, some of the
    methods, and all the fields of Choice object.
    """
    from mimesis import Choice
    obj = Choice()
    obj_1 = Choice('en')
    # test for __init__
    assert isinstance(obj, Choice)
    assert isinstance(obj_1, Choice)
    # test for __str__
    assert isinstance(str(obj), str)
    assert isinstance(repr(obj), str)
    assert isinstance(obj.__repr__(), str)
    assert isinstance(obj.__str__(), str)

# Generated at 2022-06-23 21:12:33.691166
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert callable(c)


# Generated at 2022-06-23 21:12:35.318933
# Unit test for constructor of class Choice
def test_Choice():
    """Unit tests for method Choice.
    """
    choice = Choice()
    assert isinstance(choice, Choice)

# Generated at 2022-06-23 21:12:41.712668
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    data1 = choice(items=['a', 'b', 'c'])
    data2 = choice(items=['a', 'b', 'c'], length=1)
    data3 = choice(items='abc', length=2)
    data4 = choice(items=('a', 'b', 'c'), length=5)
    data5 = choice(items='aabbbccccddddd', length=4, unique=True)
    print(data1)
    print(data2)
    print(data3)
    print(data4)
    print(data5)
    # assert False


# Generated at 2022-06-23 21:12:52.037667
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    # Test the length and if it is a list or string
    choice(items=['a', 'b', 'c'], length=4)
    choice(items=['a', 'b', 'c', 'd'], length=4)
    choice(items=['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'], length=8)
    choice(items='abc', length=3)
    choice(items='abcdefgh', length=8)

    # Test if there are enough unique elements in **items**
    choice(items=['a', 'b', 'c'], length=5, unique=True)
    choice(items='aaa', length=4, unique=True)
    choice(items=[1, 2, 3, 4], length=5, unique=True)

# Generated at 2022-06-23 21:12:59.144970
# Unit test for constructor of class Choice
def test_Choice():
    S = Choice()
    print(S(items=['a', 'b', 'c'], length=5))
    print(S(items=['a', 'b', 'c'], length=3, unique=True))
    print(S(items=['a', 'b', 'c'], length=2))
    # print(S(items=['a', 'b', 'c'], length = 1, unique = True))
    print(S(items=['a', 'b', 'c'], length=2, unique=False))
    print(S(items=['a', 'b', 'c'], length=3, unique=False))
    print(S(items=['a', 'b', 'c'], length=4, unique=False))

# Generated at 2022-06-23 21:13:07.621009
# Unit test for constructor of class Choice
def test_Choice():
    '''
    >>> from mimesis import Choice
    >>> choice = Choice()
    >>> choice(items=['a', 'b', 'c'])
    'c'
    >>> choice(items=['a', 'b', 'c'], length=1)
    ['a']
    >>> choice(items='abc', length=2)
    'ba'
    >>> choice(items=('a', 'b', 'c'), length=5)
    ('c', 'a', 'a', 'b', 'c')
    >>> choice(items='aabbbccccddddd', length=4, unique=True)
    'cdba'
    '''
    pass

# Generated at 2022-06-23 21:13:11.868905
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit: Test method __call__ of class Choice"""
    c = Choice()
    print(c(['a', 'b', 'c']))
    print(c(['a', 'b', 'c'], length=1))
    print(c('abc', length=2))
    print(c(('a', 'b', 'c'), length=5))
    print(c('aabbbccccddddd', length=4, unique=True))


# Generated at 2022-06-23 21:13:19.569860
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    items = ['a', 'b', 'c']
    assert choice(items) != items[0] or choice(items) != items[1] or choice(items) != items[2]
    length = 1
    assert choice(items, length) == ['a']
    assert choice(items, length) != ['b']
    assert choice(items, length) != ['c']
    length = 2
    assert choice(items, length) != 'ba' or choice(items, length) != 'ab'
    assert choice(items, length) == 'ba' or choice(items, length) == 'ab'
    length = 5

# Generated at 2022-06-23 21:13:20.646031
# Unit test for constructor of class Choice
def test_Choice():
    choice1 = Choice()
    choice2 = Choice()
    assert choice1 is not choice2

# Generated at 2022-06-23 21:13:24.025910
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    items = ['a', 'b', 'c']
    assert choice(items) in items

    items = 'abc'
    assert choice(items) in items

    items = 'aabbbccccddddd'
    assert choice(items, length=4) in items

# Generated at 2022-06-23 21:13:26.065435
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice is not None


# Generated at 2022-06-23 21:13:27.451446
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)


# Generated at 2022-06-23 21:13:29.664035
# Unit test for constructor of class Choice
def test_Choice():
    """Test for function __init__() of class Choice."""
    from mimesis.providers.choice import Choice
    choice = Choice()
    assert choice
    assert len(choice) is 0
    assert isinstance(choice, Choice)


# Generated at 2022-06-23 21:13:37.181607
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test class Choice method __call__."""
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-23 21:13:45.109325
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-23 21:13:53.409729
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    choice.seed(0)
    assert choice.choice.__call__(items=[1, 2, 3]) == 3
    assert choice.choice.__call__(items='Test Mimesis.') == 'i'
    assert choice.choice.__call__(items=(5, 10, 15), length=5) == (5, 10, 15, 5, 5)
    assert choice.choice.__call__(items=[1, 2, 3, 4], length=4, unique=True) == [1, 2, 3, 4]
    assert choice.choice.__call__(items='Test Mimesis.', length=5) == 'esti'

# Generated at 2022-06-23 21:13:54.749851
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    print(c(items=['a', 'b', 'c']))



# Generated at 2022-06-23 21:13:56.084870
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method __call__ of class Choice."""
    pass

# Generated at 2022-06-23 21:14:03.589462
# Unit test for constructor of class Choice
def test_Choice():
    test = Choice()
    assert "abc" == test(items=['a', 'b', 'c'], length=2)
    assert "ab" == test(items=('a', 'b', 'c'), length=2)
    assert "bc" == test(items="abc", length=2)
    assert "abcd" == test(items=['a', 'b', 'c', 'd'], length=4)
    assert "abcd" == test(items=(('a', 'b', 'c', 'd')), length=4)
    assert "abcd" == test(items="abcd", length=4)
    assert True == isinstance(test(items=['a', 'b', 'c'], length=0), str)

# Generated at 2022-06-23 21:14:04.921145
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-23 21:14:11.325486
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method __call__ of class Choice."""
    choice = Choice()
    result = choice(items=['a', 'b', 'c'])
    assert result in ['a', 'b', 'c'] 
    result = choice(items=['a', 'b', 'c'], length=1)
    assert type(result) is list
    assert len(result) == 1
    assert result[0] in ['a', 'b', 'c'] 
    result = choice(items='abc', length=2)
    assert type(result) is str
    assert len(result) == 2
    assert result in ['ab', 'ac', 'ba', 'bc', 'ca', 'cb']
    result = choice(items=tuple(['a', 'b', 'c']), length=5)
    assert type(result) is tuple

# Generated at 2022-06-23 21:14:19.578355
# Unit test for constructor of class Choice
def test_Choice():
    #choice = Choice()
    choice = Choice(locale='en')
    #print(choice.example())
    print(choice(items=['a', 'b', 'c']))
    print(choice(items=['a', 'b', 'c'], length=1))
    print(choice(items='abc', length=2))
    print(choice(items=('a', 'b', 'c'), length=5))
    print(choice(items='aabbbccccddddd', length=4, unique=True))

if __name__ == "__main__":
    test_Choice()

# Generated at 2022-06-23 21:14:29.182924
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__class__().__call__(['a','b','c']) == 'c'
    assert Choice().__class__().__call__(['a','b','c'], 1) == ['b']
    assert Choice().__class__().__call__('abc', 2) == 'ab'
    assert Choice().__class__().__call__(('a','b','c'), 5) == ('c', 'c', 'a', 'a', 'b')
    assert Choice().__class__().__call__('aabbbccccddddd', 4, True) == 'cdba'

# Generated at 2022-06-23 21:14:33.756030
# Unit test for constructor of class Choice
def test_Choice():
    assert(Choice)
    
    choice = Choice()
    print(choice)
    
    #choice = Choice()
    items = ['a', 'b', 'c']
    #length = 0
    unique = False
    #print(choice(items, length, unique))
    print(choice(items, unique=unique))

# Generated at 2022-06-23 21:14:39.710943
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit tests for __call__ method of Choice class."""
    c = Choice()
    assert c(items=[1, 2, 3]) in [1, 2, 3]
    assert c(items=[1, 2, 3], length=1) in [[1], [2], [3]]
    assert c(items=[1, 2, 3], length=4) in [[1, 2, 3, 1], [2, 3, 1, 2],
                                            [3, 1, 2, 3]]
    assert c(items=[1, 2, 3], length=4, unique=True) in [[1, 2, 3, 1],
                                                         [2, 3, 1, 2],
                                                         [3, 1, 2, 3]]

# Generated at 2022-06-23 21:14:45.444730
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    assert c(items, length, unique) == ['a']
    assert c('abc', 2) == 'ba'
    assert c(('a', 'b', 'c'), 5) == ('c', 'a', 'a', 'b', 'c')
    assert c('aabbbccccddddd', 4, True) == 'cdba'


# Generated at 2022-06-23 21:14:46.318045
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice is not None

# Generated at 2022-06-23 21:14:53.025733
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-23 21:14:57.806090
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    choice = c(items=['a', 'b', 'c'])
    choice = c(items=['a', 'b', 'c'], length=1)
    choice = c(items='abc', length=2)
    choice = c(items=('a', 'b', 'c'), length=5)
    choice = c(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-23 21:15:07.800177
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    print("test_Choice___call__:")
    choice = Choice()
    print(choice(items=['a', 'b', 'c']))
    print(choice(items=['a', 'b', 'c'], length=1))
    print(choice(items='abc', length=2))
    print(choice(items=('a', 'b', 'c'), length=5))
    print(choice(items='aabbbccccddddd', length=4, unique=True))
    try:
        choice(items=None)
    except TypeError as e:
        print(str(e))
    try:
        choice(items=[], length=1)
    except ValueError as e:
        print(str(e))

# Generated at 2022-06-23 21:15:09.162216
# Unit test for constructor of class Choice
def test_Choice():
    ch = Choice()
    assert ch('abc', 2) == 'ac'


# Generated at 2022-06-23 21:15:18.446073
# Unit test for constructor of class Choice
def test_Choice():
    """Unit test for constructor of class Choice."""
    ch=Choice()
    items_list=["alpha","beta","gamma","delta","epsilon"]

    choice=ch(items=items_list,length=1)
    assert(choice in items_list)

    choice=ch(items=items_list,length=3)
    assert(len(choice)==3)
    for item in choice:
        assert(item in items_list)

    items_tuple=("alpha","beta","gamma","delta","epsilon")
    choice=ch(items=items_tuple,length=1)
    assert(choice in items_tuple)

    choice=ch(items=items_tuple,length=3)
    assert(len(choice)==3)

# Generated at 2022-06-23 21:15:24.922615
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:15:34.468490
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method __call__ of class Choice."""
    c = Choice()
    c.__call__(items=['a', 'b', 'c'])
    c.__call__(items=['a', 'b', 'c'], length=1)
    c.__call__(items='abc', length=2)
    c.__call__(items=('a', 'b', 'c'), length=5)
    c.__call__(items='aabbbccccddddd', length=4, unique=True)
    assert c.__call__(items=['a', 'b', 'c']) in 'abc'
    assert c.__call__(items=['a', 'b', 'c'], length=1) in ['a']

# Generated at 2022-06-23 21:15:35.759459
# Unit test for constructor of class Choice
def test_Choice():
    pass

# Generated at 2022-06-23 21:15:37.214651
# Unit test for constructor of class Choice
def test_Choice():
	assert Choice().__init__()
	assert Choice().__init__()


# Generated at 2022-06-23 21:15:43.402828
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice('a') == 'a'
    assert choice('abc') == 'c'
    assert isinstance(choice('abc'), str)
    assert choice(['a', 'b', 'c']) == 'c'
    assert isinstance(choice(['a', 'b', 'c']), str)
    assert choice('abc', length=2) == 'ba'



# Generated at 2022-06-23 21:15:43.996117
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-23 21:15:44.941502
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice(None)



# Generated at 2022-06-23 21:15:53.158610
# Unit test for constructor of class Choice
def test_Choice():
    print("\n\n===============Test for Choice====================")
    choice = Choice()
    num = choice(items=['a', 'b', 'c'])
    assert num in ['a', 'b', 'c']
    seq = choice(items=['a', 'b', 'c'], length=1)
    assert len(seq) == 1
    seq = choice(items='abc', length=2)
    assert len(seq) == 2
    seq = choice(items=('a', 'b', 'c'), length=5)
    assert len(seq) == 5
    seq = choice(items='aabbbccccddddd', length=4, unique=True)
    assert len(seq) == 4
    seq = choice(items=['a', 'b', 'c'], length=0)

# Generated at 2022-06-23 21:16:02.699177
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    # result = choice(items=None, length=0, unique=False)
    # assert result == None

    result = choice(items=[], length=0, unique=False)
    assert result == None

    # result = choice(items=['', '', ''], length=0, unique=False)
    # assert result == ''

    result = choice(items=['a', 'b', 'c'], length=0, unique=False)
    assert result == 'c'

    result = choice(items=[True, False, True], length=0, unique=False)
    assert result == True

    result = choice(items=['a', 'b', 'c'], length=1, unique=False)
    assert result == ['a']


# Generated at 2022-06-23 21:16:13.020682
# Unit test for constructor of class Choice
def test_Choice():
    # expected output is a string
    choice = Choice()
    assert isinstance(choice(items=['a', 'b', 'c']), str)
    assert isinstance(choice(items=['a', 'b', 'c'], length=1), list)
    assert isinstance(choice(items='abc', length=2), str)
    assert isinstance(choice(items=('a', 'b', 'c'), length=5), tuple)
    assert isinstance(choice(items='aabbbccccddddd', length=4, unique=True), str)

    # expected output is a ValueError
    choice = Choice()
    try:
        assert choice(items='', length=5, unique=True)
        ExpectedException = False
    except ValueError:
        ExpectedException = True
    assert ExpectedException

    # expected output

# Generated at 2022-06-23 21:16:20.508928
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice(locale='en')
    data = choice('abc')
    assert data in 'abc'
    data = choice(['a', 'b', 'c'], length=3)
    assert len(data) == 3
    data = choice(('a', 'b', 'c', 'd'), length=4, unique=True)
    assert len(data) == len(set(data))
    data = choice(items=['a', 'b', 'c'])
    assert data in 'abc'
    data = choice(items=['a', 'b', 'c'], length=3)
    assert len(data) == 3
    data = choice(items=('a', 'b', 'c', 'd'), length=4, unique=True)
    assert len(data) == len(set(data))
    data = choice

# Generated at 2022-06-23 21:16:21.967236
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis import Choice
    choice = Choice()


# Generated at 2022-06-23 21:16:24.012454
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert c.__class__.__name__ == 'Choice'


# Generated at 2022-06-23 21:16:34.451491
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """ Tests method __call__ of class Choice.
    """

    # Testing the method Choice()
    choice = Choice()

    # Testing when 'items' is not a list
    try:
        choice(items=[1, 2, 3])
        assert False
    except TypeError:
        assert True
    except Exception:
        assert False

    # Testing when 'items' is not a tuple
    try:
        choice(items=(1, 2, 3))
        assert False
    except TypeError:
        assert True
    except Exception:
        assert False

    # Testing when 'items' is not a string
    try:
        choice(items='123')
        assert False
    except TypeError:
        assert True
    except Exception:
        assert False

    # Testing when 'items' is an empty list

# Generated at 2022-06-23 21:16:35.788738
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)



# Generated at 2022-06-23 21:16:42.714168
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:16:49.684692
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    choice = Choice('en')

    # test for a single element
    item = choice(['a', 'b', 'c'])
    assert isinstance(item, str)
    assert len(item) == 1

    # test for a sequence
    item = choice(['a', 'b', 'c'], length=2)
    assert isinstance(item, list)  # TODO: Always return list
    assert len(item) == 2



# Generated at 2022-06-23 21:16:50.822574
# Unit test for constructor of class Choice
def test_Choice():
    obj = Choice()
    assert isinstance(obj, Choice)

# Generated at 2022-06-23 21:16:55.085802
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    random_item = choice(items=['a', 'b', 'c'])
    random_string = choice(items='abc', length=2)
    assert isinstance(random_item, str)
    assert isinstance(random_string, str)

# Generated at 2022-06-23 21:17:03.394916
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Test with a non-empty list
    assert Choice('en').__call__(['a', 'b', 'c']) in ['a', 'b', 'c']
    # Test passing a non-empty list with length 1
    assert len(Choice('en').__call__(['a', 'b', 'c'], length=1)) == 1
    assert Choice('en').__call__(['a', 'b', 'c'], length=1)[0] in ['a', 'b', 'c']
    # Test passing a non-empty string with length 2
    assert len(Choice('en').__call__('abc', length=2)) == 2

# Generated at 2022-06-23 21:17:15.335817
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from hypothesis import given
    from hypothesis import strategies as st
    from mimesis.enums import Gender
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.providers.base import BaseProvider

    russian = RussiaSpecProvider()

    class EntityOfChoice(BaseProvider):
        def __init__(self, **kwargs) -> None:
            super().__init__(**kwargs)
            self._weight = kwargs.get('weight', 1)

        def get_weight(self) -> int:
            return self._weight


# Generated at 2022-06-23 21:17:21.860485
# Unit test for constructor of class Choice
def test_Choice():
    # Unit test for constructor of class Choice

    # Init class
    choice = Choice()

    # Test __str__
    assert str(choice).startswith('Choice<BaseProvider>')

    # Test __repr__
    assert repr(choice).startswith('Choice<BaseProvider>')

    # Test __call__
    # items: Provide elements randomly chosen from the elements in a sequence
    # items, where when length is specified the random choices are contained in a sequence
    # of the same type of length length, otherwise a single uncontained element is chosen.
    # If unique is set to True, constrain a returned sequence to contain only unique elements.
    assert choice(items={'a', 'b', 'c'}) in {'a', 'b', 'c'}

# Generated at 2022-06-23 21:17:23.630209
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'b'

# Generated at 2022-06-23 21:17:29.331334
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    choice = Choice()
    assert choice(items=['a', 'b', 'c'])
    assert choice(items=['a', 'b', 'c'], length=1)
    assert choice(items='abc', length=2)
    assert choice(items=('a', 'b', 'c'), length=5)
    assert choice(items='aabbbccccddddd', length=4, unique=True)


# Generated at 2022-06-23 21:17:31.915989
# Unit test for constructor of class Choice
def test_Choice():
    obj = Choice()
    assert obj.__call__(items=['a', 'b', 'c']) == 'c'


# Generated at 2022-06-23 21:17:42.437353
# Unit test for method __call__ of class Choice
def test_Choice___call__():
  import numpy as np
  from mimesis import Choice
  from mimesis import DataDict
  from mimesis import Person

  # Test for a not empty list
  choice = Choice()
  choice(items=[1, 2, 3], length=2)
  assert isinstance(choice, Choice)

  # Test for a empty list
  choice(items=[], length=2)
  assert isinstance(choice, Choice)

  # Test for a None list
  choice(items=None, length=2)
  assert isinstance(choice, Choice)

  # Test for all kind of list
  choices = {list: [1, 2, 3], tuple: (1, 2, 3), set: {1, 2, 3,}, np.array: np.array([1, 2, 3]),}
  p = Person()

# Generated at 2022-06-23 21:17:44.542596
# Unit test for constructor of class Choice
def test_Choice():
    # test_Choice_init
    choice = Choice()
    assert choice is not None


# Generated at 2022-06-23 21:17:47.074837
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import mimesis
    provider = mimesis.Choice()
    result = provider(items=['a', 'b', 'c'])
    assert result in ['a', 'b', 'c']

# Generated at 2022-06-23 21:17:52.250546
# Unit test for constructor of class Choice
def test_Choice():

    choice = Choice()

    assert choice(items=['a', 'b', 'c'])
    assert choice(items=['a', 'b', 'c'], length=1)
    assert choice(items='abc', length=2)
    assert choice(items=('a', 'b', 'c'), length=5)
    assert choice(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-23 21:17:57.763998
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    #items = ['a', 'b', 'c']  # given a list of items
    assert c.random.choice(['c', 'a', 'b'])
    #assert c.random.choice([2, 3, 1])
    return


test_Choice()

# Generated at 2022-06-23 21:18:00.057711
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'a'
    

# Generated at 2022-06-23 21:18:06.309357
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    
    data = choice(items='aabbbccccddddd', length=4, unique=True)
    assert data
    assert len(data) == 4
    data2 = choice(items='aabbbccccddddd', length=1)
    assert data2
    assert len(data2) == 1
    assert not isinstance(data2,list)

# Generated at 2022-06-23 21:18:14.801410
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Check if method __call__ of class Choice returns a valid result.

    :return: True if test passed.
    :rtype: bool
    """
    choice = Choice()
    elems = ['a', 'b', 'c']
    assert choice(elems) in elems
    assert choice(elems, 1)[0] == elems[0]
    assert choice('abc', 2) in {'bc', 'ab'}

    # TODO: Always return list
    assert choice('abc', 2) == 'bc'
    assert choice(('a', 'b', 'c'), 2) == ('c', 'c')

    # TODO: Always return list

# Generated at 2022-06-23 21:18:22.134545
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice() is Choice(items=[1, 2, 3])
    assert Choice(items=[1, 2, 3]) is Choice(items=[1, 2, 3], length=2)
    assert Choice(items=[1, 2, 3]) is Choice(items=[1, 2, 3], length=2, unique=True)
    assert Choice(items=[1, 2, 3], length=2) is Choice(items=[1, 2, 3], length=2, unique=True)


# Generated at 2022-06-23 21:18:23.559215
# Unit test for constructor of class Choice
def test_Choice():
    """Unit test for constructor of class Choice."""
    pass


# Generated at 2022-06-23 21:18:25.918815
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()(items=['a', 'b', 'c'])
    assert isinstance(choice, str)


# Generated at 2022-06-23 21:18:27.001117
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass


# Generated at 2022-06-23 21:18:36.618303
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis.enums import Gender
    from mimesis.providers.person.en import Person
    from mimesis.providers.person.en import Provider as PersonProvider

    provider = Choice(Person(Gender.FEMALE))

    assert str(provider.choice([1, 2, 3, 4])) in ['1', '2', '3', '4']
    assert provider(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert str(provider.choice([1, 2, 3, 4], length=1)) in ['1', '2', '3',
                                                             '4']
    assert provider(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]

# Generated at 2022-06-23 21:18:38.488764
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice(items=['a', 'b', 'c'], length=1)
    assert choice == ['a', 'b', 'c']

# Generated at 2022-06-23 21:18:43.100838
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Arrange
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 1
    expected = ['a']

    # Act
    actual = choice.__call__(items=items, length=length)

    # Assert
    assert actual == expected
    assert isinstance(actual, list)


# Generated at 2022-06-23 21:18:54.981999
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    try:
        choice(items='abc', length=1.5)
    except TypeError:
        pass
    try:
        choice(items=1, length=3)
    except TypeError:
        pass

# Generated at 2022-06-23 21:19:03.554087
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from hypothesis import given
    from hypothesis.strategies import integers, lists, text

    c = Choice()

    @given(items=lists(text(min_size=1)),
           length=integers(min_value=0, max_value=10))
    def test(items, length):
        result = c(items=items, length=length)
        assert isinstance(result, str) or isinstance(result, list)
        assert len(result) == length
    test()

    @given(items=lists(text(min_size=1)),
           length=integers(min_value=0, max_value=10))
    def test_unique(items, length):
        result = c(items=items, length=length, unique=True)
        assert isinstance(result, str) or isinstance(result, list)
