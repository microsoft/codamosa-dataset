

# Generated at 2022-06-23 21:09:09.534041
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method Choice.__call__()."""
    c = Choice()
    assert c(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert c(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert c(items='abc', length=2) in ['ba', 'ab', 'ac']

# Generated at 2022-06-23 21:09:19.549867
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice is not None 
    items_sequence_of_three_elements = choice(items=['a', 'b', 'c'])
    assert items_sequence_of_three_elements is not None
    items_sequence_of_length_one = choice(items=['a', 'b', 'c'], length = 1)
    assert items_sequence_of_length_one is not None
    items_sequence_of_two_elements = choice(items='abc', length = 2)
    assert items_sequence_of_two_elements is not None
    items_sequence_of_five_elements = choice(items=('a', 'b', 'c'), length = 5)
    assert items_sequence_of_five_elements is not None
    items_sequence_of_three_elements_

# Generated at 2022-06-23 21:09:23.084907
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 1
    unique = False

    choice = Choice()
    ret = choice(items, length, unique)
    assert ret == 'b'

if __name__ == '__main__':
    test_Choice___call__()

# Generated at 2022-06-23 21:09:23.895934
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert callable(c)

# Generated at 2022-06-23 21:09:35.203741
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test the method __call__ of class Choice."""
    choice = Choice()
    # Test 1
    # TODO: Fix this test. It cannot be compared with list.
    #assert choice(items=['a', 'b', 'c']) == 'c'
    #assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    # Test 2

# Generated at 2022-06-23 21:09:36.615227
# Unit test for constructor of class Choice
def test_Choice():
    """Constructor of class Choice."""
    choice = Choice(seed=None)
    assert isinstance(choice, Choice)
    assert isinstance(choice, BaseProvider)


# Generated at 2022-06-23 21:09:42.653595
# Unit test for constructor of class Choice
def test_Choice():

    class Choice_internal(Choice):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self.name = "choice"

    for i in range(0, len(Choice_internal().data.__dict__)):
        name = "choice " + str(i)
        Choice_internal().data.__dict__.__setitem__(name, i)


    # test 1
    res1 = Choice_internal().choice(items=['a', 'b', 'c'])
    assert res1 == "c"

    # test 2
    res1 = Choice_internal().choice(items=['a', 'b', 'c'], length=1)
    assert res1 == ["a"]

    # test 3
    res1 = Choice_internal().choice

# Generated at 2022-06-23 21:09:49.195836
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass
    # print(Choice().__call__(items='aabbbccccddddd', length=4, unique=True))
    # print(Choice().__call__(items=('a', 'b', 'c'), length=5))
    # print(Choice().__call__(items='abc', length=2))
    # print(Choice().__call__(items='aabbbccccddddd', length=4, unique=False))

# Generated at 2022-06-23 21:09:51.775253
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    a1 = choice__call__(choice)
    a2 = choice__call__(choice)
    assert a1 != a2
    pass


# Generated at 2022-06-23 21:10:00.641063
# Unit test for method __call__ of class Choice
def test_Choice___call__(): 
    from hypothesis import strategies as st
    from hypothesis import given
    from hypothesis.strategies import sampled_from,text,lists,tuples
    from hypothesis import settings
    from mimesis import Choice
    import re
    choice = Choice()
    list1 = lists(st.integers()).map(list)
    list2 = list1.filter(lambda l : (len(l)>0))
    assert isinstance(choice(items=['a', 'b', 'c']),str)
    assert choice(items=['a', 'b', 'c']) in ['a','b','c']
    assert isinstance(choice(items=['a', 'b', 'c'], length=1),list)
    assert choice(items=['a', 'b', 'c'], length=1)[0] in ['a','b','c']

# Generated at 2022-06-23 21:10:01.824733
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TODO
    pass


# Generated at 2022-06-23 21:10:06.434081
# Unit test for constructor of class Choice
def test_Choice():
    """Unit test for Choice."""
    from mimesis import Choice
    choice = Choice()
    items = [1, 2, 3, 4, 5]
    result = choice(items, length=3)
    assert str(type(result)) == "<class 'list'>"
    print(result)


# Generated at 2022-06-23 21:10:07.306236
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert True

# Generated at 2022-06-23 21:10:15.638962
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import DataType
    from mimesis.providers.base import BaseDataProvider
    from mimesis.typing import DataIterator

    class _CustomDataProvider(BaseDataProvider):
        """Custom data provider."""
        pass

    class _CustomChoice(Choice):
        """Custom choice."""
        pass

    class _CustomMetaClass(type):
        """Custom metaclass."""

        def __new__(mcs, name, bases, namespace, **kwargs):
            """Create a new class.

            :param mcs: Metaclass.
            :param name: Name of the class.
            :param bases: Bases of the class.
            :param namespace: Namespace.
            :return: Class.
            """

# Generated at 2022-06-23 21:10:20.848006
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    '''Test for the method __call__ of class Choice'''
    # Define the method
    items1 = ['apple', 'banana']
    length1 = 1
    unique1 = False
    choice1 = Choice().__call__(items=items1, length=length1, unique=unique1)
    assert choice1 in items1
    assert len(choice1) == length1
    assert len(set(choice1)) == length1
    assert isinstance(choice1, list)

    items2 = ['apple', 'banana']
    length2 = 2
    unique2 = True
    choice2 = Choice().__call__(items=items2, length=length2, unique=unique2)
    assert all(x in choice2 for x in items2)
    assert len(choice2) == length2

# Generated at 2022-06-23 21:10:23.398919
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis import Choice
    choice = Choice()
    assert choice.__class__.__name__ == 'Choice'


# Generated at 2022-06-23 21:10:33.669359
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.builtins.base import Data
    from mimesis.data import CITIES

    assert isinstance(CITIES, list)
    assert len(CITIES) > 0

    data = Data()
    choices = Choice(data)

    assert isinstance(choices, Choice)
    assert isinstance(choices('Canterbury'), str)

    assert isinstance(choices(items=CITIES, length=1), list)
    assert isinstance(choices(items=CITIES, length=2), list)
    assert isinstance(choices(items=CITIES, length=3), list)
    assert isinstance(choices(items=CITIES, length=4), list)
    assert isinstance(choices(items=CITIES, length=5), list)


# Generated at 2022-06-23 21:10:36.919215
# Unit test for constructor of class Choice
def test_Choice():
    """ Unit test for constructor of class Choice."""
    # Constructor with and without parameters
    choice1 = Choice()
    choice2 = Choice(123)
    assert isinstance(choice1, Choice)
    assert isinstance(choice2, Choice)


# Generated at 2022-06-23 21:10:44.620015
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) in ['ba', 'ab', 'ac', 'cb', 'bc', 'ca']

# Generated at 2022-06-23 21:10:47.917686
# Unit test for constructor of class Choice
def test_Choice():
    c1 = Choice()
    assert c1 is not None

    # TODO: Fix typing
    # c2 = Choice.__init__(c1)
    # assert c2 is not None

# Generated at 2022-06-23 21:10:49.633062
# Unit test for constructor of class Choice
def test_Choice():
    """Unit test for constructor of class Choice."""
    # constructor of class Choice
    Choice()



# Generated at 2022-06-23 21:10:54.723534
# Unit test for constructor of class Choice
def test_Choice():
    ch = Choice(seed=1234)
    assert ch._random.seed == 1234, 'Seed is not same'
    assert repr(ch) == 'Choice()', 'Should return repr'
    assert str(ch) == 'Choice()', 'Should return str'
    assert ch.__doc__, 'Should return doc'



# Generated at 2022-06-23 21:10:55.998245
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert callable(choice)

# Generated at 2022-06-23 21:11:07.037375
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """
    Unit test for method __call__ of class Choice
    """
    choice = Choice()
    assert choice(["a", "b", "c"]) in ["a", "b", "c"]
    assert choice(["a", "b", "c"], length=1) == ["a"]
    assert choice("abc", length=2) in ["ac", "ab", "ba", "bc"]

# Generated at 2022-06-23 21:11:07.894603
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    return c


# Generated at 2022-06-23 21:11:15.822565
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice('abcd') in 'abcd'
    assert choice(items='abcd') in 'abcd'
    assert choice(items='abcd', length=1) in 'abcd'
    assert choice(items='abcd', length=1) in 'abcd'
    assert choice(items='abcd', length=2) in 'abcd'
    assert choice(items='abcd', unique=True) in 'abcd'
    assert choice(items='abcd', unique=True, length=1) in 'abcd'
    assert choice(items='abcd', unique=True, length=2) in 'abcd'


# Generated at 2022-06-23 21:11:16.589962
# Unit test for constructor of class Choice
def test_Choice():
    pass

# Generated at 2022-06-23 21:11:27.600445
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Testing of method __call__ of class Choice."""
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ('a', 'b', 'c')
    assert choice(items=('a', 'b', 'c')) in ('a', 'b', 'c')
    assert choice(items='abc') in ('a', 'b', 'c')
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items=('a', 'b', 'c'), length=1) == ('a', )
    assert choice(items='abc', length=1) in ('a', 'b', 'c')

# Generated at 2022-06-23 21:11:28.214778
# Unit test for constructor of class Choice
def test_Choice():
    Choice()

# Generated at 2022-06-23 21:11:30.841052
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()

    choice(items=['a', 'b', 'c'])
    choice(items=['a', 'b', 'c'], length=1)
    choice(items='abc', length=2)
    choice(items=('a', 'b', 'c'), length=5)
    choice(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-23 21:11:32.271552
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice(random_state=42)
    assert Choice(random_state=3.14).random_state == 3.14

# Generated at 2022-06-23 21:11:37.519452
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    items_list = ['a','b','c']
    return choice(items_list, 3)

# Test for construction of class Choice
# Table.create(test_Choice)
# Test for construction of class Choice
Table.create(Choice(user_agent_file_path='C:/Users/harsh/Downloads/Mimesis/mimesis/data/user_agents.json'))

# Generated at 2022-06-23 21:11:43.297660
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    import pytest

    def describe_Choice___call__():
        choice = Choice()

        def it_returns_random_value_from_string_list_or_tuple():
            assert choice(['a', 'b', 'c']) in ['a', 'b', 'c']
            assert choice(('a', 'b', 'c')) in ('a', 'b', 'c')
            assert choice('abc') in 'abc'
            assert choice('10') in '10'

        def it_returns_random_choice_from_generated_sequence():
            assert choice(['a', 'b', 'c'], 1)
            assert choice(['a', 'b', 'c'], 2)
            assert choice(('a', 'b', 'c'), 1)

# Generated at 2022-06-23 21:11:52.995601
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # The provided sequence.
    items = ['a', 'b', 'c']
    # The length of a provided sequence.
    length = 3
    # Whether the provided sequence should be unique.
    unique = True

    choice_exceptions = ExceptionCollector()
    with choice_exceptions:
        # Initialize an instance of class Choice.
        choice = Choice()

        # Ensure that a returned value is one of the elements of the
        # provided sequence.
        assert choice(items=items, length=0) in items

        # Ensure that a returned value is one of the elements of the
        # provided sequence.
        assert choice(items=items, length=1) in items

        # Ensure that a returned value is a string consist of elements
        # from the provided sequence.

# Generated at 2022-06-23 21:11:55.477135
# Unit test for constructor of class Choice
def test_Choice():
    data = ['a', 'b', 'c']
    # Note that this is not actually a unit test,
    # we are just checking if it throws an error
    from mimesis import Choice
    choice = Choice()
    choice(items=data)
    assert True

# Generated at 2022-06-23 21:11:55.995115
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice()

# Generated at 2022-06-23 21:11:56.535248
# Unit test for constructor of class Choice
def test_Choice():
    return Choice()

# Generated at 2022-06-23 21:12:00.615519
# Unit test for constructor of class Choice
def test_Choice():
    provider = Choice()
    assert len(provider) > 0
    assert len(provider.random) > 0
    assert len(provider.datetime) > 0
    assert len(provider.localization) > 0
    assert len(provider.numbers) > 0
    assert len(provider.text) > 0


# Generated at 2022-06-23 21:12:01.859744
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice() is not None
    assert Choice()._data is not None
    assert Choice().random is not None


# Generated at 2022-06-23 21:12:03.218754
# Unit test for constructor of class Choice
def test_Choice():
    choices = Choice()
    assert choices is not None


# Generated at 2022-06-23 21:12:14.428670
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 1
    unique = True
    choice = Choice()
    result = choice(items)

    assert result == 'a' or result == 'b' or result == 'c'
    result = choice(items, length=length)
    assert result == ['a'] or result == ['b'] or result == ['c']

    items = 'abc'
    result = choice(items, length=2)
    assert result == 'ba' or result == 'cb' or result == 'ab'

    items = ('a', 'b', 'c')
    length = 5
    result = choice(items, length=length)

# Generated at 2022-06-23 21:12:22.074736
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    p = Person(locale='en')
    name = [p.name(gender=Gender.MALE) for _ in range(20)]
    choice = Choice()

    item: Any
    for item in choice(items=name, length=5, unique=True):
        assert len(item) == 5

    assert choice(items=name, length=5) != choice(items=name, length=5)

    assert choice(items='hello') in 'hello'
    assert choice(items='hello', length=1) == 'hello'[:1]
    assert choice(items='hello', length=2) == 'hello'[:2]
    assert choice(items='hello', length=3) == 'hello'[:3]


# Generated at 2022-06-23 21:12:32.475668
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from pprint import pprint
    from random import randint
    from time import time
    from typing import Union
    from unittest import TestCase

    case = TestCase()
    choice = Choice()

    # test type of return value
    case.assertIsInstance(
        choice(items=['a', 'b', 'c'], length=randint(0, 100)), str)
    case.assertIsInstance(
        choice(items=('a', 'b', 'c'), length=randint(0, 100)), str)
    case.assertIsInstance(
        choice(items=(1, 2, 3), length=randint(0, 100)), int)
    case.assertIsInstance(
        choice(items=[1 + 0.0, 2 + 0.0, 3 + 0.0], length=randint(0, 100)), float)

# Generated at 2022-06-23 21:12:40.690560
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert isinstance(choice(items=[], length=1), str)
    assert isinstance(choice(items=(), length=1), str)
    assert isinstance(choice(items=(), length=1), str)
    assert isinstance(choice(items=[1,2,3], length=1), str)
    assert isinstance(choice(items=[1,2,3], length=1), str)
    assert isinstance(choice(items=(1,2,3), length=1), str)
    assert isinstance(choice(items=('1','2','3'), length=1), str)
    assert isinstance(choice(items=('1','2','3'), length=1), str)
    assert isinstance(choice(items=[1,2,3], length=1), str)

# Generated at 2022-06-23 21:12:47.790111
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    #def_items = [1, 2, 3, 4, 5]
    #def_length = 3
    #def_unique = False

    choice = Choice()
    def_items = ['a', 'b', 'c']
    def_length = 1
    def_unique = False

    if not isinstance(def_length, int):
        raise TypeError('**length** must be integer.')

    if not isinstance(def_items, collections.abc.Sequence):
        raise TypeError('**items** must be non-empty sequence.')

    if not def_items:
        raise ValueError('**items** must be a non-empty sequence.')

    if def_length < 0:
        raise ValueError('**length** should be a positive integer.')


# Generated at 2022-06-23 21:12:52.931494
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:12:58.616086
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert c(items=['a', 'b', 'c']) == 'c'
    assert c(items=['a', 'b', 'c'], length=1) == ['a']
    assert c(items='abc', length=2) == 'ba'
    assert c(items=('a', 'b', 'c'), length=5)  == ('c', 'a', 'a', 'b', 'c')
    assert c(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-23 21:13:01.621142
# Unit test for constructor of class Choice
def test_Choice():
	c = Choice()
	assert c(items=['a', 'b', 'c'], length=2) == ['a', 'c']

# Generated at 2022-06-23 21:13:07.559716
# Unit test for constructor of class Choice
def test_Choice():
  choice = Choice()
  assert choice(items=['a', 'b', 'c']) == 'c'
  assert choice(items=['a', 'b', 'c'], length=1) == ['a']
  assert choice(items='abc', length=2) == 'ba'
  assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
  assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:13:16.819632
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    item = Choice().__call__(items)

# Generated at 2022-06-23 21:13:25.648184
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import random
    import string
    from hypothesis import given, settings
    from hypothesis.strategies import lists, text
    from mimesis.providers import Choice

    # Data
    EXAMPLES = ('qwertyuiop', 'asdfghjkl;', 'zxcvbnm,./')
    LENGTH = 10
    UNIQUE = True

    @given(lists(text(alphabet=string.ascii_letters), min_size=10, max_size=100))
    @settings(max_examples=1000)
    def call_choice(items):
        """Test for method __call__ of class Choice.

        :param items: List items to choice from.
        :return: None
        """
        choice = Choice()
        random.shuffle(items)

# Generated at 2022-06-23 21:13:26.918732
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice != None


# Generated at 2022-06-23 21:13:32.941218
# Unit test for constructor of class Choice
def test_Choice():
	choice = Choice()
	print(choice(items=[1,2,3]))
	print(choice(items=[1,2,3],length=1))
	print(choice(items='abc',length=2))
	print(choice(items=('a','b','c'),length=5))
	print(choice(items='aabbbccccddddd',length=4,unique=True))
test_Choice()

# Generated at 2022-06-23 21:13:39.867783
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    c = Choice('en')
    print(c(items=['a', 'b', 'c']))
    print(c(items=['a', 'b', 'c'], length=1))
    print(c(items='abc', length=2))
    print(c(items=('a', 'b', 'c'), length=5))
    print(c(items='aabbbccccddddd', length=4, unique=True))

if __name__ == '__main__':
    test_Choice___call__()

# Generated at 2022-06-23 21:13:47.409476
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:13:54.525349
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    class TestChoice(Choice):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.random.choice = lambda x: x[-1]

    choice = TestChoice()
    assert choice('abc') == 'c'
    assert choice('abc', 1) == ['c']
    assert choice('abc', 2) == ['b', 'c']
    assert choice('abc', 5) == ['a', 'b', 'c', 'b', 'c']
    assert choice('aabbbccccddddd', 4, True) == ['c', 'd', 'b', 'a']


# Generated at 2022-06-23 21:14:02.645336
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.builtins import Choice

    choice = Choice()

    # Testing __call__ method of class Choice, with 
    # items = ['a', 'b', 'c'] and length = 1 and unique = False
    

    result = choice.__call__(['a', 'b', 'c'], length=1, unique=False)

    assert result == ['a']
    

    # Testing __call__ method of class Choice, with 
    # items = 'abc' and length = 2 and unique = False
    

    result = choice.__call__('abc', length=2, unique=False)

    assert result == 'ba'
    

    # Testing __call__ method of class Choice, with 
    # items = ('a', 'b', 'c') and length = 5 and unique = False
    

    result = choice.__

# Generated at 2022-06-23 21:14:05.597438
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    print(c.choice(['a', 'b', 'c']))
    print(c.choice(['a', 'b', 'c'], unique=True))
    print(c.choice(['a', 'b', 'c'], length=5))
    print(c.choice(['a', 'b', 'c'], length=5, unique=True))
    print(c.choice(('a', 'b', 'c'), length=5))

# Generated at 2022-06-23 21:14:16.684556
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from .datetime import Datetime
    from .money import Money
    from .person import Person
    from .person import Person
    from .person import Person
    from .person import Person
    from .person import Person
    from .person import Person
    from .person import Person
    from .person import Person
    from .person import Person
    from .person import Person
    from .person import Person
    from .person import Person
    from .person import Person

    # Initialize an instance of class Choice
    obj = Choice()

    # Check example with an string
    items = 'abc'
    length = 2
    expected = 'ba'
    actual = obj(items=items, length=length)
    assert actual == expected, 'Expected {}, got {}'.format(expected, actual)

    # Check example with a set

# Generated at 2022-06-23 21:14:21.844178
# Unit test for constructor of class Choice
def test_Choice():
    """Unit test for constructor of class Choice."""
    assert Choice().__call__(items=['a', 'b', 'c'], length=1, unique=True) == ['a']
    assert Choice().__call__(items='abc', length=2, unique=False) == 'ab'
    assert Choice().__call__(items='abc', length=1, unique=True) == 'a'
    assert Choice().__call__(items='aabbbccccddddd', length=2, unique=False) == 'dd'

# Generated at 2022-06-23 21:14:27.197889
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice.__call__(['a', 'b', 'c']), str)
    assert isinstance(choice.__call__(['a', 'b', 'c'], length=1), list)
    assert isinstance(choice.__call__('abc', length=2), str)
    assert isinstance(choice.__call__(('a', 'b', 'c'), length=5), tuple)
    assert isinstance(choice.__call__('aabbbccccddddd', length=4, unique=True), str)

    # TODO: Fix this test
    #assert choice.__call__(items=['a', 'b', 'c'])
    #assert choice.__call__(items=['a', 'b', 'c'], length=1)
    #assert choice.__

# Generated at 2022-06-23 21:14:32.440554
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    test_list = ['a', 'b', 'c']
    results = c(items=test_list, length=5)
    assert isinstance(results, list)
    assert len(results) == 5
    for i in range(0, 5):
        assert results[i] in test_list
    return

# Generated at 2022-06-23 21:14:39.244712
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    # TODO: Fix these tests
    assert c(['a', 'b', 'c'], 2) == ['b', 'c']
    # assert c(['a', 'b', 'c'], 2) == 'ab'
    assert c(['a', 'b', 'c'], 2, True) == ['b', 'c']
    # assert c(['a', 'b', 'c'], 2, True) == 'bc'
    assert c(['a', 'b', 'c'], 2, False) == ['a', 'a']
    # assert c(['a', 'b', 'c'], 2, False) == 'aa'
    assert c(['a', 'b', 'c'], 0, False) == 'c'

# Generated at 2022-06-23 21:14:45.372271
# Unit test for constructor of class Choice
def test_Choice():
    c1 = Choice()
    assert c1
    c2 = Choice()
    assert c2
    c3 = Choice()
    assert c3
    c4 = Choice()
    assert c4
    c5 = Choice()
    assert c5
    c6 = Choice()
    assert c6
    c7 = Choice()
    assert c7
    c8 = Choice()
    assert c8
    c9 = Choice()
    assert c9
    c10 = Choice()
    assert c10

# Generated at 2022-06-23 21:14:46.133025
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    return 0


# Generated at 2022-06-23 21:14:53.291036
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    choice(items=['a', 'b', 'c'])
    choice(items=['a', 'b', 'c'], length=1)
    choice(items='abc', length=2)
    choice(items=('a', 'b', 'c'), length=5)
    choice(items='aabbbccccddddd', length=4, unique=True)
    False

if __name__ == "__main__":
    print("Probando funcion Choice")
    print("="*15)
    print(test_Choice())
    print("="*15)

# Generated at 2022-06-23 21:14:59.978224
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    out1 = choice(items['a', 'b', 'c'])
    assert out1 == 'c'
    out2 = choice(items=['a', 'b', 'c'], length=1)
    assert out2 == ['a']
    out3 = choice(items='abc', length=2)
    assert out3 == 'ba'
    out4 = choice(items=('a', 'b', 'c'), length=5)
    assert out4 == ('c', 'a', 'a', 'b', 'c')
    out5 = choice(items='aabbbccccddddd', length=4, unique=True)
    assert out5 == 'cdba'

# Generated at 2022-06-23 21:15:09.201178
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test Choice.__call__ method."""
    choice = Choice()

    data = choice(items=['a', 'b', 'c'])
    assert data in ('a', 'b', 'c')

    data = choice(items=['a', 'b', 'c'], length=1)
    assert type(data) == list

    data = choice(items='abc', length=2)
    assert type(data) == str

    data = choice(items=('a', 'b', 'c'), length=5)
    assert type(data) == tuple

    data = choice(items='aabbbccccddddd', length=4, unique=True)
    assert type(data) == str

    with pytest.raises(ValueError) as exception:
        choice(items='abc', length=-1)

# Generated at 2022-06-23 21:15:16.911999
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    # print(choice(items=['a', 'b', 'c']))
    # print(choice(items=['a', 'b', 'c'], length=1))
    # print(choice(items='abc', length=2))
    # print(choice(items=('a', 'b', 'c'), length=5))
    # print(choice(items='aabbbccccddddd', length=4, unique=True))
    assert True

if __name__ == "__main__":
    test_Choice()

# Generated at 2022-06-23 21:15:19.363831
# Unit test for constructor of class Choice
def test_Choice():
    assert isinstance(Choice(), Choice), True



# Generated at 2022-06-23 21:15:21.596431
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    check = c('a', 'b', 'b', 'c')
    assert type(check) == str


# Generated at 2022-06-23 21:15:23.417173
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()



# Generated at 2022-06-23 21:15:31.835199
# Unit test for constructor of class Choice
def test_Choice():

    choice = Choice()
    choice(items=['a', 'b'])
    choice(items=['a', 'b'], length=1)
    choice(items=['a', 'b', 'c'], length=3)
    choice(items=['a', 'b', 'c'], length=4)
    choice(items=['a', 'b', 'c'], length=4, unique=True)
    choice(items=['a', 'b', 'c'], length=0)
    choice(items='abc', length=3)

    choice.__init__(seed=0)  # Initialize with seed=0
    choice(items=['a', 'b'])
    choice(items=['a', 'b'], length=1)

# Generated at 2022-06-23 21:15:38.018292
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()

    sequence = [1, 2, 3, 4]
    result = choice(sequence)
    assert result in sequence

    result = choice(sequence, 2)
    assert len(result) == 2
    assert result[0] in sequence
    assert result[1] in sequence

    string = 'abcdefgh'
    result = choice(string, 3)
    assert len(result) == 3
    assert result[0] in string
    assert result[1] in string
    assert result[2] in string

    result = choice(string, length=8)
    assert result == string


# Generated at 2022-06-23 21:15:42.555208
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice(items=['a','b','c','d'],length = 5,unique = True) == 'dbac'
    assert choice(items=['a','b','c','d'],length = 1,unique = True) == 'd'


# Generated at 2022-06-23 21:15:43.903990
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert isinstance(c, BaseProvider)


# Generated at 2022-06-23 21:15:52.398395
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    choice = Choice()
    test_items = ('a', 'b', 'c', 'd')
    # Test that it can generate one
    assert choice(test_items) in test_items
    # Test that it can generate a defined number
    assert type(choice(test_items, length=1)) is tuple
    assert len(choice(test_items, length=3)) == 3
    # Test that it can generate a defined number of unique choices
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    # Test that it raises error if length > unique elements
    try:
        choice(items='aabbbccccddddd', length=4, unique=True)
    except ValueError:
        assert True

# Generated at 2022-06-23 21:15:52.986940
# Unit test for constructor of class Choice
def test_Choice():
    pass

# Generated at 2022-06-23 21:15:55.936965
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert isinstance(c, Choice)
    d = Choice(c)
    assert isinstance(d, Choice)


# Generated at 2022-06-23 21:16:05.187619
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ["a", "b", "c"]
    choice = Choice()
    result = choice(items=items)
    assert type(result) == str
    assert result in items
    items = ["a", "b", "c"]
    length = 1
    choice = Choice()
    result = choice(items=items, length=length)
    assert type(result) == list
    assert len(result) == length
    items = "abc"
    length = 2
    choice = Choice()
    result = choice(items=items, length=length)
    assert type(result) == str
    assert len(result) == length
    items = ("a", "b", "c")
    length = 5
    choice = Choice()
    result = choice(items=items, length=length)
    assert type(result) == tuple

# Generated at 2022-06-23 21:16:06.607884
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert c is not None


# Generated at 2022-06-23 21:16:16.155844
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice().code() == Choice().code()
    assert Choice().name() == Choice().name()
    assert Choice().choice(['a', 'b', 'c']) != Choice().choice(['a', 'b', 'c'])

    string = 'abc'
    assert Choice().choice(string) in string
    assert Choice().choices(string, length=1) in string

    choices = Choice().choices(string, length=2)
    assert len(choices) == 2
    assert choices in string*2

    choices = Choice().choices(string, length=5)
    assert len(choices) == 5
    assert choices in string*5

    choices = Choice().choices('aabbbccccddddd', length=4, unique=True)
    assert len(set(choices)) == len(choices) == 4

# Generated at 2022-06-23 21:16:22.529525
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from hypothesis import given
    from hypothesis.strategies import has_length, lists, text
    from pytest import raises
    from string import digits, letters

    choice = Choice()

    with raises(TypeError):
        choice(items=tuple(digits), length=2, unique=True)

    with raises(TypeError):
        choice(items='1234', length='', unique=True)

    with raises(ValueError):
        choice(items=tuple(digits), length=-1, unique=True)

    with raises(ValueError):
        choice(items=tuple(), length=1, unique=True)

    assert isinstance(choice(items=tuple(digits), length=0, unique=True), str)

    assert isinstance(choice(items=tuple(digits), length=1, unique=True), str)

# Generated at 2022-06-23 21:16:30.191699
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice.__call__(Choice, items=['a', 'b', 'c'])  # Equals 'c'
    assert Choice.__call__(Choice, items=['a', 'b', 'c'], length=1)  # Equals ['a']
    assert Choice.__call__(Choice, items='abc', length=2)  # Equals 'ba'
    assert Choice.__call__(Choice, items=('a', 'b', 'c'), length=5)  # Equals ('c', 'a', 'a', 'b', 'c')

# Generated at 2022-06-23 21:16:31.871628
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert c is not None
    assert c.seed is not None


# Generated at 2022-06-23 21:16:33.353622
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice is not None
    assert isinstance(choice, Choice)

# Generated at 2022-06-23 21:16:41.371956
# Unit test for constructor of class Choice
def test_Choice():

    list = ['a', 'b', 'c', 'd', 'e']
    choice = Choice(list)

    assert 'a' in choice.get_data()
    assert 'b' in choice.get_data()
    assert 'c' in choice.get_data()
    assert 'd' in choice.get_data()
    assert 'e' in choice.get_data()
    assert len(choice.get_data()) == 5
    assert 'f' not in choice.get_data()

    choice.add('f')
    assert 'f' in choice.get_data()
    assert len(choice.get_data()) == 6

# Generated at 2022-06-23 21:16:46.678666
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    expected = ('c', 'a', 'a', 'b', 'c')
    actual = Choice().__call__(tuple(['a', 'b', 'c']), length=5)
    assert expected == actual


# Generated at 2022-06-23 21:16:55.741857
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

# Generated at 2022-06-23 21:17:03.360551
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test case for method __call__ of class Choice."""
    c = Choice()
    assert c(items=['a', 'b', 'c']) in ['a', 'b', 'c']

    for length in [1, 2, 5, 0]:
        assert len(c(items=['a', 'b', 'c'], length=length)) == length

    assert len(c(items=('a', 'b', 'c'), length=5)) == 5
    for item in set(c(items='aabbbccccddddd', length=4, unique=True)):
        assert item in 'abcd'

    from pytest import raises

    raises(TypeError, c, items={'a', 'b', 'c'}, length=1)
    raises(ValueError, c, items='', length=1)
    raises

# Generated at 2022-06-23 21:17:07.346722
# Unit test for constructor of class Choice
def test_Choice():
	
	sequence = ['a', 'b', 'c']
	choice = Choice()
	assert choice.choice(items = sequence, length = 4)
	assert choice.choice(items = sequence, length = 0)
	assert choice.choice(items = sequence, length = 2, unique = True)

# Generated at 2022-06-23 21:17:09.638559
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis import Choice
    c = Choice()
    assert(c != None)

# Generated at 2022-06-23 21:17:19.416465
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Testing method __call__ of Choice."""
    choice = Choice('en')
    items = ['a', 'b', 'c']
    assert choice(items, length=0) in items
    assert choice(items, length=1) in [items]
    assert choice(items, length=2) in [tuple(items)]

    assert choice('abc', length=0) in 'abc'
    assert choice('abc', length=1) in list('abc')
    assert choice('abc', length=2) in tuple('abc')
    assert choice((1, 2, 3), length=0) in (1, 2, 3)
    assert choice((1, 2, 3), length=1) in [1, 2, 3]
    assert choice((1, 2, 3), length=2) in (1, 2, 3)

# Generated at 2022-06-23 21:17:29.628682
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    class TestChoice:
        def __init__(self, items, length, unique):
            self.items = items
            self.length = length
            self.unique = unique

    choice = Choice()

# Generated at 2022-06-23 21:17:31.291151
# Unit test for constructor of class Choice
def test_Choice():

    # type: () -> Choice
    assert isinstance(Choice(), Choice)


# Generated at 2022-06-23 21:17:41.927047
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    #######################
    # Test with valid data:
    #######################
    loaded_choice = Choice()
    assert(loaded_choice('a','b','c') in ['a','b','c'])
    assert(loaded_choice('a','b','c', 5) in [['a','a','a','a','a'],['b','b','b','b','b'],['c','c','c','c','c']])
    assert(loaded_choice('a','b','c', 5, True) in [['b','c','a'],['b','c','a']])
    assert(loaded_choice('a','b','c', 0, True) in ['a','b','c'])
    assert(loaded_choice('a','b','c', -1, True) == 'a')

# Generated at 2022-06-23 21:17:50.935734
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice.Meta.name == 'choice'
    assert Choice().__doc__ == Choice.__class__.__doc__
    assert Choice().__name__ == Choice.Meta.name
    ch = Choice()
    assert ch('abc') in 'abc'
    assert ch(['a', 'b', 'c']) in ['a', 'b', 'c']
    assert ch('abc', 1) in ['a', 'b', 'c']
    assert ch(['a', 'b', 'c'], 1) in ['a', 'b', 'c']
    assert ch('abc', 2) in ['ab', 'bc', 'ac']

# Generated at 2022-06-23 21:18:00.991515
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice.random.choice(items=['a', 'b', 'c']) == 'c'
    assert choice.random.choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice.random.choice(items='abc', length=2) == 'ba'
    assert choice.random.choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice.random.choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# test_Choice()

# Generated at 2022-06-23 21:18:11.852439
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.lorem import Lorem
    from mimesis.providers.date_time import Datetime, Date
    from mimesis.providers.currency import Currency
    from mimesis.providers.code import Code
    from mimesis.providers.business import Business
    from mimesis.providers.science import Science
    from mimesis.providers.internet import Internet
    from mimesis.providers.text import Text
    from mimesis.providers.other import Other
    from mimesis.providers.telecom import Telecom
    from mimesis.providers.financial import Financial

# Generated at 2022-06-23 21:18:13.137319
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert c.Meta.name == 'choice'

# Generated at 2022-06-23 21:18:14.752875
# Unit test for constructor of class Choice
def test_Choice():
    ch1 = Choice()
    assert ch1

    ch2 = Choice(seed='mimesis')
    assert ch2

# Generated at 2022-06-23 21:18:26.193824
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method __call__ of Choice class."""
    choice = Choice()
    assert choice.__call__(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice.__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice.__call__(items='abc', length=2) in ['ba', 'bb']
    assert choice.__call__(items=('a', 'b', 'c'), length=5) in [
        ('a','b','c','a','b'),
        ('a','b','c','a','c')]
    assert choice.__call__(items='aabbbccccddddd', length=4, unique=True) in [
        'cdba', 'bacd']

    #

# Generated at 2022-06-23 21:18:29.383848
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    mark = choice('a', 'b', 'c')
    assert isinstance(mark, str)

# Generated at 2022-06-23 21:18:35.224187
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:18:42.503513
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # import statements
    import random
    import string
    import unittest
    from unittest.mock import patch
    import mimesis
    from mimesis.choice import Choice

    class TestChoice(unittest.TestCase):
        """ Tests for Choice """
    
        class CustomRandom(random.Random):
            """ Custom Random subclass for testing. """
            def choice(self, items: Sequence[Any]) -> Any:
                """ Dummy choice method for testing. """
                return items[0]
    
        def test_Choice___call__(self):
            """ Test for Choice __call__ """
            # Setup
            length = 5
            items = ['a', 'b', 'c']
            choice_obj = Choice()
            expected = ('a', 'a', 'a', 'a', 'a')
            
            #

# Generated at 2022-06-23 21:18:46.001755
# Unit test for constructor of class Choice
def test_Choice():
    obj = Choice()
    obj.random.seed(2)
    assert obj('abcdef') == 'e'
test_Choice()

# Generated at 2022-06-23 21:18:56.766631
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    # See discussion at https://github.com/lk-geimfari/mimesis/issues/87
    from mimesis import Choice

    choice = Choice()
    assert choice('abcde', 2) == 'cb'
    assert choice('abcde', 2, unique=True) == 'ce'
    assert choice(['a','b','c','d','e'], 2) == ['d','a']
    assert choice(['a','b','c','d','e'], 2, unique=True) == ['c', 'd']

    assert choice('abcde', 3) == 'dace'
    assert choice('abcde', 3, unique=True) == 'dce'
    assert choice(['a','b','c','d','e'], 3) == ['b','c','d']

# Generated at 2022-06-23 21:19:00.113399
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert callable(c)
    assert isinstance(c, Choice)


# Generated at 2022-06-23 21:19:07.014312
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    items = ['a', 'b', 'c']
    # length = 1
    # unique = True
    # if unique and len(set(items)) < length:  # avoid an infinite while loop
    #     raise ValueError('There are not enough unique elements in '
    #                      '**items** to provide the specified **number**.')
    # while len(data) < length:
    #     item = choice.random.choice(items)
    #     data.append(item)
    #     if (unique and item not in data) or not unique:
    #         data.append(item)
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']