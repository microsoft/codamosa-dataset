

# Generated at 2022-06-23 21:09:03.217248
# Unit test for constructor of class Choice
def test_Choice():
    choice_1 = Choice()
    choice_2 = Choice()

    assert choice_1 == choice_2, "test_Choice() unit test failed!"


# Generated at 2022-06-23 21:09:06.733284
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice().choice(1, 2) == 1
    assert Choice().choice([1, 2]) == 1
    assert Choice().choice([1, 2], length=2) == [1, 2]
    assert Choice().choice([1, 2], length=2, unique=True) == [1, 2]


# Generated at 2022-06-23 21:09:07.109458
# Unit test for method __call__ of class Choice

# Generated at 2022-06-23 21:09:18.331759
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import pytest
    from mimesis.random import Random

    items = ['a', 'b', 'c']
    length = 1
    unique = False
    result: Union[Sequence[Any], Any]

    # Positive tests
    result = Choice(seed=12345)._Choice__call__(  # type: ignore
        items=items,
        length=length,
        unique=unique,
    )
    assert isinstance(result, Sequence) and result == ['b']
    assert Choice()._Choice__call__(  # type: ignore  # type: ignore
        items=items,
        length=length,
        unique=unique,
    ) in items

    # Negative tests

# Generated at 2022-06-23 21:09:21.282258
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choices = ["apple", "orange", "banana"]
    choice = Choice()
    a = choice.__call__(items=choices)
    assert(a in choices)


# Generated at 2022-06-23 21:09:22.240777
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 21:09:29.688930
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    choice = Choice()
    # 
    assert choice(['a', 'b', 'c']) == 'c' 
    assert choice(['a', 'b', 'c'], 1) == ['a'] 
    assert choice('abc', 2) == 'ba' 
    assert choice(('a', 'b', 'c'), 5) == ('c', 'a', 'a', 'b', 'c') 
    assert choice('aabbbccccddddd', 4, True) == 'cdba'

# Generated at 2022-06-23 21:09:36.572328
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from random import randint

    choice = Choice()
    data = ('a', 'b', 'c', 'd')
    for _ in range(10):
        length = randint(0, 100)
        result = choice(data, length=length, unique=True)
        assert isinstance(result, str)
        assert len(result) == length
        assert len(set(result)) == len(result)

    result = choice(data, unique=True)
    assert len(set(result)) == 1


# Generated at 2022-06-23 21:09:40.690883
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import doctest
    # TODO: Port tests to pytest

    # TODO: Fix doctest
    # doctest.testmod(extraglobs={'choice': Choice()})
    # fail, total = doctest.testmod(extraglobs={'choice': Choice()})
    # assert fail == 0
    # assert total == 0



# Generated at 2022-06-23 21:09:42.026578
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import doctest

    doctest.testmod(extraglobs={'choice': Choice()})

# Generated at 2022-06-23 21:09:49.815583
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    choice = Choice()
    value = choice('abc')

    assert type(value) == str
    assert value in 'abc'

    choice = Choice()
    value = choice('abc', length=3)

    assert type(value) == list
    assert len(value) == 3
    assert all([x in 'abc' for x in value])

    choice = Choice()
    value = choice('abc', length=3, unique=True)

    assert type(value) == list
    assert len(value) == 3
    assert len(list(set(value))) == 3

# Generated at 2022-06-23 21:09:58.078044
# Unit test for constructor of class Choice
def test_Choice():
    # Explicit call of test via constructor
    choice = Choice()
    elem = choice(items=['a', 'b', 'c']) 
    seq = choice(items=['a', 'b', 'c'], length=1) 
    seq2 = choice(items=('a', 'b', 'c'), length=5)
    seq3 = choice(items='aabbbccccddddd', length=4, unique=True)
    # print(choice)
    # print(elem)
    # print(seq)
    # print(seq2)
    # print(seq3)
    assert choice is not None
    assert isinstance(elem, str)
    assert isinstance(seq, list)
    assert isinstance(seq2, tuple)
    assert isinstance(seq3, str)

# Generated at 2022-06-23 21:10:09.690844
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pattern_list = ['a', 'b', 'c']
    pattern_tuple = ('a', 'b', 'c')
    pattern_str = 'abc'
#     pattern_int = (1, 2, 3)
    pattern_float = (1.1, 2.2, 3.3)
    pattern_set = {'a', 'b', 'c'}
    pattern_dict = {'a': 1, 'b': 2, 'c': 3}
#   pattern_dict_ = {'a': 1, 'b': 2, 'c': 3, 'd': 4}

#     print('Ex 4:')
    for pattern in pattern_set:
        assert isinstance(pattern, str)
        print(pattern)
        # assert isinstance(pattern, str)

#     print('Ex 1:')
#    

# Generated at 2022-06-23 21:10:11.278588
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 1

    result = choice(items, length)
    assert result == ['a']

    result = choice(items, length, unique=True)
    assert result == ['a']


# Generated at 2022-06-23 21:10:21.442286
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    test_choice = choice(items=['a', 'b', 'c'])
    assert test_choice == 'c'
    test_choice = choice(items=['a', 'b', 'c'], length=1)
    assert test_choice == ['a']
    test_choice = choice(items='abc', length=2)
    assert test_choice == 'ba'
    test_choice = choice(items=('a', 'b', 'c'), length=5)
    assert test_choice == ('c', 'a', 'a', 'b', 'c')
    test_choice = choice(items='aabbbccccddddd', length=4, unique=True)
    assert test_choice == 'cdba'

# Generated at 2022-06-23 21:10:24.042414
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=('a', 'b', 'c'), unique=True, length=4) == 'acba'

# Generated at 2022-06-23 21:10:27.310536
# Unit test for constructor of class Choice
def test_Choice():
    """Tests a constructor of class Choice."""
    from mimesis import Choice
    choice = Choice()

    assert isinstance(choice, Choice)
    assert choice.seed
    assert choice.random

# Unit tests for Choice.__call__()

# Generated at 2022-06-23 21:10:29.001735
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert (choice.__class__.__name__ == 'Choice')

# Generated at 2022-06-23 21:10:30.963671
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert c is not None


# Unit tests for __call__ of class Choice

# Generated at 2022-06-23 21:10:39.711049
# Unit test for constructor of class Choice
def test_Choice():
    s = Choice()
    choices = []
    for i in range(100):
        choices.append(s(items=['a', 'b', 'c'], length=2))
    assert len(set(choices)) == 27
    assert len(set(choices)) == len(choices)
    choices = []
    for i in range(100):
        choices.append(s(items=['a', 'b', 'c'], length=2, unique=True))
    assert len(set(choices)) == 6
    assert len(set(choices)) == len(choices)
    choices = []
    for i in range(100):
        choices.append(s(items=('a', 'b', 'c'), length=2, unique=False))
    assert len(set(choices)) == 18

# Generated at 2022-06-23 21:10:41.928545
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert isinstance(c.__dict__, dict) == True


# Generated at 2022-06-23 21:10:49.083022
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    result = choice(items=['a', 'b', 'c'])
    assert isinstance(result, str)
    result = choice(items=['a', 'b', 'c'], length=1)
    
    assert isinstance(result, list)
    result = choice(items='abc', length=2)
    assert isinstance(result, str)
    result = choice(items=('a', 'b', 'c'), length=5)
    
    assert isinstance(result, tuple)
    result = choice(items='aabbbccccddddd', length=4, unique=True)
    assert isinstance(result, str)
    print("Success!!!")

if __name__ == '__main__':
    test_Choice___call__()

# Generated at 2022-06-23 21:10:54.943976
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:10:58.807605
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    # TODO: the following is not generated
    print(choice('abc', length=1))

# Test the __call__ method of class Choice

# Generated at 2022-06-23 21:11:08.901642
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    
    lenght = choice.random.randint(1, 100)
    choice(items=['a', 'b', 'c'], length=lenght)
    choice(items=['a', 'b', 'c'], length=1)
    choice(items='abc', length=2)
    choice(items=('a', 'b', 'c'), length=5)
    choice(items='aabbbccccddddd', length=4, unique=True)
    
    try:
        choice(items=['a', 'b', 'c'], length='a')
    except TypeError:
        pass
    else:
        raise RuntimeError("TypeError not raised.")
    

# Generated at 2022-06-23 21:11:11.005718
# Unit test for constructor of class Choice
def test_Choice():
    """Test Choice.__init__()."""
    arguments = [None, 1, 'a', [1, 2, 3], set(), {}]
    choice = Choice(*arguments, **{'locale': 'en'})

    assert isinstance(choice, Choice)
    assert choice.random.choice is not None
    assert choice()



# Generated at 2022-06-23 21:11:15.442087
# Unit test for constructor of class Choice
def test_Choice():
    """Test for class Choice."""
    import random
    choice = Choice(random.random)
    choice(items=['a', 'b', 'c'])
    choice(items=['a', 'b', 'c'], length=1)
    choice(items='abc', length=2)
    choice(items=('a', 'b', 'c'), length=5)
    choice(items='aabbbccccddddd', length=4, unique=True)



# Generated at 2022-06-23 21:11:25.543018
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.choice import Choice

    choice = Choice(seed=0)
    assert isinstance(choice, BaseProvider)
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items=['a', 'b', 'c'], length=2) == ['a', 'a']
    assert choice(items=['a', 'b', 'c'], length=2) == ['a', 'a']
    assert choice(items=['a', 'b', 'c'], length=2, unique=True) == ['a', 'b']

# Generated at 2022-06-23 21:11:28.849812
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = (1,)
    length = 0
    unique = False
    seed = None
    expected = 1

    c = Choice(seed)
    actual = c(items, length, unique)

    assert actual == expected


# Generated at 2022-06-23 21:11:36.118608
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert isinstance(choice(items=['a', 'b', 'c']), str)
    assert isinstance(choice(items=['a', 'b', 'c'], length=1), list)
    assert isinstance(choice(items='abc', length=2), str)
    assert isinstance(choice(items=('a', 'b', 'c'), length=5), tuple)
    assert isinstance(choice(items='aabbbccccddddd', length=4, unique=True), str)
    #raise TypeError
    #choice(items='aabbbccccddddd', length='test')
    #raise TypeError
    #choice(items={'a','b','c'})
    #raise ValueError
    #choice(items=[])
    #raise ValueError
    #choice(items=

# Generated at 2022-06-23 21:11:38.427140
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    a = c(items=['a', 'b', 'c'])
    print(a)
# Output
# c


# Generated at 2022-06-23 21:11:50.425730
# Unit test for constructor of class Choice
def test_Choice():
    """test_Choice(items) -> unittest.result object for Choice.__init__()
    """
    import unittest
    class TestChoice(unittest.TestCase):
        """Tests for Choice class."""

        def setUp(self):
            self.choice = Choice()

        def test_constructor_arguments(self):
            """Test constructor arguments."""
            self.assertRaises(TypeError, self.choice, items=set(), length=0)
            self.assertRaises(TypeError, self.choice, items=[],
                              length='length')
            self.assertRaises(TypeError, self.choice, items=[], length=0,
                              unique='unique')

        def test_choice_method(self):
            """Test choice method."""

# Generated at 2022-06-23 21:11:55.048002
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice(items=['a', 'b', 'c'])
    assert choice(items=['a', 'b', 'c'], length=1)
    assert choice(items='abc', length=2)
    assert choice(items=('a', 'b', 'c'), length=5)
    assert choice(items='aabbbccccddddd', length=4, unique=True)
    

# Generated at 2022-06-23 21:11:58.368107
# Unit test for constructor of class Choice
def test_Choice():
    ch=Choice()
    assert ch.choice(['a','b','c', 'ab'], length=5, unique=False) == ['a', 'c', 'c', 'c', 'a']
    assert ch.choice(['a','b','c'], length=0) == 'c'

# Generated at 2022-06-23 21:12:05.804541
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Check random choice is provided or contained."""
    # Test case 1: provides a randomly-chosen sequence or bare element from a
    # sequence items = ['a', 'b', 'c']
    assert Choice().__call__(items=['a', 'b', 'c']) in ['a', 'b', 'c']

    # Test case 2: provides a randomly-chosen sequence or bare element from a
    # sequence items = ['a', 'b', 'c'], length = 1
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) in [['a', 'b', 'c']]

    # Test case 3: provides a randomly-chosen sequence or bare element from a
    # sequence items = 'abc', length = 2
    assert Choice().__call__(items='abc', length=2)

# Generated at 2022-06-23 21:12:12.975106
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    choice(items=['a', 'b', 'c']) == 'c'
    choice(items=['a', 'b', 'c'], length=1) == ['a']
    choice(items='abc', length=2) == 'ba'
    choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:12:17.135778
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    assert not Choice().__call__(items='', length=0, unique=False)
    assert Choice().__call__(items='test', length=0, unique=False) == 't'
    assert Choice().__call__(items=[1, 2, 3], length=0, unique=False) == 1
    assert Choice().__call__(items=('a', 'b', 'c'), length=2, unique=False) == ('b', 'c')
    assert Choice().__call__(items='abc', length=2, unique=False) == 'ac'
    assert Choice().__call__(items=('a', 'b', 'c'), length=2, unique=True) == ('b', 'c')
    assert Choice().__call__(items='abc', length=2, unique=True) == 'ac'
    assert Choice().__call

# Generated at 2022-06-23 21:12:19.484762
# Unit test for constructor of class Choice
def test_Choice():
  assert Choice().__class__.__name__ == 'Choice'


# Generated at 2022-06-23 21:12:20.497221
# Unit test for constructor of class Choice
def test_Choice():
    data = Choice()
    assert data is not None


# Generated at 2022-06-23 21:12:31.393625
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ab', 'ba', 'ac', 'ca', 'bc', 'cb']

# Generated at 2022-06-23 21:12:32.886126
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-23 21:12:34.040914
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TODO: Add unit test for method __call__ of class Choice
    pass

# Generated at 2022-06-23 21:12:41.988783
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    
    # Initialize a global instance of class Choice, choice
    global choice
    choice = Choice()

    # Test method __call__ of class Choice
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    assert choice(items='aabbbccccddddd', length=4, unique=False) == 'bdbd'
    # TODO:

# Generated at 2022-06-23 21:12:44.610304
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    item = Choice()
    seq = item(items=['a', 'b', 'c'])
    assert len(seq) == 1


# Generated at 2022-06-23 21:12:53.700627
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from nose.tools import assert_equals, assert_true, raises

    from mimesis import Choice

    chars = 'abcdefghijklmnopqrstuvwxyz'
    choice = Choice()
    choice_3 = choice(items=chars, length=3)
    assert_true(isinstance(choice_3, list))
    assert_equals(len(choice_3), 3)
    assert_equals(set(choice_3), set(chars))

    choice_4 = choice(items=chars, length=4)
    assert_true(isinstance(choice_4, list))
    assert_equals(len(choice_4), 4)
    assert_equals(set(choice_4), set(chars))

    choice_1 = choice(items=chars, length=1)
   

# Generated at 2022-06-23 21:13:00.978422
# Unit test for constructor of class Choice
def test_Choice():
    Provider = Choice()
    data = Provider.__call__(items=['a', 'b', 'c'])
    assert data in ['a', 'b', 'c']
    assert isinstance(data, str)

    data = Provider.__call__(items=['a', 'b', 'c'], length=1)
    assert data == ['b']
    assert isinstance(data, list)

    data = Provider.__call__(items='abc', length=2)
    assert data == 'ac'
    assert isinstance(data, str)

    data = Provider.__call__(items=('a', 'b', 'c'), length=5)
    assert data == ('b', 'c', 'b', 'a', 'b')
    assert isinstance(data, tuple)


# Generated at 2022-06-23 21:13:08.900198
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    Choice = Choice()
    assert Choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert Choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert Choice(items='abc', length=2) in ['aa', 'ab', 'ac', 'ba', 'bb', 'bc', 'ca', 'cb', 'cc']

# Generated at 2022-06-23 21:13:11.326270
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    Choice().__call__(items=['a', 'b', 'c'], length=1)

# Generated at 2022-06-23 21:13:13.405574
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    choice = Choice()
    assert choice(items) in items


# Generated at 2022-06-23 21:13:23.748841
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """."""
    choice = Choice()

#     # >>> choice(items=['a', 'b', 'c'])
#     # 'c'
#     # >>> choice(items=['a', 'b', 'c'], length=1)
#     # ['a']
#     # >>> choice(items='abc', length=2)
#     # 'ba'
#     # >>> choice(items=('a', 'b', 'c'), length=5)
#     # ('c', 'a', 'a', 'b', 'c')

#     res = choice(items=['a', 'b', 'c'])
#     print(res)
#     assert res in ['a', 'b', 'c']

#     res = choice(items=['a', 'b', 'c'], length=1)
#    

# Generated at 2022-06-23 21:13:30.467204
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from random import Random
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.code import Code
    from mimesis.providers.numbers import Numbers

    c = Choice()
    assert c.__call__(range(5)) in range(5)

    c = Choice()
    assert c.__call__(['a', 'b', 'c'], unique=True, length=5) in ['a', 'b', 'c']

    c = Choice()
    items = [1, 2, 3, 'a', 'b', 'c']
    assert c.__call__(items, length=2) in items

    r = Random

# Generated at 2022-06-23 21:13:38.656157
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    data = choice(items=['a', 'b', 'c'])
    assert data == 'c'
    data = choice(items=['a', 'b', 'c'], length=1)
    assert data == ['a']
    data = choice(items='abc', length=2)
    assert data == 'ba'
    data = choice(items=('a', 'b', 'c'), length=5)
    assert data == ('c', 'a', 'a', 'b', 'c')
    data = choice(items='aabbbccccddddd', length=4, unique=True)
    assert data == 'cdba'


# Generated at 2022-06-23 21:13:48.588767
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from random import choice
    from test_data import ChoiceData
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    from mimesis.providers.internet import Internet
    from mimesis.data import (PROVIDERS,
                              DEFAULT_LANGUAGE_CODE,
                              DEFAULT_GENDER,
                              DEFAULT_LOCALE)

    choice_data = ChoiceData()

    choice_no_args = Choice()
    choice_random_args = Choice(random=choice)

    # Test the method __call__ of class Choice with no arguments
    assert choice_no_args() == DEFAULT_LOCALE

# Generated at 2022-06-23 21:13:54.675812
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    sample = Choice()
    assert isinstance(sample(items=['a', 'b', 'c']), str)
    assert isinstance(sample(items=['a', 'b', 'c'], length=1), list)
    assert isinstance(sample(items='abc', length=2), str)
    assert isinstance(sample(items=('a', 'b', 'c'), length=5), tuple)
    assert isinstance(sample(items='aabbbccccddddd',
                             length=4, unique=True), str)
    assert len(sample(items='aabbbccccddddd',
                      length=4, unique=True)) == 4

# Generated at 2022-06-23 21:13:57.319946
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.builtins import Choice
    from mimesis.enums import Gender
    from mimesis.typing import GenderEnum, List, Tuple
    import allure
    import pytest



# Generated at 2022-06-23 21:14:08.200263
# Unit test for constructor of class Choice
def test_Choice():
    c1 = Choice()
    assert c1.random.choice(['a', 'b', 'c']) in ['a','b','c']
    assert c1.random.choice(['a', 'b', 'c']) in ['a','b','c']
    assert c1.random.choice(['a', 'b', 'c']) in ['a','b','c']

    assert c1.random.choice(tuple(['a', 'b', 'c'])) in ['a','b','c']
    assert c1.random.choice(tuple(['a', 'b', 'c'])) in ['a','b','c']
    assert c1.random.choice(tuple(['a', 'b', 'c'])) in ['a','b','c']
    

# Generated at 2022-06-23 21:14:17.404517
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    items = ['a', 'b', 'c']
    assert choice(items) in items

    items = ['a', 'b', 'c']
    length = 1
    assert choice(items, length) == ['a']

    items = 'abc'
    length = 2
    assert choice(items, length) == 'ba'

    items = ('a', 'b', 'c')
    length = 5
    assert choice(items, length) == ('c', 'a', 'a', 'b', 'c')

    items = 'aabbbccccddddd'
    length = 4
    unique = True

# Generated at 2022-06-23 21:14:18.919193
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis import Choice
    
    choice = Choice()
    assert isinstance(choice, Choice)

# Generated at 2022-06-23 21:14:23.436995
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Check if that a class can be instantiated."""
    choice = Choice()
    result = choice(items=['a', 'b', 'c'], length=0)
    assert result in ['a', 'b', 'c']

# Generated at 2022-06-23 21:14:30.260187
# Unit test for constructor of class Choice
def test_Choice():
    obj = Choice()
    test = obj(items=['a', 'b', 'c'])
    assert 'c' == test
    test = obj(items=['a', 'b', 'c'], length=1)
    assert ['a'] == test
    test = obj(items='abc', length=2)
    assert 'ba' == test
    test = obj(items=('a', 'b', 'c'), length=5)
    assert ('c', 'a', 'a', 'b', 'c') == test
    test = obj(items='aabbbccccddddd', length=4, unique=True)
    assert 'cdba' == test

test_Choice()

# Generated at 2022-06-23 21:14:38.146508
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method __call__ of class Choice."""
    # Choice(items=None, length=0, unique=False)
    choice = Choice()
    assert choice(items=['a', 'b', 'c'], length=0, unique=False) in ['a', 'b', 'c']
    assert choice(items='abcdefg', length=0, unique=False) in 'abcdefg'
    assert choice(items=(1, 2, 3), length=0, unique=False) in (1, 2, 3)
    assert choice(items=[1, 2, 3], length=0, unique=False) in [1, 2, 3]
    assert choice(items=(1, 2, 3), length=0, unique=False) in (1, 2, 3)

# Generated at 2022-06-23 21:14:47.235829
# Unit test for constructor of class Choice
def test_Choice():

    choice = Choice()
    assert choice.random.choice(['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice.random.choice(['a', 'b', 'c'], length=1) == ['a']
    assert choice.random.choice('abc', length=2) in ['ab', 'ba', 'ac', 'ca', 'bc', 'cb']

# Generated at 2022-06-23 21:14:48.200948
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-23 21:14:57.415144
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # The test is successful if the method __call__ works as expected.
    choice = Choice()

    # When the length is 0 and it's a tuple, return an element.
    assert choice(items=('a', 'b', 'c')) in ('a', 'b', 'c')

    # When the length is 0 and it's a list, return an element.
    assert choice(items=['a', 'b', 'c']) in ('a', 'b', 'c')

    # When the length is 0 and it's a string, return an element.
    assert choice(items='abc') in ('a', 'b', 'c')

    # When the length is 1 and it's a tuple, return a tuple with one element.
    assert len(choice(items=('a', 'b', 'c'), length=1)) == 1

# Generated at 2022-06-23 21:15:07.473120
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    person = Person('en')

    assert person.choice([], 0) == ''
    assert person.choice(['a', 'b', 'c', 'd']) in ['a', 'b', 'c', 'd']
    assert person.choice(['a', 'b', 'c', 'd'], 2) in [['a', 'b'], ['a', 'c'],
                                                       ['a', 'd'], ['b', 'c'],
                                                       ['b', 'd'], ['c', 'd']]

# Generated at 2022-06-23 21:15:13.430593
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import DataType
    from mimesis.builtins import datetime_
    from mimesis.data import GREEK_ALPHABET
    from mimesis.providers.datetime import Datetime
    from mimesis.schema import Field, Schema

    choice = Choice()

    assert isinstance(choice(items='abcde'), str)

    assert choice(items='abcde', length=2) in ('ab', 'ac', 'ad', 'ae',
                                                'ba', 'bc', 'bd', 'be',
                                                'ca', 'cb', 'cd', 'ce',
                                                'da', 'db', 'dc', 'de',
                                                'ea', 'eb', 'ec', 'ed')


# Generated at 2022-06-23 21:15:14.254350
# Unit test for constructor of class Choice
def test_Choice():
    Choice(seed=42)
    Choice(language='en')



# Generated at 2022-06-23 21:15:15.091384
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TODO: Need mock.patch
    pass

# Generated at 2022-06-23 21:15:25.716777
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    c = Choice()
    assert c.__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert c.__call__(items=('a', 'b', 'c'), length=3) == ('c', 'b', 'b')
    assert c.__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    assert c.__call__(items='aabbbccccddddd', length=4, unique=False) == 'cccddddd'
    assert c.__call__(items=['a', 'b', 'c']) == 'c'
    assert c.__call__(items='abcd', length=2) == 'ca'

# Generated at 2022-06-23 21:15:35.637912
# Unit test for constructor of class Choice
def test_Choice():

    choice = Choice()
    choice.seed(0)

    # Call returns a randomly-chosen sequence from a sequence
    # items = ['a', 'b', 'c']
    # length = 1
    assert choice(['a', 'b', 'c'], length=1) == ['b']

    # items = ['a', 'b', 'c']
    # length = 2
    assert choice(['a', 'b', 'c'], length=2) == ['c', 'b']

    # items = ['a', 'b', 'c']
    # length = 3
    assert choice(['a', 'b', 'c'], length=3) == ['c', 'a', 'a']

    # items = ['a', 'b', 'c']
    # length = 4

# Generated at 2022-06-23 21:15:46.452888
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice()(items=['Python', 'Java', 'C++', 'C#']) in ['Python', 'Java', 'C++', 'C#']
    assert Choice()(items=['Python', 'Java', 'C++', 'C#'], length=1) in [['Python'], ['Java'], ['C++'], ['C#']]
    assert Choice()(items='Python', length=2) in ['Py', 'yt', 'th', 'ho', 'on']
    assert Choice()(items=('Python', 'Java', 'C++', 'C#'), length=5) in [('Python', 'Java', 'C++', 'C#', 'C#'),
                                                                          ('Python', 'Java', 'C++', 'C#', 'Java')]

# Generated at 2022-06-23 21:15:52.680765
# Unit test for constructor of class Choice
def test_Choice():
    s = Choice()
    assert type(s) == Choice
    assert s.random is not None
    assert s.datetime is not None
    assert s.text is not None
    assert s.numbers is not None
    assert s.business is not None
    assert s.codec is not None
    assert s.finance is not None
    assert s.internet is not None
    assert s.misc is not None
    assert s.person is not None
    assert s.personal is not None
    assert s.science is not None
    assert s.transport is not None
    assert s.system is not None



# Generated at 2022-06-23 21:16:02.450001
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    class Dummy(object):

        @classmethod
        def __init__(cls, *args, **kwargs):
            pass

        @staticmethod
        def __call__(items: Optional[Sequence[Any]], length: int = 0,
                     unique: bool = False) -> Union[Sequence[Any], Any]:
            from mimesis.choice import Choice
            return Choice().__call__(items, length, unique)

    dummy = Dummy()

    assert dummy(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert dummy(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]

# Generated at 2022-06-23 21:16:12.751992
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # The function Choice(items=[str, str, str]) -> str
    assert type(Choice().__call__(items=['a', 'b', 'c'])) == str
    # The function Choice(items=[str, str, str], length=1) -> list
    assert type(Choice().__call__(items=['a', 'b', 'c'], length=1)) == list
    # The function Choice(items=str, length=2) -> str
    assert type(Choice().__call__(items='abc', length=2)) == str
    # The function Choice(items=(str, str, str), length=5) -> tuple
    assert type(Choice().__call__(items=('a', 'b', 'c'), length=5)) == tuple
    # The function Choice(items=str, length=4, unique=True) -> str

# Generated at 2022-06-23 21:16:13.733629
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)

# Generated at 2022-06-23 21:16:14.357738
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert c is not None

# Generated at 2022-06-23 21:16:19.688177
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    choice(items=['a', 'b', 'c'], length=1)
    choice(items='aabbbccccddddd', length=4, unique=True)
    choice(items=['a', 'b', 'c'])
    choice(items='abc', length=2)
    choice(items=('a', 'b', 'c'), length=5)

# Generated at 2022-06-23 21:16:27.488143
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    obj = Choice()
    assert obj(items=('a', 'b', 'c'), length=0) == 'c'
    assert obj(items=['a', 'b', 'c'], length=1) == ['a']
    assert obj(items='abc', length=2) == 'ba'
    assert obj(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert obj(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:16:36.326313
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    print("Test __call__ of class Choice")
    choice = Choice()
    res = choice(items=['a', 'b', 'c'])
    assert res in ['a', 'b', 'c']
    res = choice(items=['a', 'b', 'c'], length=1)
    assert res == ['a'] or res == ['b'] or res == ['c']
    res = choice(items='abc', length=2)
    assert res == 'ba' or res == 'bc' or res == 'ca'
    res = choice(items=('a', 'b', 'c'), length=5)
    assert res == ('c', 'a', 'a', 'b', 'c')
    res = choice(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-23 21:16:40.267041
# Unit test for constructor of class Choice
def test_Choice():
    obj = Choice()
    print("Choice:", obj.choice(['a','b','c'], length=3, unique=True))
    print("choice:", obj.choice(['a', 'b', 'c'], 3, True))

# Unit testing of module Choice

# Generated at 2022-06-23 21:16:50.889332
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice.
    
    Testing random choice from items in a sequence.
    
    """
    assert isinstance(Choice().__call__(items=['a', 'b', 'c']),str)
    assert isinstance(Choice().__call__(items=['a', 'b', 'c'], length=1),list)
    assert isinstance(Choice().__call__(items='abc', length=2),str)
    assert isinstance(Choice().__call__(items=('a', 'b', 'c'), length=5),tuple)
    assert isinstance(Choice().__call__(items='aabbbccccddddd', length=4, unique=True),str)

# Generated at 2022-06-23 21:16:58.006111
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:16:59.141317
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice is not None


# Generated at 2022-06-23 21:17:06.289580
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    #items: Non-empty sequence (list, tuple or string) of elements.
    #length: Length of sequence (number of elements) to provide.
    #unique: If True, ensures provided elements are unique.
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:17:09.037311
# Unit test for constructor of class Choice
def test_Choice():
    # Test for __init__()
    x = Choice()
    assert x is not None

# Unit tests for __call__()

# Generated at 2022-06-23 21:17:10.578644
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Test where unique is True and items contains insufficient unique elements
    test_choice = Choice()
    test_choice(items=['a', 'b', 'c'], length=4, unique=True)

# Generated at 2022-06-23 21:17:19.974309
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """
    Test __call__.
    """
    choice = Choice()
    items = ['One', 'Two', "Three"]
    unique = True
    length = 2
    data = choice(items=items, length=length, unique=unique)
    assert isinstance(data, list)
    assert len(data) == length
    assert len(set(data)) == length
    assert set(data).issubset(set(items))
    assert data == choice(items=items, length=length)
    assert data == choice(items=items, length=length, unique=False)
    assert data != choice(items=items, length=length, unique=False)

    # TODO: Always return list
    data_2 = choice(items=tuple(items), length=length, unique=unique)

# Generated at 2022-06-23 21:17:22.678618
# Unit test for constructor of class Choice
def test_Choice():
    """Tests the constructor of the class."""
    choice = Choice()
    assert choice is not None



# Generated at 2022-06-23 21:17:24.047728
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """
    Test for method __call__ of class Choice
    """
    pass

# Generated at 2022-06-23 21:17:24.986600
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass


# Generated at 2022-06-23 21:17:30.620659
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    choice(items=['a', 'b', 'c'])  # 'c'
    choice(items=['a', 'b', 'c'], length=1)  # ['a']
    choice(items='abc', length=2)  # 'ba'
    choice(items=('a', 'b', 'c'), length=5)  # ('c', 'a', 'a', 'b', 'c')
    choice(items='aabbbccccddddd', length=4, unique=True)  # 'cdba'

# Generated at 2022-06-23 21:17:33.634609
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()

    if not isinstance(c, Choice):
        raise TypeError('__init__() should return an instance of "Choice"')


# Generated at 2022-06-23 21:17:35.765333
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice('abc') in 'abc'
    assert choice(['a', 'b', 'c']) in ['a', 'b', 'c']

# Unit tests for function __call__ of class Choice

# Generated at 2022-06-23 21:17:38.780245
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    result = choice(items=['a', 'b', 'c'])
    assert result in ['a', 'b', 'c']


# Generated at 2022-06-23 21:17:48.652326
# Unit test for constructor of class Choice
def test_Choice():
    # Create a provider for class Choice
    my_choice = Choice()
    # Generate a random choice from items in a sequence
    my_choice('ab', length=0)
    # Generate a random choice from items in a sequence
    my_choice('ab', length=1)
    # Generate a random choice from items in a sequence
    my_choice('aabbbccccddddd', length=4, unique=True)
    # Generate a random choice from items in a sequence
    my_choice([1, 2, 3], length=5)
    # Generate a random choice from items in a sequence
    my_choice(('a', 'b', 'c'), length=5)
    # Generate a random choice from items in a sequence
    my_choice('abc', length=2)
    # Generate a random choice from items in

# Generated at 2022-06-23 21:17:49.806895
# Unit test for constructor of class Choice
def test_Choice():
    print("test_Choice()")



# Generated at 2022-06-23 21:17:51.570921
# Unit test for constructor of class Choice
def test_Choice():
    """
    Test for constructor of class Choice
    """
    choice = Choice()
    assert choice is not None


# Generated at 2022-06-23 21:17:53.348985
# Unit test for constructor of class Choice
def test_Choice():
    """Create an instance of class Choice.

    :return: An instance of Choice
    """
    choice = Choice()
    return choice


# Generated at 2022-06-23 21:17:59.964590
# Unit test for constructor of class Choice
def test_Choice():
    # Test for initialization  
    choice = Choice()
    assert choice.random.choice([1,2,3]) in [1,2,3]
    assert choice.random.choice([1,2,3]) in [1,2,3]
    

if __name__ == "__main__":
    import doctest
    doctest.testmod(verbose=True)
    test_Choice()

# Generated at 2022-06-23 21:18:03.750630
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice('en')
    res = choice(items=['a', 'b', 'c'], length=5)
    assert isinstance(res, collections.abc.Sequence)

# Generated at 2022-06-23 21:18:04.366191
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()

# Generated at 2022-06-23 21:18:07.786641
# Unit test for constructor of class Choice
def test_Choice():
    obj = Choice()
    obj2 = Choice()
    assert obj != obj2
    obj = Choice(seed = 5)
    assert obj.seed == 5
    assert obj.random != None
    assert obj.datetime != None
    assert obj.file != None

# Generated at 2022-06-23 21:18:16.595896
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method __call__ of class Choice."""
    choice = Choice()

    result = choice(items=['a', 'b', 'c'])
    assert result in ['a', 'b', 'c']

    result = choice(items=['a', 'b', 'c'], length=1)
    assert isinstance(result, list)
    assert len(result) == 1
    assert result[0] in ['a', 'b', 'c']

    result = choice(items='abc', length=2)
    assert isinstance(result, str)
    assert len(result) == 2
    assert result in ['ab', 'ac', 'ba', 'bc', 'ca', 'cb']

    result = choice(items=('a', 'b', 'c'), length=5)
    assert isinstance(result, tuple)
    assert len

# Generated at 2022-06-23 21:18:18.006710
# Unit test for constructor of class Choice
def test_Choice():
    a = Choice()
    return a

# Generated at 2022-06-23 21:18:25.256338
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice(['a', 'b', 'c']) == 'c'
    assert choice(['a', 'b', 'c'], 1) == ['a']
    assert choice('abc', 2) == 'ba'
    assert choice(('a', 'b', 'c'), 5) == ('c', 'a', 'a', 'b', 'c')
    assert choice('aabbbccccddddd', 4, True) == 'cdba'

# Generated at 2022-06-23 21:18:26.926198
# Unit test for constructor of class Choice
def test_Choice():
    ch = Choice()
    assert ch.__call__(["a", "b"], 2) == ["a", "b"]

# Generated at 2022-06-23 21:18:33.295411
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()

    #Test for string
    assert(isinstance(choice(items='abc', length=1), str))

    #Test for list
    assert(isinstance(choice(items=['a', 'b', 'c'], length=1), list))

    #Test for tuple
    assert(isinstance(choice(items=('a', 'b', 'c'), length=5), tuple))

# Generated at 2022-06-23 21:18:37.307121
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Testing method __call__ of class Choice."""
    from mimesis.choice import Choice
    choice = Choice()
    assert choice(['a', 'b', 'c', 'd', 'e'], 3) == ['e', 'a', 'e']


# Generated at 2022-06-23 21:18:44.294275
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    return True

# Generated at 2022-06-23 21:18:45.953381
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice
    assert choice()



# Generated at 2022-06-23 21:18:47.825743
# Unit test for constructor of class Choice
def test_Choice():
    """Test the constructor helper."""
    choice = Choice()
    assert isinstance(choice, Choice)

# Generated at 2022-06-23 21:18:53.134472
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # https://github.com/lk-geimfari/mimesis/issues/37
    data = Choice().__call__(items=['a', 1, 2], length=2, unique=True)
    assert isinstance(data, list) is True
    assert len(data) == 2

# Generated at 2022-06-23 21:18:59.151296
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:19:00.462965
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import doctest
    doctest.testmod()


# Generated at 2022-06-23 21:19:01.678798
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)