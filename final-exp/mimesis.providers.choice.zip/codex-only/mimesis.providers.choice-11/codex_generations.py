

# Generated at 2022-06-23 21:09:01.836289
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    assert isinstance(choice(items, length, unique), str)


# Generated at 2022-06-23 21:09:03.818672
# Unit test for constructor of class Choice
def test_Choice():
    a = Choice()
    assert isinstance(a, Choice)
    assert isinstance(a.random, Choice)


# Generated at 2022-06-23 21:09:11.352684
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Test type checking of method __call__ of class Choice with positional
    # arguments
    try:
        test_Choice = Choice()
        test_Choice.__call__(['a', 'b', 'c'], length=1, unique=True)
    except TypeError:
        pass
    else:
        assert False

    # Test type checking of method __call__ of class Choice with keyword
    # arguments
    try:
        test_Choice = Choice()
        test_Choice.__call__(items=['a', 'b', 'c'], length=1, unique=True)
    except TypeError:
        pass
    else:
        assert False

    # Test type checking of method __call__ of class Choice with arguments
    # items and length

# Generated at 2022-06-23 21:09:13.932094
# Unit test for constructor of class Choice
def test_Choice():

    # Initializes with default options
    choice = Choice()

    assert isinstance(choice, Choice)


# Generated at 2022-06-23 21:09:15.353094
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import doctest
    doctest.testmod(verbose=True)


# Generated at 2022-06-23 21:09:18.144332
# Unit test for constructor of class Choice
def test_Choice():
    test_choice = Choice()
    test_choice_2 = Choice("en")
    assert isinstance(test_choice, Choice)
    assert isinstance(test_choice_2, Choice)


# Generated at 2022-06-23 21:09:21.418623
# Unit test for constructor of class Choice
def test_Choice():
    new_choice = Choice()
    # testing constructor without arguments
    assert new_choice is not None
    assert isinstance(new_choice, Choice) == True
    assert isinstance(new_choice, BaseProvider) == True


test_Choice()

# Generated at 2022-06-23 21:09:32.511269
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    choice(items=['a', 'b', 'c'])
    choice(items=['a', 'b', 'c'], length=1)
    choice(items='abc', length=2,)
    choice(items=('a', 'b', 'c'), length=5,)
    choice(items='aabbbccccddddd', length=4, unique=True)
    try:
        choice(items=['a', 'b', 'c'], length='42')
    except TypeError:
        pass
    try:
        choice(items='abc', length='42')
    except TypeError:
        pass
    try:
        choice(items=('a', 'b', 'c'), length='42')
    except TypeError:
        pass

# Generated at 2022-06-23 21:09:41.610153
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Test for Choice.__call__()
    # TODO: Numpydoc
    """
    The test for Choice.__call__()
    """
    import pytest

    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    from mimesis.exceptions import NonEnumerableError
    from mimesis.builtins import Choice

    seed = 42
    gender = Gender.FEMALE
    locale = 'ru'
    p = Person(seed, locale, gender)
    choice = Choice()

    result = choice(items=['a', 'b', 'c'])
    assert result in ['a', 'b', 'c']
    assert len(result) == 1

    result = choice(items='abc')
    assert result in ['a', 'b', 'c']
    assert len

# Generated at 2022-06-23 21:09:52.788257
# Unit test for constructor of class Choice
def test_Choice():
    apelats = Choice()
    #print(apelats)

    #print(apelats.choice(['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']))
    #print(apelats.choice(['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'],length=4,unique=True))
    #print(apelats.choice(items=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p

# Generated at 2022-06-23 21:10:01.307817
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import pytest
    from typing import Set
    type_check: Set[str] = {
        'should be a non-empty list of str'
    }
    type_check1: Set[int] = {
        'should be a non-negative integer'
    }
    type_check2: Set[bool] = {
        'should be a bool'
    }

# Generated at 2022-06-23 21:10:02.751419
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice is not None

# Generated at 2022-06-23 21:10:13.057621
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.providers.choice import Choice
    from mimesis.exceptions import NonUniqueError, NonSequenceError, NegativeValueError
    from mimesis.typing import Sequence
    from mimesis.enums import Handler
    from mimesis.builtins import Number
    choice = Choice()
    assert isinstance(choice.seed(Handler.NONE), Choice)
    assert isinstance(choice(['a', 'b', 'c']), str)
    assert isinstance(choice(['a', 'b', 'c'], length=1), Sequence)
    assert isinstance(choice('abc', length=2), str)
    assert isinstance(choice((1, 2), length=2), tuple)
    assert isinstance(choice('aabbbccccddddd', length=4,
                             unique=True), str)


# Generated at 2022-06-23 21:10:20.921521
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:10:28.792839
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:10:35.110709
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    print(c(items=['a', 'b', 'c']))
    print(c(items=['a', 'b', 'c'], length=1))
    print(c(items='abc', length=2))
    print(c(items=('a', 'b', 'c'), length=5))
    print(c(items='aabbbccccddddd', length=4, unique=True))

if __name__ == '__main__':
    test_Choice___call__()

# Generated at 2022-06-23 21:10:35.658982
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-23 21:10:43.326126
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit: Function __call__ of class Choice."""
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:10:47.153645
# Unit test for constructor of class Choice
def test_Choice():
    # First test the test function
    x = Choice()
    assert isinstance(x, Choice), 'Did not create an instance of Choice.'

    # Now test the constructor
    try:
        x = Choice(x)
    except:
        assert True, 'constructor of Choice failed'
    else:
        assert False, 'constructor of Choice did not fail'


# Generated at 2022-06-23 21:10:53.775844
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    from mimesis import Choice
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == (
        'c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-23 21:11:00.807874
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    class_ = Choice()
    assert class_('abcd') in 'abcd'
    assert class_(['a', 'b', 'c']) in ['a', 'b', 'c']
    assert class_('abcd', 0) in 'abcd'
    assert class_(['a', 'b', 'c'], 0) in ['a', 'b', 'c']
    assert class_('abcd', 1) in 'abcd'
    assert class_(['a', 'b', 'c'], 1) in ['a', 'b', 'c']
    assert type(class_('abcd', 1)) is str
    assert type(class_(['a', 'b', 'c'], 1)) is list
    assert class_('abcd', 2) in 'abcd'

# Generated at 2022-06-23 21:11:02.682344
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert c
    assert c.__doc__
    assert c.__init__

# Generated at 2022-06-23 21:11:11.239771
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.providers.choice import Choice
    from mimesis.data import LOREM_IPSUM
    from mimesis.enums import Gender


    def _choice(items=Gender.MALE):
        assert isinstance(items, Gender)
        return Choice().choice(items)

    def _choice_sequence(items=LOREM_IPSUM):
        assert isinstance(items, (list, tuple, str))
        return Choice().choice(items)

    assert isinstance(_choice(), Gender)
    assert isinstance(_choice(tuple(Gender)), Gender)
    assert isinstance(_choice_sequence(), str)
    assert isinstance(_choice_sequence(LOREM_IPSUM), str)
    assert isinstance(_choice_sequence(tuple(LOREM_IPSUM)), str)

# Generated at 2022-06-23 21:11:14.919986
# Unit test for constructor of class Choice
def test_Choice():
    """Test class Choice."""
    choice = Choice()
    # SystemRandom is a subclass of Random, but has a different API.
    assert type(choice.random) == type(choice.random)


# Generated at 2022-06-23 21:11:21.843578
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    # Unit test for method __call__ of class Choice without unique
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.internet import Internet
    from mimesis.providers.lorem import Lorem
    from mimesis.providers.file import File
    from mimesis.providers.currency import Currency
    from mimesis.providers.business import Business
    from mimesis.providers.date_time import DateTime

    # init providers
    person = Person('en')
    internet = Internet('en')
    lorem = Lorem('en')
    file = File('en')
    currency = Currency('en')
    business = Business('en')
    date_time = DateTime

# Generated at 2022-06-23 21:11:23.419575
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice


# Unit tests for Choice.__call__ method

# Generated at 2022-06-23 21:11:28.210009
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    x = c(['a', 'b', 'd', 'f'], length=2, unique=True)
    # The assert is used to test the truth of a condition.
    assert x in ('ad', 'af', 'bd', 'bf')
    # The assert is used to test the truth of a condition.
    assert len(x) == 2
    for i in x:
        assert i in {'a', 'b', 'd', 'f'}
       
test_Choice()
print('Unit tests for Choice class have been successfully executed.')

# Generated at 2022-06-23 21:11:31.815756
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    try:
        choice = Choice()
        result = choice(items=['a', 'b', 'c'])
        assert(result == 'c')
    except TypeError:
        print("TypeError: __call__() missing 1 required positional argument: 'items'")

test_Choice___call__()

# Generated at 2022-06-23 21:11:37.383267
# Unit test for constructor of class Choice
def test_Choice():
    """Unit test for constructor of class Choice"""
    choice = Choice()
    choice(items=['a', 'b', 'c'])
    choice(items=['a', 'b', 'c'], length=1)
    choice(items='abc', length=2)
    choice(items=('a', 'b', 'c'), length=5)
    choice(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-23 21:11:42.613987
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Tests a random choice from items in a sequence."""
    c = Choice()
    assert(c(items=[1]) == 1)
    assert(c(items=[1,2,3], length=0) == 1)
    assert(c(items=[1,2,3], length=1) == [1])
    assert(c(items=[1,2,3], length=2) == [1,2])
    assert(c(items='abc', unique=True, length=3) == 'abc')


# Generated at 2022-06-23 21:11:52.653266
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) in ['a', 'b', 'c'], \
           'Failed __call__ of Choice'
    assert len(Choice().__call__(items=['a', 'b', 'c'], length=1)) == 1, \
           'Failed __call__ of Choice'
    assert Choice().__call__(items='abc', length=2) in ['ab', 'ac', 'bc'], \
           'Failed __call__ of Choice'
    assert len(Choice().__call__(items=('a', 'b', 'c'), length=5)) == 5, \
           'Failed __call__ of Choice'

# Generated at 2022-06-23 21:11:59.159670
# Unit test for constructor of class Choice
def test_Choice():
    
    choice = Choice()
    
    args = None
    kwargs = {'weight': 'male'}
    
    assert choice(*args, **kwargs) == 'male'
    
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:12:06.178692
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    from mimesis import Choice
    choice = Choice()

    assert isinstance(choice(items=['a', 'b', 'c']), str)
    assert isinstance(choice(items=['a', 'b', 'c'], length=1), list)
    assert isinstance(choice(items='abc', length=2), str)
    assert isinstance(choice(items=('a', 'b', 'c'), length=5), tuple)
    assert isinstance(choice(items='aabbbccccddddd', length=4, unique=True), str)

    try:
        choice(items=['a', 'b', 'c'], length='1')
    except TypeError:
        assert True
    except Exception:
        assert False


# Generated at 2022-06-23 21:12:09.277048
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    assert Choice(items=items, length=length,
                  unique=unique) == ['a']



# Generated at 2022-06-23 21:12:18.853007
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Cover method __call__ of class Choice."""
    choice = Choice(seed=123)
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

    # TODO: Test error
    #choice = Choice()
    #choice(items=['a', 'b', 'c'], length=5, unique=True)
    #choice(items=['a

# Generated at 2022-06-23 21:12:25.609192
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis import Choice
    choice = Choice()

    assert choice(items=['a', 'b', 'c'])
    assert choice(items=['a', 'b', 'c'], length=1)
    assert choice(items='abc', length=2)
    assert choice(items=('a', 'b', 'c'), length=5)
    assert choice(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-23 21:12:34.938652
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import random
    from mimesis import Choice
    choice = Choice()
    # Basic usage
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    assert choice.choice(items=items, length=length, unique=unique) in items
    # Big number of items
    for i in range(1000):
        if not choice.choice(items=items, length=length, unique=unique) in items:
            break
    else:
        assert True
    # Unique elements
    items = ['a', 'b', 'c', 'd', 'a', 'b', 'c', 'd', 'a', 'b', 'c', 'd']
    length = len(items)
    unique = True
    result = choice.choice(items=items, length=length, unique=unique)

# Generated at 2022-06-23 21:12:42.556840
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    provider = Choice()
    # When method __call__ of class Choice is called with a list as argument
    # then it should returns an item randomly chosen from the list
    assert provider(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    # When method __call__ of class Choice is called with a list and an item
    # length as arguments then it should returns a list with the chosen items
    assert len(provider(items=['a', 'b', 'c'], length=1)) == 1
    # When method __call__ of class Choice is called with a string and an item
    # length as arguments then it should returns a string with the chosen items
    assert len(provider(items='abc', length=2)) == 2
    # When method __call__ of class Choice is called with a tuple and an item
   

# Generated at 2022-06-23 21:12:44.794993
# Unit test for constructor of class Choice
def test_Choice():
    test_Choice = Choice(seed=12345)
    assert (test_Choice.seed == 12345)

# Unit tests for method __call__

# Generated at 2022-06-23 21:12:45.368304
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-23 21:12:54.306770
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method `__call__` of class `Choice`."""

    choice = Choice()
    data = choice(items=['a', 'b', 'c'])  # type: ignore
    assert isinstance(data, str)
    assert data in 'abc'  # nosec

    data = choice(items=('a', 'b', 'c'), length=5)
    assert isinstance(data, tuple)
    assert len(data) == 5

    data = choice(items='abc', length=2)
    assert isinstance(data, str)
    assert len(data) == 2

    data = choice(items='aabbbccccddddd', length=4, unique=True)
    assert isinstance(data, str)
    assert len(data) == 4
    assert len(set(data)) == 4

# Generated at 2022-06-23 21:13:00.513197
# Unit test for constructor of class Choice
def test_Choice():
    # Check only initialization
    Choice()
    # Check initialization with parameters
    Choice(seed=9)
    Choice(locale='ru')
    Choice(locale='ru', seed=9)
    # Check initialization with incorrect arguments
    # TypeError: 'NoneType' object is not callable
    # Choice(None)
    # TypeError: __init__() got an unexpected keyword argument 'seed1'
    # Choice(seed1=9)
    # TypeError: __init__() got an unexpected keyword argument 'locale1'
    # Choice(locale1='ru')
    # ValueError: seed must be an integer
    # Choice(seed='9')
    # ValueError: seed must be greater than zero
    # Choice(seed=-1)
    # ValueError: invalid locale 'asdf'
    # Choice(locale='asdf

# Generated at 2022-06-23 21:13:02.757434
# Unit test for constructor of class Choice
def test_Choice():
    """Test constructor of class Choice."""
    assert isinstance(Choice(), Choice)
    assert isinstance(Choice(), BaseProvider)


# Generated at 2022-06-23 21:13:03.810198
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert c is not None

# Generated at 2022-06-23 21:13:04.807401
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice
    assert choice


# Generated at 2022-06-23 21:13:07.498280
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    return


if __name__ == '__main__':
    print(test_Choice___call__())

# Generated at 2022-06-23 21:13:15.063152
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice('en')

    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['c']
    assert choice(items='abc', length=2) == 'ca'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'b', 'b', 'a', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'dabd'



# Generated at 2022-06-23 21:13:17.068018
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass
    # TODO: Add tests for the __call__ method

# Generated at 2022-06-23 21:13:21.217467
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items='abc'
    length=5
    c = Choice()
    r = c.__call__(items=items, length=length)
    assert isinstance(r, collections.abc.Sequence)
    assert len(r) == length
    assert all(x in items for x in r)
    uniques = set(r)
    assert len(uniques) <= length
    assert r == c.choice(items=items, length=length)

# Generated at 2022-06-23 21:13:26.595132
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Tests that the negative value of *length* argument raises an error.

    This test is for method __call__ of class Choice.
    """
    from random import random
    from unittest import TestCase
    from unittest.mock import patch

    from mimesis.enums import Gender
    from mimesis.providers.choice import Choice

    class _TestChoice(TestCase):

        def setUp(self):
            self.choice = Choice(seed=random())

        def test_neg_len(self):
            with self.assertRaises(ValueError):
                self.choice(Gender, length=-1)

    _TestChoice().setUp()
    _TestChoice().test_neg_len()



# Generated at 2022-06-23 21:13:31.739113
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test choice."""
    import random
    choice = Choice(random)
    try:
        choice(items=['a', 'b', 'c'], length=3)
    except ValueError:
        pass
    try:
        choice(items=['a', 'b', 'c'], length=-1)
    except ValueError:
        pass

# Generated at 2022-06-23 21:13:33.182929
# Unit test for method __call__ of class Choice

# Generated at 2022-06-23 21:13:41.910434
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method __call__ of class Choice."""
    class Choice(BaseProvider):
        """Class for generating a random choice from items in a sequence."""

        class Meta:
            """Class for metadata."""

            name = 'choice'

        def __init__(self, *args, **kwargs) -> None:
            """Initialize attributes.

            :param args: Arguments.
            :param kwargs: Keyword arguments.
            """
            super().__init__(*args, **kwargs)


# Generated at 2022-06-23 21:13:47.947099
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # If **items** is a string
    # If **items** is a tuple
    # If **items** is a list
    # If **length** is a negative integer
    # If **length** is 0
    # If **length** is a non-integer
    # The length of **items** is less than **number**, and **unique** is True
    # If **items** is a non-sequence
    # If **items** is an empty sequence
    assert False



# Generated at 2022-06-23 21:13:48.838708
# Unit test for constructor of class Choice
def test_Choice():
    # TODO: rewrite
    pass

# Generated at 2022-06-23 21:13:49.720362
# Unit test for constructor of class Choice
def test_Choice():
    pass


# Generated at 2022-06-23 21:13:51.816668
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice.random is not None
    assert choice.seed is not None
    assert choice.datetime_provider is not None


# Generated at 2022-06-23 21:13:55.129349
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c'], length=10) == ['b', 'b', 'a', 'c', 'c', 'c', 'b', 'b', 'c', 'b']

# Generated at 2022-06-23 21:14:03.010218
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method __call__ of class Choice by using Pytest."""
    items = ['a', 'b', 'c']
    # Call method __call__ of class Choice
    result = Choice.__call__(items=items)
    assert result in items
    result = Choice.__call__(items=items, length=1)
    assert result in items
    result = Choice.__call__(items='abc', length=2)
    assert result in items
    result = Choice.__call__(items=('a', 'b', 'c'), length=5)
    assert result in items
    result = Choice.__call__(items='aabbbccccddddd', length=4, unique=True)
    assert result in items

# Generated at 2022-06-23 21:14:06.839796
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import random
    random.seed(1001)
    choice = Choice(seed=1001)
    s = choice(['a', 'b', 'c'])
    assert s == 'a'
    s = choice(['a', 'b', 'c'], length=1)
    assert s == ['c']
    s = choice('abc', length=2)
    assert s == 'ba'
    s = choice(('a', 'b', 'c'), length=5)
    assert s == ('c', 'a', 'a', 'b', 'c')
    s = choice('aabbbccccddddd', length=4, unique=True)
    assert s == 'cdba'

# Generated at 2022-06-23 21:14:18.176317
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    person = Person('ru')
    person.set_gender(Gender.MALE)

    choice = Choice(seed=42)
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

    assert choice(items='abc', length=-1) == 'abc'

# Generated at 2022-06-23 21:14:20.972642
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    x = c(items=[1,2,3,4], length=4)
    print(x)
    print(x[0])
    print(len(x))


if __name__ == "__main__":
    test_Choice()

# Generated at 2022-06-23 21:14:27.130312
# Unit test for constructor of class Choice
def test_Choice():
    ch = Choice()
    assert ch.provide('items', 10)
    assert ch.provide('items', 'hello', 2)
    assert ch.provide('items', ['a', 'b', 'c'], 3)
    assert ch.provide('items', ['a', 'b', 'c'], 0)
    assert ch.provide('items', ['a', 'b', 'a'], 2, True)
    assert ch.provide('items', 'abcabcabcabc', 10, True)

# Generated at 2022-06-23 21:14:29.730675
# Unit test for constructor of class Choice
def test_Choice():
    choices = Choice()
    print(choices('abcdefghijklmnopqrstuvwxyz', length=5, unique=True))

# Generated at 2022-06-23 21:14:32.865231
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    x = c(items=['a', 'b', 'c'], length=0, unique=False)

    assert len(x) == 1
    # ...


# Generated at 2022-06-23 21:14:34.284153
# Unit test for constructor of class Choice
def test_Choice():
    print("Constructor")
    choice = Choice()
    assert choice is not None

# Generated at 2022-06-23 21:14:40.901866
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    choice(items=['a', 'b', 'c'])
    choice(items=['a', 'b', 'c'], length=1)
    choice(items='abc', length=2)
    choice(items=('a', 'b', 'c'), length=5)
    choice(items='aabbbccccddddd', length=4, unique=True)
    pass

# Generated at 2022-06-23 21:14:41.954147
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-23 21:14:49.806897
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Positive tests
    # Positive tests: no length provided
    items = ['a', 'b', 'c']
    choice = Choice()
    assert isinstance(choice(items), str)
    assert choice(items) in items

    # Positive tests: length provided
    length = 3
    items = ['a', 'b', 'c', 'd', 'e']
    choice = Choice()
    assert isinstance(choice(items, length), list)
    assert len(choice(items, length)) == length
    for item in choice(items, length):
        assert item in items

    # Negative tests
    # Negative tests: items is non-sequence, non-empty
    items = {}
    choice = Choice()
    assertRaises(TypeError, choice, items)

    # Negative tests: items is non-sequence, empty
    items = []
   

# Generated at 2022-06-23 21:14:58.662341
# Unit test for constructor of class Choice
def test_Choice():
    f = Choice()
    # print(f(["F","S"],3,False))
    # print(f(["F","S"],3,True))
    # print(f(["F","S"],0,False))
    # print(f([1,2,3],3,False))
    # print(f(['a','b','c'],3,False))
    # print(f(['a','b','c'],3,True))
    # print(f(['a','b','c'],3,False))
    # print(f(['a','b','c'],0,False))
    # print(f(('a','b','c'),3,False))
    # print(f(('a','b','c'),5,True))
    # print(f('abc',3,True))

# Generated at 2022-06-23 21:15:00.832176
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert isinstance(c, Choice)

# Test for Choice.__call__ to return an element, not contained in a list.

# Generated at 2022-06-23 21:15:09.707122
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # ```
    # >>> from mimesis import Choice
    # >>> choice = Choice()
    # ```
    pass

    # ```
    # >>> choice(items=['a', 'b', 'c'])
    # 'c'
    # ```
    pass

    # ```
    # >>> choice(items=['a', 'b', 'c'], length=1)
    # ['a']
    # ```
    pass

    # ```
    # >>> choice(items='abc', length=2)
    # 'ba'
    # ```
    pass

    # ```
    # >>> choice(items=('a', 'b', 'c'), length=5)
    # ('c', 'a', 'a', 'b', 'c')
    # ```
    pass

    # ```


# Generated at 2022-06-23 21:15:18.498913
# Unit test for constructor of class Choice
def test_Choice():
    print ("test_Choice")
    assert isinstance(Choice().hotel.chain(), str)
    assert isinstance(Choice().hotel.chain(hierarchy=True), list)
    assert isinstance(Choice().payment_card.number(mask="#### #### #### ####"), str)
    assert isinstance(Choice().payment_card.number(mask="#### #### #### ####", digits="1234567890"), str)
    assert isinstance(Choice().payment_card.number(mask="#### #### #### ####", digits="1234567890", upper=True), str)
    assert isinstance(Choice().payment_card.number(mask="#### #### #### ####", digits="1234567890", upper=False), str)
    assert isinstance(Choice().payment_card.expiration_date(), str)

# Generated at 2022-06-23 21:15:24.255112
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    class TestChoice(Choice):
        def __init__(self):
            super().__init__()

    t = TestChoice()
    assert t.__call__(items=['a', 'b', 'c']) in ['c', 'a', 'b']
    assert t.__call__(items=('a', 'b', 'c')) in ['c', 'a', 'b']
    assert t.__call__(items='abc') in ['c', 'a', 'b']

# Generated at 2022-06-23 21:15:24.829698
# Unit test for constructor of class Choice
def test_Choice():
    assert True

# Generated at 2022-06-23 21:15:26.735295
# Unit test for constructor of class Choice
def test_Choice():
    """Test constructor """
    choice = Choice()
    assert isinstance(choice, Choice)


# Generated at 2022-06-23 21:15:28.514954
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice(items=['a', 'b', 'c'])



# Generated at 2022-06-23 21:15:35.900620
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method __call__ of class Choice.
    """
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:15:46.690303
# Unit test for constructor of class Choice
def test_Choice():
    class Choice(BaseProvider):
        """Class for generating a random choice from items in a sequence."""

        class Meta:
            """Class for metadata."""

            name = 'choice'

        def __init__(self, *args, **kwargs):
            """Initialize attributes.

            :param args: Arguments.
            :param kwargs: Keyword arguments.
            """
            super().__init__(*args, **kwargs)


# Generated at 2022-06-23 21:15:52.293975
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice (items=['a', 'b', 'c']) == 'c'
    assert choice (items=['a', 'b', 'c'], length=1) == ['a']
    assert choice (items='abc', length=2) == 'ba'
    assert choice (items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice (items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:16:02.254820
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import pytest
    from mimesis.enums import Gender
    from mimesis.providers.date_time import DateTime

    dt = DateTime('en')
    d = dt.date(start=dt.datetime(year=1970), end=dt.datetime(year=1980))
    c = Choice('en')

    # Unit test: test __call__ method with items is a tuple
    assert isinstance(c(items=('a', 'b'), length=0), str)
    assert c(items=('a', 'b'), length=0) in ('a', 'b')
    assert c(items=('a', 'b'), length=1) == ('a',)

    # Unit test: test __call__ method with items is a list

# Generated at 2022-06-23 21:16:05.275734
# Unit test for constructor of class Choice
def test_Choice():
    """Test for constructor of class Choice."""

    from mimesis.builtins import Choice
    from mimesis.builtins import Seed

    seed = Seed.create_seed()
    g = Choice(seed)

# Generated at 2022-06-23 21:16:07.484450
# Unit test for constructor of class Choice
def test_Choice():
    """  Test constructor of class Choice.
    """
    choice = Choice()
    print(choice.random)



# Generated at 2022-06-23 21:16:13.993840
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    choice(items=['a', 'b', 'c'])
    choice(items=['a', 'b', 'c'], length=1)
    choice(items='abc', length=2)
    choice(items=('a', 'b', 'c'), length=5)
    choice(items='aabbbccccddddd', length=4, unique=True)
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')

# Generated at 2022-06-23 21:16:20.481043
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import random
    from mimesis.exceptions import NonEnumerableError
    from mimesis.enums import Gender
    choice = Choice(random.Random(random.randint(1, 1000)))
    gender = choice(Gender)
    a_choice = choice(gender)
    try:
        choice('abc', unique=True)
        # TODO: Remove NonEnumerableError exception
    except NonEnumerableError:
        pass
    choices = choice('abc', 3)
    choices = choice('abc', 5, unique=True)
    choice = Choice()
    choice(items='abc', length=0)
    choice(items=('a', 'b', 'c'), length=5)
    assert len(choices) == 6

# Generated at 2022-06-23 21:16:21.908581
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # (items: Optional[Sequence[Any]], length: int = 0, unique: bool = False)
    # -> Union[Sequence[Any], Any]
    pass

# Generated at 2022-06-23 21:16:31.624912
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice()._Choice__call__(items=('a', 'b', 'c'), length=1) == ['c']
    assert Choice()._Choice__call__(items=('a', 'b', 'c'), length=2) == ['b', 'a']
    assert Choice()._Choice__call__(items=('a', 'b', 'c'), length=3) == ['b', 'c', 'a']
    assert Choice()._Choice__call__(items=('a', 'b', 'c'), length=4) == ['c', 'b', 'c', 'a']
    assert Choice()._Choice__call__(items=('a', 'b', 'c'), length=5) == ['b', 'c', 'c', 'a', 'c']

# Generated at 2022-06-23 21:16:32.625146
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert c is not None

# Generated at 2022-06-23 21:16:38.623017
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    from mimesis.enums import Gender

    from test_mimesis.test_random_choice import TestChoice

    choice = TestChoice(gender=Gender.FEMALE)
    items = ('a', 'b', 'c')
    assert choice(items=items) in items
    assert choice(items=items, length=5) not in items
    assert choice(items=[], length=5) == []
    assert choice(items=items, length=5) in items
    assert choice(items=items, length=5, unique=True) not in items



# Generated at 2022-06-23 21:16:39.895887
# Unit test for constructor of class Choice
def test_Choice():
   assert Choice().__class__.__name__ == 'Choice'


# Generated at 2022-06-23 21:16:51.485731
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TODO: updates
    choice = Choice()
    assert choice(['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(['a', 'b', 'c'], 1) in [['a'], ['b'], ['c']]
    assert choice('abc', 2) in ['aa', 'bb', 'cc']
    assert choice(('a', 'b', 'c'), 2) in [('a', 'a'), ('a', 'b'), ('a', 'c'),
                                          ('b', 'a'), ('b', 'b'), ('b', 'c'),
                                          ('c', 'a'), ('c', 'b'), ('c', 'c')]

# Generated at 2022-06-23 21:17:01.015591
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.providers.internet import Internet
    from mimesis.enums import Gender

    choice = Choice(seed = 4321)
    items = ['hello', 'world']
    length = 3
    unique = True

    for i in range(length):
        item = choice(items=items, length=length, unique=unique)
        assert item in items

    assert choice(items=items, length=length, unique=unique) in items

    length = None
    assert choice(items=items, length=length, unique=unique) in items

    items = Internet('en').ipv4_address(mask=24)
    assert choice(items, length=None, unique=unique) in items

    items = Internet('en').ipv6_address()
    assert choice(items, length=None, unique=unique) in items

    #

# Generated at 2022-06-23 21:17:05.709206
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:17:07.449932
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice is not None


# Generated at 2022-06-23 21:17:09.324803
# Unit test for constructor of class Choice
def test_Choice():
    print("Test for constructor of Choice")
    assert Choice()


# Generated at 2022-06-23 21:17:19.243086
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    import pytest
    from mimesis.exceptions import NonEnumerableError

    choice = Choice()
    with pytest.raises(TypeError):
        choice(items=1, length=1, unique=False)
    with pytest.raises(TypeError):
        choice(items=[1, 2, 3], length='a', unique=False)
    with pytest.raises(ValueError):
        choice(items=[1, 2, 3], length=-1, unique=False)
    with pytest.raises(NonEnumerableError):
        choice(items=choice(items='abc', length=1, unique=False), length=1,
               unique=True)
    with pytest.raises(ValueError):
        choice(items=[], length=1, unique=False)


# Generated at 2022-06-23 21:17:23.725863
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']


# Generated at 2022-06-23 21:17:25.401754
# Unit test for constructor of class Choice
def test_Choice():
    a = Choice()
    assert a.random.choice(['a', 'b', 'c']) == 'b'

# Generated at 2022-06-23 21:17:29.298918
# Unit test for constructor of class Choice
def test_Choice():
    ch = Choice()
    assert len(ch(items=['a', 'b', 'c'], length=0)) == 1
    assert len(ch(items=['a', 'b', 'c'], length=2)) == 2
    assert len(ch(items=['a', 'b', 'c'], length=10)) == 10

# Generated at 2022-06-23 21:17:30.394364
# Unit test for constructor of class Choice
def test_Choice():
    pass


# Generated at 2022-06-23 21:17:33.469690
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice.random.choice(["a", "b", "c"]) in ["a", "b", "c"]


# Generated at 2022-06-23 21:17:40.460372
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Tests the __call__ method  of class Choice."""
    c = Choice()
    # test a common use case
    assert (c(items=['a', 'b', 'c']) in ['a', 'b', 'c']) or \
           (c(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]) or \
           (c(items='abc', length=2) in ['ba', 'ca', 'cb'])



# Generated at 2022-06-23 21:17:42.436285
# Unit test for constructor of class Choice
def test_Choice():
    a = Choice() # Should not raise any exception
    b = Choice()
    assert(a == b)

# Generated at 2022-06-23 21:17:45.913835
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']

# Generated at 2022-06-23 21:17:47.916806
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis.providers.choice import Choice

    x = Choice()
    x(items=[1,2,3], length=2, unique=False)

# Generated at 2022-06-23 21:17:56.186802
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=[], length=0) is None
    i = Choice().__call__(items=[], length=-1)
    assert isinstance(i, ValueError)

    assert Choice().__call__(items=('a', 'b', 'c'), length=0) == 'c'
    assert Choice().__call__(items=('a', 'b', 'c'), length=1) == ('a',)
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == \
           ('c', 'a', 'a', 'b', 'c')

# Generated at 2022-06-23 21:18:05.140878
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis import Choice
    choice = Choice()
    print(choice(items=['1', '2', '3'], length=2, unique=True))
    print(choice(items=['a', 'b', 'c'], length=1))
    print(choice(items='abc', length=2))
    print(choice(items=('a', 'b', 'c'), length=5))
    print(choice(items='aabbbccccddddd', length=4, unique=True))
    # print(choice(items=['a', 'b', 'c'], length='str'))
    print(choice(items=[], length=0))
    print(choice(items=['a', 'b', 'c'], length=-1))
    print(choice(items='abc', length=2, unique=True))

# Generated at 2022-06-23 21:18:08.692600
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 2
    unique = True
    assert choice(items, length, unique) == 'ba'


if __name__ == "__main__":
    test_Choice()

# Generated at 2022-06-23 21:18:17.246222
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    from mimesis import Choice
    from mimesis.data import USER_AGENTS
    from mimesis.enums import CardinalDirection

    choice = Choice()
    assert choice(items=USER_AGENTS) in USER_AGENTS
    assert choice(items=USER_AGENTS, length=3) in USER_AGENTS
    assert choice(items=CardinalDirection, length=4) in CardinalDirection
    assert choice(items='abcdefghijklmnopqrstuvwxyz', length=10) in \
        'abcdefghijklmnopqrstuvwxyz'
    assert choice(items=['a', 'b', 'c'], length=5, unique=True) in \
        ['a', 'b', 'c']

# Generated at 2022-06-23 21:18:18.356041
# Unit test for constructor of class Choice
def test_Choice():
    x = Choice()
    print(x)

# Generated at 2022-06-23 21:18:29.192738
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    test_items = ['a', 'b', 'c']
    test_length = 2

    for x in ['', 1, 'string', None, [1, 2, 3], [], {'a': 1, 'b': 2}]:
        with pytest.raises(TypeError):
            choice.__call__(x)
    with pytest.raises(TypeError):
        choice.__call__(test_items, 1.0)
    with pytest.raises(ValueError):
        choice.__call__([], test_length)
    with pytest.raises(ValueError):
        choice.__call__([1, 2], -1)
    assert isinstance(choice.__call__(test_items), str)

# Generated at 2022-06-23 21:18:30.900640
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    msg = "Method __call__ of class Choice doesn't work."
    assert Choice().__call__(['a', 'b', 'c']) == 'c', msg

# Generated at 2022-06-23 21:18:37.472657
# Unit test for constructor of class Choice
def test_Choice():
    items = ['a', 'b', 'c']
    length = 5
    unique = True

    class Foo(object):
        def __init__(self):
            self.items = items
            self.length = length
            self.unique = unique
            self.choice = Choice()

        def test_choice(self):
            self.choice(self.items, self.length, self.unique)

    foo = Foo()
    foo.test_choice()


# Generated at 2022-06-23 21:18:43.843376
# Unit test for method __call__ of class Choice
def test_Choice___call__():

  from mimesis.builtins import Choice
  from mimesis.enums import Gender
  from mimesis.typing import GenderTyped
  from textwrap import dedent

  choice = Choice()
  choice.add_provider(Gender)

  items = choice.gender(gender=GenderTyped.FEMALE)
  length = choice.integer_number(lower_bound=0, upper_bound=5)
  unique = True

  x = choice(items=items, length=length, unique=unique)

# Generated at 2022-06-23 21:18:45.755899
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice is not None


# Generated at 2022-06-23 21:18:47.606585
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice('a', length=2) == 'aa'


# Generated at 2022-06-23 21:18:49.438264
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TODO: test_Choice___call__
    pass


# Generated at 2022-06-23 21:18:51.728649
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    #print(choice("abcde"))
    return choice("abcde")

# Generated at 2022-06-23 21:18:53.373158
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice is not None


# Generated at 2022-06-23 21:19:01.653674
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method `__call__` of class `Choice`."""
    choice = Choice()
    items = ['a', 'b', 'c']
    assert choice(items=items) in items
    assert choice(items=items, length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ba', 'cb', 'ac']