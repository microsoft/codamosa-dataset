

# Generated at 2022-06-23 21:09:09.530908
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert c(items=['a', 'b', 'c']) == 'c'
    assert c(items=['a', 'b', 'c'], length=1) == ['a']
    assert c(items='abc', length=2) == 'ba'
    assert c(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert c(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    
    # __call__ raises TypeError for non-sequence items or non-integer length
    c = Choice()
    try: c(items='abc',length='a')
    except TypeError: pass
    else: raise Exception()

# Generated at 2022-06-23 21:09:10.449649
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert isinstance(c, Choice)

# Generated at 2022-06-23 21:09:12.118366
# Unit test for constructor of class Choice
def test_Choice():
    Choice(seed=12345)

# Unit tests for method of class Choice

# Generated at 2022-06-23 21:09:21.054052
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method ``__call__``."""
    choice = Choice()
    assert isinstance(choice(items=['a', 'b', 'c']), str)
    assert isinstance(choice(items=['a', 'b', 'c'], length=1), list)
    assert isinstance(choice(items='abc', length=2), str)
    assert isinstance(choice(items=('a', 'b', 'c'), length=5), tuple)
    assert isinstance(choice(items='aabbbccccddddd', length=4, unique=True), str)
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']

# Generated at 2022-06-23 21:09:30.776859
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    res = c(items= ['a', 'b', 'c'], length=10)
    assert isinstance(res, list)
    res = c(items= ['a', 'b', 'c'], length=0)
    assert type(res) in (str, bytes)
    res = c(items= ['a', 'a', 'c'], length=2)
    assert isinstance(res, list)
    assert len(res) == 2
    c = Choice('en')
    res = c(items= ['a', 'b', 'c'], length=0)
    assert type(res) in (str, bytes)
    assert res in ['a', 'b', 'c']

# Generated at 2022-06-23 21:09:33.126061
# Unit test for constructor of class Choice
def test_Choice():
    a = Choice()
    print("test_Choice: ", a)
    print("\n")
    return a


# Generated at 2022-06-23 21:09:40.577567
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    print(choice(items=['a', 'b', 'c']))
    print(choice(items=['a', 'b', 'c'], length=1))
    print(choice(items='abc', length=2))
    print(choice(items=('a', 'b', 'c'), length=5))
    print(choice(items='aabbbccccddddd', length=4, unique=True))

# Unit test:
# python3 -m doctest -v choice.py
if __name__ == "__main__":
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-23 21:09:43.288226
# Unit test for constructor of class Choice
def test_Choice():
    """Tests for the constructor of Choice class."""
    from mimesis.providers.choice import Choice
    choice = Choice()

    assert choice is not None

# Generated at 2022-06-23 21:09:49.375211
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice(items=['a', 'b', 'c'])
    assert choice(items=['a', 'b', 'c'], length=1)
    assert choice(items='abc', length=2)
    assert choice(items=('a', 'b', 'c'), length=5)
    assert choice(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-23 21:09:58.826627
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert isinstance(c(items='abc'), str)
    # assert c(items='abc', length=-1) == TypeError
    # assert c(items='abc', length=1.0) == TypeError
    # assert c(items=0, length=1) == TypeError
    assert c(items='abc', length=0) in 'abc'
    assert isinstance(c(items=('a', 'b', 'c'), length=1), tuple)
    assert isinstance(c(items=('a', 'b', 'c'), length=5), tuple)
    assert isinstance(c(items=('a', 'b', 'c'), length=1), tuple)
    assert isinstance(c(items='abc', length=2), str)

# Generated at 2022-06-23 21:09:59.960410
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice() is not None


# Generated at 2022-06-23 21:10:07.303060
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    obj=Choice()
    print(obj(items=['a', 'b', 'c']))
    print(obj(items=['a', 'b', 'c'], length=1))
    print(obj(items='abc', length=2))
    print(obj(items=('a', 'b', 'c'), length=5))
    print(obj(items='aabbbccccddddd', length=4, unique=True))

if __name__ == '__main__':
    test_Choice___call__()

# Generated at 2022-06-23 21:10:09.691134
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'

# Generated at 2022-06-23 21:10:13.201461
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TODO: Raise TypeError when **length** is not an integer
    # TODO: Raise TypeError when **items** is not a sequence
    # TODO: Raise ValueError when **items** is an empty sequence
    # TODO: Raise ValueError when **length** is negative
    pass


# Generated at 2022-06-23 21:10:15.644051
# Unit test for constructor of class Choice
def test_Choice():
    """Test class Choice."""
    choice = Choice() # type: ignore
    assert(choice)


# Unit tests for function __call__ method of class Choice

# Generated at 2022-06-23 21:10:25.269666
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    provider = Choice()
    result = provider(items=['a', 'b', 'c'])
    assert isinstance(result, str)
    result = provider(items=['a', 'b', 'c'], length=1)
    assert isinstance(result, list)
    result = provider(items='abc', length=2)
    assert isinstance(result, str)
    result = provider(items=('a', 'b', 'c'), length=5)
    assert isinstance(result, tuple)
    result = provider(items='aabbbccccddddd', length=4, unique=True)
    assert isinstance(result, str)

# Generated at 2022-06-23 21:10:33.253781
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method __call__ of class Choice."""
    choice = Choice()

    assert 'b' == choice(items=['a', 'b', 'c'])
    assert ['a'] == choice(items=['a', 'b', 'c'], length=1)
    assert 'ba' == choice(items='abc', length=2)
    assert ('c', 'a', 'a', 'b', 'c') == choice(items=('a', 'b', 'c'), length=5)
    assert 'cdba' == choice(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-23 21:10:36.514620
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    _ch = Choice()
    _ch('abc')
    _ch('abc', 1)
    _ch('abc', 2)
    _ch('aabbbccccddddd', 4, True)
    _ch(('a', 'b', 'c'), 5)


# Generated at 2022-06-23 21:10:38.079099
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice is not None

# Tests for the function Choice.__call__

# Generated at 2022-06-23 21:10:46.737442
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice(seed=200)
    data1 = c.__call__(items=['a','b','c'])
    data2 = c.__call__(items=['a','b','c'], length=1)
    data3 = c.__call__(items='abc', length=2)
    data4 = c.__call__(items=('a', 'b', 'c'), length=5)
    data5 = c.__call__(items='aabbbccccddddd', length=4, unique=True)
    data6 = c.__call__(items=123, length=4, unique=True)
    assert data1 == 'a'
    assert data2 == ['c']
    assert data3 == 'cc'

# Generated at 2022-06-23 21:10:54.889540
# Unit test for constructor of class Choice
def test_Choice():
    # Create a Choice object
    c = Choice()
    # Generate a randomly-chosen sequence or bare element from a sequence
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    # Print the results
    print(c(items, length, unique))
    # Generate a randomly-chosen sequence or bare element from a sequence
    items = 'abc'
    length = 2
    unique = False
    # Print the results
    print(c(items, length, unique))
    # Generate a randomly-chosen sequence or bare element from a sequence
    items = ('a', 'b', 'c')
    length = len(items)
    unique = True
    # Print the results
    print(c(items, length, unique))
    # Generate a randomly-chosen sequence or bare element from a

# Generated at 2022-06-23 21:10:57.947112
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for the call method of the Choice class."""
    # TODO: Write unit tests


# Generated at 2022-06-23 21:11:05.902139
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice(random=True)
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:11:12.920730
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice(['a','b','c']) == 'c'
    assert choice(['a','b','c'],1) == ['a']
    assert choice('abc',2) == 'ba'
    assert choice(('a','b','c'),5) == ('c','a','a','b','c')
    assert choice('aabbbccccddddd',4, True) == 'cdba'
    assert choice(('a','b','c'),0, True) == 'c'
    assert choice(['a','b'],3, True) == ['a','b','a']
    assert choice(['a','b'],3) == ['a','b','b']

    try:
        choice(1,1)
    except TypeError:
        return True

    return False


# Generated at 2022-06-23 21:11:15.475379
# Unit test for constructor of class Choice
def test_Choice():
    r = Random()
    return r.choice('abc')

if __name__ == "__main__":
    print(test_Choice())

# Generated at 2022-06-23 21:11:26.004384
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) in ['ab', 'ac', 'bc']

# Generated at 2022-06-23 21:11:32.802177
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert isinstance(Choice().__call__(items=['a', 'b', 'c']), str)
    assert isinstance(Choice().__call__(items=['a', 'b', 'c'], length=1), list)
    assert isinstance(Choice().__call__(items='abc', length=2), str)
    assert isinstance(Choice().__call__(items=('a', 'b', 'c'), length=5), tuple)
    assert isinstance(Choice().__call__(items='aabbbccccddddd', length=4, unique=True), str)


# Generated at 2022-06-23 21:11:35.191002
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) in ['a', 'b', 'c']


# Generated at 2022-06-23 21:11:43.013402
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    # test input type of items
    try:
        choice(items=['a', 'b'], length=2)
        choice(items='a', length=1)
    except Exception as e:
        print(e)
        raise Exception(e)
    # test input type of length
    try:
        choice(items='a', length=1.0)
    except Exception as e:
        print(e)
    # test input value of length
    try:
        choice(items='a', length=-1)
    except Exception as e:
        print(e)
    # test input value of unique
    try:
        choice(items='abcabcabcabcabcabcabcabcabc', length=3, unique=True)
    except Exception as e:
        print(e)

# Generated at 2022-06-23 21:11:45.289533
# Unit test for constructor of class Choice
def test_Choice():
    test_case1 = Choice()    
    assert isinstance(test_case1, Choice)


# Generated at 2022-06-23 21:11:47.876100
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice(seed=123)

    assert choice('abc', 3) == ('b', 'c', 'c')

# Generated at 2022-06-23 21:11:56.020623
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import pytest
    from mimesis.exceptions import NonUniqueError
    from mimesis.typing import Sequence
    from pytest import raises
    from .utils import seed

    choice = Choice('en')

    choice(items=['a', 'b', 'c'])
    choice(items=('a', 'b', 'c'))
    choice(items='abc')

    choice(items=['a', 'b', 'c'], length=1)
    choice(items=('a', 'b', 'c'), length=2)
    choice(items='abc', length=3)

    choice(items=['a', 'b', 'c'], length=5)
    choice(items=('a', 'b', 'c'), length=5)
    choice(items='abc', length=5)


# Generated at 2022-06-23 21:12:00.693369
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice('abcd') in 'abcd'
    assert choice('abcd', 1) == ['d']
    assert choice('abcd', 2) == 'db'
    assert choice('abcd', 5) == ('c', 'b', 'd', 'a', 'd')
    assert choice('aabbbccccddddd', 4, True) == 'bcdc'


# Generated at 2022-06-23 21:12:03.079497
# Unit test for constructor of class Choice
def test_Choice():
    # Initialize methods
    # __init__
    # __call__

    c = Choice()
    assert isinstance(c, Choice)  # __init__
    assert isinstance(c(), str)  # __call__

    return True

# Generated at 2022-06-23 21:12:14.302291
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for Choice.__call__()"""
    import time
    import random
    import json
    import string
    import pytest

    start = time.time()
    choice = Choice()
    assert True
    end = time.time()
    print('test_Choice___call__() Duration: {}'.format(end - start))

    assert True
    start = time.time()
    items_list = [
        random.randint(0, 10000)
        for x in range(0, random.randint(0, 100))
    ]
    items_tuple = tuple(items_list)
    items_string = ''.join(random.choice(string.ascii_letters) for i in range(random.randint(0, 100)))  # noqa: E501

# Generated at 2022-06-23 21:12:19.338525
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    obj = Choice()
    assert isinstance(obj.__call__(items=['a', 'b']), str)
    assert isinstance(obj.__call__(items=['a', 'b', 'c'], length=1), list)
    assert isinstance(obj.__call__(items='abc', length=2), str)
    assert isinstance(obj.__call__(items=('a', 'b', 'c'), length=5), tuple)

# Generated at 2022-06-23 21:12:29.928887
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choices = ['a', 'b', 'c', 'd']
    choice = Choice()
    output = choice(items=choices)
    assert output in choices
    assert not isinstance(output, list)

    output = choice(items=choices, length=4)
    assert isinstance(output, list)
    assert len(output) == 4

    output = choice(items=choices, length=4, unique=True)
    assert isinstance(output, list)
    assert len(output) == 4

    output = choice(items=tuple(choices), length=5)
    assert isinstance(output, tuple)
    assert len(output) == 5

    output = choice(items='abc', length=3)
    assert isinstance(output, str)
    assert len(output) == 3

# Generated at 2022-06-23 21:12:35.551930
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice(['a', 'b', 'c']) == 'c'
    assert choice(['a', 'b', 'c'], 1) == ['a']
    assert choice('abc', 2) == 'ba'
    assert choice(('a', 'b', 'c'), 5) == ('c', 'a', 'a', 'b', 'c')
    assert choice('aabbbccccddddd', 4, True) == 'cdba'


# Generated at 2022-06-23 21:12:36.358397
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass



# Generated at 2022-06-23 21:12:37.554638
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice('en')
    c = Choice('en')

# Generated at 2022-06-23 21:12:39.697195
# Unit test for constructor of class Choice
def test_Choice():
    """Test constructor of class Choice."""
    obj = Choice()
    assert isinstance(obj, Choice)
    assert repr(Choice) == '<Choice>'


# Generated at 2022-06-23 21:12:49.974055
# Unit test for constructor of class Choice
def test_Choice():
    ch = Choice()
    assert ch(items=['a', 'b', 'c'], length=2, unique=True) == ['b', 'c']
    assert len(ch(items=['a', 'b', 'c'], length=5, unique=False)) == 5
    assert ch(items=['a', 'b', 'c'], length=2, unique=False) == ['a', 'a']
    assert ch(items=['a', 'b', 'c'], length=2, unique=False) != ['b', 'b']
    assert ch(items=['a', 'b', 'c']) != ['b', 'b']
    assert ch(items=['a', 'b', 'c']) != ['b', 'b']

# Generated at 2022-06-23 21:12:57.959836
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    choice = Choice()

    item1 = choice(items=['a', 'b', 'c'])
    item2 = choice(items=['a', 'b', 'c'], length=1)
    item3 = choice(items='abc', length=2)
    item4 = choice(items=('a', 'b', 'c'), length=5)
    item5 = choice(items='aabbbccccddddd', length=4, unique=True)
    assert item1 == 'c'
    assert item2 == ['a']
    assert item3 == 'ba'
    assert item4 == ('c', 'a', 'a', 'b', 'c')
    assert item5 == 'cdba'


if __name__ == '__main__':
    # Unit test
    test_Choice___call__()

# Generated at 2022-06-23 21:12:59.011478
# Unit test for constructor of class Choice
def test_Choice():
    """Test for Choice class."""
    obj = Choice()
    assert obj is not None

# Generated at 2022-06-23 21:13:08.405510
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    Choice()(items=['a', 'b', 'c'])
    try:
        Choice()(items=['a', 'b', 'c'], length=1)
        Choice()(items='abc', length=2)
        Choice()(items=('a', 'b', 'c'), length=5)
        Choice()(items='aabbbccccddddd', length=4, unique=True)
    except TypeError as err:
        print(err)
    try:
        Choice()(items=1, length=1)
    except TypeError as err:
        print(err)
    try:
        Choice()(items=[1, 2, 3], length='a')
    except TypeError as err:
        print(err)

# Generated at 2022-06-23 21:13:11.602662
# Unit test for constructor of class Choice
def test_Choice():
    """Test constructor of class Choice."""
    obj = Choice()
    assert obj.seed is None
    assert obj.random is not None
    assert obj.datetime is not None

# Generated at 2022-06-23 21:13:15.463276
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    sequence = ['a', 'b', 'c']
    length = 2
    unique = True

    outcome = choice(sequence, length, unique)
    expected_outcome = choice(sequence, length, unique)

    assert outcome == expected_outcome

# Generated at 2022-06-23 21:13:22.837397
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-23 21:13:28.339727
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Initialize
    choice = Choice()
    # Test for bare elements
    choice(items=['a', 'b', 'c'])  # 'c'
    choice(items=['a', 'b', 'c'], length=1)  # ['a']
    choice(items='abc', length=2)  # 'ba'
    choice(items=('a', 'b', 'c'), length=5)  # ('c', 'a', 'a', 'b', 'c')

    # Test for unique elements
    choice(items='aabbbccccddddd', length=4, unique=True)  # 'cdba'
    choice(items='aabbbccccddddd', length=5, unique=True)  # 'dacbd'

# Generated at 2022-06-23 21:13:30.902231
# Unit test for constructor of class Choice
def test_Choice():
    """Unit test for constructor of class Choice."""
    choice = Choice()
    assert choice is not None


# Generated at 2022-06-23 21:13:38.278901
# Unit test for constructor of class Choice
def test_Choice():
    """Test for class Choice."""
    from mimesis import Choice

    choice = Choice()
    c1 = choice(items=['a', 'b', 'c'])
    c2 = choice(items=['a', 'b', 'c'], length=1)
    c3 = choice(items='abc', length=2)
    c4 = choice(items=('a', 'b', 'c'), length=5)
    c5 = choice(items='aabbbccccddddd', length=4, unique=True)
    print(c1, c2, c3, c4, c5)

# Generated at 2022-06-23 21:13:39.463852
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)


# Generated at 2022-06-23 21:13:40.726029
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()

# Generated at 2022-06-23 21:13:50.259237
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    data = choice(items=items, length=length, unique=unique)
    assert any([data == 'c', data == 'b', data == 'a'])
    data = choice(items=items, length=length, unique=unique)
    assert any([data == 'c', data == 'b', data == 'a'])
    data = choice(items=items, length=length, unique=unique)
    assert any([data == 'c', data == 'b', data == 'a'])
    data = choice(items=items)
    assert any([data == 'c', data == 'b', data == 'a'])
    data = choice(items=items)
   

# Generated at 2022-06-23 21:13:58.410282
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    print('Testing Choice.__call__')
    from mimesis import Choice
    import random # Needed to seed the random number generator
    seed = 1
    random.seed(seed)

    choice = Choice(seed=seed)
    data = choice(items=['a', 'b', 'c'])
    assert data == 'c', 'Choice.__call__ failed.'

    data = choice(items=['a', 'b', 'c'], length=1)
    assert data == ['a'], "Choice.__call__ failed."

    data = choice(items='abc', length=2)
    assert data == 'ba', "Choice.__call__ failed."

    data = choice(items=('a', 'b', 'c'), length=5)

# Generated at 2022-06-23 21:13:59.370474
# Unit test for constructor of class Choice
def test_Choice():
    pass


# Generated at 2022-06-23 21:14:02.007176
# Unit test for constructor of class Choice
def test_Choice():
    # Constructor of class Choice
    choice = Choice()
    print(choice)
    return None # no return


# Generated at 2022-06-23 21:14:03.989938
# Unit test for constructor of class Choice
def test_Choice():
    choice_class = Choice(name='choice')
    choice_instance = choice_class(items=[1,2,3])
    assert choice_instance in [1,2,3], 'Choice error'
    print('Choice constructor test passed')


# Generated at 2022-06-23 21:14:04.540210
# Unit test for constructor of class Choice
def test_Choice():
    a = Choice()
    assert a


# Generated at 2022-06-23 21:14:08.162436
# Unit test for constructor of class Choice
def test_Choice():
    choice_0 = Choice()
    print(choice_0)
    print(choice_0.seed)
    assert choice_0.seed == "123444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"

# Generated at 2022-06-23 21:14:18.682581
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

    import pytest
    with pytest.raises(TypeError):
        choice(items='aabbbccccddddd', length=4.0, unique=True)

    with pytest.raises(ValueError):
        choice(items='')

# Generated at 2022-06-23 21:14:28.925592
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    choice = Choice()
    # Sequence of length 1
    data = choice('a')
    assert data == 'a'
    # Sequence of length 2
    data = choice('ab')
    assert data == 'a' or data == 'b'
    data = choice('ab', 1, True)
    assert data == 'a' or data == 'b'
    # Sequence of length 3
    data = choice('abc')
    assert data == 'a' or data == 'b' or data == 'c'
    data = choice('abc', 1, True)
    assert data == 'a' or data == 'b' or data == 'c'
    data = choice('abc', 2, True)
    assert data == 'ab' or data == 'ac' or data == 'bc'
   

# Generated at 2022-06-23 21:14:35.388162
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice.choice(items=['a', 'b', 'c'], length=10) == ['b', 'a', 'b', 'c', 'b',
                                                               'a', 'a', 'c', 'a', 'a']
    assert choice.choice(items=('a', 'b', 'c'), length=10) == ('b', 'a', 'a', 'c', 'a',
                                                               'a', 'b', 'c', 'b', 'a')

# Generated at 2022-06-23 21:14:45.835205
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Default items.
    #
    # Call a function.
    obj  = Choice()
    item = obj(items=['a', 'b', 'c'])
    # Check the result.
    assert item in ['a', 'b', 'c']
    # Call a function with a length of a sequence.
    item = obj(items=['a', 'b', 'c'], length=1)
    # Check the result.
    assert isinstance(item, list)
    assert item == ['a']
    # Call a function with a length of a sequence.
    item = obj(items='abc', length=2)
    # Check the result.
    assert isinstance(item, str)
    assert item in ['ab', 'ba', 'ac', 'ca', 'bc', 'cb']
    # Call a function with a length of a

# Generated at 2022-06-23 21:14:55.197019
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # 1. Test random choice from a list
    choice = Choice()
    items = [1, 2, 3, 4]
    assert choice(items=items) in items

    # 2. Test random choice of a list
    choice = Choice()
    assert [choice(items=items)] in [[1], [2], [3], [4]]

    # 3. Test random choice from a string
    choice = Choice()
    items = 'abc'
    assert choice(items=items) in items

    # 4. Test random choice of a string
    choice = Choice()
    assert [choice(items=items)] in [['a'], ['b'], ['c']]

    # 5. Test unique choices
    choice = Choice()
    items = [1, 1, 2, 2, 3, 3, 4, 4]

# Generated at 2022-06-23 21:14:56.766912
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    print(choice('abc', 1))

# Generated at 2022-06-23 21:15:07.220795
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert callable(choice.__call__)
    assert isinstance(choice.__call__, collections.abc.Callable)
    assert isinstance(choice('a'), str)
    assert isinstance(choice(['a'], 1), list)
    assert isinstance(choice('a', 1), str)
    assert isinstance(choice(('a', ), 5), tuple)
    assert isinstance(choice('aabbbccccddddd', 4, True), str)
    assert isinstance(choice.__call__(['a', 'b']), str)
    assert isinstance(choice.__call__(['a', 'b'], 3), list)
    try:
        choice('a', -1)
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-23 21:15:12.213823
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit testing for Choice.__call__()."""
    from mimesis.enums import Quantifier
    from mimesis.typing import Enum

    choice = Choice()

# Generated at 2022-06-23 21:15:13.663412
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice is not None


# Generated at 2022-06-23 21:15:15.013636
# Unit test for constructor of class Choice
def test_Choice():
    """Test for constructor of class Choice."""
    choice = Choice()
    assert str == type(choice)

# Generated at 2022-06-23 21:15:19.800959
# Unit test for constructor of class Choice
def test_Choice():
    """Unit test for constructor of class Choice."""
    choice = Choice()
    assert isinstance(choice, Choice)
    assert isinstance(choice, BaseProvider)


# Generated at 2022-06-23 21:15:23.279429
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert callable(choice)
    assert not isinstance(choice, list)
    assert not isinstance(choice, tuple)
    assert isinstance(choice, Choice)


# Generated at 2022-06-23 21:15:25.459539
# Unit test for constructor of class Choice
def test_Choice():
    """Test Choice Constructor.

    :return: None
    """
    provider = Choice()
    assert provider



# Generated at 2022-06-23 21:15:26.585672
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice

# Generated at 2022-06-23 21:15:27.938903
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert isinstance(c, Choice)

# Generated at 2022-06-23 21:15:32.495630
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    items = ['a', 'b', 'c']
    result = choice(items)
    assert result in items
    result = choice(items, unique=True)
    assert result in items
    result = choice(items, length=2, unique=True)
    assert len(result) == 2
    assert len(set(result)) == 2

# Generated at 2022-06-23 21:15:38.744578
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 1
    assert len(items) > 0
    assert len(items) < length
    assert choice(items=items) in items
    assert choice(items=items, length=length) in items
    assert choice(items=items, length=0) in items
    assert choice(items=items, length=1) in items
    assert choice(items=items, length=2) in items
    assert choice(items=items, length=3) in items
    assert choice(items=items, length=4) in items
    assert choice(items=items, length=5) in items
    assert choice(items=items, length=6) in items

# Generated at 2022-06-23 21:15:48.878818
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    from mimesis import Generic
    from mimesis.enums import Gender
    from mimesis.builtins import RussiaSpecProvider
    
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) == ['b']
    assert choice(items='abc', length=2) in ['ab', 'bc', 'ac', 'ba', 'cb', 'ca']

# Generated at 2022-06-23 21:15:59.910406
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for Choice.__call__()."""
    choice = Choice()
    assert choice() is None
    assert choice() is None
    assert choice() is None
    assert choice() is None
    assert choice() is None
    assert choice() is None
    assert choice() is None
    assert choice() is None
    assert choice() is None
    assert choice() is None

    assert choice(items=['a', 'b', 'c']) is not None
    assert choice(items=['a', 'b', 'c']) is not None
    assert choice(items=['a', 'b', 'c']) is not None
    assert choice(items=['a', 'b', 'c']) is not None
    assert choice(items=['a', 'b', 'c']) is not None

# Generated at 2022-06-23 21:16:00.977902
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice


# Generated at 2022-06-23 21:16:06.392595
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method __call__ of class Choice
    """
    # Arrange
    items = ('a', 'b', 'c')
    length = 5
    unique = False
    result = ('c', 'a', 'a', 'b', 'c')
    obj = Choice()

    # Act
    response = obj(items=items, length=length, unique=unique)

    # Assert
    assert response == result

# Generated at 2022-06-23 21:16:12.751607
# Unit test for constructor of class Choice
def test_Choice():
    choice_=Choice(local_provider=True)
    #print(choice_.__class__)
    print(choice_(length=2,items=['a', 'b', 'c'],unique=True))
    print(choice_._meta.fields)
    print(choice_._meta.fields['choice']['func'](length=2,
                                                  items=['a', 'b', 'c'],
                                                  unique=True))

#test_Choice()


# Generated at 2022-06-23 21:16:18.528155
# Unit test for constructor of class Choice
def test_Choice():
    items = ["a", "b", "c"]
    length = len(items)
    choice = Choice()
    # Возвращается последовательность элементов
    assert choice(items=items, length=length) == ['a', 'b', 'c']
    # Возвращается элемент
    assert choice(items=items) == 'c'

# Generated at 2022-06-23 21:16:21.869733
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    random_item = Choice().__call__(items=['a', 'b', 'c'], length=1)
    assert random_item == ['a']


# Generated at 2022-06-23 21:16:23.554870
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice is not None


# Generated at 2022-06-23 21:16:32.702931
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Tests for method __call__ of class Choice."""
    c = Choice()
    assert isinstance(c(items=[]), str)
    assert isinstance(c(items=('a', 'b', 'c')), str)
    assert isinstance(c(items='abc'), str)
    assert len(c(items=('a', 'b', 'c'), length=5)) == 5
    assert len(c(items='abc', length=5)) == 5
    assert len(c(items=('a', 'b', 'c'), length=5, unique=True)) == 5
    assert len(c(items='abc', length=5, unique=True)) == 5
    assert isinstance(c(items=[], length=1), list)

# Generated at 2022-06-23 21:16:34.560532
# Unit test for constructor of class Choice
def test_Choice():
    obj = Choice()
    assert isinstance(obj, Choice)

# Generated at 2022-06-23 21:16:43.288173
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Tests output of method __call__ of class Choice in module choice."""
    import sys
    if sys.version_info < (3, 6):
        return
    import pytest
    from mimesis.enums import Field
    from mimesis.schema import Field as SchemaField
    from mimesis.schema import Schema
    choice = Choice()
    # TODO change to return a list
    assert choice(items=[]) == choice(items=()) == ''
    # TODO change to return a list
    assert choice(items=['a', 'b']) == choice(items=('a', 'b')) == 'b'
    assert choice(items=['a', 'b'], length=2, unique=False) == ['a', 'b']

# Generated at 2022-06-23 21:16:45.320547
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice().__class__.__name__ == 'Choice'

# Generated at 2022-06-23 21:16:48.086014
# Unit test for constructor of class Choice
def test_Choice():
    ch = Choice('a', 'b', 'c')  # type: ignore
    assert ch('a', 'b', 'c')

# Generated at 2022-06-23 21:16:51.741640
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    print("Testing Choice.__call__")
    import doctest
    from mimesis.enums import Gender
    from mimesis.providers import Choice
    c = Choice('en', Gender.FEMALE)
    doctest.testmod(extraglobs={'choice': c})


# Generated at 2022-06-23 21:16:56.608496
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Check method __call__ in Choice class."""
    items = ['a', 'b', 'c', 'd', 'e', 'f']
    length = 4
    choice = Choice()

    result = choice(items=items, length=length)

    assert len(result) == length
    assert set(result) <= set(items)

# Generated at 2022-06-23 21:16:58.084880
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis import Choice

    choice = Choice()
    assert isinstance(choice, Choice)

# Generated at 2022-06-23 21:16:58.904758
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice()


# Generated at 2022-06-23 21:16:59.402277
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice() != None

# Generated at 2022-06-23 21:17:04.687266
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    choice(items=['a', 'b', 'c'])
    choice(items=['a', 'b', 'c'], length=1)
    choice(items='abc', length=2)
    choice(items=('a', 'b', 'c'), length=5)
    choice(items='aabbbccccddddd', length=4, unique=True)
# Test for failure
#choice(items=['a', 'b', 'c'], length=5, unique=False)

# Generated at 2022-06-23 21:17:10.651298
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from random import randint

    choice = Choice()
    items = [randint(0, 1000) for _ in range(5)]
    length = randint(0, len(items))
    unique = randint(0, 1)
    result = choice(items=items, length=length, unique=unique)
    assert length == len(result)
    assert type(items) == type(result)

# Generated at 2022-06-23 21:17:15.218829
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from random import choice
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 1
    x = choice(items, length)
    assert x == ['a']
    assert type(x) == list

# Generated at 2022-06-23 21:17:19.459951
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    from mimesis.providers.choice import Choice
    assert Choice().__call__(['a', 'b', 'c']) == 'c'
    assert Choice().__call__(['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__('abc', length=2) == 'ba'
    assert Choice().__call__(('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__('aabbbccccddddd', length=4, unique=True) == 'cdba'
    assert Choice().__call__('aabbbccccddddd', length=4) == 'daac'
    assert Choice().__call

# Generated at 2022-06-23 21:17:22.084740
# Unit test for constructor of class Choice
def test_Choice():
    ch = Choice('seed')
    assert ch is not None


# Generated at 2022-06-23 21:17:30.468926
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from hypothesis import strategies as st
    from hypothesis import given
    from mimesis import Choice
    count_iterable = st.integers(min_value=0, max_value=9)
    # TODO: Add strategy for items
    items_strategy = st.integers(min_value=0, max_value=9)
    items_strategy = st.builds(tuple, items_strategy, count_iterable)
    items_strategy = st.deferred(lambda: items_strategy)
    @given(items_strategy, count_iterable, st.booleans())
    def test(items, count, unique):
        choice = Choice()

# Generated at 2022-06-23 21:17:38.012704
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert c(items=['a', 'b', 'c']) == 'c'
    assert c(items=['a', 'b', 'c'], length=1) == ['a']
    assert c(items='abc', length=2) == 'ba'
    assert c(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert c(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:17:39.703448
# Unit test for constructor of class Choice
def test_Choice():
    # We create an object of class Choice.
    choice = Choice()
    # We print the "string representation" of the object.
    print(choice)



# Generated at 2022-06-23 21:17:40.282589
# Unit test for constructor of class Choice
def test_Choice():
    tmp = Choice()
    print(tmp)

# Generated at 2022-06-23 21:17:49.865226
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items_list = ['a', 'b', 'c']
    length = 2
    unique = False
    choice = Choice()

    assert isinstance(choice(items=items_list, length=1), list)
    assert not isinstance(choice(items=items_list), list)
    assert len(choice(items=items_list, length=length)) == length
    assert len(set(choice(items=items_list, length=length,
                          unique=unique))) == len(choice(items=items_list,
                                                       length=length,
                                                       unique=unique))
    assert len(set(choice(items=items_list, length=length,
                          unique=True))) == len(choice(items=items_list,
                                                      length=length,
                                                      unique=True))

# Generated at 2022-06-23 21:17:51.243277
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice

    choice = Choice('en')
    print('choice:', choice)


# Generated at 2022-06-23 21:17:51.753108
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-23 21:17:53.739192
# Unit test for constructor of class Choice
def test_Choice():
    obj = Choice()
    assert obj is not None

# Generated at 2022-06-23 21:17:58.763404
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()

    # Test __init__()
    assert isinstance(choice, Choice)
    assert isinstance(choice, BaseProvider)

    assert choice.random is not None
    assert choice._locales is not None
    assert choice._special_methods is not None



# Generated at 2022-06-23 21:18:10.272591
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender
    from mimesis.builtins.geography import Address
    from mimesis.builtins.identification import Passport
    from mimesis.builtins.person import Person

    pp = Passport('en', gender=Gender.MALE)
    p = Person('en', gender=Gender.MALE)
    a = Address('en')

    random_choice = Choice()

    assert pp.serial_number() in \
        random_choice(items=pp.serial_number_formats, length=1)
    assert pp.passport_number() in \
        random_choice(items=pp.passport_number_formats, length=1)
    assert p.full_name() in \
        random_choice(items=[p.full_name()], length=1)
    assert p

# Generated at 2022-06-23 21:18:18.225821
# Unit test for constructor of class Choice
def test_Choice():
    d = Choice()
    assert d(['a','b','c','d','e','f','g','h','i','j','k','l','m',
         'n','o','p','q','r','s','t','u','v','w','x','y','z']) in \
         ['a','b','c','d','e','f','g','h','i','j','k','l','m',
          'n','o','p','q','r','s','t','u','v','w','x','y','z']

# Generated at 2022-06-23 21:18:29.114567
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    res1 = choice(items=['a', 'b', 'c'])
    res2 = choice(items=['a', 'b', 'c'], length=1)
    res3 = choice(items='abc', length=2)
    res4 = choice(items=('a', 'b', 'c'), length=5)
    res5 = choice(items='aabbbccccddddd', length=4, unique=True)
    assert res1 in ['a', 'b', 'c']
    assert res2 in [['a'], ['b'], ['c']]
    assert res3 in ['ab', 'ac', 'ba', 'bc', 'ca', 'cb']

# Generated at 2022-06-23 21:18:37.014641
# Unit test for constructor of class Choice
def test_Choice():
    try:
        Choice()
    except:
        raise AttributeError()

    # Unit test for constructor of class Choice with given non-sequence items
    try:
        Choice(items=None)
        raise AssertionError()
    except TypeError:
        pass

    # Unit test for constructor of class Choice with given non-sequence items
    try:
        Choice(items=123)
        raise AssertionError()
    except TypeError:
        pass

    # Unit test for constructor of class Choice with given empty items
    try:
        Choice(items=[])
        raise AssertionError()
    except ValueError:
        pass

    # Unit test for constructor of class Choice with given non-integer length
    try:
        Choice(length='-1')
        raise AssertionError()
    except TypeError:
        pass

    #

# Generated at 2022-06-23 21:18:46.393908
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()

    assert isinstance(choice(items=['a', 'b', 'c']), str)
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) == ['b']
    assert choice(items='abc', length=2) == 'bc'
    assert choice(items=('a', 'b', 'c'), length=5) == ('b', 'b', 'b', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'dcba'

    import pytest

# Generated at 2022-06-23 21:18:54.372613
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    expected_results = [
        ['a', 'a', 'a'],
        ['a', 'a', 'a', 'a'],
        ['a', 'a', 'b', 'b'],
        ['a', 'a', 'c', 'c'],
        ['b', 'b', 'c', 'c'],
        ['a', 'b', 'b', 'c'],
        ['a', 'a', 'c', 'c'],
        ['a', 'a', 'b', 'c'],
        ['a', 'a', 'b', 'b'],
        ['a', 'b', 'c', 'c'],
    ]


# Generated at 2022-06-23 21:19:02.710871
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # We can't just import Choice and use it in the unit tests, because
    # we need to mock imported modules, like random, datetime, etc.
    # In order to do this, we need to import Choice locally inside the function
    from mimesis.providers.misc import Choice
    choice = Choice()

    # Test 1: items: ['a', 'b', 'c'], length: 0, unique: False
    result = choice(items=['a', 'b', 'c'], length=0, unique=False)
    assert isinstance(result, str) and result in ['a', 'b', 'c']

    # Test 2: items: ['a', 'b', 'c'], length: 1, unique: False
    result = choice(items=['a', 'b', 'c'], length=1, unique=False)