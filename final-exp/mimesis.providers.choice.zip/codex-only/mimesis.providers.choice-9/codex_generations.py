

# Generated at 2022-06-23 21:09:08.673654
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice.choice(['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice.choice(['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice.choice('abc', length=2) in ['ab', 'bc', 'ca']

# Generated at 2022-06-23 21:09:11.705327
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    from mimesis import Choice
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']



# Generated at 2022-06-23 21:09:20.429020
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice
    items = ['a', 'b']
    length = 1
    unique = True
    assert not choice(items, length, unique) == 'b'
    assert choice((1, 2, 3)) == 3
    assert choice((1, 2, 3), length=1) == (1,)
    assert choice('abc', length=2) == 'ba'
    assert choice(('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice('aabbbccccddddd', length=4, unique=True) == 'cdba'
    assert not choice('aabbbccccddddd', unique=True) == 'ccdd'

# Generated at 2022-06-23 21:09:27.933784
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    data = ['a', 'b', 'c']
    choice(items=data)

    # test for wrong data type
    error_type = None
    try:
        choice(items='abc')
        choice(items=('a', 'b', 'c'))
        choice(items=123)
    except TypeError as err:
        error_type = err
    assert error_type is None

    # test for wrong length
    error_type = None
    try:
        choice(items=data, length=-1)
        choice(items=data, length=1)
        choice(items=data, length='a')
    except TypeError as err:
        error_type = err
    assert error_type is None

    data2 = []
    error_value = None

# Generated at 2022-06-23 21:09:37.237045
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method __call__ of class Choice."""
    obj = Choice()
    assert obj.__call__(items=['a', 'b', 'c']) == 'c'
    assert obj.__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert obj.__call__(items='abc', length=2) == 'ba'
    assert obj.__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert obj.__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:09:40.813869
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice.__call__(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice.__call__(items=['a', 'b', 'c'], length=4) in [['a', 'a', 'c', 'b'], ['b', 'c', 'b', 'a'], ['c', 'b', 'a', 'a']]



# Generated at 2022-06-23 21:09:42.842978
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert c is not None


# Generated at 2022-06-23 21:09:46.147790
# Unit test for constructor of class Choice
def test_Choice():
    """Perform unit tests on constructor of class Choice."""
    choice = Choice()
    assert(choice is not None)

# Test for __call__ of class Choice

# Generated at 2022-06-23 21:09:56.070877
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    t = Choice()
    result = t.choice.__call__(items=['a', 'b', 'c'])
    assert result in ['a', 'b', 'c']
    result = t.choice.__call__(items=['a', 'b', 'c'], length=1)
    assert result in [['a'], ['b'], ['c']]
    result = t.choice.__call__(items='abc', length=2)
    assert result in ['aa', 'bb', 'cc', 'ab', 'bc', 'ac', 'ba', 'cb', 'ca']
    result = t.choice.__call__(items=('a', 'b', 'c'), length=5)

# Generated at 2022-06-23 21:10:03.237637
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import hypothesis.strategies
    from mimesis.enums import DefaultProviders

    strategy = hypothesis.strategies.lists(
        hypothesis.strategies.text(min_size=0, max_size=10),
        min_size=0, max_size=10,
    )
    provider = DefaultProviders.CHOICE.value()

    choice_1 = provider()
    assert isinstance(choice_1, str)
    assert choice_1 in ['a', 'b', 'c', 'd', 'e', 'f', 'g',
                        'h', 'i', 'j', 'k', 'l', 'm', 'n',
                        'o', 'p', 'q', 'r', 's', 't', 'u',
                        'v', 'w', 'x', 'y', 'z']

    choice_

# Generated at 2022-06-23 21:10:13.127717
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Arrange
    choice = Choice()

    # Act
    result1 = choice(items=['a', 'b', 'c'])
    result2 = choice(items=['a', 'b', 'c'], length=1)
    result3 = choice(items='abc', length=2)
    result4 = choice(items=('a', 'b', 'c'), length=5)
    result5 = choice(items='aabbbccccddddd', length=4, unique=True)

    # Assert
    assert isinstance(result1, str)
    assert isinstance(result2, list)
    assert isinstance(result3, str)
    assert isinstance(result4, tuple)
    assert isinstance(result5, str)


# Generated at 2022-06-23 21:10:24.566130
# Unit test for constructor of class Choice
def test_Choice(): # pylint: disable=invalid-name
    """Unit test for constructor of class Choice."""
    ch = Choice() # pylint: disable=invalid-name

    # pylint: disable=too-many-branches
    choices = [
        'abc', (1, 2, 3), ['a', 'b', 'c'],
        ['a', 'b', 'c'], 'abc', (1, 2, 3),
        ['a', 'b', 'c'], ['a', 'b', 'c'], 'abc',
        (1, 2, 3), ['a', 'b', 'c'], ['a', 'b', 'c'],
        (1, 2, 3), ['a', 'b', 'c'],
    ]
    lengths = [1, 2, 5]

# Generated at 2022-06-23 21:10:34.739726
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method __call__ of class Choice."""

    # Arrange
    choice1 = Choice()
    choice2 = Choice()
    choice3 = Choice()
    choice4 = Choice()

    # Act
    result1 = choice1(items=['a', 'b', 'c'])
    result2 = choice2(items=['a', 'b', 'c'], length=1)
    result3 = choice3(items='abc', length=2)
    result4 = choice4(items=('a', 'b', 'c'), length=5)

    # Assert
    assert isinstance(result1, str)
    assert result1 in ['a', 'b', 'c']

    assert isinstance(result2, list)
    assert len(result2) == 1

# Generated at 2022-06-23 21:10:35.614755
# Unit test for constructor of class Choice
def test_Choice():

    print(Choice())

# Generated at 2022-06-23 21:10:43.461356
# Unit test for constructor of class Choice
def test_Choice():
    test = Choice()

    __items = ['a', 'b', 'c']
    assert test(__items) in __items or test(__items) == 'c'
    assert test(__items, length=1) == ['a']
    assert test(__items, length=2) in ['ab', 'ac', 'bc']

    __items = ('a', 'b', 'c')
    assert test(__items, length=1) == ('a',)
    assert test(__items, length=2) in [('a', 'a'), ('a', 'b'), ('a', 'c'), ('b', 'a'), ('b', 'b'), ('b', 'c'), ('c', 'a'), ('c', 'b'), ('c', 'c')]

    __items = 'abc'

# Generated at 2022-06-23 21:10:49.462380
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()

    assert choice(items=['a', 'b', 'c'])
    assert choice(items=['a', 'b', 'c'], length=1)
    assert choice(items='abc', length=2)
    assert choice(items=('a', 'b', 'c'), length=5)
    assert choice(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-23 21:10:51.287387
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert c.random.choice(['a','b','c']) in ['a','b','c']

# Generated at 2022-06-23 21:10:58.716239
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.builtins import Choice

    choice = Choice()
    out = choice(items=['a', 'b', 'c'])
    out2 = choice(items=['a', 'b', 'c'], length=1)
    out3 = choice(items='abc', length=2)
    out4 = choice(items=('a', 'b', 'c'), length=5)
    out5 = choice(items='aabbbccccddddd', length=4, unique=True)
    assert out in ['a', 'b', 'c']
    assert out2 == ['a']
    assert out3 in ['ab', 'ac', 'bc']
    assert len(out4) == 5
    assert out5 in ['cdba', 'adbc']

# Generated at 2022-06-23 21:11:01.330903
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()  # It is ok to instantiate the class
    c('a', 'b')   # It is ok to call the class with no argument

# Generated at 2022-06-23 21:11:10.425630
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Tests for method __call__
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ('c', 'b', 'c')
    assert choice(items=['a', 'b', 'c'], length=1) == ['c']
    assert choice(items='abc', length=2) in ('ac', 'bc', 'ca', 'cb', 'ca', 'cb')
    assert choice(items=('a', 'b', 'c'), length=5) in (('c', 'a', 'a', 'b', 'c'), ('c', 'a', 'b', 'a', 'c'), ('c', 'a', 'b', 'c', 'a'))

# Generated at 2022-06-23 21:11:15.748147
# Unit test for constructor of class Choice
def test_Choice():

    from mimesis import Choice
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:11:20.411544
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from hypothesis import given
    from hypothesis.strategies import integers, lists
    from typing import List

    from mimesis.builtins import Choice as RealChoice

    @given(items=lists(), length=integers(), unique=integers())
    def test(items: List[int], length: int, unique: int) -> None:
        choice = Choice()
        assert choice(items, length, unique) == RealChoice().choice(items, length, unique)
    test()

# Generated at 2022-06-23 21:11:27.977001
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    cc = Choice()
    for i in range(1000):
        assert isinstance(cc('abc', length=1), str)
        assert isinstance(cc(['a', 'b', 'c'], length=1), list)
        assert cc(['a', 'b', 'c'], length=1)[0] in ['a', 'b', 'c']
        assert isinstance(cc(('a', 'b', 'c'), length=1), tuple)
        assert cc(('a', 'b', 'c'), length=1)[0] in ['a', 'b', 'c']

# Generated at 2022-06-23 21:11:33.114398
# Unit test for constructor of class Choice
def test_Choice():
    # Create instance of class Choice
    choice = Choice()
    
    # Create a dictionary of arguments and their expected output
    items = ['a', 'b', 'c']
    length = 1
    unique = True
    tests = {
        'items': items,
        'length': length,
        'unique': unique,
    }

    for test, expected in tests.items():
        # Check if the expected output is equal to the method output
        assert choice(test) == expected

# Generated at 2022-06-23 21:11:41.140114
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from nose.tools import assert_equal, assert_true
    from mimesis import Choice

    choice = Choice()
    assert_equal(choice(items=['a', 'b', 'c']), 'c')
    assert_equal(choice(items=['a', 'b', 'c'], length=1), ['a'])
    assert_equal(choice(items='abc', length=2), 'ba')
    assert_equal(choice(items=('a', 'b', 'c'), length=5), ('c', 'a', 'a', 'b', 'c'))
    assert_equal(choice(items='aabbbccccddddd', length=4, unique=True), 'cdba')



# Generated at 2022-06-23 21:11:51.936815
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method __call__ of class Choice."""
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ba', 'ac', 'bc']
    assert choice(items=('a', 'b', 'c'), length=5) in [
        ('c', 'a', 'a', 'b', 'c'),
        ('a', 'b', 'b', 'c', 'a'),
        ('b', 'a', 'a', 'b', 'c'),
        ('a', 'b', 'b', 'a', 'c'),
    ]
   

# Generated at 2022-06-23 21:11:58.905516
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method __call__ of class Choice."""
    choice = Choice()
    items = ['a', 'b', 'c']
    assertion_msg = 'Should be a non-empty sequence of elements.'
    try:
        assert choice.__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba', assertion_msg
    except Exception as e:
        raise AssertionError(f'Test for method  __call__ of class Choice failed: {e}')

# Test for method __call__ of class Choice
test_Choice___call__()


if __name__ == '__main__':
    choice = Choice()
    print(choice(items='aabbbccccddddd', length=4, unique=True))

# Generated at 2022-06-23 21:12:06.068314
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ab', 'ac', 'bc']

# Generated at 2022-06-23 21:12:16.082923
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test function."""
    choice = Choice()

    items = ['a', 'b', 'c']
    length = 1
    unique = False
    assert choice(items, length, unique) is not None

    items = ['a', 'b', 'c']
    length = 1
    unique = True
    assert choice(items, length, unique) is not None

    items = 'abc'
    length = 2
    unique = False
    assert choice(items, length, unique) is not None

    items = ('a', 'b', 'c')
    length = 5
    unique = False
    assert choice(items, length, unique) is not None

    items = 'aabbbccccddddd'
    length = 4
    unique = True
    assert choice(items, length, unique) is not None

    items = []
   

# Generated at 2022-06-23 21:12:22.536471
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Tests logic of method __call__ of class Choice."""
    choice = Choice()
    if choice(items=['a', 'b', 'c']) != 'c' or \
            choice(items=['a', 'b', 'c'], length=1) != ['a'] or \
            choice(items='abc', length=2) != 'ba' or \
            choice(items=('a', 'b', 'c'), length=5) != ('c', 'a', 'a', 'b', 'c') or \
            choice(items='aabbbccccddddd', length=4, unique=True) != 'cdba':
        # fixme: Return type of method should be a sequence for length > 0.
        exit(-1)

# Generated at 2022-06-23 21:12:32.766950
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    # Use the Choice class to construct an instance
    choice = Choice()

    # Generate a list of integers chosen from the integers in [1, 2, 3]
    assert choice([1, 2, 3]) in [1, 2, 3]

    # Generate an integer from the integers in [1, 2, 3]
    assert choice([1, 2, 3], length=1) in [1, 2, 3]

    # Generate a list of integers chosen from the integers in [1, 2, 3]
    assert choice((1, 2, 3), length=5) in [(1, 2, 3), (3, 1, 2), (2, 1, 3)]

    # Generate list of integers with no duplicates chosen from the integers
    # in [1, 2]

# Generated at 2022-06-23 21:12:35.890934
# Unit test for constructor of class Choice
def test_Choice():
    """Test class Choice."""
    choice = Choice()
    print(choice(items=[1, 2, 3]))
    print(choice(items=[1, 2, 3], length=2))
    print(choice(items='abcdef', length=3, unique=True))

# Generated at 2022-06-23 21:12:36.725013
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from doctest import testmod
    testmod()

# Generated at 2022-06-23 21:12:39.541571
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Arrange
    choice = Choice()

    # Act
    actual = choice(items=['a', 'b', 'c'], length=3)

    # Assert
    expected = ['a', 'b', 'c']
    assert actual == expected

# Generated at 2022-06-23 21:12:42.606448
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice(25)
    list1 = ['a', 'b', 'c']
    # call with items=['a', 'b', 'c'], length=1, unique=False
    assert choice(items=['a', 'b', 'c'], length=1, unique=False) == list1


# Generated at 2022-06-23 21:12:50.264587
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    data = [
        ['a', 'b', 'c'],
        ['a', 'b', 'c'],
        'abc',
        ['a', 'b', 'c'],
        'aabbbccccddddd',
    ]
    length = [
        0,
        1,
        2,
        5,
        4
    ]
    unique = [
        True,
        True,
        True,
        True,
        True,
    ]

    c = Choice()
    for i in range(0, len(data)):
        assert isinstance(c(items=data[i], length=length[i], unique=unique[i]), str)
        # assert isinstance(c(items=data[i], length=length[i], unique=unique[i]), list)
        # assert isinstance(

# Generated at 2022-06-23 21:12:51.270975
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert repr(choice) == "<Choice()>"

# Generated at 2022-06-23 21:12:53.147815
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice(seed=0)
    assert choice('abc') == 'a'
    assert choice('abc', length=2) == 'ba'


# Generated at 2022-06-23 21:12:54.197550
# Unit test for constructor of class Choice
def test_Choice():
    # TODO: For now it is not needed.
    pass

# Generated at 2022-06-23 21:12:57.882906
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Arrange:
    from mimesis.providers import Choice
    choice = Choice()

    # Act:
    items = ['a', 'b', 'c']
    result = choice(items=items)

    # Assert:
    assert 'a' in result
    assert 'b' in result
    assert 'c' in result


# Generated at 2022-06-23 21:13:07.529901
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    # c(items=None, integer=None, unique=True)
#     c(items=['a','b','c'], integer=2, unique=True)
#     c(items='abbbcccc', integer=4, unique=True)
    items = ['a','b','c']
    try:
        c(items=items,length=2, unique=True)
    except Exception as e:
        raise e
    c(items,length=2, unique=True)
#     c(items=items,length=2)
#     c(items=items,length=2, unique=True)
#     c(items,length=2, unique=False)
    print(c(items,length=2, unique=True))
#     c(items,length=2, unique=False)
   

# Generated at 2022-06-23 21:13:11.368164
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 1
    unique = True
    __call__ = choice(items=items, length=length, unique=unique)
    assert __call__ == ['b']

# Generated at 2022-06-23 21:13:14.459908
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    method = Choice().__call__
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    assert method(items=items, length=length, unique=unique) == ['a']


# Generated at 2022-06-23 21:13:24.747570
# Unit test for constructor of class Choice
def test_Choice():
    import argparse
    import sys
    import unittest

    parser = argparse.ArgumentParser("Unit tests for class Choice")
    parser.add_argument('--result', '-r', action='store_true', default=False,
                        help="only print the result, and not the function call")
    parser.add_argument('--quiet', '-q', action='store_true', default=False,
                        help="suppress the output of all test results")
    args = parser.parse_args()

    if not args.quiet:
        print('\nUnit tests for class Choice\n')

    class ChoiceTestCase(unittest.TestCase):
        def setUp(self) -> None:
            self.choice = Choice();
            self.items: List[Any] = ['a', 'b', 'c']
            self.length

# Generated at 2022-06-23 21:13:32.645260
# Unit test for constructor of class Choice
def test_Choice():
    """Test Choice class."""
    # test case
    print("test_Choice")
    # test setup
    choice = Choice()
    print(choice(['a', 'b', 'c']))
    print(choice(['a', 'b', 'c'], 1))
    print(choice('abc', 2))
    print(choice(('a', 'b', 'c'), 5))
    print(choice('aabbbccccddddd', 4, True))

if __name__ == "__main__":
    test_Choice()

# Generated at 2022-06-23 21:13:34.327968
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert len(Choice().__call__(["a", "b", "c"], length=5)) == 5


# Generated at 2022-06-23 21:13:41.937473
# Unit test for constructor of class Choice
def test_Choice():
    import pytest

    with pytest.raises(TypeError):
        Choice()(items=None, length=0, unique=False)
    with pytest.raises(TypeError):
        Choice()(items=['a', 'b', 'c'], length='1', unique=False)
    with pytest.raises(ValueError):
        Choice()(items=[], length=0, unique=False)
    with pytest.raises(ValueError):
        Choice()(items=['a', 'b', 'c'], length=-1, unique=False)
    with pytest.raises(ValueError):
        Choice()(items=['a', 'b', 'c'], length=4, unique=True)

# Generated at 2022-06-23 21:13:49.679824
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-23 21:13:51.736624
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice(items=['a', 'b', 'c'], length=5, unique=False) == [
        'c', 'b', 'b', 'b', 'a']

# Generated at 2022-06-23 21:13:53.780935
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 1
    unique = True
    assert choice(items, length, unique) == ['a']

# Generated at 2022-06-23 21:14:01.952711
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Arrange
    from mimesis.enums import Datatype
    from mimesis.providers import Datetime
    from mimesis.providers import Date
    from mimesis.providers import Time
    from mimesis.providers import Person

    en_US = Datetime('en', 'US')
    en_US.seed(1)
    en_US.set_datatype(Datatype.DATE)

    en_US2 = Date('en', 'US')
    en_US2.seed(1)

    en_US3 = Time('en', 'US')
    en_US3.seed(1)

    en_US4 = Person('en', 'US')
    en_US4.seed(1)

    # Act
    _ = en_US.date()
    _ = en

# Generated at 2022-06-23 21:14:05.628315
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # coverage run -m unittest tests.test_choice.ChoiceTestCase.test___call__
    provider = Choice()
    assert provider(items=['a', 'b', 'c']) == 'c'


# Generated at 2022-06-23 21:14:16.729459
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(['a', 'b', 'c']) == 'c'
    assert Choice().__call__(['a', 'b', 'c', 'd'], length = 1, unique = True) == ['a']
    assert Choice().__call__(['a', 'b', 'c', 'd'], length = 1) == ['b']
    assert Choice().__call__(['a', 'b', 'c', 'd'], length = 2, unique = True) == ['b', 'a']
    assert Choice().__call__('abcde', length = 3) == 'ebc'
    assert Choice().__call__(('a', 'b', 'c', 'd'), length = 2) == ('b', 'a')

# Generated at 2022-06-23 21:14:17.565908
# Unit test for constructor of class Choice
def test_Choice():
    v = Choice()
    print(v)


# Generated at 2022-06-23 21:14:22.741785
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    cls = Choice()
    assert cls(items=['a', 'b', 'c']) == 'c'
    assert cls(items=['a', 'b', 'c'], length=1) == ['a']
    assert cls(items='abc', length=2) == 'ba'
    assert cls(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert cls(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:14:30.744599
# Unit test for constructor of class Choice
def test_Choice():
    # Initialize Choice obj
    choice = Choice()
    assert callable(choice) is True # check if obj is callable
    assert type(choice()) != type(()) and type(choice()) != type([]) # check random choice function

    # Check if items is a sequence
    # Empty sequence
    try:
        choice(items=[])
    except ValueError:
        pass
    else:
        print('ValueError expected')

    # Non-sequence
    try:
        choice(items=1)
    except TypeError:
        pass
    else:
        print('TypeError expected')

    # Check if length is an int
    # String
    try:
        choice(items=[1, 2, 3], length='5')
    except TypeError:
        pass
    else:
        print('TypeError expected')

    # Float
   

# Generated at 2022-06-23 21:14:31.806887
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice


# Generated at 2022-06-23 21:14:38.919710
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    assert Choice().__call__(items=items) in ['a', 'b', 'c']
    assert Choice().__call__(items=items, length=1) in [['a'], ['b'], ['c']]
    assert Choice().__call__(items='abc', length=2) in ['ba', 'ac', 'cb']
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) in [('c', 'a', 'a', 'b', 'c'), ('c', 'c', 'c', 'b', 'a'), ('a', 'b', 'a', 'b', 'c')]

# Generated at 2022-06-23 21:14:42.573856
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 2
    unique = True
    choice = Choice()
    result = choice(items=items, length=length, unique=unique)
    assert isinstance(result, str)

# Generated at 2022-06-23 21:14:46.976274
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = [1,2,3, "a"]
    length_1 = 2
    unique_1 = False

    choice = Choice()
    print(choice(items, length_1, unique_1))
if __name__ == '__main__':
    test_Choice___call__()

# Generated at 2022-06-23 21:14:56.276298
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    print(choice(items=['a', 'b', 'c']))
    assert choice(items=['a', 'b', 'c']) == 'c'
    print(choice(items=['a', 'b', 'c'], length=1))
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    print(choice(items='abc', length=2))
    assert choice(items='abc', length=2) == 'ba'
    print(choice(items=('a', 'b', 'c'), length=5))
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')

# Generated at 2022-06-23 21:15:04.981153
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis import Choice
    choice = Choice()
    items = ['a', 'b', 'c']
    choice(items=items, length=3)
    choice(items=items, length=1)
    choice(items='abc', length=2)
    choice(items='aabbbccccddddd', length=4, unique=True)
    choice(items='aabbbccccddddd', length=1, unique=True)
    choice(items='aabbbccccddddd', length=0, unique=True)
    choice(items='aabbbcc', length=1, unique=True)

# Generated at 2022-06-23 21:15:05.855433
# Unit test for constructor of class Choice
def test_Choice():
    assert(str(Choice()) != None)

# Generated at 2022-06-23 21:15:10.626626
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """
    Unit test for method __call__ of class Choice.

    """
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-23 21:15:18.624720
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    #assert choice(items=['a', 'b', 'c'], length=0) == 'c'
    #assert choice(items=['a', 'b', 'c'], length=1, unique=True) == 'c'
    #assert choice(items=['a

# Generated at 2022-06-23 21:15:20.045927
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'



# Generated at 2022-06-23 21:15:29.493925
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert type(choice('abc')) == str
    assert choice('abc', 2) == 'ca'
    assert choice('abc', 2, True) == 'bc'
    assert choice(['a', 'b', 'c'], 2) == ['a', 'a']
    assert choice(['a', 'b', 'c'], 2, True) == ['b', 'c']
    assert choice(('a', 'b', 'c')) == 'c'
    assert choice(('a', 'b', 'c'), 3) == ('a', 'b', 'b')
    assert choice(('a', 'b', 'c'), 3, True) == ('a', 'b', 'c')

# Generated at 2022-06-23 21:15:34.287340
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis.enums import Gender
    c = Choice('en', gender=Gender.FEMALE)
    result = c.choice.__call__(['a','b','c'])
    print(result)
    result = c.choice.__call__(items=['a','b','c'], length=3)
    print(result)

if __name__ == '__main__':
    test_Choice()

# Generated at 2022-06-23 21:15:35.708991
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice()

# Generated at 2022-06-23 21:15:37.215068
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice is not None


# Generated at 2022-06-23 21:15:47.755913
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ab', 'bc', 'ca']

# Generated at 2022-06-23 21:15:53.569012
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice.choice(items=['a', 'b', 'c']) == 'c'
    assert choice.choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice.choice(items='abc', length=2) == 'ba'
    assert choice.choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice.choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'




# Generated at 2022-06-23 21:15:57.284251
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items=('a', 'b', 'c'), length=2) == ('c', 'a')


# Generated at 2022-06-23 21:16:01.927186
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()

    assert choice(items=['a', 'b', 'c'])
    assert choice(items=['a', 'b', 'c'], length=1)
    assert choice(items='abc', length=2)
    assert choice(items=('a', 'b', 'c'), length=5)
    assert choice(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-23 21:16:10.212746
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    expected = [choice(items=['a', 'b', 'c'], length=2) for _ in range(10)]
    actual = ['ab', 'cb', 'ab', 'cb', 'ab', 'cb', 'ab', 'cb', 'ab', 'cb']
    assert expected == actual
    expected = [choice(items=('a', 'b', 'c'), length=2, unique=True) for _ in range(10)]
    actual = ['ca', 'ca', 'ca', 'ca', 'ca', 'ca', 'ca', 'ca', 'ca', 'ca']
    assert expected == actual



# Generated at 2022-06-23 21:16:10.821519
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-23 21:16:12.972005
# Unit test for constructor of class Choice
def test_Choice():
    meta = getattr(Choice, "Meta", None)
    assert meta is not None and getattr(meta, "name") == "choice"



# Generated at 2022-06-23 21:16:18.142495
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = ('a', 'b', 'c')
    length = 5
    assert choice(items=items, length=length) == ('c', 'b', 'a', 'a', 'b')
    assert choice(items=items, length=length, unique=True) == ('a', 'b', 'c', 'b', 'a')
    assert choice(items='abc', length=length) == 'acbac'
    assert choice(items='abc', length=length, unique=True) == 'cba'

# Generated at 2022-06-23 21:16:21.410889
# Unit test for constructor of class Choice
def test_Choice():
    controller = Choice()
    assert controller.seed == 42
    assert controller.random
    assert isinstance(controller.random, controller.Random)


# Generated at 2022-06-23 21:16:31.245421
# Unit test for method __call__ of class Choice
def test_Choice___call__(): # TODO: Add test case for unique elements
    """
    Test method Choice.__call__.
    """
    from mimesis.utils import create_seed

    class Test:
        """Class for testing."""

        choice = Choice(seed=create_seed())

    # without seed
    assert Test.choice() != Test.choice()

    # length and items
    assert Test.choice(['a', 'b', 'c', 'd'], length=2) != Test.choice(['a', 'b', 'c', 'd'], length=2)
    assert Test.choice(('a', 'b', 'c', 'd'), length=2) != Test.choice(('a', 'b', 'c', 'd'), length=2)

    # items
    assert Test.choice(('a', 'b', 'c', 'd'))

# Generated at 2022-06-23 21:16:31.785141
# Unit test for constructor of class Choice
def test_Choice():
    Choice()

# Generated at 2022-06-23 21:16:39.140233
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Testing Choice.__call__."""
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

    # test for TypeError
    try:
        choice(items='abc', length='hello')
        raise AssertionError('You cannot pass a non-integer `length`.')
    except TypeError:
        pass

    #

# Generated at 2022-06-23 21:16:39.865170
# Unit test for constructor of class Choice
def test_Choice():
	choice = Choice()

# Generated at 2022-06-23 21:16:49.121731
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-23 21:16:58.434114
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from hypothesis import given, settings
    from hypothesis.strategies import integers, lists, text
    from mimesis import Choice
    from mimesis.exceptions import NonEnumerableError
    from mimesis.typing import Enumerable
    from mimesis.utils import get_all_attributes
    from mimesis.enums import DatetimeUnit
    from mimesis.data import (
        ANIMALS,
        CURRENCIES,
        FILE_EXTENSIONS,
        GEO_NAMES,
        LANGUAGES,
        MIME_TYPES,
        MONTH_NAMES,
        OPERATORS,
        PROFESSIONS,
        PROTOCOLS,
        TLDs,
        WEEKDAY_NAMES,
    )

    choice = Choice()

# Generated at 2022-06-23 21:17:00.426093
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'


# Generated at 2022-06-23 21:17:07.505168
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    Choice().__call__(items=['a', 'b', 'c'])
    Choice().__call__(items=['a', 'b', 'c'], length=1)
    Choice().__call__(items='abc', length=2)
    Choice().__call__(items=('a', 'b', 'c'), length=5)
    Choice().__call__(items='aabbbccccddddd', length=4, unique=True)

    try:
        Choice().__call__(items=True, length='abc')
        print("FAILED: test_Choice___call__")
    except TypeError as e:
        print("SUCCESS: test_Choice___call__")
    except Exception as e:
        print("FAILED: test_Choice___call__")

# Generated at 2022-06-23 21:17:14.251262
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Check for input of non-empty sequence
    data = ('a', 'b', 'c')

# Generated at 2022-06-23 21:17:19.600375
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    import random
    import string
    import unittest

    # Initialize seed
    random.seed()

    class TestChoice(unittest.TestCase):
        """Class for testing `Choice`."""

        def test_choice__call__(self):
            """Test for `Choice.__call__`."""

            # Test with a string
            items = random.choices(string.ascii_letters, k=40)
            items = ''.join(items)
            length = random.randint(0, len(items))
            unique = False
            choice_obj = Choice(seed=42)
            result = choice_obj(items=items, length=length, unique=unique)
            self.assertIsInstance(result, str)
            self.assertEqual(len(result), length)

# Generated at 2022-06-23 21:17:27.753236
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    #from mimesis import Choice
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:17:35.680497
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    print(Choice().__call__(['a', 'b', 'c']))
    print(Choice().__call__(['a', 'b', 'c'], length=1))
    print(Choice().__call__('abc', length=2))
    print(Choice().__call__(('a', 'b', 'c'), length=5))
    print(Choice().__call__('aabbbccccddddd', length=4, unique=True))

    # TODO: test ValueError, TypeError, KeyError

test_Choice___call__()

# Generated at 2022-06-23 21:17:43.427141
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'



# Generated at 2022-06-23 21:17:44.832590
# Unit test for constructor of class Choice
def test_Choice():
    d = Choice()
    assert Choice.Meta.name == 'choice'


# Generated at 2022-06-23 21:17:46.608244
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) != 'c'


# Generated at 2022-06-23 21:17:50.782862
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test Choice.__call__."""
    import pytest

    from mimesis.exceptions import NonEnumerableError
    from mimesis.typing import Enumerable

    choice = Choice()
    with pytest.raises(NonEnumerableError):
        choice(items=1, length=1)


# Generated at 2022-06-23 21:17:52.044961
# Unit test for constructor of class Choice
def test_Choice():
    import pytest
    c = Choice()
    assert isinstance(c, Choice) == True


# Generated at 2022-06-23 21:17:54.053536
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)


# Generated at 2022-06-23 21:17:55.956651
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TODO: Write tests for method __call__ of class Choice
    assert True

# Generated at 2022-06-23 21:18:05.047827
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for __call__ method."""
    obj = Choice()
    assert obj(items=('a', 'b', 'c'), length=1) in (['a'], ('a',))
    assert len(obj(items=('a', 'b', 'c'), length=2)) == 2
    assert len(obj(items=(), length=2)) == 0
    try:
        obj(items=(), length=2)
    except ValueError as e:
        print(e)
    try:
        obj(items='abc', length=0.5)
    except TypeError as e:
        print(e)
    try:
        obj(items=2, length=1)
    except TypeError as e:
        print(e)

# Generated at 2022-06-23 21:18:13.322898
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Test string
    items = "abc"
    length = 1
    unique = False
    assert Choice().__call__(items=items, length=length, unique=unique) == 'c'

    # Test list
    items = [1, 2, 3]
    length = 2
    unique = True
    assert Choice().__call__(items=items, length=length, unique=unique) == [2, 1]

    # Test tuple
    items = (1.1, 2.0, 3.4)
    length = 3
    unique = True
    assert Choice().__call__(items=items, length=length, unique=unique) == (3.4, 2.0, 1.1)

    # Test set
    items = {1, 2, 3, 4}
    length = 0
    unique = False

# Generated at 2022-06-23 21:18:14.600624
# Unit test for constructor of class Choice
def test_Choice():
    provider = Choice()
    assert isinstance(provider, Choice)


# Generated at 2022-06-23 21:18:25.927892
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

    try:
        choice(items=('a', 'b', 'c'), length='a')
    except Exception as e:
        assert str(e) == '**length** must be integer.'
        assert True

# Generated at 2022-06-23 21:18:36.031910
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    # unit tests for method __call__ of class Choice
    # if selections is None:
    #		return random.choice()

    selection = choice(items=['a', 'b', 'c', 'd', 'e'])
    assert selection in ['a', 'b', 'c', 'd', 'e']

    selection = choice(items=['a', 'b', 'c', 'd', 'e'])
    assert selection in ['a', 'b', 'c', 'd', 'e']

    selection = choice(items=['a', 'b', 'c', 'd', 'e'])
    assert selection in ['a', 'b', 'c', 'd', 'e']

    selection = choice(items=['a', 'b', 'c', 'd', 'e'])

# Generated at 2022-06-23 21:18:42.957903
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    assert callable(Choice)

    choice = Choice()

    docex_items = ['a', 'b', 'c']
    docex_length = 1
    docex_unique = False
    choice_fixture = choice(items=docex_items, length=docex_length,
                            unique=docex_unique)
    assert choice_fixture in docex_items

    docex_items = ['a', 'b', 'c']
    docex_length = 1
    docex_unique = False
    choice_fixture = choice(items=docex_items, length=docex_length,
                            unique=docex_unique)
    assert choice_fixture in docex_items
    assert isinstance(choice_fixture, list)

    docex

# Generated at 2022-06-23 21:18:47.712239
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    mock_int = 3
    mock_bool = False
    choice = Choice()
    assert choice(items=['a', 'b', 'c'], length=mock_int, unique=mock_bool) ==\
        ['a', 'c', 'c']

# Generated at 2022-06-23 21:18:55.791484
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice()(items=['a', 'b', 'c']) == 'c'
    assert Choice()(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice()(items='abc', length=2) == 'ba'
    assert Choice()(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice()(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-23 21:18:56.306590
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-23 21:18:57.446146
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis.builtins import Choice
    assert Choice()


# Generated at 2022-06-23 21:18:59.815439
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)