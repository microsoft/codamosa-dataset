

# Generated at 2022-06-23 21:08:59.926006
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    if not callable(Choice(None, None).__call__):
        raise AssertionError


# Generated at 2022-06-23 21:09:01.925026
# Unit test for constructor of class Choice
def test_Choice():
    ch = Choice()
    assert ch is not None and isinstance(ch, Choice)

# Generated at 2022-06-23 21:09:10.069024
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice.choice(['a', 'b', 'c']) == 'c'
    assert choice.choice(['a', 'b', 'c'], length=1) == ['a']
    assert choice.choice('abc', length=2) == 'ba'
    assert choice.choice(('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice.choice('aabbbccccddddd', length=4, unique=True) == 'cdba'

    try:
        assert choice.choice([])
    except ValueError as e:
        assert str(e) == '**items** must be a non-empty sequence.'
    else:
        assert False, 'ValueError has not been raised'


# Generated at 2022-06-23 21:09:14.924875
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method _call__ of class Choice.

    This test tests the output for a range of different input values that
    should produce various different outputs.
    """

    from mimesis import Choice
    choice = Choice()

    from mimesis.enums import Languages
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.exceptions import NonEnumerableError

    # Test method calling

# Generated at 2022-06-23 21:09:20.613838
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    a = choice(['a', 'b', 'c'])
    assert type(a) is str
    a = choice(['a', 'b', 'c'], length=1)
    assert type(a) is list
    a = choice(['a', 'b', 'c'], length=2)
    assert type(a) is list
    a = choice(['a', 'b', 'c'], length=3)
    assert type(a) is list
    a = choice('abc', length=2)
    assert type(a) is str

# Generated at 2022-06-23 21:09:28.045984
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    '''
    Test method Choice.__call__().
    '''
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) in ['ab', 'ac', 'bc']

# Generated at 2022-06-23 21:09:35.526949
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:09:36.730541
# Unit test for constructor of class Choice
def test_Choice():
    print('Testing Choice... ', end='')
    choice = Choice()
    assert choice.__class__.__name__ == 'Choice'


# Generated at 2022-06-23 21:09:37.386258
# Unit test for constructor of class Choice
def test_Choice():
    Choice()


# Generated at 2022-06-23 21:09:43.923710
# Unit test for constructor of class Choice
def test_Choice():
    """Unit test for constructor of class Choice.

        >>> from mimesis import Choice
        >>> choice = Choice()
        >>> choice(items=['a', 'b', 'c'])
        'a'
        >>> choice(items=['a', 'b', 'c'], length=1)
        ['c']
        >>> choice(items='abc', length=2)
        'cc'
        >>> choice(items=('a', 'b', 'c'), length=5)
        ('b', 'a', 'a', 'b', 'a')
        >>> choice(items='aabbbccccddddd', length=4, unique=True)
        'adcb'
    """
    pass


# Generated at 2022-06-23 21:09:54.599844
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) in ['ab', 'ac', 'bc']
    assert choice(items=('a', 'b', 'c'), length=5) in \
        [('a', 'b', 'c', 'a', 'b'), ('a', 'b', 'c', 'a', 'c'), ('a', 'b', 'c', 'b', 'c')]

# Generated at 2022-06-23 21:10:02.467220
# Unit test for constructor of class Choice
def test_Choice():
    """Test case for the function Choice."""
    choice = Choice()
    assert choice.random.randrange(0, 100) in range(101)
#
#   assert choice.random.randrange(0, 100) in range(1, 101)
#
#   items = ['a', 'b', 'c']
#   assert choice(items) in items
#   assert choice(items, length=0) in items
#   assert choice(items=items, length=1) in (['a'], ['b'], ['c'])
#   assert choice(items=items, length=2) in (['a', 'b'], ['b', 'c'],
#                                            ['c', 'a'])
#   assert choice(items=items, length=3) in (['a', 'b', 'c'],
#                                

# Generated at 2022-06-23 21:10:12.865169
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice

    choice = Choice()

    assert choice(items=['a', 'b', 'c']) in ('a', 'b', 'c')
    assert choice(items=('a', 'b', 'c'), length=1) in (('a',), ('b',), ('c',))
    assert choice(items='abc', length=2) in ('ab', 'ac', 'ba', 'bc', 'ca', 'cb')

# Generated at 2022-06-23 21:10:14.020249
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice is not None
    assert isinstance(choice, Choice)

# Generated at 2022-06-23 21:10:16.781936
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    # Arrange
    import random 

    from mimesis.builtins import Choice

    # Act
    random.seed(0)
    choice = Choice()
    result = choice(items=['a', 'b', 'c'], length=1)

    # Assert
    assert result == ['c']


# Generated at 2022-06-23 21:10:28.055978
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice

    choice = Choice()

    def __call___1():
        choice(items=['a', 'b', 'c'])

    def __call___2():
        choice(items=['a', 'b', 'c'], length=1)

    def __call___3():
        choice(items='abc', length=2)

    def __call___4():
        choice(items=('a', 'b', 'c'), length=5)

    def __call___5():
        choice(items='aabbbccccddddd', length=4, unique=True)

    def __call___6():
        choice(items=1, length=3, unique=True)

    def __call___7():
        choice(items=(), length=3, unique=True)

   

# Generated at 2022-06-23 21:10:34.781138
# Unit test for constructor of class Choice
def test_Choice():
    A = Choice()
    A(items=['a', 'b', 'c'], length=1)
    A(items='abc', length=2)
    A(items=('a', 'b', 'c'), length=1)
    A(items=['a', 'b', 'c'], length=2)
    # A(items=['a', 'b', 'c'], length=5)
    # A(items=['a', 'b', 'c'], length=0)



# Generated at 2022-06-23 21:10:35.654931
# Unit test for constructor of class Choice
def test_Choice():
    provider = Choice()


# Generated at 2022-06-23 21:10:45.255496
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import pytest
    from mimesis import Choice
    choice = Choice()
    assert choice(items=[], length=2) == []
    assert choice(items=[''], length=2) == ['']
    assert choice(items=[1], length=10) == [1]
    assert choice(items=[1], length=0) == 1
    assert choice(items=[1]) == 1
    assert choice(items='', length=2) == ''
    assert choice(items='', length=0) == ''
    assert choice(items='1', length=2) == '11'
    assert choice(items='1', length=0) == '1'
    assert choice(items='1') == '1'
    assert choice(items=(), length=0) == ()
    assert choice(items=(), length=2) == ()
    assert choice

# Generated at 2022-06-23 21:10:47.689824
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice('ru')
    c(['q', 'w', 'e'], 2)

# Generated at 2022-06-23 21:10:55.542530
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    item = Choice()
    assert item(items=['a', 'b', 'c'],length=1) == ['c']
    assert item(items=['a', 'b', 'c']) == 'c'
    assert item(items=['a', 'b', 'c'], length=2) == ['b', 'c']
    assert item(items='abc', length=1) == 'b'
    assert item(items=('a', 'b', 'c'), length=1) == ('c',)
    assert item(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    try:
        item(items=['a', 'b', 'c'], length=-1)
    except ValueError:
        assert 1

# Generated at 2022-06-23 21:11:06.863230
# Unit test for constructor of class Choice
def test_Choice():
    """
    Unit test for constructor of class Choice
    """
    choice = Choice()

    random_item1 = choice(items=['a', 'b', 'c'])
    random_item2 = choice(items=['a', 'b', 'c'], length=1)
    random_item3 = choice(items='abc', length=2)
    random_item4 = choice(items=('a', 'b', 'c'), length=5)
    random_item5 = choice(items='aabbbccccddddd', length=4, unique=True)
    print("Item1: ", random_item1)
    print("Item2: ", random_item2)
    print("Item3: ", random_item3)
    print("Item4: ", random_item4)

# Generated at 2022-06-23 21:11:08.423166
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-23 21:11:14.522465
# Unit test for constructor of class Choice
def test_Choice():
    objects = ['a', 'b', 'c', 'd', 'e']
    choice_ = Choice()
    assert choice_(objects) in objects
    assert choice_(objects, length=1) in objects
    assert choice_(objects, length=2) in objects
    assert choice_(objects, length=3) in objects
    assert choice_(objects, length=4) in objects
    assert choice_(objects, length=5) in objects
    assert choice_(objects, unique=True, length=5) in objects

# Generated at 2022-06-23 21:11:16.229191
# Unit test for constructor of class Choice
def test_Choice():
    test = Choice()
    choice = Choice()
    assert choice.choice(items=['a', 'b', 'c'])

# Generated at 2022-06-23 21:11:16.971743
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-23 21:11:21.309006
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert c.choice(1) == 1
    assert c.choice([1, 2, 3, 4]) == 1
    assert c.choice(1, unique=True) == 1
    assert c.choice([1, 2, 3, 4], unique=True) == 1

# Generated at 2022-06-23 21:11:26.656354
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    from mimesis import Choice
    choice = Choice()
    print(choice(items=['a', 'b', 'c']))
    print(choice(items=['a', 'b', 'c'], length=1))
    print(choice(items='abc', length=2))
    print(choice(items=('a', 'b', 'c'), length=5))
    print(choice(items='aabbbccccddddd', length=4, unique=True))

# Generated at 2022-06-23 21:11:27.262390
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-23 21:11:27.855439
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice()
    assert Choice().__version__

# Generated at 2022-06-23 21:11:31.877444
# Unit test for constructor of class Choice
def test_Choice():
    """Unit test for the constructor of the class Choice."""
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) != None
    assert choice(items=['a', 'b', 'c'], length=1) != None
    assert choice(items='abc', length=2) != None
    assert choice(items=('a', 'b', 'c'), length=5) != None
    assert choice(items='aabbbccccddddd', length=4, unique=True) != None
    assert choice(items='aabbbccccddddd', length=4, unique=True) != None
    assert choice(items=[]) == None

# Generated at 2022-06-23 21:11:40.919258
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Initialize a test instance of class Choice
    choice = Choice()

    # Test the __call__ method
    
    # Test 1
    items = ['a', 'b', 'c']
    assert choice(items=items) == 'c'

    # Test 2
    items = ['a', 'b', 'c']
    length = 1
    assert choice(items=items, length=length) == ['a']

    # Test 3
    items = 'abc'
    length = 2
    assert choice(items=items, length=length) == 'ba'

    # Test 4
    items = ('a', 'b', 'c')
    length = 5
    assert choice(items=items, length=length) == ('c', 'a', 'a', 'b', 'c')

    # Test 5

# Generated at 2022-06-23 21:11:51.814732
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for __call__ method."""
    from mimesis.exceptions import NonDataProvidedError
    from mimesis.enums import Gender
    from mimesis.builtins import RussiaSpecProvider
    russia = RussiaSpecProvider(datetime=True)
    russia.seed(42)

    def test_items(items: Sequence[Any], length: int, unique: bool):
        """Common test method."""
        choice = Choice(datetime=True)
        choice.seed(42)

        choise_list = choice(items=items, length=length, unique=unique)
        assert (isinstance(choise_list, list)) is True
        assert (isinstance(choise_list, tuple)) is False
        assert (isinstance(choise_list, str)) is False


# Generated at 2022-06-23 21:11:59.011332
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test functionality of __call__ method of class Choice.

    Call Choice, which generates a random choice from a sequence of items,
    with a length of:

    - 0
    - 1
    - 2
    - 5

    Test with both lists and tuples of items. Test that elements are unique.
    Test that value error is raised when length is negative.
    Test that type error is raised when non-sequence item is provided.
    Test that type error is raised when non-integer length is provided.
    Test that value error is raised when there are not enough unique elements
    to provide specified number.
    """

    # Test with length 0
    from mimesis import Choice
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']

# Generated at 2022-06-23 21:12:02.687287
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    d = c(items=['a', 'b', 'c'])
    e = c(items=['a', 'b', 'c'], length=1)
    f = c(items='abc', length=2)
    g = c(items=('a', 'b', 'c'), length=5)
    h = c(items='aabbbccccddddd', length=4, unique=True)
    print(d, e, f, g, h)


if __name__ == '__main__':
    test_Choice()

# Generated at 2022-06-23 21:12:05.089635
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert isinstance(c, Choice)

# Generated at 2022-06-23 21:12:06.923086
# Unit test for constructor of class Choice
def test_Choice():
    obj = Choice()
    obj(items=['a', 'b', 'c'], length=0)

# Generated at 2022-06-23 21:12:12.464454
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    choice(items=['a', 'b', 'c'])
    choice(items=['a', 'b', 'c'], length=1)
    choice(items='abc', length=2)
    choice(items=('a', 'b', 'c'), length=5)
    choice(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-23 21:12:14.205361
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert isinstance(c, Choice) and isinstance(c, BaseProvider)

# Generated at 2022-06-23 21:12:14.734659
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass


# Generated at 2022-06-23 21:12:15.731179
# Unit test for constructor of class Choice
def test_Choice():
    pass

# Generated at 2022-06-23 21:12:17.179713
# Unit test for constructor of class Choice
def test_Choice():
    """Function test_Choice()
    """

    c = Choice()
    assert c

# Unit tests for functions

# Generated at 2022-06-23 21:12:19.245225
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass
if __name__ == '__main__':
    # Unit test for method __call__ of class Choice
    test_Choice___call__()

# Generated at 2022-06-23 21:12:29.892109
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) in ['a','b','c']
    assert Choice().__call__(items=['a', 'b', 'c'], length= 1) in [['a'],['b'],['c']]
    assert Choice().__call__(items='abc', length= 2) in ['ab','ac','bc']

# Generated at 2022-06-23 21:12:40.595039
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    class Choice_:
        class Meta:
            name = 'choice'

        def __init__(self, *args, **kwargs) -> None:
            pass
        def __call__(self, items: Optional[Sequence[Any]], length: int = 0,
                     unique: bool = False) -> Union[Sequence[Any], Any]:
            if not isinstance(length, int):
                raise TypeError('**length** must be integer.')
            if not isinstance(items, collections.abc.Sequence):
                raise TypeError('**items** must be non-empty sequence.')
            if not items:
                raise ValueError('**items** must be a non-empty sequence.')
            if length < 0:
                raise ValueError('**length** should be a positive integer.')

# Generated at 2022-06-23 21:12:49.135388
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice.__call__(Choice, items=['a', 'b', 'c']) == 'c'
    assert Choice.__call__(Choice, items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice.__call__(Choice, items='abc', length=2) == 'ba'
    assert Choice.__call__(Choice, items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice.__call__(Choice, items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:12:57.229783
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    # choice(items=['a', 'b', 'c'])
    assert isinstance(choice(items=['a', 'b', 'c']), str)
    # choice(items=['a', 'b', 'c'], length=1)
    assert isinstance(choice(items=['a', 'b', 'c'], length=1), list)
    # choice(items='abc', length=2)
    assert isinstance(choice(items='abc', length=2), str)
    # choice(items=('a', 'b', 'c'), length=5)
    assert isinstance(choice(items=('a', 'b', 'c'), length=5), tuple)
    # choice(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-23 21:12:58.684716
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)


# Generated at 2022-06-23 21:13:04.527995
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice.
    """
    items_in: list = ['a', 'b', 'c']
    length_in: int = 2
    unique_in: bool = False
    choice: Choice = Choice()
    data_out: str = choice(items_in, length_in, unique_in)
    assert data_out == 'ac'

# Generated at 2022-06-23 21:13:06.826913
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert c is not None


# Generated at 2022-06-23 21:13:08.151785
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert callable(Choice.__call__)


# Generated at 2022-06-23 21:13:17.243580
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ab', 'ac', 'ba', 'bc', 'ca', 'cb']

# Generated at 2022-06-23 21:13:21.122969
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    choice(items=['a', 'b', 'c'])
    choice(items=['a', 'b', 'c'], length=1)
    choice(items='abc', length=2)
    choice(items=('a', 'b', 'c'), length=5)
    choice(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-23 21:13:28.792722
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert c(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert c(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert c(items='abc', length=2) in ['ab', 'bc', 'ac']
    assert c(items=('a', 'b', 'c'), length=5) in [('a', 'a', 'a', 'a', 'a'),
                                                  ('b', 'b', 'b', 'b', 'b'),
                                                  ('c', 'c', 'c', 'c', 'c')]

# Generated at 2022-06-23 21:13:30.137510
# Unit test for constructor of class Choice
def test_Choice():
    e = Choice()
    assert e is not None

# Generated at 2022-06-23 21:13:39.779523
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    c = Choice()

    assert c(items=['a', 'b', 'c']) in {'a', 'b', 'c'}

    assert c(items=('a', 'b', 'c'), length=1) in {('a',), ('b',), ('c',)}
    assert len(c(items=('a', 'b', 'c'), length=1)) == 1

    assert c(items='abc', length=2) in {'ab', 'ba', 'ac', 'ca', 'bc', 'cb'}
    assert len(c(items='abc', length=2)) == 2


# Generated at 2022-06-23 21:13:41.095689
# Unit test for constructor of class Choice
def test_Choice():  # noqa: D103
    c = Choice()
    pass

# Generated at 2022-06-23 21:13:42.430072
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    pass

# Generated at 2022-06-23 21:13:51.675079
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ab', 'ba', 'ac', 'ca', 'bc', 'cb']

# Generated at 2022-06-23 21:13:59.530541
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    from mimesis.enums import Gender
    from mimesis.typing import GenderField

    locale = 'cs'
    choice = Choice(localizer=locale)

    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items='abc', length=3) in ['abc', 'bca', 'cab']

    unique = choice(items='abcabcabc', length=9, unique=True)
    assert len(set(unique)) == 3
    assert len(unique) == 9

    gender: GenderField = choice(items=[Gender.MALE, Gender.FEMALE])
    assert gender in [Gender.MALE, Gender.FEMALE]

# Generated at 2022-06-23 21:14:09.396924
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert isinstance(c(items=['a', 'b', 'c']), str)
    assert isinstance(c(items=['a', 'b', 'c'], length=2), list)
    assert isinstance(c(items='abc', length=2), str)
    assert isinstance(c(items=('a', 'b', 'c'), length=5), tuple)
    assert isinstance(c(items='aabbbccccddddd', length=4, unique=True), str)

    assert isinstance(c(items=['a', 'b', 'c'], length=1), list)

    assert c(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert c(items=['a', 'b', 'c'], length=2)

# Generated at 2022-06-23 21:14:19.832753
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) in ['ba', 'ab', 'cb']

# Generated at 2022-06-23 21:14:27.525728
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a']]
    assert choice(items='abc', length=2) in ['ba']
    assert choice(items=('a', 'b', 'c'), length=5) in [('c', 'a', 'a', 'b', 'c')]
    assert choice(items='aabbbccccddddd', length=4, unique=True) in ['cdba']


# Generated at 2022-06-23 21:14:32.748072
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    res = choice(items=['a', 'b', 'c'])
    assert res in ['a','b','c']
    res = choice(items=['a', 'b', 'c'], length=1)
    assert res in [['a'],['b'],['c']]
    # TODO: Provide test for unique elements

# Generated at 2022-06-23 21:14:33.421601
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-23 21:14:35.081661
# Unit test for constructor of class Choice
def test_Choice():
    "Test class constructor"
    data = ('a', 'b', 'c')
    choice = Choice(data)
    assert choice(data) in data



# Generated at 2022-06-23 21:14:45.620436
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    result = choice(items=['a', 'b', 'c'])
    assert result in ['a', 'b', 'c']
    result = choice(items=['a', 'b', 'c'], length=1)
    assert result in [['a'], ['b'], ['c']]
    result = choice(items='abc', length=2)
    assert result in ['ba', 'ab', 'cb']
    result = choice(items=('a', 'b', 'c'), length=5)
    assert result in [('a', 'b', 'c', 'a', 'b'), ('a', 'c', 'a', 'a', 'b'), ('a', 'b', 'c', 'c', 'b')]

# Generated at 2022-06-23 21:14:54.996142
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from random import Random
    seed = 0
    choice = Choice(random=Random(seed))
    # test_neg_length
    try:
        choice(['a', 'b', 'c'], length=-1)
        assert False
    except ValueError as e:
        assert str(e) == '**length** should be a positive integer.'

    # test_non_seq_items
    try:
        choice(None, length=0)
        assert False
    except TypeError as e:
        assert str(e) == '**items** must be non-empty sequence.'

    # test_non_integer_length
    try:
        choice(['a', 'b', 'c'], length=None)
        assert False
    except TypeError as e:
        assert str(e) == '**length** must be integer.'

   

# Generated at 2022-06-23 21:14:56.047894
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice is not None

# Generated at 2022-06-23 21:15:06.741145
# Unit test for constructor of class Choice
def test_Choice():
    # Initialize the class
    choice = Choice()
    # Test the method `__call__`
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert (choice(items=['a', 'b', 'c'], length=1) in
            [['a'], ['b'], ['c']])
    assert choice(items='abc', length=2) in ['ab', 'ac', 'bc']

# Generated at 2022-06-23 21:15:07.488245
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice() is not None

# Generated at 2022-06-23 21:15:09.827706
# Unit test for constructor of class Choice
def test_Choice():
    """Unit test for constructor of class Choice

    The constructor should create a Choice object

    >>> from mimesis import Choice
    >>> choice = Choice()
    >>> choice
    <mimesis.providers.choice.choice.Choice object at 0x7f49f1a7e210>
    """


# Generated at 2022-06-23 21:15:12.309116
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice().__class__.__name__ == 'Choice'

# Generated at 2022-06-23 21:15:19.138231
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    items = [Gender.FEMALE.value, Gender.MALE.value]
    length = 3
    unique = False

    choice = Choice()
    result = choice(items=items, length=length, unique=unique)
    print(result)
    assert len(result) == length
    assert isinstance(result, list)

    items2 = ('car', 'plane', 'boat')
    length2 = 5
    unique2 = True

    choice2 = Choice()
    result2 = choice2(items=items2, length=length2, unique=unique2)
    print(result2)
    assert len(result2) == length2
    assert isinstance(result2, tuple)
    assert len(set(result2)) == len

# Generated at 2022-06-23 21:15:20.042181
# Unit test for constructor of class Choice
def test_Choice():
    pass


# Generated at 2022-06-23 21:15:26.335931
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis import Choice
    choice = Choice()
    choice(items=['a', 'b', 'c'], length=1)
    choice(items=['a', 'b', 'c'])
    choice(items='abc', length=2)
    choice(items=('a', 'b', 'c'), length=5)
    choice(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-23 21:15:33.606800
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method __call__ of Choice"""
    choice = Choice()
    items_values = ['a', 'b', 'c']
    length_values = [0, 1, 2]
    unique_values = [True, False]
    for items, length, unique in ((items, length, unique)
                                  for items in items_values
                                  for length in length_values
                                  for unique in unique_values):
        result = choice(items=items, length=length, unique=unique)
        assert isinstance(result, (list, tuple, str))
        if isinstance(result, list):
            assert len(result) == length
            for item in result:
                assert item in items
        elif isinstance(result, tuple):
            assert len(result) == length
            for item in result:
                assert item in items
       

# Generated at 2022-06-23 21:15:38.197048
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert c(['a', 'b', 'c']), 'Should return a random choice from the list'
    assert c(['a', 'b', 'c'], 1), 'Should return a random choice from the list'

# Generated at 2022-06-23 21:15:40.187689
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    pass


# Generated at 2022-06-23 21:15:49.602880
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Tests method __call__ of class Choice"""
    import doctest
    doctest.testmod(verbose=True)
    print()
    print('-'*10, 'Unit Tests', '-'*10)
    print('Test 1: random.choice for a list')
    print(Choice().__call__(items=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'], length=1))
    print('Test 2: random.choice for a list')

# Generated at 2022-06-23 21:15:55.105685
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    # Setup
    choice = Choice()

    # Exercise
    result = choice(items=['a', 'b', 'c'])

    # Verify
    assert result in ['a', 'b', 'c']
    assert isinstance(result, str)

    # Cleanup - None



# Generated at 2022-06-23 21:15:57.165861
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = [1, 2, 3]
    length = 2
    choice = Choice()
    result = choice(items=items, length=length)
    assert isinstance(result, list)
    assert len(result) == length
    assert all(elem in item for elem in result)

# Generated at 2022-06-23 21:16:07.266789
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import unittest
    from mimesis.exceptions import NonEnumerableError
    from mimesis.typing import Seed

    class ChoiceTestCase(unittest.TestCase):

        def setUp(self) -> None:
            self.choice = Choice()

        def test_negative_number(self):
            with self.assertRaises(ValueError) as cm:
                self.choice(items='abc', length=-1)

            self.assertIn('positive', str(cm.exception))

        def test_with_unique_values(self):
            items = self.choice(items='aabbccddee', length=10, unique=True)
            self.assertTrue(isinstance(items, str))
            self.assertEqual(len(items), 10)

# Generated at 2022-06-23 21:16:09.493270
# Unit test for constructor of class Choice
def test_Choice():
    """Test Choice.__init__()."""
    c = Choice()
    assert c
    assert c.random


# Generated at 2022-06-23 21:16:11.012105
# Unit test for constructor of class Choice
def test_Choice():
    obj = Choice()
    assert obj is not None


# Generated at 2022-06-23 21:16:14.153918
# Unit test for constructor of class Choice
def test_Choice():
    obj = Choice()
    assert isinstance(obj, Choice) is True
    assert obj.seed is None
    assert obj.random is not None
    assert obj.datetime is not None
    assert obj.language is not None


# Generated at 2022-06-23 21:16:20.082567
# Unit test for method __call__ of class Choice

# Generated at 2022-06-23 21:16:22.176179
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert(c.__doc__ is not None)



# Generated at 2022-06-23 21:16:31.861120
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender
    from mimesis.providers import BaseDataProvider, Provider
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.misc import Choice
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.person import Person

    class MyProvider(Provider):
        choice = Choice()
        person = Person('en')
        numbers = Numbers()
        datetime = Datetime('en')

        def my_method(self):
            return self.choice(['a', 'b', 'c'])

    class MyDataProvider(BaseDataProvider):
        _data = {
            'genders': {
                'male': [Gender.MALE],
                'female': [Gender.FEMALE]
            }
        }

   

# Generated at 2022-06-23 21:16:33.477276
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method __call__ of class Choice."""

    # TODO: write test
    pass


# Generated at 2022-06-23 21:16:34.943669
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis import Choice
    ch = Choice()
    ar = ch(items=['a', 'b', 'c'])
    assert isinstance(ar, str)
    assert ar in ('a', 'b', 'c')


# Generated at 2022-06-23 21:16:43.514459
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert c(['a', 'b', 'c']) == 'c'
    assert c(['a', 'b', 'c'], length=1) == ['a']
    assert c('abc', length=2) == 'ba'
    assert c(('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert c('aabbbccccddddd', length=4, unique=True) == 'cdba'

    # test that we don't get an infinite loop with only 1 unique item in the set
    with pytest.raises(ValueError):
        c.__call__('a', 10, True)

    # test that we don't get an infinite loop with 0 elements
    with pytest.raises(ValueError):
        c

# Generated at 2022-06-23 21:16:45.107599
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass


# Generated at 2022-06-23 21:16:51.406976
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert c(['a','b','c']) == 'c'
    assert c(['a','b','c'],length=1) == ['a']
    assert c('abc',length=2) == 'ba'
    assert c(('a','b','c'),length=5) == ('c','a','a','b','c')
    assert c('aabbbccccddddd',length=4,unique=True) == 'cdba'


# Generated at 2022-06-23 21:16:53.625684
# Unit test for constructor of class Choice
def test_Choice():
    a = Choice()
    b = eval(repr(a))
    assert a == b

# Generated at 2022-06-23 21:16:55.529691
# Unit test for constructor of class Choice
def test_Choice():
    provider = Choice()
    assert str(type(provider)) == "<class 'mimesis.providers.misc.Choice'>"

# Generated at 2022-06-23 21:16:56.688177
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert isinstance(c, Choice)

# Generated at 2022-06-23 21:17:04.373909
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import unittest

    import pytest
    from mimesis.exceptions import NonEnumerableError

    class ChoiceTestCase(unittest.TestCase):

        def setUp(self):
            self.choice = Choice('en')

        def test_non_empty_sequence(self):
            data = ['a', 'b', 'c']
            result = self.choice(items=data)
            self.assertIn(result, data)

        def test_non_empty_sequence_with_length(self):
            data = ['a', 'b', 'c']
            result = self.choice(items=data, length=1)
            self.assertIn(result[0], data)

        def test_non_empty_sequence_with_1_length(self):
            data = ['a', 'b', 'c']
            result

# Generated at 2022-06-23 21:17:06.465376
# Unit test for constructor of class Choice
def test_Choice():
    """Unit test for constructor of class Choice."""
    choice = Choice()

    assert choice.random is not None

# Generated at 2022-06-23 21:17:17.719128
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    class Test:
        """Class for testing."""

        def __init__(self):
            self.choice = Choice()

        def get_choice(self, items: Optional[Sequence[Any]],
                       length: int = 0, unique: bool = False) -> \
                Union[Sequence[Any], Any]:  # noqa: D202
            try:
                return self.choice(items, length, unique)
            except (TypeError, ValueError):
                return None

    test = Test()


# Generated at 2022-06-23 21:17:28.148018
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # type: () -> None
    """Test for method __call__."""

    # Block for method __call__ of class Choice
    provider = Choice()
    assert provider(items=[1, 2, 3]) == 1
    assert provider(items=[1, 2, 3], length=1) == [1]
    assert provider(items=('a', 'b', 'c'), length=2) == ('b', 'b')
    assert provider(items='abbcccddd', length=3) == 'bdd'
    assert provider(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert provider(items='aabbbccccddddd', length=4, unique=True) == 'aacd'

# Generated at 2022-06-23 21:17:38.650356
# Unit test for method __call__ of class Choice
def test_Choice___call__():
  # dict of input arguments
  args = {'items': [3, '9', 'x', 'y'], 'length': 3, 'unique': True}
  # with arguments, without kwargs
  obj = Choice()
  assert isinstance(obj(**args), list)
  # cleanup - nothing to do
  # with arguments, with kwargs
  obj = Choice()
  assert isinstance(obj(**args), list)
  # cleanup - nothing to do
  # without arguments, without kwargs
  obj = Choice()
  assert isinstance(obj(), list)
  # cleanup - nothing to do
  # without arguments, with kwargs
  obj = Choice()
  assert isinstance(obj(**args), list)
  # cleanup - nothing to do

# Generated at 2022-06-23 21:17:44.394499
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_ = Choice()
    print(choice_('abc'))
    print(choice_(items='abc', length=2))
    print(choice_(items=('a', 'b', 'c'), length=5))
    print(choice_(items='aabbbccccddddd', length=4, unique=True))


if __name__ == "__main__":
    test_Choice___call__()

# Generated at 2022-06-23 21:17:46.838595
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    items = [i for i in range(10)]
    items = choice(items=items, length=10, unique=True)
    print(items)
# test_Choice()


# Generated at 2022-06-23 21:17:48.093379
# Unit test for constructor of class Choice
def test_Choice():
    ch = Choice()
    print(ch)


# Generated at 2022-06-23 21:17:51.189431
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert str(choice) == "choice"
    assert type(choice) == Choice
    assert repr(choice) == "Choice()"
    
    
    
    
    

# Generated at 2022-06-23 21:17:57.925041
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit tests for method __call__ of class Choice."""

# Generated at 2022-06-23 21:17:59.460396
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice

    # TODO: write tests
    assert True

# Generated at 2022-06-23 21:18:10.742809
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """ Tests method __call__ of class Choice. """
    from mimesis.enums import Gender
    from mimesis.schema import Field
    from mimesis.typing import Generic
    import datetime
    choice = Choice()
    assert isinstance(choice.items(schema=[Field('price', type_=int)]), dict)
    assert isinstance(choice.items(schema=[Field('quantity', type_=int)]), dict)
    assert isinstance(choice.choice_of(schema=[Field('price', type_=int)]), dict)
    assert isinstance(choice.choice_of(schema=[Field('quantity', type_=int)]), dict)
    assert isinstance(choice.items(schema=['a', 'b', 'c', 'd']), dict)

# Generated at 2022-06-23 21:18:11.806188
# Unit test for constructor of class Choice
def test_Choice():
    choice_obj = Choice()

# Generated at 2022-06-23 21:18:17.769377
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) ==  ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:18:19.704334
# Unit test for constructor of class Choice
def test_Choice():
    obj = Choice()
    repr(obj)
    str(obj)

# Generated at 2022-06-23 21:18:29.809993
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) in ['aa', 'ba', 'ca', 'ab', 'bb', 'cb', 'ac', 'bc', 'cc']
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')

# Generated at 2022-06-23 21:18:32.558605
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    assert isinstance(choice(items, length, unique), str)



# Generated at 2022-06-23 21:18:35.939902
# Unit test for constructor of class Choice
def test_Choice():
    data = ['a', 'a', 'b', 'b', 'c', 'c']
    assert Choice().choice(data, 4) == ['a', 'a', 'b', 'c']

# Generated at 2022-06-23 21:18:42.113571
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis import Choice
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


if __name__ == '__main__':
    test_Choice()

# Generated at 2022-06-23 21:18:50.501621
# Unit test for constructor of class Choice
def test_Choice():
    test_class = Choice()
    test_class(items=['a', 'b', 'c'])
    test_class(items=['a', 'b', 'c'], length=1)
    test_class(items='abc', length=2)
    test_class(items=('a', 'b', 'c'), length=5)
    test_class(items='aabbbccccddddd', length=4, unique=True)


# Generated at 2022-06-23 21:19:00.033100
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ab', 'bc', 'ac']