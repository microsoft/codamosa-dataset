

# Generated at 2022-06-23 21:09:06.368526
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    print(choice(items=['a', 'b', 'c']))
    print(choice(items=['a', 'b', 'c'], length=1))
    print(choice(items='abc', length=2))
    print(choice(items=('a', 'b', 'c'), length=5))
    print(choice(items='aabbbccccddddd', length=4, unique=True))

# test_Choice()

# Generated at 2022-06-23 21:09:07.845128
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    print(Choice().__call__(['a', 'b', 'c']))


# Generated at 2022-06-23 21:09:12.496159
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    for _ in range(10):
        assert Choice().__call__(items='abc', length=2) in ['ab', 'ac', 'bc']
        assert Choice().__call__(items=['a', 'b', 'c'], length=2) in [['a', 'b'],['a', 'c'],['b', 'c']]

# Generated at 2022-06-23 21:09:14.794092
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert len(choice('test', 2)) == 2

# Generated at 2022-06-23 21:09:16.099687
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice is not None


# Generated at 2022-06-23 21:09:22.534805
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.providers.datetime import Datetime
    dt = Datetime('en')
    choice = Choice(dt)
    sequence = range(10)
    random_choice = choice(sequence)
    assert isinstance(random_choice, int)
    assert random_choice in sequence
    assert isinstance(choice(sequence, length=1), list)

    # TypeError for non-integer length
    non_int_length = choice(sequence, length='a')
    assert non_int_length == TypeError

    # TypeError for non-sequence items
    items = dt.datetime()
    non_sequence = choice(items)
    assert non_sequence == TypeError

    # ValueError for negative length
    negative_length = choice(sequence, length=-1)
    assert negative_length == ValueError

    # ValueError for

# Generated at 2022-06-23 21:09:26.173902
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice('abcd') in 'abcd'
    assert choice('abcd', length=4) in ('abcd', 'adbc', 'cabd', 'cdab')
    assert choice((1, 2, 3, 4), length=4) in ((1, 2, 3, 4), (2, 1, 4, 3), (2, 3, 1, 4))

# Generated at 2022-06-23 21:09:30.437921
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items = ['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items = ['a', 'b', 'c'], length = 1) == ['a']
    assert Choice().__call__(items = 'abc', length = 2) == "ba"
    assert Choice().__call__(items = ('a', 'b', 'c'), length = 5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items = 'aabbbccccddddd', length = 4, unique = True) == 'cdba'


# Generated at 2022-06-23 21:09:32.408700
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice(locale='en')
    # As long as this runs without error, it probably worked.

# Generated at 2022-06-23 21:09:33.898952
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice().__class__.__name__=='Choice'


# Generated at 2022-06-23 21:09:35.842975
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.providers.choice import Choice
    choice = Choice()
    choice(items=[])


# Generated at 2022-06-23 21:09:41.855373
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice.choice(items=['a', 'b', 'c']) == 'c'
    assert choice.choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice.choice(items='abc', length=2) == 'ba'
    assert choice.choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a','b','c')
    assert choice.choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:09:52.973183
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.providers.sequence import Sequence
    import random
    obj = Choice(random.Random())
    result = obj({})
    if not isinstance(result, type):
        raise TypeError('Invalid type.')

    result = obj([])
    if not isinstance(result, type):
        raise TypeError('Invalid type.')

    result = obj(Sequence())
    if not isinstance(result, type):
        raise TypeError('Invalid type.')
    # TODO: Remove "+ ' '"
    result = obj(Sequence() + ' ', length=1)
    if not isinstance(result, list):
        raise TypeError('Invalid type.')

    result = obj(Sequence() + ' ', length=2)
    if not isinstance(result, type):
        raise TypeError('Invalid type.')

   

# Generated at 2022-06-23 21:09:59.217673
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ('a', 'b', 'c')
    length = 5
    choice = Choice()
    random_choice = choice(items=items, length=length)
    assert len(random_choice) == length
    assert isinstance(random_choice, tuple)
    assert random_choice in [('a', 'b', 'c', 'a', 'b'), ('b', 'a', 'c', 'c', 'a'),
                             ('c', 'b', 'b', 'a', 'c'), ('a', 'c', 'a', 'b', 'c')]

# Generated at 2022-06-23 21:10:00.851273
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    choice('0123456789', length=7, unique=True)

# Generated at 2022-06-23 21:10:09.488452
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()

    assert choice.seed_is_set() == False

    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    return

# Generated at 2022-06-23 21:10:13.038071
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for the method __call__ of class Choice."""
    choice = Choice()
    assert isinstance(choice.__call__(items=['a', 'b', 'c']), str)
    assert isinstance(choice.__call__(items=['a', 'b', 'c'], length=1), list)
    assert isinstance(choice.__call__(items='abc', length=2), str)
    assert isinstance(choice.__call__(items=('a', 'b', 'c'), length=5), tuple)
    assert isinstance(choice.__call__(items='aabbbccccddddd', length=4,
                                      unique=True), str)

# Generated at 2022-06-23 21:10:24.430162
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Method to test method __call__ in Choice class."""
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in {'ba', 'cb', 'ab'}

# Generated at 2022-06-23 21:10:25.417883
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice(seed=123)


# Generated at 2022-06-23 21:10:27.729317
# Unit test for constructor of class Choice
def test_Choice():
    """Check `Choice` class."""
    data = Choice().choice(['a', 'b', 'c'])
    assert isinstance(data, str)

    data = Choice().choice(['a', 'b', 'c'], length=1)
    assert isinstance(data, list)

    data = Choice().choice('aabbbccccddddd', length=4, unique=True)
    assert isinstance(data, str)

# Generated at 2022-06-23 21:10:28.335724
# Unit test for constructor of class Choice
def test_Choice():
    Choice()

# Generated at 2022-06-23 21:10:29.520399
# Unit test for constructor of class Choice
def test_Choice():
    x = Choice()
    print(x)

# Generated at 2022-06-23 21:10:30.151897
# Unit test for constructor of class Choice
def test_Choice():
    obj=Choice()

# Generated at 2022-06-23 21:10:33.546128
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice(locale='fr')   
    print("\n TEST constructeur de classe choice \n")
    print("\n TEST constructeur de classe choice renvoie  ", choice)
    return 0


# Generated at 2022-06-23 21:10:35.152743
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis import Choice
    choice = Choice()
    assert callable(choice)


# Generated at 2022-06-23 21:10:41.000386
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-23 21:10:47.461224
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:10:48.484172
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass



# Generated at 2022-06-23 21:10:50.442078
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    items = ['a', 'b', 'c']
    length = 1

    assert(choice(items, length) == ['a'])

# Generated at 2022-06-23 21:10:56.930117
# Unit test for constructor of class Choice
def test_Choice():
    """Unit test for constructor of class Choice."""
    from mimesis.exceptions import NonEnumerableError
    from mimesis.enums import Gender
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.date import Date
    from mimesis.providers.misc import Misc
    from mimesis.providers.number import Number
    from mimesis.providers.person import Person
    from mimesis.providers.person import UserAgent
    from mimesis.providers.person import Business
    from mimesis.providers.person import Address
    from mimesis.providers.person import Basic
    from mimesis.providers.person import Demographics
    from mimesis.providers.person import Name
    from mimesis.providers.person import Payment

# Generated at 2022-06-23 21:11:07.661215
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_items = 'abcdef'
    list_items = ['a', 'b', 'c', 'd', 'e', 'f']
    tuple_items = ('a', 'b', 'c', 'd', 'e', 'f')
    int_items = [1, 2, 3, 4, 5, 6]
    float_items = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6]
    complex_items = [complex(0, 1), complex(1, 0), complex(1, 1),
                     complex(0, -1), complex(-1, 0), complex(1j)]
    unique_items = ['aa', 'bb', 'cc', 'dd', 'ee', 'ff']
    non_sequence_items = 12345

    c = Choice()

# Generated at 2022-06-23 21:11:14.036479
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    class_name = 'Choice'
    method_name = '__call__'
    # 1. items - sequence
    items = ['item1', 'item2', 'item3']
    # 1.1. length - not int
    length = ''
    expected = TypeError
    actual = ''
    assert_raises(class_name, method_name, expected, actual, items=items, length=length)
    # 1.2. length - negative
    length = -1
    expected = ValueError
    actual = ''
    assert_raises(class_name, method_name, expected, actual, items=items, length=length)
    # 1.3. length - positive
    length = 2
    expected = list
    actual = type(Choice().choice(items=items, length=length))

# Generated at 2022-06-23 21:11:16.082183
# Unit test for constructor of class Choice
def test_Choice():
    x = Choice()
    assert hasattr(x, 'random')
    assert hasattr(x, 'datetime')


# Generated at 2022-06-23 21:11:18.499155
# Unit test for constructor of class Choice
def test_Choice():
    """
    """
    choice = Choice()
    a = choice(items=['a', 'b', 'c'])
    print(a)


# Generated at 2022-06-23 21:11:29.117893
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ba', 'ac', 'bc']
    assert choice(items=('a', 'b', 'c'), length=5) in [
        ('c', 'a', 'a', 'b', 'c'), ('c', 'c', 'b', 'a', 'b'),
        ('a', 'b', 'c', 'c', 'a')
    ]

# Generated at 2022-06-23 21:11:34.170136
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()

    print(choice(items=['a', 'b', 'c']))
    print(choice(items=['a', 'b', 'c'], length=1))
    print(choice(items=['a', 'b', 'c'], length=2))
    print(choice(items=['a', 'b', 'c'], length=5))
    print(choice(items=['aabbbccccddddd'], length=4, unique=True))


# Generated at 2022-06-23 21:11:38.270227
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method __call__ of class Choice."""
    # Case 1:
    # container is list and length is 5
    random_number = 7
    container = [1, 2, 3]
    length = 5
    unique = False
    random_result = ['a', 'b', 'c', 'a']


# Generated at 2022-06-23 21:11:40.438466
# Unit test for constructor of class Choice
def test_Choice():
    """Test Choice class."""
    # TODO
    pass

# Generated at 2022-06-23 21:11:51.477594
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Tests for method __call__ of class Choice."""
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 1
    unique = False

    assert choice(items, length, unique) == ['a'], 'Failed Choice.__call__()'
    assert choice(items, length=length) == ['c'], 'Failed Choice.__call__()'

    assert choice(items=items) == 'c', 'Failed Choice.__call__()'
    assert choice(items=items, length=length) == ['a'], \
        'Failed Choice.__call__()'
    assert choice(items=items, length=5) == ['b', 'c', 'c', 'a', 'c'], \
        'Failed Choice.__call__()'

    items = 'abc'

# Generated at 2022-06-23 21:11:55.763325
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import random
    assert Choice().choice(items=[1, 2, 3]) in [1, 2, 3]
    assert Choice().choice(items=[1, 2, 3], length=0) in [1, 2, 3]
    assert Choice().choice(items=[1, 2, 3], length=1) == [1]
    assert Choice().choice(items='abc', length=2) in ['ab', 'bc', 'ac']
    assert Choice().choice(items='aabbbccccddddd', length=4, unique=True) in ['adbc', 'abdc', 'dbca', 'bacd', 'dabc']
    try:
        Choice().choice(items='abc', length=4, unique=True)
    except ValueError:
        pass
    else:
        assert False

# Generated at 2022-06-23 21:11:58.742139
# Unit test for constructor of class Choice
def test_Choice():
    print(Choice().choice(['a', 'b', 'c'], 2))
    print(Choice().choice(['a', 'b', 'c'], 2, unique=False))

if __name__ == '__main__':
    test_Choice()

# Generated at 2022-06-23 21:11:59.281664
# Unit test for constructor of class Choice
def test_Choice():
    Choice()

# Generated at 2022-06-23 21:12:02.198400
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method Choice.__call__() with normal input."""
    choice = Choice()
    result = choice(items=['a', 'b', 'c'])
    assert result in ('a', 'b', 'c')



# Generated at 2022-06-23 21:12:04.962562
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)


# Generated at 2022-06-23 21:12:11.262623
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items=('a', 'b', 'c')) == 'c'
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']

# Generated at 2022-06-23 21:12:14.047137
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) != 'c'
    assert choice(items=['a', 'b', 'c'], length=1) != ['a']
    assert choice(items='abc', length=2) != 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) != ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) != 'cdba'


# Generated at 2022-06-23 21:12:21.913143
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    choice = Choice()

    # Call Choice.__call__

# Generated at 2022-06-23 21:12:23.783115
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice('de')
    assert type(choice) == Choice

# Generated at 2022-06-23 21:12:24.932195
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice


# Generated at 2022-06-23 21:12:28.167058
# Unit test for constructor of class Choice
def test_Choice():
    """Unit test for constructor of class Choice."""
    p = Choice()
    assert isinstance(p, Choice)



# Generated at 2022-06-23 21:12:30.137944
# Unit test for constructor of class Choice
def test_Choice():
    """Test for class Choice."""
    # Init
    choice = Choice(seed=123456)
    # Result
    assert choice is not None

# Generated at 2022-06-23 21:12:40.618756
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    obj = Choice()

    obj(items=['a', 'b', 'c'])
    obj(items=['a', 'b', 'c'], length=1)
    obj(items='abc', length=2)
    obj(items=('a', 'b', 'c'), length=5)
    obj(items='aabbbccccddddd', length=4, unique=True)

    try:
        obj(items=None)
        raise AssertionError('TypeError not raised.')
    except TypeError as e:
        assert e.args[0] == '**items** must be non-empty sequence.'


# Generated at 2022-06-23 21:12:45.841362
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    import doctest
    result = doctest.testmod()
    if result.failed == 0:
        print('Unit test for method __call__ of class Choice '
              'has passed.')
    else:
        print('Unit test for method __call__ of class Choice '
              'has failed.')


# Generated at 2022-06-23 21:12:47.253631
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)


# Generated at 2022-06-23 21:12:55.853235
# Unit test for method __call__ of class Choice
def test_Choice___call__():
  p = Choice()
  items = ["a", "b", "c"]
  length = 1
  unique = True
  result = p.__call__(items, length, unique)
  if str(result) != "a" and str(result) != "b" and str(result) != "c":
      raise Exception("Got " + str(result) + " (type: " + str(type(result)) + \
          "), expected a, b, or c.")
  items = ["a", "b", "c"]
  length = 2
  unique = False
  result = p.__call__(items, length, unique)

# Generated at 2022-06-23 21:12:56.373139
# Unit test for constructor of class Choice
def test_Choice():   
    assert Choice()

# Generated at 2022-06-23 21:13:02.948621
# Unit test for constructor of class Choice
def test_Choice():
    """
    test_Choice
    """
    c = Choice()
    # str
    assert isinstance(c(items='abc', length=0), str)
    # List
    assert isinstance(c(items=['a', 'b', 'c'], length=1), list)
    # Tuple
    assert isinstance(c(items=['a', 'b', 'c'], length=5), tuple)

# Generated at 2022-06-23 21:13:04.049335
# Unit test for constructor of class Choice
def test_Choice():
    Choice(seed=0)

# Generated at 2022-06-23 21:13:09.868232
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method __call__ of class Choice."""
    c = Choice()
    # Arguments
    params = [
        (['a', 'b', 'c'], 0, False),
        (['a', 'b', 'c'], 1, False),
        ("abc", 2, False),
        (('a', 'b', 'c'), 5, False),
        ('aabbbccccddddd', 4, True)
    ]
    for (items, length, unique) in params:
        print(c(items, length, unique))
    # Expected TypeError
    choice_test.test_type_error(c, '__call__')
    # Expected ValueError
    choice_test.test_value_error(c, '__call__')

# Generated at 2022-06-23 21:13:13.302640
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import hypothesis

    from . import custom_hypothesis_support

    strategy = hypothesis.strategies.data()
    strategy.draw_and_produce(custom_hypothesis_support.reify_choice)

# Generated at 2022-06-23 21:13:18.759567
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    result = c(items=['a', 'b', 'c'], length=1)
    assert result == ['c']
    result = c(items='abc', length=2)
    assert result == 'bc'
    result = c(items=('a', 'b', 'c'), length=5)
    assert result == ('b', 'c', 'b', 'c', 'c')
    result = c(items='aabbbccccddddd', length=4, unique=True)
    assert result == 'bdca'


# Generated at 2022-06-23 21:13:21.410296
# Unit test for constructor of class Choice
def test_Choice():
    """Test for Choice class."""
    c = Choice()
    items = [10, 20, 30]

    assert c(items) in items



# Generated at 2022-06-23 21:13:25.187201
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    print(choice('abc'))
    print(choice(['a', 'b', 'c']))
    print(choice(('a', 'b', 'c')))
    print(choice('abc', 5))
    print(choice('aabbccddde', 5, unique=True))


# Generated at 2022-06-23 21:13:31.293935
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import unittest

    class TestChoiceCall(unittest.TestCase):
        """Test method __call__ of class Choice."""

        def setUp(self):
            """Initialize attributes."""
            self.choice = Choice()

        def tearDown(self):
            """Reset attributes."""
            del self.choice

        def test_call(self):
            """Test method __call__ of class Choice."""
            self.assertIsInstance(self.choice(), str)
            self.assertIsInstance(self.choice(items='abcd'), str)

            self.assertIsInstance(self.choice(length=1), list)
            self.assertIsInstance(self.choice(items='abcd', length=1), list)
            self.assertIsInstance(self.choice(items='abcd', length=4), str)

           

# Generated at 2022-06-23 21:13:36.620422
# Unit test for method __call__ of class Choice
def test_Choice___call__(): # TODO: assert for method __call__
    choice = Choice()
    choice(items=['a', 'b', 'c'])
    choice(items=['a', 'b', 'c'], length=1)
    choice(items='abc', length=2)
    choice(items=('a', 'b', 'c'), length=5)
    choice(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-23 21:13:46.371575
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) == ['a'] or \
        choice(items=['a', 'b', 'c'], length=1) == ['b'] or \
        choice(items=['a', 'b', 'c'], length=1) == ['c']
    assert choice(items='abc', length=2) in ['ab', 'bc', 'ca']

# Generated at 2022-06-23 21:13:47.724720
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis import Choice
    print(Choice)


# Generated at 2022-06-23 21:13:49.106122
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert(isinstance(choice, Choice))


# Generated at 2022-06-23 21:13:50.620597
# Unit test for constructor of class Choice
def test_Choice():
    """Tests constructor."""
    choice = Choice()
    assert isinstance(choice, Choice)


# Generated at 2022-06-23 21:13:53.331605
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice.__class__.__name__ == 'Choice'
    assert isinstance(choice, Choice)
    assert isinstance(choice, BaseProvider)

# Unit tests for method __call__ of class Choice

# Generated at 2022-06-23 21:13:55.008178
# Unit test for constructor of class Choice
def test_Choice():
    '''Checking the constructor of class Choice'''
    c = Choice()
    assert isinstance(c, Choice)


# Generated at 2022-06-23 21:14:01.358171
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    provider = Choice()
    item = provider(items=["a", "b", "c"])
    assert type(item) == str
    item = provider(items=["a", "b", "c"], length=1)
    assert type(item) == list
    item = provider(items="abc", length=2)
    assert type(item) == str
    item = provider(items=("a", "b", "c"), length=5)
    assert type(item) == tuple
    item = provider(items="aabbbccccddddd", length=4, unique=True)
    assert type(item) == str

# Generated at 2022-06-23 21:14:07.614002
# Unit test for constructor of class Choice
def test_Choice():
    choice=Choice()
    #print('aa', choice(items=[1, 2, 3, 4], length=2, unique=True))
    #print(choice(items=['a', 'b', 'c'], length=1))
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items=[1, 2, 3, 4], length=2, unique=True) == [4, 1]

# Generated at 2022-06-23 21:14:18.232150
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    choice = Choice()
    assert choice('abc') in 'abc'
    assert choice(['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(('a', 'b', 'c')) in ('a', 'b', 'c')
    assert choice('abc', length=1) in 'abc'
    assert choice('abc', length=2) in 'abc'
    assert choice('abc', length=3) in 'abc'
    assert choice('abc', length=4) in 'abc'
    assert choice(['a', 'b', 'c'], length=1) in ['a', 'b', 'c']
    assert choice(['a', 'b', 'c'], length=2) in ['a', 'b', 'c']

# Generated at 2022-06-23 21:14:28.884512
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ab', 'ac', 'bc']

# Generated at 2022-06-23 21:14:35.637827
# Unit test for constructor of class Choice
def test_Choice():
    # Test with length less than zero
    with pytest.raises(ValueError) as length: 
        choice = Choice(universe=[1,2,3,4,5], length=-1, unique=False)
        choice_list = choice.generate()

    # Test with type of  length not an integer
    with pytest.raises(TypeError) as type: 
        choice = Choice(universe=[1,2,3,4,5], length='a', unique=False)
        choice_list = choice.generate()


# Generated at 2022-06-23 21:14:45.902068
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.providers.choice import Choice 
    choice = Choice()
    item = choice(items=['a', 'b', 'c'], length=2, unique=False)
    assert type(item) == str
    item = choice(items=('a', 'b', 'c'), length=5, unique=False)
    assert type(item) == tuple
    item = choice(items='abc', length=2, unique=False)
    assert type(item) == str
    item = choice(items=['a', 'b', 'c'], length=1, unique=False)
    assert type(item) == list
    item = choice(items='aabbbccccddddd', length=4, unique=True)
    assert type(item) == str

# Generated at 2022-06-23 21:14:52.937573
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    assert(choice(items=['a', 'b', 'c']) == 'c')
    assert(choice(items=['a', 'b', 'c'], length=1) == ['a'])
    assert(choice(items='abc', length=2) == 'ba')
    assert(choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c'))
    assert(choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba')


# Generated at 2022-06-23 21:15:00.457135
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    data1 = choice('a','b','c')
    assert isinstance(data1, str)

    data2 = choice('a','b','c', length=1)
    assert isinstance(data2, list)
    assert len(data2) == 1

    data3 = choice('abc', length=2)
    assert isinstance(data3, str)
    assert len(data3) == 2

    data4 = choice('aabbbccccddddd',length=4, unique=True)
    assert isinstance(data4, str)
    assert len(data4) == 4

    data5 = choice('aabbbccccddddd', length=5, unique=False)
    assert isinstance(data5, str)
    assert len(data5) == 5

# Generated at 2022-06-23 21:15:02.527137
# Unit test for constructor of class Choice
def test_Choice():
    obj = Choice()
    print("Choice", obj)


# Generated at 2022-06-23 21:15:04.220621
# Unit test for constructor of class Choice
def test_Choice():
    """Unit test for constructor of class Choice."""
    choice = Choice()
    choice.__init__()


# Generated at 2022-06-23 21:15:10.651713
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    data = {
        'items': [''],
        'length': -1,
        'unique': True,
    }

    with pytest.raises(ValueError) as err:
        c = Choice()
        c(**data)

    assert str(err.value) == '**items** must be a non-empty sequence.'

    with pytest.raises(ValueError) as err:
        c = Choice()
        c(items=['a'], **data)

    assert str(err.value) == '**length** should be a positive integer.'

    with pytest.raises(ValueError) as err:
        c = Choice()
        assert c(items=['a'], length=1, **data)


# Generated at 2022-06-23 21:15:18.644292
# Unit test for method __call__ of class Choice

# Generated at 2022-06-23 21:15:19.367586
# Unit test for constructor of class Choice
def test_Choice():
    pass

# Generated at 2022-06-23 21:15:21.984893
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    print(c(items=[1,2,3,4], length=1))
    print('PASSED: test_Choice()')


# Generated at 2022-06-23 21:15:25.167637
# Unit test for constructor of class Choice
def test_Choice():
    """Testing of Choice."""
    from mimesis.providers.choice import Choice
    choice = Choice()
    assert choice('abc') == 'c'
    assert choice('abc', 1) == 'a'

# Generated at 2022-06-23 21:15:34.849783
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    r = c(items=['a', 'b', 'c'])
    assert isinstance(r, str) and r in ['a', 'b', 'c']
    r = c(items=['a', 'b', 'c'], length=1)
    assert isinstance(r, list) and r in [['a'], ['b'], ['c']]
    r = c(items='abc', length=2)
    assert isinstance(r, str) and r in ['ba', 'ab', 'cb', 'ac', 'bc']
    r = c(items=('a', 'b', 'c'), length=5)

# Generated at 2022-06-23 21:15:36.226261
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert callable(choice)

# Generated at 2022-06-23 21:15:44.760500
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-23 21:15:48.221983
# Unit test for constructor of class Choice
def test_Choice():
    provider = Choice()
    assert repr(provider) == 'Choice()'
    assert provider.__str__() == 'Choice'
    assert provider.__unicode__() == 'Choice'
    assert provider.__bytes__() == b'Choice'


# Generated at 2022-06-23 21:15:56.445245
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:16:01.557483
# Unit test for constructor of class Choice
def test_Choice():
    seq = ('a', 'b', 'c')
    choices = Choice()
    assert isinstance(choices, Choice)
    assert callable(choices)
    assert isinstance(choices(seq, 2), str)
    assert isinstance(choices(seq, 2, False), str)
    assert isinstance(choices(seq, 2, True), str)
    assert isinstance(choices(seq), str)


# Generated at 2022-06-23 21:16:09.348822
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    for _ in range(100):
        choice = Choice()
        assert isinstance(choice(items=['a', 'b', 'c']), str)
        assert isinstance(choice(items=('a', 'b', 'c')), str)
        assert isinstance(choice(items='abc'), str)
        assert isinstance(choice(items=('a', 'b', 'c'), length=5), tuple)
        assert isinstance(choice(items='aabbbccccddddd', length=4, unique=True), str)
        assert choice(items='abc') in ['a', 'b', 'c']

# Generated at 2022-06-23 21:16:12.839983
# Unit test for constructor of class Choice
def test_Choice():
    choice =  Choice()
    choice_2 = Choice(seed = 1)
    choice_3 = Choice(seed = 2)
    assert choice.random is not choice_2.random
    assert choice_2.random is choice_3.random

# Generated at 2022-06-23 21:16:19.437873
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    data = choice(items=['a', 'b', 'c'])
    assert data == 'c'
    data = choice(items=['a', 'b', 'c'], length=1)
    assert data == ['a']
    data = choice(items='abc', length=2)
    assert data == 'ba'
    data = choice(items=('a', 'b', 'c'), length=5)
    assert data == ('c', 'a', 'a', 'b', 'c')
    data = choice(items='aabbbccccddddd', length=4, unique=True)
    assert data == 'cdba'


# Generated at 2022-06-23 21:16:21.261602
# Unit test for constructor of class Choice
def test_Choice():
    cc = Choice()
    print(cc)


# Generated at 2022-06-23 21:16:21.897754
# Unit test for constructor of class Choice
def test_Choice():
    ch = Choice()



# Generated at 2022-06-23 21:16:26.145103
# Unit test for constructor of class Choice
def test_Choice():
    c1 = Choice()
    c2 = Choice('a', 'b', 'c')
    assert c1
    assert c1.random
    assert c1.datetime
    assert c2
    assert c2.random
    assert c2.datetime


# Generated at 2022-06-23 21:16:31.098764
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:16:34.848649
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    s = 'abc'
    assert len(set(Choice().__call__(s, 5))) == 3
    assert len(set(Choice().__call__(s, 5, unique=True))) == 3
    assert set(Choice().__call__(s, 5)) == set(Choice().__call__(s, 5))

# Generated at 2022-06-23 21:16:42.361665
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = ['a', 'b', 'c']
    assert choice(items) == 'c'
    assert choice(items, length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    assert choice(items=('a', 'b', 'c'), length=2) == ('c', 'b')

# Generated at 2022-06-23 21:16:46.519075
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    items=['a', 'b', 'c']
    length=1
    unique=False
    choice.__call__(items=items, length=length, unique=unique)

# Generated at 2022-06-23 21:16:54.830512
# Unit test for constructor of class Choice
def test_Choice():
    try:
        choice = Choice()
   #     choice(items=['a', 'b', 'c'])
    #    choice(items=['a', 'b', 'c'], length=1)
     #   choice(items='abc', length=2)
      #  choice(items=('a', 'b', 'c'), length=5)
       # choice(items='aabbbccccddddd', length=4, unique=True)
        #choice(items='aabbbccccddddd', length=4, unique=True)
    except TypeError as e:
        print("Error: ", e)


if __name__ == '__main__':
    test_Choice()


#WORKING

# Generated at 2022-06-23 21:16:57.690070
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    _items = ['a', 'b', 'c']
    _length = 1
    _unique = False
    expected_result = ['a']
    result = Choice().__call__(items=_items, length=_length, unique=_unique)
    assert result == expected_result


# Generated at 2022-06-23 21:17:03.204334
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'



# Generated at 2022-06-23 21:17:03.868279
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert c is not None

# Generated at 2022-06-23 21:17:08.771327
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    # asser if result is a list
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    # asser if result is a str
    assert choice(items='abc', length=2) == 'ba'
    # asser if result is a tuple
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    # asser if result is a str
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-23 21:17:19.007780
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    assert choice(['a', 'b', 'c'], length=1) == ['c']
    assert choice(['a', 'b', 'c'], length=2) == ['c', 'c']
    assert choice(['a', 'b', 'c'], length=3) == ['b', 'b', 'a']
    assert choice([], length=1) == ['']
    assert choice('abc', length=2) == ['a', 'b']
    assert choice(('a', 'b', 'c'), length=5) == ('c', 'b', 'a', 'b', 'c')
    assert choice('aabbbccccddddd', length=4, unique=True) == ['b', 'c', 'd', 'a']

# Generated at 2022-06-23 21:17:29.454517
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Test: Test with choice out of list
    expected = 'a'
    actual = Choice()(items = ['a', 'b', 'c'])
    assert actual == expected
    # Test: Test with choice out of list with length 1
    expected = ['a']
    actual = Choice()(items = ['a', 'b', 'c'], length = 1)
    assert actual == expected
    # Test: Test with choice out of list with length 2
    expected = 'ba'
    actual = Choice()(items = 'abc', length = 2)
    assert actual == expected
    # Test: Test with choice out of tuple
    expected = ('c', 'a', 'a', 'b', 'c')
    actual = Choice()(items = ('a', 'b', 'c'), length = 5)
    assert actual == expected
    # Test: Test

# Generated at 2022-06-23 21:17:40.240711
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    print(c(items=['a', 'b', 'c']))
    print(c(items=['a', 'b', 'c'], length=1))
    print(c(items='abc', length=2))
    print(c(items=('a', 'b', 'c'), length=5))
    print(c(items='aabbbccccddddd', length=4, unique=True))
    try:
        c(items='abc', length=2.5)
    except TypeError:
        print('Error: TypeError')
    try:
        c(items=True, length=2)
    except TypeError:
        print('Error: TypeError')
    try:
        c(items=[], length=2)
    except ValueError:
        print('Error: ValueError')

# Generated at 2022-06-23 21:17:42.180804
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']

# Generated at 2022-06-23 21:17:51.138943
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice('en')
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ab', 'ac', 'bc']

# Generated at 2022-06-23 21:17:57.881687
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Test for non-sequence items
    try:
        Choice().__call__(123)
    except TypeError:
        pass
    else:
        print("Test for no-sequence items failed")

    # Test for non-integer length
    try:
        Choice().__call__(['a', 'b', 'c'], 'length')
    except TypeError:
        pass
    else:
        print("Test for non-integer length failed")

    # Test for negative length
    try:
        Choice().__call__(['a', 'b', 'c'], -1)
    except ValueError:
        pass
    else:
        print("Test for negative length failed")

    # Test for empty sequence
    try:
        Choice().__call__([])
    except ValueError:
        pass

# Generated at 2022-06-23 21:18:06.440297
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items_0 = ['a', 'b', 'c']
    items_1 = ('a', 'b', 'c')
    items_2 = 'abc'
    choice = Choice()
    res = choice(items_0)
    assert type(res) is str
    res = choice(items_1)
    assert type(res) is str
    res = choice(items_2)
    assert type(res) is str

    res = choice(items_0, length=1)
    assert type(res) is list
    res = choice(items_1, length=1)
    assert type(res) is list
    res = choice(items_2, length=1)
    assert type(res) is str

    res = choice(items_0, length=1, unique=True)
    assert type(res) is list
   

# Generated at 2022-06-23 21:18:09.836541
# Unit test for constructor of class Choice
def test_Choice():
    instance = Choice()
    assert isinstance(instance, Choice)
    assert hasattr(instance, 'random')
    assert hasattr(instance, 'datetime')
    assert hasattr(instance, '__version__')



# Generated at 2022-06-23 21:18:17.069590
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    from mimesis import Choice
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'



# Generated at 2022-06-23 21:18:28.109590
# Unit test for constructor of class Choice
def test_Choice():
    """Tests for constructor of  class Choice"""
    choice = Choice(seed=1)
    assert choice.random.choice(items=[2, 3, 4, 2, 3, 4, 2, 3, 4],length=3,unique=False) == [3, 2, 4]
    assert choice.random.choice(items=[2, 3, 4, 2, 3, 4, 2, 3, 4],length=3,unique=True) == [4, 3, 2]
    assert choice.random.choice(items=[2, 3, 4, 2, 3, 4, 2, 3, 4],length=10,unique=False) == [2, 4, 2, 3, 4, 4, 2, 3, 4, 4]

# Generated at 2022-06-23 21:18:29.191330
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert callable(Choice)

# Generated at 2022-06-23 21:18:29.926993
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()


# Generated at 2022-06-23 21:18:30.944894
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice(seed=123)


# Generated at 2022-06-23 21:18:32.092775
# Unit test for constructor of class Choice
def test_Choice():
    # Not implemented
    pass


# Generated at 2022-06-23 21:18:37.431121
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert Choice().__call__(items=['a', 'b', 'c'], length=1, unique=True) == ['b']
    assert Choice().__call__(items='abc', length=2) in ['ab', 'bc', 'ca']

# Generated at 2022-06-23 21:18:43.461348
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 10
    unique = True

    choice = Choice()
    data = choice(items=items, length=length, unique=unique)

    print(type(data))
    print(len(data))
    print(len(set(data)))
    print(data)

# Run unit test for method __call__ of class Choice
if __name__ == '__main__':
    test_Choice___call__()

# Generated at 2022-06-23 21:18:55.049549
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert isinstance(c, Choice)
    assert isinstance(c.random, BaseProvider)
    assert isinstance(c.datetime, BaseProvider)
    assert isinstance(c.text, BaseProvider)
    assert isinstance(c.numbers, BaseProvider)
    assert isinstance(c.personal, BaseProvider)
    assert isinstance(c.internet, BaseProvider)
    assert isinstance(c.misc, BaseProvider)
    assert isinstance(c.lorem, BaseProvider)
    assert isinstance(c.business, BaseProvider)
    assert isinstance(c.finance, BaseProvider)
    assert isinstance(c.codecs, BaseProvider)
    assert isinstance(c.science, BaseProvider)
    assert isinstance(c.transport, BaseProvider)

# Generated at 2022-06-23 21:18:57.816873
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    choice(items=['a', 'b', 'c'])
    choice(items=['a', 'b', 'c'], length=1)
    choice(items='abc', length=2)
    choice(items=('a', 'b', 'c'), length=5)
    choice(items='aabbbccccddddd', length=4, unique=True)
    choice(items=[], length=5)
    choice(items=['a', 'b', 'c'], length=5)
    choice(items=[], length=0)
    choice(items=['a', 'b', 'c'], length=0)

# Generated at 2022-06-23 21:19:02.695468
# Unit test for constructor of class Choice
def test_Choice():
	assert isinstance(Choice().choice(items, length, unique), TypeError)
	assert isinstance(Choice().choice(items, length, unique), TypeError)
	assert isinstance(Choice().choice(items, length, unique), TypeError)
	assert isinstance(Choice().choice(items, length, unique), TypeError)
	assert isinstance(Choice().choice(items, length, unique), TypeError)
	return None