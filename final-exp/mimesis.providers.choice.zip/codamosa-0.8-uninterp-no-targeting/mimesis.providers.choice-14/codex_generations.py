

# Generated at 2022-06-21 15:56:32.394600
# Unit test for constructor of class Choice
def test_Choice():
    """Provides a random choice from items in a sequence."""
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.numbers import BaseNumbersProvider

    choice = Choice(Numbers(BaseProvider(None)))
    assert choice is not None
    assert isinstance(choice, Choice)

# Generated at 2022-06-21 15:56:40.805770
# Unit test for constructor of class Choice
def test_Choice():
    import random
    import time

    choice = Choice(random, time)
    # Test generation of int
    for i in range(1, 10):
        assert choice() == choice(items=['a', 'b', 'c'], length=i)
    # Test generation of string
    for i in range(1, 10):
        assert choice() == choice(items='abc', length=i)
    # Test generation of tuple
    for i in range(1, 10):
        assert choice() == choice(items=('a', 'b', 'c'), length=i)
    # Test generation of list
    for i in range(1, 10):
        assert choice() == choice(items=['a', 'b', 'c'], length=i)



# Generated at 2022-06-21 15:56:54.167948
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test class Choice."""
    # TODO: Fix tests

# Generated at 2022-06-21 15:56:55.295737
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()


# Generated at 2022-06-21 15:56:56.410403
# Unit test for constructor of class Choice
def test_Choice():
    pass


# Generated at 2022-06-21 15:57:02.882839
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'



# Generated at 2022-06-21 15:57:13.796398
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    import random
    import pytest

    choice = Choice(random)

    items = ['alpha','beta','gamma','delta']
    length = 4
    unique = True
    output = choice(items=items,length=length,unique=unique)
    assert len(output) == length
    assert unique
    assert isinstance(output,list)

    items = 'test'
    length = 6
    unique = True
    with pytest.raises(ValueError):
        output = choice(items=items,length=length,unique=unique)

    items = 'test'
    length = 10
    unique = False
    output = choice(items=items,length=length,unique=unique)
    assert len(output) == length
    assert not unique

    # Don't add tests for invalid input, since Type

# Generated at 2022-06-21 15:57:14.604669
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice().__init__()


# Generated at 2022-06-21 15:57:22.532982
# Unit test for constructor of class Choice
def test_Choice():
    # Positive cases
    choice = Choice()
    assert isinstance(choice, Choice)
    assert choice([1, 2, 3]) in [1, 2, 3]
    assert choice([1, 2, 3], length=1) == [1]
    assert choice('abc', length=2) in ['ab', 'bc', 'ac']

# Generated at 2022-06-21 15:57:28.940709
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    print(Choice().__call__(items=['a','b','c']))
    print(Choice().__call__(items=['a','b','c'], length=1))
    print(Choice().__call__(items='abc', length=2))
    print(Choice().__call__(items=('a', 'b', 'c'), length=5))
    print(Choice().__call__(items='aabbbccccddddd', length=4, unique=True))
    print(Choice().__call__(items='aabbbccccddddd', length=5, unique=True))
    print(Choice().__call__(items='aabbbccccddddd', length=4))
    print(Choice().__call__(items='aabbbccccddddd', length=5))


# Generated at 2022-06-21 15:57:42.434237
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    import unittest
    import sys

    class ChoiceTestCase(unittest.TestCase):
        """Test methods of class Choice."""

        def setUp(self):
            """Initialize attributes."""
            self.choice = Choice()

        def test_Choice___call__(self):
            """Test method __call__ of class Choice."""
            seq = ('\u0422\u043e\u0442', '\u0442\u0430\u043a',
                   '\u0436\u0435')
            self.assertIn(self.choice(items=seq), seq)

        def test_Choice___call__with_length(self):
            """Test method __call__ of class Choice with **length** arg."""

# Generated at 2022-06-21 15:57:45.099448
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    print(choice(items=['a', 'b', 'c'], length=3, unique=True))

# Generated at 2022-06-21 15:57:46.422031
# Unit test for constructor of class Choice
def test_Choice():
    provider = Choice()
    assert provider is not None


# Generated at 2022-06-21 15:57:57.760855
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    choice = Choice()
    
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

    try:
        choice(items=['a', 'b', 'c'], length='c')
    except TypeError:
        pass
    else:
        assert False


# Generated at 2022-06-21 15:57:58.843193
# Unit test for constructor of class Choice
def test_Choice():
    Choice()


# Generated at 2022-06-21 15:58:05.542881
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice_ = Choice()
    items = ['a', 'b', 'c']
    c1 = choice_(items)
    assert(c1 == 'a' or c1 == 'b' or c1 == 'c')
    c2 = choice_(items, length=1)
    assert(c2 == ['a'] or c2 == ['b'] or c2 == ['c'])
    c3 = choice_(items, length=2)
    assert(c3 == 'ab' or c3 == 'ba' or c3 == 'ac' or c3 == 'ca' or c3 == 'bc' or c3 == 'cb')
    c4 = choice_(items, length=3)
    assert(len(c4) == 3)

# Generated at 2022-06-21 15:58:14.564069
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Tests for Choice.__call__."""
    from mimesis import Choice
    from mimesis.enums import Gender

    c = Choice()

    assert isinstance(c(['a', 'b', 'c'], 0), str)

    assert isinstance(c(['a', 'b', 'c'], 1), list)
    assert isinstance(c(('a', 'b', 'c'), 1), tuple)
    assert isinstance(c('abc', 1), str)

    assert c(['a', 'b', 'c'], 1) == ['a']
    assert c(('a', 'b', 'c'), 1) == ('a',)
    assert c('abc', 1) == 'a'

    assert len(c(['a', 'b', 'c'], 2)) == 2

# Generated at 2022-06-21 15:58:16.657759
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    #TODO: Write a unit test for method __call__ of class Choice
    pass


# Generated at 2022-06-21 15:58:26.526707
# Unit test for constructor of class Choice
def test_Choice():
    """Test class Choice."""
    # Select from a sequence.
    from mimesis import Choice
    choice = Choice()
    data = choice(items=['a', 'b', 'c'])
    assert data in ['a', 'b', 'c']
    assert isinstance(data, str)

    # Specify length of returned sequence.
    data = choice(items=['a', 'b', 'c'], length=1)
    assert len(data) == 1
    assert isinstance(data, list)

    # Specify a string sequence.
    data = choice(items='abc', length=2)
    assert data in ['aa', 'bb', 'cc', 'ab', 'ac', 'ba', 'bc', 'ca', 'cb']
    assert isinstance(data, str)

    # Specify a tuple sequence.
    data

# Generated at 2022-06-21 15:58:41.046558
# Unit test for constructor of class Choice
def test_Choice():

    # Test items as a list
    assert type(Choice().choice(['d', 'e', 'f'], 0)) == str

    # Test items as a string
    assert type(Choice().choice('aabbb', 0)) == str

    # Test items as a tuple
    assert type(Choice().choice(('z', 'y', 'x'), 0)) == str

    # Test items as a list and length as a positive integer
    assert type(Choice().choice(['a', 'b', 'c'], 7)) != str

    # Test items as a string and length as a positive integer
    assert type(Choice().choice('abc', 4)) != str

    # Test items as a tuple and length as a positive integer
    assert type(Choice().choice(('d', 'e', 'f'), 2)) != str

    # Test items as a list and length as a

# Generated at 2022-06-21 15:58:49.150499
# Unit test for constructor of class Choice
def test_Choice():
    Choice()

# Generated at 2022-06-21 15:58:50.537736
# Unit test for constructor of class Choice
def test_Choice():
    #Test if Choice is a class
    assert isinstance(Choice, type)    
    

# Generated at 2022-06-21 15:58:52.014218
# Unit test for constructor of class Choice
def test_Choice():
    foo = Choice()
    foo(items=[1, 2, 3], length=4, unique=True)
test_Choice()

# Generated at 2022-06-21 15:58:54.998075
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Tests __call__ method of Choice."""
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) == 'c'


# Generated at 2022-06-21 15:59:05.638861
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    class ChoiceExtended(Choice):
        def __init__(self, seed=None, datetime=None):
            super(ChoiceExtended, self).__init__(seed=seed, datetime=datetime)

    # Case 1
    choice = ChoiceExtended()
    assert choice(items=['a', 'b', 'c']) == 'c'

    # Case 2
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']

    # Case 3
    assert choice(items='abc', length=2) == 'ba'

    # Case 4
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')

    # Case 5

# Generated at 2022-06-21 15:59:08.601529
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choices = Choice()
    for _ in range(5):
        assert isnumber(choices(items=[1, 2, 3, 4, 5], length=5, unique=False))


# Generated at 2022-06-21 15:59:14.739746
# Unit test for constructor of class Choice
def test_Choice():
    # init
    choice = Choice()

    # get_random_choice
    items = [1, 2, 3, 4, 5]
    length = 2
    unique = False
    result = choice(items, length, unique)
    assert result in items

    # __call__
    items = [1, 2, 3]
    length = 4
    unique = False
    result = choice(items, length, unique)
    assert len(result) == length
    assert isinstance(result, list)

# Generated at 2022-06-21 15:59:22.368708
# Unit test for constructor of class Choice
def test_Choice():
    test_choice = Choice()
    test_choice(items=['a', 'b', 'c'])
    test_choice(items=['a', 'b', 'c'], length=1)
    test_choice(items=['a', 'b', 'c'], length=2, unique=True)
    test_choice(items=('a', 'b', 'c'), length=5)
    test_choice(items='aabbbccccddddd', length=4, unique=True)

    try:
        test_choice(items=())
    except ValueError:
        pass

    try:
        test_choice(items=('a', 'b', 'c'), length=5, unique=True)
    except ValueError:
        pass


# Generated at 2022-06-21 15:59:31.883518
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # (items, length, unique)
    test_cases = [
        # (items, length, unique)
        (['a', 'b', 'c'], 0, False),
        (['a', 'b', 'c'], 1, False),
        ('abc', 2, False),
        (('a', 'b', 'c'), 5, False),
        ('aabbbccccddddd', 4, True),
        # Check for non-sequence input
        (float(4), 1, True),
        (False, 1, True),
        # Check for negative length
        (['a', 'b', 'c'], -1, False)
    ]
    choice = Choice()
    for items, length, unique in test_cases:
        choice(items, length, unique)

# Generated at 2022-06-21 15:59:37.501191
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice.__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice.__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice.__call__(items='abc', length=2) == 'ba'
    assert Choice.__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice.__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    raise TypeError('**length** must be integer.')

    raise TypeError('**items** must be non-empty sequence.')

    raise ValueError('**items** must be a non-empty sequence.')

    raise

# Generated at 2022-06-21 15:59:58.602951
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    # Meta Class
    class Meta:
        name = 'choice'

    # Choice Class
    class Choice(BaseProvider):

        """Class for generating a random choice from items in a sequence."""

        class Meta:
            name = 'choice'

        def __init__(self, *args, **kwargs):
            """Initialize attributes.

            :param args: Arguments.
            :param kwargs: Keyword arguments.
            """
            super().__init__(*args, **kwargs)


# Generated at 2022-06-21 16:00:08.837457
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice.

    Run with pytest command.
    """
    choice = Choice()
    result = choice(['a', 'b', 'c'])
    assert result in ['a', 'b', 'c']
    result = choice(['a', 'b', 'c'], 1)
    assert result == ['a'] or result == ['b'] or result == ['c']
    result = choice('abc', 2)
    assert result == 'aa' or result == 'bb' or result == 'cc'
    result = choice('abc', 5)
    assert result == 'aaaaa' or result == 'bbbbb' or result == 'ccccc'
    result = choice('aabbbccccddddd', 4, unique=True)
    assert len(set(result)) == 4

# Generated at 2022-06-21 16:00:14.303508
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice is not None

# Unit tests for method __call__ of class Choice

# Generated at 2022-06-21 16:00:22.058525
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice

    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['c', 'a', 'b']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ba', 'bc', 'cb', 'ca', 'ab']
    assert choice(items=('a', 'b', 'c'), length=5) in [('c', 'a', 'a', 'b', 'c'), ('c', 'c', 'b', 'c', 'a')]
    assert choice(items='aabbbccccddddd', length=4, unique=True) in ['cdba', 'cdbc', 'cbcd']

# Generated at 2022-06-21 16:00:32.103573
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    result = Choice().__call__(length=0, unique=False)
    assert isinstance(result, str)

    result = Choice().__call__(items=['a', 'b', 'c'], length=1, unique=True)
    assert isinstance(result, list)

    result = Choice().__call__(items='abc', length=0, unique=True)
    assert isinstance(result, str)

    result = Choice().__call__(items='abc', length=0, unique=False)
    assert isinstance(result, str)

    result = Choice().__call__(items=[], length=5, unique=True)
    assert isinstance(result, list)

    result = Choice().__call__(items=['a', 'b', 'c'], length=0, unique=False)

# Generated at 2022-06-21 16:00:38.318129
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    c('items=["a", "b", "c"]')
    c('items=["a", "b", "c"], length=1')
    c('items=["a", "b", "c"], length=2')
    c('items=["a", "b", "c"], length=5')
    c('items=["a", "b", "c"], length=4, unique=True')


# Generated at 2022-06-21 16:00:40.572558
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice
    assert choice('abc') in {'a', 'b', 'c'}
    assert choice('abc', length=1) == 'c'

# Generated at 2022-06-21 16:00:43.047388
# Unit test for constructor of class Choice
def test_Choice():

    obj = Choice()

    assert isinstance(obj, Choice)

# Generated at 2022-06-21 16:00:47.848361
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.providers.choice import Choice
    choice=Choice()
    result1=choice(items=['a', 'b', 'c'])
    assert result1=='c'
    result2=choice(items=['a', 'b', 'c'], length=1)
    assert result2==['a']
    result3=choice(items='abc', length=2)
    assert result3=='ba'
    result4=choice(items=('a', 'b', 'c'), length=5)
    assert result4==('c', 'a', 'a', 'b', 'c')
    result5=choice(items='aabbbccccddddd', length=4, unique=True)
    assert result5=='cdba'

# Generated at 2022-06-21 16:00:49.924166
# Unit test for constructor of class Choice
def test_Choice():
    """Creates an object of Class Choice"""
    obj = Choice()
    assert isinstance(obj, Choice) == True


# Generated at 2022-06-21 16:01:23.726444
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    print(Choice().__call__())
    # print(Choice().__call__(items=None))

# Generated at 2022-06-21 16:01:32.579236
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    
    print(choice(items=['a', 'b', 'c']))
    # choice.random.seed(0)
    # assert choice(items=['a', 'b', 'c']) == 'c'
    # 
    # choice.random.seed(1)
    # assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    # 
    # choice.random.seed(2)
    # assert choice(items='abc', length=2) == 'ba'
    # 
    # choice.random.seed(3)
    # assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    # 
    # choice.random.seed(4)

# Generated at 2022-06-21 16:01:33.375040
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()


# Generated at 2022-06-21 16:01:34.397857
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice().__init__() == None


# Generated at 2022-06-21 16:01:39.646420
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

"""
Auxiliary functions used for testing the basic behaviour of numpy ndarray
objects.

Note that these functions are only intended to be called by tests.
"""

import numpy as np
import collections.abc


# Generated at 2022-06-21 16:01:49.038340
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    seq = ['a', 'b', 'c']
    assert Choice().__call__(seq) in seq
    assert Choice().__call__(seq, length=1)[0] in seq
    assert Choice().__call__('abc', length=2) in  ['ab', 'ac', 'bc']

# Generated at 2022-06-21 16:01:57.226187
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 5
    unique = True

    data = []  # type: ignore
    if unique and len(set(items)) < length:  # avoid an infinite while loop
        raise ValueError('There are not enough unique elements in '
                         '**items** to provide the specified **number**.')
    while len(data) < length:
        item = Choice.random.choice(items)
        if (unique and item not in data) or not unique:
            data.append(item)

    # TODO: Always return list
    if isinstance(items, list):
        return data
    elif isinstance(items, tuple):
        return tuple(data)
    return ''.join(data)

# Generated at 2022-06-21 16:02:00.792379
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 1
    unique = True

    assert choice(items=items, length=length, unique=unique) == 'c'

# Generated at 2022-06-21 16:02:09.781168
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from random import randint
    from string import ascii_letters
    # Expect TypeError on non-sequence items
    try:
        print(Choice()(items='abc', length=2, unique=False))
        assert False
    except TypeError:
        pass
    # Expect TypeError on non-integer length
    try:
        print(Choice()(items='abc', length=2.0, unique=False))
        assert False
    except TypeError:
        pass
    # Expect ValueError on negative length
    try:
        print(Choice()(items=['a', 'b', 'c'], length=-1))
        assert False
    except ValueError:
        pass
    # Expect ValueError on insufficient unique elements

# Generated at 2022-06-21 16:02:11.295616
# Unit test for constructor of class Choice
def test_Choice():
    print("Testing Constructor of Choice")
    choice = Choice()
    print(choice.__dict__)
    return choice


# Generated at 2022-06-21 16:03:05.010416
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'

# Generated at 2022-06-21 16:03:10.406231
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice.random.choice(['a', 'b', 'c']) == 'c'
    assert choice.random.choice('abc') in list('abc')
    assert isinstance(choice.random.choice('abc'), str)
    assert choice.random.choice(('a', 'b', 'c')) in list(('a', 'b', 'c'))
    assert isinstance(choice.random.choice(('a', 'b', 'c')), tuple)

    assert choice(['a', 'b', 'c']) == 'c'
    assert isinstance(choice(['a', 'b', 'c']), str)
    assert choice(['a', 'b', 'c'], length=1) == ['a']

# Generated at 2022-06-21 16:03:20.354045
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    
    choice = Choice()
    
    # Case 1: items is a list of strings and length is 0
    assert choice(items=['a', 'b', 'c']) == 'c'

    # Case 2: items is a list of strings and length is 1
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    
    # Case 3: items is string and length is 2
    assert choice(items='abc', length=2) == 'ba'

    # Case 4: items is a tuple and length is 5
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')

    # Case 5: items is a string and length is 4 and unique is True

# Generated at 2022-06-21 16:03:24.832975
# Unit test for constructor of class Choice
def test_Choice():
    provider = Choice()
    for i in range(0, len(provider(items=["a", "b", "c"]))):
        print(provider(items=["a", "b", "c"]))
    print(provider(items=["a", "b", "c"], length=5))
    print(provider(items=["a", "b", "c"], length=5, unique=True))
    print(provider(items="abc", length=2))

# Unit test when the length is 0

# Generated at 2022-06-21 16:03:30.419046
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    items = ['a','b','c','d']
    length = 4
    test_choice = choice(items,length)
    correct_choice = ['c','d','a','a']
    assert test_choice == correct_choice


# Generated at 2022-06-21 16:03:39.621345
# Unit test for method __call__ of class Choice

# Generated at 2022-06-21 16:03:44.538216
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    with Choice() as c:
        assert isinstance(c(items=['a', 'b', 'c']), str)
        assert c(items=['a', 'b', 'c']) in ['a', 'b', 'c']
        assert isinstance(c(items=['a', 'b', 'c'], length=1), list)
        assert c(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
        assert isinstance(c(items='abc', length=2), str)
        assert c(items='abc', length=2) in ['ab', 'ba', 'ac', 'ca', 'bc', 'cb']
        assert isinstance(c(items=('a', 'b', 'c'), length=5), tuple)

# Generated at 2022-06-21 16:03:47.866629
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis import Choice
    choice = Choice()
    assert choice
    assert isinstance(choice, Choice)
    assert isinstance(choice, BaseProvider)
    assert isinstance(choice, Choice)
    assert isinstance(choice, BaseProvider)


# Generated at 2022-06-21 16:03:52.473455
# Unit test for constructor of class Choice
def test_Choice():
    temp = Choice("en")
    assert (isinstance(temp, Choice))
    assert (hasattr(temp, "Meta"))
    assert (temp.Meta.name == "choice")
    assert (temp.random is not None)
    assert (temp.__doc__ is not None)



# Generated at 2022-06-21 16:04:01.641666
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()

    # Positive
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    
    # Negative
    try:
        assert choice(items=2)
    except TypeError:
        pass
    else:
        raise Exception('The length must be integer.')
