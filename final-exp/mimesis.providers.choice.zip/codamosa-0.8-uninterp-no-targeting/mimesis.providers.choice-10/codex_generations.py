

# Generated at 2022-06-21 15:56:39.738756
# Unit test for constructor of class Choice
def test_Choice():
    
    # Reduces redundancies of code
    def test_with_type_error(choice, t_type, p, p_type, expected):
        with pytest.raises(t_type) as e:
            getattr(choice, p)(getattr(choice, p_type)(expected))
            assert str(e.value) == f"**{p}** must be {p_type}."
    
    def testing(choice, items, length, unique, expected):
        result = choice(items, length, unique)

        # Raises TypeError for non-sequence items
        test_with_type_error(choice, TypeError, 'choice', 'address', 'USA')
        test_with_type_error(choice, TypeError, 'choice', 'code', '12345')

        # Raises TypeError for non-integer length


# Generated at 2022-06-21 15:56:40.955307
# Unit test for constructor of class Choice
def test_Choice():
    d = Choice()
    print(d())

# Generated at 2022-06-21 15:56:54.348953
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 1
    unique = False

    assert type(items) == list
    assert len(items) > 0
    assert type(length) == int
    assert length >= 0

    # Test
    choice = Choice()
    output = choice(items=items)
    assert output in items
    assert type(output) == str
    output = choice(items=items, length=length)
    assert output in items
    if type(output) == list:
        assert len(output) == length
        assert set(output).issubset(set(items))
    elif type(output) == tuple:
        assert len(output) == length
        assert set(output).issubset(set(items))
    else:
        assert len(output) == length

# Generated at 2022-06-21 15:56:56.779903
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method __call__ of class Choice."""
    # TODO: Unit test for method __call__ of class Choice
    pass

# Generated at 2022-06-21 15:57:03.293657
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    print(c(items=['a', 'b', 'c'], length=3, unique=False))
    print(c(items=['a', 'b', 'c'], length=3, unique=True))
    print(c(items=['a', 'b', 'c'], length=2, unique=True))
    print(c(items=['a', 'b', 'c'], length=1, unique=True))
    print(c(items='abc', length=3, unique=False))
    print(c(items='abc', length=3, unique=True))

# Generated at 2022-06-21 15:57:14.167631
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method __call__ of class Choice."""
    from mimesis import Choice
    choice = Choice()
    items = ['a', 'b', 'c']
    assert choice(items) in items
    assert choice(items=items, length=1) == ['a']
    assert choice(items='abc', length=2) in ['ba', 'ab', 'cb']
    assert choice(items=('a', 'b', 'c'), length=5) in [
        ('a', 'c', 'c', 'b', 'b'),
        ('c', 'c', 'b', 'b', 'c'),
        ('c', 'b', 'c', 'a', 'c')
    ]

# Generated at 2022-06-21 15:57:15.988232
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 1
    assert choice(items, length) == ['a']

# Generated at 2022-06-21 15:57:17.417374
# Unit test for constructor of class Choice
def test_Choice():
    # TODO: Test if __init__ function has a parameters named `random`
    pass


# Generated at 2022-06-21 15:57:26.662387
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from hypothesis import given
    from hypothesis.strategies import integers
    from hypothesis.strategies import lists
    from hypothesis.strategies import tuples
    from hypothesis.strategies import text
    from hypothesis.strategies import one_of

    @given(integers(min_value=-1))
    def test_raises_ValueError_for_non_positive_length(length):
        from pytest import raises
        from mimesis.exceptions import NonPositiveNumber

        with raises(NonPositiveNumber):
            choice = Choice()
            choice(items=[1, 2, 3], length=length)

    def test_raises_TypeError_for_non_sequence_items():
        from pytest import raises
        from mimesis.exceptions import NonSequence

        with raises(NonSequence):
            choice = Choice

# Generated at 2022-06-21 15:57:35.856683
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    print(choice(items=['a', 'b', 'c']))
    print(choice(items=['a', 'b', 'c'], length=1))
    print(choice(items='abc', length=2))
    print(choice(items=('a', 'b', 'c'), length=5))
    print(choice(items='aabbbccccddddd', length=4, unique=True))
    # print(choice(items=['a', 'b', 'c'], length='two'))
    # print(choice(items=['a', 'b', 'c']))
    # print(choice(items=5, length=5))


# Generated at 2022-06-21 15:57:50.799290
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=list('abc')) == 'c'
    assert Choice().__call__(items=list('abc'), length=1) == ['a']
    assert Choice().__call__(items=str('abc'), length=2) == 'ba'
    assert Choice().__call__(items=tuple('abc'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'



# Generated at 2022-06-21 15:57:58.095047
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    print(choice(items=['a', 'b', 'c']))
    print(choice(items=['a', 'b', 'c'], length=1))
    print(choice(items='abc', length=2))
    print(choice(items=('a', 'b', 'c'), length=5))
    print(choice(items='aabbbccccddddd', length=4, unique=True))



if __name__ == '__main__':
    test_Choice()

# Generated at 2022-06-21 15:58:03.118910
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    print(choice(items=['a','b','c']))
    print(choice(items=['a','b','c'], length=1))
    print(choice(items='abc', length=2))
    print(choice(items=('a','b','c'), length=5))
    print(choice(items='aabbbccccddddd', length=4, unique=True))

test_Choice()

# Generated at 2022-06-21 15:58:04.725895
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice


## Unit test for method __call__ of class Choice

# Generated at 2022-06-21 15:58:05.962083
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TODO: Create unit test
    pass


# Generated at 2022-06-21 15:58:14.863679
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in {'a', 'b', 'c'}
    assert choice(items=['a', 'b', 'c'], length=1) in {['a'], ['b'], ['c']}
    assert choice(items='abc', length=2) in {'ba', 'ab', 'cb'}

# Generated at 2022-06-21 15:58:25.502020
# Unit test for constructor of class Choice
def test_Choice():
    choices = Choice()
    len_items = len(choices(length=10, items=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']))
    assert len_items == 10
    items = choices(length=10, items=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'])

# Generated at 2022-06-21 15:58:26.474643
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass


# Generated at 2022-06-21 15:58:41.111002
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # __init__ and __call__ methods
    assert Choice().__class__.__init__.__doc__ is not None
    assert Choice().__class__.__call__.__doc__ is not None

    # examples provided in docstrings
    assert Choice()(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert Choice()(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice()(items='abc', length=2) in ['ba', 'ab', 'cb']
    assert Choice()(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')

# Generated at 2022-06-21 15:58:46.095386
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()

    assert choice(items=['a', 'b', 'c'])
    assert choice(items=['a', 'b', 'c'], length=1)
    assert choice(items='abc', length=2)
    assert choice(items=('a', 'b', 'c'), length=5)
    assert choice(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-21 15:58:54.596226
# Unit test for constructor of class Choice
def test_Choice():
    pass

# Generated at 2022-06-21 15:58:58.335260
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.providers.choice import Choice
    result = Choice().__call__(items=['a', 'b', 'c'])
    assert result in ['a', 'b', 'c']

# Generated at 2022-06-21 15:59:05.761385
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-21 15:59:06.646126
# Unit test for constructor of class Choice
def test_Choice():
    """ Unit test for constructor of class Choice. """
    pass

# Generated at 2022-06-21 15:59:16.067988
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert c.choice.__call__(['a', 'b', 'c']) in ['a', 'b', 'c']
    assert c.choice.__call__(['a', 'b', 'c'], 2) in ['a', 'b', 'c']
    assert c.choice.__call__(['a', 'b', 'c'], 3, True) in ['a', 'b', 'c']
    assert c.choice.__call__(['a', 'b', 'c', 'c'], 3, True) in ['a', 'b', 'c']
    assert c.choice.__call__(['a', 'b', 'c', 'c'], 3, False) in ['a', 'b', 'c']

# Generated at 2022-06-21 15:59:21.339006
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice()(items=['a', 'b', 'c']) == 'c'
    assert Choice()(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice()(items='abc', length=2) == 'ba'
    assert Choice()(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice()(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-21 15:59:24.501104
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    data = choice(items=['a','b','c','d','e','f','g','h'], length=2)
    assert len(data) == 2


# Generated at 2022-06-21 15:59:32.289515
# Unit test for constructor of class Choice
def test_Choice():
    """Test class Choice."""
    choice = Choice()
    assert choice is not None
    assert choice(items=['a', 'b', 'c']) == 'b'
    assert choice(items=['a', 'b', 'c'], length=1) == ['b']
    assert choice(items='abc', length=2) == 'bb'
    assert choice(items=('a', 'b', 'c'), length=5) == ('b', 'c', 'b', 'c', 'c')
    assert choice(items=[1, 2, 3], length=3, unique=True) == [3, 2, 1]


# Generated at 2022-06-21 15:59:33.724003
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    data = c(['a','b','c','d'], 2)
    assert type(data) == list
    print(data)

# Generated at 2022-06-21 15:59:37.162353
# Unit test for constructor of class Choice
def test_Choice():
    """
    Qualitative test for constructor of class Choice.
    """
    c = Choice()
    assert len(c.data) == 0
    assert not c.seed



# Generated at 2022-06-21 15:59:56.616873
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    choice(items=[1,2,3], length=1)
    choice(items=[1,2,3], length=1, unique=False)
    choice(items=[1,2,3], length=1, unique=True)
    choice(items=[1,2,3], length=2)
    choice(items=[1,2,3], length=2, unique=False)
    choice(items=[1,2,3], length=2, unique=True)
    choice(items=[1,2,3], length=4)
    choice(items=[1,2,3], length=4, unique=False)
    choice(items=[1,2,3], length=4, unique=True)
    choice(items=[1,2,3], length=5)

# Generated at 2022-06-21 16:00:03.800953
# Unit test for constructor of class Choice
def test_Choice():
    """Unit test for constructor of class Choice."""
    class_ = Choice()

    class_.random.choice(items=['a', 'b', 'c'])
    class_.random.choice(items='abc', length=2)
    class_.random.choice(items=['a', 'b', 'c'], length=5)
    class_.random.choice(items=['a', 'b', 'c'], length=5, unique=True)


# Generated at 2022-06-21 16:00:05.299832
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    print(f'in __call__(): {c("abc", 2, True)}')

# Generated at 2022-06-21 16:00:15.449849
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import DataType
    from mimesis.exceptions import NonEnumerableError
    from mimesis.typing import AnyDataType
    from mimesis.typing import SequenceDataType
    choice_ = Choice()
    items = choice_.datetime(
        pattern='%Y%m%d',
        start='19990101',
        end='20001231',
    )
    assert (choice_.__call__(items=items)
            in ('19990127', '19990122', '19990123', '19990125', '19990129',
                '19990120', '19990101'))

# Generated at 2022-06-21 16:00:18.159806
# Unit test for constructor of class Choice
def test_Choice():
    obj = Choice()
    obj.seed(0)
    assert str(obj('abc')) == 'b'
    assert str(obj('abc', length=2, unique=True)) == 'ac'
    assert str(obj('abc', length=1)) == 'c'

# Generated at 2022-06-21 16:00:19.257129
# Unit test for constructor of class Choice
def test_Choice():
    value = Choice()
    assert isinstance(value, Choice), 'Not initialized'

# Generated at 2022-06-21 16:00:22.810001
# Unit test for constructor of class Choice
def test_Choice():

    choice = Choice()
    choice(items=['a', 'b', 'c'])
    choice(items=['a', 'b', 'c'], length=1)
    choice(items='abc', length=2)
    choice(items=('a', 'b', 'c'), length=5)
    choice(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-21 16:00:24.444165
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()


# Generated at 2022-06-21 16:00:26.445740
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice is not None

# Generated at 2022-06-21 16:00:28.658561
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c', 'd', 'e', 'f']
    length = 3
    unique = False

    return not isinstance(Choice().__call__(items, length, unique), list)



# Generated at 2022-06-21 16:01:49.595962
# Unit test for constructor of class Choice
def test_Choice():
    """Test class Choice"""
    obj = Choice()
    assert str(obj.items()) == "Choice('a', 'b')"


# Generated at 2022-06-21 16:01:52.406185
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Arrange
    choice = Choice()

    # Act
    actual = choice(items=['a', 'b', 'c'])

    # Assert
    assert actual in ('a', 'b', 'c')



# Generated at 2022-06-21 16:02:00.030008
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender

    choice = Choice()

    assert choice(items=['a', 'b', 'c'], length=0) in ('a', 'b', 'c'), "Failed."
    assert choice(items=['a', 'b', 'c'], length=4) in ('a', 'b', 'c'), "Failed."

    assert(choice(items=['a', 'b', 'c'], length=None, unique=True) in ('a', 'b', 'c')), "Failed."
    assert(choice(items=['a', 'b', 'c'], length=None, unique=False) in ('a', 'b', 'c')), "Failed."


# Generated at 2022-06-21 16:02:08.096792
# Unit test for constructor of class Choice
def test_Choice():
    Choice = Choice()
    data = Choice(['a', 'b', 'c'])
    assert data == 'c'
    data = Choice(items=['a', 'b', 'c'], length=1)
    assert data == ['a']
    data = Choice(items='abc', length=2)
    assert data == 'ba'
    data = Choice(items=('a', 'b', 'c'), length=5)
    assert data == ('c', 'a', 'a', 'b', 'c')
    data = Choice(items='aabbbccccddddd', length=4, unique=True)
    assert data == 'cdba'

# Generated at 2022-06-21 16:02:15.985190
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis import Ability
    from mimesis.enums import Ability as AbilityEnum

    ab = Ability()
    assert isinstance(ab.field(AbilityEnum.INTELLIGENCE), list) is True
    assert isinstance(ab.field(AbilityEnum.WISDOM), list) is True
    assert isinstance(ab.field(), list) is True
    assert isinstance(ab.strength(), int) is True
    assert isinstance(ab.dexterity(), int) is True
    assert isinstance(ab.constitution(), int) is True
    assert isinstance(ab.intelligence(), int) is True
    assert isinstance(ab.wisdom(), int) is True
    assert isinstance(ab.charisma(), int) is True



# Generated at 2022-06-21 16:02:24.791067
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method `__call__` of class `Choice`."""
    # Positive tests
    print(':::POSITIVE TESTS:::')
    print('Test #1')
    choice = Choice()
    print(
        choice(items=['a', 'b', 'c'])
    )
    print('Test #2')
    choice = Choice()
    print(
        choice(items=['a', 'b', 'c'], length=1)
    )
    print('Test #3')
    choice = Choice()
    print(
        choice(items='abc', length=2)
    )
    print('Test #4')
    choice = Choice()
    print(
        choice(items=('a', 'b', 'c'), length=5)
    )
    print('Test #5')

# Generated at 2022-06-21 16:02:35.492412
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.typing import GenderEnum
    from datetime import datetime
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.address import Address
    from mimesis.enums import AddressType
    from mimesis.typing import AddressTypeEnum
    from mimesis.providers.business import Business
    from mimesis.providers.internet import Internet
    from mimesis.providers.science import Science
    from mimesis.providers.code import Code
    from mimesis.enums import Industry
    from mimesis.typing import IndustryEnum
    from mimesis.providers.currency import Currency

# Generated at 2022-06-21 16:02:37.599908
# Unit test for constructor of class Choice
def test_Choice():
    test = Choice()
    assert str(type(Choice())) == "<class 'mimesis.data.Choice'>"
    assert isinstance(Choice(), Choice)


# Generated at 2022-06-21 16:02:39.397920
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert(isinstance(c, Choice))

# Generated at 2022-06-21 16:02:48.949271
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import pytest
    provider = Choice()
    with pytest.raises(TypeError):
        provider(items=['a', 'b', 'c'], length='1')

    with pytest.raises(ValueError):
        provider(items=['a', 'b', 'c'], length=-1)

    with pytest.raises(TypeError):
        provider(items=1, length=1)

    with pytest.raises(ValueError):
        provider(items=[], length=1)

    data = provider(items=['a', 'b', 'c'], length=1)
    assert isinstance(data, list)
    assert len(data) == 1
    assert data[0] in ['a', 'b', 'c']

    data = provider(items=['a', 'b', 'c'])
   

# Generated at 2022-06-21 16:05:36.263748
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender

    c = Choice("en",Gender.MALE)
    print(c.choice("M F").__call__("M F"))

    c = Choice("en",Gender.MALE)
    print(c.choice("M F").__call__("M F"))
    print(c.choice("M F").__call__(["M", "F"]))
    print(c.choice("M F").__call__(["M", "F"], 1))
    print(c.choice("M F").__call__("MF", 1, False))
    print(c.choice("M F").__call__("MF", 2, False))
    print(c.choice("M F").__call__("MF", 2, True))

# Generated at 2022-06-21 16:05:46.735303
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender
    from mimesis.enums import Person as PersonEnums
    from mimesis.providers.bases import BaseProvider

    choice = Choice()

    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) in ['ab', 'ac', 'bc']
    assert choice(items=('a', 'b', 'c'), length=5) in [('a', 'b', 'c', 'a', 'b')]
    assert choice(items='aabbbccccddddd', length=4, unique=True) in ['cdba', 'cdbd', 'cdad']

   

# Generated at 2022-06-21 16:05:56.037423
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice('abc') in ['a', 'b', 'c']
    assert choice('abc', 1) == ['c']
    assert choice('abc', 2) in ['bc', 'ca', 'ac']
    assert choice('abc', 5) in ['c', 'a', 'b', 'c', 'a', 'b', 'c']
    assert choice('aabbbccccddddd', 4, True) in ['cdba', 'dbac', 'cbad']
    assert choice('aabbbccccddddd', 4, False) in ['cdba', 'dbac', 'cbad',
                                                  'cbad', 'cdba', 'cdda']

# Generated at 2022-06-21 16:06:04.830387
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from hypothesis import strategies as st
    from hypothesis import example, given

    from . import strategies as s

    @given(st.lists(s.items()))
    def test_empty_items(items):
        choice = Choice()
        if len(items) == 0:
            with pytest.raises(ValueError):
                choice(items=items)
        else:
            assert choice(items=items) in items

    @given(st.tuples(s.items()))
    def test_empty_items(items):
        choice = Choice()
        if len(items) == 0:
            with pytest.raises(ValueError):
                choice(items=items)
        else:
            assert choice(items=items) in items


# Generated at 2022-06-21 16:06:06.761557
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    obj = Choice()
    obj(['a', 'b', 'c'], 3, True)

# Generated at 2022-06-21 16:06:07.296671
# Unit test for constructor of class Choice
def test_Choice():
    pass


# Generated at 2022-06-21 16:06:08.135626
# Unit test for constructor of class Choice
def test_Choice():
    assert isinstance(Choice(), Choice)


# Generated at 2022-06-21 16:06:10.551576
# Unit test for constructor of class Choice
def test_Choice():
    """Unit test for constructor of class Choice."""
    from mimesis import Choice
    choice = Choice()
    assert isinstance(choice, Choice)
    assert isinstance(choice.random, Choice)


# Generated at 2022-06-21 16:06:15.994216
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    choice.choice(items=['a', 'b', 'c'])
    assert choice.choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice.choice(items='abc', length=2) == 'ba'
    assert choice.choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice.choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    assert choice.choice(items='aabbbccccddddd', length=0, unique=True) == ''

# Generated at 2022-06-21 16:06:17.406419
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    pass