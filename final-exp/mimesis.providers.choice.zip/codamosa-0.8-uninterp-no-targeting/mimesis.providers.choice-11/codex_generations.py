

# Generated at 2022-06-21 15:56:25.923262
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice is not None

# Generated at 2022-06-21 15:56:37.162413
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice: Choice = Choice()
    # test default return value
    assert choice(items=['a', 'b', 'c']) in ('a', 'b', 'c')
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) in ('ba', 'ab', 'ac', 'bc')

# Generated at 2022-06-21 15:56:38.429878
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice().__class__.__name__ == "Choice"

# Generated at 2022-06-21 15:56:39.770193
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert c() == 'c'


# Generated at 2022-06-21 15:56:46.079566
# Unit test for constructor of class Choice
def test_Choice():
    print("\n#Unit test for constructor of class Choice")
    print(Choice.__init__.__doc__)
    # 1. call with no argument
    c1 = Choice()
    assert c1 is not None
    # 2. call with argument
    c2 = Choice(seed=0)
    assert c2 is not None


# Generated at 2022-06-21 15:56:47.534313
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice is not None

# Generated at 2022-06-21 15:56:56.411572
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.schema import Field

    choice = Choice('ru')
    data_schema = {
        'key': Field('text.word', pattern='^a+b+c+d+$'),
        'value': Field('choice', items='1234567890', length=3, unique=True)
    }
    data = {
        'key': 'aabbbcccddddd',
        'value': [1, 2, 3]
    }

    # TODO: Still returns list
    assert data_schema['value'].func(choice) == data['value']

# Generated at 2022-06-21 15:56:57.851540
# Unit test for constructor of class Choice
def test_Choice():
    """Unit tests for Choice.__init__()"""
    choice = Choice(locale='en')

# Unit tests for Choice.items()

# Generated at 2022-06-21 15:56:59.793152
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert str(Choice().__call__(items='test', length=5)) == 'testt'

# Generated at 2022-06-21 15:57:09.991364
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()

    # test the return of the function call
    assert c(['a', 'b', 'c']) in ['a', 'b', 'c']
    assert c(['a', 'b', 'c', 'd'], 2) in [['a', 'd'], ['a', 'b'], ['a', 'c'], ['b', 'c'], ['b', 'd'], ['c', 'd']]
    assert isinstance(c(['a', 'b', 'c'], 2), list)
    assert c('abc') in ['a', 'b', 'c']
    assert c(['a', 'b', 'c'], 2, True) in [['a', 'b'], ['a', 'c'], ['b', 'c']]

# Generated at 2022-06-21 15:57:19.531472
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-21 15:57:20.970744
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice()


# Generated at 2022-06-21 15:57:25.773771
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()

    choice(items=['a', 'b', 'c'])
    choice(items=['a', 'b', 'c'], length=1)
    choice(items='abc', length=2)
    choice(items=('a', 'b', 'c'), length=5)
    choice(items='aabbbccccddddd', length=4, unique=True)


# Generated at 2022-06-21 15:57:36.798921
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    requirement_id = 2
    requirement_status = 0

    print(requirement_id, " - ", end="")
    if len(sys.argv) == 1:
        print("Run with '-v' flag for more information.")
    else:
        if len(sys.argv) == 2 and sys.argv[1] == "-v":
            print("Verbose mode enabled.")
        else:
            requirement_status = 1
            print("Run with '-v' flag for more information.")
    for i in range(4):
        print(i + 1, " - ", end="")
        choice = Choice()

# Generated at 2022-06-21 15:57:46.804108
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ab', 'ac', 'bc', 'ba', 'ca', 'cb']
    assert choice(items=('a', 'b', 'c'), length=5) in [('a', 'b', 'c', 'a', 'b'), ('c', 'a', 'b', 'c', 'a'), ('c', 'a', 'b', 'c', 'c')]

# Generated at 2022-06-21 15:57:47.244413
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice()

# Generated at 2022-06-21 15:57:54.847717
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    items = item_list = ['a', 'b', 'c']
    length = 10
    unique = True
    result = choice(items=items, length=length, unique=unique)
    if not isinstance(result, list) or not set(item_list)==set(result) or result.count('a') + result.count('b') + result.count('c') != length:
        raise Exception("Feature extraction failed")


# Generated at 2022-06-21 15:58:03.797465
# Unit test for constructor of class Choice
def test_Choice():
    # test constructor of class Choice
    choice_provider = Choice()
    test_doc = """
        >>> from mimesis import Choice
        >>> choice = Choice()

        >>> choice(items=['a', 'b', 'c'])
        'c'
        >>> choice(items=['a', 'b', 'c'], length=1)
        ['a']
        >>> choice(items='abc', length=2)
        'ba'
        >>> choice(items=('a', 'b', 'c'), length=5)
        ('c', 'a', 'a', 'b', 'c')
        >>> choice(items='aabbbccccddddd', length=4, unique=True)
        'cdba'
    """
    exec(test_doc)
    # if no error raise, means test passed

# Generated at 2022-06-21 15:58:13.195609
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    result = choice(items=['a', 'b', 'c'])
    assert isinstance(result, str)
    assert result == 'a' or result == 'b' or result == 'c'
    result = choice(items=['a', 'b', 'c'], length=1)
    assert isinstance(result, list)
    assert len(result) == 1
    result = choice(items='abc', length=2)
    assert isinstance(result, str)
    assert len(result) == 2
    result = choice(items=('a', 'b', 'c'), length=5)
    assert isinstance(result, tuple)
    assert len(result) == 5
    result = choice(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-21 15:58:23.305082
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['c', 'b', 'a']
    assert choice(items=['a', 'b', 'c'], length=0) in ['c', 'b', 'a']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ba', 'cb', 'ac', 'cb', 'ac', 'ba']

# Generated at 2022-06-21 15:58:47.047582
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice is not None


# Generated at 2022-06-21 15:58:51.039078
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice(seed=1)
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    assert choice(items=items, length=length, unique=unique) == 'c'
    # length = 1
    # unique = True
    # assert choice(items=items, length=length, unique=unique) == 'c'


# Generated at 2022-06-21 15:58:56.281912
# Unit test for constructor of class Choice
def test_Choice():
    obj = Choice()
    assert obj
    obj(items=['a', 'b', 'c'])
    obj(items=['a', 'b', 'c'], length=1)
    obj(items='abc', length=2)
    obj(items=('a', 'b', 'c'), length=5)
    obj(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-21 15:59:01.447544
# Unit test for constructor of class Choice
def test_Choice():
    assert type(Choice) == type
    c = Choice()
    assert type(c) == Choice
    assert type(c(items=[1, 2, 3], length=5)) == list
    assert type(c(items=(1, 2, 3), length=5)) == tuple
    assert type(c(items='abc', length=5)) == str


# Generated at 2022-06-21 15:59:11.627651
# Unit test for method __call__ of class Choice

# Generated at 2022-06-21 15:59:17.852056
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    choice = Choice()

    items1 = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']

    for i in range(100):

        print("\n")
        print(choice(items=items1, length=1))


if __name__ == '__main__':
    test_Choice___call__()

# Generated at 2022-06-21 15:59:28.921724
# Unit test for constructor of class Choice
def test_Choice():

    list1 = ['a', 'b', 'c']
    list2 = ['x', 'y', 'z']
    tuple1 = ('a', 'b', 'c')
    tuple2 = ('x', 'y', 'z')
    string1 = 'abc'
    string2 = 'xyz'

    choice = Choice()

    assert choice(items=list1) in ['a', 'b', 'c']
    assert choice(items=list2, length=1) in [['x'], ['y'], ['z']]
    assert choice(items=string1, length=2) in ['ac', 'ba', 'ab', 'ca', 'bc', 'cb']

# Generated at 2022-06-21 15:59:30.594285
# Unit test for constructor of class Choice
def test_Choice():
    """Test constructor of class Choice"""
    c = Choice()
    assert c is not None


# Generated at 2022-06-21 15:59:32.116677
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice(localization='Russian').choice().choice('123', 1) == '1'


# Generated at 2022-06-21 15:59:41.069961
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    provider1 = Choice('en')
    provider2 = Choice('ru_RU')
    provider3 = Choice('zh_CN')

    result1 = provider1('abc')
    assert isinstance(result1, str)
    assert result1 in 'abc'

    result2 = provider1('abc', 2)
    assert isinstance(result2, list)
    assert len(result2) == 2
    for i in result2:
        assert i in 'abc'

    result3 = provider2('abc', 3, True)
    assert isinstance(result3, str)
    assert len(result3) == 3
    assert ''.join(set(result3)) == result3

    result4 = provider3('abc', 0)
    assert isinstance(result4, str)
    assert result4 in 'abc'

# Generated at 2022-06-21 15:59:54.479613
# Unit test for constructor of class Choice
def test_Choice():
    data = Choice()
    result = data(items=['a', 'b', 'c'])
    assert result in ['a', 'b', 'c']

# Generated at 2022-06-21 15:59:55.527156
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis import Choice
    c = Choice()
    assert c is not None

# Generated at 2022-06-21 16:00:06.897121
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """ test_Choice___call__() -> None
    Unit test for method __call__ of class Choice
    """
    ch = Choice()
    s = ('a' , 'b', 'c', 'd', 'e', 'f', 'g')

    assert ch(s, length = 0) in s
    assert ch(s, unique = True) in s
    ss = ch(s, length = 3)
    assert len(ss) == 3
    assert len(set(ss)) <= 3
    ss = ch(s, length = 4, unique = True)
    assert len(ss) == 4
    assert len(set(ss)) == 4

    try:
        ch(5, length = 0)
        assert False
    except TypeError:
        pass

# Generated at 2022-06-21 16:00:08.727084
# Unit test for constructor of class Choice
def test_Choice():
    # noinspection PyUnusedLocal
    def test_constructor(c: Choice):
        pass

    test_constructor(Choice())



# Generated at 2022-06-21 16:00:14.958995
# Unit test for constructor of class Choice
def test_Choice():
    cc = Choice(seed=12345)
    items = [('a', 1), ('b', 2), ('c', 3)]
    print(cc(items, length=2))
    print(cc(items, length=2))
    print(cc(items, length=2))
    print(cc(items, length=5))
if __name__ == '__main__':
    test_Choice()

# Generated at 2022-06-21 16:00:22.161418
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    choice = Choice()
    unique_choice = Choice()
    # assert choice() == choice() or choice(unique=True) != choice(unique=True)
    assert choice(items=['a', 'b', 'c'])
    assert choice(items=['a', 'b', 'c'], length=1)
    assert choice(items='abc', length=2)
    assert choice(items=('a', 'b', 'c'), length=5)
    assert choice(items='aabbbccccddddd', length=4, unique=True)
    # assert choice(items=('a', 'b', 'c'), length=5, unique=True)
    # assert choice(items='aabbbccccddddd', length=10)
    # assert choice(items

# Generated at 2022-06-21 16:00:25.058160
# Unit test for constructor of class Choice
def test_Choice():
    choice_1 = Choice()
    assert isinstance(choice_1, Choice)


# Generated at 2022-06-21 16:00:32.029115
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-21 16:00:39.659370
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    print(c('0123456789', 11, True) == '0123456789') # True
    print(c('abcdefghijklmnopqrstuvwxyz', 5)) # 'srzvk'
    print(c('hello world', 0)) # ' '
    print(c('hello world', 1)) # ['w']
    print(c('hello world', 2)) # 'od'
    print(c('hello world', 0)) # ' '


if __name__ == '__main__':
    test_Choice___call__()

# Generated at 2022-06-21 16:00:48.615035
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert isinstance(Choice.__doc__, str)
    assert isinstance(Choice.__init__.__doc__, str)
    assert isinstance(c.__call__, collections.abc.Callable)
    assert isinstance(c.choice, collections.abc.Callable)
    assert isinstance(c.choices, collections.abc.Callable)
    assert isinstance(c.choices(['a', 'b', 'c'], length=1), list)
    assert isinstance(c.choices(['a', 'b', 'c'], length=1)[0], str)
    assert isinstance(c.choices(['a', 'b', 'c'], length=2), list)

# Generated at 2022-06-21 16:01:32.695217
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert (choice.__call__(items=['a', 'b', 'c'])) == 'c'
    assert (choice.__call__(items=['a', 'b', 'c'], length=1)) == ['a']
    assert (choice.__call__(items='abc', length=2)) == 'ba'
    assert (choice.__call__(items=('a', 'b', 'c'), length=5)) == ('c', 'a', 'a', 'b', 'c')
    assert (choice.__call__(items='aabbbccccddddd', length=4, unique=True)) == 'cdba'
    try:
        choice.__call__(items=None)
    except ValueError:
        assert True

# Generated at 2022-06-21 16:01:38.800571
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    drop_data = []

# Generated at 2022-06-21 16:01:48.531579
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    answer = choice(items=['a', 'b', 'c'])
    assert answer in ['a', 'b', 'c']
    assert type(answer) == str

    answer = choice(items=['a', 'b', 'c'], length=1)
    assert set(answer) == {'a'}
    assert type(answer) == list

    answer = choice(items='abc', length=2)
    assert set(answer) == {'a', 'b', 'c'}
    assert len(answer) == 2
    assert type(answer) == str

    answer = choice(items=('a', 'b', 'c'), length=5)
    assert set(answer) == {'a', 'b', 'c'}
    assert len(answer) == 5
    assert type(answer) == tuple

# Generated at 2022-06-21 16:01:50.773432
# Unit test for constructor of class Choice
def test_Choice():
    """
    Unit test for constructor of class Choice
    """
    c = Choice()
    assert c is not None


# Generated at 2022-06-21 16:01:53.562479
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    # TODO: Add a few more tests
    # if __name__ == '__main__':
    #     print(test_Choice___call__())
    #     pprint(test_Choice___call__())

# Generated at 2022-06-21 16:02:00.739335
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    from mimesis.enums import Gender, PersonPronoun, PersonTitle
    from mimesis.typing import GenderEnum, PersonPronounEnum, PersonTitleEnum

    # Test with choice of item from sequence, where sequence is list of
    # characters.
    choice = Choice()

    actual = choice(items=['a', 'b', 'c'])
    expected = 'c'
    assert actual == expected

    # Test with choice of item from sequence, where sequence is list of strings,
    # with length of provided list set to 1.
    actual = choice(items=['a', 'b', 'c'], length=1)
    expected = ['a']
    assert actual == expected

    # Test with choice of item from sequence, where sequence is list of
    # characters, with length of provided list set to 2.
    actual

# Generated at 2022-06-21 16:02:02.805476
# Unit test for constructor of class Choice
def test_Choice():
    print('\nTesting constructor of class Choice')
    choice = Choice()

    # This is a random test
    print(choice(items=['a', 'b', 'c']))

# Generated at 2022-06-21 16:02:03.926452
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice


# Generated at 2022-06-21 16:02:08.688818
# Unit test for constructor of class Choice

# Generated at 2022-06-21 16:02:09.138867
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

# Generated at 2022-06-21 16:04:04.675055
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length = 1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length = 2) in ['ab', 'bc', 'ac']

# Generated at 2022-06-21 16:04:07.626287
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice(seed=0).choice.__name__ == 'test_Choice.<locals>.__test__'

# Unit tests for call method of class Choice

# Generated at 2022-06-21 16:04:09.594453
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    choice.choice()

# Generated at 2022-06-21 16:04:15.270710
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice('a', 'b', 'c') in 'abc', "choice is incorrect"
    assert choice('aabbbccccddddd', 4, True) in 'abcd', "choice is incorrect"
    assert choice('aabbbccccddddd', 4, False) in 'aabbbccccddddd', "choice is incorrect"
    assert choice(1, 2, 3) in (1,2,3), "choice is incorrect"

# Generated at 2022-06-21 16:04:17.111553
# Unit test for constructor of class Choice
def test_Choice():
    inst = Choice()
    assert repr(inst) == "Choice()"
    assert str(inst) == "Choice()"


# Generated at 2022-06-21 16:04:18.396830
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice.__class__.__name__ == "Choice"


# Generated at 2022-06-21 16:04:24.702775
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)
    assert isinstance(choice._random, Choice)
    assert isinstance(choice._datetime, Choice)
    assert isinstance(choice._text, Choice)
    assert isinstance(choice._person, Choice)
    assert isinstance(choice._business, Choice)
    assert isinstance(choice._address, Choice)
    assert isinstance(choice._code, Choice)
    assert isinstance(choice._numbers, Choice)
    assert isinstance(choice._finance, Choice)
    assert isinstance(choice._internet, Choice)
    assert isinstance(choice._payment, Choice)
    assert isinstance(choice._hardware, Choice)
    assert isinstance(choice._software, Choice)
    assert isinstance(choice._files, Choice)
    assert isinstance(choice._science, Choice)

# Generated at 2022-06-21 16:04:25.941376
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert (isinstance(c, Choice))

# Generated at 2022-06-21 16:04:37.416757
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ('a', 'b', 'c')
    assert choice(items={'a', 'b', 'c'}) in ('a', 'b', 'c')
    assert choice(items=(1, 2, 3)) in (1, 2, 3)
    assert choice(items=(1, 2, 3), length=2) in ((1, 2), (1, 3), (2, 1), (2, 3), (3, 1), (3, 2))
    assert choice(items=(1, 2, 3), length=2, unique=True) in ((1, 2), (1, 3), (2, 3))
    assert choice(items='abc') in ('a', 'b', 'c')

# Generated at 2022-06-21 16:04:40.678489
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice()(items=[0, 1, 2], length=1) in [0, 1, 2]
    assert len(Choice()(items=[0, 1, 2], length=10, unique=True)) == 10
    assert len(Choice()(items=range(10), length=10)) == 10
