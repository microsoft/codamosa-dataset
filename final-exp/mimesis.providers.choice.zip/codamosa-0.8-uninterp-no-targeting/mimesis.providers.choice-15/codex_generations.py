

# Generated at 2022-06-21 15:56:19.747111
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice()

# Generated at 2022-06-21 15:56:20.323519
# Unit test for constructor of class Choice
def test_Choice():
    assert isinstance(Choice(), Choice) is True

# Generated at 2022-06-21 15:56:22.058189
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice()._meta.name == 'choice'


# Generated at 2022-06-21 15:56:25.654572
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()

    assert choice(items=['a', 'b', 'c'])
    assert choice(items='abc', length=2)
    assert choice(items=('a', 'b', 'c'), length=5)


# Generated at 2022-06-21 15:56:35.046439
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """ Unit test for method __call__ of class Choice"""
    from mimesis import Choice

    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['c']
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-21 15:56:37.285577
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)


# Generated at 2022-06-21 15:56:40.039478
# Unit test for constructor of class Choice
def test_Choice():
    """Test constructor of Choice class."""
    from mimesis.enums import Seed
    random = [1, 2, 3, 4, 5]
    choice = Choice(random=random, seed=Seed.SYS)
    assert choice._random is random

# Generated at 2022-06-21 15:56:53.311761
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    import random
    import string

    random.seed(0)
    choice = Choice(random)

    # Testing if length >= 0
    try:
        choice(items=['a', 'b', 'c'], length=-5)
        assert False, 'Test raised exception'
    except ValueError:
        assert True, 'Test did not throw exception'

    # Testing if length >= 0
    try:
        choice(items=['a', 'b', 'c'], length=-5)
        assert False, 'Test raised exception'
    except ValueError:
        assert True, 'Test did not throw exception'

    # Testing if number <= length

# Generated at 2022-06-21 15:57:02.978043
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    assert Choice()(['a', 'b']) in ['a', 'b']
    assert Choice()(tuple(['a', 'b'])) in ['a', 'b']
    assert Choice()('ab') in ['a', 'b']
    assert Choice()(tuple(['a', 'b']), length=2) in ['ab', 'ba']
    assert Choice()(['a', 'b'], length=2, unique=True) in ['ab', 'ba']
    assert Choice()(('a', 'b', 'c', 'd'), length=3, unique=True) \
        in ['abd', 'bac', 'dac', 'cad', 'dbc', 'acb', 'bcd', 'dcb', 'cdb', \
            'bad', 'dab', 'cbd']

# Generated at 2022-06-21 15:57:04.416967
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice is not None


# Generated at 2022-06-21 15:57:37.628953
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test function of Choice class"""
    choice = Choice()
    items = ['a', 'b', 'c']
    assert choice(items, 0) in ['a', 'b', 'c']
    assert choice(items, 1) == ['a']
    assert choice('abc', 2) in ['ba', 'bc', 'ca', 'cb']
    assert len(choice(('a', 'b', 'c'), 5)) == 5
    assert choice('aabbbccccddddd', 4,  True) in ['bddc', 'cadb', 'cadb', 'dcab', 'cabd']

if __name__ == '__main__':
    test_Choice___call__()

# Generated at 2022-06-21 15:57:44.501276
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    method_name = '__call__'
    provider = Choice()
    assert getattr(provider, method_name)(items=['a', 'b', 'c']) == 'c'
    assert getattr(provider, method_name)(items=['a', 'b', 'c'], length=1) == ['a']
    assert getattr(provider, method_name)(items='abc', length=2) == 'ba'
    assert getattr(provider, method_name)(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert getattr(provider, method_name)(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-21 15:57:48.269521
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    class MockChoice:
        def __init__(self):
            self.random = MockRandom()

    class MockRandom:
        def choice(self, item: list):
            return item[0]

    choice = MockChoice()

    assert choice.random.choice(['a', 'b']) == 'a'

# Generated at 2022-06-21 15:57:50.092596
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice() is not None

# Generated at 2022-06-21 15:57:55.723518
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for Choice.__call__ method."""

    items = [Choice() for i in range(10)]
    print(items)
    items = tuple(items)
    print(items)
    items = "".join(items)
    print(items)

    # length = Choice()
    # items = Choice()
    # unique = Choice()

# Generated at 2022-06-21 15:58:04.144952
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    from mimesis import Choice

    choice = Choice()

    # items is not a sequence
    items = 10
    length = 5
    unique = True
    assert choice(items=items, length=length, unique=unique) == None
    
    # items is empty
    items = []
    assert choice(items=items, length=length, unique=unique) == None

    # length is not an integer
    items = ['a', 'b', 'c']
    length = '5'
    assert choice(items=items, length=length, unique=unique) == None

    # length is negative
    length = -5
    assert choice(items=items, length=length, unique=unique) == None

    # unique is True and number of elements in items are less than length
    length = 10

# Generated at 2022-06-21 15:58:13.533586
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    try:
        choice(items=['a', 'b', 'c'], length='1')
        assert False
    except TypeError as e:
        assert str(e) == '**length** must be integer.'

# Generated at 2022-06-21 15:58:21.586661
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert isinstance(c(items=['a', 'b', 'c']), str)
    assert isinstance(c(items=['a', 'b', 'c'], length=1), list)
    assert isinstance(c(items='abc', length=2), str)
    assert isinstance(c(items=('a', 'b', 'c'), length=5), tuple)
    assert isinstance(c(items='aabbbccccddddd', length=4, unique=True), str)
    assert isinstance(c(items='aabbbccccddddd', length=4), str)

# Generated at 2022-06-21 15:58:26.120969
# Unit test for constructor of class Choice
def test_Choice():
    assert isinstance(Choice(), Choice)
    assert isinstance(Choice.__init__(Choice()), None)
    assert Choice().__doc__ == """Class for generating a random choice from items in a sequence."""
    assert Choice().__args__ == "(self, *args, **kwargs)"
    assert Choice().__init__.__args__ == "(self, *args, **kwargs)"

# Generated at 2022-06-21 15:58:29.045236
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice().random  # should not raise AttributeError
    assert Choice().random.seed  # should not raise AttributeError
    assert Choice().seed(42)  # should not raise AttributeError


# Generated at 2022-06-21 15:59:35.449962
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert isinstance(Choice()._Choice__call__(['a', 'b', 'c']), str)
    assert isinstance(Choice()._Choice__call__(['a', 'b', 'c'], length=1), list)
    assert isinstance(Choice()._Choice__call__('abc', length=2), str)
    assert isinstance(Choice()._Choice__call__(('a', 'b', 'c'), length=5), tuple)
    assert isinstance(Choice()._Choice__call__('aabbbccccddddd', length=4, unique=True), str)

# Generated at 2022-06-21 15:59:38.216378
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    # TODO: define assert
    test_obj = Choice()



# Generated at 2022-06-21 15:59:39.098597
# Unit test for constructor of class Choice
def test_Choice():
    obj_choice = Choice()
    assert obj_choice
    assert obj_choice.random



# Generated at 2022-06-21 15:59:50.770121
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import unittest
    class TestChoice___call__(unittest.TestCase):
        def test_base_case(self):
            import random
            from mimesis.providers.choice import Choice
            from mimesis.providers.generic import Generic
            from mimesis.enums import Gender
            from mimesis.typing import Sequence, Any
            from mimesis.providers.person import Person
            from mimesis.enums import Gender
            from mimesis.providers.date import Date
            from mimesis.enums import ClassMethod
            from mimesis.providers.person import Person
            from mimesis.providers.internet import Internet
            from mimesis.enums import ClassMethod
            from mimesis.providers.misc import Misc

# Generated at 2022-06-21 15:59:57.794790
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method __call__ of class Choice."""
    choice = Choice()
    item = choice(items=['a', 'b', 'c'])
    assert isinstance(item, str)
    item = choice(items=['a', 'b', 'c'], length=1)
    assert isinstance(item, list)
    item = choice(items='abc', length=2)
    assert isinstance(item, str)
    item = choice(items=('a', 'b', 'c'), length=5)
    assert isinstance(item, tuple)
    item = choice(items='aabbbccccddddd', length=4, unique=True)
    assert isinstance(item, str)

# Generated at 2022-06-21 16:00:04.316835
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    choice.random.choice
    choice(items=['a', 'b', 'c'], length=1)
    choice(items='abc', length=2)
    choice(items=('a', 'b', 'c'), length=5)
    choice(items='aabbbccccddddd', length=4, unique=True)
    return

if __name__ == '__main__':
    test_Choice()

# Generated at 2022-06-21 16:00:04.844745
# Unit test for constructor of class Choice
def test_Choice():
    Choice()

# Generated at 2022-06-21 16:00:15.136969
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import sys
    from random import seed
    from mimesis.providers.choice import Choice
    from mimesis.typing import Any, Sequence, Union
    from mimesis.enums import Gender

    seed(0)
    choice = Choice()
    items = ['a', 'b', 'c']
    assert choice(items=items) == 'a'
    assert choice(items=items, length=1) == ['a']
    assert choice(items='abc', length=2) == 'ca'
    assert choice(items=('a', 'b', 'c'), length=5) == ('a', 'b', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cbda'

# Generated at 2022-06-21 16:00:21.196732
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    choice.random.seed(0)
    assert choice('abc') == 'a'
    assert choice(items=['a', 'b', 'c'], length=1) == ['b']
    assert choice(items='abc', length=2) == 'ac'
    assert choice(items=('a', 'b', 'c'), length=5) == ('a', 'a', 'b', 'c', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'bcad'


# Generated at 2022-06-21 16:00:31.341716
# Unit test for constructor of class Choice
def test_Choice():
    """Function for testing class Choice"""
    choice = Choice()
    # a = choice(items=['a', 'b', 'c'], length=1)
    b = choice(items=['a', 'b', 'c'])
    # c = choice(items='abc', length=2)
    # d = choice(items=('a', 'b', 'c'), length=5)
    # e = choice(items='aabbbccccddddd', length=4, unique=True)
    # print(a)
    print(b)
    # print(c)
    # print(d)
    # print(e)


if __name__ == '__main__':
    test_Choice()

# Generated at 2022-06-21 16:02:13.769859
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice._Choice__call__(items=['a', 'b', 'c'], length=0, unique=True) in ['a', 'b', 'c'] and Choice(items=['a', 'b', 'c'], length=0, unique=True) in ['a', 'b', 'c'] and Choice.Meta.name == 'choice'

# Generated at 2022-06-21 16:02:23.606600
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    test = Choice()
    a = test(items, length, unique)
    assert a in items

    items = 'abc'
    length = 2
    unique = False
    test = Choice()
    a = test(items, length, unique)
    assert len(a) == 2
    assert a[0] in items
    assert a[1] in items

    items = ('a', 'b', 'c')
    length = 5
    unique = False
    test = Choice()
    a = test(items, length, unique)
    assert isinstance(a, tuple)
    assert len(a) == 5
    assert a[0] in items
    assert a[1] in items
    assert a[2] in items
    assert a

# Generated at 2022-06-21 16:02:24.339837
# Unit test for constructor of class Choice
def test_Choice():
    assert isinstance(Choice(), Choice) == True

# Generated at 2022-06-21 16:02:25.696592
# Unit test for constructor of class Choice
def test_Choice():
    print("Testing constructor of Choice:")
    choice = Choice()
    print(choice('abcd', 3, True))



# Generated at 2022-06-21 16:02:30.512406
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    
    # Test 1: class initialization
    choice = Choice()
    assert choice is not None, 'Test 1 failed'

    # Test 2: non-empty sequence items
    test_items = ['a', 'b', 'c']
    result = choice(items=test_items)
    assert result in test_items, 'Test 2 failed'

    # Test 3: non-empty sequence items and length 1
    result = choice(items=test_items, length=1)
    assert result == [test_items[0]], 'Test 3 failed'

    # Test 4: non-empty sequence items and length 2
    test_items = 'abc'
    result = choice(items=test_items, length=2)
    assert len(result) == 2, 'Test 4 failed'

    # Test 5: non-empty sequence items and length 5
    test

# Generated at 2022-06-21 16:02:32.880228
# Unit test for constructor of class Choice
def test_Choice():
    c=Choice()
    ch=c(['a','b'],2)
    assert ch=='ba'

# Generated at 2022-06-21 16:02:38.676968
# Unit test for constructor of class Choice
def test_Choice():
    c= Choice()
    assert c('a',1,False) == 'a'
    assert c(['a','b','c'],2,True) == ['c','b']
    assert c('a',1,True) == 'a'
    assert c(['a','b','c'],0,True) in ['c','b','a']
    assert c(['a','b','c'],1,False) in ['c','b','a']

# Generated at 2022-06-21 16:02:44.281727
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    print(choice(items=['a', 'b', 'c']))

    print(choice(items=['a', 'b', 'c'], length=1))
    print(choice(items='abc', length=2))
    print(choice(items=('a', 'b', 'c'), length=5))
    print(choice(items='aabbbccccddddd', length=4, unique=True))


if __name__ == '__main__':
    test_Choice___call__()

# Generated at 2022-06-21 16:02:44.800392
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice()

# Generated at 2022-06-21 16:02:47.379030
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'


# Generated at 2022-06-21 16:06:04.902339
# Unit test for constructor of class Choice
def test_Choice():
    Choice()

# Generated at 2022-06-21 16:06:09.357266
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a','b','c'])
    assert choice(items=['a','b','c'], length=1)
    assert choice(items='abc', length=2)
    assert choice(items=('a','b','c'), length=5)
    assert choice(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-21 16:06:14.918449
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice ()
    # test 1
    assert choice (items=['a', 'b', 'c']) == 'c'
    # test 2
    assert choice (items=['a', 'b', 'c'], length=1) == ['a']
    # test 3
    assert choice (items='abc', length=2) == 'ba'
    # test 4
    assert choice (items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    # test 5
    assert choice (items='aabbbccccddddd', length=4, unique=True) == 'cdba'