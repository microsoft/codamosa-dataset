

# Generated at 2022-06-21 15:56:19.158782
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice.Meta.name == 'choice'
    assert choice('abc', 0) == 'a'


# Generated at 2022-06-21 15:56:28.704328
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice('en')
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ac', 'ab', 'bc']

# Generated at 2022-06-21 15:56:31.698661
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    result = choice(items=['a', 'b', 'c'])
    assert result == 'c'



# Generated at 2022-06-21 15:56:40.873220
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    # Testing
    assert isinstance(c(items='abc', length=1), str)
    assert isinstance(c(items='abc', length=1), str)
    assert isinstance(c(items=('a', 'b', 'c'), length=2), tuple)
    assert isinstance(c(items=('a', 'b', 'c'), length=2), tuple)
    assert isinstance(c(items=('a', 'b', 'c'), length=2), tuple)
    assert isinstance(c(items=('a', 'b', 'c'), length=3), tuple)
    assert isinstance(c(items=('a', 'b', 'c'), length=3), tuple)
    assert isinstance(c(items=('a', 'b', 'c'), length=3), tuple)

# Generated at 2022-06-21 15:56:44.890725
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Calling __call__ should return list with given length
    choice = Choice()
    data = choice(items=['a', 'b', 'c'], length=5)
    assert len(data) == 5


# Generated at 2022-06-21 15:56:49.003193
# Unit test for constructor of class Choice
def test_Choice():
    from  mimesis import Choice
    choice_obj = Choice()
    assert isinstance(choice_obj, Choice)
    assert repr(choice_obj)
    assert str(choice_obj)


# Generated at 2022-06-21 15:56:50.181491
# Unit test for constructor of class Choice
def test_Choice():
    ch = Choice()
    assert ch



# Generated at 2022-06-21 15:56:51.109773
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-21 15:56:58.672299
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    print(c(items=['a', 'b', 'c']))
    print(c(items=['a', 'b', 'c'], length=1))
    print(c(items='abc', length=2))
    print(c(items=('a', 'b', 'c'), length=5))
    print(c(items='aabbbccccddddd', length=4, unique=True))

if __name__ == '__main__':
    test_Choice___call__()

# Generated at 2022-06-21 15:57:03.134558
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    global items
    global length
    global unique
    choice = Choice()
    choice(items=['a', 'b', 'c'])
    choice(items=['a', 'b', 'c'], length=1)
    choice(items='abc', length=2)
    choice(items=('a', 'b', 'c'), length=5)
    choice(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-21 15:57:16.391002
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    c = Choice()
    assert isinstance(c(items=['a', 'b', 'c', 'd']), str)
    assert c(items=['a', 'b', 'c', 'd']) in ['a', 'b', 'c', 'd']
    assert isinstance(c(items=('a', 'b', 'c', 'd')), str)
    assert c(items=('a', 'b', 'c', 'd')) in ['a', 'b', 'c', 'd']
    assert isinstance(c(items=('a', 'b', 'c', 'd'), length=4), tuple)
    assert len(c(items=('a', 'b', 'c', 'd'), length=4)) == 4

# Generated at 2022-06-21 15:57:18.731975
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    assert Choice.__call__('Кобра') == 'б'


# Generated at 2022-06-21 15:57:26.864880
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    x = choice(items=['a', 'b', 'c'])
    assert x == 'c'
    choice = Choice()
    x = choice(items=['a', 'b', 'c'], length=1)
    assert x == ['a']
    choice = Choice()
    x = choice(items='abc', length=2)
    assert x == 'ba'
    choice = Choice()
    x = choice(items=('a', 'b', 'c'), length=5)
    assert x == ('c', 'a', 'a', 'b', 'c')
    choice = Choice()
    x = choice(items='aabbbccccddddd', length=4, unique=True)
    assert x == 'cdba'

# Generated at 2022-06-21 15:57:29.168154
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis import Choice
    choice = Choice()
    print(choice)
    print(choice.__class__)



# Generated at 2022-06-21 15:57:30.790841
# Unit test for constructor of class Choice
def test_Choice():
    """Test constructor of class Choice."""
    _ = Choice()



# Generated at 2022-06-21 15:57:34.934402
# Unit test for constructor of class Choice
def test_Choice():
    ch = Choice()
    print(ch)
    print(ch(items='ABCDEFGHIJKLMNOPQRSTUVWXYZ', length=26, unique=True))
    print(ch(items='ABCDEFGHIJKLMNOPQRSTUVWXYZ', length=26, unique=False))
    pass

# Generated at 2022-06-21 15:57:36.799886
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert c.Meta.name == 'choice'
    

# Generated at 2022-06-21 15:57:40.272205
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Arrange
    items = ['a', 'b', 'c']
    length = 5
    unique = True

    # Act
    choice = Choice()
    choice(items=items, length=length, unique=unique)


# Generated at 2022-06-21 15:57:48.728579
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Snake test for method __call__ of class Choice."""
    choice = Choice()
    # Test a single random choice
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    # Test one of each element
    assert choice(items=['a', 'b', 'c'], length=3) == ['a', 'b', 'c'] or \
           choice(items=['a', 'b', 'c'], length=3) == ['b', 'c', 'a'] or \
           choice(items=['a', 'b', 'c'], length=3) == ['c', 'a', 'b']



# Generated at 2022-06-21 15:57:50.783803
# Unit test for constructor of class Choice
def test_Choice():
    """Test for constructor of class Choice."""
    choice = Choice()

# Generated at 2022-06-21 15:58:11.663517
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert isinstance(choice(items=['a', 'b', 'c'], length=1), list)
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    try:
        choice(items=[1, 2, 3], length=2)
    except TypeError as e:
        assert str(e) == '**items** must be non-empty sequence.'

# Generated at 2022-06-21 15:58:17.255368
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) in ['ba', 'ab', 'cb', 'bc', 'ca', 'ac']

# Generated at 2022-06-21 15:58:17.999515
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert True

# Generated at 2022-06-21 15:58:18.756551
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-21 15:58:27.723160
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method __call__ of class Choice.

    """
    # Initialize a provider
    choice = Choice()
    assert choice('a', length=3) == 'aaa'
    assert choice(['a','b','c']) in ['a','b','c']
    assert choice(['a','b','c']) in ['a','b','c']
    assert choice(['a','b','c'], 3, False) in [('a','b','c'),('a','b','c'),('a','b','c')]
    assert choice(('a','b','c',), 3, False) in [('a','b','c'),('a','b','c'),('a','b','c')]

# Generated at 2022-06-21 15:58:28.550957
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert True


# Generated at 2022-06-21 15:58:41.046758
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    choice(items=['a', 'b', 'c'])

    try:
        choice(items=['a', 'b', 'c'], length=1)
    except TypeError as e:
        print(e)
    try:
        choice(items='abc', length=2)
    except TypeError as e:
        print(e)
    try:
        choice(items=('a', 'b', 'c'), length=5)
    except TypeError as e:
        print(e)

    try:
        choice(items='aabbbccccddddd', length=4, unique=True)
    except ValueError as e:
        print(e)

if __name__ == "__main__":
    test_Choice()

# Generated at 2022-06-21 15:58:43.106730
# Unit test for constructor of class Choice
def test_Choice():
    # TODO: Add test cases
    choice = Choice()
    return choice


# Generated at 2022-06-21 15:58:44.595742
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice.__class__.__name__ == 'Choice'


# Generated at 2022-06-21 15:58:45.762355
# Unit test for constructor of class Choice
def test_Choice():

    assert Choice().__init__() == None


# Generated at 2022-06-21 15:59:11.929622
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice.random.choice(items=['a', 'b', 'c']) == 'c'
    assert choice.random.choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice.random.choice(items='abc', length=2) == 'ba'
    assert choice.random.choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice.random.choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-21 15:59:20.837062
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Initialize some attributes
    choice = Choice()

    # Check ValueError if items is not a sequence
    with pytest.raises(ValueError):
        expected = choice(items={}, length=0)

    # Check TypeError if items is not a sequence
    with pytest.raises(TypeError):
        expected = choice(items=1, length=0)

    # Check ValueError if length is negative
    with pytest.raises(ValueError):
        expected = choice(items=['a', 'b', 'c'], length=-1)

    # Check TypeError if length is not an int
    with pytest.raises(TypeError):
        expected = choice(items=['a', 'b', 'c'], length='a')

    # Check if items is an empty list

# Generated at 2022-06-21 15:59:28.522462
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert isinstance(c(items=['a', 'b', 'c']), str)
    assert isinstance(c(items=['a', 'b', 'c'], length=1), list)
    assert isinstance(c(items='abc', length=2), str)
    assert isinstance(c(items=('a', 'b', 'c'), length=5), tuple)
    assert isinstance(c(items='aabbbccccddddd', length=4, unique=True), str)

# Generated at 2022-06-21 15:59:33.572153
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice('en')
    items = ['a', 'b', 'c']
    print(c(items))
    print(c(items, length=1))
    items = 'abc'
    print(c(items, length=2))
    items = ('a', 'b', 'c')
    print(c(items, length=5))
    items = 'aabbbccccddddd'
    print(c(items, length=4, unique=True))

# Generated at 2022-06-21 15:59:34.707056
# Unit test for constructor of class Choice
def test_Choice():
    print ("Test Choice")


# Generated at 2022-06-21 15:59:39.083575
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 1
    unique = False

    num_tests = 1000

    for _ in range(num_tests):
        choice = Choice()
        generated_items = choice(items, length, unique)

        if generated_items not in items:
            return False

    return True

# Generated at 2022-06-21 15:59:50.770257
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TODO: Add test for bool(choice())
    choice = Choice()

    # TODO: Choose best assert method
    #assert choice(items=['a', 'b', 'c']) == 'c'
    #assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    #assert choice(items='abc', length=2) == 'ba'
    #assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    #assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-21 15:59:58.414219
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""

    # Test it
    choice = Choice()
    # Test 1
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    assert choice(items=items, length=length, unique=unique) == ['a']
    # Test 2
    items = 'abc'
    assert choice(items=items) == 'c'
    # Test 3
    items = ('a', 'b', 'c')
    length = 5
    assert choice(items=items, length=length) == ('c', 'a', 'a', 'b', 'c')
    # Test 4
    items = 'aabbbccccddddd'
    length = 4
    unique = True

# Generated at 2022-06-21 16:00:05.657776
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """
    >>> from mimesis import Choice
    >>> choice = Choice()
    >>> choice(items=('a', 'b', 'c'))
    'c'
    >>> choice(items=('a', 'b', 'c'), length=1)
    ('a',)
    >>> choice(items='abc', length=2)
    'ba'
    >>> choice(items='aabbbccccddddd', length=4, unique=True)
    'cdba'
    """

    pass

# Generated at 2022-06-21 16:00:06.937797
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice() #Create provider
 



# Generated at 2022-06-21 16:00:53.831061
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()

    assert c(items=['a', 'b', 'c']) == 'c'
    assert c(items=['a', 'b', 'c'], length=1) == ['a']
    assert c(items='abc', length=2) == 'ba'
    assert c(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert c(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

    assert c(['a', 'b', 'c']) == 'c'
    assert c(['a', 'b', 'c'], 1) == ['a']
    assert c('abc', 2) == 'ba'

# Generated at 2022-06-21 16:01:01.267978
# Unit test for constructor of class Choice
def test_Choice():
    import pytest
    from mimesis import Choice
    choice = Choice()

    # Non-empty sequence of elements.
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    with pytest.raises(TypeError):
        choice(items=[], length='1')

# Generated at 2022-06-21 16:01:10.586809
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from hypothesis import given
    from hypothesis.strategies import integers

    from mimesis.builtins import Choice
    from mimesis.typing import List, Sequence

    @given(integers(), integers(min_value=1))
    def test_choice_sequence(length, seed):
        choice = Choice(seed)
        chosen = choice(['a', 'b', 'c'], length=length)
        assert len(chosen) == length
        assert isinstance(chosen, (List, Sequence))
        assert all(x in ['a', 'b', 'c'] for x in chosen)

    @given(integers(), integers(min_value=1))
    def test_unique_choice_sequence(length, seed):
        choice = Choice(seed)

# Generated at 2022-06-21 16:01:15.173727
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c'])
    assert choice(items=['a', 'b', 'c'], length=1)
    assert choice(items='abc', length=2)
    assert choice(items=('a', 'b', 'c'), length=5)
    assert choice(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-21 16:01:25.251372
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import unittest
    class TestChoice(unittest.TestCase):
        def setUp(self):
            self.choice = Choice()

        def test_Choice___call__(self):
            self.assertEqual(self.choice(items=['a', 'b', 'c']), 'c')
            self.assertEqual(self.choice(items=['a', 'b', 'c'], length=1), ['a'])
            self.assertEqual(self.choice(items='abc', length=2), 'ba')
            self.assertEqual(self.choice(items=('a', 'b', 'c'), length=5), ('c', 'a', 'a', 'b', 'c'))

# Generated at 2022-06-21 16:01:28.182220
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    seq = c(['a', 'b', 'c', 'd'], length=5)
    seq[0] == 'a' or seq[0] == 'b' or seq[0] == 'c' or seq[0] == 'd'

# Generated at 2022-06-21 16:01:32.281724
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    # Method __call__:
    # If the items argument is not a sequence, raises 
    # the TypeError '**items** must be non-empty sequence.'
    try:
        choice(items=100)
    except TypeError:
        pass
    else:
        raise TypeError('The items argument is not a sequence, does not raise \
            TypeError \'**items** must be non-empty sequence.')
    
    # If the items argument is a empty sequence, raises
    # the ValueError '**items** must be a non-empty sequence.'
    try:
        choice(items=[])
    except ValueError:
        pass
    else:
        raise ValueError('The items argument is a empty sequence, does not raise \
            ValueError \'**items** must be a non-empty sequence.')
    
   

# Generated at 2022-06-21 16:01:33.376629
# Unit test for constructor of class Choice
def test_Choice():
    """Class Testing."""
    c = Choice()
    assert isinstance(c, Choice)

# Generated at 2022-06-21 16:01:35.184299
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    print(c.__doc__)
    assert c.__doc__ == 'Class for generating a random choice from items in a sequence.'


# Generated at 2022-06-21 16:01:44.830889
# Unit test for method __call__ of class Choice
def test_Choice___call__():
  from mimesis import Choice
  choice = Choice()
  assert choice(items=['a', 'b', 'c']) == 'c'
  assert choice(items=['a', 'b', 'c'], length=1) == ['a']
  assert choice(items='abc', length=2) == 'ba'
  assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
  assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
  try:
    choice(items=['a', 'b', 'c'], length=0.5)
    assert False, 'Expected error'
  except TypeError:
    pass

# Generated at 2022-06-21 16:02:58.570048
# Unit test for constructor of class Choice
def test_Choice():
    """Test constructor of class Choice."""
    c = Choice()
    assert c(items=[1, 2, 3]) in [1, 2, 3]
    assert c(items=[1, 2, 3], length=1) in [[1], [2], [3]]
    assert c(items=[1, 2, 3], length=2) in [[1, 2], [2, 3]]
    assert c(items=[1, 2, 3], length=3) in [[3, 2, 1], [1, 2, 3]]
    assert c(items=[1, 2, 3], length=2, unique=True) in [[1, 2], [2, 3]]
    assert c(items=[1, 2, 3], length=3, unique=True) in [[1, 2, 3], [2, 1, 3]]

# Generated at 2022-06-21 16:02:59.746650
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice() is not None



# Generated at 2022-06-21 16:03:02.189557
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice.random.choice(['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice.random.choice(['a', 'b', 'c'], 3) in ['a', 'b', 'c']



# Generated at 2022-06-21 16:03:05.772469
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice('a', 'b', 'c') in ['a', 'b', 'c']
    assert choice('a', 'b', 'c', length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ab', 'bc', 'ac']
    assert choice('aabbbccccddddd', length=4, unique=True) in ['abcd', 'cdba', 'dcba']

# Generated at 2022-06-21 16:03:11.052193
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) in [('c', 'a', 'a', 'b', 'c'), ('a', 'c', 'b', 'c', 'a')]
    assert choice(items='aabbbccccddddd', length=4, unique=True) in ['cdba', 'cdaa', 'bcdc', 'badc', 'bcab']

# Generated at 2022-06-21 16:03:20.882608
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    # Define arguments
    items = [1]
    length = 0
    unique = False

    choice = Choice()

    # Check result
    result = choice(items = items, length = length, unique = unique)
    assert result == 1

    # Define arguments
    items = [1, 2, 3]
    length = 1
    unique = False

    choice = Choice()

    # Check result
    result = choice(items = items, length = length, unique = unique)
    assert result == [1]

    # Define arguments
    items = ('1', 2, 3)
    length = 2
    unique = False

    choice = Choice()

    # Check result
    result = choice(items = items, length = length, unique = unique)

# Generated at 2022-06-21 16:03:22.926045
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    choice = Choice(seed = 'a')
    choice = Choice(locale = 'ru')
    assert isinstance(choice, Choice)
    assert isinstance(choice, BaseProvider)


# Generated at 2022-06-21 16:03:23.757168
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert False

# Generated at 2022-06-21 16:03:24.689416
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert isinstance(c, Choice)



# Generated at 2022-06-21 16:03:30.686237
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)
    assert isinstance(choice.random, choice.random.__class__)
    assert isinstance(choice.datetime, choice.datetime.__class__)
    assert isinstance(choice.provider, choice.provider.__class__)
