

# Generated at 2022-06-21 15:56:26.561758
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis.typing import Callable

    assert Choice is Callable

# Generated at 2022-06-21 15:56:27.434302
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()

# Generated at 2022-06-21 15:56:28.472542
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()

# Generated at 2022-06-21 15:56:39.161198
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 0
    unique = False
    choice = Choice()
    result = choice(items, length, unique)
    assert result == 'c'

items = ['a', 'b', 'c']
length = 1
unique = False
choice = Choice()
result = choice(items, length, unique)
assert result == ['a']

items = 'abc'
length = 2
unique = False
choice = Choice()
result = choice(items, length, unique)
assert result == 'ba'

items = ('a', 'b', 'c')
length = 5
unique = False
choice = Choice()
result = choice(items, length, unique)
assert result == ('c', 'a', 'a', 'b', 'c')


# Generated at 2022-06-21 15:56:41.107732
# Unit test for constructor of class Choice
def test_Choice():
    """ Test correctness of constructor of class Choice. """
    choice = Choice()
    assert choice is not None

# Generated at 2022-06-21 15:56:50.692268
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice(random=None)
    print(choice(items=['a', 'b', 'c'], length=10, unique=False))
    print(choice(items=['a', 'b', 'c'], length=1, unique=False))
    print(choice(items='abc', length=2, unique=False))
    print(choice(items=('a', 'b', 'c'), length=5, unique=False))
    print(choice(items='aabbbccccddddd', length=4, unique=True))


# Generated at 2022-06-21 15:56:52.355388
# Unit test for constructor of class Choice
def test_Choice():
    pl = Choice()
    assert len(pl.items) > 0


# Generated at 2022-06-21 15:57:01.963998
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    choice(items=[1, 2], length=1, unique=False)
    choice(items=(1, 2, 3), length=3, unique=False)
    choice(items='12', length=1, unique=True)
    choice(items='12', length=3, unique=False)
    try:
        choice(items={1, 2}, length=1, unique=False)
    except TypeError:
        pass
    try:
        choice(items=(1, 2, 3), length=0)
    except ValueError:
        pass
    try:
        choice(items=(1, 2, 3), length=1, unique=True)
    except ValueError:
        pass

# Generated at 2022-06-21 15:57:09.055305
# Unit test for constructor of class Choice
def test_Choice():
    # Test constructor of class Choice
    choice = Choice()
    choice.seed(2)
    assert choice('abc') == 'b'
    assert choice('abc', length=1) == ['a']
    assert choice('abc', length=2) == 'ba'
    assert choice(('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice('aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-21 15:57:14.926440
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) != ''
    assert choice(items=['a', 'b', 'c'], length=1) is not None
    assert choice(items='abc', length=2) != ''
    assert choice(items=('a', 'b', 'c'), length=5) is not None
    assert choice(items='aabbbccccddddd', length=4, unique=True) != ''

# Generated at 2022-06-21 15:57:27.604286
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    provider = Choice()
    result = provider(items=['a', 'b', 'c'], unique=True)
    assert result in ['a', 'b', 'c'], 'The result is wrong!'

    result = provider(items=['a', 'b', 'c'], length=1)
    assert result == ['b'], 'The result is wrong!'

    result = provider(items='abc', length=2)
    assert result == 'ac', 'The result is wrong!'

    result = provider(items=('a', 'b', 'c'), length=5)
    assert result == ('a', 'b', 'b', 'a', 'a'), 'The result is wrong!'

    result = provider(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-21 15:57:37.863399
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Test with kwargs not in method signature
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

    # Test with insufficient unique elements

# Generated at 2022-06-21 15:57:43.198556
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) != 'A'
    assert choice(items=['a', 'b', 'c'], length=1) == ['c']
    assert choice(items='abc', length=2) != ['a','b','c']
    assert choice(items=('a', 'b', 'c'), length=5) != ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) != 'dddd'

# Generated at 2022-06-21 15:57:44.360949
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice() is not None

# Generated at 2022-06-21 15:57:45.396814
# Unit test for constructor of class Choice
def test_Choice():
    assert isinstance(Choice(), Choice)


# Generated at 2022-06-21 15:57:55.820661
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    import pytest
    c = Choice()
    with pytest.raises(TypeError):
        c(items=('a', 'b', 'c'), length='a')
    with pytest.raises(TypeError):
        c(items=2)
    with pytest.raises(ValueError):
        c(items=('a', 'b', 'c'), length=-1)
    with pytest.raises(ValueError):
        c(items=(), length=1)
    assert c(items=('a', 'b', 'c'), length=1) == ['a']
    assert c(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')

# Generated at 2022-06-21 15:58:04.192929
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    import pytest

    from mimesis.enums import Alignment
    from mimesis.typing import Sequence

    from . import GENERATOR

    with pytest.raises(TypeError):
        Choice(GENERATOR)()

    with pytest.raises(ValueError):
        Choice(GENERATOR)(items=[])

    with pytest.raises(ValueError):
        Choice(GENERATOR)(items=list(range(10)), length=-1)

    with pytest.raises(ValueError):
        Choice(GENERATOR)(items=list(range(10)), length=14, unique=True)

    # TODO: 1st argument is **items**, **length** is **number**

# Generated at 2022-06-21 15:58:12.338733
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TODO: We should use hypothesis here. That would be better
    from mimesis import Choice
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-21 15:58:19.640858
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert c(items=['a', 'b', 'c']) == 'c'
    assert c(items=['a', 'b', 'c'], length=1) == ['a']
    assert c(items='abc', length=2) == 'ba'
    assert c(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert c(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-21 15:58:28.103518
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Объект с метаданными для провайдера
    meta = Choice.Meta()

    # Инициализация провайдера
    provider = Choice(meta)

    # Проверяем генерацию конкретных значений
    assert provider() == 'Владимир'
    assert provider(unique=True) == 'Киев'
    assert provider(length=1) == ['Владимир']

# Generated at 2022-06-21 15:59:22.363376
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice('fghkyyy') == 'h'
    assert choice(('a', 'b', 'c', 'd'), length=1) == ('a',)
    assert choice(('a', 'b', 'c', 'd'), length=4) == ('d', 'b', 'b', 'a')
    assert choice(['a', 'b', 'c', 'd', 'e', 'f', 'g'], length=2) == ['a', 'e']
    assert choice(('a', 'b', 'c', 'd', 'e', 'f', 'g'), length=2) == ('a', 'e')

# Generated at 2022-06-21 15:59:23.423045
# Unit test for constructor of class Choice
def test_Choice():
        c = Choice()
        assert c is not None

# Generated at 2022-06-21 15:59:33.065584
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test Choice.__call__."""
    c = Choice()
    assert c(items=['a', 'b', 'c']) == 'c'

    assert c(items=['a', 'b', 'c'], length=1) == ['a']
    assert c(items='abc', length=2) == 'ba'
    assert c(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert c(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

    with pytest.raises(TypeError, match=r'**length** must be integer.'):
        c(items=['a', 'b', 'c'], length='foo')


# Generated at 2022-06-21 15:59:34.567289
# Unit test for constructor of class Choice
def test_Choice():
    choi = Choice()
    assert choi is not None


# Generated at 2022-06-21 15:59:40.028160
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TODO: Add more tests
    choice = Choice()

    assert choice(items=['a', 'b', 'c'])
    assert choice(items=['a', 'b', 'c'], length=1)
    assert choice(items='abc', length=2)
    assert choice(items=('a', 'b', 'c'), length=5)
    assert choice(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-21 15:59:44.350297
# Unit test for constructor of class Choice
def test_Choice():
    """Unit test for constructor of class Choice."""

    choice = Choice()
    items = ['a', 'b', 'c']
    value = choice(items)
    assert isinstance(value, str)
    assert value in items



# Generated at 2022-06-21 15:59:54.642293
# Unit test for method __call__ of class Choice

# Generated at 2022-06-21 16:00:05.571356
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    from mimesis.enums import Gender
    from mimesis.providers.text import Text
    from mimesis.providers.person import Person
    from mimesis.providers.business import Business
    from mimesis.providers.numbers import Numbers

    text = Text('en')
    person = Person('en')
    business = Business('en')
    numbers = Numbers()
    choice = Choice()

    assert isinstance(choice(["a", "b"], length=2), list)
    assert isinstance(choice(("a", "b"), length=2), tuple)
    assert isinstance(choice("abc", length=2), str)
    assert choice(["a", "b", "c"], length=1) == ["a"]

# Generated at 2022-06-21 16:00:07.897219
# Unit test for constructor of class Choice
def test_Choice():
    import pytest
    choice = Choice()
    assert choice.random.choice(['a', 'b', 'c']) in ['a', 'b', 'c']


# Generated at 2022-06-21 16:00:08.397318
# Unit test for constructor of class Choice
def test_Choice():
    Choice()