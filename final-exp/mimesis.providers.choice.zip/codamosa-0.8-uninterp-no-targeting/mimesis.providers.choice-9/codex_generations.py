

# Generated at 2022-06-21 15:56:26.076522
# Unit test for constructor of class Choice
def test_Choice():
    pass

# Generated at 2022-06-21 15:56:28.418777
# Unit test for constructor of class Choice
def test_Choice():
    """Unit test for constructor of class Choice."""
    choice_ = Choice()
    assert choice_ is not None


# Generated at 2022-06-21 15:56:39.123261
# Unit test for constructor of class Choice
def test_Choice():
    # Construct instance of class Choice
    choice = Choice()

    # Items are of type Sequence (of Any)
    choice(items=['a', 'b', 'c'])
    choice(items=['a', 'b', 'c'], length=1)
    choice(items='abc', length=2)
    choice(items=('a', 'b', 'c'), length=5)
    choice(items='aabbbccccddddd', length=4, unique=True)

    # Length is of type int
    choice(items=['a', 'b', 'c'], length=1)

    try:
        # Length is not of type int
        choice(items=['a', 'b', 'c'], length="one")
    except TypeError as e:
        print(e)

# Generated at 2022-06-21 15:56:43.426466
# Unit test for constructor of class Choice
def test_Choice():
    choice1 = Choice()
    assert isinstance(choice1, Choice)
    assert choice1.Meta.name == 'choice'
    choice2 = Choice(random=None)
    assert choice2.random is None


# Generated at 2022-06-21 15:56:56.299338
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method Choice.__call__."""
    from mimesis import Choice
    choice = Choice()
    assert (choice(items=['a', 'b', 'c']) in ['a', 'b', 'c'])
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ac', 'bc', 'ab']

# Generated at 2022-06-21 15:57:03.077315
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    Choice._create_random_patcher()
    choice = Choice()

    # test case 01: sequence of list
    assert choice(items=['a', 'b', 'c']) == 'a'
    assert choice(items=['a', 'b', 'c'], length=1) == ['b']
    assert choice(items=['a', 'b', 'c'], length=2) == ['a', 'c']
    assert choice(items=['a', 'b', 'c'], length=3) == ['b', 'b', 'a']
    assert choice(items=['a', 'b', 'c'], length=5) == ['b', 'a', 'a', 'b', 'a']
    assert choice(items=['a', 'b', 'c'], length=0) == 'a'

# Generated at 2022-06-21 15:57:13.982399
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from .random import Random
    r = Random()

    choice = Choice(r)

    def test(items, length, unique):
        return choice(items, length, unique)

    # testing integer
    assert test(items=12, length=1, unique=True) == 1

    # testing set
    assert type(test(items=set('abc'), length=1, unique=True)) == str

    assert len(test(items=['a', 'b', 'c'], length=1, unique=True)) == 1
    assert len(test(items=['a', 'b', 'c'], length=2, unique=True)) == 2
    assert len(test(items=['a', 'b', 'c'], length=3, unique=True)) == 3

# Generated at 2022-06-21 15:57:16.858095
# Unit test for constructor of class Choice
def test_Choice():
    """This is a test function."""
    c = Choice()
    assert c.random
    assert c.seed
    assert c.datetime
    assert c.localization
    assert c.provider_name == 'choice'
    assert c.__doc__

# Generated at 2022-06-21 15:57:25.205965
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Setup
    import pytest # type: ignore
    choice = Choice()
    # Exercise and Verify

    with pytest.raises(TypeError):
        choice(items=['a', 'b', 'c'], length=0.0)
    with pytest.raises(TypeError):
        choice(items=0)
    with pytest.raises(TypeError):
        choice(items=0.0)
    with pytest.raises(TypeError):
        choice(items=['a', 'b', 'c'], length='a')
    with pytest.raises(ValueError):
        choice(items=['a', 'b', 'c'], length=-1)
    with pytest.raises(ValueError):
        choice(items='')
    with pytest.raises(ValueError):
        choice

# Generated at 2022-06-21 15:57:29.406942
# Unit test for constructor of class Choice
def test_Choice():
    ch = Choice()
    assert ch.__class__.__name__ == 'Choice'
    assert ch.__class__.__module__ == 'mimesis.providers.choice'
    assert Choice.Meta.name == 'choice'


# Generated at 2022-06-21 15:57:38.138452
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice is not None


# Generated at 2022-06-21 15:57:39.386915
# Unit test for constructor of class Choice
def test_Choice():
    f = Choice('en')
    assert isinstance(f, Choice)


# Generated at 2022-06-21 15:57:49.094972
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    from mimesis import Choice
    from mimesis.enums import Gender
    choice = Choice()

    # Test with sequence of strings.
    assert isinstance(choice(items=['a', 'b', 'c']), str)
    assert isinstance(choice(items=['a', 'b', 'c'], length=1), list)
    assert isinstance(choice(items='abc', length=2), str)
    assert isinstance(choice(items=('a', 'b', 'c'), length=5), tuple)
    assert isinstance(choice(items='aabbbccccddddd', length=4, unique=True), str)

    # Test with sequence of tuples.
    assert isinstance(choice(items=Gender), str)
    assert isinstance(choice(items=Gender, length=1), list)

# Generated at 2022-06-21 15:57:52.155909
# Unit test for constructor of class Choice
def test_Choice():
    
    ch = Choice()

    assert (ch != None)
    assert isinstance(ch, Choice)
    assert (len(ch.__dict__) > 0)



# Generated at 2022-06-21 15:58:02.377915
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    a = choice(items=['a', 'b', 'c'])
    b = choice(items=['a', 'b', 'c'], length=1)
    c = choice(items='abc', length=2)
    d = choice(items=('a', 'b', 'c'), length=5)
    e = choice(items='aabbbccccddddd', length=4, unique=True)

    assert a in ['a', 'b', 'c']
    assert b in [['a'], ['b'], ['c']]
    assert c in ['aa', 'ab', 'ac', 'ba', 'bb', 'bc', 'ca', 'cb', 'cc']

# Generated at 2022-06-21 15:58:03.859411
# Unit test for constructor of class Choice
def test_Choice():
  c = Choice()
  assert c is not None


# Generated at 2022-06-21 15:58:10.913495
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice(local=True)

    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-21 15:58:14.882034
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice.Meta.name == 'choice'
    assert choice('ABC') in 'ABC'
    assert choice(['A', 'B', 'C']) in ['A', 'B', 'C']
    assert choice(('A', 'B', 'C')) in ('A', 'B', 'C')
    assert choice(['A', 'B', 'C'], 1) in [['A'], ['B'], ['C']]
    assert choice(list('ABC'), 2) in [list('AB'), list('AC'), list('BC')]
    assert choice('ABC', length=3) in 'ABC'

# Generated at 2022-06-21 15:58:17.984327
# Unit test for constructor of class Choice
def test_Choice():
    """Test the constructor of the class Choice."""
    choice = Choice()
    assert isinstance(choice, Choice)
    assert isinstance(choice, BaseProvider)


# Generated at 2022-06-21 15:58:23.659274
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    print(choice(['a', 'b', 'c'], 0))
    print(choice(['a', 'b', 'c'], 1))
    print(choice('abc', 2))
    print(choice(('a', 'b', 'c'), 5))
    print(choice('aabbbccccddddd', 4, True))
test_Choice___call__()

# Generated at 2022-06-21 15:59:07.822416
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    print(c(items=['a', 'b', 'c']))
    print(c(items=['a', 'b', 'c'], length=1))
    print(c(items='abc', length=2))
    print(c(items=('a', 'b', 'c'), length=5))
    print(c(items='aabbbccccddddd', length=4, unique=True))

test_Choice()

# Generated at 2022-06-21 15:59:11.325197
# Unit test for constructor of class Choice
def test_Choice():
    """Unit test for constructor of class Choice."""
    choice = Choice()

    assert callable(choice) is True
    assert isinstance(choice, Choice)
    assert isinstance(choice.random, choice.Random)


# Generated at 2022-06-21 15:59:20.434977
# Unit test for constructor of class Choice
def test_Choice():
    import pytest
    from mimesis import Choice

    try:
        print(Choice())
    except RuntimeError as err:
        assert str(err) == "RNG has not been initialized with a seed."
    # Initialize the RNG with a seed
    Choice().seed(12345)
    print(Choice())
    # Test for __call__ method
    choice = Choice()
    print(choice(items=['a', 'b', 'c']))
    print(choice(items=['a', 'b', 'c'], length=1))
    print(choice(items='abc', length=2))
    print(choice(items=('a', 'b', 'c'), length=5))
    print(choice(items='aabbbccccddddd', length=4, unique=True))

# Generated at 2022-06-21 15:59:31.079101
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    '''
    Unit test for method __call__ of class Choice
    '''
    # Define variables
    choice = Choice()
    arr_1 = ['a', 'b', 'c']
    arr_2 = ['a', 'b', 'c', 'd']
    arr_3 = ['a', 'b', 'c', 'd', 'e']

    def _test_choice__call__(arr: list):
        '''
        Unit test for method __call__ of class Choice

        :param arr: List with elements
        '''
        assert choice(items=arr) in arr
        assert choice(items=arr, length=1) in arr
        assert choice(items=arr, length=2) in arr
        assert choice(items=arr, length=3) in arr

# Generated at 2022-06-21 15:59:37.272077
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c'], length=1, unique=True) == 'a'
    assert Choice().__call__(items=['a', 'b', 'c'], length=2, unique=True) in ['ab', 'ba']
    for i in range(100):
        assert Choice().__call__(items=['a', 'b', 'c'], length=3, unique=True) in ['abc', 'bac', 'bca', 'cab', 'cba']
    try:
        Choice().__call__(items=('a', 'b', 'c'), length=-1, unique=True)
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-21 15:59:38.177001
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert (c != None)

# Generated at 2022-06-21 15:59:48.703740
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.providers.choice import Choice

    mimesis_choice = Choice()

    assert mimesis_choice(items=['a', 'b', 'c']) == 'c'
    assert mimesis_choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert mimesis_choice(items='abc', length=2) == 'ba'
    assert mimesis_choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert mimesis_choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

    assert mimesis_choice(items=['a', 'b', 'c'], length='hello') == 'c'

# Generated at 2022-06-21 15:59:57.235728
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from random import choice
    from pprint import pprint
    from mimesis.providers.choice import Choice

    choice_ = Choice()

    choice_(items=['a', 'b', 'c']) == 'c'
    choice_(items=['a', 'b', 'c'], length=1) == ['a']
    choice_(items='abc', length=2) == 'ba'
    choice_(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    choice_(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

    items = ['a', 'b', 'c']
    length = 1
    assert choice_(items=items, length=length) == choice(items)
    length = 2
   

# Generated at 2022-06-21 16:00:03.313801
# Unit test for constructor of class Choice
def test_Choice():
    result = Choice()
    assert isinstance(result,Choice)
    items = {0: 2, 1: 2, 2: 2, 3: 2, 4: 2, 5: 2, 6: 2, 7: 2, 8: 2, 9: 2}
    assert result(items) == 9
    assert result(items,3) == [2, 4, 7]
    

# Generated at 2022-06-21 16:00:04.568132
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import doctest
    doctest.testmod()
    return None


# Generated at 2022-06-21 16:00:32.574092
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    test_input = """
input:
['a','b','c']
['b','d','f','g','u','v','w','a','e','t','q','k','l','q','z','f','d']
['z','a','b','c']
['a']
['a','b','c']
('a','b','c')
('a','b','c')
('h','j','k','l','m','n','o')
('h','j','k','l','m','n','o')
''
''
['a','b']
['a','b']
"""

# Generated at 2022-06-21 16:00:43.047573
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    ch = Choice()
    result = ch(items=['a', 'b', 'c'])
    assert result in ['a', 'b', 'c']
    result = ch(items=['a', 'b', 'c'], length=1)
    assert result == ['a']
    result = ch(items='abc', length=2)
    assert result in ['ba', 'ab']
    result = ch(items=('a', 'b', 'c'), length=5)
    assert result in [('b', 'a', 'b', 'c', 'a'), ('a', 'b', 'c', 'b', 'a')]
    result = ch(items='aabbbccccddddd', length=4, unique=True)
    assert result in ['bacd', 'adcb']

# Generated at 2022-06-21 16:00:43.899883
# Unit test for constructor of class Choice
def test_Choice():
    r = Choice()
    r


# Generated at 2022-06-21 16:00:45.224814
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert isinstance(c, Choice)


# Generated at 2022-06-21 16:00:45.723691
# Unit test for constructor of class Choice
def test_Choice():
    Choice()

# Generated at 2022-06-21 16:00:48.845479
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    items = ['a', 'b', 'c']
    i1 = c(items=items)
    print(i1)
    assert i1 in items

    items = 'abc'
    length = 2
    i2 = c(items=items, length=length)
    assert len(i2) == length

    unique = True
    assert c(items='aabbbccccddddd', length=4, unique=unique) == 'cdba'

# Generated at 2022-06-21 16:00:50.182499
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice) is True


# Generated at 2022-06-21 16:00:51.439795
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice is not None
    assert isinstance(choice, Choice)

# Generated at 2022-06-21 16:00:55.099786
# Unit test for constructor of class Choice
def test_Choice():
    print("Checking constructor of class Choice")
    c = Choice()
    assert c.random.choice(['a', 'b', 'c']) != c.random.choice(['a', 'b', 'c'])


# Generated at 2022-06-21 16:01:01.880745
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test Choice._call__()."""
    # Test sequence return
    data = Choice().__call__(items=['a', 'b', 'c'], length=3, unique=False)
    data == ['b', 'b', 'c'] # expect False; actual: True
    data = Choice().__call__(items=['a', 'b', 'c'], length=3, unique=True)
    data == ['b', 'a', 'c'] # expect False; actual: True

    # Test element return
    data = Choice().__call__(items=['a', 'b', 'c'], length=0, unique=False)
    data == 'a' # expect False; actual: True
    data = Choice().__call__(items=['a', 'b', 'c'], length=0, unique=True)
    data

# Generated at 2022-06-21 16:02:25.450146
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import pytest
    choice = Choice()

    test_items = ['a', 'b', 'c']
    assert isinstance(choice(items=test_items), str)

    test_items = ['a', 'b', 'c']
    assert choice(items=test_items, length=1) == ['a']

    test_items = 'abc'
    assert choice(items=test_items, length=2) == 'ba'

    test_items = ('a', 'b', 'c')
    assert choice(items=test_items, length=5) == ('c', 'a', 'a', 'b', 'c')

    test_items = 'aabbbccccddddd'
    assert choice(items=test_items, length=4, unique=True) == 'cdba'


# Generated at 2022-06-21 16:02:26.308324
# Unit test for constructor of class Choice
def test_Choice():
    obj = Choice()
    assert obj
    assert obj.seed is None


# Generated at 2022-06-21 16:02:32.294526
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method __call__ of class Choice."""
    choice = Choice()
    assert isinstance(choice(items=['a', 'b', 'c']), str)
    assert len(choice(items=['a', 'b', 'c'], length=3)) == 3

# Generated at 2022-06-21 16:02:33.772918
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()

# Generated at 2022-06-21 16:02:41.413376
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-21 16:02:49.394227
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-21 16:02:56.463932
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    print('\n**** In test_Choice::test_Choice__call__() ****\n')
    print('**** Test of Choice.__call__() ****')
    choice = Choice()
    print('choice = Choice()\n')

    print('choice(items=[\'a\', \'b\', \'c\']) = ', end="")
    print(choice(items=['a', 'b', 'c']))
    print('choice(items=[\'a\', \'b\', \'c\'], length=1) = ', end="")
    print(choice(items=['a', 'b', 'c'], length=1))
    print('choice(items=\'abc\', length=2) = ', end="")
    print(choice(items='abc', length=2))

# Generated at 2022-06-21 16:03:04.102857
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    ## Test if TypeError is raised with non-sequence items or non-integer length.
    def test_TypeError():
        choice = Choice()

        non_sequence_items = 'non-sequence items'
        non_integer_length = 'non-integer length'
        try:
            choice(items=non_sequence_items)
        except TypeError:
            pass

        try:
            choice(items=non_sequence_items, length=non_integer_length)
        except TypeError:
            pass

    ## Test if ValueError is raised with negative length or insufficient unique elements.
    def test_ValueError():
        choice = Choice()

        negative_length = -1
        insufficient_unique_elements = 'a'

# Generated at 2022-06-21 16:03:05.010394
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__ == Choice().__call__


# Generated at 2022-06-21 16:03:10.353991
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method __call__ of class Choice."""
    from mimesis.common import is_non_empty_sequence
    from mimesis.data import DATA
    from mimesis.providers.choice import Choice

    choice = Choice()
    for items in DATA:
        for length in range(5):
            for unique in (True, False):
                result = choice(items, length, unique)
                assert is_non_empty_sequence(result)