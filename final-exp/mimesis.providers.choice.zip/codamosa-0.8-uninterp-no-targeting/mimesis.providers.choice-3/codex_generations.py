

# Generated at 2022-06-21 15:56:20.779622
# Unit test for constructor of class Choice
def test_Choice():
    # TODO: Implement constructor test
    assert Choice()

# Generated at 2022-06-21 15:56:23.292057
# Unit test for constructor of class Choice
def test_Choice():
    t = Choice()
    assert isinstance(t, Choice)
    assert isinstance(t.random, Choice.random)


# Generated at 2022-06-21 15:56:24.410482
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice().__class__.__name__ == 'Choice'


# Generated at 2022-06-21 15:56:35.797492
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test __call__ method of Choice class."""
    from mimesis import Choice
    from mimesis.enums import Gender

    choice = Choice()
    result = choice(items=['a', 'b', 'c'])
    assert result in ['a', 'b', 'c']

    result = choice(items=['a', 'b', 'c'], length=1)
    assert result == ['a'] or result == ['b'] or result == ['c']

    result = choice(items='abc')
    assert result in 'abc'

    result = choice(items='abc', length=2)
    assert result == 'ba' or result == 'ab' or result == 'ac' or result == 'cb' or result == 'ca' or result == 'bc'


# Generated at 2022-06-21 15:56:41.521621
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'



# Generated at 2022-06-21 15:56:54.960373
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice(seed = "test")
    assert choice('abc') in ['a', 'b', 'c']
    assert choice('abc', unique = True) in ['a', 'b', 'c']
    assert choice('abc', length = 2) in ['ab', 'ac', 'ba', 'bc', 'ca', 'cb']
    assert choice('abc', length = 2, unique = True) in ['ab', 'ac', 'ba', 'bc', 'ca', 'cb']
    assert choice(('a', 'b', 'c')) in ['a', 'b', 'c']
    assert choice(('a', 'b', 'c'), unique = True) in ['a', 'b', 'c']

# Generated at 2022-06-21 15:57:02.580509
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    test_items = ['a', 'b', 'c']
    obj_choice = Choice()
    assert obj_choice(items=test_items) in test_items
    assert obj_choice(items=test_items, length=1) == ['a']
    assert obj_choice(items='abc', length=2) == 'ba'
    assert obj_choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert obj_choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-21 15:57:05.337439
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice()
    assert Choice._random
    assert Choice._datetime
    assert Choice._generator
    assert Choice.Meta.name=='choice'


# Generated at 2022-06-21 15:57:13.353965
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    assert type(choice(items=['a', 'b', 'c'], length=1)) == list
    assert type(choice(items='abc')) == str
    assert type(choice(items='abc', unique=True)) == str
    assert type(choice(items='abc', length=1)) == list
    assert type(choice(items=['a', 'b', 'c'], length=1)) == list
    assert len(choice(items=['a', 'b', 'c'], length=5)) == 5



# Generated at 2022-06-21 15:57:15.587714
# Unit test for constructor of class Choice
def test_Choice():
    
    import pytest
    from mimesis import Choice
    
    # Test whether a Choice object was correctly instantiated
    assert isinstance(ExampleChoice, Choice)
    
    
    
    

# Generated at 2022-06-21 15:57:37.050396
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    def generator_string(length: int, char: str = "") -> str:
        """Generator function string.

        :param length: Length of string.
        :param char: Character that will be present in string.
        """
        return char * length

    @given(text())
    def test_string(char: str):
        """Test choice by string.

        :param char: String characters.
        """
        choice = Choice()
        number = choice(items=char, length=1)
        assert len(number) == 1
        assert number in char


# Generated at 2022-06-21 15:57:44.361144
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-21 15:57:46.057743
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert c.__class__.__name__ == 'Choice'
    assert c.__class__.__module__ == 'mimesis.providers.datetime'


# Generated at 2022-06-21 15:57:52.254977
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    try:
        choice = Choice()
        assert choice(items=['a','b','c']) in ['a','b','c']
    except Exception as e:
        print(e)
        assert False
    try:
        choice = Choice()
        assert choice(items=['a','b','c'], length=1) == ['a']
    except Exception as e:
        print(e)
        assert False
    try:
        choice = Choice()
        assert choice(items='abc', length=2) in ['ab','ac','bc']
    except Exception as e:
        print(e)
        assert False

# Generated at 2022-06-21 15:58:02.447453
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert isinstance(c.__class__.__call__(c, items=['a', 'b', 'c']), str)
    assert isinstance(c.__class__.__call__(c, items=['a', 'b', 'c'], length=1), list)
    assert isinstance(c.__class__.__call__(c, items='abc', length=2), str)
    assert isinstance(c.__class__.__call__(c, items=('a', 'b', 'c'), length=5), tuple)
    assert isinstance(c.__class__.__call__(c, items='aabbbccccddddd', length=4, unique=True), str)

# Generated at 2022-06-21 15:58:06.792283
# Unit test for constructor of class Choice
def test_Choice():
    """Test the constructor of class Choice."""
    Choice(seed=12345)
    Choice(random_state=12345)
    Choice(locale='zh')
    Choice(seed=12345, locale='zh')
    Choice(random_state=12345, locale='zh')

# Unit tests for method __call__ of class Choice

# Generated at 2022-06-21 15:58:13.566871
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    # test_Choice___call___correct_sequence
    assert isinstance(c(items=['a', 'b', 'c']), str)
    # test_Choice___call___correct_sequence_and_length
    assert isinstance(c(items=['a', 'b', 'c'], length=1), list)
    # test_Choice___call___correct_sequence_and_length_and_unique
    assert len(set(c(items='aabbbccccddddd', length=4, unique=True))) == 4


# Generated at 2022-06-21 15:58:17.158495
# Unit test for constructor of class Choice
def test_Choice():
    # Test case 1:
    choice = Choice()
    assert choice is not None

    # Test case 2:
    choice = Choice(items=['a', 'b', 'c'])
    assert choice is not None
    assert isinstance(choice, Choice)


# Generated at 2022-06-21 15:58:18.803469
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)


# Generated at 2022-06-21 15:58:27.060859
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    # Arrange
    import numpy as np
    from hypothesis import given, settings, strategies as st

    from mimesis import Choice

    @settings(deadline=None)
    @given(st.lists(st.integers()), st.integers())
    def test_choose_from_list(items: List[int], length: int) -> None:
        # Act
        choice = Choice(seed=42)
        choice_list = choice(items=items, length=length)

        # Assert
        expected = np.random.RandomState(42).choice(items, size=length, replace=True)
        assert choice_list == expected

    test_choose_from_list()
    print("Success")

# Generated at 2022-06-21 15:59:00.682606
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice()._test_() is not None

# Generated at 2022-06-21 15:59:10.968481
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Test choice method
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    assert choice(items='aabbbccccddddd', length=4, unique=False) == 'ccdd'
    assert choice(items='aabbbccccddddd', length=5, unique=False) == 'acabc'
   

# Generated at 2022-06-21 15:59:12.618445
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)

# Unit tests for calling object of class Choice

# Generated at 2022-06-21 15:59:21.263326
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == any([ 'a', 'b', 'c'])
    assert choice(items=['a', 'b', 'c'], length=1) == any([ ['a'] ])
    assert choice(items='abc', length=2) == any([ 'ba' ])
    assert choice(items=('a', 'b', 'c'), length=5) == any([ ('c', 'a', 'a', 'b', 'c') ])
    assert choice(items='aabbbccccddddd', length=4, unique=True) == any([ 'cdba' ])
    try:
        choice(items=('a', 'b', 'c'), length=3.1)
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-21 15:59:28.111953
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    print(choice(items=['a', 'b', 'c']))
    print(choice(items=['a', 'b', 'c'], length=1))
    # print(choice(items='abc', length=2))
    print(choice(items=('a', 'b', 'c'), length=5))
    print(choice(items='aabbbccccddddd', length=4, unique=True))


# Generated at 2022-06-21 15:59:33.972314
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-21 15:59:39.502622
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    choice(items=['a', 'b', 'c'])
    choice(items=['a', 'b', 'c'], length=1)
    choice(items='abc', length=2)
    choice(items=('a', 'b', 'c'), length=5)
    choice(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-21 15:59:51.203424
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method __call__ of class Choice"""

    from mimesis import Choice
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ab', 'ac', 'ba', 'bc', 'ca', 'cb']

# Generated at 2022-06-21 15:59:58.646909
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    # Test with negative length value
    is_negative = False
    try:
        Choice()(items='abc', length=-1)
    except ValueError:
        is_negative = True
    assert is_negative

    # Test with non-integer length value
    is_non_integer = False
    try:
        Choice()(items='abc', length='str')
    except TypeError:
        is_non_integer = True
    assert is_non_integer

    # Test with non-sequence items value
    is_non_sequence = False
    try:
        Choice()(items=123, length=0)
    except TypeError:
        is_non_sequence = True
    assert is_non_sequence

    # Test with empty items value
    is_empty = False

# Generated at 2022-06-21 16:00:02.112350
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice.random.choice(['a', 'b', 'c']) in ['a', 'b', 'c']


# Generated at 2022-06-21 16:00:37.600255
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice()

# Generated at 2022-06-21 16:00:39.173564
# Unit test for constructor of class Choice
def test_Choice():
    """Unit test for constructor of class Choice."""
    choice = Choice()
    assert choice


# Generated at 2022-06-21 16:00:48.057050
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Testing when items is a list and length is 4.
    # Unique: True.
    choice = Choice()
    assert len(choice(items=['a', 'b', 'c'], length=4)) == 4
    # Assert that the elements in the list are unique.
    assert len(set(choice(items=['a', 'b', 'c', 'd'], length=4))) == 4
    assert len(set(choice(items=['a', 'b', 'c', 'd'], length=4))) == 4

    # Testing when items is a tuple and length is 6.
    # Unique: False.
    assert len(choice(items=('a', 'b', 'c', 'd'), length=6)) == 6
    # Assert that the elements in the tuple are not unique.

# Generated at 2022-06-21 16:00:49.796234
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert isinstance(Choice()(), str)  # noqa: S101:line-too-long

# Generated at 2022-06-21 16:00:50.825326
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert c is not None

# Generated at 2022-06-21 16:00:58.650497
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert(c(items=[0,1,2]) == 0 or c(items=[0,1,2]) == 1 or c(items=[0,1,2]) == 2)
    assert(c(items=[0,1,2], length=1) == [0] or c(items=[0,1,2], length=1) == [1] or c(items=[0,1,2], length=1) == [2])
    assert(c(items='abc', length=2) == 'ba' or c(items='abc', length=2) == 'ab' or c(items='abc', length=2) == 'bc')

# Generated at 2022-06-21 16:00:59.792092
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice


# Generated at 2022-06-21 16:01:06.810031
# Unit test for constructor of class Choice
def test_Choice():
    a = Choice()
    print(a)
    print(a(items=['a', 'b', 'c']))
    print(a(items=['a', 'b', 'c'], length=1))
    print(a(items='abc', length=2))
    print(a(items=('a', 'b', 'c'), length=5))
    print(a(items='aabbbccccddddd', length=4, unique=True))

if __name__ == '__main__':
    test_Choice()

# Generated at 2022-06-21 16:01:07.581890
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()

# Generated at 2022-06-21 16:01:08.719140
# Unit test for constructor of class Choice
def test_Choice():
	choice = Choice()
	return choice(items=['a', 'b', 'c'])