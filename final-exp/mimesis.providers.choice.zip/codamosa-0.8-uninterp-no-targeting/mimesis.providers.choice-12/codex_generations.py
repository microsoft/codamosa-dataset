

# Generated at 2022-06-21 15:56:26.073832
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-21 15:56:28.916328
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    assert isinstance(Choice().__call__(items=['a', 'b', 'c']), str)



# Generated at 2022-06-21 15:56:37.108140
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    assert choice(items=['a', 'b', 'c'], length=4) == ['a', 'a', 'c', 'b']
    assert choice(items='abc', length=5) == 'ccabb'
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    assert choice(items='aabbbccccddddd', length=7, unique=False) == 'dddddccaaaaa'
test_Choice___call__()


# Generated at 2022-06-21 15:56:43.461409
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert(Choice().__call__(items=['a', 'b', 'c']) in ['a', 'b', 'c'])
    assert(Choice().__call__(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']])
    assert(Choice().__call__(items='abc', length=2) in ['ab', 'bc', 'ac'])
    assert(Choice().__call__(items=('a', 'b', 'c'), length=4) in [('a', 'b', 'c', 'a'), ('b', 'c', 'a', 'b'), ('c', 'a', 'b', 'c')])

# Generated at 2022-06-21 15:56:51.736273
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    c = Choice()
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    result = c(items, length, unique)
    print(result)

    data = [1, 2, 3, 4]
    result = c(data)
    print(result)

    items = 'abc'
    length = 2
    result = c(items, length, False)
    print(result)


test_Choice___call__()

# Generated at 2022-06-21 15:57:02.122501
# Unit test for constructor of class Choice
def test_Choice():
    print()
    print('Test runnning: Choice()')
    print('-==========================-')
    choice = Choice()
    print('choice(items=[1,2,3]) is: ', choice(items=[1,2,3]))
    print('choice(items=["a", "b", "c"]) is: ', choice(items=["a", "b", "c"]))
    print('choice(items=["a", "b", "c"], length=5) is: ', choice(items=["a", "b", "c"], length=5))
    print('choice(items=[1,2,3], length=1) is: ', choice(items=[1,2,3], length=1))

# Generated at 2022-06-21 15:57:02.997919
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice is not None

# Generated at 2022-06-21 15:57:04.466879
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice.Meta.name == 'choice'


# Generated at 2022-06-21 15:57:07.793034
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    result = Choice(seed=123).__call__(items=[1, 2, 3, 4], length=5)
    assert result == [2, 4, 1, 3, 3], 'Wrong __call__'

# Generated at 2022-06-21 15:57:15.001030
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    print("choice: ", choice(items=['a', 'b', 'c']))
    print("choice: ", choice(items=['a', 'b', 'c'], length=1))
    print("choice: ", choice(items='abc', length=2))
    print("choice: ", choice(items=('a', 'b', 'c'), length=5))
    print("choice: ", choice(items='aabbbccccddddd', length=4, unique=True))

if __name__ == '__main__':
    test_Choice()

# Generated at 2022-06-21 15:57:25.681480
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Tests for method __call__ of class Choice."""
    choice = Choice()

    result = choice(items=['a', 'b', 'c'])
    assert isinstance(result, str)

    result = choice(items=['a', 'b', 'c'], length=1)
    assert isinstance(result, list)
    assert result == ['a']

    result = choice(items='abc', length=2)
    assert isinstance(result, str)
    assert result == 'ba'

    result = choice(items=('a', 'b', 'c'), length=5)
    assert isinstance(result, tuple)
    assert result == ('c', 'a', 'a', 'b', 'c')

    result = choice(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-21 15:57:36.410593
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = ['a', 'b', 'c', 'd']
    length = 0
    unique = True
    len_i = len(items)
    i = choice(items, length, unique)
    assert i in items
    assert isinstance(i, type(items[0]))
    length = 1
    i = choice(items, length, unique)
    assert len(i) == length
    assert isinstance(i, type(items[0])) or isinstance(i, type([items[0]]))
    length = len_i
    i = choice(items, length, unique)
    assert len(i) == length
    assert isinstance(i, type(items[0])) or isinstance(i, type([items[0]]))

# Generated at 2022-06-21 15:57:40.046855
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = [1, 2, 3]
    length = 4
    unique = True
    choice = Choice()(items=items, length=length, unique=unique)
    assert isinstance(choice, list)
    assert len(choice) == length
    assert len(set(items)) == len(items)


# Generated at 2022-06-21 15:57:42.604215
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    result = choice(items=['a', 'b', 'c'])
    assert result in ['a', 'b', 'c']


# Generated at 2022-06-21 15:57:48.414824
# Unit test for constructor of class Choice
def test_Choice(): 
    choice = Choice()
    #assert choice.random.choice(['a', 'b', 'c']) == 'c'
    assert choice.random.choice(['a', 'b', 'c']) == 'a'
    #assert choice('aabbbccccddddd', length=4, unique=True) == 'cdba'
    assert choice('aabbbccccddddd', length=4, unique=True) == 'aabb'

# Generated at 2022-06-21 15:57:52.524096
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert(choice(items=['a', 'b', 'c']) in ['a', 'b', 'c'])

if __name__ == '__main__':
    test_Choice()

# Generated at 2022-06-21 15:58:02.622351
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    try:
        choice(items='abc', length=2.0)
        assert False
    except TypeError:
        pass

# Generated at 2022-06-21 15:58:12.297978
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    # test
#     assert choice(items=['a', 'b', 'c']) == 'c'
#     assert choice(items=['a', 'b', 'c'], length=1) == ['a']
#     assert choice(items='abc', length=2) == 'ba'
#     assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
#     assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    # test exception
    try:
        choice(items=None, length=10)
    except TypeError:
        pass
    else:
        raise Exception

# Generated at 2022-06-21 15:58:22.342461
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()

    assert isinstance(choice(items=['a', 'b', 'c']), str)
    assert isinstance(choice(items=['a', 'b', 'c'], length=1), list)
    assert isinstance(choice(items='abc', length=2), str)
    assert isinstance(choice(items=('a', 'b', 'c'), length=5), tuple)
    assert isinstance(choice(items='aabbbccccddddd', length=4, unique=True), str)
    try:
        choice(items=['a', 'b', 'c'], length='a')
    except TypeError:
        pass
    else:
        raise Exception('This case should fail')

# Generated at 2022-06-21 15:58:24.830076
# Unit test for constructor of class Choice
def test_Choice():
    """test_Choice(items=None, length=None, unique=False) -> None
    """
    c = Choice()
    assert isinstance(c, Choice)


# Generated at 2022-06-21 15:58:56.162202
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis import Choice
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 1
    unique = True
    assert choice(items=items, length=length, unique=unique) == "b"

# Generated at 2022-06-21 15:59:02.445004
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    Choice().__call__(items=['a', 'b', 'c']) # should return ``
    Choice().__call__(items=['a', 'b', 'c'], length=1) # should return ``
    Choice().__call__(items='abc', length=2) # should return ``
    Choice().__call__(items=('a', 'b', 'c'), length=5) # should return ``


# Generated at 2022-06-21 15:59:12.577100
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from hypothesis import strategies as st
    from hypothesis import given
    from mimesis import Choice

    test_data: st.SearchStrategy[tuple] = st.tuples(
        st.lists(st.integers(), min_size=1),
        st.integers(min_value=0),
        st.booleans(),
    )

    @given(test_data)
    def test_method(data: tuple) -> None:
        items = data[0]
        length = data[1]
        unique = data[2]
        c = Choice()
        choice = c(items, length, unique)
        assert isinstance(choice, list) or isinstance(choice, tuple)
        if length > 0:
            if unique:
                assert len(set(choice)) == len(choice)
            assert len(choice)

# Generated at 2022-06-21 15:59:21.235865
# Unit test for constructor of class Choice
def test_Choice():
    choice_instance = Choice(seed=123)
    alphabets = ['a', 'b', 'c']
    assert choice_instance(alphabets) == 'c'
    assert choice_instance(alphabets, length=1) == ['b']
    assert choice_instance(alphabets, length=3) == ['a', 'a', 'a']
    assert choice_instance(alphabets, length=2, unique=True) == ['a', 'c']
    numbers = [1, 2, 3]
    assert choice_instance(numbers) == 1
    assert choice_instance(numbers, length=2) == [2, 3]
    assert choice_instance(numbers, length=2, unique=True) == [2, 3]

# Generated at 2022-06-21 15:59:23.085583
# Unit test for constructor of class Choice
def test_Choice():
    """
    ::

        obj = Choice()
        obj.__call__(length=2)
    """
    pass

# Generated at 2022-06-21 15:59:32.835086
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    import pytest
    from mimesis.builtins import Choice

    # Test errors and edge cases
    with pytest.raises(TypeError) as exc_info:
        Choice().__call__(items=['a', 'b', 'c'], length=1.1)
    assert str(exc_info.value) == '**length** must be integer.'

    with pytest.raises(TypeError) as exc_info:
        Choice().__call__(items=1)
    assert str(exc_info.value) == '**items** must be non-empty sequence.'

    with pytest.raises(ValueError) as exc_info:
        Choice().__call__(items=[])

# Generated at 2022-06-21 15:59:36.591789
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice      # choice is defined
    #assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')

# Generated at 2022-06-21 15:59:42.962475
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert c(items=[1, 2, 3], length=0) in [1, 2, 3]
    assert c(items='abc', length=1) in ['a', 'b', 'c']
    assert c(items=[1, 2, 3], length=1) in [[1], [2], [3]]
    assert c(items=(1, 2, 3), length=3) in [(1, 2, 3), (2, 3, 1), (3, 1, 2)]
    assert c(items='abc', length=2) in ['ab', 'ba', 'ac', 'ca', 'bc', 'cb']

# Generated at 2022-06-21 15:59:45.508760
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    chosen = choice(items=['a', 'b', 'c', 'd', 'e', 'f'], length=4)


# Generated at 2022-06-21 15:59:49.006232
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = list('abc')
    length = 1
    _choice = Choice()
    result = _choice(items, length)
    assert result == ['b']


# Generated at 2022-06-21 16:01:01.179445
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    def assert_raises(func):
        try:
            func()
            raise AssertionError
        except Exception:
            pass

    choices = Choice()
    assert choices(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choices(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choices(items='abc', length=1) in ['a', 'b', 'c']
    assert choices(items=tuple('abc'), length=1) in [('a',), ('b',), ('c',)]
    assert_raises(lambda: choices(items=['a', 'b'], length=3))
    assert_raises(lambda: choices(items='a', length=1))

# Generated at 2022-06-21 16:01:08.719148
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Tests method ``__call__()`` of class ``Choice``."""
    # Tests for method __call__ of class Choice
    # Test that was explicitly specified in method __doc__
    # TODO: Use doctest instead
    # TODO: Actually assert something
    # self.assertEqual(expected, Choice().__call__(items, length, unique))
    # TODO: Implement the rest of the tests
    pass



if __name__ == "__main__":
    import doctest

    doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE)

# Generated at 2022-06-21 16:01:16.181504
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method **__call__** of class :class:`mimesis.providers.Choice`.

    :return: None
    """
    from unittest import TestCase
    import random
    from unittest.mock import patch
    from mimesis.enums import Seed
    from mimesis.providers.choice import Choice

    class MyCase(TestCase):
        """Test for method __call__ of class Choice."""

        def setUp(self):
            """Set up fixtures."""
            self.choice = Choice(seed=4444, seed_type=Seed.NUMBER)

        def tearDown(self):
            """Tear down."""
            pass


# Generated at 2022-06-21 16:01:18.067476
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice"""
    pass


# Generated at 2022-06-21 16:01:19.152334
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert c.meta.name == 'choice'


# Generated at 2022-06-21 16:01:28.239931
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.misc import Choice as ChoiceMimesis
    from mimesis.providers.misc import Misc
    from mimesis.providers.person import Person
    from mimesis.providers.person.en import Provider as PersonEN
    from mimesis.providers.text import Text
    from mimesis.providers.text.en import Provider as TextEN

    random_choice = Choice().__call__  # type: Any
    random_choice = ChoiceMimesis().__call__  # type: Any

    assert isinstance(random_choice(['a', 'b', 'c'], 1, False), str)
    assert isinstance(random_choice(['a', 'b', 'c'], 1, True), str)
    assert isinstance

# Generated at 2022-06-21 16:01:36.123480
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from .choice import Choice
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    # assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

    try:
        choice(items=[], length=2)
    except ValueError as e:
        assert str(e) == '**items** must be a non-empty sequence.'

# Generated at 2022-06-21 16:01:40.985058
# Unit test for constructor of class Choice
def test_Choice():
    length = 2
    items = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
    c = Choice()
    print(c(items, length=length))

# Generated at 2022-06-21 16:01:42.247289
# Unit test for constructor of class Choice
def test_Choice():
    c=Choice()
    assert isinstance(c,Choice)


# Generated at 2022-06-21 16:01:49.736782
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in "abc"
    assert choice(items='abc', length=2) in "abc"
    assert choice(items='abc', length=2) in "abc"
    assert choice(items='abc', length=2) in "abc"
    assert choice(items=['a', 'b', 'c'], length=1) in ['a']
    assert choice(items=('a', 'b', 'c'), length=5) in ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) in 'cdba'


# Generated at 2022-06-21 16:04:38.795726
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Testing method __call__ of class Choice."""
    ch = Choice()
    assert ch(['a', 'b', 'c']) in ['a', 'b', 'c']
    assert ch(['a', 'b', 'c'], length=1) == ['a'] or \
           ch(['a', 'b', 'c'], length=1) == ['b'] or \
           ch(['a', 'b', 'c'], length=1) == ['c']
    assert ch('abc', length=2) in ['ab', 'ac', 'bc']

# Generated at 2022-06-21 16:04:43.254924
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 2
    choice = Choice()
    result = choice.__call__(items=items, length=length)
    assert isinstance(result, collections.abc.Sequence)
    assert len(result) == 2
    assert result[0] in ['a', 'b', 'c']
    assert result[1] in ['a', 'b', 'c']
    assert result[0] != result[1]
    # test for unique elements
    result = choice.__call__(items=items, length=length, unique=True)
    assert isinstance(result, collections.abc.Sequence)
    assert len(result) == 2
    assert result[0] in ['a', 'b', 'c']
    assert result[1] in ['a', 'b', 'c']


# Generated at 2022-06-21 16:04:52.602472
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-21 16:05:03.539861
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c'], length=0) == 'b'
    assert Choice().__call__(items=('a', 'b', 'c'), length=0) == 'c'
    assert Choice().__call__(items='abc', length=0) == 'c'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) == 'bc'
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('b', 'a', 'c', 'b', 'b')

# Generated at 2022-06-21 16:05:05.170987
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    profile = Choice()
    assert profile(items=['a', 'b', 'c']) == 'c'
    assert profile(items=('a', 'b', 'c'), length=1) == ('a',)


# Generated at 2022-06-21 16:05:05.888043
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice


# Generated at 2022-06-21 16:05:11.041342
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.data import DATA

    c = Choice(seed=0)
    assert c(DATA['vowels']) == 'u'
    assert c(DATA['vowels'], length=1) == ['i']

    c.random.seed(0)
    assert c(DATA['vowels']) == 'u'
    assert c(DATA['vowels'], length=1) == ['i']


# Generated at 2022-06-21 16:05:11.858957
# Unit test for constructor of class Choice
def test_Choice():
     choice = Choice()
     assert isinstance(choice, Choice)
     


# Generated at 2022-06-21 16:05:12.236791
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-21 16:05:20.577913
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ab', 'bc', 'ac']