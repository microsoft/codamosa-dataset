

# Generated at 2022-06-21 15:56:26.241857
# Unit test for constructor of class Choice
def test_Choice():
    results = [Choice.Meta.name == 'choice',]

# Unit tests for method call of class Choice

# Generated at 2022-06-21 15:56:28.221906
# Unit test for constructor of class Choice
def test_Choice():
    if not hasattr(Choice, '__init__'):
        raise Exception("Class 'Choice' has no __init__ constructor")

# Generated at 2022-06-21 15:56:36.280654
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-21 15:56:43.096636
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test choice method."""
    # TODO: Should be done in normal ways

    class ChoiceMock(Choice):
        """Class of mocked choice."""

        def __init__(self):
            """Set up attributes."""
            self.random_choice = iter([1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89])

# Generated at 2022-06-21 15:56:54.629018
# Unit test for constructor of class Choice
def test_Choice():
    """Test constructor of class Choice."""
    choice = Choice()
    assert choice.__call__(['a', 'b', 'c']) == 'c'
    assert choice.__call__(items='abc', length=2) == 'ba'
    assert choice.__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice.__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    # TODO: TEST TYPE ERROR
    # assert choice.__call__(items=['a', 'b', 'c'], length=0.5) == 'c'

# Generated at 2022-06-21 15:57:00.946921
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert isinstance(c, Choice)
    assert isinstance(c.random, Choice.random.__class__)
    assert isinstance(c.datetime, Choice.datetime.__class__)
    assert isinstance(c.timer, Choice.timer.__class__)
    assert isinstance(c.meta, Choice.meta.__class__)
    assert isinstance(c.provider_name, Choice.provider_name.__class__)
    assert isinstance(c.seed, Choice.seed.__class__)
    assert isinstance(c._seed, Choice._seed.__class__)
    assert isinstance(c._quatum, Choice._quatum.__class__)
    assert isinstance(c._use_sysrandom, Choice._use_sysrandom.__class__)

# Generated at 2022-06-21 15:57:03.685064
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert c.__doc__ is not None
    assert c.__init__.__doc__ is not None
    assert c.__call__.__doc__ is not None


# Generated at 2022-06-21 15:57:14.395193
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()

    # test empty sequence
    try:
        c(items=())
    except ValueError:
        pass
    else:
        assert False
    try:
        c(items=[])
    except ValueError:
        pass
    else:
        assert False
    try:
        c(items='')
    except ValueError:
        pass
    else:
        assert False

    # test for length < 0
    try:
        c(items=[1, 2, 3], length=-1)
    except ValueError:
        pass
    else:
        assert False
    try:
        c(items=(1, 2, 3), length=-1)
    except ValueError:
        pass
    else:
        assert False

# Generated at 2022-06-21 15:57:17.632137
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    choice = Choice()

    result = choice(items)
    print(result)

    result = choice(items, length=1000)
    print(result)

    print(choice(items, length=20, unique=True))

# Generated at 2022-06-21 15:57:26.045515
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis.providers.text import Text
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.misc import Misc
    from mimesis.providers.internet import Internet
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.file import File

    choice = Choice(Datetime(), Misc(), Internet(), Numbers(), Text(), File())

    # Test __init__()
    assert isinstance(choice, Choice)
    assert isinstance(choice, BaseProvider)

    # Test __call__()
    # Correct execution
    assert choice(items=[1, 2, 3], length=2) == [2, 2]
    assert choice(items=[1, 2, 3]) in [1, 2, 3]

    # Incorrect execution

# Generated at 2022-06-21 15:57:35.773598
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-21 15:57:45.792134
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # item is not a sequence
    with pytest.raises(TypeError):
        assert Choice(seed=42)._Choice__call__(items=None, length=1)

    # length is not an int
    with pytest.raises(TypeError):
        assert Choice(seed=42)._Choice__call__(items=['a', 'b', 'c'], length=1.1)

    # length is negative
    with pytest.raises(ValueError):
        assert Choice(seed=42)._Choice__call__(items=['a', 'b', 'c'], length=-1)

    # item is an empty sequence
    with pytest.raises(ValueError):
        assert Choice(seed=42)._Choice__call__(items=[], length=1)

    # length == 0

    # item is a list

# Generated at 2022-06-21 15:57:47.467311
# Unit test for constructor of class Choice
def test_Choice():
    """Unit test for constructor of Choice class."""
    choice = Choice()
    assert choice is not None

# Generated at 2022-06-21 15:57:57.118647
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'b'
    assert choice(items=['a', 'b', 'c'], length=1) == ['b']
    assert choice(items='abc', length=2) == 'cb'
    assert choice(items=('a', 'b', 'c'), length=5) == ('a', 'b', 'a', 'b', 'b')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'acbd'

# Generated at 2022-06-21 15:57:58.537862
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice.__class__.__name__ == 'Choice'

# Generated at 2022-06-21 15:58:05.432641
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    try:
        choice(items=('a', 'b', 'c'), length='2')
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-21 15:58:06.863609
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice("Mimesis")
    assert isinstance(c, Choice)

# Generated at 2022-06-21 15:58:15.307476
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice"""
    from mimesis import Choice
    choice = Choice()
    assert choice.choice(items=['a', 'b', 'c'], length=1, unique=True) == 'a'
    assert choice.choice(items=['a', 'b', 'c'], length=1, unique=False) == 'c'
    assert choice.choice(items=['a', 'b', 'c'], length=2, unique=True) == 'bc'
    assert choice.choice(items=['a', 'b', 'c'], length=2, unique=False) in ['ca', 'cb', 'cc']
    assert choice.choice(items=['a', 'b', 'c'], length=3, unique=True) == 'bac'

# Generated at 2022-06-21 15:58:25.773063
# Unit test for constructor of class Choice
def test_Choice():

    # Unit test for __init__ of Choice
    assert Choice.__init__ is not None

    # Unit test for __call__ of Choice
    assert Choice().__call__('aabbcc', unique=True) is not None
    assert Choice().__call__('aabbcc', length=2, unique=True) is not None
    assert Choice().__call__('aabbccdd', length=3) is not None
    assert Choice().__call__(['a', 'b', 'c']) is not None
    assert Choice().__call__(['a', 'b', 'c'], length=1) is not None
    assert Choice().__call__('abc', length=2) is not None
    assert Choice().__call__(('a', 'b', 'c'), length=5) is not None

# Generated at 2022-06-21 15:58:41.098358
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import mimesis
    c = mimesis.Choice()
    assert c(items=['a', 'b', 'c']) == 'c'
    assert c(items=['a', 'b', 'c'], length=1) == ['a']
    assert c(items='abc', length=2) == 'ba'
    assert c(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert c(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-21 15:58:46.749078
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)


# Generated at 2022-06-21 15:58:53.411619
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """The method tests the output when calling __call__ method of the class Choice."""
    # TODO: This is NOT a unit test for the method __call__().
    # TODO: It just tests the usage of the method.
    from mimesis import Choice

    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-21 15:58:55.057324
# Unit test for constructor of class Choice
def test_Choice():
    instance = Choice()
    assert isinstance(instance, Choice)


# Generated at 2022-06-21 15:59:05.678839
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    # 1
    assert choice('abc') in 'abc'
    # 2
    assert choice('abc', 1) == ['a']
    # 3
    assert choice('abc', 2) in ['ab', 'ac', 'bc']
    assert len(choice('abc', 2)) == 2
    # 4
    assert choice('abc', 3) in ['aaa', 'aab', 'aac', 'aba', 'abb', 'abc', 'aca', 'acb', 'acc',
                                'baa', 'bab', 'bac', 'bba', 'bbb', 'bbc', 'bca', 'bcb', 'bcc',
                                'caa', 'cab', 'cac', 'cba', 'cbb', 'cbc', 'cca', 'ccb', 'ccc']

# Generated at 2022-06-21 15:59:15.938627
# Unit test for constructor of class Choice
def test_Choice():
    obj = Choice()
    print(obj.random.choice(items=[1, 2, 3]))
    print(obj.random.choice(items=[1, 2, 3], length=1))
    print(obj.random.choice(items=[1, 2, 3], length=2))
    print(obj.random.choice(items=[1, 2, 3], length=3))
    print(obj.random.choice(items=[1, 2, 3], length=4))
    print(obj.random.choice(items=[1, 2, 3], length=5))

    print(obj.random.choice(items=[1, 2, 3, 55, 77], length=5))
    print(obj.random.choice(items=[1, 2, 3, 55, 77], length=4))

# Generated at 2022-06-21 15:59:21.669207
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-21 15:59:23.841923
# Unit test for constructor of class Choice
def test_Choice():
    """Test case for the class constructor.
    """
    # Positive
    choice = Choice()
    assert choice is not None


# Generated at 2022-06-21 15:59:24.460743
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()

# Generated at 2022-06-21 15:59:26.913693
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    test = choice(items=[1,2,3,4,5])
    print(test)

# Generated at 2022-06-21 15:59:29.065596
# Unit test for constructor of class Choice
def test_Choice():
    """Unit test for Choice class constructor."""
    choice = Choice()
    assert choice.random.__class__.__name__ == 'Generator'


# Generated at 2022-06-21 15:59:42.803394
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    from random import choice

    from mimesis import Choice

    choice_nstdin = Choice()
    choice_stdin = Choice('stdin')
    items = ['a', 'b', 'c']
    length = 1
    unique = True

    # Basic usage
    assert choice(items) == choice_nstdin(items)
    assert choice(items) == choice_stdin(items)

    # Length specified
    assert [choice(items, length)] == choice_nstdin(items, length)
    assert [choice(items, length)] == choice_stdin(items, length)

    # Unique specified
    assert choice(items, length, unique) == choice_nstdin(items, length,
                                                          unique)

# Generated at 2022-06-21 15:59:43.931932
# Unit test for constructor of class Choice
def test_Choice():
    obj = Choice()
    assert obj is not None

# Generated at 2022-06-21 15:59:48.836178
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    res = choice(items=['a', 'b', 'c'], length=5)
    assert(res == ['a', 'b'])  
    #assert(res == ['a', 'b', 'b', 'a', 'c'])

test_Choice___call__()

# Generated at 2022-06-21 15:59:51.041453
# Unit test for constructor of class Choice
def test_Choice():
    """Unit test for constructor of class Choice."""
    c = Choice()
    assert isinstance(c, Choice)


# Generated at 2022-06-21 15:59:55.428782
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    choice(items=[1, 2, 3])
    choice(items=[1, 2, 3], length=1)
    choice(items='abc', length=2)
    choice(items=('a', 'b', 'c'), length=5)
    choice(items='aabbbccccddddd', length=4, unique=True)

test_Choice()

# Generated at 2022-06-21 15:59:56.713601
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-21 16:00:07.324977
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    result = choice(items=['a', 'b', 'c'], length=2, unique=True)
    assert(result in ['ab', 'ac', 'bc'])
    assert(len(result) == 2)
    result = choice(items=[1, 2, 3, 4], length=3, unique=True)
    assert(result in [[1, 2, 3], [1, 2, 4], [1, 3, 4], [2, 3, 4]])
    assert(len(result) == 3)
    result = choice(items=[1, 2, 3, 4], length=4, unique=False)
    assert(result in [[1, 2, 3, 4], [4, 3, 2, 1], [1, 1, 2, 3], [1, 4, 2, 3]])

# Generated at 2022-06-21 16:00:14.303512
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert callable(choice)
    assert choice.__class__.__name__ == 'Choice'
    assert choice.__class__.Meta.name == 'choice'


# Generated at 2022-06-21 16:00:15.136097
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert c


# Generated at 2022-06-21 16:00:16.215553
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice.__class__.__name__ == 'Choice'

# Generated at 2022-06-21 16:00:32.978461
# Unit test for constructor of class Choice
def test_Choice():
    obj = Choice()
    assert isinstance(obj, Choice)


# Generated at 2022-06-21 16:00:42.938400
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice.

    Note that this is a "generated" unit test.  This was generated by the
    program "test_generator.py" which is located in the source directory.
    The generated unit test is located in the generated file:
        
        tests/test_providers_choice_generated.py

    """
    import sys
    from os.path import dirname, join

    from mimesis import Choice

    sys.path.append(join(dirname(__file__), '..', 'tests'))
    from test_providers_choice_generated import TestChoice

    tc = TestChoice()
    for name, method in tc.items():
        method()

# Generated at 2022-06-21 16:00:44.406275
# Unit test for constructor of class Choice
def test_Choice():
    """Test for constructor of class Choice"""
    # TODO:
    # choice = Choice()
    pass

# Generated at 2022-06-21 16:00:54.063789
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    method = Choice().__call__
    _random = Choice().random.choice
    test_Choice___call___args = {
        'items': [],
        'length': 0,
        'unique': False,
    }
    expected = _random(test_Choice___call___args['items'])
    actual = method(**test_Choice___call___args)
    assert actual == expected, 'Line 27 of choice.py'

    test_Choice___call___args = {
        'items': [],
        'length': 1,
        'unique': False,
    }
    expected = []
    actual = method(**test_Choice___call___args)
    assert actual == expected, 'Line 36 of choice.py'


# Generated at 2022-06-21 16:00:55.666609
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import ChoicePlaceholder
    choice = Choice()


# Generated at 2022-06-21 16:01:02.172164
# Unit test for constructor of class Choice
def test_Choice():
    
    c = Choice()
    items = ['a', 'b', 'c']
    # length = 1
    # unique = False
    assert c.__class__ == Choice
    
    assert c.__call__(items, 1, False) ==  ['a']
    # assert c.__call__(items, 2, False) ==  ['a', 'b'] # it should be wrong since only one element is attached to return
    # assert c.__call__(items, 2, True) ==  ['a', 'b'] # it should be wrong since it is not unique
    assert c.__call__(items, 3, True) ==  ['c', 'a', 'b'] # it is correct since it is the maximum length

    # length = 0
    assert c.__call__(items, 0, False) ==  'c'
   

# Generated at 2022-06-21 16:01:02.864786
# Unit test for constructor of class Choice
def test_Choice():
    pass

# Generated at 2022-06-21 16:01:03.812830
# Unit test for constructor of class Choice
def test_Choice():
    obj = Choice()
    assert obj is not None

# Generated at 2022-06-21 16:01:05.521084
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method ``Choice.__call__()``."""


# vim: tabstop=4 expandtab shiftwidth=4 softtabstop=4 autoindent

# Generated at 2022-06-21 16:01:06.396679
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert callable(Choice()._Choice__call__)

# Generated at 2022-06-21 16:01:39.554420
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    print(choice('abc'))


# Generated at 2022-06-21 16:01:49.013857
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    class_ = Choice()
    assert class_.__call__(items=['a', 'b', 'c']) == 'c'
    assert class_.__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert class_.__call__(items='abc', length=2) == 'ba'
    assert class_.__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert class_.__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    try:
        class_.__call__(items=['a', 'b', 'c'], length='string')
    except TypeError:
        pass
    else:
        assert False

# Generated at 2022-06-21 16:01:57.820253
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    div = Choice(seed=123)

    items = [1, 2, 3, 4, 5]
    assert div(items) == 3
    assert div(items, 1) == [1]
    assert div(items, 2) == [1, 2]
    assert div(items, 5) == [3, 1, 5, 2, 1]
    assert div(items, unique=True) == 5
    assert div(items, 1, unique=True) == [4]
    assert div(items, 2, unique=True) == [5, 1]
    assert div(items, 5, unique=True) == [2, 3, 5, 4, 1]

    items = 'abcdef'

    assert div(items) == 'f'
    assert div(items, 1) == ['a']

# Generated at 2022-06-21 16:02:08.688638
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    import random
    import string
    random.seed(0)
    items = ''.join(random.choices(string.ascii_letters + string.digits, k=10))
    assert c(items, length=0) == '3'
    assert c(items, length=1) == ['u']
    assert c(items, length=2) == '7e'
    assert c(items, length=5) == ('7', 'e', 'a', 'w', '1')
    assert c(items, length=4, unique=True) == '7ew5'
    random.seed(0)
    l = list(items)
    random.shuffle(l)
    assert c(l, length=0) == '3'

# Generated at 2022-06-21 16:02:15.675850
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()

    # test for __call__
    print(choice(items=['a', 'b', 'c']))
    print(choice(items=['a', 'b', 'c'], length=1))
    print(choice(items='abc', length=2))
    print(choice(items=('a', 'b', 'c'), length=5))
    print(choice(items='aabbbccccddddd', length=4, unique=True))

    print(choice(items='aabbbccccddddd', length=10, unique=True))


if __name__ == "__main__":
    test_Choice()

# Generated at 2022-06-21 16:02:24.307664
# Unit test for constructor of class Choice
def test_Choice():
    ch = Choice()
    assert ch.random.choice(items=['a', 'b', 'c']) in {'a', 'b', 'c'}
    assert ch.random.choice(items=['a', 'b', 'c'], length=1) == ['b']
    assert ch.random.choice(items='abc', length=2) in {'ab', 'ac', 'bc'}
    assert ch.random.choice(items=('a', 'b', 'c'), length=5) == ('b', 'c', 'c', 'a', 'c')
    assert ch.random.choice(items='aabbbccccddddd', length=4, unique=True) in {'dab', 'abd', 'db', 'bad', 'da'}


# Generated at 2022-06-21 16:02:28.290321
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert callable(choice.__call__)
    assert callable(choice(items=['a', 'b', 'c'], length=1))
    assert callable(choice(items='abc', length=2))
    assert callable(choice(items=('a', 'b', 'c'), length=5))
    assert callable(choice(items='aabbbccccddddd', length=4, unique=True))
    assert choice.choice(items=['a', 'b', 'c'], length=1) == ['c']


# Generated at 2022-06-21 16:02:31.776886
# Unit test for constructor of class Choice
def test_Choice():
    print("Test Choice... ", end='', flush=True)
    try:
        choice = Choice()
        print("OK")
    except:
        print("FAIL")


# Generated at 2022-06-21 16:02:33.617210
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert isinstance(c, Choice)


# Generated at 2022-06-21 16:02:36.655151
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    items=['a','b','c']
    length=3
    unique=False
    choice = Choice()
    random_choice= choice(items,length,unique)

    assert(isinstance(random_choice, list))
    assert(len(random_choice)==length)
    assert(all(random_choice[i] in items for i in range(len(random_choice))))

# Generated at 2022-06-21 16:03:39.435756
# Unit test for constructor of class Choice
def test_Choice():
    Choice()

# Generated at 2022-06-21 16:03:43.823300
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    try:
        c('1')
    except TypeError:
        pass
    try:
        c(['a','b','c'], 1.0)
    except TypeError:
        pass
    try:
        c([])
    except ValueError:
        pass
    try:
        c(['a', 'b', 'c'], -1)
    except ValueError:
        pass
    try:
        c(['a', 'b', 'c'], 1, True)
    except ValueError:
        pass
    try:
        c(['a', 'b', 'c'], 1, True, [])
    except TypeError:
        pass

# Generated at 2022-06-21 16:03:45.823304
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)


# Generated at 2022-06-21 16:03:56.222291
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ba', 'ac', 'cb']
    assert choice(items=('a', 'b', 'c'), length=5) in [
        ('c', 'a', 'a', 'b', 'c'), ('c', 'c', 'a', 'a', 'b'),
        ('b', 'c', 'c', 'a', 'a'), ('a', 'b', 'c', 'c', 'a'),
        ('a', 'a', 'b', 'c', 'c')
    ]

# Generated at 2022-06-21 16:04:03.924398
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.providers.choice import Choice
    choice = Choice()
    choice_obj1 = choice(items=['a', 'b', 'c'])
    assert isinstance(choice_obj1, str)
    choice_obj2 = choice(items=['a', 'b', 'c'], length=1)
    assert isinstance(choice_obj2, list)
    choice_obj3 = choice(items='abc', length=2)
    assert isinstance(choice_obj3, str)
    choice_obj4 = choice(items=('a', 'b', 'c'), length=5)
    assert isinstance(choice_obj4, tuple)
    choice_obj5 = choice(items='aabbbccccddddd', length=4, unique=True)
    assert isinstance(choice_obj5, str)


# Generated at 2022-06-21 16:04:04.631180
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-21 16:04:05.061538
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice is Choice

# Generated at 2022-06-21 16:04:06.888577
# Unit test for constructor of class Choice
def test_Choice():
    ch = Choice()
    assert ch._rand is not None


# Generated at 2022-06-21 16:04:17.217341
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    provider = Choice()

    data = ['a', 'b', 'c']
    data_result = provider(items=data)
    assert isinstance(data_result, str)
    assert data_result in data

    data_result = provider(items=data, length=1)
    assert isinstance(data_result, list)
    assert len(data_result) == 1
    assert data_result[0] in data

    data_result = provider(items='abc', length=2)
    assert isinstance(data_result, str)
    assert len(data_result) == 2
    for item in data_result:
        assert item in data

    data_result = provider(items=('a', 'b', 'c'), length=5)
    assert isinstance(data_result, tuple)

# Generated at 2022-06-21 16:04:18.695045
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    items = choice(items=['a', 'b', 'c'])
    assert isinstance(items, str)
