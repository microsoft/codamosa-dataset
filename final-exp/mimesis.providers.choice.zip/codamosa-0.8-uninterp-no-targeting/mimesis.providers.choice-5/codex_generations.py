

# Generated at 2022-06-21 15:56:40.185544
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a'] or \
        Choice().__call__(items=['a', 'b', 'c'], length=1) == ['b'] or \
        Choice().__call__(items=['a', 'b', 'c'], length=1) == ['c']
    assert Choice().__call__(items='abc', length=2) in ['ab', 'bc', 'ac']

# Generated at 2022-06-21 15:56:41.662286
# Unit test for constructor of class Choice
def test_Choice():
    ch = Choice()
    return ch

# Test for Choice.__call__

# Generated at 2022-06-21 15:56:46.075883
# Unit test for constructor of class Choice
def test_Choice():
    seq = [1,2,3,4,5]
    choice = Choice()
    seq_choice = choice(items=seq)
    assert isinstance(seq_choice, int)

# Generated at 2022-06-21 15:56:58.369259
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import pytest
    from mimesis import Choice
    choice = Choice()
    assert choice.choice(items=["a","b","c"]) == "c"
    assert choice.choice(items=["a","b","c"], length=1) == ["a"]
    assert choice.choice(items="abc", length=2) == "ba"
    assert choice.choice(items=('a','b','c'), length=5) == ('c','a','a','b','c')
    assert choice.choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

    with pytest.raises(TypeError):
        choice.choice(items="abc", length="1")

    with pytest.raises(TypeError):
        choice.choice(items=12, length=1)

   

# Generated at 2022-06-21 15:57:00.240933
# Unit test for constructor of class Choice
def test_Choice():
    """Test the constructor of class Choice.
    """
    obj_choice = Choice()
    assert obj_choice

# Generated at 2022-06-21 15:57:02.833923
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 1
    unique = False

    choice = Choice()
    choice(items=items, length=length, unique=unique)


# Generated at 2022-06-21 15:57:13.755903
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # a = Choice.__call__(items=['a', 'b', 'c'])
    # b = Choice.__call__(items=['a', 'b', 'c'], length=1)
    # c = Choice.__call__(items='abc', length=2)
    # d = Choice.__call__(items=('a', 'b', 'c'), length=5)
    # e = Choice.__call__(items='aabbbccccddddd', length=4, unique=True)

    choice = Choice()
    a = choice(items=['a', 'b', 'c'])
    b = choice(items=['a', 'b', 'c'], length=1)
    c = choice(items='abc', length=2)

# Generated at 2022-06-21 15:57:14.566646
# Unit test for constructor of class Choice
def test_Choice():
    assert isinstance(Choice, object)


# Generated at 2022-06-21 15:57:16.219807
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice(['a', 'b', 'c'], 0) == choice(['a', 'b', 'c'])

# Generated at 2022-06-21 15:57:21.645970
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    this = Choice()
    assert isinstance(this(['a', 'b', 'c']), str)
    assert isinstance(this(['a', 'b', 'c'], 1), list)
    assert isinstance(this('abc', 2), str)
    assert isinstance(this(('a', 'b', 'c'), 5), tuple)
    assert isinstance(this('aabbbccccddddd', 4, True), str)

# Generated at 2022-06-21 15:59:22.134268
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    choice(items=['a', 'b', 'c'])
    choice(items=['a', 'b', 'c'], length=1)
    choice(items='abc', length=2)
    choice(items=('a', 'b', 'c'), length=5)
    choice(items='aabbbccccddddd', length=4, unique=True)
    items=['a', 'b', 'c']
    length=1
    unique=True
    choice(items, length, unique)
    print("test_Choice() PASSED")

# Generated at 2022-06-21 15:59:30.782555
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test Choice.__call__ method.

    >>> from mimesis import Choice
    >>> choice = Choice()

    >>> choice(items=['a', 'b', 'c'])
    'c'
    >>> choice(items=['a', 'b', 'c'], length=1)
    ['a']
    >>> choice(items='abc', length=2)
    'ba'
    >>> choice(items=('a', 'b', 'c'), length=5)
    ('c', 'a', 'a', 'b', 'c')
    >>> choice(items='aabbbccccddddd', length=4, unique=True)
    'cdba'

    """

# Generated at 2022-06-21 15:59:32.672010
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)

# Generated at 2022-06-21 15:59:41.536778
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    class Choice(object):
        def __init__(self, seed=None, *args, **kwargs):
            self.seed = seed
        def choice(self, items):
            return items[self.seed]

    TestChoice = Choice(seed = 1)


# Generated at 2022-06-21 15:59:52.825687
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from . import Choice
    provider = Choice()
    data = provider(['a', 'b', 'c'])
    assert data in ('a', 'b', 'c')
    data = provider(['a', 'b', 'c'], length=1)
    assert data in (['a'], ['b'], ['c'])
    data = provider('abc', length=2)
    assert data in ('ba', 'ca', 'cb','ab')
    data = provider(('a', 'b', 'c'), length=5)

# Generated at 2022-06-21 15:59:58.760240
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Check __call__ method for class Choice."""
    from mimesis import Choice
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-21 16:00:05.728709
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = ['a','b','c','d']
    length = 3
    unique = True
    assert (choice(items,length,unique) in items)
    assert (len(choice(items,length,unique)) == len(choice(items,length,unique))) == length
    assert (unique and choice(items, length, unique) not in choice(items, length, unique))
    assert all(x in items for x in choice(items,length,unique))

# Generated at 2022-06-21 16:00:07.783450
# Unit test for constructor of class Choice
def test_Choice():
    items = ['a', 'b', 'c']
    choice = Choice()
    assert choice(items) in items


# Generated at 2022-06-21 16:00:14.327742
# Unit test for constructor of class Choice
def test_Choice():
    """
    
    """
    choice = Choice()
    assert choice.__class__.__name__ == "Choice"

# test_Choice()



# Generated at 2022-06-21 16:00:18.295593
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    for _ in range(100):
        try:
            assert random.choice(['a', 'b', 'c', 'd', 'e']) \
                   in ['a', 'b', 'c', 'd', 'e']
        except AssertionError:
            pass

