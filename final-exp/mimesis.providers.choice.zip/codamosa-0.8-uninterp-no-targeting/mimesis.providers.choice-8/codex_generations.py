

# Generated at 2022-06-21 15:56:27.875821
# Unit test for constructor of class Choice
def test_Choice():
    """Test the constructor of class Choice."""
    c = Choice()
    # print(c)
    # print(repr(c))
    # print(str(c))
    # print(c.serialize())
    assert c is not None


# Generated at 2022-06-21 15:56:36.327398
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-21 15:56:44.890752
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    from mimesis import Choice

    choice = Choice()

    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-21 15:56:49.003233
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = ['a', 'b', 'c']
    element = choice(items=items)
    assert element in items
    assert isinstance(element, str)


# Generated at 2022-06-21 15:56:58.214976
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert isinstance(Choice("a", "b", length=2), list)
    assert type(Choice("a", "b", unique=True)) == str
    assert Choice("a", "b", length=2) == ['b', 'a']
    assert Choice("a", "b", length=2) == ["b", "a"]
    assert Choice("a", "b", length=2) == ("b", "a")
    assert Choice("a", "b", unique=True) == "b" or "a"
    assert Choice("a", "b", unique=True) != "b" or "a"

# Generated at 2022-06-21 15:56:58.884441
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-21 15:57:04.997079
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ab', 'ac', 'bc']
    assert choice(items=('a', 'b', 'c'), length=5) in [
        ('a', 'b', 'c', 'a', 'b'), ('a', 'b', 'c', 'a', 'c'), ('a', 'b', 'c', 'b', 'c')
    ]

# Generated at 2022-06-21 15:57:09.648932
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert c.__str__() == 'Choice'
    assert c.__doc__ == Choice.__doc__
    assert c.items == []
    assert c.length == 0
    assert c.unique == False
    assert c.Meta.name == 'choice'


# Generated at 2022-06-21 15:57:12.703044
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    class Meta(Choice.Meta):
        name = 'choice'
    choice._meta = Meta()
    assert choice([1,2],2) in [(1,2),(2,1)]

# Generated at 2022-06-21 15:57:13.755954
# Unit test for constructor of class Choice
def test_Choice():
    assert issubclass(Choice, BaseProvider)

# Generated at 2022-06-21 15:57:27.460787
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items = ['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items = ['a', 'b', 'c'], length = 1) == ['a']
    assert Choice().__call__(items = 'abc', length = 2) == 'ba'
    assert Choice().__call__(items = ('a', 'b', 'c'), length = 5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items = 'aabbbccccddddd', length = 4, unique = True) == 'cdba'
    try:
        Choice().__call__(items = 1)
    except TypeError:
        pass


# Generated at 2022-06-21 15:57:37.863815
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice('abc') in ['a', 'b', 'c']
    assert choice('abc', length=1) in [['a'], ['b'], ['c']]
    assert choice('abc', length=2) in ['ab', 'bc', 'ac']
    assert choice('aabbbccccddddd', length=4, unique=True) in ['cabd', 'bacd', 'dabc', 'cbad', 'cdab', 'bdac', 'cdba', 'dacb']
    try:
        choice(500)
    except TypeError as e:
        assert str(e) == '**items** must be non-empty sequence.'

# Generated at 2022-06-21 15:57:44.637866
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    choice = Choice()

    assert choice(items=['a', 'b', 'c'], length=1, unique=False) == ['c']
    assert choice(items=['a', 'b', 'c'], length=1, unique=True) == ['c']
    assert choice(items='abc', length=2, unique=False) == 'bc'
    assert choice(items='abc', length=2, unique=True) == 'cb'
    assert choice(items=('a', 'b', 'c'), length=5, unique=False) == ('a', 'a', 'c', 'a', 'c')

# Generated at 2022-06-21 15:57:46.382366
# Unit test for constructor of class Choice
def test_Choice():
    ch = Choice()
    print (ch(items=['a', 'b', 'c']))


# Generated at 2022-06-21 15:57:57.718221
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice() # objet de la classe Choice
    choice('a') # Un élément au hasard dans la liste différent de ''
    choice('a', unique=True) # Un élément au hasard dans la liste différent de ''
    choice('', unique=True) # Un élément au hasard dans la liste différent de ''
    choice([1, 2, 3]) # Un élément au hasard dans la liste différent de []
    choice([1, 2, 3], unique=True) # Un élément au hasard dans la liste différent de []
    choice([], unique=True) # Un élément au hasard dans la liste différent de []
    choice((1, 2, 3)) # Un élément au hasard dans

# Generated at 2022-06-21 15:58:03.084703
# Unit test for constructor of class Choice
def test_Choice():
    test_choice = Choice()
    test_choice(items=['a', 'b', 'c'])
    test_choice(items=['a', 'b', 'c'], length=1)
    test_choice(items='abc', length=2)
    test_choice(items=('a', 'b', 'c'), length=5)
    test_choice(items='aabbbccccddddd', length=4, unique=True)
    assert True

# Generated at 2022-06-21 15:58:05.024570
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice(items=['a', 'b', 'c'], length=0, unique=False) == 'c'

# Generated at 2022-06-21 15:58:12.125856
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(['a', 'b', 'c'])
    assert Choice().__call__(['a', 'b', 'c'], length=1)
    assert Choice().__call__('abc', length=2)
    assert Choice().__call__(('a', 'b', 'c'), length=5)
    assert Choice().__call__('aabbbccccddddd', length=4, unique=True)

    assert Choice().__call__(None, length=1) == []
    assert Choice().__call__(items=None) == ''

# Generated at 2022-06-21 15:58:19.561708
# Unit test for constructor of class Choice
def test_Choice():
    """Class Choice"""
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-21 15:58:28.067444
# Unit test for method __call__ of class Choice

# Generated at 2022-06-21 15:58:46.752059
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert callable(choice)


# Unit tests for method __call__ of class Choice

# Generated at 2022-06-21 15:58:47.829673
# Unit test for constructor of class Choice
def test_Choice():
    obj = Choice()
    assert obj.items == []


# Generated at 2022-06-21 15:58:50.262858
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis import Choice
    choice = Choice()
    assert isinstance(choice, Choice)
    assert isinstance(choice.random, Choice.random.__class__)


# Generated at 2022-06-21 15:59:00.593572
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""

    from mimesis import Choice

    choice = Choice()

    # Test 1: Normal behavior
    result = choice(items=['a', 'b', 'c'])
    assert result == 'c' or result == 'b' or result == 'a'

    # Test 2: Normal behavior
    result = choice(items=['a', 'b', 'c'], length=1)
    assert result == ['a'] or result == ['b'] or result == ['c']

    # Test 3: Normal behavior
    result = choice(items='abc', length=2)
    assert result == 'ba' or result == 'bc' or result == 'ca' or\
        result == 'cb' or result == 'ac' or result == 'ab'

    # Test 4: Normal behavior

# Generated at 2022-06-21 15:59:10.757682
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Init object
    choice = Choice("en")
    
    # Call method
    assert len(choice(items=[1, 2, 3])) <= 3
    assert type(choice(items=[1, 2, 3])) == int
    assert len(choice(items=[1, 2, 3], length=1)) == 1
    assert [choice(items=[1, 2, 3], length=1)] == [1]
    assert len(choice(items=[1, 2, 3], length=2)) == 2
    assert len(choice(items=[1, 2, 3], length=4)) == 4
    assert choice(items=[1, 2, 3], length=1) == 1
    assert choice(items=[1, 2, 3], length=2) == 2
    assert choice(items=[1, 2, 3], length=3) == 3
   

# Generated at 2022-06-21 15:59:13.169044
# Unit test for constructor of class Choice
def test_Choice():
    items=['a', 'b', 'c']
    length= 1
    unique= False
    a= Choice()
    assert a(items,length,unique) == 'c'

# Generated at 2022-06-21 15:59:20.251752
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Tests for method __call__ of class Choice."""
    # Test for method __call__ without length and unique
    seed = 10
    choice = Choice(seed=seed)  # type: ignore
    expected = 'あ'
    actual = choice(['あ', 'い', 'う'])
    assert actual == expected

    # Test for method __call__ with length and unique
    seed = 10
    choice = Choice(seed=seed)
    expected = 'あい'
    actual = choice(['あ', 'い', 'う', 'あ', 'い'], length=2, unique=True)
    assert actual == expected

# Generated at 2022-06-21 15:59:28.447282
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice()(items=['a', 'b', 'c']) == 'c'
    assert Choice()(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice()(items='abc', length=2) == 'ba'
    assert Choice()(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice()(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-21 15:59:29.769876
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TODO: implement test
    pass


# Generated at 2022-06-21 15:59:31.187429
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice(items = ['a', 'b', 'c']) == 'c'

# Generated at 2022-06-21 16:04:53.292328
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    print(c.__doc__)
    c = Choice('en')
    print(c.__doc__)


# Generated at 2022-06-21 16:05:04.022723
# Unit test for constructor of class Choice
def test_Choice():
    # Successful cases
    Choice(None)
    # Raises TypeError for unsupported types

    # Successful cases
    Choice(None).__call__(['a', 'b', 'c'])
    Choice(None).__call__(['a', 'b', 'c'], 1)
    Choice(None).__call__('abc', 2)
    Choice(None).__call__(('a', 'b', 'c'), 5)
    Choice(None).__call__('aabbbccccddddd', 4, True)
    # Raises ValueError when items is not iterable
    try:
        Choice(None).__call__(None)
    except ValueError:
        pass
    # Raises ValueError when length is not a positive integer

# Generated at 2022-06-21 16:05:07.678582
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis.providers.datetime import Datetime
    dt = Datetime()
    dt.datetime(min_year=1, max_year=2)
    dt.date(min_year=1, max_year=2)

# Generated at 2022-06-21 16:05:09.296742
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice()


# Generated at 2022-06-21 16:05:16.954697
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()

    test1 = choice(items=["a", "b", "c"])
    assert isinstance(test1, str)

    test2 = choice(items=["a", "b", "c"], length=1)
    assert isinstance(test2, list)

    test3 = choice(items="abc", length=2)
    assert isinstance(test3, str)

    test4 = choice(items=("a", "b", "c"), length=5)
    assert isinstance(test4, tuple)

    test5 = choice(items="aabbbccccddddd", length=4, unique=True)
    assert isinstance(test5, str)


# Generated at 2022-06-21 16:05:19.991375
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice is not None

# Generated at 2022-06-21 16:05:26.432381
# Unit test for constructor of class Choice
def test_Choice():
    a = Choice()
    b = Choice(a)
    c = Choice('abc')
    d = Choice([1, 2, 3])
    e = Choice((1, 2, 3))
    assert a is not None
    assert b is not None
    assert c is not None
    assert d is not None
    assert e is not None


# Generated at 2022-06-21 16:05:33.775744
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice

    choice = Choice()
    print(choice(items=['a', 'b', 'c']))

    print(choice(items=['a', 'b', 'c'], length=1))
    print(choice(items='abc', length=2))
    print(choice(items=('a', 'b', 'c'), length=5))

    print(choice(items='aabbbccccddddd', length=4, unique=True))

if __name__ == '__main__':
    test_Choice___call__()

# Generated at 2022-06-21 16:05:45.204777
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert isinstance(choice(items=['a', 'b', 'c'], length=1), list)
    assert isinstance(choice(items=('a', 'b', 'c'), length=1), tuple)
    assert isinstance(choice(items='abc', length=1), str)
    assert ''.join(choice(items='abc', length=1)) == 'a'
    assert choice(items='abc', length=1) == 'a'
    assert choice(items=['a', 'b', 'c'], length=2) == ['c', 'a']

    try:
        choice(items=['a', 'b', 'c'], length='a')
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-21 16:05:52.715273
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test Choice.__call__ method."""
    from mimesis import Choice
    from mimesis.exc import NonEnumerableError
    from mimesis.builtins import Person

    choice = Choice()
    assert isinstance(choice(items=['a', 'b', 'c']), str)
    assert isinstance(choice(items=['a', 'b', 'c'], length=1), list)
    assert isinstance(choice(items='abc', length=2), str)
    assert isinstance(choice(items=('a', 'b', 'c'), length=5), tuple)
    assert isinstance(choice(items='aabbbccccddddd', length=4,
                             unique=True), str)