

# Generated at 2022-06-21 15:56:28.694364
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    from mimesis import Choice
    from mimesis.exceptions import NonUniqueSequence
    from mimesis.exceptions import NonSequenceError

    choice = Choice()


# Generated at 2022-06-21 15:56:39.239792
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert c.choice(['a', 'b'], 1) in  ['a', 'b'], 'test_Choice'
    assert isinstance(c.choice(['a', 'b'], 1), list), 'test_choice_list'
    assert isinstance(c.choice('ab', 1), str), 'test_choice_str'
    assert isinstance(c.choice(('a', 'b'), 1), tuple), 'test_choice_tuple'
    assert isinstance(c.choice(('a', 'b'), 2), tuple), 'test_choice_tuple2'

    #test errors
    try:
        c.choice([], 2)
        assert False, 'test_choice_error'
    except ValueError:
        pass


# Generated at 2022-06-21 15:56:47.085589
# Unit test for constructor of class Choice
def test_Choice():
    obj = Choice()
    assert obj
    if __name__ == '__main__':
        print(obj(items=['a', 'b', 'c'], length=1))
        print(obj(items='abc', length=2))
        print(obj(items=('a', 'b', 'c'), length=5))
        print(obj(items='aabbbccccddddd', length=4, unique=True))

# Generated at 2022-06-21 15:56:59.042671
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    __tracebackhide__ = True

    msg = 'Test method __call__::msg: %s, %s'
    choice = Choice()

    try:
        choice(items=['a', 'b', 'c'])
    except Exception as err:
        raise AssertionError(msg % ('elements', err))

    try:
        choice(items=['a', 'b', 'c'], length=1)
    except Exception as err:
        raise AssertionError(msg % ('list elements', err))

    try:
        choice(items='abc', length=2)
    except Exception as err:
        raise AssertionError(msg % ('string elements', err))

    try:
        choice(items=('a', 'b', 'c'), length=5)
    except Exception as err:
        raise AssertionError

# Generated at 2022-06-21 15:57:00.071143
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert c is not None

# Generated at 2022-06-21 15:57:00.611808
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-21 15:57:08.459067
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice.choice(items=['a', 'b', 'c']) == 'c'
    assert choice.choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice.choice(items='abc', length=2) == 'ba'
    assert choice.choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice.choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-21 15:57:16.885149
# Unit test for constructor of class Choice
def test_Choice():
    provider = Choice()
    items = ['a', 'b', 'c']
    length = 1
    unique = True

    assert(isinstance(provider, Choice))
    assert(isinstance(items, collections.abc.Sequence))
    assert(isinstance(length, int))
    assert(isinstance(unique, bool))

    assert(isinstance(provider(items, length, unique), collections.abc.Sequence))

    assert(provider(items=['a', 'b', 'c'], length=1, unique=True) == ['a'])
    assert(provider(items=('a', 'b', 'c'), length=5, unique=True) == ('a', 'b', 'c', 'a', 'c'))



# Generated at 2022-06-21 15:57:25.244031
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method __call__ of class Choice"""
    choice = Choice()
    assert isinstance(choice(items=['a', 'b', 'c']), str)
    assert isinstance(choice(items=['a', 'b', 'c'], length=1), list)
    assert isinstance(choice(items='abc', length=2), str)
    assert isinstance(choice(items=('a', 'b', 'c'), length=5), tuple)
    assert isinstance(choice(items='aabbbccccddddd', length=4, unique=True), str)
    with raises(TypeError):
        choice(items=['a', 'b', 'c'], length='3')
    with raises(TypeError):
        choice(items=object())
    with raises(TypeError):
        choice(items=None)


# Generated at 2022-06-21 15:57:27.655692
# Unit test for constructor of class Choice
def test_Choice():
    # Create instance of class Choice
    a = Choice()
    # Test __init__
    assert a


# Generated at 2022-06-21 15:57:37.098319
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from lib import choice
    items = [1, 2, 3]
    length = 3
    unique = False
    choice_object = choice.Choice(items, length, unique)
    result = choice_object.__call__(items, length, unique)
    assert result == (1, 2, 3)

# Generated at 2022-06-21 15:57:37.624679
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-21 15:57:38.462143
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert c != None

# Generated at 2022-06-21 15:57:44.500842
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert 'ccc' == choice(items='abc', length=3)
    assert ['a', 'b', 'c'] == choice(items=['a', 'b', 'c'], length=3)
    assert 'cca' == choice(items='abc', unique=True, length=3)
    assert ['a', 'b', 'c'] == choice(items=('a', 'b', 'c'), unique=True, length=3)

# Generated at 2022-06-21 15:57:45.029929
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice


# Generated at 2022-06-21 15:57:51.085620
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    print('Testing Choice.__call__ ... ', end='')
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    print('Passed.')



# Generated at 2022-06-21 15:57:55.044614
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Arrange
    from mimesis import Choice
    choice = Choice()


    # Act
    result = choice(items=['a', 'b', 'c'])

    # Assert
    assert result == 'c'


# Generated at 2022-06-21 15:57:58.181707
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    result = Choice().__call__(items='abc', length=2)
    assert result == 'ba' or result == 'ab' or result == 'cb' or result == 'ac' or result == 'bc'

# Generated at 2022-06-21 15:57:59.787342
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)


# Generated at 2022-06-21 15:58:05.930996
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    p = Choice()
    # 1.
    res = p(items=['a', 'b', 'c'])
    assert res in ['a', 'b', 'c']
    # 2.
    res = p(items=['a', 'b', 'c'], length=1)
    assert res in [['a'], ['b'], ['c']]
    # 3.
    res = p(items='abc', length=2)
    assert res in ['aa', 'ab', 'ac', 'ba', 'bb', 'bc', 'ca', 'cb', 'cc']
    # 4.
    res = p(items=('a', 'b', 'c'), length=5)
    assert len(res) == 5

# Generated at 2022-06-21 15:58:21.975214
# Unit test for constructor of class Choice
def test_Choice():
    """Test for constructor of class Choice."""

    c = Choice
    assert isinstance(c, object)

# Generated at 2022-06-21 15:58:23.118348
# Unit test for constructor of class Choice
def test_Choice():
    a = Choice()
    assert a is not None

# Generated at 2022-06-21 15:58:24.704385
# Unit test for constructor of class Choice
def test_Choice():

    from mimesis import Choice
    mimesis = Choice()
    assert mimesis is not None


# Generated at 2022-06-21 15:58:27.269172
# Unit test for constructor of class Choice
def test_Choice():
    # Just a quick test to ensure this class works.
    # More extensive tests are found in tests/test_providers.py
    c = Choice()
    assert c.choice(['a', 'b', 'c']) in ['a','b','c']

# Generated at 2022-06-21 15:58:28.551130
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice('A') == 'A'

# Generated at 2022-06-21 15:58:41.111061
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Arrange
    choice = Choice()

    # Act
    items = choice(['a', 'b', 'c'])
    length = choice(['a', 'b', 'c'], 1)
    unique = choice('abc', 2)
    positive = choice(('a', 'b', 'c'), 5)
    negative = choice('aabbbccccddddd', 4, True)

    # Assert
    assert items in ['a', 'b', 'c']
    assert length == ['a']
    assert unique == 'ba'

# Generated at 2022-06-21 15:58:50.166533
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.builtins import Choice as BaseChoice
    choice = Choice()
    basechoice = BaseChoice()
    assert choice(items=['a', 'b', 'c']) == basechoice(['a', 'b', 'c'])
    assert choice(items=['a', 'b', 'c'], length=1) == basechoice(['a', 'b', 'c'], 1)
    assert choice(items='abc', length=2) == basechoice('abc', 2)
    assert choice(items=('a', 'b', 'c'), length=5) == basechoice(('a', 'b', 'c'), 5)
    assert choice(items='aabbbccccddddd', length=4, unique=True) == basechoice('aabbbccccddddd', 4, True)

# Generated at 2022-06-21 15:58:57.239532
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-21 15:58:59.515228
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=(), unique=True) == ()  # noqa


# Generated at 2022-06-21 15:59:09.803045
# Unit test for constructor of class Choice
def test_Choice():
	choice = Choice()
	test_items = [['a', 'b', 'c'], ['a', 'b', 'c'], ['a', 'b', 'c'], ['a', 'b', 'c'], ['a', 'b', 'c']]
	test_length = [1, 2, 3, 4, 5]
	test_unique = [False, False, False, False, True]
	test_res = [choice(items=test_items[i], length=test_length[i], unique=test_unique[i]) for i in range(0, 5)]
	test_correct = [['c'], ['b', 'a'], ['a', 'b', 'b'], ['c', 'b', 'b', 'a'], ['b', 'a', 'c', 'c']]

# Generated at 2022-06-21 15:59:50.769909
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice"""
    # TODO: write unit test
    assert False


# Generated at 2022-06-21 15:59:53.863467
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice(seed=1337)
    
    assert c(['a', 'b', 'c']) == 'c'
    assert c(['a', 'b', 'c'], 1) == ['a']
    assert c('abc', 2) == 'ba'
    assert c(('a', 'b', 'c'), 5) == ('c', 'a', 'a', 'b', 'c')
    assert c('aabbbccccddddd', 4, True) == 'cdba'

# Generated at 2022-06-21 15:59:59.920297
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    print(choice(items=['a', 'b', 'c']))
    print(choice(items=['a', 'b', 'c'], length=1))
    print(choice(items='abc', length=2))
    print(choice(items=('a', 'b', 'c'), length=5))
    print(choice(items='aabbbccccddddd', length=4, unique=True))

# test_Choice()

# Generated at 2022-06-21 16:00:02.262788
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice.seed is not None


# Generated at 2022-06-21 16:00:10.064361
# Unit test for constructor of class Choice
def test_Choice():
    """Test for class Choice."""
    choice = Choice()
    assert (choice(items=['a', 'b', 'c']) == "c")
    assert (choice(items=['a', 'b', 'c'], length=1) == ['a'])
    assert (choice(items='abc', length=2) == "ba")
    assert (choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c'))
    assert (choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba')


# Generated at 2022-06-21 16:00:14.308217
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-21 16:00:22.059262
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis import Choice

    choice = Choice()
    choice('abc', unique=True)
    #choice.items = ['a', 'b', 'c']
    #choice(length=3, unique=True)
    #choice.items = 'abcxc'
    #choice(length=3)

    t = choice('abc', length=0, unique=True)
    assert isinstance(t, str)

    t = choice('abc', length=1, unique=True)
    assert isinstance(t, str)

    t = choice('abc', length=1, unique=False)
    assert isinstance(t, str)

    t = choice('abc', length=2, unique=False)
    assert isinstance(t, str)

    t = choice('abc', length=2, unique=True)

# Generated at 2022-06-21 16:00:24.443614
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert isinstance(c, Choice)

# Generated at 2022-06-21 16:00:29.805339
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert choices('a', length=1) == ['a']
    assert choices('a', length=2) == ['a', 'a']
    assert choices('abcd', length=4) == ['d', 'b', 'a', 'd']
    assert choices('aabbbccccddddd', length=4) == ['d', 'd', 'c', 'a']

# Generated at 2022-06-21 16:00:31.368750
# Unit test for constructor of class Choice
def test_Choice():
    i = Choice()
    assert isinstance(i, Choice)


# Generated at 2022-06-21 16:01:33.478975
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method Choice.__call__.
    """
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    assert choice(items=('a', 'b', 'c')) in ('a', 'b', 'c')

# Generated at 2022-06-21 16:01:41.073297
# Unit test for constructor of class Choice
def test_Choice():
    # Test for invalid arguments
    try:
        Choice(items=None)
    except TypeError:
        assert True
    else:
        assert False

    try:
        Choice(items='a', length=None)
    except TypeError:
        assert True
    else:
        assert False

    try:
        Choice(items='a', length=-1)
    except ValueError:
        assert True
    else:
        assert False

    try:
        Choice(items='', length=1)
    except ValueError:
        assert True
    else:
        assert False

    try:
        Choice(items='', length=10, unique=True)
    except ValueError:
        assert True
    else:
        assert False

    # Test for valid arguments
    assert len(Choice.choice('abcde', length=5)) == 5

# Generated at 2022-06-21 16:01:43.242391
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice('en')
    # lang = 'en'
    c = choice(items = ['a', 'b', 'c'])
    print(c)

# Generated at 2022-06-21 16:01:52.012596
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.exceptions import NonEnumerableError

    choice = Choice()

    result = choice(items=['a', 'b', 'c'])
    assert result == 'c'

    result = choice(items=['a', 'b', 'c'], length=1)
    assert result == ['a']

    result = choice(items='abc', length=2)
    assert result == 'ba'

    result = choice(items=('a', 'b', 'c'), length=5)
    assert result == ('c', 'a', 'a', 'b', 'c')

    result = choice(items='aabbbccccddddd', length=4, unique=True)
    assert result == 'cdba'


# Generated at 2022-06-21 16:01:59.771385
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items='abc', length=2) in ['ab', 'ac', 'bc']
    assert choice(items=('a', 'b', 'c'), length=5) in [
        ('a', 'b', 'c', 'a', 'c'),
        ('a', 'b', 'c', 'a', 'b'),
        ('a', 'b', 'c', 'c', 'a'),
        ('a', 'b', 'c', 'b', 'c'),
        ('a', 'b', 'c', 'c', 'b'),
        ('a', 'b', 'c', 'b', 'a'),
    ]

# Generated at 2022-06-21 16:02:09.215567
# Unit test for constructor of class Choice
def test_Choice():
    items = ["a", "b", "c"]
    choice = Choice()
    choice.random.choice(items)
    choice(items=["a", "b", "c"])
    choice(items=["a", "b", "c"], length=1)
    choice(items="abc", length=2)
    choice(items=("a", "b", "c"), length=5)
    choice(items="aabbbccccddddd", length=4, unique=True)
    try:
        choice("abc", 1, True)
    except TypeError:
        pass
    try:
        choice(["a", "b", "c"], True, True)
    except TypeError:
        pass

# Generated at 2022-06-21 16:02:18.488087
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis.enums import Gender
    from mimesis.providers import Address, Person

    seed = 123456789

    random = Person('en')
    random.random = seed
    p = random.create_person_obj(gender=Gender.MALE)
    assert p['full_name'] == 'Benjamin Rosales'
    assert p['address'] == '221 Roosevelt St, Wausau, WI 54403'
    assert p['phone_number'] == '(225) 459-9882'
    assert p['email'] == 'jamesfoster@dacom.net'
    assert p['username'] == 'jamesfoster'

    random = Person('ru')
    random.random = seed
    p = random.create_person_obj(gender=Gender.MALE)

# Generated at 2022-06-21 16:02:25.980982
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice(seed=10)

    # return list
    assert choice(['a','b','c'], length=2) == ['a','a']
    assert choice(['a','b','c'], length=5) == ['c','a','a','b','c']
    assert choice(['a','b','c'], length=1) == ['a']
    assert choice(['a','b','c']) == 'c'
    # return tuple
    assert choice(('a','b','c'), length=2) == ('c','a')
    assert choice(('a','b','c'), length=5) == ('c','a','a','b','c')
    assert choice(('a','b','c'), length=1) == ('a',)
    assert choice(('a','b','c')) == 'c'
   

# Generated at 2022-06-21 16:02:26.388406
# Unit test for constructor of class Choice
def test_Choice():
    Choice()

# Generated at 2022-06-21 16:02:34.213852
# Unit test for constructor of class Choice
def test_Choice():
    ch = Choice()
    ch(items=['a', 'b', 'c'])
    ch(items=['a', 'b', 'c'], length=1)
    ch(items='abc', length=2)
    ch(items=('a', 'b', 'c'), length=5)
    ch(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-21 16:04:14.712957
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    result = Choice().__call__(items=[1,2,3])
    expected = 3
    assert result == expected


# Generated at 2022-06-21 16:04:15.553593
# Unit test for constructor of class Choice
def test_Choice():
    obj = Choice()
    assert obj is not None

# Generated at 2022-06-21 16:04:21.046300
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.builtins import Choice
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    choice = Choice()
    person = Person('en')

    assert isinstance(choice('abcdefg', 2), str)
    assert isinstance(choice(('a', 'b', 'c'), 2), tuple)
    assert choice(str(Gender.GENDERS)) in {'Male', 'Female'}

    assert choice([person.full_name(gender=Gender.MALE)]) in \
        person.full_name._male_names

# Generated at 2022-06-21 16:04:22.673737
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert isinstance(c, Choice)
    assert hasattr(c, 'Meta')
    assert hasattr(c, '__call__')


# Generated at 2022-06-21 16:04:23.328335
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()


# Generated at 2022-06-21 16:04:26.589929
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert isinstance(choice(items=['a', 'b', 'c']), str)
    assert isinstance(choice(items=['a', 'b', 'c'], length=1), list)
    assert isinstance(choice(items='abc', length=2), str)
    assert isinstance(choice(items=('a', 'b', 'c'), length=5), tuple)
    assert isinstance(choice(items='aabbbccccddddd', length=4, unique=True), str)


# Generated at 2022-06-21 16:04:35.151266
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert(choice(['a', 'b', 'c']) == 'c')
    assert(choice(['a', 'b', 'c'], 1) == ['b'])
    assert(choice('abc', 2) == 'ab')
    assert(choice(('a', 'b', 'c'), 5) == ('a', 'b', 'a', 'b', 'a'))
    assert(choice('aabbbccccddddd', 4, True) == 'dabd')

# Generated at 2022-06-21 16:04:36.439921
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice) is True


# Generated at 2022-06-21 16:04:42.023676
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
# END Unit test for constructor of class Choice



# Generated at 2022-06-21 16:04:43.135203
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    # TODO: Add method __call__ test
    pass