

# Generated at 2022-06-21 15:56:27.176183
# Unit test for constructor of class Choice
def test_Choice():
    Choice('en')

# Unit tests for choice

# Generated at 2022-06-21 15:56:36.056470
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    choice.random = 'fake_random'
    assert choice._random is 'fake_random'

    assert choice.__call__(items=['a', 'b', 'c']) == 'c'
    assert choice.__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice.__call__(items='abc', length=2) == 'ba'
    assert choice.__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')

# Generated at 2022-06-21 15:56:48.413192
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice

    choice = Choice()

    # __call__ with items='abc' and length=2
    assert choice(items='abc', length=2) in ('ba', 'ab', 'bc')

    # __call__ with items=('a', 'b', 'c') and length=5

# Generated at 2022-06-21 15:57:00.200180
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    from mimesis import Choice

    choice = Choice()

    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

    try:
        choice(items=[], length=1)
    except ValueError:
        pass
    else:
        assert False, 'ValueError not raised.'


# Generated at 2022-06-21 15:57:02.137673
# Unit test for constructor of class Choice
def test_Choice():
    items = ['a', 'b', 'c']
    ch = Choice()
    print(ch(items=items))


# Generated at 2022-06-21 15:57:11.633846
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    # case 1
    items = ('a', 'b', 'c', 'd')
    length = 2
    res_expected = ('b', 'a')
    assert choice(items, length) == res_expected, 'Error: Choice'

    # case 2
    items = ('a', 'b', 'c', 'd')
    length = 0
    res_expected = 'b'
    assert choice(items, length) == res_expected, 'Error: Choice'

    # case 3
    items = 'abcdef'
    length = 3
    res_expected = 'fba'
    assert choice(items, length) == res_expected, 'Error: Choice'


# Generated at 2022-06-21 15:57:13.269350
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis import Choice
    choice = Choice()


# Generated at 2022-06-21 15:57:14.389125
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)


# Generated at 2022-06-21 15:57:20.925213
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'



# Generated at 2022-06-21 15:57:22.078514
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)

# Generated at 2022-06-21 15:57:29.656130
# Unit test for constructor of class Choice
def test_Choice():
    try:
        choice = Choice()
        assert choice == Choice
    except Exception:
        raise AssertionError("Choice can't be initialized")
    try:
        choice = Choice()
        assert choice is not None
    except Exception:
        raise AssertionError("Choice can't be initialized")


# Generated at 2022-06-21 15:57:32.641651
# Unit test for constructor of class Choice
def test_Choice():
    """Unit test for constructor of class Choice."""
    choice = Choice()

    # __init__
    assert choice is not None
    assert isinstance(choice, Choice)

# Unit tests for Choice.__call__

# Generated at 2022-06-21 15:57:34.593689
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert c("abc", 1, True) == "c"



# Generated at 2022-06-21 15:57:41.561284
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'



# Generated at 2022-06-21 15:57:44.906581
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # input
    items = 'abc'
    length = 2
    unique = False
    return_val = ''.join(Choice.__call__(None, items, length, unique))
    assert return_val == 'bb'

# Generated at 2022-06-21 15:57:45.920496
# Unit test for constructor of class Choice
def test_Choice():
    assert isinstance(Choice(), Choice)


# Generated at 2022-06-21 15:57:52.215910
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Coverage for the method __call__ of class Choice
    import pytest

    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=1) == 'a'
    assert choice(items='abc', length=2) in ['ab', 'ac', 'ba', 'bc', 'ca', 'cb']

# Generated at 2022-06-21 15:58:02.410505
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ab', 'ac', 'bc']

# Generated at 2022-06-21 15:58:03.858787
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)


# Generated at 2022-06-21 15:58:10.177396
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    print(choice(items=['a', 'b', 'c']))
    print(choice(items=['a', 'b', 'c'], length=1))
    print(choice(items='abc', length=2))
    print(choice(items=('a', 'b', 'c'), length=5))
    print(choice(items='aabbbccccddddd', length=4, unique=True))

if __name__ == '__main__':
    test_Choice()

# Generated at 2022-06-21 15:58:24.286773
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    if (Choice().__call__(items=['a', 'b', 'c'])!='c') or \
        (Choice().__call__(items=['a', 'b', 'c'], length=1)!=['a']) or \
        (Choice().__call__(items='abc', length=2)!='ba') or \
        (Choice().__call__(items=('a', 'b', 'c'), length=5)!=('c', 'a', 'a', 'b', 'c')) or \
        (Choice().__call__(items='aabbbccccddddd', length=4, unique=True)!='cdba'):
        print("Warning: In Choice - method __call__!")

# Generated at 2022-06-21 15:58:27.017596
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    r = choice(items=[1,2,3,4,0], length=3, unique=True)
    assert r in [0,1,2,3,4]

# Generated at 2022-06-21 15:58:41.047538
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """
    :return:
    """
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

    try:
        assert choice(items=set(['a', 'b', 'c']), length=3)
    except TypeError:
        raise TypeError('**items** must be non-empty sequence.')

# Generated at 2022-06-21 15:58:50.095870
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.typing import Sequence, TypeVar, Union
    from typing import Generic, GenericMeta
    TData = TypeVar('TData')

    class GenericSuppress:
        """Provide a mechanism to suppress messages to the user
        in cases where this would otherwise be useful,
        but can be safely ignored.
        """
        def __init__(self, *args, **kwargs):
            pass

        def __enter__(self):
            """Suppress.
            >>> with GenericSuppress():
            ...     suppress = True
            """
            self.suppressed = True

        def __exit__(self, *exc):
            """Un-suppress.
            >>> with GenericSuppress():
            ...     print('Success!')
            ...     suppress = False
            Success!
            """
            self.suppressed = False


# Generated at 2022-06-21 15:59:00.403603
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    # items
    assert choice("a","b","c") in ["a","b","c"]
    # sequence of items
    assert choice(("a","b","c")) in ['a','b','c']
    # string
    assert choice("abc") in ['a','b','c']
    # length
    assert len(choice("abc",length=2)) == 2
    # return list
    assert type(choice("abc",length=2)) is list
    assert type(choice("abc", length=0)) is not list
    # return tuple
    assert type(choice(("a","b","c"),length=2)) is tuple
    # return string
    assert type(choice("abc",length=2)) is str
    # unique

# Generated at 2022-06-21 15:59:10.592761
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    from pprint import pprint

    from mimesis.enums import Seed
    from mimesis.random import Random
    from mimesis.builders import ProviderBuilder

    random = Random()
    random.seed(seed=Seed.MIMESIS)

    provider = ProviderBuilder(random).build('choice')
    result = provider(items=['a', 'b', 'c'],length=2,unique=True)
    assert isinstance(result, str)
    assert result == 'ac'
    result = provider(items=['a', 'b', 'c'],length=2,unique=False)
    assert isinstance(result, str)
    assert result == 'bb'
    result = provider(items=['a', 'b', 'c'],length=2)
    assert isinstance(result, str)

# Generated at 2022-06-21 15:59:20.033384
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    choice = Choice()

    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ab', 'bc', 'ac']

# Generated at 2022-06-21 15:59:28.702459
# Unit test for constructor of class Choice
def test_Choice():
    """Test Choice class."""
    items = ['a', 'b', 'c']
    length = 1
    unique = False

    choice = Choice()
    choice(items=['a', 'b', 'c'])
    choice(items=['a', 'b', 'c'], length=1)
    choice(items='abc', length=2)
    choice(items=('a', 'b', 'c'), length=5)
    choice(items='aabbbccccddddd', length=1, unique=True)
    #choice(items, length, unique)



# Generated at 2022-06-21 15:59:37.204592
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    class TestClassChoice:
        def test__init__(self):
            choice = Choice()
            assert choice

        def test__call__(self):
            choice = Choice()
            assert choice(items=['a', 'b', 'c'])
            assert choice(items=['a', 'b', 'c'], length=1)
            assert choice(items='abc', length=2)
            assert choice(items=('a', 'b', 'c'), length=5)
            assert choice(items='aabbbccccddddd', length=4, unique=True)

    testclass = TestClassChoice()
    testclass.test__init__()
    testclass.test__call__()

# Generated at 2022-06-21 15:59:41.174884
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    print(choice(items=['a', 'b', 'c']))
    print(choice(items=['a', 'b', 'c'], length=1))
    print(choice(items='abc', length=2))
    print(choice(items=('a', 'b', 'c'), length=5))
    print(choice(items='aabbbccccddddd', length=4, unique=True))


# Generated at 2022-06-21 15:59:56.489449
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert isinstance(c(), str)
    c = Choice()
    assert isinstance(c(['a', 'b', 'c']), str)
    c = Choice()
    assert isinstance(c(['a', 'b', 'c'], 1), list)
    c = Choice()
    assert isinstance(c('abc', 2), str)
    c = Choice()
    assert isinstance(c(('a', 'b', 'c'), 5), tuple)
    c = Choice()
    assert isinstance(c('aabbbccccddddd', 4, True), str)
    try: c('')
    except ValueError: pass
    try: c(1)
    except TypeError: pass
    try: c([], -1)
    except ValueError: pass

# Generated at 2022-06-21 16:00:07.109100
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from hypothesis import strategies as st
    from mimesis.providers.choice import Choice
    from mimesis.enums import Alphabet
    from hypothesis import given

    @given(st.lists(elements=st.sampled_from(Alphabet.CHARACTERS), min_size=1))
    def test_unique(data: list):
        provider = Choice()
        length = len(data) - 1
        result = provider(data, length, unique=True)
        assert len(result) == length
        assert type(result) == type(data)

    test_unique()

    @given(st.lists(elements=st.integers(), min_size=1))
    def test_unique_2(data: list):
        provider = Choice()
        length = len(data)

# Generated at 2022-06-21 16:00:14.598465
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert isinstance(Choice().__call__(items=[1]), int)
    assert isinstance(Choice().__call__(items=[1, 2, 3], length=1), list)
    assert isinstance(Choice().__call__(items='abc', length=2), str)
    assert isinstance(Choice().__call__(items=('a', 'b', 'c'), length=5), tuple)
    assert isinstance(Choice().__call__(items='aabbbccccddddd', length=4, unique=True), str)

# Generated at 2022-06-21 16:00:22.262119
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    print(c(items=['a', 'b', 'c']))
    print(c(items=['a', 'b', 'c'], length=1))
    print(c(items='abc', length=2))
    print(c(items=('a', 'b', 'c'), length=5))
    print(c(items='aabbbccccddddd', length=4, unique=True))
    try:
        c(0, 0)
    except TypeError:
        pass
    try:
        c('aBc', 'a')
    except TypeError:
        pass
    try:
        c('aBc', 2)
    except ValueError:
        pass

# Generated at 2022-06-21 16:00:30.787920
# Unit test for constructor of class Choice
def test_Choice():

    from mimesis import Choice
    choice = Choice()

    items = ['a', 'b', 'c']
    length = 1

    assert choice(items=items) == 'c'
    assert choice(items=items, length=length) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-21 16:00:31.797153
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TODO: test for class Choice
    pass

# Generated at 2022-06-21 16:00:39.995235
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()

    items = ('a', 'b', 'c')
    length = 1
    unique = False
    expected = choice(items, length, unique)
    print(expected)

    items = ('a', 'b', 'c')
    length = 3
    unique = False
    expected = choice(items, length, unique)
    print(expected)

    items = ('a', 'b', 'c')
    length = 3
    unique = True
    expected = choice(items, length, unique)
    print(expected)


if __name__ == "__main__":
    test_Choice()

# Generated at 2022-06-21 16:00:40.878041
# Unit test for constructor of class Choice
def test_Choice():
    print('the class Choice constructor is executed!')

# Generated at 2022-06-21 16:00:48.846559
# Unit test for constructor of class Choice
def test_Choice():
    class Meta:
        name = 'choice'
    class Choice(BaseProvider):
        class Meta:
            name = 'choice'

    choice = Choice()
    assert choice('items=["a", "b", "c"]') == 'c'
    assert choice('items=["a", "b", "c"]', length=1) == ['a']
    assert choice('items="abc"', length=2) == 'ba'
    assert choice('items=("a", "b", "c")', length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice('items="aabbbccccddddd"', length=4, unique=True) == 'cdba'

# Generated at 2022-06-21 16:00:50.182862
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice
test_Choice()


# Generated at 2022-06-21 16:01:15.276244
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method ``__call__`` of class ``Choice``."""
    assert Choice().__call__.__annotations__ == {
        'items': Optional[Sequence[Any]],
        'length': int,
        'unique': bool,
        'return': Union[Sequence[Any], Any]
    }
    choice = Choice()

    # TypeError: For non-sequence items or non-integer length.
    with pytest.raises(TypeError):
        choice(items='abc', length=1.1)
    with pytest.raises(TypeError):
        choice(items=123, length=1)
    with pytest.raises(TypeError):
        choice(items=123.456, length=1)

    # ValueError: If negative length or insufficient unique elements.

# Generated at 2022-06-21 16:01:18.294058
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice is not None
    # test default values
    assert choice.random is not None
    assert choice.datetime is not None
    assert choice.seed is not None

# Generated at 2022-06-21 16:01:27.580675
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice; choice = Choice()

    assert type(choice(['a', 'b', 'c'], length=2)) == list, 'Choice() isn\'t returning a list'

    try: choice()
    except ValueError: pass
    else: raise AssertionError('Choice() should have raised ValueError for no params')

    try: choice([])
    except ValueError: pass
    else: raise AssertionError('Choice() should have raised ValueError for empty param')

    try: choice(['a', 'b', 'c'], length=-1)
    except ValueError: pass
    else: raise AssertionError('Choice() should raise ValueError for negative length')

    try: choice(['a', 'b', 'c'], length=2, unique=True)
    except ValueError: pass
    else: raise Ass

# Generated at 2022-06-21 16:01:28.807123
# Unit test for constructor of class Choice
def test_Choice():
    choice=Choice()
    items=['a', 'b', 'c']
    length=5
    print(choice(items,length))
test_Choice()

# Generated at 2022-06-21 16:01:30.116699
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice('en')
    assert choice._language == 'en'

# Unit tests for call constructor of class Choice

# Generated at 2022-06-21 16:01:32.080903
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice"""
    pass

# Generated at 2022-06-21 16:01:33.159669
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice is not None


# Generated at 2022-06-21 16:01:39.081073
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    choice = Choice()

    assert isinstance(choice(items=['a', 'b', 'c']), str)
    assert isinstance(choice(items='abc'), str)
    assert isinstance(choice(items=['a', 'b', 'c'], length=1), list)
    assert isinstance(choice(items='abc', length=2), str)
    assert isinstance(choice(items=('a', 'b', 'c'), length=5), tuple)
    assert isinstance(choice(items='aabbbccccddddd', length=4, unique=True), str)

    try:
        choice(items=['a', 'b', 'c'], length=5.5)
    except TypeError:
        pass
    else:
        assert False, "Should have thrown exception."


# Generated at 2022-06-21 16:01:42.193479
# Unit test for constructor of class Choice
def test_Choice():
    """Run some tests."""
    choice = Choice()
    assert choice is not None
    assert isinstance(choice, Choice)
    assert type(choice).__name__ == 'Choice'


# Generated at 2022-06-21 16:01:43.801561
# Unit test for constructor of class Choice
def test_Choice():
    """Test for Choice class"""
    choice = Choice()
    
    assert isinstance(choice, Choice)

# Generated at 2022-06-21 16:02:19.008707
# Unit test for constructor of class Choice
def test_Choice():
    '''Test case for the constructor of class Choice. It is supposed to
    have a valid initialization.'''
    from mimesis import Choice
    choice = Choice(seed=123456)
    assert choice == choice
    assert choice.seed == 123456
    assert choice in globals().values()


# Generated at 2022-06-21 16:02:26.030433
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert (choice(items=['a', 'b', 'c']) in ['a', 'b', 'c'])
    assert (choice(items=['a', 'b', 'c'], length=1) == ['a']
            or choice(items=['a', 'b', 'c'], length=1) == ['b']
            or choice(items=['a', 'b', 'c'], length=1) == ['c'])
    assert (choice(items='abc', length=2) == 'ba'
            or choice(items='abc', length=2) == 'ac'
            or choice(items='abc', length=2) == 'cb')

# Generated at 2022-06-21 16:02:27.035210
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert c == Choice()
    assert c is not Choice()


# Generated at 2022-06-21 16:02:37.025711
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from random import Random
    from unittest import TestCase
    from unittest.mock import patch

    from mimesis.builtins import seed
    from mimesis.exceptions import NonUniqueError
    from mimesis.providers.choice import DUMMY_ITEMS

    class ChoiceTestCase(TestCase):

        def setUp(self):
            self.choice = Choice(seed=seed)
            self.choice._random = Random(x=1)

        def test_method_called_with_no_args(self):
            with self.assertRaises(TypeError):
                self.choice()

        def test_method_called_with_no_items(self):
            with self.assertRaises(ValueError):
                self.choice(items=[])


# Generated at 2022-06-21 16:02:44.291887
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice
    assert choice.random
    assert isinstance(choice.random, mimesis.Random)  # pylint: disable=E1101
    assert choice.datetime
    assert isinstance(choice.datetime, mimesis.Datetime)  # pylint: disable=E1101
    assert choice.text
    assert isinstance(choice.text, mimesis.Text)  # pylint: disable=E1101
    assert choice.numbers
    assert isinstance(choice.numbers, mimesis.Numbers)  # pylint: disable=E1101



# Generated at 2022-06-21 16:02:45.493889
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert (choice != None)


# Generated at 2022-06-21 16:02:47.338085
# Unit test for constructor of class Choice
def test_Choice():
    test = Choice('en')
    assert test


# Generated at 2022-06-21 16:02:50.584841
# Unit test for constructor of class Choice
def test_Choice():
    d = Choice()
    choice = d(items=['a', 'b', 'c'], length=5, unique=True)
    assert choice == ('b', 'a', 'c', 'a', 'b')

# Generated at 2022-06-21 16:02:51.889590
# Unit test for constructor of class Choice
def test_Choice():
    """Unit test for Choice class."""
    assert len(Choice(seed=1)()) > 0

# Generated at 2022-06-21 16:02:58.194878
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    ret = choice(items=["a","b","c"])
    assert ret
    assert isinstance(ret, str)
    assert ret == "a"
    ret = choice(items=["a","b","c"],length=1)
    assert ret
    assert isinstance(ret, list)
    assert ret == ["a"]
    ret = choice(items="abc",length=2)
    assert ret
    assert isinstance(ret, str)
    assert ret == "ab"
    ret = choice(items=("a", "b", "c"),length=5)
    assert ret
    assert isinstance(ret, tuple)
    assert ret == ("a", "c", "b", "c", "a")