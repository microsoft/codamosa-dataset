

# Generated at 2022-06-21 15:56:34.942985
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    data = ['a', 'b', 'c']
    length = 1
    choice1 = Choice()
    if choice1(items=data, length=length) != ['a']:
        raise AssertionError()
    data = 'abc'
    length = 2
    if choice1(items=data, length=length) != 'ba':
        raise AssertionError()
    data = ('a', 'b', 'c')
    length = 5
    if choice1(items=data, length=length) != ('c', 'a', 'a', 'b', 'c'):
        raise AssertionError()
    data = 'aabbbccccddddd'
    length = 4
    unique = True

# Generated at 2022-06-21 15:56:41.468973
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-21 15:56:47.084158
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert repr(c) == "<Choice()>"
    assert isinstance(c, Choice)
    assert c.random.choice.__name__ == "choice"
    assert c.random.random.__name__ == "random"


# Generated at 2022-06-21 15:56:48.228279
# Unit test for constructor of class Choice
def test_Choice():
    assert isinstance(Choice(), Choice)

# Generated at 2022-06-21 15:57:00.070452
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    assert choice('a') == 'a'
    assert choice([]) == []
    assert choice(('a', 'b', 'c'), 1) == ('c',)
    assert choice([1, 2, 3], 1) == [2]
    assert len(choice([1, 1, 2, 3], 1)) == 1
    assert 2 in choice([1, 1, 2, 3], 2)
    #assert choice(['a', 'b', 'c'], 3) == ('a', 'b', 'c')  # TODO: Returns list
    #assert choice(['a', 'b', 'c'], 3) == ['a', 'b', 'c']  # TODO: Returns list

# Generated at 2022-06-21 15:57:00.614916
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()

# Generated at 2022-06-21 15:57:02.834953
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()

    assert isinstance(choice('abc', length=1), list)
    assert isinstance(choice(['a', 'b', 'c'], length=1), list)

# Generated at 2022-06-21 15:57:11.004308
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    print(choice(items=['a', 'b', 'c']))
    print(choice(items=['a', 'b', 'c'], length=1))
    print(choice(items='abc', length=2))
    print(choice(items=('a', 'b', 'c'), length=5))
    print(choice(items='aabbbccccddddd', length=4, unique=True))
    # print(choice(items=('a', 'b', 'c'), length=4, unique=True))
test_Choice()

# Generated at 2022-06-21 15:57:19.631762
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    data = choice(items=['a', 'b', 'c'])
    assert data in ['a', 'b', 'c']
    data = choice(items=['a', 'b', 'c'], length=1)
    assert data in [['a'], ['b'], ['c']]
    data = choice(items='abc', length=2)
    assert data in ['ba', 'ac', 'bc']
    data = choice(items=('a', 'b', 'c'), length=5)
    assert data in [('c', 'a', 'a', 'b', 'c'),
                    ('b', 'c', 'a', 'b', 'c'),
                    ('a', 'c', 'a', 'b', 'c')]

# Generated at 2022-06-21 15:57:27.544539
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice([]) == ""
    assert choice(['a', 'b', 'c']) in ['a','b','c']
    assert choice(['a', 'b', 'c'], length=1) == ['a']
    assert choice('abc', length=2) in ['ba', 'ab', 'ac', 'bc']

# Generated at 2022-06-21 15:57:35.423557
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    c('abcd',  3,  False)
    c('abcd',  3,  True)
    c(('ab', 'cd'),  3,  False)
    c(('ab', 'cd'),  3,  True)
    c(('ab', 'cd'),  10,  True)

# Generated at 2022-06-21 15:57:45.398231
# Unit test for constructor of class Choice
def test_Choice():
    """Test class Choice."""
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in [
        'c', 'b', 'a',
    ]
    assert choice(items=['a', 'b', 'c'], length=1) in [
        ['a'],
        ['b'],
        ['c'],
    ]
    assert choice(items='abc', length=2) in [
        'ab',
        'ba',
        'ac',
        'ca',
        'bc',
        'cb',
    ]

# Generated at 2022-06-21 15:57:46.802647
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)

# Generated at 2022-06-21 15:57:47.784631
# Unit test for constructor of class Choice
def test_Choice():
    assert isinstance(Choice(), BaseProvider)



# Generated at 2022-06-21 15:57:59.787917
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice(random_state=42)

    # basic
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

    # advanced
    assert choice(items=(), length=-1) == ValueError
    assert choice(items=['a', 'b', 'c'], length=0) == 'c'

# Generated at 2022-06-21 15:58:02.784887
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    assert Choice().__call__(items=items) == 'c'
    assert Choice().__call__(items=items, length=length) == ['a']



# Generated at 2022-06-21 15:58:12.421822
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c= Choice()
    assert c(items=['a', 'b', 'c'])== 'c'
    assert c(items=['a', 'b', 'c'], length=1)== ['a']
    assert c(items='abc', length=2)== 'ba'
    assert c(items=('a', 'b', 'c'), length=5)== ('c', 'a', 'a', 'b', 'c')
    assert c(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    assert c(items=['a', 'b', 'c'], length=0) == 'b'
    try:
        c(items=['a', 'b', 'c'], length='b')
        raise Exception()
    except TypeError:
        pass

# Generated at 2022-06-21 15:58:17.292258
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    choice = Choice()
    assert choice(items=['a', 'b', 'c'])
    assert choice(items=['a', 'b', 'c'], length=1)
    assert choice(items='abc', length=2)
    assert choice(items=('a', 'b', 'c'), length=5)
    assert choice(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-21 15:58:25.502169
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice()(items=None) == None  # ERROR
    assert Choice()(items=1) == None  # ERROR
    assert Choice()(items=[]) == None  # ERROR
    assert Choice()(items=[1, 2, 3]) == None  # ERROR
    assert Choice()(items=[1, 2, 3], length=1) == None  # ERROR
    assert Choice()(items='123', length=2) == None  # ERROR
    assert Choice()(items=(1, 2, 3), length=5) == None  # ERROR
    assert Choice()(items='123123123123', length=4, unique=True) == None  # ERROR



# Generated at 2022-06-21 15:58:27.361607
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 1
    choice = Choice(items)
    assert choice.__call__(length) == ['a']

# Generated at 2022-06-21 15:58:50.598328
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert (c('a', 'b', 'c') in ['a', 'b', 'c'])
    assert (c('a', 'b', 'c', length=1) in [['a'], ['b'], ['c']])
    assert (c('a', 'b', 'c', length=2) in ['aa', 'ab', 'ac', 'ba', 'bb', 'bc', 'ca', 'cb', 'cc'])

# Generated at 2022-06-21 15:58:58.980461
# Unit test for constructor of class Choice
def test_Choice():
    local = Choice()
    print(local)
    assert type(local) == Choice
    print(local(items=['a', 'b', 'c']))
    print(local(items=['a', 'b', 'c'], length=1))
    print(local(items='abc', length=2))
    print(local(items=('a', 'b', 'c'), length=5))
    print(local(items='aabbbccccddddd', length=4, unique=True))

    local2Choice = Choice(local)
    print(local2Choice)

#if __name__ == '__main__':
#    test_Choice()

# Generated at 2022-06-21 15:59:01.311875
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert c._data.load().get('choice') is not None


# Unit tests for method Choice.__call__

# Generated at 2022-06-21 15:59:07.865219
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    # first use of 'choice' provider
    assert isinstance(choice('abc'), str)
    assert choice(['a', 'b', 'c'], length=1) == ['a']
    assert choice('abc', length=2) == 'ba'
    assert choice(('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice('aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-21 15:59:08.843621
# Unit test for constructor of class Choice
def test_Choice():
    c=Choice()
    assert c is not None

# Generated at 2022-06-21 15:59:17.557960
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    # TODO: Remove this line
    assert choice(items='abc', length=2) == ['a', 'b']

# Generated at 2022-06-21 15:59:18.993988
# Unit test for constructor of class Choice
def test_Choice():
    """Unit test for constructor of class Choice."""
    choice = Choice()
    assert isinstance(choice, Choice)

# Generated at 2022-06-21 15:59:21.403589
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice(name='Choice')
    assert isinstance(c, Choice)

# Generated at 2022-06-21 15:59:31.119869
# Unit test for constructor of class Choice
def test_Choice():
    # test for the Choice contructor
    # object should be created successfully.

    choice = Choice()
    result = choice(items=['a', 'b', 'c'])
    #assert result == "c"
    result = choice(items=['a', 'b', 'c'], length=1)
    #assert result == "a"
    result = choice(items='abc', length=2)
    #assert result == 'ba'
    result = choice(items=('a', 'b', 'c'), length=5)
    #assert result == ('c', 'a', 'a', 'b', 'c')
    result = choice(items='aabbbccccddddd', length=4, unique=True)
    #assert result == "cdba"
    return

# Generated at 2022-06-21 15:59:40.411680
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender
    from mimesis.providers.network import Network
    # unit-test: MyPy, type-checking
    choice = Choice()
    choice('abc', 0)
    choice(['a', 'b', 'c'])
    choice(['a', 'b', 'c'], 1)
    choice('abc', 2)
    choice(('a', 'b', 'c'), 5)
    choice('aabbbccccddddd', 4, unique=True)

    # unit-test: PyTest, code-coverage
    choice = Choice()
    assert isinstance(choice('abc', 0), str)
    assert isinstance(choice(['a', 'b', 'c']), str)
    assert isinstance(choice(['a', 'b', 'c'], 1), list)


# Generated at 2022-06-21 15:59:55.617755
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # pylint: disable=import-outside-toplevel
    from mimesis.enums import Gender
    from mimesis.providers.misc import Misc
    from mimesis.providers.person import Person
    from mimesis.typing import DataTypes

    choice = Choice()

    assert isinstance(choice(items=['a', 'b', 'c']), str)
    assert isinstance(choice(items=['a', 'b', 'c'], length=1), list)
    assert isinstance(choice(items='abc', length=2), str)
    assert isinstance(choice(items=('a', 'b', 'c'), length=5), tuple)
    assert isinstance(choice(items='aabbbccccddddd', length=4, unique=True), str)


# Generated at 2022-06-21 16:00:06.895268
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Extracted manually from the source code
    assert Choice().random.choice is not None
    assert Choice().random.choice([1, 2, 3]) == 2
    assert Choice()([1, 2, 3]) == 2
    assert Choice().choice([2, 3]) == 3
    assert Choice().choice(items=[1, 2, 3]) == 2
    assert Choice().choice([1, 2, 3]) == 2
    assert Choice().choice(items=[1, 2, 3]) == 2
    assert Choice().choice(items=[1, 2, 3], length=1) == [1]
    assert Choice().choice(items=[1, 2, 3], length=1, unique=True) == [1]
    assert Choice().choice(items=[1, 2, 3], unique=True) == 1

# Generated at 2022-06-21 16:00:08.163908
# Unit test for constructor of class Choice
def test_Choice():
    test = Choice()
    assert isinstance(test, Choice)

# Generated at 2022-06-21 16:00:15.515949
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items='abc', length=1) in ['a', 'b', 'c']
    assert choice(items=('a', 'b', 'c'), length=5) in ['a', 'b', 'c']
    assert choice(items='aabbbccccddddd', length=4, unique=True) in ['a', 'b', 'c', 'd']
    return


# Generated at 2022-06-21 16:00:22.560465
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    len = choice.random.randint(3, 5)
    unique = True
    selection = choice(items=['a', 'b', 'c'], length=len, unique=unique)
    if len > 1:
        assert(isinstance(selection, list))
    else:
        assert(isinstance(selection, str))
    assert(len(selection) == len)
    assert(len(set(selection)) == len)
    assert(len(set(selection) & set(['a', 'b', 'c'])) == len)
    unique = choice.random.randint(0, 1) == 0
    length = choice.random.randint(len, len+10)
    selection = choice(items=['a', 'b', 'c'], length=length, unique=unique)

# Generated at 2022-06-21 16:00:30.120194
# Unit test for constructor of class Choice
def test_Choice():

    choice = Choice()
    # print(choice.choice(items=['a', 'b', 'c']))
    # print(choice.choice(items=['a', 'b', 'c'], length=1))
    # print(choice.choice(items='abc', length=2))
    print(choice.choice(items=('a', 'b', 'c'), length=5))
    # print(choice.choice(items='aabbbccccddddd', length=4, unique=True))


# Generated at 2022-06-21 16:00:35.200177
# Unit test for constructor of class Choice
def test_Choice():
    #create an instance of class Choice
    a = Choice()
    #create the variable to be passed in call method
    items = ['a', 'b', 'c']

    length = 4
    # create variable which when set to True ensures elements in the sequence are unique
    unique = True
    #unit test
    assert a(items, length, unique) == 'cbaa'

# Generated at 2022-06-21 16:00:44.857133
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from typing import Any, Optional, Sequence, Union
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.geo import Geo
    from mimesis.providers.internet import Internet
    from mimesis.providers.text import Text
    from mimesis.providers.random import Random
    from mimesis.providers.science import Science
    from mimesis.providers.address import Address
    from mimesis.providers.files import Files
    from mimesis.providers.system import System
    from mimesis.providers.person import Person
    from mimesis.providers.business import Business
    from mimesis.providers.misc import Misc
    from mimesis.choice import Choice
    from mimesis.enums import Gender

# Generated at 2022-06-21 16:00:48.649002
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'b', 'c', 'a', 'b')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    assert choice(items='abc', length=2) == 'ba'

# Generated at 2022-06-21 16:00:50.335006
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert(choice.random.choice in ('a', 'b', 'c'))

# Generated at 2022-06-21 16:05:34.856063
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert(Choice()(items=['a', 'b', 'c']) == 'c')
    assert(Choice()(items=['a', 'b', 'c'], length=1) == ['a'])
    assert(Choice()(items='abc', length=2) == 'ba')
    assert(Choice()(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c'))
    assert(Choice()(items='aabbbccccddddd', length=4, unique=True) == 'cdba')

    try:
        Choice()(items='abc', length='a')
    except TypeError as e:
        assert(str(e) == '**length** must be integer.')

# Generated at 2022-06-21 16:05:42.355109
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    response = choice.__call__(items=['a', 'b', 'c'], length=5, unique=True)
    assert response in (['a', 'b', 'c', 'a', 'a'], \
                        ['a', 'b', 'c', 'a', 'b'],
                        ['a', 'b', 'c', 'a', 'c'],
                        ['a', 'b', 'c', 'b', 'c'])



# Generated at 2022-06-21 16:05:48.905752
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice().choice(['a', 'b', 'c']) in ['a', 'b', 'c']
    assert Choice().choice(['a', 'b', 'c'], length=1) in ['a', 'b', 'c']
    assert Choice().choice(['a', 'b', 'c'], length=5) in ['a', 'b', 'c']
    assert Choice().choice(['a', 'b', 'c'], length=10) in ['a', 'b', 'c']


# Generated at 2022-06-21 16:05:50.551724
# Unit test for constructor of class Choice
def test_Choice():

    assert isinstance(Choice(), Choice)

# Generated at 2022-06-21 16:06:01.098969
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """
    Test for method __call__ of class Choice.
    """
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ba', 'cb', 'ac']
    assert choice(items=('a', 'b', 'c'), length=5) in [('c', 'a', 'a', 'b', 'c'), ('a', 'a', 'c', 'b', 'c'),
                                                       ('c', 'a', 'c', 'b', 'a')]

# Generated at 2022-06-21 16:06:10.220818
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.builtins import Choice
    from hypothesis import given, strategies as st
    from mimesis.enums import Gender

    @given(st.lists(st.integers()),
           st.integers(),
           st.booleans())
    def test_Choice___call__(items,length,unique):
        choice = Choice()
        output = choice(items,length,unique)
        assert len(output) == length
        if unique:
            assert len(set(output)) == len(output)
        if not unique:
            assert len(output) == len(set(output))
    test_Choice___call__()


# Generated at 2022-06-21 16:06:17.189865
# Unit test for constructor of class Choice
def test_Choice():
    print("Testing class Choice and its methods...")
    obj1 = Choice() #creating an object
    print(obj1.__call__(list([10,20]),5))
    print(obj1.__call__(list([10,20]),-5))#testing for negative length
    print(obj1.__call__(list([]),5))#testing for empty sequence
    print(obj1.__call__('str',5))#testing for string
    print(obj1.__call__(set([10,20]),5))#testing for set
    print(obj1.__call__(dict({10:20}),5))#testing for dictionary
    print(obj1.__call__(list([10,20]),5,True))#testing for unique