

# Generated at 2022-06-21 15:56:27.676197
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    
    items = ['a', 'b', 'c']
    length = 1
    unique = True

    result = Choice.__call__(Choice, items, length, unique)
    assert result == "a"

# Generated at 2022-06-21 15:56:35.053426
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert len(c()) > 0
    assert c() in ('a', 'd', 'g', 'j', 'm', 'p', 's', 'v', 'y', ' ', '.')
    assert c('ab') in ('a', 'b')
    assert c('ab', 2) in ('aa', 'ab', 'ba', 'bb')
    assert c('ab', 2, True) in ('ab', 'ba')

test_Choice()

# Generated at 2022-06-21 15:56:38.690866
# Unit test for constructor of class Choice
def test_Choice():
    """
    Test constructor of class Choice
    """
    choice = Choice()
    assert choice.__class__.__name__ == "Choice"
    assert callable(choice)



# Generated at 2022-06-21 15:56:41.009144
# Unit test for constructor of class Choice
def test_Choice():
    chooser = Choice()
    assert chooser(items=['a', 'b', 'c'], length=1) == ['b']

# Generated at 2022-06-21 15:56:45.830692
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from . import Choice
    choice = Choice()

    items = ['a', 'b', 'c']
    length = 1
    unique = False

    result = choice(items=items, length=length, unique=unique)

    assert result == ['a']

# Generated at 2022-06-21 15:56:50.123987
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Arrange
    choice = Choice()
    expected = 'c'

    # Act
    actual = choice(items=['a', 'b', 'c'])

    # Assert
    assert actual == expected


# Generated at 2022-06-21 15:57:01.366055
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=('a', 'b', 'c')) in ['a', 'b', 'c']
    assert choice(items='abc') in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=5) in ['aabbc', 'aaacb', 'acaba', 'acbaa', 'aacbb']
    assert choice(items='aabbbccccddddd', length=4, unique=True) in ['cabd', 'dbca', 'abcd', 'cdba']

# Generated at 2022-06-21 15:57:02.343183
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert c is not None

# Generated at 2022-06-21 15:57:13.270311
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)
    assert isinstance(choice, BaseProvider)
    assert isinstance(choice.random, Choice._random_module.Random)
    assert isinstance(choice.datetime, Choice._datetime_module.datetime)
    assert isinstance(choice.datetime.datetime.now(), Choice._datetime_module.datetime)
    assert isinstance(choice.datetime.date.today(), Choice._datetime_module.date)
    assert isinstance(choice.datetime.time(0), Choice._datetime_module.time)
    assert isinstance(choice.datetime.timedelta(0), Choice._datetime_module.timedelta)
    assert isinstance(choice.text, Choice._text_module.Text)

# Generated at 2022-06-21 15:57:14.964189
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert callable(choice)


# Generated at 2022-06-21 15:57:36.241531
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.providers import Choice
    choice = Choice()
    data = choice(items=[1, 2, 3], length=5)
    assert data == [3, 3, 1, 3, 3]
    data = choice(items=(1, 2, 3), length=5)
    assert data == (3, 1, 1, 3, 2)
    data = choice(items="123", length=5)
    assert data == "11311"
    data = choice(items=('a', 'b', 'c'), length=5)

# Generated at 2022-06-21 15:57:46.166922
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = Choice().__call__(["a", "b", "c"], 4, False)
    assert type(items) == list
    assert len(items) == 4
    assert set(items) == set(["a", "b", "c"])
    assert all(i in items for i in ["a", "b", "c"])

    items = Choice().__call__(["a", "b", "c"], 4, True)
    assert type(items) == list
    assert len(items) == 4
    assert set(items) == set(["a", "b", "c"])

    items = Choice().__call__(["a", "b", "c"], 0, True)
    assert type(items) == str
    assert items in ["a", "b", "c"]


# Generated at 2022-06-21 15:57:49.154577
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice.seed is not None
    assert choice.random is not None
    assert choice.datetime is not None
    assert choice.__name__ == 'Choice'

    choice = Choice(seed=12345)
    assert choice.seed == 12345


# Generated at 2022-06-21 15:57:54.394218
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    _Choice = Choice()
    _Choice(items, length, unique)

    # TODO: Fix this.
    # length = 'x'
    # _Choice = Choice()
    # _Choice(items, length, unique)



# Generated at 2022-06-21 15:58:03.612404
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 2
    unique = True
    c = Choice()
    # print(c.__call__(items, length, unique))


from mimesis.builtins import datetime as date
from mimesis.data import TRADITIONAL_FOODS
from mimesis.data import TRADITIONAL_RECIPES
from mimesis.data import TRADITIONAL_CITIES
from mimesis.enums import Gender
from mimesis.providers import AddressProvider
from mimesis.providers import PersonProvider
from mimesis.providers import FoodProvider
from mimesis.providers import RecipeProvider
from mimesis.providers import BusinessProvider
from mimesis.providers import InternetProvider
from mimesis.providers import FinancialProvider

# Generated at 2022-06-21 15:58:07.521799
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert len(choice(items=['1', '2', '3'])) == 3
    assert isinstance(choice(items=['1', '2', '3']), str)
    assert isinstance(choice(items=['1', '2', '3'], length=5), list)

# Generated at 2022-06-21 15:58:15.597041
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender
    from mimesis.builtins import Person
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import DATA
    from mimesis.providers.person import Person as PersonProvider
    import unittest2 as unittest

    p = Person()
    pp = PersonProvider(p)
    # m = pp(gender=Gender.MALE)
    # f = pp(gender=Gender.FEMALE)
    # choice = Choice()
    # item = choice(DATA['male_last_names'], length=1)

    # class ChoiceTestCase(unittest.TestCase):
    #     def test_choice(self):
    #         self.assertTrue(isinstance(item, list))

    # if __name__ == '

# Generated at 2022-06-21 15:58:18.478160
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    item = choice(choice.datetime.datetimes(start='2019-08-01', end='2019-08-31'))
    assert item is not None

# Generated at 2022-06-21 15:58:27.562741
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    # Tests with unique=False
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')

    # Tests with unique=True
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

    # Tests with empty items
    try:
        choice(items='', length=0, unique=True)
        assert False, "Expected ValueError wasn't raised."
    except ValueError:
        pass


# Generated at 2022-06-21 15:58:41.047517
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    choice = Choice()
    assert choice.__call__(['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice.__call__(['a', 'b', 'c'], 1) == ['c']
    assert choice.__call__('abc', 2) in ['ba', 'cb', 'ac']

# Generated at 2022-06-21 15:58:54.060602
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.exceptions import NonEnumerableError

    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) in ['ab', 'bc', 'ca']

# Generated at 2022-06-21 15:59:04.580008
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # print("\tTesting method \"__call__\" from class Choice")
    num_passed = 0
    num_failed = 0

    items = ['a', 'b', 'c']
    length = 1
    choice = Choice()
    expected = ['a']
    actual = choice(items, length)
    passed = actual == expected
    assert passed

    if passed:
        num_passed += 1
    else:
        num_failed += 1

    items = 'abc'
    length = 2
    choice = Choice()
    expected = 'ba'
    actual = choice(items, length)
    passed = actual == expected
    assert passed

    if passed:
        num_passed += 1
    else:
        num_failed += 1

    items = ('a', 'b', 'c')
    length = 5
    choice

# Generated at 2022-06-21 15:59:08.885153
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    # Define variables
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    data = ['a']

    # Create instance of class Choice and call method __call__
    choice = Choice()
    result = choice(items, length, unique)

    # Check result
    assert result == data

# Generated at 2022-06-21 15:59:18.570787
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    test_item1 = "abc"
    test_length1 =3
    test_unique1 = False
    test_item2 = [1, 2, 0, -1]
    test_length2 = 2
    test_unique2 = True
    assert choice(test_item1, test_length1, test_unique1) != None
    assert choice(test_item2, test_length2, test_unique2) != None
    assert choice(test_item1, test_length1, test_unique1) != choice(test_item1, test_length1, test_unique1)
    assert choice(test_item2, test_length2, test_unique2) != choice(test_item2, test_length2, test_unique2)


# Generated at 2022-06-21 15:59:22.119702
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert isinstance(c, Choice)
    assert isinstance(c._random.choice, collections.abc.Callable)


# Generated at 2022-06-21 15:59:31.964275
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    from json import loads
    test_list = ['a', 'b', 'c']
    test_tuple = ('a', 'b', 'c')
    for _ in range(10):
        assert choice(items=test_list) in test_list
        assert choice(items=test_list, length=1) == ['a']
        assert choice(items=test_tuple, length=2) == ('b', 'a')
        assert choice(items='abc', length=3) == 'abc'

# Generated at 2022-06-21 15:59:40.956763
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert c._random.choice(items=['a', 'b', 'c']) == 'c'
    assert c._random.choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert c._random.choice(items=['a', 'b', 'c'], length=1, unique=True) == ['a']
    assert c._random.choice(items='abc', length=2) == 'ba'
    assert c._random.choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert c._random.choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-21 15:59:50.769911
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    

# Generated at 2022-06-21 15:59:52.668584
# Unit test for constructor of class Choice
def test_Choice():
    """test_Choice:test class Choice constructor."""
    c = Choice() #type: ignore
    assert isinstance(c,Choice)


# Generated at 2022-06-21 15:59:54.839115
# Unit test for constructor of class Choice
def test_Choice():
    try:
        Choice()
    except:
        print("Error in initialization of Choice")
    else:
        print("Successful initialization of Choice")


# Generated at 2022-06-21 16:00:18.892455
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    obj = Choice()
    items = ['a', 'b', 'c', 'd', 'e']
    length = 5
    unique = True
    res = obj.__call__(items, length, unique)
    assert type(res) is list
    assert len(res) == 5
    assert len(set(res)) == 5

    length = 2
    unique = True
    res = obj.__call__(items, length, unique)
    assert type(res) is list
    assert len(res) == 2
    assert len(set(res)) == 2

    length = 2
    unique = False
    res = obj.__call__(items, length, unique)
    assert type(res) is list
    assert len(res) == 2
    assert len(set(res)) < len(res)

    res = obj.__

# Generated at 2022-06-21 16:00:19.698570
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice


# Generated at 2022-06-21 16:00:24.798465
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-21 16:00:27.729534
# Unit test for constructor of class Choice
def test_Choice():
    """ Unit test for constructor of class Choice.

    :return:
    """
    c = Choice()
    assert c is not None


# Generated at 2022-06-21 16:00:35.878396
# Unit test for constructor of class Choice
def test_Choice():
    a = Choice()
    b = Choice()
    #print(a.choice(items=['a', 'b', 'c']))
    #print(b.choice(items=['a', 'b', 'c']))
    assert (a.choice(items=['a', 'b', 'c']) == b.choice(items=['a', 'b', 'c']))
    #print(a.choice(items=['a', 'b', 'c'], length=1))
    #print(b.choice(items=['a', 'b', 'c'], length=1))
    assert (a.choice(items=['a', 'b', 'c'], length=1) != b.choice(items=['a', 'b', 'c'], length=1))
    #print(a.choice(items='abc', length

# Generated at 2022-06-21 16:00:45.684885
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    providerChoice = Choice()
    result = str(providerChoice.__call__(items=['a', 'b', 'c']))
    assert len(result) == 1
    result = str(providerChoice.__call__(items=['a', 'b', 'c'], length=1))
    assert result == "['a']"
    result = str(providerChoice.__call__(items='abc', length=2))
    assert result == 'ba'
    result = str(providerChoice.__call__(items=('a', 'b', 'c'), length=5))
    assert result == "('c', 'a', 'a', 'b', 'c')"
    result = str(providerChoice.__call__(items='aabbbccccddddd', length=4, unique=True))
    assert result

# Generated at 2022-06-21 16:00:46.580426
# Unit test for constructor of class Choice
def test_Choice():
    x = Choice()
    print(x)


# Generated at 2022-06-21 16:00:47.881966
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)
    assert str(choice)

# Generated at 2022-06-21 16:00:57.872864
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c'], length=2) == ['c', 'c']

    # Wrong type for items
    try:
        choice(items=1, length=2)
    except TypeError:
        pass
    else:
        assert False

    # Wrong type for length
    try:
        choice(items=['a', 'b', 'c'], length='a')
    except TypeError:
        pass
    else:
        assert False

    # length can not be negative
    try:
        choice(items=['a', 'b', 'c'], length=-1)
    except ValueError:
        pass
    else:
        assert False

    # length can not be greater than unique items

# Generated at 2022-06-21 16:01:00.668787
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items_ = [1, 2, 3]
    length_ = 3 # int
    unique_ = True
    assert choice(items=items_, length=length_, unique=unique_) in items_*length_ # items_*length_ = [1, 2, 3, 1, 2, 3, 1, 2, 3]

# Generated at 2022-06-21 16:01:27.745040
# Unit test for constructor of class Choice
def test_Choice():
    """Test method for Choice."""
    # TODO: Implement
    pass

# Generated at 2022-06-21 16:01:28.755135
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice is not None
    assert 'Choice' in dir(choice)


# Generated at 2022-06-21 16:01:36.604110
# Unit test for constructor of class Choice
def test_Choice():
    ch = Choice()
    assert ch(items = ['a', 'b', 'c'])
    assert ch(items = 'abc', length = 2)
    assert ch(items = ['a', 'b', 'c'], length = 1)
    assert ch(items = ['a', 'b', 'c'], length = 1, unique = True)
    assert ch(items = ['a', 'b', 'c'], length = 2, unique = True)
    assert ch(items = ['a', 'b', 'c'], length = 3, unique = True)
    assert ch(items = ['a', 'b', 'c'], length = 5, unique = True)
    assert ch(items = ['a', 'b', 'c'], length = 5)

# Generated at 2022-06-21 16:01:46.698878
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Test for normal method usage

    from mimesis.providers.datetime import Datetime
    from mimesis.providers.choice import Choice

    from mimesis.enums import Gender

    choice = Choice()
    datetime = Datetime()

    # Test for normal method usage
    assert choice(choice(['a', 'b', 'c', 'd'])) == 'b'
    assert choice(choice(['a', 'b', 'c', 'd']), length=1) == ['a']
    assert choice(choice((Gender.MALE, Gender.FEMALE)), length=2) == (Gender.FEMALE, Gender.MALE)
    assert choice(choice('abc'), length=2) == 'bc'

    # Test for not enough unique elements to provide the specified length.

# Generated at 2022-06-21 16:01:55.552482
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import sys
    import pytest

    from mimesis.builtins import Choice
    from mimesis.enums import State

    choice = Choice()

    # Testing for different types of **items**

    @pytest.mark.parametrize('datatype', [
        '',
        (),
        [],
        list(),
        set(),
        dict(),
        {},
        0,
        1,
        2,
        5,
        10,
        100,
        sys.float_info.max,
        sys.maxsize,
        State,
    ])
    def test_Choice___call__with_incorrect_items(datatype):
        with pytest.raises(TypeError):
            choice(datatype)

    # Testing for correct type but empty **items**


# Generated at 2022-06-21 16:02:01.151613
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    class _MockGenerator:
        def choice(self, x):
            return x[0]

    _mock_choice = Choice(_MockGenerator())

    def _test(items, length, unique):
        assert _mock_choice(items, length, unique) == _mock_choice.__call__(items, length, unique)

    _test(['a', 'b', 'c'], 0, False)
    _test(['a', 'b', 'c'], 1, False)
    _test('abc', 2, False)
    _test(('a', 'b', 'c'), 5, False)
    _test('aabbbccccddddd', 4, True)


# Generated at 2022-06-21 16:02:04.962198
# Unit test for constructor of class Choice
def test_Choice():
    k = Choice()
    assert repr(k) == '<Choice>'
    assert isinstance(k, BaseProvider)
    assert isinstance(k, Choice)
    assert isinstance(k, Choice.Meta)


# Generated at 2022-06-21 16:02:06.463932
# Unit test for constructor of class Choice
def test_Choice():
    assert str(Choice()) == 'Choice()'


# Generated at 2022-06-21 16:02:08.688307
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    result = choice(items=['a', 'b', 'c'], length=1, unique=False)
    assert result == ['a']
    assert isinstance(result, list)

# Generated at 2022-06-21 16:02:13.456956
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    items = ['a', 'b', 'c']
    length = 11
    unique = True

    data = choice(items=items, length=length, unique=unique)

    assert isinstance(data, list)
    assert len(data) == length
    assert len(set(data)) == length
    for d in data:
        assert d in items

# Testing for bug https://github.com/lk-geimfari/mimesis/issues/129

# Generated at 2022-06-21 16:02:56.290453
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice.__class__ == Choice

# Generated at 2022-06-21 16:02:57.000243
# Unit test for method __call__ of class Choice
def test_Choice___call__(): # todo
    pass


# Generated at 2022-06-21 16:03:04.331784
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    test_items = [1, 2, 3]
    test_items_tuple = (1, 2, 3)
    test_items_str = '123'
    test_items_negative_length = -1
    test_items_sequence = []
    assert choice.__call__(items=test_items) in test_items
    assert choice.__call__(items=test_items, length=1) in ([1], [2], [3])
    assert choice.__call__(items=test_items_tuple, length=1) in ((1,), (2,), (3,))
    assert choice.__call__(items=test_items_str, length=1) in ('1', '2', '3')

# Generated at 2022-06-21 16:03:09.920642
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit tests for method __call__ of class Choice."""
    c = Choice()

    # items is a non-empty sequence (list, tuple)
    assert isinstance(c(items=['a', 'b', 'c']), str)
    assert isinstance(c(items=['a', 'b', 'c'], length=1), list)
    assert isinstance(c(items='abc', length=2), str)
    assert isinstance(c(items=('a', 'b', 'c'), length=5), tuple)
    assert isinstance(c(items='aabbbccccddddd', length=4, unique=True), str)

    # items is an empty sequence
    assert ValueError(c, items=[])

    # items is not a sequence
    assert TypeError(c, items={1, 2, 3})



# Generated at 2022-06-21 16:03:16.761492
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    from mimesis import Choice
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) in 'abc'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) in 'ab'
    assert choice(items=('a', 'b', 'c'), length=5) in ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) in 'cdba'

# Generated at 2022-06-21 16:03:18.069538
# Unit test for constructor of class Choice
def test_Choice():
    """Test constructor of class Choice
    """
    # Arrange
    # Act
    choice = Choice()

    # Assert
    assert isinstance(choice, Choice)

# Generated at 2022-06-21 16:03:24.115730
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice.choice(['a', 'b', 'c'])=='c'
    assert choice.choice(['a', 'b', 'c'],length=1)==['a']
    assert choice.choice('abc',length=2)=='ba'
    assert choice.choice(('a', 'b', 'c'),length=5)==('c', 'a', 'a', 'b', 'c')
    assert choice.choice('aabbbccccddddd',length=4,unique=True)=='cdba'
    return 0

# Generated at 2022-06-21 16:03:35.432267
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(['a', 'b', 'c'], length=2) in [['a', 'b'], ['a', 'c'], ['b', 'c']]
    assert choice('abc', length=2) in ['ab', 'bc', 'ac']
    assert choice(('a', 'b', 'c'), length=5) in [('a', 'b', 'c', 'a', 'b'), ('a', 'b', 'c', 'a', 'c'), ('a', 'b', 'c', 'b', 'c')]

# Generated at 2022-06-21 16:03:37.478262
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert isinstance(choice, Choice)
    assert isinstance(choice.seed, str)


# Generated at 2022-06-21 16:03:39.131199
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice('en')
    assert isinstance(choice, Choice)

# Generated at 2022-06-21 16:05:08.827380
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    result = choice(['a', 'b', 'c'], 2)
    assert result == ['a', 'b']



# Generated at 2022-06-21 16:05:13.509767
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""

    obj = Choice()
    obj(items=['a', 'b', 'c'])
    obj(items=['a', 'b', 'c'], length=1)
    obj(items='abc', length=2)
    obj(items=('a', 'b', 'c'), length=5)
    obj(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-21 16:05:15.435599
# Unit test for constructor of class Choice
def test_Choice():
    print("Test the constructor of Choice: ", Choice)


# Generated at 2022-06-21 16:05:22.802125
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert c(items=['a', 'b', 'c'], length=1) == ['a']
    assert c(items=['a', 'b', 'c'], length=2) == ['a', 'a']
    assert c(items=['a', 'b', 'c'], length=5) == ['c', 'a', 'a', 'b', 'c']
    assert c(items='abc', length=1) == 'b'
    assert c(items='abc', length=2) == 'ba'
    assert c(items=('a', 'b', 'c'), length=1) == ('a',)
    assert c(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')

# Generated at 2022-06-21 16:05:29.954770
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice()
    assert c.choice(items=['a', 'b', 'c']) == 'a'
    assert c.choice(items=['a', 'b', 'c'], length=1) == 'c'
    assert c.choice(items='abc', length=2) == 'cc'



# Generated at 2022-06-21 16:05:35.964830
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-21 16:05:46.447002
# Unit test for constructor of class Choice
def test_Choice():
    from mimesis import Choice
    c = Choice()
    assert c.random.choice(['a', 'b', 'c']) in ['a', 'b', 'c']
    assert c(items=['a', 'b']) in ['a', 'b']
    assert c(items=['a', 'b'], length=1) in ['a', 'b'] and c(items=['a', 'b'], length=1).__len__() == 1
    assert c(items=['a', 'b'], length=2) in ['aa', 'ab', 'ba', 'bb'] and c(items=['a', 'b'], length=2).__len__() == 2

# Generated at 2022-06-21 16:05:56.290758
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender
    from mimesis.providers import Person
    from mimesis.providers. choice import Choice
    from mimesis.exceptions import TypedError


    for i in range(100):
        person_ = Person('en')
        assert isinstance(person_.name(gender=Gender.MALE), str)
        assert isinstance(person_.name(gender=Gender.FEMALE), str)

    person_ = Person('en', seed=456)
    assert person_.name(gender=Gender.MALE) == 'Arthur'
    assert person_.name(gender=Gender.FEMALE) == 'Jill'

    person_ = Choice('en', seed=456)
    assert person_.name(gender=Gender.MALE) == 'Arthur'

# Generated at 2022-06-21 16:06:05.323365
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    choice = Choice()
    # Seed used in test
    seed = 'bf56f1d2-7a21-4c16-a66a-cf8173ce4d4b'
    # First call
    result = choice(items=['a', 'b', 'c'])
    assert result == 'c'
    # Second call
    result = choice(items=['a', 'b', 'c'], length=1)
    assert result == ['c']
    # Third call
    result = choice(items='abc', length=2)
    assert result == 'ca'
    # Fourth call
    result = choice(items=('a', 'b', 'c'), length=5)
    assert result == ('c', 'a', 'a', 'b', 'c')

# Generated at 2022-06-21 16:06:13.327728
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # check unique=False
    assert not isinstance(Choice().__call__(length=10, items=['a', 'b']), list)
    # check variable length
    assert isinstance(Choice().__call__(length=10, items=['a', 'b']), str)
    assert isinstance(Choice().__call__(length=10, items=[1, 2]), list)

    data = Choice().__call__(length=10, items=['a', 'b'])
    assert len(data) == 10
    assert isinstance(data, str)

    data = Choice().__call__(length=10, items=[1, 2])
    assert len(data) == 10
    assert isinstance(data, list)

    # check unique=True