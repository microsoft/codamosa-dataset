

# Generated at 2022-06-25 20:29:13.692689
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()

    items = [' a', ' b', ' c']

    result_0 = choice_0.__call__(items)
    assert result_0 == ' c'
    result_1 = choice_0.__call__(items, unique=True)
    assert result_1 in [' a', ' b', ' c']
    result_2 = choice_0.__call__(items, length=1)
    assert result_2 == [' a']
    result_3 = choice_0.__call__('abc', length=2)
    assert result_3 == 'ba'
    result_4 = choice_0.__call__(('a', 'b', 'c'), length=5)
    assert result_4 == ('c', 'a', 'a', 'b', 'c')
    result_5 = choice_

# Generated at 2022-06-25 20:29:21.467165
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.data import SEQUENCES
    from mimesis.enums import DataType
    choice_2 = Choice()
    for sequence in SEQUENCES:
        for item_type in sequence.items:
            if DataType(item_type) == DataType.INTEGER:
                item = [1,2,3,4,5]
            elif DataType(item_type) == DataType.STRING:
                item = ['a', 'b', 'c', 'd', 'e']
            elif DataType(item_type) == DataType.DECIMAL:
                item = [1.0, 2.0, 3.0, 4.0, 5.0]
            elif DataType(item_type) == DataType.BOOLEAN:
                item = [True, False]
            el

# Generated at 2022-06-25 20:29:26.224247
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Create an 'Choice' object
    arg0 = None
    arg1 = 0
    arg2 = False
    choice = Choice()

    # Call '__call__' method of 'Choice' class with arguments
    result = choice(arg0, arg1, arg2)
    assert (isinstance(result, str))



# Generated at 2022-06-25 20:29:36.377258
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    seq_0 = choice(items=['a', 'b', 'a'], length=4, unique=True)
    if seq_0 != 'baa':
        raise ValueError('Failed test case 0')
    seq_1 = choice(items=[1, 2, 1], length=4, unique=True)
    if seq_1 != (1, 1, 2):
        raise ValueError('Failed test case 1')
    seq_2 = choice(items=[2, 1], length=4, unique=True)
    if seq_2 != (1, 1, 2):
        raise ValueError('Failed test case 2')
    seq_3 = choice(items=[2, 3, 4, 3], length=4, unique=True)
    if seq_3 != (3, 2, 4):
        raise ValueError

# Generated at 2022-06-25 20:29:44.269634
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    arg_0 = ('a', 'b', 'c')
    arg_1 = 2
    arg_2 = False
    arg_3 = choice_0(arg_0, arg_1, arg_2)
    assert (arg_3 in arg_0)
    assert (arg_3 in arg_0)
    assert (arg_3 in arg_0)
    choice_0 = Choice()
    arg_0 = 'abc'
    arg_1 = 2
    arg_2 = False
    arg_3 = choice_0(arg_0, arg_1, arg_2)
    assert (arg_3 in arg_0)
    assert (arg_3 in arg_0)
    assert (arg_3 in arg_0)
    choice_0 = Choice()

# Generated at 2022-06-25 20:29:53.070883
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    result = choice(items=['a', 'b', 'c'])
    assert result in ['a', 'b', 'c'], 'Returned value unexpected.'
    result = choice(items=[1, 2, 3], length=1)
    assert isinstance(result, list) and result[0] in [1, 2, 3], \
        'Returned value unexpected.'
    result = choice(items='abc', length=1)
    assert isinstance(result, str) and result[0] in ['a', 'b', 'c'], \
        'Returned value unexpected.'
    result = choice(items=('a', 'b', 'c'), length=1)
    assert isinstance(result, tuple) and result[0] in ('a', 'b', 'c'), \
        'Returned value unexpected.'


# Generated at 2022-06-25 20:30:03.597262
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.utils import random_int
    choice_34 = Choice(random_int(0, 1000000000))
    # Case 1
    choice_34.seed(34)
    choice_34.random = random_int(-4294967296, 4294967296)
    choice_34.__call__(['a', 'b', 'c'], 1, True) == 'a'
    # Case 2
    choice_34.seed(34)
    choice_34.random = random_int(-4294967296, 4294967296)

# Generated at 2022-06-25 20:30:15.346829
# Unit test for method __call__ of class Choice

# Generated at 2022-06-25 20:30:16.515559
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-25 20:30:20.965166
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ("a", "b", "c")
    length = 1
    unique = False
    expected = "c"

    choice = Choice()
    data = choice(items=items, length=length, unique=unique)
    print(data)
    assert data == expected


# Generated at 2022-06-25 20:30:30.385338
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    choice_1 = Choice()
    assert choice_0(items=['a', 'b', 'c']) == 'c'
    assert choice_0(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice_0(items='abc', length=2) == 'ba'
    assert choice_0(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice_0(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-25 20:30:39.801199
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    item_0 = ['a', 'b', 'c']
    length_0 = 1
    unique_0 = False
    choice_0 = Choice()
    type_result_0 = type(choice_0(item_0, length_0, unique_0))
    assert type_result_0 == list
    
    item_1 = ['a', 'b', 'c']
    length_1 = 1
    unique_1 = True
    choice_1 = Choice()
    type_result_1 = type(choice_1(item_1, length_1, unique_1))
    assert type_result_1 == list
    
    item_2 = ['a', 'b', 'c']
    length_2 = 2
    unique_2 = True
    choice_2 = Choice()

# Generated at 2022-06-25 20:30:47.989793
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(['a', 'b', 'c']) == 'c'
    assert Choice().__call__(['a', 'b', 'c'], 1) == ['a']
    assert Choice().__call__('abc', 2) == 'ba'
    assert Choice().__call__(('a', 'b', 'c'), 5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__('aabbbccccddddd', 4, True) == 'cdba'

# Generated at 2022-06-25 20:30:54.699428
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    length = 5
    unique = True
    items = ['a', 'b', 'c']
    choice_0(items, length, unique)

    # Method __call__ raises 'TypeError' if items is a str type
    items = 'a'
    try:
        choice_0(items, length, unique)
    except TypeError:
        pass
    
    # Method __call__ raises 'ValueError' if length is negative
    length = -5
    try:
        choice_0(items, length, unique)
    except ValueError:
        pass

    # Method __call__ raises 'ValueError' if items is empty
    items = []
    try:
        choice_0(items, length, unique)
    except ValueError:
        pass

# TODO: The following test case is ignored

# Generated at 2022-06-25 20:30:56.210163
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    choice_1 = Choice()


# Generated at 2022-06-25 20:31:08.864265
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Check the value returned by the method Choice.__call__()
    choice_0 = Choice()
    result___call__ = choice_0(items=['a', 'b', 'c'])
    assert type(result___call__) is str

    # Check the value returned by the method Choice.__call__()
    choice_0 = Choice()
    result___call__ = choice_0(items=['a', 'b', 'c'], length=1)
    assert type(result___call__) is list

    # Check the value returned by the method Choice.__call__()
    choice_0 = Choice()
    result___call__ = choice_0(items='abc', length=2)
    assert type(result___call__) is str

    # Check the value returned by the method Choice.__call__()
    choice_0 = Choice

# Generated at 2022-06-25 20:31:19.508380
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0('abc', 3, True) in ('abc', 'acb', 'bac', 'bca', 'cab', 'cba')
    assert choice_0('abc', 2, False) in ('ab', 'ac', 'ba', 'bc', 'ca', 'cb')
    assert choice_0('abc', 2, True) in ('ab', 'ac', 'ba', 'bc', 'ca', 'cb')
    assert choice_0('abc', 1, False) in 'abc'
    assert choice_0('abc', 1, True) in 'abc'
    assert choice_0('abc', 0, False) in 'abc'
    assert choice_0('abc', 0, True) in 'abc'



# Generated at 2022-06-25 20:31:27.951879
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method __call__ of class Choice."""
    choice_0 = Choice()

    assert choice_0(items=['a', 'b', 'c']) == 'c'
    assert choice_0(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice_0(items='abc', length=2) == 'ba'
    assert choice_0(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice_0(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-25 20:31:37.441659
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'



# Generated at 2022-06-25 20:31:43.721713
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 0
    unique = False
    print(Choice.__call__(items, length, unique))
    # assert isinstance(Choice.__call__(items, length, unique), )


choice = Choice()
print(choice('abc', length=2))

# Generated at 2022-06-25 20:31:54.603900
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_2 = Choice()
    items_0 = ['a', 'b', 'c']
    length_0 = 1
    unique_0 = False
    choice_3 = choice_2(items=items_0, length=length_0, unique=unique_0)
    assert choice_3 == ['a']

    choice_4 = Choice()
    items_1 = 'abc'
    length_1 = 2
    unique_1 = False
    choice_5 = choice_4(items=items_1, length=length_1, unique=unique_1)
    assert choice_5 == 'ba'

    choice_6 = Choice()
    items_2 = ('a', 'b', 'c')
    length_2 = 5
    unique_2 = False

# Generated at 2022-06-25 20:32:06.201826
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    choice_1 = Choice()
    assert choice_0(items=['a', 'b', 'c']) == 'c'
    assert choice_1(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice_0(items='abc', length=2) == 'ba'
    assert choice_1(items=('a', 'b', 'c'), length=5) == (
        'c',
        'a',
        'a',
        'b',
        'c',
    )
    assert choice_0(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-25 20:32:12.621818
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()

    # Test with a (somehow) long string
    long_string = "a" * 100000
    assert choice_0(long_string, 2) in long_string

    choice_1 = Choice()
    assert choice_0(long_string, length=2) != choice_1(long_string, 2)

# Generated at 2022-06-25 20:32:20.462627
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    choice_1 = Choice()
    choice_2 = Choice()
    choice_3 = Choice()
    choice_4 = Choice()
    choice_5 = Choice()
    choice_6 = Choice()
    choice_7 = Choice()
    choice_8 = Choice()
    choice_9 = Choice()
    choice_10 = Choice()
    choice_11 = Choice()
    assert set(choice_0(items=['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'])) == {
        'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'}

# Generated at 2022-06-25 20:32:29.951026
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # 1.
    choice_0 = Choice()
    items_0 = ['a', 'b', 'c']
    length_0 = 0
    unique_0 = False
    method_result_0 = choice_0(items=items_0, length=length_0, unique=unique_0)
    expected_result_0 = 'c'
    assert method_result_0 == expected_result_0

    # 2.
    choice_1 = Choice()
    items_1 = ['a', 'b', 'c']
    length_1 = 1
    unique_1 = False
    method_result_1 = choice_1(items=items_1, length=length_1, unique=unique_1)
    expected_result_1 = ['a']
    assert method_result_1 == expected_result_1

    # 3.


# Generated at 2022-06-25 20:32:40.235964
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    choice_1 = Choice()
    assert choice_0(('a', 'b', 'c')) == 'c'
    assert choice_1(('a', 'b', 'c'), 0) == 'c'
    assert choice_0(('a', 'b', 'c'), 0) == 'b'
    assert choice_1(('a', 'b', 'c'), 0) == 'c'
    assert choice_0(('a', 'b', 'c'), 1) == ['b']
    assert choice_1(('a', 'b', 'c'), 1) == ['c']
    assert choice_0(('a', 'b', 'c'), 2) == ['b', 'c']
    assert choice_1(('a', 'b', 'c'), 2) == ['c', 'c']

# Generated at 2022-06-25 20:32:44.206868
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0(("a", "b", "c"), 4, True) == "abc"
    assert choice_0(("a", "b", "c")) == "c"


# Generated at 2022-06-25 20:32:52.417123
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert 'ba' == Choice().__call__(items='abc', length=2)
    assert ('a', 'b', 'b') == Choice().__call__(items=('a', 'b', 'b'), length=3)
    assert 'ccc' == Choice().__call__(items='ccc', length=3)
    assert 'ab' == Choice().__call__(items='ab', length=2)
    assert 'dcb' == Choice().__call__(items='abcd', length=3, unique=True)
    assert 'aa' == Choice().__call__(items='aa', length=2)
    assert 'bc' == Choice().__call__(items='abc', length=2)
    assert 'cc' == Choice().__call__(items='cc', length=2)

# Generated at 2022-06-25 20:33:03.957738
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    choice_0 = Choice()
    item_list = []
    for i in range(0,10):
        item_list.append(choice_0(items=['a', 'b', 'c'], length=0))
        item_list.append(choice_0(items=['a', 'b', 'c'], length=3, unique=True))
        item_list.append(choice_0(items=['a', 'b', 'c'], length=3, unique=False))
    for item in item_list:
        print(item)
    #assert item_list.count('a') > 0
    #assert item_list.count('b') > 0
    #assert item_list.count('c') > 0
    #assert item_list.count('a') + item_list.count('b') + item_list

# Generated at 2022-06-25 20:33:14.880068
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().choice(items=('a', 'b', 'c'), length=2, unique=True) == 'ab'
    assert Choice().choice(items=['a', 'b', 'c'], length=5, unique=False) == ['a', 'a', 'a', 'c', 'b']
    assert Choice().choice(items=['a', 'b', 'c'], length=5, unique=True) == ['b', 'a', 'c', 'b', 'a']
    assert Choice().choice(items=['a', 'b', 'c'], length=2, unique=False) == ['a', 'c']
    assert Choice().choice(items=['a', 'b', 'c'], length=0, unique=False) == 'c'
    assert Choice().choice(items='abc', length=1, unique=True)

# Generated at 2022-06-25 20:33:27.552368
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    choice_1 = Choice()
    assert choice_0(items=[]) == choice_1(items=[])
    assert choice_0(items=(), length=0) == choice_1(items=(), length=0)
    assert choice_0(items='', length=0, unique=False) == choice_1(items='', length=0, unique=False)
    assert choice_0(items=(), length=0, unique=False) == choice_1(items=(), length=0, unique=False)

# Generated at 2022-06-25 20:33:36.270851
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice()(items=['a', 'b', 'c']) == 'c'
    assert Choice()(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice()(items='abc', length=2) == 'ba'
    assert Choice()(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice()(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-25 20:33:43.069420
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Function call
    assert False

    # Type errors
    try:
        Choice().__call__(items=None, length=0, unique=False)
    except TypeError:
        pass

    # Value errors
    try:
        Choice().__call__(items='', length=-1, unique=False)
    except ValueError:
        pass

# Generated at 2022-06-25 20:33:49.329356
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    item_0 = choice_0('', -1, False)
    item_1 = choice_0('', 0, False)
    item_2 = choice_0('', 1, False)
    item_3 = choice_0('', 2, False)
    item_4 = choice_0('', 3, False)
    item_5 = choice_0('', 4, False)
    item_6 = choice_0('', 5, False)
    item_7 = choice_0('', 6, False)
    item_8 = choice_0('', 7, False)
    item_9 = choice_0('', 8, False)
    item_10 = choice_0('', 9, False)
    item_11 = choice_0('', 10, False)

# Generated at 2022-06-25 20:33:59.865731
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Generate random choice from list of five unique integers
    choice_0 = Choice()
    assert isinstance(choice_0(items=[0, 1, 2, 3, 4], length=5, unique=True), list)

    # Generate random choice from list of five unique integers
    choice_1 = Choice()
    assert choice_1(items=[10, 11, 12, 13, 14], length=2, unique=True) == [10, 12]

    # Generate random choice from string of five unique letters
    choice_2 = Choice()
    assert choice_2(items='abcde', length=2, unique=True) == 'cb'

    # Generate random choice from tuple of five unique integers
    choice_3 = Choice()
    assert choice_3(items=(0, 1, 2, 3, 4), length=5, unique=True)

# Generated at 2022-06-25 20:34:08.242080
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Create an instance of class Choice
    choice = Choice()
    # Get a randomly-chosen sequence or bare element from a sequence...
    # ...where when length is specified the random choices are contained in a sequence of the same type of length length,
    # ...otherwise a single uncontained element is chosen.
    # ...If unique is set to True, constrain a returned sequence to contain only unique elements.
    # Show the results
    print(choice(items=['a', 'b', 'c']))
    print(choice(items=['a', 'b', 'c'], length=1))
    print(choice(items='abc', length=2))
    print(choice(items=('a', 'b', 'c'), length=5))
    print(choice(items='aabbbccccddddd', length=4, unique=True))


# Generated at 2022-06-25 20:34:15.333323
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert isinstance(choice(items=['a', 'b', 'c']), str)
    assert isinstance(choice(items=['a', 'b', 'c'], length=1), list)
    assert isinstance(choice(items='abc', length=2), str)
    assert isinstance(choice(items=('a', 'b', 'c'), length=5), tuple)
    assert isinstance(choice(items='aabbbccccddddd', length=4, unique=True), str)

# Generated at 2022-06-25 20:34:25.658147
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-25 20:34:30.880104
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = [1, 2, 3]
    length = 3
    unique = True
    _res = choice(items=items, length=length, unique=unique)


# Generated at 2022-06-25 20:34:34.779389
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 1
    unique = True
    expected = 'a'
    actual = Choice().__call__(items, length, unique)
    assert expected == actual

# Generated at 2022-06-25 20:34:51.561106
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    seq = ['a', 'b', 'c']
    choice_0 = Choice()
    assert isinstance(choice_0(items=seq), str)
    assert choice_0(items=seq, length=1) == ['b']
    assert isinstance(choice_0(items='abc', length=2), str)
    assert choice_0(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice_0(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

    choice_1 = Choice()
    assert choice_1(items=seq) == 'c'
    assert choice_1(items=seq, length=1) == ['a']

# Generated at 2022-06-25 20:34:55.574265
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_ = Choice()
    try:
        assert choice_(['a', 'b', 'c'])
    except ValueError:
        assert True
    except Exception:
        assert False

    assert choice_(['a', 'b', 'c'], length=1) == ['a']
    assert choice_('abc', length=2) == 'ba'
    assert choice_(('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice_('aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-25 20:35:03.615023
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    from hypothesis import strategies as st
    from hypothesis import given

    @given(st.lists(st.integers()), st.integers(), st.booleans())
    def check(x_lst, x_int, x_bool):
        choice = Choice()
        try:
            choice(x_lst, x_int, x_bool)
        except Exception as e:
            print(e)

    # End of function check
    check()

# Generated at 2022-06-25 20:35:15.780688
# Unit test for method __call__ of class Choice

# Generated at 2022-06-25 20:35:23.386841
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(['a', 'b', 'c']) == 'c'
    assert choice(['a', 'b', 'c'], 1) == ['a']
    assert choice('abc', 2) == 'ba'
    assert choice(('a', 'b', 'c'), 5) == ('c', 'a', 'a', 'b', 'c')
    assert choice('aabbbccccddddd', 4, unique=True) == 'cdba'

# Generated at 2022-06-25 20:35:32.812895
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    choice_1 = Choice()
    t = choice_0('', 0, False)
    assert isinstance(t, str)
    assert choice_0('', 0, False) == ''
    assert choice_0((1, 2, 3), 0, False) == 3
    assert choice_0('abc', 1, False) == 'a'
    assert choice_0(('a', 'b', 'c'), 1, False) == 'a'
    assert choice_0('abc', 3, True) == 'abc'
    assert choice_1('', 0, False) == ''
    assert choice_1((1, 2, 3), 0, False) == 2
    assert choice_1('abc', 1, False) == 'c'
    assert choice_1(('a', 'b', 'c'), 1, False)

# Generated at 2022-06-25 20:35:43.343360
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(['a', 'b', 'c'], 4, False) in (['a', 'b', 'c', 'b'], ['b', 'c', 'a', 'b'], ['c', 'a', 'b', 'b'], ['b', 'c', 'b', 'a'], ['a', 'b', 'b', 'c'], ['b', 'a', 'b', 'c'], ['c', 'b', 'b', 'a'], ['a', 'b', 'c', 'b'], ['b', 'c', 'b', 'a'], ['c', 'a', 'b', 'b'])
    assert choice(['a', 'b', 'c'], 1, True).__class__ == list
    assert choice(['a', 'b', 'c'], 1, True)

# Generated at 2022-06-25 20:35:53.117089
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    items_0: List[Any] = ['-', '.', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']

    assert len(items_0) == 36
    assert choice_0.choice(items=items_0) in set(items_0)
    assert choice_0.choice(items=items_0, length=1) in items_0

# Generated at 2022-06-25 20:35:59.473207
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = 'abcdefgh'
    assert isinstance(choice(items=items, length=6), str)
    assert isinstance(choice(items=items, length=2), str)
    assert isinstance(choice(items=items, length=6, unique=True), str)
    assert isinstance(choice(items=items, length=2, unique=True), str)

# Generated at 2022-06-25 20:36:10.913633
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert (choice('abc', 2, True) in ('ab', 'ac', 'ba', 'bc', 'ca', 'cb'))
    assert (choice(('a', 'b', 'c'), 2, False) in ('a', 'b', 'c'))
    assert (choice((('a', 'b', 'c'), ('d', 'e', 'f')), 2, False) in ('a', 'b', 'c'))
    assert (choice((('a', 'b', 'c'), ('d', 'e', 'f')), 2, True) in ('a', 'b', 'c'))
    assert (choice((('a', 'b', 'c'), ('d', 'e', 'f')), 2, False) in (('a', 'b', 'c'), ('d', 'e', 'f')))
   

# Generated at 2022-06-25 20:36:51.991689
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from unittest.mock import patch
    from mimesis import Choice
    choice = Choice()
    i = [1, 2, 3, 4, 5]
    assert isinstance(choice(items = i), int)
    with patch('mimesis.Choice.random.choice') as mock:
        choice.__call__(i)
        mock.assert_called_once_with(i)
    assert choice(i, length = 10) == ([1, 5, 2, 1, 1, 4, 4, 1, 2, 5], 10)
    assert choice(i, length = 0) == 1
    assert choice(i, length = 6) == ([5, 5, 4, 3, 5, 5], 6)
    assert choice(i, length = 2) == ([1, 1], 2)

# Generated at 2022-06-25 20:37:00.825691
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    choise_0 = choice(items, length, unique)
    assert choise_0 in ['a', 'b', 'c']
    choise_1 = choice(items, length, unique)
    assert choise_1 in ['a', 'b', 'c']
    assert choise_0 != choise_1
    assert True

if __name__ == '__main__':
    test_case_0()
    test_Choice___call__()

# Generated at 2022-06-25 20:37:11.665261
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    choice_1 = Choice()
    items_0 = choice_0.__call__(items=[-1, 0, 1])
    assert items_0 == 1.0
    items_1 = choice_0.__call__(items=[-1, 0, 1], length=0)
    assert items_1 == 0.0
    items_2 = choice_0.__call__(items=[-1, 0, 1], length=1, unique=True)
    assert items_2 == [-1]
    items_3 = choice_0.__call__(items=[-1, 0, 1], length=2, unique=False)
    assert items_3 == [1.0, 0.0]

# Generated at 2022-06-25 20:37:15.836479
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = [1, 2, 3]
    length = 1
    actual = Choice().__call__(items, length)
    expected = [1]

    assert actual == expected



# Generated at 2022-06-25 20:37:22.942283
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    from mimesis.exceptions import NonEnumerableError

    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'b'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('a', 'a', 'c', 'a', 'a')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdaa'

    # Test non-enumera

# Generated at 2022-06-25 20:37:26.742485
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_3 = Choice()
    print('*args=', choice_3.__call__(items=['a', 'b', 'c'], length=2))



# Generated at 2022-06-25 20:37:32.315291
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    items = set()
    length = choice_0._Choice__get_random_length(items)
    unique = choice_0.random.random_boolean()
    ret_1 = choice_0(items=items, length=length, unique=unique)
    ret_2 = choice_0(items=items, length=length, unique=unique)
    assert len(items) == len(ret_1)
    assert ret_1 == ret_2



# Generated at 2022-06-25 20:37:41.141315
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    choice_1 = Choice()
    assert choice_0('abc') == 'b'
    assert choice_0('abc', length=0) == 'c'
    assert choice_0('abc', length=1) == ['a']
    assert choice_0('abc', length=2) == 'bc'
    assert choice_0('abc', length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice_0('aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-25 20:37:47.271905
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert(isinstance(choice(items=['a', 'b', 'c']), str))
    assert(isinstance(choice(items=['a', 'b', 'c'], length=1), list))
    assert(isinstance(choice(items='abc', length=2), str))
    assert(isinstance(choice(items=('a', 'b', 'c'), length=5), tuple))
    assert(isinstance(choice(items='aabbbccccddddd', length=4, unique=True), str))

    # check error for non-sequence items
    try:
        choice(items=123, length=1)
    except TypeError as e:
        assert(str(e) == "**items** must be non-empty sequence.")

    # check error for non-integer length

# Generated at 2022-06-25 20:37:51.949607
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    choice_1 = Choice()
    choice_0(items=['a', 'b', 'c'], length=1)
    choice_0(items='abc', length=2)
    choice_0(items=('a', 'b', 'c'), length=5)
    choice_0(items='aabbbccccddddd', length=4, unique=True)

test_case_0()