

# Generated at 2022-06-25 20:29:14.830460
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = [1, 2, 3]
    length = None
    unique = True
    choice_0 = Choice()
    choice_0.__call__(items, length, unique)
    items = tuple([1, 2, 3])
    choice_0.__call__(items, length, unique)
    items = 'abc'
    choice_0.__call__(items, length, unique)


# Generated at 2022-06-25 20:29:16.539349
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    str_0 = choice_0(items=('a', 'b', 'c'))
    assert str_0 == 'a'


# Generated at 2022-06-25 20:29:22.133069
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice(seed=1234)
    assert choice.__call__(items=['a', 'b', 'c', 'd', 'e'], length=10, unique=True) == 'daebfcbddf'
    assert choice.__call__(items=['a', 'b', 'c', 'd', 'e'], unique=True) == 'e'
    assert choice.__call__(items=['a', 'b', 'c', 'd', 'e'], length=10, unique=False) == 'baaceddccd'
    assert choice.__call__(items=['a', 'b', 'c', 'd', 'e'], length=0, unique=True) == 'd'

# Generated at 2022-06-25 20:29:32.880309
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    str_0 = choice_0(items=['a', 'b', 'c'], length=1, unique=False)
    str_1 = choice_0(items=['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'])
    str_2 = choice_0(items=['a', 'b', 'c'], length=1, unique=True)
    str_3 = choice_0(items=['a', 'b', 'c'], length=10)

# Generated at 2022-06-25 20:29:41.482719
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import random
    import sys
    import unittest
    import unittest.mock
    class Test__call__(unittest.TestCase):
        def setUp(self):
            self.rand_choice = random.choice
            self.use_argv = sys.argv
        def tearDown(self):
            random.choice = self.rand_choice
            sys.argv = self.use_argv
        def test_items_is_not_a_sequence__should_raise_TypeError(self):
            self.assertRaises(TypeError, Choice().__call__, items=1)
        def test_items_is_an_empty_sequence__should_raise_ValueError(self):
            self.assertRaises(ValueError, Choice().__call__, items=[])

# Generated at 2022-06-25 20:29:52.089620
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    # assert choice_0.__call__(items=["a", "b", "c"], unique=False, length=0) == 'c'
    # assert choice_0.__call__(items=["a", "b", "c"], unique=False, length=2) == ['c', 'b']
    # assert choice_0.__call__(items=["a", "b", "c"]) == 'c'
    # assert choice_0.__call__(items=["a", "b", "c"], unique=False) == 'c'
    # assert choice_0.__call__(items=[], unique=False) == ''
    assert choice_0.__call__(items=['a', 'b', 'c'], length=2) == ['a', 'c']
    # assert choice

# Generated at 2022-06-25 20:30:03.566149
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_1 = Choice()
    int_1 = choice_1(items=None, length=4, unique=True)
    int_2 = choice_1(items=list(), length=2, unique=False)
    int_3 = choice_1(items=(list(),), length=0, unique=False)
    int_4 = choice_1(items=(None,), length=0, unique=True)
    int_5 = choice_1(items='', length=0, unique=True)
    int_6 = choice_1(items=(list(),), length=2, unique=False)
    int_7 = choice_1(items=(str(),), length=1, unique=True)
    int_8 = choice_1(items=tuple(), length=0, unique=True)

# Generated at 2022-06-25 20:30:09.022458
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender
    from mimesis.providers.job import Job

    job = Job('en')
    job.add_gender(Gender.FEMALE)
    job.add_gender(Gender.MALE)
    job.add_gender(Gender.TRANSGENDER)

    assert job('occupation') in job()

# Generated at 2022-06-25 20:30:18.058525
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice

    items = ['a', 'b', 'c']
    length = 1
    unique = False
    ret = Choice().__call__(items, length, unique)

    if not isinstance(ret, Sequence):  # type: ignore
        raise AssertionError(
            f"{ret} should be sequence of [Any] type.")
    if not isinstance(ret, Sequence):  # type: ignore
        raise AssertionError(
            f"{ret} should be sequence of [Any] type.")
    if length != 1:
        raise AssertionError(
            f"{length} should be equal to 1.")
    if not (ret == ['a']):
        raise AssertionError(
            f"{ret} should be equal to ['a'].")

# Generated at 2022-06-25 20:30:28.108298
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    str_0 = None
    str_1 = None
    int_0 = None
    tuple_0 = None
    list_0 = None
    str_2 = None
    # for testing
    print(choice_0(items=str_0, length=int_0))
    # for testing
    print(choice_0(items=tuple_0, length=int_0))
    # for testing
    print(choice_0(items=list_0, length=int_0))
    # for testing
    print(choice_0(items=str_1, length=int_0, unique=True))
    # for testing
    print(choice_0(items=str_2, length=int_0, unique=True))

# Generated at 2022-06-25 20:30:40.214208
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # __call__(self, items, length=0, unique=False)
    choice_0 = Choice()
    str_0 = choice_0.__call__(['a','b','c'],3)
    str_1 = choice_0.__call__(['a','b','c'])
    str_2 = choice_0.__call__('abc',2)
    str_3 = choice_0.__call__(('a','b','c'),5)
    str_4 = choice_0.__call__('aabbbccccddddd',4,True)
    choice_0.__call__('aabbbccccddddd',4,False)
    choice_0.__call__(('a','b','c'),5,False)

# Generated at 2022-06-25 20:30:40.861444
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-25 20:30:49.189992
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    str_0 = 'xS'

    def def_func(seed=None):
        pass

    choice_0.random.seed(seed=None)
    choice_0.random.choice(str_0)

    str_1 = choice_0.__call__(items=str_0, length=1, unique=True)
    assert str_1 == 'S'
    choice_0.random.choice(str_0)

    tuple_0 = choice_0.__call__(items=str_0, length=1, unique=True)
    assert tuple_0 == 'x'

# Generated at 2022-06-25 20:30:52.792307
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    with pytest.raises(TypeError):
        assert (choice_0(items=int_0, length=0, unique=True) == None)



# Generated at 2022-06-25 20:30:59.759992
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # In place of a proper test case,
    # here is some code that will run if
    # you run this file:
    assert Choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert len(Choice(items=['a', 'b', 'c'], length=1)) == 1
    assert len(Choice(items='aabbbccccddddd', length=4, unique=True)) == 4
    assert len(Choice(items='aabbbccccddddd', length=5, unique=True)) == 5
    assert Choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')

# Generated at 2022-06-25 20:31:06.867390
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    ch = Choice()
    ch(items=['a', 'b', 'c'])
    ch(items=['a', 'b', 'c'], length=1)
    ch(items='abc', length=2)
    ch(items=('a', 'b', 'c'), length=5)
    ch(items='aabbbccccddddd', length=4, unique=True)


# Generated at 2022-06-25 20:31:18.509645
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    items_0 = ['a', 'b', 'c']
    length_0 = 0
    unique_0 = False
    result_0 = choice_0(items_0, length_0, unique_0)
    assert isinstance(result_0, str)
    assert result_0 == 'b'
    unique_0 = True
    result_1 = choice_0(items_0, length_0, unique_0)
    assert isinstance(result_1, str)
    assert result_1 == 'a'
    items_0 = tuple(['a', 'b', 'c'])
    result_2 = choice_0(items_0, length_0, unique_0)
    assert isinstance(result_2, str)
    assert result_2 == 'b'

# Generated at 2022-06-25 20:31:21.921828
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice(locale='en')
    str_0 = choice_0(items='abcdef', length=2)
    assert str_0 == 'af'



# Generated at 2022-06-25 20:31:26.560431
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['F', 'd', 'Q', 'z', 'e', 'h', 'i', 'g']
    choice_0 = Choice()
    try:
        assert choice_0(items=items, length=2) in items
    except Exception as e:
        print(e)


# Generated at 2022-06-25 20:31:38.531425
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    sequence_0 = ('str', 'str')
    int_0 = choice_0(sequence_0)
    assert isinstance(int_0, str)
    assert int_0 in sequence_0

    choice_1 = Choice()
    sequence_1 = ('str', 'str')
    int_1 = choice_1(sequence_1, 0)
    assert isinstance(int_1, str)
    assert int_1 in sequence_1

    choice_2 = Choice()
    sequence_2 = ('str', 'str')
    int_2 = choice_2(sequence_2, 1)
    assert isinstance(int_2, str)
    assert int_2 in sequence_2

    choice_3 = Choice()
    sequence_3 = ('str', 'str')
    int_3 = choice_

# Generated at 2022-06-25 20:31:48.590710
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    items_0 = range(2)
    unique_0 = True
    length_0 = choice_0.random.randint(0, 100)

    result_0 = choice_0(items_0, length_0, unique_0)

    assert result_0 != []

test_Choice___call__()

# Generated at 2022-06-25 20:31:53.261028
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    # Positive test case for method __call__ of class Choice with arguments
    # items=(int,), length=int>0, unique=bool
    items_0 = (3, 4, 5, 6)
    length_0 = 4
    unique_0 = False
    result = choice_0(items=items_0, length=length_0, unique=unique_0)
    assert result in items_0

    # Positive test case for method __call__ of class Choice with arguments
    # items=(str,), length=int>0, unique=bool
    items_1 = "abcdefg"
    length_1 = 4
    unique_1 = False
    result = choice_0(items=items_1, length=length_1, unique=unique_1)
    assert result in items_1

    # Positive

# Generated at 2022-06-25 20:31:55.955153
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    try:
        choice_0 = Choice()
        int_0 = choice_0(items=['a', 'b', 'c'], length=1)
    except Exception as e:
        print(e)
    else:
        print('Function call `Choice___call__` passed.')

# Generated at 2022-06-25 20:31:59.660252
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    var_0 = choice_0(items=list_0, length=int_0, unique=bool_0)


# Generated at 2022-06-25 20:32:07.318199
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.providers.price import Price
    from mimesis.providers.choice import Choice
    price_0 = Price()
    price_0.__class__.__name__ = 'Price'
    price_0.__class__.__doc__ = 'Class for generating price data.'
    choice_0 = Choice()
    choice_0.__class__.__name__ = 'Choice'
    choice_0.__class__.__doc__ = 'Class for generating a random choice from items in a sequence.'
    str_0 = choice_0(items=(Price, Choice))


# Generated at 2022-06-25 20:32:18.281871
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    sequence_0 = choice_0(items=('',))
    assert not isinstance(sequence_0, str)
    sequence_1 = choice_0(items=([],), length=0)
    assert isinstance(sequence_1, list)
    sequence_2 = choice_0(items=("",), length=0)
    assert isinstance(sequence_2, str)
    sequence_3 = choice_0(items=(tuple(),), length=0, unique=True)
    assert isinstance(sequence_3, tuple)
    sequence_4 = choice_0(items=("",), length=1)
    assert isinstance(sequence_4, str)
    sequence_5 = choice_0(items=([],), length=0, unique=False)
    assert isinstance(sequence_5, list)

# Generated at 2022-06-25 20:32:18.925620
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice(None)() == '_'

# Generated at 2022-06-25 20:32:22.595182
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    int_0 = None
    #list_0 = [choice_0(items = [True, False])] * 3


# Generated at 2022-06-25 20:32:29.173285
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'



# Generated at 2022-06-25 20:32:39.896520
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    result_0 = choice_0.__call__(items=['a', 'b', 'c'])
    assert result_0 == 'c'

    result_1 = choice_0.__call__(items=['a', 'b', 'c'], length=1)
    assert result_1 == ['a']

    result_2 = choice_0.__call__(items='abc', length=2)
    assert result_2 == 'ba'

    result_3 = choice_0.__call__(items=('a', 'b', 'c'), length=5)
    assert result_3 == ('c', 'a', 'a', 'b', 'c')

    result_4 = choice_0.__call__(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-25 20:34:19.635049
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    items_0 = choice_0.__call__()
    assert items_0 is not None



# Generated at 2022-06-25 20:34:28.948729
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.providers.choice import Choice

    choice_0 = Choice()
    choice_0.random.choice = lambda: 'a'
    choice_1 = choice_0(items='abc', length=2)
    assert choice_1 == 'ba'

    choice_0.random.choice = lambda: 'a'
    choice_1 = choice_0(items=['a', 'b', 'c'], length=1)
    assert choice_1 == ['a']

    choice_0.random.choice = lambda: 'c'
    choice_1 = choice_0(items=['a', 'b', 'c'])
    assert choice_1 == 'c'

    choice_0.random.choice = lambda: 'c'

# Generated at 2022-06-25 20:34:35.746423
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    int_0 = None
    assert choice_0(items=[], unique=False) == int_0, "(choice_0(items=[], unique=False) == int_0)"
    assert choice_0(items=[], length=0, unique=False) == int_0, "(choice_0(items=[], length=0, unique=False) == int_0)"


# Generated at 2022-06-25 20:34:43.609905
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0(['a', 'b', 'c'], unique = False, length = 5) == 'aaccb'
    assert choice_0(['a', 'b', 'c'], unique = True, length = 2) == 'bc'
    assert choice_0('abc', length = None, unique = True) == 'a'
    assert choice_0('abc', unique = False, length = 0) == 'c'


# Generated at 2022-06-25 20:34:48.826438
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    str_0 = choice_0(items=['a', 'b', 'c'])
    list_0 = choice_0(items=['a', 'b', 'c'], length=1)
    str_1 = choice_0(items='abc', length=2)
    tuple_0 = choice_0(items=('a', 'b', 'c'), length=5)
    str_2 = choice_0(items='aabbbccccddddd', length=4, unique=True)
    list_1 = choice_0(items=['a', 'b', 'c'])
    list_2 = choice_0(items=['a', 'b', 'c'], length=1)
    str_3 = choice_0(items='abc', length=2)

# Generated at 2022-06-25 20:34:53.015477
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0(['a', 'b', 'c'], None) in ['a', 'b', 'c']

# Generated at 2022-06-25 20:35:05.337732
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    str_0 = None
    str_1 = choice_0(items=('a', 'b', 'c'), length=2)
    assert str_1 == 'ca'
    str_1 = choice_0(items='abc', length=2)
    assert str_1 == 'ba'
    str_1 = choice_0(items=['a', 'b', 'c'])
    assert str_1 == 'c'
    str_1 = choice_0(items='aabbbccccddddd', length=4, unique=True)
    assert str_1 == 'cdba'
    str_1 = choice_0(items=['a', 'b', 'c'], length=1)
    assert str_1 == ['a']

# Generated at 2022-06-25 20:35:16.624456
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from random import randint

    choice_0 = Choice()
    int_0 = randint(0, 32)
    int_1 = randint(0, 32)
    int_2 = randint(0, 32)
    int_3 = randint(0, 32)
    int_4 = randint(0, 32)
    int_5 = randint(0, 32)
    int_6 = randint(0, 32)
    int_7 = randint(0, 32)
    int_8 = randint(0, 32)
    int_9 = randint(0, 32)
    int_10 = randint(0, 32)
    int_11 = randint(0, 32)
    int_12 = randint(0, 32)
    int_13 = randint(0, 32)
    int

# Generated at 2022-06-25 20:35:26.033969
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    instance_0 = Choice()
    assert instance_0(length=0) is None
    assert instance_0(items=['a', 'b', 'c']) == 'c'
    assert instance_0(items=['a', 'b', 'c'], length=1) == ['a']
    assert instance_0(items='abc', length=2) == 'ba'
    assert instance_0(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert instance_0(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    try:
        instance_0(length=lambda *_: None)
    except TypeError:
        assert True
    else:
        assert False

# Generated at 2022-06-25 20:35:27.347035
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    pass