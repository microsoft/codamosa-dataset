

# Generated at 2022-06-25 20:29:12.157581
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    choice_0 = Choice()
    return_0 = choice_0(items=(), length=214, unique=False)

    assert return_0 == ('')


# Generated at 2022-06-25 20:29:17.376889
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    choice(items=['a', 'b', 'c'])
    choice(items=['a', 'b', 'c'], length=1)
    choice(items='abc', length=2)
    choice(items=('a', 'b', 'c'), length=5)
    choice(items='aabbbccccddddd', length=4, unique=True)
    choice(items='', length=4, unique=True)
    choice(items='', length=0)
    choice(items='abc', length=-1)
    choice(items=[1, 2, 3], length=5, unique=True)

# Generated at 2022-06-25 20:29:27.210397
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_1 = Choice()
    # choice_1(items=[], length=0, unique=False)
    # choice_1(items=[""], length=0, unique=False)
    choice_1(items=["", ""], length=0, unique=False)
    # choice_1(items=["", "", ""], length=0, unique=False)
    # choice_1(items=[], length=0, unique=True)
    # choice_1(items=[""], length=0, unique=True)
    choice_1(items=["", ""], length=0, unique=True)
    # choice_1(items=["", "", ""], length=0, unique=True)
    # choice_1(items=[], length=1, unique=False)
    # choice_1(items=[""], length=1

# Generated at 2022-06-25 20:29:33.605981
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0('abc', 0) == 'a'
    assert choice_0('abc', 1) == ['b']
    assert choice_0('abc', 2) == 'ab'
    assert choice_0(('a', 'b', 'c'), 5) == ('c', 'a', 'a', 'b', 'c')
    assert choice_0('aabbbccccddddd', 4, True) == 'cdba'


# Generated at 2022-06-25 20:29:42.029575
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()

    output_0 = choice_0(items=['a', 'b', 'c'])
    assert str(output_0) in ['a', 'b', 'c']

    output_1 = choice_0(items=['a', 'b', 'c'], length=1)
    assert str(output_1) in [["a"], ["b"], ["c"]]

    output_2 = choice_0(items='abc', length=2)
    assert str(output_2) in ['ac', 'bc', 'ab']

    output_3 = choice_0(items=('a', 'b', 'c'), length=5)

# Generated at 2022-06-25 20:29:47.796369
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    subset_0 = choice_0(length=1, items=['a', 'b', 'c'])
    assert subset_0 == ['a']
    subset_1 = choice_0(items=['a', 'b', 'c'])
    assert subset_1 == 'c'
    subset_2 = choice_0(length=1, items='abc')
    assert subset_2 == ['a']
    subset_3 = choice_0(items='abc', length=2)
    assert subset_3 == 'ba'
    subset_4 = choice_0(items=('a', 'b', 'c'), length=5)
    assert subset_4 == ('c', 'a', 'a', 'b', 'c')

# Generated at 2022-06-25 20:29:50.684477
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_ = Choice()
    items = 'abc'
    length = 0
    unique = False
    assert choice_(items, length, unique) == 'c'


# Generated at 2022-06-25 20:29:55.396867
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    # Test 0
    test_0_items = ['a', 'b', 'c']
    test_0_number = 1
    test_0_unique = False
    test_0_expected = ['a']
    test_0_actual = choice_0(items=test_0_items, length=test_0_number, unique=test_0_unique)
    assert test_0_actual == test_0_expected, "Test 0: Expected %s, but got %s" % (test_0_expected, test_0_actual)
    # Test 1
    test_1_items = 'abc'
    test_1_number = 2
    test_1_unique = False
    test_1_expected = 'ba'

# Generated at 2022-06-25 20:30:04.725063
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    # choice_0.__call__(items=['a', 'b', 'c'])


#  ================================================================
#  Generated testCases for Class Choice
#  ================================================================
#  def test_case_1():
#      choice_0 = Choice()
#      choice_0.__call__(items=['a', 'b', 'c'])
#
#  def test_case_2():
#      choice_0 = Choice()
#      choice_0.__call__(items=['a', 'b', 'c'])
#
#  def test_case_3():
#      choice_0 = Choice()
#      choice_0.__call__(items=['a', 'b', 'c'])
#
#  def test_case_4():


# Generated at 2022-06-25 20:30:15.910181
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import collections

    choice_0 = Choice()
    items_0 = ('a',)
    length_0 = 5
    unique_0 = True

    if not isinstance(length_0, int):
        raise TypeError('**length** must be integer.')
    if not isinstance(items_0, collections.abc.Sequence):
        raise TypeError('**items** must be non-empty sequence.')
    if not items_0:
        raise ValueError('**items** must be a non-empty sequence.')
    if length_0 < 0:
        raise ValueError('**length** should be a positive integer.')
    if length_0 == 0:
        return choice_0.random.choice(items_0)
    data = []

# Generated at 2022-06-25 20:30:26.280696
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    choice_0(items=['a', 'b', 'c'])
    choice_0(items=['a', 'b', 'c'], length=1)
    choice_0(items='abc', length=2)
    choice_0(items=('a', 'b', 'c'), length=5)
    choice_0(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-25 20:30:28.616892
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = (2, 3, 4, 5)
    length = 4
    unique = False
    choice_0 = Choice()
    choice_0.__call__(items, length, unique)



# Generated at 2022-06-25 20:30:39.719527
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    # TODO: what if unique is false?

    # If a non-sequence items and a negative length is given, then a
    #   ValueError should be raised.
    choice_1 = Choice()
    try:
        choice_1(items=['a', 'b', 'c'], length=-1)
        raise AssertionError('Expected raised ValueError when negative '
                             '**length** is provided.')
    except ValueError:
        pass

    # If a non-sequence items and a non-integer length is given, then a
    #   ValueError should be raised.
    choice_2 = Choice()

# Generated at 2022-06-25 20:30:43.672081
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    choice_0 = Choice()
    item = choice_0(items=['a', 'b', 'c'], length=1, unique=True)
    assert item == 'c'



# Generated at 2022-06-25 20:30:45.873555
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    choice_0(items=['a', 'b', 'c'])


# Generated at 2022-06-25 20:30:52.389745
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    choice((1, 2), 2) is None
    choice((1, 2), 2) is None
    choice((1, 2), 2) is None
    choice((1, 2), 2) is None
    choice((1, 2), 2) is None


# Generated at 2022-06-25 20:31:00.086497
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert c(items=['a', 'b', 'c'], length=0) in ['a', 'b', 'c']
    assert c(items=['a', 'b', 'c'], length=1) == ['a']
    assert c(items=['a', 'b', 'c'], length=5) == ['c', 'b', 'a', 'a', 'b']
    assert c(items='abc', length=5) == 'bccaa'
    assert c(items=('a', 'b', 'c'), length=5) == ('c', 'b', 'a', 'a', 'b')
    assert c(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-25 20:31:10.297336
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert choice_0(items=['a', 'b', 'c']) == 'c'
    assert choice_0(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice_0(items='abc', length=2) == 'ba'
    assert choice_0(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice_0(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    assert choice_0(items=['a', 'b'], length=2, unique=True) == ['a', 'b']

# Generated at 2022-06-25 20:31:18.614503
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_1 = Choice()
    assert choice_1.__call__(items=['a', 'b', 'c']) == 'c'
    assert choice_1.__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice_1.__call__(items='abc', length=2) == 'ba'
    assert choice_1.__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice_1.__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-25 20:31:27.209967
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Test if items is empty
    try:
        choice_1 = Choice()
        choice_1(items=[], length=5)
        flag_1 = False
    except ValueError:
        flag_1 = True
    assert flag_1

    # Test if items is not sequence
    try:
        choice_2 = Choice()
        choice_2(items=1)
        flag_1 = False
    except TypeError:
        flag_1 = True
    assert flag_1

    # Test if item is not sequence
    try:
        choice_3 = Choice()
        choice_3(items=1, length=1)
        flag_1 = False
    except TypeError:
        flag_1 = True
    assert flag_1

    # Test if length is not integer

# Generated at 2022-06-25 20:31:36.351274
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    assert isinstance(choice(items=items, length=length, unique=unique), Choice)


# Generated at 2022-06-25 20:31:48.927218
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=[u'a', u'b', u'c']) in [u'a', u'b', u'c']
    assert choice(items=[u'a', u'b', u'c'], length=1) in [[u'a'], [u'b'], [u'c']]
    assert choice(items=u'abc', length=2) in [u'ab', u'bc', u'ca']

# Generated at 2022-06-25 20:31:50.261983
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    pattern_0 = choice_0(items=('A', ), length=1, unique=False)
    assert pattern_0 == 'A'


# Generated at 2022-06-25 20:31:57.197745
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    choice_1 = Choice()
    actual = choice_1(items=[], length=0, unique=False)

    assert actual is not None

    choice_2 = Choice()
    actual = choice_2(items=[], length=0, unique=True)

    assert actual is not None

    choice_3 = Choice()
    actual = choice_3(items=['foo', 'bar'], length=0, unique=False)

    assert actual is not None

    choice_4 = Choice()
    actual = choice_4(items=['foo', 'bar'], length=0, unique=True)

    assert actual is not None

    choice_5 = Choice()
    actual = choice_5(items=['foo', 'bar'], length=1, unique=False)

    assert actual is not None

    choice_6 = Choice()

# Generated at 2022-06-25 20:31:58.583270
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Run the tests
    choice_0 = Choice()

# Generated at 2022-06-25 20:32:08.166127
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from random import Random
    from mimesis.providers.base import BaseProvider
    from mimesis.enums import Gender
    from typing import Any, Optional, Sequence, Union
    choice_0 = Choice()
    #
    # Tests for argument items:
    choice_0(items=['a', 'b', 'c'])
    choice_0(items=['a', 'b', 'c'], length=1)
    choice_0(items='abc', length=2)
    choice_0(items=('a', 'b', 'c'), length=5)
    choice_0(items='aabbbccccddddd', length=4, unique=True)
    # Tests for argument length:
    choice_0(items=['a', 'b', 'c'], length=1)

# Generated at 2022-06-25 20:32:18.420296
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    _test_expected_type = TypeError
    _test_expected_type_explanation = """
        **choice** should be a non-empty sequence.
        """
    _test_expected_value = ValueError
    _test_expected_value_explanation = """
        There are not enough unique elements in **choice** to provide the
        specified **length**.
        """
    _test_exceptions = [_test_expected_type, _test_expected_value]
    _test_exceptions_explanation = [_test_expected_type_explanation,
                                    _test_expected_value_explanation]
    _test_object = choice_0
    _test_args0 = []
    _test_kwargs0 = {'items': ''}
    _test_args

# Generated at 2022-06-25 20:32:29.090349
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice

    choice_0 = Choice()

# Generated at 2022-06-25 20:32:39.864189
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    length_1 = True
    try:
        choice(items=['a', 'b', 'c'], length='a')
    except TypeError as exception:
        length_1 = True
    assert length_1
    items_1 = True

# Generated at 2022-06-25 20:32:44.297293
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choices = ['a', 'b', 'c', 'd', 'e']
    length = 0
    unique = False
    choice = Choice()
    assert choice.__call__(items=choices, length=length, unique=unique) in choices
    
    

# Generated at 2022-06-25 20:33:01.193303
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_1 = Choice()
    assert choice_1(items=['a', 'b', 'c']) == 'c'

# Generated at 2022-06-25 20:33:03.750194
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Initialize class
    choice = Choice()

    # Test method by calling it with its
    # mandatory arguments
    assert choice.__call__(
        items=['a', 'b', 'c'],
        length=1) == ['a']



# Generated at 2022-06-25 20:33:14.880629
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 0
    unique = False
    choice_0 = Choice(locale='ru')
    choice_0_1 = choice_0.__call__(items, length, unique)
    assert isinstance(choice_0_1, str)
    assert choice_0_1 in ['a', 'b', 'c']

    items = ['a', 'b', 'c']
    length = 1
    unique = False
    choice_0 = Choice(locale='ru')
    choice_0_1 = choice_0.__call__(items, length, unique)
    assert isinstance(choice_0_1, list)
    assert choice_0_1 == ['b']

    items = 'abc'
    length = 2
    unique = False

# Generated at 2022-06-25 20:33:22.774590
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0(items='abc', unique=True) in 'abc'
    assert choice_0(items='abc',length=1) in 'abc'
    assert choice_0(items='abc',length=2) in 'abc'
    assert choice_0(items='abc',length=1,unique=True) in 'abc'
    assert choice_0(items='abc',length=2,unique=True) in 'abc'
    assert choice_0(items=['a', 'b', 'c'],length=1) in (['a', 'b', 'c'])
    assert choice_0(items=['a', 'b', 'c'],unique=True) in (['a', 'b', 'c'])

# Generated at 2022-06-25 20:33:30.119118
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    # TypeError: **length** must be integer
    # (items=['a', 'b', 'c'], length='a') -> TypeError
    # (items=['a', 'b', 'c'], length=['a']) -> TypeError
    # (items=['a', 'b', 'c'], length={'a': 'b'}) -> TypeError
    # (items=['a', 'b', 'c'], length=True) -> TypeError
    # (items=['a', 'b', 'c'], length=1.0) -> TypeError
    # (items=['a', 'b', 'c'], length=()) -> TypeError

    # TypeError: **items** must be non-empty sequence
    # (items=False, length=1) -> TypeError
    # (items=

# Generated at 2022-06-25 20:33:34.903484
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    data = """a"""
    length = 0
    unique = False
    choice_0 = Choice()
    result_0 = choice_0(items=data, length=length, unique=unique)
    assert isinstance(result_0, str)

# Generated at 2022-06-25 20:33:46.673175
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice(seed=1)

    # Test method returns a list
    expected_result_0 = ['e', 'i', 'e', 'i', 'e']

    # Test method returns a tuple
    expected_result_1 = ('e', 'i', 'o', 'u')

    # Test method returns a string
    expected_result_2 = 'ab'

    # Test method returns a single list element
    expected_result_3 = 'a'

    # Test method returns a single tuple element
    expected_result_4 = 'b'

    # Test method returns a single string element
    expected_result_5 = 'a'

    # Test method returns a list with unique elements
    expected_result_6 = ['o', 'u', 'i', 'a']

    # Test method returns a tuple with unique elements
    expected_result

# Generated at 2022-06-25 20:33:52.177349
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    items_0 = ['a', 'b', 'c']
    length_0 = 0
    unique_0 = False

if __name__ == '__main__':
    pass

# Generated at 2022-06-25 20:33:59.511975
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-25 20:34:08.095912
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()

    # items is a List
    items_0: List[int] = [1, 2, 3]
    assert choice_0(items_0) in items_0

    # items is a Tuple
    items_1: Tuple[int] = (1, 2, 3)
    assert choice_0(items_1) in items_1

    # items is a String
    items_2: str = '123'
    assert choice_0(items_2) in items_2

    # items is a List of length 1
    items_3: List[List[int]] = [[1]]
    assert choice_0(items_3) in items_3

    # items is a List of length 2
    items_4: List[List[int]] = [[1, 2]]

# Generated at 2022-06-25 20:34:36.938358
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-25 20:34:46.276753
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    items_0 = tuple()
    length_0 = choice_0.random.randint(0, 99)
    unique_0 = choice_0.random.randint(0, 99)
    choice_0.__call__(items=items_0, length=length_0, unique=unique_0)
    items_1 = tuple()
    length_1 = choice_0.random.randint(0, 99)
    unique_1 = choice_0.random.randint(0, 99)
    choice_0.__call__(items=items_1, length=length_1, unique=unique_1)
    assert items_1 == ()
    assert length_1 == 2
    assert unique_1 == 2
    print('Test for Choice.__call__: Pass')

# Generated at 2022-06-25 20:34:47.317690
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice()(items=[0, 1], length=2) == [0, 1]


# Generated at 2022-06-25 20:34:55.078436
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_1 = Choice()
    object_1 = choice_1.__call__(['a', 'b', 'c'])
    object_2 = choice_1.__call__(['a', 'b', 'c'], 3)
    object_3 = choice_1.__call__('abc', 2)
    object_4 = choice_1.__call__(('a', 'b', 'c'), 5)
    object_5 = choice_1.__call__('aabbbccccddddd', 4, True)
    object_6 = choice_1.__call__(items=['a', 'b', 'c'])
    object_7 = choice_1.__call__(items=['a', 'b', 'c'], length=3)

# Generated at 2022-06-25 20:35:04.727045
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0(items=['a', 'b', 'c']) == 'c'
    assert choice_0(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice_0(items='abc', length=2) == 'ba'
    assert choice_0(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice_0(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-25 20:35:10.833431
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    try:
        choice_1 = Choice()
        choice_1.__call__(items=['a', 'b', 'c'])
    except TypeError:
        assert False
    except ValueError:
        assert False
    else:
        assert True



# Generated at 2022-06-25 20:35:18.195987
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0(items=['a', 'b', 'c']) == 'c'
    assert choice_0(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice_0(items='abc', length=2) == 'ba'
    assert choice_0(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice_0(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

    assert choice_0(items=None, length=1) == [None]
    assert choice_0(items=('a', ), length=1) == ('a', )

# Generated at 2022-06-25 20:35:21.490524
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_1 = Choice()
    choice_1(items=('a', 'b', 'c'), length=5)


# Generated at 2022-06-25 20:35:25.144404
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import pytest
    items0 = ["summer", "Winter", "spring", "fall"]
    expected_type = str
    expected_value = "spring"
    actual_type = type(Choice.__call__(Choice(), items0))
    actual_value = Choice.__call__(Choice(), items0)
    assert actual_type == expected_type
    assert actual_value == expected_value


# Generated at 2022-06-25 20:35:32.398171
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    choice_0.__call__(items=['a', 'b', 'c'])
    choice_0.__call__(items=['a', 'b', 'c'], length=1)
    choice_0.__call__(items='abc', length=2)
    choice_0.__call__(items=('a', 'b', 'c'), length=5)
    choice_0.__call__(items='aabbbccccddddd', length=4, unique=True)
    choice_0.__call__(items=[], length=0, unique=False)

# Generated at 2022-06-25 20:36:21.217647
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    result_0 = choice_0(items=['a', 'b', 'c'])
    expected_0 = 'c'
    assert (result_0 == expected_0)
    result_1 = choice_0(items=['a', 'b', 'c'], length=1)
    expected_1 = ['a']
    assert (result_1 == expected_1)
    result_2 = choice_0(items='abc', length=2)
    expected_2 = 'ba'
    assert (result_2 == expected_2)
    result_3 = choice_0(items=('a', 'b', 'c'), length=5)
    expected_3 = ('c', 'a', 'a', 'b', 'c')
    assert (result_3 == expected_3)
    result_4

# Generated at 2022-06-25 20:36:24.673397
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert (choice_0('\x1b\x1d', 1, True) == '\x1b')



# Generated at 2022-06-25 20:36:33.849559
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    # Initialization
    choice = Choice()

    # Test
    # Note: Choice(items='abcd', length=4, unique=False) is a list
    assert choice(items='abcd', length=4, unique=False) == ['a', 'c', 'd', 'c']

    # Test
    # Note: Choice(items='abcd', length=4, unique=False) is a list
    assert choice(items='abcd', length=4, unique=False) == ['b', 'b', 'a', 'd']

    # Test
    # Note: Choice(items='abcd', length=4, unique=False) is a list
    assert choice(items='abcd', length=4, unique=False) == ['b', 'a', 'a', 'a']

    # Test
    # Note: Choice(items='abcd

# Generated at 2022-06-25 20:36:42.874107
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    assert choice(items, length, unique) == ['a']
    assert choice(items) == 'c'
    assert choice(items, length) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-25 20:36:52.349393
# Unit test for method __call__ of class Choice

# Generated at 2022-06-25 20:36:57.506284
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 0
    unique = False
    expected = 'c'
    actual = choice(items=items, length=length, unique=unique)
    assert expected == actual

# Generated at 2022-06-25 20:36:58.795041
# Unit test for method __call__ of class Choice
def test_Choice___call__():
        test_case_0()

# Generated at 2022-06-25 20:37:00.749959
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Testing the raise of an "TypeError" exception
    try:
        choice_0 = Choice()
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-25 20:37:07.138641
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    items_value_0 = ['a', 'b', 'c']
    length_value_0 = 1
    unique_value_0 = True
    assert choice_0(items=items_value_0, length=length_value_0, unique=unique_value_0) == ['a']


# Generated at 2022-06-25 20:37:13.509995
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    choice_1 = choice_0(items=['a', 'b', 'c'], length=1, unique=False)
    assert choice_1 == 'c'
    choice_2 = choice_0(items=['a', 'b', 'c'], length=1, unique=False)
    assert choice_2 == 'a'
    choice_3 = choice_0(items=['a', 'b', 'c'], length=1, unique=False)
    assert choice_3 == 'b'
    choice_4 = choice_0(items=['a', 'b', 'c'], length=1, unique=False)
    assert choice_4 == 'c'
    choice_5 = choice_0(items=['a', 'b', 'c'], length=1, unique=False)
   