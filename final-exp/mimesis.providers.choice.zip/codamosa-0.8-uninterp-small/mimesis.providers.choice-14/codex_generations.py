

# Generated at 2022-06-25 20:29:15.621050
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0(items=[1, 2, 3]) == 3
    assert choice_0(items=['a', 'b', 'c'], length=1) == ['b']
    assert choice_0(items='abc', length=2) == 'cb'
    assert choice_0(items=('a', 'b', 'c'), length=5) == ('c', 'b', 'c', 'a', 'c')
    assert choice_0(items='aabbbccccddddd', length=4, unique=True) == 'bacd'
    assert choice_0(items=['a', 'b', 'c'], length=-1) == ['a', 'c', 'b', 'a', 'c']

# Generated at 2022-06-25 20:29:20.514251
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TODO: Setup
    choice_0 = Choice()
    items_1 = ''
    length_1 = 0
    unique_1 = False
    # TODO: Assertions
    try:
        choice_0(items_1, length_1, unique_1)
        assert False
    except ValueError as e:
        assert str(e) == '**items** must be a non-empty sequence.'
    


# Generated at 2022-06-25 20:29:23.160335
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    items = list(range(10))
    length = 5
    unique = True

    assert choice_0(items=items, length=length, unique=unique) != None


# Generated at 2022-06-25 20:29:26.843280
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 0
    unique = False
    choice_0 = Choice()
    result_0 = choice_0(items, length, unique)
    assert isinstance(result_0, str)



# Generated at 2022-06-25 20:29:36.842524
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    result = choice_0(items=['a', 'b', 'c'])
    assert result in ['a', 'b', 'c']

    choice_1 = Choice()
    result = choice_1(items=['a', 'b', 'c'], length=1)
    assert result in [['a'], ['b'], ['c']]

    choice_2 = Choice()
    result = choice_2(items='abc', length=2)
    assert result == 'ba'

    choice_3 = Choice()
    result = choice_3(items=('a', 'b', 'c'), length=5)

# Generated at 2022-06-25 20:29:39.732810
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    actual = Choice().__call__(items, length, unique)
    expected = 'b'
    assert actual == expected


# Generated at 2022-06-25 20:29:51.016413
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0(['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice_0(items=['a', 'b', 'c'], length=1) == 'b'
    assert choice_0(items='abc', length=2) in ['bb', 'ab', 'ac']
    assert choice_0(items=('a', 'b', 'c'), length=5) in ['c', 'c', 'c', 'a', 'a', 'a', 'b', 'b', 'b']
    assert choice_0(items='aabbbccccddddd', length=4, unique=True) in ['cdba', 'dab', 'bdca', 'dbca', 'dbac', 'bdac', 'bdca', 'cdba']



# Generated at 2022-06-25 20:29:57.398109
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    value_0 = choice_0(items=['a', 'b', 'c'], unique=True)
    assert value_0 == 'c'


# Test the method Choice.__call__ with parameter length=1

# Generated at 2022-06-25 20:29:59.938547
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    data = choice(items=['a', 'b', 'c'], length=2)
    assert len(data) == 2


# Generated at 2022-06-25 20:30:02.511413
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    test_case_0()
    test_Choice___call____0()
    test_Choice___call____1()
    test_Choice___call____2()
    test_Choice___call____3()


# Generated at 2022-06-25 20:30:16.993567
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0(items=(1, 2, 3)) in {1, 2, 3}
    assert choice_0(items=(1, 2, 3, 4), length=1) in {(1,), (2,), (3,), (4,)}
    assert choice_0(items=(1, 2, 3, 4), length=2) in {(2, 3), (1, 2), (1, 4), (2, 1), (3, 1), (3, 4), (3, 2), (1, 3), (4, 1), (4, 2), (4, 3)}

# Generated at 2022-06-25 20:30:27.493305
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for the method __call__ of class Choice."""
    choice_0 = Choice()
    items_0 = ('Test',)
    items_1 = (1, 0, 8)
    items_2 = (' ',)
    items_3 = (0, 0, 0)
    items_4 = ('^I', '\n')
    length_0 = 0
    length_1 = 1
    unique_0 = False
    unique_1 = True

# Generated at 2022-06-25 20:30:32.336110
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_1 = Choice()
    assert choice_1('abcd', 0, False) == 'b'
    assert choice_1('abc', 2, False) == 'ac'
    assert choice_1('abc', 3, False) == 'bac'

# Generated at 2022-06-25 20:30:40.707980
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Test with items as a list
    items = ['a', 'b', 'c']
    actual = Choice().__call__(items=items, length=0, unique=False)
    assert isinstance(actual, str)
    assert actual in ['a', 'b', 'c']    
    
    # Test with items as a string
    items = 'abc'
    actual = Choice().__call__(items=items, length=1, unique=False)
    assert isinstance(actual, str)
    assert actual in ['a', 'b', 'c']
    
    # Test with items as a tuple
    items = ('a', 'b', 'c')
    actual = Choice().__call__(items=items, length=2, unique=False)
    assert isinstance(actual, tuple)

# Generated at 2022-06-25 20:30:48.803001
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert choice_0(items=('a', 'b', 'c')) == 'c'
    assert choice_0(items=('a', 'b', 'c'), length=1) == ['a']
    assert choice_0(items='abc', length=2) == 'ba'
    assert choice_0(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice_0(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-25 20:30:59.026269
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    from ddt import ddt, data
    from typing import List


# Generated at 2022-06-25 20:31:05.842460
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    sequence_0 = ['a', 'b', 'c', 'd']
    sequence_1 = ['e', 'f', 'g', 'h']
    assert Choice().__call__(sequence_0) == 'd'
    assert Choice().__call__(sequence_1, length=4) == ['e', 'f', 'g', 'h']

# Generated at 2022-06-25 20:31:17.989062
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()

    items = 'a'
    length = 0
    unique = False
    string_var_0 = choice_0.__call__(items, length, unique)
    assert string_var_0 == 'a'
    string_var_0 = choice_0.__call__(items, length=length, unique=unique)
    assert string_var_0 == 'a'
    length = 1
    list_var_0 = choice_0.__call__(items, length, unique)
    assert list_var_0 == ['a']
    list_var_0 = choice_0.__call__(items, length=length, unique=unique)
    assert list_var_0 == ['a']
    unique = True

# Generated at 2022-06-25 20:31:26.797149
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0(items=['a', 'b', 'c']) == 'c'
    assert choice_0(items=list(['a', 'b', 'c']), length=1) == ['a']
    assert choice_0(items=list(['a', 'b', 'c']), length=5) == ['c', 'a', 'a', 'b', 'c']
    assert choice_0(items='abc', length=2) == 'ba'
    assert choice_0(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    try:
        choice_0(items=list(['a', 'b', 'c']), length='a')
    except TypeError as e:
        assert '**length** must be integer' in str

# Generated at 2022-06-25 20:31:37.406281
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    choice_1 = Choice()
    assert choice_0(items=['a', 'b', 'c']) == 'c'
    assert choice_1(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice_0(items='abc', length=2) == 'ba'
    assert choice_1(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    assert choice_0(items=['a', 'b', 'c'], length=1) == ['a']

# Generated at 2022-06-25 20:31:50.420785
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    choice_0(('m', 'v', 'x'), length=5)
    choice_0(('v', 'w', 'm', 'v', 'o', 't', 'd', 'g', 'o', 'n'), 1)
    choice_0(('j', 'q', 'u', 'y', 'l', 'n', 'a', 'x'), 4, 1)
    choice_0(''.join(['a' for _ in range(6)]), 5, True)
    choice_0(''.join(['w' for _ in range(7)]), 8, False)
    choice_0('m', length=0, unique=True)

# Generated at 2022-06-25 20:31:57.651837
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_1 = Choice()
    assert isinstance(choice_1(items=['a', 'b', 'c']), str)
    assert isinstance(choice_1(items=['a', 'b', 'c'], length=1), list)
    assert isinstance(choice_1(items='abc', length=2), str)
    assert isinstance(choice_1(items=('a', 'b', 'c'), length=5), tuple)
    assert isinstance(choice_1(items='aabbbccccddddd', length=4, unique=True), str)


# Generated at 2022-06-25 20:32:05.091517
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    choice_0(length=0)
    choice_0(unique=True, length=0)
    choice_0(unique=False, length=0)
    choice_0(items=[])
    choice_0(items=[], length=0)
    choice_0(items=[], length=0, unique=True)
    choice_0(items=[], length=0, unique=False)


# Generated at 2022-06-25 20:32:09.622925
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    items = 'abc'
    length = 1
    unique = False
    choice_0(items, length, unique)


# Generated at 2022-06-25 20:32:16.349843
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items_0 = list()
    length_0 = 6
    unique_0 = False
    choice_0 = Choice()
    assert isinstance(choice_0.__call__(*[items_0, length_0, unique_0]), list)
    items_1 = tuple()
    length_1 = 0
    unique_1 = False
    choice_1 = Choice()
    assert isinstance(choice_1.__call__(*[items_1, length_1, unique_1]), tuple)

# Generated at 2022-06-25 20:32:23.076656
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items_0 = ['a', 'b', 'c']
    length_0 = 1
    unique_0 = False
    choice_1 = Choice()
    return_value_0 = choice_1(items=items_0, length=length_0, unique=unique_0)
    return return_value_0


# Generated at 2022-06-25 20:32:30.783781
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert choice_0(items=('a', 'b', 'c')) == 'a'
    assert choice_0(items=('a', 'b', 'c'), length=2) == 'ca'
    assert choice_0(items=('a', 'b', 'c'), length=1) == ('b',)
    assert choice_0(items=('a', 'b', 'c'), unique=True) == 'a'
    assert choice_0(items=('a', 'b', 'c'), unique=True, length=2) == 'cb'
    assert choice_0(items=('a', 'a', 'a'), unique=True) == 'a'
    assert choice_0(items=('a', 'a', 'a'), unique=True, length=2) == 'aa'


# Generated at 2022-06-25 20:32:39.895524
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_1 = Choice()
    assert (choice_1(items=['a', 'b', 'c']) == 'c')
    assert (choice_1(items=['a', 'b', 'c'], length=1) == ['a'])
    assert (choice_1(items='abc', length=2) == 'ba')
    assert (choice_1(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c'))
    assert (choice_1(items='aabbbccccddddd', length=4, unique=True) == 'cdba')

test_case_0()
test_Choice___call__()

# Generated at 2022-06-25 20:32:50.242023
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    try:
        choice_0(items=('a', 'b', 'c'), length=1)
    except Exception:
        pass
    try:
        choice_0(items=('a', 'b', 'c'), length=1, unique=True)
    except Exception:
        pass
    try:
        choice_0(items=['a', 'b', 'c'], length=1, unique=True)
    except Exception:
        pass
    try:
        choice_0(items=['a', 'b', 'c'])
    except Exception:
        pass
    try:
        choice_0(items=['a', 'b', 'c'], length=1, unique=True)
    except Exception:
        pass

# Generated at 2022-06-25 20:32:52.354629
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    mimesis_0 = Choice()
    str_0 = mimesis_0(items='abc', length=2)
    assert str_0 == 'ba'


# Generated at 2022-06-25 20:33:05.742818
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0(items=['a', 'b', 'c']) == 'a'
    assert choice_0(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice_0(items='abc', length=2) == 'ab'
    assert choice_0(items=('a', 'b', 'c'), length=5) == ('b', 'a', 'a', 'a', 'a')
    assert choice_0(items='aabbbccccddddd', length=4, unique=True) == 'abcd'


# Generated at 2022-06-25 20:33:09.439248
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items_0 = ['a', 'b', 'c']
    length_0 = 1
    unique_0 = False
    class_name_1 = choice_0(items=items_0, length=length_0, unique=unique_0)
    assert class_name_1 == ['a']

# Generated at 2022-06-25 20:33:21.208174
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert len(choice_0(items=[1, 2, 3])) >= (0)
    assert choice_0(items=[1, 2, 3, 4, 5], length=5) == [1, 2, 4, 4, 5]
    assert choice_0(items=[1, 2, 3], length=10) == [2, 1, 3, 1, 1, 3, 3, 1, 3, 3]
    assert choice_0(items=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20], length=10, unique=True) == [16, 5, 4, 19, 3, 6, 17, 18, 20, 15]

# Generated at 2022-06-25 20:33:28.076202
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_1 = Choice()
    assert choice_1(items=['a', 'b', 'c']) == 'c'
    assert choice_1(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice_1(items='abc', length=2) == 'ba'
    assert choice_1(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice_1(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-25 20:33:38.336361
# Unit test for method __call__ of class Choice

# Generated at 2022-06-25 20:33:42.508441
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 0
    unique = False
    assert (Choice.__call__(items, length, unique) == 'a')


# Generated at 2022-06-25 20:33:46.706511
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__('abc', length=2) == 'ba'
    assert Choice().__call__(length=0, items=['a', 'b', 'c']) == 'c'
    assert Choice().__call__(length=5, items=('a', 'b', 'c')) == ('c', 'a', 'a', 'b', 'c')


# Generated at 2022-06-25 20:33:52.183023
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = None
    length = 0
    unique = False
    actual = choice_0.__call__(items, length, unique)
    expected = None
    assert actual == expected


# Generated at 2022-06-25 20:34:00.812163
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0.choice(['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice_0.choice(['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice_0.choice('abc', length=2) in ['ab', 'ac', 'bc']

# Generated at 2022-06-25 20:34:08.475962
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    choice_1 = Choice(seed=1)
    choice_2 = Choice(seed=108)
    choice_3 = Choice(seed=0)

    assert choice_0(['a', 'b', 'c', 'd', 'e', 'f'], 1, True) in (
        'a', 'b', 'c', 'd', 'e', 'f')
    assert choice_1(['a', 'b', 'c', 'd', 'e', 'f'], 1, True) in (
        'a', 'b', 'c', 'd', 'e', 'f')
    assert choice_2(['a', 'b', 'c', 'd', 'e', 'f'], 1, True) in (
        'a', 'b', 'c', 'd', 'e', 'f')

# Generated at 2022-06-25 20:34:29.563060
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method __call__ of class Choice"""
    choice_0 = Choice()
    v_0 = choice_0(items=['a', 'b', 'c'])
    # 'c'
    v_1 = choice_0(items=['a', 'b', 'c'], length=1)
    # ['a']
    v_2 = choice_0(items='abc', length=2)
    # 'ba'
    v_3 = choice_0(items=('a', 'b', 'c'), length=5)
    # ('c', 'a', 'a', 'b', 'c')
    v_4 = choice_0(items='aabbbccccddddd', length=4, unique=True)
    # 'cdba'



# Generated at 2022-06-25 20:34:38.996269
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method __call__ of class Choice."""

    choice_0 = Choice()
    assert choice_0(items=['a', 'b', 'c']) == 'c'

    choice_1 = Choice()
    assert choice_1(items=['a', 'b', 'c'], length=1) == ['a']

    choice_2 = Choice()
    assert choice_2(items='abc', length=2) == 'ba'

    choice_3 = Choice()
    assert choice_3(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')

    choice_4 = Choice()
    assert choice_4(items='aabbbccccddddd', length=4, unique=True) == 'cdba'



# Generated at 2022-06-25 20:34:45.869702
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0.__call__(items=["a", "b", "c"]) == "c"
    assert choice_0.__call__(items=["a", "b", "c"], length=1) == ["a"]
    assert choice_0.__call__(items="abc", length=2) == "ba"
    assert choice_0.__call__(items=("a", "b", "c"), length=5) == ("c", "a", "a", "b", "c")
    assert choice_0.__call__(items="aabbbccccddddd", length=4, unique=True) == "cdba"

# Generated at 2022-06-25 20:34:53.760424
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    choice_0(items=('a', 'b', 'c'), length=4, unique=True)
    choice_0(items=('a', 'b', 'c'))
    choice_0(items='ab', length=10, unique=True)
    choice_0(items='', length=1, unique=False)
    choice_0(items='ab', length=10, unique=True)
    choice_0(items=('a', 'b', 'c'), length=5)
    choice_0(items=('a', 'b', 'c'), length=4, unique=True)
    choice_0(items='', length=2, unique=False)
    choice_0(items=('a', 'b', 'c'), length=1, unique=False)

# Generated at 2022-06-25 20:35:05.724034
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Checking the value of all fields
    choice_1 = Choice()
    assert choice_1.__call__(items=['a', 'b', 'c', 'd',
                                    'e', 'f', 'g', 'h',
                                    'i', 'j', 'k', 'l',
                                    'm', 'n', 'o', 'p', 'q',
                                    'r', 's', 't', 'u', 'v',
                                    'w', 'x', 'y', 'z']) == 'a'

# Generated at 2022-06-25 20:35:09.492953
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    res = Choice().__call__(['a', 'b', 'c'], 1, False)
    assert isinstance(res, str)

# Generated at 2022-06-25 20:35:17.810542
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=[], length=0, unique=False) is None
    assert Choice().__call__(items=[], length=0, unique=True) is None
    assert Choice().__call__(items=[], length=10, unique=False) is None
    assert Choice().__call__(items=[], length=10, unique=True) is None
    assert Choice().__call__(items=[0], length=0, unique=False) is None
    assert Choice().__call__(items=[0], length=0, unique=True) is None
    assert Choice().__call__(items=[0], length=10, unique=False) is None
    assert Choice().__call__(items=[0], length=10, unique=True) is None

# Generated at 2022-06-25 20:35:26.428059
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    choice_0._locales = 'en'
    choice_0.context['partition'] = {'seed': 0, 'counter': 0}

    items = choice_0(items=['a', 'b', 'c'])
    item = choice_0(items=['a', 'b', 'c'], length=1)
    item = choice_0(items='abc', length=2)
    item = choice_0(items=('a', 'b', 'c'), length=5)
    item = choice_0(items='aabbbccccddddd', length=4, unique=True)

    assert items == 'c'
    assert item == ['a']
    assert item == 'ba'
    assert item == ('c', 'a', 'a', 'b', 'c')

# Generated at 2022-06-25 20:35:30.185989
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()

    # Call method __call__ of choice_0
    assert isinstance(choice_0(items='abc', length=2, unique=True), str)


# Generated at 2022-06-25 20:35:42.083718
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0(('a', 'b', 'c')) == 'a'
    assert choice_0(('a', 'b', 'c'), 2) == ['b', 'b']
    assert choice_0(('a', 'b', 'c'), 2, True) == ['a', 'c']
    assert choice_0(('a', 'b', 'c'), 2, False) == ['a', 'b']
    # TODO: fix dynamic typing
    # assert choice_0(('a', 'b', 'c'), 2, unique=True) == ['a', 'c']
    # assert choice_0(('a', 'b', 'c'), 2, unique=False) == ['a', 'b']
    assert choice_0('abc', 2) == 'aa'

# Generated at 2022-06-25 20:38:25.857130
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice()(items=['a', 'b', 'c'], length=0, unique=False) == 'c'
    assert Choice()(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice()(items='abc', length=2) == 'ba'
    assert Choice()(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice()(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-25 20:38:33.284398
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_1 = Choice()
    assert choice_1(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice_1(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice_1(items='abc', length=2) in ['ab', 'ac', 'bc']

# Generated at 2022-06-25 20:38:36.627982
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 0
    unique = False
    choice_0 = Choice()
    assert isinstance(choice_0(items, length,unique), str)
    

# Generated at 2022-06-25 20:38:42.734268
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    choice_1 = Choice()
    items_0 = ['a', 'b', 'c']
    length_0 = 0
    unique_0 = False
    length_1 = 1
    length_2 = 2
    length_3 = 5
    unique_1 = True
    assert choice_0(items_0) in items_0
    if len(items_0) == 1:
        assert choice_0(items_0) == choice_1(items_0)
    assert len(choice_0(items_0, length_0)) == length_0
    assert len(choice_0(items_0, length_1)) == length_1
    assert len(choice_0(items_0, length_2)) == length_2
    assert len(choice_0(items_0, length_3))

# Generated at 2022-06-25 20:38:48.071210
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.builtins import Choice as Choice_0

    assert isinstance(Choice_0().__call__(items=[], length=0), str) is True
    assert isinstance(Choice_0().__call__(items=[], length=0, unique=False),
                      str) is True
    assert Choice_0().__call__(items=[], length=0, unique=False) == ''
    assert Choice_0().__call__(items=[], length=0, unique=False) == ''
    assert Choice_0().__call__(items=[], length=0, unique=False) == ''
    assert Choice_0().__call__(items=[], length=0, unique=False) == ''
    assert Choice_0().__call__(items=[], length=0, unique=False) == ''
    assert Choice_0().__call

# Generated at 2022-06-25 20:38:49.353298
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method __call__ of class Choice."""
    __tracebackhide__ = True
    choice = Choice()

    asse

# Generated at 2022-06-25 20:38:50.315324
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__('abc', 3) == ['c', 'c', 'c']


# Generated at 2022-06-25 20:38:52.274502
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0.__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 20:38:57.963691
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    choice_1 = Choice()

    # Test with basic parameters
    assert choice_0(items=[1, 2, 3]) in [1, 2, 3]
    assert choice_0(items=[1, 2, 3], length=1) == [1]
    assert choice_0(items='abc', length=2) in ['ba', 'ac', 'cb']
    assert choice_0(items=(1, 2, 3), length=5) in [(1, 3, 2, 1, 2), (2, 1, 2, 3, 2), (2, 3, 1, 2, 3)]
    assert choice_0(items=(1, 2, 3), length=5, unique=True) in [(1, 2, 3), (1, 3, 2), (3, 1, 2)]

    # Test with arbitrary parameters


# Generated at 2022-06-25 20:39:04.909943
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items_0 = 'tPyjDZ'
    items_1 = ['J', '', 'X', 'j', 'y', 'e', '', '', 'K', 'b', 'a', '', '', '', '', 'X', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '']
    items_2 = ['H', 'G', '']