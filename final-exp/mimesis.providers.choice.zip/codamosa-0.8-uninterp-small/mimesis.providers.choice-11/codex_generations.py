

# Generated at 2022-06-25 20:29:13.251231
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.builtins import Choice
    list_0 = []
    choice_0 = Choice(*list_0)
    list_1 = ['', '', '']
    list_2 = ['', '', '']
    length_0 = 1
    string_0 = choice_0(list_1, length_0)


# Generated at 2022-06-25 20:29:19.416976
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    list_0 = []
    choice_0 = Choice(*list_0)
    choice_0.random.choice = lambda : 'h'
    length = 0
    assert choice_0.__call__(['v', 's', 'h'], length, False) == 'h'
    choice_0.random.choice = lambda : 'c'
    length = 2
    assert choice_0.__call__(['v', 'h', 'c'], length, False) == 'ch'
    choice_0.random.choice = lambda : 'k'
    length = 4
    assert choice_0.__call__('vk', length, False) == 'kkkk'



# Generated at 2022-06-25 20:29:24.069700
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test case for method __call__ of class Choice"""
    list_0 = ['1', '0', '3', '8', '6', '4', '5']
    choice_0 = Choice(length=5)
    choice_2 = list_0[5]
    choice_1 = choice_0(items=list_0, length=10, unique=True)
    assert choice_1 == choice_2

# Generated at 2022-06-25 20:29:28.348320
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    list_0 = ['a', 'b', 'c']
    int_0 = 1
    bool_0 = False
    assert len(choice_0(list_0, length=int_0, unique=bool_0)) == int_0

# Generated at 2022-06-25 20:29:38.100385
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import string # Dictionary of string constants
    int_0 = 1 # Variable_0
    length_0 = string.ascii_letters # Variable_1
    length_1 = length_0 # Variable_2
    length_2 = length_1 # Variable_4
    int_1 = 0 # Variable_3
    length_3 = length_2 # Variable_6
    length_4 = length_3 # Variable_8
    int_2 = int_1 # Variable_7
    length_5 = length_4 # Variable_10
    int_3 = int_2 # Variable_9
    length_6 = length_5 # Variable_12
    length_7 = length_6 # Variable_14
    int_4 = int_3 # Variable_13
    length_8 = length_7 # Variable_16
    int_5 = int_2

# Generated at 2022-06-25 20:29:45.407073
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    v0 = 0x5B6DBF
    v1 = 0x5B6DBD
    v2 = 0x5B6DBE
    v3 = 0x5B6DC0

# Generated at 2022-06-25 20:29:54.913703
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    items = ['a', 'b', 'c']
    value_0 = choice_0(items=items)
    value_1 = choice_0(items=items, length=1)
    value_2 = choice_0(items='abc', length=2)
    value_3 = choice_0(items=('a', 'b', 'c'), length=5)
    value_4 = choice_0(items='aabbbccccddddd', length=4, unique=True)
    assert value_0 == 'c'
    assert value_1 == ['a']
    assert value_2 == 'ba'
    assert value_3 == ('c', 'a', 'a', 'b', 'c')
    assert value_4 == 'cdba'

# Generated at 2022-06-25 20:30:03.799585
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(('b', 'd', '1', 'e', 'f'), 0) == '1'
    assert Choice().__call__(('f', '8', 'd', '4', '6', '7'), 1) == ['8']
    assert Choice().__call__(['5', '9', '3', '3', '5'], 0, False) == '3'
    assert Choice().__call__(('2', '2', '7', 'c', 'c'), 0, False) == '7'
    assert Choice().__call__('b55d9c94e', 0, True) == 'e'
    assert Choice().__call__('e2dd', 2, True) == 'de'

# Generated at 2022-06-25 20:30:15.575753
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0('abcd') in ('a', 'b', 'c', 'd')
    assert choice_0('abcd', 1) in (
        ['a'],
        ['b'],
        ['c'],
        ['d'],
    )

    assert choice_0('abcd', 2) in (
        'a',
        'b',
        'c',
        'd',
        'ba',
        'ab',
        'bd',
        'db',
        'dc',
        'cd',
        'ca',
        'ac',
        'ad',
        'da',
    )


# Generated at 2022-06-25 20:30:26.648633
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    items_0 = ['a', 'b', 'c']
    assert choice_0(items_0) == 'a'
    items_1 = ['a', 'b', 'c']
    length_0 = 1
    assert choice_0(items_1, length_0) == ['a']
    items_2 = 'abc'
    length_1 = 2
    assert choice_0(items_2, length_1) == 'cd'
    items_3 = ('a', 'b', 'c')
    length_2 = 5
    assert choice_0(items_3, length_2) == ('a', 'c', 'b', 'b', 'a')
    items_4 = 'aabbbccccddddd'
    length_3 = 4
    unique_0 = True

# Generated at 2022-06-25 20:30:32.581518
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice(locale='zh')
    result_0 = choice_0(items=(), unique=True)
    assert result_0 == ()

# Generated at 2022-06-25 20:30:34.092715
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice == choice.random.choice(choice)

# Generated at 2022-06-25 20:30:40.915669
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    # Test case 0
    try:
        list_0 = ['eAvZ8YvZh', '', 'o9]', 'r^-jy`v5']
        choice_0 = Choice(*list_0)
        choice_0(['', '', 'EjG'], 0, True)
    except ValueError as value_e:
        pass

        # Test case 1
        try:
            list_1 = ['CyaVp', '', 'GBP']
            choice_1 = Choice(*list_1)
            choice_1(['i.`-{&', 'jxD4@'], -4, True)
        except ValueError as value_e:
            pass

# Generated at 2022-06-25 20:30:51.118103
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Test against an arbitrary list of strings.
    items_0 = [
        '_0_',
        '_1_',
        '_2_',
    ]
    length_0 = choice_0(items_0, 10)
    # print("length_0:", length_0)
    # print("length_0:", len(length_0))
    # print("items_0:", items_0)
    # print("items_0:", len(items_0))
    assert isinstance(items_0, list)
    assert len(items_0) == 3
    assert isinstance(length_0, list)
    assert len(length_0) == 10
    # print("length_0:", length_0)
    # print("items_0:", items_0)

    # Test against an arbitrary list

# Generated at 2022-06-25 20:30:55.334152
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    class_ = Choice()
    class_.get_random = lambda *args, **kwargs: 0
    assert class_(['a', 'b', 'c']) == 'a'


# Generated at 2022-06-25 20:30:58.754216
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    try:
        assert Choice.__call__()
    except TypeError:
        assert False
    except KeyError:
        assert True

    assert Choice.__call__()


# Generated at 2022-06-25 20:31:09.788690
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """
    Test __call__
    """
    # Test cases
    # Test case 0
    # Setup
    x = choice_0.__call__()
    # Exercise
    # Exercise
    # Exercise
    # Exercise
    # Exercise
    # Exercise
    # Exercise
    # Exercise
    # Exercise
    # Exercise
    # Exercise
    # Exercise
    # Exercise
    # Exercise
    # Exercise
    # Exercise
    # Exercise
    # Exercise
    # Exercise
    # Exercise
    # Exercise
    # Exercise
    # Exercise
    # Exercise
    # Exercise
    # Exercise
    # Exercise
    # Exercise
    # Exercise
    # Exercise
    # Exercise
    # Exercise
    # Exercise
    # Exercise
    # Exercise
    # Exercise
    # Exercise
    # Exercise
    # Exercise
    # Exercise


# Generated at 2022-06-25 20:31:15.853658
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0(items=['a', 'b', 'c']) == 'c'
    assert choice_0(items='abc', length=2) == 'ba'
    assert choice_0(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-25 20:31:27.926345
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    item_0 = Choice()
    item_0.seed(92)
    item_1 = item_0('aabbc', 2, True)
    assert type(item_1) == str
    assert item_1 == 'cb'
    list_0 = []
    choice_0 = Choice(*list_0)
    item_2 = choice_0('abc', 3, True)
    assert type(item_2) == str
    assert item_2 == 'bca'
    choice_1 = Choice(*list_0)
    item_3 = choice_1('abc', 3, False)
    assert item_3 == 'ccc'
    choice_2 = Choice(*list_0)
    item_4 = choice_2(('ab', 'c', 'd', 'e', 'f'), 0, True)

# Generated at 2022-06-25 20:31:37.976058
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-25 20:31:52.865367
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    # int length
    length_0 = choice_0.random.randint(0, 10)
    # sequence items
    items_0 = choice_0.random.randint(0, 10, choice_0.random.randint(1, 10))
    # bool unique
    unique_0 = choice_0.random.choice((True, False))
    # call Choice.__call__(items: Sequence[Any], length: int = 0, unique: bool = False)
    choice_0(items=items_0, length=length_0, unique=unique_0)

    # str items
    items_1 = choice_0.random.randstr(length_0)
    # call Choice.__call__(items: Sequence[Any], length: int = 0, unique: bool = False)
    choice_

# Generated at 2022-06-25 20:31:59.277216
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items_0 = []
    length_0 = 0
    unique_0 = False
    choice_0 = Choice()
    assert choice_0(items=items_0, length=length_0, unique=unique_0) == None
    items_1 = [1, 2, 3]
    length_1 = 0
    unique_1 = False
    choice_1 = Choice()
    assert choice_1(items=items_1, length=length_1, unique=unique_1) == 2
    items_2 = 'abc'
    length_2 = 0
    unique_2 = False
    choice_2 = Choice()
    assert choice_2(items=items_2, length=length_2, unique=unique_2) == 'a'
    items_3 = 'abc'
    length_3 = 3

# Generated at 2022-06-25 20:32:06.697473
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    list_0 = ['q', 'Q', 'Ny', 'b', '\u00f8', '\u00d1', 'X', '\u00f2']
    choice_0 = Choice(**list_0)
    items_0 = choice_0
    length_0 = 2
    unique_0 = True
    result_0 = choice_0(items=items_0, length=length_0, unique=unique_0)
    # assert value is True
    assert result_0 == 'Q\u00d1'


# Generated at 2022-06-25 20:32:08.835763
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    list_0 = []
    assert 'cc'.upper() == 'CC'



# Generated at 2022-06-25 20:32:18.622553
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()

    choice(items=['a', 'b', 'c'], length=1)
    choice(items=['a', 'b', 'c'], length=1, unique=True)
    choice(items=['a', 'b', 'c'], length=2)
    choice(items=['a', 'b', 'c'], length=2, unique=True)
    choice(items=['a', 'b', 'c'], length=3)
    choice(items=['a', 'b', 'c'], length=3, unique=True)
    choice(items=['a', 'b', 'c'], length=4)
    choice(items=['a', 'b', 'c'])
    choice(items=(), length=4)

# Generated at 2022-06-25 20:32:24.719923
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    length_0 = 0
    items_0 = ['a', 'b', 'c']
    unique_0 = False
    choice_0(items_0, length_0, unique_0)


if __name__ == '__main__':
    test_Choice___call__()

# Generated at 2022-06-25 20:32:31.287971
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items_0 = None
    length_0 = 0
    unique_0 = False
    assert Choice().__call__(items_0, length_0, unique_0) == None
    assert Choice().__call__(items=None, length=0, unique=False) == None
    items_1 = 'p5Zq'
    length_1 = 3
    unique_1 = True
    assert Choice().__call__(items_1, length_1, unique_1) == 'p5Z'
    assert Choice().__call__(items='p5Zq', length=3, unique=True) == 'p5Z'
    items_2 = 0
    length_2 = 4
    unique_2 = False
    assert Choice().__call__(items_2, length_2, unique_2) == None
    assert Choice().__

# Generated at 2022-06-25 20:32:40.727005
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice(*[], **{'seed': 0})
    list_0 = []
    integer_0 = 0
    list_1 = choice_0(list_0, integer_0)
    assert list_1 is None
    list_2 = choice_0(list_0)
    assert list_2 is None
    tuple_0 = ()
    list_3 = choice_0(tuple_0, integer_0)
    assert list_3 is None
    list_4 = choice_0(tuple_0)
    assert list_4 is None
    string_0 = '1G2cH'
    list_5 = choice_0(string_0, integer_0)
    assert list_5 is None
    list_6 = choice_0(string_0)
    assert list_6 is None
    list

# Generated at 2022-06-25 20:32:47.878567
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    string_0 = 'gSmuBxQ$e@1'
    length_0 = 6
    choice_0 = Choice()
    elements_0 = tuple(string_0[:length_0])
    number_0 = 3
    string_1 = choice_0(items=elements_0, length=number_0)
    print(string_1)


# Generated at 2022-06-25 20:32:51.650370
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Test cases
    # TODO: More cases

    # Call method __call__ of class Choice
    choice_0 = Choice()
    # choice_0._Choice__call__()



# Generated at 2022-06-25 20:33:09.834436
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    list_0 = []
    choice_0 = Choice(*list_0)
    str_0 = choice_0.choice(['b', 'c', 'd', 'e', 'f', 'g', 'h', 'j', 'k', 'i', 'l', 'm', 'n', 'o', 'p', 'q', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'j', 'k', 'i', 'l', 'm', 'n', 'o', 'p', 'q', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'])
    str_1 = choice_0.choice(['d', 'e'])
   

# Generated at 2022-06-25 20:33:21.398193
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    list_0 = ['a', 'b', 'c', 'd']
    choice_0 = Choice(*list_0)

    # Test line 21
    try:
        choice_0.__call__(items=choice_0.random.choice(choice_0.random.choice(list_0)))
    except ValueError:
        pass
    except TypeError:
        pass
    else:
        assert False
    # Test line 22
    try:
        choice_0.__call__(items=choice_0.random.choice(choice_0.random.choice(list_0)), length=choice_0.random.randint(1, 1000))
    except Exception:
        assert False
    # Test line 23

# Generated at 2022-06-25 20:33:29.475264
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    list_0 = ['a', 'b', 'c']
    choice_0 = Choice()
    assert choice_0(items=list_0) == 'c'
    assert choice_0(items=list_0, length=(-1)) == 'c'
    assert choice_0(items=list_0, length=1) == ['a']
    assert choice_0(items='abc', length=2) == 'ba'
    assert choice_0(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice_0(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    list_1 = []
    choice_1 = Choice(list_1)

# Generated at 2022-06-25 20:33:33.107204
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    sequence_0 = []
    sequence_1 = []
    sequence_2 = []
    choice_0 = Choice(*sequence_0)
    assert type(choice_0.__call__(sequence_1, 1, False)) == str
    assert type(choice_0.__call__(sequence_2, 1, True)) == str


# Generated at 2022-06-25 20:33:41.292953
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.utils import randomness
    from mimesis.enums import Gender

    list_0 = []
    list_1 = [0, 0, 0, 1, 1, 0, 1, 0, 0, 1, 0, 1, 1, 1, 1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1]
    list_2 = [True, False, False, False, False, True, True]

# Generated at 2022-06-25 20:33:48.812761
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice(None)
    sequence_0 = []
    assert choice_0(sequence_0) == choice_0.random.choice(sequence_0)
    sequence_1 = ['x', 'X', 'x', 'X', 'x']
    assert choice_0(sequence_1, length=4, unique=True) == 'XxxX'
    sequence_2 = ['a', 'b', 'c', 'd', 'e']
    assert choice_0(sequence_2, length=4, unique=True) == 'aceb'
    sequence_3 = []
    assert choice_0(sequence_3) == choice_0.random.choice(sequence_3)
    sequence_4 = ['x', 'X', 'x', 'X', 'x']

# Generated at 2022-06-25 20:33:59.695758
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    list_0 = ['a', 'b', 'c']
    int_0 = choice_0(list_0, 1)
    assert int_0 == ['a']
    int_1 = choice_0(list_0, 2)
    assert int_1 == ['c', 'b']
    int_2 = choice_0(list_0, 3)
    assert int_2 == ['a', 'c', 'b']
    int_3 = choice_0(list_0)
    assert int_3 == 'b'
    int_4 = choice_0(list_0, 4, True)
    assert int_4 == ['a', 'c', 'b', 'c']
    int_5 = choice_0(list_0, 5)

# Generated at 2022-06-25 20:34:04.120864
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    list_0 = []
    choice_0 = Choice(*list_0)
    str_0 = choice_0(str, 2, False)
    assert str_0 == 'Z'



# Generated at 2022-06-25 20:34:16.014942
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_1 = Choice()
    items_0 = ['a', 'b', 'c']
    length_0 = 1
    unique_0 = False
    assert (choice_1(items=items_0, length=length_0, unique=unique_0) == ['a'])
    items_1 = 'abc'
    length_1 = 2
    unique_1 = False
    assert (choice_1(items=items_1, length=length_1, unique=unique_1) == 'ba')
    items_2 = ('a', 'b', 'c')
    length_2 = 5
    unique_2 = False
    assert (choice_1(items=items_2, length=length_2, unique=unique_2) == \
        ('c', 'a', 'a', 'b', 'c'))
    items_

# Generated at 2022-06-25 20:34:27.584770
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Initialization
    items_0 = []
    items_1 = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
    assert Choice(items_0).__call__() in items_0
    assert Choice(items_1).__call__() in items_1
    assert Choice(items_1).__call__(length=0) in items_1
    assert Choice(items_1).__call__(length=2) in items_1
    assert Choice(items_1).__call__(length=3) in items_1
    assert Choice(items_1).__call__(length=4) in items_1
    assert Choice(items_1).__call__(length=5) in items_1

# Generated at 2022-06-25 20:34:49.436700
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    list_1 = []
    choice_1 = Choice(*list_1)
    assert choice_1(items=[], length=0)
    list_2 = []
    choice_2 = Choice(*list_2)
    assert choice_2(items=[], length=1)
    list_3 = []
    choice_3 = Choice(*list_3)
    assert choice_3(items=[], length=0, unique=False)
    list_4 = []
    choice_4 = Choice(*list_4)
    assert choice_4(items=[], length=1, unique=True)
    list_5 = []
    choice_5 = Choice(*list_5)
    assert choice_5(items=[], length=0, unique=False)
    assert choice_5(items=[], length=1, unique=True)
    list_6

# Generated at 2022-06-25 20:34:52.844062
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TODO
    method_name = '__call__'
    assert True


# Generated at 2022-06-25 20:34:56.383854
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    list_0 = []
    choice_0 = Choice(*list_0)
    choice_0.__call__(items = ('a', 'b', 'c'), unique=True)

# Generated at 2022-06-25 20:35:06.654207
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    list_0 = [1, 2]
    choice_0 = Choice(*list_0)
    choice_1 = Choice(*list_0)
    choice_2 = Choice(*list_0)
    choice_3 = Choice(*list_0)
    choice_4 = Choice(*list_0)
    choice_5 = Choice(*list_0)
    choice_6 = Choice(*list_0)
    choice_7 = Choice(*list_0)
    choice_8 = Choice(*list_0)
    choice_9 = Choice(*list_0)
    choice_10 = Choice(*list_0)
    choice_11 = Choice(*list_0)
    choice_12 = Choice(*list_0)
    choice_13 = Choice(*list_0)
    choice_14 = Choice(*list_0)

# Generated at 2022-06-25 20:35:16.960089
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice(4)

    # Try method call with negative length.
    # Try method call with length greater than the length of items and unique
    # True.
    try:
        choice_0.__call__(['', '9'], -1, True)
    except ValueError:
        pass

    # Try method call with empty items and non-zero length.
    try:
        choice_0.__call__([], 1)
    except ValueError:
        pass

    # Try method call with items and length greater than the length of items
    # and unique True.
    try:
        choice_0.__call__(['X', 'X', 'X', 'X', 'X', 'X'], 6, True)
    except ValueError:
        pass

    # Try method call with non-sequence items.

# Generated at 2022-06-25 20:35:26.161647
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    list_0 = []
    choice_0 = Choice(*list_0)
    int_0 = choice_0(['a', 'b', 'c', 'e', 'd'], unique=False, length=5)
    assert int_0 in ['a', 'b', 'c', 'd', 'e']
    bool_0 = choice_0.random.getstate() is choice_0.random.getstate()
    assert bool_0 is True
    int_1 = choice_0(['a', 'b', 'c', 'e', 'd'], unique=False, length=2)
    assert int_1 in ['a', 'b', 'c', 'd', 'e']
    list_1 = []
    choice_1 = Choice(*list_1)

# Generated at 2022-06-25 20:35:33.571688
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from collections.abc import Sequence
    from mimesis import Choice
    choice = Choice()
    choice_1 = Choice('randomly-chosen-sequence-or-bare-element-from-sequence')
    choice_2 = Choice()
    choice_3 = Choice(items = [], length = 0, unique = False)
    choice_4 = Choice(items = choice_3, length = 0, unique = False)
    choice_5 = Choice(items = choice_3, length = choice_3, unique = False)
    choice_6 = Choice(items = choice_3, length = choice_3, unique = choice_3)
    choice_7 = Choice(items = choice_3, length = choice_3, unique = choice_3)
    choice_8 = Choice(items = choice_3, length = choice_3, unique = choice_3)

# Generated at 2022-06-25 20:35:40.673084
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Case 0: Non-empty sequence (list, tuple or string) of elements.
    items_0 = ['a', 'b', 'c']
    length_0 = 5
    unique_0 = False
    choice_0 = Choice()

    assert choice_0(items_0, length_0, unique_0) == ['a', 'b', 'b', 'c', 'c']
    return


# Generated at 2022-06-25 20:35:51.900891
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    list_0 = ['e', 'b']
    choice_0 = Choice(*list_0)
    value_0 = choice_0.__call__(['b', 'a'])
    assert isinstance(value_0, (str, list, tuple))
    assert value_0 in ('a', 'b')
    list_1 = []
    choice_1 = Choice(*list_1)
    value_1 = choice_1.__call__(['c', 'e', 'b', 'd', 'a'])
    assert isinstance(value_1, (str, list, tuple))
    assert value_1 in ('a', 'b', 'c', 'd', 'e')
    list_2 = []
    choice_2 = Choice(*list_2)

# Generated at 2022-06-25 20:36:02.123656
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pattern_0 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    pattern_1 = re.compile(r'\d+')
    sequence_0 = pattern_0
    choice_0 = Choice()
    boolean_0 = choice_0(sequence_0)
    assert isinstance(boolean_0, int)
    assert not isinstance(boolean_0, str)
    boolean_0 = choice_0(sequence_0, True)
    assert isinstance(boolean_0, int)
    boolean_0 = choice_0(items=sequence_0, length=0)
    assert isinstance(boolean_0, int)
    boolean_0 = choice_0(items=sequence_0, length=1)
    assert isinstance(boolean_0, int)
