

# Generated at 2022-06-25 20:29:15.650482
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_1 = Choice()
    choice_1.__call__(items=['a', 'b', 'c'])
    choice_1.__call__(items=['a', 'b', 'c'], length=1)
    choice_1.__call__(items='abc', length=2)
    choice_1.__call__(items=('a', 'b', 'c'), length=5)
    choice_1.__call__(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-25 20:29:24.328446
# Unit test for method __call__ of class Choice
def test_Choice___call__():
# Test 1
    try:
        assert choice_0.__call__(["a", "b", "c"], 0, False) == "c"
    except (TypeError, ValueError, AssertionError):
        pass

# Test 2
    try:
        assert choice_0.__call__(["a", "b", "c"], 1, False) == ["a"]
    except (TypeError, ValueError, AssertionError):
        pass

# Test 3
    try:
        assert choice_0.__call__("abc", 2, False) == "ba"
    except (TypeError, ValueError, AssertionError):
        pass

# Test 4

# Generated at 2022-06-25 20:29:29.607910
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items_1: Optional[Sequence[Any]] = ('a', 'b', 'c')
    length_1: int = 0
    unique_1: bool = False
    value_1 = Choice.__call__(Choice(), items_1, length_1, unique_1)
    # Tested with examples in class docstring
    assert value_1 == 'a'



# Generated at 2022-06-25 20:29:39.375232
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    data = [
        ('a', 'c'),
        ('a', 'b'),
        ('a', 'c'),
        ('a', 'b'),
        ('a', 'b'),
        ('a', 'c'),
        ('a', 'c'),
        ('a', 'c'),
        ('a', 'b'),
        ('a', 'b'),
        ('a', 'b'),
        ('a', 'b'),
        ('a', 'c'),
        ('a', 'c'),
        ('a', 'b'),
        ('a', 'b'),
        ('a', 'c'),
        ('a', 'c'),
        ('a', 'c'),
        ('a', 'c'),
        ('a', 'b'),
    ]
    choice_1 = Choice()


# Generated at 2022-06-25 20:29:43.981692
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    print(Choice().call(items=['a', 'b', 'c']))
    print(Choice().call(items=['a', 'b', 'c'], length=1))
    print(Choice().call(items='abc', length=2))
    print(Choice().call(items=('a', 'b', 'c'), length=5))
    print(Choice().call(items='aabbbccccddddd', length=4, unique=True))


# Generated at 2022-06-25 20:29:52.933552
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    # TODO this test will fail unless Choice returns a type that is consistent
    # with the type of items
    # assert choice_0(items=['a', 'b', 'c']) == 'c'
    assert choice_0(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice_0(items='abc', length=2) == 'ba'
    assert choice_0(items=('a', 'b', 'c'), length=5) == \
           ('c', 'a', 'a', 'b', 'c')
    assert choice_0(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-25 20:30:03.597543
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Base use case
    seq = ('a', 'b', 'c', 'd', 'e', 'f')
    length = 5
    unique = False
    for i in range(0, 5):
        ret = Choice().__call__(
            items=seq,
            length=length,
            unique=unique,
        )
        assert isinstance(ret, collections.abc.Sequence)
        assert len(ret) == length
        for item in ret:
            assert item in seq

    list_0 = ['a', 'b', 'c', 'd', 'e', 'f']
    length_0 = 4
    unique_0 = True
    ret_0 = Choice().__call__(
        items=list_0,
        length=length_0,
        unique=unique_0,
    )

# Generated at 2022-06-25 20:30:11.906153
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test predefined method"""
    choice_0 = Choice()
    items = list()
    length = 0
    unique = False
    result = choice_0(items, length, unique)
    assert result == list()
    items = str()
    length = 2
    unique = False
    result = choice_0(items, length, unique)
    assert result == str()
    items = tuple()
    length = 1
    unique = True
    result = choice_0(items, length, unique)
    assert result == tuple()

# Generated at 2022-06-25 20:30:13.277195
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice

    choice_1 = Choice()
    assert choice_1(items=('a', 'b', 'c'), length=5) == ('a', 'c', 'b', 'c', 'b')

# Generated at 2022-06-25 20:30:17.141559
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0(items=('a', 'b', 'c')) == 'c'
    assert choice_0(items=('a', 'b', 'c'), length=1) == ['a']
    assert choice_0(items='a', length=2) == 'aa'
    assert choice_0(items='abc', length=2) == 'ba'
    assert choice_0(items=('a', 'b', 'c'), length=5) == ('a', 'b', 'c', 'a', 'b')
    assert choice_0(items='aabbbccccddddd', length=4, unique=True) == 'adbc'

# Generated at 2022-06-25 20:30:29.028872
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    items_0 = ['a', 'b', 'c']
    expected = 'c'
    actual = choice_0(items=items_0)
    assert actual == expected, f'Actual {actual} <> Expected {expected}'

    choice_1 = Choice()
    items_1 = ['a', 'b', 'c']
    length_1 = 1
    expected = ['a']
    actual = choice_1(items=items_1, length=length_1)
    assert actual == expected, f'Actual {actual} <> Expected {expected}'

    choice_2 = Choice()
    items_2 = 'abc'
    length_2 = 2
    expected = 'ba'
    actual = choice_2(items=items_2, length=length_2)
    assert actual

# Generated at 2022-06-25 20:30:39.719007
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    item = choice(('a', 'b', 'c'), unique=False)
    # TODO: Consider some assertion
    item

    item = choice(['a', 'b', 'c'], unique=True)
    # TODO: Consider some assertion
    item

    item = choice(['a', 'b', 'c'])
    # TODO: Consider some assertion
    item

    word = choice(['a', 'b', 'c', 'd'], length=10, unique=True)
    # TODO: Consider some assertion
    word

    word = choice('foobar', length=3)
    # TODO: Consider some assertion
    word

    word = choice('foobar', length=3, unique=False)
    # TODO: Consider some assertion
    word


# Generated at 2022-06-25 20:30:42.161504
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()

    assert choice_0(items=['a', 'b', 'c']) == 'c'


# Generated at 2022-06-25 20:30:47.071246
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0(items=['a', 'b', 'c']) == 'c'
    assert choice_0(items=[1, 'c', 'a', 'b']) in (1, 'c', 'a', 'b')

# Generated at 2022-06-25 20:30:53.924301
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    try:
        choice_1 = Choice().__call__(['a', 'b', 'c'])
    except Exception as e:
        print(e)
        if isinstance(e, TypeError) and str(e) == '**items** must be non-empty sequence.':
            print('Success')
    else:
        print('Failed')
    try:
        choice_2 = Choice().__call__(['a', 'b', 'c'], 1)
    except Exception as e:
        print(e)
        if isinstance(e, TypeError) and str(e) == '**items** must be non-empty sequence.':
            print('Success')
    else:
        print('Failed')

# Generated at 2022-06-25 20:30:58.233415
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_1 = Choice()
    # TODO: Implement a more complete test case
    assert choice_1(items=['a', 'b', 'c'], length=2, unique=True) in (
        ['a', 'c'], ['c', 'a'], ['a', 'b'], ['b', 'a'], ['b', 'c'], ['c', 'b'])

# Generated at 2022-06-25 20:31:07.739349
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0(items=['a', 'b', 'c']) == 'c'
    assert choice_0(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice_0(items='abc', length=2) == 'ba'
    assert choice_0(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice_0(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-25 20:31:12.771018
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice( )
    choice_1 = Choice( )
    choice_2 = Choice( )


# Generated at 2022-06-25 20:31:22.338734
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_1 = Choice()
    assert isinstance(choice_1.__call__(items=['a', 'b', 'c']), str)
    assert isinstance(choice_1.__call__(items=['a', 'b', 'c'], length=1), list)
    assert isinstance(choice_1.__call__(items='abc', length=2), str)
    assert (isinstance(choice_1.__call__(items=('a', 'b', 'c'), length=5),
                       tuple))
    assert isinstance(choice_1.__call__(items='aabbbccccddddd', length=4,
                                        unique=True), str)
    assert choice_1.__call__(items=['a', 'b', 'c']) in ('a', 'b', 'c')

# Generated at 2022-06-25 20:31:29.341023
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TEST CASES
    # test_case_0:
    items_0 = ['a', 'b', 'c']
    length_0 = 1
    unique_0 = False
    assert choice_0(items=items_0, length=length_0, unique=unique_0) == 'a'

    # test_case_1:
    items_1 = 'abc'
    length_1 = 2
    unique_1 = False
    assert choice_0(items=items_1, length=length_1, unique=unique_1) == 'bc'

    # test_case_2:
    items_2 = ('a', 'b', 'c')
    length_2 = 5
    unique_2 = False

# Generated at 2022-06-25 20:31:40.898010
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice(seed=2217)
    assert choice_0(items=set([1, 2]), length=7, unique=True) == {2, 1}

    choice_1 = Choice(seed=45888)
    assert choice_1(items=set([1, 2]), length=7, unique=False) == {2, 2, 1, 1}

    choice_2 = Choice(seed=93466)
    assert choice_2(items=set([1, 2]), length=1, unique=True) == {2}

    choice_3 = Choice(seed=50734)
    assert choice_3(items=set([1, 2]), length=0, unique=False) == {2}

    choice_4 = Choice(seed=6643)

# Generated at 2022-06-25 20:31:48.387082
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    choice = Choice()

    output = choice.__call__(items, length, unique)
    print(output)

    items_1 = 'abc'
    length_1 = 2
    unique_1 = False
    choice_1 = Choice()

    output_1 = choice_1.__call__(items_1, length_1, unique_1)
    print(output_1)


# Generated at 2022-06-25 20:31:52.865588
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    from random import choice

    choice_0 = Choice()
    sequence_0 = ('a', 'b', 'c')
    assert choice_0(items=sequence_0) in sequence_0


# Generated at 2022-06-25 20:31:59.290180
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_1 = Choice()
    result_1 = choice_1.__call__(items=['a', 'b', 'c'])
    assert (result_1 == 'c')
    result_2 = choice_1.__call__(items=['a', 'b', 'c'], length=1)
    assert (result_2 == ['a'])
    result_3 = choice_1.__call__(items='abc', length=2)
    assert (result_3 == 'ba')
    result_4 = choice_1.__call__(items=('a', 'b', 'c'), length=5)
    assert (result_4 == ('c', 'a', 'a', 'b', 'c'))

# Generated at 2022-06-25 20:32:03.225211
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b']
    length = 2
    choice = Choice()
    result = choice(items, length, unique=False)
    assert result in items

# Generated at 2022-06-25 20:32:05.765528
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert (choice_0(items=('a', 'b', 'c'), length=5)) == ('c', 'a', 'a', 'b', 'c')



# Generated at 2022-06-25 20:32:17.689551
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    # case 0
    # items = ['a', 'b', 'c']
    # length = 0
    # unique = False
    # expected = 'c'
    result_0 = choice_0.__call__(items=['a', 'b', 'c'], length=0, unique=False)
    assert result_0 == 'c'
    # case 1
    # items = ['a', 'b', 'c']
    # length = 1
    # unique = False
    # expected = ['a']
    result_1 = choice_0.__call__(items=['a', 'b', 'c'], length=1, unique=False)
    assert result_1 == ['a']
    # case 2
    # items = 'abc'
    # length = 2
    # unique = False


# Generated at 2022-06-25 20:32:25.425682
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choices = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
    choice_0 = Choice()
    choice_0.__call__(items=choices, length=20, unique=True)
    
    
    
    

# Generated at 2022-06-25 20:32:31.515423
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    choice_1 = Choice(seed=3579709891)  # Local seed for unit testing
    choice_2 = Choice(seed=3579709891)

    assert choice_1('ABC', 0) == 'C'
    assert choice_2('ABC', 0) == 'C'
    assert (choice_1('ABC', 4) == 'BCAC')
    assert (choice_2('ABC', 4) == 'BCAC')
    assert (choice_1('ABC', 4, True) == 'ACCB')
    assert (choice_2('ABC', 4, True) == 'ACCB')
    assert (choice_1('ABC', 10) == 'ACCCABABCB')
    assert (choice_2('ABC', 10) == 'ACCCABABCB')

# Generated at 2022-06-25 20:32:39.349225
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0(items=['a', 'b', 'c']) == 'c'
    assert choice_0(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice_0(items='abc', length=2) == 'ba'
    assert choice_0(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice_0(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-25 20:33:21.631672
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()

# Generated at 2022-06-25 20:33:26.365694
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for Choice.__call__."""
    from typing import Any, Sequence
    choice = Choice()
    _items = 'abc'  # type: Optional[Sequence[Any]]
    _length = 0
    _unique = False
    _output = choice(items=_items, length=_length, unique=_unique)
    assert isinstance(_output, str)

# Generated at 2022-06-25 20:33:32.318398
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    items_0 = ['a', 'b', 'c']
    length_0 = 2
    unique_0 = True
    ret_0 = choice_0(items=items_0, length=length_0, unique=unique_0)
    assert ret_0 == 'ab'

# Generated at 2022-06-25 20:33:40.986052
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-25 20:33:46.073937
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    items_0 = ['', '', '', '', '', '', '', '', '', '']
    length_0 = 1
    unique_0 = False
    data_0 = choice_0(items_0, length_0, unique_0)
    assert len(data_0) == length_0



# Generated at 2022-06-25 20:33:52.178680
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 1
    unique = False

    expected = 'b'
    actual = Choice().__call__(items, length, unique)

    assert expected == actual


# Generated at 2022-06-25 20:33:59.510707
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0(items=['a', 'b', 'c']) == 'c'
    assert choice_0(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice_0(items='abc', length=2) == 'ba'
    assert choice_0(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice_0(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-25 20:34:08.095943
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_1 = Choice()
    assert choice_1(items=['a', 'b', 'c']) == 'a'
    choice_2 = Choice()
    assert choice_2(items=['a', 'b', 'c']) == 'b'
    choice_3 = Choice()
    assert choice_3(items=['a', 'b', 'c']) == 'c'
    choice_4 = Choice()
    assert choice_4(items=['a', 'b', 'c'], length=0) == 'a'
    choice_5 = Choice()
    assert choice_5(items=['a', 'b', 'c'], length=1) == ['a']
    choice_6 = Choice()
    assert choice_6(items='abc', length=2) == 'ab'
    choice_7 = Choice()
   

# Generated at 2022-06-25 20:34:16.402740
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender
    c = Choice()

    # Test for bool
    data = c()
    assert data in [True, False]

    # Test for digit
    data = c()
    assert isinstance(data, int)

    # Test for gender
    data = c()
    assert isinstance(data, Gender)

    # Test for integer
    data = c()
    assert isinstance(data, int)

    # Test for string
    data = c()
    assert isinstance(data, str)

    # Test for unique
    data = c()
    assert len(data) == 10
    assert len(set(data)) == len(data)

# Generated at 2022-06-25 20:34:25.869446
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-25 20:35:23.145898
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=[1, 2, 3, 4, 5], length=3) != None


# Generated at 2022-06-25 20:35:32.726966
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()


# Generated at 2022-06-25 20:35:43.343980
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0(items=['a', 'b', 'c']) == 'c'
    assert choice_0(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice_0(items='abc', length=2) == 'ba'
    assert choice_0(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice_0(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

    with raises(TypeError):
        choice_0(items=['a', 'b', 'c'], length=2.5)
    with raises(TypeError):
        choice_0(items='str', length=5)

# Generated at 2022-06-25 20:35:51.236213
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert choice_0.__call__(items=None) == choice_0.random.choice(None)
    assert choice_0.__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice_0.__call__('aabbbccccddddd', length=4, unique=True) == 'cdba'
    assert choice_0.__call__(items=None, length=5, unique=True) == choice_0.random.choice(None)

# Generated at 2022-06-25 20:35:56.966312
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 5
    unique = True
    data = choice(items=items, length=length, unique=unique)
    assert isinstance(data, collections.abc.Sequence)


# Generated at 2022-06-25 20:35:59.591373
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    expected = 'a'
    actual = choice_0(items=['a', 'b', 'c'])
    assert actual == expected



# Generated at 2022-06-25 20:36:10.502062
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0(items=['a', 'b', 'c'], length=5, unique=False) == ['b', 'c', 'a', 'c', 'b']
    assert choice_0(items='abc', length=2, unique=True) == 'ca'
    assert choice_0(items=('a', 'b', 'c'), length=4, unique=False) == ('a', 'c', 'c', 'c')
    assert choice_0(items=['a', 'b', 'c'], length=1, unique=True) == ['c']
    assert choice_0(items='aabbbccccddddd', length=4, unique=True) == 'aadb'

# Generated at 2022-06-25 20:36:21.343517
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    string = ["Mick", "Danny", "Alex", "Kate", "Tyler", "Anastasia", "Sara", "Samantha", "Will", "Caroline", "Stephen", "Owen", "Jacob", "Hannah", "Jessica", "Olivia", "Poppy", "Ava", "Isabelle", "Ruby", "Grace", "Emily", "Emilia", "Amelia", "Isla", "Ella", "Chloe", "Lily"]
    choice_1 = Choice()
    choice_2 = Choice()
    choice_3 = Choice()
    choice_4 = Choice()
    choice_5 = Choice()
    choice_6 = Choice()
    choice_7 = Choice()
    choice_8 = Choice()

    output_0 = choice_1(string, 1, True)

# Generated at 2022-06-25 20:36:25.935424
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    assert choice(items=items, length=length, unique=unique) in items

# Generated at 2022-06-25 20:36:34.230276
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import unittest.mock
    import sys
    import unittest
    import warnings

    class CallTestCase(unittest.TestCase):
        """Tests for `Choice.__call__` method."""

        def test_choice_0(self):
            """Test __call__ method of Choice class."""
            # Set up test values
            arg_0 = ['a', 'b', 'c']
            arg_1 = 1
            arg_2 = False
            # Attempt to execute the code to be tested
            # Assert the results of the test
            self.assertEqual(choice_0(
                arg_0, arg_1, arg_2), 'b')
        def test_choice_1(self):
            """Test __call__ method of Choice class."""
            # Set up test values

# Generated at 2022-06-25 20:38:59.715196
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    items_0 = choice_0('a', 'b', 'c')
    length_0 = 2
    unique_0 = True
    result_0 = choice_0(items_0, length_0, unique_0)
    assert result_0 == 'ab'

# Generated at 2022-06-25 20:39:01.193773
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice()(items=['a', 'b', 'c']) == 'c'


# Generated at 2022-06-25 20:39:05.498706
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    assert isinstance(choice(items=['a', 'b', 'c']), str)
    assert isinstance(choice(items=['a', 'b', 'c'], length=1), Sequence)
    assert isinstance(choice(items='abc', length=2), str)
    assert isinstance(choice(items=('a', 'b', 'c'), length=5), Sequence)
    assert isinstance(choice(items='aabbbccccddddd', length=4, unique=True), str)