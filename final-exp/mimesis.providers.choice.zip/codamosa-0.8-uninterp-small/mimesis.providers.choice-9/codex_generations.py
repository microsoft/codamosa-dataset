

# Generated at 2022-06-25 20:29:28.525239
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Generating a randomly-chosen sequence or bare element from a sequence.

    # Provide elements randomly chosen from the elements in a sequence list
    # items, where when length is specified the random choices are contained in
    # a sequence of the same type of length length, otherwise a single
    # uncontained element is chosen. If unique is set to True, constrain a
    # returned sequence to contain only unique elements.
    choice_1 = Choice()
    assert choice_1(items=['a', 'b', 'c']) == 'c'
    assert choice_1(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice_1(items='abc', length=2) == 'ba'

# Generated at 2022-06-25 20:29:30.062620
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'a'


# Generated at 2022-06-25 20:29:39.733630
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    print('\nUnit test for method __call__ of class Choice')
    print('\n' + '_'*70)


# Generated at 2022-06-25 20:29:49.260102
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_1 = Choice()
    assert choice_1(items=['a', 'b', 'c']) == 'c'
    assert choice_1(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice_1(items='abc', length=2) == 'ba'
    assert choice_1(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice_1(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-25 20:29:58.377203
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    choice_1 = Choice(seed=6)
    choice_2 = Choice(locale='en-GB')
    choice_3 = Choice(seed=0)
    choice_4 = Choice(locale='cs-CZ')
    choice_5 = Choice(seed=1)
    choice_6 = Choice(locale='pl-PL')
    items_0 = '+:/.&,|(#[._]@*-\\"66?3E%Z$u8Q'
    length_0 = 27
    length_1 = 14
    length_2 = 1
    length_3 = 4
    length_4 = 5
    length_5 = 6
    length_6 = 7
    length_7 = 8
    length_8 = 9
    length_9 = 10

# Generated at 2022-06-25 20:30:08.242417
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    test_str = '''
        >>> from mimesis import Choice
        >>> choice = Choice()

        >>> choice(items=['a', 'b', 'c'])
        'c'
        >>> choice(items=['a', 'b', 'c'], length=1)
        ['a']
        >>> choice(items='abc', length=2)
        'ba'
        >>> choice(items=('a', 'b', 'c'), length=5)
        ('c', 'a', 'a', 'b', 'c')
        >>> choice(items='aabbbccccddddd', length=4, unique=True)
        'cdba'
    '''
    test_code = compile(test_str, '', 'exec')
    exec(test_code)

# Generated at 2022-06-25 20:30:16.413623
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    result = Choice().__call__(items=['a', 'b', 'c'], length=1)
    result = Choice().__call__(items=['a', 'b', 'c'])
    result = Choice().__call__(items='abc', length=2)
    result = Choice().__call__(items=('a', 'b', 'c'), length=5)
    result = Choice().__call__(items='aabbbccccddddd', length=4, unique=True)
    result = Choice().__call__('aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-25 20:30:21.395046
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # arrange
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 1
    unique = True
    expected = ['a']
    # act
    actual = choice.__call__(items=items, length=length, unique=unique)
    # assert
    assert actual == expected

# Generated at 2022-06-25 20:30:27.958910
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    for _ in range(1):
        choice_0 = Choice()
        arg_0 = choice_0.choice(['a', 'b', 'c'])
        assert choice_0(items=['a', 'b', 'c']) == arg_0

        choice_1 = Choice()
        arg_1 = choice_1.choice(['a', 'b', 'c'])
        assert choice_1(items=['a', 'b', 'c'], length=1) == [arg_1]

        choice_2 = Choice()
        arg_2 = choice_2.choice('abc')
        assert choice_2(items='abc', length=1) == arg_2

        choice_3 = Choice()
        arg_3 = choice_3.choice(['a', 'b', 'c'])

# Generated at 2022-06-25 20:30:35.847577
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_1 = Choice()
    choice_1(items=['a', 'b', 'c'])
    choice_1(items=['a', 'b', 'c'], length=1)
    choice_1(items='abc', length=2)
    choice_1(items=('a', 'b', 'c'), length=5)
    choice_1(items='aabbbccccddddd', length=4, unique=True)


# Generated at 2022-06-25 20:30:49.795842
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice() == 'a'
    assert choice() == 'b'
    assert choice() == 'c'

# Generated at 2022-06-25 20:30:59.353397
# Unit test for method __call__ of class Choice
def test_Choice___call__():
  choice_0 = Choice()
  items = ["a", "b", "c"]
  length = 7
  unique = True
  assert choice_0(items, length, unique) == "abaaabac"
  items = ["a", "b", "c"]
  length = 1
  unique = True
  assert choice_0(items, length, unique) == "c"
  items = ["a", "b", "c"]
  length = 6
  unique = False
  assert choice_0(items, length, unique) == "cacccc"
  items = ["a", "b", "c"]
  length = 5
  unique = True
  assert choice_0(items, length, unique) == "cabca"
  items = ["a", "b", "c"]
  length = 9
  unique = True


# Generated at 2022-06-25 20:31:07.503706
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    items_0 = choice_0.__call__(choice_0.random.choice, 1)
    items_1 = choice_0.__call__('test', 9, True)
    items_2 = choice_0.__call__(choice_0.random.choice, 1)
    items_3 = choice_0.__call__('test', 9, True)
    items_4 = choice_0.__call__(choice_0.random.choice, 1)


# Generated at 2022-06-25 20:31:18.790804
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    choice_1 = Choice()
    choice_2 = Choice()
    choice_3 = Choice()
    items_0 = list(range(0, 5))
    items_1 = list(range(0, 6))
    items_2 = list(range(0, 7))
    items_3 = tuple(range(0, 8))
    items_4 = tuple(range(0, 9))
    length_0 = 8
    length_1 = 9
    unique_0 = True
    unique_1 = False
    ret = choice_0(items_0, length_0, unique_0)
    print(ret)
    ret = choice_1(items_1, length_1, unique_0)
    print(ret)

# Generated at 2022-06-25 20:31:28.424907
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Verify __call__ method for a class Choice"""
    # Test the Choice._call__ function for random choice
    choice = Choice()
    assert choice(items=[1, 2, 3, 4], length=2) in [[1, 2], [2, 1], [3, 4], [4, 3]]
    assert choice(items=[1, 2, 3, 4], length=0) in [1, 2, 3, 4]
    assert choice(items=[1, 2, 3, 4], length=2, unique=True) in [[1, 2], [2, 1], [3, 4], [4, 3]]
    # Test for invalid arguments

# Generated at 2022-06-25 20:31:37.302081
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    choice_0 = Choice()
    assert choice_0(items=['a', 'b', 'c']) == 'c'
    assert choice_0(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice_0(items='abc', length=2) == 'ba'
    assert choice_0(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')

# Generated at 2022-06-25 20:31:49.508217
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_1 = Choice()
    assert check_type(choice_1()) == str

    choice_2 = Choice(seed=12345)
    assert check_type(choice_2()) == str

    choice_3 = Choice(seed=12345)
    assert check_type(choice_3(['a', 'b', 'c'])) == str
    assert check_type(choice_3(['a', 'b', 'c'], 0)) == str
    assert check_type(choice_3(['a', 'b', 'c'], 1)) == list

    choice_4 = Choice(seed=12345)
    assert check_type(choice_4(['a', 'b', 'c'], -1)) == str
    assert check_type(choice_4(['a', 'b', 'c'], -1)) == str

   

# Generated at 2022-06-25 20:31:56.711569
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()  # length: 0, unique: False
    # if not items:
    assert choice_0([]) == None
    assert choice_0([], 1) == None
    # if not isinstance(items, collections.abc.Sequence):
    assert choice_0(0) == None
    assert choice_0(None) == None
    assert choice_0(0, 1) == None
    assert choice_0(None, 1) == None
    # if not isinstance(length, int):
    assert choice_0([0.0], 0.0) == None
    assert choice_0(['aaa'], 'aaa') == None
    # if length < 0:
    assert choice_0([1, 2, 3], -1) == None
    # if length == 0:
    choice_1 = Choice()  #

# Generated at 2022-06-25 20:32:04.356925
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()

    assert choice_0(items=['a', 'b', 'c'], length=2, unique=True) == 'cb'

    assert choice_0(items=['a', 'b', 'c'], length=2, unique=False) == 'cc'

    assert choice_0(items='abc', length=1, unique=False) == 'c'



# Generated at 2022-06-25 20:32:10.137317
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    _items: Optional[Sequence[Any]] = ['a', 'b', 'c']
    _length: int = 0
    _unique: bool = False
    choice_0 = Choice()
    assert choice_0(_items=_items, _length=_length, _unique=_unique) == 'c'

    _items: Optional[Sequence[Any]] = ['a', 'b', 'c']
    _length: int = 1
    _unique: bool = False
    choice_0 = Choice()
    assert choice_0(_items=_items,
                    _length=_length,
                    _unique=_unique) == ['a']

    _items: Optional[Sequence[Any]] = 'abc'
    _length: int = 2
    _unique: bool = False
    choice_0 = Choice()

# Generated at 2022-06-25 20:32:22.009684
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert callable(Choice.__call__)
    data = 'abc'
    assert Choice().__call__(data) in data
    assert len(Choice().__call__(data, 3)) == 3
    assert Choice().__call__(data, 4, True) in (data + data)


# Generated at 2022-06-25 20:32:26.079927
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    sequence = Choice__call__(items, length, unique)
    assert sequence == ['a']
    

# Generated at 2022-06-25 20:32:34.812873
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    choice_0(items=['a', 'b', 'c'])
    choice_0(items=['a', 'b', 'c'], length=1)
    choice_0(items='abc', length=2)
    choice_0(items=('a', 'b', 'c'), length=5)
    choice_0(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-25 20:32:41.680831
# Unit test for method __call__ of class Choice

# Generated at 2022-06-25 20:32:49.581179
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    choice_1 = Choice()
    items_0 = ['a', 'b', 'c']
    length_0 = 1
    length_1 = 2
    result_0 = choice_0(items=items_0, length=length_0)
    result_1 = choice_0(items=items_0, length=length_1)
    result_2 = choice_1(items=items_0, length=length_1, unique=True)
    assert result_0 == ['a']
    assert result_1 == 'cc'
    assert result_2 == 'cb'

# Generated at 2022-06-25 20:33:01.811163
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    items = ['a', 'b', 'c']
    length = 1
    unique = False
    output = choice(items=items, length=length, unique=unique)
    assert isinstance(output, list)
    assert len(output) == length
    for item in output:
        assert item in items

    items = 'abc'
    length = 2
    unique = False
    output = choice(items=items, length=length, unique=unique)
    assert isinstance(output, str)
    assert len(output) == length
    for item in output:
        assert item in items

    items = ('a', 'b', 'c')
    length = 5
    unique = False
    output = choice(items=items, length=length, unique=unique)
    assert isinstance(output, tuple)

# Generated at 2022-06-25 20:33:06.723343
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_1 = Choice()
    assert choice_1(items=['a', 'b', 'c']) == 'c'
    assert choice_1(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice_1(items='abc', length=2) == 'ba'
    assert choice_1(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice_1(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-25 20:33:09.993184
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice()(['a', 'b', 'c']) == 'c'
    assert Choice()(['a', 'b', 'c'], length=1) == ['a']
    assert Choice()('abc', length=2) == 'ba'

# Generated at 2022-06-25 20:33:22.725328
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    choice_1 = Choice()
    result_1 = choice_1(items, length, unique)
    assert result_1 in ('a', 'b', 'c')

    length = 2
    choice_2 = Choice()
    result_2 = choice_2(items, length, unique)
    assert isinstance(result_2, str)
    assert all([char in items for char in result_2])

    items = ['a', 'b', 'c', 'd', 'e']
    length = 5
    choice_3 = Choice()
    result_3 = choice_3(items, length, unique)
    assert isinstance(result_3, list)
    assert len(result_3) == length

# Generated at 2022-06-25 20:33:30.092894
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.structures import Structures
    import datetime
    _datetime = datetime.datetime(2020, 1, 1, 0, 0)
    _integer = 0
    _float = 0.0
    _string = ''
    _choice_0 = Choice()
    _choice_1 = Choice()
    _choice_2 = Choice()
    _choice_3 = Choice()
    _choice_4 = Choice()
    _choice_5 = Choice(datetime=Datetime(datetime=_datetime, timezone='US/Pacific'))
    _choice_6 = Choice(datetime=Datetime(datetime=_datetime, timezone='UTC'))
    _choice_7 = Choice(structures=Structures(seed=_integer))