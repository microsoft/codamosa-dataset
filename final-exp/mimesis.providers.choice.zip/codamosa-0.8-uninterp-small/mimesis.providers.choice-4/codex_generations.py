

# Generated at 2022-06-25 20:29:33.414032
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items_0 = ['ee', 'Ud', 'K<p', '|@D', '', 'O$*', '0', 'S\\k', '', '', '', '', '', '1<4', '', '', '', '', '', '']
    length_0 = 16
    unique_0 = False
    choice_0 = Choice()
    output_0 = choice_0(items_0, length_0, unique_0)
    assert type(output_0) is list
    assert len(output_0) == length_0
    items_1 = ['#.`', '', '', '', '|', 'j<>', '', '', '', '', '', '', '1(', '', '', '', '', '', '', '', 'D', '', '']
    length_1

# Generated at 2022-06-25 20:29:38.183909
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    tuple_0 = ('h', 'H', 'e', 'D')
    int_0 = 7
    bool_0 = False
    tuple_1 = choice_0.__call__(tuple_0, int_0, bool_0)
    assert tuple_1 == ('H', 'h', 'h', 'h', 'E', 'e', 'D')



# Generated at 2022-06-25 20:29:41.515751
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    item0 = ['a', 'b', 'c']
    int_0 = 2
    bool_0 = True

    assert type(choice_0.__call__(items=item0, length=int_0, unique=bool_0)) is str


# Generated at 2022-06-25 20:29:44.840285
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0(items="\u2086", length=2) == '\u2086\u2086'



# Generated at 2022-06-25 20:29:53.357787
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    
    # Test 1
    assert choice.__call__(('a', 'b', 'c', 'd'), 1, False) == 'a' and choice.__call__(('a', 'b', 'c', 'd'), 1, False) == 'b' and choice.__call__(('a', 'b', 'c', 'd'), 1, False) == 'c' and choice.__call__(('a', 'b', 'c', 'd'), 1, False) == 'd'
    
    # Test 2

# Generated at 2022-06-25 20:29:56.960939
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0(items=list_0, length=int_0, unique=bool_0) == str_0

# Generated at 2022-06-25 20:30:06.167337
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    print("Testing __call__...")
    choice_0 = Choice()
    int_0 = -668
    assert choice_0(items='', length=int_0) == '', "str.__call__(items='', length=int_0) == ''"
    assert choice_0(items='', length=int_0) == '', "str.__call__(items='', length=int_0) == ''"
    assert choice_0(items='', length=int_0) == '', "str.__call__(items='', length=int_0) == ''"
    assert choice_0(items='', length=int_0) == '', "str.__call__(items='', length=int_0) == ''"

# Generated at 2022-06-25 20:30:10.046314
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice()(items=('a', 'b', 'c'), length=5) == ('a', 'c', 'a', 'b', 'c'), 'Method __call__ in class Choice returned unexpected result.'


# Generated at 2022-06-25 20:30:18.524074
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    str_0 = 'C0Acp8xnXo'
    int_0 = -292
    bool_0 = False
    choice_1 = Choice()
    str_1 = 'q6'
    int_1 = -922
    list_0 = []
    for _ in range(40):
        list_0.append(choice_1.random.randint(1, 10))
    int_2 = -300
    bool_1 = True
    str_2 = 'Fh'
    int_3 = -364
    choice_2 = Choice()
    str_3 = 'HgZ2xh9b'
    int_4 = -447
    bool_2 = True
    str_4 = 'd'
    int_5 = -506
    bool_3 = False

# Generated at 2022-06-25 20:30:28.758106
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    # Case 0
    choice_0 = Choice()
    str_0 = '7500U'
    int_0 = -668
    bool_0 = False
    list_0 = [1, 2, 3]
    list_1 = [str_0, int_0, bool_0, list_0]
    bool_1 = True
    int_1 = 5
    str_1 = choice_0(list_1, int_1, bool_1)
    assert((str_1 != str_0) and (str_1 != int_0) and (str_1 != bool_0) and
           (str_1 != list_0) and (len(set(str_1)) == len(str_1)))

    # Case 1
    choice_1 = Choice()
    int_2 = 500
    bool_2 = False


# Generated at 2022-06-25 20:30:50.081274
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    str_0 = '7500U'
    int_0 = -668
    bool_0 = False
    data = []  # type: ignore
    if bool_0 and len(set(data)) < int_0:  # avoid an infinite while loop
        raise ValueError('There are not enough unique elements in **items** to provide the specified **number**.')
    while len(data) < int_0:
        item = choice_0.random.choice(data)
        if (bool_0 and item not in data) or not bool_0:
            data.append(item)
    if isinstance(data, list):
        return data
    elif isinstance(data, tuple):
        return tuple(data)
    return ''.join(data)


# Generated at 2022-06-25 20:30:59.443980
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    str_0 = '9abcdefghijklmnopqrstuvwxyz'
    int_0 = -668
    bool_0 = False

# Generated at 2022-06-25 20:31:04.920541
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    str_0 = '7500U'
    int_0 = -668
    bool_0 = False
    # TODO: Check returned value
    choice_0(str_0, int_0, bool_0)


# Generated at 2022-06-25 20:31:11.084683
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    int_0 = -668
    str_0 = '7500U'
    bool_0 = False
    int_1 = -668
    assert choice_0('7500U') is None
    assert choice_0('7500U', length=1) is None
    str_1 = '7500U'
    assert choice_0('7500U', length=2) is None
    str_2 = '7500U'
    assert choice_0('7500U', length=5) is None
    str_3 = '7500U'
    assert choice_0('7500U', length=4, unique=True) is None

# Generated at 2022-06-25 20:31:16.939311
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    str_0 = '7500U'
    int_0 = -668
    bool_0 = False

    choice_1 = Choice()
    str_1 = '##G@'
    int_2 = -967
    bool_3 = False

    # Call method __call__ from class Choice
    str_2 = choice_1(str_1, int_2, bool_3)

# Generated at 2022-06-25 20:31:28.052765
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()

    # from mimesis.providers.person.en_GB.address.address import Address
    # TODO: Global scope
    # address = Address()

    # str_1 = address.country()
    str_1 = 'United Kingdom'
    # int_0 = address.latitude()
    int_0 = 51.5073509
    # int_1 = address.longitude()
    # str_2 = address.street_address()
    # str_3 = address.city()
    # str_4 = address.postcode()
    # str_5 = address.region()
    str_5 = 'England'
    # list_0 = [str_1, int_0, int_1, str_2, str_3, str_4, str_5]

    # dict_0 =

# Generated at 2022-06-25 20:31:36.028146
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items_0 = ['e', '0*9;\xa8', '\xa1', '\nj']
    length_0 = 88
    unique_0 = False
    assert len(Choice.__call__(items_0, length_0, unique_0)) == 88
    assert Choice.__call__(items_0, length_0, unique_0)[0] == 'e'

# Generated at 2022-06-25 20:31:39.464630
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    str_0 = '7500U'
    int_0 = -668
    bool_0 = False


# Generated at 2022-06-25 20:31:52.866451
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    list_0 = ['85', 'a', '465', ':Gs', 'l', '~', '4505', 'j5_']
    str_0 = choice_0(list_0, length=5, unique=False)
    assert str_0 is None or any((isinstance(str_0, str), str_0 == ''))
    str_1 = choice_0(list_0, length=4, unique=True)
    assert str_1 is None or any((isinstance(str_1, str), str_1 == ''))
    str_2 = choice_0(list_0, unique=False)
    assert str_2 is None or any((isinstance(str_2, str), str_2 == ''))

# Generated at 2022-06-25 20:31:59.277161
# Unit test for method __call__ of class Choice

# Generated at 2022-06-25 20:32:29.212596
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    from mimesis.enums import Gender
    choice = Choice('en')
    choice('items=Gender.ALL_GENDERS.value')
    choice('items=Gender.ALL_GENDERS.value', length=3)
    choice('items=Gender.ALL_GENDERS.value', length=3, unique=True)
    choice('items=Gender.ALL_GENDERS.value', length=0)
    choice('items=Gender.ALL_GENDERS.value', length=0, unique=True)



# Generated at 2022-06-25 20:32:39.896297
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    length = 2
    unique = False
    assert unique
    unique = True
    assert not unique
    items = None
    choice(items=items, length=length, unique=unique)
    assert length == 2
    length = 3
    assert length != 2
    length = 4
    assert not length == 2
    choice(items=items, length=length, unique=unique)
    assert unique
    unique = False
    assert not unique
    unique = True
    assert unique

# Generated at 2022-06-25 20:32:48.922066
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    items = choice_0(choice_0.choices(items=['a', 'b', 'c']), None)
    b = choice_0(choice_0.choices(items=['a', 'b', 'c']), None, None)
    print(items)
    print(b)

    list_4 = list.from_iterable(iter(tuple(str.ascii_lowercase)) for _ in range(2))
    list_5 = [list_4[i:i + 1] for i in range(0, len(list_4), 1)]
    print(list_5)



# Generated at 2022-06-25 20:32:54.527911
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    # str_0 = '7500U'
    # int_0 = -668
    # bool_0 = False
    list_0 = ['c', 'e', 'a']
    list_1 = ['4', '3', '4', '0', '1']
    list_2 = ['9', 'A']
    tuple_0 = ('c', 'e', 'a')
    assert choice_0(list_0) == choice_0(tuple_0)
    assert choice_0(items=['c', 'e', 'a'], length=1) == choice_0(items=['c', 'e', 'a', 'h', 'f'], length=0)

# Generated at 2022-06-25 20:32:59.457462
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = 'abcdefghijklmnopqrstuvwxyz'
    length = 10
    unique = False
    assert len(choice(items, length, unique)) == length


# Generated at 2022-06-25 20:33:01.546115
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    items_0 = choice_0('abcd')


# Generated at 2022-06-25 20:33:07.617396
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    list_0 = ['https://david.chiboks@example.com', 'lCVSFLhOuV', 'Zb0XfY7cRb2hvk7C', 'lCVSFLhOuV', 'https://david.chiboks@example.com']
    list_1 = choice_0(list_0)
    int_0 = -4
    list_2 = choice_0(list_0, length=int_0)
    str_0 = 'https://david.chiboks@example.com'
    tuple_0 = (str_0, 'lCVSFLhOuV', 'Zb0XfY7cRb2hvk7C', 'lCVSFLhOuV', str_0)
    tuple_1

# Generated at 2022-06-25 20:33:14.879742
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from unittest.mock import MagicMock, patch
    from mimesis.builtins.base import Generic
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.choice import Choice

    with patch.object(Choice, '__init__', return_value=None):
        choice = Choice()



# Generated at 2022-06-25 20:33:17.901458
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    str_0 = '0p2225y8h'
    int_0 = -2
    bool_0 = True

# Generated at 2022-06-25 20:33:23.816506
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_0 = 'u'
    float_0 = -8.8
    float_1 = -1.3968
    choice_0 = Choice()
    str_1 = choice_0(items=['5', '+', 'X', 'd'], length=float_1)
    assert str_1 == 'd+5d'
    str_2 = choice_0(items=-6.2, length=float_1)
    assert str_2 == '-'
    str_3 = choice_0(items=True, length=float_1)
    assert str_3 == 'F'
    str_4 = choice_0(items=['5', '+', 'X', 'd'], length=0)
    assert str_4 == 'X'

# Generated at 2022-06-25 20:34:18.005329
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    str_0 = '7500U'
    int_0 = -668
    bool_0 = False
    assert choice_0(
        items='7500U',
        length=1,
        unique=False,
    ) == '7'
    assert choice_0(
        items='7500U',
        length=2,
        unique=False,
    ) == '55'
    assert choice_0(
        items='7500U',
        length=3,
        unique=False,
    ) == '000'
    assert choice_0(
        items='7500U',
        length=4,
        unique=False,
    ) == '500U'

# Generated at 2022-06-25 20:34:24.875821
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    items_0 = ['a', 'b', 'c']
    choice_0(items_0, fd8e1c7becf)
    choice_0(items_0, unique=True)
    choice_0(items_0)
    choice_0(items_0, unique=True)
    choice_0(items_0)
    str_0 = 'l'
    choice_0(str_0, fd8e1c7becf)
    choice_0(str_0, fd8e1c7becf, unique=True)
    choice_0(str_0, fd8e1c7becf)
    choice_0(str_0, unique=True)
    choice_0(str_0)
    choice_0(str_0)
   

# Generated at 2022-06-25 20:34:29.230635
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    sequence_0 = choice_0('opsu')

    # TODO: Improve assert
    assert len(sequence_0) > 0

# Generated at 2022-06-25 20:34:37.079230
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = ['c', 'a', 'b']
    length = 2
    unique = True
    value = choice(items, length, unique)
    value_ = choice.choice(items, length, unique)
    assert value == value_
    result = [] # type: ignore
    for k in range(10000):
        result.append(choice(items, length, unique))
    for k in range(10000):
        value = choice(items, length, unique)
        if value in result:
            result.remove(value)
    assert result == []


# Generated at 2022-06-25 20:34:40.474509
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    try:
        choice_0(items=(0,), length=int_0)
    except TypeError:
        pass


# Generated at 2022-06-25 20:34:53.234055
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from unittest import TestCase
    from types import MethodType
    from mimesis import Choice
    from mimesis.enums import IntegerRange
    from mimesis.typing import Sequence
    from tests import data
    from mimesis.exceptions import NonEnumerableError
    # TestCase.assertIsInstance(choice.__call__(self, items=None, length=0, unique=False), True)
    # TestCase.assertEqual(choice.__call__(self, items=None, length=0, unique=False), True)
    # TestCase.assertNotEqual(choice.__call__(self, items=None, length=0, unique=False), True)
    # TestCase.assertEqual(choice.__call__(self, items=None, length=0, unique=False), True)
    # Test

# Generated at 2022-06-25 20:35:05.457668
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    str_0 = '7500U'
    length_0 = -225
    int_0 = -668
    bool_0 = False
    choice_0(str_0, length_0, int_0)
    choice_0('0L', -250, True)
    choice_0('0L', int_0, bool_0)
    choice_0('oxf9P6')
    choice_0('oxf9P6', 0)
    choice_0('oxf9P6', 0, bool_0)
    choice_0('', length_0, int_0)
    choice_0('', length_0, int_0)
    choice_0('', int_0, bool_0)
    choice_0('', length_0, bool_0)
    choice_0

# Generated at 2022-06-25 20:35:11.676635
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    list_0 = ['-', '_', '+', ')']
    choice_1 = choice_0(items=list_0, length=0, unique=False)
    assert isinstance(choice_1, (list, tuple, str))


# Generated at 2022-06-25 20:35:16.564483
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    str_0 = '7500U'
    int_0 = -668
    bool_0 = False
    str_1 = choice_0(items=str_0, length=int_0, unique=bool_0)
    assert str_1 is not None
    assert isinstance(str_1, str)
    assert len(str_1) == int_0
    assert str_1 in str_0
    assert not bool_0


# Generated at 2022-06-25 20:35:21.198990
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    assert (choice(items, length, unique) ==
            ['a'])



# Generated at 2022-06-25 20:36:54.374166
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert choice_0.__call__(items=[int_0, int_0, int_0], length=int_0) == 12



# Generated at 2022-06-25 20:36:59.680235
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    int_0 = 4158208034476749006
    int_1 = 0
    str_0 = 'test_mimesis.test_choice.test_Case_0()'
    choice_0(items=str_0, length=int_0, unique=int_1)

# Generated at 2022-06-25 20:37:11.295566
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    str_0 = '7500U'
    list_0 = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
    list_1 = []
    str_1 = choice_0(items='abc', length=2)
    assert str_1 == 'bc'

# Generated at 2022-06-25 20:37:22.170712
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    tuple_0 = (
        '\x1f',
        '\x1a',
        '\x05',
        '\x1f',
        '\x05',
        '\r',
        '\x0e',
        '\x03',
        '\x0f',
    )
    int_0 = -555
    choice_1 = Choice()
    list_0 = [
        1101,
        8871,
        1874,
        8871,
        1874,
        201,
        7167,
        565,
        1615,
    ]
    assert choice_0(tuple_0, int_0) == choice_1(list_0, int_0)

    choice_2 = Choice()

# Generated at 2022-06-25 20:37:32.571544
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    list_0 = ['Fc', 'a', '', '', 'J', '6p', 'w', '']
    list_1 = choice_0(list_0, 2, True)
    list_2 = [list_0[i] for i in range(2)]
    assert list_1 == list_2
    assert choice_0(list_0) == '8'
    assert choice_0(list_0, 6, True) == 'Wfryv'
    list_3 = choice_0(list_0, 7, True)
    list_4 = [list_0[i] for i in range(7)]
    assert list_3 == list_4
    str_0 = 'eQz'
    assert choice_0(str_0) == 'Q'
    list_

# Generated at 2022-06-25 20:37:43.197822
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    str_0 = '7500U'
    int_0 = -668
    bool_0 = False
    int_1 = 1310
    int_2 = 763
    int_3 = 763
    int_4 = 763
    int_5 = 763
    int_6 = 763
    int_7 = 763
    int_8 = 763
    int_9 = 763
    # assert choice_0.choice(items=str_0, length=int_0, unique=bool_0) == 'UI7t0N7500U'
    assert choice_0(str_0, int_0, bool_0) == 'UI7t0N7500U'
    
    # assert choice_0.choice(items=int_1, length=int_0, unique

# Generated at 2022-06-25 20:37:45.466048
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    str_0 = '7500U'
    int_0 = -668
    bool_0 = False
    list_0 = choice_0(length=6, unique=False)
    assert len(list_0) == 6





# Generated at 2022-06-25 20:37:53.541604
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items_0 = ['n', '', 'Z7']
    items_1 = ['0', 'H', 'hC']
    items_2 = ['-2', '', 'R']
    length = 0
    # items = str
    choice_0 = Choice()
    ret_0 = choice_0(items=items_0, length=length)
    str_0 = 'Z7'
    assert str_0 == ret_0

    # items = list
    choice_1 = Choice()
    ret_1 = choice_1(items=items_1, length=length)
    str_1 = 'H'
    assert str_1 == ret_1

    # items = tuple
    choice_2 = Choice()
    ret_2 = choice_2(items=items_2, length=length)

# Generated at 2022-06-25 20:37:55.665925
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()  # TODO: create a object instance (e.g. choice_0)
    # TODO: implement test body


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 20:38:04.276950
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import random
    import string
    choice_0 = Choice()
    string_0 = choice_0.choice(['n', ']', 'n', 'i', 'G', ')', '|', 'A', 'i', '`', '`', 'z', 's', 'C', '#', 'r'])
    string_1 = choice_0.choice([58, '.', 'H', 'P', 'g', 't', 'M', 'K', '?'])
    string_2 = choice_0.choice(['=', 's', 'P', 'a', 'T', 'E', '-', 'x', '4', 'y', '.', 'v', 'w', '8', '7', 'b'])
    string_3 = choice_0.choice(['e'])
    string_4 = choice_