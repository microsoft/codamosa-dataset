

# Generated at 2022-06-25 20:29:21.046496
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice()('abc') in 'abc'
    assert Choice()('abc', 1) in ['a']
    assert Choice()('abc', 2) in ['bc', 'ab', 'ac']
    assert Choice()('abc', 3) in ['cba', 'bca', 'bac', 'cab', 'acb', 'abc']

# Generated at 2022-06-25 20:29:26.055885
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = None
    # Code to modify the arguments before passing them to Classmethod
    tuple_0 = (choice_0,)
    list_0 = []
    # Passing arguments to classmethod
    # In the actual implementation, modify the following method call
    assert isinstance(Choice.__call__(*tuple_0, **dict(list_0)), Sequence)

# Generated at 2022-06-25 20:29:36.210833
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_0 = None
    dict_0 = {str_0: str_0, str_0: str_0}
    choice_0 = Choice(**dict_0)
    arg_0 = 1.5
    arg_1 = -1
    arg_2 = 1.5
    arg_3 = 'baba'
    arg_4 = 13
    arg_5 = 'babacadabra'
    arg_6 = 'pesca'
    arg_7 = 1
    arg_8 = 'r'
    arg_9 = -8
    arg_10 = -1
    arg_11 = -8
    arg_12 = 'baba'
    arg_13 = -1
    arg_14 = 'pesca'
    arg_15 = 'r'
    arg_16 = 1.5
   

# Generated at 2022-06-25 20:29:43.330773
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items_0 = ''
    length_0 = 0
    unique_0 = True
    choice_0 = Choice()
    choice_1 = Choice(**__var)
    assert choice_1 is not None
    assert choice_0 is not None
    quantity_0 = 0
    choice_1 = Choice(quantity=quantity_0)
    assert choice_1 is not None
    assert choice_0 is not None
    choice_1 = Choice()

    # Call method
    # TODO: Fix type error
    # result = choice_1(items=items_0, length=length_0, unique=unique_0)
    # assert result is not None
    # assert choice_0 is not None



# Generated at 2022-06-25 20:29:46.897228
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    obj_0 = choice_0.__call__([1, 2, 3, 4], 4, True)
    assert obj_0 == [4, 3, 1, 2]


# Generated at 2022-06-25 20:29:54.035768
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    choice_0.__class__.__name__.lower()
    items_0 = ('\x01', 'n', '\x01', 'h', 'Q', '\x02', ';', 's')
    length_0 = 9
    unique_0 = False
    value_0 = choice_0.__call__(items_0, length_0, unique_0)
    choice_0.seed(7)
    value_1 = choice_0.__call__(items_0, length_0, unique_0)
    assert value_0 == value_1
    choice_0.seed(7)
    items_1 = ('P', '\x02', 'g', 'w', '\x04', '\x04', '9', '}')
    length_1 = 3


# Generated at 2022-06-25 20:29:58.958190
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    length_0 = 0
    items_0 = str()
    choice_0 = Choice()
    # Uncomment the next line for output.
    # choice_0(items_0, length_0, False)
    # Uncomment the next line for output.
    # choice_0(items_0, length_0, True)


# Generated at 2022-06-25 20:30:01.443805
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    obj = Choice()
    items = []
    length = 0
    unique = False
    assert obj(items, length, unique) == obj.__call__(items, length, unique)



# Generated at 2022-06-25 20:30:03.448305
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # assert choice_0.__call__(length=2, unique=True, items=str_0) == str_0
    pass

# Generated at 2022-06-25 20:30:15.113508
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    print("test_Choice___call__()")

    # TODO: Python 3.8+ I would create a class for this
    class ChoiceSubClass(Choice):
        def __init__(self) -> None:
            super().__init__()

        def __call__(self, items: Optional[Sequence[Any]], length: int = 0,
                     unique: bool = False) -> Union[Sequence[Any], Any]:
            return super().__call__(items, length, unique)

    choice_0 = ChoiceSubClass(nonce='123')
    print(choice_0.__call__(['a', 'b', 'c']))
    # TODO: UUID is not deterministic, need to use fixed uuid
    print(choice_0.__call__(['a', 'b', 'c']))

# Generated at 2022-06-25 20:30:25.173109
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_0 = None
    dict_0 = {str_0: str_0, str_0: str_0}
    choice_0 = Choice(**dict_0)

    lst_0 = [str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0]
    choice_0.seed(1)
    for e_0 in lst_0:
        str_1 = choice_0(lst_0, 1, True)
        assert str_1 in lst_0

# Generated at 2022-06-25 20:30:25.749403
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-25 20:30:28.144252
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-25 20:30:30.969445
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice.__call__() == "a"

# Generated at 2022-06-25 20:30:34.413556
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    sequence_0 = [True, object()]
    choice_0 = Choice()
    sequence_0[0] = choice_0(sequence_0, 2)
    assert sequence_0[0] is not None


# Generated at 2022-06-25 20:30:39.206107
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_0 = None
    list_0 = []
    choice_0 = Choice(**{str_0: str_0, str_0: str_0})
    
    # Call method __call__ of class Choice
    try:
        choice_0(items=list_0, length=None, unique=None)
    except ValueError as e:
        print('ValueError: ', e)


# Generated at 2022-06-25 20:30:49.978007
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    tuple_0 = None
    int_1 = -0
    str_0 = None
    str_1 = '2'
    sequence_0 = []
    list_0 = []
    int_0 = 0
    int_2 = 255
    list_1 = ['', '', str_0, str_0, '4HJ7', str_1, '4HJ7']
    int_3 = 3
    int_4 = 10
    str_2 = '4HJ7'
    int_5 = 4
    int_6 = 5
    choice_0 = Choice(list_0)
    choice_1 = Choice(list_1)
    choice_2 = Choice(list_1)
    choice_3 = Choice(list_1)
    choice_4 = Choice(list_1)
    choice_5 = Choice

# Generated at 2022-06-25 20:30:57.170137
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_1 = Choice()
    choice_1(items='abc', length=3, unique=False)
    choice_1(items=['a', 'b', 'c'])
    choice_1(items='abc', length=2, unique=False)
    choice_1(items=('a', 'b', 'c'), length=5, unique=False)
    choice_1(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-25 20:31:09.193263
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_0 = 'ÄØ^<'
    str_1 = str_0 * 2
    choice_0 = Choice()
    assert choice_0(items=['a', 'b', 'c']) == 'b'
    assert choice_0(items=['a', 'b', 'c'], unique=False) == 'a'
    assert choice_0(items='abc', length=3, unique=True) == 'caa'
    assert choice_0(items='abc', length=2, unique=True) == 'ba'
    assert choice_0(items='abc', length=1, unique=False) == 'a'
    assert choice_0(items='abc', length=4, unique=True) == 'ccbb'

# Generated at 2022-06-25 20:31:15.485924
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_0 = None
    dict_0 = {str_0: str_0, str_0: str_0}
    choice_0 = Choice(**dict_0)
    list_0 = []
    int_0 = 0
    bool_0 = False
    sequence_0 = choice_0(list_0, int_0, bool_0)

# Test function for method __call__ of class Choice

# Generated at 2022-06-25 20:31:28.053746
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    dict_0 = {}
    choice_0 = Choice(**dict_0)
    choice_0._random.choice = lambda x: 'a'

    assert choice_0(items='abc') == 'a'
    assert choice_0(items='abc', length=1) == ['a']
    assert choice_0(items='abc', length=2) == 'ba'
    assert choice_0(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice_0(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    assert choice_0(items=['a', 'b', 'c']) == 'c'

# Generated at 2022-06-25 20:31:33.953369
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items_0 = '1'
    assert callable(Choice(items_0))
    assert Choice(Choice(Choice(Choice(Choice(Choice(Choice(Choice(
        Choice(Choice(Choice(items_0))))))))))()) == Choice(items_0)()


# Generated at 2022-06-25 20:31:39.053769
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_0 = None
    str_1 = str_0
    list_0 = [str_1, str_1, str_1]
    tuple_0 = (str_0, str_0, str_0)
    int_0 = get_primitive(int)
    choice_0 = Choice()
    call_0 = choice_0.__call__(list_0)
    call_1 = choice_0.__call__(tuple_0, int_0)

# Generated at 2022-06-25 20:31:45.454845
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items_0 = [1, 2, 3]
    choice_0 = Choice()
    number_0 = choice_0(items=items_0, length=0)
    assert number_0 in items_0
    assert number_0 == choice_0(items=items_0, length=1)[0]


# Generated at 2022-06-25 20:31:52.865614
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    dict_0 = dict()
    dict_1 = {'items': [], 'length': 0, 'unique': False}
    choice_0 = Choice(**dict_0)
    choice_1 = Choice(**dict_0)
    choice_0 = choice_1
    choice_1 = choice_0
    choice_2 = Choice(**dict_1)
    choice_2 = choice_0
    choice_3 = Choice(**dict_1)
    choice_3 = choice_0

# Generated at 2022-06-25 20:31:57.085322
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = None
    dict_0 = {'length': 3, 'items': choice_0}
    str_0 = None
    try:
        choice_0 = Choice(**dict_0)(unique=True, **dict_0)
    except ValueError as e:
        assert e.args[0] == 'There are not enough unique elements in **items** to provide the specified **number**.'
        raise
    else:
        assert False, 'Unreachable'


# Generated at 2022-06-25 20:32:03.921556
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_0 = None
    list_0 = [str_0, str_0, str_0]
    choice_0 = Choice()
    num_0 = 0
    num_1 = -1
    choice_0(list_0, num_0, True)
    choice_0(list_0, num_1, True)

# Generated at 2022-06-25 20:32:11.670475
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_0 = None
    dict_0 = {str_0: str_0, str_0: str_0}
    choice_0 = Choice(**dict_0)
    list_0 = choice_0.__call__(list_0, int_0)
    str_0 = choice_0.__call__()

# Generated at 2022-06-25 20:32:19.479743
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_0 = None
    str_1 = str_0
    set_0 = set()
    str_2 = str_1
    str_3 = str_0
    int_0 = 0
    str_4 = str_1
    int_1 = 0
    str_2 = str_1
    int_2 = 0
    float_0 = float()
    float_1 = float_0
    list_0 = list()
    str_3 = str_1
    set_0 = set()
    str_4 = str_1
    choice_0 = Choice()
    str_2 = str_3
    list_0 = list()
    set_0 = {str_2, str_1}
    list_0 = [str_4, str_0, str_1]
    str_5 = str_0

# Generated at 2022-06-25 20:32:24.621826
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Case 1
    str_0 = None
    dict_0 = {str_0: str_0, str_0: str_0}
    choice_0 = Choice(**dict_0)
    str_1 = choice_0(items=('',))
    assert str_1 == ''
    # Case 2
    str_0 = None
    dict_0 = {str_0: str_0, str_0: str_0}
    choice_0 = Choice(**dict_0)
    list_0 = []
    str_1 = choice_0(items=list_0)
    assert str_1 is None
    # Case 3
    str_0 = None
    dict_0 = {str_0: str_0, str_0: str_0}
    choice_0 = Choice(**dict_0)
   

# Generated at 2022-06-25 20:32:39.257609
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    # TODO: Fix Choice.__call__ to reliably return a string or a list
    str_0 = choice_0.__call__(None, 0, False)
    assert str_0 is not None, 'TypeError did not return an exception'
    str_1 = choice_0.__call__(None, 0, True)
    assert str_1 is not None, 'TypeError did not return an exception'

    # TODO: Fix Choice.__call__ to reliably return a string or a list
    str_2 = choice_0.__call__([], 0, False)
    assert str_2 is not None, 'TypeError did not return an exception'
    str_3 = choice_0.__call__([], 0, True)

# Generated at 2022-06-25 20:32:41.724636
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    choice_0.random.choice(('abc',))



# Generated at 2022-06-25 20:32:44.834736
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choices = {'a', 'b', 'c'}
    c_obj = Choice()
    c_obj.seed(1)
    assert c_obj(choices) in choices


# Generated at 2022-06-25 20:32:52.737813
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    dict_0 = dict()
    dict_0 = {}
    dict_0 = {'a': 'a', 'b': 'b', 'c': 'c'}
    c_0 = Choice(**dict_0)
    dict_0 = {}
    dict_0 = {}
    dict_0 = {'a': 'a', 'b': 'b', 'c': 'c'}
    tuple_0 = ('a', 'b', 'c')
    c_1 = Choice(**dict_0)
    dict_0 = {}
    dict_0 = {}
    dict_0 = {'a': 'a', 'b': 'b', 'c': 'c'}
    list_0 = ['a', 'b', 'c']
    c_2 = Choice(**dict_0)


# Generated at 2022-06-25 20:33:04.107455
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_0 = None
    dict_0 = {str_0: str_0, str_0: str_0}
    choice_0 = Choice(**dict_0)
    str_1 = '1.8.3'
    str_2 = 'PyNaCl==1.3.0'
    str_3 = 'frozendict==1.2'
    tuple_1 = (str_1, str_2, str_3)
    int_0 = choice_0(tuple_1, length=1)
    str_4 = '3.3.3'
    str_5 = 'Django==2.2.7'
    str_6 = 'Flask==0.12'
    list_0 = [str_4, str_5, str_6]
    int_1 = choice_0

# Generated at 2022-06-25 20:33:07.046879
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    list_0 = list()
    list_1 = list()
    str_0 = choice_0(list_0, length=int(0), unique=bool(0))
    assert str_0 == str()
    list_1 = choice_0(list_0, length=int('100'), unique=bool(0))
    assert list_1 == list()


# Generated at 2022-06-25 20:33:14.880098
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    items_0 = ['a', 'b', 'c']
    length_0 = 0
    unique_0 = False
    value_0 = choice_0(items=items_0, length=length_0, unique=unique_0)
    assert value_0.endswith('a')

    items_1 = ['a', 'b', 'c']
    length_1 = 1
    unique_1 = False
    value_1 = choice_0(items=items_1, length=length_1, unique=unique_1)
    assert value_1.endswith('a')

    items_2 = 'abc'
    length_2 = 2
    unique_2 = False
    value_2 = choice_0(items=items_2, length=length_2, unique=unique_2)


# Generated at 2022-06-25 20:33:15.979121
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    int_0 = Choice_0.choice(int_0, int_0, bool_0)

# Generated at 2022-06-25 20:33:21.476039
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_0 = None
    int_0 = None
    dict_0 = {str_0: str_0, str_0: str_0}
    choice_0 = Choice(**dict_0)
    items = [int_0]
    length = choice_0.random.uniform(minval=0, maxval=100)
    unique = bool(choice_0.random.randint(minval=0, maxval=1))
    choice_0(items, length, unique)
    choice_0(items, length)

# Generated at 2022-06-25 20:33:27.583671
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Test with 0 parameters ...
    choice_0 = Choice()
    assert True
    # Test with 1 parameters ...
    choice_0 = Choice()
    assert isinstance(choice_0(items=[]), str)
    # Test with 2 parameters ...
    choice_0 = Choice()
    assert isinstance(choice_0(items=[], length=1), list)
    # Test with 3 parameters ...
    choice_0 = Choice()
    assert isinstance(choice_0(items=[], length=1, unique=True), list)
    # Test with 4 parameters ...

# Generated at 2022-06-25 20:33:37.555432
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items_0 = None
    length_0 = 3
    unique_0 = False
    choice_0 = Choice()
    choice_0.__call__(items_0, length_0, unique_0)
    choice_1 = Choice()
    assert choice_1.__call__(items_0, length_0, unique_0) == items_0


# Generated at 2022-06-25 20:33:40.518185
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    item = 1
    length = 1
    obj = Choice()
    obj.__call__(item, length)

# Generated at 2022-06-25 20:33:46.040200
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('c',
                                                                  'a', 'a', 'b',
                                                                  'c')



# Generated at 2022-06-25 20:33:52.679750
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    tuple_0 = (False, '', Choice, choice_0, Choice, choice_0)
    data = choice_0.__call__(items=(False, '', Choice, choice_0, Choice, choice_0), length=2)

# Generated at 2022-06-25 20:33:57.231528
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    provider = Choice(seed=0)
    assert provider(items=["a", "b", "c"], length=5) == ("c", "a", "a", "b", "c")
    assert provider(items="aabbbccccddddd", length=4, unique=True) == "cdba"

# Generated at 2022-06-25 20:34:02.790159
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items_0 = ()
    length_0 = 0
    unique_0 = False
    choice_0 = Choice()
    # TODO: Commented till a bug will be fixed
    # result = choice_0(items=items_0, length=length_0, unique=unique_0)
    assert (result is None)
    items_0 = ()
    length_0 = 0
    unique_0 = True
    choice_0 = Choice()
    result = choice_0(items=items_0, length=length_0, unique=unique_0)
    assert (result is None)
    items_0 = (1, 2)
    choice_0 = Choice()
    result = choice_0(items=items_0)
    assert result == '2'
    items_0 = (1, 2)
    length_0 = 5

# Generated at 2022-06-25 20:34:09.013187
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0(items='abc', length=2) == 'ba'
    tuple_0 = ('a', 'a')
    assert choice_0(items=tuple_0, length=5, unique=True) == ('a', 'a', 'a')
    int_0 = (1 / 1)
    assert choice_0(items=[int_0, int_0, int_0], length=1) == [1.0]
    assert choice_0(items=[], length=2, unique=True) == []
    tuple_1 = ('a',)
    list_0 = [tuple_1 for x in range(0, 1)]
    assert choice_0(items=list_0, length=2) == [('a',), ('a',)]

# Generated at 2022-06-25 20:34:17.434036
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    choice_0 = Choice()
    str_0 = choice_0(items=items)
    assert isinstance(str_0, str)

    int_0 = choice_0(items=items, length=1)
    assert isinstance(int_0, list)
    assert len(int_0) == 1

    str_1 = choice_0(items='abc', length=2)
    assert isinstance(str_1, str)
    assert len(str_1) == 2

    tuple_0 = choice_0(items=('a', 'b', 'c'), length=5)
    assert isinstance(tuple_0, tuple)
    assert len(tuple_0) == 5


# Generated at 2022-06-25 20:34:27.996782
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items_0 = ''
    length_0 = 0
    unique_0 = False
    test_values = [('', True), ('', False), ('', False), ('', False)]
    for (length_1, unique_1) in test_values:
        length_1 = (dict_0[str_0]) if ((items_0 in dict_0)) else (length_0)
        unique_1 = (dict_0[str_0]) if ((items_0 in dict_0)) else (unique_0)
        try:
            dummy_0 = (length_1, unique_1)
            assert True
        except ValueError:
            assert False
        try:
            dummy_1 = (length_1, unique_1)
            assert True
        except TypeError:
            assert False

# Generated at 2022-06-25 20:34:38.198262
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_0 = None
    list_0 = ['H', 'G', 'K', 'V', 'K']
    int_0 = 9
    int_1 = 7
    str_1 = choice_0(list_0, int_0, True)
    int_2 = 5
    str_2 = choice_0(list_0, int_1, False)
    int_3 = 4
    str_3 = choice_0(list_0, int_2, True)
    int_4 = 7
    str_4 = choice_0(list_0, int_3, False)
    int_5 = 0
    str_5 = choice_0(list_0, int_4, True)
    int_6 = 2
    str_6 = choice_0(list_0, int_5, False)
    int

# Generated at 2022-06-25 20:35:02.736619
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    length = 0
    unique = False
    items = 'abc'
    choice_2 = Choice()
    assert isinstance(choice_2.__call__(items, length, unique), str)


# Generated at 2022-06-25 20:35:10.410155
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_2 = None
    str_0 = None
    dict_0 = {str_0: str_0, str_0: str_0}
    choice_0 = Choice(**dict_0)
    tuple_0 = (str_2, str_2)
    result = choice_0(tuple_0, 0, True)
    assert result == 'V'


# Generated at 2022-06-25 20:35:15.479664
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # initialize choice_0
    choice_0 = Choice()

    # provide test data for Choice.__call__
    items = ['a', 'b', 'c']
    length = 1
    unique = False

    # call Choice.__call__
    result = choice_0(items=items, length=length, unique=unique)

    # assert that result matches expected value
    assert result == ['a']

# Generated at 2022-06-25 20:35:25.634114
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    dict_0 = {'length': 5}
    dict_1 = {'length': 4}
    str_0 = 'abc'
    str_1 = choice_0(items=str_0, **dict_0, unique=True)
    str_2 = 'baacb'
    bool_0 = str_1 == str_2
    dict_2 = {'unique': True}
    str_3 = 'aabbbccccddddd'
    str_4 = choice_0(items=str_3, length=5, **dict_2)
    str_5 = 'babcc'
    bool_1 = str_4 == str_5
    str_6 = 'abc'

# Generated at 2022-06-25 20:35:32.748796
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items_0 = [0, 0, 0, 0, 0]
    length_0 = choice_0.random.randint(
        0, 2**(choice_0.random.randint(100, 500)))
    unique_0 = choice_0.random.choice([
        True, False, False, False, False, False, False, False, False, False
    ])
    choice_0 = Choice(**{'use_datetime': False})
    result_0 = choice_0(
        items=items_0, length=length_0, unique=unique_0)
    assert isinstance(result_0, int)



# Generated at 2022-06-25 20:35:41.160635
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    assert type(choice(items=['a', 'b', 'c'])) is str
    assert type(choice(items=['a', 'b', 'c'], length=1)) is list
    assert type(choice(items='abc', length=2)) is str
    assert type(choice(items=('a', 'b', 'c'), length=5)) is tuple
    assert type(choice(items='aabbbccccddddd', length=4, unique=True)) is str

# Generated at 2022-06-25 20:35:50.001934
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_0 = None
    list_0 = [str_0, str_0]
    tuple_0 = (str_0, str_0)
    str_1 = None
    int_0 = 0

    # Call method __call__ of class Choice
    assert Choice().__call__(list_0) == str_0
    assert Choice().__call__(tuple_0) == str_0
    assert Choice().__call__(str_1) == str_0
    assert Choice().__call__(str_1, int_0) == str_0

# Generated at 2022-06-25 20:36:01.154555
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=Choice().__call__) == 'a'
    assert Choice().__call__(items=Choice().__call__) == 'a'
    assert Choice().__call__(items=Choice().__call__) == 'a'
    assert Choice().__call__(items=Choice().__call__) == 'a'
    assert Choice().__call__(items=Choice().__call__) == 'a'
    assert Choice().__call__(items=Choice().__call__) == 'a'
    assert Choice().__call__(items=Choice().__call__) == 'a'
    assert Choice().__call__(items=Choice().__call__) == 'a'
    assert Choice().__call__(items=Choice().__call__) == 'a'

# Generated at 2022-06-25 20:36:11.245471
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    set_0 = {'2WaD', ' t', 'Vz'}
    set_1 = {'!x', '+', '*h'}
    num_0 = -101
    str_0 = '5R'
    str_1 = 'UT'
    choice_0 = Choice()
    assert choice_0(set_0, length=3) == {'Vz', '2WaD', ' t'}
    assert choice_0(set_1, length=2, unique=True) == {'+', '!x'}

# Generated at 2022-06-25 20:36:13.552414
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert callable(Choice().__call__)