

# Generated at 2022-06-25 20:29:33.127044
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice_0(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice_0(items='abc', length=2) in ['ab', 'ac', 'ba', 'bc', 'ca', 'cb']

# Generated at 2022-06-25 20:29:41.692574
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    # Call Choice.__call__(items=['a', 'b', 'c'])
    try:
        assert_equal(['a', 'b', 'c'], choice_0.__call__(items=['a', 'b', 'c']))
    except Exception as e:
        print(e)

    # Call Choice.__call__(items=['a', 'b', 'c'], length=1)
    try:
        assert_equal([1], choice_0.__call__(items=['a', 'b', 'c'], length=1))
    except Exception as e:
        print(e)

    # Call Choice.__call__(items='abc', length=2)

# Generated at 2022-06-25 20:29:52.242846
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender
    from mimesis.providers.datetime import Datetime

    for _ in range(1000):
        result = Choice().__call__(items={Gender.FEMALE, Gender.MALE})
        assert isinstance(result, Gender)
        assert result in {Gender.FEMALE, Gender.MALE}

        result = Choice().__call__(items=(Datetime, Choice))
        assert isinstance(result, (Datetime, Choice))

        result = Choice().__call__(items=[1, 2, 3], length=0)
        assert isinstance(result, int)
        assert result in [1, 2, 3]

        result = Choice().__call__(items=[1, 2, 3], length=3)
        assert isinstance(result, list)

# Generated at 2022-06-25 20:30:03.566277
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0('', length=0) == ''
    assert choice_0((0, 1), length=1) == (0,)
    assert choice_0(['\t', '\t'], length=2, unique=True) == '\t\t'
    assert choice_0(['', '', '\r'], length=3) == ['', '', '\r']
    assert choice_0(('\t',), length=0) == '\t'
    assert choice_0((' ', '\n'), length=2) == ('\n', ' ')
    assert choice_0(('',), length=1, unique=True) == ('',)
    assert choice_0(('', '\n', '\t'), length=1) == ('',)
    assert choice_0

# Generated at 2022-06-25 20:30:07.465367
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    # check type
    assert isinstance(choice(items=items, length=length, unique=unique), str)


# Generated at 2022-06-25 20:30:10.045680
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(('a', 'b', 'c', 'd')) in ('a', 'b', 'c', 'd')

# Generated at 2022-06-25 20:30:13.523367
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    data = 'aabbbccccddddd'
    choice_1 = Choice()
    assert choice_1(items=data, length=4, unique=True) in data[:4]

# Generated at 2022-06-25 20:30:19.701965
# Unit test for method __call__ of class Choice
def test_Choice___call__():  # noqa
    choice = Choice()
    # Test case 1
    items = ['a', 'b', 'c']
    length = 0
    unique = False
    answer = choice(items=items, length=length, unique=unique)
    assert answer == 'c'
    # Test case 2
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    answer = choice(items=items, length=length, unique=unique)
    assert answer == ['a']
    # Test case 3
    items = 'abc'
    length = 2
    unique = False
    answer = choice(items=items, length=length, unique=unique)
    assert answer == 'ba'
    # Test case 4
    items = ('a', 'b', 'c')
    length = 5
    unique = False
   

# Generated at 2022-06-25 20:30:26.737366
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    number_0 = Choice.__call__(Choice, '[BTC, LTC, ETH]')
    number_1 = Choice.__call__(Choice, '[BTC, LTC, ETH]', 1, True)
    number_2 = Choice.__call__(Choice, 'abc', 2, True)
    number_3 = Choice.__call__(Choice, '(a, b, c)', 5, True)
    number_4 = Choice.__call__(Choice, 'aabbbccccddddd', 4, True)


# Generated at 2022-06-25 20:30:31.666019
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0(items=[1, 2, 3, 4, 5, 6, 7, 8, 9], length=5, unique=True) in [1, 2, 3, 4, 5, 6, 7, 8, 9]



# Generated at 2022-06-25 20:30:50.860120
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    it = ['a', 'b', 'c']
    choice = Choice()
    choice(items=it, length=0)
    assert type(choice(items=it, length=0)) == str
    choice(items=it, length=1)
    assert type(choice(items=it, length=1)) == list
    choice = Choice()
    choice(items=it, length=0)
    assert type(choice(items=it, length=0)) == str
    choice(items=it, length=1)
    assert type(choice(items=it, length=1)) == list
    choice = Choice()
    choice(items=it, length=0)
    assert type(choice(items=it, length=0)) == str
    choice(items=it, length=1)

# Generated at 2022-06-25 20:30:56.000229
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    choice_0.random.seed(7588)
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    assert (choice_0(items, length, unique) == 'a')


# Generated at 2022-06-25 20:31:08.764295
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items='abc', length=1) == 'a'
    assert Choice('en').__call__(items='abc', length=2) == 'ca'
    assert Choice('ru').__call__(items='abc', length=3) == 'abc'
    assert Choice('en').__call__(items='abc', length=4, unique=True) == 'cba'
    assert Choice('ru').__call__(items='abc', length=5, unique=True) == 'bcac'
    assert Choice('en').__call__(items=(1, 2, 3, 4), length=1) == (4,)
    assert Choice('ru').__call__(items=(1, 2, 3, 4), length=2) == (2, 3)

# Generated at 2022-06-25 20:31:18.289668
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0(items=['a', 'b', 'c']) == 'c'
    assert choice_0(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice_0(items='abc', length=2) == 'ba'
    assert choice_0(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice_0(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Unit test to test class Choice

# Generated at 2022-06-25 20:31:28.277139
# Unit test for method __call__ of class Choice

# Generated at 2022-06-25 20:31:39.225640
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    assert Choice().__call__(items=['a', 'b', 'c'], length=-1) == ['b']

# Generated at 2022-06-25 20:31:52.865551
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0(items=['a', 'b', 'c']) in ['a','b','c']
    assert choice_0(items=['a', 'b', 'c'], length=1) in [['a'],['b'],['c']]
    assert choice_0(items='abc', length=2) in ['ab','bc','ca']
    assert choice_0(items=('a', 'b', 'c'), length=5) in [('c', 'a', 'b', 'b', 'a'), ('a', 'b', 'c', 'c', 'b'), ('b', 'b', 'c', 'c', 'a')]
    assert choice_0(items='aabbbccccddddd', length=4, unique=True) in ['cdba', 'dcba']

# Generated at 2022-06-25 20:31:57.527048
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Parameters:
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    # Expected results:
    expected_items_ = ['a']
    # Returned results
    returned_items_ = Choice().__call__(items=items, length=length, unique=unique)
    # Assertions
    # Assert type.
    assert isinstance(returned_items_, list)
    # Assert answer 1.
    assert returned_items_ == expected_items_


# Generated at 2022-06-25 20:32:07.816678
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0(items=['a', 'b', 'c'], length=0, unique=False) == choice_0(items=['a', 'b', 'c'],)
    assert choice_0(items='abc', length=5, unique=False) == 'cabca'
    assert choice_0(items=('a', 'b', 'c'), length=5, unique=False) == ('c', 'a', 'a', 'b', 'c')
    assert choice_0(items='aabbbccccddddd', length=0, unique=False) == choice_0(items='aabbbccccddddd')

# Generated at 2022-06-25 20:32:11.338176
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    data_0 = choice_0(items=['a', 'b', 'c'], length=0)
    assert data_0 == 'c'


# Generated at 2022-06-25 20:32:28.598281
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0(items=['a', 'b', 'c']) == 'c'
    assert choice_0(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice_0(items='abc', length=2) == 'ba'
    assert choice_0(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice_0(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    with raises(TypeError):
        choice_0(items=None, length=1)
        choice_0(items=[], length=1)

# Generated at 2022-06-25 20:32:37.874204
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0(items=['a', 'b', 'c']) == 'c'
    assert choice_0(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice_0(items='abc', length=2) == 'ba'
    assert choice_0(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice_0(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-25 20:32:49.201399
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    global choice_0
    # Test of __call__ for Choice
    # Test for Choice.__call__(items = ['a', 'b', 'c'], length = 0, unique = False)
    assert choice_0(items = ['a', 'b', 'c'], length = 0, unique = False) == 'b'
    # Test for Choice.__call__(items = ['a', 'b', 'c'], length = 1, unique = False)
    assert choice_0(items = ['a', 'b', 'c'], length = 1, unique = False) == ['b']
    # Test for Choice.__call__(items = 'abc', length = 2, unique = False)
    assert choice_0(items = 'abc', length = 2, unique = False) == 'ab'
    # Test for Choice.__call__(items

# Generated at 2022-06-25 20:33:01.405776
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    number = choice_0(items=['a', 'b', 'c'])
    assert (number in ['a', 'b', 'c'])
    assert (isinstance(number, str) or isinstance(number, str))
    assert (len(['a', 'b', 'c']) >= 1)

    number = choice_0(items=['a', 'b', 'c'], length=-1)
    assert (number in ['a', 'b', 'c'])
    assert (isinstance(number, str) or isinstance(number, str))
    assert (len(['a', 'b', 'c']) >= 1)

    number = choice_0(items=['a', 'b', 'c'], length=1)

# Generated at 2022-06-25 20:33:06.008386
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    choice_0 = Choice()
    choice_1 = Choice()
    assert choice_0(items=['a', 'b', 'c']) == 'c'
    assert choice_1(items=['a', 'b', 'c'], length=1) == ['a']


# Generated at 2022-06-25 20:33:09.567959
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 0
    unique = False
    choice_1 = Choice()
    value = choice_1(items=items, length=length, unique=unique)
    expected = 'c'
    assert value == expected


# Generated at 2022-06-25 20:33:14.879708
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice()._Choice__call__(items=['a', 'b', 'c']) == 'c'


# Generated at 2022-06-25 20:33:21.143026
# Unit test for method __call__ of class Choice

# Generated at 2022-06-25 20:33:29.457823
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    items_0 = [0, 1, 2]
    length_0 = 0
    unique_0 = False
    result = choice_0(items=items_0, length=length_0, unique=unique_0)
    assert result in items_0

    items_1 = (0, 1, 2)

    result_1 = choice_0(items=items_1, length=length_0, unique=unique_0)
    assert result_1 in items_1

    items_2 = '012'

    result_2 = choice_0(items=items_2, length=length_0, unique=unique_0)
    assert result_2 in items_2

    items_3 = [0, 1, 2]


# Generated at 2022-06-25 20:33:34.158774
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    choice_1 = Choice()
    choice_2 = Choice()
    assert choice_0(length=0, items='3f4c3c03855') == '3'
    assert choice_1(length=0, items=['1', '2', '', '1', '2']) == '2'
    assert choice_2(length=0, items=('e', '8', '', 'f')) == 'e'



# Generated at 2022-06-25 20:33:49.274667
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from string import ascii_letters
    from random import seed
    from random import randint

    seed(1)
    c_0_0 = Choice()
    p_0_0 = c_0_0(items=ascii_letters)
    assert type(p_0_0) is str
    assert p_0_0 == 'K'
    seed(1)
    c_0_1 = Choice()
    p_0_1 = c_0_1(items=ascii_letters, length=8)
    assert type(p_0_1) is str
    assert p_0_1 == 'KfjyDxnP'
    seed(1)
    c_0_2 = Choice()

# Generated at 2022-06-25 20:33:52.105746
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0(items=None) == None


# Generated at 2022-06-25 20:34:00.788272
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    choices_1 = choice_0('string', 1, True)
    choices_1 = choice_0('string', 1, False)
    choices_2 = choice_0('string', 2, True)
    choices_2 = choice_0('string', 2, False)
    choices_3 = choice_0('string', 3, True)
    choices_3 = choice_0('string', 3, False)
    choices_4 = choice_0('string', 4, True)
    choices_4 = choice_0('string', 4, False)
    choices_5 = choice_0('string', 5, True)
    choices_5 = choice_0('string', 5, False)
    choices_6 = choice_0('string', 6, True)
    choices_6 = choice_0('string', 6, False)

# Generated at 2022-06-25 20:34:04.279574
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    # Call Choice.__call__()
    result = choice(items=['a', 'b', 'c'])

    assert result == 'c'


# Generated at 2022-06-25 20:34:16.069521
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()

    assert choice_0(items=[1, 2, 3], length=0, unique=False) == 3
    assert choice_0(items=[1, 2, 3], length=1, unique=False) == [1]
    assert choice_0(items=['a', 'b', 'c'], length=1, unique=False) == ['a']
    assert choice_0(items=['a', 'b', 'c'], length=2, unique=False) == 'ab'
    assert choice_0(items=('a', 'b', 'c'), length=3, unique=False) == ('c', 'b', 'a')
    assert choice_0(items=['a', 'b', 'c'], length=4, unique=True) == 'bca'

# Generated at 2022-06-25 20:34:18.024830
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass  # TODO


# Generated at 2022-06-25 20:34:23.594573
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) == 'b'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-25 20:34:30.126179
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    assert choice('123') in ['1', '2', '3']
    assert choice('234', length=2) in ['23', '32', '42']
    assert choice('aBc', length=2) in ['aB', 'Bc', 'ac']
    assert choice(['x'], length=2) in [['x', 'x']]
    assert choice(tuple('xx'), length=2) in [('x', 'x')]
    assert choice('xxxx', length=4, unique=True) in ['x', 'x']
    assert choice(('x', 'y', 'z'), length=2) in [('x', 'x'), ('y', 'y'), ('z', 'z')]

# Generated at 2022-06-25 20:34:39.213986
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    choice = Choice()
    result = choice(items=['a', 'b', 'c'])
    assert isinstance(result, str)
    result = choice(items=['a', 'b', 'c'], length=1)
    assert isinstance(result, list)
    result = choice(items='abc', length=2)
    assert isinstance(result, str)
    result = choice(items=('a', 'b', 'c'), length=5)
    assert isinstance(result, tuple)
    result = choice(items='aabbbccccddddd', length=4, unique=True)
    assert isinstance(result, str)

# Generated at 2022-06-25 20:34:45.113981
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0.__call__(['a', 'b', 'c']) == 'c'
    assert choice_0.__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice_0.__call__(items='abc', length=2) == 'ba'
    assert choice_0.__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice_0.__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-25 20:35:42.264230
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice(seed=13293)
    items_0 = ['a', 'b', 'c']
    length_0 = 1
    unique_0 = False
    result_0 = choice_0(items=items_0, length=length_0, unique=unique_0)
    assert isinstance(result_0, list) and len(result_0) == 1 and result_0 == ['a']
    choice_1 = Choice(seed=6819)
    items_1 = ['a', 'b', 'c']
    length_1 = 1
    unique_1 = True
    result_1 = choice_1(items=items_1, length=length_1, unique=unique_1)
    assert result_1 == 'c'
    choice_2 = Choice(seed=81218)

# Generated at 2022-06-25 20:35:52.713657
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice()(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert Choice()(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert Choice()(items='abc', length=2) in ['ab', 'bc', 'ac']
    assert Choice()(items=('a', 'b', 'c'), length=5) in [
        ('a', 'c', 'a', 'b', 'c'),
        ('b', 'b', 'a', 'c', 'a'),
        ('a', 'a', 'c', 'b', 'c'),
        ('b', 'c', 'c', 'b', 'a'),
        ('b', 'a', 'c', 'a', 'c'),
    ]


# Generated at 2022-06-25 20:36:02.415661
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choices_1 = Choice()
    choices_1(items=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20])
    choices_1(items=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20], length=4)
    choices_1(items=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20], length=3, unique=True)

# Generated at 2022-06-25 20:36:03.674611
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TODO
    pass



# Generated at 2022-06-25 20:36:10.991060
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'



# Generated at 2022-06-25 20:36:18.312611
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()



# Generated at 2022-06-25 20:36:22.107447
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0(items=['a', 'b', 'c']) == 'c'
    assert choice_0(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice_0(items='abc', length=2) == 'ba'
    assert choice_0(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice_0(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-25 20:36:31.983842
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(['a', 'b', 'c']) == 'c'
    assert Choice().__call__(['a', 'b', 'c'], 1) == ['a']
    assert Choice().__call__('abc', 2) == 'ba'
    assert Choice().__call__(('a', 'b', 'c'), 5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__('aabbbccccddddd', 4, True) == 'cdba'
    assert Choice().__call__(()) == []
    assert Choice().__call__([]) == []

# Generated at 2022-06-25 20:36:35.546179
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0(["a", "b", "c"]) == "c"


# Generated at 2022-06-25 20:36:44.395354
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    x = Choice()
    y = x(items=['a', 'b', 'c'], length=1)

    assert isinstance(y, list)
    assert y == ['a']

    y = x(items=['a', 'b', 'c'])

    assert isinstance(y, str)
    assert y in ['a', 'b', 'c']

    y = x(items='abc', length=2)

    assert isinstance(y, str)
    assert y in ['ab', 'bc', 'ac']

    y = x(items=('a', 'b', 'c'), length=5)

    assert isinstance(y, tuple)
    assert len(y) == 5
    assert all(el in ['a', 'b', 'c'] for el in y)


# Generated at 2022-06-25 20:37:53.118988
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    returned = choice(items=["a", "b", "c"])
    assert isinstance(returned, str)
    returned_1 = choice(items=["a", "b", "c"], length=1)
    assert isinstance(returned_1, list)
    returned_2 = choice(items="abc", length=2)
    assert isinstance(returned_2, str)
    returned_3 = choice(items=("a", "b", "c"), length=5)
    assert isinstance(returned_3, tuple)
    returned_4 = choice(items="aabbbccccddddd", length=4, unique=True)
    assert isinstance(returned_4, str)

# Generated at 2022-06-25 20:37:56.299539
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    item_0 = choice_0(items='abc', length=5)
    assert isinstance(item_0, str)
    assert item_0 == 'cbaba'
    item_1 = choice_0(items='abc', length=1)
    assert isinstance(item_1, str)
    assert item_1 == 'c'

# Generated at 2022-06-25 20:37:58.504830
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(['a', 'b', 'c'], 1) in [['a'], ['b'], ['c']]

# Generated at 2022-06-25 20:38:06.595963
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(['a', 'b', 'c']) == 'c'
    assert choice(['a', 'b', 'c'], 1) == ['a']
    assert choice('abc', 2) == 'ba'
    assert choice(('a', 'b', 'c'), 5) == ('c', 'a', 'a', 'b', 'c')
    assert choice('aabbbccccddddd', 4, True) == 'cdba'
    with pytest.raises(TypeError):
        choice(1.23)
    with pytest.raises(TypeError):
        choice(['a', 'b', 'c'], 1.5)
    with pytest.raises(ValueError):
        choice([], 1)

# Generated at 2022-06-25 20:38:13.171295
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    items_0 = ['a', 'b', 'c']
    choice___call___return_value_0 = choice_0(items=items_0)
    expected_result_0 = 'a'
    assert choice___call___return_value_0 == expected_result_0
    choice_1 = Choice()
    items_1 = ['a', 'b', 'c']
    choice___call___return_value_1 = choice_1(items=items_1, length=1)
    expected_result_1 = ['b']
    assert choice___call___return_value_1 == expected_result_1
    choice_2 = Choice()
    items_2 = 'abc'
    choice___call___return_value_2 = choice_2(items=items_2, length=2)

# Generated at 2022-06-25 20:38:15.096798
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Get a random item from a sequence."""
    for _ in range(20):
        # TODO: Type cast
        assert isinstance(Choice()(items=(1, 2, 3)), int)

# Generated at 2022-06-25 20:38:17.399739
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ('a', 'b', 'c', 'd', 'e')
    choice_0 = Choice()
    result = choice_0(items=items, length=5, unique=False)
    assert isinstance(result, tuple) and set(result) == set(items)


# Generated at 2022-06-25 20:38:22.771146
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    pattern_1 = choice_0(items=(), length=0)
    pattern_2 = choice_0(items=('',), length=0)
    pattern_3 = choice_0(items=(), length=0)
    pattern_4 = choice_0(items=('',), length=0)
    pattern_5 = choice_0(items=(), length=0)
    pattern_6 = choice_0(items=('',), length=0)
    pattern_7 = choice_0(items=(), length=0)
    pattern_8 = choice_0(items=('',), length=0)
    pattern_9 = choice_0(items=(), length=0)
    pattern_10 = choice_0(items=('',), length=0)

# Generated at 2022-06-25 20:38:27.739318
# Unit test for method __call__ of class Choice
def test_Choice___call__(): 

    choice_0 = Choice()
    # Test for method __call__ of class Choice
    assert choice_0(items=['a', 'b', 'c']) in ('a', 'b', 'c')  # __doc__
    assert choice_0(items=['a', 'b', 'c'], length=1) in (['a'], )  # __doc__
    assert choice_0(items='abc', length=2) in ('ba', )  # __doc__
    assert choice_0(items=('a', 'b', 'c'), length=5) in (('c', 'a', 'a', 'b', 'c'), )  # __doc__
    assert choice_0(items='aabbbccccddddd', length=4, unique=True) in ('cdba', )  # __doc__

# Generated at 2022-06-25 20:38:36.891631
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    items_0 = ['a', 'b', 'c']
    assert choice_0(items_0) == 'c'
    length_0 = 1
    assert choice_0(items_0, length_0) == ['a']
    items_1 = 'abc'
    length_1 = 2
    assert choice_0(items_1, length_1) == 'ba'
    items_2 = ('a', 'b', 'c')
    length_2 = 5
    assert choice_0(items_2, length_2) == ('c', 'a', 'a', 'b', 'c')
    items_3 = 'aabbbccccddddd'
    length_3 = 4
    unique_0 = True