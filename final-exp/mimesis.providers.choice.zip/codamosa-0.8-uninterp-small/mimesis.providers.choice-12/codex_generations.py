

# Generated at 2022-06-25 20:29:13.224349
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice('en')
    length_1 = 3
    items_1_0 = ['a', 'b', 'c']
    value_1_0 = ['c', 'a', 'a']


# Generated at 2022-06-25 20:29:16.612118
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from random import randint

    from .code_blocks.choice import *
    int_0 = randint(1, (2147483647 * 2) + 1)
    str_0 = choice_0(items=choice_1, length=int_0, unique=choice_2)
    str_1 = choice_3(items=choice_4, length=int_0)


# Generated at 2022-06-25 20:29:26.055510
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items_0 = 'ykmhciuagCm'
    length_0 = 48
    result_1 = Choice()(items=items_0, length=length_0)
    result_2 = Choice()(items='adGPDfDQ', length=65, unique=True)
    assert result_1 == result_2
    assert result_1 == 'gfhacCgGmCQQmCgGQyDGgfahPQyPDgfafafPQyDQQQGmfhfafDPDPD'
    assert result_2 == 'gfhacCgGmCQQmCgGQyDGgfahPQyPDgfafafPQyDQQQGmfhfafDPDPD'


# Generated at 2022-06-25 20:29:28.348320
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    choice_0.__call__(items=['a', 'b', 'c'], length=4)

# Generated at 2022-06-25 20:29:30.457651
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    global choice_0
    assert choice_0('', 10) == ''
    assert choice_0('', 10) == ''


# Generated at 2022-06-25 20:29:39.961857
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert('[a, b, c]' in str(Choice().__call__(items=['a', 'b', 'c'], length=3))), "find failed."
    assert('f' not in str(Choice().__call__(items=['a', 'b', 'c'], length=3))), "find failed."
    # TODO: Fix return type
    assert(Choice().__call__(items=['a', 'b', 'c'], length=3) == ['a', 'b', 'c'])
    assert(Choice().__call__(items=['a', 'b', 'c'], length=3) != ['a', 'b', 'f']), "find failed."

# Generated at 2022-06-25 20:29:51.084085
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    # Test for method __call__ in class Choice
    choice_0.random.choice = lambda l: 'abc'
    print(choice_0(items = ['a', 'b', 'c']))
    assert choice_0(items = ['a', 'b', 'c']) == 'c'
    print(choice_0(items = ['a', 'b', 'c'], length = 1))
    assert choice_0(items = ['a', 'b', 'c'], length = 1) == ['a']
    print(choice_0(items = 'abc', length = 2))
    assert choice_0(items = 'abc', length = 2) == 'ba'
    print(choice_0(items = ('a', 'b', 'c'), length = 5))

# Generated at 2022-06-25 20:30:03.449419
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    int_0 = 9999
    choice_0 = Choice()

# Generated at 2022-06-25 20:30:15.112627
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    data_0_0 = 'bc'
    data_0_1 = ('c',)
    data_0_2 = ('a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i')
    data_0_3 = 8

    int_0 = 5
    choice_0 = Choice()
    result_0 = choice_0(data_0_1, int_0)
    assert result_0 == data_0_2

    #  Test that the method will raise a value error if the sequence argument contains unique elements and the number
    #  argument is greater than the number of unique elements in the sequence argument
    #  TODO: Add check that the sequence argument contains unique elements
    data_0_4 = "abc"
    tuple_0 = (2,)

# Generated at 2022-06-25 20:30:24.922279
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    num_0 = test_Choice___call__.num_0
    assert not isinstance(num_0, int)
    assert not isinstance(num_0, str)
    assert not isinstance(num_0, float)
    assert not isinstance(num_0, list)
    assert not isinstance(num_0, tuple)
    assert not isinstance(num_0, dict)
    assert not isinstance(num_0, set)
    assert not isinstance(num_0, bytes)
    assert not isinstance(num_0, bytearray)
    assert not isinstance(num_0, memoryview)



# Generated at 2022-06-25 20:30:38.122947
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    seq_1 = [Choice() for _ in range(9999)]
    for i in range(9999):
        seq_1[i]((1, 2), False)
    for i in range(9999):
        seq_1[i]([1], False)
    for i in range(9999):
        seq_1[i]([1], False)
    for i in range(9999):
        seq_1[i](['a'], False)
    for i in range(9999):
        seq_1[i]([object()], False)
    for i in range(9999):
        seq_1[i]([1], True)
    for i in range(9999):
        seq_1[i]([1], True)
    for i in range(9999):
        seq_1[i](['a'], True)

# Generated at 2022-06-25 20:30:40.700483
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    int_0 = 9999
    choice_0.seed(int_0)

# Generated at 2022-06-25 20:30:45.673022
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    list_0 = ['a','b','c']
    list_1 = choice_0(items=list_0,length=5,unique=False)
    print(list_1)



# Generated at 2022-06-25 20:30:58.345619
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Init
    choice_0 = Choice()
    with raises(TypeError):
        choice_0.__call__(items='', length='', unique='')

    with raises(ValueError):
        choice_0.__call__(items='', length=0, unique=False)

    # We should always return list
    """
    assert choice_0.__call__(items=['', ''], length=0, unique=False) == ['a', 'a']
    assert choice_0.__call__(items='', length=0, unique=False) == ''
    assert choice_0.__call__(items=['', ''], length=2, unique=False) == ['b', 'b']
    assert choice_0.__call__(items=(), length=0, unique=False) == ()
    """
    assert choice_

# Generated at 2022-06-25 20:31:09.622724
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice()(['a', 'b', 'c']) == 'c'
    assert Choice()(['a', 'b', 'c'], 1) == ['a']
    assert Choice()('abc', 2) == 'ba'
    assert Choice()(('a', 'b', 'c'), 5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice()('aabbbccccddddd', 4, True) == 'cdba'
    assert Choice()(('a', 'b', 'c'), 1, True) == ('c',)
    assert Choice()(['a', 'b', 'c', 'd'], 5, True) == ['a', 'b', 'c', 'd']

# Generated at 2022-06-25 20:31:11.223215
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-25 20:31:19.532215
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    sequence_0 = ['O', '', 'A', 'Y', 'Q', '', '', 'K', 'Z', '', 'D', '']
    positive_int_0 = 1
    for i in range(33):
        int_0 = 999999
        choice_0 = Choice()
        choice_1 = choice_0(sequence_0, positive_int_0)
        assert choice_1 in sequence_0
        sequence_1 = ['Y', 'C', 'K', '', '', '', 'A', 'I', 'A', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'Z', 'K', '', '', '', '', '', 'H']
        choice_2 = Choice()

# Generated at 2022-06-25 20:31:27.913746
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TODO: We should not use single line comments in the code, we should
    #  delete it, or use reStructuredText.
    str_0 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
    str_1 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
    str_2 = ""
    str_3 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
    str_4 = ""

# Generated at 2022-06-25 20:31:33.269436
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    result_0 = choice_0(None)
    assert result_0 == "b"

if __name__ == '__main__':
    test_case_0()
    test_Choice___call__()

# Generated at 2022-06-25 20:31:40.942662
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    int_0 = 9999
    choice_0 = Choice()
    choice_0_items_0 = ['a', 'b', 'c']
    choice_0_length_0 = 0
    choice_0_unique_0 = True
    choice_0_res_0 = choice_0(items=choice_0_items_0, length=choice_0_length_0, \
        unique=choice_0_unique_0)

    choice_0_items_1 = ['a', 'b', 'c']
    choice_0_length_1 = 1
    choice_0_unique_1 = False
    choice_0_res_1 = choice_0(items=choice_0_items_1, length=choice_0_length_1, \
        unique=choice_0_unique_1)

    choice_0_items_

# Generated at 2022-06-25 20:31:53.258758
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    int_0 = 9999
    choice_0 = Choice()
    list_0 = ['a', 'b', 'c']
    str_0 = choice_0(items=list_0)
    list_1 = [str_0]
    str_1 = choice_0(items=list_0, length=1)
    str_2 = choice_0(items='abc', length=2)
    tuple_0 = ('c', 'a', 'a', 'b', 'c')
    tuple_1 = choice_0(items=('a', 'b', 'c'), length=5)
    str_3 = choice_0(items='aabbbccccddddd', length=4, unique=True)
    assert str_0 == 'c'
    assert str_1 == list_1

# Generated at 2022-06-25 20:31:56.247167
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    int_0 = 9999
    choice_0 = Choice()
    args_0 = ['a', 'b', 'c']
    kwargs_0 = {'length': 1}
    result = choice_0(items=args_0, **kwargs_0)
    assert result == ['a']


# Generated at 2022-06-25 20:32:01.241772
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    choice_0 = Choice()
    # check if the return type of method '__call__' of class 'Choice'
    # is of type 'str'
    assert isinstance(choice_0('abc', 1), str) == True


# Generated at 2022-06-25 20:32:01.982161
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert True


# Generated at 2022-06-25 20:32:03.366087
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass


# Generated at 2022-06-25 20:32:09.711040
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    choice_0 = Choice()
    # Test for exceptions
    # The following raises TypeError, so the test is successful
    with pytest.raises(TypeError) as exception_0:
        choice_0.choice(999, 1)
    # The following raises ValueError, so the test is successful
    with pytest.raises(ValueError) as exception_0:
        choice_0.choice(999, 1)
    # The following raises TypeError, so the test is successful
    with pytest.raises(TypeError) as exception_0:
        choice_0.choice('', 1)
    # The following raises ValueError, so the test is successful
    with pytest.raises(ValueError) as exception_0:
        choice_0.choice('', -1)
    # Test for return type

# Generated at 2022-06-25 20:32:17.838758
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=[1, 2, 3], length=1, unique=True) == [3]
    assert choice(items='ab', length=1, unique=False) == 'b'
    assert choice(items=('a', 'b', 'c', 'd', 'e'), length=1, unique=True) == 'c'
    assert choice(items=[1, 2, 3], length=1, unique=False) == [2]
    assert choice(items='abc', length=1, unique=True) == 'a'
    assert choice(items=(1, 2, 3, 4, 5, 6), length=1, unique=False) == 3
    assert choice(items=[1, 2, 3], length=1, unique=True) == [3]

# Generated at 2022-06-25 20:32:28.932188
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    int_0 = 1073741823
    choice_0 = Choice()
    list_0 = []
    for _ in range(0, int_0):
        list_0.append(choice_0())

    # Check the uniqueness of the output.
    list_1 = []
    for _ in range(0, int_0):
        list_1.append(choice_0())
    assert list_0 == list_1

    # Check the uniqueness of the output.
    list_1 = []
    for _ in range(0, int_0):
        list_1.append(choice_0())
    assert list_0 == list_1

    bool_0 = False
    set_1 = set(list_0)
    assert bool_0 == (len(set_1) < int_0)


# Generated at 2022-06-25 20:32:39.768206
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert True == Choice().__call__((4,) * 5, 1)
    assert True == Choice().__call__([42, 86, 49, 38, 82, 93], 1)
    assert True == Choice().__call__((4,) * 5, 1)
    assert True == Choice().__call__((4,) * 5, 1)
    assert True == Choice().__call__([42, 86, 49, 38, 82, 93], 1)
    assert True == Choice().__call__((4,) * 5, 1)
    assert True == Choice().__call__((4,) * 5, 1)
    assert True == Choice().__call__([42, 86, 49, 38, 82, 93], 1)
    assert True == Choice().__call__((4,) * 5, 1)

# Generated at 2022-06-25 20:32:47.946395
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    sequence_0 = choice_0(items=(1, 4, 2, 3), length=4, unique=False)
    sequence_1 = choice_0(items=(1, 4, 2, 3), length=4, unique=True)

    if __name__ == '__main__':
        print(sequence_0)
        print(sequence_1)


if __name__ == '__main__':
    test_case_0()
    test_Choice___call__()
    print("Everything passed")

# Generated at 2022-06-25 20:33:01.193098
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items_1 = [1, 2, 3]
    length_1 = 0
    unique_1 = True
    output_1 = Choice().__call__(items=items_1, length=length_1,
                                 unique=unique_1)
    # Results may differ from run to run.
    assert True


# Generated at 2022-06-25 20:33:08.543661
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    int_0 = 9999
    choice_0 = Choice()
    choice_0.__call__(None, 2, False)
    choice_0.__call__(None, 2, True)
    choice_0.__call__([], 2, False)
    choice_0.__call__([], 2, True)
    choice_0.__call__([int_0], 2, False)
    choice_0.__call__([int_0], 2, True)

# Generated at 2022-06-25 20:33:14.879842
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    test_0 = Choice()
    test_1 = Choice()
    test_2 = Choice()
    test_3 = Choice()
    test_4 = Choice()
    test_5 = Choice()
    test_6 = Choice()
    test_7 = Choice()
    test_8 = Choice()
    test_9 = Choice()
    test_10 = Choice()
    test_11 = Choice()
    test_12 = Choice()
    test_13 = Choice()
    test_14 = Choice()
    test_15 = Choice()
    test_16 = Choice()
    test_17 = Choice()
    test_18 = Choice()
    test_19 = Choice()
    test_20 = Choice()
    test_21 = Choice()
    test_22 = Choice()
    test_23 = Choice()
    test_24 = Choice()

# Generated at 2022-06-25 20:33:19.784811
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    int_0 = 9999
    choice_0 = Choice(int_0)
    items_0 = list()
    length_0 = 0
    unique_0 = True
    ret_0 = choice_0(items_0, length_0, unique_0)

    assert ret_0 == []
    assert True




# Generated at 2022-06-25 20:33:23.587389
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    items = ('abc',)
    length = 1
    choice_0___call__ = choice_0.__call__(items, length)
    items = ('abc',)
    length = 1
    unique = True
    choice_0___call__ = choice_0.__call__(items, length, unique)
    items = ('abc',)
    length = 2
    choice_0___call__ = choice_0.__call__(items, length)
    items = ('abc',)
    length = 2
    unique = True
    choice_0___call__ = choice_0.__call__(items, length, unique)

# Generated at 2022-06-25 20:33:24.981504
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__() is not None


# Generated at 2022-06-25 20:33:29.650459
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    int_0 = 9999
    # TODO: Replace 'assert' statement with a unit test (get_list)
    assert int_0 == 9999


# Generated at 2022-06-25 20:33:34.306167
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = 'mRbXfv'
    expected = 'f'
    choice_0 = Choice()
    p = choice_0(items=items)
    assert expected == p


# Generated at 2022-06-25 20:33:37.282569
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    int_0 = 9999
    choice_0 = Choice(int_0)
    sequence_0 = ('h', 'P', 'Y', 'q')
    int_1 = 2
    bool_0 = True
    assert choice_0(sequence_0, int_1, bool_0) == 'P'

# Generated at 2022-06-25 20:33:40.787066
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    with raises(ValueError):
        choice_0 = Choice()
        choice_0(items=[], length=22, unique=False)


# Generated at 2022-06-25 20:34:06.950219
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.providers.generic import Generic
    from mimesis.providers.datetime import Datetime
    from mimesis.types import Address, DatetimeFormat
    f = Generic()
    d = Datetime()
    l = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    sl = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    l.remove(sl[0])
    sl.remove(sl[0])
    l.remove(sl[1])
    sl.remove(sl[1])
    l.remove(sl[2])
    sl.remove(sl[2])
    l.remove(sl[3])
    sl.remove(sl[3])
    l.remove(sl[4])
    sl.remove

# Generated at 2022-06-25 20:34:10.627666
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert choice_0.__call__() == ('a', 'b', 'b', 'a')

# Generated at 2022-06-25 20:34:17.995302
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items_0 = ['a', 'b', 'c']
    length_0 = 0
    unique_0 = False
    return_value_1 = Choice.__call__(items=items_0, length=length_0, unique=unique_0)
    items_1 = 'abc'
    length_1 = 2
    unique_1 = False
    return_value_2 = Choice.__call__(items=items_1, length=length_1, unique=unique_1)
    items_2 = ['a', 'b', 'c']
    length_2 = 1
    unique_2 = False
    return_value_3 = Choice.__call__(items=items_2, length=length_2, unique=unique_2)
    items_3 = ('a', 'b', 'c')
    length_3 = 5


# Generated at 2022-06-25 20:34:18.905797
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert True

# Generated at 2022-06-25 20:34:28.566575
# Unit test for method __call__ of class Choice

# Generated at 2022-06-25 20:34:38.473464
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    for _ in range(10):
        tt = Choice()
        tt_1 = (tt('abcd',2, False))
        tt_2 = (tt(('a', 'b', 'c', 'd'), 2, False))
        tt_3 = (tt(['a', 'b', 'c', 'd'], 2, False))
        tt_4 = (tt('abcdef', 0, False))
        tt_5 = (tt(('a', 'b', 'c', 'd', 'e', 'f'), 0, False))
        tt_6 = (tt(['a', 'b', 'c', 'd', 'e', 'f'], 0, False))
        tt_7 = (tt('abcdef', 3, True))

# Generated at 2022-06-25 20:34:44.750970
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    # Define a few commonly used variables
    seed = 9999
    int_0 = 9999
    str_0 = "3q_vV0W!a?s0=$I"

    # Call the Choice class constructor
    obj_0 = Choice()

    # Call the Choice class constructor with positional arguments
    obj_1 = Choice(str_0, str_0)

    # TODO: Test the exceptions raised by the Choice class constructor
    # TODO: Test the exceptions raised by the Choice class constructor with positional arguments

    # Call the Choice class __call__ method with positional arguments
    str_1 = obj_1(str_0, int_0)

    # TODO: Test the exceptions raised by the Choice class __call__ method with positional arguments

# Generated at 2022-06-25 20:34:53.721555
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from random import choice

    items = ['a', 'b', 'c']
    length = 2
    length_1 = 1
    length_2 = 0
    unique = True
    length_3 = 3
    length_4 = 4

    items_1 = ('a', 'b', 'c')
    items_2 = 'abc'
    length_5 = 5
    items_3 = 'aabbbccccddddd'
    length_6 = 10000

    # Test for TypeError when __call__() is called with wrong type
    # Test for ValueError when __call__() is called with negative number
    # Test for ValueError when __call__() is called with insufficient unique elements
    # Test if the random choice is equal to the value in items
    # Test if the random choice is equal to one of the values in the sequence items
    #

# Generated at 2022-06-25 20:35:05.695047
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    int_0 = 9999
    choice_0 = Choice()
    # Number of times to repeat **items** when **length** is specified
    # and is greater than the length of **items**.
    # length: Length of sequence (number of elements) to provide.
    str_0 = choice_0(length=0, items='abcdefghijklmnopqrstuvwxyz', unique=False)
    assert str_0 in ['b', 'a', 'e', 'm', 'd', 'l', 'p', 'x', 'j', 'o', 'y', 'z', 'i', 'n', 'r', 'v', 'w', 'c', 'h', 'g', 'k', 's', 'f', 'q', 'u', 't']

# Generated at 2022-06-25 20:35:16.712434
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_0 = 'e'
    str_1 = 'b'
    str_2 = 'c'
    str_3 = 'd'
    str_4 = 'a'
    list_0 = ['me', 'b', 'c', 'd', 'a']
    list_1 = ['e', 'b', 'c', 'd', 'a']
    list_2 = ['e', 'b', 'c', 'd', 'a']
    list_3 = ['e', 'b', 'c', 'd', 'a']
    list_4 = ['e', 'b', 'c', 'd', 'a']
    list_5 = ['e', 'b', 'c', 'd', 'a']
    str_5 = 'eaaabdca'

# Generated at 2022-06-25 20:35:51.899979
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice.

    Arguments:
    _ = {not used}

    Returns:
    Return type: None

    Raises:
    Exception: 
    """

    _ = {not used}
    choice = Choice()

    # Implicitly tests unique by not populating the return list to length
    choice.__call__(items=['a', 'b', 'c'])
    choice.__call__(items=['a', 'b', 'c'], length=1)
    choice.__call__(items='abc', length=2)
    choice.__call__(items=('a', 'b', 'c'), length=5)
    choice.__call__(items='aabbbccccddddd', length=4, unique=True)


test_case_0()


# Generated at 2022-06-25 20:35:54.151453
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    int_0 = 9999
    choice_0 = Choice()


# Generated at 2022-06-25 20:35:55.450394
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert False


# Generated at 2022-06-25 20:36:00.827961
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    list_0 = ['b', None, None, 'a', 'c', None]
    int_0 = 1
    bool_0 = True
    var_0 = choice_0(list_0, int_0, bool_0)
    assert (var_0 == 'b')

if __name__ == '__main__':
    test_case_0()
    test_Choice___call__()
    print('.')

# Generated at 2022-06-25 20:36:02.193959
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    test_case_0()

# Generated at 2022-06-25 20:36:07.693600
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    length_0 = choice_0.__call__(tuple((choice_0.random.randint(0, 9999) for _ in range(10)))).__len__()  # type: ignore
    assert length_0 != 0


# Generated at 2022-06-25 20:36:14.240889
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    int_0 = 9999
    choice_0 = Choice()
    int_1 = 1
    list_0 = ['a', 'b', 'c']
    #
    # Test for a single choice from the list.
    #
    str_0 = choice_0(items=list_0)
    #
    # Test for a list of choices at the specified length.
    #
    list_1 = choice_0(items=list_0, length=int_1)
    #
    # Test for a list of choices at the specified length, with no duplicates.
    #
    list_2 = choice_0(items=['a', 'a', 'b', 'c', 'c'], length=int_0, unique=True)
    #
    # Test for a string of choices at the specified length, with no duplicates.


# Generated at 2022-06-25 20:36:22.123005
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items_0 = ['a', 'b', 'c']
    length_0 = 1
    unique_0 = True
    choice_0 = Choice()
    choice_1 = Choice()

    choice_2 = Choice()

    str_0 = choice_1(items_0)
    print("str_0:", str_0)
    assert str_0 == 'b'
    str_1 = choice_2(items=items_0, length=length_0)
    print("str_1:", str_1)
    assert str_1 == ['a']
    str_2 = choice_0(items='abc', length=2)
    print("str_2:", str_2)
    assert str_2 == 'ba'

# Generated at 2022-06-25 20:36:26.789815
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items_0 = ('a', 'b', 'c')
    unique_0 = False
    length_0 = 0
    choice_0 = Choice()
    assert choice_0(items=items_0, length=length_0, unique=unique_0) in \
           ('a', 'b', 'c')
    items_1 = ('a', 'b', 'c')
    unique_1 = True
    length_1 = 0
    choice_1 = Choice()
    assert choice_1(items=items_1, length=length_1, unique=unique_1) in \
           ('a', 'b', 'c')
    items_2 = 'abc'
    unique_2 = False
    length_2 = 0
    choice_2 = Choice()

# Generated at 2022-06-25 20:36:31.634673
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    arg_length = 3
    arg_unique = True
    arg_items = ['a', 'b', 'c', 'd', 'e']
    choice_0 = Choice()
    choice_1 = Choice()

    ret_0 = choice_0(arg_length, arg_unique, arg_items)
    