

# Generated at 2022-06-25 20:29:58.418372
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Test of method __call__
    assert Choice.__call__(Choice, *[], **{'items': '', 'unique': False}) == ''
    assert Choice.__call__(Choice, *[], **{'items': '', 'length': 0, 'unique': False}) == ''
    assert Choice.__call__(Choice, *[], **{'items': '', 'length': 0}) == ''
    assert Choice.__call__(Choice, *[], **{'items': '', 'length': 0, 'unique': True}) == ''
    assert Choice.__call__(Choice, *[], **{'items': '', 'length': 1, 'unique': False}) == ''
    assert Choice.__call__(Choice, *[], **{'items': '', 'length': 1}) == ''
    assert Choice.__call__

# Generated at 2022-06-25 20:30:05.674713
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    none_type_0 = None
    list_0 = []
    tuple_0 = ()
    str_0 = ''
    bool_0 = bool()
    choice_0 = Choice(*list_0)
    choice_1 = Choice(*list_0, length=10, unique=bool_0)
    choice_0.__call__(items=choice_0, length=10)
    choice_0.__call__(items=none_type_0, length=10)
    choice_0.__call__(items='abc', length=10)
    choice_0.__call__(items=tuple_0, length=10)
    choice_0.__call__(items=str_0, length=10)
    choice_0.__call__(items=str_0, length=10, unique=10)
    choice

# Generated at 2022-06-25 20:30:16.805830
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    none_type_0 = None
    list_0 = []
    choice_0 = Choice(*list_0)
    choice_1 = Choice('abc', 0, False)
    none_type_1 = choice_1()
    assert none_type_1 == 'c'
    none_type_2 = choice_1('a', 1)
    assert none_type_2 == ['a']
    none_type_3 = choice_1('abc', 2)
    assert none_type_3 == 'ba'
    none_type_4 = choice_1(('a', 'b', 'c'), 5)
    assert none_type_4 == ('c', 'a', 'a', 'b', 'c')
    none_type_5 = choice_1('aabbbccccddddd', 4, True)
    assert none_type

# Generated at 2022-06-25 20:30:26.869875
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert callable(Choice.__call__)
    choice_0 = Choice()
    assert choice_0(items='abc', length=2) == 'ba'
    assert str(choice_0(items='abc', length=2)) == 'ba'
    assert choice_0(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert str(choice_0(items=('a', 'b', 'c'), length=5)) == 'caabc'
    assert choice_0(items='abcd', length=3) == 'adb'
    assert str(choice_0(items='abcd', length=3)) == 'adb'



# Generated at 2022-06-25 20:30:38.309150
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    ones_str = '11111'
    ones_list = ['1'] * 5
    ones_tuple = ('1',) * 5
    choice_0(ones_list, 5)
    choice_0(ones_tuple, 5)
    choice_0(ones_str, 5)
    choice_0(ones_list, 3)
    choice_0(ones_tuple, 3)
    choice_0(ones_str, 3)
    choice_0(ones_list, 3, True)
    choice_0(ones_tuple, 3, True)
    choice_0(ones_str, 3, True)
    choice_0(ones_list, 5, True)
    choice_0(ones_tuple, 5, True)

# Generated at 2022-06-25 20:30:49.293196
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    list_0 = ['a', 'b', 'c']
    bool_0 = False
    list_1 = Choice.Choice().__call__(list_0, length=4, unique=bool_0)
    assert len(list_1) == 4
    assert list_1[0] in list_0
    assert list_1[1] in list_0
    assert list_1[2] in list_0
    assert list_1[3] in list_0
    bool_1 = True
    list_2 = Choice.Choice().__call__(list_0, length=2, unique=bool_1)
    assert len(list_2) == 2
    assert list_2[0] in list_0
    assert list_2[1] in list_0
    bool_2 = True

# Generated at 2022-06-25 20:30:59.257380
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    data_input_0 = ['a', 'b', 'c']
    data_input_1 = 0
    data_expect_0 = 'c'
    choice_0 = Choice()
    assert choice_0(items=data_input_0) == data_expect_0
    data_expect_1 = ['a']
    assert choice_0(items=data_input_0, length=data_input_1) == data_expect_1
    data_input_2 = 'abc'
    data_input_3 = 2
    data_expect_2 = 'ba'
    assert choice_0(items=data_input_2, length=data_input_3) == data_expect_2
    data_input_4 = ('a', 'b', 'c')
    data_input_5 = 5
   

# Generated at 2022-06-25 20:31:04.878921
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    item = Choice()
    items = Choice()
    items = Choice()
    length = Choice()
    length = Choice()
    unique = Choice()
    unique = Choice()
    item.__call__(items,length,unique)

# Unit tests for class Choice

# Generated at 2022-06-25 20:31:11.737028
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import random
    from copy import copy
    none_type_0 = None
    none_type_1 = None
    list_0 = []
    tuple_0 = ()
    list_1 = []
    bool_0 = True
    list_2 = []
    string_0 = str()
    list_3 = []
    string_1 = str()
    list_4 = []
    int_0 = 0
    list_5 = []
    str_0 = str()
    list_6 = []
    str_1 = str()
    list_7 = []
    str_2 = str()
    list_8 = []
    str_3 = str()
    list_9 = []
    str_4 = str()
    list_10 = []
    int_1 = 0

    # Call method __call__ of class Choice

# Generated at 2022-06-25 20:31:20.970563
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    str_0 = 'gnWm'
    tuple_0 = ()
    int_0 = 3019
    boolean_0 = False
    choice_0(items=str_0, length=int_0, unique=boolean_0)
    choice_0(items=str_0, length=int_0)
    choice_0(items=str_0)
    choice_0(items=tuple_0, length=int_0, unique=boolean_0)
    choice_0(items=tuple_0, length=int_0)
    choice_0(items=tuple_0)
    list_1 = [int, str]
    tuple_4 = choice_0(items=list_1, length=int_0, unique=boolean_0)

# Generated at 2022-06-25 20:34:17.308362
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    none_type_0 = None
    list_0 = []
    choice_0 = Choice(*list_0)
    bool_0 = bool()
    none_type_1 = choice_0.__call__(none_type_0, bool_0, bool_0)
    none_type_2 = choice_0.__call__(none_type_0)
    none_type_3 = choice_0.__call__(none_type_0, bool_0)
    none_type_4 = choice_0.__call__(none_type_0, bool_0, bool_0)
    none_type_5 = choice_0.__call__(none_type_0)
    none_type_6 = choice_0.__call__(none_type_0)


# Generated at 2022-06-25 20:34:28.356508
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice(items=[1, 2, 3], length=1).__call__() == [1]
    assert Choice(items=['a', 'b', 'c'], length=1).__call__() == ['a']
    assert Choice(items=[(1, 2), (3, ), (4, )], length=1).__call__() == [(1, 2)]
    assert Choice(items=['a', 'b', 'c', 'd', 'e'], length=3).__call__() == ['b', 'd', 'e']

# Generated at 2022-06-25 20:34:35.110747
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    # Set up test values
    choice_0 = Choice()
    items_0: list = [int]
    length_0: int = 0
    unique_0: bool = 0

    # Unit test
    assert choice_0(items=items_0, length=length_0, unique=unique_0) == 0

test_case_0()
test_Choice___call__()

# Generated at 2022-06-25 20:34:46.088838
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    choice_0 = Choice()
    type_0 = type((list(list()),))
    list_0 = []
    tuple_0 = tuple(list_0)
    items_0 = tuple_0
    length_0 = 1
    unique_0 = False
    return_value_0 = choice_0(items=items_0, length=length_0, unique=unique_0)
    assert type(return_value_0) == type_0

    choice_1 = Choice()
    type_1 = type((list(list()),))
    list_1 = []
    tuple_1 = tuple(list_1)
    items_1 = tuple_1
    length_1 = 1
    unique_1 = False

# Generated at 2022-06-25 20:34:48.091810
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    list_0 = ['a', 'b', 'c']
    assert choice_0(list_0, 1) in list_0


# Generated at 2022-06-25 20:34:55.432254
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items_0 = []
    length_0 = 22
    unique_0 = False
    choice_0 = Choice()
    try:
        choice_0(items_0, length_0, unique_0)
    except TypeError as e:
        assert isinstance(e, TypeError)
        assert '**length** must be integer.' == str(e)
    items_0 = ("c", "a", "d", "d", "e", "a", "a", "e", "a", "a", "c", "c", "d", "d", "d", "b", "c", "a", "a", "e", "b", "c")
    length_0 = 0
    unique_0 = True
    choice_0 = Choice()

# Generated at 2022-06-25 20:35:06.741364
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    none_type_0 = None
    list_0 = []
    choice_0 = Choice(*list_0)
    int_0 = 0
    items_0 = ['a', 'b', 'c']
    try:
        choice_0.choice(items_0, int_0, unique=False)
    except TypeError:
        pass
    except ValueError:
        pass
    choice_0 = Choice(*list_0)
    int_0 = 0
    items_0 = ['a', 'b', 'c']
    try:
        choice_0.choice(items_0, int_0, unique=False)
    except TypeError:
        pass
    except ValueError:
        pass
    choice_0 = Choice(*list_0)
    int_0 = 0

# Generated at 2022-06-25 20:35:17.254616
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items_0 = ['a', 'b', 'c']
    choice_0 = Choice()
    ret_0 = choice_0(items=items_0)
    assert ret_0 in items_0
    items_1 = 'abc'
    length_0 = 1
    choice_1 = Choice()
    ret_1 = choice_1(items=items_1, length=length_0)
    assert len(ret_1) == length_0
    assert ret_1 in items_1
    length_1 = 2
    choice_2 = Choice()
    ret_2 = choice_2(items=items_1, length=length_1)
    assert len(ret_2) == length_1
    assert ret_2 in items_1
    items_2 = ('a', 'b', 'c')
    length_2 = 5

# Generated at 2022-06-25 20:35:26.217812
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    choice = Choice()
    length = 0
    unique = False
    call_0 = choice(items, length, unique)
    items_1 = 'abc'
    length_1 = 2
    unique_1 = False
    call_1 = choice(items_1, length_1, unique_1)
    items_2 = ('a', 'b', 'c')
    length_2 = 5
    unique_2 = False
    call_2 = choice(items_2, length_2, unique_2)
    items_3 = 'aabbbccccddddd'
    length_3 = 4
    unique_3 = True
    call_3 = choice(items_3, length_3, unique_3)


# Generated at 2022-06-25 20:35:33.722916
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    method_name_0 = 'mimesis.builtins.choice.Choice.__call__'
    method_name_1 = 'mimesis.builtins.choice.Choice.__call__'
    method_name_2 = 'mimesis.builtins.choice.Choice.__call__'
    method_name_3 = 'mimesis.builtins.choice.Choice.__call__'
    method_name_4 = 'mimesis.builtins.choice.Choice.__call__'
    method_name_5 = 'mimesis.builtins.choice.Choice.__call__'
    method_name_6 = 'mimesis.builtins.choice.Choice.__call__'
    method_name_7 = 'mimesis.builtins.choice.Choice.__call__'