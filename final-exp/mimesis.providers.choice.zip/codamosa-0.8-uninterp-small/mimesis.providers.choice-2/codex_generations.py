

# Generated at 2022-06-25 20:29:31.766198
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_1 = Choice()

    # Test cases for TypeError
    # test_choice___call__TypeError_items_is_not_sequence
    try:
        choice_1(items=0)
    except TypeError:
        pass
    else:
        raise Exception('Test failed!')
    # test_choice___call__TypeError_length_is_not_integer
    try:
        choice_1(items=["a", "b", "c"], length="2")
    except TypeError:
        pass
    else:
        raise Exception('Test failed!')

    # Test cases for ValueError
    # test_choice___call__ValueError_items_is_empty_sequence
    try:
        choice_1(items=[])
    except ValueError:
        pass
    else:
        raise Exception('Test failed!')


# Generated at 2022-06-25 20:29:40.904917
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_1 = Choice()

    assert choice_1(items=['a', 'b', 'c']) == 'c'
    assert choice_1(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice_1(items='abc', length=2) == 'ba'
    assert choice_1(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice_1(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    assert isinstance(choice_1(items=['a', 'b', 'c']), str)
    assert isinstance(choice_1(items=['a', 'b', 'c'], length=1), list)
   

# Generated at 2022-06-25 20:29:45.806424
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items_0 = ["", "", ""]
    length_0 = choice_0(items=items_0)
    unique_0 = False
    var_0 = choice_0(items=items_0, length=length_0, unique=unique_0)


# Generated at 2022-06-25 20:29:52.488174
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    items_0 = choice_0(None, 1, 1)
    assert items_0 == 1
    items_1 = choice_0(['a', 'b', 'c'], 1, 1)
    assert items_1 == 1


# Generated at 2022-06-25 20:30:03.565147
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_1 = Choice()
    assert choice_1(items=list(range(1, 10)), length=0, unique=False) == 5
    assert choice_1(items=('a', 'b', 'c'), length=1) == ('c',)
    gt_2 = choice_1(items='abc', length=2)
    assert gt_2 == 'ba' or gt_2 == 'ab' or gt_2 == 'cb'
    assert len(choice_1(items=('a', 'b', 'c'), length=5)) == 5
    assert len(choice_1(items='aabbbccccddddd', length=4, unique=True)) == 4
    assert choice_1(items=list(range(1, 10)), length=0, unique=False) == 5

# Generated at 2022-06-25 20:30:07.368832
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice(
    )("Lorem ipsum dolor sit amet consectetur adipiscing elit".split(
    ), 21) == 'sit', "Failed: test_Choice___call__ Failed"


# Generated at 2022-06-25 20:30:10.722668
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    items = 'abc'
    length = 1
    unique = True
    assert choice_0.__call__(items=items, length=length, unique=unique) == 'c'

# Generated at 2022-06-25 20:30:14.575207
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    choice_0.random.seed(0)
    __ret = choice_0(items=['a', 'b', 'c'])
    assert __ret == 'a'



# Generated at 2022-06-25 20:30:20.105248
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    #
    choice_0 = Choice()
    #
    items_0 = ['a', 'b', 'c']
    length_0 = 0
    unique_0 = False
    ret_0 = choice_0(items=items_0, length=length_0, unique=unique_0)
    assert ret_0 == 'a'

    #
    choice_1 = Choice()
    items_1 = ['a', 'b', 'c']
    length_1 = 1
    unique_1 = False
    ret_1 = choice_1(items=items_1, length=length_1, unique=unique_1)
    assert ret_1 == ['c']

    #
    choice_2 = Choice()
    items_2 = 'abc'
    length_2 = 2
    unique_2 = False
    ret_2 = choice

# Generated at 2022-06-25 20:30:21.780198
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice.__call__(Choice(), Sequence[Any], 0, False)


# Generated at 2022-06-25 20:30:31.341252
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Testing if the random choice is in items
    # Testing with a list as the argument items
    # Not unique
    choice_0 = Choice()
    sequence_0 = ['24', '66', '99']
    assert choice_0(sequence_0, 15) == '964216969964216969964216969'
    # Unique
    choice_1 = Choice()
    sequence_1 = ['27', '74', '33']
    assert choice_1(sequence_1, 15, True) == '2743333727432774277433'
    # Testing with a tuple as the argument items
    # Not unique
    choice_2 = Choice()
    sequence_2 = ('11', '21', '97')

# Generated at 2022-06-25 20:30:35.305661
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    items_0 = ['a', 'b', 'c']
    length_0 = 2
    unique_0 = True
    actual = choice_0(items_0, length_0, unique_0)
    expected = 'ba'
    assert actual == expected

# Generated at 2022-06-25 20:30:41.806633
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0(items=['a', 'b', 'c']) == 'b'
    assert choice_0(items=['a', 'b', 'c'], length=0) == 'b'
    assert choice_0(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice_0(items='abc', length=2) == 'cb'
    assert choice_0(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'a', 'b')
    assert choice_0(items='aabbbccccddddd', length=4, unique=True) == 'adbc'
    assert choice_0.__call__(items=['a', 'b', 'c']) == 'b'

# Generated at 2022-06-25 20:30:46.797079
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ()
    length = 2
    unique = True
    choice_0 = Choice()
    result = choice_0.__call__(items, length, unique)
    assert result == '', 'Expected value of result:  Expected:<>'


# Generated at 2022-06-25 20:30:58.645201
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    from random import Random
    from math import inf
    from copy import copy
    from datetime import timedelta
    from datetime import time
    from datetime import datetime
    from decimal import Decimal
    from fractions import Fraction
    from enum import Enum
    from fractions import Fraction as Fraction_0
    from datetime import time as time_0
    from datetime import timedelta as timedelta_0
    from collections.abc import MutableSequence
    from datetime import datetime as datetime_0
    from fractions import Fraction as Fraction_1
    from decimal import Decimal as Decimal_0
    from fractions import Fraction as Fraction_2
    from fractions import Fraction as Fraction_3
    from datetime import time as time_1
    from datetime import timedelta as timedelta_1

# Generated at 2022-06-25 20:31:09.734642
# Unit test for method __call__ of class Choice

# Generated at 2022-06-25 20:31:20.114979
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    prov = Choice()
    # Call method __call__ of Choice with arguments: items = ['a', 'b', 'c'], length = 0, unique = False
    assert prov(items = ['a', 'b', 'c'], length = 0, unique = False) == 'c'
    # Call method __call__ of Choice with arguments: items = ['a', 'b', 'c'], length = 1, unique = False
    assert prov(items = ['a', 'b', 'c'], length = 1, unique = False) == ['a']
    # Call method __call__ of Choice with arguments: items = 'abc', length = 2, unique = False
    assert prov(items = 'abc', length = 2, unique = False) == 'ba'
    # Call method __call__ of Choice with arguments: items = ('a', 'b', 'c'), length

# Generated at 2022-06-25 20:31:28.333433
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TODO: Fix this or remove
    if hasattr(Choice, '__call__'):
        choice_0 = Choice()

        # TODO: Fix this or remove
        if not hasattr(choice_0, 'random'):
            raise RuntimeError("Cannot run tests for this provider yet, "
                               "as it's missing the random attribute.")

        choice_0.random.select_random = lambda *_: 1
        res_1 = choice_0(items=(10, 20, 30), length=5, unique=True)
        assert res_1 == (20, 10, 30, 20, 10)

        choice_0.random.select_random = lambda *_: 0
        res_2 = choice_0(items=(30, 40, 50), length=1, unique=True)
        assert res_2 == (30,)



# Generated at 2022-06-25 20:31:34.160775
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    items_0 = ['a', 'b', 'c']
    length_0 = 1
    unique_0 = True
    assert choice_0(items=items_0, length=length_0, unique=unique_0) == 'c'


# Generated at 2022-06-25 20:31:40.436736
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    choice_0.__call__(items=['a', 'b', 'c'])
    choice_0.__call__(items=['a', 'b', 'c', 'd'], length=1)
    choice_0.__call__(items='abcd', length=2)
    choice_0.__call__(items=tuple(['a', 'b', 'c', 'd']), length=5)
    choice_0.__call__(items='aabbbccccddddd', length=4, unique=True)


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-25 20:31:47.049847
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    # NoneType, NoneType test
    assert choice_0(items=None, length=None) is None
    # NoneType, NoneType test
    assert choice_0(items=None, length=0) is None
    

# Generated at 2022-06-25 20:31:54.776783
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    items_0 = ['a', 'b', 'c']
    length_0 = 1
    unique_0 = True
    # Expect: 'a'
    print(choice_0(items=items_0, length=length_0, unique=unique_0))

    choice_1 = Choice()
    items_1 = ['a', 'b', 'c']
    length_1 = 1
    # Expect: ['a']
    print(choice_1(items=items_1, length=length_1))

    choice_2 = Choice()
    items_2 = 'abc'
    length_2 = 2
    # Expect: 'ba'
    print(choice_2(items=items_2, length=length_2))

    choice_3 = Choice()

# Generated at 2022-06-25 20:32:06.919690
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    choice_1 = Choice()
    choice_2 = Choice()
    choice_3 = Choice()
    choice_4 = Choice()
    choice_5 = Choice()
    choice_6 = Choice()
    choice_7 = Choice()
    choice_8 = Choice()
    choice_9 = Choice()
    choice_10 = Choice()
    choice_11 = Choice()
    choice_12 = Choice()
    choice_13 = Choice()
    choice_14 = Choice()
    choice_15 = Choice()
    choice_16 = Choice()
    choice_17 = Choice()
    choice_18 = Choice()
    choice_19 = Choice()
    choice_20 = Choice()
    choice_21 = Choice()
    choice_22 = Choice()
    choice_23 = Choice()
    choice_24 = Choice()

# Generated at 2022-06-25 20:32:11.748571
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = [3, 5, 7, 11, 13, 17, 19, 23, 29, 31]
    length = 2
    condition = len(Choice().__call__(items, length=length)) == length
    print(not condition)


# Generated at 2022-06-25 20:32:19.494882
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    # sequence = [asd,bsd,csd]
    # assert choice_0.__call__(items=sequence) == 'csd'
    assert choice_0.__call__(items=['a', 'b', 'c']) == 'c'
    assert choice_0.__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice_0.__call__(items='abc', length=2) == 'ba'
    assert choice_0.__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')

# Generated at 2022-06-25 20:32:22.722043
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    items = ('a', 'bb', 'ccc')  # Test with tuple
    unique = True
    data = choice_0(items, 5, unique)  # Get 5 unique elements of items
    assert isinstance(data, tuple) is True
    assert len(data) == 5
    for element in data:
        assert element in items
    assert len(set(data)) == 5


# Generated at 2022-06-25 20:32:30.661114
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0.random.choice(['a', 'b', 'c']) == choice_0(['a', 'b', 'c'])
    assert choice_0.random.choice(['a', 'b', 'c']) == choice_0(items=['a', 'b', 'c'])
    assert choice_0.random.choice(['a', 'b', 'c']) == choice_0(items=['a', 'b', 'c'], length=0)
    choice_0.random.choice(['a', 'b', 'c']) == choice_0(items=['a', 'b', 'c'], length=0, unique=False)

# Generated at 2022-06-25 20:32:39.012378
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_1 = Choice()
    assert choice_1(items=['a', 'b', 'c']) == 'c'
    assert choice_1(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice_1(items='abc', length=2) == 'ba'
    assert choice_1(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice_1(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-25 20:32:49.854735
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert type(Choice()(items=[1])) is int
    assert type(Choice()(items=['a', 'b'])) is str
    assert type(Choice()(items=['a', 'b'], length=1)) is list
    assert type(Choice()(items='aabccc')) is str
    assert type(Choice()(items=(1, 2))) is int
    assert type(Choice()(items=['a', 'b', 'c'], length=5)) is list
    assert type(Choice()(items='abc', length=5, unique=True)) is str
    assert Choice()(items=[1], length=1) == [1]
    assert Choice()(items=[100, 200, 300]) in [100, 200, 300]

# Generated at 2022-06-25 20:32:55.168876
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    choice(items=['a', 'b', 'c'])
    choice(items='abc', length=2)


if __name__ == '__main__':
    choice = Choice()
    choice(items=['a', 'b', 'c'])
    choice(items='abc', length=2)

# Generated at 2022-06-25 20:33:08.903049
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from random import choice

    elem_0 = choice(['a', 'a', 'b'])
    assert elem_0 in ('a', 'b')
    elem_2 = Choice().__call__(['a', 'a', 'b'])
    assert elem_2 in ('a', 'b')
    elem_1 = Choice(seed=45454545).__call__(['a', 'a', 'b'], length=1)
    assert elem_1 in ('a', 'b')
    from sys import exc_info
    from traceback import format_exception
    from io import StringIO
    buf_0 = StringIO()
    except_0 = exc_info()

# Generated at 2022-06-25 20:33:14.880005
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    items_0: list = []
    length_0 = 0
    unique_0 = False
    choice_0(items=items_0, length=length_0, unique=unique_0)

# Generated at 2022-06-25 20:33:21.154585
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    x = choice(items=['a', 'b', 'c'])
    assert x == 'c'
    x = choice(items=['a', 'b', 'c'], length=1)
    assert x == ['a']
    x = choice(items='abc', length=2)
    assert x == 'ba'
    x = choice(items=('a', 'b', 'c'), length=5)
    assert x == ('c', 'a', 'a', 'b', 'c')
    x = choice(items='aabbbccccddddd', length=4, unique=True)
    assert x == 'cdba'
    try:
        choice(items=[])
    except ValueError:
        assert True
    else:
        assert False

# Generated at 2022-06-25 20:33:29.446914
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    choice_1 = Choice()
    choice_2 = Choice()
    choice_3 = Choice()

    selection = choice_0.__call__(items=['a', 'b', 'c'], length=0, unique=False)
    assert selection == 'c'

    selection = choice_1.__call__(items=['a', 'b', 'c'], length=1, unique=False)
    assert selection == ['a']

    selection = choice_2.__call__(items='abc', length=2, unique=False)
    assert selection == 'ba'

    selection = choice_3.__call__(items=('a', 'b', 'c'), length=5, unique=False)
    assert selection == ('c', 'a', 'a', 'b', 'c')

# Unit test

# Generated at 2022-06-25 20:33:33.012631
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    data = choice_0(items=['a', 'b', 'c'], length=1)
    assert data == ['a']
    

# Generated at 2022-06-25 20:33:40.408858
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in ['a', 'b', 'c']
    assert choice(items='abc', length=2) in ['ab', 'ac', 'ba', 'bc', 'cb', 'ca']
    assert choice(items=('a', 'b', 'c'), length=5) in ['a', 'b', 'c']
    assert choice(items='aabbbccccddddd', length=4, unique=True) in ['a', 'b', 'c', 'd']

# Generated at 2022-06-25 20:33:48.537150
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c'], length=0) == 'a'
    assert choice(items=['a', 'b', 'c'], length=2, unique=True) == 'bc'
    assert choice(items='abc', length=4, unique=False) == 'caaa'
    assert choice(items='abc', length=5, unique=True) == 'cbacb'
    assert choice(items=('a', 'b', 'c'), length=3, unique=False) == ('b', 'a', 'c')
    assert choice(items=('a', 'b', 'c'), length=4, unique=True) == ('c', 'a', 'b', 'b')

# Generated at 2022-06-25 20:33:52.675937
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    items_0 = ()
    length_0 = 1
    unique_0 = True
    unique_1 = False


# Generated at 2022-06-25 20:33:58.446454
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0(None, 0) == 'ф'
    assert choice_0(None, 0, unique=True) == 'p'
    assert choice_0(None, length=0, unique=True) == 'я'
    assert choice_0(length=0, unique=True) == '\u0430'  # 'а'
    assert choice_0(None, length=0) == 'b'

# Generated at 2022-06-25 20:34:00.386693
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    choice_0 = Choice()
    choice_0___call__ = choice_0(items, length, unique)


# Generated at 2022-06-25 20:34:09.261553
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TODO: Unit test __call__
    pass

# Generated at 2022-06-25 20:34:17.529654
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items_0 = []
    length_0 = 0
    unique_0 = True
    choice_0 = Choice()
    choice_1 = choice_0(items=items_0, length=length_0, unique=unique_0)
    assert choice_1 == 'OyGmoOTZ' or choice_1 == 'NspYDz' or choice_1 == 'Ad'
    del choice_0, items_0, length_0, unique_0, choice_1

    items_0 = []
    length_0 = 0
    unique_0 = True
    choice_0 = Choice()
    choice_1 = choice_0(items=items_0, length=length_0, unique=unique_0)
    assert choice_1 == 'OyGmoOTZ' or choice_1 == 'NspYDz' or choice_1

# Generated at 2022-06-25 20:34:21.322973
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0(items=['a', 'b', 'c'], length=0) == 'b'



# Generated at 2022-06-25 20:34:29.440497
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_1 = Choice()
    items_1 = ['a', 'b', 'c']
    length_1 = 1
    unique_1 = False
    print(choice_1(items=items_1, length=length_1, unique=unique_1))
    items_2 = 'abc'
    length_2 = 2
    unique_2 = False
    print(choice_1(items=items_2, length=length_2, unique=unique_2))
    items_3 = ('a', 'b', 'c')
    length_3 = 5
    unique_3 = False
    print(choice_1(items=items_3, length=length_3, unique=unique_3))
    items_4 = 'aabbbccccddddd'
    length_4 = 4
    unique_4 = True
    print

# Generated at 2022-06-25 20:34:38.941431
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()

    expected_0 = ('a', 'c', 'c', 'a')
    result_0 = choice_0(items=('a', 'c', 'c', 'a'), length=4)
    assert result_0 == expected_0

    expected_1 = 'a'
    result_1 = choice_0(items=['a'])
    assert result_1 == expected_1

    expected_2 = 'b'
    result_2 = choice_0(items=['a', 'b'], length=0)
    assert result_2 == expected_2

    expected_3 = ('a', 'a', 'b', 'c')
    result_3 = choice_0(items=('a', 'a', 'b', 'c'), length=4, unique=False)
    assert result_3 == expected_

# Generated at 2022-06-25 20:34:42.453405
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    items_0 = ['a', 'b', 'c']
    length_0 = 1
    unique_0 = True
    value = choice_0.__call__(items_0, length_0, unique_0)
    assert value == ['a']



# Generated at 2022-06-25 20:34:48.288187
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    choice = Choice()

    assert type(choice(items=['a', 'b', 'c'])) is str
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert type(choice(items=['a', 'b', 'c'], length=1)) is list
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert type(choice(items='abc', length=2)) is str
    assert choice(items='abc', length=2) == 'ba'
    assert type(choice(items=('a', 'b', 'c'), length=5)) is tuple
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')

# Generated at 2022-06-25 20:34:53.913131
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items_0 = []
    length_0 = -1
    unique_0 = False
    exception = None

    try:
        # Call method __call__ of Choice with arguments items_0, length_0, unique_0 (line 6)
        choice_0.__call__(items=items_0, length=length_0, unique=unique_0)
    except Exception as caughtException:
        exception = caughtException

    assert type(exception) == ValueError


# Generated at 2022-06-25 20:35:05.778865
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert (choice(items=['a', 'b', 'c']) ==
            Choice().__call__(items=['a', 'b', 'c'])) is True
    assert (choice(items=['a', 'b', 'c'], length=1) ==
            Choice().__call__(items=['a', 'b', 'c'], length=1)) is True
    assert (choice(items='abc', length=2) ==
            Choice().__call__(items='abc', length=2)) is True
    assert (choice(items=('a', 'b', 'c'), length=5) ==
            Choice().__call__(items=('a', 'b', 'c'), length=5)) is True

# Generated at 2022-06-25 20:35:16.713273
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items_0 = [0, 1, 16, 63, 10, 12, 9, 10, 12, 12, 9, 12, 1, 5, 9, 4, 11, 5, 9, 11, 6, 5, 9, 14, 17, 1, 9, 2, 3, 3, 4, 14, 4, 12, 15, 2, 6, 2, 9, 4, 8, 2, 1, 2, 6, 12, 11, 2, 0, 2]
    length_0 = 61
    unique_0 = False

# Generated at 2022-06-25 20:35:42.113909
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()


# Generated at 2022-06-25 20:35:44.825078
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = ['a', 'b', 'c']
    assert choice(items) in items


# Generated at 2022-06-25 20:35:53.634582
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    # Test items must be non-empty sequence
    with raises(TypeError) as context:
        choice_0.__call__(items='', length=int(), unique=False)
    assert str(context.value) == '**items** must be non-empty sequence.'
    # Test length must be integer
    with raises(TypeError) as context:
        choice_0.__call__(items=list(), length=float(), unique=False)
    assert str(context.value) == '**length** must be integer.'
    choice_1 = Choice()
    assert choice_1.__call__(items=list(['a', 'b', 'c'])) in ['a', 'b', 'c']
    choice_2 = Choice()

# Generated at 2022-06-25 20:35:58.070799
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    def test_case_0():
        choice_0 = Choice()
        result_0 = choice_0(items='abc', length=1)
        assert result_0 == ('a',)



# Generated at 2022-06-25 20:36:04.059586
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    result = Choice.__call__(items=['a', 'b', 'c'])
    assert result in ('a', 'b', 'c')
    result = Choice.__call__(items=['a', 'b', 'c'], length=1)
    assert len(result) == 1 and result in (['a'], ['b'], ['c'])
    result = Choice.__call__(items='abc', length=2)
    assert len(result) == 2 and result in ('ba', 'ac', 'cb')
    result = Choice.__call__(items=('a', 'b', 'c'), length=5)

# Generated at 2022-06-25 20:36:13.109866
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0.__call__(["A", "B", "C"]) == "B"
    assert choice_0.__call__(["C", "B", "B"]) == "B"
    assert choice_0.__call__(["B", "C", "C"]) == "C"
    assert choice_0.__call__(["C", "C", "B"]) == "B"
    assert choice_0.__call__(["C", "B", "A"], 0) == "B"
    assert choice_0.__call__(["A", "B", "C"], 1) == ["A"]
    assert choice_0.__call__(["C", "A", "B"], 2) == ["B", "C"]

# Generated at 2022-06-25 20:36:21.761145
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_1 = Choice()
    items_1 = [
        'a',
        'b',
        'c',
    ]
    length_1 = 1
    unique_1 = False
    res_1 = choice_1(items_1, length_1, unique_1)
    assert res_1 == 'a'
    items_2 = [
        'a',
        'b',
        'c',
    ]
    length_2 = 2
    unique_2 = True
    res_2 = choice_1(items_2, length_2, unique_2)
    assert res_2 in ['ac', 'ab', 'bc']
    items_3 = [
        'a',
        'b',
        'c',
    ]
    length_3 = 3
    unique_3 = False
    res_3

# Generated at 2022-06-25 20:36:26.064043
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    # call method __call__ of class Choice
    assert choice_0.__call__(items=('a', 'b', 'c')) in ['a', 'b', 'c']

# Generated at 2022-06-25 20:36:34.275922
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    t_0 = Choice()

# Generated at 2022-06-25 20:36:43.837741
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    choice_1 = Choice()
    assert choice_1('aabbbccccddddd', 4, True) in 'cabd'
    assert choice_0('aabbbccccddddd', 4, True) in 'cabd'
    assert choice_0('aabbbccccddddd', 2, True) in 'abcd'
    assert choice_0('aabbbccccddddd', 3, True) in 'abcd'
    assert choice_0('aabbbccccddddd', 1, True) in 'abcd'
    choice_0 = Choice()
    for _ in range(10):
        assert choice_0('aabbbccccddddd', 2, True) in 'abcd'



# Generated at 2022-06-25 20:37:17.397582
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    items_0 = ()
    #assert choice_0.__call__(items_0, 0) == '', 'Failed assert #0'


# Generated at 2022-06-25 20:37:24.094682
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0(items=('a', 'b', 'c'), unique=False) == 'b'
    assert choice_0(items=[], length=18, unique=False) == []
    assert choice_0(items=('a', 'b', 'c'), unique=False) == 'b'
    assert (choice_0(items=[], unique=False) == [])
    assert choice_0(items=['a', 'b', 'c'], length=12, unique=True) == 'bbacbaacbac'
    assert choice_0(items=['a', 'b', 'c'], length=7, unique=True) == 'cbacba'

# Generated at 2022-06-25 20:37:33.333074
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice().__call__(items='', length=0)
    assert isinstance(choice_0, str)

    choice_1 = Choice().__call__(items=('',), length=0)
    assert isinstance(choice_1, tuple)

    choice_2 = Choice().__call__(items=(), length=0)
    assert isinstance(choice_2, tuple)

    choice_3 = Choice().__call__(items=('',), length=1)
    assert isinstance(choice_3, tuple)

    choice_4 = Choice().__call__(items=(), length=1)
    assert isinstance(choice_4, tuple)

    choice_5 = Choice().__call__(items=[], length=0)
    assert isinstance(choice_5, list)

    choice_6 = Choice().__call

# Generated at 2022-06-25 20:37:43.548503
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    item_0 = ["a", "b", "c"]

    # Verify the type of return is the same of argument 'items'
    return_type = type(choice_0(item_0))
    assert return_type == type(item_0)

    # Verify if the returned value is in argument 'items'
    list_of_elements = item_0
    assert choice_0(list_of_elements) in list_of_elements

    # Verify if the returned value is the same of the argument 'items'
    list_of_elements = ["a", "b", "c"]
    assert choice_0(choice_0(list_of_elements)) in list_of_elements
    list_of_elements = (1, 2, 3)

# Generated at 2022-06-25 20:37:47.573285
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_ = Choice()
    items = ['a', 'b', 'c']
    length = 1
    unique = True
    _return = choice_.__call__(items, length, unique)
    # assertion
    assert _return == 'b'

    choice_ = Choice()
    items = ['a', 'b', 'c']
    length = 2
    unique = False
    _return = choice_.__call__(items, length, unique)
    # assertion
    assert _return == ['a', 'c']


# Generated at 2022-06-25 20:37:52.969043
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0(items=[0, 0, 1, 1, 2, 2, 3, 3, 4, 4], length=2, unique=False) in [0, 0, 1, 1, 2, 2, 3, 3, 4, 4]
    assert choice_0(items=[0, 0, 1, 1, 2, 2, 3, 3, 4, 4], length=2, unique=True) in [0, 1, 2, 3, 4]


# Generated at 2022-06-25 20:37:58.586835
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice()(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice()(items=('a', 'a', 'b', 'b', 'c', 'c', 'd', 'd', 'd', 'd'), length=4, unique=True) == ('d', 'd', 'a', 'c')
    assert Choice()(items='abc', length=2) == 'ba'
    assert Choice()(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    assert Choice()(items=('a', 'b', 'c'), length=1) == ['a']

# Generated at 2022-06-25 20:38:07.149641
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Initialize choice_0 with argument items of value ['a', 'b', 'c']
    choice_0 = Choice(items=['a', 'b', 'c'])
    # Initialize choice_1 with argument items of value ('a', 'b', 'c')
    choice_1 = Choice(items=('a', 'b', 'c'))
    # Initialize choice_2 with argument items of value 'abc'
    choice_2 = Choice(items='abc')
    # Initialize choice_3 with argument length of value 1
    choice_3 = Choice(length=1)
    # Initialize choice_4 with argument length of value 2
    choice_4 = Choice(length=2)
    # Initialize choice_5 with argument length of value 5
    choice_5 = Choice(length=5)
    # Initialize choice_6 with argument

# Generated at 2022-06-25 20:38:13.814335
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items_1 = ['a', 'b', 'c']
    length_1 = 1
    unique_1 = False
    expected_1 = ['a']
    actual_1 = Choice().__call__(items=items_1, length=length_1,
                                 unique=unique_1)
    assert actual_1 == expected_1
    # --------------
    items_2 = 'abc'
    length_2 = 2
    unique_2 = False
    expected_2 = 'ba'
    actual_2 = Choice().__call__(items=items_2, length=length_2,
                                 unique=unique_2)
    assert actual_2 == expected_2
    # --------------
    items_3 = ('a', 'b', 'c')
    length_3 = 5
    unique_3 = False
    expected_3

# Generated at 2022-06-25 20:38:22.550357
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert isinstance(choice_0(items=['a', 'b', 'c']), str)
    assert isinstance(choice_0(items=['a', 'b', 'c'], length=1), list)
    assert isinstance(choice_0(items='abc', length=2), str)
    assert isinstance(choice_0(items=('a', 'b', 'c'), length=5), tuple)
    assert isinstance(choice_0(items='aabbbccccddddd', length=4, unique=True), str)
    assert choice_0(items=['a', 'b', 'c']) in ['a', 'b', 'c']