

# Generated at 2022-06-25 20:29:29.121654
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_0 = 'l'
    str_1 = 'V'
    str_2 = '{'
    str_3 = 'r'
    str_4 = '0'
    choice_0 = Choice()
    assert choice_0.__call__([str_0]) == 'l'
    assert choice_0.__call__([str_0, str_1, str_2], 2) == '{l'
    assert choice_0.__call__(['', str_0, str_1, str_2]) == '{'
    assert choice_0.__call__([str_0, str_1, str_2], 1) == ['l']
    choice_1 = Choice()
    assert choice_1.__call__([str_0, str_1, str_3], 2, False) == 'rl'


# Generated at 2022-06-25 20:29:33.269996
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_0 = '$TKV[r'
    int_0 = 1
    bool_0 = False
    choice_0 = Choice()
    var_0 = choice_0.__call__(str_0, int_0, bool_0)


# Generated at 2022-06-25 20:29:41.767546
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items_0 = ['a', 'b', 'c']
    items_1 = ['a', 'b', 'c']
    length_0 = 0
    length_1 = 1
    length_2 = 2
    length_3 = 5
    length_4 = 4
    str_0 = 'abc'
    str_1 = 'aabbbccccddddd'
    tuple_0 = ('a', 'b', 'c')
    unique_0 = True
    unique_1 = False
    choice_0 = Choice()
    choice_1 = Choice()
    var_0 = choice_0.__call__(items=items_0, unique=unique_0)
    var_1 = choice_0.__call__(items=items_1, length=length_0)
    var_2 = choice_0.__call__

# Generated at 2022-06-25 20:29:52.241274
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_0 = 'N'
    choice_0 = Choice()
    var_0 = choice_0.__call__(str_0)
    str_1 = 'b'
    tuple_0 = ('i', '~')
    list_0 = ('B', 'b', 'Z', '#', 'U', '6', 'l', 'a', '$', "\'")
    tuple_1 = (str_0, str_1, tuple_0, list_0)
    var_1 = choice_0.__call__(tuple_1)
    assert var_1 in (str_0, str_1, tuple_0, list_0)
    list_1 = (';', 'Z', 'w', 'q', 'A', '~')

# Generated at 2022-06-25 20:30:03.566213
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0.__call__(['a', 'b'], 0, True) == 'b'
    assert choice_0.__call__(['a', 'b', 'c'], 0, True) == 'a'
    assert choice_0.__call__(['a', 'b', 'c', 'd', 'e'], 0, True) == 'd'
    assert choice_0.__call__(['a', 'b', 'c', 'd', 'e'], 0, True) == 'd'
    assert choice_0.__call__(['a', 'b', 'c', 'd', 'e'], 0, True) == 'e'

# Generated at 2022-06-25 20:30:15.307879
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Tests for some cases
    str_1 = 'R\x8b\x0f'
    choice_1 = Choice()
    assert choice_1.__call__(str_1) == '\x8b'
    str_2 = '\xe8\xcb\x0d\xdf\xca\xe8\xe1\xdc\x94'
    choice_2 = Choice()
    assert choice_2.__call__(str_2) == '\xe1'
    choice_3 = Choice()
    assert choice_3.__call__(str_2) == '\xe8'
    choice_4 = Choice()
    assert choice_4.__call__(str_2) == '\xe8'

# Generated at 2022-06-25 20:30:20.348400
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_0 = 'A_(,l'
    choice_0 = Choice()
    var_0 = choice_0.__call__(str_0, length=4)
    assert type(var_0) is str
    assert var_0 == ','


# Generated at 2022-06-25 20:30:23.121193
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_0 = 'b'
    int_0 = 1
    choice_0 = Choice()
    var_0 = choice_0.__call__(str_0, int_0)

# Generated at 2022-06-25 20:30:30.963726
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_0 = 'j'
    choice_0 = Choice()
    var_0 = choice_0.__call__(str_0,  unique=True)

    str_1 = '*zc'
    choice_0 = Choice()
    var_1 = choice_0.__call__(str_1)

    str_2 = 'a'
    choice_0 = Choice()
    var_2 = choice_0.__call__(str_2,  length=1,  unique=True)

    str_3 = 'M'
    choice_0 = Choice()
    var_3 = choice_0.__call__(str_3,  unique=True)

    str_4 = '1jgW'
    choice_0 = Choice()
    var_4 = choice_0.__call__(str_4)

# Generated at 2022-06-25 20:30:40.042941
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    def test_Choice___call___0():
        str_1 = 'й'
        choice_1 = Choice()
        var_1 = choice_1.__call__(str_1)
        assert var_1 == 'й'

    def test_Choice___call___1():
        str_2 = 'п'
        choice_2 = Choice()
        var_2 = choice_2.__call__(str_2, 2)
        assert var_2 == 'пп'

    def test_Choice___call___2():
        str_3 = 'ж'
        choice_3 = Choice()
        var_3 = choice_3.__call__(str_3, 7)
        assert var_3 == 'жжжжжжж'


# Generated at 2022-06-25 20:30:48.097872
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_0 = 'P'
    int_0 = 7
    bool_0 = True
    choice_0 = Choice()
    # Line of code where exception is expected
    exception_0 = Choice.__call__(choice_0, str_0, int_0, bool_0)

# Generated at 2022-06-25 20:30:48.874136
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert 1



# Generated at 2022-06-25 20:30:51.204450
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items_0 = [31, 11, 25, 47, 5, 2, 48, 59, 34, 33, 29, 6, 58, 26, 36]
    choice_0 = Choice(items_0)



# Generated at 2022-06-25 20:30:59.781187
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Choice().__call__(items=None, length=0, unique=False)
    assert Choice().__call__(['1', '2', '3']) in ['1', '2', '3']
    assert Choice().__call__(1) == 1
    assert Choice().__call__([1]) == 1
    assert Choice().__call__(['1', '2', '3'], length=1) in [['1'], ['2'], ['3']]
    assert Choice().__call__(['1', '2', '3'], length=2) in [['1', '2'], ['1', '3'], ['2', '3']]

# Generated at 2022-06-25 20:31:10.197734
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    int_0 = Choice().__call__((-1729502442, -1729502442, -1729502442, -1729502442, -1729502442, -1729502442, -1729502442, -1729502442, -1729502442, -1729502442), 4)
    assert ((-1729502442, -1729502442, -1729502442, -1729502442) == int_0)
    assert ((-1729502442, -1729502442, -1729502442, -1729502442) == int_0)
    triple_0 = (1, 2, 3)
    long_0 = Choice().__call__(triple_0, unique=True)

# Generated at 2022-06-25 20:31:19.183449
# Unit test for method __call__ of class Choice

# Generated at 2022-06-25 20:31:27.615613
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_0 = '&5'
    tuple_0 = ('|', '6', '#', 'B')
    choice_0 = Choice()
    var_3 = choice_0.__call__(tuple_0, 1, False)
    assert var_3 == ('|',)
    var_4 = choice_0.__call__(str_0, 1, True)
    assert var_4 == ('&',)
    str_3 = ''
    choice_1 = Choice()
    assert choice_1.__call__(str_3) == '&'
    tuple_1 = ('x1',)
    assert choice_1.__call__(tuple_1, 1, False) == ('x1',)
    assert choice_1.__call__(tuple_0, 1, True) == ('|',)

# Generated at 2022-06-25 20:31:35.477017
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    str_0 = 'W}'
    int_0 = 0
    bool_0 = False
    choice_0.__call__(str_0, int_0, bool_0)
    bool_1 = False
    choice_0.__call__(str_0, int_0, bool_1)


# Generated at 2022-06-25 20:31:37.711716
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_0 = 'g(Z'
    choice_0 = Choice()
    var_0 = choice_0.__call__(str_0, length=1)
    assert var_0 == '('



# Generated at 2022-06-25 20:31:49.731329
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    int_0 = -5
    str_0 = '\"'
    tup_0 = ('a', 'a', 'a')
    choice_0 = Choice()
    var_0 = choice_0.__call__(tup_0, int_0, True)
    var_1 = choice_0.__call__(tup_0, 5)
    var_2 = choice_0.__call__(str_0, 5, True)
    var_3 = choice_0.__call__(tup_0, 0)
    try:
        choice_0.__call__(tup_0, 5, '', str_0)
        raise AssertionError
    except TypeError:
        pass

# Generated at 2022-06-25 20:31:58.116338
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_1 = '\n0'
    assert Choice().__call__(str_1) in str_1


# Generated at 2022-06-25 20:32:02.005748
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_0 = 'U7V'
    choice_0 = Choice()
    var_0 = choice_0.__call__(str_0)


# Generated at 2022-06-25 20:32:09.261098
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_1 = Choice()
    var_form0 = choice_1.__call__(['a', 'b', 'c'])
    assert check_type_str(var_form0)
    var_form1 = choice_1.__call__(['a', 'b', 'c'], 
                                  length=1)
    assert check_type_list_str(var_form1)
    var_form2 = choice_1.__call__('abc', 
                                  length=2)
    assert check_type_str(var_form2)
    var_form3 = choice_1.__call__(('a', 'b', 'c'),
                                  length=5)
    assert check_type_tuple_str(var_form3)

# Generated at 2022-06-25 20:32:16.706722
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_1 = Choice()

    # Call method __call__ of class Choice with arguments
    choice_2 = choice_1.__call__(('a', 'b', 'c'))

    # Call method __call__ of class Choice with arguments
    choice_3 = choice_1.__call__('abcd', 0, False)

    # Call method __call__ of class Choice with arguments
    choice_4 = choice_1.__call__(('a', 'b', 'c'))

    # Call method __call__ of class Choice with arguments
    choice_5 = choice_1.__call__('abcdefg', 4, True)

    # Call method __call__ of class Choice with arguments
    choice_6 = choice_1.__call__(('a', 'b', 'c'), 5, False)

# Generated at 2022-06-25 20:32:28.596273
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_0 = 'K!l'
    int_0 = 0
    choice_0 = Choice()
    var_0 = choice_0.__call__(str_0, int_0)
    str_1 = '2&M'
    int_1 = 9
    var_1 = choice_0.__call__(str_1, int_1)
    tuple_0 = ()
    var_2 = choice_0.__call__(tuple_0)
    str_2 = '0,}'
    int_2 = 6
    var_3 = choice_0.__call__(str_2, int_2, True)
    list_0 = []
    var_4 = choice_0.__call__(list_0)
    tuple_1 = ()
    int_3 = 9
    var_5

# Generated at 2022-06-25 20:32:32.612353
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_0 = '?J'
    choice_0 = Choice()
    var_0 = choice_0.__call__(str_0)
    assert var_0 == '?'

# Generated at 2022-06-25 20:32:41.010044
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_0 = '?J'
    choice_0 = Choice()
    str_1 = ':t'
    str_2 = '`w'
    str_3 = '#3 '
    str_4 = 'N'
    str_5 = '"5'
    str_6 = ';$'
    int_0 = 2
    var_0 = choice_0.__call__(str_0, int_0, True)
    str_7 = '42'
    str_8 = '?J'
    str_9 = '\x1b'
    str_10 = 'X'
    str_11 = 'z'
    str_12 = '40\x80'
    int_1 = 7
    var_1 = choice_0.__call__(str_7, int_1, True)

# Generated at 2022-06-25 20:32:44.476212
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_0 = '6~'
    int_0 = 14360
    choice_0 = Choice()
    var_0 = choice_0.__call__(str_0, int_0)


# Generated at 2022-06-25 20:32:45.293075
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-25 20:32:52.835025
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items_0 = []
    length_0 = 0
    unique_0 = False
    choice_0 = Choice()
    var_0 = choice_0.__call__(items_0,length_0,unique_0)
    if isinstance(var_0, Sequence):
        print("PASS")
    else:
        print("FAIL")

    items_0 = []
    length_0 = 0
    unique_0 = True
    choice_0 = Choice()
    var_0 = choice_0.__call__(items_0,length_0,unique_0)
    if isinstance(var_0, Sequence):
        print("PASS")
    else:
        print("FAIL")

    items_0 = ['$','.']
    length_0 = 0
    unique_0 = False
    choice_0 = Choice

# Generated at 2022-06-25 20:32:56.866023
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    result = choice_0.__call__('abc')

# Generated at 2022-06-25 20:33:05.768299
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_0 = 'q'
    list_0 = [str_0]
    length_0 = -1
    var_0 = Choice().__call__(list_0, length_0)

    str_1 = '&'
    list_1 = [str_1]
    length_1 = -1
    var_1 = Choice().__call__(list_1, length_1)

    str_2 = ';'
    list_2 = [str_2]
    length_2 = -1
    var_2 = Choice().__call__(list_2, length_2)

    int_0 = 1
    list_3 = [int_0]
    length_2 = -1
    var_3 = Choice().__call__(list_3, length_2)

    list_4 = []
    length

# Generated at 2022-06-25 20:33:08.261329
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_0 = '?J'
    choice_0 = Choice()
    var_0 = choice_0.__call__(str_0)

# Generated at 2022-06-25 20:33:14.879874
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    str_0 = '?J'
    var_0 = choice_0.__call__(str_0, 2)
    assert var_0 is not None
    var_1 = choice_0.__call__(str_0, 1)
    assert var_1 is not None
    int_0 = 0
    var_2 = choice_0.__call__(str_0, int_0)
    assert var_2 is not None


# Generated at 2022-06-25 20:33:15.537448
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    assert test_case_0() == None


# Generated at 2022-06-25 20:33:18.462607
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = ['a', 'b', 'c']
    data = choice.__call__(items)


# Generated at 2022-06-25 20:33:19.966478
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = "abc"
    choice = Choice()
    var_0 = choice.__call__(items)
    # assert choice.__call__(items) in items

# Generated at 2022-06-25 20:33:25.122526
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_0 = '?J'
    choice_0 = Choice()
    # Error: TypeError: **length** must be integer.
    # var_0 = choice_0.__call__(str_0, str_0)
    # Error: TypeError: **items** must be non-empty sequence.
    # var_0 = choice_0.__call__(0, str_0)
    # Error: ValueError: **items** must be a non-empty sequence.
    # var_0 = choice_0.__call__(0)
    # Error: ValueError: **items** must be a non-empty sequence.
    # var_0 = choice_0.__call__(0, 0, 0)
    # Error: ValueError: **length** should be a positive integer.
    # var_0 = choice_0.__

# Generated at 2022-06-25 20:33:37.543622
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TypeError: '**items** must be non-empty sequence.'
    choice_0 = Choice()
    var_0 = choice_0.__call__(items={'QX': '|O'})

    # ValueError: '**items** must be a non-empty sequence.'
    choice_1 = Choice()
    var_0 = choice_1.__call__(items=())

    # TypeError: '**length** must be integer.'
    choice_2 = Choice()
    var_0 = choice_2.__call__(items=('.', 'P', '6', '@', '>'))

    # ValueError: '**length** should be a positive integer.'
    choice_3 = Choice()
    var_0 = choice_3.__call__(items=('J', '#'), length=1)

    #

# Generated at 2022-06-25 20:33:42.718510
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_0 = 'A_8Ix'
    int_0 = -10
    choice = Choice()  # dummy choice to suppress Pylint errors
    _ = choice.__call__(items=str_0, length=int_0)



# Generated at 2022-06-25 20:33:59.612178
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_0 = '?J'
    length_0 = -574955991
    unique_0 = False
    choice_0 = Choice()
    try :
        choice_0.__call__(str_0, length_0, unique_0)
    except ValueError:
        pass
    except Exception:
        print('Unexpected error')

    str_0 = '};&w+jH'
    length_0 = 5
    unique_0 = True
    choice_0 = Choice()
    try :
        choice_0.__call__(str_0, length_0, unique_0)
    except ValueError:
        pass
    except Exception:
        print('Unexpected error')

    str_0 = 'tYm'
    length_0 = -566377084
    unique_0 = True


# Generated at 2022-06-25 20:34:08.146997
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_0 = ''
    str_1 = '2&bV'
    str_2 = '7?e'
    str_3 = '8"v'
    str_4 = 'N\x04'
    str_5 = 'o#Qk'
    str_6 = 'KEc'
    str_7 = 'h4'
    str_8 = '\\k|h'
    int_0 = 0
    int_1 = 8
    int_2 = -4
    int_3 = 5
    int_4 = 2
    int_5 = 1
    int_6 = 4
    int_7 = 3
    choice_0 = Choice()
    var_0 = choice_0.__call__(str_0, int_5)

# Generated at 2022-06-25 20:34:14.820587
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    str_0 = 'zsjD'
    var_0 = choice_0.__call__(str_0, length=1)
    assert var_0 == 's'
    str_0 = 'yKj'
    var_0 = choice_0.__call__(str_0, length=2, unique=True)
    assert var_0 == 'Ky'



# Generated at 2022-06-25 20:34:21.655787
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_0 = '3!E^b'
    tuple_0 = (str_0, str_0, str_0, str_0)
    choice_0 = Choice()
    var_0 = choice_0.__call__(tuple_0, length=4)


# Generated at 2022-06-25 20:34:27.068694
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items_0 = [{},[],[],0.575049,0.575049,0.575049,-0.903860,{}]
    length_0 = -0.180198
    choice_0 = Choice()
    try:
        var_0 = choice_0.__call__(items_0, length_0)
        #fail()
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 20:34:37.989701
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_gen_0 = Choice()
    str_gen_1 = Choice()
    str_gen_2 = Choice()
    str_gen_3 = Choice()
    str_gen_4 = Choice()
    str_gen_5 = Choice()
    str_gen_6 = Choice()
    str_gen_7 = Choice()
    str_gen_8 = Choice()
    str_gen_9 = Choice()
    str_gen_10 = Choice()
    str_gen_11 = Choice()
    str_gen_12 = Choice()
    str_gen_13 = Choice()
    str_gen_14 = Choice()
    str_gen_15 = Choice()
    str_gen_16 = Choice()
    str_gen_17 = Choice()
    str_gen_18 = Choice()
    str_gen_19 = Choice()

# Generated at 2022-06-25 20:34:41.879598
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    char_0 = Choice()
    sequence_0 = char_0.__call__(list_0, int_0)
    assert sequence_0 == random.choice(list_0)
    assert sequence_0 == random.choice(list_0)
    assert sequence_0 == random.choice(list_0)


# Generated at 2022-06-25 20:34:46.149906
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_0 = '?J'
    list_0 = []
    choice_0 = Choice()
    var_0 = choice_0.__call__(str_0)
    for var_1 in str_0:
        list_0.append(var_1)
    var_2 = choice_0.__call__(list_0)
    assert (var_0 == var_2)
    assert (var_0 in str_0)


# Generated at 2022-06-25 20:34:47.947962
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(str_0) == '?J'


# Generated at 2022-06-25 20:34:52.558031
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_0 = 'e'
    choice_0 = Choice()
    var_0 = choice_0.__call__(str_0)
    assert choice_0.__class__.Meta.name == 'choice'


# Generated at 2022-06-25 20:35:07.161065
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    try:
        str_0 = '?J'
        choice_0 = Choice()
        var_0 = choice_0.__call__(str_0)
    except TypeError as e_0:
        # print(e_0)
        assert str(e_0) == '**items** must be non-empty sequence.'

    try:
        choice_0 = Choice()
        var_0 = choice_0.__call__(None)
    except TypeError as e_0:
        # print(e_0)
        assert str(e_0) == '**items** must be non-empty sequence.'


# Generated at 2022-06-25 20:35:08.757782
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass


# Generated at 2022-06-25 20:35:17.611402
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    #
    # Asserts that this method raises ValueError when there are not enough
    # unique elements in **items** to provide the specified **number**
    #
    try:
        choice_0 = Choice()
        choice_0.__call__('????', 3, True)
        assert False
    except ValueError:
        pass

    #
    # Asserts that this method raises ValueError when length is negative
    #
    try:
        choice_0 = Choice()
        choice_0.__call__('abc', length=-1, unique=False)
        assert False
    except ValueError:
        pass

    #
    # Asserts that this method raises TypeError when **length** is not
    # integer
    #

# Generated at 2022-06-25 20:35:19.941934
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    # Asserts if class Choice can be instantiated.
    pass


# Generated at 2022-06-25 20:35:23.559770
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    # TODO: Implement unit test for method __call__ of class Choice
    # unit test framework passes the wrong method cdoe
    # assert isinstance(choice.choice([]), int)
    assert isinstance(choice.__call__([0]), int)

# Generated at 2022-06-25 20:35:32.903056
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_0 = 'E\x00'
    choice_0 = Choice()
    var_0 = choice_0.__call__(str_0, 2, False)
    assert var_0 in (str_0)
    bool_0 = []
    var_1 = choice_0.__call__(str_0, 2, bool_0)
    assert var_1 in (str_0)
    str_1 = '+\x00'
    var_2 = choice_0.__call__(str_1, 2, False)
    assert var_2 in (str_1)
    bool_1 = []
    var_3 = choice_0.__call__(str_1, 2, bool_0)
    assert var_3 in (str_1)
    choice_1 = Choice()

# Generated at 2022-06-25 20:35:36.641821
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_0 = '8po9s*'
    choice_0 = Choice()
    var_0 = choice_0.__call__(str_0)

# Generated at 2022-06-25 20:35:44.486377
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    str_0 = '2(nFW\'='
    int_0 = 0
    bool_0 = True
    choice_0.__call__(str_0, int_0, bool_0)
    str_1 = 'R`;^M'
    tuple_0 = ('R`;^M',)
    choice_0.__call__(str_1, int_0, bool_0)
    str_2 = 'p/z:T'
    choice_0.__call__(str_2, int_0, bool_0)
    str_3 = '>`\'+`aU6S'
    choice_0.__call__(str_3, int_0, bool_0)
    str_4 = 'b]J@}'
    int_1 = 6

# Generated at 2022-06-25 20:35:53.533355
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    try:
        assert callable(Choice.__call__)
    except AssertionError as e:
        raise(e)
    try:
        assert isinstance(Choice.__call__(Choice(), ['a', 'b', 'c']), str)
    except AssertionError as e:
        raise(e)
    try:
        assert isinstance(Choice.__call__(Choice(), ['a', 'b', 'c'], length=1), list)
    except AssertionError as e:
        raise(e)
    try:
        assert isinstance(Choice.__call__(Choice(), 'abc', length=2), str)
    except AssertionError as e:
        raise(e)

# Generated at 2022-06-25 20:36:02.635357
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_0 = '?J'
    choice_0 = Choice()
    var_0 = choice_0.__call__(str_0)
    assert var_0 == '?J'
    str_1 = ':b'
    choice_1 = Choice()
    var_1 = choice_1.__call__(str_1, 1)
    assert var_1 == [':']
    tuple_0 = ('p', '*')
    choice_2 = Choice()
    var_2 = choice_2.__call__(tuple_0, 1)
    assert var_2 == ('p',)
    tuple_1 = ('1', '2')
    choice_3 = Choice()
    var_3 = choice_3.__call__(tuple_1, 5)

# Generated at 2022-06-25 20:36:22.938775
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    length_0 = 4
    item_0 = 'abcdef'
    choice_0 = Choice()
    var_0 = choice_0.__call__(item_0, length_0)
    assert var_0 == 'eacf'
    length_0 = 2
    item_0 = ' '
    choice_0 = Choice()
    var_0 = choice_0.__call__(item_0, length_0)
    assert var_0 == '  '
    length_0 = 8

# Generated at 2022-06-25 20:36:28.602369
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_0 = '<c[_?\x0e'
    choice_0 = Choice()
    var_0 = choice_0.__call__(str_0, 4, True)
    assert var_0 == 'cc<_'

# Generated at 2022-06-25 20:36:31.500269
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_2 = '@?'
    choice_2 = Choice()
    list_2 = list(str_2)
    int_2 = len(list_2)
    bool_2 = False
    var_2 = choice_2.__call__(list_2, int_2, bool_2)



# Generated at 2022-06-25 20:36:43.281920
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items_0 = [True, False, False]
    items_1 = [True, False, False]
    items_2 = [True, False, False]
    items_3 = [True]
    items_4 = [True]
    items_5 = [True]
    items_6 = [False, False, True]
    items_7 = [False, False, True]
    items_8 = [False, False, True]
    items_9 = [False, False, True]
    items_10 = [True, False, False]
    items_11 = [True, False, False]
    items_12 = [True, False, False]
    items_13 = [False, True, True]
    items_14 = [False, True, True]
    items_15 = [False, True, True]
    items_

# Generated at 2022-06-25 20:36:52.582502
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_1 = '*'
    choice_0 = Choice()
    assert choice_0.__call__(str_1) == '*'
    assert choice_0.__call__(str_1, length=1) == ['*']
    list_0 = []
    for _ in range(3):
        list_0.append(choice_0.__call__(str_1, 0))
    assert len(list_0) == 3
    int_0 = choice_0.__call__(str_1, 1)
    assert isinstance(int_0, list)
    assert all(map(lambda x: isinstance(x, str), int_0))
    assert len(int_0) == 1
    int_1 = choice_0.__call__(str_1, 2)

# Generated at 2022-06-25 20:36:56.806275
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_0 = '?J'
    choice_0 = Choice()
    var_0 = choice_0.__call__(str_0)
    assert var_0 == '?'

# Generated at 2022-06-25 20:37:03.899856
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    bool_0 = False
    str_2 = '_ -'
    str_3 = 'l\x0cq\x1d'
    int_0 = -1

# Generated at 2022-06-25 20:37:12.589481
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    str_0 = 'eH'
    choice_0 = Choice()
    result_0 = choice_0.__call__(str_0)
    assert str(result_0) == result_0
    assert isinstance(result_0, str)
    str_list_0 = ['"', 'i', 'j']
    result_1 = choice_0.__call__(str_list_0)
    assert str(result_1) == result_1
    assert isinstance(result_1, str)
    list_0 = [0, 0, 4]
    result_2 = choice_0.__call__(list_0, 0)
    assert list(result_2) == result_2
    assert isinstance(result_2, list)
    tuple_0 = (0, 1, 9)

# Generated at 2022-06-25 20:37:22.648865
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test case for Choice.__call__"""

    str_0 = '?'
    str_1 = '%'
    str_2 = '_'
    str_3 = 'T'
    str_4 = '\\'
    str_5 = 'V'
    str_6 = '\\'
    str_7 = 'u'
    str_8 = 'I'
    str_9 = '4'
    str_10 = '='
    str_11 = 'N'
    str_12 = '|'
    str_13 = 'U'
    str_14 = '^'
    str_15 = 'p'
    str_16 = 'E'
    str_17 = 'h'
    str_18 = 'O'
    str_19 = 'Y'
    str_20 = 'F'


# Generated at 2022-06-25 20:37:32.753629
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    t_1 = Choice()

    # No argument given
    try:
        res_0 = Choice.__call__()
    except TypeError:
        pass
    else:
        raise AssertionError

    # Items argument given
    items_1 = [1, 2, 3]
    res_1 = Choice.__call__(t_1, items_1)
    assert res_1 in items_1

    # Items and length argument given
    items_2 = [1, 2, 3]
    length_1 = 2
    res_2 = Choice.__call__(t_1, items_2, length_1)
    assert len(res_2) == length_1
    # TODO: Check every element

    # Items and unique argument given
    items_3 = [1, 2, 1]