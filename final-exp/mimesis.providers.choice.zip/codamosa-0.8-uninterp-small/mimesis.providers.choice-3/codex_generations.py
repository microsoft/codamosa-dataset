

# Generated at 2022-06-25 20:29:18.042646
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    try:
        choice_0.__call__()
        assert False
    except TypeError:
        pass
    try:
        choice_0.__call__(list_0=list_1)
        assert False
    except TypeError:
        pass
    try:
        choice_0.__call__(list_0=list_2, length=0)
        assert False
    except TypeError:
        pass
    assert choice_0.__call__(list_0=list_2, length=1) == ['a']
    assert choice_0.__call__(list_0=list_3, length=2) == 'ba'

# Generated at 2022-06-25 20:29:27.841620
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    list_0 = ["a", "b", "c"]
    int_0 = 0
    var_0 = choice_0.__call__(list_0, int_0=0, unique=False)
    assert var_0

    list_0 = ["a", "b", "c"]
    int_0 = 1
    var_0 = choice_0.__call__(list_0, int_0=1, unique=False)
    assert var_0

    list_0 = "abc"
    int_0 = 2
    var_0 = choice_0.__call__(list_0, int_0=2, unique=False)
    assert var_0

    list_0 = ("a", "b", "c")
    int_0 = 5
    var_0 = choice_

# Generated at 2022-06-25 20:29:37.644352
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    assert choice_0(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice_0(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice_0(items='abc', length=2) in ['ab', 'ac', 'bc']
    assert choice_0(items=('a', 'b', 'c'), length=5) in [('a', 'c', 'b', 'c', 'a'), ('b', 'c', 'c', 'c', 'a'), ('c', 'b', 'a', 'b', 'a')]

# Generated at 2022-06-25 20:29:41.899467
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    try:
        items = None
        length = 0
        unique = False
        choice = Choice()
        choice.__call__(items, length, unique)
    except TypeError as e:
        assert str(e).find('**length** must be integer.') == 0
    except ValueError as e:
        assert str(e).find('**items** must be a non-empty sequence.') == 0

# Generated at 2022-06-25 20:29:46.839883
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    list_0 = None
    assert_raises(TypeError, Choice().__call__, list_0)
    list_0 = ()
    assert_raises(ValueError, Choice().__call__, list_0)
    list_0 = ()
    assert_raises(TypeError, Choice().__call__, list_0, length=0.0)
    list_0 = ()
    assert_raises(ValueError, Choice().__call__, list_0, length=-1)
    list_0 = ()
    assert_raises(ValueError, Choice().__call__, list_0, length=0, unique=True)

# Generated at 2022-06-25 20:29:52.296457
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender
    items = [Gender.MALE, Gender.FEMALE]

    c = Choice()
    for _ in range(100):
        assert c(items) in items



# Generated at 2022-06-25 20:29:57.216580
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    list_0 = None
    choice_0 = Choice()
    try:
        var_0 = choice_0.__call__(list_0)
        assert False
    except ValueError:
        assert True



# Generated at 2022-06-25 20:30:02.464531
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    int_0 = randint(0, maxsize)
    str_0 = ''.join([choice(ascii_letters) for _ in range(randint(0, maxsize))])

    tuple_0 = (str_0,)
    list_0 = list(tuple_0)
    choice_0 = Choice()
    var_0 = choice_0.__call__(list_0, int_0)


# Generated at 2022-06-25 20:30:08.410421
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    list_0 = ['', '5', 'h^3a', '', '']
    length_0 = 5
    unique_0 = True
    choice_0 = Choice()
    var_0 = choice_0.__call__(list_0, length_0, unique_0).__eq__(['h^3a', '', '', '', ''])
    assert(var_0)
    list_1 = ['', 0.0, 'U', '6', 0.0]
    length_1 = 5
    unique_1 = True
    choice_1 = Choice()
    var_1 = choice_1.__call__(list_1, length_1, unique_1).__eq__([0.0, '6', 0.0, '', ''])
    assert(var_1)

# Generated at 2022-06-25 20:30:12.743591
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    try:
        list_0 = [1, 2, 3]
        choice_0 = Choice()
        var_0 = choice_0.__call__(list_0)
    except TypeError:
        print('type error raised')

# Generated at 2022-06-25 20:30:26.605637
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    print('test_Choice___call__')
    choice_0 = Choice()

    list_0 = ['a', 'b', 'c']
    assert choice_0.__call__(items=list_0) == 'c'

    list_0 = ['a', 'b', 'c']
    assert choice_0.__call__(items=list_0, length=1) == ['a']

    list_0 = 'abc'
    assert choice_0.__call__(items=list_0, length=2) == 'ba'

    list_0 = ('a', 'b', 'c')
    assert choice_0.__call__(items=list_0, length=5) == ('c', 'a', 'a', 'b', 'c')

    list_0 = 'aabbbccccddddd'

# Generated at 2022-06-25 20:30:37.923559
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    list_0 = []
    tuple_0 = ()
    choice_0 = Choice()
    item_0 = choice_0(list_0, 1)
    item_1 = choice_0(tuple_0, 1)
    item_2 = choice_0(list_0, 0)
    item_3 = choice_0(tuple_0, 0)
    item_4 = choice_0(list_0, 1, False)
    item_5 = choice_0(tuple_0, 1, False)
    item_6 = choice_0(list_0, 1, False)
    item_7 = choice_0(tuple_0, 1, False)
    item_8 = choice_0(list_0, 0, False)
    item_9 = choice_0(tuple_0, 0, False)


# Generated at 2022-06-25 20:30:39.988009
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(["a", "b", "c", "d"], 1, True) == "d"

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 20:30:46.473187
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    print('Calling method Choice.__call__')
    choice_0 = Choice()
    list_0 = ['b', 'a', 'c']
    var_0 = choice_0.__call__(list_0)
    # AssertionError: Expected 's' to equal 'a'.
    # self.assertEqual(var_0, 'a')


# Generated at 2022-06-25 20:30:58.512241
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    try:
        assert (Choice().__call__(items=None) == None)
    except TypeError:
        assert True

    try:
        assert (Choice().__call__(items=[]) == None)
    except ValueError:
        assert True

    try:
        assert (Choice().__call__(items={}) == None)
    except TypeError:
        assert True

    try:
        assert (Choice().__call__(items='', length=0) == None)
    except ValueError:
        assert True

    try:
        assert (Choice().__call__(items='', length=1) == None)
    except ValueError:
        assert True

    try:
        assert (Choice().__call__(items='abc', length=0) == None)
    except TypeError:
        assert True


# Generated at 2022-06-25 20:31:09.452763
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    print(choice_0.__call__('abc'))
    print(choice_0.__call__([1, 2]))
    print(choice_0.__call__([1, 2], 1))
    print(choice_0.__call__('abc', 2))
    print(choice_0.__call__(['a', 'b', 'c'], 5))
    print(choice_0.__call__('aabbbccccddddd', 4, True))
    print(choice_0.__call__('abc', 3, True))
    print(choice_0.__call__('abc', 3, True))
    print(choice_0.__call__('abc', 5, True))

test_Choice___call__()

# Generated at 2022-06-25 20:31:13.926796
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    list_0 = ('',)
    length_0 = 0
    unique_0 = False
    choice_0 = Choice()
    var_0 = choice_0.__call__(list_0, length_0, unique_0)
    print(var_0)

# Generated at 2022-06-25 20:31:17.807538
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    obj_0 = Choice()
    list_0 = ['A', 'B', 'C']
    int_0 = 0
    bool_0 = False
    var_0 = obj_0.__call__(list_0, int_0, bool_0)

# Generated at 2022-06-25 20:31:22.445175
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    list_0 = ['a', 'b', 'c']
    choice_0 = Choice()
    assert choice_0.__call__(list_0, 1)

test_Choice___call__()
test_case_0()

# Generated at 2022-06-25 20:31:25.093814
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    list_0 = ('0', '9', '6', 'e')
    int_0 = -7
    choice_0 = Choice()
    var_0 = choice_0.__call__(list_0, int_0)


# Generated at 2022-06-25 20:31:38.618676
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    seed = 2
    choice_0 = Choice(seed=seed)
    assert choice_0.__call__([]) == 'b'
    assert choice_0.__call__(['', '', '']) == ''
    assert choice_0.__call__(['', '', ''], 1) == ['']
    assert choice_0.__call__(['', '', ''], 2) == ['', '']
    assert choice_0.__call__(['', '', ''], 1, False) == ''
    assert choice_0.__call__(['', '', ''], 2, False) == 'b'
    assert choice_0.__call__(['', '', ''], 1, True) == ''
    assert choice_0.__call__(['', '', ''], 2, False) == 'b'
    assert choice_

# Generated at 2022-06-25 20:31:44.386506
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    args_0 = []
    kwargs_0 = {'length': 0}
    list_0 = ['a', 'b']
    choice_0 = Choice()
    var_0 = choice_0.__call__(list_0, **kwargs_0)


# Generated at 2022-06-25 20:31:46.611258
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    list_0 = ('a', 'b', 'c')
    length_0 = 2
    unique_0 = False
    choice_0 = Choice()
    var_1 = choice_0.__call__(list_0, length_0, unique_0)
    assert isinstance(var_1, str)
    assert var_1 == 'bc'

# Generated at 2022-06-25 20:31:54.392478
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import mimesis
    choice_0 = mimesis.Choice()
    assert choice_0.__call__('abc') in ('a', 'b', 'c')
    assert choice_0.__call__('abc', 0) in ('a', 'b', 'c')
    assert choice_0.__call__('abc', 1) in (['a'], ['b'], ['c'])
    assert choice_0.__call__('abc', 2) in ('ab', 'ac', 'bc')
    assert choice_0.__call__('abc', 3) in ('abc', 'acb', 'bac', 'bca', 'cab', 'cba')

# Generated at 2022-06-25 20:32:06.836975
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice()
    list_0 = (str(),)
    int_0 = choice_0.random.randint(0, 9999)
    bool_0 = choice_0.random.randint(0, 9999)
    bool_1 = choice_0.random.randint(0, 9999)
    bool_2 = choice_0.random.randint(0, 9999)
    bool_3 = choice_0.random.randint(0, 9999)
    bool_4 = choice_0.random.randint(0, 9999)
    bool_5 = choice_0.random.randint(0, 9999)
    bool_6 = choice_0.random.randint(0, 9999)
    bool_7 = choice_0.random.randint(0, 9999)
   

# Generated at 2022-06-25 20:32:10.614204
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    list_0 = ['a', 'b', 'c']
    int_0 = choice_0.__call__(list_0)
    assert int_0 in list_0

# Generated at 2022-06-25 20:32:19.200114
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    list_0 = ['']
    choice_0 = Choice()
    assert isinstance(choice_0.__call__(list_0), str)

    list_0 = ['']
    choice_0 = Choice()
    assert isinstance(choice_0.__call__(list_0, int()), list)

    list_0 = ['']
    choice_0 = Choice()
    assert isinstance(choice_0.__call__(list_0, int(), bool()), list)

    list_0 = ['']
    choice_0 = Choice()
    assert isinstance(choice_0.__call__(list_0, int()), list)

    list_0 = ['']
    choice_0 = Choice()
    assert isinstance(choice_0.__call__(list_0, int()), list)



# Generated at 2022-06-25 20:32:28.221568
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert choice_0.__call__(items=('a', 'b', 'c')) == 'a'
    assert choice_0.__call__(items=('a', 'b', 'c'), length=1) == 'a'
    assert choice_0.__call__(items='abc', length=2) == 'ba'
    assert choice_0.__call__(items=('a', 'b', 'c'), length=5) == ('a', 'b', 'c', 'a', 'b')
    assert choice_0.__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-25 20:32:39.466401
# Unit test for method __call__ of class Choice

# Generated at 2022-06-25 20:32:50.097407
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    list_0 = [None]
    # 1. Should throw RuntimeError
    expected = RuntimeError()
    actual = None
    try:
        choice_0 = Choice()
        choice_0.__call__(list_0)
    except RuntimeError as e:
        actual = e
    assert actual == expected

    list_0 = ['a']
    # 1. Should throw RuntimeError
    expected = RuntimeError()
    actual = None
    try:
        choice_0 = Choice()
        choice_0.__call__(list_0)
    except RuntimeError as e:
        actual = e
    assert actual == expected

    list_0 = []
    # 2. Should throw ValueError
    expected = ValueError()
    actual = None

# Generated at 2022-06-25 20:32:58.500220
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    list_0 = []
    choice_0 = Choice()
    var_0 = choice_0.__call__(list_0, 1)
    assert var_0 == list_0


# Generated at 2022-06-25 20:33:06.407082
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    list_0 = []
    choice_0 = Choice()
    var_0 = choice_0.__call__([])
    assert var_0.__class__ == list
    assert var_0 == []

    tuple_0 = ()
    var_1 = choice_0.__call__(tuple_0)
    assert var_1.__class__ == tuple
    assert var_1 == ()

    var_2 = choice_0.__call__('', length=4, unique=True)
    assert var_2 == ''
    var_3 = choice_0.__call__('abc', length=None)
    assert var_3.__class__ == str
    assert var_3 == 'c'

# Generated at 2022-06-25 20:33:14.880630
# Unit test for method __call__ of class Choice
def test_Choice___call__(): # pylint: disable=R0915
    list_0 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 0]
    choice_0 = Choice()
    var_0 = choice_0.__call__(list_0)
    assert var_0 == 1

    list_0 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 0]
    choice_0 = Choice()
    var_0 = choice_0.__call__(list_0)
    assert var_0 == 1

    list_0 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 0]
    choice_0 = Choice()
    var_0 = choice_0.__call__(list_0)
    assert var_0 == 1


# Generated at 2022-06-25 20:33:21.142709
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_0 = Choice(seed=1234)

    assert choice_0.__call__("", 1, True) == "f"
    assert choice_0.__call__("", 0, False) == "e"
    assert choice_0.__call__("", 0, False) == "d"
    assert choice_0.__call__("", 0, False) == "a"
    assert choice_0.__call__("", 1, True) == "a"
    assert choice_0.__call__("", 0, True) == "e"
    assert choice_0.__call__("", 0, False) == "a"
    assert choice_0.__call__("", 0, False) == "c"
    assert choice_0.__call__("", 0, True) == "c"

# Generated at 2022-06-25 20:33:25.315696
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__('a' * 5, 1) == 'a'
    assert Choice().__call__('a' * 5, 1) == 'a'
    assert Choice().__call__('a' * 5, 1) == 'a'



# Generated at 2022-06-25 20:33:31.428814
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    list_1 = [1, 2, 3]
    choice_1 = Choice()
    var_1 = choice_1.__call__(list_1, choice_1.random.randint(), choice_1.random.choice())
    assert var_1 in list_1


# Generated at 2022-06-25 20:33:38.094809
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    list_0 = ["b", "g", "f", "v", "Y", "G", "9", "i", "4"]
    choice_0 = Choice()
    var_0 = choice_0.__call__(list_0, 0)
    try:
        assert var_0 == "g", "Expected <g>, but got <%s>." % var_0
    except AssertionError as e:
        raise AssertionError("Test Case 0 Choice.__call__ expected <g> but was <%s>" % var_0) from e


# Generated at 2022-06-25 20:33:41.402030
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    list_0 = None
    choice_0 = Choice()
    choice_0.__call__(list_0)



# Generated at 2022-06-25 20:33:46.040151
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    list_0 = None
    choice_0 = Choice()
    try:
        choice_0.__call__(list_0)
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-25 20:33:51.316094
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Setup
    choice = Choice()

    # Act
    choice_0 = choice.__call__(length=3, unique=True, items='abcde')

    # Assert
    assert choice_0 is not None