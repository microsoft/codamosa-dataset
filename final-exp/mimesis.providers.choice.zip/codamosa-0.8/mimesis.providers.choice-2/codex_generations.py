

# Generated at 2022-06-12 01:35:59.909718
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import sys
    import unittest

    class ChoiceTestCase(unittest.TestCase):
        """Test methods of class Choice."""

        def test___call__(self):
            """Test method __call__ of class Choice."""
            # Arguments
            _items = 'abc'
            _length = 2
            _unique = False

            # Return value
            _return = 'ba'

            # Tests
            choice = Choice()
            result = choice(_items, _length, _unique)
            self.assertEqual(result, _return)

        def test___call___with_length(self):
            """Test method __call__ of class Choice."""
            # Arguments
            _items = 'abc'
            _length = 10
            _unique = True

            # Return value

# Generated at 2022-06-12 01:36:09.282438
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    print('Test method __call__ of class Choice')
    from mimesis import Choice
    from mimesis.enums import Gender
    from mimesis.exceptions import NonEnumerableError
    from mimesis.typing import Sequence
    from mimesis.providers.person.en import Person

    _choice = Choice()
    non_empty_sequence = 'abc'
    length = 2
    sequence_of_length_two = 'cb'

    assert _choice(items=non_empty_sequence, length=length) == sequence_of_length_two

    assert isinstance(_choice(items=non_empty_sequence, length=length), Sequence)
    assert not isinstance(_choice(items=non_empty_sequence, length=length), list)

    assert len(_choice(items=non_empty_sequence, length=length)) == length

# Generated at 2022-06-12 01:36:16.925866
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    Choice.seed(0)
    data = Choice()
    items = ['a', 'b', 'c']
    # length = 0
    assert data(items) in items
    # length = 1
    assert data(items, 1) == items
    # length = 2, unique = False
    assert set(data(items, 2)) == set(items)
    # length = 3, unique = True
    assert set(data(items, 3, True)) == set(items)
    # length = 4, unique = True
    with pytest.raises(ValueError) as err:
        data(items, 4, True)
    assert str(err.value) == 'There are not enough unique elements in **items** to provide the specified **number**.'
    # length = -1

# Generated at 2022-06-12 01:36:21.970678
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Randomly-chosen sequence or bare element from a sequence."""
    choice = Choice()
    assert isinstance(choice(items=['a', 'b', 'c']), str)
    assert isinstance(choice(items=['a', 'b', 'c'], length=1), list)
    assert isinstance(choice(items='abc', length=2), str)
    assert isinstance(choice(items=('a', 'b', 'c'), length=5), tuple)
    assert isinstance(choice(items='aabbbccccddddd', length=4, unique=True), str)


# Generated at 2022-06-12 01:36:31.149907
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    value = choice(items=['a', 'b', 'c'])
    assert value == 'c'
    value = choice(items=['a', 'b', 'c'], length=1)
    assert value == ['a']
    value = choice(items='abc', length=2)
    assert value == 'ba'
    value = choice(items=('a', 'b', 'c'), length=5)
    assert value == ('c', 'a', 'a', 'b', 'c')
    value = choice(items='aabbbccccddddd', length=4, unique=True)
    assert value == 'cdba'

# Generated at 2022-06-12 01:36:38.705131
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from nose.tools import assert_equal, assert_raises # type: ignore
    from nose.plugins.attrib import attr # type: ignore

    choice = Choice()

    assert_raises(TypeError, choice, items=123)
    assert_raises(TypeError, choice, items=('a', 'b', 'c'), length="abc")
    assert_raises(ValueError, choice, items=())
    assert_raises(ValueError, choice, items=('a', 'b', 'c'), length=-1)
    assert_raises(ValueError, choice,
                               items=('a', 'b', 'c'), length=5, unique=True)

    assert_equal(choice(items=['a', 'b', 'c']), 'c')

# Generated at 2022-06-12 01:36:50.077003
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.builtins import Choice
    choice=Choice()
    assert choice(['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ba', 'ac', 'bc']
    assert choice(items=('a', 'b', 'c'), length=5) in \
        [('c', 'a', 'a', 'b', 'c'), ('c', 'a', 'b', 'a', 'c'), ('a', 'b', 'c', 'a', 'a'), ('b', 'c', 'c', 'a', 'b')]

# Generated at 2022-06-12 01:37:00.718186
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    assert (choice(items=items, length=length, unique=unique) == ['a'])
    length_1 = 10
    assert (choice(items=items, length=length_1, unique=unique) == ['c', 'c', 'c', 'b', 'c', 'b', 'b', 'c', 'a', 'c'])
    length_2 = 2
    assert (choice(items=items, length=length_2, unique=unique) == ['b', 'b'])
    length_3 = 5
    assert (choice(items=items, length=length_3, unique=unique) == ['c', 'b', 'a', 'a', 'a'])

# Generated at 2022-06-12 01:37:10.011096
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    choice_data1 = Choice()
    assert choice_data1(items=('a', 'b', 'c')) in {'a', 'b', 'c'}
    choice_data2 = Choice()
    assert choice_data2(items=('a', 'b', 'c'), length=2) in {('a', 'b'), ('a', 'c'), ('b', 'c')}
    choice_data3 = Choice()
    assert choice_data3(items=('a', 'b', 'c'), length=2, unique=True) in {('a', 'b'), ('a', 'c'), ('b', 'c')}
    choice_data4 = Choice()

# Generated at 2022-06-12 01:37:17.975152
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    call = Choice()
    # call(items=['a', 'b', 'c'])
    assert call(items=['a', 'b', 'c']) == 'c'
    # call(items=['a', 'b', 'c'], length=1)
    assert call(items=['a', 'b', 'c'], length=1) == ['a']
    # call(items='abc', length=2)
    assert call(items='abc', length=2) == 'ba'
    # call(items=('a', 'b', 'c'), length=5)
    assert call(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    # call(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-12 01:37:37.300421
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    # test1
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['b']
    assert choice(items='abc', length=2) == 'bc'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    # test2
    assert choice(items=['a'], length=1) == ['a']
    assert choice(items=['a'], length=0) == 'a'
    assert choice(items='a', length=1) == 'a'


# Generated at 2022-06-12 01:37:47.841638
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Choice.__call__(items=NoneType, length=0)
    try:
        choice.__call__(items=None)
        raise AssertionError()
    except TypeError:
        pass
    try:
        choice.__call__(items=None, length=0)
        raise AssertionError()
    except TypeError:
        pass

    # Choice.__call__(items=int, length=0)
    try:
        choice.__call__(items=1)
        raise AssertionError()
    except TypeError:
        pass
    try:
        choice.__call__(items=1, length=0)
        raise AssertionError()
    except TypeError:
        pass

    # Choice.__call__(items=float, length=0)

# Generated at 2022-06-12 01:37:56.232743
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    
    assert 'c'==choice(items=['a', 'b', 'c'])
    assert ['a']==choice(items=['a', 'b', 'c'], length=1)
    assert 'ba'==choice(items='abc', length=2)
    assert ('c', 'a', 'a', 'b', 'c')==choice(items=('a', 'b', 'c'), length=5)
    assert 'cdba'==choice(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-12 01:38:07.571282
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""

    c = Choice()
    assert c(items=['a', 'b', 'c'], length=3, unique=True) == ['c', 'a', 'b']
    assert c(items=['a', 'b', 'c'], length=2, unique=False) == ['b', 'c']
    assert c(items='abcdefghijklmnopqrstuvwxyz', length=5, unique=True) == 'zwvgj'
    assert c(items=(1, 2, 3), length=5, unique=True) == (3, 1, 2, 2, 3)
    assert c(items=['a', 'b', 'c'], unique=True) == 'a'

# Generated at 2022-06-12 01:38:15.191459
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    obj = Choice()
    items = ['a', 'b', 'c']
    assert obj(items=items) == 'c'
    assert obj(items=items, length=1) == ['a']
    assert obj(items='abc', length=2) == 'ba'
    assert obj(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert obj(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:38:25.466050
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import random
    import time
    import pytest
    x = time.time_ns()
    r = random.randint(0, 5)
    c = Choice()
    if r == 0:
        if c('1234') == '1234':
            x += 5
    if r == 1:
        if c('1', 1) == [1]:
            x += 5
    if r == 2:
        if c('1234', 2) == '13':
            x += 5
    if r == 3:
        if c('1234', 3) == '123':
            x += 5
    if r == 4:
        if c('1', 2) == [1, 1]:
            x += 5
    if r == 5:
        if c('1', 2, unique=True) == [1, 1]:
            x

# Generated at 2022-06-12 01:38:35.043499
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc') in ['a', 'b', 'c']
    assert choice(items='abc', length=1) in ['a', 'b', 'c']
    assert choice(items='abc', length=2) in ['aa', 'bb', 'cc', 'ab', 'ac', 'bc']
    assert isinstance(choice(items='aabbbccccddddd', length=5, unique=True), str)
    assert isinstance(choice(items=('a', 'b', 'c'), length=2, unique=True), tuple)

# Generated at 2022-06-12 01:38:45.791775
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    # See docstrings in Choice.__call__()
    sequence = ['a', 'b', 'c', 'd', 'e', 'f']

    # Test case #1
    choice = Choice()
    chosen = choice(items=sequence, length=0)
    assert chosen in sequence

    # Test case #2
    choice = Choice()
    length = choice.random.randint(1, 5)
    chosen = choice(items=sequence, length=length)
    assert len(chosen) == length

    # Test case #3
    choice = Choice()
    chosen = choice(items=sequence, length=0, unique=True)
    assert chosen in sequence

    # Test case #4
    choice = Choice()
    length = choice.random.randint(1, 5)

# Generated at 2022-06-12 01:38:49.142793
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(['a', 'b', 'c'])
    assert CallableMethod(Choice, '__call__').call([])
test_Choice___call__.method = '__call__'


# Generated at 2022-06-12 01:39:01.332349
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    provider = Choice()
    # Case 1
    items = ['a', 'b', 'c']
    result = provider.__call__(items=items)
    # Case 2
    length = 1
    result = provider.__call__(items=items, length=length)
    # Case 3
    items = 'abc'
    length = 2
    result = provider.__call__(items=items, length=length)
    # Case 4
    items = ('a', 'b', 'c')
    length = 5
    result = provider.__call__(items=items, length=length)
    # Case 5
    items = 'aabbbccccddddd'
    length = 4
    unique = True
    result = provider.__call__(items=items, length=length, unique=unique)

# Generated at 2022-06-12 01:39:10.793684
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    data = choice(items=['a', 'b', 'c'], length=10, unique=True)
    assert len(data) == 10


# Generated at 2022-06-12 01:39:19.199414
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=0) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:39:30.868756
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    # Tests for method __call__ of class Choice
    assert isinstance(choice(items=[1, 2, 3]), int)
    assert isinstance(choice(items=[1, 2, 3], length=2), list)
    assert isinstance(choice(items=[1, 2, 3], length=1), list)
    assert isinstance(choice(items=(1, 2, 3), length=3), tuple)
    assert len(choice(items=(1, 2, 3), length=3)) == 3
    assert len(choice(items=[1, 2, 3], length=3)) == 3
    # assert choice(items=[1, 1, 2], length=1, unique=True) == [2]
    # assert choice(items=[1, 1, 2], length=3, unique=True) == [2, 1]
   

# Generated at 2022-06-12 01:39:39.262863
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    print(c(items=['a', 'b', 'c'], length=0))
    print(c(items=['a', 'b', 'c'], length=1))
    print(c(items='abc', length=2))
    print(c(items=('a', 'b', 'c'), length=5))
    print(c(items='aabbbccccddddd', length=4, unique=True))
    # print(c(items=['a', 'b', 'c'], length='1'))
    # print(c(items=['a', 'b', 'c'], length=-1))
    # print(c(items=['a', 'b', 'c'], length=4, unique=True))
    # print(c(items=None, length=1))


# Generated at 2022-06-12 01:39:47.497779
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method __call__ of class Choice."""
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-12 01:39:56.498379
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    _items = ['a', 'b', 'c', 'd']
    assert len(Choice().__call__(_items)) == 1
    assert Choice().__call__(_items) in _items
    assert Choice().__call__(_items, 3) in [_items, _items[::-1]]
    assert Choice().__call__(_items, 4) in [_items, _items[::-1]]
    assert Choice().__call__(_items, 2, True) in [[_items[0], _items[1]],
                                                 [_items[0], _items[-1]],
                                                 [_items[-1], _items[0]],
                                                 [_items[-1], _items[-2]]]

# Generated at 2022-06-12 01:40:03.192279
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items1 = 'a,b,c'
    items2 = ('a', 'b', 'c')
    items3 = ['a', 'b', 'c']
    length = 2
    unique = True
    assert isinstance(choice(items=items1), str)
    assert isinstance(choice(items=items2), tuple)
    assert isinstance(choice(items=items3), list)
    assert isinstance(choice(items=items1, length=length), str)
    assert isinstance(choice(items=items2, length=length), tuple)
    assert isinstance(choice(items=items3, length=length), list)
    assert isinstance(choice(items=items1, length=length, unique=unique), str)

# Generated at 2022-06-12 01:40:10.711172
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    print(choice(items=['a', 'b', 'c']))
    print(choice(items=['a', 'b', 'c'], length=1))
    print(choice(items='abc', length=2))
    print(choice(items=('a', 'b', 'c'), length=5))
    print(choice(items='aabbbccccddddd', length=4, unique=True))


# Generated at 2022-06-12 01:40:19.243338
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test function for method __call__ of class Choice"""
    assert Choice().__call__(['a', 'b', 'c']) in ('a', 'b', 'c')
    assert Choice().__call__(['a', 'b', 'c'], length=1) in (['a'], ['b'], ['c'])
    assert Choice().__call__(['a', 'b', 'c'], length=2) in (['a', 'a'], ['a', 'b'], ['a', 'c'],
                                                            ['b', 'a'], ['b', 'b'], ['b', 'c'],
                                                            ['c', 'a'], ['c', 'b'], ['c', 'c'])

# Generated at 2022-06-12 01:40:27.003036
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) != 'd'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:43:51.953040
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-12 01:44:00.737943
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(('a', 'b', 'c')) in ('c', 'a', 'b')
    assert Choice().__call__(('a', 'b', 'c'), length=1) in (('c',),('a',),('b',))
    assert Choice().__call__('abc', length=2) in ('ba', 'ac', 'ab')
    assert Choice().__call__(('a', 'b', 'c'), length=5) in (('c', 'a', 'a', 'c', 'b'), ('c', 'c', 'a', 'b', 'b'), ('c', 'b', 'a', 'c', 'b'), ('a', 'c', 'b', 'b', 'a'), ('c', 'c', 'c', 'a', 'b') )

# Generated at 2022-06-12 01:44:10.831286
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    ch = Choice()
    assert ch(items=('a', 'b', 'c')) in ['a', 'b', 'c']
    assert ch(items=('a', 'b', 'c'), length=1) == ['c']
    assert ch(items='abc', length=2) in ['ba', 'ab', 'bc']
    assert ch(items='aabbbccccddddd', length=4) in ['bdac', 'cddb', 'bddc']

# Generated at 2022-06-12 01:44:18.568995
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    items = ['a', 'b', 'c']
    assert choice(items) in items

    items = ['a', 'b', 'c']
    assert len(choice(items, length=1)) == 1

    items = 'abc'
    assert len(choice(items, length=2)) == 2

    items = ('a', 'b', 'c')
    assert len(choice(items, length=5)) == 5

    items = 'aabbbccccddddd'
    assert len(choice(items, length=4, unique=True)) == 4


# Generated at 2022-06-12 01:44:24.479720
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=('a', 'b', 'c')) in ['a', 'b', 'c']
    assert choice(items='abc', length=2) in ['ba', 'cb', 'ac']
    assert choice(items='abc', length=3) in ['cab', 'bca', 'abc']
    assert choice(items=('a', 'b', 'c'), length=2, unique=True) in ['ab', 'bc', 'ca']

# Generated at 2022-06-12 01:44:30.977838
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    choice = Choice()

    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:44:32.449572
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert callable(Choice)

# Generated at 2022-06-12 01:44:39.650057
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Return a uncontained element randomly chosen from a sequence
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'
    # Return a sequence of length 1 randomly chosen from a sequence
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    # Return a sequence of length 2 randomly chosen from a sequence
    assert Choice().__call__(items='abc', length=2) == 'ba'
    # Return a sequence of length 5 randomly chosen from a sequence
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == \
        ('c', 'a', 'a', 'b', 'c')
    # Return a sequence of length 4 randomly chosen from a sequence

# Generated at 2022-06-12 01:44:49.069669
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    obj = Choice()
    assert obj(items = ['a', 'b'], length = 5) == ['b', 'b', 'a', 'b', 'a']
    assert obj(items = ('a', 'b'), length = 5) == ('a', 'b', 'b', 'b', 'a')
    assert obj(items = {'a', 'b'}, length = 5) == ['a', 'a', 'a', 'b', 'b']
    assert obj(items = 'abc', length = 5) == 'cbacc'
    assert obj(items = 'aabbbccccddddd', length = 4, unique = True) == 'cdba'


# Generated at 2022-06-12 01:44:57.271687
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    # Define some tuples
    t_0 = ()
    t_1 = (1, 2, 3, 4, 5)
    t_2 = ("a", "b", "c", "d", "e")
    t_3 = ("a", "b", "c", "d", "e", "f", "g", "h", "i")

    # Create an instance of class Choice
    choice = Choice()

    # Define a function to test the method
    def test(items, expected_length=None, expected_item=None, unique=False,
             length=0):
        """Test with different tuples different length and different output."""
        if expected_length is None:
            assert len(choice(items, unique=unique, length=length)) == length
