

# Generated at 2022-06-12 01:37:12.865213
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choices = {
        'items': ['a', 'b', 'c'],
        'length': 1,
        'unique': False
    }

    choice = Choice()
    '''
    choice.random.choice(choices.items)
    '''


# Generated at 2022-06-12 01:37:21.093696
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:37:25.718856
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice('abc') == 'a'
    assert choice('abc', length=1) == ['a']
    assert choice('abc', length=2) == 'ba'
    assert choice('aabbbccccddddd', length=4, unique=True) == 'cbda'

# Generated at 2022-06-12 01:37:37.347253
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Calling a not empty array
    assert(len(Choice().__call__('abc', 2)) == 2)
    # Calling an empty array
    assert(Choice().__call__('', 2) == '')
    # Calling a array with negative length
    assert(Choice().__call__('abc', -2) == '')
    # Calling a choice of array
    assert(Choice().__call__('aebc') in ['a', 'b', 'c'])
    # Calling a not empty array with unique elements
    assert(len(Choice().__call__('aebc', 4, True)) == 4)
    # Calling a empty array with unique elements
    assert(Choice().__call__('', 4, True) == '')
    # Calling a array with negative length with unique elements

# Generated at 2022-06-12 01:37:45.701820
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import random
    import re
    import string
    from mimesis import Choice

    choice = Choice()

    data = ['a', 'b', 'c']
    choice_1 = [choice(data) for _ in range(1000)]
    choice_2 = [choice(data, length=1) for _ in range(1000)]

    assert len(choice_1) == 1000
    assert len(set(choice_1)) == 3
    assert len(choice_2) == 1000
    assert len(set(choice_2)) == 1

    def get_random_string(length):
        lowercase_letters = string.ascii_lowercase
        return ''.join(random.choice(lowercase_letters) for i in range(length))


# Generated at 2022-06-12 01:37:50.745430
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for Choice.__call__ method."""
    from mimesis import Choice
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ab', 'ac', 'bc']

# Generated at 2022-06-12 01:38:00.096899
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    import random
    import sys
    import unittest

    from mimesis import Choice
    from mimesis.enums import Gender

    class ChoiceTestCase(unittest.TestCase):
        """Tests for Choice."""

        def setUp(self):
            """Set up test data."""
            self.seed = 42
            self.choice = Choice(seed=self.seed)
            self.sequence = tuple(range(10))

        def test___call__(self):
            """Test method __call__."""
            self.assertEqual(len(self.choice('abc', length=5)), 5)
            self.assertEqual(len(self.choice('abc', length=5)), 5)

# Generated at 2022-06-12 01:38:07.049596
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    choice = Choice()
    items = ['a', 'b', 'c']
    assert choice(items=items) in items
    assert choice(items=items, length=1) in items
    assert choice(items='abc', length=2) in 'abc'
    assert choice(items=tuple(items), length=5) in items
    assert choice(items='aabbbccccddddd', length=4, unique=True) in 'abcd'

# Generated at 2022-06-12 01:38:17.381587
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    try:
        assert Choice().__call__(['a', 'b', 'c']) == 'c'
        assert Choice().__call__(['a', 'b', 'c'], length=1) == ['a']
        assert Choice().__call__('abc', length=2) == 'ba'
        assert Choice().__call__(('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
        assert Choice().__call__('aabbbccccddddd', length=4, unique=True) == 'cdba'
    except AssertionError:
        print("Error! Test method __call__ of class Choice is fail.")
        print("Please check method __call__ of class Choice")
        return False
    print("Test method __call__ of class Choice is completed.")

# Generated at 2022-06-12 01:38:24.795286
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Method __init__ of class Choice
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-12 01:39:34.750651
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    assert callable(choice.__call__)
    assert (isinstance(choice(items=['a', 'b', 'c'],
                                  length=1),
                        list))
    assert (isinstance(choice(items=['a', 'b', 'c'],
                                  length=1),
                        list))
    assert (isinstance(choice(items='abc',
                                  length=2),
                        str))
    assert (isinstance(choice(items=('a', 'b', 'c'),
                                  length=5),
                        tuple))
    assert (isinstance(choice(items='aabbbccccddddd',
                                  length=4, unique=True),
                        str))

# Generated at 2022-06-12 01:39:41.852760
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender
    from mimesis.providers.utils import get_provider
    en = get_provider('en')

    choice = Choice()

    items = (1, 2, 3, 4, 5)
    length = 2
    unique = False
    out = choice(items, length, unique)

    assert isinstance(out, tuple)
    assert len(out) == length

    items = (1, 2, 3, 4, 5)
    length = 2
    unique = True
    out = choice(items, length, unique)

    assert isinstance(out, tuple)
    assert len(out) == length

    items = 'abcdefgh'
    length = 5
    unique = False
    out = choice(items, length, unique)

    assert isinstance(out, str)

# Generated at 2022-06-12 01:39:52.687366
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice of module choice"""
    choice = Choice()
    assert choice(items=['a', 'b', 'c'], length=2) == ['b', 'a']
    assert choice(items='abc', length=5) == 'acbca'
    assert choice(items='abc', length=0) in ['a', 'b', 'c']
    assert choice(items=(1, 2, 3), length=4) == (2, 3, 1, 2)
    assert choice(items='aabbbccccddddd', length=3, unique=True) in ['abd', 'acd', 'adb']
    assert choice(items=['a', 'b', 'c'], length=1) == ['c']

# Generated at 2022-06-12 01:40:00.283396
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method __call__ of class Choice."""
    choice = Choice()
    assert choice(items = ['a', 'b', 'c']) in ('a', 'b', 'c')
    assert choice(items = ('a', 'b', 'c'), length = 3) in (('a', 'b', 'c'), ('a', 'c', 'b'), ('b', 'a', 'c'), ('b', 'c', 'a'), ('c', 'a', 'b'), ('c', 'b', 'a'))
    assert choice(items = 'abc', length = 3) in ('abc', 'acb', 'bac', 'bca', 'cab', 'cba')

# Generated at 2022-06-12 01:40:11.019438
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items='abc', length=1) == 'a'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items=['a', 'b', 'c'], length=2) == ['a', 'b']
    assert Choice().__call__(items=['a', 'b', 'c'], length=3) == ['a', 'b', 'c']
    assert Choice().__call__(items='abc', length=1) == 'a'
    assert Choice().__call__(items='abc', length=2) == 'ab'
    assert Choice().__call__(items='abc', length=3) == 'abc'

# Generated at 2022-06-12 01:40:19.777818
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    obj = Choice()
    r1 = obj()
    assert type(r1) is list
    r2 = obj(length=2)
    assert len(r2) == 2
    r3 = obj(length=3)
    assert len(r3) == 3
    r4 = obj(length=4)
    assert len(r4) == 4
    r5 = obj(length=5)
    assert len(r5) == 5
    r6 = obj(length=6)
    assert len(r6) == 6
    assert r1 != r2 != r3 != r4 != r5 != r6
    assert r2 != r3 != r4 != r5 != r6
    assert r3 != r4 != r5 != r6

# Generated at 2022-06-12 01:40:28.684273
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Provide elements randomly chosen from the elements in a sequence
    # **items**, where when **length** is specified the random choices are
    # contained in a sequence of the same type of length **length**,
    # otherwise a single uncontained element is chosen. If **unique** is set
    # to True, constrain a returned sequence to contain only unique elements.
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')

# Generated at 2022-06-12 01:40:40.342292
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.specification import Argument
    class MyChoice(Choice):
        def __call__(self, items: Sequence[Any] = Argument('seq', providers='choice.items'),
                     length: int = Argument('int', providers='choice.length'),
                     unique: bool = Argument('bool', providers='choice.unique')):
            return (items, length, unique)
    class MyChoice2(choice):
        class Meta:
            name = 'my_choice'
    my_choice = MyChoice()
    my_choice2 = MyChoice2()
    assert my_choice.items(length=1).__next__() == my_choice.__call__().__next__()[0]
    assert my_choice.items(length=100).__next__() == my_choice.__call__().__next__()[0]

# Generated at 2022-06-12 01:40:43.859815
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    result = choice(items=['a', 'b', 'c'], length=0, unique=False)
    print(result)
    assert result == 'c'

if __name__ == '__main__':
    test_Choice___call__()

# Generated at 2022-06-12 01:40:51.553526
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice.__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice.__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice.__call__(items='abc', length=2) == 'ba'
    assert Choice.__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice.__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:45:09.023218
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    assert Choice()(items=['a', 'b', 'c']) == 'c'
    assert Choice()(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice()(items='abc', length=2) == 'ba'
    assert Choice()(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice()(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

    try:
        Choice()(items=123, length=1)
        assert False
    except TypeError:
        pass

# Generated at 2022-06-12 01:45:19.816750
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = [0, 1, 2, 3]
    assert choice(items) in items
    assert len(choice(items, unique=True)) == len(set(choice(items, unique=True)))
    assert isinstance(choice(items, unique=True), str)
    expected = [choice(items) for _ in range(100)]
    expected_unique = [i for i in set(expected)]
    assert choice(items, length=100) == expected
    assert choice(items, length=100, unique=True) == expected_unique

    items = (0, 1, 2, 3)
    assert choice(items) in items
    assert len(choice(items, unique=True)) == len(set(choice(items, unique=True)))
    assert isinstance(choice(items, unique=True), str)
    expected

# Generated at 2022-06-12 01:45:28.375381
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice.__call__(Choice(), items=['a', 'b', 'c']) == 'c'
    assert Choice.__call__(Choice(), items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice.__call__(Choice(), items='abc', length=2) == 'ba'
    assert Choice.__call__(Choice(), items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice.__call__(Choice(), items='aabbbccccddddd', length=4, unique=True) == 'cdba'



# Generated at 2022-06-12 01:45:33.924994
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import doctest
    doctest.testmod(raise_on_error=True, verbose=False)

if __name__ == "__main__":
    test_Choice___call__()

# Generated at 2022-06-12 01:45:44.372957
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for Choice.__call__.

    Metadata:
        test_flag: random

    These tests are not deterministic, but should cover enough cases to
    ensure that the distribution of random choices is uniform.
    """
    from mimesis.typing import Chars
    from mimesis.enums import Gender, DataType

    choice = Choice(seed=42)
    assert choice(items=(1, 2, 3), length=0) == 2
    assert choice(items=('a', 'b', 'c')) == 'b'
    assert choice(items=('a', 'b', 'c'), length=1) == ('a',)
    assert choice(items='abc', length=3) == 'abc'
    assert choice(items=(1, 2, 3), length=5) == (2, 3, 3, 3, 1)

# Generated at 2022-06-12 01:45:53.056924
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    # Testing non-sequence items
    with pytest.raises(TypeError):
        choice(items=None)
    # Testing non-integer length
    with pytest.raises(TypeError):
        choice(items=[1, 2, 3], length=None)
    # Testing empty sequence
    with pytest.raises(ValueError):
        choice(items=[])
    # Testing negative length
    with pytest.raises(ValueError):
        choice(items=[1, 2, 3], length=-1)
    # Testing insufficient unique elements
    with pytest.raises(ValueError):
        choice(items=[1, 1, 1], length=4, unique=True)
    # Testing random sequence choice