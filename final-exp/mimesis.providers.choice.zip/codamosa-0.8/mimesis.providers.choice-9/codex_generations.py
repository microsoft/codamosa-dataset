

# Generated at 2022-06-12 01:36:05.947278
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    items = ['a', 'b', 'c']
    choices = []
    for i in range(1000):
        choices.append(c(items=items))
        
    assert str(choices).find('c') != -1
    
    
    choices = []
    for i in range(1000):
        choices.append(c(items=items, length=1))
    print(choices)
    
    
    choices = []
    for i in range(1000):
        choices.append(c(items='abc', length=2))
    print(choices)
    
    choices = []
    for i in range(1000):
        choices.append(c(items=('a', 'b', 'c'), length=5))
    print(choices)
    
    
    choices = []


# Generated at 2022-06-12 01:36:12.864763
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-12 01:36:24.288345
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.localization import Localization
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.person import Person
    from mimesis.providers.utils import serialize
    from mimesis.typing import AnyData
    from mimesis.typing import JSONType
    from time import time

    random_seed = 42
    random_data = [42, True, 'foo', 42.0, [1, 'a']]
    random_dict = {'a': 'a', 'b': 1, 'c': True}
    random_data_serialized = serialize(random_data)
    random_dict_serialized = serialize(random_dict)


# Generated at 2022-06-12 01:36:34.649655
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # When parameter length is set to 0, normally return a single
    # uncontained element.
    assert Choice().call(['a', 'b', 'c'], length=0) == 'b'

    # When parameter length is set to 0, normally return a single
    # uncontained element.
    assert Choice().call(['a', 'b', 'c'], length=1) == ['b']

    # When parameter length is set to 0, normally return a single
    # uncontained element.
    assert Choice().call('abc', length=2) == 'ab'

    # When parameter length is set to 0, normally return a single
    # uncontained element.
    assert Choice().call(('a', 'b', 'c'), length=5) == \
        ('c', 'c', 'a', 'a', 'b')

    # When parameter length

# Generated at 2022-06-12 01:36:35.168739
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-12 01:36:43.741333
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Function to test the __call__ method of Choice class."""
    from mimesis import Choice
    choice = Choice()

    assert choice(items=['a', 'b', 'c'])
    assert choice(items=['a', 'b', 'c'], length=1)
    assert choice(items='abc', length=2)
    assert choice(items=('a', 'b', 'c'), length=5)
    assert choice(items='aabbbccccddddd', length=4)

# Generated at 2022-06-12 01:36:51.682942
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) in ['ba', 'ab', 'cb']
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) in ['cdab', 'bcad', 'dbac', 'cdba']

# Generated at 2022-06-12 01:36:58.362829
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method __call__ of class Choice."""
    from mimesis.providers.choice import Choice
    for length in [0, 1, 2, 3, 5]:
        for items in [['a', 'b', 'c'], ('a', 'b', 'c'), 'abc']:
            choice = Choice()
            choice(items=items, length=length)



# Generated at 2022-06-12 01:37:09.386854
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

    import pytest
    with pytest.raises(TypeError) as excinfo:
        assert Choice().__call__(items=5, length=5)

# Generated at 2022-06-12 01:37:17.706197
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Example of using method __call__ of class Choice.

    :return: True.
    :rtype: bool
    """
    from mimesis import Choice
    choice = Choice()
    actual = choice(items = ['a', 'b', 'c'])
    print(actual)
    assert actual == 'c'

    actual = choice(items = ['a', 'b', 'c'], length = 1)
    print(actual)
    assert actual == ['a']

    actual = choice(items = 'abc', length = 2)
    print(actual)
    assert actual == 'ba'

    actual = choice(items = ('a', 'b', 'c'), length = 5)
    print(actual)
    assert actual == ('c', 'a', 'a', 'b', 'c')


# Generated at 2022-06-12 01:37:21.599332
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass


# Generated at 2022-06-12 01:37:24.444293
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    choice = Choice()
    assert choice(items=['a', 'b', 'c']) ==  "b"
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-12 01:37:25.316093
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass


# Generated at 2022-06-12 01:37:32.487487
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    class Type:
        pass
    class UnsupportedType:
        pass

    # The following call raises TypeError
    # >>> choice(items=['a', 'b', 'c'])
    # >>> choice(items=['a', 'b', 'c'], length=1)
    # >>> choice(items='abc', length=2)
    # >>> choice(items=('a', 'b', 'c'), length=5)
    # >>> choice(items='aabbbccccddddd', length=4, unique=True)

    # The following call raises ValueError
    # >>> choice(items='', length=4)
    # >>> choice(items=[], length=4)
    # >>> choice([], length=4)
    # >>> choice(items=[1, 2, 3], length=4, unique=True)

    # Chooses

# Generated at 2022-06-12 01:37:41.611343
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    def compare(fn):
        from mimesis.enums import ChoiceVariant
        from mimesis.typing import ChoiceFunc

        f = ChoiceFunc(fn)
        assert len(f([1])) == len(fn([1]))
        assert f([1, 2], 2) == fn([1, 2], 2)
        assert f('abc', 4) == fn('abc', 4)
        assert f((1, 2, 3), 3) == fn((1, 2, 3), 3)
        assert f('abcabcabcabc', 3) == fn('abcabcabcabc', 3)

        assert f([1, 2, 3], 3) != fn([1, 2, 3], 3)
        assert f('abc', 4) != fn('abc', 4)

# Generated at 2022-06-12 01:37:42.564548
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()


# Generated at 2022-06-12 01:37:53.278121
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    print("Unit test for method Choice.__call__")
    choice = Choice()
    assert type(choice("abc", 1)[0]) is str
    assert len(choice("abc", 1)) == 1
    assert type(choice("abc", 1)[0]) is str
    assert type(choice("abc", 1)[0]) is str
    assert len(choice("abc", 1)) == 2
    assert type(choice("abc", 1)[0]) is str
    assert type(choice("abc", 1)[0]) is str
    assert choice("abc") in ["a", "b", "c"]
    assert choice("abc", 0) in ["a", "b", "c"]
    assert type(choice("abc", 1)[0]) is str
    assert choice("abc", 1)[0] in ["a", "b", "c"]

# Generated at 2022-06-12 01:37:57.481325
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import pytest

    with pytest.raises(TypeError) as exception:
        Choice()(items=1, length=0, unique=False)
    assert str(exception.value) == '**items** must be non-empty sequence.'


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 01:38:08.453743
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method __call__ of class Choice.

    :return: Nothing.
    :raises: unittest.TestError if test not passed.
    """
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.text import Text

    # Instance of BaseProvider
    base = BaseProvider()
    # Formatted sequence
    formatter = ['{}', '{}', '{}']
    items = ['a', 'b', 'c']
    length = 3

    # Instance of Choice
    choice = Choice(formatter=formatter, seed=10)
    # Random choice without repetition
    random_choice = choice(items=items, length=length, unique=True)
    # Random choice with repetition

# Generated at 2022-06-12 01:38:08.962484
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-12 01:38:21.944201
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Tests the method __call__ of class Choice."""
    from mimesis.providers.choice import Choice
    from mimesis.providers.person import Person
    from mimesis.providers.url import URL
    choice = Choice()
    people = []
    for i in range(5):
        people.append(Person().full_name())
    print(choice('abc', 2))
    print(choice(people, 2))
    urls = []
    for i in range(5):
        urls.append(URL().link())
    print(choice(urls, 3))
    print(choice(people, 1))
    print(choice(people, 4, unique=True))
    

# Generated at 2022-06-12 01:38:29.876980
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(['a', 'b', 'c']) == 'a'
    assert choice(['a', 'b', 'c'], 1) == ['b']
    assert choice('abc', 2) == 'ab'
    assert choice(('a', 'b', 'c'), 5) == ('b', 'c', 'a', 'c', 'a')
    assert choice('aabbbccccddddd', 4, True) == 'cdbb'


# Generated at 2022-06-12 01:38:38.109591
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # nc
    choice=Choice(random=None)
    assert choice(items=['a', 'b', 'c'])=='c'
    assert choice(items=['a', 'b', 'c'], length=1)==['a']
    assert choice(items='abc', length=2)=='ba'
    assert choice(items=('a', 'b', 'c'), length=5)==('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True)=='cdba'
    try:
        choice(items=[], length=0)
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-12 01:38:41.527680
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.builtins import Choice
    choice = Choice()
    assert choice.__call__(items=['a', 'b', 'c'])


# Generated at 2022-06-12 01:38:51.161749
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """ Test case for Choice.__call__. """

    import pytest

    with pytest.raises(ValueError):
        choice = Choice()
        choice(items=[])
    with pytest.raises(TypeError):
        choice = Choice()
        choice(items=0)
    with pytest.raises(TypeError):
        choice = Choice()
        choice(items=[], length='str')
    with pytest.raises(ValueError):
        choice = Choice()
        choice(items=['a', 'b', 'c'], length=-1)
    with pytest.raises(ValueError):
        choice = Choice()
        choice(items=[1], unique=True)

    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ('a', 'b', 'c')


# Generated at 2022-06-12 01:39:02.288766
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    provider = Choice()
    result = provider(items=['a', 'b', 'c'])
    expected = 'c'
    assert result == expected
    result = provider(items=['a', 'b', 'c'], length=1)
    expected = ['a']
    assert result == expected
    result = provider(items='abc', length=2)
    expected = 'ba'
    assert result == expected
    result = provider(items=('a', 'b', 'c'), length=5)
    expected = ('c', 'a', 'a', 'b', 'c')
    assert result == expected
    result = provider(items='aabbbccccddddd', length=4, unique=True)
    expected = 'cdba'
    assert result == expected

# Generated at 2022-06-12 01:39:08.126056
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    print('Running Tests for Class Choice')
    choice = Choice()
    array = 'aabbccddeeffgghh'
    res = choice(array, 3)
    assert len(res) == 3, 'Expected length of 3, got {}'.format(len(res))
    assert isinstance(choice('abc', 2), str), 'Expected str, got {}'.format(type(choice('abc', 2)))


# Generated at 2022-06-12 01:39:12.546001
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for the methods __call__ of class Choice."""
    choices = ['a', 'b', 'c']
    choice = Choice()
    assert choice.choice(choices) == choice(choices)
    assert isinstance(choice.choice(choices), str)


# Generated at 2022-06-12 01:39:19.889849
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    assert choice(items=[1, 2, 3], length=2) == [3, 2]
    assert choice(items=(1, 2, 3), length=3) == (3, 1, 1)
    assert choice(items=[1, 2, 3], length=0) == 3
    assert choice(items=(1, 2, 3), length=0) == 2
    assert choice(items='abc', length=0) == 'c'
    assert choice(items='abc', length=2) == 'bc'

# Generated at 2022-06-12 01:39:20.397794
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-12 01:40:27.113143
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert c(items=['a', 'b', 'c']) == 'c'
    assert c(items=['a', 'b', 'c'], length=1) == ['a']
    assert c(items='abc', length=2) == 'ba'
    assert c(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert c(items='aabbbccccddddd', length=4, unique=True) == 'cdba'



# Generated at 2022-06-12 01:40:36.826208
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(
        items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:40:42.634963
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    assert choice(items=[], length=5) == []

# Generated at 2022-06-12 01:40:48.774274
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert isinstance(choice(['a', 'b', 'c']), str)
    assert isinstance(choice(['a', 'b', 'c'], 1), list)
    assert isinstance(choice('abc', 2), str)
    assert isinstance(choice(('a', 'b', 'c'), 5), tuple)
    assert isinstance(choice('aabbccddddd', 4, True), str)

# Generated at 2022-06-12 01:40:50.717130
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    choice(items=['a', 'b', 'c'])


# Generated at 2022-06-12 01:40:52.261523
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass
    # TODO: Write unit test for method __call__ of class Choice

# Generated at 2022-06-12 01:41:02.088888
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) in ['ba', 'ac', 'ab']
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    # TODO: Fix this
    #assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) in ['cdba', 'cbd', 'dbca']


# Generated at 2022-06-12 01:41:02.619246
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-12 01:41:03.143213
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-12 01:41:12.635864
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()