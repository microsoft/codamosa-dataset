

# Generated at 2022-06-12 01:36:02.558331
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test :code:`__call__(self, items, length=0, unique=False)` method.

        >> from mimesis import Choice
        >> choice = Choice()
        >> choice(items=['a', 'b', 'c'])
        'a'
        >> choice(items=['a', 'b', 'c'], length=1)
        ['c']
        >> choice(items='abc', length=2)
        'ac'
        >> choice(items=('a', 'b', 'c'), length=5)
        ('b', 'c', 'a', 'b', 'c')
        >> choice(items='aabbbccccddddd', length=4, unique=True)
        'abcd'

    :return: None
    """
    from mimesis import Choice
    choice = Choice()



# Generated at 2022-06-12 01:36:03.540759
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 01:36:10.131941
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    if __name__ == '__main__':
        # execute only if run as a script
        choice = Choice()
        print(choice(items=['a', 'b', 'c']))
        print(choice(items=['a', 'b', 'c'], length=1))
        print(choice(items='abc', length=2))
        print(choice(items=('a', 'b', 'c'), length=5))
        print(choice(items='aabbbccccddddd', length=4, unique=True))

if __name__ == '__main__':
    test_Choice___call__()

# Generated at 2022-06-12 01:36:17.112198
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert c.choice(items=['a', 'b', 'c']) == c(items=['a', 'b', 'c'])
    assert c.choice(items=['a', 'b', 'c'], length=1) == c(items=['a', 'b', 'c'], length=1)
    assert c.choice(items='abc', length=2) == c(items='abc', length=2)
    assert c.choice(items=('a', 'b', 'c'), length=5) == c(items=('a', 'b', 'c'), length=5)
    assert c.choice(items='aabbbccccddddd', length=4, unique=True) == c(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-12 01:36:25.291191
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method __call__."""
    from mimesis import Choice
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'a'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ab'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'babc'


# Generated at 2022-06-12 01:36:33.587359
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:36:37.561651
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TODO: Mimesis does not have a set test strategy.
    # Maybe unittest could be used in the future.

    # init
    choice = Choice()
    result = choice(items=['a', 'b', 'c', 'd', 'e'], length=2, unique=True)

    # assertion
    assert len(result) == 2
    assert type(result) == list



# Generated at 2022-06-12 01:36:49.394271
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert (
        c(['a', 'b', 'c']) in ['a', 'b', 'c']
    ), 'This should be one of a, b, c'
    assert c(['a', 'b', 'c'], 1) in [['a']], 'This should be one of [[a]]'
    assert c('abc', 2) in [
        'ab', 'ac', 'ba', 'bc', 'ca', 'cb'
    ], 'This should be one of ab ba ca ac bc cb'

# Generated at 2022-06-12 01:36:50.892241
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert c('aaaaabbbbb') in 'aaaaabbbbb'


# Generated at 2022-06-12 01:37:00.824150
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(['a', 'b', 'c'], 1) in [['a'], ['b'], ['c']]
    assert choice('abc', 2) in ['ba', 'bc', 'ab']
    assert choice(('a', 'b', 'c'), 5) in [('c', 'a', 'a', 'b', 'c'), ('c', 'a', 'b', 'a', 'c'), ('c', 'b', 'a', 'c', 'a')]
    assert choice('aabbbccccddddd', 4, True) in ['cdba', 'cbad', 'bcad']


# Generated at 2022-06-12 01:37:10.587398
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) == ['a'] or ['b'] or ['c']
    assert choice(items='abc', length=2) in ['ab', 'bc', 'ac']
    assert choice(items=('a', 'b', 'c'), length=5) == ('a', 'b', 'c', 'a', 'b')
    assert choice(items='aabbbccccddddd', length=4, unique=True) in ['abcc', 'bacd', 'abcd']
    try:
        choice(items=[], length=0)
    except ValueError:
        pass

# Generated at 2022-06-12 01:37:18.322492
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method `__call__` of class `Choice`."""
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ba', 'ca', 'cb']

# Generated at 2022-06-12 01:37:27.776225
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TODO: We should always return a list
    # items = [1]
    # length = 10
    # unique = True
    # Choice(items='aabbbccccddddd', length=4, unique=True)
    # res = Choice(items='aabbbccccddddd', length=4, unique=True)
    # assert res == ['a', 'a', 'b', 'b', 'c', 'c', 'c', 'c', 'd', 'd']
    # assert res == (1, 1, 1, 1, 1, 1, 1, 1, 1, 1)
    Sequence[Any]
    Choice.__call__(items='aabbbccccddddd', length=4, unique=True)



# Generated at 2022-06-12 01:37:34.713978
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    assert choice(['a', 'b', 'c']) == 'c'
    assert choice(['a', 'b', 'c'], 1) == ['a']
    assert choice('abc', 2) == 'ba'
    assert choice(('a', 'b', 'c'), 5) == ('c', 'a', 'a', 'b', 'c')
    assert choice('aabbbccccddddd', 4, unique=True) == 'cdba'


# Generated at 2022-06-12 01:37:35.173502
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert True

# Generated at 2022-06-12 01:37:43.720949
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test Choice with method __call__."""
    choice = Choice()
    assert isinstance(choice(items=['a', 'b', 'c']), str)
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert isinstance(choice(items=('a', 'b', 'c'), length=5), tuple)
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    assert choice(items=['a', 'b', 'c'], length=0) in ('a', 'b', 'c')
    assert choice(items=('a', 'b', 'c'), length=1) == ('a', )

# Generated at 2022-06-12 01:37:46.987883
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    expected = ['a']

    # This is the object we are testing
    our_choice = Choice()
    # This is the actual test
    our_choice(items = items, length = length, unique = unique) == expected

# Generated at 2022-06-12 01:37:57.827791
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ab', 'ac', 'bc']

# Generated at 2022-06-12 01:38:03.660668
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ('hello', 'how', 'are', 'you')
    length = 4
    unique = True
    a = Choice.__call__(items, length, unique)
    if (a == ('are', 'hello', 'you', 'how')):
        return True
    else:
        return False


# Generated at 2022-06-12 01:38:11.500996
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()

    item1 = choice(items=['a', 'b', 'c'])
    assert choice(items=['a', 'b', 'c']) == item1
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-12 01:38:17.837740
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    # TODO: Add more tests here
    assert True

# Generated at 2022-06-12 01:38:26.506768
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ab', 'ac', 'bc']

# Generated at 2022-06-12 01:38:33.595083
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert c(items=['a', 'b', 'c']) != ''
    assert c(items=['a', 'b', 'c'], length=1) == ['a']
    assert c(items='abc', length=2) == 'ba'
    assert c(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert c(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:38:44.341632
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from hypothesis import given
    from hypothesis import strategies as st

    from mimesis import Choice

    choice = Choice()

    # st.integers()
    @given(st.integers(min_value=0))
    def test_Choice___call___length(length: int) -> None:
        # st.lists(st.integers()).map(list)
        # non_empty_lists = st.lists(st.integers()).filter(lambda elems: elems)
        # data = non_empty_lists.map(list)
        # data = st.lists(st.integers(), min_size=1, max_size=10).map(list)
        data = st.lists(st.integers())


# Generated at 2022-06-12 01:38:46.583928
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from doctest import testmod
    testmod()


if __name__ == '__main__':
    # Unit test for method __call__ of class Choice
    test_Choice___call__()

# Generated at 2022-06-12 01:38:54.516970
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.typing import Sequence
    from . import Choice
    choice=Choice()

    # Test for TypeError: For non-sequence items or non-integer length.
    try:
        choice(items=None)
    except TypeError:
        pass
    except Exception as e:
        raise ValueError(e)
    try:
        choice(items='abc', length='abc')
    except TypeError:
        pass
    except Exception as e:
        raise ValueError(e)

    # Test for ValueError: If negative length or insufficient unique elements.
    try:
        choice(items=['a', 'b', 'c'], length=-1)
    except ValueError:
        pass
    except Exception as e:
        raise ValueError(e)

# Generated at 2022-06-12 01:39:02.750618
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'b'
    assert choice(items=['a', 'b', 'c'], length=5) == ['a', 'a', 'c', 'c', 'a']
    assert choice(items=('a', 'b', 'c'), length=5) == ('a', 'c', 'c', 'b', 'a')
    assert choice(items='abc', length=10) == 'ccccbabaca'
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'dcba'

# Generated at 2022-06-12 01:39:13.598102
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ["a", "b", "c"]
    length = 1
    assert Choice().__call__(items, length) == ["a"]
    items = "abc"
    length = 2
    assert Choice().__call__(items, length) == "ba"
    items = ('a', 'b', 'c')
    length = 5
    assert Choice().__call__(items, length) == ('c', 'a', 'a', 'b', 'c')
    items = 'aabbbccccddddd'
    length = 4
    assert Choice().__call__(items, length, unique=True) == 'cdba'
    try:
        Choice().__call__(42)
    except TypeError as e:
        assert str(e) == '**items** must be non-empty sequence.'

# Generated at 2022-06-12 01:39:22.457086
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    items = ['a', 'b', 'c']
    assert choice(items) in items
    assert choice(items, 0) in items
    assert choice(items, 1) in items
    assert choice(items, 2) in items
    assert len(choice(items, 4)) == 4
    assert len(choice(items, 5)) == 5
    assert len(choice(items, 100)) == 100

    assert choice(items, -1, unique=True) is None
    assert choice(items, 0, unique=True) in items
    assert choice(items, 1, unique=True) in items
    assert choice(items, 2, unique=True) in items
    assert len(choice(items, 4, unique=True)) == 4
    assert len(choice(items, 5, unique=True)) == 5

# Generated at 2022-06-12 01:39:31.925085
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice()(items=['a', 'b', 'c']) == 'c'
    assert Choice()(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice()(items='abc', length=2) == 'ba'
    assert Choice()(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice()(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-12 01:39:49.204452
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method ``__call__`` of class Choice."""
    # params = (items, length, unique)

# Generated at 2022-06-12 01:39:56.330870
# Unit test for method __call__ of class Choice

# Generated at 2022-06-12 01:40:01.658831
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c_obj =Choice()
    assert c_obj(items=['a', 'b', 'c']) == 'c'
    assert c_obj(items=['a', 'b', 'c'], length=1) == ['a']
    assert c_obj(items='abc', length=2) == 'ba'
    assert c_obj(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert c_obj(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:40:05.679506
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(['a', 'b', 'c']) == 'c'
    assert Choice().__call__(['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__('abc', length=2) == 'ba'
    assert Choice().__call__(('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__('aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-12 01:40:16.732789
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method __call__ of class Choice."""
    from mimesis.enums import Gender
    from mimesis.typing import Seed
    choice = Choice(seed=Seed(Gender.FEMALE.value))

    assert choice(items=['a', 'b', 'c']) == 'a'
    assert choice(items=['a', 'b', 'c'], length=1) == ['c']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('a', 'b', 'c', 'b', 'a')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdbb'

# Generated at 2022-06-12 01:40:25.090428
# Unit test for method __call__ of class Choice
def test_Choice___call__():  # -> None
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:40:26.106641
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TODO: Write test for method __call__ of class Choice
    pass

# Generated at 2022-06-12 01:40:37.846436
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from pickle import loads, dumps
    from mimesis.enums import Gender
    from mimesis.builtins import Person
    from mimesis.exceptions import NonUniqueError
    from mimesis.providers.generic import Choice
    c = Choice()

    seq = c(['a', 'b', 'c'], length=4)
    assert seq == ['a', 'b', 'c', 'b']

    seq = c(('a', 'b', 'c'), length=4)
    assert seq == ('a', 'b', 'c', 'c')

    seq = c(['a', 'b', 'c'], length=4, unique=True)
    assert seq == ['a', 'b', 'c', 'a']

    seq = c(('a', 'b', 'c'), length=4, unique=True)

# Generated at 2022-06-12 01:40:47.159577
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # test 1
    choice = Choice()
    x = choice(items=['a', 'b', 'c'])
    assert x == 'c'

    # test 2
    choice = Choice()
    x = choice(items=['a', 'b', 'c'], length=1)
    assert x == ['a']

    # test 3
    choice = Choice()
    x = choice(items='abc', length=2)
    assert x == 'ba'

    # test 4
    choice = Choice()
    x = choice(items=('a', 'b', 'c'), length=5)
    assert x == ('c', 'a', 'a', 'b', 'c')

    # test 5
    choice = Choice()
    x = choice(items='aabbbccccddddd', length=4, unique=True)


# Generated at 2022-06-12 01:40:52.601331
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    my_Choice = Choice()
    my_Choice(items=['a', 'b', 'c'])
    my_Choice(items=['a', 'b', 'c'], length=1)
    my_Choice(items='abc', length=2)
    my_Choice(items=('a', 'b', 'c'), length=5)
    my_Choice(items='aabbbccccddddd', length=4, unique=True)


# Generated at 2022-06-12 01:41:15.346432
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    # Test 1
    seq = ['a', 'b', 'c']
    assert callable(choice.__call__)
    assert choice.__call__(seq) in seq
    # Test 2
    seq = [1, 2, 3, 4, 5, 6]
    assert choice.__call__(seq,  length=1) in seq
    # Test 3
    seq = ['a', 'b', 'c']
    assert choice.__call__(seq,  length=1) in seq
    # Test 4
    seq = ['a', 'b', 'c']
    assert choice.__call__(seq,  length=2) in seq
    # Test 5
    seq = ['a', 'b', 'c']
    assert choice.__call__(seq,  length=3) in seq
    #

# Generated at 2022-06-12 01:41:20.109044
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    print(choice(items="HELLO"))
    print(choice(items="HELLO", length=1))
    print(choice(items="HELLO", length=1, unique=True))
    print(choice(items="HELLO", length=10, unique=True))


# Generated at 2022-06-12 01:41:26.122017
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:41:35.401693
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test function Choice.__call__()."""

    provider = Choice()
    # case 1
    items = ['a', 'b', 'c']
    assert provider(items) in items
    # case 2
    assert provider(items, 1) == ['a']
    # case 3
    assert provider(items, length=2) in ['ab', 'ac', 'ba', 'bc', 'ca', 'cb']
    # case 4

# Generated at 2022-06-12 01:41:45.217370
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice: Choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert len(choice(items=['a', 'b', 'c'], length=1)) == 1
    assert choice(items='abc', length=2) in ['ab', 'ac', 'bc']
    assert len(choice(items=('a', 'b', 'c'), length=5)) == 5

# Generated at 2022-06-12 01:41:51.160479
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    class AnyChoice:
        '''Mock object.'''
        def __init__(self, *args, **kwargs):
            pass
        def random(self):
            return AnyChoice()
        def choice(self, items):
            return items[0]

    class EmptyChoice:
        '''Mock object.'''
        def __init__(self, *args, **kwargs):
            pass
        def random(self):
            return EmptyChoice()
        def choice(self, items):
            return items[0]

    assert Choice().__call__(['apples', 'oranges']) == 'apples'
    assert Choice().__call__(['apples', 'oranges'], length=1) == ['apples']

# Generated at 2022-06-12 01:41:57.086850
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import pytest
    from . import choice

    items = 'abcdefghijklmnopqrstuvwxyz'

    result = choice(items)
    assert isinstance(result, str)
    assert len(result) == 1
    assert result in items

    result = choice(items, length=3)
    assert isinstance(result, str)
    assert len(result) == 3
    assert set(result) <= set(items)

    result = choice(items, length=len(items))
    assert isinstance(result, str)
    assert len(result) == len(items)
    assert set(result) == set(items)

    result = choice(items, length=100)
    assert isinstance(result, str)
    assert len(result) == 100
    assert set(result) == set(items)

   

# Generated at 2022-06-12 01:41:59.247140
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items = ['a', 'b', 'c'], length = 0, unique = False) == 'b'

# Generated at 2022-06-12 01:42:05.466969
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import pytest
    c = Choice()
    assert c() == 'c'
    assert c(length=1) == ['a']
    assert c(length=2) == 'ba'
    assert c(length=5) == ('c', 'a', 'a', 'b', 'c')
    assert c(length=4, unique=True) == 'cdba'
    assert c(length=4, unique=True) == 'cdba'
    assert c(length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:42:08.864647
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import random
    from mimesis.builtins import Seed, SeedFactory
    choice = Choice()
    choice = choice(items=["a", "b", "c"], length=1)
    seed = SeedFactory(seed=Seed())
    seed.set_state(seed.get_state())
    random.setstate(Seed.get_state())
    random.choice(["a", "b", "c"])
    print(choice)