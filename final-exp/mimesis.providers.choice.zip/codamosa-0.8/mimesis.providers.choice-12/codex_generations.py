

# Generated at 2022-06-12 01:36:07.387023
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice

    choice = Choice()

    # items='abc'
    items = 'abc'
    items_type = 'str'
    length = 1
    unique = True

    # When length is 1, one random element from the set items is returned.
    response = choice(items=items, length=length)
    assert isinstance(response, type(items))
    assert response in items

    response = choice(items=items, length=length, unique=unique)
    assert isinstance(response, type(items))
    assert response in items

    # When length is different from 1, a sequence of length length is
    # returned, which is of the same type as items.
    length = 3
    response = choice(items=items, length=length)
    assert isinstance(response, type(items))

# Generated at 2022-06-12 01:36:10.980604
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    choice = Choice()
    assert choice(items, length=length, unique=unique) == 'a'

# Generated at 2022-06-12 01:36:17.930853
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test function for method __call__ of class Choice."""
    from mimesis import Choice
    from mimesis.enums import Gender
    from mimesis.exceptions import NonEnumerableError

    choice = Choice()

    assert isinstance(choice(items=[1, 2, 3]), int)
    assert choice(items=[1, 2, 3, 4, 5], length=5) == [5, 1, 1, 2, 4]
    assert choice(items=[1, 2, 3, 4, 5], length=0) == 3
    assert ''.join(choice(items='aabbbccccddddd', length=4, unique=True)) ==\
        'cdba'

    choice = Choice('en')
    assert isinstance(choice.gender, Gender)

# Generated at 2022-06-12 01:36:20.130814
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert isinstance(Choice().__call__(), str)
    assert isinstance(Choice().__call__(length=1), list)



# Generated at 2022-06-12 01:36:28.169364
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-12 01:36:37.332480
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    from collections.abc import Sequence

    choice = Choice()

    assert not isinstance(0, Sequence)
    assert isinstance([] , Sequence)
    assert isinstance((), Sequence)
    assert isinstance('', Sequence)
    assert isinstance([1], Sequence)
    assert isinstance(('a','b'), Sequence)
    assert isinstance('abc', Sequence)
    
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')

# Generated at 2022-06-12 01:36:49.150178
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from random import randint
    from unittest import TestCase

    from . import UNIQUE
    from . import NON_UNIQUE

    choice = Choice()

    # Test a randomly-chosen element from a sequence.
    for _ in range(UNIQUE):
        n = randint(1, UNIQUE)
        items = [x for x in range(n)]
        length = 0
        result = choice(items=items, length=length)
        TestCase().assertIn(result, items, 'Err: __call__(items, length)')

    # Test a randomly-chosen sequence of elements from a sequence.
    for _ in range(UNIQUE):
        n = randint(1, UNIQUE)
        items = [x for x in range(n)]

# Generated at 2022-06-12 01:36:59.969967
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    choice(items=['a', 'b', 'c'])
    choice(items=['a', 'b', 'c'], length=1)
    choice(items='abc', length=2)
    choice(items=('a', 'b', 'c'), length=5)
    choice(items='aabbbccccddddd', length=4, unique=True)
    try:
        choice(items='abc', length=1.5)
    except TypeError:
        print("passed: __call__: TypeError: **length** must be integer.")
    try:
        choice(items=1.5, length=1)
    except TypeError:
        print("passed: __call__: TypeError: **items** must be non-empty sequence.")

# Generated at 2022-06-12 01:37:09.959104
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Tests for the method __call__ of class Choice."""
    with pytest.raises(TypeError, message="The variable length must be integer"):
        assert Choice(locale='es').__call__(items=['a', 'b', 'c'], length=0.6, unique=False)
    with pytest.raises(TypeError, message="The variable items must be non-empty sequence"):
        assert Choice(locale='es').__call__(items='aabbbccccddddd', length={}, unique=True)
    with pytest.raises(ValueError, message="The variable items must be a non-empty sequence"):
        assert Choice(locale='es').__call__(items=[], length=5, unique=False)

# Generated at 2022-06-12 01:37:17.949621
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from hypothesis import given
    from hypothesis import strategies as st
    from mimesis import Choice
    from mimesis.typing import SequenceItems

    choice = Choice()
    choice_int = Choice()
    lst = st.lists(st.integers())
    choice_int(items=lst)
    choice(items=st.integers())
    st.lists(st.integers())

    @given(st.lists(st.integers()))
    def test_Choice___call__(items):
        assert isinstance(choice(items=items), int)

    @given(st.lists(st.integers()).map(lambda x: x[:5]))
    def test_Choice___call__(items):
        assert isinstance(choice_int(items=items, length=1), int)

# Generated at 2022-06-12 01:37:29.827246
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    """ Tests the method __call__ of class Choice. """

    # Test a simple case
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'

    # Test cases with length of list
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')

    # Test case with unique set to true
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

    # Test if the items is a list of dict

# Generated at 2022-06-12 01:37:33.815838
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # noinspection DuplicatedCode
    try:
        choice = Choice()
        choices = choice(items=['a', 'b', 'c'], length=1)
        assert type(choices) == list
    except Exception as e:
        exc = e
        print(exc)

test_Choice___call__()

# Generated at 2022-06-12 01:37:43.400970
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    ch = Choice()
    assert ch(items=[1,2,3]) == 2
    assert ch(items=[1,2,3], length=1) == [1]
    assert ch(items='ab', length=4) == 'aaab'
    assert ch(items='abbbbc', length=2, unique=True) == 'cb'
    assert ch(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')

    try:
        ch(items={1,2,3})
    except TypeError as e:
        assert e.args[0] == '**items** must be non-empty sequence.'


# Generated at 2022-06-12 01:37:54.190641
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    if __name__ == '__main__':
        from argparse import ArgumentParser, Namespace

    from mimesis import Choice

    parser = ArgumentParser()
    parser.add_argument(
        '-l', '--length', type=int, default=1,
        help='Length of sequence or number of elements.'
    )
    parser.add_argument(
        '-u', '--unique', action='store_true', default=False,
        help='If True, ensures provided elements are unique.'
    )
    parser.add_argument(
        'items', nargs='+',
        help='Non-empty sequence (list, tuple or string) of items.'
    )
    args = parser.parse_args()  # type: Namespace

    choice = Choice()  # type: Choice

# Generated at 2022-06-12 01:38:01.268366
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ba', 'ca', 'bc']
    assert choice(items=('a', 'b', 'c'), length=5) in [('a', 'b', 'a', 'c', 'c'), ('a', 'b', 'c', 'b', 'a'), ('c', 'a', 'a', 'b', 'c')]

# Generated at 2022-06-12 01:38:06.733718
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    data = {'items': [['a', 'b', 'c'],
                      ['a', 'b', 'c'],
                      'abc',
                      ('a', 'b', 'c'),
                      'aabbbccccddddd'],
            'length': [1, 5, 2, 5, 4],
            'unique': [False, False, False, False, True]}
    return data


# Generated at 2022-06-12 01:38:17.095490
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person
    from mimesis.providers.structures import Structure
    from mimesis.providers.text import Text
    from mimesis.providers.utils import Utilities

    # Test for example with Integer
    c = Choice()
    number = c(items=range(100))
    assert isinstance(number, int)
    assert number < 100

    # Test for example with String
    word = c(items='abcdefgh')
    assert isinstance(word, str)
    assert len(word) == 1

    # Test for example with Tuple

# Generated at 2022-06-12 01:38:23.129306
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice

    choice = Choice()

    choice(items=['a', 'b', 'c'])
    choice(items=['a', 'b', 'c'], length=1)
    choice(items='abc', length=2)
    choice(items=('a', 'b', 'c'), length=5)
    choice(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-12 01:38:30.754939
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    cls = Choice()
    items = ['a', 'b', 'c']
    length = 1
    unique = True
    assert callable(cls.__call__)
    assert cls.__call__(items=items) in items
    assert len(cls.__call__(items=items, length=length)) == length
    assert len(cls.__call__(items=items, length=length, unique=unique)) == length
    assert len(set(cls.__call__(items=items, length=length, unique=unique))) == length

# Generated at 2022-06-12 01:38:37.466669
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ('a', 'b', 'c')
    assert choice(items=['a', 'b', 'c'], length=1) in (['a'], ['b'], ['c'])
    assert choice(items='abc', length=2) in ('ab', 'ac', 'bc')
    assert choice(items=('a', 'b', 'c'), length=5) in (('a', 'b', 'c', 'b', 'c'), ('a', 'a', 'b', 'c', 'c'), ('a', 'b', 'a', 'b', 'c'))
    assert choice(items='aabbbccccddddd', length=4, unique=True) in ('cdba', 'cadb', 'caab')

# Generated at 2022-06-12 01:38:52.589099
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=('a', 'b', 'c')) in ('a', 'b', 'c')
    assert Choice().__call__(items='abc') in ('a', 'b', 'c')
    l = Choice().__call__(items='abc', length=2)
    assert len(l) == 2 and set(l).issubset(set('abc'))
    t = Choice().__call__(items=('a', 'b', 'c', 'd'), length=3)
    assert len(t) == 3 and set(t).issubset(set('abcd'))
    s = Choice().__call__(items='aabbccdd', length=5, unique=True)

# Generated at 2022-06-12 01:39:03.812381
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(['a', 'b', 'c']) == 'c'
    assert Choice().__call__(['a', 'b', 'c'], 1) == ['a']
    assert Choice().__call__('abc', 2) == 'ba'
    assert Choice().__call__(('a', 'b', 'c'), 5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__('aabbbccccddddd', 4, True) == 'cdba'
    # TODO: Move assert to docstring
    # assert Choice().__call__(['a'], 1, True)
    # assert Choice().__call__()
    # assert Choice().__call__((), 1)
    # assert Choice().__call__('', 1)
    assert Choice().__call

# Generated at 2022-06-12 01:39:14.868222
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    print(choice(items=['a', 'b', 'c']))
    print(choice(items=['a', 'b', 'c'], length=1))
    print(choice(items='abc', length=2))
    print(choice(items=('a', 'b', 'c'), length=5))
    print(choice(items='aabbbccccddddd', length=4, unique=True))
    try:
        print(choice(items='abc', length='d'))
    except TypeError as e:
        print(e)
    try:
        print(choice(items=[], length=0))
    except ValueError as e:
        print(e)

# Generated at 2022-06-12 01:39:19.820993
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    c = Choice()
    assert isinstance(c(items=[1, 2, 3]), int)
    assert isinstance(c(items=[1, 2, 3], length=1), list)
    assert isinstance(c(items=[1, 2, 3], length=4), list)


# Generated at 2022-06-12 01:39:22.797344
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Testing method __call__ of class Choice."""
    choice = Choice()
    assert len(choice('abc', length=5)) == 5
    assert choice('abc', length=1)[0] == 'b'
    assert len(choice('abc', length=0)) == 1

# Generated at 2022-06-12 01:39:34.941579
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice(seed=123)
    assert choice.choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice.choice(items=['a', 'b', 'c'], length=2) == ['a', 'a']
    assert choice.choice(items=['a', 'b', 'c'], length=3) == ['a', 'a', 'a']
    assert choice.choice(items=['a', 'b', 'c'], length=4) == ['a', 'a', 'a', 'a']
    assert choice.choice(items='abc', length=2) == 'ba'
    assert choice.choice(items='abc', length=3) == 'bab'
    assert choice.choice(items='abc', length=4) == 'babc'

# Generated at 2022-06-12 01:39:45.558216
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    test_items = ('1', '2', '3', '4', '5')
    try:
        test_length = -1
        choice(items=test_items, length=test_length)
        assert False
    except ValueError:
        pass

    test_items = 'abc'
    test_length = 0
    assert choice(items=test_items, length=test_length) in test_items

    test_items = (1, 2, 3)
    test_length = 4
    assert type(choice(items=test_items, length=test_length)) == tuple

    test_items = 'bca'
    test_length = 3
    test_unique = True
    assert choice(items=test_items, length=test_length,
                  unique=test_unique) == 'abc'


# Generated at 2022-06-12 01:39:51.596401
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method __call__ of class Choice."""
    import pytest

    @pytest.mark.parametrize('param, expected', [
        ([1, 2, 3], 1),
        (range(1, 6), 2),
        ([1, 2, 3], 3),
        (range(1, 6), 4),
    ])
    def test(param, expected):
        c = Choice()
        result = c(param, expected)
        assert result == expected


# Generated at 2022-06-12 01:39:58.340011
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert c(['a', 'b', 'c']) in ['a', 'b', 'c']
    assert c(['a', 'b', 'c'], length=1) == ['a']
    assert c('abc', length=2) in ['aa', 'bb', 'cc', 'ac', 'ab', 'ba', 'bc', 'cb', 'ca']
    assert len(c(('a', 'b', 'c'), length=5)) == 5
    assert c('aabbbccccddddd', length=4, unique=True) in 'abcd'


# Generated at 2022-06-12 01:40:03.283358
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-12 01:40:25.672290
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    # Test raw sequence and length.
    test_items = ['a', 'b', 'c']  # type: ignore
    test_length = 3

    choice = Choice()
    result = choice(items=test_items, length=test_length)

    assert len(result) == test_length  # type:ignore
    assert len(set(result)) == len(test_items)  # type:ignore

    # Test string object and length.
    test_items = 'abc'  # type: ignore
    test_length = 2

    choice = Choice()
    result = choice(items=test_items, length=test_length)

    assert isinstance(result, str)
    assert len(result) == test_length
    assert len(set(result)) == len(test_items)  # type:ignore

    # Test list and length

# Generated at 2022-06-12 01:40:31.136317
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from random import randint
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.list import List

    class TestChoice(BaseProvider):
        __provider__ = Choice

    choice = TestChoice()
    data = List()

    for i in range(100):
        number = randint(0, 10)
        result = choice(data.uniform_list(number), length=number)
        print(result)

# Generated at 2022-06-12 01:40:41.574206
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().choice(items=['a', 'b', 'c']) in ('a', 'b', 'c'), 'a'
    assert Choice().choice(items=['a', 'b', 'c'], length=1) in (['a'], ['b'], ['c']), 'b'
    assert Choice().choice(items='abc', length=2) in ('ab', 'ac', 'ba', 'bc', 'ca', 'cb'), 'c'

# Generated at 2022-06-12 01:40:49.678803
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # A random choice from items in a sequence. Base test.
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']

    # A random choice from items in a sequence. Length specified.
    choice = Choice()
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]

    # A random choice from items in a sequence. Specified unique elements.
    choice = Choice()
    assert choice(items='abc', length=2, unique=True) in ['ab', 'ac', 'bc']



# Generated at 2022-06-12 01:40:55.124508
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method __call__ of class Choice."""
    pc = Choice()
    pc(items=['a', 'b', 'c'])
    pc(items=['a', 'b', 'c'], length=1)
    pc(items='abc', length=2)
    pc(items=('a', 'b', 'c'), length=5)
    pc(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-12 01:41:05.087255
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    cls = Choice()
    assert cls(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert cls(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert cls(items='abc', length=2) in ['ba', 'ab', 'ac']
    assert cls(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert cls(items='aabbbccccddddd', length=4, unique=True) in ['cdba', 'cbad', 'cbda', 'cabd', 'cadb', 'cdab', 'cbad', 'cbda']


# Generated at 2022-06-12 01:41:14.172832
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice(seed=10)

    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=['a', 'b', 'c'], length=3) == ['c', 'b', 'a']
    assert choice(items=['a', 'b', 'c'], length=3, unique=True) == ['c', 'b', 'a']
    assert choice(items=['a', 'b', 'c'], length=5) == ['c', 'a', 'a', 'b', 'c']

# Generated at 2022-06-12 01:41:19.782123
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    test_instance = Choice()
    test_call_1_result = test_instance(items=['a', 'b', 'c'])
    assert isinstance(test_call_1_result, str)
    test_call_2_result = test_instance(items=['a', 'b', 'c'], length=1)
    assert isinstance(test_call_2_result, list)
    test_call_3_result = test_instance(items='abc', length=2)
    assert isinstance(test_call_3_result, str)
    test_call_4_result = test_instance(items=('a', 'b', 'c'), length=5)
    assert isinstance(test_call_4_result, tuple)

# Generated at 2022-06-12 01:41:27.206256
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""

# Generated at 2022-06-12 01:41:29.469939
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TODO: Make assertion
    choice = Choice()
    assert choice(items=['a', 'b', 'c'])

