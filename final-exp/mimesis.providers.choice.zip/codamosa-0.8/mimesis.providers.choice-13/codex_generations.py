

# Generated at 2022-06-12 01:35:51.283119
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TODO: Rename, split and document this method
    import doctest
    doctest.testmod(verbose=True)


# Generated at 2022-06-12 01:35:51.957719
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Example of using the test method."""
    # TODO: write this
    pass

# Generated at 2022-06-12 01:35:53.483616
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TODO: Should be fixed. Return string instead of list
    assert Choice().__call__(['a', 'b', 'c']) == 'c'



# Generated at 2022-06-12 01:36:03.769381
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    assert choice.choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice.choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice.choice(items='abc', length=2) in ['ba', 'ab', 'cb', 'ac', 'ca']
    assert choice.choice(items=('a', 'b', 'c'), length=5) in [('c', 'a', 'a', 'b', 'c'), ('a', 'c', 'c', 'a', 'b'), ('b', 'c', 'a', 'a', 'c')]

# Generated at 2022-06-12 01:36:09.773906
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    choice = Choice()
    assert choice(['a', 'b', 'c']) == 'c'
    assert choice(['a', 'b', 'c'], 1) == ['a']
    assert choice('abc', 2) == 'ba'
    assert choice(('a', 'b', 'c'), 5) == ('c', 'a', 'a', 'b', 'c')
    assert choice('aabbbccccddddd', 4, True) == 'cdba'


# Generated at 2022-06-12 01:36:15.411688
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:36:23.007590
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-12 01:36:25.575875
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    result = choice(items=['a','b','c'], length=2)
    print(result)


# Generated at 2022-06-12 01:36:35.709853
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for Choice.__call__() method."""
    choice = Choice()

    # Providing a length of 0 means that a randomly-selected single element
    # from **items** is returned (not a sequence containing this element).
    assert choice(items=['a', 'b', 'c'], length=0) in 'abc'

    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')

    # When **unique** is set to True, returned elements are guaranteed to be
    # unique.

# Generated at 2022-06-12 01:36:47.560247
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TODO: Fix this test
    pass
    #from mimesis.enums import Gender
    #from mimesis.builtins import RussiaSpecProvider
    #from mimesis.builtins import USASpecProvider
    #from mimesis.builtins import UKSpecProvider
    #from mimesis.builtins import JapanSpecProvider
    #from mimesis.builtins import SpainSpecProvider
    #from mimesis.builtins import ItalySpecProvider
    #from mimesis.builtins import GermanySpecProvider
    #from mimesis.builtins import FranceSpecProvider
    #from mimesis.builtins import MexicoSpecProvider
    #from mimesis.builtins import BrazilSpecProvider
    #from mimesis.builtins import CanadaSpecProvider
    #from mimesis.builtins import AustraliaSpecProvider
    #from mimesis

# Generated at 2022-06-12 01:37:10.010671
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice=Choice()
    # Call the method with 'a', 'b', 'c' and 0 as the argument and it will return 'c' or Likewise for length=1
    assert choice(['a', 'b', 'c'],0)=='c' or choice(['a', 'b', 'c'],length=1)==['a']
    # call the method with 'abc' as items and 2 as length and it will return 'ba'
    assert choice('abc',length=2)=='ba'
    # call the method with ('a', 'b', 'c') as items and 5 as length and it will return ('c', 'a', 'a', 'b', 'c')

# Generated at 2022-06-12 01:37:10.556791
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert True

# Generated at 2022-06-12 01:37:13.947129
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 1
    unique = True
    result = choice(items=items, length=length, unique=unique)
    assert type(result) is list
    assert len(result) == length


# Generated at 2022-06-12 01:37:25.687382
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method __call__ of class Choice.

    This test is for testing the method __call__ of class Choice, in order to 
    test if the output of random choice from list of items of length m is n, 
    where n is less than or equal to m.

    """
    # Initialization of the class with default constructor.
    choice = Choice()


    items = ['a', 'b', 'c']
    # Generating random choice from list of items and length = 1.
    assert choice(items, length=1) <= items
    # Generating random choice from list of items and length = 2.
    assert choice(items, length=2) <= items
    # Generating random choice from list of items and length = 3.
    assert choice(items, length=3) <= items
    # Generating random choice from list of items and length

# Generated at 2022-06-12 01:37:36.837896
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) in ['ab', 'ba', 'cb', 'bc', 'ca', 'ac']
    assert len(choice(items='abcdefghijklmnopqrstuvwxyz', length=5)) == 5

# Generated at 2022-06-12 01:37:47.436165
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    choice = Choice()
    try:
        choice(items=[])
    except ValueError:
        pass
    else:
        assert False # Should've raised ValueError
    try:
        choice(items='', length=0)
    except ValueError:
        pass
   

# Generated at 2022-06-12 01:37:56.955385
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.providers import Choice
    choice = Choice()
    result = choice(items=['a', 'b', 'c'])
    assert isinstance(result, str)
    result = choice(items=['a', 'b', 'c'], length=1)
    assert isinstance(result, list)
    result = choice(items='abc', length=2)
    assert isinstance(result, str)
    result = choice(items=('a', 'b', 'c'), length=5)
    assert isinstance(result, tuple)
    result = choice(items='aabbbccccddddd', length=4, unique=True)
    assert isinstance(result, str)

# Generated at 2022-06-12 01:38:07.987898
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Test **items** is empty, should return an exception
    choice = Choice()
    try:
        choice(items=[], length=1)
    except Exception as err:
        assert err.args[0] == '**items** must be a non-empty sequence.'

    # Test **items** is not a sequence, should return an exception
    try:
        choice(items=1, length=1)
    except Exception as err:
        assert err.args[0] == '**items** must be non-empty sequence.'

    # Test **length** is not integer and **items** is a list, should return exception
    try:
        choice(items=['a', 'b', 'c'], length=1.0)
    except Exception as err:
        assert err.args[0] == '**length** must be integer.'

    # Test

# Generated at 2022-06-12 01:38:18.237861
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    provider = Choice()
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    result = provider(items, length, unique)
    assert result in items
    length = 2
    result = provider(items, length, unique)
    assert len(result) == length
    assert set(result).issubset(items)
    length = 4
    unique = True
    result = provider(items, length, unique)
    assert len(result) == length
    assert set(result).issubset(items)
    assert len(set(result)) == length
    items = ()
    with pytest.raises(TypeError):
        provider(items, length, unique)
    items = []
    with pytest.raises(ValueError):
        provider(items, length, unique)

# Generated at 2022-06-12 01:38:26.679229
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import sys, os
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
    import mimesis.base
    choice = Choice('en')

    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    raise mimesis.base.MethodNot

# Generated at 2022-06-12 01:38:50.192601
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    c = Choice()
    assert isinstance(c(items=['a'], length=0, unique=False), str)
    assert isinstance(c(items=(), length=0, unique=False), str)
    assert isinstance(c(items='', length=0, unique=False), str)
    assert isinstance(c(items=['a'], length=0, unique=True), str)
    assert isinstance(c(items=(), length=0, unique=True), str)
    assert isinstance(c(items='', length=0, unique=True), str)

    assert isinstance(c(items=['a'], length=1, unique=False), list)
    assert isinstance(c(items=(), length=1, unique=False), list)
   

# Generated at 2022-06-12 01:39:01.535865
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    # TODO: Test for non-unique items
    from mimesis import Choice

    choice = Choice()
    items = ['a', 'b', 'c']
    choices = choice(items=items)
    assert choices

    choices = choice(items=items, length=1)
    assert isinstance(choices, list) and len(choices) == 1

    choices = choice(items=items, length=2)
    assert isinstance(choices, list) and len(choices) == 2

    choices = choice(items='abc', length=2)
    assert isinstance(choices, str) and len(choices) == 2

    choices = choice(items=('a', 'b', 'c'), length=3)

# Generated at 2022-06-12 01:39:07.562313
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c'])
    assert choice(items=['a', 'b', 'c'], length=1)
    assert choice(items='abc', length=2)
    assert choice(items=('a', 'b', 'c'), length=5)
    assert choice(items='aabbbccccddddd', length=4, unique=True)


# Generated at 2022-06-12 01:39:16.534989
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    ret = choice(items=['a', 'b', 'c'])
    assert isinstance(ret, str)
    ret = choice(items=['a', 'b', 'c'], length=1)
    assert isinstance(ret, list)
    ret = choice(items='abc', length=2)
    assert isinstance(ret, str)
    ret = choice(items=('a', 'b', 'c'), length=5)
    assert isinstance(ret, tuple)
    ret = choice(items='aabbbccccddddd', length=4, unique=True)
    assert isinstance(ret, str)

# Generated at 2022-06-12 01:39:23.695578
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.builtins import Choice
    choice = Choice(seed=123)
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

    # Raise error for non-sequence items
    from mimesis.exceptions import NonSequenceTypeError
    from mimesis.builtins import Choice
    choice = Choice(123)

# Generated at 2022-06-12 01:39:35.191807
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    test_case_1429 = [None, None, None]
    result_1429 = Choice().__call__(test_case_1429[0], length=test_case_1429[1], unique=test_case_1429[2])
    expected_1429 = ValueError()
    assert type(result_1429) == type(expected_1429)

    test_case_1430 = [None, None, None]
    result_1430 = Choice().__call__(test_case_1430[0], length=test_case_1430[1], unique=test_case_1430[2])
    expected_1430 = ValueError()
    assert type(result_1430) == type(expected_1430)

    test_case_1431 = [None, None, None]
    result_1431 = Choice

# Generated at 2022-06-12 01:39:45.960662
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    assert Choice()(items=[1, 2, 3]) == 3
    assert Choice()(items=[1, 'a', 2, 3], length=1) == [2]
    assert Choice()(items='abc', length=2) == 'bc'
    assert Choice()(items='aabbbccccddddd', length=4, unique=True) == 'bdca'
    assert Choice()(items=[1, 2, 3], length=3, unique=True) == [2, 1, 3]
    assert Choice()(items=(1, 2, 3, 4, 5)) in [1, 2, 3, 4, 5]
    assert Choice()(items=(1, 2, 3, 4)) == 4
    assert Choice()(items=[1, 2, 3], length=1) == [1]

# Generated at 2022-06-12 01:39:54.836617
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    obj = Choice()
    assert isinstance(obj, Choice)
    assert obj.__call__(items=['a', 'b', 'c'], length=5) == ['a', 'a', 'c', 'b', 'c']
    assert obj.__call__(items=('a', 'b', 'c'), length=5) == ('b', 'b', 'a', 'b', 'c')
    assert obj.__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    assert obj.__call__(items=('a', 'b', 'c'), length=0) == 'a'
    assert obj.__call__(items=['a', 'b', 'c'], length=1) == ['a']

# Generated at 2022-06-12 01:39:56.720438
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    p = Choice()
    print(p.__call__(["a","b","c"]))


# Generated at 2022-06-12 01:40:03.329183
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    from mimesis import Choice
    choice = Choice()

    # Test for TypeError
    items = 1
    length = 'a'
    # choice(items, length)
    # Traceback (most recent call last):
    # ...
    # TypeError: **items** must be non-empty sequence.
    # choice(items, length)
    # Traceback (most recent call last):
    # ...
    # TypeError: **length** must be integer.

    # Test for ValueError
    items = []
    # choice(items)
    # Traceback (most recent call last):
    # ...
    # ValueError: **items** must be a non-empty sequence.
    # choice(items, length)
    # Traceback (most recent call last):
    # ...

# Generated at 2022-06-12 01:40:19.007480
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items='abc', length=2) in ['aa', 'bb', 'cc']
    assert choice(items='abc', length=2, unique=True) in ['ab', 'ac', 'bc']
    assert choice(items=(1, 2, 3), length=5) in [(1, 2, 3, 1, 2), (1, 2, 3, 1, 3), (1, 2, 3, 2, 3)]
    assert choice(items=(1, 2, 3), length=5) not in [(4, 2, 3, 1, 2), (1, 2, 3, 4, 5), (1, 2, 3, 6, 7)]

# Generated at 2022-06-12 01:40:26.544263
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c'], length=3) == ['c', 'b', 'b']
    assert choice(items=['a', 'b', 'c'], length=0) == 'c'
    assert choice(items=('a', 'b', 'c'), length=2) == ('a', 'c')
    assert choice(items='abc', length=2) == 'cc'
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'bdcac'


# Generated at 2022-06-12 01:40:38.247063
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method Choice.__call__."""
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    choice = Choice(locale='en')
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) in ['ab', 'ac', 'ba', 'bc',
                                              'ca', 'cb']

# Generated at 2022-06-12 01:40:47.761680
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = Choice(seed=0).__call__(items=['a', 'b', 'c'])
    assert items == 'c'
    items = Choice(seed=0).__call__(['a', 'b', 'c'], length=1)
    assert items == ['a']
    items = Choice(seed=0).__call__('abc', length=2)
    assert items == 'ba'
    items = Choice(seed=0).__call__(('a', 'b', 'c'), length=5)
    assert items == ('c', 'a', 'a', 'b', 'c')
    items = Choice(seed=0).__call__('aabbbccccddddd', length=4, unique=True)
    assert items == 'cdba'


# Generated at 2022-06-12 01:40:50.954402
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 5
    expected = ['c', 'a', 'a', 'b', 'c']
    assert Choice(items=items, length=length) == expected


# Generated at 2022-06-12 01:41:01.926100
# Unit test for method __call__ of class Choice
def test_Choice___call__():
        import pytest
        from mimesis.exceptions import NonDataFieldError

        choice = Choice()
        with pytest.raises(TypeError):
            choice(items=['a', 'b', 'c'])
        with pytest.raises(TypeError):
            choice(items=['a', 'b', 'c'], length=1)
        with pytest.raises(TypeError):
    	    choice(items=None, length=2)
        with pytest.raises(TypeError):
    	    choice(items='abc', length=2)
        with pytest.raises(TypeError):
    	    choice(items=('a', 'b', 'c'), length=5)

# Generated at 2022-06-12 01:41:11.507742
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from random import choice
    from string import ascii_uppercase
    choice_ = Choice()
    assert choice_('abc') in {'a', 'b', 'c'}
    assert choice(('a', 'b', 'c')) in {'a', 'b', 'c'}
    assert choice_(ascii_uppercase, length=1) == ['Q']
    assert choice_(ascii_uppercase, length=9999)  # Do not check length

# Generated at 2022-06-12 01:41:17.111037
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Example 1
    choice = Choice()
    result = choice(items=['a', 'b', 'c'])
    print(result)

    # Example 2
    result = choice(items=['a', 'b', 'c'], length=1)
    print(result)

    # Example 3
    result = choice(items='abc', length=2)
    print(result)

    # Example 4
    result = choice(items=('a', 'b', 'c'), length=5)
    print(result)

    # Example 5
    result = choice(items='aabbbccccddddd', length=4, unique=True)
    print(result)

# Generated at 2022-06-12 01:41:24.158526
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(["a", "b", "c"]) == "c"
    assert Choice().__call__(["a", "b", "c"], 1) == ["a"]
    assert Choice().__call__("abc", 2) == "ba"
    assert Choice().__call__(('a', 'b', 'c'), 5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__("aabbbccccddddd", 4, True) == "cdba"



# Generated at 2022-06-12 01:41:34.862490
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    print('Testing Choice.__call__')
    c = Choice()
    print('choice(items=["a", "b", "c"])')
    assert c(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    print('choice(items=["a", "b", "c"], length=1)')
    assert c(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    print('choice(items="abc", length=2)')
    assert c(items='abc', length=2) in ['ba', 'cb', 'ac']
    print('choice(items=("a", "b", "c"), length=5)')
    assert c(items=('a', 'b', 'c'), length=5)