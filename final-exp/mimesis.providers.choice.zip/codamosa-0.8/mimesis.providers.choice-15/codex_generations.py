

# Generated at 2022-06-12 01:35:53.127717
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 01:36:03.398958
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    obj = Choice()
    tupl = ('one', 'two', 'three')
    assert obj(tupl) in tupl
    assert obj(tupl, 2) in tupl
    assert obj(tupl, 5) in tupl
    assert obj(tupl, 1) in tupl
    assert obj(tupl, length=2) in tupl
    assert obj(tupl, length=5) in tupl
    assert obj(tupl, length=1) in tupl
    assert obj('abc') in tupl
    assert obj('abc', 2) in tupl
    assert obj('abc', 5) in tupl
    assert obj('abc', 1) in tupl
    assert obj('abc', length=2) in tupl
    assert obj('abc', length=5) in tupl

# Generated at 2022-06-12 01:36:11.741554
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method Choice.__call__."""
    assert Choice().choice(['a', 'b', 'c']) == 'b'
    assert Choice().choice(['a', 'b', 'c'], 0) == 'b'
    assert Choice().choice(['a', 'b', 'c'], 1) == ['a']
    assert Choice().choice(['a', 'b', 'c'], 2) == ['c', 'b']
    assert Choice().choice(['a', 'b', 'c'], 2, 0) == ['a', 'c']
    assert Choice().choice(['a', 'b', 'c'], 2, 1) == ['b', 'a']
    assert Choice().choice(['a', 'b', 'c'], 3, 1) == ['b', 'a', 'a']

# Generated at 2022-06-12 01:36:19.185483
# Unit test for method __call__ of class Choice
def test_Choice___call__():
  items = 'aabbbccccddddd'
  length = 0
  unique = False
  test = Choice()
  expected = test.random.choice(items)
  actual = test(items=items, length=length, unique=unique)
  assert(expected == actual)
  
  length = 1
  expected = test.random.sample(items, length)
  actual = test(items=items, length=length, unique=unique)
  assert(expected == actual)

# Generated at 2022-06-12 01:36:29.977335
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender
    from mimesis.providers.link import Link
    from mimesis.providers.name import Name

    c = Choice()

    items = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']

    # length = 0
    res = c.__call__(items = items)
    assert isinstance(res, str)
    assert res in items

    # length = 1
    res = c.__call__(items = items, length = 1)
    assert isinstance(res, list)
    assert res[0] in items

    # length < len(items)

# Generated at 2022-06-12 01:36:38.157205
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from unittest import TestCase, main

    from mimesis.builtins import Choice

    class ChoiceTestCase(TestCase):
        """Class for testing class Choice."""

        def setUp(self) -> None:
            """Setup for tests."""
            self.choice = Choice()

        def test_call_with_items(self):
            data = self.choice(items=['a', 'b', 'c'])
            self.assertIn(data, ['a', 'b', 'c'])

        def test_call_with_items_and_length(self):
            data = self.choice(items=['a', 'b', 'c'], length=1)
            self.assertEqual(data, ['a'])

        def test_call_with_items_and_length_with_string(self):
            data

# Generated at 2022-06-12 01:36:49.998478
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import pytest
    c = Choice()
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    with pytest.raises(TypeError) as exception_info:
        c.__call__(items, 3.14)
        assert '**length** must be integer' in str(exception_info.value)
    with pytest.raises(TypeError) as exception_info:
        c.__call__(1, length)
        assert '**items** must be non-empty sequence' in str(exception_info.value)
    with pytest.raises(ValueError) as exception_info:
        c.__call__(items, length)
        assert '**items** must be a non-empty sequence' in str(exception_info.value)

# Generated at 2022-06-12 01:36:52.456180
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice()._choice(items=['a', 'b', 'c', ], length=7, ) == ['b', 'b', 'c', 'c', 'a', 'b', 'b']

# Generated at 2022-06-12 01:36:52.999741
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-12 01:37:02.382867
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice(locale='en')
    fixture = ['a', 'b', 'c']
    assert choice(fixture) in fixture
    assert choice(fixture, length=1) in fixture

    fixture = ['a', 'b', 'c']
    assert choice(fixture, length=1) == ['a']

    fixture = 'abc'
    assert choice(fixture, length=2) == 'ba'

    fixture = ('a', 'b', 'c')
    assert choice(fixture, length=5) == ('c', 'a', 'a', 'b', 'c')

    fixture = 'aabbbccccddddd'
    assert choice(fixture, length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:37:14.505941
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__."""
    from mimesis.providers.base import BaseProvider, choice
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.files import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.text import Text

    num = Numbers()
    text = Text()
    datetime = Datetime()
    file = File()

    class MyProvider(BaseProvider):
        datetime = Datetime()
        numbers = Numbers()
        text = Text()
        file = File()

    my_provider = MyProvider()

    class MyChoice(BaseProvider):
        pass

    my_choice = MyChoice()

    BaseProvider.register(datetime)
    BaseProvider.register(num)


# Generated at 2022-06-12 01:37:26.375706
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    ch = Choice()
    items = ['a', 'b', 'c', 'd', 'e', 'f', 'g']
    length = 5

    result = ch(items)
    assert result in items

    result = ch(items, length)
    assert len(result) == length
    result = ch(items, length, True)
    assert len(result) == length
    # assert len(set(result)) == length
    result = ch(items, length, False)
    assert len(result) == length

    result = ch(items, length=3)
    assert len(result) == 3
    result = ch(items, length=3, unique=True)
    assert len(result) == 3
    result = ch(items, length=3, unique=False)
    assert len(result) == 3


# Generated at 2022-06-12 01:37:33.685584
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method `Choice.__call__`."""
    items = ['a', 'b', 'c']
    length = 5
    unique = True
    expected = 'abc'
    actual = Choice().__call__(items, length, unique)
    assert actual == expected
    items = ['a', 'b', 'c']
    length = 5
    unique = False
    expected = 'bcb'
    actual = Choice().__call__(items, length, unique)
    assert actual == expected

# Generated at 2022-06-12 01:37:40.447803
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.providers.choice import Choice as Ch
    from mimesis.enums import Gender
    c = Ch('en', Gender.FEMALE)
    print(c(items=['a', 'b', 'c']))
    print(c(items=['a', 'b', 'c'], length=1))
    print(c(items='abc', length=2))
    print(c(items=('a', 'b', 'c'), length=5))
    print(c(items='aabbbccccddddd', length=4, unique=True))
# test_choice()

# Generated at 2022-06-12 01:37:42.047906
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass



# Generated at 2022-06-12 01:37:52.146252
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    provider = Choice()
    result = provider(items=['a', 'b', 'c'])
    assert result in ['a', 'b', 'c']
    result = provider(items=['a', 'b', 'c'], length=1)
    assert isinstance(result, list) and len(result) == 1
    assert result[0] in ['a', 'b', 'c']
    result = provider(items='abc', length=2)
    assert isinstance(result, str) and len(result) == 2
    assert result in ['ab', 'ac', 'ba', 'bc', 'ca', 'cb']
    result = provider(items=('a', 'b', 'c'), length=5)

# Generated at 2022-06-12 01:38:00.524281
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    from mimesis import Choice
    from mimesis.enums import Gender

    choice = Choice()
    test_items = ['a', 'b', 'c']
    test_length = 2
    test_unique = True
    actual_value = choice(items=test_items, length=test_length, unique=test_unique)
    expected_type = str
    assert isinstance(actual_value, expected_type)
    expected_length = test_length
    assert len(actual_value) == expected_length
    actual_value = set(actual_value)
    expected_value = set(test_items)
    assert actual_value == expected_value
    test_items = {'a', 'b', 'c'}
    test_length = 4
    test_unique = False

# Generated at 2022-06-12 01:38:09.653998
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(["a", "b", "c"]) == "b" or Choice().__call__(["a", "b", "c"]) == "c" or Choice().__call__(["a", "b", "c"]) == "a"
    assert Choice().__call__(["a", "b", "c"], length=1) == ["a"] or Choice().__call__(["a", "b", "c"], length=1) == ["b"] or Choice().__call__(["a", "b", "c"], length=1) == ["c"]
    assert Choice().__call__("abc", length=2) == "ab" or Choice().__call__("abc", length=2) == "bc" or Choice().__call__("abc", length=2) == "ac"
    assert Choice().__call__

# Generated at 2022-06-12 01:38:20.652000
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 1
    assert choice(items=items, length=length) == ['a']
    length = 2
    assert choice(items=items, length=length) == ['b', 'b']
    length = 5
    assert choice(items=items, length=length) == ['a', 'c', 'b', 'a', 'c']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=2) == ('a', 'b')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    length = 0
    assert choice(items=items, length=length) == 'b'

# Generated at 2022-06-12 01:38:21.580397
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TODO: Add test
    pass

# Generated at 2022-06-12 01:38:25.695041
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    expected = True
    actual = Choice().__call__(('a', 'b', 'c'), 5, True)
    assert expected == actual, 'Call on Choice failed'


# Generated at 2022-06-12 01:38:35.273536
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender
    import random
    choice = Choice('en', random.Random(1))

    # test __init__
    assert choice

    # test __call__
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

    assert choice(items=['a', 'b', 'c'], length=-1) == 'c'

# Generated at 2022-06-12 01:38:46.045064
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    class Dummy(object):
        def __init__(self,Choice):
            self.Choice=Choice
            self.random=self.Choice.random
            self.items=None
            self.length=0
            self.unique=False

    c=Dummy(Choice())
    #items为不为空的列表，且length为0，则随机返回一个
    c.items=['a', 'b', 'c']
    assert c.Choice(c.items, c.length)=='c'
    #items为不为空的列表，且length为正整数，则随机返回一个长度为length的

# Generated at 2022-06-12 01:38:47.343910
# Unit test for method __call__ of class Choice
def test_Choice___call__():
  pass


# Generated at 2022-06-12 01:38:52.661719
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    obj = Choice()
    assert type(obj(items=['a', 'b', 'c'])) is str
    assert type(obj(items=['a', 'b', 'c'], length=1)) is list
    assert type(obj(items='abc', length=2)) is str
    assert type(obj(items=('a', 'b', 'c'), length=5)) is tuple
    assert type(obj(items='aabbbccccddddd', length=4, unique=True)) is str


# Generated at 2022-06-12 01:39:01.285289
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TODO write more
    assert Choice()(items=['a', 'b', 'c']) == 'c'
    assert Choice()(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice()(items='abc', length=2) == 'ba'
    assert Choice()(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice()(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:39:12.210373
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert len(choice(items=['a', 'b', 'c'], length=1)) == 1
    assert choice(items='abc', length=2) in ['ab', 'ac', 'ba', 'bc', 'ca', 'cb']

# Generated at 2022-06-12 01:39:21.649565
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice(seed=123456789)
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    assert isinstance(choice.__call__(items=['a', 'b', 'c']), str)
    assert isinstance(choice.__call__(items=['a', 'b', 'c'], length=1), list)

# Generated at 2022-06-12 01:39:33.754187
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice.

    To run this test, you must run following command:
        python -m unittest tests.test_choice
    """
    import unittest
    from mimesis.exceptions import NonEnumerableError, UniqueError

    # Ignore PEP 8:
    # pylint: disable=no-self-use
    # pylint: disable=too-many-public-methods

    class ChoiceTestCase(unittest.TestCase):
        """Class for testing method __call__ of class Choice."""

        def setUp(self) -> None:
            """Initialize attributes before each test.

            :return: None
            """
            self.choice = Choice()


# Generated at 2022-06-12 01:39:40.972955
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    person = Person('en')
    male_name_sample = ['John', 'Robert', 'James', 'Michael']
    assert person._choice(male_name_sample) in male_name_sample
    assert person._choice(male_name_sample, length=2) in [
        'JohnRobert',
        'JohnJames',
        'JohnMichael',
        'RobertJames',
        'RobertMichael',
        'JamesMichael'
    ]
    assert person._choice(male_name_sample, length=3) in [
        'JohnRobertJames',
        'JohnRobertMichael',
        'JohnJamesMichael',
        'RobertJamesMichael'
    ]
    assert len(person._choice(male_name_sample, length=4)) == 12

# Generated at 2022-06-12 01:39:49.184680
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()

    item_list = ['a', 'b', 'c']
    assert isinstance(choice(item_list), str)
    
    item_list = ['a', 'b', 'c']
    assert len(choice(item_list, len(item_list))) == len(item_list)

    item_string = 'abc'
    assert isinstance(choice(item_string, 2), str)


# Generated at 2022-06-12 01:39:57.022597
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    provider = Choice()
    assert provider(['a', 'b', 'c']) in ['a', 'b', 'c']
    assert provider(['a', 'b', 'c'], 1) == ['b']
    assert provider('ABC', 2) in ['BA', 'AC', 'AB', 'CA']
    assert provider(('a', 'b', 'c'), 5) in (('a', 'c', 'c', 'b', 'a'), ('c', 'a', 'a', 'b', 'c'))
    assert provider('aabbbccccddddd', 4, True) in ('bcca', 'cdab', 'cabd', 'bdac', 'dabc')


# Generated at 2022-06-12 01:40:03.556535
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit: Verify the interface and behavior of Choice.__call__."""
    from mimesis.enums import Flags
    from mimesis.exceptions import NonEnumerableError
    from mimesis.typing import Seed

    meta = Choice.Meta()
    assert meta.name == 'choice'

    # Verify that the length argument has type int
    # pylint: disable=no-member
    data = [int(i) for i in range(-10, 0)]
    data.extend([float(i) for i in range(-10, 0)])
    data.extend(['', ' ', '1', '\t', 'a', 'b', 'ab', 'abc'])
    data.extend([False, True, None, object()])

# Generated at 2022-06-12 01:40:15.406525
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Run the following lines of code as if they were written in the console.
    # --------------------------------
    # from mimesis import Choice
    # choice = Choice()
    # choice(items=['a', 'b', 'c'])
    # choice(items=['a', 'b', 'c'], length=1)
    # choice(items='abc', length=2)
    # choice(items=('a', 'b', 'c'), length=5)
    # choice(items='aabbbccccddddd', length=4, unique=True)
    # --------------------------------

    import sys

    try:
        import mimesis
    except ImportError:
        sys.exit('mimesis is not installed. Try running: pip install mimesis')

    from mimesis import Choice

    # Initialize an object of class Choice
    choice

# Generated at 2022-06-12 01:40:25.589391
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Special cases
    choice = Choice()
    with pytest.raises(TypeError) as exc_info:
        choice(items=None)
    assert str(exc_info.value) == '**items** must be non-empty sequence.'
    with pytest.raises(TypeError) as exc_info:
        choice(items=None, length=0)
    assert str(exc_info.value) == '**items** must be non-empty sequence.'
    with pytest.raises(TypeError) as exc_info:
        choice(items=[], length=0)
    assert str(exc_info.value) == '**items** must be non-empty sequence.'
    with pytest.raises(TypeError) as exc_info:
        choice(items='abc', length=None)

# Generated at 2022-06-12 01:40:37.293982
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    instance = Choice()
    print("mimesis.providers.choice.Choice.__call__('abc', 1): %s" % \
          instance.__call__("abc", 1))
    print("mimesis.providers.choice.Choice.__call__('abc', 2): %s" % \
          instance.__call__("abc", 2))
    print("mimesis.providers.choice.Choice.__call__('abc', 2, True): %s" % \
          instance.__call__("abc", 2, True))
    print("mimesis.providers.choice.Choice.__call__('abc', 3, True): %s" % \
          instance.__call__("abc", 3, True))

# Generated at 2022-06-12 01:40:43.660695
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender
    import pytest
    from mimesis.builtins import RussiaSpecProvider

    pattern = RegexPattern(r'[a-z]+')

    def test_choice():
        choice = Choice()
        items = ['a', 'b', 'c']
        length = 1
        result = choice(items=items, length=length)
        assert result == "a"

        length = 2
        result = choice(items=items, length=length)
        assert result == "ab"

        length = 0
        result = choice(items=items, length=length)
        assert result == "b"

        length = 3
        result = choice(items=items, length=length)
        assert result == "ccb"


# Generated at 2022-06-12 01:40:52.971912
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import pytest
    from random import choice

    random_choice = choice
    choice = Choice()

    try:
        choice(items=123)
    except TypeError:
        pass
    else:
        pytest.fail('Error: **items** must be non-empty sequence.')

    try:
        choice(items=())
    except ValueError:
        pass
    else:
        pytest.fail('Error: **items** must be a non-empty sequence.')

    try:
        choice('a', 'b', 'c')
    except TypeError:
        pass
    else:
        pytest.fail('Error: **items** must be non-empty sequence.')

    try:
        choice(items='', length=1)
    except ValueError:
        pass

# Generated at 2022-06-12 01:40:59.629647
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    sequence = ['a', 'b', 'c']
    assert len(Choice().__call__(sequence, 2)) == 2
    assert len(set(Choice().__call__(sequence, 10))) == len(sequence)
    assert Choice().__call__(sequence) == Choice().__call__(sequence, 1)[0]
    assert isinstance(Choice().__call__(sequence, 1), list)
    assert isinstance(Choice().__call__(sequence), str)

# Generated at 2022-06-12 01:41:09.583132
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from yandextank.common.util import make_choice
    choice = make_choice()
    # choice = Choice()
    items = ['a', 'b', 'c']
    result = choice(items=items)
    assert result == 'c'
    result = choice(items=items, length=1)
    assert result == ['a']
    result = choice(items='abc', length=2)
    assert result == 'ba'
    result = choice(items=('a', 'b', 'c'), length=5)
    assert result == ('c', 'a', 'a', 'b', 'c')
    result = choice(items='aabbbccccddddd', length=4, unique=True)
    assert result == 'cdba'

    # Test errors

# Generated at 2022-06-12 01:41:23.112997
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert isinstance(Choice.__call__(Choice(),  ['a', 'b', 'c']), str)
    assert isinstance(Choice.__call__(Choice(),  ['a', 'b', 'c'], 1), list)
    assert isinstance(Choice.__call__(Choice(),  'abc', 2), str)
    assert isinstance(Choice.__call__(Choice(),  ('a', 'b', 'c'), 5), tuple)
    assert isinstance(Choice.__call__(Choice(),  'aabbbccccddddd', 4, True), str)

# Generated at 2022-06-12 01:41:27.642086
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    # Case:
    assert isinstance(Choice().__call__(items=['a', 'b', 'c']), str)



# Generated at 2022-06-12 01:41:36.056690
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method __call__ of class Choice."""
    choice = Choice()
    result = choice(items=['a', 'b', 'c'])
    print(result)
    assert result in ['a', 'b', 'c']

    result = choice(items=['a', 'b', 'c'], length=1)
    print(result)
    assert isinstance(result, list)
    assert len(result) == 1
    assert result == ['a'] or result == ['b'] or result == ['c']

    result = choice(items='abc', length=2)
    print(result)
    assert result in ['ab', 'ba', 'ac', 'ca', 'bc', 'cb']

    result = choice(items=('a', 'b', 'c'), length=5)
    print(result)
    assert isinstance

# Generated at 2022-06-12 01:41:37.147366
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    # TODO: Add docstring
    pass

# Generated at 2022-06-12 01:41:41.331505
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    # test_items_empty
    with pytest.raises(ValueError):
        choice(items=[])
    # test_items_not_sequence
    with pytest.raises(TypeError):
        choice(items='')
    # test_items_not_string
    with pytest.raises(TypeError):
        choice(items=0)
    # test_length_is_str
    with pytest.raises(TypeError):
        choice(items=['a', 'b', 'c'], length='abc')
    # test_length_zero_and_return_string
    assert choice(items='abc', length=0) in ['a', 'b', 'c']
    # test_length_zero_and_return_tuple

# Generated at 2022-06-12 01:41:42.943542
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TODO: Add test(s)
    raise NotImplementedError


# Generated at 2022-06-12 01:41:49.238050
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    '''
    Unit test for method __call__ of class Choice
    '''
    choice = Choice()
    items = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t'
    ,'u','v','w','x','y','z','0','1','2','3','4','5','6','7','8','9','@','#','$','%','&']
    item_ = choice(items = items, length = 10, unique = True)
    assert len(item_) == 10
    assert isinstance(item_, str)
    for item in item_:
        assert item in items



# Generated at 2022-06-12 01:41:55.222227
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    import random
    from mimesis.enums import Gender
    
    random.seed(0)
    choice = Choice('en', 'zh-CN', gender=Gender.FEMALE)
    assert choice(items=['a', 'b', 'c']) == 'a'
    assert choice(items=['a', 'b', 'c'], length=1) == ['c']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'b', 'b', 'a', 'b')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cbbd'
    

# Generated at 2022-06-12 01:42:00.320835
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Without parameters
    choice = Choice()

    result_1 = choice(items=['a', 'b', 'c', 'd'])
    result_2 = choice(items='abc', length=2)
    result_3 = choice(items=(1, 2, 3, 4), length=5)

    assert result_1 in ['a', 'b', 'c', 'd']
    assert result_2 in ['ab', 'bc', 'ac', 'ba', 'cb', 'ca']
    assert result_3 in [(1, 2, 3, 4, 1), (1, 2, 3, 4, 2), (1, 2, 3, 4, 3),
                        (1, 2, 3, 4, 4)]

    # With parameters
    choice = Choice()
    items = ['a', 'b', 'c', 'd']

# Generated at 2022-06-12 01:42:06.433814
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    print(c(items=['a', 'b', 'c']))
    print(c(items=['a', 'b', 'c'], length=1))
    print(c(items='abc', length=2))
    print(c(items=('a', 'b', 'c'), length=5))
    print(c(items='aabbbccccddddd', length=4, unique=True))

if __name__ == '__main__':
    test_Choice___call__()

# Generated at 2022-06-12 01:42:25.712240
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method __call__ of class Choice."""
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ab', 'ba', 'ac', 'ca', 'bc', 'cb']

# Generated at 2022-06-12 01:42:32.685847
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Test for raises TypeError for non-sequence items
    # Try to call method __call__ of class Choice with non-sequence items
    try:
        choice = Choice()
        choice(items={'a', 'b', 'c'}, length=3)
    except TypeError:
        print('TypeError for non-sequence items is ok')
    else:
        print('Test for raises TypeError for non-sequence items failed')
    # Test for raises ValueError when items is empty
    # Try to call method __call__ of class Choice with empty items
    try:
        choice = Choice()
        choice(items=[])
    except ValueError:
        print('ValueError for empty items is ok')
    else:
        print('Test for raises ValueError when items is empty failed')
    # Test for raises TypeError for non-integer length
    # Try

# Generated at 2022-06-12 01:42:40.181672
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method __call__ of class Choice."""
    choice_ = Choice()
    assert choice_(items=['a', 'b', 'c']) == 'c'
    assert choice_(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice_(items='abc', length=2) == 'ba'
    assert choice_(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice_(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-12 01:42:49.744611
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    if choice(items=['a', 'b', 'c']) != 'c':
        raise AssertionError('Test failure')
    if choice(items=['a', 'b', 'c'], length=1) != ['a']:
        raise AssertionError('Test failure')
    if choice(items='abc', length=2) != 'ba':
        raise AssertionError('Test failure')
    if choice(items=('a', 'b', 'c'), length=5) != ('c', 'a', 'a', 'b', 'c'):
        raise AssertionError('Test failure')
    if choice(items='aabbbccccddddd', length=4, unique=True) != 'cdba':
        raise AssertionError('Test failure')


# Generated at 2022-06-12 01:42:57.567057
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:43:04.486413
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    try:
        assert type(Choice().__call__(['a', 'b', 'c'])) is str
        assert Choice().__call__(['a', 'b', 'c'], length=1) == ['a']
        assert Choice().__call__('abc', length=2) == 'ba'
        assert Choice().__call__(('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
        assert Choice().__call__('aabbbccccddddd', length=4, unique=True) == 'cdba'
    except AssertionError as e:
        raise AssertionError(e)
    except Exception as e:
        raise Exception(e)

# Generated at 2022-06-12 01:43:13.804074
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    ch = Choice()
    assert type(ch.__call__(["a","b"])) is str
    assert ch.__call__(["a","b"]) == 'a' or ch.__call__(["a","b"]) == 'b'
    assert ch.__call__(["a","b"],3) == ['a','b','a'] or ch.__call__(["a","b"],3) == ['a','a','b']
    assert ch.__call__(["a","b"],3,unique = True) == ['a','b',None] or ch.__call__(["a","b"],3,unique = True) == [None,'a','b']
    assert ch.__call__(('a','b'),3) == ['a','b','a'] or ch.__call__(['a','b'],3)

# Generated at 2022-06-12 01:43:22.171230
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

if __name__ == '__main__':
    test_Choice___call__()

# Generated at 2022-06-12 01:43:24.272106
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender
    choice = Choice(gender=Gender.FEMALE)
    choice(['a', 'b', 'c'], 3)
    choice('a', 3)

# Generated at 2022-06-12 01:43:28.782452
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Prepare the arguments
    items_ = ['a', 'b', 'c']
    length_ = 1
    unique_ = False
    # Execute the tested code
    result = Choice().__call__(items=items_,length=length_,unique=unique_)
    # Verify the result
    assert result == ['a']
    

# Generated at 2022-06-12 01:43:50.266719
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TODO: Test

    pass

# Generated at 2022-06-12 01:43:51.880679
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    print(c(items=['a', 'b', 'c'], length=4, unique=True))

# Generated at 2022-06-12 01:43:55.029256
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    fn = Choice()
    fn(items=['a', 'b', 'c'])
    fn(items=['a', 'b', 'c'], length=1)
    fn(items='abc', length=2)
    fn(items=('a', 'b', 'c'), length=5)
    fn(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-12 01:43:57.376278
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    choice = Choice()
    items = ['a', 'b', 'c']
    assert choice(items) in items



# Generated at 2022-06-12 01:44:08.279136
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) in ['ab', 'ac', 'bc']

# Generated at 2022-06-12 01:44:17.060118
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    items = ['a', 'b', 'c']
    assert choice(items) in items

    items = ['a', 'b', 'c']
    length = 1
    assert len(choice(items, length)) == length

    items = 'abc'
    length = 2
    assert len(choice(items, length)) == length

    items = ('a', 'b', 'c')
    length = 5
    assert len(choice(items, length)) == length

    items = 'aabbbccccddddd'
    length = 4
    unique = True
    assert len(choice(items, length, unique)) == length


# Generated at 2022-06-12 01:44:23.951061
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice.

    >>> test_Choice___call__()
    [1]
    """
    from random import seed
    from mimesis import Choice
    from mimesis.builtins.numbers import Number

    seed(1)
    choice = Choice()
    num = Number()
    print('[1]', choice(items=num.positive_floats(min_value=0.0, max_value=1.0),
                       length=5,
                       unique=True))



# Generated at 2022-06-12 01:44:30.470506
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:44:33.181901
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = [1, 2, 3]
    length = 2
    unique = True

    choice = Choice()
    assert choice.__call__(items, length, unique) in [[1,2], [1,3], [2,3]]

# Generated at 2022-06-12 01:44:33.939808
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
