

# Generated at 2022-06-12 01:35:54.010838
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Return the same object
    assert Choice().__class__ == Choice
    # Return the same object
    assert Choice().get_choice().__class__ == Choice
    # Return some string
    assert isinstance(Choice().choice(length=1), str)
    # Return some string
    assert isinstance(Choice().choice(length=2), str)
    # Return some string
    assert isinstance(Choice().choice(length=3), str)
    # Return some string
    assert isinstance(Choice().choice(length=4), str)
    # Return some string
    assert isinstance(Choice().choice(length=5), str)
    # Return some string
    assert isinstance(Choice().choice(length=6), str)
    # Return some string
    assert isinstance(Choice().choice(length=7), str)
    # Return some string
   

# Generated at 2022-06-12 01:36:03.355145
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Intentionally set these incorrectly to ensure they are overridden.
    choice = Choice()
    assert choice.__call__(items=['a', 'b', 'c']) == 'c'
    assert choice.__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice.__call__(items='abc', length=2) == 'ba'
    assert choice.__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice.__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:36:09.738690
# Unit test for method __call__ of class Choice
def test_Choice___call__():
        choice = Choice()
        assert choice(items=['a', 'b', 'c']) == 'c'
        assert choice(items=['a', 'b', 'c'], length=1) == ['a']
        assert choice(items='abc', length=2) == 'ba'
        assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
        assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-12 01:36:15.899152
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:36:26.284367
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from hypothesis import given
    from hypothesis.strategies import integers
    from hypothesis.strategies import lists

    from mimesis import Choice
    from mimesis.enums import Gender

    choice = Choice()
    choice.seed(0)

    @given(integers(min_value=-1))
    def test_length_less_than_zero(length):
        import pytest
        from pytest import raises

        with raises(ValueError) as ex:
            choice(items=[1, 2, 3], length=length)
        assert 'should be a positive integer' in str(ex.value)

    @given(lists(elements=integers(), min_size=1))
    def test_empty_items(items):
        import pytest
        from pytest import raises

        with raises(ValueError) as ex:
            choice

# Generated at 2022-06-12 01:36:32.795034
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=[True, False], length=0) == False
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2, unique=True) == 'ba'
    assert Choice().__call__(items='aabbbcccddddeeeee', length=4, unique=True) == 'aebc'

# Generated at 2022-06-12 01:36:43.875070
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    try:
        choice(items='abc', length=2.0)
        assert False
    except TypeError:
        assert True
    try:
        choice(items=3.0)
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-12 01:36:48.703119
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.providers import Choice
    from mimesis.enums import Gender
    from tests.data import BASE_PATH

    choice = Choice()
    result = choice.__call__(items=[Gender.M, Gender.F])
    with open(BASE_PATH + "/data/choice/__call__/result.txt", "r") as file:
        assert file.readline().rstrip() == result

    result = choice.__call__(items=['a', 'b', 'c', 'd'], length=4)
    with open(BASE_PATH + "/data/choice/__call__/result1.txt", "r") as file:
        assert file.readline().rstrip() == result

    result = choice.__call__('abc', length=2)

# Generated at 2022-06-12 01:36:59.606743
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) in ['ab', 'ba', 'ac', 'ca', 'bc', 'cb']

# Generated at 2022-06-12 01:37:09.959325
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method __call__ of class Choice."""
    from mimesis import Choice

    choice = Choice()

    # Test for Case 1
    # Case 1: Test for item as string
    assert choice(items='abc', length=1) == 'a'
    assert choice(items='abc', length=2) == 'ac'
    assert choice(
        items='abc',
        length=3,
    ) == 'cab'
    assert choice(items='abc', length=4) == 'bbc'
    assert choice(items='abc', length=5) == 'cbab'
    assert choice(items='abc', length=6) == 'cbabc'
    assert choice(items='abc', length=7) == 'cbacab'
    assert choice(items='abc', length=8) == 'acbbcba'
   

# Generated at 2022-06-12 01:37:19.792590
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:37:29.313831
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice

    choice = Choice()
    assert choice(items=[1,2,3], length=0, unique=False) in [1,2,3]
    assert choice(items='abc', length=0, unique=False) in 'abc'
    assert choice(items=(1, 2, 3), length=0, unique=False) in (1, 2, 3)

    assert choice(items=[1, 2, 3], length=1, unique=False) == [1]
    assert choice(items='abc', length=1, unique=False) == 'a'
    assert choice(items=(1, 2, 3), length=1, unique=False) == (1,)

    assert choice(items=[1, 2, 3], length=2, unique=False) == [1, 2]

# Generated at 2022-06-12 01:37:39.401642
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    import pytest

    message = 'is not a non-empty sequence'

    provider = Choice()

    assert provider(items = ['a', 'b', 'c'], length = 1) == ['a']
    assert provider(items = 'abc', length = 2) == 'ba'
    assert provider(items = ('a', 'b', 'c'), length = 5) == ('c', 'a', 'a', 'b', 'c')
    assert provider(items = 'aabbbccccddddd', length = 4, unique = True) == 'cdba'
    assert provider('aabbbccccddddd', 4, True) == 'cdba'

    with pytest.raises(TypeError) as excinfo:
        provider(items = 5, length = 1)
    assert str(excinfo.value) == "5 " + message

# Generated at 2022-06-12 01:37:40.229932
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert True


# Generated at 2022-06-12 01:37:47.019819
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert isinstance(c(items=['a', 'b', 'c']), str)
    assert isinstance(c(items=['a', 'b', 'c'], length=1), list)
    assert isinstance(c(items='abc', length=2), str)
    assert isinstance(c(items=('a', 'b', 'c'), length=5), tuple)
    assert isinstance(c(items='aabbbccccddddd', length=4, unique=True), str)


# Generated at 2022-06-12 01:37:53.990434
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    choice(items=['a', 'b', 'c'])
    choice(items=['a', 'b', 'c'], length=1)
    choice(items='abc', length=2)
    choice(items=('a', 'b', 'c'), length=5)
    choice(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-12 01:38:01.205077
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import sys, os
    import doctest

    doctest.testmod()

    module_name = '.'.join(__name__.split('.')[:-1])
    use_resources = module_name + '.tests.resources'
    use_resources = os.path.abspath(use_resources)
    path_add = []
    if use_resources not in sys.path:
        path_add.append(use_resources)

    path_add.extend(['.', '..', '../..', '../../..'])
    [sys.path.insert(0, aa) for aa in path_add if aa not in sys.path]

    from tests.providers.base.test_choice import TestChoice

    test_cases = TestChoice.__dict__.keys()

# Generated at 2022-06-12 01:38:09.956719
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Non-empty sequence: list of elements
    items = ['a', 'b']
    c = Choice()
    result = c(items=items, length=2)
    assert isinstance(result, list)
    assert len(result) == 2

    # Empty sequence: list of elements
    items = []
    c = Choice()
    result = c(items=items, length=2)
    assert isinstance(result, list)
    assert len(result) == 0

    # Non-empty sequence: tuple of elements
    items = ('a', 'b')
    c = Choice()
    result = c(items=items, length=2)
    assert isinstance(result, tuple)
    assert len(result) == 2

    # Empty sequence: tuple of elements
    items = ()
    c = Choice()

# Generated at 2022-06-12 01:38:14.683490
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import doctest
    doctest.testmod(verbose=True)
    doctest.testfile("docs/choice.rst", verbose=True)

if __name__ == "__main__":
    test_Choice___call__()

# Generated at 2022-06-12 01:38:18.162456
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c=Choice()
    assert len(c.choice(items=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'],length=10)) == 10

# Generated at 2022-06-12 01:38:25.764953
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    result = ('c', 'a', 'a', 'b', 'c')
    assert result == Choice().__call__(items=('a', 'b', 'c'), length=5)

# Generated at 2022-06-12 01:38:35.348767
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import pytest # type: ignore
    from mimesis.enums import Localization
    from mimesis.enums import Gender
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.address import Address
    from mimesis.builtins import RussiaSpecProvider

    choice = Choice(localization=Localization.RU)
    dt = Datetime(localization=Localization.RU)
    address = Address(localization=Localization.RU)

    assert choice(['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(['a', 'b', 'c'], 1) in [['a'], ['b'], ['c']]
    assert choice('abc', 2) in ['ba', 'ac', 'cb']

# Generated at 2022-06-12 01:38:39.542695
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender
    from mimesis.builtins import RussiaSpecProvider

    choice = Choice()
    person = RussiaSpecProvider(gender=Gender.MALE)

    assert person.full_name() in choice(items=['A', 'B'])

# Generated at 2022-06-12 01:38:44.952690
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from choice import Choice as Ch
    ch = Ch()
    item_test = ch(['a', 'b', 'c'], unique=True)
    assert isinstance(item_test, str)
    assert item_test in 'abc'

# Comment out to run all tests
test_Choice___call__()
# Uncomment to run one test
# print(test_Choice___call__())

# Generated at 2022-06-12 01:38:53.434074
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    random_object = Choice()

    # Should return ['a']
    print(random_object.__call__(items, length, unique))

    items = 'abc'
    length = 2

    # Should return 'ba'
    print(random_object.__call__(items, length, unique))

    items = ['a', 'b', 'c']
    length = 5

    # Should return ('c', 'a', 'a', 'b', 'c')
    print(random_object.__call__(items, length, unique))

    items = 'aabbbccccddddd'
    length = 4
    unique = True

    # Should return 'cdba'

# Generated at 2022-06-12 01:38:58.272720
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    instance = Choice()
    assert isinstance(instance('abc'), str), "Not a string"
    assert isinstance(instance('abc'), str), "Not a string"
    assert isinstance(instance(('a', 'b', 'c')), tuple), "Not a tuple"


# Generated at 2022-06-12 01:39:08.459456
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    obj = Choice()
    x = Choice()
    y = Choice()
    z = Choice()
    assert x is not y
    assert y is not z
    assert z is not x

    assert 'c' == obj(items=['a', 'b', 'c'])
    assert ['a'] == obj(items=['a', 'b', 'c'], length=1)
    assert 'ba' == obj(items='abc', length=2)
    assert ('c', 'a', 'a', 'b', 'c') == obj(items=('a', 'b', 'c'), length=5)
    assert 'cdba' == obj(items='aabbbccccddddd', length=4, unique=True)
    # [] == obj(items=[])
    # '' == obj(items='')

# Generated at 2022-06-12 01:39:15.869392
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    assert Choice()('abc',1) == 'c'
    assert Choice()('abc',2) == 'ac'
    assert Choice()('abc',1,unique=True) == 'a'
    assert Choice()('abc',2,unique=True) == 'ac'
    assert Choice()('abc',4,unique=True) == 'acbd'
    assert Choice()('aabbccdd',4,unique=True) == 'cbdc'
    assert Choice()('aabbccdd',4) == 'cddb'

# Generated at 2022-06-12 01:39:23.442420
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    expected = choice(items=['a', 'b', 'c'])
    assert expected in ['a', 'b', 'c']

    expected = choice(items=['a', 'b', 'c'], length=1)
    assert expected == ['a'] or expected == ['b'] or expected == ['c']

    expected = choice(items='abc', length=2)
    assert expected == 'ba' or expected == 'bc' or expected == 'ab' or expected == 'cb' or expected == 'ca' or expected == 'ac'

    expected = choice(items=('a', 'b', 'c'), length=5)

# Generated at 2022-06-12 01:39:33.163968
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(['a', 'b', 'c']) in 'abc'
    assert choice(['a', 'b', 'c'], 1) == ['b']
    assert choice('abc', 2) in 'abcaabcbacbabccbacbcaccc'
    assert choice(('a', 'b', 'c'), 5) == ('b', 'c', 'b', 'a', 'b')
    assert choice('aabbbccccddddd', 4, True) in 'abcdabcdabcdabcd'

# Test for checking correct work when parameter items is not a sequence

# Generated at 2022-06-12 01:40:15.488781
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice.__call__(items=['a', 'b', 'c']) == 'c'
    assert choice.__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice.__call__(items='abc', length=2) == 'ba'
    assert choice.__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice.__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:40:25.794055
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c'], length=4, unique=True) is not None
    assert Choice().__call__(items=('a', 'b', 'c'), length=0, unique=False) is not None
    assert Choice().__call__(items='abc', length=2, unique=False) is not None
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=False) is not None
    assert Choice().__call__(items=['a', 'b', 'c'], length=0, unique=False) is not None
    assert Choice().__call__(items=['a', 'b', 'c'], length=4, unique=False) is not None

# Generated at 2022-06-12 01:40:37.561135
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    # Generate a randomly-chosen sequence or bare element from a sequence.

    from mimesis import Choice
    choice = Choice()

    # Provide elements randomly chosen from the elements in a sequence items,
    # where when length is specified the random choices are contained in a
    # sequence of the same type of length length, otherwise a single
    # uncontained element is chosen. If unique is set to True, constrain a
    # returned sequence to contain only unique elements.

    # **items** must be non-empty sequence.
    with raises(TypeError):
        choice(items=set())

    # **length** must be integer.
    with raises(TypeError):
        choice(items=[], length='abc')

    # **items** must be a non-empty sequence.

# Generated at 2022-06-12 01:40:46.911459
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    assert choice(items=['a', 'b', 'c']) == 'c'
    try:
        choice(items=['a', 'b', 'c'], length='abc')
    except TypeError:
        assert True
    try:
        choice(items='abc', length=-1)
    except ValueError:
        assert True

# Generated at 2022-06-12 01:40:54.527359
# Unit test for method __call__ of class Choice
def test_Choice___call__():
  '''case_Choice___call__()'''
  choice = Choice()
  assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
  assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
  assert choice(items='abc', length=2) in ['ab', 'ac', 'bc']

# Generated at 2022-06-12 01:41:04.282785
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.providers.choice import Choice
    choice = Choice()

    assert isinstance(choice(items=['a', 'b', 'c']), str)
    assert isinstance(choice(items=['a', 'b', 'c'], length=1), list)
    assert isinstance(choice(items='abc', length=2), str)
    assert isinstance(choice(items=('a', 'b', 'c'), length=5), tuple)
    assert isinstance(choice(items='aabbbccccddddd', length=4, unique=True), str)

    assert choice(items=('a', 'b', 'c')) in 'abc'

# Generated at 2022-06-12 01:41:07.969710
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    ch = Choice()
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    assert ch(items, length, unique) == ['a']


# Generated at 2022-06-12 01:41:10.548449
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 2
    unique = True
    choice = Choice()
    result = choice.__call__(items, length, unique)


# Generated at 2022-06-12 01:41:17.285709
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test Choice.__call__().

    It is supposed to return a sequence or bare element randomly chosen
    from a given sequence.
    """
    # Initialize the class
    sequence = Choice()
    # Case 1 - items is a list
    items = ['a', 'b', 'c']
    # Case 1.1 - length is 0
    assert sequence(items=items, length=0) in items
    # Case 1.2 - length is positive
    assert len(sequence(items=items, length=2)) == 2
    # Case 2 - items is a tuple
    items = ('a', 'b', 'c')
    # Case 2.1 - length is 0
    assert sequence(items=items, length=0) in items
    # Case 2.2 - length is positive

# Generated at 2022-06-12 01:41:22.974163
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    class Candidate:
        def test(self, items: Optional[Sequence[Any]], length: int = 1,
                 unique: bool = False) -> Union[Any, Sequence[Any]]:
            choice = Choice()
            return choice(items, length, unique)

    candidate = Candidate()
    result = candidate.test(['a', 'b', 'c'], length=3, unique=False)
    assert result == ['c', 'a', 'a']