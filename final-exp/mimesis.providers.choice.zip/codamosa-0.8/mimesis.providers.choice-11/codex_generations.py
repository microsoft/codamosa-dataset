

# Generated at 2022-06-12 01:36:09.876660
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    items = ['a', 'b', 'c']
    data = c(items, length= len(items), unique=True)
    assert isinstance(data, list)

    data = c(items, length= len(items), unique=False)
    assert isinstance(data, list)

    data = c(items, length= len(items)-1, unique=False)
    assert isinstance(data, list)

    data = c(items, length= len(items)+1, unique=True)
    assert isinstance(data, list)

    data = c(items, length= len(items)+1, unique=False)
    assert isinstance(data, list)

    items = ('a', 'b', 'c')
    data = c(items, length= len(items), unique=True)

# Generated at 2022-06-12 01:36:20.573656
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    try:
        Choice().__call__(items=None)
    except TypeError as err:
        assert str(err) == '**items** must be non-empty sequence.'


# Generated at 2022-06-12 01:36:31.435255
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    Dict1 = {}
    Dict1['0'] = ('list', ['a', 'b', 'c'], 'str', 0, False, 'str', 'c')
    Dict1['1'] = ('list', ['a', 'b', 'c'], 'list', 1, False, 'list', ['a'])
    Dict1['2'] = ('str', 'abc', 'str', 2, False, 'str', 'ba')
    Dict1['3'] = ('tuple', ('a', 'b', 'c'), 'tuple', 5, False, 'tuple',
                  ('c', 'a', 'a', 'b', 'c'))
    Dict1['4'] = ('str', 'aabbbccccddddd', 'str', 4, True, 'str', 'cdba')


# Generated at 2022-06-12 01:36:37.861626
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.person import Person

    person = Person('en', gender=Gender.MALE)
    choice = Choice('en')

    # __call__(self, items: Sequence, length: int = 0, unique: bool = False)
    choice(items=['one', 'two', 'three'])
    choice(items=['one', 'two', 'three'], length=1)
    choice(items='abc', length=2)
    choice(items=('a', 'b', 'c'), length=5)
    choice(items='aabbbccccddddd', length=4, unique=True)
    choice(items=['one', 'two', 'three'], length=4)

# Generated at 2022-06-12 01:36:39.980819
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""



# Generated at 2022-06-12 01:36:44.982776
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    assert Choice().__call__(items, length, unique) == 'a'
    assert Choice().__call__(items, length=1) == 'c'


# Generated at 2022-06-12 01:36:46.520206
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # type: () -> None
    """Test for method __call__ of class Choice"""
    pass

# Generated at 2022-06-12 01:36:48.103163
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    choice_ = Choice()
    choice_('⠘⠸⠰⠆', 1) == '⠆'


# Generated at 2022-06-12 01:36:59.405643
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    ''' Unit test for method __call__ of class Choice
    '''
    print(Choice())
    assert True

    # Normal fail-case with no inputs
    try:
        Choice.Choice()
    except Exception as e:
        assert type(e) == TypeError
        assert str(e) == 'Choice() takes from 1 to 3 positional arguments ' \
                         'but 4 were given'

    # Boundary fail-case with no items
    try:
        Choice.Choice(seed=777)()
    except Exception as e:
        assert type(e) == ValueError
        assert str(e) == '**items** must be a non-empty sequence.'

    # Boundary success-case with no length
    # TODO: Understand this expectation
    temp = Choice(seed=777)(items=[0, 1, 2])

# Generated at 2022-06-12 01:37:09.959360
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items_seq = ['a', 'b', 'c']
    length_seq = 1
    unique_seq = True
    choice_seq = Choice()

    # item = ['a', 'b', 'c']
    # length = 1
    # unique = True
    expected_value_1 = ['a']
    actual_value_seq = choice_seq(items = items_seq, length = length_seq, unique = unique_seq)
    assert actual_value_seq == expected_value_1, 'AssertionError: expected value = {expected_value}, but actual value = {actual_value}'.format(expected_value=expected_value_1, actual_value=actual_value_seq)

    items_non_seq = {}
    length_non_seq = 1
    unique_non_seq = True

# Generated at 2022-06-12 01:37:24.688373
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """
    This function tests method __call__ of class Choice.
    """
    global random
    import random
    random.seed(123)
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-12 01:37:31.780846
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import pytest
    try:
        ch = Choice()
        ch(items=['a', 'b', 'c'])
        ch(items=['a', 'b', 'c'], length=1)
        ch(items='abc', length=2)
        ch(items=('a', 'b', 'c'), length=5)
        ch(items='aabbbccccddddd', length=4, unique=True)
    except TypeError:
        pytest.fail("Raised TypeError unexpectedly!")
    except ValueError:
        pytest.fail("Raised ValueError unexpectedly!")
    # Test if a TypeError will be raised when the items argument is not a sequence.

# Generated at 2022-06-12 01:37:38.300754
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items=['a', 'b', 'c']) == 'c'

# Generated at 2022-06-12 01:37:48.416673
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) in ['ab', 'ac', 'bc']
    assert choice(items=('a', 'b', 'c'), length=5) in [('a', 'a', 'b', 'c', 'c'), ('a', 'b', 'c', 'c', 'a'), ('b', 'a', 'c', 'c', 'a'), ('b', 'c', 'a', 'c', 'a'), ('b', 'c', 'c', 'a', 'a')]

# Generated at 2022-06-12 01:37:58.611105
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from unittest import TestCase, main
    from random import randint
    from mimesis import Choice, Random
    class Choice___call__(TestCase):
        def test_random_choice(self):
            choice = Choice()
            alphabet = 'abcdefghijklmnopqrstuvwxyz'
            random = Random(randint(0, 2**32 - 1))
            choice.bind(random=random)
            choice_ = choice.__call__(items=alphabet)
            self.assertIn(choice_, alphabet)
            choice_ = choice.__call__(items=alphabet, length=randint(1, 10))
            self.assertIn(choice_, alphabet)
            choice_ = choice.__call__(items=alphabet, length=randint(1, 10),
                                      unique=True)

# Generated at 2022-06-12 01:38:09.006369
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Test for Choice.__call__(items, length=0)
    choice = Choice()
    value = choice(items=('a', 'b', 'c'))
    assert isinstance(value, str)
    assert value in ('a', 'b', 'c')
    # Test for Choice.__call__(items, length=1)
    value = choice(items=('a', 'b', 'c'), length=1)
    assert isinstance(value, list)
    assert value == ['c']
    # Test for Choice.__call__(items, length=2)
    value = choice(items='abc', length=2)
    assert isinstance(value, str)
    assert len(value) == 2
    assert value in ('ba', 'cb', 'bc', 'ab', 'ca', 'ac')
    # Test for Choice

# Generated at 2022-06-12 01:38:19.292757
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    c = Choice()
    assert c(['a', 'b', 'c'], unique=True) in ['a', 'b', 'c']
    assert c(['a', 'b', 'c'], unique=True, length=2) in ['ab', 'ac', 'bc']
    assert c(['a', 'b', 'c'], unique=True, length=3) in ['abc', 'acb', 'bac', 'bca', 'cab', 'cba']

# Generated at 2022-06-12 01:38:26.955905
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Test with non-sequence and non-empty items
    try:
        Choice().__call__(items=1)
    except TypeError as exc:
        assert str(exc) == '**items** must be non-empty sequence.'
    else:
        raise AssertionError('TypeError not raised.')

    # Test with some valid input arguments
    assert Choice().__call__(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) in ['ab', 'ba', 'ac', 'ca', 'bc', 'cb']

# Generated at 2022-06-12 01:38:36.478700
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    choice1 = Choice("name1")
    choice2 = Choice("name2")
    choice3 = Choice("name3")
    choice4 = Choice("name4")
    choice5 = Choice("name5")
    choice6 = Choice("name6")

    assert isinstance(choice1(items=[1, 2, 3]), int)

    assert isinstance(choice1(items=[1, 2, 3], length=1), list)
    assert isinstance(choice2(items=[1, 2, 3], length=2), list)
    assert isinstance(choice3(items=[1, 2, 3], length=3), list)

    assert isinstance(choice4(items='abc', length=1), str)

# Generated at 2022-06-12 01:38:41.972708
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items=['a', 'b', 'c']
    length=2

    choice = Choice()
    result = choice(items, length, True)

    assert result is not None
    assert isinstance(result, str)
    assert len(result) == 2
    assert result in ['ab', 'ac', 'bc']

# Generated at 2022-06-12 01:39:01.200404
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test method __call__ of class Choice."""
    import pytest
    from mimesis.enums import Gender
    from mimesis.providers import GenericChoice
    from .helpers import get_fixture

    choices = Choice('en')
    generic_choices = GenericChoice('en', gender=Gender.MALE)

    # Test for:
    # ('__call__',
    #  ('items', ['a', 'b', 'c']),
    #  ('length', None),
    #  ('unique', False),
    #  ('result', 'b'))
    assert choices(items=['a', 'b', 'c']) in ['a', 'b', 'c']

    # Test for:
    # ('__call__',
    #  ('items', (1, 2, 3)),
    #  ('

# Generated at 2022-06-12 01:39:12.127211
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import random
    import pytest
    from mimesis import Choice
    seed = random.randint(0, 10_000)
    random.seed(seed)
    # fmt: off
    test_values = [
        pytest.param({'items': ['a', 'b', 'c'], 'length': 0},
                     marks=pytest.mark.xfail(raises=TypeError, strict=True)),
        {'items': ['a', 'b', 'c'], 'length': 1, 'unique': True},
        {'items': 'abc', 'length': 2},
        {'items': ('a', 'b', 'c'), 'length': 5},
        {'items': 'aabbbccccddddd', 'length': 4, 'unique': True},
    ]
    # fmt: on

# Generated at 2022-06-12 01:39:21.588455
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Function to test method __call__ of class Choice."""
    # TODO: Make this a doctest
    import mimesis

    c = mimesis.Choice()

    assert c(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert c(items=['a', 'b', 'c'], length=1) == ['a']
    assert c(items='abc', length=2) in ['ab', 'ba', 'bc', 'cb', 'ac', 'ca']

# Generated at 2022-06-12 01:39:33.672789
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test that `Choice.__call__` returns a random choice from items in
    a sequence."""
    from random import seed
    from string import ascii_lowercase
    from typing import Sequence, TypeVar

    T = TypeVar('T')  # pylint: disable=invalid-name

    seed(18614)

    choice = Choice()
    items = ['a', 'b', 'c']
    assert isinstance(choice(items), str)

    seed(18614)
    T = TypeVar('T')  # pylint: disable=invalid-name
    assert choice(items, length=0) == 'c'

    seed(18614)
    assert choice(items, length=1) == ['a']

    seed(18614)
    assert choice(items, length=2) == ['c', 'c']

# Generated at 2022-06-12 01:39:40.895683
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Provides a random choice from items in a sequence."""
    import pytest
    from mimesis.providers.choice import Choice

    choice = Choice()

    with pytest.raises(TypeError) as ex:
        choice(items=1, length=1)
        assert str(ex.value) == '**items** must be non-empty sequence.'

    with pytest.raises(TypeError) as ex:
        choice(items=[], length=1)
        assert str(ex.value) == '**items** must be non-empty sequence.'

    with pytest.raises(TypeError) as ex:
        choice(items=[1, 2, 3], length='1')
        assert str(ex.value) == '**length** must be integer.'


# Generated at 2022-06-12 01:39:44.788406
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = [1, 2, 3, 4, 5, 6, 7]
    ch = Choice()
    s = ch(items)
    assert s in items


# Generated at 2022-06-12 01:39:54.397548
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    from mimesis.providers import Choice
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ac', 'ab', 'bc']
    assert choice(items=('a', 'b', 'c'), length=5) in [
        ('c', 'a', 'a', 'b', 'c'), ('c', 'a', 'b', 'b', 'b'), ('a', 'c', 'c', 'c', 'a')]

# Generated at 2022-06-12 01:40:01.985135
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    # Test for valid input arguments:
    choice(items=['a', 'b', 'c'])
    choice(items=['a', 'b', 'c'], length=1)
    choice(items='abc', length=2)
    choice(items=('a', 'b', 'c'), length=5)
    choice(items='aabbbccccddddd', length=4, unique=True)
    # Test for invalid input arguments:
    try:
        choice(items=['a', 'b', 'c'], length='string')
    except TypeError:
        pass
    try:
        choice(items=['a', 'b', 'c'], length=-5)
    except ValueError:
        pass

# Generated at 2022-06-12 01:40:07.295505
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TODO: Refactor
    from random import seed
    from hypothesis import given, settings
    from hypothesis.strategies import integers, lists
    
    seed(555)
    
    @settings(max_examples=10)
    @given(lists(integers()), integers(), integers())
    def tests(items, length, unique):
        """Method for testing method __call__ of class Choice.
        
        :param items: List of items
        :param length: length of returned list
        :param unique: unique parameter
        :return: nothing
        """

# Generated at 2022-06-12 01:40:11.544078
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in 'abc'
    assert choice(items=('a', 'b', 'c'), length=2) in ('ab', 'bc', 'ac')

# Generated at 2022-06-12 01:40:31.510731
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    _ = Choice()
    r = _(items=['a', 'b', 'c'], length=1, unique=False)
    assert isinstance(r, list)

    r = _(items=('a', 'b', 'c'), length=3, unique=True)
    assert isinstance(r, tuple)

    assert _(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:40:39.816349
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    choice_ = Choice()
    assert choice_(['a', 'b', 'c']) == 'c'
    assert choice_(['a', 'b', 'c'], 1) == ['a']
    assert choice_('abc', 2) == 'ba'
    assert choice_(('a', 'b', 'c'), 5) == ('c', 'a', 'a', 'b', 'c')
    assert choice_('aabbbccccddddd', 4, True) == 'cdba'

# Generated at 2022-06-12 01:40:49.996711
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    print(c(items=['a', 'b', 'c'])) # "a", "b", "c"
    print(c(items=['a', 'b', 'c'], length=1)) # ["a"]
    print(c(items='abc', length=2)) # "ba"
    print(c(items=('a', 'b', 'c'), length=5)) # ('c', 'a', 'a', 'b', 'c'), ('c', 'a', 'b', 'c', 'a'), ('a', 'b', 'c', 'b', 'a'), ('b', 'a', 'c', 'b', 'a')
    print(c(items='aabbbccccddddd', length=4, unique=True)) # "cdba", "dbac", "dcba", "db

# Generated at 2022-06-12 01:40:50.672800
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert callable(Choice.__call__)

# Generated at 2022-06-12 01:40:58.858150
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.providers.utils import Data
    data = Data()

    items = data.generate_nested_lists(data, 10, 'abc')


    items[0] = data.generate_nested_lists(data, 10, 'abc')
    length = data.generate_nested_lists(data, 10, 'abc')
    unique = data.generate_nested_lists(data, 10, 'abc')
    print(items[0], length, unique)
    choice = Choice()
    choice(items[0], length, unique)

# Generated at 2022-06-12 01:41:01.034575
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    assert Choice.__call__(items, length, unique) == ['a']


# Generated at 2022-06-12 01:41:09.775352
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items1 = ['a', 'b', 'c']
    choice = Choice()
    assert choice(items=items1) in items1
    assert choice(items=items1, length=1) == ['a']
    items2 = 'abc'
    assert choice(items=items2, length=2) == 'ba'
    items3 = ('a', 'b', 'c')
    assert choice(items=items3, length=5) == ('c', 'a', 'a', 'b', 'c')
    items4 = 'aabbbccccddddd'
    assert choice(items=items4, length=4, unique=True) == 'cdba'


# Generated at 2022-06-12 01:41:16.788433
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    # Generate a randomly-chosen sequence or bare element from a sequence.
    # Provide elements randomly chosen from the elements in a sequence
    # **items**, where when **length** is specified the random choices are
    # contained in a sequence of the same type of length **length**,
    # otherwise a single uncontained element is chosen. If **unique** is set
    # to True, constrain a returned sequence to contain only unique elements.
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ab', 'ac', 'bc']

# Generated at 2022-06-12 01:41:22.504039
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    result, items, length, unique = [], ['a', 'b', 'c'], 1, False

    result.append(choice(items, length, unique))

    if ((result[0] == ['a']) or (result[0] == ['b']) or (result[0] == ['c'])):
        rtn = True
    else:
        rtn = False

    return rtn


# Generated at 2022-06-12 01:41:29.427256
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """
    Test function.
    """
    # Test initialization
    test_case = Choice()

    # Test call
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    result = test_case(items=items, length=length, unique=unique)

    # Assert comparison
    assert result == ['c']

# Generated at 2022-06-12 01:42:07.798805
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().choice(items=['a', 'b', 'c']) == 'c'
    assert Choice().choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().choice(items='abc', length=2) == 'ba'
    assert Choice().choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-12 01:42:17.797658
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ab', 'cb', 'ba']

# Generated at 2022-06-12 01:42:27.302736
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice.
    """
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

    try:
        choice(items=123)
    except TypeError as exc:
        assert '**items** must be non-empty sequence.' in str(exc)


# Generated at 2022-06-12 01:42:33.636729
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    string_sequences = [
        '',  # edge case
        'a',
        'ab',
        'abc',
        'abcd',
        'abcde',
    ]
    tuple_sequences = [
        tuple(),  # edge case
        tuple('a'),
        tuple('ab'),
        tuple('ab'),
        tuple('abcd'),
        tuple('abcde'),
    ]
    for s in string_sequences:
        assert choice(items=s, length=0) in s
    for t in tuple_sequences:
        assert choice(items=t, length=0) in t
    # TODO: Implement test that ensures that the return value is of the same type as items
    assert len(choice(items='abcd', length=3)) == 3



# Generated at 2022-06-12 01:42:39.462426
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method __call__ of class Choice."""
    # Arrange
    chooser = Choice()
    # Act
    try:
        choice = chooser(items=['a', 'b', 'c'], length=1)
        # Assert
        assert choice == ['a'], "Test failed"
    except Exception as e:
        print("test_Choice___call__ Exception: ", e)
        assert False, "Test failed"



# Generated at 2022-06-12 01:42:40.552127
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    '''
    Test calling a function.
    '''
    pass


# Generated at 2022-06-12 01:42:45.985666
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice('en').choice({1,2,3}) in (1,2,3)
    assert Choice('en').choice('abc') in 'abc'
    assert Choice('en').choice(('a', 'b', 'c')) in ('a', 'b', 'c')
    assert Choice('en').choice({'a', 'b', 'c'}) in {'a', 'b', 'c'}
    assert Choice('en').choice(set('abc')) in set('abc')

# Generated at 2022-06-12 01:42:51.345779
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test Choice.__call__()."""
    items = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    choice = Choice()
    result = choice(items, 10, True)
    assert isinstance(result, (list, tuple, str))
    assert len(result) == 10
    assert not isinstance(result, str) or len(result) == 10

# Generated at 2022-06-12 01:42:59.745520
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method __call__ of class Choice"""
    _choice = Choice()
    _choice(items=['a', 'b', 'c'])
    _choice(items=['a', 'b', 'c'], length=1)
    _choice(items='abc', length=2)
    _choice(items=('a', 'b', 'c'), length=5)
    _choice(items='aabbbccccddddd', length=4, unique=True)
    _choice(items=['a', 'b', 'c'], length=1, unique=True)


# Generated at 2022-06-12 01:43:01.300806
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method __call__ of class Choice.

    This method does not currently have a direct unit test.
    """
    return None


# Generated at 2022-06-12 01:44:27.728105
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # 
    data = Choice().__call__(items=['a', 'b', 'c'], length=1)
    assert data == ['a']

    # 
    data = Choice().__call__(items=['a', 'b', 'c'], length=1)
    assert data == ['b']

    # 
    data = Choice().__call__(items=['a', 'b', 'c'], length=1)
    assert data == ['c']

    # 
    data = Choice().__call__(items=['a', 'b', 'c'], length=2)
    assert data == ['a', 'a']

    # 
    data = Choice().__call__(items=['a', 'b', 'c'], length=2)
    assert data == ['a', 'b']

    # 

# Generated at 2022-06-12 01:44:33.328360
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    example = Choice()
    assert example(items=['a', 'b', 'c']) == 'c'
    assert example(items=['a', 'b', 'c'], length=1) == ['a']
    assert example(items='abc', length=2) == 'ba'
    assert example(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert example(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-12 01:44:39.930878
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    # test data type error exceptions
    try:
        choice(items=['a', 'b', 'c'], length='abc')
    except TypeError:
        pass
    else:
        assert False

    # test value error exceptions
    try:
        choice(items=['a', 'b', 'c'], length=-1)
    except ValueError:
        pass
    else:
        assert False

    try:
        choice(items=['a', 'b', 'c'], length=4, unique=True)
    except ValueError:
        pass
    else:
        assert False

    # test results
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']


# Generated at 2022-06-12 01:44:48.034793
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-12 01:44:53.198132
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:45:01.370275
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    ch = Choice()
    assert ch(['a', 'b', 'c']) in ('a', 'b', 'c')
    assert ch(['a', 'b', 'c'], 1) == ['b']
    assert ch('abc', 2) in ('ab', 'bc', 'ac')
    assert sorted(ch('aabbbccccddddd', 4, True)) == ['a', 'b', 'c', 'd']
    assert ch('aabbbccccddddd', 5, True) in ['abdcc', 'baccd', 'bcdda', 'adbcb']
    assert ch(('a', 'b', 'c'), 5) == ('a', 'c', 'c', 'a', 'a')
    assert ch((1, 2, 3), 3) == (2, 3, 1)

# Generated at 2022-06-12 01:45:08.845489
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    print(Choice.__call__(items=['a', 'b', 'c'], unique=False, length=0))
    print(Choice.__call__(items=['a', 'b', 'c'], unique=False, length=1))
    print(Choice.__call__(items='abc', unique=False, length=2))
    print(Choice.__call__(items=('a', 'b', 'c'), unique=False, length=5))
    print(Choice.__call__(items='aabbbccccddddd', unique=True, length=4))
    print()


# Generated at 2022-06-12 01:45:19.086847
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    # Test with items is list
    items = [1, 2, 3]
    length = 3
    res = choice(items, length, True)
    assert (len(res) == length)
    assert (len(set(res)) == length)
    for i in items:
        assert (i in res)
    # Test with items is tuple
    items = (1, 2, 3)
    length = 3
    res = choice(items, length, True)
    assert (len(res) == length)
    assert (len(set(res)) == length)
    for i in items:
        assert (i in res)
    # Test with items is string
    items = '123'
    length = 3
    res = choice(items, length, True)
    assert (len(res) == length)


# Generated at 2022-06-12 01:45:25.599723
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:45:35.240320
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    assert Choice().__call__(items=[], length=0) == None
    assert Choice().__call__(items=[], length=1) == None
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'