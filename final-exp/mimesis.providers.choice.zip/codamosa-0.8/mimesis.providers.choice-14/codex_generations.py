

# Generated at 2022-06-12 01:35:53.640567
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    for seed in range(10):
        for items in ([1, 2, 3, 4, 5], ['a', 'b', 'c'], ('a', 'b', 'c'), 'abc'):
            choice = Choice(seed=seed)
            assert choice(items=items) in items
            assert choice(items=items, length=1) == [choice(items=items)]
            assert choice(items=items, length=2) in [
                ''.join(c)
                for c in [
                    (choice(items=items), choice(items=items)),
                    (choice(items=items), choice(items=items)),
                    (choice(items=items), choice(items=items))
                ]
            ]

# Generated at 2022-06-12 01:35:57.762283
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 1
    unique = True
    print(choice(items, length, unique))
    length = 2
    unique = False
    print(choice(items, length, unique))



# Generated at 2022-06-12 01:36:07.624128
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert isinstance(choice( items=['a', 'b', 'c']), str)
    assert isinstance(choice( items=['a', 'b', 'c'], length=1), list)
    assert isinstance(choice( items='abc', length=2), str)
    assert isinstance(choice( items=('a', 'b', 'c'), length=5), tuple)
    assert isinstance(choice( items='aabbbccccddddd', length=4, unique=True), str)
    assert choice( items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice( items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]

# Generated at 2022-06-12 01:36:14.264301
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(['a', 'b', 'c']) == 'c'
    assert Choice().__call__(['a', 'b', 'c'], 1) == ['a']
    assert Choice().__call__('abc', 2) == 'ba'
    assert Choice().__call__(('a', 'b', 'c'), 5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__('aabbbccccddddd', 4, True) == 'cdba'


# Generated at 2022-06-12 01:36:18.808869
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Init
    obj = Choice()
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    expected = 'c'

    # Run
    actual = obj(items=items, length=length, unique=unique)

    # Assert
    assert actual == expected


# Generated at 2022-06-12 01:36:29.596000
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    seq = ['a', 'b', 'c']
    assert Choice()(seq) in seq

    seq = ['a', 'b', 'c']
    assert Choice()(seq, 0) in seq

    seq = ['a', 'b', 'c']
    assert Choice()(seq, 1)[0] in seq

    seq = ['a', 'b', 'c']
    assert len(Choice()(seq, 2)) == 2

    seq = ['a', 'b', 'c']
    for i in range(10):
        assert len(Choice()(seq, i)) == i

    seq = ['a', 'b', 'c']
    assert Choice()(seq, 5) == ['a', 'b', 'c', 'b', 'a']

    seq = ['a', 'b', 'c']

# Generated at 2022-06-12 01:36:36.195104
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:36:44.894214
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    obj = Choice()
    assert obj(['a', 'b', 'c']) == 'a'
    assert obj(['a', 'b', 'c'], length=1) == ['b']
    assert obj('abc', length=2) == 'ab'
    assert obj(('a', 'b', 'c'), length=5) == ('a', 'b', 'a', 'b', 'c')
    assert obj('aabbbccccddddd', length=4, unique=True) == 'abdc'


# Generated at 2022-06-12 01:36:55.740634
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Test 1: Non-negative integer length and unique is False
    choice = Choice()
    length = 1
    items = [1, 2, 3]
    assert choice(items, length, False) in items
    length = 0
    assert choice(items, length, False) in items
    items = 'abc'
    assert choice(items, length, False) in items
    items = (1, 2, 3)
    assert choice(items, length, False) in items
    items = 'aabbbccccddddd'
    assert choice(items, length, False) in items
    
    # Test 2: Non-negative integer length and unique is True
    length = 1
    items = [1, 2, 3]
    assert choice(items, length, True) in items
    items = 'abc'

# Generated at 2022-06-12 01:37:06.613178
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Test for method __call__ of class Choice.
    from mimesis import Choice

    # Create a test Choice object.
    choice = Choice()

    # Assert returns an element from a list.
    item = choice(items=['a', 'b', 'c'])
    assert item

    # Assert returns a list of a specified length.
    item = choice(items=['a', 'b', 'c'], length=1)
    assert item
    assert len(item) == 1

    # Assert returns a string of a specified length.
    item = choice(items='abc', length=2)
    assert item
    assert len(item) == 2

    # Assert returns a tuple of a specified length.
    item = choice(items=('a', 'b', 'c'), length=5)
    assert item
    assert len

# Generated at 2022-06-12 01:37:14.472477
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:37:26.339328
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    class Meta:
        name = 'choice'

    class Choice:
        class Meta:
            name = 'choice'

        def __init__(self, meta):
            self._random = None
            self._meta = meta

        def __call__(self, items: Optional[Sequence[Any]], length: int = 0, unique: bool = False) -> Union[Sequence[Any], Any]:
            if not isinstance(length, int):
                raise TypeError('**length** must be integer.')

            if not isinstance(items, collections.abc.Sequence):
                raise TypeError('**items** must be non-empty sequence.')

            if not items:
                raise ValueError('**items** must be a non-empty sequence.')

            if length < 0:
                raise ValueError('**length** should be a positive integer.')

# Generated at 2022-06-12 01:37:37.341669
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # docstring example
    choice = Choice()
    choice(items=['a', 'b', 'c'])
    choice(items=['a', 'b', 'c'], length=1)
    choice(items='abc', length=2)
    choice(items=('a', 'b', 'c'), length=5)
    choice(items='aabbbccccddddd', length=4, unique=True)

    try:
        choice('a', 1)
    except TypeError:
        pass
    try:
        choice(1, 1)
    except TypeError:
        pass
    try:
        choice([], 1)
    except ValueError:
        pass
    try:
        choice(['a'], -1)
    except ValueError:
        pass

# Generated at 2022-06-12 01:37:47.840797
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.builtins import Choice
    from mimesis import Datetime
    from mimesis import Generic
    from mimesis import Person
    from mimesis.enums import Gender

    choice = Choice()
    dt = Datetime()
    g = Generic()
    p = Person('en')

    # Assert argument 'items' is not empty
    assert choice(items='') == ' '
    assert choice(items='qwertyuiop', length=1) == 'y'
    assert choice(items='qwertyuiop', length=3) == 'qou'
    assert choice(items='qwertyuiop', length=3, unique=True) == 'ryo'
    assert choice(items=[1, 2, 3], length=4, unique=True) == [1, 3, 2, 1]


# Generated at 2022-06-12 01:37:58.451449
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    choice = Choice()
    assert choice(items=[1, 2, 3, 4, 5]) in [1, 2, 3, 4, 5]
    assert choice(items=[1, 2, 3, 4, 5], length=1) in [[1], [2], [3], [4], [5]]
    assert choice(items=[1, 2, 3, 4, 5], length=2) in [[1, 2], [2, 3], [3, 4], [4, 5], [5, 1]]
    assert choice(items=[1, 2, 3, 4, 5], length=3) in [[1, 2, 3], [2, 3, 4], [3, 4, 5], [4, 5, 1], [5, 1, 2]]

# Generated at 2022-06-12 01:38:05.740936
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    string_items = 'abcdefg'
    assert Choice().__call__(string_items) in string_items

    sequence_items = ['a', 'b', 'c', 'd']
    length = 2
    assert len(Choice().__call__(sequence_items, length)) == length

    unique_items = 'abbbccccdddd'
    length = 2
    assert len(set(Choice().__call__(unique_items, length, unique=True))) == length


# Generated at 2022-06-12 01:38:16.973652
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice()(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert Choice()(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert Choice()(items='abc', length=2) in ['ab', 'bc', 'ca']
    assert Choice()(items=('a', 'b', 'c'), length=5) in [('a', 'a', 'b', 'c', 'c'),
                                                         ('a', 'b', 'c', 'a', 'c'),
                                                         ('a', 'b', 'c', 'c', 'a')]

# Generated at 2022-06-12 01:38:25.868745
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice.Meta.name == 'choice'

    # Check for exception TypeError
    try:
        Choice()()
    except TypeError:
        pass
    else:
        assert False

    # Check for exception TypeError
    try:
        Choice()(items=0)
    except TypeError:
        pass
    else:
        assert False

    # Check for exception TypeError
    try:
        Choice()(items=[], length='abc')
    except TypeError:
        pass
    else:
        assert False

    # Check for exception ValueError
    try:
        Choice()(items=[])
    except ValueError:
        pass
    else:
        assert False

    # Check for exception ValueError

# Generated at 2022-06-12 01:38:35.422210
# Unit test for method __call__ of class Choice

# Generated at 2022-06-12 01:38:37.108053
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    choice(items=['a', 'b', 'c'], length=1)
    # TODO: Test for error

# Generated at 2022-06-12 01:38:47.392123
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = ['a', 'b', 'c']
    assert choice(items=items) == 'c'
    assert choice(items=items, length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=tuple(items), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-12 01:38:47.803193
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-12 01:38:55.919745
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-12 01:39:06.916396
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Unit test for case when **length** is negative.
    choice_1 = Choice()
    try:
        choice_1(['a', 'b', 'c'], length=-1)
    except ValueError:
        pass
    else:
        raise AssertionError
    # Unit test for case when **items** is empty.
    choice_2 = Choice()
    try:
        choice_2([], length=1)
    except ValueError:
        pass
    else:
        raise AssertionError
    # Unit test for case when **items** is not a sequence.
    choice_3 = Choice()
    try:
        choice_3(1.0, length=1)
    except TypeError:
        pass
    else:
        raise AssertionError
    # Unit test for case when **length** is not integer.

# Generated at 2022-06-12 01:39:12.357840
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ba', 'ca', 'ab', 'ac']

# Generated at 2022-06-12 01:39:19.700149
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    pass



# Generated at 2022-06-12 01:39:31.173172
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice.Meta.name == 'choice'

    choice = Choice()
    sequence = ['a', 'b', 'c']

    assert isinstance(choice(sequence), str)
    assert isinstance(choice(sequence, length=1), list)
    assert isinstance(choice(sequence, length=3), list)
    assert isinstance(choice('abc', length=1), str)
    assert isinstance(choice('abc', length=2), str)
    assert isinstance(choice(('a', 'b', 'c'), length=1), tuple)
    assert isinstance(choice(('a', 'b', 'c'), length=5), tuple)
    assert isinstance(choice('aabbbccccddddd', length=4, unique=True), str)

    assert choice(sequence) in sequence

# Generated at 2022-06-12 01:39:38.837519
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(['a', 'b', 'c']) in ['a', 'b', 'c']

    # Short random data does not guarantee all cases will be checked
    for _ in range(1000):
        assert Choice().__call__(['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
        assert Choice().__call__(['a', 'b', 'c'], length=2) in [['a', 'b'], ['a', 'c'], ['b', 'a'], ['b', 'c'], ['c', 'a'], ['c', 'b']]
        assert Choice().__call__(['a', 'b', 'c'], length=3) in [['a', 'b', 'c']]


# Generated at 2022-06-12 01:39:39.762109
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-12 01:39:45.678796
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    _items = ['a', 'b', 'c']
    _length = 1
    _unique = False
    c = Choice()
    result = c(items=_items, length=_length, unique=_unique)
    assert result == 'c' or result == 'a' or result == 'b'

if __name__ == '__main__':
    test_Choice___call__()

# Generated at 2022-06-12 01:40:00.561932
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method __call__ of class Choice."""
    # TODO: Rewrite test with pytest
    from mimesis.choice import Choice
    from mimesis.builtins import Builtins

    choice = Choice(Builtins)
    assert not isinstance(choice.items('test'), tuple)
    assert not isinstance(choice.items('test'), str)
    assert isinstance(choice.items('test'), list)
    assert len(choice.items('test', 4)) == 4
    assert not isinstance(choice.items('test', 4), str)
    assert not isinstance(choice.items('test', 4), tuple)
    assert isinstance(choice.items('test', 4), list)
    assert choice.items('test', unique=True)
    assert choice.items('test', unique=True)

# Generated at 2022-06-12 01:40:10.723320
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    from mimesis.enums import Gender
    choice = Choice()
    assert choice(items=Gender.MALE.value) in Gender.MALE.value
    assert choice(items=Gender.MALE.value, length=1) == [Gender.MALE.value[0]]
    assert choice(items=Gender.MALE.value, length=2) == ['m', 'm']
    assert len(choice(items=Gender.MALE.value, length=5)) == 5
    assert choice(items=Gender.MALE.value, length=1, unique=True) == ['m']
    assert len(choice(items=Gender.MALE.value, length=2, unique=True)) == 2
    # Exceptions

# Generated at 2022-06-12 01:40:13.741653
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    obj = Choice()
    assert isinstance(obj(items, length, unique), tuple)
    return True


# Generated at 2022-06-12 01:40:15.488202
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TODO: Method not yet implemented.
    pass


# Generated at 2022-06-12 01:40:19.171012
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Setup
    items = ["a", "b", "c"]
    length = 2
    unique = False
    
    # Exercise
    result = Choice()(items, length, unique)
    
    # Verify
    assert len(result) == length



# Generated at 2022-06-12 01:40:20.287434
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-12 01:40:28.701471
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice

    choice = Choice()

    assert choice(items=('a', 'b', 'c')) in ('a', 'b', 'c')
    assert choice(items=('a', 'b', 'c'), length=1) in (('a',), ('b',), ('c',))
    assert choice(items='abc', length=2) in ('ab', 'ac', 'ba', 'bc', 'ca', 'cb')

# Generated at 2022-06-12 01:40:33.966519
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = 'abc'
    length = 2
    unique = True
    expected = 'ca'

    choice = Choice()
    result = choice(items=items, length=length, unique=unique)
    try:
        assert result == expected
    except:
        print("Error: test_Choice___call__")
        exit(1)
    print("Success: test_Choice___call__")



# Generated at 2022-06-12 01:40:41.486857
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()

    assert isinstance(choice(items=['a','b','c']), str)
    assert isinstance(choice(items=['a','b','c'], length=1), list)
    assert isinstance(choice(items='abc', length=2), str)
    assert isinstance(choice(items=('a', 'b', 'c'), length=5), tuple)
    assert isinstance(choice(items='aabbbccccddddd', length=4, unique=True), str)

# Generated at 2022-06-12 01:40:51.257439
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Given
    from mimesis import Choice
    choice = Choice()

    # When
    result_items = choice(items=['a', 'b', 'c'])
    # Then
    assert result_items in ['a', 'b', 'c']

    # When
    result_items_length = choice(items=['a', 'b', 'c'], length=1)
    # Then
    assert result_items_length == ['a'] or result_items_length == ['b'] or result_items_length == ['c']

    # When
    result_items_length_unique = choice(items=['a', 'b', 'c'], length=1, unique=True)
    # Then
    assert result_items_length_unique == ['a'] or result_items_length_unique == ['b'] or result_items_length

# Generated at 2022-06-12 01:41:15.114297
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test Choice.__call__()."""
    import pytest

    tester = Choice()

    with pytest.raises(TypeError) as context:
        tester(items=['a', 'b', 'c'], length='1')
    assert str(context.value) == '**length** must be integer.'

    with pytest.raises(TypeError) as context:
        tester(items={'a': 1, 'b': 2, 'c': 3})
    assert (
        str(context.value) == "**items** must be non-empty sequence."
    )

    with pytest.raises(ValueError) as context:
        tester(items=[], length=0)
    assert (
        str(context.value) == "**items** must be a non-empty sequence."
    )


# Generated at 2022-06-12 01:41:25.002374
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice()._Choice__call__(['a', 'b', 'c']) in ['a', 'b', 'c']
    assert Choice()._Choice__call__(['a', 'b', 'c'], 1) in [['a'], ['b'], ['c']]
    assert Choice()._Choice__call__('abc', 2) in ['ba', 'bc', 'ac', 'ab', 'ca', 'cb']

# Generated at 2022-06-12 01:41:30.033719
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice()(items=['a', 'b', 'c']) == 'c'
    assert Choice()(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice()(items='abc', length=2) == 'ba'
    assert Choice()(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice()(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


from mimesis.enums import Gender
from mimesis.providers.person import Person
from mimesis.providers.person.en_us import EnUSPerson
from mimesis.providers.person.ru import RuPerson

# Generated at 2022-06-12 01:41:32.836158
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    import doctest
    doctest.testmod(verbose=True, optionflags=doctest.NORMALIZE_WHITESPACE)

# Generated at 2022-06-12 01:41:35.429770
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    foo = Choice()
    assert len(foo(items=[1,2,3,4,5,6], length=5))==5
    assert isinstance(foo(items='abc', length=2),str)


# Generated at 2022-06-12 01:41:40.548421
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    provider = Choice(random_module=DevNullRandom())
    result = provider(items=[1, 2, 3, 4, 5], length=4)
    assert isinstance(result, list)
    assert result == [1, 2, 3, 4]

if __name__ == "__main__":
    test_Choice___call__()
    print("Success")

# Generated at 2022-06-12 01:41:46.536480
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-12 01:41:54.365829
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['c']
    assert choice(items='abc', length=2) == 'ac'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:41:59.890532
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    # example 1
    items = ('a', 'b', 'c')
    length = 2
    assert choice(items=items, length=length) == 'bc'
    # example 2
    items = ('a', 'b', 'c')
    length = 2
    assert choice(items=items, length=length) == 'bc'
    # example 3
    items = 'abcd'
    length = 2
    assert choice(items=items, length=length) == 'ac'
    # example 4
    items = 'abcd'
    length = 2
    assert choice(items=items, length=length) == 'bd'
    # example 5
    items = 'abcd'
    length = 2
    assert choice(items=items, length=length) == 'ad'


# Generated at 2022-06-12 01:42:06.861035
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    x = Choice()
    assert(x(items=['a', 'b', 'c']) == 'a')
    assert(x(items=['a', 'b', 'c'], length=1) == ['a'])
    assert(x(items='abc', length=2) == 'ba')
    assert(x(items=('a', 'b', 'c'), length=5) == ('a', 'c', 'b', 'c', 'a'))
    assert(x(items='aabbbccccddddd', length=4, unique=True) == 'dbac')
    return

# Generated at 2022-06-12 01:42:51.073662
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice # from mimesis.providers.choice import Choice
    choice = Choice()
    
    # choice(items=['a', 'b', 'c'])
    items = ['a', 'b', 'c']
    result = choice(items=items)
    assert result in items
    
    # >>> choice(items=['a', 'b', 'c'], length=1)
    items = ['a', 'b', 'c']
    length = 1
    result = choice(items=items, length=length)
    assert len(result) == length and all(e in items for e in result)
   
    # >>> choice(items='abc', length=2)
    items = 'abc'
    length = 2
    result = choice(items=items, length=length)

# Generated at 2022-06-12 01:43:01.256871
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert c(items=['a', 'b'], length=1) == ['b']
    assert c(items='aabbbccccddddd', length=4, unique=True) in ['bcdc', 'ddca', 'dbcc', 'cadb', 'ccbd', 'cadb', 'ccbd']
    assert c(items=('a', 'b', 'c'), length=5) in [('b', 'b', 'c', 'b', 'a'), ('b', 'a', 'a', 'c', 'c')]
    assert c(items='abc', length=2) in ['ca', 'bc', 'ab']
    assert c(items=['a', 'b', 'c'], length=0) in ['c', 'a', 'b']

# Generated at 2022-06-12 01:43:11.332175
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.choice import Choice
    c = Choice()
    assert isinstance(c, BaseProvider)
    assert isinstance(c, Choice)
    assert c.random.choice(['this', 'is', 'a', 'test']) in ['this', 'is', 'a', 'test']
    assert c.random.choice('aabbbccccddddd') in 'aabbbccccddddd'
    assert c(items=['this', 'is', 'a', 'test']) in ['this', 'is', 'a', 'test']
    assert c(items=['this', 'is', 'a', 'test'], length=1) in [['this'], ['is'], ['a'], ['test']]

# Generated at 2022-06-12 01:43:12.124644
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TODO
    # assert False
    pass

# Generated at 2022-06-12 01:43:14.222443
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = ['a', 'b', 'c']
    result = choice(items)
    assert result in items


# Generated at 2022-06-12 01:43:17.279962
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 1

    expected = ['a']
    actual = choice(items, length=length)

    assert actual == expected


# Generated at 2022-06-12 01:43:24.327318
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=('a', 'b', 'c')) == 'c'
    assert choice(items=('a', 'b', 'c'), length=1) == ('a', )
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:43:33.431476
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import random
    import pytest
    choice = Choice()
    assert isinstance(choice(items=[]), str) == True
    assert isinstance(choice(items=[], length=2), list) == True
    assert isinstance(choice(items=[], unique=True), str) == True
    assert isinstance(choice(items=[], unique=True, length=1), list) == True
    assert isinstance(choice(items=1.0, unique=True, length=2), str) == True
    assert isinstance(choice(items='mimesis', length=3), str) == True
    assert isinstance(choice(items='mimesis', length=2, unique=True), str) == True
    assert isinstance(choice(items='mimesis', length=3, unique=True), str) == True

# Generated at 2022-06-12 01:43:44.132779
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    class X:
        pass
    print(Choice().__call__([1, 2, 3, 4, 5], 2, True))
    print(Choice().__call__((1, 2, 3, 4, 5), 2, True))
    print(Choice().__call__('123456', 2, True))
    print(Choice().__call__(range(10), 5, True))
    print(Choice().__call__('aaabbbcccddd', 6, True))
    print(Choice().__call__({1, 2, 3, 4, 5}, 3, True))
    print(Choice().__call__(set([1, 2, 3, 4, 5]), 3, True))
    print(Choice().__call__({'a': 1, 'b': 2, 'c': 3}, 3, True))

# Generated at 2022-06-12 01:43:52.567535
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test ``Choice().__call__()``"""
    choice = Choice()
    assert isinstance(choice.__call__(items=['a', 'b', 'c']), str)
    assert isinstance(choice.__call__(items=['a', 'b', 'c'], length=1), list)
    assert isinstance(choice.__call__(items='abc', length=2), str)
    assert isinstance(choice.__call__(items=('a', 'b', 'c'), length=5), tuple)
    assert isinstance(choice.__call__(items='aabbbccccddddd', length=4, unique=True), str)
    assert isinstance(choice.__call__(items='aabbbccccddddd', length=4), str)

