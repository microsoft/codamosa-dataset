

# Generated at 2022-06-12 01:35:54.141519
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Tests that random choice returns a bare item and a sequence of items.
    
    """
    # First argument is the sequence of items to choose from
    items = ['a', 'b', 'c']
    # Second argument is the length of the sequence to return, which can be 0,
    # in which case a bare item will be returned (that is, not wrapped in a
    # sequence)
    length = 1
    # Third argument is whether a sequence should be returned with unique
    # elements or not
    unique = False

    random_choice = Choice()
    # Call __call__ method of class Choice
    random_choice(items=items, length=length, unique=unique)

# Generated at 2022-06-12 01:36:02.708329
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-12 01:36:11.189546
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method __call__ of class Choice."""

# Generated at 2022-06-12 01:36:18.390876
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender
    from mimesis.schema import Field
    from mimesis.providers.choice import Choice
    from mimesis.providers.person import Person
    from mimesis.builtins import MetaBaseProvider
    from mimesis.session import Session
    from mimesis.utils import get_random

    class BaseTest:
        """Create a basic data class."""

        def __init__(self):
            """Initialize attributes."""
            self.choice = Choice(localization='en')
            self.person = Person('en')

    test = BaseTest()

    result = test.choice(items=['a', 'b', 'c'])
    assert result in ['a', 'b', 'c']


# Generated at 2022-06-12 01:36:24.112585
# Unit test for method __call__ of class Choice

# Generated at 2022-06-12 01:36:26.287318
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    s = choice(items=[1, 2, 3], length=3)
    assert len(s) == 3


# Generated at 2022-06-12 01:36:36.301849
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 1
    assert Choice().__call__(items=items,length=length) == ['a']


# Generated at 2022-06-12 01:36:47.676965
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    Choice()(items=['a', 'b', 'c']);
    Choice()(items=['a', 'b', 'c'], length=1);
    Choice()(items='abc', length=2);
    Choice()(items=('a', 'b', 'c'), length=5);
    Choice()(items='aabbbccccddddd', length=4, unique=True);
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) == 'ba'

# Generated at 2022-06-12 01:36:55.887920
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    provider = Choice()
    assert provider(items=['a', 'b', 'c']) == 'c'
    assert provider(items=['a', 'b', 'c'], length=1) == ['a']
    assert provider(items='abc', length=2) == 'ba'
    assert provider(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert provider(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:37:06.806905
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    class ClassA:
        def __init__(self):
            self._x = random.randint(1,10)
            self._y = random.randint(1,10)
            self._z = random.randint(1,10)

        @property
        def x(self):
            return self._x
        @property
        def y(self):
            return self._y
        @property
        def z(self):
            return self._z

    my_tuple = ('a', 'b', 'c', 'd', 'e')
    my_str = '123456789'
    my_list = [1, 2, 3, 4, 5, 6, 7, 8, 9]
    my_dict = {'x': 1, 'y': 2, 'z': 3}
    my_obj = ClassA

# Generated at 2022-06-12 01:37:17.005772
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    from mimesis.exceptions import NonUniqueError

    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']

    choice = Choice()
    assert choice(items=[1, 2, 3, 4], length=5) == [3, 3, 3, 3, 3]

    choice = Choice()
    assert choice(items=(1, 2, 3), length=10, unique=True) == (1, 1, 3, 3, 2)

    choice = Choice()
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']

    choice = Choice()

# Generated at 2022-06-12 01:37:27.356608
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    item1 = choice(items=['a', 'b', 'c'])
    item2 = choice(items=['a', 'b', 'c'], length=1)
    item3 = choice(items='abc', length=2)
    item4 = choice(items=('a', 'b', 'c'), length=5)
    item5 = choice(items='aabbbccccddddd', length=4, unique=True)

    assert item1 in ['a', 'b', 'c']
    assert item2 in [['a'], ['b'], ['c']]
    assert item3 in ['ba', 'ab', 'ac', 'ca', 'cb']

# Generated at 2022-06-12 01:37:37.820236
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    data = choice(items=['a', 'b', 'c'])
    assert data in ['a', 'b', 'c']
    data = choice(items=['a', 'b', 'c'], length=1)
    assert data in [['a'], ['b'], ['c']]
    data = choice(items='abc', length=2)
    assert data in ['ab', 'ac', 'bc']
    data = choice(items=('a', 'b', 'c'), length=5)
    assert data in [('a', 'b', 'c', 'a', 'b'), ('a', 'b', 'c', 'a', 'c'), ('a', 'b', 'c', 'b', 'c')]
    data = choice(items=('a', 'b', 'c'), length=0)

# Generated at 2022-06-12 01:37:47.881964
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ab', 'ac', 'bc']
    assert choice(items=('a', 'b', 'c'), length=5) in [('c', 'a', 'a', 'b', 'c'), ('b', 'b', 'c', 'a', 'a')]
    assert choice(items='aabbbccccddddd', length=4, unique=True) in ['cdba', 'acbd']


 # Unit test for method __call__ of class Choice

# Generated at 2022-06-12 01:37:58.451054
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert c(['a', 'b', 'c']) in ['a', 'b', 'c']
    assert c(['a', 'b', 'c'], 2) == ['b', 'c']
    assert c(['a', 'b', 'c'], 2, unique=True) == ['a', 'b']
    assert c(('a', 'b', 'c')) in ('a', 'b', 'c')
    assert c(('a', 'b', 'c'), 2) == ('b', 'c')
    assert c(('a', 'b', 'c'), 2, unique=True) == ('a', 'b')
    assert c('abc') in 'abc'
    assert c('abc', 2) == 'bc'
    assert c('abc', 2, unique=True) == 'ac'


# Generated at 2022-06-12 01:38:08.905784
# Unit test for method __call__ of class Choice

# Generated at 2022-06-12 01:38:19.143978
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert c(['a','b','c','d','e','f']) in ['a','b','c','d','e','f']
    assert c(['a','b','c','d','e','f'],2) in [('a','b'),('a','c'),('a','d'),('b','c'),('b','d'),('c','d')]
    assert c('abc',2) in ['ba','bc','ca']
    assert c(('a','b','c','d','e','f'),3) in [('c','a','b'),('c','a','d'),('c','e','d'),('c','d','e'),('c','e','b'),('c','d','b')]

# Generated at 2022-06-12 01:38:24.268950
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c'], length=1, unique=True) == ['b']
    assert Choice().__call__(items='abc', length=2, unique=False) == 'cc'
    assert Choice().__call__(items=('a', 'b', 'c'), length=4, unique=True) == ('c', 'b', 'a', 'a')


# Generated at 2022-06-12 01:38:25.515760
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    print(c(items=['a', 'b', 'c'], length=5))

# Generated at 2022-06-12 01:38:29.368648
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    choice = Choice()
    name = Person('en', Gender.FEMALE).full_name()
    assert choice(items=name, length=1) == [name]
    assert choice(items=[name], length=0) == name

# Generated at 2022-06-12 01:38:35.545423
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    input_items = ['a', 'b', 'c']
    expected_output = ['c']
    assert Choice().__call__(input_items, length=1) == expected_output


# Generated at 2022-06-12 01:38:40.648141
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().choice(['a', 'b', 'c']) in list('abc')
    assert len(Choice().choice(['a', 'b', 'c'], length=1)) == 1
    assert len(Choice().choice(list(range(10)), length=4)) == 4



# Generated at 2022-06-12 01:38:45.579414
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c', 'd', 'e']
    length = 4
    choice = Choice()
    print(choice(items=items, length=length))
    print(choice(items=items))
    print(choice(items=items, unique=True))


if __name__ == '__main__':
    test_Choice___call__()

# Generated at 2022-06-12 01:38:48.936547
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Ensure method's name is as expected."""
    # arrange
    from mimesis import Choice

    # act
    choice = Choice()

    # assert
    assert callable(choice.__call__)


# Generated at 2022-06-12 01:38:58.655194
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:39:08.877697
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Test of Choice()
    # Initializes an instance of Choice
    choice = Choice()
    # Choice must be instance of Choice
    assert isinstance(choice, Choice)
    # Choice() cannot call without arguments
    # And must return ValueError:
    # TypeError: __call__() missing 2 required positional arguments:
    # 'items' and 'length'
    with pytest.raises(TypeError):
        choice()
    # Choice(items=['a', 'b', 'c']) must return one of ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    # Choice(items=['a', 'b', 'c'], length=1)
    # must return list of one of ['a', 'b', 'c']

# Generated at 2022-06-12 01:39:12.171968
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = 'abcdefgh'
    length = 7
    unique = True
    data = choice(items, length, unique)
    print(data)


# Generated at 2022-06-12 01:39:21.620468
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import random
    import sys

    import pytest

    from mimesis.providers.choice import Choice
    from mimesis.tests.utils import assert_provider_methods_are_defined

    assert_provider_methods_are_defined(Choice)
    choices = Choice(seed=42)
    assert isinstance(choices._random, random.Random)
    assert choices._random is not random.random
    assert choices._random.getstate() == random.Random(42).getstate()
    assert choices.seed == 42
    assert (choices(items=['a', 'b', 'c']) == 'b')
    assert choices(items=['a', 'b', 'c'], length=1) == ['a']
    assert choices(items='abc', length=2) == 'cb'

# Generated at 2022-06-12 01:39:31.329650
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method __call__ of class Choice."""
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:39:39.579098
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test the method __call__ of class Choice."""
    # NOTE
    # 1. The class Choice inherits from the BaseProvider.
    # 2. The method __call__ of the class Choice has 6 dictionaries of tests.
    #    Each dictionary has an assertion that tests a particular case.
    # 3. The keys of the dictionaries are:
    #    'items' - the items that are needed to compute the result of the
    #              method __call__ of class Choice
    #    'length' - to compute the length of the result of the method
    #               __call__ of class Choice
    #    'unique' - to compute if the value of the result of the method
    #               __call__ of class Choice will be unique
    #    'value' - the expected value of the result of the method __call__
    #              of class Choice


# Generated at 2022-06-12 01:39:54.601120
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    item_list = ['a', 'b', 'c']
    item_tuple = ('a', 'b', 'c')
    item_string = 'abc'
    length = 2
    unique = True
    assert choice(item_list) in item_list and isinstance(choice(item_list), str)
    assert choice(item_list, length) == ['c']
    assert choice(item_string, length) == 'ba'
    assert choice(item_tuple, length) == ('c', 'b')
    assert choice(item_string, length, unique) == 'cb'
    try:
        choice(item_list, length='test')
    except TypeError as e:
        assert '**length** must be integer.' in str(e)

# Generated at 2022-06-12 01:39:59.194197
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    length = 3
    unique = True
    # type: ignore
    # E: Deferred attribute import

    choice = Choice()
    # CallableProvider.__call__(items=items, length=3, unique=True)
    assert choice.__call__(items=items, length=length, unique=unique) == 'abc'



# Generated at 2022-06-12 01:40:09.204687
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test Choice.__call__().

    It should be able to generate a randomly-chosen sequence or bare element
    from a sequence. Provide elements randomly chosen from the elements in a
    sequence **items**, where when **length** is specified the random choices
    are contained in a sequence of the same type of length **length**,
    otherwise a single uncontained element is chosen. If **unique** is set to
    True, constrain a returned sequence to contain only unique elements.
    """
    # Should be type error
    try:
        Choice().__call__(['a', 'b', 'c'], length='a')
    except TypeError:
        pass

    # Should be type error
    try:
        Choice().__call__({'a', 'b', 'c'})
    except TypeError:
        pass

    # Should be value error


# Generated at 2022-06-12 01:40:18.837703
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    from typing import Any, Optional, Sequence

    # Example-1
    choice = Choice()
    # Get a randomly-chosen sequence or bare element from a sequence.
    res1 = choice(items=['a', 'b', 'c'], length=0)
    # Expected: 'c'
    res2 = choice(items=['a', 'b', 'c'], length=1)
    # Expected: ['a']
    res3 = choice(items='abc', length=2)
    # Expected: 'ba'
    res4 = choice(items=('a', 'b', 'c'), length=5)
    # Expected: ('c', 'a', 'a', 'b', 'c')

# Generated at 2022-06-12 01:40:25.417127
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    item_1 = choice(items=("a", "b", "c", "d"), length=4, unique=True)
    item_2 = choice(items=("a", "b", "c", "d"), length=4, unique=False)
    assert isinstance(item_1, str)
    assert isinstance(item_1, tuple)
    assert isinstance(item_2, str)
    assert isinstance(item_2, tuple)

# Generated at 2022-06-12 01:40:36.863463
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import pytest
    from mimesis.schema import Field, Schema

    seed = 123
    schema = Schema(seed=seed)
    schema.add_provider(Choice)

    items_number = 50
    items = [schema('choice').__call__(length=0) for _ in range(items_number)]
    assert(len(items) == items_number)
    assert(len(set(items)) == items_number)

    items_number = 50
    items = [schema('choice').__call__(length=1) for _ in range(items_number)]
    assert(len(items) == items_number)
    assert(len(set(items)) == items_number)

    # test with one item
    items_number = 50

# Generated at 2022-06-12 01:40:43.208444
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Tests for method __call__ of class Choice."""
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 1
    unique = False

    if not isinstance(choice(items), str):
        raise ValueError('expected type is str')
    if not isinstance(choice(items, length), list):
        raise ValueError('expected type is list')
    if not isinstance(choice(items, length, unique), list):
        raise ValueError('expected type is list')
    if not isinstance(choice(items, length, True), list):
        raise ValueError('expected type is list')
    if not isinstance(choice(items, 2, True), list):
        raise ValueError('expected type is list')


# Generated at 2022-06-12 01:40:50.992175
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().call(items=['a', 'b', 'c']) == 'c'
    assert Choice().call(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().call(items='abc', length=2) == 'ba'
    assert Choice().call(items=('a', 'b', 'c'), length=5) \
           == ('c', 'a', 'a', 'b', 'c')
    assert Choice().call(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
 

# Generated at 2022-06-12 01:41:00.270065
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice

    choice = Choice()

    # Testing for __call__ method for non-empty sequence
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-12 01:41:06.319194
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    print(choice(items=['a', 'b', 'c']))
    print(choice(items=['a', 'b', 'c'], length=1))
    print(choice(items='abc', length=2))
    print(choice(items=('a', 'b', 'c'), length=5))
    print(choice(items='aabbbccccddddd', length=4, unique=True))



# Generated at 2022-06-12 01:41:26.988595
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert Choice().__call__(items=['a', 'b', 'c'], length=2) in [['a', 'b'], ['a', 'c'], ['b', 'c']]
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]

# Generated at 2022-06-12 01:41:32.489777
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    print(choice(items=['a', 'b', 'c']))
    print(choice(items=['a', 'b', 'c'], length=1))
    print(choice(items='abc', length=2))
    print(choice(items=('a', 'b', 'c'), length=5))
    print(choice(items='aabbbccccddddd', length=4, unique=True))



# Generated at 2022-06-12 01:41:35.188409
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    list_items = ['a','b','c']
    list_length = 1
    list_unique = False

    list_result = Choice(items=list_items, length=list_length, unique=list_unique)

    assert list_result == ['c']

# Generated at 2022-06-12 01:41:45.040881
# Unit test for method __call__ of class Choice
def test_Choice___call__():
  """Tests method __call__ of class Choice."""
  # TODO: Add more unit tests
  choice = Choice()
  assert choice(items=['a', 'b', 'c']) in ['c', 'b', 'a']
  assert choice(items=['a', 'b', 'c'], length=1) in [ ['a'], ['b'], ['c'] ]
  assert choice(items='abc', length=2) in [ 'ba', 'cb', 'ac', 'bc']

# Generated at 2022-06-12 01:41:54.859922
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import json
    from io import StringIO
    from unittest import TestCase, main
    from unittest.mock import patch

    from mimesis.enums import Gender
    from mimesis.exceptions import NonEnumerableError
    from mimesis.providers.datetime import Datetime
    from mimesis.random import Random
    from mimesis.utils import validate_arguments

    class TestChoice(TestCase):
        __test__ = False
        source = 'mimesis.providers.choice.Choice'

        def setUp(self):
            self.datetime = Datetime()
            self.choice = Choice(seed=self.datetime.timestamp())


# Generated at 2022-06-12 01:41:57.806876
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items, length, unique = ('a', 'b', 'c'), 2, True
    result = choice(items, length, unique)
    
    #TODO: What is the format of result?
    assert len(result) == length and result[0] in items and result[1] in items and result[0] != result[1]

# Generated at 2022-06-12 01:42:06.796060
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """
    Test `Choice().__call__()`.

    :return:
    """
    from mimesis import Choice
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ba', 'ac', 'cb']

# Generated at 2022-06-12 01:42:16.654918
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Test case 1:
    # Provide elements randomly chosen from the elements in a list, where
    #  when length is specified the random choices are contained in a list
    #  of the same length, otherwise a single uncontained element is chosen.
    result = Choice().__call__(items=['a', 'b', 'c'], length=1)
    assert isinstance(result, list), "test_Choice___call__: expected list"
    assert len(result) == 1, "test_Choice___call__: expected length 1"
    assert result[0] in ['a', 'b', 'c'], \
            "test_Choice___call__: expected a or b or c"

    # Test case 2:
    # Provide elements randomly chosen from the elements in a tuple, where
    #  when length is specified the random choices are contained in a tuple


# Generated at 2022-06-12 01:42:22.399937
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c1 = Choice()
    print(c1(items=['a', 'b', 'c']))
    print(c1(items=['a', 'b', 'c'], length=1))
    print(c1(items='abc', length=2))
    print(c1(items=('a', 'b', 'c'), length=5))
    print(c1(items='aabbbccccddddd', length=4, unique=True))
    

# Generated at 2022-06-12 01:42:30.555943
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ('a', 'b', 'c')
    length = 5
    unique = True
    choice = Choice(seed=1234567890)
    assert choice(items=items, length=length, unique=unique) == ('a', 'c', 'b', 'c', 'a')

    length = 0
    unique = False
    choice = Choice(seed=1234567890)
    assert choice(items=items, length=length, unique=unique) == 'c'

    items = ['a', 'b', 'c']
    length = 1
    unique = False
    choice = Choice(seed=1234567890)
    assert choice(items=items, length=length, unique=unique) == ['c']

if __name__ == '__main__':
    test_Choice___call__()

# Generated at 2022-06-12 01:43:10.481980
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Tests for method __call__ of class Choice"""
    from mimesis import Choice
    choice = Choice()
    test = choice(items=['a', 'b', 'c'])
    assert test in ['a', 'b', 'c']
    test = choice(items=['a', 'b', 'c'], length=1)
    assert test == ['a'] or test == ['b'] or test == ['c']
    test = choice(items='abc', length=2)
    assert test == 'ba' or test == 'ab' or test == 'ba'
    test = choice(items=('a', 'b', 'c'), length=5)
    assert len(test) == 5
    test = choice(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-12 01:43:17.391725
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method **__call__** of class Choice.

    """
    choice = Choice()
    assert isinstance(choice(items=['a', 'b', 'c']), str)
    assert isinstance(choice(items=['a', 'b', 'c'], length=1), list)
    assert isinstance(choice(items='abc', length=2), str)
    assert isinstance(choice(items=('a', 'b', 'c'), length=5), tuple)
    assert isinstance(choice(items='aabbbccccddddd', length=4, unique=True), str)

# Generated at 2022-06-12 01:43:24.186519
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c','a','a','b','c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-12 01:43:27.184321
# Unit test for method __call__ of class Choice
def test_Choice___call__():
  items = list('1234567890')
  length = 7
  unique = True
  expected_unique_result = '7346210'
  choice = Choice()
  result = choice(items, length, unique)
  assert expected_unique_result == result

# Generated at 2022-06-12 01:43:35.042203
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from unittest.mock import Mock
    from unittest import TestCase
    from mimesis.enums import SupportType

    mock_self = Mock(spec=Choice)

    mock_self.random.choice.return_value = 'c'
    assert Choice.__call__(mock_self, items=['a', 'b', 'c']) == 'c'
    mock_self.random.choice.assert_called_once_with(['a', 'b', 'c'])
    mock_self.random.choice.reset_mock()

    mock_self.random.choice.return_value = 'c'
    assert Choice.__call__(mock_self, items=['a', 'b', 'c'], length=1) == ['c']
    mock_self.random.choice.assert_called_once

# Generated at 2022-06-12 01:43:43.632231
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert c(items=['a', 'b', 'c']) == 'c'
    assert c(items=['a', 'b', 'c'], length=1) == ['a']
    assert c(items='abc', length=2) == 'ba'
    assert c(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert c(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-12 01:43:52.122617
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice(seed=123)
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    try:
        choice(items=None)
    except TypeError:
        assert True
    except Exception:
        assert False
    try:
        choice(items='abc', length=2, unique=1)
    except TypeError:
        assert True


# Generated at 2022-06-12 01:44:00.211318
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from typing import List
    from mimesis.providers.datetime import Datetime

    choice = Choice(datetime=Datetime('en'))
    # When length = 0, a single element is returned without a container
    result = choice(items=[1, 2, 3])
    assert isinstance(result, int)
    # When length is specified, a list is returned
    result = choice(items=[1, 2, 3], length=2)
    assert isinstance(result, List)
    assert len(result) == 2
    result = choice(items=[1, 2, 3], length=3)
    assert isinstance(result, List)
    assert len(result) == 3
    # Unique elements are only provided by setting unique = True
    result = choice(items=[1, 1, 2, 3], length=4, unique=True)


# Generated at 2022-06-12 01:44:10.002373
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert isinstance(c(['a', 'b', 'c']), type(c(['a', 'b', 'c'])))
    assert isinstance(c(['a', 'b', 'c'], length=1), type(c(['a', 'b', 'c'])))
    assert isinstance(c(length=1, items=['a', 'b', 'c']), type(c(['a', 'b', 'c'])))
    assert isinstance(c('abc', length=2), type(c(['a', 'b', 'c'])))
    assert isinstance(c(('a', 'b', 'c'), length=5), type(c(['a', 'b', 'c'])))

# Generated at 2022-06-12 01:44:19.155809
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from typing import Sequence

    from mimesis.enums import Gender
    from mimesis.providers.geography import Geography

    provider = Choice()
    data = ['apple', 'banana', 'cherry', 'fig']
    fruits = provider(items=data, length=4)
    assert isinstance(fruits, Sequence)
    assert len(fruits) == 4
    assert set(fruits) == set(data)

    data = ['apple', 'banana', 'cherry', 'fig']
    fruit = provider(items=data)
    assert fruit in data

    geo = Geography()
    default_locale = geo.get_locale()
    geo.set_locale('fr')
    geo.set_gender(Gender.FEMALE)
    data = geo.female_name()

# Generated at 2022-06-12 01:45:36.692858
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    from mimesis.builtins import Choice

    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]

    assert choice(items='abc', length=2) in ['ab', 'bc', 'ca']

# Generated at 2022-06-12 01:45:46.128992
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    # Given
    choice = Choice()

    # When
    items = ['a', 'b', 'c']
    retval_1 = choice(items=items)
    length = 1
    retval_2 = choice(items=items, length=length)
    items = 'abc'
    length = 2
    retval_3 = choice(items=items, length=length)
    items = ('a', 'b', 'c')
    length = 5
    retval_4 = choice(items=items, length=length)
    items = 'aabbbccccddddd'
    length = 4
    unique = True
    retval_5 = choice(items=items, length=length, unique=unique)

    # Then