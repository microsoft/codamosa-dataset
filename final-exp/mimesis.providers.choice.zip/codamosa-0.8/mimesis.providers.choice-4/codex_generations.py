

# Generated at 2022-06-12 01:35:56.665926
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # GIVEN
    choice = Choice()

    # WHEN
    item1 = choice(items=['a', 'b', 'c'])
    item2 = choice(items=['a', 'b', 'c'], length=1)
    item3 = choice(items='abc', length=2)
    item4 = choice(items=('a', 'b', 'c'), length=5)
    item5 = choice(items='aabbbccccddddd', length=4, unique=True)

    # THEN
    assert item1 in 'abc'
    assert item2 == ['a']
    assert item3 in ['ba', 'bb', 'ab', 'ac', 'ba']

# Generated at 2022-06-12 01:36:07.345631
# Unit test for method __call__ of class Choice
def test_Choice___call__():    
    class TestChoice:
        def test_constructor(self, seed):
            c = Choice(seed=seed)
            assert c is not None
            assert isinstance(c, BaseProvider)
            assert isinstance(c, Choice)

        def test_items_should_be_an_nonempty_sequence(self, seed):
            c = Choice(seed=seed)
            #test_constructor(seed)
            with pytest.raises(TypeError):
                c(items=0)
            with pytest.raises(ValueError):
                c(items=[])

        def test_length_should_be_integer(self, seed):
            c = Choice(seed=seed)
            #test_constructor(seed)

# Generated at 2022-06-12 01:36:09.501866
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    text = ['a', 'b', 'c']
    random.choice(text)


# Generated at 2022-06-12 01:36:14.539767
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    ch = Choice()
    assert len(ch(items='abc', length=3)) == 3
    # test return type list
    assert isinstance(ch(items='abc', length=3), list)
    # test return type string
    assert isinstance(ch(items='abc', length=0), str)
    # test return type tuple
    assert isinstance(ch(items=('a', 'b', 'c'), length=5), tuple)

# Generated at 2022-06-12 01:36:24.291386
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from random import uniform
    from mimesis.enums import Gender

    choice = Choice()
    items = list(range(10))
    length = int(uniform(0, 10))
    ret = choice(items, length, False)
    assert isinstance(ret, list) or isinstance(ret, str) or isinstance(ret, tuple)
    assert (len(ret) == length) or (len(ret) == 1)

    items = tuple(range(10))
    length = int(uniform(0, 10))
    ret = choice(items, length, False)
    assert isinstance(ret, tuple)
    assert len(ret) == length

if __name__ == '__main__':
    test_Choice___call__()

# Generated at 2022-06-12 01:36:25.670737
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice()(items=['a', 'b', 'c'])

# Generated at 2022-06-12 01:36:30.074757
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.providers.choice import Choice
    from mimesis.enums import Gender
    # Create a class for a provider
    c = Choice()
    # Call the method
    c(items=[Gender.MALE, Gender.FEMALE, Gender.NEUTER])

# Generated at 2022-06-12 01:36:38.233966
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a'] or \
           Choice().__call__(items=['a', 'b', 'c'], length=1) == ['b'] or \
           Choice().__call__(items=['a', 'b', 'c'], length=1) == ['c']
    assert Choice().__call__(items='abc', length=2) in ['ac', 'bc', 'ab']

# Generated at 2022-06-12 01:36:50.035529
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    print(choice(items=['a', 'b', 'c']))
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    print(choice(items=['a', 'b', 'c'], length=1))
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    print(choice(items='abc', length=2))
    assert choice(items='abc', length=2) in ['ba', 'ab', 'cb', 'ac', 'bc']
    print(choice(items=('a', 'b', 'c'), length=5))

# Generated at 2022-06-12 01:37:00.692764
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Test with negative length
    choice = Choice()
    try:
        assert choice(items=[1, 2, 3], length=-4)
    except ValueError:
        assert True
    else:
        assert False

    # Test with float length
    try:
        assert choice(items=[1, 2, 3], length=3.3)
    except TypeError:
        assert True
    else:
        assert False

    # Test with int length
    assert choice(items=[1, 2, 3], length=3) == [1, 2, 3]

    # Test with int length and unique
    assert len(choice(items=[1, 2, 3], length=3, unique=True)) == 3

    # Test with int length and unique with less elements
    items = [1, 2, 3]

# Generated at 2022-06-12 01:37:04.608148
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    return choice(items=['a', 'b', 'c'])


# Generated at 2022-06-12 01:37:14.740028
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import unittest
    from mimesis.enums import Gender
    from mimesis.person import Person

    class TestCase(unittest.TestCase):
        def test_choice_str(self):
            choice = Choice()
            self.assertIsInstance(choice(items='aA', length=0), str)
            self.assertIsInstance(choice(items='aA', length=1), str)
            self.assertIsInstance(choice(items='aA', length=20), str)

        def test_choice_int(self):
            choice = Choice()
            self.assertIsInstance(choice(items=[1, 2, 3], length=0), int)
            self.assertIsInstance(choice(items=[1, 2, 3], length=1), int)

# Generated at 2022-06-12 01:37:17.058166
# Unit test for method __call__ of class Choice
def test_Choice___call__():
        pass



# Generated at 2022-06-12 01:37:27.391681
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    c = Choice()
    assert c(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert c(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert c(items='abc', length=2) in ['ba', 'ab', 'cb', 'ac', 'bc']

# Generated at 2022-06-12 01:37:34.835573
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) == 'b'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'cb'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'addc'


# Generated at 2022-06-12 01:37:42.880164
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b']]
    assert choice(items='abc', length=2) in ['ba', 'ab']
    assert choice(items=('a', 'b', 'c'), length=5) in [('c', 'a', 'a', 'b', 'c'), ('b', 'a', 'b', 'c', 'a')]
    assert choice(items='aabbbccccddddd', length=4, unique=True) in ['cdba', 'dcba']

# Generated at 2022-06-12 01:37:49.513623
# Unit test for method __call__ of class Choice
def test_Choice___call__():
  items = ['a', 'b', 'c', 'd']

  choice = Choice()
  # => should return items and throw no errors
  # single value
  choice(items)
  # => should return items and throw no errors
  # multiple values
  choice(items, length=5)
  # => should return items and throw no errors
  # single value, unique
  choice(items, unique=True)
  # => should return items and throw no errors
  # multiple values, unique
  choice(items, length=5, unique=True)

# Generated at 2022-06-12 01:37:50.158578
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-12 01:37:53.593588
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = Choice().__call__(items=['a', 'b', 'c', 'd'], length=5, unique=True)
    print(items)


# Generated at 2022-06-12 01:37:57.121188
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    data = []
    while len(data) < 3:
        item = choice(items=['a', 'b', 'c'])
        if item not in data:
            data.append(item)
    assert data == ['a','b','c']
    print(data)

# Generated at 2022-06-12 01:38:26.381853
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    _choice = Choice()
    items = ['a', 'b', 'c']
    items2 = ['a', 'b', 'c']
    length = 1
    length2 = 1
    unique = False
    unique2 = False
    assert _choice(items=items, length=length, unique=unique) == 'c', \
        "Test method __call__ of class Choice failed!"
    assert _choice(items=items2, length=length2, unique=unique2) == 'c', \
        "Test method __call__ of class Choice failed!"
    print("Test method __call__ of class Choice - OK!")


# Generated at 2022-06-12 01:38:36.041029
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import json
    import pytest
    from hypothesis import assume, given, settings
    from hypothesis.strategies import (
        lists,
        text,
        tuples,
    )
    from mimesis.exceptions import NonEnumerableError
    from mimesis.typing import Sequence

    choice = Choice()

    @given(tuples(text(min_size=1)))
    def test_Choice___call__items_tuple_element(items: Sequence[str]):
        result = choice(items)
        assert result in items

    @given(tuples(text(min_size=1), min_size=1))
    @settings(max_examples=10)
    def test_Choice___call__items_tuple_length(items: Sequence[str]):
        length = choice(range(1, 10))
       

# Generated at 2022-06-12 01:38:36.973201
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass



# Generated at 2022-06-12 01:38:42.321243
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Tests that Choice().__call__() returns expected output."""
    args = ['a', 'b', 'c']
    length = 1
    unique = False

    choice = Choice()
    result = choice(args, length, unique)
    assert result == 'c'



# Generated at 2022-06-12 01:38:51.793440
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for Choice.__call__.

    Test cases:
        Method Choice.__call__ generates a randomly-chosen sequence or bare
        element from a sequence. Provide elements randomly chosen from the
        elements in a sequence **items**, where when **length** is specified
        the random choices are contained in a sequence of the same type of
        length **length**, otherwise a single uncontained element is chosen.
        If **unique** is set to True, constrain a returned sequence to contain
        only unique elements.

        :returns: None
    """
    import random
    from mimesis import Choice
    from unittest import TestCase
    from unittest.mock import patch

    class TestCaseChoice(TestCase):
        """Class for testing Choice.__call__."""


# Generated at 2022-06-12 01:39:02.990999
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    assert choice([1, 2, 3], length=2) == [1, 3]
    assert choice([1, 2, 3], length=2, unique=True) == [1, 2]


# Generated at 2022-06-12 01:39:11.112288
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    data = Choice(seed=1337)

    assert data(items=['a', 'b', 'c']) == 'c'
    assert data(items=['a', 'b', 'c'], length=1) == ['a']
    assert data(items='abc', length=2) == 'ba'
    assert data(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert data(items='aabbbccccddddd', length=4, unique=True) == 'cdba'



# Generated at 2022-06-12 01:39:20.990010
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    provider = Choice()
    assert isinstance(choice(items=['a', 'b', 'c']), str)
    assert isinstance(choice(items=['a', 'b', 'c'], length=2), list)
    assert len(choice('a', length=2)) == 2
    assert choice('a', length=2) == ['a', 'a']
    assert len(choice('a', length=5)) == 5
    assert choice('a', length=5) == ['a', 'a', 'a', 'a', 'a']
    assert len(choice(1, length=5)) == 5
    assert choice(1, length=5) == [1, 1, 1, 1, 1]

# Generated at 2022-06-12 01:39:33.087716
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import pkg_resources
    import os

    test_cases = []
    with pkg_resources.resource_stream('tests.providers', 'choice.yml') \
            as file:
        for test_case in yaml.load(file):
            test_cases.append(test_case)

    def run(test_case, func):
        """Check if provided arguments are correct."""
        if "error" in test_case:
            with pytest.raises(test_case["error"]):
                func(test_case["items"], test_case["length"],
                     test_case["unique"])
        else:
            result = func(test_case["items"], test_case["length"],
                          test_case["unique"])
            assert result == test_case["result"]
    #
    # Unit test for method

# Generated at 2022-06-12 01:39:40.631783
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    result_1 = choice(items=['a', 'b', 'c'])
    assert result_1 == 'c'
    result_2 = choice(items=['a', 'b', 'c'], length=1)
    assert result_2 == ['a']
    result_3 = choice(items='abc', length=2)
    assert result_3 == 'ba'
    result_4 = choice(items=('a', 'b', 'c'), length=5)
    assert result_4 == ('c', 'a', 'a', 'b', 'c')
    result_5 = choice(items='aabbbccccddddd', length=4, unique=True)
    assert result_5 == 'cdba'

# Generated at 2022-06-12 01:43:51.701849
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice, Seed
    from mimesis.providers.control import Control
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.identifier import Identifier
    from mimesis.providers.internet import Internet
    from mimesis.providers.localization import Localization
    from mimesis.providers.mac import MACAddress
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.person import Person
    from mimesis.providers.person.en import Person as PersonEN
    from mimesis.providers.person.ru import Person as PersonRU
    from mimesis.providers.person.uk import Person as PersonUK
    from mimesis.providers.person.zh_CN import Person as PersonZH_CN

# Generated at 2022-06-12 01:44:00.348518
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for:
    ```
        choice = Choice()
        choice(items=['a', 'b', 'c'])
        choice(items=['a', 'b', 'c'], length=1)
        choice(items='abc', length=2)
        choice(items=('a', 'b', 'c'), length=5)
        choice(items='aabbbccccddddd', length=4, unique=True)
    ```
    """
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'

# Generated at 2022-06-12 01:44:08.574038
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test generation of choice from sequence."""

    choice = Choice()
    print(choice(items=['a', 'b', 'c']))
    print(choice(items=['a', 'b', 'c'], length=1))
    print(choice(items='abc', length=2))
    print(choice(items=('a', 'b', 'c'), length=5))
    print(choice(items='aabbbccccddddd', length=4, unique=True))


# Generated at 2022-06-12 01:44:18.247243
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = [1, 2, 3, 4, 5]
    length = 3
    output = choice(items, length)
    assert isinstance(output, list)
    assert len(output) == length
    assert all(x in items for x in output)

    choice = Choice()
    items = [1, 2, 3, 4, 5]
    length = 3
    unique = True
    output = choice(items, length, unique)
    assert isinstance(output, list)
    assert len(output) == length
    assert all(x in items for x in output)
    assert len(set(output)) == length

    choice = Choice()
    items = [1, 2, 3, 4, 5]
    length = 6
    output = choice(items, length, True)

# Generated at 2022-06-12 01:44:24.900203
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert c(items=['a','b','c']) == 'c'
    assert c(items=['a','b','c'],length=1) == ['a']
    assert c(items='abc',length=2) == 'ba'
    assert c(items=('a','b','c'),length=5) == ('c','a','a','b','c')
    assert c(items='aabbbccccddddd',length=4,unique=True) == 'cdba'


# Generated at 2022-06-12 01:44:32.068846
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice(seed=1)(items=['a', 'b', 'c']) == 'b'
    assert Choice(seed=1)(items=['a', 'b', 'c'], length=1) == ['c']
    assert Choice(seed=1)(items='abc', length=2) == 'cb'
    assert Choice(seed=1)(items=('a', 'b', 'c'), length=5) == ('a', 'a', 'c', 'a', 'c')
    assert Choice(seed=1)(items='aabbbccccddddd', length=4, unique=True) == 'dbac'

# Generated at 2022-06-12 01:44:37.831218
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # 1
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 0
    unique = False
    assert choice(items=items, length=length, unique=unique) in items
    # 2
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    assert choice(items=items, length=length, unique=unique) in items
    # 3
    choice = Choice()
    items = 'abc'
    length = 2
    unique = False
    assert choice(items=items, length=length, unique=unique) in items
    # 4
    choice = Choice()
    items = ('a', 'b', 'c')
    length = 5
    unique = False
    assert choice(items=items, length=length, unique=unique)

# Generated at 2022-06-12 01:44:39.768326
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    provider = Choice()
    assert isinstance(provider(['a', 'b', 'c']), str)
    assert isinstance(provider(['a', 'b', 'c'], length=1), list)
    assert isinstance(provider('abc', length=2), str)
    assert isinstance(provider(('a', 'b', 'c'), length=5), tuple)

# Generated at 2022-06-12 01:44:50.197918
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    instance = Choice()
    assert instance(items=[1, 2, 3], length=1) == [1]
    assert len(set(instance(items=[1, 2, 3], length=3))) == 3
    assert instance(items='abcdefg', length=1) == 'c'
    assert instance(items='abcdefg', length=3) == 'gbc'
    assert len(instance('abcdefg', 5)) == 5
    assert len(set(instance('abcdefg', 5))) == 5
    assert instance(items='abcdefg', length=1) == 'a'
    assert instance(items='abcdefg', length=3) == 'baf'
    assert len(instance('abcdefg', 5)) == 5
    assert len(set(instance('abcdefg', 5))) == 5

# Generated at 2022-06-12 01:44:51.520296
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method __call__ of class Choice"""
    pass