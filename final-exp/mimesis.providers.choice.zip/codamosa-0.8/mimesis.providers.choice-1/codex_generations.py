

# Generated at 2022-06-12 01:35:57.761719
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert Choice().__call__(items='abc', length=2) in ['ac', 'bc', 'ab']
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) in [('a', 'b', 'c', 'a', 'b'), ('c', 'a', 'b', 'c', 'a'), ('a', 'b', 'c', 'a', 'a')]

# Generated at 2022-06-12 01:36:07.623251
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    # test__call__1
    try:
        assert choice(items='abc', length='a') == 'ab'
    except Exception as e:
        print(e)
        assert type(e) == TypeError

    # test__call__2
    try:
        assert choice(items=['a', 'b', 'c'], length=5) == ['c', 'b', 'c', 'a', 'b']
    except Exception as e:
        print(e)
        assert type(e) == ValueError

    # test__call__3
    try:
        assert choice(items='bba', length=-1, unique=True) == 'baa'
    except Exception as e:
        print(e)
        assert type(e) == ValueError

    # test__call__4

# Generated at 2022-06-12 01:36:16.279375
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

    # Test for non-sequence items
    non_sequence_items = 1
    try:
        choice(items=non_sequence_items)
    except Exception as exc:
        assert exc.__class__.__name__ == 'TypeError'

# Generated at 2022-06-12 01:36:24.818246
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    x = Choice()
    assert x.__call__(items=['a', 'b', 'c']) == 'c'
    assert x.__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert x.__call__(items='abc', length=2) == 'ba'
    assert x.__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert x.__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:36:25.809376
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    return True


# Generated at 2022-06-12 01:36:35.937687
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test Choice.__call__()"""
    f = Choice()
    f('abc') # 'c'
    f(items=['a', 'b', 'c'], length=1) # ['a']
    f(items='abc', length=2) # 'ba'
    f(items=('a', 'b', 'c'), length=5) # ('c', 'a', 'a', 'b', 'c')
    f(items='aabbbccccddddd', length=4, unique=True) # 'cdba'
    try:
        f(items='abc', length='1')
        assert False
    except TypeError:
        assert True
    try:
        f(items=0, length=0)
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-12 01:36:45.528225
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:36:51.696704
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method __call__ of class Choice."""
    # Test case 1
    choice, item = Choice(), ['a', 'b', 'c']
    assert callable(choice)
    assert choice.__class__.__name__ == 'Choice'

    assert isinstance(choice(item, length=1), list)
    assert choice(item, length=1) == ['c']

    # Test case 2
    choice2 = Choice()
    assert choice2(item, length=2) == ['c', 'c']
    assert choice2(item, length=0) == 'c'

    # Test case 3
    item2 = ('a', 'b', 'c')
    choice3 = Choice()
    assert isinstance(choice3(item2, length=5), tuple)

    # Test case 4

# Generated at 2022-06-12 01:37:02.102419
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender

    cl = Choice(gender=Gender.MALE)
    assert cl(['a', 'b']) in ['a', 'b']
    assert cl(['a', 'b'], length=1) in [
        ['a'],
        ['b'],
    ]
    assert cl(['a', 'b'], length=2) in [
        ['b', 'a'],
        ['a', 'b'],
    ]

# Generated at 2022-06-12 01:37:10.401279
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method __call__ of class Choice."""
    import random
    import string
    import time
    import pytest

    from mimesis.typing import AnyOf

    # Test for 
    #     def __call__(self, items: Optional[Sequence[Any]], length: int = 0,
    #                  unique: bool = False) -> Union[Sequence[Any], Any]:

# Generated at 2022-06-12 01:37:15.962782
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Note: The type is Callable[[Choice], Any] (Any is not used)
    pass



# Generated at 2022-06-12 01:37:26.998185
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    assert (choice(items=['a', 'b', 'c'],  length=4, unique=True)) == ['c', 'a', 'b', 'a']
    assert (choice(items=['a', 'b', 'c'])) == 'a'
    assert (choice(items=['a', 'b', 'c'],  length=3, unique=True)) == ['a', 'b', 'c']
    assert (choice(items=['a', 'b', 'c'],  length=1, unique=True)) == ['a']
    assert (choice(items=['a', 'b', 'c'],  length=0, unique=True)) == 'a'

# Generated at 2022-06-12 01:37:37.463540
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    from mimesis.enums import CardinalDirection
    from mimesis.exceptions import NonEnumerableError
    choice = Choice()
    # Generate a randomly-chosen sequence or bare element from a sequence.
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['aa', 'bb', 'ab', 'ba', 'ac', 'ca', 'bc', 'cb']

# Generated at 2022-06-12 01:37:44.000581
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TODO: Add more tests
    assert "".join(Choice().__call__(list('abcdefghijklmnopqrstuvwxyz'), length=10)) in list('abcdefghijklmnopqrstuvwxyz')
    assert "".join(Choice().__call__(['a', 'b', 'c'], length=1)) in ['a', 'b', 'c']
    assert "".join(Choice().__call__(['a', 'b', 'c'], length=1)) in ['a', 'b', 'c']
    assert Choice().__call__((1, 2, 3, 4)) in (1, 2, 3, 4)

# Generated at 2022-06-12 01:37:48.643828
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 1
    unique = True
    assert choice(items=items) in items
    assert len(choice(items=items)) == 1
    assert len(choice(items=items, length=length)) == length
    assert choice(items=items, length=length) in [items]
    assert len(choice(items=items, length=length, unique=unique)) == length
    assert choice(items=items, length=length, unique=unique) in [items]


# Generated at 2022-06-12 01:37:50.821331
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    data = choice(['a', 'b', 'c'], length=1)
    assert data == "a"

# Generated at 2022-06-12 01:37:56.840884
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    items = 'asdf'
    print (c.__call__(items, 3))
    print (c.__call__(items, 3, True))
    print (c.__call__(items, 0, True))
    print (c.__call__(items, 0, False))

if __name__ == '__main__':
    test_Choice___call__()

# Generated at 2022-06-12 01:38:05.133044
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    method1 = Choice()
    print(method1(items=['a', 'b', 'c']))
    print(method1(items=['a', 'b', 'c'], length=1))
    print(method1(items='abc', length=2))
    print(method1(items=('a', 'b', 'c'), length=5))
    print(method1(items='aabbbccccddddd', length=4, unique=True))


if __name__ == '__main__':
    test_Choice___call__()

# Generated at 2022-06-12 01:38:06.115006
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TODO:
    pass

# Generated at 2022-06-12 01:38:17.055373
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method __call__ of class Choice.
    """
    class ClassName(Choice):
        """Docstring for ClassName. """

        class Meta:
            """Class for metadata."""

            name = 'choice'

    assert ClassName.Meta.name == 'choice'

    choice = ClassName()

    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ab', 'ac', 'bc']
    # assert choice(items=('a', 'b', 'c'), length=5) in \
    #     (('a', 'b', 'c', 'a', '

# Generated at 2022-06-12 01:38:28.487265
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender

    c = Choice()
    assert c(items=Gender) in Gender.items()
    assert isinstance(c.sequence(items=Gender, length=3), list)
    assert isinstance(c(items=Gender, length=3, unique=True), list)
    assert isinstance(c(items=Gender.items()), str)
    assert isinstance(c.sequence(items=Gender.items(), length=3), str)
    assert isinstance(c(items=Gender.items(), length=3, unique=True), str)
    assert c(items=['1', '2', '3']) in ['1', '2', '3']

# Generated at 2022-06-12 01:38:37.443795
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.mimesis import Mimesis
    from mimesis.mimesis import MimesisError
    from mimesis.enums import ExceptionArgumentValue
    mimesis = Mimesis('en')
    choice = Choice('en')
    assert choice(['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(['a', 'b', 'c'], length=1) == ['a']
    assert choice('abc', length=2) in ['ba', 'ab', 'cb']

# Generated at 2022-06-12 01:38:48.810379
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    choice = Choice()
    # Test for non-sequence items
    try:
        choice(items={'a':1, 'b':2})
        raise RuntimeError('This line should not be reached.')
    except TypeError:
        pass
    # Test for non-empty sequence
    try:
        choice(items=[])
        raise RuntimeError('This line should not be reached.')
    except ValueError:
        pass
    # Test for non-integer length
    try:
        choice(items=['a', 'b'], length=3.1415926)
        raise RuntimeError('This line should not be reached.')
    except TypeError:
        pass
    # Test for non-positive length

# Generated at 2022-06-12 01:38:52.504656
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Arrange
    # Act
    choice = Choice()

    # Assert
    result = choice(items=['a', 'b', 'c'])
    assert type(result) is str



# Generated at 2022-06-12 01:39:03.717616
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Assume
    choice = Choice()

    # Assume
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

    # Assert
    try:
        choice(items={1, 2, 3}, length=1)
        assert False
    except TypeError as e:
        assert str(e) == '**items** must be non-empty sequence.'

# Generated at 2022-06-12 01:39:06.510893
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test behaviour of method Choice.__call__().

    Not yet implemented.
    :return: True
    :rtype: bool
    """
    return True

# Generated at 2022-06-12 01:39:14.668525
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-12 01:39:21.679331
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    from mimesis import Choice
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-12 01:39:31.795378
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-12 01:39:39.652983
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c'], length=0, unique=True) in (
        'a', 'b', 'c')
    assert choice(items=('a', 'b', 'c'), length=2) in ('aa', 'ab', 'ac',
                                                       'ba', 'bb', 'bc', 'ca',
                                                       'cb', 'cc')
    assert choice(items=['a', 'b', 'c'], length=2, unique=True) in (
        'ab', 'ac', 'bc')
    assert choice(items='abc', length=2, unique=True) in ('ab', 'ac', 'bc')
    assert choice(items='abc', length=0) in ('a', 'b', 'c')

# Generated at 2022-06-12 01:40:02.275109
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    alpha = list('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ')
    c = Choice()

    assert isinstance(c(items=alpha), str)
    assert isinstance(c(items=alpha, length=1), list)
    assert len(c(items=alpha, length=5)) == 5
    assert len(''.join(c(items=alpha, length=5))) == 5
    assert isinstance(c(items=tuple(alpha), length=5), tuple)
    assert len(c(items=tuple(alpha), length=5)) == 5
    assert len(''.join(c(items=tuple(alpha), length=5))) == 5

# Generated at 2022-06-12 01:40:07.509684
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import random
    import copy
    import collections.abc
    import pytest
    from typing import Any, Optional, Sequence, Union
    from mimesis import Choice
    choice_1 = Choice()
    choice_2 = Choice(random)
    choice_3 = Choice(random, seed=True)
    choice_4 = Choice(random, seed=True)
    print('choice_1.seed =>', choice_1.seed)
    print('choice_2.seed =>', choice_2.seed)
    print('choice_3.seed =>', choice_3.seed)
    print('choice_4.seed =>', choice_4.seed)
    print('choice_3.choice(items=\'abc\') =>', choice_3.choice(items='abc'))

# Generated at 2022-06-12 01:40:17.746431
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    random_choice_1 = choice(items=['a', 'b', 'c'])
    random_choice_2 = choice(items=['a', 'b', 'c'], length=1)
    random_choice_3 = choice(items='abc', length=2)
    random_choice_4 = choice(items=('a', 'b', 'c'), length=5)
    random_choice_5 = choice(items='aabbbccccddddd', length=4, unique=True)
    assert type(random_choice_1) == str
    assert random_choice_1 in ['a', 'b', 'c']
    assert random_choice_2 == ['a']
    assert type(random_choice_3) == str
    assert type(random_choice_4) == tuple
    assert random_

# Generated at 2022-06-12 01:40:27.714729
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # setup
    args = ()
    kwargs = {}
    choice = Choice(args, kwargs)

    # test for return type: str
    items = ('a', 'b', 'c')
    assert_type_string = choice(items)

    # test for return type: list
    items = ('a', 'b', 'c')
    length = 1
    # assert_type_list = choice(items, length)

    # test for return type: list
    items = 'a'
    length = 2
    # assert_type_list = choice(items, length)

    # test for return type: tuple
    items = ('a', 'b', 'c')
    length = 5
    # assert_type_tuple = choice(items, length)

    # test for return type: str

# Generated at 2022-06-12 01:40:36.048428
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert type(c(items=['a', 'b', 'c'])) == str
    assert type(c(items=['a', 'b', 'c'], length=1)) == list
    assert type(c(items='abc', length=2)) == str
    assert type(c(items=('a', 'b', 'c'), length=5)) == tuple
    assert type(c(items='aabbbccccddddd', length=4, unique=True)) == str

# Generated at 2022-06-12 01:40:43.300864
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    # Set up the call arguments
    items=['a', 'b', 'c']
    length=0

    # Call the method under test
    result = instance.__call__(items, length)

    assert result == 'a'

    # Set up the call arguments
    items=['a', 'b', 'c']
    length=1

    # Call the method under test
    result = instance.__call__(items, length)

    assert result == ['a']

    # Set up the call arguments
    items='abc'
    length=2

    # Call the method under test
    result = instance.__call__(items, length)

    assert result == 'ba'

    # Set up the call arguments
    items=('a', 'b', 'c')
    length=5

    # Call the method under test
    result = instance

# Generated at 2022-06-12 01:40:52.752030
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from hypothesis import given
    from hypothesis.strategies import integers, lists, tuples
    from mimesis.exceptions import NonDataError
    c = Choice()
    assert c(['a', 'b', 'c']) in ['a', 'b', 'c']
    assert c(['a', 'b', 'c'], 1) in [['a'], ['b'], ['c']]
    assert c('abc', 2) in ['aa', 'bb', 'cc', 'ab', 'ac', 'ba']

# Generated at 2022-06-12 01:41:00.712553
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-12 01:41:08.661818
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    
    from mimesis import Choice
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:41:16.082085
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.geography import Geography
    from mimesis.providers.misc import Misc
    from mimesis.providers.person import Person

    choice = Choice(Datetime, Geography, Misc, Person)
    print(choice)

    assert isinstance(choice, Choice)
    assert isinstance(choice('ABCDE'), str)
    assert isinstance(choice(['A', 'B', 'C', 'D', 'E']), str)
    assert isinstance(choice('abc', unique=True), str)
    assert isinstance(choice([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11], length=2), list)

    try:
        choice(length='hello')
    except TypeError:
        pass

# Generated at 2022-06-12 01:41:52.089912
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    print('Test method __call__ of class Choice')
    choice = Choice()
    print(choice(items=['a', 'b', 'c'], length=1, unique=True))


# Generated at 2022-06-12 01:41:57.842123
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice.seed(12345)
    data1 = choice('abc')
    assert data1 == 'a'
    data2 = choice('abc', length=1)
    assert data2 == ['b']
    data3 = choice('abc', length=2)
    assert data3 == 'ba'
    data4 = choice(('a', 'b', 'c'), length=5)
    assert data4 == ('b', 'a', 'c', 'a', 'c')
    data5 = choice('aabbbccccddddd', length=4, unique=True)
    assert data5 == 'cdda'
    data6 = choice.seed(1234).__call__('abc')
    assert data6 == 'c'

# Generated at 2022-06-12 01:42:06.827999
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Tests the method __call__ of class Choice"""
    import random
    import mimesis
    from mimesis.enums import Gender
    
    assert isinstance(Choice(), Choice)
    assert isinstance(Choice(random.Random()), Choice)
    assert isinstance(Choice(mimesis.generic.Generic(locale='en'))
                      , Choice)
    assert isinstance(Choice(mimesis.enums.Gender), Choice)
    assert isinstance(Choice(Gender.MALE), Choice)
    assert isinstance(Choice().__class__, Choice)
    my_choice = Choice()
    my_choice2 = Choice(random.Random())
    my_choice3 = Choice(mimesis.generic.Generic(locale='en'))
    my_choice4 = Choice(mimesis.enums.Gender)


# Generated at 2022-06-12 01:42:16.698449
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice1 = Choice()
    assert choice1(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice1(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice1(items='abc', length=2) in ['ba', 'ab', 'ac']

# Generated at 2022-06-12 01:42:26.362478
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Tests the method __call__ of class Choice."""
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

    # TypeError: For non-sequence items or non-integer length.

# Generated at 2022-06-12 01:42:33.076430
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method __call__ of class Choice."""
    provider = Choice()
    assert provider(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert provider(items=['a', 'b', 'c'], length=1) == ['c']
    assert provider(items='abc', length=2) in ['ba', 'ab', 'ac', 'cb', 'ca', 'bc']
    assert provider(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')

# Generated at 2022-06-12 01:42:40.624802
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice"""
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-12 01:42:46.680688
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    for items in [
        ['a', 'b', 'c'],
        'abc',
        ('a', 'b', 'c'),
        'aabbbccccddddd'
    ]:
        for length in [1, 2, 5]:
            result = Choice().__call__(items=items, length=length)
            assert isinstance(result, type(items))
            assert len(result) == length
        result = Choice().__call__(items=items)
        assert isinstance(result, type(items[0]))


# Generated at 2022-06-12 01:42:57.382764
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c1 = Choice()
    lst = [1, 2, 3, 4, 5]
    assert isinstance(c1(items=lst), int)
    assert c1(items=lst) in lst
    assert isinstance(c1(items=lst, length=5), list)
    assert len(c1(items=lst, length=5)) == 5
    assert isinstance(c1(items=lst, length=5, unique=True), list)
    assert len(c1(items=lst, length=5, unique=True)) == 5

# Generated at 2022-06-12 01:43:04.798804
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import random
    import string

    _random_seed = 1234
    _items = ['a', 'b', 'c', 'd', 'e', 'f']
    _length = random.randint(1, len(_items))
    _unique = random.choice([True, False])
    _result = list()
    random.seed(_random_seed)
    _choice = Choice(_random_seed)
    _result.append(_choice(items=_items, length=_length, unique=_unique))
    _result.append(_choice(items=list(string.ascii_lowercase), length=8, unique=True))
    _result.append(_choice(items=list(string.ascii_lowercase), length=20, unique=True))

# Generated at 2022-06-12 01:44:21.247354
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert test_Choice___call__.counter == 0


# Generated at 2022-06-12 01:44:30.160186
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    class TestChoice:
        """Class for unit testing methods of class Choice."""

        def __init__(self):
            self.choice = Choice()

        def test_call(self) -> None:
            """Test for method __call__ of class Choice."""
            self.choice(items=['a', 'b', 'c'])
            self.choice(items=['a', 'b', 'c'], length=1)
            self.choice(items='abc', length=2)
            self.choice(items=('a', 'b', 'c'), length=5)
            self.choice(items='aabbbccccddddd', length=4, unique=True)

    test_choice = TestChoice()
    test_choice.test_call()
    return
test_Choice___call__()

# Generated at 2022-06-12 01:44:36.600177
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    import pytest
    from mimesis.exceptions import NonEnumerableError
    from mimesis.typing import Enumerable

    provider = Choice()

    data: Enumerable = []

    with pytest.raises(NonEnumerableError):
        provider(data)

    data = [1, True, 'str', 3.2]

    assert provider(data) in data
    assert provider(data, length=3) in data
    assert provider(data, length=3) in data
    assert provider(data, length=10, unique=True) in data
    assert provider(data, length=10, unique=False) in data

# Generated at 2022-06-12 01:44:41.537012
# Unit test for method __call__ of class Choice
def test_Choice___call__():
        choice = Choice()
        items = ['a', 'b', 'c']
        assert choice(items=items) == 'c'
        assert choice(items=items, length=1) == ['a']
        assert choice(items='abc', length=2) == 'ab'
        assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
        assert choice(items='aabbbccccddddd', length=4) == 'cdbc'
        assert choice(items='aabbbccccddddd', length=4, unique=True) == 'dcba'

# if __name__ == '__main__':
    # test_Choice___call__()

# Generated at 2022-06-12 01:44:48.664570
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:44:56.269261
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    # Case 1
    result = choice(items=['a', 'b', 'c'])
    assert result in ['a', 'b', 'c']
    # Case 2
    result = choice(items=['a', 'b', 'c'], length=1)
    assert result == ['a']
    # Case 3
    result = choice(items='abc', length=2)
    assert result == 'ba'
    # Case 4
    result = choice(items=('a', 'b', 'c'), length=5)
    assert result == ('c', 'a', 'a', 'b', 'c')
    # Case 5
    result = choice(items='aabbbccccddddd', length=4, unique=True)
    assert result == 'cdba'
   

# Generated at 2022-06-12 01:45:05.258170
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    i = Choice()
    assert i(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert i(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert i(items='abc', length=2) in ['ab', 'ac', 'bc']

# Generated at 2022-06-12 01:45:15.210067
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    class MyClass:
        def __init__(self):
            self._choice = Choice()
        def get_choice(self, items, length):
            return self._choice(items=items, length=length)

    my_class = MyClass()

    answer = my_class.get_choice(items=['a', 'b', 'c'], length=0)
    assert answer in ['a', 'b', 'c']

    answer = my_class.get_choice(items=['a', 'b', 'c'], length=1)
    assert len(answer) == 1
    assert answer[0] in ['a', 'b', 'c']

    answer = my_class.get_choice(items='abc', length=2)
    assert len(answer) == 2
    assert answer[0] in 'abc'
    assert answer

# Generated at 2022-06-12 01:45:21.109178
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-12 01:45:27.688879
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.providers import Choice
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4,
                  unique=True) == 'cdba'
    return True