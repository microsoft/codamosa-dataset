

# Generated at 2022-06-12 01:36:10.917515
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    # def __call__(self, items: Optional[Sequence[Any]], length: int = 0,
    #              unique: bool = False) -> Union[Sequence[Any], Any]:
    # => Sequence or uncontained element randomly chosen from items
    # Provide elements randomly chosen from the elements in a sequence **items**,
    # where when **length** is specified the random choices are contained in a
    # sequence of the same type of length **length**, otherwise a single
    # uncontained element is chosen.If **unique** is set to True, constrain a
    # returned sequence to contain only unique elements.

# `.choice(items, unique=True)`
    choice(items=['a', 'b', 'c']) # 'c'

# Generated at 2022-06-12 01:36:17.505174
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    items1 = ['a', 'b', 'c']
    length_1 = 0
    unique_1 = False
    expected_1 = NotImplemented
    actual_1 = c(items=items1, length=length_1, unique=unique_1)
    assert type(actual_1) == type(expected_1)
    assert actual_1 in items1
    items2 = ['a', 'b', 'c']
    length_2 = 1
    unique_2 = False
    expected_2 = NotImplemented
    actual_2 = c(items=items2, length=length_2, unique=unique_2)
    assert type(actual_2) == type(expected_2)
    assert actual_2 in items2
    items3 = 'abc'
    length_3 = 2
    unique

# Generated at 2022-06-12 01:36:25.670995
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:36:35.825526
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from unittest import TestCase

    from mimesis.builtins import Choice
    from mimesis.enums import Gender, PersonNamePart
    from mimesis.providers.person import Person
    from mimesis.types import Seed

    class CustomChoice(Choice):
        class Meta:
            seed = Seed('test_package')
            name = 'custom_choice'

    class TestChoice(TestCase):

        def test_correct_type(self):
            p = Person(seed=CustomChoice.Meta.seed)
            self.assertIsInstance(CustomChoice()(p.full_name()), str)

        def test_random_element(self):
            p = Person(seed=CustomChoice.Meta.seed)
            elems = ['foo', 'bar', 'baz']

# Generated at 2022-06-12 01:36:47.560196
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Data for positive test cases
    n_positive = [
        (['a', 'b', 'c'], 0, False, 'c'),
        (['a', 'b', 'c'], 1, False, ['a']),
        ('abc', 2, False, 'ba'),
        (('a', 'b', 'c'), 5, False, ('c', 'a', 'a', 'b', 'c')),
        ('aabbbccccddddd', 4, True, 'cdba'),
    ]

    # Data for negative test cases
    n_negative = [
        ('abc', '2', False, TypeError),
        ('abc', 2, False, ValueError),
        ('abc', 2, False, ValueError),
    ]

    # Runs positive cases

# Generated at 2022-06-12 01:36:59.088461
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method __call__ of class Choice."""

    from mimesis import Choice
    choice = Choice()

    assert choice() == None
    assert choice(unique=True) == None
    assert choice(items=[]) == None
    assert choice(items=[], length=1) == None
    assert choice(items=[], length=1, unique=True) == None

    assert choice(length=1) == None
    assert choice(length=1, unique=True) == None

    with raises(TypeError):
        choice(length='a')
    with raises(TypeError):
        choice(items={}, length=1)
    with raises(TypeError):
        choice(items={}, length=1, unique=True)

    with raises(TypeError):
        choice(items=['a', 'b', 'c'], length='a')

# Generated at 2022-06-12 01:37:08.373974
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) == 'b'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['b']
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:37:09.241534
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass


# Generated at 2022-06-12 01:37:17.590759
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.person.en_US import EnUSPerson

    person = Person(locale='en-US')
    en_us_person = EnUSPerson(locale='en-US')
    choices = Choice(locale='en-US')
    assert isinstance(choices(['a', 'b', 'c']), str)
    assert isinstance(choices(['a', 'b', 'c'], length=1), list)
    assert isinstance(choices('abc', length=2), str)
    assert isinstance(choices(('a', 'b', 'c'), length=5), tuple)

# Generated at 2022-06-12 01:37:26.955902
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice(seed=123).__call__(items=['a', 'b', 'c']) == 'a'
    assert Choice(seed=123).__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice(seed=123).__call__(items='abc', length=2) == 'ba'
    assert Choice(seed=123).__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice(seed=123).__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:37:39.660582
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(['a', 'b', 'c'], 1) == ['a']
    assert len(choice(['a', 'b', 'c'], 5)) == 5
    assert len(choice(['a', 'b', 'c'], 4)) == 4
    assert choice('abc') in ['a', 'b', 'c']  # It is the same as
    # choice(list('abc'))
    assert choice('abc', 1) == 'a'
    assert len(choice('abc', 5)) == 5

# Generated at 2022-06-12 01:37:44.326345
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['Item1', 'Item2', 'Item3']
    length = 2
    unique = False
    choice = Choice()
    assert isinstance(choice(items, length, unique), Sequence)
    assert type(choice(items, length, unique)) == type(items)
    assert len(choice(items, length, unique)) - length == 0


# Generated at 2022-06-12 01:37:49.278583
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice_ = Choice()

    assert choice_(items=['a', 'b', 'c']) == 'c'
    assert choice_(items=('a', 'b', 'c'), length=1) == ('b',)
    assert choice_(items='abc', length=2) == 'ba'
    assert choice_(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b',
                                                         'c')
    assert choice_(items='aabbbccccddddd', length=4, unique=True) == 'cdba'



# Generated at 2022-06-12 01:37:51.603193
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c']
    assert Choice()._Choice__call__(items=items) in items


# Generated at 2022-06-12 01:38:00.375626
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    #
    # Initialize attributes
    #
    t = Choice()
    items = ['a', 'b', 'c']
    length = 0
    unique = False
    #
    # Should generate a randomly-chosen sequence or bare element from a sequence
    #
    # Provide elements randomly chosen from the elements in a sequence **items**, where when **length** is specified the random choices are contained in a sequence of the same type of length **length**, otherwise a single uncontained element is chosen. If **unique** is set to True, constrain a returned sequence to contain only unique elements.
    #
    # :param items: Non-empty sequence (list, tuple or string) of elements.
    # :param length: Length of sequence (number of elements) to provide.
    # :param unique: If True, ensures provided elements are unique.
    # :return: Sequence

# Generated at 2022-06-12 01:38:09.653966
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method __call__ of class Choice.

    :return: Nothing.
    """
    class MockChoice(Choice):
        """Mock of Choice."""

        def __init__(self):
            self.random = MockRandom()

    from mimesis.exceptions import NonEnumerableError
    from mimesis.enums import Gender
    from mimesis.pseudo_random import MockRandom
    from mimesis.typing import Seed

    fr = MockChoice()
    fr._seed = Seed(0)
    fr_call = fr(items=['a', 'b', 'c'])
    assert fr_call == 'c'

    fr = MockChoice()
    fr._seed = Seed(1)
    fr_call = fr(items=['a', 'b', 'c'], length=2)
    assert fr

# Generated at 2022-06-12 01:38:16.487741
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    print(c(items=['a', 'b', 'c']))
    # print(c(items=['a', 'b', 'c'], length=1))
    # print(c(items='abc', length=2))
    # print(c(items=('a', 'b', 'c'), length=5))
    # print(c(items='aabbbccccddddd', length=4, unique=True))

# Generated at 2022-06-12 01:38:24.003035
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert 1 == 1
    # choice = Choice()
    # assert choice(items=['a', 'b', 'c']) == 'c'
    # assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    # assert choice(items='abc', length=2) == 'ba'
    # assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    # assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-12 01:38:27.150760
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """ Test class Choice.
    """
    c0 = Choice()
    c1 = Choice()
    c2 = Choice()
    assert c0(items=['a', 'b', 'c']) == 'c'
    assert c1(items=['a', 'b', 'c'], length=1) == ['a']
    assert c2(items='abc', length=2) == 'ba'



# Generated at 2022-06-12 01:38:36.677560
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    # when random.choice(['a', 'b', 'c']) == 'c':
    assert choice(['a', 'b', 'c']) == 'c'
    # when random.choice(['a', 'b', 'c']) == 'a':
    assert choice(['a', 'b', 'c'],1) == ['a']
    # when random.choice('abc') == 'b':
    assert choice('abc',2) == 'ba'
    # when random.choice(('a', 'b', 'c')) == 'a':
    assert choice(('a', 'b', 'c'),5) == ('c', 'a', 'a', 'b', 'c')
    # when random.choice('aabbbccccddddd') == 'd':

# Generated at 2022-06-12 01:38:44.341382
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    from mimesis import Choice
    choice = Choice()
    choices = ['a', 'b', 'c']
    length = 1
    unique = False

    assert choice.__call__(choices) in choices
    assert len(choice.__call__(choices, length=length)) == length
    assert len(set(choice.__call__(choices, length, unique))) == length

# Generated at 2022-06-12 01:38:50.727857
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    # assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:39:02.202848
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice("en")
    assert choice(items=["a","b","c"]) in ["a","b","c"]
    assert choice(items=["a","b","c"], length=1) in [["a"],["b"],["c"]]
    assert choice(items="abc", length=2) in ["ab","bc","ac"]

# Generated at 2022-06-12 01:39:12.970146
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert isinstance(choice(items=['a', 'b', 'c']), str)
    assert isinstance(choice(items=['a', 'b', 'c'], length=1), list)
    assert isinstance(choice(items='abc', length=2), str)
    assert isinstance(choice(items=('a', 'b', 'c'), length=5), tuple)
    assert isinstance(choice(items='aabbbccccddddd', length=4, unique=True), str)
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items='abc', length=2) in ['aa', 'ab', 'ac', 'ba', 'bb', 'bc', 'ca', 'cb', 'cc']

# Generated at 2022-06-12 01:39:21.130541
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    items1 = ['a', 'b', 'c']
    assert c(items1) in items1

    items2 = ['a', 'b', 'c']
    assert c(items2, 3) == ['a', 'a', 'b']

    assert c(items2, unique=True) in items2
    assert c(items2, 3, unique=True) == ['d', 'a', 'b']

    items3 = ('a', 'b', 'c')
    assert c(items3, 3) == ('c', 'c', 'a')

    items4 = 'abc'
    assert c(items4, 3) == 'ccb'

# Generated at 2022-06-12 01:39:33.164615
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender
    from mimesis.typing import Dict, List, Tuple, Union
    import pytest

    data: Dict = {
        'args': [
            [1, 2, 3],
        ],
        'kwargs': {
            'length': 5,
        }
    }

    choice = Choice('en', gender=Gender.FEMALE)
    result: Union[List[int], Tuple[int]] = choice(*data['args'], **data['kwargs'])

    assert len(result) == data['kwargs']['length']

    choice = Choice('ru', gender=Gender.FEMALE)
    result: Union[List[int], Tuple[int]] = choice(*data['args'], **data['kwargs'])


# Generated at 2022-06-12 01:39:44.020323
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test a random choice from items in a sequence."""
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ba', 'ca', 'cb', 'ab']

# Generated at 2022-06-12 01:39:51.669349
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-12 01:39:52.580435
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass


# Generated at 2022-06-12 01:39:53.135474
# Unit test for method __call__ of class Choice
def test_Choice___call__():    
    assert True == True

# Generated at 2022-06-12 01:40:03.335526
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # test_Choice___call___1
    choice_1 = Choice()
    items_1 = list(['a', 'a', 'b', 'c', 'd', 'f', 'g', 'h', 'i', 'k', 'l', 'm', 'n', 'p', 'q', 'r', 's', 't', 'v', 'x', 'y', 'z'])
    assert choice_1(items_1) in items_1

    # test_Choice___call___2
    choice_2 = Choice()
    items_2 = list(['a', 'b', 'c'])
    assert choice_2(items_2, 1) == [choice_2(items_2)]

    # test_Choice___call___3
    choice_3 = Choice()
    items_3 = str('abc')
    assert choice_

# Generated at 2022-06-12 01:40:15.252410
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender, Speciality
    from mimesis.providers.science import Science

    provider = Science(
        specialities=Speciality.JAVASCRIPT_PROGRAMMING.value,
        gender=Gender.FEMALE.value
    )

    choice = Choice(localization=provider.localization)

    assert isinstance(
        choice(items=provider.specialities),
        str
    ) is True

    # TODO: Fix this. It should be return list of strings
    assert isinstance(
        choice(items=provider.specialities, length=2),
        list
    ) is True

    # TODO: Fix this. It should be return tuple of strings
    assert isinstance(
        choice(items=provider.specialities, length=3),
        tuple
    )

# Generated at 2022-06-12 01:40:17.225973
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert len(Choice().__call__(items='abc', length=2)) == 2
    assert len(Choice().__call__(items='abc')) == 1


# Generated at 2022-06-12 01:40:23.117060
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    obj = Choice()
    item = ['a', 'b', 'c']
    #assert obj(items=item, length=5, unique=True) == ['c', 'a', 'a', 'b', 'c']
    assert obj.choice(item, 5, True) == ['c', 'a', 'a', 'b', 'c']


if __name__ == '__main__':
    test_Choice___call__()

# Generated at 2022-06-12 01:40:24.188301
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TODO: Update after it implemented
    pass

# Generated at 2022-06-12 01:40:27.594094
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    actual_output = Choice()("abcd", 4)
    expected_output = [Choice().random.choice("abcd") for i in range(4)]
    print("Expected output:",expected_output)
    print("Actual output:",actual_output)
    assert actual_output==expected_output


# Generated at 2022-06-12 01:40:33.513951
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice([1, 2, 3]) == 3
    assert choice([1, 2, 3], 1) == [1]
    assert choice('abc', 2) == 'ba'
    assert choice(('a', 'b', 'c'), 5) == ('c', 'a', 'a', 'b', 'c')
    assert choice('aabbbccccddddd', 4, True) == 'cdba'

# Generated at 2022-06-12 01:40:42.918942
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender
    ch = Choice('en')
    a = ch(items=[1, 2, 3], length=2)
    b = ch(items=(1, 2, 3), length=3)
    c = ch(items='abc', length=2)
    d = ch(items=[1, 2, 3], length=5)
    e = ch(items='qwerty', length=5, unique=True)
    f = ch(items=['M', 'F', 'X'], length=1)
    g = ch(items=Gender)
    h = ch(items=Gender, length=2)

    assert len(a) == 2
    assert len(b) == 3
    assert len(c) == 2
    assert len(d) == 5
    assert len(set(e)) == len

# Generated at 2022-06-12 01:40:43.437456
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-12 01:40:52.348661
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    class DummyProvider(BaseProvider):
        pass
    dummy = DummyProvider()
    setattr(dummy.random, 'choice', lambda items: items[0])
    choice = Choice(dummy)

    assert choice(items=['a', 'b', 'c']) == 'a'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'aa'
    assert choice(items=('a', 'b', 'c'), length=5) == ('a', 'a', 'a', 'a', 'a')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'aaaa'


# Generated at 2022-06-12 01:41:09.817795
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    _choice = Choice(seed=123)

    items = list(range(10))
    length = 7
    unique = True

    assert _choice(items=items, length=length, unique=unique) == [3, 0, 8, 4, 1, 5, 7]

    items = list(range(5))
    length = 8
    unique = True

    assert _choice(items=items, length=length, unique=unique) == [4, 3, 1, 0, 2, 3, 1, 0]

    items = 'abc'
    length = 2
    unique = True

    assert _choice(items=items, length=length, unique=unique) == 'ab'

    items = tuple(range(3))
    length = 5
    unique = True


# Generated at 2022-06-12 01:41:16.821306
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Mimesis unit test."""
    from mimesis.enums import Gender

# Generated at 2022-06-12 01:41:25.926680
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    

    try:
        instance = Choice()
    except Exception as e:
        print(e)
        assert False

    try:
        result = instance(items=['a', 'b', 'c'])
    except Exception as e:
        print(e)
        assert False
    else:
        print(result)

    try:
        result = instance(items=['a', 'b', 'c'], length=1)
    except Exception as e:
        print(e)
        assert False
    else:
        print(result)

    try:
        result = instance(items='abc', length=2)
    except Exception as e:
        print(e)
        assert False
    else:
        print(result)


# Generated at 2022-06-12 01:41:28.480339
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Tests the __call__ method of Choice class."""
    print(':: test __call__ method of Choice class')


# Generated at 2022-06-12 01:41:36.521875
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    c = Choice()

    print(c(items=['a', 'b', 'c'])) # 给出输出结果
    print(c(items=['a', 'b', 'c'], length=1)) # 给出输出结果
    print(c(items='abc', length=2)) # 给出输出结果
    print(c(items=('a', 'b', 'c'), length=5)) # 给出输出结果
    print(c(items='aabbbccccddddd', length=4, unique=True)) # 给出输出结果



# Generated at 2022-06-12 01:41:36.925877
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert True

# Generated at 2022-06-12 01:41:37.549405
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()


# Generated at 2022-06-12 01:41:46.318037
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in 'abc'
    assert choice(items=['a', 'b', 'c'], length=1) in ['a', 'b', 'c']
    assert choice(items='abc', length=2) in 'abc'
    assert choice(items=('a', 'b', 'c'), length=5) in ('abc', 'bac', 'bca', 'cab', 'cba')

# Generated at 2022-06-12 01:41:51.799803
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TODO: Use better arguments
    choice = Choice()
    choice(items=['a', 'b', 'c'], length=1, unique=False)
    choice(items=['a', 'b', 'c'], length=10, unique=False)
    choice(items=['a', 'b', 'c'], length=1, unique=True)
    # TODO: Use more test cases

# Generated at 2022-06-12 01:41:54.061075
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method __call__ of class Choice."""
    pass

# Generated at 2022-06-12 01:42:26.476300
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert isinstance(c(items=['a', 'b', 'c']), str)
    assert isinstance(c(items='abc'), str)
    assert isinstance(c(items=('a', 'b', 'c')), str)
    assert isinstance(c(items=('a', 'b', 'c'), length=1), tuple)
    assert isinstance(c(items=('a', 'b', 'c'), length=5), tuple)
    assert isinstance(c(items='abc', length=1), str)
    assert isinstance(c(items='abc', length=5), str)
    assert isinstance(c(items='aabbbccccddddd', length=4, unique=True), str)

# Generated at 2022-06-12 01:42:32.581229
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    choice = Choice()
    #print(choice(items=['a', 'b', 'c']))
    #print(choice(items=['a', 'b', 'c'], length=1))
    #print(choice(items='abc', length=2))
    #print(choice(items=('a', 'b', 'c'), length=5))
    #print(choice(items='aabbbccccddddd', length=4, unique=True))
    pass

# Program driver
if __name__ == '__main__':
    # execute only if run as the entry point into the program
    test_Choice___call__()

# Generated at 2022-06-12 01:42:41.951082
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) in ['ab', 'bc', 'ac']

# Generated at 2022-06-12 01:42:48.377777
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:42:58.884031
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    # case 1
    items = ['a', 'b', 'c']
    length = 1
    unique = False
    result = choice(items=items, length=length, unique=unique)
    expected = ['c']
    assert result == expected
    # case 2
    items = ['a', 'b', 'c']
    length = 0
    unique = False
    result = choice(items=items, length=length, unique=unique)
    expected = 'c'
    assert result == expected
    # case 3
    items = 'abc'
    length = 2
    unique = False
    result = choice(items=items, length=length, unique=unique)
    expected = 'ba'
    assert result == expected
    # case 4

# Generated at 2022-06-12 01:43:05.360152
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ba', 'ac', 'bc', 'ab']
    assert choice(items=('a', 'b', 'c'), length=5) in \
        [('c', 'a', 'a', 'b', 'c'), ('c', 'c', 'a', 'b', 'a'), ('b', 'a', 'a', 'c', 'c')]

# Generated at 2022-06-12 01:43:10.520830
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    choice(items=['a', 'b', 'c'])
    choice(items=['a', 'b', 'c'], length=1)
    choice(items='abc', length=2)
    choice(items=('a', 'b', 'c'), length=5)
    choice(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-12 01:43:15.157604
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import pytest
    choice = Choice()
    test_items = ['a', 'b', 'c']
    test_length = 6
    test_unique = True
    test_result = choice(items=test_items,length=test_length,unique=test_unique)
    assert len(test_result) == test_length
    for elem in test_result:
        assert elem in test_items

# Generated at 2022-06-12 01:43:24.657542
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    try:
        choice(items=['a', 'b', 'c'], length='a')
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-12 01:43:32.569816
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test a class Choice."""

    # Test call with a integer length
    try:
        data = Choice()(items=[1, 2, 3, 4, 5], length=5)
        assert len(data) == 5
    except ValueError:
        pass
    except TypeError:
        pass
    except AssertionError:
        pass

    # Test call with a negative length

    try:
        data = Choice()(items=[1, 2, 3, 4, 5], length=-5)
        assert len(data) != 5
    except ValueError:
        pass
    except TypeError:
        pass
    except AssertionError:
        pass