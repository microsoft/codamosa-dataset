

# Generated at 2022-06-12 01:35:53.391340
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method Choice.__call__."""
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 1
    assert choice(items=items, length=length) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:36:03.629209
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Test Positive
    assert Choice().__call__(list(['a', 'b', 'c'])) in ['a', 'b', 'c']

    # Test Positive
    assert len(Choice().__call__(list(['a', 'b', 'c']), length=5)) == 5
    assert Choice().__call__(list(['a', 'b', 'c']), length=5) in [
        'abbc', 'abbb', 'abcc', 'abaa', 'abab', 'abcb', 'abba', 'abac',
        'abca', 'abcb'
    ]

    # Test Positive
    assert Choice().__call__(list(['a', 'b', 'c']), length=5, unique=True) in [
        'cab', 'bac', 'cba'
    ]

    # Test

# Generated at 2022-06-12 01:36:09.943578
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:36:20.660437
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    items = ['a', 'b', 'c']
    assert choice(items=items) in items
    assert len(choice(items=items, length=1)) == 1
    assert len(choice(items='abc', length=2)) == 2
    assert len(choice(items=('a', 'b', 'c'), length=5)) == 5
    assert len(choice(items='aabbbccccddddd', length=4, unique=True)) == 4
    try:
        choice(items=[], length=1)
        assert False
    except ValueError:
        assert True
    try:
        choice(items=[], length=0)
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-12 01:36:31.482482
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()

    # Case: items: ['a', 'b', 'c']
    result = choice(items=['a', 'b', 'c'])
    assert isinstance(result, str)
    assert result in ['a', 'b', 'c']

    # Case: items: ['a', 'b', 'c'], length: 1
    result = choice(items=['a', 'b', 'c'], length=1)
    assert isinstance(result, list)
    assert len(result) == 1
    assert result[0] in ['a', 'b', 'c']

    # Case: items: 'abc', length: 2
    result = choice(items='abc', length=2)
    assert isinstance(result, str)

# Generated at 2022-06-12 01:36:38.895851
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.geo import Geo
    from mimesis.providers.internet import Internet
    from mimesis.providers.text import Text
    from mimesis.providers.system import System
    from mimesis.providers.person import Person
    from mimesis.providers.business import Business
    from mimesis.providers.payment import Payment
    from mimesis.providers.unit import Unit
    from mimesis.providers.misc import Misc, Emoji
    from mimesis.providers.person import Person
    from mimesis.providers.code import Code
    from mimesis.providers.person import Person


# Generated at 2022-06-12 01:36:42.475026
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=[1, 2, 3]) == 3
    assert choice(items=[1, 2, 3], length=1) == [1]


# Generated at 2022-06-12 01:36:50.278610
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) == 'ba'
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:37:00.850129
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert isinstance(c(items='abc', length=2), str)
    assert isinstance(c(items='abc', length=2), str)
    assert isinstance(c(items='abc', length=2), str)
    assert isinstance(c(items='abc', length=2), str)
    assert isinstance(c(items='abc'), str)
    assert isinstance(c(items='abc'), str)
    assert isinstance(c(items='abc'), str)
    assert isinstance(c(items='abc'), str)
    assert isinstance(c(items='abc'), str)
    assert isinstance(c(items=('a', 'b', 'c'), length=5), tuple)
    assert isinstance(c(items=('a', 'b', 'c'), length=5), tuple)
   

# Generated at 2022-06-12 01:37:10.010495
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    _choice = Choice()
    assert _choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert _choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert _choice(items=['a', 'b', 'c'], length=2) in [['a', 'a'], ['b', 'b'], ['c', 'c']]
    assert _choice(items='abc', length=2) in ['aa', 'bb', 'cc']

# Generated at 2022-06-12 01:37:24.773233
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    choice = Choice()

# Generated at 2022-06-12 01:37:32.094800
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert c(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert c(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert c(items='abc', length=2) in ['ab', 'ac', 'ba', 'bc', 'ca', 'cb']

# Generated at 2022-06-12 01:37:40.281090
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import pytest
    from random import seed, random
    from itertools import product

    seed(0)
    choice = Choice()
    test_data = ('abc', ('a', 'b', 'c'), ['a', 'b', 'c'],
                 'aabbbccccdddddeeeee')
    for item in test_data:
        assert choice(item) in item
        for _ in range(10):
            n = random() * (len(item) - 1)
            assert choice(item, length=n) in item
        for n in range(1, 11):
            assert choice(item, length=n) in product(item, repeat=n)

# Generated at 2022-06-12 01:37:45.944195
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    _choice = Choice()
    _choice(items=['a', 'b', 'c'])
    _choice(items=['a', 'b', 'c'], length=1)
    _choice(items='abc', length=2)
    _choice(items=('a', 'b', 'c'), length=5)
    _choice(items='aabbbccccddddd', length=4, unique=True)


# Generated at 2022-06-12 01:37:50.057014
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = ['a', 'b', 'c', 'd', 'e', 'f']
    length = 5
    unique = False
    output = Choice().__call__(items=items, length=length, unique=unique)
    assert len(output) == length


# Generated at 2022-06-12 01:37:59.574477
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    if True:
        from mimesis import Choice
        # from mimesis.enums import Gender
        choice = Choice()
        # print(choice(items=[x for x in range(10)]))
        # print(choice(items=['a', 'b', 'c'], length=1))
        # print(choice(items='abc', length=2))
        # print(choice(items=('a', 'b', 'c'), length=5))
        # print(choice(items='aabbbccccddddd', length=4, unique=True))
        return
    else:
        choice = Choice()
        print(choice(items=['a', 'b', 'c']))
        print(choice(items=['a', 'b', 'c'], length=1))

# Generated at 2022-06-12 01:38:09.210283
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c', 'd']) in ['a', 'b', 'c', 'd']
    assert choice(items=['a', 'b', 'c', 'd'], length=1) in [['a'], ['b'], ['c'], ['d']]
    assert choice(items=('a', 'b', 'c', 'd'), length=3) in [('a', 'c', 'b'), ('b', 'a', 'c'), ('c', 'a', 'b'), ('d', 'b', 'c')]

# Generated at 2022-06-12 01:38:19.378919
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    # Test input items is valid
    items1 = [1,2,3,4]
    items2 = ('a','b','c')
    items3 = 'abc'
    # Test input length is valid
    length1 = 0
    length2 = 4
    length3 = 5
    # Test input unique is valid
    unique1 = True
    unique2 = False
    if choice(items=items1, length = length1, unique = unique1):
        print("Test Choice___call__ passed!")
    if choice(items=items1, length = length2, unique = unique2):
        print("Test Choice___call__ passed!")
    if choice(items=items1, length = length3, unique = unique1):
        print("Test Choice___call__ passed!")

# Generated at 2022-06-12 01:38:20.928980
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass


# Generated at 2022-06-12 01:38:23.373396
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Arrange
    from mimesis.builtins import Choice
    choice = Choice()

    # Act
    result = choice(items=['a', 'b', 'c'])

    # Assert
    assert result in ('a', 'b', 'c')


# Generated at 2022-06-12 01:38:37.956598
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Test items = list, length = int, unique = True
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 2
    unique = True
    assert isinstance(choice(items=items, length=length, unique=unique), str)
    # Test items = list, length = int, unique = False
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 2
    unique = False
    assert isinstance(choice(items=items, length=length, unique=unique), str)
    # Test items = list, length = int, unique = True
    choice = Choice()
    items = ['a', 'b', 'c']
    length = 2
    unique = True
    assert isinstance(choice(items=items, length=length, unique=unique), str)
   

# Generated at 2022-06-12 01:38:48.977546
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender
    from mimesis.providers.datetime import Datetime

    d = Datetime('en')
    choices = Choice('en', random_type=Gender.FEMALE)
    c = choices(items=['a', 'b', 'c'])
    assert c == 'c'
    c = choices(items=['a', 'b', 'c'], length=1)
    assert type(c) == list
    assert c == ['a']
    c = choices(items='abc', length=2)
    assert c == 'ba'
    c = choices(items=('a', 'b', 'c'), length=5)
    assert type(c) == tuple
    assert c == ('c', 'a', 'a', 'b', 'c')

# Generated at 2022-06-12 01:38:51.128941
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for __call__ method of class Choice."""
    pass

# Generated at 2022-06-12 01:38:55.357139
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method __call__"""
    c = Choice()
    assert isinstance(c([""], 1), list)
    assert isinstance(c((""), 1), tuple)
    assert isinstance(c("", 1), str)

# Generated at 2022-06-12 01:39:00.760551
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice

    choice = Choice()
    data, result = choice(items=['a', 'b', 'c'], length=1), ['a']
    assert data == result

    data, result = choice(items=['a', 'b', 'c'], length=2), ['a', 'a']
    assert data == result



# Generated at 2022-06-12 01:39:06.791800
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.builtins import Choice
    from mimesis.exceptions import NonUniqueError
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.datetime import Timezone
    from mimesis.providers.text import Text
    from mimesis.providers.person import Person
    from mimesis.providers.person import Person
    from mimesis.providers.person import Person
    from mimesis.providers.person import Person
    choice = Choice()
    # Test method __call__ of class Choice
    # TestCase 1
    assert choice('abc') == 'a'
    # TestCase 2
    assert choice(['a', 'b', 'c'], 1) == ['c']
    # TestCase 3

# Generated at 2022-06-12 01:39:12.239293
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert c(items=['a', 'b', 'c']) == 'c'
    assert c(items=['a', 'b', 'c'], length=1) == ['a']
    assert c(items='abc', length=2) == 'ba'
    assert c(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert c(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    try:
        c(items=['a', 'b', 'c'], length=1.1)
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-12 01:39:18.250573
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c'])
    assert choice(items=['a', 'b', 'c'], length=1)
    assert choice(items='abc', length=2)
    assert choice(items=('a', 'b', 'c'), length=5)
    assert choice(items='aabbbccccddddd', length=4, unique=True)



# Generated at 2022-06-12 01:39:20.725022
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for Choice.__call__()."""
    data = Choice()(items='abc', length=1)
    assert data


# Generated at 2022-06-12 01:39:32.666488
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender

    item = Choice()
    tst_items_1 = item(items=list(map(str, range(1, 4))),
                    length=1,
                    unique=False)
    assert tst_items_1 in list(map(str, range(1, 4)))

    tst_items_2 = item(items=('a', 'b', 'c', 'd', 'e', 'f'),
                    length=3,
                    unique=True)
    assert tst_items_2 in ['abc', 'def', 'abd', 'ade', 'aef', 'bcd', 'bce', 'bde',
                            'bef', 'cde', 'cdf', 'cef']


# Generated at 2022-06-12 01:39:47.715663
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice(None)(items=('a', 'b', 'c')) in ('a', 'b', 'c')


# Generated at 2022-06-12 01:39:52.697450
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    choice(items=['a', 'b', 'c'])
    choice(items=['a', 'b', 'c'], length=1)
    choice(items='abc', length=2)
    choice(items=('a', 'b', 'c'), length=5)
    choice(items='aabbbccccddddd', length=4, unique=True)

# Generated at 2022-06-12 01:39:58.930425
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-12 01:40:04.497946
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method __call__ of class Choice."""
    choice = Choice()

    # Test case 1
    assert choice(items=['a', 'b', 'c']) == 'c'

    # Test case 2
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']

    # Test case 3
    assert choice(items='abc', length=2) == 'ba'

    # Test case 4
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')

    # Test case 5
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

    # Test case 6

# Generated at 2022-06-12 01:40:16.163490
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    assert c.__call__(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert c.__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert c.__call__(items='abc', length=2) in ['ba', 'ab', 'bc']

# Generated at 2022-06-12 01:40:23.414500
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__('abc') == 'c'
    assert Choice().__call__('abc', 1) == ['a']
    assert Choice().__call__('abc', 2) == 'ba'
    assert Choice().__call__(('a', 'b', 'c'), 5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__('aabbbccccddddd', 4, True) == 'cdba'


# Unit tests for class Choice

# Generated at 2022-06-12 01:40:30.070328
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # TODO: Update test_Choice___call__
    choice = Choice()

    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

    try:
        choice(items=['a', 'b'], length=1.5)
    except TypeError:
        pass
    else:
        assert False, 'TypeError should have been raised.'


# Generated at 2022-06-12 01:40:40.910147
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test __call__ method of class Choice."""
    items = [
        (1, 2, 3, 4, 5, 6, 7, 8, 9, 10),  # tuple in list
        (1, 2, 3, 4, 5, 6, 7, 8, 9, 10),
        [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
    ]
    choice = Choice()
    result = choice(items)
    assert result in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

    items = [1, 2, 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k']

# Generated at 2022-06-12 01:40:41.873520
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # unit tested
    pass

# Generated at 2022-06-12 01:40:51.599749
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    del items, length, unique, data, item
    choice = Choice()
    # Test that an error is raised when length is not int
    try:
        choice(items=['a', 'b', 'c'], length=1.0)
    except TypeError:
        pass

    # Test that an error is raised when items is not a sequence
    try:
        choice(items=1, length=1)
    except TypeError:
        pass

    # Test that an error is raised when items is an empty sequence
    try:
        choice(items=[], length=1)
    except ValueError:
        pass

    # Test that an error is raised when length is a negative int
    try:
        choice(items=['a', 'b', 'c'], length=-1)
    except ValueError:
        pass

    # Test that an

# Generated at 2022-06-12 01:41:24.263803
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    _instance = Choice()
    _instance(items=['a', 'b', 'c'])

    _instance(items=['a', 'b', 'c'], length=1)

    _instance(items='abc', length=2)

    _instance(items=('a', 'b', 'c'), length=5)

    _instance(items='aabbbccccddddd', length=4, unique=True)

ChoiceProvider = Choice

# Generated at 2022-06-12 01:41:34.863940
# Unit test for method __call__ of class Choice

# Generated at 2022-06-12 01:41:44.969213
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    try:
        # ! Choice(items=None)
        # ? raises TypeError
        Choice(items=None)
    except TypeError as e:
        print("TypeError")
        print("items must be non-empty sequence.\n")
    else:
        print("Error")
    try:
        # ! Choice(items=())
        # ? raises ValueError
        Choice(items=())
    except ValueError as e:
        print("ValueError")
        print("**items** must be a non-empty sequence.\n")
    else:
        print("Error")
    try:
        # ! Choice(items=(1,2,3), length=-1)
        # ? raises ValueError
        Choice(items=(1,2,3), length=-1)
    except ValueError as e:
        print("ValueError")


# Generated at 2022-06-12 01:41:51.040075
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Tests Choice.__call__()."""
    choice = Choice()
    assert len(Choice.__dict__) == 1
    assert choice('abc') in 'abc'
    assert choice('abc', 1) == ['a']
    assert choice('abc', 2) in ['ba', 'ab', 'cb']
    assert choice(tuple('abc'), 5) in [('c', 'a', 'a', 'b', 'c'), ('c', 'a', 'b', 'c', 'c'), ('b', 'a', 'b', 'b', 'a')]
    assert choice('aabbbccccddddd', 4, unique=True) in ['cdba', 'acbd', 'abdc', 'abcd', 'dcba' ]

# Generated at 2022-06-12 01:41:56.981523
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    from mimesis import Choice

    choice = Choice()

    if choice(items=[0, 1, 2]) != 0:
        raise TypeError('Expected 0')

    if choice(items=[0, 1, 2], length=1) != [0]:
        raise TypeError('Expected [0]')

    if choice(items=['a', 'b', 'c'], length=2) != 'ac':
        raise TypeError('Expected "ac"')

    if choice(items=[0, 1, 2, 3, 4, 5, 6, 7, 8, 9], length=4) != [1, 8, 5, 7]:
        raise TypeError('Expected [1, 8, 5, 7]')


# Generated at 2022-06-12 01:42:01.540032
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    "Unit test for method Choice.__call__(items, length, unique)."
    from mimesis.builtins import Choice
    choice = Choice()

    items  = ['a', 'b', 'c']
    length = 1

    assert isinstance(choice(items=items, length=length), list)
    assert choice(items=items, length=length) == ['a']


# Generated at 2022-06-12 01:42:09.011062
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    from hypothesis import given
    from hypothesis.strategies import integers, lists, one_of, sampled_from, text
    from mimesis import Choice

    @given(lists(integers()), integers(min_value=0, max_value=100),
           sampled_from([False, True]))
    def test_with_integers(items, length, unique):
        c = Choice()
        data = c(items=items, length=length, unique=unique)
        assert len(data) == length
        if unique:
            assert len(data) == len(set(data))

    @given(lists(text()), integers(min_value=0, max_value=100),
           sampled_from([False, True]))
    def test_with_text(items, length, unique):
        c = Choice()

# Generated at 2022-06-12 01:42:16.783774
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    provider = Choice()
    assert provider(items=['a', 'b', 'c']) == 'c'
    assert provider(items=['a', 'b', 'c'], length=1) == ['a']
    assert provider(items='abc', length=2) == 'ba'
    assert provider(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert provider(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:42:17.347799
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-12 01:42:26.922010
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    # Test with str
    response = c(items='abc', length=2)
    assert isinstance(response, str)
    assert len(response) == 2
    assert response[0] in 'abc'
    assert response[1] in 'abc'
    # Test with list
    response = c(items=['a', 'b', 'c'], length=2)
    assert isinstance(response, list)
    assert len(response) == 2
    assert response[0] in ['a', 'b', 'c']
    assert response[1] in ['a', 'b', 'c']
    # Test with tuple
    response = c(items=('a', 'b', 'c'), length=2)
    assert isinstance(response, tuple)
    assert len(response) == 2

# Generated at 2022-06-12 01:43:24.582301
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for __call__ method of class Choice."""
    result = set({})
    for _ in range(1000):
        result.add(Choice().__call__(['a', 'b', 'c']))
    assert result == {'a', 'b', 'c'}

# Generated at 2022-06-12 01:43:32.469112
# Unit test for method __call__ of class Choice
def test_Choice___call__(): 
    from mimesis import Choice
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert len(choice(items=['a', 'b', 'c'], length=1)) == 1
    assert choice(items='abc', length=2) in ['ab', 'ac', 'bc'] 
    assert len(choice(items=('a', 'b', 'c'), length=5)) == 5
    assert choice(items='aabbbccccddddd', length=4, unique=True) in ['aabb', 'bbaa']
    pass

# Generated at 2022-06-12 01:43:32.984903
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    pass

# Generated at 2022-06-12 01:43:40.696200
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # 1st test

    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:43:43.881628
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    provider = Choice()
    items = ["a", "b", "c"]
    length = 1
    unique = False
    result = provider(items, length, unique)
    assert result in items

# Generated at 2022-06-12 01:43:52.318024
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Gender
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person import Person
    from mimesis.providers.misc import Choice
    from mimesis.providers.internet import Internet

    # Test call without length
    with Choice() as ch:
        assert ch(items=[1, 2, 3]) in [1, 2, 3]
        assert ch(items='abc') in 'abc'
        assert ch(items=('a', 'b', 'c')) in 'abc'

    # Test call with unique
    with Choice() as ch:
        assert len(set(ch(items='aabbbccccddddd', length=4, unique=True))) == 4

    # Test with tuples

# Generated at 2022-06-12 01:44:00.411684
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    try:
        choice(items=['a', 'b', 'c'], length=1.0)
    except TypeError as e:
        assert str(e) == '**length** must be integer.'

# Generated at 2022-06-12 01:44:09.963850
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    item = choice(items=['a', 'b', 'c'])
    assert isinstance(item, str)
    item = choice(items=['a', 'b', 'c'], length=1)
    assert isinstance(item, list) and len(item) == 1
    item = choice(items='abc', length=2)
    assert isinstance(item, str) and len(item) == 2
    item = choice(items=('a', 'b', 'c'), length=5)
    assert isinstance(item, tuple) and len(item) == 5
    item = choice(items='aabbbccccddddd', length=4, unique=True)
    assert isinstance(item, str) and len(item) == 4

# Generated at 2022-06-12 01:44:19.154392
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    choice.random.seed(0)
    assert choice(items=['a', 'b', 'c']) == 'a'
    choice.random.seed(1)
    assert choice(items=['a', 'b', 'c']) == 'c'

# Generated at 2022-06-12 01:44:20.876575
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert "a" in Choice().__call__(items=["a", "b", "c", "d"])
