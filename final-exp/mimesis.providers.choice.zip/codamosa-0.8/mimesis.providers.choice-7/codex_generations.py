

# Generated at 2022-06-12 01:35:55.483376
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from random import choice
    from string import ascii_letters
    from string import digits
    from mimesis import Choice
    choice_ = Choice()

    # Unit tests for __call__ of class Choice
    assert isinstance(choice_(items=('a', 'b', 'c')), str)
    assert isinstance(choice_(items=[1, 2, 3], length=1), list)
    assert isinstance(choice_(items=('a', 'b', 'c'), length=3), tuple)
    assert isinstance(choice_(items=ascii_letters, length=2), str)
    assert isinstance(choice_(items=digits, length=2), str)
    assert choice_(items=digits, length=6) in list(digits)
    assert choice_(items=digits) in list(digits)

# Generated at 2022-06-12 01:36:00.362773
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""

    # Setup
    choice = Choice()

    # Execute
    items = choice(items=['a', 'b', 'c'])

    # Verify
    assert (items in ('a', 'b', 'c'))


# Generated at 2022-06-12 01:36:08.804547
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    test_items = [['a', 'b', 'c'], ['a', 'b', 'c'], 'abc', ('a', 'b', 'c'),
                  'aabbbccccddddd']
    test_length = [0, 1, 2, 5, 4]
    test_unique = [False, False, False, False, True]
    test_expected = ['b', ['a'], 'cb', ('a', 'b', 'c', 'c', 'a'), 'cdba']

    for i in range(len(test_items)):
        result = choice(test_items[i], test_length[i], test_unique[i])
        assert test_expected[i] == result

# Generated at 2022-06-12 01:36:16.705744
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    with pytest.raises(TypeError) as err:
        Choice().__call__(items=['a', 'b', 'c'], length="5")
    assert str(err.value) == '**length** must be integer.'

    with pytest.raises(TypeError) as err:
        Choice().__call__(items=Choice(), length=1)
    assert str(err.value) == '**items** must be non-empty sequence.'

    with pytest.raises(ValueError) as err:
        Choice().__call__(items=[])
    assert str(err.value) == '**items** must be a non-empty sequence.'

    with pytest.raises(ValueError) as err:
        Choice().__call__(items=['a', 'b', 'c'], length=-5)
    assert str

# Generated at 2022-06-12 01:36:18.760272
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method __call__ of class Choice."""
    # TODO: complete this test
    pass

# Generated at 2022-06-12 01:36:29.497685
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Tests for method __call__ of class Choice."""

    import pytest
    from mimesis.exceptions import NonEnumerableError

    # Passing a non-empty sequence of elements to items.
    with pytest.raises(NonEnumerableError):
        Choice().__call__(items=['a', 'b', 'c'])

    # Passing a non-empty sequence of elements to items.
    # Providing the length.
    with pytest.raises(NonEnumerableError):
        Choice().__call__(items=['a', 'b', 'c'], length=1)

    # Passing a non-empty sequence of elements to items.
    # Providing the length.
    with pytest.raises(NonEnumerableError):
        Choice().__call__(items='abc', length=2)

    # Passing a non

# Generated at 2022-06-12 01:36:36.404918
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis import Choice
    choice = Choice()
    assert choice(items=['a', 'b', 'c'])  == 'c'
    assert choice(items=['a', 'b', 'c'], length=1)  == ['a']
    assert choice(items='abc', length=2)  == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5)  == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True)  == 'cdba'

# Generated at 2022-06-12 01:36:46.395478
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    provider_ = Choice()
    result = provider_(items=['a', 'b', 'c'])
    assert result == 'c'
    result = provider_(length=1, items=['a', 'b', 'c'])
    assert result == ['a']
    result = provider_(items='abc', length=2)
    assert result == 'ba'
    result = provider_(items=('a', 'b', 'c'), length=5)
    assert result == ('c', 'a', 'a', 'b', 'c')
    result = provider_(items='aabbbccccddddd', length=4, unique=True)
    assert result == 'cdba'

# Generated at 2022-06-12 01:36:52.998286
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    c = Choice()
    # TODO: выяснить почему ожидаемый результат выходит в формате наоборот
#     assert c(items=['a', 'b', 'c'],length=1) == list('a')
#     assert c(items=['a', 'b', 'c'],length=2) == list('ab')
#     assert c(items=['a', 'b', 'c'],length=3) == list('abc')
#     assert c(items=['a', 'b', 'c'],length=4) == list('abc')
#     assert c(items='abc',length

# Generated at 2022-06-12 01:37:00.718129
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert Choice().__call__(['a', 'b', 'c']) == 'c'
    assert Choice().__call__(['a', 'b', 'c'], 1) == ['a']
    assert Choice().__call__('abc', 2) == 'ba'
    assert Choice().__call__(('a', 'b', 'c'), 5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__('aabbbccccddddd', 4, True) == 'cdba'

# Generated at 2022-06-12 01:37:07.496827
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    results = []
    for i in range(100):
        choice = Choice().test__call__(
            items=['a', 'b', 'c'],
            length=2,
            unique=False
        )
        results.append(choice)
    assert results
    print("results=%s" % results)

if __name__ == "__main__":
    test_Choice___call__()

# Generated at 2022-06-12 01:37:15.406150
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) in ['a', 'b', 'c']
    assert choice(items=['a', 'b', 'c'], length=1) in [['a'], ['b'], ['c']]
    assert choice(items='abc', length=2) in ['ba', 'ab', 'cb']
    assert choice(items=('a', 'b', 'c'), length=5) in (['a', 'b', 'c'] * 5)
    assert choice(items='aabbbccccddddd', length=4, unique=True) in ['cdba', 'cabd', 'dcba']

# Generated at 2022-06-12 01:37:26.647243
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    _items = ['a', 'b', 'c']
    _length = 5
    _unique = True

    def _inner():
        """Inner function."""
        _obj = Choice()
        _result = _obj(items=_items, length=_length, unique=_unique)
        assert isinstance(_result, (list, tuple, str))
        assert len(_result) == _length

    for _ in range(100):
        _inner()

    def _inner2():
        """Inner function."""
        _obj = Choice()
        _result = _obj(_items)
        assert isinstance(_result, (list, tuple, str))

    for _ in range(100):
        _inner2()

# Generated at 2022-06-12 01:37:37.382211
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import random
    import unittest

    class Choice___call__TestCase(unittest.TestCase):
        def setUp(self):
            self.choice = Choice()
            self.choice.random = random.SystemRandom()

        def test_Choice___call__(self):
            self.assertIn(self.choice(items=['a', 'b', 'c']), ['a', 'b', 'c'])
            self.assertIn(self.choice(items=('a', 'b', 'c'), length=5),
                          ('a', 'b', 'c'))
            self.assertEqual(self.choice(items=['a', 'b', 'c'], length=1),
                             ['a'])

# Generated at 2022-06-12 01:37:39.878405
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Tests method Choice.__call__."""
    import doctest
    doctest.testmod(verbose=True)

test_Choice___call__()

# Generated at 2022-06-12 01:37:50.155528
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import pytest
    from random import randint
    from mimesis.providers.choice import Choice
    from mimesis.enums import Localization

    item = ('a', 'b', 'c')
    choice = Choice(Localization.EN)
    assert choice(items=item, length=randint(0, 10))
    assert choice(items=item, length=randint(0, 10), unique=True)

    with pytest.raises(TypeError) as excinfo:
        choice(items='a', length=randint(0, 10))
    assert excinfo.value.args[0] == '**length** must be integer.'


# Generated at 2022-06-12 01:37:58.415940
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    from mimesis import Choice
    choice = Choice()

    choice(items=['a', 'b', 'c'])
    'c'
    choice(items=['a', 'b', 'c'], length=1)
    ['a']
    choice(items='abc', length=2)
    'ba'
    choice(items=('a', 'b', 'c'), length=5)
    ('c', 'a', 'a', 'b', 'c')
    choice(items='aabbbccccddddd', length=4, unique=True)
    'cdba'

# Generated at 2022-06-12 01:38:08.871895
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert len(Choice()(items=list(range(1, 100)), length=1)) == 1
    assert len(Choice()(items=list(range(1, 100)), length=2)) == 2
    assert len(Choice()(items=list(range(1, 100)), length=3)) == 3
    assert len(Choice()(items=list(range(1, 100)), length=4)) == 4
    assert len(Choice()(items=list(range(1, 100)), length=5)) == 5
    assert len(Choice()(items=list(range(1, 100)), length=6)) == 6
    assert len(Choice()(items=list(range(1, 100)), length=7)) == 7
    assert len(Choice()(items=list(range(1, 100)), length=8)) == 8

# Generated at 2022-06-12 01:38:17.026658
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import string
    import random
    from mimesis.providers.choice import Choice

    choice = Choice()
    data = string.ascii_letters

    items = data
    unique = False
    length = random.randint(1, len(items))
    res2 = choice(items=items, length=length, unique=unique)

    items = data
    unique = True
    length = random.randint(1, len(items))
    res3 = choice(items=items, length=length, unique=unique)

    print(res2, res3)

# Generated at 2022-06-12 01:38:21.869658
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    data = {
        'items': [10, 15, 20],
        'length': 2,
        'unique': True,
        'result': 10,
    }
    provider = Choice()
    result = provider(data['items'], data['length'], data['unique'])
    
    assert result == data['result']

# Generated at 2022-06-12 01:38:26.850263
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import doctest
    results = doctest.testmod()
    if results.failed == 0:
        print('TEST PASSED')

# Generated at 2022-06-12 01:38:36.087092
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # test Choice.__call__(items = list, length = 1)
    assert Choice()(items = ['a', 'b', 'c'], length = 1) == ['a']

    # test Choice.__call__(items = str, length = 2)
    assert Choice()(items = 'abc', length = 2) == 'ba'

    # test Choice.__call__(items = tuple, length = 5)
    assert Choice()(items = ('a', 'b', 'c'), length = 5) == ('c', 'a', 'a', 'b', 'c')

    # test Choice.__call__(items = str, length = 4, unique = True)
    assert Choice()(items = 'aabbbccccddddd', length = 4, unique = True) == 'cdba'

# Generated at 2022-06-12 01:38:44.952102
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # expected value = 'c'
    items = ['a', 'b', 'c']
    # expected value = ['a']
    items = ['a', 'b', 'c']
    # expected value = 'ba'
    items = 'abc'
    # expected value = ('c', 'a', 'a', 'b', 'c')
    items = ('a', 'b', 'c')
    # expected value = 'cdba'
    items = 'aabbbccccddddd'
    assert items == 'aabbbccccddddd'
    assert items == 'aabbbccccddddd'

# Generated at 2022-06-12 01:38:53.434791
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    choice = Choice()
    assert choice(items=['a', 'b', 'c']) == 'c'
    assert choice(items=['a', 'b', 'c'], length=1) == ['a']
    assert choice(items='abc', length=2) == 'ba'
    assert choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'
    assert choice(items=['a', 'b', 'c'], length=1) == ['b']
    assert choice(items='abc', length=2) == 'aa'

# Generated at 2022-06-12 01:39:04.845182
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    # Initialize class
    choice = Choice()

    items = ['a', 'b', 'c']
    c = choice(items=items)
    assert c in items

    c = choice(items=items, length=1)
    assert c in items

    c = choice(items='abc', length=2)
    assert len(c) == 2
    assert c[0] in 'abc'
    assert c[1] in 'abc'

    c = choice(items=('a', 'b', 'c'), length=5)

# Generated at 2022-06-12 01:39:15.643228
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """
    Unit test for method __call__ of class Choice
    """
    import random
    import string
    import sys
    import unittest

    if sys.version_info >= (3, 5):
        from importlib import reload

    class ChoiceTestCase(unittest.TestCase):
        """Tests for Choice."""

        def setUp(self):
            """
            Setup for ChoiceTestCase
            """
            try:
                reload(string)
            except NameError:
                pass

            self.choice = Choice(random=random)

            try:
                reload(string)
            except NameError:
                pass

        def tearDown(self):
            """
            Teardown for ChoiceTestCase
            """
            self.choice = None


# Generated at 2022-06-12 01:39:23.352865
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit tests for methods of class Choice."""
    import pytest
    from mimesis.enums import ExceptionName
    from mimesis.exceptions import NonEnumerableError

    choice = Choice()

    with pytest.raises(TypeError):
        choice(
            items=('a', 'b', 'c'), length=1.1
        )

    with pytest.raises(TypeError):
        choice(
            items={'a', 'b', 'c'}, length=1
        )

    with pytest.raises(TypeError):
        choice(
            items=None, length=1
        )

    with pytest.raises(ValueError):
        choice(
            items=(),
        )


# Generated at 2022-06-12 01:39:35.184104
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    from mimesis.enums import Severity
    choice = Choice(severity=Severity.CRITICAL)
    items = ['a', 'b', 'c']
    assert choice(items=items) in items
    assert len(choice(items=items, length=1)) == 1
    assert len(choice(items='abc', length=2)) == 2
    assert len(choice(items=('a', 'b', 'c'), length=5)) == 5
    assert len(choice(items='aabbbccccddddd', length=4, unique=True)) == 4
    #assert choice(items='aabbbccccddddd', length=5, unique=True) == ['a', 'b', 'c', 'd', 'e']
    #assert len(choice(items='aabbbccccddddd', length

# Generated at 2022-06-12 01:39:45.315213
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import random
    class _random():
        def choice(items: Any) -> Any:
            return 'c'
    _choice = Choice(random=_random())

    assert _choice(items=['a', 'b', 'c']) == 'c'

    assert _choice(items=['a', 'b', 'c'], length=1) ==  ['a']

    assert _choice(items='abc', length=2) == 'ba'

    assert _choice(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')

    assert _choice(items='aabbbccccddddd', length=4, unique=True) == 'cdba'


# Generated at 2022-06-12 01:39:53.249992
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choice = Choice()
    # TODO: fix randomness
    assert choice(['a', 'b', 'c']) == "c"
    assert choice(['a', 'b', 'c'], length=1) == ['a']
    assert choice('abc', length=2) == 'ba'
    assert choice(('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert choice('aabbbccccddddd', length=4, unique=True) == 'cdba'
    assert choice('aabbbccccddddd', length=4, unique=False) == 'cabd'

# Generated at 2022-06-12 01:42:12.629804
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    assert True


# Generated at 2022-06-12 01:42:22.968885
# Unit test for method __call__ of class Choice

# Generated at 2022-06-12 01:42:26.520508
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    try:
        choice = Choice()
        assert choice(items=['a', 'b', 'c'], length=1) == ['b']
    except Exception:
        print('Choice() method __call__() failed.')


# Generated at 2022-06-12 01:42:33.078415
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Unit test for method __call__ of class Choice."""
    import random
    random.seed(0)
    assert Choice().__call__(items=['a', 'b', 'c']) == 'c'
    assert Choice().__call__(items=['a', 'b', 'c'], length=1) == ['a']
    assert Choice().__call__(items='abc', length=2) == 'ba'
    # noinspection PyTypeChecker
    assert Choice().__call__(items=('a', 'b', 'c'), length=5) == ('c', 'a', 'a', 'b', 'c')
    assert Choice().__call__(items='aabbbccccddddd', length=4, unique=True) == 'cdba'

# Generated at 2022-06-12 01:42:40.731571
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test for method __call__ of class Choice."""
    c = Choice()

    items = ['a', 'b', 'c']
    assert c(items) in items
    assert c(items, length=1) in items
    assert c(items, length=2) in items
    assert c(items, length=3) in items
    assert c(items, length=4) in items

    try:
        c(items, length=0)
    except Exception as e:
        assert isinstance(e, ValueError)

    try:
        c(items, unique=True)
    except Exception as e:
        assert isinstance(e, ValueError)

# Generated at 2022-06-12 01:42:50.336498
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    """Test method __call__ of class Choice."""
    # Case 1.
    choice = Choice()
    result = choice(items=['a', 'b', 'c'])
    assert result in ['a', 'b', 'c']
    # Case 2.
    choice = Choice()
    result = choice(items=['a', 'b', 'c'], length=1)
    assert result in [ ['a'], ['b'], ['c'] ]
    # Case 3.
    choice = Choice()
    result = choice(items='abc', length=2)
    assert result in ['ab', 'ac', 'bc']
    # Case 4.
    choice = Choice()
    result = choice(items=('a', 'b', 'c'), length=5)

# Generated at 2022-06-12 01:42:58.925970
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    choices = Choice()
    print(choices(items=['a', 'b', 'c']))  # prints 'c'
    print(choices(items=['a', 'b', 'c'], length=1))  # prints ['a']
    print(choices(items='abc', length=2))  # prints 'ba'
    print(choices(items=('a', 'b', 'c'), length=5))  # prints ('c', 'a', 'a', 'b', 'c')
    print(choices(items='aabbbccccddddd', length=4, unique=True))  # prints 'cdba'

# Generated at 2022-06-12 01:43:02.378478
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    items = [1, 2, 3]
    length = 2
    choice = Choice()

    returned = choice(items, length)
    assert isinstance(returned, list)
    assert type(returned) == list
    assert len(returned) == 2
    assert returned == [3, 2] or returned == [2, 3]

# Generated at 2022-06-12 01:43:12.012055
# Unit test for method __call__ of class Choice
def test_Choice___call__():

    # Test for invalid type for **length**
    try:
        result = Choice().__call__(items=['a', 'b', 'c'], length=True)
    except Exception as e:
        assert e.__class__.__name__ == TypeError.__name__
        assert e.args[0] == '**length** must be integer.'

    # Test for invalid type for **items**
    try:
        result = Choice().__call__(items=True)
    except Exception as e:
        assert e.__class__.__name__ == TypeError.__name__
        assert e.args[0] == '**items** must be non-empty sequence.'

    # Test for invalid **length**

# Generated at 2022-06-12 01:43:22.261426
# Unit test for method __call__ of class Choice
def test_Choice___call__():
    import random
    import string
    from mimesis.exceptions import NonEnumerableError
    from mimesis.typing import Seed

    choice = Choice()

    # Case 1: Non-empty sequence
    assert isinstance(choice(items=['a', 'b', 'c']), str)

    # Case 2: Length 1
    assert isinstance(choice(items=['a', 'b', 'c'], length=1), list)

    # Case 3: Length 2
    assert isinstance(choice(items='abc', length=2), str)

    # Case 4: Length 2
    assert isinstance(choice(items=('a', 'b', 'c'), length=5), tuple)

    # Case 5: Unique
    assert isinstance(choice(items='aabbbccccddddd', length=4, unique=True), str)