

# Generated at 2022-06-23 05:31:54.704680
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dummy_instance = AnsibleDumper(indent=4, width=1000, allow_unicode=False)

    assert isinstance(dummy_instance, object)


# Generated at 2022-06-23 05:32:06.976876
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Test with a text secret (unicode)
    text_secret = u'a' * 32
    aveu = AnsibleVaultEncryptedUnicode(text_secret)
    assert '  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa' in yaml.dump(aveu, Dumper=AnsibleDumper)

    # Test with a binary secret (bytes)
    binary_secret = b'b' * 32
    aveu = AnsibleVaultEncryptedUnicode(binary_secret)
    assert '  bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb' in yaml.dump(aveu, Dumper=AnsibleDumper)

# Generated at 2022-06-23 05:32:11.508112
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    repr = yaml.Representer()
    repr.flatten = lambda obj, info: obj

    assert(represent_vault_encrypted_unicode(repr, 'hello') == "!vault |\n  aGVsbG8=\n")

# Generated at 2022-06-23 05:32:19.546640
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper
    sample = dict(
        a=1,
        b=dict(
            c=2,
            d=3
        ),
        e=dict(
            f=dict(
                g=4,
                h=5
            ),
            i=6,
            j=7
        )
    )

    result = dumper.represent_hostvars(sample)
    assert result.value == sample
    assert result.style == '|'


# Generated at 2022-06-23 05:32:22.589398
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    ad = AnsibleDumper()
    assert isinstance(ad, AnsibleDumper)

# Generated at 2022-06-23 05:32:24.509660
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper) == 'None\n'

# Generated at 2022-06-23 05:32:30.736218
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    ansible_dumper = AnsibleDumper()

    assert ansible_dumper.represent_binary == represent_binary
    assert ansible_dumper.represent_str == represent_unicode
    assert ansible_dumper.represent_list == yaml.representer.SafeRepresenter.represent_list
    assert ansible_dumper.represent_dict == yaml.representer.SafeRepresenter.represent_dict
    assert ansible_dumper.represent_undefined == represent_undefined

my_tuple = (1, 2)

# Generated at 2022-06-23 05:32:32.982264
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    d = AnsibleDumper
    assert isinstance(d, SafeDumper)

# Generated at 2022-06-23 05:32:38.492632
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # data
    data = {'key1': 'value1', 'key2': 'value2'}
    # result
    result = b'{key1: value1, key2: value2}\n...\n'
    # tests
    assert yaml.dump(HostVars(data), Dumper=AnsibleDumper) == result



# Generated at 2022-06-23 05:32:40.419387
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper is not None
    assert AnsibleDumper.representer is not None

# Generated at 2022-06-23 05:32:43.860426
# Unit test for function represent_undefined
def test_represent_undefined():
    yaml_str = yaml.dump([AnsibleUndefined], default_flow_style=True, Dumper=AnsibleDumper)
    assert yaml_str == "[bool(ansible.template.AnsibleUndefined)]\n"


# Generated at 2022-06-23 05:32:54.236772
# Unit test for function represent_unicode

# Generated at 2022-06-23 05:33:03.648825
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    rep = yaml.representer.SafeRepresenter.represent_str
    # Some utf-8 encoded text for testing
    # Bytes with values in range 0-127 are not affected by utf-8 encoding
    ansible_unicode = AnsibleUnicode('ansible_unicode')
    ansible_utf8 = AnsibleUnicode('ansible_utf-8')
    ansible_unicode.encode('utf-8')
    ansible_utf8.encode('utf-8')
    assert ansible_unicode == ansible_utf8
    assert dumper.represent_unicode(dumper, ansible_unicode) == rep(dumper, text_type(ansible_unicode))
    assert dumper.represent_unicode(dumper, ansible_utf8)

# Generated at 2022-06-23 05:33:08.016713
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import Undefined
    from ansible.template import UndefinedError

    expect_error = False
    try:
        yaml.safe_dump(Undefined(), Dumper=AnsibleDumper)
    except UndefinedError:
        expect_error = True
    assert expect_error

# Generated at 2022-06-23 05:33:16.986634
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    '''Test our definition of a Vault encrypted unicode string'''

    # TODO:  This is quite basic, we should test for quoted output,
    #        and also that an existing secret is not modified.


# Generated at 2022-06-23 05:33:18.648828
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert hasattr(AnsibleDumper, 'add_representer')


# Generated at 2022-06-23 05:33:20.242144
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper is not None

# Generated at 2022-06-23 05:33:23.487971
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    assert dumper.represent_undefined(dumper, AnsibleUndefined('{{ foo }}')) == True



# Generated at 2022-06-23 05:33:26.695627
# Unit test for function represent_unicode
def test_represent_unicode():
    dump_str = yaml.dump(u'some string', Dumper=AnsibleDumper)
    assert dump_str == 'some string\n...\n'



# Generated at 2022-06-23 05:33:29.452094
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper, type)



# Generated at 2022-06-23 05:33:36.386565
# Unit test for function represent_binary
def test_represent_binary():
    input = b'123'
    output = yaml.representer.SafeRepresenter.represent_binary(
        yaml.representer.SafeRepresenter(), input)
    assert output == '!!binary |-\n  MTIz\n'
    input = b'MTIz'
    output = yaml.representer.SafeRepresenter.represent_binary(
        yaml.representer.SafeRepresenter(), input)
    assert output == '!!binary |-\n  MTIz\n'



# Generated at 2022-06-23 05:33:39.451520
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    assert dumper.represent_data(AnsibleUndefined) is False


# Generated at 2022-06-23 05:33:44.404575
# Unit test for function represent_unicode
def test_represent_unicode():
    '''represent_unicode should return a yaml.representer.SafeRepresenter.represent_str'''
    dumper = yaml.Dumper
    data = '123'
    result = represent_unicode(dumper, data)
    # string is converted to unicode and then serialized
    assert result == True


# Generated at 2022-06-23 05:33:54.354132
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hv = HostVars('127.0.0.1')

    hv.add_hostvar(HostVarsVars({'ansible_connection': 'local'}))
    hv.add_hostvar(HostVarsVars({'ansible_host': '127.0.0.1'}))
    hv.update(VarsWithSources({'gather_facts': True}))

    output = yaml.dump({'127.0.0.1': hv}, default_flow_style=False, Dumper=AnsibleDumper)
    assert output == '127.0.0.1:\n  gather_facts: true\n  ansible_connection: local\n  ansible_host: 127.0.0.1\n'



# Generated at 2022-06-23 05:34:02.216370
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    data = dict(a="1", b=dict(b1=1.1), c=[])
    for filename in ["test_AnsibleDumper.yml", "test_AnsibleDumper2.yml"]:
        # Unit test for function text_type
        with open(filename, 'w') as f:
            yaml.dump(data, f, Dumper=AnsibleDumper, default_flow_style=False)

        with open(filename, 'r') as f:
            for line in f:
                print(line)

# Generated at 2022-06-23 05:34:12.711593
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = AnsibleVaultEncryptedUnicode("mypassword")

# Generated at 2022-06-23 05:34:16.750040
# Unit test for function represent_hostvars
def test_represent_hostvars():
    ansible_dumper = AnsibleDumper()
    hostvars = HostVars(hostvars='hostvars')
    assert ansible_dumper.represent_hostvars(hostvars) == ansible_dumper.represent_dict(dict(hostvars))

# Generated at 2022-06-23 05:34:18.230617
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper(indent=4, width=12)



# Generated at 2022-06-23 05:34:21.079039
# Unit test for function represent_binary
def test_represent_binary():
    from ansible.parsing.yaml.objects import AnsibleUnsafeBytes
    data = AnsibleUnsafeBytes(b'123')
    assert AnsibleDumper().represent_binary(data) == \
        yaml.representer.SafeRepresenter().represent_binary(data)

# Generated at 2022-06-23 05:34:23.183734
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper().safe_representers == SafeDumper.safe_representers

# Generated at 2022-06-23 05:34:33.088302
# Unit test for function represent_undefined
def test_represent_undefined():
    # Scenario 1: _fail_with_undefined_error is NOT true
    repr_undef = AnsibleDumper.represent_undefined
    old_fail_undef = AnsibleDumper._fail_with_undefined_error
    AnsibleDumper._fail_with_undefined_error = False
    assert repr_undef(AnsibleDumper, AnsibleUndefined) is False
    AnsibleDumper._fail_with_undefined_error = old_fail_undef

    # Scenario 2: _fail_with_undefined_error is true
    AnsibleDumper._fail_with_undefined_error = True
    try:
        repr_undef(AnsibleDumper, AnsibleUndefined)
    except AnsibleUndefined as e:
        assert "One or more undefined variables" in str(e)


# Generated at 2022-06-23 05:34:39.127363
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import Templar
    from ansible.template.safe_eval import unsafe_eval

    templar = Templar(loader=None, variables={})
    dump_str = yaml.dump({'foo': unsafe_eval("Undefined('foo')")}, Dumper=AnsibleDumper)
    assert dump_str == "# Error evaluating value: Undefined Variable Undefined('foo')\nFalse\n"

# Generated at 2022-06-23 05:34:49.748594
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.manager import VariableManager
    from ansible.vars import hostvars as hv
    from tempfile import NamedTemporaryFile

    # create an empty hostvars
    host_vars_manager = hv.HostVars(loader=None, variables=VariableManager())

    # HostVars is AnsibleMapping
    assert isinstance(host_vars_manager, AnsibleMapping)

    # get the yaml representation
    t = yaml.dump(host_vars_manager, default_flow_style=False)

    # make sure it's valid yaml
    data = yaml.load(t, Loader=yaml.SafeLoader)

    # make sure data is a AnsibleMapping
    assert isinstance(data, AnsibleMapping)

    # make sure it's an empty AnsibleM

# Generated at 2022-06-23 05:34:52.031478
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():

    # test the constructor is not None
    adumper = AnsibleDumper()

    assert adumper is not None


# Generated at 2022-06-23 05:34:56.238528
# Unit test for function represent_undefined
def test_represent_undefined():
    data = AnsibleUndefined('test_represent_undefined')
    assert yaml.dump(data, Dumper=AnsibleDumper)
    data = AnsibleUndefined('test_represent_undefined', 'attr')
    assert yaml.dump(data, Dumper=AnsibleDumper)

# Generated at 2022-06-23 05:34:59.247791
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(b'\x80') == AnsibleDumper.represent_binary(AnsibleDumper.represent_scalar, 'tag:yaml.org,2002:binary', b'\x80')

# Generated at 2022-06-23 05:35:07.929894
# Unit test for function represent_hostvars
def test_represent_hostvars():
    var = HostVars(hostvars={"host1": {"var1": "val1"}, "host2": {"var2": "val2"}})
    result = yaml.dump(var, Dumper=AnsibleDumper)
    assert result == '\n' \
                      'host1:\n' \
                      '  var1: "val1"\n' \
                      'host2:\n' \
                      '  var2: "val2"\n'

    var = HostVarsVars(hostvars={"host1": {"var1": "val1"}, "host2": {"var2": "val2"}})
    result = yaml.dump(var, Dumper=AnsibleDumper)

# Generated at 2022-06-23 05:35:11.790253
# Unit test for function represent_unicode
def test_represent_unicode():
    my_unicode = AnsibleUnicode(text_type(b'abcd\x00'.decode('utf-8')))
    represent_unicode(AnsibleDumper, my_unicode)



# Generated at 2022-06-23 05:35:12.564091
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper

# Generated at 2022-06-23 05:35:14.694388
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) is None

# Generated at 2022-06-23 05:35:24.084965
# Unit test for function represent_unicode
def test_represent_unicode():
    # Test yaml.representer.SafeRepresenter.represent_unicode
    # isn't being called on instances of AnsibleUnicode
    # This means __repr__ won't be called on the instance
    # since it calls yaml.representer.SafeRepresenter.represent_unicode
    # inside its implementation.
    # The default implementation of __repr__ on a str subclass
    # returns 'text_type(self)' which would corrupt the string
    dumper = AnsibleDumper

    class MyStrSubclass(str):
        def __repr__(cls):
            return repr('my_repr')

    # In case the class defines a different __repr__
    # and doesn't call the base class.
    test = MyStrSubclass('my string')

# Generated at 2022-06-23 05:35:25.777176
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    AnsibleDumper()



# Generated at 2022-06-23 05:35:30.857425
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # this is a silly test, but we have to have something
    # and the above code is complex enough that it's not
    # obvious what to test for.
    assert represent_vault_encrypted_unicode(AnsibleDumper,
                                             AnsibleVaultEncryptedUnicode('foo')) == '!vault |\n  Zm9v'

# Generated at 2022-06-23 05:35:33.906252
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foobar') == yaml.representer.SafeRepresenter.represent_str(dumper, u'foobar')



# Generated at 2022-06-23 05:35:40.017481
# Unit test for function represent_binary
def test_represent_binary():
    dumper = yaml.SafeDumper
    dumper.add_representer(binary_type, represent_binary)
    dumped = yaml.dump(b'\xff', Dumper=dumper)
    # Check that the dumped string is equivalent to the one provided,
    # which is the YAML representation for the string "ff".
    assert dumped == "!!binary '\\\\xff'\n"

# Generated at 2022-06-23 05:35:44.347521
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    data = b'ABC\x00DEF'
    yaml_str = dumper.represent_binary(data)
    assert(yaml_str == "\x41\x42\x43\x00\x44\x45\x46")



# Generated at 2022-06-23 05:35:44.962128
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    AnsibleDumper()

# Generated at 2022-06-23 05:35:48.579537
# Unit test for function represent_undefined
def test_represent_undefined():
    yaml_data = yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper)
    assert yaml_data == 'null\n'



# Generated at 2022-06-23 05:35:52.553863
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = HostVars({"var1": "value1", "var2": "value2"})
    assert represent_hostvars(None, data) == {'var1': 'value1', 'var2': 'value2'}

# Generated at 2022-06-23 05:36:03.357171
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    '''
    Test that the function represent_vault_encrypted_unicode
    returns the appropriate YAML representation of an
    AnsibleVaultEncryptedUnicode object.
    '''
    dumper = AnsibleDumper()

# Generated at 2022-06-23 05:36:06.343082
# Unit test for function represent_binary
def test_represent_binary():
    stream = yaml.StringIO()
    yaml.Dumper = AnsibleDumper
    yaml.SafeDumper.add_representer(binary_type, represent_binary)
    yaml.dump('some binary value', stream, default_flow_style=False)
    assert stream.getvalue() == "'some binary value'\n"

# Generated at 2022-06-23 05:36:15.370301
# Unit test for function represent_unicode
def test_represent_unicode():
    # object1 -> ascii
    object1 = u'i am ascii'
    expected1 = yaml.representer.SafeRepresenter.represent_str(AnsibleDumper, text_type(object1))
    actual1 = represent_unicode(AnsibleDumper, object1)
    assert actual1 == expected1

    # object2 -> unicode
    object2 = u'i am unicode \u5409\u5409\u5409'
    expected2 = yaml.representer.SafeRepresenter.represent_str(AnsibleDumper, text_type(object2))
    actual2 = represent_unicode(AnsibleDumper, object2)
    assert actual2 == expected2

    # object3 -> bytes
    object3 = b'i am bytes'
    expected3 = yaml.representer

# Generated at 2022-06-23 05:36:17.605050
# Unit test for function represent_undefined
def test_represent_undefined():
    yaml_data = yaml.dump({"test": AnsibleUndefined}, Dumper=AnsibleDumper)
    assert yaml_data == '{test: false}\n'



# Generated at 2022-06-23 05:36:24.918254
# Unit test for function represent_hostvars
def test_represent_hostvars():
    """
    Write docstring.
    """
    # hostvars = {'key1': 'value1', 'key2': 'value2'}
    hostvars = VarsWithSources({'key1': 'value1', 'key2': 'value2'})
    output = yaml.dump(hostvars, default_flow_style=False, Dumper=AnsibleDumper)
    assert output == 'key1: value1\nkey2: value2\n'


# Generated at 2022-06-23 05:36:33.966453
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hv = HostVars()
    hv['a.b'] = {'c': 'd'}
    hv['a.b']['vars'] = HostVarsVars()
    hv['a.b']['vars']['e'] = 'f'

    yaml_text = yaml.dump(hv, Dumper=AnsibleDumper)
    assert yaml_text == '{a: {b: {c: d, vars: {e: f}}}}\n'

    # Test with a VarsWithSources instance
    hv = VarsWithSources()
    hv['a.b'] = {'c': 'd'}
    hv['a.b']['vars'] = HostVarsVars()

# Generated at 2022-06-23 05:36:44.783618
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultEditor, VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.module_utils.common.text.converters import ensure_text

    # Test if string is correctly serialized
    if not hasattr(yaml, 'CSafeLoader'):
        import warnings
        warnings.warn("Problem with PyYAML 3.11 in Python 3.4. PyYAML 3.12 works.")

    editor = VaultEditor(1, b'\x00')
    plaintext = 'plaintext'
    ciphertext = editor.encrypt(plaintext)
    data = AnsibleVaultEncryptedUnicode(ciphertext)
    serialized = yaml.dump(data, Dumper=AnsibleDumper)


# Generated at 2022-06-23 05:36:52.013205
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template.safe_eval import assert_passes_undefined_checks

    # Here bool will ensure _fail_with_undefined_error happens
    # if the value is Undefined.
    # This happens because Jinja sets __bool__ on StrictUndefined
    assert_passes_undefined_checks(lambda: yaml.dump(
        AnsibleUndefined('my_undefined_value'),
        default_flow_style=False,
        Dumper=AnsibleDumper
    ))

# Generated at 2022-06-23 05:36:53.414875
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert AnsibleDumper.represent_hostvars is represent_hostvars



# Generated at 2022-06-23 05:36:59.567190
# Unit test for function represent_undefined
def test_represent_undefined():
    # Just check the call to _fail_with_undefined_error
    # In Python 3.4 bool(None) raises a TypeError
    # In Python 2.7 bool(None) returns False and thus _fail_with_undefined_error won't be called
    try:
        represent_undefined(AnsibleDumper, AnsibleUndefined())
    except TypeError:
        pass

# Generated at 2022-06-23 05:37:03.123703
# Unit test for function represent_undefined
def test_represent_undefined():
    representer = yaml.representer.SafeRepresenter()
    representer.add_representer(AnsibleUndefined, represent_undefined)
    assert not representer.represent_undefined(AnsibleUndefined())

# Generated at 2022-06-23 05:37:07.557886
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper
    data = AnsibleVaultEncryptedUnicode(b"foo")

    ret = dumper.represent_vault_encrypted_unicode(dumper, data)
    assert ret == '!vault |\n          Zm9v\n'


# Generated at 2022-06-23 05:37:19.597135
# Unit test for function represent_hostvars
def test_represent_hostvars():

    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.unsafe_proxy import wrap_var

    loader = AnsibleLoader(None, '<string>')

# Generated at 2022-06-23 05:37:30.698783
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(binary_type('"foo"', 'utf-8')) == yaml.representer.SafeRepresenter.represent_binary(dumper, binary_type('"foo"', 'utf-8'))
    assert dumper.represent_binary(binary_type('"foo"', 'utf-8')) == yaml.representer.SafeRepresenter.represent_binary(dumper, binary_type('"foo"', 'utf-8'))
    assert dumper.represent_binary(binary_type('"bar"', 'utf-8')) == yaml.representer.SafeRepresenter.represent_binary(dumper, binary_type('"bar"', 'utf-8'))

# Generated at 2022-06-23 05:37:33.676286
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = yaml.dumper.BaseDumper()
    dumper.represent_undefined = represent_undefined

    assert dumper.represent_data(AnsibleUndefined('foo')) is True

# Generated at 2022-06-23 05:37:41.910678
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    vault = VaultLib([])
    encrypted_str = AnsibleVaultEncryptedUnicode(vault.encrypt("stub"), vault)

    data = {'a': 'stub', 'b': 'stub', 'c': encrypted_str}
    hostvars = HostVars(data)

    result = yaml.dump(hostvars, Dumper=AnsibleDumper)
    assert 'a: stub\nb: stub\nc: !vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          ...' in result



# Generated at 2022-06-23 05:37:50.334256
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    value = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\n356536306665383366373361333765303735396330656561383731366536393935373538333864613661310a63353037383038643135333730653635383634616532346435333035653331366235653361613432360a3930643332333162326565643939383335373834376163653966343264646638336437326261313065\n')
    # vault_data = value._ciphertext.decode()
    # print("vault_data is : %s" % vault_data)

# Generated at 2022-06-23 05:37:57.097694
# Unit test for function represent_unicode
def test_represent_unicode():
    # Make sure represent_unicode works as expected
    dump_data = AnsibleUnicode('abc')
    assert yaml.dump(dump_data, Dumper=AnsibleDumper) == "abc\n...\n"
    dump_data = AnsibleUnicode(u'abc')
    assert yaml.dump(dump_data, Dumper=AnsibleDumper) == "abc\n...\n"


# Issue #28996: make sure represent_binary handles bytestring

# Generated at 2022-06-23 05:38:06.145397
# Unit test for function represent_unicode
def test_represent_unicode():
    # Test function represent_unicode
    new_dumper = AnsibleDumper

    # Test unicode string
    unicode_string = u"Hello, world"
    assert new_dumper.represent_unicode(new_dumper, unicode_string) == "Hello, world"

    # Test unicode string with characters outside of ASCII
    unicode_string = u"Ångström"
    assert new_dumper.represent_unicode(new_dumper, unicode_string) == "Ångström"

    # Test BYTES
    bytes_string = "Hello, world"
    assert new_dumper.represent_unicode(new_dumper, bytes_string) == "Hello, world"

    # Test BYTES with characters outside ASCII
    bytes_string = "Ångström"

# Generated at 2022-06-23 05:38:14.314137
# Unit test for function represent_undefined
def test_represent_undefined():
    assert represent_undefined(None, AnsibleUndefined) == False
    assert represent_undefined(None, AnsibleUndefined("foo")) == False
    assert represent_undefined(None, AnsibleUndefined(u"foo")) == False
    assert represent_undefined(None, AnsibleUndefined(b"foo")) == False
    assert represent_undefined(None, AnsibleUndefined(AnsibleUndefined("foo"))) == False
    assert represent_undefined(None, AnsibleUndefined(AnsibleUndefined(b"foo"))) == False

# Generated at 2022-06-23 05:38:17.446558
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, u'foo') == u'foo'
    assert represent_unicode(None, u'\xc3\xa9') == u'é'
    assert represent_unicode(None, 'foo') == u'foo'



# Generated at 2022-06-23 05:38:23.253803
# Unit test for function represent_hostvars
def test_represent_hostvars():

    dumper = yaml.SafeDumper
    hostvars = HostVars()
    hostvars.update([('hostname', 'example'), ('port', 22)])
    assert dumper.represent_dict(dumper, hostvars) == dumper.represent_dict(dumper, {'hostname': 'example', 'port': 22})



# Generated at 2022-06-23 05:38:27.249635
# Unit test for function represent_undefined
def test_represent_undefined():
    #  Carries out the represent_undefined function
    #  on AnsibleUndefined object and returns the
    #  object as a boolean this tests that AnsibleUndefined
    #  has a __bool__ function.
    undef = AnsibleUndefined
    assert AnsibleDumper.represent_undefined(undef) is True

# Generated at 2022-06-23 05:38:31.790157
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    safe_dumper = yaml.SafeDumper
    encrypted_data = yaml.nodes.ScalarNode('!vault',
                                           'AES256',
                                           style='|')
    assert (represent_vault_encrypted_unicode(safe_dumper,
                                              'AES256') == encrypted_data)

# Generated at 2022-06-23 05:38:36.417722
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    result = yaml.dump(AnsibleUndefined('foo'), default_flow_style=False, Dumper=dumper)
    expected_result = 'bar\n'
    assert result == expected_result

# Generated at 2022-06-23 05:38:41.803638
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    class T(Templar):
        pass

    t = T(loader=None, variables={'foo': 'blub'})

    undefined = AnsibleUnsafeText(t._fail_with_undefined_error(t.templar._finalize_failed(var='blub', msg='foo', obj='bar', host='baz')))

    assert undefined == "{{ blub | to_nice_yaml | to_json }}"

# Generated at 2022-06-23 05:38:51.647293
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hv = HostVars({"a": 1})
    hvv = HostVarsVars({"b": 2})
    vws = VarsWithSources({"c": 3})

    data = {
        "hv": hv,
        "hvv": hvv,
        "vws": vws,
    }

    ansible_dumper = AnsibleDumper()
    yaml.Dumper.ignore_aliases = lambda *args: True
    expected = """{hv: {a: 1}, hvv: {b: 2}, vws: {c: 3}}"""
    assert expected == yaml.dump(data, Dumper=ansible_dumper)

# Generated at 2022-06-23 05:38:52.984270
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    a = AnsibleDumper
    assert a != None


# Generated at 2022-06-23 05:38:57.820517
# Unit test for function represent_binary
def test_represent_binary():
    representer = yaml.representer.BaseRepresenter()

    # Create a Dumper object with our fake representer object
    dumper = AnsibleDumper(representer=representer)

    unsafe_bytes = AnsibleUnsafeBytes(b'\xED\x9D\xC0\xF2')
    result = dumper.represent_data(unsafe_bytes)

    assert result == b"!binary |\n  w6I=\n"

# Generated at 2022-06-23 05:39:00.938205
# Unit test for function represent_hostvars
def test_represent_hostvars():
    obj = AnsibleMapping(dict(key_1=42, key_2=55))
    stream = AnsibleDumper.represent_hostvars(obj)
    assert stream == u'{key_1: 42, key_2: 55}', stream


# Generated at 2022-06-23 05:39:05.928055
# Unit test for function represent_undefined
def test_represent_undefined():
    AnsibleDumper.represent_undefined(None)


# Ensure that the objects are recognized by AnsibleDumper when instantiated
# This will have been caught by the unit tests, but just an extra check
assert isinstance(yaml.dump({}, Dumper=AnsibleDumper), str)

# Generated at 2022-06-23 05:39:17.857556
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper.yaml_base_dumper_class == SafeDumper
    assert hasattr(AnsibleDumper, 'represent_unicode')
    assert hasattr(AnsibleDumper, 'represent_binary')
    assert hasattr(AnsibleDumper, 'represent_hostvars')
    assert hasattr(AnsibleDumper, 'represent_vault_encrypted_unicode')
    assert hasattr(AnsibleDumper, 'represent_undefined')

# Generated at 2022-06-23 05:39:18.590801
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
  pass

# Generated at 2022-06-23 05:39:21.081561
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = {'test': 'data'}
    assert AnsibleDumper().represent_hostvars(data) == 'test: data'



# Generated at 2022-06-23 05:39:27.206134
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper()
    assert dumper.default_style == '"'
    assert dumper.default_flow_style is None
    assert dumper.indent == 4
    assert dumper.width == 80
    assert dumper.allow_unicode is True
    assert dumper.line_break == '\n'

# Generated at 2022-06-23 05:39:29.798306
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

    dumper.represent_binary('foo') == '!!binary |\n  Zm9v\n'

# Generated at 2022-06-23 05:39:33.926928
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_scalar(u'!vault', b'bar').value == "!vault |\n      bar\n"

# Generated at 2022-06-23 05:39:40.575550
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template.template import Undefined
    from ansible.parsing.yaml.objects import AnsibleMapping
    a = {'a': Undefined, 'b': [Undefined]}
    b = AnsibleMapping(a)
    c = AnsibleDumper(allow_unicode=True)
    assert c.represent_mapping('tag:yaml.org,2002:map', b)
    assert c.represent_sequence('tag:yaml.org,2002:seq', b['b'])

# Generated at 2022-06-23 05:39:45.625177
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, 'unicode_str') == \
        yaml.representer.SafeRepresenter.represent_str(None, text_type('unicode_str'))
    assert represent_unicode(None, 'unicode_str'.encode()) == \
        yaml.representer.SafeRepresenter.represent_str(None, text_type('unicode_str'))

# Generated at 2022-06-23 05:39:48.449870
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    with open('/etc/passwd') as passwd:
        data = yaml.safe_load(passwd)
    yaml.dump(data, Dumper=AnsibleDumper, indent=2, default_flow_style=False)

# Generated at 2022-06-23 05:39:52.067099
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = {'a': '1', 'b': '2'}

    h = HostVars(data)
    d = {'h': h}

    result = yaml.dump(d, Dumper=AnsibleDumper)

    expected = '''h: {a: 1, b: 2}
'''
    assert result == expected



# Generated at 2022-06-23 05:40:01.626956
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    # If this test fails, consider upgrading PyYAML
    assert AnsibleDumper.yaml_representers == {
        AnsibleUnicode: represent_unicode,
        AnsibleUnsafeText: represent_unicode,
        AnsibleUnsafeBytes: represent_binary,
        HostVars: represent_hostvars,
        HostVarsVars: represent_hostvars,
        VarsWithSources: represent_hostvars,
        AnsibleSequence: yaml.representer.SafeRepresenter.represent_list,
        AnsibleMapping: yaml.representer.SafeRepresenter.represent_dict,
        AnsibleVaultEncryptedUnicode: represent_vault_encrypted_unicode,
        AnsibleUndefined: represent_undefined
    }

# Generated at 2022-06-23 05:40:13.900515
# Unit test for function represent_undefined
def test_represent_undefined():
    # Explicitly check for the results of represent_undefined
    # and not use UnsafeLoader.load_all().
    # This is because load_all() has a call to load() which
    # in turn uses SafeLoader.construct_object() which
    # converts Undefined to None.
    d = AnsibleDumper(encoding='utf-8')
    try:
        result = d.represent_data(AnsibleUndefined())
    except RuntimeError as e:
        result = e.args[0]
    assert result == 'Invalid YAML: while parsing a flow mapping\n' \
                     '  in "string", line 1, column 1\n' \
                     'expected <block end>, but found \'<block mapping start>\'\n' \
                     '  in "string", line 1, column 2:'

# Generated at 2022-06-23 05:40:23.430589
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert not hasattr(AnsibleDumper.SafeRepresenter, 'represent_unicode')
    assert not hasattr(AnsibleDumper.SafeRepresenter, 'represent_binary')
    assert not hasattr(AnsibleDumper.SafeRepresenter, 'represent_undefined')
    assert hasattr(AnsibleDumper.SafeRepresenter, 'represent_str')
    assert not hasattr(AnsibleDumper.SafeRepresenter, 'represent_hostvars')
    assert not hasattr(AnsibleDumper.SafeRepresenter, 'represent_vault_encrypted_unicode')
    assert not hasattr(AnsibleDumper, 'SafeRepresenter')

    assert hasattr(AnsibleDumper, 'represent_unicode')
    assert hasattr(AnsibleDumper, 'represent_str')
    assert not hasattr

# Generated at 2022-06-23 05:40:28.314891
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    '''
    Creates an AnsibleDumper instance.
    '''
    AnsibleDumper()


# Generated at 2022-06-23 05:40:38.397837
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    ansible_dumper = AnsibleDumper()

    # Test if representers for super class SafeDumper exist.
    assert len(yaml.representer.SafeDumper.yaml_representers_types) > 0
    assert len(yaml.representer.SafeDumper.yaml_representers_types[0]) > 0
    assert len(yaml.representer.SafeDumper.yaml_representers_types[0][0]) > 0

    # Test if AnsibleDumper contains SafeDumper's representers for
    # types float and int.
    assert len(ansible_dumper.yaml_representers_types) > 0
    assert len(ansible_dumper.yaml_representers_types[0]) > 0

# Generated at 2022-06-23 05:40:44.084324
# Unit test for function represent_unicode
def test_represent_unicode():
    ansible_unicode = AnsibleUnicode("\u00a2")
    dumped_ansible_unicode = AnsibleDumper.represent_unicode(ansible_unicode)
    assert dumped_ansible_unicode == '!ansible|unsafe \\xa2'



# Generated at 2022-06-23 05:40:48.093020
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(AnsibleUnsafeBytes('\x16')) == "!!binary '\x16'\n"


# Generated at 2022-06-23 05:40:54.648794
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = """
    foo: bar
    baz:
      - 1
      - 2
      - 3
    """

    ds = AnsibleLoader(data, file_name=None).get_single_data()
    out = yaml.dump(ds, Dumper=AnsibleDumper, default_flow_style=False)
    assert out == data

# Generated at 2022-06-23 05:41:04.722750
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.vault import VaultSecret
    from io import BytesIO

    vault = VaultLib([])
    secret = VaultSecret(VaultEditor([], 1, 1, None, BytesIO('my secret password'.encode())))
    encrypted = vault.encrypt(secret, 'my secret password')

    vault_encrypted_unicode = AnsibleVaultEncryptedUnicode(encrypted)

# Generated at 2022-06-23 05:41:08.093498
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    ad = AnsibleDumper()
    # Assert that the class of ad is AnsibleDumper
    assert isinstance(ad, AnsibleDumper)


# Unit test to test the representers

# Generated at 2022-06-23 05:41:19.840180
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    text = 'foo'
    unencrypted_data = 'bar'
    encrypted_data = VaultLib.encrypt(text, unencrypted_data)
    dumper = AnsibleDumper()
    encrypted_unicode = AnsibleVaultEncryptedUnicode(encrypted_data)
    result = dumper.represent_data(encrypted_unicode)
    assert isinstance(result, text_type)

# Generated at 2022-06-23 05:41:22.726825
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'\x80') == u'\x80'
    assert dumper.represent_unicode(u'foo') == u'"foo"'

# Generated at 2022-06-23 05:41:34.352570
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = yaml.dumper.SafeDumper
    text = '$ANSIBLE_VAULT;1.1;AES256\nU2FsdGVkX18EXAMPLEcpd4h9oCXOjJYdY+07' \
        'BhJbwF+vzC67Ttra8Q2CfhZRjdYkYbL8\n3cqmJpwAAAAAAAAAAAAAAAPTsW8bo9/xb' \
        'Y7MkZDrS/6hNUzNnUvIn/NgW8d9XcXH\n0f0='
    encrypted = AnsibleVaultEncryptedUnicode(text)

    # Unit test using the AnsibleDumper

# Generated at 2022-06-23 05:41:41.079724
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(u"unicode", Dumper=AnsibleDumper) == u"unicode\n...\n"
    assert yaml.dump(u"unicode".encode('utf-8'), Dumper=AnsibleDumper) == u"unicode\n...\n"
    assert yaml.dump(u"unicøde".encode('utf-8'), Dumper=AnsibleDumper) == u"unic\u00f8de\n...\n"



# Generated at 2022-06-23 05:41:44.551005
# Unit test for function represent_unicode
def test_represent_unicode():
    u = u'\u2642'
    data = yaml.dump(u, Dumper=AnsibleDumper)
    assert data == u'- !!python/unicode &id001 \'\\u2642\'\n'



# Generated at 2022-06-23 05:41:56.194478
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():

    # Create a Cipher object (VaultLib.Cipher)
    from ansible.parsing.vault import VaultLib
    vault_lib = VaultLib("mypassword")

    # Create a VaultSecret object
    from ansible.parsing.vault import VaultSecret
    vault_secret = VaultSecret(vault_lib, b'test_message')

    # Create a AnsibleVaultEncryptedUnicode object
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode