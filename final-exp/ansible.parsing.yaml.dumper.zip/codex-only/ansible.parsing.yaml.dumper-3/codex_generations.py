

# Generated at 2022-06-23 05:31:54.663266
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper, type(yaml.Dumper))

# Generated at 2022-06-23 05:32:02.189706
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper
    assert represent_hostvars(dumper, {"a": "b"}) == dumper.represent_dict({"a": "b"})



# Generated at 2022-06-23 05:32:03.737580
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert hasattr(AnsibleDumper, 'add_representer')

# Generated at 2022-06-23 05:32:13.515603
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    bytes_content = b'\x01\x02\x03\x04'

    if hasattr(bytes_content, 'decode'):
        # Python 2: If a bytes content has the decode method, it is a bytes object
        # In Python 2, bytes is an alias of str
        assert type(dumper.represent_binary(bytes_content)) is yaml.nodes.ScalarNode

    else:
        # Python 3: If a bytes content does not have the decode method, it is a str object
        # In Python 3, str is an alias of unicode
        assert type(dumper.represent_binary(bytes_content)) is yaml.nodes.ScalarNode

# Generated at 2022-06-23 05:32:14.168766
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    AnsibleDumper()

# Generated at 2022-06-23 05:32:17.363939
# Unit test for function represent_binary
def test_represent_binary():
    data = AnsibleUnsafeBytes(b'\x80\x81\x82\x83')
    result = yaml.representer.SafeRepresenter.represent_binary(AnsibleDumper, data)
    assert result == "!!binary |\n  gICAgICA="


# Generated at 2022-06-23 05:32:18.779579
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper, SafeDumper)

# Generated at 2022-06-23 05:32:28.034477
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    # Test with VaultLib.yaml_load=True
    vault = VaultLib(password='secret')

# Generated at 2022-06-23 05:32:29.073966
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper, type)

# Generated at 2022-06-23 05:32:36.198841
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dict_to_test = {'some_key': 'some_value'}
    hostvars = HostVars()
    hostvars.add(dict_to_test, 'ansible_facts')
    expected = '{ansible_facts: {some_key: some_value}}'
    actual = yaml.dump(hostvars, Dumper=AnsibleDumper)
    assert expected == actual



# Generated at 2022-06-23 05:32:46.771531
# Unit test for function represent_binary
def test_represent_binary():
    # Generate a random binary blob (b'\x00' ... b'\xff')
    from os import urandom
    from random import randint
    from ssl import RAND_bytes

    def _is_urandom():
        try:
            RAND_bytes(1)
            return False
        except NotImplementedError:
            return True

    data = urandom(randint(0, 128)) if _is_urandom() else b'\x00' * randint(0, 128)
    representer = AnsibleDumper.represent_binary

    # Generate a simple scalar YAML representation
    expected = "!!binary |-\n  %s" % '\n'.join(data.encode('base64').decode().split())
    assert representer(None, data) == expected

    # Generate a flow Y

# Generated at 2022-06-23 05:32:51.865521
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()
    eu = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\n.....\n')
    assert dumper.represent_vault_encrypted_unicode(eu) == '!vault |\n  $ANSIBLE_VAULT;1.1;AES256\n.....\n'

# Generated at 2022-06-23 05:32:58.580294
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    value = b'\x01\x02\x03\x04\x05\x06\x07\x08\t\n\x0b\x0c\r\x0e\x0f'
    output = yaml.representer.SafeRepresenter.represent_binary(dumper, value)

    assert output == '!!binary |\n  AQIDBAUGBwgJCAkK\n'


# Generated at 2022-06-23 05:33:05.187607
# Unit test for function represent_unicode
def test_represent_unicode():
    x = AnsibleUnicode('unicode string')
    yaml.add_representer(AnsibleUnicode, represent_unicode, SafeDumper)
    assert yaml.dump(x, default_flow_style=True) == 'unicode string\n'
    assert yaml.dump(x, default_flow_style=False) == '- unicode string\n'


# Generated at 2022-06-23 05:33:07.065667
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper(), yaml.representer.SafeRepresenter)

# Generated at 2022-06-23 05:33:12.078327
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper.yaml_representers == SafeDumper.yaml_representers
    assert AnsibleDumper.add_representer == SafeDumper.add_representer
    assert AnsibleDumper.add_multi_representer == SafeDumper.add_multi_representer
    assert AnsibleDumper.remove_representer == SafeDumper.remove_representer



# Generated at 2022-06-23 05:33:14.593729
# Unit test for function represent_binary
def test_represent_binary():
    assert b'!binary |\n  dGVzdA==\n' == yaml.dump(binary_type(b'test'), Dumper=AnsibleDumper)

# Generated at 2022-06-23 05:33:23.628461
# Unit test for function represent_binary
def test_represent_binary():
    obj = AnsibleDumper({})
    value = b'a'
    result = obj.represent_binary(value)
    assert result == u'!!binary a'

    # Test !!python/unicode
    value = u'abcd'
    result = obj.represent_binary(value)
    assert result == u'!!binary YWJjZA=='

    # Test !!python/str
    value = 'abcd'
    result = obj.represent_binary(value)
    assert result == u'!!binary YWJjZA=='



# Generated at 2022-06-23 05:33:28.498148
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = yaml.YAML()
    dumper.version = (1, 2)
    hv = HostVars(dict(foo=dict(bar='foobar')))
    assert dumper.dump(hv) == 'foo:\n  bar: foobar\n'


# Generated at 2022-06-23 05:33:30.334449
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    d = AnsibleDumper.add_representer()
    assert d == AnsibleDumper


# Generated at 2022-06-23 05:33:34.201941
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = HostVars({'ansible_variable': 'value'})
    assert yaml.dump(hostvars, Dumper=AnsibleDumper) == (
        "ansible_variable: value\n"
    )



# Generated at 2022-06-23 05:33:36.670544
# Unit test for function represent_hostvars
def test_represent_hostvars():
    h = HostVars({"aglobal": "avalue"})
    assert(yaml.dump(h, Dumper=AnsibleDumper) == u'aglobal: avalue\n')



# Generated at 2022-06-23 05:33:41.053434
# Unit test for function represent_binary
def test_represent_binary():
    representer = AnsibleDumper()
    assert(representer.represent_binary('test_bytes')) == u'!binary |\n  dGVzdF9ieXRlcw=='


# Generated at 2022-06-23 05:33:43.252162
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper()
    assert dumper.default_flow_style is False


# Generated at 2022-06-23 05:33:46.611504
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(u'unicode string', Dumper=AnsibleDumper, default_flow_style=False) == u'unicode string\n...\n'



# Generated at 2022-06-23 05:33:51.072926
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(AnsibleDumper, AnsibleUnicode('hello')) == 'hello'
    assert represent_unicode(AnsibleDumper, AnsibleUnsafeText('hello')) == 'hello'



# Generated at 2022-06-23 05:33:57.963176
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars

    data = HostVars(host={"var1": "value1", "var2": "value2"})
    expected = {'hostvars': {'host': {'var1': 'value1', 'var2': 'value2'}}}

    dumped = yaml.dump(data, Dumper=AnsibleDumper)
    result = yaml.load(dumped, Loader=yaml.SafeLoader)

    assert result == expected

# Generated at 2022-06-23 05:34:03.657380
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(u'a') == yaml.dump(AnsibleUnicode(u'a'))



# Generated at 2022-06-23 05:34:08.795863
# Unit test for function represent_unicode
def test_represent_unicode():
    # Dump a string into a yaml
    # Then load it back again
    # Then check if the string was dumped correctly
    test_str = u"asd123"
    yaml_rep = yaml.dump(test_str)
    yaml_rep_loaded = yaml.load(yaml_rep, Loader=yaml.BaseLoader)
    assert yaml_rep_loaded == test_str

# Generated at 2022-06-23 05:34:11.978727
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    ansible_dumper = AnsibleDumper()
    assert ansible_dumper.__class__ == AnsibleDumper



# Generated at 2022-06-23 05:34:22.971778
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    print(dumper.represent_hostvars({u'a': u'b'}))
    print(dumper.represent_hostvars({'a': 'b'}))
    print(dumper.represent_hostvars({u'a': 1}))
    print(dumper.represent_hostvars({u'a': u'1'}))
    print(dumper.represent_hostvars({u'a': 1.11}))
    print(dumper.represent_hostvars({u'a': u'1.11'}))
    print(dumper.represent_hostvars({u'a': None}))
    print(dumper.represent_hostvars({u'a': False}))

# Generated at 2022-06-23 05:34:25.389775
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper()
    assert isinstance(dumper, yaml.representer.SafeRepresenter)



# Generated at 2022-06-23 05:34:34.019718
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, AnsibleUnicode('foo')) == yaml.representer.SafeRepresenter.represent_str(None, 'foo')
    assert represent_unicode(None, AnsibleUnsafeText('foo')) == yaml.representer.SafeRepresenter.represent_str(None, 'foo')
    assert represent_unicode(None, u'foo') == yaml.representer.SafeRepresenter.represent_str(None, 'foo')
    assert represent_unicode(None, b'foo') == yaml.representer.SafeRepresenter.represent_str(None, 'foo')



# Generated at 2022-06-23 05:34:44.954646
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    d = {'foo': AnsibleVaultEncryptedUnicode('bar')}
    serialized = yaml.dump(d, Dumper=AnsibleDumper, default_flow_style=False)

# Generated at 2022-06-23 05:34:47.056899
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper
    assert dumper is not None

# Generated at 2022-06-23 05:34:50.326156
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper(None, None, None, None)
    dumper_represent_undefined = dumper.represent_undefined(AnsibleUndefined())
    assert dumper_represent_undefined == False


# Generated at 2022-06-23 05:34:54.176374
# Unit test for function represent_undefined
def test_represent_undefined():
    dump_data = AnsibleDumper.represent_undefined(AnsibleDumper, AnsibleUndefined)
    assert dump_data is False
    dump_data = AnsibleDumper.represent_undefined(AnsibleDumper, "defined")
    assert dump_data is True


# Generated at 2022-06-23 05:35:01.480145
# Unit test for function represent_binary
def test_represent_binary():
    text_data = AnsibleUnsafeBytes(b'foo')
    text_data.encoding = 'utf-8'
    assert yaml.dump(text_data, Dumper=AnsibleDumper, default_flow_style=False) == u"!!binary |\n  Zm9v\n\n"

    text_data = AnsibleUnsafeBytes(b'foo')
    text_data.encoding = None
    assert yaml.dump(text_data, Dumper=AnsibleDumper, default_flow_style=False) == u"!!binary |\n  Zm9v\n\n"



# Generated at 2022-06-23 05:35:04.197166
# Unit test for function represent_undefined
def test_represent_undefined():

    yaml_data = u'{{ undefined_variable }}'
    dumper = AnsibleDumper
    result = dumper.represent_undefined(dumper, AnsibleUndefined)
    assert isinstance(result, bool)

# Generated at 2022-06-23 05:35:15.733231
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, 'Hello World') == yaml.representer.SafeRepresenter.represent_binary(dumper, 'Hello World')
    assert dumper.represent_binary(dumper, b'Hello World') == yaml.representer.SafeRepresenter.represent_binary(dumper, b'Hello World')
    assert dumper.represent_binary(dumper, 'Hello World'.encode('utf-8')) == yaml.representer.SafeRepresenter.represent_binary(dumper, 'Hello World')
    assert dumper.represent_binary(dumper, 'Hello'.encode('utf-8')) == yaml.representer.SafeRepresenter.represent_binary(dumper, 'Hello')

# Generated at 2022-06-23 05:35:19.034051
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    assert dumper.represent_undefined is represent_undefined
    obj = AnsibleUndefined("some value")
    assert dumper.represent_undefined(dumper, obj) is True


dumper = AnsibleDumper

# Generated at 2022-06-23 05:35:29.925336
# Unit test for function represent_hostvars
def test_represent_hostvars():
    """
    When representer is called on HostVars object, it should return
    hostvars object as dictionary.
    """
    from ansible.vars.hostvars import HostVars

    yaml.add_representer(HostVars, represent_hostvars)
    hosts = HostVars({"localhost": {"ansible_os_family": "Linux", "ansible_distribution": "Debian"}})
    _yaml = yaml.dump(hosts)
    expected_yaml = "localhost:\n  ansible_distribution: Debian\n  ansible_os_family: Linux\n"
    assert _yaml == expected_yaml

# Generated at 2022-06-23 05:35:31.133093
# Unit test for function represent_binary
def test_represent_binary():
    output = represent_binary(None, u'hello')
    assert output == 'hello'

# Generated at 2022-06-23 05:35:34.132071
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(AnsibleDumper, u'foobar') == yaml.representer.SafeRepresenter.represent_str(AnsibleDumper, 'foobar')


# Generated at 2022-06-23 05:35:42.213526
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib

    vault = VaultLib(password='password')
    result = vault.encrypt('PANDA')
    ciphertext = result.encode()
    encrypted_unicode = AnsibleVaultEncryptedUnicode(ciphertext, vault)
    dumper = AnsibleDumper(indent=4, width=1000, default_style='|')

    assert b'!vault |' in dumper.represent_data(encrypted_unicode)
    assert ciphertext.decode() in dumper.represent_data(encrypted_unicode).decode()

# Generated at 2022-06-23 05:35:43.640455
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert hasattr(AnsibleDumper, 'add_multi_representer')

# Generated at 2022-06-23 05:35:48.427856
# Unit test for function represent_hostvars
def test_represent_hostvars():
    h = HostVars()
    h.data = {"foo":"bar"}
    ansible_dumper = AnsibleDumper()
    # Representer function should return a string
    assert isinstance(represent_hostvars(ansible_dumper, h), text_type)

# Generated at 2022-06-23 05:35:53.338611
# Unit test for function represent_unicode
def test_represent_unicode():

    # Test unicode
    assert 'foo' == yaml.dump(u'foo', Dumper=AnsibleDumper).strip()

    # Test bytes
    assert 'foo' == yaml.dump(u'foo'.encode(), Dumper=AnsibleDumper).strip()

    # Test unsafe text
    assert 'foo' == yaml.dump(AnsibleUnsafeText(u'foo'), Dumper=AnsibleDumper).strip()

    # Test unsafe bytes
    assert 'foo' == yaml.dump(AnsibleUnsafeBytes(u'foo'.encode()), Dumper=AnsibleDumper).strip()

# Generated at 2022-06-23 05:36:01.943091
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager

    dumper = AnsibleDumper
    v = VariableManager()
    hv = HostVars(v)
    hv['foo'] = 'bar'
    hv['baz'] = 'qux'
    data = dumper.represent_data(hv)
    print(data)
    assert 'bar' == yaml.load(data, Loader=AnsibleLoader)['foo']
    assert 'qux' == yaml.load(data, Loader=AnsibleLoader)['baz']



# Generated at 2022-06-23 05:36:02.981074
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert(AnsibleDumper)



# Generated at 2022-06-23 05:36:07.861881
# Unit test for function represent_undefined
def test_represent_undefined():
    abc = AnsibleUndefined("abc")
    assert bool(abc) is False

    bool_true = bool(AnsibleUndefined("True"))
    bool_false = bool(AnsibleUndefined("False"))
    bool_0 = bool(AnsibleUndefined("0"))
    bool_1 = bool(AnsibleUndefined("1"))

    assert bool_true is False
    assert bool_false is False
    assert bool_0 is False
    assert bool_1 is False

# Generated at 2022-06-23 05:36:11.165752
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(u"unicode", Dumper=AnsibleDumper) == "unicode\n..."



# Generated at 2022-06-23 05:36:17.076267
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper(
        None,
        default_flow_style=False,
        indent=2,
        width=80,
    )
    assert dumper.default_flow_style is False
    assert dumper.indent == 2
    assert dumper.width == 80



# Generated at 2022-06-23 05:36:19.574282
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined) == True

# Generated at 2022-06-23 05:36:23.030648
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = AnsibleVaultEncryptedUnicode('test')
    yaml_data = yaml.dump(data, Dumper=AnsibleDumper)
    assert yaml_data == "!vault |\n  test\n"

# Generated at 2022-06-23 05:36:25.282009
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode('test') == u'test'



# Generated at 2022-06-23 05:36:29.257909
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    assert dumper.represent_unicode(dumper, u'\x16') == u'"\\u0016"'
    assert dumper.represent_unicode(dumper, b'\x16') == u'"\\u0016"'

# Generated at 2022-06-23 05:36:31.861771
# Unit test for function represent_binary
def test_represent_binary():
    b = b'foo'
    rep = represent_binary(None, b)
    assert rep == yaml.representer.SafeRepresenter.represent_binary(None, b)

# Generated at 2022-06-23 05:36:33.435686
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper.represent_undefined(None, AnsibleUndefined)



# Generated at 2022-06-23 05:36:44.315394
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    a = AnsibleDumper()
    assert a.stream is None
    assert a.default_flow_style is False
    assert a.indent is 2
    assert a.width == 60
    assert a.allow_unicode is True
    assert a.line_break == '\n'
    assert a.encoding == 'utf-8'
    assert a.explicit_start is None
    assert a.explicit_end is None
    assert a.version is (1, 2)
    assert a.tags is None
    assert a.use_version is None
    assert a.top_level_colon_align is False
    assert a.prefix_colon is None
    assert a.dumper is None
    assert a.resolver is None
    assert a.representer is None
    assert a.serializer is None

# Generated at 2022-06-23 05:36:55.014779
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.constructor import AnsibleConstructor

    # Setup
    vault_password = "42"
    vault = VaultLib(vault_password)
    original = AnsibleVaultEncryptedUnicode(vault.encrypt("test")).__repr__()
    d = yaml.dumper.Dumper(width=100000, default_flow_style=False)

# Generated at 2022-06-23 05:37:05.017222
# Unit test for function represent_binary
def test_represent_binary():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils._text import to_bytes

    utf_data = to_bytes(u'\u2713', encoding='utf-8')

    stream = StringIO()

    dumper = AnsibleDumper(stream=stream, default_style=None)
    dumper.represent_binary(utf_data)

    if PY3:
        assert stream.getvalue() == "|-\n  !binary |\n    4pyT\n"
    else:
        assert stream.getvalue() == "|-\n  !binary |\n    4pyT\n"

# Generated at 2022-06-23 05:37:06.774749
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    ad_obj = AnsibleDumper()
    assert type(ad_obj) == AnsibleDumper

# Generated at 2022-06-23 05:37:10.585454
# Unit test for function represent_unicode
def test_represent_unicode():
    test_dumper = AnsibleDumper()
    assert test_dumper.represent_unicode(AnsibleUnicode('From String')) == "From String"



# Generated at 2022-06-23 05:37:12.021489
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    ansible_dumper = AnsibleDumper
    assert ansible_dumper

# Generated at 2022-06-23 05:37:18.036800
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, u'unicode string') == 'unicode string'
    assert represent_unicode(None, 'unicode string') == 'unicode string'
    assert represent_unicode(None, {'key': 'unicode string'}) == 'key: unicode string'
    assert represent_unicode(None, ['unicode string']) == '- unicode string'


# Generated at 2022-06-23 05:37:27.885046
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = yaml.Dumper
    representer = AnsibleDumper
    ut = AnsibleUndefined

    try:
        # This is the only way to currently test the representation.
        # We need to add a private method to AnsibleUndefined that
        # raises an exception.  See the yaml code in represent_undefined
        # above.
        ut._fail_with_undefined_error = True
        represent_undefined(dumper, ut())
    except Exception:
        # We want this to fail!
        pass
    finally:
        # Remove the private method to prevent issues for other tests
        del ut._fail_with_undefined_error

# Generated at 2022-06-23 05:37:29.965764
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode(u'"hello"')) == u'"\\"hello\\""\n'

# Generated at 2022-06-23 05:37:33.044272
# Unit test for function represent_binary
def test_represent_binary():
    d = AnsibleDumper()
    result = d.represent_binary(b'\x01\x02\x027')
    assert result == u'!!binary |\n  AQAyMzs=\n'

# Generated at 2022-06-23 05:37:36.372065
# Unit test for function represent_undefined
def test_represent_undefined():
    obj = AnsibleUndefined('FAIL')
    dumper = AnsibleDumper
    # This should not throw
    dumper.represent_undefined(obj)

# Generated at 2022-06-23 05:37:46.812427
# Unit test for function represent_binary
def test_represent_binary():
    a = AnsibleDumper()
    # Test to make sure newlines are escaped
    b = '\n\r\ttest'
    val = a.represent_binary(b)
    assert val == "'\\n\\r\\ttest'"
    # Test to make sure quotes are escaped
    b = '"test"'
    val = a.represent_binary(b)
    assert val == "'''test'''"
    # Test to make sure single quotes are not escaped
    b = "'test'"
    val = a.represent_binary(b)
    assert val == "'test'"
    # Test to make sure '' does not raise an error
    b = ''
    val = a.represent_binary(b)
    assert val == "''"
    # Test to make sure non-text types raise an error
    b = 1

# Generated at 2022-06-23 05:37:55.189869
# Unit test for function represent_hostvars
def test_represent_hostvars():
    test_data = dict(
        a=1,
        b=2,
        c=3
    )

    # "safe" is the default, but included here for illustration purposes
    dumped_data = yaml.dump(HostVars(test_data), Dumper=AnsibleDumper, default_flow_style=False)
    assert dumped_data == """\
a: 1
b: 2
c: 3
"""

    dumped_data = yaml.dump(HostVarsVars(dict(foo=HostVars(test_data))), Dumper=AnsibleDumper, default_flow_style=False)
    assert dumped_data == """\
foo:
  a: 1
  b: 2
  c: 3
"""


# Generated at 2022-06-23 05:37:59.826421
# Unit test for function represent_hostvars
def test_represent_hostvars():
    output = yaml.dump(
        {'a': 'b', 'c': 'd'},
        Dumper=AnsibleDumper,
        default_flow_style=False
    )
    assert output == 'a: b\nc: d\n'

# Generated at 2022-06-23 05:38:02.115712
# Unit test for function represent_unicode
def test_represent_unicode():
    obj = AnsibleUnicode(u'a')
    assert yaml.dump(obj) == 'a\n...\n'



# Generated at 2022-06-23 05:38:05.221697
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    d = yaml.Dumper()
    flow = AnsibleVaultEncryptedUnicode('Hello')
    represent_vault_encrypted_unicode(d, flow)
    assert d.output == '!vault |\n  Hello\n'

# Generated at 2022-06-23 05:38:06.441108
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    x = AnsibleDumper()
    assert x is not None

# Generated at 2022-06-23 05:38:09.167338
# Unit test for function represent_binary
def test_represent_binary():
    rep = AnsibleDumper.represent_binary
    assert rep(None, b'\x58') == "'X'"

# Generated at 2022-06-23 05:38:18.752915
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    import sys
    import io
    import re

    # what we expect in the output
    expected_output = re.compile(r'''
        ^---\n
        (?:.*\n)*
        (?:
            (?:    |\t)-\b.*\n
        )+
        (?:.*\n)*
        $
    ''', re.DOTALL | re.VERBOSE)

    # grab some arbitrary object and use it for testing
    from ansible.module_utils.six import iteritems
    from ansible.parsing.yaml.loader import AnsibleLoader

    test_obj = AnsibleLoader(None, 'dummy').get_single_data()

    # capture the output producing by AnsibleDumper
    old_stdout = sys.stdout
    old_stderr = sys.stderr

# Generated at 2022-06-23 05:38:24.614964
# Unit test for function represent_unicode
def test_represent_unicode():

    plain_text = 'hello'
    ansible_unicode = AnsibleUnicode(plain_text)

    yaml_text = yaml.dump(
        ansible_unicode,
        Dumper=AnsibleDumper,
        default_flow_style=False,
        encoding='utf-8',
        allow_unicode=True,
    )

    assert yaml_text == "{0}: \"{1}\"\n".format(u'test_ansible_unicode', plain_text)



# Generated at 2022-06-23 05:38:28.508024
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    secret = u'this is a secret'
    encrypted_secret = AnsibleVaultEncryptedUnicode(secret)
    yaml.dump(encrypted_secret, Dumper=AnsibleDumper)

# Generated at 2022-06-23 05:38:32.562298
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    p = AnsibleDumper()
    assert hasattr(p, 'add_representer')
    assert hasattr(p, 'represent_dict')
    assert hasattr(p, 'represent_str')
    assert hasattr(p, 'represent_list')
    assert hasattr(p, 'represent_scalar')

# Generated at 2022-06-23 05:38:42.153203
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper()

    assert dumper.yaml_representers == {
        AnsibleUnicode: represent_unicode,
        AnsibleUnsafeText: represent_unicode,
        AnsibleUnsafeBytes: represent_binary,
        HostVars: represent_hostvars,
        HostVarsVars: represent_hostvars,
        VarsWithSources: represent_hostvars,
        AnsibleSequence: yaml.representer.SafeRepresenter.represent_list,
        AnsibleMapping: yaml.representer.SafeRepresenter.represent_dict,
        AnsibleVaultEncryptedUnicode: represent_vault_encrypted_unicode,
        AnsibleUndefined: represent_undefined,
    }

# Generated at 2022-06-23 05:38:48.935983
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    hostvars = HostVars(VarsWithSources({'key': 'value'}, [{'key': 'value'}, {'key': 'value'}]))
    result = hostvars.to_yaml(dumper=dumper)
    result_obj = yaml.safe_load(result)
    assert result_obj == {'key': 'value'}

# Generated at 2022-06-23 05:38:57.893521
# Unit test for function represent_binary
def test_represent_binary():

    dumper = yaml.dumper.SafeDumper
    dumper.add_representer(binary_type, represent_binary)
    data = u'\u00e4'.encode('utf-8')
    result = dumper.represent_binary(dumper, data)

    # result will be a pair (tag, output).
    # we ignore the tag
    output = result[1]

    # the output should be a binary string.
    assert isinstance(output, binary_type)

    # the output should be a base64 encoded string
    assert output.startswith(b'!!binary')

    # the output should be a valid base64 string
    assert output[9:].endswith(b'AQ==\n')

# Generated at 2022-06-23 05:38:59.760985
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper()
    assert dumper.default_flow_style is False
    assert dumper._unsafe is False


# Generated at 2022-06-23 05:39:10.520458
# Unit test for function represent_binary
def test_represent_binary():
    # Test a bytes string that is in the ASCII range
    ascii_range_bytes = b'Hello world!'
    result = yaml.Dumper.represent_binary(None, ascii_range_bytes)
    assert result == "!!binary |-\n  SGVsbG8gd29ybGQh"

    # Test a bytes string that contains non-ASCII unicode
    non_ascii_bytes = ascii_range_bytes + b'\xc3\x81'
    result = yaml.Dumper.represent_binary(None, non_ascii_bytes)
    assert result == "!!binary |\n  SGVsbG8gd29ybGQhw4Q="

    # Make sure that a str is not modified to bytes
    str_input = 'Hello world!'
    result = y

# Generated at 2022-06-23 05:39:13.853997
# Unit test for function represent_undefined
def test_represent_undefined():
    # Test if representing undefined raises exception
    # This is the main check in represent_undefined
    input_data = AnsibleUndefined("ERROR")
    try:
        yaml.dump(input_data, Dumper=AnsibleDumper)
    except AnsibleUndefined:
        raise Exception('represent_undefined does not raise exception')

# Generated at 2022-06-23 05:39:24.017033
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = HostVars(host_vars_filepath='')
    hostvars['test_key1'] = 'test_value1'
    hostvars['test_key2'] = 'test_value2'

    # Python 3: Test for bytes
    result = yaml.dump(hostvars, Dumper=AnsibleDumper)
    assert result == (u"!!python/object/apply:ansible.parsing.yaml.objects.HostVars\n"
                      "host_vars_filepath: None\n"
                      "vars:\n"
                      "  test_key1: test_value1\n"
                      "  test_key2: test_value2\n")

    # Python 2: Test for string

# Generated at 2022-06-23 05:39:30.976507
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    """Function represent_vault_encrypted_unicode - Dump vault encrypted scalar without newline chars."""
    from ansible.parsing.vault import VaultLib

    vault = VaultLib('test')
    text = vault.encrypt(u'secret')
    assert isinstance(text, AnsibleVaultEncryptedUnicode)
    assert '\n' not in AnsibleDumper().represent_vault_encrypted_unicode(text)



# Generated at 2022-06-23 05:39:42.237225
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars, HostVarsVars
    from ansible.parsing.yaml.objects import AnsibleMapping

    data = {'foo': 1, 'bar': 'some string'}
    hv = HostVars()
    hv.update(data)

    y = AnsibleMapping()
    y.update(data)

    assert yaml.dump(data) == yaml.dump(y)
    assert yaml.dump(hv) == yaml.dump(y)

    data = {'foo': 1, 'bar': 'some string', 'baz': [2, 3, 4]}
    hv = HostVars()
    hv.update(data)

    y = AnsibleMapping()
    y.update(data)


# Generated at 2022-06-23 05:39:50.343311
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    test_string = "This is a test string to see if the vault string is represented properly"
    av_obj = AnsibleVaultEncryptedUnicode(test_string)
    result = represent_vault_encrypted_unicode(AnsibleDumper, av_obj)

# Generated at 2022-06-23 05:40:01.007384
# Unit test for function represent_hostvars
def test_represent_hostvars():
    '''This function is used to test the behavior of
    the represent_hostvars function.

    The test cases are simple but explicit, it tests
    that the hostvars and vars_with_sources are dumped exactly the same
    and that they dumped in the same way as a regular dictionary.'''


# Generated at 2022-06-23 05:40:03.172008
# Unit test for function represent_undefined
def test_represent_undefined():
    results = yaml.dump({'undefined': AnsibleUndefined})
    assert results == '{undefined: false}\n'

# Generated at 2022-06-23 05:40:11.206583
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    ansible_object = AnsibleVaultEncryptedUnicode('dGVzdA==')
    ansible_object._ciphertext = 'dGVzdA=='
    ansible_dumper_object = AnsibleDumper()
    assert ansible_dumper_object.represent_vault_encrypted_unicode(ansible_object) == "!vault |\n          dGVzdA=="



# Generated at 2022-06-23 05:40:11.862405
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper

# Generated at 2022-06-23 05:40:20.823366
# Unit test for function represent_unicode
def test_represent_unicode():
    representer = AnsibleDumper()
    ansible_unicode_value = AnsibleUnicode('unicode')
    yaml.representer.SafeRepresenter.represent_str = lambda x, y: y
    assert representer.represent_unicode(ansible_unicode_value) == 'unicode'
    ansible_unsafe_text = AnsibleUnsafeText('unsafe text')
    assert representer.represent_unicode(ansible_unsafe_text) == 'unsafe text'
    ansible_unsafe_bytes = AnsibleUnsafeBytes(b'unsafe bytes')
    assert representer.represent_unicode(ansible_unsafe_bytes) == b'unsafe bytes'

# Generated at 2022-06-23 05:40:22.954231
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    ansible_dumper = AnsibleDumper()

    assert ansible_dumper.encoding == 'utf-8'

# Generated at 2022-06-23 05:40:34.024990
# Unit test for function represent_unicode
def test_represent_unicode():
    d = AnsibleDumper(indent=2, default_flow_style=False)
    data = {'normal_str': 'I am a normal string. Nothing special.',
            'ansible_str': AnsibleUnicode('I am an AnsibleUnicode.'),
            }
    dump_data = yaml.dump(data, Dumper=d)
    assert dump_data == text_type("""\
normal_str: I am a normal string. Nothing special.
ansible_str: 'I am an AnsibleUnicode.'
""")
    # Now test the same thing with unicode
    data = {'normal_str': u'I am a normal string. Nothing special.',
            'ansible_str': AnsibleUnicode(u'I am an AnsibleUnicode.'),
            }
    dump_

# Generated at 2022-06-23 05:40:36.515374
# Unit test for function represent_hostvars
def test_represent_hostvars():
    h = HostVars()
    h.update({'foo': 'bar'})
    assert represent_hostvars(None, h) == 'bar'

# Generated at 2022-06-23 05:40:42.357789
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    data = 'test_encrypted'
    encrypted_data = vault.encrypt(data.encode('utf-8'))
    encrypted_data = AnsibleVaultEncryptedUnicode(encrypted_data, vault=vault)
    output = yaml.dump(encrypted_data, Dumper=AnsibleDumper)
    assert '!vault |\n' in output



# Generated at 2022-06-23 05:40:49.063475
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper
    data = HostVars({
        "a": "b",
        "c": "d"
    })
    assert dumper.represent_hostvars(dumper, data) == dumper.represent_dict(dumper, dict(data))



# Generated at 2022-06-23 05:40:52.903131
# Unit test for function represent_unicode
def test_represent_unicode():
    from io import StringIO
    stream = StringIO()
    yaml.dump('foo', stream, Dumper=AnsibleDumper, default_flow_style=False)
    assert 'foo' in stream.getvalue()



# Generated at 2022-06-23 05:40:55.932859
# Unit test for function represent_hostvars
def test_represent_hostvars():
    foo = AnsibleVars()
    foo.update(1, "hello world")
    assert foo == {'foo': 'hello world'}



# Generated at 2022-06-23 05:40:58.876559
# Unit test for function represent_hostvars
def test_represent_hostvars():
    obj = HostVars(myvar=1)
    assert yaml.dump(obj, Dumper=AnsibleDumper) == "myvar: 1\n"



# Generated at 2022-06-23 05:41:10.281955
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dump = AnsibleDumper(None, None, None)
    assert dump is not None
    assert '!python/unicode' in AnsibleDumper.yaml_representers
    assert '!unsafe/text' in AnsibleDumper.yaml_representers
    assert '!unsafe/bytes' in AnsibleDumper.yaml_representers
    assert '!hostvars' in AnsibleDumper.yaml_representers
    assert '!hostvarsvars' in AnsibleDumper.yaml_representers
    assert '!vars_with_sources' in AnsibleDumper.yaml_representers
    assert '!python/tuple' in AnsibleDumper.yaml_representers
    assert '!python/dict' in AnsibleDumper.yaml_representers
    assert '!vault'

# Generated at 2022-06-23 05:41:13.258224
# Unit test for function represent_binary
def test_represent_binary():

    sample = AnsibleDumper.represent_binary(b'ex\x01ple')
    assert sample == '!!binary "ZXgweHBsZQ==\n"\n'

# Generated at 2022-06-23 05:41:14.678973
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper

    assert AnsibleUnicode in dumper._representers

# Generated at 2022-06-23 05:41:19.226029
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleUndefined('') == AnsibleUndefined('')
    assert AnsibleUndefined('') != AnsibleUndefined('foo')
    assert AnsibleUndefined('') != 'foo'
    assert AnsibleUndefined('') is not None
    assert AnsibleUndefined('') and not AnsibleUndefined('') is False

# Generated at 2022-06-23 05:41:26.973168
# Unit test for function represent_unicode
def test_represent_unicode():
    # Test unicode string
    text = u'基本Python'
    assert(yaml.dump(text, Dumper=AnsibleDumper) == u"'基本Python'\n")

    # Test non-ASCII char string
    text = b'\xe5\x9f\xba\xe6\x9c\xacP\x79\x74\x68\x6f\x6e'
    assert(yaml.dump(text, Dumper=AnsibleDumper) == u"\n    !!binary |-\n      '''\n      5q2l5paHPXRvbg==\n      '''\n")


# Generated at 2022-06-23 05:41:31.742883
# Unit test for function represent_undefined
def test_represent_undefined():
    # Here bool will ensure _fail_with_undefined_error happens
    # if the value is Undefined.
    # This happens because Jinja sets __bool__ on StrictUndefined
    from ansible.template import StrictUndefined
    assert not StrictUndefined()

# Generated at 2022-06-23 05:41:34.240887
# Unit test for function represent_undefined
def test_represent_undefined():
    # It should not raise Exception, if the value is AnsibleUndefined
    yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper)

# Generated at 2022-06-23 05:41:37.841735
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    dumper.represent_undefined(AnsibleUndefined(
                obj='{{ foo }}', django_key='foo',
                boolean=False, undefined_type='variable'))



# Generated at 2022-06-23 05:41:48.376371
# Unit test for function represent_unicode
def test_represent_unicode():
    # Test for Unicode strings
    string = u"This is an unicode string: \u20ac"
    dumped_string = yaml.dump(string, Dumper=AnsibleDumper)
    assert dumped_string == u"This is an unicode string: \u20ac\n"

    # Test for string which starts with u
    string = u"u\u20ac"
    dumped_string = yaml.dump(string, Dumper=AnsibleDumper)
    assert dumped_string == u"!ansible_unsafe 'u\\u20ac'\n"

    # Test for string which starts with U
    string = u"U\u20ac"
    dumped_string = yaml.dump(string, Dumper=AnsibleDumper)

# Generated at 2022-06-23 05:41:49.089821
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    AnsibleDumper()

# Generated at 2022-06-23 05:41:53.021540
# Unit test for function represent_binary
def test_represent_binary():

    # Test bytes
    # This import must be here to avoid circular imports
    from ansible.parsing.yaml.dumper import AnsibleDumper
    yaml_str = yaml.dump(dict(a=b'bytes'), Dumper=AnsibleDumper)
    assert yaml_str == '{a: !!binary |\n  Ynl0ZXM=\n}'

# Generated at 2022-06-23 05:41:58.296396
# Unit test for function represent_unicode
def test_represent_unicode():
    # Test for non-ascii unicode string
    data = text_type("héhé")
    output = yaml.dump(data, Dumper=AnsibleDumper, encoding=None, allow_unicode=True)
    assert output == "héhé\n...\n"

