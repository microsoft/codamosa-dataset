

# Generated at 2022-06-23 05:32:01.442987
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256'
                                        '\n3934663538363366653065353639396231333963666332343138373665626534393262616433\n'
                                        '3830356531343437613365633064623331636562316466653737626265373230623037353761\n'
                                        '39346536\n')

# Generated at 2022-06-23 05:32:07.534283
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # TODO: Put this into Unit Test
    # test_veu is a AnsibleVaultEncryptedUnicode
    # test_veu_dumped is a string created by represent_vault_encrypted_unicode
    test_veu = AnsibleVaultEncryptedUnicode(binary_type('test'.encode()))
    test_veu_dumped = yaml.dump(test_veu, Dumper=AnsibleDumper)
    assert test_veu_dumped == '!vault |\n          ' + test_veu._ciphertext.decode() + '\n'

# Generated at 2022-06-23 05:32:12.383606
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = HostVars(vars=dict(sample='value'))
    yaml_dump = yaml.dump(hostvars, Dumper=AnsibleDumper)
    expected_yaml = '''{sample: value}
'''
    assert yaml_dump == expected_yaml



# Generated at 2022-06-23 05:32:20.514010
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.inventory import Inventory
    from ansible.module_utils.six.moves import StringIO
    loader = DataLoader()
    s = u'{"key": "value"}'
    h = HostVars(loader=loader, variables=VariableManager(loader=loader)._vars_cache)
    h['hostname'] = s
    stream = StringIO()
    yaml.dump(h, stream=stream, Dumper=AnsibleDumper, default_flow_style=False)
    assert stream.getvalue() == "key: value\n"

# Generated at 2022-06-23 05:32:29.348046
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    ciphertext = vault.encrypt('foo')


# Generated at 2022-06-23 05:32:34.777948
# Unit test for function represent_binary
def test_represent_binary():
    binary_string = text_type(b'\xc3\xbc', 'utf-8')
    assert binary_string.encode('utf-8') == b'\xc3\xbc'
    assert represent_binary(None, binary_string) == b'!binary |\n  w7A='

# Generated at 2022-06-23 05:32:39.952536
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper
    h = HostVars(vars=VarsWithSources({'test_var': 'test_val'}, sources=['test_source']))
    dumper.add_representer(
        HostVars,
        represent_hostvars,
    )
    data = dumper.represent_data(h)
    assert data == '{test_var: test_val}\n'

# Generated at 2022-06-23 05:32:42.591818
# Unit test for function represent_binary
def test_represent_binary():
    assert AnsibleDumper.represent_binary(b'\xe2\x80\x8b') == '>>-\n    \\xe2\\x80\\x8b\n'


# Generated at 2022-06-23 05:32:47.725879
# Unit test for function represent_undefined
def test_represent_undefined():
    d = AnsibleDumper()

    # Check that AnsibleUndefined is not dumped by default
    result = d.represent_data(AnsibleUndefined)
    assert result is None

    # Check that AnsibleUndefined can be dumped if enabled
    result = d.represent_data(AnsibleUndefined, serialize_undefined=True)
    assert result

# Generated at 2022-06-23 05:32:50.846091
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    # Ensure object is of type AnsibleDumper
    assert isinstance(AnsibleDumper, object)
    # Ensure object is of type SafeDumper
    assert issubclass(AnsibleDumper, SafeDumper)

# Generated at 2022-06-23 05:32:51.818613
# Unit test for function represent_hostvars
def test_represent_hostvars():
    represent_hostvars(None, None)

# Generated at 2022-06-23 05:32:56.593217
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import Templar

    tmplar = Templar()
    data = AnsibleUndefined
    ret = represent_undefined(None, data)
    assert ret is False

    tmplar._fail_on_undefined = False
    ret = represent_undefined(None, data)
    assert ret is data

# Generated at 2022-06-23 05:33:01.320588
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = HostVars({"a": "b"})
    assert yaml.dump(
        hostvars,
        Dumper=AnsibleDumper,
        width=1000,
    ) == "a: b\n"



# Generated at 2022-06-23 05:33:12.054767
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    encrypted_unicode = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256;test\n6331393661383436'
                                                     '3735333438653737346533316265663563383235663662\n35643836323333396231393734306633306234626266\n'
                                                     '30393933373264353461633339396565343664636438\n39656138616234323661373939663564326263656531\n'
                                                     '323064653933\n')

# Generated at 2022-06-23 05:33:14.192600
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode(u'hello')) == u'test: hello\n'



# Generated at 2022-06-23 05:33:20.290413
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper(default_flow_style=False)

    # Test that the binary data is not represented in unicode
    assert dumper.represent_scalar(u'tag:yaml.org,2002:str', binary_type(b"\xFF\xFE\xFD\xFC\xFB\xFA"), style='|') != dumper.represent_binary(binary_type(b"\xFF\xFE\xFD\xFC\xFB\xFA"))



# Generated at 2022-06-23 05:33:24.821132
# Unit test for function represent_unicode
def test_represent_unicode():
    data = {
        'unicode': AnsibleUnicode(u'\u2600')
    }
    yaml.dump(data, Dumper=AnsibleDumper).strip() == u'unicode: "\u2600"'

# Generated at 2022-06-23 05:33:28.028901
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper

    assert dumper(AnsibleUndefined()) == dumper(False)


# unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-23 05:33:38.097212
# Unit test for function represent_unicode
def test_represent_unicode():
    s = yaml.load(u'foo: !!python/unicode "unicode string"')
    assert s == {'foo': 'unicode string'}

    # We test with a string with non-ascii chars, to ensure that
    # the !unicoce constructor actually gets used.
    # See: https://github.com/ansible/ansible/issues/12763
    # If non-ascii chars are there, the representer function gets called
    s = yaml.load(u'foo: !!python/unicode "unicode string with non-ascii: \xa3"')
    assert s == {'foo': u'unicode string with non-ascii: \xa3'}

    s = yaml.load('foo: !!python/unicode "unicode string"')

# Generated at 2022-06-23 05:33:39.525250
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper is not None
    assert AnsibleDumper().__class__.__name__ == 'AnsibleDumper'

# Generated at 2022-06-23 05:33:43.483176
# Unit test for function represent_unicode
def test_represent_unicode():

    # We need to instantiate the class ourselves.
    representer = AnsibleDumper()

    # The actual unit test
    assert representer.represent_unicode(u'unicode') == representer.represent_unicode(u'unicode')

# Generated at 2022-06-23 05:33:44.251214
# Unit test for function represent_hostvars
def test_represent_hostvars():
    pass

# Generated at 2022-06-23 05:33:46.243734
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper(), yaml.SafeDumper)


# Note: testing assumes python2

# Generated at 2022-06-23 05:33:49.146435
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = HostVars(vars=dict(foo='bar', baz='bam'))
    dumper = AnsibleDumper()
    dumper.represent_hostvars(hostvars)

# Generated at 2022-06-23 05:33:53.142068
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    assert AnsibleDumper.yaml_representers[AnsibleBaseYAMLObject] == represent_unicode

# Generated at 2022-06-23 05:34:08.064829
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    representer = AnsibleDumper()
    representer.add_representer(
        AnsibleVaultEncryptedUnicode,
        represent_vault_encrypted_unicode
    )

# Generated at 2022-06-23 05:34:11.318660
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert hasattr(AnsibleDumper, 'add_representer')

# Generated at 2022-06-23 05:34:22.353994
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    '''Ensure AnsibleVaultEncryptedUnicode data is represented properly'''
    dump = AnsibleDumper().represent_data(
        AnsibleVaultEncryptedUnicode(
            AnsibleUnsafeText('bar'),
        )
    )
    assert dump == '!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          633635373066366331666261363466373336303938303765613432303634656637393763386365\n          623762626330393336343761360a32396439333064326135656434376233363237623562653664\n          6565376139653338316630396529\n'  # noqa



# Generated at 2022-06-23 05:34:28.397665
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    ciphertext = b'$ANSIBLE_VAULT;1.2;AES256;testhost\n32343234323432=\n'
    data = AnsibleVaultEncryptedUnicode(ciphertext)
    assert AnsibleDumper.represent_vault_encrypted_unicode(AnsibleDumper, data) == u'!vault |\n  ' + ciphertext.decode()

# Generated at 2022-06-23 05:34:37.611001
# Unit test for function represent_binary
def test_represent_binary():

    class TestBinData:
        '''
        BinData
        '''
        def __init__(self, value):
            self.value = value

        def __bytes__(self):
            return self.value

    value = TestBinData(b'123')
    dumper = AnsibleDumper(indent=4, width=80, sort_keys=True, allow_unicode=True)
    dumper.open()
    assert dumper.represent_binary(value) == "!!binary |-\n    MTIz\n"

    value = TestBinData(b'1234567890abcdef')
    dumper = AnsibleDumper(indent=4, width=80, sort_keys=True, allow_unicode=True)
    dumper.open()

# Generated at 2022-06-23 05:34:42.111985
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()

    try:
        assert dumper.represent_data(AnsibleUndefined())
    except yaml.YAMLError:
        assert False, 'Unexpected YAMLError with function represent_undefined'

# Generated at 2022-06-23 05:34:44.877149
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    data = AnsibleUndefined('unit test for function represent_undefined')
    assert dumper.represent_undefined(dumper, data) == bool(data)

# Generated at 2022-06-23 05:34:47.701962
# Unit test for function represent_binary
def test_represent_binary():
    rep = AnsibleDumper.represent_binary
    data = b'binary_data'
    expected = yaml.representer.SafeRepresenter.represent_binary(None, data)
    assert rep(None, data) == expected

# Generated at 2022-06-23 05:34:52.336812
# Unit test for function represent_hostvars
def test_represent_hostvars():

    def check(data, expected):
        dumper = AnsibleDumper()
        actual = yaml.dump(data, Dumper=dumper)
        assert actual == expected

    check({'test': 'value'}, '{test: value}\n')
    check(HostVars({'test': 'value'}), '{test: value}\n')

# Generated at 2022-06-23 05:34:54.456697
# Unit test for function represent_undefined
def test_represent_undefined():
    data = AnsibleUndefined('hello')
    representer = AnsibleDumper()
    assert not representer.represent_undefined(data)



# Generated at 2022-06-23 05:34:59.065690
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    instance = AnsibleVaultEncryptedUnicode('this is a secret')
    data = instance._ciphertext.decode()
    assert isinstance(data, text_type)
    assert represent_vault_encrypted_unicode(AnsibleDumper, instance) == u'!vault |\n  {}'.format(data)

# Generated at 2022-06-23 05:35:03.033561
# Unit test for function represent_binary
def test_represent_binary():
    # Note: this is NOT a real test, just a way to quickly check
    # the output of the function while debugging
    import sys
    dumper = AnsibleDumper()
    result = dumper.represent_binary(b'\xe2\x82\xa1')
    sys.stdout.write(result)



# Generated at 2022-06-23 05:35:10.350199
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Test with simple string
    value = u'test'

# Generated at 2022-06-23 05:35:13.286908
# Unit test for function represent_undefined
def test_represent_undefined():

    test_dict = {'test': AnsibleUndefined}

    assert yaml.dump(test_dict, Dumper=SafeDumper, default_flow_style=False) == 'test: null\n'

# Generated at 2022-06-23 05:35:14.828054
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    yaml.dump(AnsibleVaultEncryptedUnicode('test value'), Dumper=AnsibleDumper, default_flow_style=False)

# Generated at 2022-06-23 05:35:20.176502
# Unit test for function represent_unicode
def test_represent_unicode():
    class TestAnsibleUnicode(AnsibleUnicode):
        pass
    assert represent_unicode(AnsibleDumper, TestAnsibleUnicode('tardis')) == 'tardis'
    assert represent_unicode(AnsibleDumper, TestAnsibleUnicode('tardis: hello')) == 'tardis: hello'


# Generated at 2022-06-23 05:35:27.446649
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES')
    dumper = AnsibleDumper()
    result = dumper.represent_vault_encrypted_unicode(data)
    assert isinstance(result, type(u'unicode'))
    assert result == '!vault |\n  $ANSIBLE_VAULT;1.1;AES'

# Generated at 2022-06-23 05:35:32.006827
# Unit test for function represent_undefined
def test_represent_undefined():
    '''
    Create an AnsibleUndefined object, serialize it and verify the result
    '''
    u = AnsibleUndefined(is_missing=True)
    d = AnsibleDumper()
    result = d.represent_undefined(u)

    assert result is False

# Generated at 2022-06-23 05:35:33.844813
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    ansible_dumper = AnsibleDumper()
    assert isinstance(ansible_dumper, AnsibleDumper)

# Generated at 2022-06-23 05:35:41.601743
# Unit test for function represent_unicode
def test_represent_unicode():
    class TestAnsibleDumper(AnsibleDumper):
        def represent_unicode(self, data):
            return self.represent_scalar('tag:yaml.org,2002:str', data, style='|')

    # data is unicode
    s = u"язык"
    data = AnsibleUnicode(s)
    result = TestAnsibleDumper().represent_unicode(data)
    assert result == u"!<tag:yaml.org,2002:str> |\n  {0}".format(s)



# Generated at 2022-06-23 05:35:45.312615
# Unit test for function represent_hostvars
def test_represent_hostvars():
    m_dict = dict(name='test')
    m_hostvars = HostVars(m_dict)
    yaml_dump = yaml.safe_dump(m_hostvars)
    assert yaml_dump == "name: test\n"



# Generated at 2022-06-23 05:35:48.875809
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    ansible_dumper = AnsibleDumper()
    assert ansible_dumper.default_flow_style is False, "Cannot determine default flow style"



# Generated at 2022-06-23 05:35:52.058583
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    dumper.add_representer(
        binary_type,
        represent_binary,
    )

    data = u"12345"
    assert yaml.representer.SafeRepresenter.represent_binary(dumper, binary_type(data)) == u"!binary |\n  MTIzNDU=\n"

# Generated at 2022-06-23 05:35:59.748144
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    dumper = AnsibleDumper
    obj_list = [AnsibleUnicode, AnsibleUnsafeText, AnsibleUnsafeBytes, HostVars,
                HostVarsVars, AnsibleSequence, AnsibleMapping,
                AnsibleVaultEncryptedUnicode, AnsibleUndefined]

    for obj in obj_list:
        assert obj in dumper.yaml_representers


# Generated at 2022-06-23 05:36:05.443105
# Unit test for function represent_hostvars
def test_represent_hostvars():
    render_data = None
    render_data = HostVars({"foo": "bar"})
    render_data = VarsWithSources({"foo": "bar"})
    render_data = HostVarsVars({"foo": "bar"})
    if render_data:
        result = AnsibleDumper().represent_data(render_data)
        assert result == u'{foo: bar}\n'


# Generated at 2022-06-23 05:36:08.617196
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    undefined = AnsibleUndefined('Test')

    #assert represent_undefined(dumper, undefined) == 'undef'
    assert bool(represent_undefined(dumper, undefined))

# Generated at 2022-06-23 05:36:11.105930
# Unit test for function represent_binary
def test_represent_binary():
    assert AnsibleDumper.represent_binary(['value']).startswith('!!binary ')



# Generated at 2022-06-23 05:36:20.864181
# Unit test for function represent_unicode
def test_represent_unicode():
    # test string with non-ASCII characters
    data = u'\x95ó\x90\x1f\x95ó\x90\x1f\u0421\u0456\u0432\u0435\u0442'
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(data) == dumper.represent_str(data)

    # test string with non-byte characters
    data = u'\u0421\u0456\u0432\u0435\u0442'
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(data) == dumper.represent_str(data)



# Generated at 2022-06-23 05:36:30.798452
# Unit test for function represent_undefined
def test_represent_undefined():
    import pytest
    from jinja2.runtime import StrictUndefined
    from ansible.template import AnsibleUndefined

    strict_undefined = StrictUndefined()

    # Configure AnsibleUndefined to function identically to StrictUndefined (default)
    AnsibleUndefined.error_on_undefined = True
    AnsibleUndefined.error_on_forced_unicode = False
    AnsibleUndefined.error_on_non_ascii_bytes = False

    assert strict_undefined == AnsibleUndefined()

    # Expected _fail_with_undefined_error to be raised
    with pytest.raises(yaml.representer.RepresenterError):
        AnsibleDumper.represent_undefined(None, AnsibleUndefined())

# Generated at 2022-06-23 05:36:33.584742
# Unit test for function represent_undefined
def test_represent_undefined():
    with open('test_represent_undefined.yml', 'w') as f:
        # Here is the test.
        f.write(yaml.dump(dict(undef=AnsibleUndefined), Dumper=AnsibleDumper))



# Generated at 2022-06-23 05:36:38.298031
# Unit test for function represent_binary
def test_represent_binary():
    assert AnsibleDumper.represent_binary(bytearray([1, 2, 3])) == \
        u'!!binary "\\x01\\x02\\x03"'
    assert AnsibleDumper.represent_binary(bytearray()) == u'!!binary ""'



# Generated at 2022-06-23 05:36:39.344960
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper, type)

# Generated at 2022-06-23 05:36:46.396848
# Unit test for function represent_undefined
def test_represent_undefined():
    # Because bool(AnsibleUndefined) is False,
    # the brancing for !str will fail and we will
    # end up with the branching for !bool
    # This is because Jinja sets __bool__ on StrictUndefined
    # and will fail with _fail_with_undefined_error
    # This fails if AnsibleDumper.represent_undefined does not
    # use bool() around AnsibleUndefined
    assert yaml.dump({'undefined': AnsibleUndefined,}, Dumper=AnsibleDumper) == 'undefined: null\n'

# Generated at 2022-06-23 05:36:47.033444
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper

# Generated at 2022-06-23 05:36:50.997374
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = {'a': '1', 'b': '2'}
    result = yaml.dump(data, Dumper=AnsibleDumper)
    assert result == '{a: 1, b: 2}\n...\n'

# Generated at 2022-06-23 05:36:55.407454
# Unit test for function represent_unicode
def test_represent_unicode():
    data = AnsibleUnicode(u'abcd')
    assert yaml.dump(data, Dumper=AnsibleDumper) == u'abcd\n...\n'
    assert yaml.dump([data], Dumper=AnsibleDumper) == u'- abcd\n...\n'



# Generated at 2022-06-23 05:37:06.009226
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    d = AnsibleDumper()
    text = 'This is some secret text'
    encrypted = AnsibleVaultEncryptedUnicode(text)
    # Represent
    result = d.represent_data(encrypted)

# Generated at 2022-06-23 05:37:06.756467
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    AnsibleDumper()



# Generated at 2022-06-23 05:37:12.122768
# Unit test for function represent_unicode
def test_represent_unicode():
    yaml_dump = yaml.safe_dump('foo', default_flow_style=True)
    yaml_dump2 = yaml.safe_dump(AnsibleUnicode('foo'), default_flow_style=True)
    assert yaml_dump == yaml_dump2

# Generated at 2022-06-23 05:37:22.768296
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = AnsibleVaultEncryptedUnicode(u'The secret is: {{ password }}')
    result = represent_vault_encrypted_unicode(None, data)
    assert result == u'!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          383830396561623635366266623435336630313631323038623035383933373530323332393734\n          633376623438363736313839663636346665313932636462663732396332316134383464313334\n          316165353666333961386638306262646265333431623136346238323739393232626431393038\n          61323633336536643362\n          '

# Generated at 2022-06-23 05:37:24.931348
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert type(AnsibleDumper) == type, "Test the constructor of class AnsibleDumper"

# Generated at 2022-06-23 05:37:31.359006
# Unit test for function represent_undefined
def test_represent_undefined():
    ans_undef = AnsibleUndefined()

    # For the sake of this test, put in a context that causes
    # _fail_with_undefined_error to be called.
    obj = {'a': {'b': {'c': ans_undef}}}

    dumper = AnsibleDumper
    dumper.open()
    try:
        y = dumper.represent_mapping(u'!unsafe tag', obj, style='>')
    finally:
        dumper.dispose()
    assert not y

# Generated at 2022-06-23 05:37:33.877669
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper(), SafeDumper)

# Generated at 2022-06-23 05:37:42.669213
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    my_vault = VaultLib(None)
    my_vault.decrypt(b'$ANSIBLE_VAULT;1.1;AES256', 'my_secret')
    e_text = my_vault.encrypt(b'my_secret_value')
    a_veu = AnsibleVaultEncryptedUnicode(e_text)
    x = yaml.dump(a_veu, Dumper=AnsibleDumper, default_flow_style=False)

# Generated at 2022-06-23 05:37:50.847409
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    '''Function represent_vault_encrypted_unicode'''
    data = u'\u2713'
    plaintext = binary_type('\x6f\x4f\x4a\x4a\x4f\x66\x69\x4f\x4a\x4a\x4f\x66\x74\x48\x43\x3d')

# Generated at 2022-06-23 05:37:51.710530
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert(True)

# Generated at 2022-06-23 05:38:03.325439
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.module_utils.six import PY3
    from ansible.parsing.yaml.loader import AnsibleLoader

    hosts = [{'ubuntu': {'ansible_host': '127.0.0.1', 'new_field': 1}},
             {'centos': {'ansible_host': '192.168.0.1', 'new_field': 1}}]
    yml_data = AnsibleLoader(hosts, yaml_loader=yaml.loader.SafeLoader).get_single_data()
    data = yaml.load(yaml.dump(yml_data, Dumper=AnsibleDumper), AnsibleLoader)
    assert data == hosts
    if PY3:
        assert isinstance(data, list)
        assert len(data[0]) == 1

# Generated at 2022-06-23 05:38:14.268712
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-23 05:38:21.339303
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(None)
    data=b'!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          3663363365663034363161376262613561346233346166333862643032346265643831333737366364\n          393339363761320a633535676564313331373932316265633035336465666433636663386138313237\n          6435646331626533330a35343762316335313733646166646636386236623061353961353038316330\n          30666362353265326565313937306231366338313366\n'

# Generated at 2022-06-23 05:38:32.289967
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    """
    Test that the vault encrypted unicode object gets represented properly
    """
    from ansible.vars.unsafe_proxy import AnsibleVaultEncryptedUnicode
    dumper = AnsibleDumper
    expected = u'!vault |\n  $ANSIBLE_VAULT;1.1;AES256\n  353165636335363662653562636365383538663532313662663530343931323266653534363662\n  30623966356362626563386231613631333638333835346638613664636166353634623732333534\n  653766393830\n'

# Generated at 2022-06-23 05:38:42.740403
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-23 05:38:52.800540
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    import sys
    import inspect

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestAnsibleDumper(unittest.TestCase):

        def setUp(self):
            self.dumper = AnsibleDumper

        def test_AnsibleDumper_object_creation(self):
            ''' AnsibleDumper object can be created '''
            self.assertIsNotNone(self.dumper)

        def test_AnsibleDumper_representers(self):
            ''' AnsibleDumper has some representers '''
            representers = set(self.dumper.yaml_representers.keys())

# Generated at 2022-06-23 05:38:54.473419
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(binary_type("test123"), Dumper=AnsibleDumper) == "test123\n..."

# Generated at 2022-06-23 05:38:56.764149
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    with open("/tmp/test_json", "w") as f:
        f.write(yaml.dump("a string", Dumper=AnsibleDumper))

# Generated at 2022-06-23 05:38:59.546204
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    ansible_dumper = AnsibleDumper()
    assert ansible_dumper is not None



# Generated at 2022-06-23 05:39:08.851237
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.dataloader import DataLoader
    import io
    import ansible
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    plaintext = b'This is a secret message.'
    encrypted_data = '$ANSIBLE_VAULT;1.1;AES256\n32383263386533363335636130613034613538396265313162643439663763313663363963376264323\n3383963386165323461653265326335666635333739376136313661333437666533343962313037333539\n636633363931\n'
    vault_pass = b'hello'

   

# Generated at 2022-06-23 05:39:12.010733
# Unit test for function represent_hostvars
def test_represent_hostvars():
    r = AnsibleDumper.represent_hostvars
    assert r(AnsibleDumper, HostVars(test=1)) == {'test': 1}

# Generated at 2022-06-23 05:39:18.558118
# Unit test for function represent_hostvars
def test_represent_hostvars():
    a_dict = {u'a': text_type('a'), u'b': u'b'}

    data = HostVars(a_dict)

    # ensure the data being added from the dict
    assert data.data == a_dict

    # This will run the representer code
    b_dict = AnsibleDumper.represent_hostvars(data)
    assert isinstance(b_dict, dict)
    assert b_dict == a_dict

# Generated at 2022-06-23 05:39:21.354025
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(dict(a=u'\u1234'), Dumper=AnsibleDumper) == \
        '{a: "\\u1234"}\n'

# Generated at 2022-06-23 05:39:29.088510
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper(None)
    bytestring = b'abcd'
    if hasattr(yaml, 'CSafeDumper'):
        assert dumper.represent_data(bytestring) == "!!binary 'YWJjZA==\n'"
    else:
        assert dumper.represent_data(bytestring) == "!!binary 'YWJjZA=='\n"



# Generated at 2022-06-23 05:39:33.724433
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert represent_hostvars(None, {'foo': 'bar', 'f': 'b'}) == "{foo: bar, f: b}"
    assert represent_hostvars(None, {}) == "{}"



# Generated at 2022-06-23 05:39:35.692514
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper_TestAnsibleDumper()
    assert dumper is not None

# Generated at 2022-06-23 05:39:39.544114
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper(width=4096)
    assert dumper.represent_binary(b"100100100100") == '!!binary |\n  MTAwMTAwMTAwMTAw\n'

# Generated at 2022-06-23 05:39:48.749294
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-23 05:39:50.570301
# Unit test for function represent_undefined
def test_represent_undefined():
    test_value = AnsibleUndefined("test")
    _ = yaml.dump([test_value], Dumper=AnsibleDumper)



# Generated at 2022-06-23 05:39:53.508123
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(u'[unicode_str]', Dumper=AnsibleDumper).strip() == u"'[unicode_str]'"

# Generated at 2022-06-23 05:40:02.613798
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump("foo", Dumper=AnsibleDumper) == "foo\n...\n"
    assert yaml.dump("foo\n", Dumper=AnsibleDumper) == "|-\n  foo\n  \n"
    assert yaml.dump("foo\nbar\nbaz", Dumper=AnsibleDumper) == "|-\n  foo\n  bar\n  baz\n"
    assert yaml.dump("foo\nbar\nbaz\n", Dumper=AnsibleDumper) == (
        "|-\n  foo\n  bar\n  baz\n  \n"
    )

# Generated at 2022-06-23 05:40:10.905305
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper is not None
    assert issubclass(AnsibleDumper, SafeDumper)
    assert AnsibleDumper.yaml_representers is not None
    assert isinstance(AnsibleDumper.yaml_representers, dict)
    assert AnsibleDumper.dumper_factory_presets is not None
    assert isinstance(AnsibleDumper.dumper_factory_presets, dict)
    assert AnsibleDumper.representers is not None
    assert isinstance(AnsibleDumper.representers, dict)

# Generated at 2022-06-23 05:40:14.257288
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert represent_hostvars(None, HostVars(vars={'test_key': 'test_value'})) == {'test_key': 'test_value'}



# Generated at 2022-06-23 05:40:18.214339
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    loader = yaml.SafeLoader
    if yaml.__with_libyaml__:
        assert dumper.represent_binary(b'hello') == '!!binary "aGVsbG8="'
        assert loader(dumper.represent_binary(b'hello')).construct_yaml_binary(
            loader.compose_node(None, None)) == b'hello'

# Generated at 2022-06-23 05:40:30.077204
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-23 05:40:32.042866
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    ansible_dumper = AnsibleDumper()
    assert isinstance(ansible_dumper, AnsibleDumper)

# Generated at 2022-06-23 05:40:39.984144
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():

    class StubRepresenter(object):

        def represent_scalar(self, tag, data, style=None):
            return 'tag: %s, data: %s' % (tag, data)

    a_val = AnsibleVaultEncryptedUnicode('abcd')

    # Test wrapper
    rep_val = represent_vault_encrypted_unicode(StubRepresenter(), a_val)
    assert 'tag: !vault, data: abcd' == rep_val

    # Test class directly
    rep_val = AnsibleDumper.represent_vault_encrypted_unicode(StubRepresenter(), a_val)
    assert 'tag: !vault, data: abcd' == rep_val

# Generated at 2022-06-23 05:40:49.168185
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    ansible_dumper = AnsibleDumper()
    sorted_output = sorted(list(ansible_dumper.yaml_representers))
    assert sorted_output == sorted(list([
        AnsibleUnicode,
        AnsibleUnsafeText,
        AnsibleUnsafeBytes,
        HostVars,
        HostVarsVars,
        VarsWithSources,
        AnsibleSequence,
        AnsibleMapping,
        AnsibleVaultEncryptedUnicode,
        AnsibleUndefined
    ]))

# Generated at 2022-06-23 05:40:53.482589
# Unit test for function represent_unicode
def test_represent_unicode():
    output = yaml.dump(dict(key=AnsibleUnicode("value")),
                       Dumper=AnsibleDumper,
                       default_flow_style=False,
                       encoding='utf-8')
    assert output == u'key: value\n'

# Generated at 2022-06-23 05:41:03.689129
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-23 05:41:04.440395
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    AnsibleDumper

# Generated at 2022-06-23 05:41:07.928108
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper(indent=1, width=10)

# create an instance of AnsibleDumper.
ansible_dumper = AnsibleDumper(indent=1, width=10)


# Generated at 2022-06-23 05:41:10.210628
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper, default_flow_style=False) == ""

# Generated at 2022-06-23 05:41:21.697146
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper

# Generated at 2022-06-23 05:41:24.033811
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    '''Just test that we can instantiate a AnsibleDumper'''
    AnsibleDumper()

# Generated at 2022-06-23 05:41:32.243118
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # This test shows that AnsibleUnicode is converted to yaml safe unicode
    data = {'foo': AnsibleUnicode(u'bar')}
    hv = HostVars(data)
    dumper = yaml.SafeDumper

    # We are just testing that the HostVars object can be dumped.
    # The output should be {'foo': 'bar'}
    # So we don't care about the output.
    # Just that it won't fail.
    dumper.represent_hostvars(dumper, hv)

# Generated at 2022-06-23 05:41:37.642143
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert issubclass(AnsibleDumper, yaml.SafeDumper)
    assert AnsibleDumper
    ansible_dumper = AnsibleDumper()
    assert ansible_dumper
    assert ansible_dumper == yaml.SafeDumper()
    assert isinstance(ansible_dumper, yaml.SafeDumper)


# Generated at 2022-06-23 05:41:42.631121
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper(default_flow_style=False)
    data = {'one': 'two'}
    hostvars = HostVars(data)
    assert dumper.represent_hostvars(hostvars) == dumper.represent_dict(dict(data))



# Generated at 2022-06-23 05:41:45.570043
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper(indent=4, width=80, default_flow_style=False)
    result = dumper.represent_undefined(AnsibleUndefined)
    assert result is False

# Generated at 2022-06-23 05:41:50.640693
# Unit test for function represent_unicode
def test_represent_unicode():
    data = AnsibleUnicode('abc')
    expected = "abc" + '\n...\n'
    dumper = AnsibleDumper()
    actual = yaml.dump(data, Dumper=AnsibleDumper)
    assert actual == expected

# Generated at 2022-06-23 05:41:53.325162
# Unit test for function represent_binary
def test_represent_binary():
    rep = yaml.representer.SafeRepresenter()
    assert isinstance(AnsibleDumper.represent_binary(rep, '123'), str)