

# Generated at 2022-06-23 05:32:01.221564
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    yaml.dump({'foo': 'bar'}, Dumper=AnsibleDumper)



# Generated at 2022-06-23 05:32:04.600398
# Unit test for function represent_binary
def test_represent_binary():
    assert represent_binary(AnsibleDumper, b'foobar') == yaml.representer.SafeRepresenter.represent_binary(AnsibleDumper, b'foobar')



# Generated at 2022-06-23 05:32:14.314247
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-23 05:32:17.135440
# Unit test for function represent_undefined
def test_represent_undefined():
    assert not represent_undefined(None, AnsibleUndefined())
    assert not represent_undefined(None, AnsibleUndefined('foo'))

# Generated at 2022-06-23 05:32:21.544240
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = [
        {'hostvars': {'foo': 'foo', 'bar': 'bar'}},
        {'hostvars': {'foo': 'bar', 'bar': 'foo'}},
    ]
    assert yaml.dump(data) == "---\n- {bar: bar, foo: foo}\n- {bar: foo, foo: bar}\n", yaml.dump(data)

# Generated at 2022-06-23 05:32:31.044386
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    def test(value):
        assert yaml.safe_dump(value, Dumper=AnsibleDumper, default_flow_style=None) == value._ciphertext
        assert yaml.safe_load(value._ciphertext, Loader=yaml.SafeLoader) == value.get_decrypted_text()

    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-23 05:32:32.356958
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert(AnsibleDumper)



# Generated at 2022-06-23 05:32:33.445124
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper

# Generated at 2022-06-23 05:32:34.524048
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper



# Generated at 2022-06-23 05:32:45.198778
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-23 05:32:49.058754
# Unit test for function represent_undefined
def test_represent_undefined():

    dumper = AnsibleDumper()
    text = dumper.represent_undefined(AnsibleUndefined(fail_on_undefined=True))
    assert text == 'UNDEFINED'

    text = dumper.represent_undefined(AnsibleUndefined(fail_on_undefined=False))
    assert text == 'None'



# Generated at 2022-06-23 05:33:00.705294
# Unit test for function represent_unicode
def test_represent_unicode():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader

    dump_data = AnsibleUnicode('abc')

    stream = yaml.dump(dump_data, Dumper=AnsibleDumper, default_flow_style=False)
    assert stream.strip() == 'abc', "dump_data %s" % stream

    load_data = yaml.load(stream, Loader=AnsibleLoader)
    assert isinstance(load_data, AnsibleUnicode)
    assert isinstance(load_data, text_type)
    assert load_data == dump_data, "load_data %s" % load_data

# Generated at 2022-06-23 05:33:01.550848
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper is not None

# Generated at 2022-06-23 05:33:12.264965
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    from ansible.module_utils.common.json import module_json as json
    try:
        import __builtin__ as builtins
        builtins.__dict__['basestring'] = str
    except ImportError:
        import builtins
        builtins.__dict__['basestring'] = str

    test_string = "I like turtles."
    test_unicode = u"I like türtle."
    test_byte = b"I like binary."
    test_dict = {u'foo': u'bar'}
    test_list = [u'foo', u'bar']
    test_undefined = AnsibleUndefined()

    assert yaml.dump(test_string) == yaml.dump(test_string, Dumper=AnsibleDumper)

# Generated at 2022-06-23 05:33:15.463152
# Unit test for function represent_binary
def test_represent_binary():
    # Non-empty binary data
    data = b'foobar'

    # Should be converted to plain string "foobar"
    assert yaml.dump(data, Dumper=AnsibleDumper) == b'"foobar"\n'

# Generated at 2022-06-23 05:33:18.312727
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = yaml.Dumper()
    dumper.represent_undefined = represent_undefined
    assert dumper.represent_data(AnsibleUndefined) == 'undef'

# Generated at 2022-06-23 05:33:28.756286
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources

    hv_vars = HostVars(aggregate_vars={'foo': 'bar'}, hostvars={'test': {'test1': 'test2'}})
    dumper = AnsibleDumper()
    res_expected = "aggregate_vars: {foo: bar}\nhostvars: {test: {test1: test2}}\n"

    result = dumper.represent_hostvars(hv_vars)
    assert result == res_expected

    hv_vars = VarsWithSources(aggregate_vars={'foo': 'bar'}, hostvars={'test': {'test1': 'test2'}})
    dumper = AnsibleDumper

# Generated at 2022-06-23 05:33:35.640119
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    yaml_dump = yaml.dump(AnsibleVaultEncryptedUnicode(u'foo'), Dumper=AnsibleDumper)
    assert yaml_dump == u'!vault |\n  $ANSIBLE_VAULT;1.2;AES256;foo;16\n  393763393666306439663437656338623135383664313962376438626262386133356437353936\n  6300\n'



# Generated at 2022-06-23 05:33:41.902343
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(10) == u'10'
    assert dumper.represent_unicode(u'abc') == u'abc'
    assert dumper.represent_unicode(u'\u2713') == u'\u2713'


# Generated at 2022-06-23 05:33:52.749435
# Unit test for function represent_unicode
def test_represent_unicode():
    yaml_data = '''
---
a: "{{ foo }}"
b: "{{ bar }}"
c: "{{ bam }}"
'''

    # str
    data = yaml.load(yaml_data)
    assert isinstance(data['a'], AnsibleUnicode)

    # bytes
    data = yaml.load(yaml_data.encode())
    assert isinstance(data['a'], AnsibleUnicode)

    # str
    output = yaml.dump(data, Dumper=AnsibleDumper, default_flow_style=False)
    assert isinstance(output, text_type)

    # bytes
    output = yaml.dump(data, Dumper=AnsibleDumper, default_flow_style=False, encoding='utf-8')

# Generated at 2022-06-23 05:34:03.194711
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import UnsafeText
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import get_file_vault_secret
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vault_secret = get_file_vault_secret(['tests/test_vault_pass'])
    vault = AnsibleVaultEncryptedUnicode(VaultLib([vault_secret]), UnsafeText('test'))
    d = AnsibleDumper(default_flow_style=False)
    d.represent_vault_encrypted_unicode(vault)

# Generated at 2022-06-23 05:34:06.873599
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import template
    from ansible.template.safe_eval import unsafe_eval

    # Check that it doesn't fail
    dumper = AnsibleDumper()
    dumper.represent_undefined('fake_data')

# Generated at 2022-06-23 05:34:12.934024
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.hostvars import HostVars, HostVarsVars, VarsWithSources
    data = AnsibleMapping()
    data.mapping = dict(a='1', b='2')
    for obj in [HostVars(data=data), HostVarsVars(data=data), VarsWithSources(data=data)]:
        assert represent_hostvars(None, obj) == yaml.representer.SafeRepresenter.represent_dict(None, dict(data))

# Generated at 2022-06-23 05:34:15.758170
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    assert dumper.represent_undefined(dumper, AnsibleUndefined()) == False

dumper = AnsibleDumper


# Generated at 2022-06-23 05:34:18.125612
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert yaml.dump(HostVars(dict()), Dumper=AnsibleDumper) == "--- {}\n"



# Generated at 2022-06-23 05:34:21.343070
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper(None, None, yaml.RoundTripDumper)
    assert dumper.represent_binary(b'!') == '!!binary |\n  IQ=='



# Generated at 2022-06-23 05:34:29.982152
# Unit test for function represent_binary
def test_represent_binary():
    # Note: SafeRepresenter.represent_binary requires the binary data to be bytes in python3
    # In python2 the yaml lib does not enforce this and the test_basic_dump test would break if not handled correctly.
    # test data = '\x01\x02\x03'.encode('ascii')

    # test data = '\x01\x02\x03'
    data = binary_type('\x01\x02\x03')
    loader = AnsibleDumper
    expected = '!!binary "AQID"'
    dumped = loader.represent_binary(loader, data)
    assert dumped == expected

# Generated at 2022-06-23 05:34:30.968890
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    a = AnsibleDumper()



# Generated at 2022-06-23 05:34:34.876476
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == False



# Generated at 2022-06-23 05:34:41.726681
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Setup test
    stream = open('/dev/null', 'w')
    dumper = AnsibleDumper(stream)
    dummy_str = 'My Value'
    data = AnsibleVaultEncryptedUnicode(dummy_str)

    # Run test
    output = dumper.represent_vault_encrypted_unicode(data)

    # Verify results
    assert output == "!vault |\n          {}".format(dummy_str)



# Generated at 2022-06-23 05:34:47.106861
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper()

    # Private methods are used for testing
    assert dumper._alias_key == yaml.representer.SafeRepresenter._alias_key  # pylint: disable=protected-access
    assert dumper._tag_properties == yaml.representer.SafeRepresenter._tag_properties  # pylint: disable=protected-access


# Unit tests for adding representers

# Generated at 2022-06-23 05:34:52.386970
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(AnsibleDumper, u'foo') == u"'foo'"
    assert represent_unicode(AnsibleDumper, u'fóo') == u"'fóo'"
    assert represent_unicode(AnsibleDumper, u'fóó\nbar') == u"|-\n  fóó\n  bar"


# Generated at 2022-06-23 05:34:58.429698
# Unit test for function represent_hostvars
def test_represent_hostvars():
    s = "{'simple': 'ok'}"
    dmp = AnsibleDumper(None, yaml.RoundTripDumper)
    hosted = HostVars(None)
    for k, v in yaml.load(s).items():
        setattr(hosted, k, v)

    data = dmp.represent_hostvars(hosted)
    assert list(data.value)[0].value.value == 'simple'
    assert list(data.value)[0].value.value == 'simple'

# Generated at 2022-06-23 05:35:01.081029
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    ansible_dumper = AnsibleDumper()
    assert ansible_dumper is not None

# Generated at 2022-06-23 05:35:02.285585
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    loader = AnsibleDumper()
    return loader



# Generated at 2022-06-23 05:35:09.757360
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert(dumper.represent_binary(b'hello') == "{hello}")
    assert(dumper.represent_binary('hello') == '{hello}')
    assert(dumper.represent_data({'hello': b'world'}) == "{'hello': {world}}")
    assert(dumper.represent_data({'hello': 'world', 'moo': b'moo'}) == "{'hello': 'world', 'moo': {moo}}")

# Generated at 2022-06-23 05:35:19.693846
# Unit test for function represent_undefined
def test_represent_undefined():
    """
    Test that AnsibleDumper correctly handles Jinja StrictUndefined values.
    """
    d = AnsibleDumper()

    # An undefined value should cause _fail_with_undefined_error()
    tested = False
    def fail(*args, **kwargs):
        nonlocal tested
        tested = True
        raise AssertionError()

    # This function is only used to flag an error,
    # so a dummy function is used.
    d._fail_with_undefined_error = fail

    # A regular undefined value should fail
    try:
        d.represent_data(AnsibleUndefined)
    except AssertionError:
        pass

    assert tested

# Preload the AnsibleDumper so that we don't have to keep adding our representers
dumper = AnsibleDumper

# Generated at 2022-06-23 05:35:20.292373
# Unit test for function represent_hostvars
def test_represent_hostvars():
    return

# Generated at 2022-06-23 05:35:28.735814
# Unit test for function represent_unicode
def test_represent_unicode():

    # First create an instance of our dumper class
    # This will be used to output yaml
    yaml_dump = yaml.dump

    # Create some data that we think is unicode
    data = {'unicode_string': u'this is unicode'}

    output = yaml_dump(data, Dumper=AnsibleDumper)

    # Print out a message saying run as a test
    print("======\n%s\n=====\n" % output)



# Generated at 2022-06-23 05:35:30.245080
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper()
    assert dumper is not None


# Generated at 2022-06-23 05:35:33.561686
# Unit test for function represent_unicode
def test_represent_unicode():
    value = yaml.dump(
        {
            'unicode': AnsibleUnicode('foo'),
        },
        Dumper=AnsibleDumper,
        default_flow_style=False,
    )
    assert value == "unicode: foo\n"



# Generated at 2022-06-23 05:35:38.159857
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper(indent=2)
    for data in (HostVars(), HostVarsVars(), {'a': 1, 'b': 2}):
        assert dumper.represent_hostvars(data) == dumper.represent_dict(dict(data))

# Generated at 2022-06-23 05:35:39.906071
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleUndefined("foo") is True

# Generated at 2022-06-23 05:35:43.831034
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(u'\x80'.encode('utf8'),
                     default_flow_style=False,
                     Dumper=AnsibleDumper).replace('\n', '') == '!binary |\n  wAAA'



# Generated at 2022-06-23 05:35:54.740462
# Unit test for function represent_unicode

# Generated at 2022-06-23 05:35:57.331148
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    ansible_dumper = AnsibleDumper()
    assert(ansible_dumper is not None)


# Generated at 2022-06-23 05:35:59.459559
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    assert dumper.represent_unicode(dumper, "test") == "test"


# Generated at 2022-06-23 05:36:08.612667
# Unit test for function represent_binary
def test_represent_binary():
    data_str = b'!vault |\n          $ANSIBLE_VAULT;1.1;AES256'
    retval = yaml.representer.SafeRepresenter.represent_binary(AnsibleDumper, data_str)
    assert retval == '!binary |\n          ISFhbHZhaXIgVmF1bHQ7MS4xO0FFUzI1Ng=='
    # This test is for https://github.com/ansible/ansible/issues/55291

# Generated at 2022-06-23 05:36:18.271735
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = yaml.SafeDumper
    dumper.add_representer(
        AnsibleVaultEncryptedUnicode,
        represent_vault_encrypted_unicode,
    )

# Generated at 2022-06-23 05:36:24.095559
# Unit test for function represent_binary
def test_represent_binary():
    class TestAnsibleDumper(AnsibleDumper):
        pass

    TestAnsibleDumper.add_representer(bytes, TestAnsibleDumper.represent_binary)
    result = yaml.dump(b'foo', Dumper=TestAnsibleDumper)
    assert result == '!!binary "Zm9v\\n"\n'

# Generated at 2022-06-23 05:36:27.826164
# Unit test for function represent_binary
def test_represent_binary():
    yaml_str = yaml.dump(AnsibleUnsafeBytes(b'\x00\x01\x02\xFF'), Dumper=AnsibleDumper)
    assert yaml_str == "!!binary '\\x00\\x01\\x02\\xff'\n"

# Generated at 2022-06-23 05:36:29.698748
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper()
    assert hasattr(dumper, 'add_representer')



# Generated at 2022-06-23 05:36:32.688064
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    data = (u'{key1: value1, key2: value2}')
    assert represent_hostvars(dumper, data) == u'test'



# Generated at 2022-06-23 05:36:38.647775
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumps = yaml.dump(AnsibleVaultEncryptedUnicode(value='$ANSIBLE_VAULT;1.1;AES256\n516b397743656d4c'), Dumper=AnsibleDumper)
    assert dumps == '!vault |\n  $ANSIBLE_VAULT;1.1;AES256\n  516b397743656d4c\n'

# Generated at 2022-06-23 05:36:42.381086
# Unit test for function represent_unicode
def test_represent_unicode():
    test = {'test': 'Fumaça não é fumaça'}
    assert yaml.dump(test, Dumper=AnsibleDumper) == '{test: Fumaça não é fumaça}\n'



# Generated at 2022-06-23 05:36:50.743217
# Unit test for function represent_hostvars
def test_represent_hostvars():
    import ansible.playbook.play_context
    play_context = ansible.playbook.play_context.PlayContext()
    hostvars = HostVars(play_context, dict(a=1, b=2))
    d = dict(hostvars=hostvars)
    result = yaml.dump(d, default_flow_style=False, Dumper=AnsibleDumper)
    assert result == '''hostvars:
  a: 1
  b: 2
'''



# Generated at 2022-06-23 05:36:53.006582
# Unit test for function represent_unicode
def test_represent_unicode():
    yaml.safe_dump(dict(a=u'foo', b=u'[u\'bar\']'), default_flow_style=True, Dumper=AnsibleDumper)

# Generated at 2022-06-23 05:36:56.071683
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():

    for width in range(1, 4):
        for indent in range(1, 4):
            dumper = AnsibleDumper(width=width, indent=indent)
            assert dumper.width == width
            assert dumper.indent == indent

# Generated at 2022-06-23 05:37:06.136942
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib

    vault_pass = 'ansible'

# Generated at 2022-06-23 05:37:17.889087
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    test_data = AnsibleVaultEncryptedUnicode("This is a test")

    # Note: pyyaml doesn't like to encode unicode
    ciphertext = ansible_yaml.dump(test_data, encoding='utf-8', Dumper=AnsibleDumper)

# Generated at 2022-06-23 05:37:22.963084
# Unit test for function represent_hostvars
def test_represent_hostvars():
    output = yaml.dump({'hostvars': HostVars(b_vars={'password': b'password'})}, Dumper=AnsibleDumper)
    assert 'hostvars' in output
    assert 'password' in output
    assert AnsibleUnicode(b'password', convert_bare=True, errors='strict').startswith('PASSWORD')



# Generated at 2022-06-23 05:37:27.260484
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    a = u'\u2713'
    b = dumper.represent_unicode(dumper, a)
    c = u'\u2713'
    assert c == text_type(b)



# Generated at 2022-06-23 05:37:28.864487
# Unit test for function represent_undefined
def test_represent_undefined():
    isinstance(AnsibleUndefined(), AnsibleUndefined)

# Generated at 2022-06-23 05:37:37.032586
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x00\x00\x01') == u'!!binary |\n  AAECAw==\n'
    assert dumper.represent_binary(b'\x01\x00\x00\x00') == u'!!binary |\n  AQAAAA==\n'
    assert dumper.represent_binary(b'\x00\x00\x00\x00') == u'!!binary |\n  AAAA\n'
    assert dumper.represent_binary(b'\x00\x00\x00\x00\x00\x00\x00\x00') == u'!!binary |\n AAAAAAAA\n'

# Generated at 2022-06-23 05:37:47.236284
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper

# Generated at 2022-06-23 05:37:55.229753
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = AnsibleVaultEncryptedUnicode('test_value')
    text = represent_vault_encrypted_unicode(None, data)

# Generated at 2022-06-23 05:37:57.651596
# Unit test for function represent_undefined
def test_represent_undefined():
    assert bool(AnsibleUndefined("undefined"))
    assert not bool(AnsibleUndefined("the value of undefined"))

# Generated at 2022-06-23 05:38:04.540683
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    data = AnsibleUnicode(value=u'\u263a')

    assert yaml.representer.SafeRepresenter.represent_str(dumper, data) == yaml.representer.SafeRepresenter.represent_str(dumper, data.value)
    assert yaml.representer.SafeRepresenter.represent_str(dumper, data.value) == u"!!python/unicode '\\u263a'"
    assert dumper.represent_unicode(data) == u"!ansible-unicode '\\u263a'"



# Generated at 2022-06-23 05:38:09.214967
# Unit test for function represent_hostvars
def test_represent_hostvars():
    import ansible.playbook.play_context

    dumper = AnsibleDumper
    result = dumper.represent_hostvars(dumper,
                                       HostVars(vars=dict(a=dict(b=1)),
                                                host=ansible.playbook.play_context.PlayContext()))

    assert result



# Generated at 2022-06-23 05:38:11.132430
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper()
    assert dumper.__class__.__name__ == 'AnsibleDumper'

# Generated at 2022-06-23 05:38:15.003507
# Unit test for function represent_unicode
def test_represent_unicode():
    a = AnsibleUnicode(u'foo')
    assert yaml.dump(a, Dumper=AnsibleDumper, default_flow_style=False) == '!!python/unicode \'foo\'\n'



# Generated at 2022-06-23 05:38:26.631681
# Unit test for function represent_unicode
def test_represent_unicode():
    if not yaml.__with_libyaml__:
        raise AssertionError('libyaml is required to make this test work')

    import collections

    # Unicode string
    data = u'u\u1234'
    result = yaml.dump(data, width=60, default_flow_style=False, Dumper=AnsibleDumper)
    assert result == "- u\u1234\n"

    # Unicode string with multiple lines
    data = u"u\n1234\u1234"
    result = yaml.dump(data, width=60, default_flow_style=False, Dumper=AnsibleDumper)
    assert result == u"- u\n  1234\u1234\n"

    # Dict with unicode key

# Generated at 2022-06-23 05:38:34.812728
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.objects import AnsibleMapping
    data = {
        'localhost': {
            'hostvars': {
                'var1': 1,
                'var2': 2,
            },
            'children': [
                'ungrouped'
            ]
        }
    }

    ansible_mapping = AnsibleMapping.construct(data)
    new_data = represent_hostvars(AnsibleDumper, ansible_mapping)
    final_data = yaml.dump(new_data)

    assert final_data == "{localhost: {children: ['ungrouped'], var1: 1, var2: 2}}\n"

# Generated at 2022-06-23 05:38:39.918548
# Unit test for function represent_unicode
def test_represent_unicode():
    data = dict(key_u=u"value", key_u_unicode=u'\u9c7c')
    assert yaml.dump(data, Dumper=AnsibleDumper, default_flow_style=False) == 'key_u: value\nkey_u_unicode: "\\u9c7c"\n'



# Generated at 2022-06-23 05:38:42.999071
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.objects import AnsibleMapping
    assert type(represent_hostvars(AnsibleDumper, HostVars({"a": "b"}))) is AnsibleMapping

# Generated at 2022-06-23 05:38:49.446503
# Unit test for function represent_unicode
def test_represent_unicode():

    class FakeDumper(object):
        def represent_str(self, *args, **kwargs):
            return (args, kwargs)

    dumper = FakeDumper()

    data = 'test'
    expected = (('test',), {})
    actual = represent_unicode(dumper, data)
    assert expected == actual

    data = 1
    expected = (('1',), {})
    actual = represent_unicode(dumper, data)
    assert expected == actual



# Generated at 2022-06-23 05:38:51.228842
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert(AnsibleDumper)



# Generated at 2022-06-23 05:38:55.554222
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    class DummyVault(object):
        def __init__(self, ciphertext):
            self._ciphertext = ciphertext

    dumper = AnsibleDumper  # pylint: disable=no-member
    assert dumper.represent_data(DummyVault(b'ABC')) == u"!vault |\n  ABC\n"

# Generated at 2022-06-23 05:39:05.859610
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # This is a unit test for function represent_hostvars.
    #
    # To run only this test:
    #   python -m pytest tests/units/test_yaml.py::test_represent_hostvars
    #

    # Needed because HostVars is an object
    class bla(object):
        def __init__(self, a, b):
            self.a = a
            self.b = b
        def __iter__(self):
            return iter(self.__dict__)
        def __repr__(self):
            return '%s(%r, %r)' % (self.__class__.__name__, self.a, self.b)

    input = bla('a', 'b')
    result = yaml.dump(input, Dumper=AnsibleDumper)

# Generated at 2022-06-23 05:39:17.802288
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    text = "This is a test string"
    text_utf8 = text.encode('utf-8')
    text_b64 = b'VGhpcyBpcyBhIHRlc3Qgc3RyaW5n'
    text_b64_utf8 = text_b64.decode('utf-8')
    ansible_text = AnsibleUnsafeText(text_utf8, convert_bare=False)
    ansible_text_b64 = AnsibleUnsafeText(text_b64_utf8, encode_type='base64', convert_bare=False)
    ansible_text_utf8 = AnsibleUnsafeText(text_utf8, encode_type='strict_base64', convert_bare=False)
    ansible_bytes = AnsibleUnsafeBytes(text_utf8)
    ansible_

# Generated at 2022-06-23 05:39:23.026389
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    d = AnsibleDumper(stream=None,
                      default_flow_style=None,
                      canonical=None,
                      indent=None,
                      width=None,
                      allow_unicode=None,
                      line_break=None,
                      encoding=None,
                      explicit_start=None,
                      explicit_end=None,
                      version=None,
                      tags=None)
    assert d is not None

# Generated at 2022-06-23 05:39:28.755396
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    # Test with type_representations as None
    AnsibleDumper(type_representations=None)

    # Test with type_representations as dictionary
    dumper = AnsibleDumper(type_representations=dict(unicode=represent_unicode))
    assert dumper.representers[AnsibleUnicode] == represent_unicode



# Generated at 2022-06-23 05:39:30.889792
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper.represent_undefined(AnsibleDumper, AnsibleUndefined()) == True



# Generated at 2022-06-23 05:39:35.641150
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.safe_dump(AnsibleUndefined(), default_flow_style=False) == u'true\n'
    assert yaml.safe_dump({'a': AnsibleUndefined()}, default_flow_style=False) == u'a: true\n'



# Generated at 2022-06-23 05:39:45.805893
# Unit test for function represent_undefined
def test_represent_undefined():
    yaml_data = yaml.load("""
        ---
        foo: !jinja2-L4
          {{
            'item': '{{ i1 }'
               }}
        """, Loader=yaml.FullLoader)
    dumper = AnsibleDumper()
    # Returns true because value is not undefined
    assert dumper.represent_data(yaml_data) == True
    # Here bool will ensure _fail_with_undefined_error
    # if the value is Undefined.
    # This happens because Jinja sets __bool__ on StrictUndefined
    yaml_data = yaml.load("""
        foo: !jinja2-L3
          {{
            i1
               }}
        """, Loader=yaml.FullLoader)
    # Checks whether the error is raised.
    # Returns false because

# Generated at 2022-06-23 05:39:47.973149
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper()

    # Success condition
    if dumper is not None:
        print("Success: AnsibleDumper()")



# Generated at 2022-06-23 05:39:49.787190
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(binary_type(b'a'), Dumper=AnsibleDumper) == "!!binary 'YQ=='\n"

# Generated at 2022-06-23 05:39:54.758925
# Unit test for function represent_binary
def test_represent_binary():
    """This test ensures that we don't dump a binary string (b'some_string')
    as it would lead to yaml dumper to add extra '' around the binary
    string. Note that this is required when ansible_python_interpreter is
    'python3' and ansible_managed is unicode.
    """
    string = b'some_string'
    assert str(string) == "b'some_string'"
    assert yaml.dump(string) == "b'some_string'\n"
    struct = dict(some_key=string)
    assert yaml.safe_dump(struct) == "some_key: some_string\n"

# Generated at 2022-06-23 05:39:57.443845
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(b'foo', Dumper=AnsibleDumper).strip() == 'foo'

# Generated at 2022-06-23 05:39:59.786015
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    x = AnsibleDumper()

    # Testing init function
    # assert isinstance(x, object)

# Generated at 2022-06-23 05:40:02.506083
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper().represent_undefined(AnsibleUndefined()) == bool(AnsibleUndefined())

# Tests for the classes

# Generated at 2022-06-23 05:40:10.864074
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    string = 'foo'
    ciphertext = b'bar'
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    vault = VaultLib([])
    secret = VaultSecret(vault=vault, secret=ciphertext)
    aveu = AnsibleVaultEncryptedUnicode(string, secret)
    assert AnsibleDumper.represent_vault_encrypted_unicode(AnsibleDumper, aveu) == u"!vault |\n  \"bar\""

# Generated at 2022-06-23 05:40:14.621213
# Unit test for function represent_binary
def test_represent_binary():
    data = b'\x01\x02\03'
    result = yaml.representer.SafeRepresenter.represent_binary(AnsibleDumper, data)
    assert result == u'!!binary |\n  AQID\n'



# Generated at 2022-06-23 05:40:16.116032
# Unit test for function represent_undefined
def test_represent_undefined():
    AnsibleUndefined(fail_on_undefined=False)

# Generated at 2022-06-23 05:40:16.729883
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    AnsibleDumper()

# Generated at 2022-06-23 05:40:23.117390
# Unit test for function represent_unicode
def test_represent_unicode():

    assert represent_unicode(AnsibleDumper, 'abc') == yaml.representer.SafeRepresenter.represent_str(AnsibleDumper, 'abc')
    assert represent_unicode(AnsibleDumper, u'abc') == yaml.representer.SafeRepresenter.represent_str(AnsibleDumper, 'abc')



# Generated at 2022-06-23 05:40:28.130132
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template.safe_eval import Undefined
    x = Undefined()
    dumper = AnsibleDumper()
    try:
        dumper.represent_undefined(dumper, x)
        assert False, 'represent_undefined did not fail'
    except yaml.representer.RepresenterError:
        pass

# Generated at 2022-06-23 05:40:32.414582
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    b = dumper.represent_binary(b'\x00\x01')
    assert b == yaml.representer.SafeRepresenter.represent_binary(dumper, b'\x00\x01')



# Generated at 2022-06-23 05:40:36.923231
# Unit test for function represent_binary
def test_represent_binary():
    dumper = yaml.SafeDumper
    representer = represent_binary
    assert representer(dumper, binary_type(b"test")) == yaml.representer.SafeRepresenter.represent_binary(dumper, b"test")



# Generated at 2022-06-23 05:40:40.852730
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper(width=1000)
    assert dumper.represent_data(AnsibleUndefined) is None
    assert dumper.represent_data(AnsibleUndefined(fail_on_undefined=True)) is True


# Generated at 2022-06-23 05:40:43.857129
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    assert dumper.represent_undefined(dumper, 'hello')
    assert not dumper.represent_undefined(dumper, AnsibleUndefined())

# Generated at 2022-06-23 05:40:49.927068
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    binary = b'\x01'
    result = dumper.represent_binary(binary)
    expected = yaml.representer.SafeRepresenter.represent_binary(dumper, binary)
    assert result == expected



# Generated at 2022-06-23 05:40:53.491821
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    undefined = AnsibleUndefined()
    assert dumper.represent_data(undefined) == b'false'

# Generated at 2022-06-23 05:41:02.658497
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = yaml.dumper.Dumper
    dumper.add_representer(
        AnsibleVaultEncryptedUnicode,
        represent_vault_encrypted_unicode,
    )
    data = AnsibleVaultEncryptedUnicode(u'foo')

# Generated at 2022-06-23 05:41:06.836381
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = HostVars({"foo": "bar"})
    yaml_data = yaml.dump(hostvars, Dumper=AnsibleDumper)
    assert yaml_data == u"{foo: bar}\n"



# Generated at 2022-06-23 05:41:16.373910
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    yaml_data = AnsibleVaultEncryptedUnicode('test')
    data = {'test': yaml_data}
    yaml_str = yaml.safe_dump(data, default_flow_style=False, Dumper=AnsibleDumper)

# Generated at 2022-06-23 05:41:20.453250
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = yaml.SafeDumper
    dumper.add_representer(AnsibleUndefined, represent_undefined)
    x = AnsibleUndefined()
    assert dumper.represent_data(x) is False



# Generated at 2022-06-23 05:41:28.471513
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault_str = VaultLib()
    vault_str.encrypt("test")
    rep_data = AnsibleVaultEncryptedUnicode('test')
    rep_data._ciphertext = vault_str.encrypt("test")
    representer = represent_vault_encrypted_unicode(None,rep_data)
    assert representer == '!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          63326164666430366231306235333138636363326262346638313861313733326434336331623465\n          3834376239393838333834623034333131343739376166\n          '

# Generated at 2022-06-23 05:41:36.797359
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-23 05:41:41.394222
# Unit test for function represent_unicode
def test_represent_unicode():
    u = u'\u2642'
    yu = yaml.dump(u, Dumper=AnsibleDumper).encode('utf-8')
    testyu = b'\xef\xbc\x82'
    assert yu == testyu



# Generated at 2022-06-23 05:41:49.053883
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import DataLoader

    inventory = DataLoader()
    hvars = HostVars(hostname='hostname1')
    hvars['var1'] = 'foo'
    hvars['var2'] = 5
    inventory.add_host(hostname='hostname1', variables=hvars)
    result = yaml.dump([hvars], Dumper=AnsibleDumper, default_flow_style=False)
    assert result == '''\
- var1: foo
  var2: 5
'''

# Generated at 2022-06-23 05:41:56.517377
# Unit test for function represent_unicode
def test_represent_unicode():
    # pylint: disable=invalid-name
    yaml.add_representer(
        AnsibleUnicode,
        represent_unicode,
        Dumper=AnsibleDumper
    )

    assert yaml.dump(AnsibleUnicode('moo')) == 'moo\n...\n'

    yaml.add_representer(
        AnsibleUnsafeText,
        represent_unicode,
        Dumper=AnsibleDumper
    )

    assert yaml.dump(AnsibleUnsafeText('moo')) == 'moo\n...\n'

