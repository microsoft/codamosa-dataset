

# Generated at 2022-06-23 05:31:55.457327
# Unit test for function represent_undefined
def test_represent_undefined():
    try:
        AnsibleDumper.represent_undefined(1)
    except yaml.representer.RepresenterError:
        pass
    else:
        raise AssertionError('No exception was raised.')

# Generated at 2022-06-23 05:31:58.347960
# Unit test for function represent_undefined
def test_represent_undefined():
    undefined = AnsibleUndefined('test_represenet_undefined')
    assert represent_undefined(AnsibleDumper, undefined)
    assert not yaml.representer.SafeRepresenter.represent_undefined(AnsibleDumper, undefined)

# Generated at 2022-06-23 05:32:08.096357
# Unit test for function represent_hostvars
def test_represent_hostvars():
    import copy
    from ansible.parsing.yaml.objects import AnsibleMapping
    hv = HostVars({'a': {'b': {'c': 'd'}}, 'e': 'f'}, [], None)
    assert represent_hostvars(None, copy.deepcopy(hv)).__class__ is AnsibleMapping
    assert represent_hostvars(None, copy.deepcopy(hv))['a'].__class__ is AnsibleMapping
    assert represent_hostvars(None, copy.deepcopy(hv))['a']['b'].__class__ is AnsibleMapping
    assert represent_hostvars(None, copy.deepcopy(hv))['a']['b']['c'] == 'd'

# Generated at 2022-06-23 05:32:14.286271
# Unit test for function represent_binary
def test_represent_binary():
    # represent_binary should represent binary data as str, not unicode
    dumper = AnsibleDumper()
    dumper.add_representer(binary_type, dumper.represent_binary)
    result = dumper.represent_data(b'foo\xffbar')
    assert result == u'!!binary |\n  ' + u'Zm9v/mJhcg==\n'
    assert isinstance(result, text_type)

# Generated at 2022-06-23 05:32:19.919720
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert represent_unicode(dumper, AnsibleUnicode('Hello world')) == 'Hello world'
    assert represent_unicode(dumper, AnsibleUnsafeText('Hello world')) == 'Hello world'
    assert represent_unicode(dumper, AnsibleUnsafeBytes('Hello world')) == b'Hello world'



# Generated at 2022-06-23 05:32:30.816990
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('ansible')
    vault.decrypt = lambda data: b"PLAIN_TEXT"

# Generated at 2022-06-23 05:32:33.065507
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    obj = AnsibleDumper()
    assert obj is not None

# Generated at 2022-06-23 05:32:35.665761
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper.yaml_representers == object.yaml_representers
# Calls above function "test_AnsibleDumper()"
test_AnsibleDumper()

# Generated at 2022-06-23 05:32:42.000188
# Unit test for function represent_binary
def test_represent_binary():
    assert AnsibleDumper.represent_binary(b'\xA1') == b'!binary |-\n  \xc2\xa1\n'
    assert AnsibleDumper.represent_binary(b'\x00\x01\x02\x03\x14') == b'!binary |-\n  \x00\x01\x02\x03\x14\n'

# Generated at 2022-06-23 05:32:48.660528
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # Generate some mock hostvars objects
    data = HostVars()
    data.add_host(HostVarsVars())
    data.add_host(HostVarsVars())

    # Dump the data
    stream = AnsibleDumper.represent_dict(dict(data))

    # Round-trip the results
    roundtrip = yaml.load(stream)

    # Check that the hosts were added and returned.
    assert roundtrip['hosts'] == {}



# Generated at 2022-06-23 05:32:50.148687
# Unit test for function represent_undefined
def test_represent_undefined():
    AnsibleDumper.represent_undefined(AnsibleDumper, AnsibleUndefined())

# Generated at 2022-06-23 05:32:51.124983
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():

    assert AnsibleDumper is not None

# Generated at 2022-06-23 05:32:59.604567
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hv = HostVars.from_vars({'foo': 'bar'})
    hvv = HostVarsVars({'foo': 'bar'})
    vws = VarsWithSources({'foo': 'bar'}, 'file', 'filename')
    assert yaml.dump(hv, Dumper=SafeDumper) == '{foo: bar}\n'
    assert yaml.dump(hvv, Dumper=SafeDumper) == '{foo: bar}\n'
    assert yaml.dump(vws, Dumper=SafeDumper) == '{foo: bar}\n'



# Generated at 2022-06-23 05:33:03.418879
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, binary_type(b'foo')) == dumper.represent_str(dumper, 'foo')

# Generated at 2022-06-23 05:33:06.618994
# Unit test for function represent_undefined
def test_represent_undefined():
    undefined_var = AnsibleUndefined('var_name')
    yaml_data = yaml.dump(undefined_var, Dumper=AnsibleDumper)
    assert yaml_data == 'True\n'

# Generated at 2022-06-23 05:33:10.069453
# Unit test for function represent_binary
def test_represent_binary():
    representer = AnsibleDumper.represent_binary
    assert representer('some text') == (b'some text', None)
    assert representer('some text', style='|') == (b'some text', u'|')



# Generated at 2022-06-23 05:33:17.907211
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    import re

    # TODO: move to more rigorous test harness
    vm = VariableManager()
    hv = HostVars()
    hv.add_host_vars('foo', dict(a=1, b=2))
    vm._hostvars = hv
    m = AnsibleMapping(vm.hostvars)

    dumper = AnsibleDumper()
    dumped = re.sub('\n *', '', dumper.represent_dict(m))
    expected = "{'foo': {'a': 1, 'b': 2}}"
    assert dumped == expected

# Generated at 2022-06-23 05:33:28.344407
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = yaml.dumper.SafeDumper
    hostvars = HostVars('example')
    assert represent_hostvars(dumper, hostvars) == '{}'
    hostvars['example'] = 'example'
    hostvars['example2'] = 'example2'
    hostvars2 = HostVars('example2')
    hostvars2['example'] = 'example'
    hostvars2['example2'] = hostvars
    hostvars2['example3'] = 'example3'
    assert represent_hostvars(dumper, hostvars2) == 'example: example\nexample3: example3\nexample2: example2:\n  example: example\n  example2: {}\n'


# Generated at 2022-06-23 05:33:31.786215
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    # Instantiate AnsibleDumper
    ad = AnsibleDumper(explicit_start=True, explicit_end=True,
                       default_flow_style=False)

    # Verify that ad.Dumper initialized
    assert isinstance(ad, SafeDumper)

# Generated at 2022-06-23 05:33:37.263032
# Unit test for function represent_unicode
def test_represent_unicode():
    from ansible.module_utils.six import PY3
    dumper = yaml.dumper.SafeDumper
    if PY3:
        template = "!ansible-unicode '%s'"
    else:
        template = "!ansible-unicode u'%s'"
    # Test unicode
    value = AnsibleUnicode(u'foo')
    assert dumper.represent_unicode(dumper, value) == template % u'foo'
    # Test strings
    value = AnsibleUnicode('foo')
    assert dumper.represent_unicode(dumper, value) == template % 'foo'

# Generated at 2022-06-23 05:33:39.620932
# Unit test for function represent_binary
def test_represent_binary():
    assert represent_binary(AnsibleDumper, b'foo') == u'tagged:yaml.org,2002:binary !binary >\n  Zm9v\n'



# Generated at 2022-06-23 05:33:47.364290
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():

    # Create an AnsibleVaultEncryptedUnicode object
    item = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256', '$ANSIBLE_VAULT;1.1;AES256')

    # Create AnsibleDumper object
    yaml_out = AnsibleDumper()

    # Encrypt an AnsibleVaultEncryptedUnicode object
    yaml_encoded = yaml_out.represent_vault_encrypted_unicode(item)

    assert yaml_encoded == "!vault |\n  $ANSIBLE_VAULT;1.1;AES256"

# Generated at 2022-06-23 05:33:58.585891
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = AnsibleVaultEncryptedUnicode('test', b'value')
    dumper = AnsibleDumper(width=float('inf'))

# Generated at 2022-06-23 05:34:06.281240
# Unit test for function represent_hostvars
def test_represent_hostvars():
    AnsibleDumper.add_representer(
        HostVars,
        represent_hostvars,
    )
    h = HostVars({"a": 1})
    h.add_new_var('b', 2)
    assert yaml.dump(h) == '{a: 1, b: 2}\n'

# Generated at 2022-06-23 05:34:08.085861
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('string'), Dumper=AnsibleDumper) == "string\n...\n"

# Generated at 2022-06-23 05:34:16.533090
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(AnsibleDumper, 'This is a string') == "!ansible_unsafe 'This is a string'"
    assert represent_unicode(AnsibleDumper, AnsibleUnsafeText(u'This is a string')) == "!ansible_unsafe 'This is a string'"
    assert represent_unicode(AnsibleDumper, AnsibleUnsafeBytes.unsafe_proxy(b'this is a string')) == "!ansible_unsafe this is a string"



# Generated at 2022-06-23 05:34:26.707743
# Unit test for function represent_unicode
def test_represent_unicode():
    sample_data = {
        'key_1': 'value_1',
        u'key_2': u'value_2',
        'key_3': u'value_3',
        u'key_4': 'value_4',
    }
    sample_dict = {
        'key_1': sample_data['key_1'],
        u'key_2': sample_data[u'key_2'],
        'key_3': sample_data['key_3'],
        u'key_4': sample_data[u'key_4'],
    }
    # Make sure keys and values are not treated as unicode
    assert yaml.dump(sample_data) == yaml.dump(sample_dict)



# Generated at 2022-06-23 05:34:36.998084
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib, VaultSecret
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    vault_secret = VaultSecret(b'$ANSIBLE_VAULT;1.1;AES256', b'12345678901234567890123456789012')
    vault = VaultLib(vault_secret)

# Generated at 2022-06-23 05:34:41.011814
# Unit test for function represent_binary
def test_represent_binary():
    string = b"some text"
    result = yaml.dump(string, Dumper=AnsibleDumper)
    assert result == "!!binary |\n  c29tZSB0ZXh0\n"


# Generated at 2022-06-23 05:34:51.328545
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    class TestRepresenter(SafeDumper):
        pass

    TestRepresenter.add_representer(
        AnsibleVaultEncryptedUnicode,
        represent_vault_encrypted_unicode,
    )


# Generated at 2022-06-23 05:34:54.780487
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper(allow_unicode=True)
    result = dumper.represent_binary(b'foo\x00bar')
    assert result == u'!!binary |\n  Zm9vAGJhcg==', result

# Generated at 2022-06-23 05:35:02.481616
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    with pytest.raises(TypeError):
        yaml.AnsibleDumper()
    with pytest.raises(AttributeError):
        yaml.AnsibleDumper('foo')
    assert yaml.AnsibleDumper(undefined=None) == yaml.SafeDumper(None)
    assert yaml.AnsibleDumper(undefined=None) == yaml.AnsibleDumper(None)
    assert yaml.AnsibleDumper(undefined=None) != yaml.SafeDumper()
    assert yaml.AnsibleDumper(undefined=None) != yaml.AnsibleDumper()

# Generated at 2022-06-23 05:35:04.742233
# Unit test for function represent_unicode
def test_represent_unicode():
    data = {'foo': u'bar'}
    assert yaml.dump(data, Dumper=AnsibleDumper) == '{foo: bar}\n'


# Generated at 2022-06-23 05:35:16.184355
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper(width=float('inf'))
    a = AnsibleVaultEncryptedUnicode(b'$ANSIBLE_VAULT;1.1;AES256;blah\n3456')
    b = AnsibleVaultEncryptedUnicode(b'$ANSIBLE_VAULT;1.1;AES256;blah\n345678901234567890123456789012')

# Generated at 2022-06-23 05:35:22.963176
# Unit test for function represent_unicode
def test_represent_unicode():
    from ansible.module_utils.six import PY3
    if not PY3:
        # PY2 has a bug in PyYaml that cause the unit test
        # to fail there.
        return
    dumper = yaml.SafeDumper
    ansible_unicode = AnsibleUnicode(u'\u2713')
    yaml_unicode = u'\u2713'
    assert yaml.dump(ansible_unicode, Dumper=dumper) == yaml.dump(yaml_unicode, Dumper=dumper)

# Generated at 2022-06-23 05:35:32.844238
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    import base64
    import binascii
    # 'Hello World' encrypted with password 'test'
    # (using ansible-vault encrypt_string)
    ciphertext = base64.b64decode(b'AQAAABAAAAB+1x2krh0q3PqBJAZjIuV7ALM1WKNuJ7YfXU6kxJxzH+')
    data = AnsibleVaultEncryptedUnicode(ciphertext)
    yaml.dump(data, Dumper=AnsibleDumper) == '!vault |\n          ' + binascii.hexlify(ciphertext).decode('ascii')



# Generated at 2022-06-23 05:35:38.060195
# Unit test for function represent_hostvars
def test_represent_hostvars():
    ansible_dumper = AnsibleDumper()
    hostvars_obj = {'foo': 'bar'}
    assert ansible_dumper.represent_dict(hostvars_obj) == ansible_dumper.represent_hostvars(hostvars_obj)

# Generated at 2022-06-23 05:35:40.861719
# Unit test for function represent_binary
def test_represent_binary():
    assert "{ foo: !!binary 'foo==' }" == yaml.safe_dump({'foo': 'foo'}, default_flow_style=False)

# Generated at 2022-06-23 05:35:41.833510
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-23 05:35:44.725117
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

    # Test for bytes
    res = dumper.represent_binary(None, b'foo')
    assert res == '!!binary |\n  Zm9v'



# Generated at 2022-06-23 05:35:55.381242
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    '''
    Ensure that AnsibleVaultEncryptedUnicode is correctly represented as safe string
    '''

    import io as io
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    ciphertext = VaultLib.encrypt(b'this is a test', b'pass')
    data = AnsibleVaultEncryptedUnicode(u'test', u'pass', ciphertext)

    out = io.StringIO()
    AnsibleDumper(stream=out).represent_data(data)


# Generated at 2022-06-23 05:36:01.802363
# Unit test for function represent_unicode
def test_represent_unicode():
    s = u'\u00a3'
    yaml_s = b'!!python/unicode "\\xa3"'

    assert yaml.dump(s) == yaml_s
    assert yaml.dump(AnsibleUnicode(s)) == yaml_s

    assert yaml.load(yaml_s) == s
    assert yaml.load(yaml_s) == AnsibleUnicode(s).__str__()



# Generated at 2022-06-23 05:36:04.694718
# Unit test for function represent_undefined
def test_represent_undefined():
    s = AnsibleDumper({'a': {'b': {'c': AnsibleUndefined}}}).serialize()
    assert s == '{a: {b: {c: {_fail_with_undefined_error: true}}}}\n'

# Generated at 2022-06-23 05:36:07.104717
# Unit test for function represent_binary
def test_represent_binary():
    data = b'123'
    assert AnsibleDumper.represent_binary(None, data) == '!!binary "MTIz"\n'

# Generated at 2022-06-23 05:36:11.920965
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(text_type(u'foo')) == dumper.represent_unicode(AnsibleUnicode(u'foo'))



# Generated at 2022-06-23 05:36:23.393996
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.module_utils.six import PY3
    if not PY3:
        from cStringIO import StringIO
    else:
        from io import StringIO

    data_hv = HostVars()
    data_hv._variable_manager = None
    data_hv.add_field('ansible_ssh_host', '127.0.0.1')
    data_hv.add_field('ansible_user', 'user')

    stream = StringIO()
    AnsibleDumper(stream=stream).represent(data_hv)
    assert stream.getvalue() == '\n'.join((
        'ansible_ssh_host: 127.0.0.1',
        'ansible_user: user',
        '',
    ))



# Generated at 2022-06-23 05:36:30.462026
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.module_utils.six import PY3
    from ansible.template import StrictUndefined
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    import sys

    if PY3:
        assert(repr(AnsibleUndefined()) == "Undefined")
        assert(text_type(AnsibleUndefined()) == "Undefined")
    else:
        assert(repr(AnsibleUndefined()) == "Undefined")
        assert(text_type(AnsibleUndefined()) == "Undefined")
        assert(binary_type(AnsibleUndefined()) == "Undefined")

    loader = DataLoader()

# Generated at 2022-06-23 05:36:35.566014
# Unit test for function represent_undefined
def test_represent_undefined():
    # Make sure a StrictUndefined from Jinja2 is
    # correctly represented by raise an error.
    from jinja2.runtime import StrictUndefined
    import pytest

    u = StrictUndefined()

    with pytest.raises(yaml.constructor.ConstructorError):
        yaml.safe_dump([u], Dumper=AnsibleDumper)

# Generated at 2022-06-23 05:36:45.769134
# Unit test for function represent_binary
def test_represent_binary():
    import os.path
    from ansible.parsing.yaml.objects import AnsibleUnsafeText, AnsibleUnsafeBytes

    def roundtrip(value):
        return yaml.safe_load(yaml.dump(value, Dumper=AnsibleDumper))

    # Empty bytes
    assert b'' == roundtrip(AnsibleUnsafeBytes(b''))
    assert b'' == roundtrip(AnsibleUnsafeText(''))

    # Bytes with multiple lines
    assert b'\n' * 100 == roundtrip(AnsibleUnsafeBytes(b'\n' * 100))
    assert b'\n' * 100 == roundtrip(AnsibleUnsafeText('\n' * 100))

    # Bytes with multiple lines and non-ASCII character

# Generated at 2022-06-23 05:36:46.821408
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper()

# Generated at 2022-06-23 05:36:49.925935
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    assert represent_vault_encrypted_unicode(None, AnsibleVaultEncryptedUnicode("hello")) == ("!vault |\n          aGVsbG8=\n")

# Generated at 2022-06-23 05:36:53.762703
# Unit test for function represent_unicode
def test_represent_unicode():
    u = u'\u263a'
    yaml_dump = yaml.dump({'a': u}, Dumper=AnsibleDumper, default_flow_style=False)
    assert yaml_dump == '{a: "\\u263a"}\n'

# Generated at 2022-06-23 05:36:58.183411
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper.represent_undefined(AnsibleDumper, AnsibleUndefined) == False
    assert AnsibleDumper.represent_undefined(AnsibleDumper, None) is None

# Generated at 2022-06-23 05:37:08.771950
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()
    data1 = AnsibleVaultEncryptedUnicode(value="data1")
    data2 = AnsibleVaultEncryptedUnicode(value="data2")
    datalist = [data1, data2]
    datadict = {'data1': data1, 'data2': data2}
    res1 = dumper.represent_scalar(u'!vault', data1._ciphertext.decode(), style='|')
    res2 = dumper.represent_scalar(u'!vault', data2._ciphertext.decode(), style='|')
    res3 = dumper.represent_list([data1, data2])
    res4 = dumper.represent_dict(datadict)


# Generated at 2022-06-23 05:37:11.260487
# Unit test for function represent_hostvars
def test_represent_hostvars():
    yaml.dump(dict(a='1', b='2', c='3'), Dumper=AnsibleDumper)



# Generated at 2022-06-23 05:37:17.001661
# Unit test for function represent_unicode
def test_represent_unicode():
    u = AnsibleUnicode(1)
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u) == dumper.represent_unicode(u.__unicode__())
    assert dumper.represent_unicode(u) == (yaml.representer.SafeRepresenter.represent_str(dumper, text_type(1)))

# Generated at 2022-06-23 05:37:20.037272
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    dumper.add_representer(
        AnsibleUndefined,
        represent_undefined,
    )
    assert yaml.dump(AnsibleUndefined(), Dumper=dumper) == ''

# Generated at 2022-06-23 05:37:31.234409
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

# Generated at 2022-06-23 05:37:36.721492
# Unit test for function represent_undefined
def test_represent_undefined():
    data = AnsibleUndefined()

    dumper = AnsibleDumper()
    try:
        dumper.represent_data(data)
        assert False, "should have raised UndefinedError"
    except yaml.representer.RepresenterError:
        assert True
        pass

# Generated at 2022-06-23 05:37:39.841551
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    undefined = AnsibleUndefined("Test")
    assert repr(undefined) == repr(dumper.represent_undefined(dumper, undefined))

# Generated at 2022-06-23 05:37:48.439796
# Unit test for function represent_unicode
def test_represent_unicode():
    # this is a string that is unicode in Python2 and str in Python3
    utf8_str = u'\u03bb'
    yaml_string = yaml.dump(utf8_str, Dumper=AnsibleDumper, encoding=None)
    if isinstance(utf8_str, text_type):
        assert yaml_string == u"{0}\n".format(utf8_str)
    elif isinstance(utf8_str, binary_type):
        assert yaml_string == u"{0}\n".format(utf8_str.decode('utf8'))
    else:
        raise AssertionError("type error utf8_str is {0}".format(utf8_str))


# Generated at 2022-06-23 05:37:53.652233
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumpers = AnsibleDumper
    vars = HostVars(
        hostname='localhost',
        variables=dict(var1='something', var2=['first', 'second'])
    )
    output = dumpers.represent_hostvars(dumpers, vars)

    assert 'var1: something\nvar2:\n- first\n- second' in output



# Generated at 2022-06-23 05:38:04.086513
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib

    vault = VaultLib([])
    result = vault.encrypt(b'foo')
    rep = yaml.representer.SafeRepresenter()

# Generated at 2022-06-23 05:38:05.207062
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper(None), yaml.dumper.Dumper)

# Generated at 2022-06-23 05:38:10.079623
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    dumper.add_representer(
        HostVars,
        represent_hostvars,
    )

    assert dumper.represent_hostvars(HostVars('foo', {'bar': 'baz'})) == dumper.represent_dict({'bar': 'baz'})
    assert dumper.represent_hostvars(HostVars('foo', {'bar': 'baz'})) == dumper.represent_dict({'bar': 'baz'})

# Generated at 2022-06-23 05:38:16.476421
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(dict(unicode=AnsibleUnicode('test'))) == '{unicode: test}\n'
    assert yaml.dump(dict(unsafetext=AnsibleUnsafeText('test'))) == '{unsafetext: test}\n'
    assert yaml.dump(dict(unsafebytes=AnsibleUnsafeBytes('test'))) == "{unsafebytes: !!binary |\n  dGVzdA==}\n"

# Generated at 2022-06-23 05:38:20.579252
# Unit test for function represent_binary
def test_represent_binary():
    assert(yaml.safe_load("!!binary 'test'\n") == b'test')
    assert(yaml.safe_load("!!binary |\n"
                          "  dGVzdAo=\n") == b'test\n')

# Generated at 2022-06-23 05:38:25.007085
# Unit test for function represent_undefined
def test_represent_undefined():
    # Create a representer instance.
    representer = AnsibleDumper()
    # Create undefined variable.
    undefined = AnsibleUndefined('{{ var }}')

    assert bool(undefined) == True
    assert str(undefined) == '{{ var }}'
    assert bool(representer.represent_undefined(undefined)) == True
    # assert representer.represent_undefined(undefined) == '{{ var }}'

# Generated at 2022-06-23 05:38:34.743850
# Unit test for function represent_hostvars
def test_represent_hostvars():
    import types
    from ansible.parsing.vault import VaultLib

    yaml.add_representer(types.FunctionType, yaml.representer.SafeRepresenter.represent_str)

    # Test representer for HostVars object
    data1 = HostVars({'test_key': 'test_value'})
    data1_expected = "test_key: test_value\n"
    result1 = yaml.dump(data1, Dumper=AnsibleDumper, default_flow_style=False)
    assert result1 == data1_expected

    # Test representer for AnsibleVaultEncryptedUnicode object
    vault = VaultLib([])
    vault_text = vault.encrypt('test_vault_value')
    data2 = AnsibleVaultEncryptedUnicode(vault_text)

# Generated at 2022-06-23 05:38:39.212188
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = yaml.dump({'hostvars': HostVars({"foo": "bar", "baz": "faz"})}, Dumper=AnsibleDumper)
    assert data == u'{hostvars: {baz: faz, foo: bar}}\n'



# Generated at 2022-06-23 05:38:47.792258
# Unit test for function represent_binary
def test_represent_binary():
    data = b'\xe5\x93\x88\xe5\x91\x98\xe6\x82\xa8\xe5\xa5\xbd\xef\xbc\x8c\xe4\xb8\x96\xe7\x95\x8c'
    result = yaml.dump(data, Dumper=AnsibleDumper)
    assert result == '!!binary |\n  5oeW5Yqx5ZCN44CC5Lya5aW9\n'



# Generated at 2022-06-23 05:38:50.797186
# Unit test for function represent_hostvars
def test_represent_hostvars():
    h = HostVars()
    h.vars = {"a": "1"}
    assert yaml.dump(h, Dumper=AnsibleDumper) == "a: 1\n"



# Generated at 2022-06-23 05:38:51.398038
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper

# Generated at 2022-06-23 05:38:57.359852
# Unit test for function represent_unicode
def test_represent_unicode():
    input_data = u'data'
    expected = yaml.representer.SafeRepresenter.represent_unicode(None, input_data)
    actual = represent_unicode(None, input_data)
    assert expected == actual
    input_data = u'b\xe5\xf8\xe5'
    expected = yaml.representer.SafeRepresenter.represent_unicode(None, input_data)
    actual = represent_unicode(None, input_data)
    assert expected == actual

# Generated at 2022-06-23 05:38:59.880912
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    if AnsibleDumper() is None:
        raise AssertionError('Test AnsibleDumper constructor failed')

# Generated at 2022-06-23 05:39:10.548279
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Store the data as a normal unicode string
    text = u'0123456789ABCDEF'
    encrypted_text = AnsibleVaultEncryptedUnicode(text)

    # Then we want to convert it to a yaml string
    key = u'1234567890123456'  # Not really a valid encryption key here
    yaml_string = yaml.dump(
        encrypted_text,
        Dumper=yaml.SafeDumper,
        default_flow_style=False,
        width=255,
    )

    # Then we want to convert that yaml string back into a AnsibleVaultEncryptedUnicode
    encrypted_text_from_yaml = yaml.load(
        yaml_string,
        Loader=yaml.SafeLoader,
    )

    # Then we want to validate that

# Generated at 2022-06-23 05:39:21.630752
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.hostvars import HostVars
    doc = AnsibleMapping()
    doc.update({'hostvars': HostVars()})
    content = yaml.dump(doc, Dumper=AnsibleDumper)
    assert content == 'hostvars: {}\n'

    doc = AnsibleMapping()
    doc.update({'hostvars': HostVars(dict(key='value1'))})
    content = yaml.dump(doc, Dumper=AnsibleDumper)
    assert content == "hostvars: {key: value1}\n"

    doc = AnsibleMapping()
    doc.update({'hostvars': HostVars(dict(key='value2'))})
   

# Generated at 2022-06-23 05:39:25.439634
# Unit test for function represent_hostvars
def test_represent_hostvars():
    '''
    Test that AnsibleDumper.represent_hostvars is a function.
    '''

    assert callable(AnsibleDumper.represent_hostvars)

# Generated at 2022-06-23 05:39:26.659228
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper



# Generated at 2022-06-23 05:39:27.964506
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
        dumper = AnsibleDumper()
        assert dumper

# Generated at 2022-06-23 05:39:31.063018
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    assert represent_vault_encrypted_unicode(
        AnsibleDumper,
        AnsibleVaultEncryptedUnicode(b'data')
    ) == u'!vault |\n  data'

# Generated at 2022-06-23 05:39:41.332177
# Unit test for function represent_binary
def test_represent_binary():
    dumper = yaml.SafeDumper
    data = u'\u2605'

    assert yaml.representer.SafeRepresenter.represent_binary(dumper, binary_type(data)) == '!!binary "4pi="'

    dumper.add_representer(
        AnsibleUnsafeText,
        represent_unicode,
    )

    assert yaml.representer.SafeRepresenter.represent_binary(dumper, binary_type(data)) == '!!binary "4pi="'

    dumper.add_representer(
        AnsibleUnsafeBytes,
        represent_binary,
    )

    assert yaml.representer.SafeRepresenter.represent_binary(dumper, binary_type(data)) == '!!binary "4pi="'

# Generated at 2022-06-23 05:39:44.083555
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    # test that the constructor of AnsibleDumper can be called without arguments
    assert AnsibleDumper()

if __name__ == "__main__":
    test_AnsibleDumper()

# Generated at 2022-06-23 05:39:49.667115
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = [{'hostvars': {'foo': 'bar'}}]

    # The original code was trying to do a simple return of _actual_data
    # but that fails when the data is empty (no {}), because then it returns
    # None.  We need to give it a value.
    hostvars = HostVars(data)
    result = represent_hostvars(AnsibleDumper.add_representer, hostvars)
    assert result == {'hostvars': hostvars._actual_data}

# Generated at 2022-06-23 05:39:53.210382
# Unit test for function represent_binary
def test_represent_binary():
    test_input = b'some text'
    yaml_dumper = AnsibleDumper
    yaml_output = yaml.dumps(test_input, Dumper=yaml_dumper)
    assert yaml_output == '!!binary |\n  c29tZSB0ZXh0\n'


# Generated at 2022-06-23 05:39:54.682531
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper.add_representer, object)

# Generated at 2022-06-23 05:39:57.300868
# Unit test for function represent_unicode
def test_represent_unicode():
    yaml.dump(AnsibleUnicode('some string'), Dumper=AnsibleDumper)



# Generated at 2022-06-23 05:40:02.167202
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = {
        'hostvars': {'host1': {'foo': 'foo', 'bar': 'bar'}, 'host2': {'foo': 'foo'}},
    }
    AnsibleDumper.represent_hostvars(AnsibleDumper, data)

# Generated at 2022-06-23 05:40:12.921123
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vault = VaultEditor(b'$ANSIBLE_VAULT;1.1;AES256')
    plaintext_data = text_type('TEST: data')
    encrypted_data = vault.encrypt(plaintext_data)
    data = AnsibleVaultEncryptedUnicode(value=encrypted_data)
    yaml_representation = yaml.dump(data, Dumper=AnsibleDumper)
    assert data._ciphertext in yaml_representation
    assert plaintext_data not in yaml_representation


# Generated at 2022-06-23 05:40:16.525751
# Unit test for function represent_undefined
def test_represent_undefined():
    # Here bool will ensure _fail_with_undefined_error happens
    # if the value is Undefined.
    # This happens because Jinja sets __bool__ on StrictUndefined
    assert bool(AnsibleUndefined())



# Generated at 2022-06-23 05:40:21.666709
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    ae = AnsibleVaultEncryptedUnicode('test')
    b = AnsibleDumper.represent_vault_encrypted_unicode(a=None, data=ae)
    assert b == u'!vault |\n%s' % ae.get_decrypted_text()

# Generated at 2022-06-23 05:40:23.337721
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper, type)



# Generated at 2022-06-23 05:40:29.246445
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    assert(represent_vault_encrypted_unicode(None, AnsibleVaultEncryptedUnicode('test')) == u"!vault |\n          dGVzdA==\n")


# Generated at 2022-06-23 05:40:36.263401
# Unit test for function represent_undefined
def test_represent_undefined():
    representer = AnsibleDumper()
    repr_undef = representer.represent_undefined(AnsibleUndefined(fail_on_undefined=True))
    assert repr_undef == False, 'Did not get False from represent_undefined with fail_on_undefined=True'
    repr_undef = representer.represent_undefined(AnsibleUndefined(fail_on_undefined=False))
    assert repr_undef == True, 'Did not get True from represent_undefined with fail_on_undefined=False'

# Generated at 2022-06-23 05:40:38.144572
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert(dumper.represent_undefined(None) is True)

# Generated at 2022-06-23 05:40:47.648850
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib()
    vault_secret = vault.encrypt(b'abcdef')
    vault_secret_unicode = AnsibleVaultEncryptedUnicode(vault_secret)


# Generated at 2022-06-23 05:40:56.363314
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-23 05:41:05.781315
# Unit test for function represent_hostvars
def test_represent_hostvars():
    '''
    A unit test for the function represent_hostvars
    '''
    from ansible.vars import VariableManager
    vm = VariableManager()

    # Test one level
    data = {u'demo1': u'demo1', u'level1': {u'demo2': u'demo2', u'demo3': u'demo3'}}
    hostvars1 = HostVars(u'group1', vm, data)

    # Test two level
    data = {u'demo1': u'demo1',
            u'level1': {u'demo2': u'demo2', u'demo3': u'demo3',
                        u'level2': {u'demo4': u'demo4', u'demo5': u'demo5'}}}

# Generated at 2022-06-23 05:41:09.418000
# Unit test for function represent_hostvars
def test_represent_hostvars():

    class Data(object):
        foo = 'bar'

    data = Data()

    d = AnsibleDumper()
    d.saferepr = lambda obj: text_type(obj)
    output = d.represent_hostvars(data)
    assert output == '{foo: bar}'

# Generated at 2022-06-23 05:41:09.944854
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert(True)

# Generated at 2022-06-23 05:41:19.277512
# Unit test for function represent_hostvars
def test_represent_hostvars():
    import json
    data = text_type(json.dumps(dict(hostvars=dict(
        host1=dict(name1='value1', name2='value2'),
        host2=dict(name1='value1', name2='value2'))),
                        sort_keys=True, indent=4))
    d = AnsibleDumper(indent=2)
    hostvars = HostVars(dict(
        host1=dict(name1='value1', name2='value2'),
        host2=dict(name1='value1', name2='value2')))
    result = d.represent_hostvars(hostvars)
    assert data == text_type(result)

# Generated at 2022-06-23 05:41:23.708299
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    ansible_string = AnsibleUnicode('{"ansible": 2.0}')
    dumped_string = u"{'ansible': 2.0}\n"
    assert dumper.represent_unicode(ansible_string) is dumped_string



# Generated at 2022-06-23 05:41:29.864530
# Unit test for function represent_unicode
def test_represent_unicode():
    yaml_str = '''{a: '1'}'''
    data = yaml.load(yaml_str)
    dumper = AnsibleDumper()
    result = yaml.dump(data, Dumper=AnsibleDumper, default_flow_style=False)
    assert result == "{a: '1'}\n"

# Generated at 2022-06-23 05:41:41.172216
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = yaml.Dumper
    data = '$ANSIBLE_VAULT;1.1;AES256;ansible\n3362386131633065663261623663356139663136323962333932616134363761313031306436353734\n30643862316664386230643366396330663064663236376361313437643834336333643336136343737\n323464663133396239326262646161336134623365656564333665663132346265333833663065326433\n63333134613339666238636162393564636336333436656531323235666436623838653830'

# Generated at 2022-06-23 05:41:49.056225
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    yaml_obj1 = AnsibleDumper(indent=2, width=50, default_flow_style=True)
    yaml_obj2 = AnsibleDumper.__new__(AnsibleDumper)
    yaml_obj2.__init__(indent=4, width=40, default_flow_style=False)
    assert (yaml_obj1.indent == 2 and yaml_obj1.width == 50 and yaml_obj1.default_flow_style)
    assert (yaml_obj2.indent == 4 and yaml_obj2.width == 40 and not yaml_obj2.default_flow_style)

# Generated at 2022-06-23 05:41:54.192308
# Unit test for function represent_binary
def test_represent_binary():
    from ansible.module_utils.common.yaml import AnsibleDumper

    dumper = AnsibleDumper()
    data = 'A\tB\nC\rD\u0002E\u0012F'

    assert dumper.represent_binary(data) == "{!!binary}%s" % data.encode('base64').strip()