

# Generated at 2022-06-23 05:31:54.203982
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    dumper.open()
    result = dumper.represent_hostvars({'foo': 'bar'})
    assert result == '{foo: bar}\n'

# Generated at 2022-06-23 05:32:00.012874
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper
    assert dumper.__name__ == 'AnsibleDumper'
    assert isinstance(dumper, SafeDumper)
    assert dumper.represent_list is yaml.representer.SafeRepresenter.represent_list
    assert dumper.represent_dict is yaml.representer.SafeRepresenter.represent_dict
    assert dumper.represent_str is yaml.representer.SafeRepresenter.represent_str
    assert dumper.represent_binary is yaml.representer.SafeRepresenter.represent_binary

# Generated at 2022-06-23 05:32:08.459337
# Unit test for function represent_binary
def test_represent_binary():
    # Test for representation of string util
    # - simple binary data
    # - unicode in binary data
    # - no changes required when data is unicode
    data = {"key1": "this is binary data"}
    result = yaml.dump(data, Dumper=AnsibleDumper)
    assert result == "key1: !!binary |\n  dGhpcyBpcyBiaW5hcnkgZGF0YQo=\n"
    data = {"key1": "this is unicode chars in binary data: \u263A"}
    result = yaml.dump(data, Dumper=AnsibleDumper)

# Generated at 2022-06-23 05:32:17.037857
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

# Generated at 2022-06-23 05:32:21.155984
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper(default_flow_style=False)
    output = dumper.represent_unicode(u'foo')
    assert output == u'test_represent_unicode: !!python/unicode ''foo\n'
    assert isinstance(output, text_type)



# Generated at 2022-06-23 05:32:29.819425
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hv = HostVars(None)
    hv.set_variable('a', 10)
    hv.set_variable('b', 'ansible')
    hv.set_variable('c', [1, 2, 3])
    hv.set_variable('d', {'one': 1})
    hv.set_variable('e', AnsibleUnicode('unicode'))
    hv.set_variable('f', AnsibleUnsafeText('unsafe_text'))
    hv.set_variable('g', AnsibleUnsafeBytes('unsafe_bytes'))

# Generated at 2022-06-23 05:32:32.454844
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars import HostVars
    assert represent_hostvars(AnsibleDumper, HostVars()) == {}


# Generated at 2022-06-23 05:32:37.483117
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = AnsibleVaultEncryptedUnicode(b'1234567890')
    assert yaml.dump(data, Dumper=AnsibleDumper) == '!vault |\n          MTIzNDU2Nzg5MAo=\n'


# Generated at 2022-06-23 05:32:39.637718
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dump = yaml.dump(HostVars(dict(A="B")), Dumper=AnsibleDumper)
    assert("A: B" in dump)

# Generated at 2022-06-23 05:32:42.271033
# Unit test for function represent_hostvars
def test_represent_hostvars():

    data = HostVars(dict(ansible_user='foo'))

    assert dict(data) == dict(ansible_user='foo')



# Generated at 2022-06-23 05:32:49.012465
# Unit test for function represent_binary
def test_represent_binary():
    # Make sure it works with both bytes and text
    assert yaml.dump(b'\xff').startswith('!!binary ')
    assert yaml.dump(u'\u0100').startswith('!!binary ')

    # Make sure it doesn't double-encode, this
    # is the situation we have in templates, where
    # binary content comes in as a text type.
    assert b'\xff' in yaml.dump(u'\xff')



# Generated at 2022-06-23 05:32:50.865455
# Unit test for function represent_binary
def test_represent_binary():
    yaml.dump(b'foo', Dumper=AnsibleDumper, default_flow_style=None)



# Generated at 2022-06-23 05:32:53.538685
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert represent_hostvars(None, {'key1': 'val1'}) == {'key1': 'val1'}



# Generated at 2022-06-23 05:32:56.731923
# Unit test for function represent_binary
def test_represent_binary():
    assert AnsibleDumper.represent_binary(b'ascii_bytes') == ('!!binary |-\n'
                                                              '  YXNjaWlfYnl0ZXM=\n')

# Generated at 2022-06-23 05:33:00.966030
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    bin_data = b'hello world'
    assert dumper.represent_binary(bin_data) == u'!binary |-\n  aGVsbG8gd29ybGQ=\n'

# Generated at 2022-06-23 05:33:10.078655
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Fake some data
    my_data = AnsibleVaultEncryptedUnicode(b'$ANSIBLE_VAULT;7.2;AES256;abc\nabcdefghijklmnopqrstuvwxyz1234567890\n')

    # Call the function
    result = represent_vault_encrypted_unicode(None, my_data)

    # Check the results
    assert isinstance(result, text_type)
    assert result == '!vault |\n  $ANSIBLE_VAULT;7.2;AES256;abc\n  abcdefghijklmnopqrstuvwxyz1234567890\n'



# Generated at 2022-06-23 05:33:16.184130
# Unit test for function represent_hostvars
def test_represent_hostvars():
    import io

    mystream = io.BytesIO()

    data = {'a': 'simple', 'dict': 'of', 'host': 'vars'}

    mydumper = AnsibleDumper(mystream)
    mydumper.open()
    mydumper.represent(HostVars(data))
    mydumper.close()

    mystream.seek(0)
    test_data = yaml.safe_load(mystream)
    assert test_data == {'a': 'simple', 'dict': 'of', 'host': 'vars'}



# Generated at 2022-06-23 05:33:22.335594
# Unit test for function represent_undefined
def test_represent_undefined():
    data = AnsibleUndefined('{{undefined_var}}')
    ansible_dumper = AnsibleDumper()
    ansible_dumper.represent_dict({'test': data})

    data = AnsibleUndefined('{{undefined_var}}', '{{undefined_var}}')
    ansible_dumper = AnsibleDumper()
    ansible_dumper.represent_dict({'test': data})



# Generated at 2022-06-23 05:33:24.281804
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    test_obj = AnsibleDumper()
    assert test_obj != None

# Generated at 2022-06-23 05:33:26.569435
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, AnsibleUnicode(u'foo')) == u'foo'

# Generated at 2022-06-23 05:33:27.680250
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper is not None

# Generated at 2022-06-23 05:33:30.531101
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.safe_dump(AnsibleUndefined(), default_flow_style=False, Dumper=AnsibleDumper) == ''

# Generated at 2022-06-23 05:33:33.743858
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper, type)
    assert issubclass(AnsibleDumper, yaml.representer.SafeRepresenter)



# Generated at 2022-06-23 05:33:37.257506
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = yaml.SafeDumper
    dumper.add_representer(
        AnsibleUndefined,
        represent_undefined
    )
    assert dumper.represent_undefined(dumper, AnsibleUndefined()) == False

# Generated at 2022-06-23 05:33:40.411581
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper(None)
    result = dumper.represent_binary(b'123')
    assert result == "!!binary |\n  MTIz"
    result = dumper.represent_binary(b'')
    assert result == "!!binary |\n  "

# Generated at 2022-06-23 05:33:45.051057
# Unit test for function represent_binary
def test_represent_binary():
    dumper = yaml.SafeDumper(allow_unicode=True)
    dumper.add_representer(bytes, represent_binary)
    results = yaml.safe_dump({"test": b"test"}, stream=None, Dumper=dumper)
    assert(results == 'test: !!binary "dGVzdA==\n"\n')

# Generated at 2022-06-23 05:33:52.232402
# Unit test for function represent_binary
def test_represent_binary():

    # Create instance of AnsibleDumper class
    dumper = AnsibleDumper()

    # Unit test with good input
    data = {b"a": b"b"}
    exp_result = b"{a: b}\n"
    assert dumper.represent_dict(data) == exp_result

    # Unit test with bad input
    data = {u"a": u"b"}
    exp_result = b"{a: b}\n"
    assert dumper.represent_dict(data) == exp_result

# Generated at 2022-06-23 05:33:55.885965
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # would normally be VarsWithSources
    hv = HostVars(HostVarsVars())
    dumper = AnsibleDumper
    result = dumper.represent(hv)
    assert result[0][0] == '{'

# Generated at 2022-06-23 05:34:04.415255
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = {
        'first_variable': 1,
        'second_variable': 2,
    }

    expected = yaml.dump(data, Dumper=yaml.Dumper)

    d = AnsibleDumper()
    result = d.represent_hostvars(data)
    assert result == expected



# Generated at 2022-06-23 05:34:07.183026
# Unit test for function represent_binary
def test_represent_binary():
    dump_data = lambda data: yaml.dump(data, Dumper=AnsibleDumper)
    assert dump_data(b"abc\x00") == "!!binary |\n  YWJjAA==\n"

# Generated at 2022-06-23 05:34:10.619551
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode(u'{}{}'.format(u'\u2713', u'\u2713')), Dumper=AnsibleDumper, allow_unicode=True) == u'\u2713\u2713\n...\n'



# Generated at 2022-06-23 05:34:17.643293
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-23 05:34:21.130262
# Unit test for function represent_binary
def test_represent_binary():
    # On Python 3, represent_binary() is not used as str == binary_type
    if yaml.version_info[0] >= 3:
        return

    # Create a yaml.dumper.SafeDumper()
    safe_dumper = yaml.SafeDumper

    # Create a test string
    binary_value = b'\xFF'

    # Call represent_binary()
    result = safe_dumper.represent_binary(safe_dumper, binary_value)

    # Check the result
    assert result.startswith("!!binary")

# Generated at 2022-06-23 05:34:24.232901
# Unit test for function represent_binary
def test_represent_binary():
    d = AnsibleDumper()
    assert d.represent_binary(b'blah') == yaml.representer.SafeRepresenter.represent_binary(d, b'blah')



# Generated at 2022-06-23 05:34:29.050106
# Unit test for function represent_undefined
def test_represent_undefined():
    d = AnsibleDumper(None, False, None, None)
    # This will not throw an exception because we've allowed
    # undefined to be rendered as an empty string
    assert d.represent_undefined(AnsibleUndefined(obj='foo')) == ''

# Generated at 2022-06-23 05:34:30.068164
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper(None), AnsibleDumper)

# Generated at 2022-06-23 05:34:34.225570
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    data = vault.encrypt('password', 'Hello world!')
    represent_vault_encrypted_unicode(None, data)


if __name__ == "__main__":
    test_represent_vault_encrypted_unicode()

# Generated at 2022-06-23 05:34:34.809000
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    pass

# Generated at 2022-06-23 05:34:37.320003
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper(), AnsibleDumper)


# Unit test of representer method add_representer

# Generated at 2022-06-23 05:34:43.366930
# Unit test for function represent_hostvars
def test_represent_hostvars():
    '''
    Test function represent_hostvars
    '''
    data = dict(foo='bar', baz='qux')
    hv = HostVars(data)
    dumper = AnsibleDumper()
    value = dumper.represent_hostvars(hv)
    assert value == dumper.represent_dict(data)



# Generated at 2022-06-23 05:34:45.963300
# Unit test for function represent_undefined
def test_represent_undefined():
    # If represent_undefined was not defined, then this would fail with an exception
    assert type(yaml.dump(AnsibleUndefined('foo'))) == str

# Generated at 2022-06-23 05:34:56.917177
# Unit test for function represent_hostvars
def test_represent_hostvars():

    from ansible.inventory.host import Host
    from ansible.parsing.yaml.loader import AnsibleLoader

    h = Host('foohost')
    h.vars = {'a': 10}
    h.groups = [
        {'a': 1, 'b': 2},
        {'c': 3, 'b': 4}
    ]

    data = """
    host_var1: foo
    host_var2: {foo: bar}
    host_var3: [foo, bar]
    """
    h.vars = AnsibleLoader(data).get_single_data()

    d = AnsibleDumper()
    hv = HostVars.from_host(h)
    result = d.represent_hostvars(hv)


# Generated at 2022-06-23 05:35:06.817129
# Unit test for function represent_undefined
def test_represent_undefined():
    def test_loader(data, loader=yaml.SafeLoader):
        return yaml.load(data, loader=loader)

    # Simulating a dict
    dumper = AnsibleDumper(dict)
    dumped = yaml.dump(dict(foo='{{ bar }}'), Dumper=dumper)

    # The default loader will return a string with {{bar}} which is not
    # the same as undefined
    assert test_loader(dumped)['foo'] == '{{ bar }}', 'String should be present'

    # However overriding the loader will raise an error
    assert test_loader(dumped, AnsibleDumper)['foo'] == '{{ bar }}', 'String should be present'

    # Simulating a dict
    dumper = AnsibleDumper(list)

# Generated at 2022-06-23 05:35:09.808765
# Unit test for function represent_binary
def test_represent_binary():
    assert represent_binary(AnsibleDumper, b"\x00\x01\x02\x03") == "!!binary |\n  AAAECAw==\n"



# Generated at 2022-06-23 05:35:14.284944
# Unit test for function represent_unicode
def test_represent_unicode():
    test_data = AnsibleUnicode('\xa7')
    test_data = test_data.encode('unicode_escape')
    assert test_data == b'\\xa7'
    test_data = test_data.decode('unicode-escape')
    assert test_data == u'\xa7'



# Generated at 2022-06-23 05:35:21.534483
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    class data(object):
        def __init__(self, ciphertext):
            self._ciphertext = ciphertext
    encrypted = data('$ANSIBLE_VAULT;9.9;MYVAULT\nblablablablablablablablablabla==\n')
    expected = "!vault |\n  $ANSIBLE_VAULT;9.9;MYVAULT\n  blablablablablablablablablabla==\n"
    result = yaml.dump(encrypted, Dumper=AnsibleDumper)

    assert result == expected

# Generated at 2022-06-23 05:35:26.519504
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = HostVars(hostvars={"foo": "bar"})
    dumper = AnsibleDumper()
    result = dumper.represent_hostvars(data)
    assert result == dumper.represent_dict({"foo": "bar"})



# Generated at 2022-06-23 05:35:31.676409
# Unit test for function represent_undefined
def test_represent_undefined():

    dumper = AnsibleDumper()
    data = AnsibleUndefined('foo')

    try:
        dumper.represent_data(data)
        assert False
    except AnsibleUndefined as e:
        assert data.error_message == e.args[0]

    # this should not raise an error
    data = 'foo'
    dumper.represent_data(data)

# Generated at 2022-06-23 05:35:36.551267
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = {'vars': {'foo': 'bar', 'bam': 'boo'}}

    hv = HostVars(data)

    s = yaml.serialize(hv)

    assert type(s) == text_type
    assert 'foo' in s
    assert 'bam' in s
    assert 'bar' in s
    assert 'boo' in s

# Generated at 2022-06-23 05:35:41.541404
# Unit test for function represent_unicode
def test_represent_unicode():
    output = yaml.dump(AnsibleUnicode('test'), Dumper=AnsibleDumper, default_flow_style=False)
    assert output == "!!python/unicode 'test'\n"



# Generated at 2022-06-23 05:35:53.052871
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader(), sources=['localhost,'])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    variable_manager.extra_vars = {'foo': 'bar'}
    host = inventory.get_host('localhost')
    results = host.get_vars()


# Generated at 2022-06-23 05:35:58.562133
# Unit test for function represent_undefined
def test_represent_undefined():
    '''
    Check if yaml.dump(AnsibleUndefined()) throws an exception
    :return:
    '''
    # AnsibleDumper.add_representer(AnsibleUndefined, represent_undefined)
    assert(yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper) == '')



# Generated at 2022-06-23 05:36:08.667137
# Unit test for function represent_binary
def test_represent_binary():
    # Create a class instance to use for testing
    # This is what get_yaml_loader() returns
    dumper = AnsibleDumper()

    # Create a bytes object containing only 7-bit ASCII characters
    test_bytes = b'this is a 7-bit ASCII string'

    # Expect that represent_binary converts the 7-bit ASCII string to a
    # string, that is, it uses SafeDumper.represent_str
    assert dumper.represent_binary(test_bytes) == dumper.represent_str(text_type(test_bytes))

    # Create a binary string
    test_binary = b'this is a binary string \x00 with null bytes \x02 and other stuff'

    # Expect that represent_binary converts the binary string to a
    # string that has the bytes encoded in base64, that is, it uses
    # SafeD

# Generated at 2022-06-23 05:36:10.682315
# Unit test for function represent_undefined
def test_represent_undefined():
    yaml.dump(AnsibleUndefined, Dumper=AnsibleDumper)

# Generated at 2022-06-23 05:36:16.986803
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert 'var1: value1' not in yaml.dump(HostVars(var1='value1', var2='value2'), Dumper=AnsibleDumper)
    assert 'var2: value2' not in yaml.dump(HostVars(var1='value1', var2='value2'), Dumper=AnsibleDumper)

# Generated at 2022-06-23 05:36:20.343255
# Unit test for function represent_binary
def test_represent_binary():
    actual = AnsibleDumper().represent_binary(b'\x44\x65\x76\x49\x64')
    assert actual == 'DEviD\n...\n'

# Generated at 2022-06-23 05:36:25.473383
# Unit test for function represent_undefined
def test_represent_undefined():
    def test_represent_undefined():
        dumper = AnsibleDumper()
        try:
            dumper.represent_data(AnsibleUndefined())
        except yaml.YAMLError as e:
            assert "does not have a value defined" in str(e)
        else:
            assert False, "Expected a yaml.YAMLError"

# Generated at 2022-06-23 05:36:32.112383
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    result = dumper.represent_undefined(AnsibleUndefined)
    assert result is False


for cls in (yaml.Dumper, yaml.SafeDumper):
    # seems to be necessary for the AnsibleUndefined type
    cls.add_multi_representer(
        AnsibleUndefined,
        lambda dumper, data: yaml.ScalarNode(tag=u'tag:yaml.org,2002:null', value=""),
    )

# Generated at 2022-06-23 05:36:43.163062
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-23 05:36:49.351113
# Unit test for function represent_unicode
def test_represent_unicode():
    class FakeYamlDumper:
        def represent_str(self, data):
            return [u'%s' % data]

    assert represent_unicode(FakeYamlDumper(), u'foo') == [u'foo']
    assert represent_unicode(FakeYamlDumper(), u'foo\nbar') == [u'foo\nbar']



# Generated at 2022-06-23 05:36:55.115313
# Unit test for function represent_unicode
def test_represent_unicode():
    '''
    AnsibleDumper should use represent_unicode for AnsibleUnicode objects
    '''
    obj = AnsibleUnicode('abc')

    dumper = AnsibleDumper()
    result = dumper.represent_data(obj)

    assert str(result) == 'abc'
    assert yaml.dump(obj, Dumper=AnsibleDumper) == 'abc\n...\n'



# Generated at 2022-06-23 05:37:00.642059
# Unit test for function represent_hostvars
def test_represent_hostvars():
    ''' unit test for represent_hostvars'''
    output = yaml.dump(HostVars('test', dict(test=dict(test='test'))), Dumper=AnsibleDumper)
    assert output == ("---\n"
                      "test:\n"
                      "  test: test\n")



# Generated at 2022-06-23 05:37:05.611128
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.safe_dump('abc') == yaml.dump(u'abc', Dumper=AnsibleDumper)
    assert yaml.safe_dump('abc'.encode()) == yaml.dump(u'abc'.encode(), Dumper=AnsibleDumper)



# Generated at 2022-06-23 05:37:08.003833
# Unit test for function represent_hostvars
def test_represent_hostvars():
    d = AnsibleDumper()
    assert d.represent_data(HostVars({'a': 'b'})) == '{a: b}\n...\n'



# Generated at 2022-06-23 05:37:09.538314
# Unit test for function represent_undefined
def test_represent_undefined():
    undefined = AnsibleUndefined('testing')
    assert represent_undefined(None, undefined) == False

# Generated at 2022-06-23 05:37:20.467118
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.compat.tests.mock import patch
    vault_password = '$ANSIBLE_VAULT;1.2;AES256;test_password'

# Generated at 2022-06-23 05:37:23.823530
# Unit test for function represent_unicode
def test_represent_unicode():
    data = dict(foo="Hello 我")
    results = yaml.safe_dump(data, default_flow_style=False, Dumper=AnsibleDumper)
    assert 'Hello 我' in results

# Generated at 2022-06-23 05:37:26.273479
# Unit test for function represent_unicode
def test_represent_unicode():
    result = represent_unicode(AnsibleDumper, u'\u0042')
    assert result == u'\u0042'

# Generated at 2022-06-23 05:37:33.363801
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = {'a': '1',
            'b': '2',
            'c': '3',
            'd': {
                'e': '4',
                'f': '5',
                'g': '6',
            }
    }
    data_pyyaml = yaml.dump(data, Dumper=yaml.SafeDumper)
    data_ansible = yaml.dump(data, Dumper=AnsibleDumper)
    assert data_pyyaml == data_ansible



# Generated at 2022-06-23 05:37:44.878725
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = yaml.dumper.Dumper(stream=None,
                                default_style=None,
                                default_flow_style=False,
                                canonical=False,
                                indent=4,
                                width=80,
                                allow_unicode=True,
                                line_break=None,
                                encoding=None,
                                explicit_start=None,
                                explicit_end=None,
                                version=None,
                                tags=None)
    dumper.represented_objects = {}
    dumper.ignore_aliases = set()

    class AnsibleUnicodeStub(object):
        def __init__(self, value):
            self.value = value

        def __unicode__(self):
            return self.value.decode('unicode_escape')

    result = d

# Generated at 2022-06-23 05:37:48.955526
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    d = AnsibleDumper()
    assert isinstance(d, AnsibleDumper)



# Generated at 2022-06-23 05:37:56.160558
# Unit test for function represent_hostvars
def test_represent_hostvars():

    from ansible.parsing.yaml.objects import AnsibleMapping

    class FakeHostvars(dict):
        pass

    testdata = {"test_key1": HostVarsVars(AnsibleMapping())}
    testdata["test_key1"]["test_key2"] = "test_value"
    result = yaml.safe_load(yaml.dump(testdata, Dumper=AnsibleDumper))
    assert result["test_key1"]["test_key2"] == "test_value"

# Generated at 2022-06-23 05:37:58.211517
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    # create a new instance
    assert isinstance(AnsibleDumper(), AnsibleDumper)

# Generated at 2022-06-23 05:38:02.115196
# Unit test for function represent_binary
def test_represent_binary():
    data = b'\xc3\xa9'
    r = yaml.representer.SafeRepresenter.represent_binary(AnsibleDumper, data)
    expected = '!!binary |-\n  w6k=\n'
    assert r == expected



# Generated at 2022-06-23 05:38:08.836084
# Unit test for function represent_undefined
def test_represent_undefined():
    '''
    Ensure that AnsibleUndefined works as expected with represent_undefined
    '''
    data = AnsibleUndefined('test')

    # This raises an exception if it fails
    AnsibleDumper.represent_undefined(AnsibleDumper, data)

# Generated at 2022-06-23 05:38:10.046068
# Unit test for function represent_unicode
def test_represent_unicode():
    represent_unicode(None, u'foo')

# Generated at 2022-06-23 05:38:12.733567
# Unit test for function represent_unicode
def test_represent_unicode():

    y = AnsibleUnicode(value=u'foo')
    yaml.dump(y, Dumper=AnsibleDumper)


# Generated at 2022-06-23 05:38:20.579377
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():

    # Ensure that AnsibleDumper is a subclass of SafeDumper
    assert issubclass(AnsibleDumper, SafeDumper)

    # Ensure that AnsibleDumper construction works
    dumper = AnsibleDumper

    # Ensure that each of the representers have been added
    assert dumper.represent_dict == SafeDumper.represent_dict
    assert dumper.represent_list == SafeDumper.represent_list
    assert dumper.represent_str == SafeDumper.represent_str
    assert dumper.represent_unicode == represent_unicode
    assert dumper.represent_unsafe_text == represent_unicode
    assert dumper.represent_unsafe_bytes == represent_binary
    assert dumper.represent_hostvars == represent_hostvars
    assert dumper.represent_vault_encrypted_unicode == represent_

# Generated at 2022-06-23 05:38:31.097407
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper(indent=3)
    hostvars = HostVars()
    hostvars.add_host_var("testhost1", "var1", "a")
    hostvars.add_host_var("testhost1", "var2", "b")
    hostvars.add_host_var("testhost2", "var3", "c")

    doc = dumper.represent_data(hostvars)

    m = yaml.load(doc)
    assert "testhost2" in m
    assert "testhost1" in m
    assert m["testhost1"]["var1"] == "a"
    assert m["testhost2"]["var3"] == "c"

# Generated at 2022-06-23 05:38:37.007934
# Unit test for function represent_unicode
def test_represent_unicode():
    obj = yaml.AnsibleDumper(width=10000)
    data = {
        text_type('foo'): text_type('bar')
    }
    d = yaml.dump(data)
    assert d == text_type("foo: bar\n")

# Generated at 2022-06-23 05:38:37.856804
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper is not None



# Generated at 2022-06-23 05:38:47.066176
# Unit test for function represent_unicode
def test_represent_unicode():
    # Create a fake instance of AnsibleDumper
    class FakeAnsibleDumper(object):
        pass
    inst = FakeAnsibleDumper()
    inst.represent_str = lambda x, y: y + text_type(len(y))

    result = represent_unicode(inst, 'EOF')
    assert result == 'EOF3'
    # Test for AnsibleUnicode
    result = represent_unicode(inst, AnsibleUnicode('EOF'))
    assert result == 'EOF3'



# Generated at 2022-06-23 05:38:48.468711
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper(indent=4) is not None



# Generated at 2022-06-23 05:38:51.347639
# Unit test for function represent_undefined
def test_represent_undefined():
    # Arrange
    dumper = AnsibleDumper()
    # Act
    result = dumper.represent_data(AnsibleUndefined("Undefined"))
    # Assert
    assert result.startswith("<")

# Generated at 2022-06-23 05:39:01.744038
# Unit test for function represent_hostvars
def test_represent_hostvars():
    loader = yaml.Loader('''
            var1: sample1
            var2: 2
            var3: {"k": "v"}
            var4:
            - 1
            - 2
            var5: sample5
            ''')
    loader.constructor.add_constructor(
        u'tag:yaml.org,2002:map',
        loader.constructor.construct_yaml_map)
    data = loader.get_single_data()
    hv = HostVars(dict(var1=dict(source='sample1'), var5=dict(source='sample5')))
    data.update(hv)

# Generated at 2022-06-23 05:39:05.016343
# Unit test for function represent_undefined
def test_represent_undefined():
    ansible_dumper = AnsibleDumper()
    AnsibleUndefined()
    assert len(ansible_dumper.represent_undefined(AnsibleUndefined())) > 0

# Generated at 2022-06-23 05:39:10.512800
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hv = HostVars(host_vars_dict=dict(a=1, b=2), host_name='example_host')
    d = yaml.dump(hv, Dumper=AnsibleDumper)
    assert 'hostvars.example_host' in d


# Generated at 2022-06-23 05:39:14.896847
# Unit test for function represent_unicode
def test_represent_unicode():
    import sys
    if sys.version_info[0] >= 3:
        assert represent_unicode(None, AnsibleUnicode("foo")) == "foo"
    else:
        assert represent_unicode(None, AnsibleUnicode("foo")) == u"foo"



# Generated at 2022-06-23 05:39:24.692740
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = u'$ANSIBLE_VAULT;1.1;AES256\n6130326431666333613233383839343638636162663132393663353039616237343931623334626662\n3965643135313161386265653633343665313666323935666530393338343566643034376436303938\n3532626263633562343131613063316239383164376263366433393132333761316133346533376334\n61333430396665653566\n'
    data = AnsibleVaultEncryptedUnicode.from_string(data)
    s = yaml.dump(data, Dumper=AnsibleDumper)

# Generated at 2022-06-23 05:39:33.060690
# Unit test for function represent_hostvars
def test_represent_hostvars():
    '''Test represent_hostvars function'''
    dumper = AnsibleDumper()
    # Test success
    value = {'key': 'value'}
    data = HostVars(value)
    result = dumper.represent_data(data)
    assert result == u'{key: value}\n...\n'
    # Test error
    value = {'key': 'value'}
    data = HostVars(value)
    data.set_failed()
    assert dumper.represent_data(data) == u'MISSING\n...\n'

# Generated at 2022-06-23 05:39:41.863440
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    ciphertext = '$ANSIBLE_VAULT;1.1;AES256\n3962336130653436633639333734633065393263333636663433353861336562653531650a653632393565373865383165616431636163316439353261336666356137326436\n'
    # Load stdin with vault-encrypted string
    import io
    import sys
    old_stdin = sys.stdin
    sys.stdin = io.StringIO(ciphertext)
    # Import BaseVaultLoader
    from ansible.parsing.vault import VaultLib
    vault_loader = VaultLib()
    vault_encrypted = vault_loader.read_vaultfile(sys.stdin)
    sys.stdin = old_stdin
    custom

# Generated at 2022-06-23 05:39:50.763681
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import StrictUndefined
    from ansible.template import UndefinedError
    from ansible.vars.manager import VariableManager
    import sys

    # StrictUndefined
    try:
        # redirect stdout
        old_stdout = sys.stdout
        sys.stdout = open('/dev/null', 'w')
        yaml.dump(StrictUndefined(), Dumper=AnsibleDumper)
        sys.stdout = old_stdout
    except UndefinedError:
        pass
    else:
        raise AssertionError('Test represent_undefined failed to raise UndefinedError on StrictUndefined')

    # EmptyVariable (implicitly undefined)

# Generated at 2022-06-23 05:39:53.717781
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_data(AnsibleUndefined()) == dumper.represent_bool(True)

# Generated at 2022-06-23 05:39:59.787209
# Unit test for function represent_unicode
def test_represent_unicode():
    # create a simple data structure, with unicode
    data = {u'unicode': u'\u2713'}

    # create a dumper function
    dumper = AnsibleDumper()

    # create a yaml document
    document = yaml.dump(data, Dumper=dumper)

    # show document
    print(document)


# Generated at 2022-06-23 05:40:06.238536
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()

    # Ensure dumper returns an error if the value is an instance of AnsibleUndefined
    # by using the bool() operator.
    data = AnsibleUndefined()
    assert dumper.represent_undefined(data)

    # Ensure dumper does not return an error if the value is not an instance of AnsibleUndefined
    data = "string"
    assert dumper.represent_str(data)

# Generated at 2022-06-23 05:40:15.222579
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert yaml.dump(HostVars(foo='bar'), Dumper=AnsibleDumper, default_flow_style=False) == \
        'foo: bar\n'
    assert yaml.dump(HostVars(foo=['bar', 'baz']), Dumper=AnsibleDumper, default_flow_style=False) == \
        'foo:\n- bar\n- baz\n'
    assert yaml.dump(HostVars(foo=HostVars(bar='baz')), Dumper=AnsibleDumper, default_flow_style=False) == \
        'foo:\n  bar: baz\n'



# Generated at 2022-06-23 05:40:16.402904
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper


# Generated at 2022-06-23 05:40:18.566768
# Unit test for function represent_binary
def test_represent_binary():
    assert AnsibleDumper.represent_binary(None, u'\00\01') == u'!!binary |\n  AAEC\n'

# Generated at 2022-06-23 05:40:23.062523
# Unit test for function represent_unicode
def test_represent_unicode():
    data = AnsibleUnicode('string', 'utf-8')
    stream = '{}'.format(yaml.dump(data, Dumper=AnsibleDumper))
    assert stream == "!!python/unicode 'string'\n"


# Generated at 2022-06-23 05:40:34.113190
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib

    # derived from the unit test for this function in the VaultLib class
    test_secret = text_type("super secret")
    vault = VaultLib('tests/test_vault_password.txt')
    vault_secret = vault.encrypt(test_secret)
    d = AnsibleDumper({})

    vault_secret_yaml = d.represent_data(vault_secret)

# Generated at 2022-06-23 05:40:43.759683
# Unit test for function represent_binary
def test_represent_binary():
    bin_str = b'\xe5\xad\xa6\xe6\x95\x99'
    ansible_dumper = AnsibleDumper()
    # binary string
    result = ansible_dumper.represent_binary(bin_str)
    assert result == "!!binary \"5L+h5pS25ZGY\"\n"
    # unicode string
    unicode_str = bin_str.decode('utf-8')
    result = ansible_dumper.represent_binary(unicode_str)
    assert result == "!!binary \"5L+h5pS25ZGY\"\n"
    # AnsibleUnsafeBytes
    ansible_unsafe_bytes = AnsibleUnsafeBytes(bin_str)

# Generated at 2022-06-23 05:40:51.258649
# Unit test for function represent_binary
def test_represent_binary():
    dumper = yaml.SafeDumper()

    # Ensure we can render a binary string that is a unicode representation
    # of a byte sequence.
    assert u'\u00ff'.encode('utf-8') == dumper.represent_binary(u'\u00ff')
    # Ensure we can render a binary string that is a str representation of a
    # byte sequence.
    assert '\xff' == dumper.represent_binary('\xff')

# Generated at 2022-06-23 05:40:53.150600
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert type(AnsibleDumper) == type

# Generated at 2022-06-23 05:41:03.488614
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # Test with a mock HostVars object
    class MockHostVars(HostVars):
        def __init__(self, data):
            self._data = data
            self.__dict__ = data

        def keys(self):
            return self._data.keys()

        def __getitem__(self, item):
            return self._data[item]

        def __getattr__(self, item):
            return self._data[item]

    # Test HostVars object
    mock_hostvars = MockHostVars({'foo': 'bar', 'baz': 'quux'})
    yaml_string = yaml.dump({'hostvars': mock_hostvars}, Dumper=AnsibleDumper)

    # Test that HostVars are serialized correctly

# Generated at 2022-06-23 05:41:06.082843
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    instance = AnsibleDumper()

    assert instance
    assert isinstance(instance, AnsibleDumper)
    assert instance.default_flow_style is False



# Generated at 2022-06-23 05:41:12.883525
# Unit test for function represent_binary
def test_represent_binary():
    d = yaml.Dumper()
    y = yaml.dumper.SafeDumper()
    assert yaml.add_representer(bytes, represent_binary, Dumper=d) is None
    assert yaml.add_representer(binary_type, represent_binary, Dumper=y) is None
    assert d.represent_binary(b'test') == y.represent_binary(b'test')
    assert d.represent_binary(b'test') == y.represent_binary(b'test')
    assert d.represent_binary(b'test') == y.represent_binary(b'test')
    assert d.represent_binary(b'test') == y.represent_binary(b'test')
    assert d.represent_binary(b'test') == y.represent_binary(b'test')
    assert d.represent

# Generated at 2022-06-23 05:41:23.040210
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-23 05:41:25.305514
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    ad = AnsibleDumper()
    assert isinstance(ad, yaml.dumper.SafeDumper)

# Generated at 2022-06-23 05:41:27.696664
# Unit test for function represent_unicode
def test_represent_unicode():
    data = AnsibleUnicode('foo')
    rep = represent_unicode(AnsibleDumper, data)
    assert(isinstance(rep, yaml.representer.SafeRepresenter))



# Generated at 2022-06-23 05:41:35.830563
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, u'') == '""'
    assert represent_unicode(None, u'foo') == '"foo"'
    assert represent_unicode(None, u'foo "bar" baz') == '"foo \\"bar\\" baz"'
    assert represent_unicode(None, u'foo \'bar\' baz') == '"foo \'bar\' baz"'
    assert represent_unicode(None, u'foo\nbar\tbaz') == '"foo\\nbar\\tbaz"'
    assert represent_unicode(None, u'foo\u2022bar') == '"foo\\u2022bar"'

# Generated at 2022-06-23 05:41:39.065990
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(binary_type(b'test'), Dumper=AnsibleDumper) == u"!!binary 'dGVzdA=='\n"

# Generated at 2022-06-23 05:41:44.456939
# Unit test for function represent_unicode
def test_represent_unicode():
    '''
    Check that represent_unicode works as expected
    '''
    ansibledumper = AnsibleDumper()
    sample_data = AnsibleUnicode('some data')
    result = ansibledumper.represent_unicode(sample_data)
    assert isinstance(result, yaml.nodes.ScalarNode)
    assert result.value == 'some data'

# Generated at 2022-06-23 05:41:51.054115
# Unit test for function represent_unicode
def test_represent_unicode():
    ansible_unicode = yaml.representer.BaseRepresenter.represent_unicode
    ansible_dumper = AnsibleDumper(encoding='utf-8')

    verify_unicode_representer = lambda text: \
        (text_type, text) == ansible_unicode(ansible_dumper, text)

    assert verify_unicode_representer(u'\N{SNOWMAN}')
    assert verify_unicode_representer(u'\ud800')
    assert verify_unicode_representer('\N{SNOWMAN}')