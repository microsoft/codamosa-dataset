

# Generated at 2022-06-23 05:32:02.644346
# Unit test for function represent_hostvars
def test_represent_hostvars():
    try:
        import __main__
        main = __main__
    except (ImportError, AttributeError):
        main = {}

    from io import StringIO
    from types import ModuleType

    hv = HostVars(main)
    hv.set('test_key', 'test_value')
    stream = StringIO()

    AnsibleDumper.represent_hostvars(hv, stream=stream)
    out = stream.getvalue()
    assert 'test_key: test_value' in out

    stream = StringIO()
    hvv = HostVarsVars(main)
    hvv.set('test_key', 'test_value')
    AnsibleDumper.represent_hostvars(hvv, stream=stream)
    out = stream.getvalue()

# Generated at 2022-06-23 05:32:08.664750
# Unit test for function represent_binary
def test_represent_binary():
    binary = b'123\n456'
    assert b"!!binary |-\n  MTIzCjQ1Ng==\n" == yaml.dump(binary, Dumper=AnsibleDumper, default_flow_style=False)



# Generated at 2022-06-23 05:32:17.094963
# Unit test for function represent_unicode
def test_represent_unicode():
    '''
    Ensure that the representation of AnsibleUnicode objects
    are always safe for yaml.

    Note: This validation is not as complete as the tests
    in library/collection_loader/modules/test_yaml_unsafe.py
    by design. The test in the collection loader is intended
    to ensure all possible unsafe yaml is caught before
    Ansible core or a plugin is able to load the unsafe data.

    This test is for a bug where AnsibleUnicode objects
    were being represented as ASCII text by yaml dumpers.
    This test is only intended to ensure that this specific
    bug can not happen again.
    '''

# Generated at 2022-06-23 05:32:22.763118
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper

    # assert that Undefined.__bool__ is True
    assert(bool(AnsibleUndefined()) is True)

    # assert that dumper.represent_undefined would fail
    # because Undefined is true
    try:
        dumper.represent_undefined(AnsibleUndefined())
    except AssertionError:
        pass
    else:
        raise AssertionError('Expected AssertionError')

# Generated at 2022-06-23 05:32:28.463613
# Unit test for function represent_hostvars
def test_represent_hostvars():
    old_hostvars = HostVars(
        hostvars={
            'host1': {'foo': 1},
            'host2': {'foo': 2}
        }
    )
    new_hostvars = HostVars(
        hostvars={
            'host1': {'foo': 1},
            'host2': {'foo': 2}
        }
    )

    assert old_hostvars == new_hostvars

# Generated at 2022-06-23 05:32:31.710385
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = HostVars.from_yaml("test.yml", {'a': 1})
    dumped = yaml.dump(data, default_flow_style=False)
    assert dumped == "a: 1\n"

# Generated at 2022-06-23 05:32:42.297649
# Unit test for function represent_unicode
def test_represent_unicode():
    class Options(object):
        canonical = True
        indent = 2
        width = 80
        tags = {}
        block_seq_indent = 2
        flow_style = True

    data = "foobar"
    dumper = AnsibleDumper(Options())
    dumper.ignore_aliases = lambda data: True
    res = dumper.represent_unicode(data)
    assert res == u'foo\nb\n  bar\n'

    data = [
        "foobar",
        "foobaz",
        "12345",
        ["hello", "world"]
    ]
    dumper = AnsibleDumper(Options())
    dumper.ignore_aliases = lambda data: True
    res = dumper.represent_unicode(data)

# Generated at 2022-06-23 05:32:44.092334
# Unit test for function represent_undefined
def test_represent_undefined():
    d = AnsibleDumper()
    assert d.represent_data(AnsibleUndefined()) == 'None'



# Generated at 2022-06-23 05:32:50.148533
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    out = AnsibleDumper()  # AnsibleDumper(output_stream=sys.stdout, default_style=None, default_flow_style=False, canonical=False, indent=2, width=80, allow_unicode=True, line_break=None, encoding=None, explicit_start=None, explicit_end=None, version=None, tags=None)
    return out


#--

# Generated at 2022-06-23 05:32:52.884295
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    assert dumper.represent_data(dumper, AnsibleUndefined(var_name='foo')) is False

# Generated at 2022-06-23 05:32:56.343978
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    assert dumper.represent_hostvars({'a': 'b'}) == dumper.represent_dict({'a': 'b'})



# Generated at 2022-06-23 05:33:00.962638
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.load(yaml.dump("foo", Dumper=AnsibleDumper)) == "foo"
    assert yaml.load(yaml.dump(u("\u263a"), Dumper=AnsibleDumper)) == u("\u263a")



# Generated at 2022-06-23 05:33:11.829588
# Unit test for function represent_binary
def test_represent_binary():
    # Ensure that we can represent binary data
    # NOTE: The test here is a little sloppy in that we can't actually
    #       verify the output without deserializing it back to binary.
    #       However, serializing and deserializing is problematic in the
    #       first place because the length of the encoded data is variable.
    #       In other words, we are trusting the serialization/deserialization
    #       implementation of PyYaml to properly encode binary data.
    test_cases = [b'\x00', b'\x01', b'\x7f', b'\xff', b'\x00\x00\x00', b'\x01\x00\x7f\xff\xff']

# Generated at 2022-06-23 05:33:14.327610
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper
    assert dumper.org_represent_str == yaml.representer.SafeRepresenter.represent_str

# unit tests for the overridden methods

# Generated at 2022-06-23 05:33:16.258526
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.dump({'a': AnsibleUndefined}, Dumper=AnsibleDumper) == '{a: null}\n'

# Generated at 2022-06-23 05:33:20.338220
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(AnsibleDumper, u'foo') == 'foo'
    assert represent_unicode(AnsibleDumper, 'foo') == u'foo'



# Generated at 2022-06-23 05:33:23.487844
# Unit test for function represent_undefined
def test_represent_undefined():
    def_val = AnsibleUndefined()
    dumper = AnsibleDumper()
    assert not dumper.represent_undefined(def_val)

# Generated at 2022-06-23 05:33:31.070972
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # vaule is a AnsibleVaultEncryptedUnicode
    value = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.2;AES256;ansible\n363263356130313935363561643138323137653931613236316337613239633139313262623964\n313365636331636431343630333537343637646639353637373664383431316237303433373861\n303364326231366138383130313839656431336531653166646231383566663436343263363363\n3266363335373233633232613333383762373465333933313661387d')
   
    # Temp_data = {'key

# Generated at 2022-06-23 05:33:33.443625
# Unit test for function represent_undefined
def test_represent_undefined():
    s = AnsibleUndefined('test')
    assert AnsibleDumper.represent_undefined(s)



# Generated at 2022-06-23 05:33:36.990369
# Unit test for function represent_binary
def test_represent_binary():
    test_obj = AnsibleUnsafeBytes(b'foo')
    test_obj.__unicode__ = lambda: 'FOO'
    assert b'FOO' == yaml.dump(test_obj, Dumper=AnsibleDumper)

# Generated at 2022-06-23 05:33:47.436836
# Unit test for function represent_binary
def test_represent_binary():
    class TestOptions(object):
        def __init__(self, block_style=False):
            self.block_style = block_style

    dum = AnsibleDumper(TestOptions())
    data = b'\x00\x01\x02\x03'
    node = dum.represent_binary(data)
    assert node.style == '|'
    assert node.value == data.decode('iso-8859-1')

    data = b'hello\nworld'
    node = dum.represent_binary(data)
    assert node.style == '|'
    assert node.value == data.decode('utf-8')

    data = b'hello\x81\x82world'
    node = dum.represent_binary(data)
    assert node.style == '|'
    assert node

# Generated at 2022-06-23 05:33:58.685644
# Unit test for function represent_binary
def test_represent_binary():
    # AnsibleUnsafeBytes are converted to AnsibleUnsafeText on Python 2,
    # this test case is not relevant to Python 2.
    if isinstance(u"", text_type):
        return

    # This emulates what happens when ansible.module_utils.basic.AnsibleModule
    # is instantiated with unsafe_proxy=True.
    class AnsibleUnsafeBytesSubclass(AnsibleUnsafeBytes):
        __module__ = AnsibleUnsafeBytes.__module__
        __doc__ = AnsibleUnsafeBytes.__doc__

    aub = AnsibleUnsafeBytesSubclass("\x00\x01\x02\x03", warnings=[])

# Generated at 2022-06-23 05:34:06.330427
# Unit test for function represent_binary
def test_represent_binary():
    yaml_data = """---
- foo: "bar"
- baz: "qux"
"""
    yaml_rep = yaml.safe_dump(yaml.safe_load(yaml_data), default_flow_style=False)
    assert yaml_rep == yaml_data

# Generated at 2022-06-23 05:34:12.371285
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib

    data = AnsibleVaultEncryptedUnicode('my string')
    passwd = 'my secret'
    vault = VaultLib(passwd)
    result = vault.decrypt(data._ciphertext.decode())
    assert result == data._ciphertext.decode()
    rep_vault = represent_vault_encrypted_unicode(AnsibleDumper, data)
    assert rep_vault == '!vault |\n%s' % data._ciphertext.decode()

# Generated at 2022-06-23 05:34:23.413960
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # hostvars = HostVars(dict([('localhost', {'a': 1})])
    hostvars = HostVars()
    hostvars.set_variable('localhost', 'a', 1)
    if yaml.dump(dict(hostvars)) != "localhost:\n  a: 1\n":
        raise AssertionError("test_represent_hostvars failed")
    return "test_represent_hostvars passed"


if __name__ == '__main__':
    import sys
    import json
    import pprint
    from io import StringIO

    # ARG0: name of the test to run
    # ARG1: YAML string to parse
    # ARG2: expected JSON string to dump out
    TEST_NAME = sys.argv[1]

# Generated at 2022-06-23 05:34:34.267078
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

    # Note: only want to represent the encrypted data

# Generated at 2022-06-23 05:34:37.390215
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode(u'foo')) == u'- foo\n'
    assert yaml.dump(AnsibleUnicode(u'foo\n')) == u'|-\n  foo\n'



# Generated at 2022-06-23 05:34:40.539853
# Unit test for function represent_unicode
def test_represent_unicode():
    obj = AnsibleUnicode(u"My Test")
    assert yaml.dump(obj, Dumper=AnsibleDumper) == u"My Test\n..."



# Generated at 2022-06-23 05:34:50.953417
# Unit test for function represent_undefined
def test_represent_undefined():
    u = AnsibleUndefined
    dumper = AnsibleDumper()
    # here should not invoke represent_undefined
    yaml.dump(u, dumper, default_flow_style=False)
    yaml.dump(u(obj=u), dumper, default_flow_style=False)
    # here should invoke represent_undefined
    try:
        yaml.dump(u(), dumper, default_flow_style=False)
    except:
        pass
    try:
        yaml.dump(u(obj='x'), dumper, default_flow_style=False)
    except:
        pass
    # This will not cause _fail_with_undefined_error
    yaml.dump(u(obj=u(obj='x')), dumper, default_flow_style=False)

# Generated at 2022-06-23 05:34:55.244448
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()

    # Create a HostVars object with a dictionary
    hostvars_obj = HostVars({'dict_var': 'dict_val'})
    assert dumper.represent_data(hostvars_obj) == '{dict_var: dict_val}'



# Generated at 2022-06-23 05:35:02.990868
# Unit test for function represent_hostvars
def test_represent_hostvars():
    import json
    import tempfile
    import os

    out = tempfile.NamedTemporaryFile(delete=False)
    a = {'a': 'A', 'c': 'C'}
    b = {'b': 'B', 'c': 'C'}
    all_hosts = HostVars(dict(a=a, b=b))
    data = dict(all=all_hosts, a=HostVarsVars(a), b=HostVarsVars(b))
    yaml.dump(data, out, default_flow_style=False, Dumper=AnsibleDumper)
    out.close()
    out_data = open(out.name).read()
    os.unlink(out.name)

# Generated at 2022-06-23 05:35:04.496601
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    rep = AnsibleDumper(width=80)
    assert rep.width == 80

# Generated at 2022-06-23 05:35:10.385131
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(binary_type('hello'), default_flow_style=True, Dumper=AnsibleDumper) == '!!binary |\n  aGVsbG8=\n'
    assert yaml.dump(binary_type(u'hello'), default_flow_style=True, Dumper=AnsibleDumper) == '!!binary |\n  aGVsbG8=\n'

# Generated at 2022-06-23 05:35:20.152719
# Unit test for function represent_hostvars
def test_represent_hostvars():
    import os
    import sys

    sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../../'))

    from ansible.parsing.yaml.dumper import represent_hostvars

    foo = {'test': 'foo', 'test2': 'bar'}
    foo_obj = HostVars(host_data=foo)

    bar = {'a': 'b'}
    bar_obj = HostVarsVars(host_data=bar)

    test = {'foo': foo_obj, 'bar': bar_obj, 'baz': None}
    test_obj = VarsWithSources(vars=test)


# Generated at 2022-06-23 05:35:32.227852
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.manager import VariableManager

    var1 = VarsWithSources(name='var1', variables=dict(parent='var1val'))
    var2 = VarsWithSources(name='var2', variables=dict(parent='var2val'))
    var3 = VarsWithSources(name='var3', variables=dict(parent='var3val'))

    vars_manager = VariableManager()
    vars_manager.add_vars(var1, var2, var3)
    assert 'parent' in vars_manager

    host = HostVars(name='testhost', vars_manager=vars_manager)
    host.update(dict(host='hostval'))

    r = AnsibleDumper().represent_data(host)

# Generated at 2022-06-23 05:35:34.085944
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():

    dumper = AnsibleDumper

    assert isinstance(dumper, SafeDumper)



# Generated at 2022-06-23 05:35:44.020289
# Unit test for function represent_undefined
def test_represent_undefined():

    dumper = AnsibleDumper
    result = dumper.represent_undefined(dumper, AnsibleUndefined('foo'))
    assert result == True

    dumper.allow_undefined = True
    result = dumper.represent_undefined(dumper, AnsibleUndefined('foo'))
    assert result == False

    dumper.allow_undefined = False
    dumper.default_flow_style = True
    result = dumper.represent_undefined(dumper, AnsibleUndefined('foo'))
    assert result == False

    dumper.default_flow_style = False
    result = dumper.represent_undefined(dumper, AnsibleUndefined('foo'))
    assert result == False

# Generated at 2022-06-23 05:35:46.703579
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper, default_flow_style=False) == ('')

# Generated at 2022-06-23 05:35:51.046291
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper(
        None,
        default_flow_style=False,
        indent=2,
        width=80,
    )
    assert dumper.represent_data(AnsibleUndefined()) == ''

# Generated at 2022-06-23 05:35:56.840379
# Unit test for function represent_undefined
def test_represent_undefined():
    dump_data = yaml.dump(AnsibleUndefined("test-represent-undefined"), Dumper=AnsibleDumper)
    # The value should be 'None' since we are using bool(AnsibleUndefined("test-represent-undefined"))
    assert dump_data == "null\n"

# Generated at 2022-06-23 05:36:01.793543
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper('tag:yaml.org,2002:map', default_flow_style=True)
    data = {'hostvars': {'host1': {'var': 'value'}}}
    output = yaml.dump(data, Dumper=dumper)

    assert output == '{hostvars: {host1: {var: value}}}\n'



# Generated at 2022-06-23 05:36:09.441055
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import Jinja2Environment, AnsibleUndefined
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.vault import VaultLib
    # ansible.module_utils.six.* is added to __builtin__.__dict__
    # as a part of ansible/__init__.py
    from six import string_types

    vault_password = 'mypassword'
    vault = VaultLib([vault_password])
    env = Jinja2Environment()
    env.loader = AnsibleLoader(None, vault, env)

    # creating a new AnsibleMapping object
    data = AnsibleMapping()

# Generated at 2022-06-23 05:36:13.122447
# Unit test for function represent_binary
def test_represent_binary():
    data = AnsibleUnsafeBytes(b'foobar')
    dumper = AnsibleDumper()
    assert dumper.represent_binary(data) == yaml.representer.SafeRepresenter.represent_binary(dumper, b'foobar')

# Generated at 2022-06-23 05:36:17.076929
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    """
        This is test stub to check AnsibleDumper is an instance of SafeDumper.
    """
    x = AnsibleDumper()
    assert isinstance(x, SafeDumper)

# Generated at 2022-06-23 05:36:28.054891
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.yaml import AnsibleVaultEncryptedUnicode

    plaintext = b'$ANSIBLE_VAULT;1.1;AES256\n35383065383134333764633562613334323234363436333965333642336330303163363438633865\n33343864383938663834376264636132393939616664363531326366316666646232653832393633\n613231366133353466356163333230\n'
    data = AnsibleVaultEncryptedUnicode(VaultLib.decrypt(plaintext, b'foo'))
    dumper = AnsibleDumper()

# Generated at 2022-06-23 05:36:35.946925
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from io import StringIO
    from ansible.vars.hostvars import HostVars
    hv = HostVars()
    assert hv.host == 'fakehost'
    assert hv.vars == {}

    dumper = AnsibleDumper
    data = hv
    # We are not using StringIO, but a file opened in binary mode
    # on text data, because PyYAML uses \n in the dump and StringIO
    # will raise TypeError when using write with bytes on Python3.
    stream = StringIO()
    dumper.represent_dict(dict(data))
    dumper.dump(data, stream)
    assert stream.getvalue() == """{}
"""


# Generated at 2022-06-23 05:36:43.414392
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    d = HostVars({"inventory_hostname": "localhost", "hostvar2": "hostval2"})
    assert yaml.safe_dump(d, default_flow_style=False) == """---
hostvar2: hostval2
inventory_hostname: localhost
"""
    assert yaml.safe_dump(d, default_flow_style=True) == "hostvar2: hostval2\ninventory_hostname: localhost\n"



# Generated at 2022-06-23 05:36:45.105435
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper, type)

# Generated at 2022-06-23 05:36:55.645703
# Unit test for function represent_unicode
def test_represent_unicode():
    # Testing with a unicode string
    yaml_string = "unicode: '\u3068'"
    expected_result = (u'unicode: \'\u3068\'')
    assert yaml.load(yaml_string, Loader=yaml.SafeLoader) == expected_result
    assert yaml.load(yaml_string, Loader=yaml.FullLoader) == expected_result
    # Testing with a safe string
    yaml_string = "unicode: 'something safe'"
    expected_result = (u'unicode: \'something safe\'')
    assert yaml.load(yaml_string, Loader=yaml.SafeLoader) == expected_result
    assert yaml.load(yaml_string, Loader=yaml.FullLoader) == expected_result
    # Testing with a safe string that

# Generated at 2022-06-23 05:37:06.009171
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    '''
    Test for AnsibleVaultEncryptedUnicode objects
    '''
    test_yaml = '''
    string: !vault |
          $ANSIBLE_VAULT;1.1;AES256
          66386265626337616635656435313436373063366132396161393136613237343539346661666436
          66333062376335363664353737663933386638373337396566633432313635373636303363663961
          34323139393236356332663737663466633462393839363236363330353433623237393830383532
          31633066333834626137323235393965
    '''

# Generated at 2022-06-23 05:37:10.610181
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = HostVars(
        hostvars={"test_var": "test_value"},
        vars_files={"test_file": "test_file_name"},
        vars_prompts={"test_prompt": "test_prompt_text"},
    )
    dumper = yaml.Dumper
    dumper.represent_hostvars(hostvars)

# Generated at 2022-06-23 05:37:13.848267
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    """Ensure that the AnsibleDumper class can be instantiated"""

    instance = AnsibleDumper()
    assert isinstance(instance, yaml.representer.SafeRepresenter)

# Generated at 2022-06-23 05:37:21.549861
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars import VariableManager

    data = b'{"example_key": "example_value"}'.decode('utf-8')
    stream = yaml.load(data, Loader=yaml.BaseLoader)
    # Note that the type here is HostVars, not HostVarsVars
    # HostVars contains HostVarsVars objects
    assert isinstance(stream, HostVars)

    manager = VariableManager()
    # get_vars() returns a HostVarsVars instance
    result = manager.get_vars(loader=None, play=None, host=stream)
    assert isinstance(result, HostVarsVars)
    assert result['example_key'] == 'example_value'

# Generated at 2022-06-23 05:37:32.786229
# Unit test for function represent_binary
def test_represent_binary():
    import yaml
    from ansible.module_utils.common.yaml import AnsibleDumper, AnsibleLoader

    class Mydumper(AnsibleDumper):
        pass

    if yaml.__with_libyaml__:
        yaml.dumper.Dumper = Mydumper
    else:
        yaml.emitter.Emitter = Mydumper
    yaml.add_representer(binary_type, represent_binary, Dumper=Mydumper)

    class Myloader(AnsibleLoader):
        pass

    if yaml.__with_libyaml__:
        yaml.loader.SafeLoader = Myloader
    else:
        yaml.parser.SafeParser = Myloader

# Generated at 2022-06-23 05:37:39.463278
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.template.safe_eval import unsafe_eval
    hostvars = HostVars(unsafe_eval("{'foo': 'bar'}"))
    assert yaml.dump(hostvars, Dumper=AnsibleDumper) == 'foo: bar\n'
    assert yaml.safe_dump(hostvars, Dumper=AnsibleDumper) == 'foo: bar\n'

# Generated at 2022-06-23 05:37:43.061887
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    try:
        AnsibleDumper()
    except TypeError as e:
        assert '__init__() takes at least 2 arguments' in str(e)
    else:
        assert False, 'AnsibleDumper() works without parameters'

# Generated at 2022-06-23 05:37:47.387938
# Unit test for function represent_binary
def test_represent_binary():
    ansible_dumper = AnsibleDumper()
    test_bytes = AnsibleUnsafeBytes(b'\xf1\xf2\xbc')
    expected_output = text_type("!binary |-\n  w5bDm8Kz\n")
    actual_output = ansible_dumper.represent_binary(test_bytes)
    assert actual_output == expected_output

# Generated at 2022-06-23 05:37:49.241176
# Unit test for function represent_binary
def test_represent_binary():
    yaml.dump(AnsibleUnsafeBytes(b'abc'), AnsibleDumper)


# Generated at 2022-06-23 05:37:53.877003
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    dumper.ignore_aliases = lambda *args: True
    d = HostVars()
    assert dict(dumper.represent_data(d)) == dict(dumper.represent_dict(dict(d)))

# Generated at 2022-06-23 05:38:04.002463
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    initial_data = b'9d2ca8b4e4b4c2d1\n'
    ciphertext = AnsibleVaultEncryptedUnicode(initial_data)

    assert ciphertext._ciphertext == initial_data

    output = represent_vault_encrypted_unicode(AnsibleDumper, ciphertext)
    # should be in the form of | <ciphertext>
    assert output.startswith('|')

    # remove \x00, which is the result of using SafeDumper
    assert output[:3] + output[3:].replace('\x00', '') == '|9d2ca8b4e4b4c2d1\n'



# Generated at 2022-06-23 05:38:07.430596
# Unit test for function represent_hostvars
def test_represent_hostvars():
    obj = HostVars()
    obj.add("ansible_all_ipv4_addresses", ["8.8.8.8", "9.9.9.9"])

    # Make sure it dumps fine
    yaml.dump(obj, Dumper=AnsibleDumper)


# Generated at 2022-06-23 05:38:08.951515
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'hello').value == 'hello'

# Generated at 2022-06-23 05:38:10.878531
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper(), yaml.dumper.Dumper)



# Generated at 2022-06-23 05:38:18.480342
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    representer_function = represent_binary
    representer = AnsibleUnsafeBytes

    # Test binary strings
    representer_function(dumper, representer(b'\x00\xff'))
    representer_function(dumper, representer(b'Ab\xe9\x00\xff'))

    # Test unicode strings
    try:
        representer_function(dumper, '\x00\xff')
    except UnicodeDecodeError:
        pass
    try:
        representer_function(dumper, 'Ab\xe9\x00\xff')
    except UnicodeDecodeError:
        pass

# Generated at 2022-06-23 05:38:24.148190
# Unit test for function represent_binary
def test_represent_binary():
    # Represent u'\u0430\n'
    data = b'\xd0\xb0\n'
    expected_result = '!!binary |-\n  0JHQsNC10L3RgtGA\n'
    actual_result = yaml.dump(data, Dumper=AnsibleDumper)
    assert expected_result == actual_result

# Generated at 2022-06-23 05:38:34.194790
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-23 05:38:37.909230
# Unit test for function represent_unicode
def test_represent_unicode():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    u = u'H\xe9llo'
    encoded = yaml.dump({'key': AnsibleUnicode(u)}, Dumper=AnsibleDumper).strip()
    assert encoded == u"key: 'H\\xe9llo'"

# Generated at 2022-06-23 05:38:41.765716
# Unit test for function represent_unicode
def test_represent_unicode():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    yaml.dump(AnsibleUnicode('test'), Dumper=AnsibleDumper)



# Generated at 2022-06-23 05:38:44.031939
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode("test"), Dumper=AnsibleDumper) == u"test\n..."

# Generated at 2022-06-23 05:38:55.681994
# Unit test for function represent_binary
def test_represent_binary():
    import io
    output = io.BytesIO()
    serialized = yaml.dump(b'\xde\xad\xbe\xef', stream=output, Dumper=AnsibleDumper, default_flow_style=False)
    output.seek(0)
    assert output.read().decode() == '!!binary |\n  w5qETg==\n'

# Test the yaml dumper for unsafe data
from ansible.template.template import AnsibleJ2Template
test_template = '''
{%- if unsafe -%}
{{ unsafe }}
{%- endif -%}
'''
# Test the yaml dumper for unsafe data: text_type
from ansible.template.template import AnsibleJ2Template

# Generated at 2022-06-23 05:38:58.987746
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = yaml.SafeDumper
    dumper.add_representer(AnsibleUndefined, represent_undefined)
    assert dumper.represent_undefined(dumper, AnsibleUndefined) is True
    assert dumper.represent_undefined(dumper, 'foo') is False

# Generated at 2022-06-23 05:39:03.447982
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    assert represent_vault_encrypted_unicode(None, AnsibleVaultEncryptedUnicode(u'a')) == "!vault |\n          YQ==\n"
    assert represent_vault_encrypted_unicode(None, AnsibleVaultEncryptedUnicode(u'')) == "!vault |\n          cGFzc3dvcmQ=\n"

# Generated at 2022-06-23 05:39:05.969968
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    if AnsibleDumper._yaml_base_dumper_init:
        AnsibleDumper._yaml_base_dumper_init()

# Generated at 2022-06-23 05:39:09.503564
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper().__class__ is AnsibleDumper

# Unit tests for _AnsibleSafeDumper._represent_safe_scalar
# These are really "test the tests"

# Generated at 2022-06-23 05:39:19.768746
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template.safe_eval import Undefined

    class MyUndefined(Undefined):
        pass

    class MyOtherUndefined(Undefined):
        pass

    class MyNotUndefined(object):
        pass

    class MyNonUndefined(False):
        pass

    u = MyUndefined()
    assert AnsibleDumper.represent_undefined(u) is False
    assert AnsibleDumper.represent_undefined(undefined) is False
    assert AnsibleDumper.represent_undefined(MyOtherUndefined()) is False
    assert AnsibleDumper.represent_undefined(MyNonUndefined()) is False
    assert AnsibleDumper.represent_undefined(MyNotUndefined()) is True

# Generated at 2022-06-23 05:39:23.628420
# Unit test for function represent_unicode
def test_represent_unicode():
    u = AnsibleUnicode(text_type('test'))
    output = yaml.dump(u, Dumper=AnsibleDumper)
    assert output == "test\n..."



# Generated at 2022-06-23 05:39:30.205008
# Unit test for function represent_binary
def test_represent_binary():
    """ This is a representation of the binary data
    'user: !binary |-\n  QWxpZ2h0cw==\n'
    """
    assert yaml.dump( {'user': binary_type('Alights')}, Dumper=AnsibleDumper ) == (
        "{u'user': !!binary |-\n    QWxpZ2h0cw==\n}"
    )


# Generated at 2022-06-23 05:39:35.282986
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from collections import namedtuple
    from ansible.parsing.yaml import AnsibleLoader
    hv = HostVars(dict(a=1), dict(a=2))
    ldr = AnsibleLoader(hv, None)
    assert ldr.get_single_data() == dict(a=2)

# Generated at 2022-06-23 05:39:39.147739
# Unit test for function represent_undefined
def test_represent_undefined():
    from io import StringIO
    from ansible.template.jinja2 import StrictUndefined
    output = StringIO()
    dumper = AnsibleDumper(output)
    dumper.represent_undefined(StrictUndefined())
    assert output.getvalue() == ""



# Generated at 2022-06-23 05:39:42.292537
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = dict(ansible_facts=dict(a=1, b=2))
    assert dict(data) == yaml.load(yaml.dump(data, Dumper=AnsibleDumper))



# Generated at 2022-06-23 05:39:44.494810
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(u'foo', Dumper=AnsibleDumper) == u'foo\n...\n'



# Generated at 2022-06-23 05:39:45.588794
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper, type)

# Generated at 2022-06-23 05:39:55.678572
# Unit test for function represent_hostvars
def test_represent_hostvars():

    from ansible.parsing.yaml.dumper import HostVars, HostVarsVars

    # HostVars / HostVarsVars
    v = HostVars()
    v['k1'] = 'foo'
    yaml_data = yaml.dump(v, Dumper=AnsibleDumper)
    assert yaml_data == "k1: foo\n"

    v = HostVarsVars()
    v['k1'] = 'foo'
    yaml_data = yaml.dump(v, Dumper=AnsibleDumper)
    assert yaml_data == "k1: foo\n"



# Generated at 2022-06-23 05:40:03.783028
# Unit test for function represent_binary
def test_represent_binary():
    lines = [u'\x00\x01\x02\x03']
    dump = yaml.dump(lines, Dumper=AnsibleDumper)
    assert dump == "!!python/unicode '\\x00\\x01\\x02\\x03'\n"
    dump = yaml.dump(lines, Dumper=AnsibleDumper, encoding='utf-8')
    assert dump == "!!python/unicode '\\x00\\x01\\x02\\x03'\n"

# Generated at 2022-06-23 05:40:10.190688
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    expected = '# this is a comment\\nfoo'
    data = AnsibleUnicode(u'# this is a comment\nfoo', 'string')
    assert dumper.represent_unicode(dumper, data) == expected

    data = AnsibleUnsafeText(u'# this is a comment\nfoo')
    assert dumper.represent_unicode(dumper, data) == expected



# Generated at 2022-06-23 05:40:13.627452
# Unit test for function represent_binary
def test_represent_binary():
    assert represent_binary(AnsibleDumper, b'foo') == '!!binary "Zm9v"'
    assert represent_binary(AnsibleDumper, u'foo') == '!!binary "Zm9v"'

# Generated at 2022-06-23 05:40:20.465645
# Unit test for function represent_undefined
def test_represent_undefined():

    dumper = AnsibleDumper

    # Here we have to make sure that the dumper shows boolean
    # for undefined so that _fail_with_undefined_error works
    # This works because Jinja2 sets __bool__ on the StrictUndefined,
    # which AnsibleUndefined is a subclass of
    data = AnsibleUndefined()
    result = dumper.represent_data(data)
    assert result == 'false'

    data = AnsibleUndefined('hello')
    result = dumper.represent_data(data)
    assert result == 'false'

# Generated at 2022-06-23 05:40:21.613429
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper is not None


# Generated at 2022-06-23 05:40:30.394776
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    indent = 4
    width = 60
    allow_unicode = False
    line_break = '\n'
    encoding = 'utf-8'
    # FIXME: options cannot be passed to the constructor of this class.
    # Following 2 statements will raise exception.
    # dumper = AnsibleDumper(indent, width, allow_unicode, line_break, encoding)
    # dumper = AnsibleDumper(options=yaml.dump(HostVars({'a': 'b'}), Dumper=AnsibleDumper))
    dumper = AnsibleDumper()
    assert dumper is not None



# Generated at 2022-06-23 05:40:33.556452
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = HostVars({'foo': 'bar'})
    actual = yaml.dump({'foo': data}, Dumper=AnsibleDumper)
    assert actual == '{foo: bar}\n'

# Generated at 2022-06-23 05:40:43.652599
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    # In Ansible everything is an object.  This is not true of PyYaml.
    # In this example, a string (object) is represented as a scalar.
    yaml.load('[foo]') is None

    # It should be a list (container).  In PyYaml, this is the list
    # container.  Ansible uses its own container type.  The Ansible
    # container is a list of objects.  Objects are not scalars.
    yaml.load('[foo]', Loader=yaml.BaseLoader) is None

    # The AnsibleDumper is a subclass of SafeDumper.  This is the
    # representation of a simple mapping.  The is a safe representation.
    yaml.load('{foo}', Loader=yaml.SafeLoader) is None

    # Here is the representation of an Ansible

# Generated at 2022-06-23 05:40:51.062037
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    assert dumper.represent_unicode(dumper, u'hello') == u'? hello\n'
    assert dumper.represent_unicode(dumper, u'') == u'""\n'
    assert dumper.represent_unicode(dumper, u'{}') == u'"? {}\n"\n'



# Generated at 2022-06-23 05:40:55.281756
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    # Try to instantiate class AnsibleDumper
    try:
        AnsibleDumper()
        assert True
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-23 05:40:57.475142
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    undefined = AnsibleUndefined("myvar")
    dumper.represent_undefined(undefined)

# Generated at 2022-06-23 05:41:02.421765
# Unit test for function represent_hostvars
def test_represent_hostvars():
    """
    All AnsibleUnicode object should be turned into string
    """
    data = {'data': dict(a=AnsibleUnicode('test'))}
    result = yaml.dump(data, Dumper=AnsibleDumper)
    assert result == '{data: {a: test}}\n'


# Generated at 2022-06-23 05:41:11.180912
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    plain_text = AnsibleVaultEncryptedUnicode('my secret')
    expected = '!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          35306163356362326134376138306331666366346162363633333138393637613830393931383565\n          3038643862633165373565656637363164663133376439653234386361\n          39363338626363326536373437383131663165393733396162396238663038643739666664663038\n          6332623130643130376432666235633062393938336665373066\n'
    assert str(plain_text) == expected

# Generated at 2022-06-23 05:41:12.876160
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    ans_dumper = AnsibleDumper()
    assert ans_dumper is not None

# Generated at 2022-06-23 05:41:22.994683
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Fake ansible.vars.manager.VarsWithSources.{},
    representer = AnsibleDumper
    # the class object param, will be the value of data param in function represent_vault_encrypted_unicode
    # the id of data is the value of self param in function represent_vault_encrypted_unicode
    # the id of data is the value of AnsibleVaultEncryptedUnicode param in function represent_vault_encrypted_unicode

# Generated at 2022-06-23 05:41:25.305501
# Unit test for function represent_undefined
def test_represent_undefined():
    stream = AnsibleDumper.represent_undefined(None)
    assert stream is False


# Generated at 2022-06-23 05:41:35.574389
# Unit test for function represent_unicode
def test_represent_unicode():
    ''' represent_unicode should return proper representation of unicode strings '''

    representer = AnsibleDumper()

    string = 'string'
    # this should not return braces
    assert(representer.represent_unicode(string) == string)

    string = 'st\u2021ing'
    # this should return braces
    assert(representer.represent_unicode(string) == 'st\\u2021ing')

    string = u'\u00E6ble'
    # this should always return braces
    assert(representer.represent_unicode(string) == u'\\u00e6ble')

    # this should always return braces
    string = '\x81'
    assert(representer.represent_unicode(string) == '\\u0081')

    # this should always return braces

# Generated at 2022-06-23 05:41:46.088233
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # Test with no data, should be an empty dict
    assert AnsibleDumper.represent_hostvars(AnsibleDumper(), HostVars({})) == '{}'

    # Test with a HostVarsVars data, should be the same as represent_dict
    data = HostVarsVars({'test': 1})
    assert AnsibleDumper.represent_hostvars(AnsibleDumper(), data) == 'test: 1'

    # Test with a VarsWithSources data, should be the same as reprsent_dict
    data = VarsWithSources({'test': 1})
    assert AnsibleDumper.represent_hostvars(AnsibleDumper(), data) == 'test: 1'

    # Test with HostVars data, should be the same as represent_dict

# Generated at 2022-06-23 05:41:55.732528
# Unit test for function represent_binary
def test_represent_binary():
    res = represent_binary(AnsibleDumper, b"testing \x00\x01\x02\x03")
    assert res == "!!binary 'dGVzdGluZyAwMDEwMjAz'\n"
    res = represent_binary(AnsibleDumper, b"testing \x01\x02\x03")
    assert res == "!!binary 'dGVzdGluZyAxMDIwMw=='\n"
    res = represent_binary(AnsibleDumper, "testing \x01\x02\x03")
    assert res == "!!binary 'dGVzdGluZyAxMDIwMw=='\n"