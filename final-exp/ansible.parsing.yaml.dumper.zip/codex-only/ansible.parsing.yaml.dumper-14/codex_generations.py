

# Generated at 2022-06-23 05:31:54.578702
# Unit test for function represent_unicode
def test_represent_unicode():
    u = u'\x1a\x1b'
    print(yaml.dump(u, Dumper=AnsibleDumper, default_flow_style=False))


# Generated at 2022-06-23 05:32:05.237250
# Unit test for function represent_hostvars
def test_represent_hostvars():
    test_hostvars = {
        'hostvars': [{'key1': 'value1'}, {'key2': 'value2'}]
    }
    result = yaml.safe_dump(test_hostvars, default_flow_style=False, Dumper=AnsibleDumper, allow_unicode=True)
    assert '&id001\n  key1: value1' in result
    assert '&id002\n  key2: value2' in result

# Generated at 2022-06-23 05:32:06.074316
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert True is not False

# Generated at 2022-06-23 05:32:11.555035
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    binary_data = b'b\xc3\xaa\xc3\xa7on\x00\xff'
    assert dumper.represent_binary(binary_data) == '!binary |\n  YsOoc25+fg==\n'

# Generated at 2022-06-23 05:32:13.715270
# Unit test for function represent_undefined
def test_represent_undefined():
    assert represent_undefined(AnsibleDumper, AnsibleUndefined())

# Generated at 2022-06-23 05:32:20.149430
# Unit test for function represent_unicode
def test_represent_unicode():
    # test_obj is a unicode string
    test_obj = u"testing\u2038"
    # test_obj_dump is the unicode string dumped to UTF-8
    test_obj_dump = b"testing\xe2\x80\xb8"
    res = represent_unicode(AnsibleDumper, test_obj)
    # We expect the string to dumped to UTF-8
    assert res == test_obj_dump



# Generated at 2022-06-23 05:32:30.817013
# Unit test for function represent_unicode
def test_represent_unicode():
    # Test valid unicode characters
    input = AnsibleUnicode('\u1234')
    output = yaml.dump(input, Dumper=AnsibleDumper)
    assert output == '!ansible_unicode u1234\n...\n'

    # Test invalid unicode characters
    input = AnsibleUnicode('\udc00')
    output = yaml.dump(input, Dumper=AnsibleDumper)
    assert output == '!ansible_unicode udc00\n...\n'

    # Test with control characters
    input = AnsibleUnicode('hello\tworld\r\n')
    output = yaml.dump(input, Dumper=AnsibleDumper)
    assert output == '!ansible_unicode hello\\tworld\\r\\n\n...\n'

# Generated at 2022-06-23 05:32:34.712277
# Unit test for function represent_undefined
def test_represent_undefined():
    test_value = AnsibleUndefined
    representer = yaml.representer.SafeRepresenter()
    assert represent_undefined(representer, test_value)

# Generated at 2022-06-23 05:32:36.240940
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper(), AnsibleDumper)



# Generated at 2022-06-23 05:32:46.815453
# Unit test for function represent_binary
def test_represent_binary():

    # Set up a test case.
    test_plain = u'This is a test.\n'.encode()
    test_unicode = u'\u1234\u5678'.encode()
    test_bytes = b'\x00\x01\x7f\xff'

    # Create the Dumper and dump the test cases.
    dumper = AnsibleDumper(width=float("inf"), default_flow_style=False)
    plain_dump = dumper.represent_binary(test_plain)
    unicode_dump = dumper.represent_binary(test_unicode)
    bytes_dump = dumper.represent_binary(test_bytes)

    # Evaluate the results of dumping.

# Generated at 2022-06-23 05:32:51.989090
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    test_data = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\n1234\n')

    # Dump data into yaml and verify it
    assert yaml.dump(test_data) == '!vault |\n  $ANSIBLE_VAULT;1.1;AES256\n  1234\n'



# Generated at 2022-06-23 05:32:55.562130
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    plaintext = u"This is a test"
    d = yaml.load(yaml.dump(AnsibleVaultEncryptedUnicode(plaintext)))
    assert d == plaintext


# Generated at 2022-06-23 05:33:00.553610
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = dict(foo='bar')
    hv = HostVars(data)
    hvv = HostVarsVars(hv)
    v = VarsWithSources(hvv)
    assert represent_hostvars(None, v) == {'foo': 'bar'}



# Generated at 2022-06-23 05:33:08.283968
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper(default_flow_style=False, pure=True)
    data = "simple string"
    value = dumper.represent_scalar(u'tag:yaml.org,2002:str', data, style='"')
    assert value == "simple string"
    data = u"simple unicode string"
    value = dumper.represent_scalar(u'tag:yaml.org,2002:str', data, style='"')
    assert value == "simple unicode string"



# Generated at 2022-06-23 05:33:10.764192
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(binary_type(b'foo\x00bar')) == "!!binary \"Zm9vAGJhcg==\\n\"\n"

# Generated at 2022-06-23 05:33:13.429410
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    data = dict(data_key='data_value')
    assert dumper.represent_hostvars(HostVars(data)) == dumper.represent_dict(data)

# Generated at 2022-06-23 05:33:19.894123
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(AnsibleDumper, u'foo') == "foo"
    assert represent_unicode(AnsibleDumper, u'☃') == "☃"
    assert represent_unicode(AnsibleDumper, u'i ♥ Ansible') == "i ♥ Ansible"

# Generated at 2022-06-23 05:33:26.187158
# Unit test for function represent_binary
def test_represent_binary():
    with open('/bin/ls', 'rb') as f:
        ls = f.read()
    dumped = yaml.dump(ls, Dumper=AnsibleDumper)
    # This is how python3 represents bytes, but is not easily readable
    assert dumped == "!!binary |-\n  bGlz\n", dumped
    # This is how python2 represent bytes, but is not easily readable
    # assert dumped == "!!binary |\n  bGlz\n", dumped

# Generated at 2022-06-23 05:33:26.948154
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert True

# Generated at 2022-06-23 05:33:28.722796
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    test_obj = AnsibleDumper()
    assert hasattr(test_obj, 'add_representer')

# Generated at 2022-06-23 05:33:38.921510
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert yaml.dump(HostVars({})) == "{}\n"
    assert yaml.dump(HostVars({"foo": "bar"})) == "{foo: bar}\n"
    assert yaml.dump(HostVars({"foo": "bar", "baz": 123})) == "{baz: 123, foo: bar}\n"
    # Note: YAML is a superset of JSON, therefore the output must be valid JSON.
    # Since JSON does not allow bareword keys, the keys must be quoted.
    assert yaml.dump(HostVars({"foo bar": "baz"})) == '{"foo bar": baz}\n'
    assert yaml.dump(HostVars({'!x': "y"})) == '{"!x": y}\n'

# Generated at 2022-06-23 05:33:41.154483
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.dump(AnsibleUndefined, Dumper=AnsibleDumper) == ""

# Generated at 2022-06-23 05:33:52.360410
# Unit test for function represent_binary
def test_represent_binary():

    def check_represent_binary(data, expected):
        dumper = AnsibleDumper
        actual = dumper.represent_binary(dumper, data)
        assert actual == expected, "%s != %s" % (actual, expected)


# Generated at 2022-06-23 05:33:56.809547
# Unit test for function represent_unicode
def test_represent_unicode():
    # Just a test to see if this will actually work or not
    bad_dict = {
        'value': AnsibleUnicode('value'),
    }
    text = yaml.dump(bad_dict, Dumper=AnsibleDumper)
    assert isinstance(text, text_type)



# Generated at 2022-06-23 05:34:09.276453
# Unit test for function represent_hostvars
def test_represent_hostvars():

    # Simple data represent
    data = HostVars()
    data.vars = dict(a=1, b=2, c=3)
    expected = dict(a=1, b=2, c=3)

    assert yaml.dump(data, Dumper=AnsibleDumper) == yaml.dump(expected, Dumper=AnsibleDumper)

    # Represent with no variables
    data = HostVars()
    assert yaml.dump(data, Dumper=AnsibleDumper) == '{}\n'

    # Represent with empty variables
    data = HostVars(vars=[])
    assert yaml.dump(data, Dumper=AnsibleDumper) == '{}\n'

# Generated at 2022-06-23 05:34:12.374480
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, text_type('foo')) == text_type('foo')
    assert represent_unicode(None, text_type('bar')) == text_type('bar')

# Generated at 2022-06-23 05:34:13.852377
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    ad = AnsibleDumper()
    # does not raise
    assert True

# Generated at 2022-06-23 05:34:15.426884
# Unit test for function represent_undefined
def test_represent_undefined():
    d = yaml.dumps(AnsibleUndefined())
    assert d == ''

# Generated at 2022-06-23 05:34:19.005212
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    encrypted = AnsibleVaultEncryptedUnicode('randomstr')
    dump = lambda x: yaml.dump(x, Dumper=AnsibleDumper)
    assert dump(encrypted) == '!vault |\n          randomstr'

# Generated at 2022-06-23 05:34:20.683568
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert str(AnsibleDumper) == "<class 'ansible.parsing.yaml.dumper.AnsibleDumper'>"

# Generated at 2022-06-23 05:34:24.921224
# Unit test for function represent_binary
def test_represent_binary():
    actual = yaml.dump(binary_type('f\x08\xd2\r'), Dumper=AnsibleDumper, default_flow_style=False)
    expected = '\n!!binary |\n  ZgAAAAAAAAE=\n'
    assert actual == expected

# Generated at 2022-06-23 05:34:35.906908
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper(default_flow_style=False)
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(None)
    data = vault.encrypt(u'hello')
    data = AnsibleVaultEncryptedUnicode(data)

# Generated at 2022-06-23 05:34:41.112396
# Unit test for function represent_undefined
def test_represent_undefined():
    try:
        AnsibleDumper.represent_undefined(AnsibleDumper, AnsibleUndefined)
        assert False, "We should have failed here, if we didn't, test failed."
    except AssertionError as e:
        assert str(e) == "The task includes an option with an undefined variable. The error was: 'AnsibleUndefined' is undefined"



# Generated at 2022-06-23 05:34:46.497248
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper.add_representer is not None
    assert AnsibleDumper.represent_hostvars is not None
    assert AnsibleDumper.represent_vault_encrypted_unicode is not None
    assert AnsibleDumper.represent_unicode is not None
    assert AnsibleDumper.represent_binary is not None
    assert AnsibleDumper.represent_undefined is not None

# Generated at 2022-06-23 05:34:51.429722
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert isinstance(dumper.represent_data(AnsibleUndefined), bool)
    assert isinstance(dumper.represent_data(AnsibleUndefinedStrict()), bool)
    assert isinstance(dumper.represent_data(AnsibleUndefinedNonStrict()), bool)



# Generated at 2022-06-23 05:35:01.382191
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    encrypted_string = "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          323939333764376633616236633563396366316636262666663383230363537313132313331313633\n          633537306564393061666332323262316332396164360a626431316138626666383631373335636234\n          6264383533386334323161373539313332333433393637363331616530356162396335643532646534\n          3736323438643833370a3830346465"
    data = AnsibleVaultEncryptedUnicode(encrypted_string)

# Generated at 2022-06-23 05:35:09.201075
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = 'foo'
    obj = AnsibleVaultEncryptedUnicode(data)
    rep = represent_vault_encrypted_unicode(None, obj)

# Generated at 2022-06-23 05:35:11.917460
# Unit test for function represent_unicode
def test_represent_unicode():
    u_str = AnsibleUnicode('abc')
    result = represent_unicode(AnsibleDumper, u_str)
    assert result == "abc"



# Generated at 2022-06-23 05:35:15.442237
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    e = AnsibleVaultEncryptedUnicode("test")
    d = AnsibleDumper({})
    assert d.represent_data(e) == "!vault |\n  test\n"

# Generated at 2022-06-23 05:35:20.568384
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = HostVars({"foo": "bar"})
    # convert HostVars object to dict
    res = represent_hostvars(None, hostvars)
    # should be a dict
    assert isinstance(res, dict)
    # can be marshalled to Yaml and parsed back to dict
    res = yaml.load(yaml.dump(res))
    assert res["foo"] == "bar"



# Generated at 2022-06-23 05:35:32.390243
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    assert dumper.represent_unicode(dumper, AnsibleUnicode('foo')) != yaml.representer.SafeRepresenter.represent_str(dumper, 'foo')
    assert dumper.represent_unicode(dumper, AnsibleUnicode('foo')) == text_type('foo')
    assert dumper.represent_unicode(dumper, AnsibleUnicode('бафф')) == text_type('бафф')
    # Test that it doesn't break on latin-1 chars
    assert dumper.represent_unicode(dumper, AnsibleUnicode('\u0080')) == text_type('\u0080')
    # Test that it deals with surrogates

# Generated at 2022-06-23 05:35:36.128303
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper, type)
    assert yaml.SafeDumper in AnsibleDumper.__bases__
    assert yaml.dumper.SafeDumper in AnsibleDumper.__mro__
    assert callable(AnsibleDumper)

# Generated at 2022-06-23 05:35:44.584082
# Unit test for function represent_unicode
def test_represent_unicode():
    class RepresentUnicodeTest:
        represent_unicode_test_data_1 = AnsibleUnicode(u'foo')
        represent_unicode_test_data_2 = text_type(u'bar')

    dump_data = yaml.dump(RepresentUnicodeTest(), Dumper=AnsibleDumper, default_flow_style=True)
    assert dump_data == '{represent_unicode_test_data_1: foo, represent_unicode_test_data_2: bar}\n'



# Generated at 2022-06-23 05:35:47.519026
# Unit test for function represent_binary
def test_represent_binary():
    assert AnsibleDumper.represent_binary(None, b'abcd') == AnsibleDumper.represent_binary(None, b'abcd')

# Generated at 2022-06-23 05:35:52.320443
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = dict(key1='value1', key2='value2')
    assert AnsibleDumper.represent_dict(data) == "!!python/object/apply:hostvars [['key1', 'value1'], ['key2', 'value2']]\n"

# Generated at 2022-06-23 05:35:55.367369
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template.safe_eval import Undefined
    dumper = AnsibleDumper()
    assert not dumper.represent_data(Undefined())



# Generated at 2022-06-23 05:35:59.748396
# Unit test for function represent_unicode
def test_represent_unicode():
    from ansible.parsing.yaml import objects
    stream = objects.AnsibleUnicode('bytes-converted-unicode')
    assert yaml.dump(stream, Dumper=AnsibleDumper) == 'bytes-converted-unicode\n...\n'

# Generated at 2022-06-23 05:36:05.092854
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(AnsibleDumper, 'foo') == u'foo'
    assert represent_unicode(AnsibleDumper, b'foo') == u'foo'
    assert represent_unicode(AnsibleDumper, u'foo') == u'foo'
    assert represent_unicode(AnsibleDumper, AnsibleUnicode('foo')) == u'foo'

# Generated at 2022-06-23 05:36:06.706266
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert hasattr(AnsibleDumper, 'add_representer')

# Generated at 2022-06-23 05:36:08.758541
# Unit test for function represent_undefined
def test_represent_undefined():
    ansible_dumper = AnsibleDumper()
    undefined = AnsibleUndefined()

    # Undefined always return False
    assert ansible_dumper.represent_undefined(undefined) is False



# Generated at 2022-06-23 05:36:18.329047
# Unit test for function represent_binary
def test_represent_binary():
    import sys
    import io

    if sys.version_info[0] < 3:
        # Python2
        binary_type = (lambda x: x)
        native_binary_type = str
    else:
        # Python3
        binary_type = bytes
        native_binary_type = bytes

    dumper = AnsibleDumper(stream=io.StringIO(), default_flow_style=False)
    dumper.open()

    bin_str = binary_type(b'\xe7\x9a\x84\xe6\xb5\x81\xe6\x8d\x95\xe8\xbe\xbe')
    dumper.represent_binary(bin_str)

    output = dumper.stream.getvalue()


# Generated at 2022-06-23 05:36:20.902369
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    dumper.represent_undefined(AnsibleUndefined)



# Generated at 2022-06-23 05:36:25.532871
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    with_param = AnsibleDumper(indent=4)
    without_param = AnsibleDumper()
    assert with_param.__dict__ == without_param.__dict__
    assert str(with_param) == str(without_param)
    assert repr(with_param) == repr(without_param)

# Generated at 2022-06-23 05:36:34.965137
# Unit test for function represent_unicode
def test_represent_unicode():
    # Create object for testing
    ansible_unicode = AnsibleUnicode(u'foo')

    # Create yaml objects for testing
    yaml_unicode = yaml.representer.SafeRepresenter.represent_str(AnsibleDumper, u'foo')
    yaml_bytes = yaml.representer.SafeRepresenter.represent_binary(AnsibleDumper, b'foo')

    # Call function under test, capture result
    result = represent_unicode(AnsibleDumper, ansible_unicode)

    # Test result and type
    assert result == yaml_unicode
    assert isinstance(result, yaml_unicode.__class__)

    # Call function under test on AnsibleUnsafeBytes, capture result
    ansible_bytes = AnsibleUnsafeBytes(b'foo')

# Generated at 2022-06-23 05:36:45.368046
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    ciphertext = b'$ANSIBLE_VAULT;1.1;AES256\n' \
                 b'31783930333236353430393366633534356563633762643433316139633662636436353830653238\n' \
                 b'35376461633961376435383064663035626261396133653033613365633265\n'
    encrypted_data = AnsibleVaultEncryptedUnicode(ciphertext)

# Generated at 2022-06-23 05:36:46.768837
# Unit test for function represent_undefined
def test_represent_undefined():
    # FIXME: Add a unit test for function represent_undefined
    pass

# Generated at 2022-06-23 05:36:51.552023
# Unit test for function represent_hostvars
def test_represent_hostvars():
    h = HostVars({'a': 1})

    # This will fail with an error if there is a bug
    # The error would look something like this:
    # RecursionError: maximum recursion depth exceeded in comparison
    result = yaml.dump(h, Dumper=AnsibleDumper)



# Generated at 2022-06-23 05:36:55.237335
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    if yaml.__with_libyaml__:
        assert isinstance(AnsibleDumper(None), yaml.representer.Representer)
    else:
        assert isinstance(AnsibleDumper(None), yaml.representer.BaseRepresenter)

# Generated at 2022-06-23 05:36:56.953476
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper is not None

# Generated at 2022-06-23 05:37:02.665923
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = dict(a=1, c=3)
    hostvars = HostVars(inventory=None, hostname='localhost')
    hostvars.data = data
    result = AnsibleDumper().represent_hostvars(hostvars)
    assert result.tag == u'!unsafe/dict', 'tag should be unsafe/dict'
    assert result.value == data, 'value should be data'



# Generated at 2022-06-23 05:37:06.078407
# Unit test for function represent_binary
def test_represent_binary():
    dumper = yaml.SafeDumper
    assert dumper.represent_binary(dumper, b'some string') == '!!binary |\n  c29tZSBzdHJpbmc=\n'

# Generated at 2022-06-23 05:37:10.050636
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = HostVars()
    hostvars['k1'] = 'v1'
    hostvars['k2'] = 'v2'
    data = represent_hostvars(AnsibleDumper, hostvars)
    assert data == {'k1': 'v1', 'k2': 'v2'}



# Generated at 2022-06-23 05:37:20.466541
# Unit test for function represent_unicode
def test_represent_unicode():
    assert(represent_unicode(AnsibleDumper(), u'u\u2029'.encode('utf-8')) == 'u\u2029')
    assert(represent_unicode(AnsibleDumper(), u'u\u2029') == 'u\u2029')
    assert(represent_unicode(AnsibleDumper(), u'u\u2029'.encode('utf-16')) == 'u\u2029')
    assert(represent_unicode(AnsibleDumper(), u'u\u2029'.encode('utf-32')) == 'u\u2029')
    assert(represent_unicode(AnsibleDumper(), 'u\u2029'.encode('utf-8')) == 'u\u2029')



# Generated at 2022-06-23 05:37:26.068126
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    bytes_type = b"\xFF\xFF\xFF\xFF"
    text_type = "\xFF\xFF\xFF\xFF"
    if dumper.represent_binary(bytes_type) != dumper.represent_binary(text_type):
        assert False, 'Binary format for string and bytes not same'

# Generated at 2022-06-23 05:37:35.338300
# Unit test for function represent_binary
def test_represent_binary():
    # Given
    input_unicode = u"\u043f\u0440\u0438\u0432\u0435\u0442"
    input_bytes = input_unicode.encode('utf8')
    input_ansible_unsafe_bytes = AnsibleUnsafeBytes(input_bytes)
    expected_output = b"!binary |-\n  0KLigw=="

    # When
    actual_output = yaml.dump(input_ansible_unsafe_bytes, Dumper=AnsibleDumper)
    actual_output_list = actual_output.split(b'\n')

    # Then
    assert actual_output_list[0] == expected_output

# Generated at 2022-06-23 05:37:38.455566
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = HostVars()
    hostvars['hello'] = 'world'
    data = yaml.dump(hostvars, Dumper=AnsibleDumper)
    assert u'hello: world\n' == data

# Generated at 2022-06-23 05:37:41.268266
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    AnsibleDumper(
        [],
        '',
        None,
        None,
        None,
        None,
        None
    )

# Generated at 2022-06-23 05:37:48.841780
# Unit test for function represent_hostvars
def test_represent_hostvars():
    y = yaml.safe_load
    d = yaml.safe_dump

    # no key, just value
    x = HostVars()
    assert x == y(d(x, Dumper=AnsibleDumper))

    # key and value
    x = HostVars({'a': 'b'})
    assert x == y(d(x, Dumper=AnsibleDumper))

    # key with dots and valid value
    x = HostVars({'a.b': 'c'})
    assert x == y(d(x, Dumper=AnsibleDumper))

    # key with dots and invalid value
    x = HostVars({'a.b': VarsWithSources({'c': 'd'})})
    assert x == y(d(x, Dumper=AnsibleDumper))

   

# Generated at 2022-06-23 05:37:54.397926
# Unit test for function represent_unicode
def test_represent_unicode():

    set_option_original = yaml.add_representer
    try:
        # Run test
        yaml.add_representer(
            AnsibleUnicode,
            represent_unicode,
        )
        data = AnsibleUnicode('\u2603')  # Snowman
        assert yaml.dump([data]) == '[Snowman]\n'

    finally:
        yaml.add_representer = set_option_original

# Generated at 2022-06-23 05:37:56.312012
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper()
    assert isinstance(dumper, SafeDumper)

# Generated at 2022-06-23 05:38:02.825552
# Unit test for function represent_unicode
def test_represent_unicode():
    # Test that a non-unicode string is properly converted to unicode
    # using the default encoding
    non_unicode_str = b'\xc3\xa9'
    expected_str = u'\xe9'
    ansible_representer = AnsibleDumper.yaml_representers[text_type]
    actual_str = ansible_representer.represent_data(text_type(non_unicode_str))
    assert expected_str == actual_str



# Generated at 2022-06-23 05:38:03.589067
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    AnsibleDumper()
    assert True



# Generated at 2022-06-23 05:38:05.556994
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('test'), Dumper=AnsibleDumper) == 'test\n...\n'

# Generated at 2022-06-23 05:38:07.108154
# Unit test for function represent_binary
def test_represent_binary():
    yaml.safe_dump(b"data", default_flow_style=True, Dumper=AnsibleDumper)

# Generated at 2022-06-23 05:38:10.898882
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    res = dumper.represent_undefined(u'foo')
    assert res is not None, 'represent_undefined returned value should not be None, but be true/false'
    try:
        res
    except Exception as e:
        raise Exception('represent_undefined returned value should not raise exception: %s' % e)

# Generated at 2022-06-23 05:38:15.536096
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hv = HostVars({"test": "ansible"})
    result = yaml.dump(hv, Dumper=AnsibleDumper)
    assert result == '{test: ansible}\n...\n'


# Unit test function represent_vault_encrypted_unicode

# Generated at 2022-06-23 05:38:27.258230
# Unit test for function represent_binary
def test_represent_binary():
    '''
    This is a very small test for the represent_binary function. It does not
    cover every case of its functionality but at least tests the happy path.
    '''
    # Create a simple dumper
    dumper = AnsibleDumper()

    # Create an instance of AnsibleUnsafeBytes
    x = AnsibleUnsafeBytes('abcde', errors='surrogate_or_strict')

    # Use the representer to convert to YAML string
    yaml_str = dumper.represent_binary(x)

    # The current value of yaml_str is "!!binary |\n  YWJjZGU=\n"
    # The following code converts the string to a dictionary.
    # The dictionary value for the '!!binary' key should be the base64 encoding
    # of the original string. Let's decode it and

# Generated at 2022-06-23 05:38:29.864959
# Unit test for function represent_unicode
def test_represent_unicode():
    yaml.dump(dict(data=u'\u2713'), default_flow_style=False, Dumper=AnsibleDumper)


# Generated at 2022-06-23 05:38:34.680796
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert yaml.dump(HostVars(dict(foo='bar')), Dumper=AnsibleDumper) == u'foo: bar\n'



# Generated at 2022-06-23 05:38:40.484306
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;5.1;ABCD;123123123\n123123123\n')
    assert yaml.safe_dump(data, default_flow_style=False, Dumper=AnsibleDumper) == "!vault |\n  $ANSIBLE_VAULT;5.1;ABCD;123123123\n  123123123\n\n"


# Generated at 2022-06-23 05:38:52.675784
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-23 05:38:53.961429
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    obj = AnsibleDumper()
    assert hasattr(obj, 'add_representer')

# Generated at 2022-06-23 05:38:56.852005
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = {'hostname': 'localhost', 'group': 'local'}
    result = yaml.dump(data, Dumper=AnsibleDumper)
    assert result == u'{hostname: localhost, group: local}\n'



# Generated at 2022-06-23 05:39:02.925256
# Unit test for function represent_unicode
def test_represent_unicode():
    # Test if 'unicode' object is represent with double quotes
    data = yaml.load(yaml.dump(u'unicode_string', Dumper=yaml.SafeDumper))
    assert isinstance(data, text_type)
    assert data == u'unicode_string'



# Generated at 2022-06-23 05:39:12.165910
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(u'Süßes Pond', Dumper=AnsibleDumper, default_flow_style=False).strip() == u"!ansible-unsafe |\n  - 'S\\xc3\\xbc\\xc3\\x9fes Pond'"
    assert yaml.dump(u'Süßes Pond'.encode('utf-8'), Dumper=AnsibleDumper, default_flow_style=False).strip() == u"!ansible-unsafe 'S\\xc3\\xbc\\xc3\\x9fes Pond'"
    assert yaml.dump(u'Süßes Pond'.encode('latin_1'), Dumper=AnsibleDumper, default_flow_style=False).strip() == u"!ansible-unsafe 'S\\xfc\\xdfes Pond'"

# Generated at 2022-06-23 05:39:13.345801
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper is not None



# Generated at 2022-06-23 05:39:13.821838
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert True

# Generated at 2022-06-23 05:39:23.966342
# Unit test for function represent_binary
def test_represent_binary():
    from io import BytesIO
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import b
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnsafeBytes

    d = AnsibleDumper()

    # Test binary data with '|' style
    output = BytesIO()
    d.represent_binary(b'\x00\x01\x02\x03\x04\x05\x06\x07', output)
    output.seek(0)
    data = AnsibleLoader(output).get_single_data()
    assert data == AnsibleUnsafeBytes(b'\x00\x01\x02\x03\x04\x05\x06\x07')

    #

# Generated at 2022-06-23 05:39:24.827414
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    AnsibleDumper()

# Generated at 2022-06-23 05:39:33.959314
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dict1 = dict(a=1, b=2)
    hostvars = HostVars(dict1)
    # hostvars.__dict__ is a dictproxy and cannot be dumped by default.
    # This will cause an error for function hostvars_from_yaml
    # make a local dict
    dict2 = dict(hostvars.__dict__)
    expected_result = yaml.representer.SafeRepresenter.represent_dict(AnsibleDumper, dict2)
    actual_result = represent_hostvars(AnsibleDumper, hostvars)
    assert actual_result == expected_result


# Generated at 2022-06-23 05:39:40.425140
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()
    veu = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256;user@domain.com\n3289f260e195f3095089b8c2b0d2b2c9ea93559ff8e17854b43811e7aeba6f0b\n')
    assert dumper.represent_data(veu) == u"!vault |\n  $ANSIBLE_VAULT;1.1;AES256;user@domain.com\n  3289f260e195f3095089b8c2b0d2b2c9ea93559ff8e17854b43811e7aeba6f0b\n  \n"


# Generated at 2022-06-23 05:39:49.423758
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\n33383538633033316262636235363934336433323362363066336435663833633061396136636536\n33333066626536643934623863323731623230666465653165643236346564393330323666373062\n35\n')
    dump = yaml.dump(data, Dumper=SafeDumper, default_flow_style=False)
    # Ensure data is returned as unicode
    assert isinstance(dump, text_type), 'dump result should be unicode'
    assert dump.startswith('!vault'), 'Dump should start with !vault'

# Generated at 2022-06-23 05:39:51.203957
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert '!!binary "bWV0YQ=="' == dumper.represent_binary(dumper, b'meta')



# Generated at 2022-06-23 05:39:59.150965
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # Note: since we need to test this with python2 we need to use b'' here
    # to not get unicode issues.
    from ansible.parsing.yaml.data import DataLoader

    data = b'{"foo": "bar"}'
    loader = DataLoader()
    hostvars = HostVars(loader._construct_mapping(loader.get_single_data(data), loader.compose_node, 'hostvars'), 'hostvars')
    yaml.dump(hostvars, Dumper=AnsibleDumper)

# Generated at 2022-06-23 05:40:09.281924
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    '''
    Test that the encrypted data is properly represented as yaml
    '''
    ydump = yaml.dump(
        {'encrypted': AnsibleVaultEncryptedUnicode('encrypted_data')},
        Dumper=AnsibleDumper,
        default_flow_style=False,
    )
    assert ydump == 'encrypted: !vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          62626463336534653933656464613836663162356539346362333862376162316535303937623761613\n          666537316162323662643062636138396130353431323961\n\n', ydump


# Generated at 2022-06-23 05:40:20.302949
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-23 05:40:31.669945
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    assert represent_vault_encrypted_unicode(
        AnsibleDumper, AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\n34346433356336646633396432653635373365336564623937306539376665363130303232613439\n38323232643536366137363738343534323961633532643566666139393833626333373466333465\n35306230323635363835646132313036346535333734313033376266616338386636373234656534\n6365623939316530353365663434336635653762633439\n')
    ) == yaml.representer.SafeRepresenter.represent_sc

# Generated at 2022-06-23 05:40:42.700090
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    v = AnsibleVaultEncryptedUnicode("foo")
    output = yaml.dump(v, Dumper=AnsibleDumper)

# Generated at 2022-06-23 05:40:53.990920
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert yaml.safe_dump(HostVars(dict(a=1, b=2)), Dumper=AnsibleDumper) == '{a: 1, b: 2}\n...\n'
    assert yaml.safe_dump(HostVarsVars(dict(a=1, b=2)), Dumper=AnsibleDumper) == '{a: 1, b: 2}\n...\n'
    assert yaml.safe_dump(VarsWithSources(dict(a=1, b=2)), Dumper=AnsibleDumper) == '{a: 1, b: 2}\n...\n'



# Generated at 2022-06-23 05:41:04.336128
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-23 05:41:10.671088
# Unit test for function represent_undefined
def test_represent_undefined():
    yaml.representer.Representer.add_representer(
        AnsibleUndefined,
        represent_undefined,
    )
    undefined = AnsibleUndefined()
    # The code path for different Python versions is different.
    # This ensure both code path are called.
    try:
        undefined.__bool__()
    except Exception:
        pass
    try:
        undefined.__nonzero__()
    except Exception:
        pass

# Generated at 2022-06-23 05:41:13.387984
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(b'\x80n\x00\x7f\xff') == "!!binary |\n  Bw4G/f/8=\n"

# Generated at 2022-06-23 05:41:23.327609
# Unit test for function represent_unicode
def test_represent_unicode():
    '''
    Test ansible.utils.unsafe_proxy.AnsibleUnicode with !ansible/unsafe/unicode
    '''

    # Test one value
    # Note: dump function expects to receive a dict
    data = {'test': AnsibleUnicode('test')}
    dumped = yaml.dump(data, Dumper=AnsibleDumper, default_flow_style=False)
    assert dumped == """\
test: !ansible/unsafe/unicode 'test'\n"""  # noqa: F821

    # Test two values
    data = {'a': AnsibleUnicode('test'), 'b': AnsibleUnicode('test')}
    dumped = yaml.dump(data, Dumper=AnsibleDumper, default_flow_style=False)

# Generated at 2022-06-23 05:41:26.243668
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode(u'hello world'), Dumper=AnsibleDumper) == u'hello world\n...\n'



# Generated at 2022-06-23 05:41:29.769213
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    ad = AnsibleDumper(default_flow_style=False)
    assert isinstance(ad, AnsibleDumper)



# Generated at 2022-06-23 05:41:31.684363
# Unit test for function represent_binary
def test_represent_binary():
    data = yaml.safe_load(u"---\n- !binary |\n  x\n")
    assert isinstance(data[0], binary_type)



# Generated at 2022-06-23 05:41:39.441374
# Unit test for function represent_unicode
def test_represent_unicode():
    ad = AnsibleDumper(sort_keys=True)
    string_value = u"Lightweight Directory Access Protocol"
    expected_yaml = u"'Lightweight Directory Access Protocol'"
    actual_yaml = ad.represent_unicode(string_value)
    try:
        assert actual_yaml == expected_yaml
    except AssertionError:
        raise AssertionError("Expected '{0}' instead of '{1}'".format(expected_yaml, actual_yaml))
        return 1
    else:
        return 0



# Generated at 2022-06-23 05:41:49.588127
# Unit test for function represent_hostvars
def test_represent_hostvars():
    '''
    This is a unit test for function represent_hostvars
    '''
    # XXX: Note: This unit test doesn't actually assert anything.
    # It's here so we'll remember to implement one if we ever convert
    # represent_hostvars to a function.

    # Test that all data types are properly encoded
    # string, bool, integer, float, list, dict, datetime
    # Create a simple hostvars object
    simple_hostvars = HostVars()
    simple_hostvars.update({
        'string': 'string',
        'bool': True,
        'integer': 1,
        'float': 1.1,
        'list': [1, 2, 3],
        'dict': {'key': 'value'},
        'datetime': datetime.datetime.now(),
    })

# Generated at 2022-06-23 05:41:52.878729
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('value'), Dumper=AnsibleDumper) == 'value\n...\n'

