

# Generated at 2022-06-23 05:32:02.238356
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    string = '$ANSIBLE_VAULT;1.1;AES256\n6333626431633133353765646635346431303262633961376239633666656232323966623434636230\n3935363664336562303031666266323662323166633165373536303733383966636132343861353732\n3264393366356232396630653135663962373962633231343535636133613861623438343330366239\n6639623430663636396633\n'

# Generated at 2022-06-23 05:32:05.163366
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    data = HostVars({'foo': 'bar'})
    assert dumper.represent_hostvars(data).value == '{foo: bar}\n'

# Generated at 2022-06-23 05:32:09.294956
# Unit test for function represent_binary
def test_represent_binary():
    b = b"hello"
    d = AnsibleDumper()
    assert d.represent_binary(b) == d.represent_str(b)



# Generated at 2022-06-23 05:32:18.281220
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    class Test1:
        def __init__(self, _ciphertext):
            self._ciphertext = _ciphertext

# Generated at 2022-06-23 05:32:20.468755
# Unit test for function represent_hostvars
def test_represent_hostvars():

    repr = AnsibleDumper().represent_hostvars(HostVars(variable_manager=None, loader=None))
    assert repr == u"{}"

# Generated at 2022-06-23 05:32:26.542056
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    # Test that the constructor of class AnsibleDumper doesn't fail on defaults
    AnsibleDumper()

    # Test that the constructor of class AnsibleDumper fails for invalid 'Dumper' arguments
    try:
        AnsibleDumper(a='b')
        assert False, "AnsibleDumper failed to catch kwargs it doesn't expect"
    except TypeError:
        pass

# Generated at 2022-06-23 05:32:29.718921
# Unit test for function represent_undefined
def test_represent_undefined():
    data = AnsibleUndefined()
    # make sure that we do not get a recursion error
    dumper = AnsibleDumper(None)
    dumper.represent_undefined(data)

# Generated at 2022-06-23 05:32:33.235619
# Unit test for function represent_binary
def test_represent_binary():
    data = AnsibleDumper.represent_binary(b'\x01\x02')
    assert data == "!!binary |\n  AQI="



# Generated at 2022-06-23 05:32:40.488123
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources

    d = HostVars('', '', {})
    d2 = VarsWithSources('', '', {})

    assert yaml.dump(d, Dumper=AnsibleDumper).strip() == '{}'
    assert yaml.dump(d2, Dumper=AnsibleDumper).strip() == '{}'

# Generated at 2022-06-23 05:32:51.411312
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper(width=4096)
    assert dumper.represent_unicode(u'comment') == yaml.representer.SafeRepresenter.represent_str(dumper, 'comment')
    assert dumper.represent_unicode(u'comment') == yaml.representer.SafeRepresenter.represent_unicode(dumper, u'comment')
    assert dumper.represent_unicode(u'comment') != yaml.representer.SafeRepresenter.represent_unicode(dumper, 'comment')
    assert dumper.represent_unicode(u'comment') != yaml.representer.SafeRepresenter.represent_str(dumper, u'comment')

    # We want to support boolean type

# Generated at 2022-06-23 05:33:01.388510
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01') == u"!!binary 'AAE='"
    assert dumper.represent_binary(b'\x00\x01', style='|') == u"!!binary |\n  AA=="
    assert dumper.represent_binary(b'\x00\x01', style='>') == u"!!binary >\n  AAE="

    # Ensure that the 'binary' tag is prepended
    # if it is not already present.
    assert dumper.represent_binary(u'\u0000\u0001') == u"!!binary 'AAE='"
    assert dumper.represent_binary(b'\x00\x01') == u"!!binary 'AAE='"

# Generated at 2022-06-23 05:33:09.890506
# Unit test for function represent_unicode
def test_represent_unicode():
    # Create a random string
    test_str = u"\u00E9\u00E9\u00E9\u1E00"

    test_representer = AnsibleDumper
    test_representer.add_representer(
        AnsibleUnicode,
        represent_unicode,
    )
    test_text = yaml.dump({'test_str': test_str}, Dumper=test_representer)
    assert test_text == u"{test_str: '\u00E9\u00E9\u00E9\u1E00'}\n"



# Generated at 2022-06-23 05:33:12.656579
# Unit test for function represent_unicode
def test_represent_unicode():
    data = 'hello world'
    d = yaml.dump(data, Dumper=AnsibleDumper)
    assert d
    assert d == '"hello world"\n'



# Generated at 2022-06-23 05:33:15.300963
# Unit test for function represent_binary
def test_represent_binary():
    ansible_dumper = AnsibleDumper()
    output = yaml.representer.SafeRepresenter.represent_binary(ansible_dumper, 'a')
    assert output == binary_type('!!binary a\n')

# Generated at 2022-06-23 05:33:26.523085
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-23 05:33:37.086860
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # test strings to represent as !vault
    test_strings = [
        u'\u00FCnic\u00F4de',  # unicode with accents
        b'\xFCnic\xF4de',  # bytes with accents
        u'\u00FC\u00F4\u00FC',  # repeated unicode string with accents
        u'unicode_without_accents',  # unicode string without accents
        b'unicode_without_accents',  # bytes string without accents
        b'bytes_without_accents',  # bytes string without accents
        u'',  # empty unicode string
        b'',  # empty bytes string
    ]

    for test_string in test_strings:
        data = AnsibleVaultEncryptedUnicode(test_string)
        assert yaml.round_

# Generated at 2022-06-23 05:33:38.302822
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper(), AnsibleDumper)

# Generated at 2022-06-23 05:33:39.808228
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper, yaml.dumper.Dumper)

# Generated at 2022-06-23 05:33:44.034953
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    """Instantiate an AnsibleDumper class and make sure that the
    """
    dumper = AnsibleDumper(None, None)

    # pylint: disable=no-member
    assert dumper.add_representer == yaml.representer.SafeRepresenter.add_representer

# Generated at 2022-06-23 05:33:46.455383
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(None) == 'null', 'Failed to represent undefined'

# Generated at 2022-06-23 05:33:52.863147
# Unit test for function represent_binary
def test_represent_binary():
    data = yaml.dump(b'\xc3\xb6\xc3\xa4\xc3\xbc', Dumper=AnsibleDumper)
    assert data == u'!!binary |-\n  w6TDtsO8\n'

    data = yaml.dump(b'hello world', Dumper=AnsibleDumper)
    assert data == "!!binary |-\n  aGVsbG8gd29ybGQ=\n"

# Generated at 2022-06-23 05:34:07.731134
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hv = HostVars()
    hv.name = "fqdn"
    hv.hostname = "hostname"
    hv.hostvars = VarsWithSources({})
    hv.hostvars.add_source(dict(a=1, b=dict(c=2)))
    hv.hostvars.add_source(dict(b=dict(c=3)))

    hv2 = HostVars()
    hv2.name = "fqdn"
    hv2.hostname = "hostname"
    hv2.hostvars = VarsWithSources({})
    hv2.hostvars.add_source(dict(a=1, b=dict(c=2)))

# Generated at 2022-06-23 05:34:13.456131
# Unit test for function represent_hostvars
def test_represent_hostvars():
    h = AnsibleDumper(indent=2)
    data = {'key': 'value'}
    assert h.represent_hostvars(HostVars(data)) == h.represent_dict({'.hostvars': data})



# Generated at 2022-06-23 05:34:17.134637
# Unit test for function represent_hostvars
def test_represent_hostvars():
    d = AnsibleDumper()
    hvars = HostVars("var_name", dict())
    serialized = d.represent_hostvars(hvars)
    assert dict == type(yaml.load(serialized))

# Generated at 2022-06-23 05:34:18.634396
# Unit test for function represent_undefined
def test_represent_undefined():
    yaml.safe_dump(AnsibleUndefined(), Dumper=AnsibleDumper)

# Generated at 2022-06-23 05:34:19.481119
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    AnsibleDumper()



# Generated at 2022-06-23 05:34:21.296269
# Unit test for function represent_binary
def test_represent_binary():
    ansible_dumper = AnsibleDumper()
    assert ansible_dumper.represent_data('ABC') == '!!binary |\n  QUJD\n'

# Generated at 2022-06-23 05:34:32.613693
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    vault = AnsibleVaultEncryptedUnicode()

# Generated at 2022-06-23 05:34:39.994550
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    assert represent_vault_encrypted_unicode(DumperMock(), AnsibleVaultEncryptedUnicode(u'hello')) == u'!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          30336138393634626338663966633663353839663734653032623165663233616435626464353463\n          3832366137343265663537376633363239343332623163370a346339653333363232393239353637\n          61636263323532616365323665653735333232646666623337656331653466363737616637363966\n          656333333239650a'

# Generated at 2022-06-23 05:34:42.816484
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper()
    assert dumper
    assert isinstance(dumper, yaml.representer.SafeRepresenter)



# Generated at 2022-06-23 05:34:45.414399
# Unit test for function represent_binary
def test_represent_binary():
    test = AnsibleUnsafeBytes(b'\x80\x00\x8a')
    yaml.dump(test, Dumper=AnsibleDumper)

# Generated at 2022-06-23 05:34:51.521794
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = HostVars()
    hostvars['inventory_hostname'] = 'foo'
    hostvars['group_names'] = ['group1', 'group2']
    assert yaml.dump(hostvars, Dumper=AnsibleDumper) == """{inventory_hostname: foo,
  group_names: [group1, group2]}
"""



# Generated at 2022-06-23 05:35:01.427590
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    d = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\n36333032656538306665353264356437613431353131626137653432386566303937613533623339\n64386263386237313136376338623433663664343566663264396235623163623662653338663634\n63313464346233326533316434646632396637336166623338623230393966333663653162376137\n61366437306262653238326430343736653731383430663338303137343732336633343562653836\n')

# Generated at 2022-06-23 05:35:05.081802
# Unit test for function represent_unicode
def test_represent_unicode():

    # Setup
    from ansible.module_utils.six import u
    dumper = AnsibleDumper()

    # Test
    result = dumper.represent_unicode(u('unicode_string'))

    # Verify
    assert result == u('unicode_string')



# Generated at 2022-06-23 05:35:08.689372
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper
    host = HostVars(dict(), dict())
    expected = u'{}\n'
    result = dumper.represent_hostvars(dumper, host)
    print(result)
    assert result == expected

# Generated at 2022-06-23 05:35:11.964199
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = dict(foo=1, bar=2)
    result = represent_hostvars(None, HostVars(data))
    assert result == {'foo': 1, 'bar': 2}



# Generated at 2022-06-23 05:35:21.094353
# Unit test for function represent_hostvars
def test_represent_hostvars():

    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    yaml.add_representer(
        AnsibleBaseYAMLObject,
        lambda dumper, data: dumper.represent_scalar(u'tag:yaml.org,2002:null', u'null')
    )

    data = '''
    ---
    hostvars:
        host1:
            name: localhost
        host2:
            name: localhost
    '''

    # Using AnsibleLoader(data, file=None) on the data
    # raises TypeError: __init__() got multiple values for
    # argument 'file'
    # For now, make a temporary file.
    import tempfile
    import io

    tmpfile = tempfile.mkstemp()

# Generated at 2022-06-23 05:35:28.114991
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = {'localhost': {'ansible_connection': 'local', 'ansible_host': 'localhost', 'ansible_user': 'user'}}
    result = yaml.dump(data, Dumper=AnsibleDumper)
    assert result == '{localhost: {ansible_connection: local, ansible_host: localhost, ansible_user: user}}\n'



# Generated at 2022-06-23 05:35:35.225777
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hv = HostVars('127.0.0.1', '0.3')
    hv.update({'foo': 'bar'})

    # Inject a non-serializable value
    # For example AnsibleUnsafeText
    hv['unsafe'] = AnsibleUnsafeText(text_type(u'Hello, uns\xe1fe!'))

    # We should not raise an exception
    d = AnsibleDumper()
    d.represent_hostvars(hv)



# Generated at 2022-06-23 05:35:38.721910
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper, type), "Failed to create instance of AnsibleDumper()"
    assert isinstance(AnsibleDumper(), yaml.representer.SafeRepresenter), "Failed to create instance of AnsibleDumper()"

# Generated at 2022-06-23 05:35:46.420671
# Unit test for function represent_unicode
def test_represent_unicode():
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import StringIO
    import sys

    sio = StringIO()
    dumper = AnsibleDumper(stream=sio)
    dumper.represent_unicode(u'unicode_key')
    result = sio.getvalue()
    if PY2:
        assert result == "'unicode_key'\n"
    else:
        assert result == "unicode_key\n"



# Generated at 2022-06-23 05:35:50.450108
# Unit test for function represent_unicode
def test_represent_unicode():
    from ansible.module_utils.common.yaml import AnsibleUnicode
    assert represent_unicode(None, AnsibleUnicode(u'test')) == u'test'



# Generated at 2022-06-23 05:36:02.270351
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'\x00\x01\x02') == \
        u'!!binary |\n' \
        u'  AAEBAQ==\n'
    assert dumper.represent_binary(dumper, b'\x00\x01\x02\x03') == \
        u'!!binary |\n' \
        u'  AAEBAQID\n'
    assert dumper.represent_binary(dumper, b'\x00\x01\x02\x03\x04') == \
        u'!!binary |\n' \
        u'  AAEBAQIDBAU=\n'

# Generated at 2022-06-23 05:36:07.485786
# Unit test for function represent_unicode
def test_represent_unicode():
    yaml.dump(AnsibleUnicode(text_type(u'foo')), default_flow_style=True)
    # with pytest.raises(TypeError):
    #    yaml.dump(AnsibleUnicode(u'foo'), default_flow_style=True)
    assert yaml.dump(AnsibleUnicode(text_type(u'foo')), default_flow_style=True) == "foo\n..."

# Generated at 2022-06-23 05:36:10.023446
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    data = b'foo'
    assert dumper.represent_binary(dumper, data) == u'!binary "Zm9v"'

# Generated at 2022-06-23 05:36:15.360050
# Unit test for function represent_unicode
def test_represent_unicode():
    # Test empty string
    yaml_obj = yaml.dump(u'', Dumper=AnsibleDumper)
    assert yaml_obj == "''\n"

    # Test non-empty string
    yaml_obj = yaml.dump(u'string', Dumper=AnsibleDumper)
    assert yaml_obj == "string\n"



# Generated at 2022-06-23 05:36:18.423377
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.safe_dump(text_type('test')) == u'test\n...\n'
    assert yaml.dump(text_type('test')) == u'test\n...\n'



# Generated at 2022-06-23 05:36:29.534169
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-23 05:36:36.574134
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.vars.passwordvars import PasswordVars
    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultLib

    class Options(object):
        vault_password_file = 'test/fixtures/vault/vault.txt'

    class Play(object):
        name = "test"
        hosts = ['127.0.0.1']

    class PlayContext(object):
        play = Play()
        vault_password = None
        def __init__(self):
            self.vault_password = 'test'

    vault = VaultLib(Options())
    variable_manager = VariableManager(loader=None, inventory=None, play=PlayContext())

    variable_manager.set_vault_password(vault.secrets)
    variable_manager.set_

# Generated at 2022-06-23 05:36:38.970323
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-23 05:36:44.867837
# Unit test for function represent_binary
def test_represent_binary():
    from ansible.module_utils.common.yaml import AnsibleDumper
    from ansible.utils.unsafe_proxy import ANSIBLE_TEST_DATA_ROOT

    test_data = open(ANSIBLE_TEST_DATA_ROOT + "/test_yaml_binary.txt").read()

    data = {u'text': test_data}

    yaml.dump(data, Dumper=AnsibleDumper)

# Generated at 2022-06-23 05:36:52.886881
# Unit test for function represent_undefined
def test_represent_undefined():
    # Setup
    test_yaml = """---
foo: 'bar'
most_likely_a_string: !!python/object/apply:__builtin__.str
    - [1, 'two', 3]
"""
    test_data = yaml.load(test_yaml, Loader=yaml.SafeLoader)

    # Note: in general we don't want to serialize undefined values so we'll just skip
    #       testing the output.
    yaml.dump(test_data, Dumper=AnsibleDumper, default_flow_style=False)

# Generated at 2022-06-23 05:36:54.300873
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper
    assert dumper is not None

# Generated at 2022-06-23 05:36:56.185784
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert yaml.dump(HostVars(dict()), Dumper=AnsibleDumper) == "{}\n..."



# Generated at 2022-06-23 05:37:06.239265
# Unit test for function represent_unicode
def test_represent_unicode():
    d = AnsibleDumper(indent=0)
    unicodestring = u'{0}'.format("some ascii text")
    assert d.represent_unicode(unicodestring) == yaml.representer.SafeRepresenter.represent_str(d, "some ascii text")
    assert d.represent_unicode(unicodestring) != yaml.representer.SafeRepresenter.represent_str(d, "some ascii text1")
    assert d.represent_unicode(unicodestring) != yaml.representer.SafeRepresenter.represent_str(d, u"some ascii text")

    unicodestring = u"some unicode text\u2014with unicode"

# Generated at 2022-06-23 05:37:10.950628
# Unit test for function represent_hostvars
def test_represent_hostvars():
    foo = HostVars({"test": "foo"})
    yaml_data = yaml.dump({foo: foo}, Dumper=AnsibleDumper)
    assert yaml_data == "test: foo\n", "HostVars representation should be a dict"



# Generated at 2022-06-23 05:37:19.394582
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import Jinja2Template
    chain = Jinja2Template()

    loader = yaml.SafeLoader
    loader.add_constructor(
        yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG,
        lambda loader, node: dict(loader.construct_pairs(node))
    )
    data = yaml.load("""
foo: {{ foo }}
baz: 42
""", Loader=loader)
    result = chain.do_template(data, dict(foo="bar"))

    assert result == dict(
        baz=42,
        foo="bar",
    )

# Generated at 2022-06-23 05:37:30.505513
# Unit test for function represent_unicode
def test_represent_unicode():
    # Assert various conditions for which the represent_unicode function
    # should return the same results as yaml.representer.SafeRepresenter.represent_str
    # 1. input type is AnsibleUnicode or any subtype of AnsibleUnicode
    assert represent_unicode(AnsibleDumper, AnsibleUnicode('')) == \
        yaml.representer.SafeRepresenter.represent_str(AnsibleDumper, '')
    assert represent_unicode(AnsibleDumper, u'') == yaml.representer.SafeRepresenter.represent_str(AnsibleDumper, '')
    assert represent_unicode(AnsibleDumper, 'hello') == yaml.representer.SafeRepresenter.represent_str(AnsibleDumper, 'hello')
    # 2. input type is AnsibleUn

# Generated at 2022-06-23 05:37:33.518274
# Unit test for function represent_unicode
def test_represent_unicode():
    data = AnsibleUnicode('hello world')
    s = yaml.dump(data, Dumper=AnsibleDumper)
    assert s == u'hello world\n...\n'


# Generated at 2022-06-23 05:37:37.485429
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    dumper.add_representer(binary_type, represent_binary)
    result = dumper.represent_binary(dumper.represent_binary, u'hello')
    assert result == (u'!binary |\n'
                      '  aGVsbG8=\n')

# Generated at 2022-06-23 05:37:40.977986
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    d = b'{"my_key": "my_value"}'

    r = dumper.represent_binary(dumper, d)
    assert r == "!!binary |\n  eyJteV9rZXkiOiAibXlfdmFsdWUifQ==\n"

# Generated at 2022-06-23 05:37:45.579486
# Unit test for function represent_binary
def test_represent_binary():
    bytes_in = b'\x00\xff\x01\xfe'
    yaml_out = yaml.dump(bytes_in, Dumper=AnsibleDumper)
    assert yaml_out == '!!binary |\n  AAAB/wAA'
    assert bytes_out == b'\x00\xff\x01\xfe'

# Generated at 2022-06-23 05:37:52.458542
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    ciphertext = "AES256_CTR:b'gAJVBw8CTyfDh7YjG1d2Q=='\n"
    data = AnsibleVaultEncryptedUnicode(ciphertext)
    output = yaml.dump(data, Dumper=AnsibleDumper)
    expected = "!vault |\n  AES256_CTR:b'gAJVBw8CTyfDh7YjG1d2Q=='\n"

    assert output == expected

# Generated at 2022-06-23 05:37:56.349225
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hv = HostVars('/some/path')
    assert represent_hostvars(AnsibleDumper, hv) == AnsibleDumper.represent_dict(dict(hv))


# Generated at 2022-06-23 05:38:06.284669
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vl = VaultLib(VaultSecret('secret'))
    encrypted_unicode = AnsibleVaultEncryptedUnicode(vl.encrypt('test'), b'$ANSIBLE_VAULT;1.0;AES256')

# Generated at 2022-06-23 05:38:15.537570
# Unit test for function represent_hostvars
def test_represent_hostvars():

    class TestVars(object):
        def __init__(self, test_dict):
            self._hostvars = test_dict

    hostvars = TestVars(
        dict(
            dict(
                simplevar="simplevalue",
                complexvar=dict(
                    complexvar1="complexvalue1"
                )
            )
        )
    )

    expected_result = '''simplevar: simplevalue
complexvar:
  complexvar1: complexvalue1'''

    result = yaml.dump(hostvars, Dumper=AnsibleDumper, default_flow_style=False)
    assert result == expected_result



# Generated at 2022-06-23 05:38:17.571024
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    stream = AnsibleDumper(use_ansible_safe=False)

    print(stream)

# Generated at 2022-06-23 05:38:21.990190
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, AnsibleUnicode(u'\u20ac')) == u'\u20ac'
    assert represent_unicode(None, AnsibleUnsafeText(u'\u20ac')) == u'\u20ac'

# Generated at 2022-06-23 05:38:26.893572
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert(
        yaml.dump(
            HostVars(
                {'a': 1, 'b': 'two'},
                vault_password='vault_password',
            ),
            Dumper=AnsibleDumper
        ) == 'a: 1\nb: two\n'
    )

# Generated at 2022-06-23 05:38:31.011511
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    mybinary = b'\x80\x00\x00\x00\x00\x00\x00\x00'
    result = dumper.represent_binary(dumper, mybinary)
    assert result.value == 'AAAAAAAbAAAAAAAAAQ=='

# Generated at 2022-06-23 05:38:36.162002
# Unit test for function represent_binary
def test_represent_binary():
    data = AnsibleUnsafeBytes('hello')
    dump = yaml.dump(data, Dumper=AnsibleDumper)
    assert dump == '!!binary |\n  aGVsbG8=\n'



# Generated at 2022-06-23 05:38:39.010158
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import Undefined
    data = AnsibleUndefined('test')
    AnsibleDumper.represent_undefined(data)
    assert isinstance(data, Undefined)

# Generated at 2022-06-23 05:38:44.349247
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.objects import AnsibleMapping
    data = HostVars({"foo": "bar"})
    dumper = AnsibleDumper
    result = dumper.represent_hostvars(dumper, data)
    assert isinstance(result, AnsibleMapping)
    assert list(result.items()) == [('foo', "bar")]

# Generated at 2022-06-23 05:38:50.595925
# Unit test for function represent_undefined
def test_represent_undefined():
    '''
    AnsibleUndefined should be represented as False
    '''
    dumper = AnsibleDumper
    puts = dumper.add_representer(AnsibleUndefined, represent_undefined)
    assert not dumper.represent_data(AnsibleUndefined())
    dumper.add_representer(AnsibleUndefined, puts)



# Generated at 2022-06-23 05:38:53.062114
# Unit test for function represent_undefined
def test_represent_undefined():
    assert False is yaml.safe_dump(AnsibleUndefined(), Dumper=yaml.SafeDumper)

# Generated at 2022-06-23 05:38:58.393622
# Unit test for function represent_hostvars
def test_represent_hostvars():
    ''' This function tests represent_hostvars function'''
    dumper = AnsibleDumper()
    hostvars = HostVars(dict(foo="foo"))

    assert yaml.safe_dump(dict(foo="foo"), Dumper=AnsibleDumper) == yaml.escape("{'foo': 'foo'}\n")
    assert dumper.represent_hostvars(hostvars) == yaml.escape("{'foo': 'foo'}\n")

# Generated at 2022-06-23 05:39:09.404089
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    ciphertext = vault.encrypt(b"my secret")
    encrypted_string = AnsibleVaultEncryptedUnicode(ciphertext)
    dumper = yaml.dumper.SafeDumper
    dumper.add_representer(
        AnsibleVaultEncryptedUnicode,
        represent_vault_encrypted_unicode,
    )
    result = yaml.dump(encrypted_string, Dumper=dumper)

# Generated at 2022-06-23 05:39:14.006931
# Unit test for function represent_binary
def test_represent_binary():
    try:
        yaml.safe_load(yaml.dump(binary_type(b'foo'), Dumper=AnsibleDumper))
    except yaml.serializer.SerializerError as e:
        raise AssertionError('Failed to serialize binary') from e

# Generated at 2022-06-23 05:39:23.452947
# Unit test for function represent_undefined
def test_represent_undefined():
    # Test for undefined variable.
    data = {'key': AnsibleUndefined()}
    result = yaml.safe_dump(data, default_flow_style=False, Dumper=AnsibleDumper)
    assert 'undefined' in result

    # Test for undefined variable in sequence.
    data = [AnsibleUndefined()]
    result = yaml.safe_dump(data, default_flow_style=False, Dumper=AnsibleDumper)
    assert 'undefined' in result

    # Test for defined variable.
    data = {'key': 'value'}
    result = yaml.safe_dump(data, default_flow_style=False, Dumper=AnsibleDumper)
    assert 'value' in result

# Generated at 2022-06-23 05:39:31.192628
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, u'foo') == yaml.representer.SafeRepresenter.represent_str(None, text_type(u'foo'))
    assert represent_unicode(None, u'bar') == yaml.representer.SafeRepresenter.represent_str(None, text_type(u'bar'))
    assert represent_unicode(None, u'baz') == yaml.representer.SafeRepresenter.represent_str(None, text_type(u'baz'))



# Generated at 2022-06-23 05:39:34.383138
# Unit test for function represent_unicode
def test_represent_unicode():
    y = AnsibleUnicode(u'test')
    # This is the function being tested
    assert yaml.dump(y, Dumper=AnsibleDumper) == u"test\n..."

# Generated at 2022-06-23 05:39:39.854772
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # Create an instance of HostVars
    hv = HostVars(name='test', variables={'key': 'value'})
    # Create an instance of the ansible dumper
    ad = AnsibleDumper(width=None)
    # Ensure we can represent a hostvars object
    assert ad.represent_hostvars(hv) == ad.represent_dict(hv)



# Generated at 2022-06-23 05:39:48.922554
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    vault = VaultLib('secret')

# Generated at 2022-06-23 05:39:51.356136
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

    class UnicodeHelper(object):
        def encode(self, encoding):
            return binary_type()

    assert dumper.represent_binary(UnicodeHelper()) is None



# Generated at 2022-06-23 05:40:01.672524
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper.yaml_representers[AnsibleUnicode] == represent_unicode
    assert AnsibleDumper.yaml_representers[AnsibleUnsafeText] == represent_unicode
    assert AnsibleDumper.yaml_representers[AnsibleUnsafeBytes] == represent_binary
    assert AnsibleDumper.yaml_representers[HostVars] == represent_hostvars
    assert AnsibleDumper.yaml_representers[HostVarsVars] == represent_hostvars
    assert AnsibleDumper.yaml_representers[VarsWithSources] == represent_hostvars
    assert AnsibleDumper.yaml_representers[AnsibleSequence] == yaml.representer.SafeRepresenter.represent_list

# Generated at 2022-06-23 05:40:05.870447
# Unit test for function represent_unicode
def test_represent_unicode():

    assert yaml.dump(u'bytes'.encode('utf-8'), default_flow_style=True, Dumper=AnsibleDumper) == u'bytes\n...\n'

# Generated at 2022-06-23 05:40:16.227263
# Unit test for function represent_unicode
def test_represent_unicode():
    foo = u'\u5f20\u6cd5\u5e93'  # "Zhang Feige"
    assert represent_unicode(AnsibleDumper, foo) == u": '{0}'".format(foo)

    foo = u'unicode? I thinks not'
    assert represent_unicode(AnsibleDumper, foo) == u": '{0}'".format(foo)

    foo = u"Zhang \N{CJK UNIFIED IDEOGRAPH-4E3A}"
    assert represent_unicode(AnsibleDumper, foo) == u": '{0}'".format(foo)

    foo = text_type(b'\xc3\xb1andicode?')

# Generated at 2022-06-23 05:40:25.126643
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    data = u'test'
    encrypted_data = AnsibleVaultEncryptedUnicode(vault.encrypt(data))
    assert encrypted_data._ciphertext.decode() != data
    # encrypt() is based on the key, so running the test twice would not match
    encrypted_data2 = AnsibleVaultEncryptedUnicode(vault.encrypt(data))
    assert encrypted_data._ciphertext.decode() != encrypted_data2._ciphertext.decode()
    test_string = "!vault |\n          %s" % encrypted_data._ciphertext.decode()
    test_dumper = AnsibleDumper(width=255)
    assert test_dumper.represent_scalar

# Generated at 2022-06-23 05:40:30.097521
# Unit test for function represent_undefined
def test_represent_undefined():
    data = AnsibleUndefined('x')
    d = AnsibleDumper()
    assert d.represent_undefined(data) == False
    assert d.represent_undefined(True) == True
    assert d.represent_undefined(False) == False
    assert d.represent_undefined(None) == False

# Generated at 2022-06-23 05:40:33.316103
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    binary = b'\x00\x01'
    assert dumper.represent_binary(dumper, binary) == "!!binary 'AAE='"



# Generated at 2022-06-23 05:40:37.276309
# Unit test for function represent_binary
def test_represent_binary():
    data = AnsibleUnsafeBytes(b'hi')
    rep = AnsibleDumper.represent_binary(data)
    assert rep.value == "!!binary 'aGk='"
    assert type(rep.value) == str



# Generated at 2022-06-23 05:40:40.813095
# Unit test for function represent_undefined
def test_represent_undefined():
    test_data = {'foo': '{{not_defined}}'}
    output = yaml.safe_dump(test_data, Dumper=AnsibleDumper)
    assert output == '{foo: !!bool False}\n'

# Generated at 2022-06-23 05:40:47.464138
# Unit test for function represent_unicode
def test_represent_unicode():
    data = AnsibleUnicode('\u2713')
    dump = yaml.dump(data, Dumper=AnsibleDumper)
    assert dump == u'!!python/name:ansible.parsing.yaml.objects.AnsibleUnicode u\'\u2713\'\n'



# Generated at 2022-06-23 05:40:58.345988
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    test_dumper = AnsibleDumper
    test_dumper.add_representer(
        AnsibleVaultEncryptedUnicode,
        represent_vault_encrypted_unicode,
    )
    example_str = 'test string'
    example_unicode = AnsibleVaultEncryptedUnicode(example_str)
    result = yaml.dump({'test': example_unicode}, Dumper=test_dumper)
    assert result == "test: !vault |\n  $ANSIBLE_VAULT;1.1;AES256\n  35306436336566653537373365353738343039383037643532643965333135626665336630353633\n  3930353436\n"

# Generated at 2022-06-23 05:41:05.863380
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper(width=1000)
    assert dumper.represent_binary(b'foo') == u'!!binary |\n  foo\n'
    assert dumper.represent_binary(u'foo'.encode('utf-8')) == u'!!binary |\n  foo\n', 'Ensure unicode is correctly encoded'

# Generated at 2022-06-23 05:41:10.061984
# Unit test for function represent_undefined
def test_represent_undefined():
    # Test with Unicode type
    text_obj = AnsibleUndefined()
    assert yaml.dump(text_obj, Dumper=AnsibleDumper) == '{}'

    # Test for bytes type
    bytes_obj = AnsibleUnsafeBytes(b'\xb5')
    assert yaml.dump(bytes_obj, Dumper=AnsibleDumper) == '{}'

# Generated at 2022-06-23 05:41:16.326445
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = HostVars(vars=dict(a=1, b=2, c=dict(d=3, e=4)))
    v = VarsWithSources(hostvars=hostvars)
    assert yaml.safe_dump({"x": v}, Dumper=AnsibleDumper) == 'x: {a: 1, b: 2, c: {d: 3, e: 4}}\n'



# Generated at 2022-06-23 05:41:23.409622
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = yaml.Dumper()
    yaml.add_representer(AnsibleVaultEncryptedUnicode, represent_vault_encrypted_unicode, Dumper=dumper.__class__)
    a = AnsibleVaultEncryptedUnicode('AES256', '$ANSIBLE_VAULT;1.1;AES256')
    assert yaml.dump(a, Dumper=dumper.__class__) == '!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          \n'


# Generated at 2022-06-23 05:41:27.118189
# Unit test for function represent_binary
def test_represent_binary():
    d = AnsibleDumper(default_style=None)  # default style is auto
    result = d.represent_binary(u'\uffff')
    assert result == u'!!binary |\n  //8=\n'



# Generated at 2022-06-23 05:41:36.476156
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Tests represent_vault_encrypted_unicode on data with a unicode ciphertext
    data = AnsibleVaultEncryptedUnicode(u'abc')
    assert yaml.dump(data, Dumper=AnsibleDumper) == '!vault |\n  abc\n'

    # Tests represent_vault_encrypted_unicode on data with a utf-8 ciphertext
    data = AnsibleVaultEncryptedUnicode(u'\xe2\x9c\x88')
    assert yaml.dump(data, Dumper=AnsibleDumper) == '!vault |\n  \xe2\x9c\x88\n'

    # Tests represent_vault_encrypted_unicode on data with a non-unicode ciphertext

# Generated at 2022-06-23 05:41:41.544463
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = HostVars(vars=dict(key='value'))
    assert dict(hostvars) == dict(key='value')
    d = yaml.dump(hostvars, Dumper=AnsibleDumper)
    assert d == 'key: value\n'



# Generated at 2022-06-23 05:41:50.978676
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-23 05:41:58.355196
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    from shutil import rmtree
    from tempfile import mkdtemp
    from ansible.vars.manager import load_extra_vars
    from ansible.vars.manager import load_options_vars
    tmpdir = mkdtemp(prefix='ansible_test_documenter')
    extra_vars = load_extra_vars(tmpdir)
    options_vars = load_options_vars(tmpdir, extra_vars)