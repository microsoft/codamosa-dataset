

# Generated at 2022-06-23 05:31:59.078319
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    # Note: we don't test the actual representation of any of the above classed,
    # we test that AnsibleDumper is "constructible", and can be used as a
    # replacement for yaml.dump(s)
    for data in [
        {'a': 'A', 'b': 'B'},
        [1, 2],
        'a',
        1,
        None,
        True,
        False,
        [],
        {},
    ]:
        text_type(yaml.dump(data, Dumper=AnsibleDumper))
        binary_type(yaml.dump(data, Dumper=AnsibleDumper))

# Generated at 2022-06-23 05:32:02.149054
# Unit test for function represent_hostvars
def test_represent_hostvars():
    yaml_string = yaml.dump({'foo': HostVars('bar')}, Dumper=AnsibleDumper)
    assert yaml_string == 'foo: bar\n'

# Generated at 2022-06-23 05:32:05.429529
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dump = AnsibleDumper().represent_hostvars(HostVars({'hostvars': {'a': 'b'}}))
    assert dump == '{hostvars: {a: b}}\n'


# Generated at 2022-06-23 05:32:16.131906
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper()
    assert isinstance(dumper, yaml.representer.SafeRepresenter)

    # By default, the test_AnsibleDumper doesn't check
    # the function is added or not.
    # So we need a test case to verify it.
    #
    # Test case: AnsibleDumper has representers of
    # AnsibleUnicode, AnsibleSequence, AnsibleMapping, AnsibleVaultEncryptedUnicode

    assert AnsibleUnicode in dumper.yaml_representers
    assert AnsibleSequence in dumper.yaml_representers
    assert AnsibleMapping in dumper.yaml_representers
    assert AnsibleVaultEncryptedUnicode in dumper.yaml_representers



# Generated at 2022-06-23 05:32:17.683919
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    d = AnsibleDumper
    assert d


# Generated at 2022-06-23 05:32:23.806736
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.objects import AnsibleMapping
    # Test that the representer runs when called
    assert AnsibleDumper.represent_hostvars({}) == AnsibleMapping()
    # Test that the representer maps HostVars to AnsibleMapping
    assert isinstance(AnsibleDumper.represent_hostvars(HostVars()), AnsibleMapping)
    # Test that the representer maps HostVarsVars to AnsibleMapping
  

# Generated at 2022-06-23 05:32:32.581134
# Unit test for function represent_unicode
def test_represent_unicode():
    # Check string with non-ascii characters
    from ansible.module_utils.six import b
    yaml_data = yaml.dump(dict(v=b('\u8def\u4e91').decode('utf-8')), Dumper=AnsibleDumper, default_flow_style=False)
    assert '\u8def\u4e91' in yaml_data

    # Check string with only ascii characters
    yaml_data = yaml.dump(dict(v=b('abc').decode('utf-8')), Dumper=AnsibleDumper, default_flow_style=False)
    assert 'abc' in yaml_data

    # Check integer

# Generated at 2022-06-23 05:32:34.712038
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper()
    assert dumper is not None



# Generated at 2022-06-23 05:32:43.695314
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    output = yaml.dump([AnsibleVaultEncryptedUnicode(b'test')], Dumper=AnsibleDumper)
    assert output == '- !vault |\n  $ANSIBLE_VAULT;1.1;AES256\n  396637353066643765666439343837666261356435373739303632393533663938656234303530\n  376638353661303665663035386361370a66303466366338623864353166656364313137396136\n  366230653365386638353666653563383037373338643162343734653732303562316339613733\n  39646461393964650a\n'

    # Test with multiple encrypted vault items

# Generated at 2022-06-23 05:32:46.786234
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    binary = b'\xff'
    assert dumper.represent_binary(binary) == u'!!binary |\n  //8=\n'

# Generated at 2022-06-23 05:32:48.021719
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    ansible_dumper = AnsibleDumper([])
    assert isinstance(ansible_dumper, AnsibleDumper)

# Generated at 2022-06-23 05:32:50.962285
# Unit test for function represent_undefined
def test_represent_undefined():
    s = AnsibleUndefined()
    d = AnsibleDumper()
    assert d.represent_undefined(s) == True
    assert d.represent_undefined(None) == False

# Generated at 2022-06-23 05:32:58.569842
# Unit test for function represent_hostvars
def test_represent_hostvars():
    '''
    Make sure HostVars are dumped as a dict
    '''
    test_hostvars = HostVars(hostname='test_host')
    test_hostvars.update({'foo': 'bar'})
    result = yaml.dump(test_hostvars, Dumper=AnsibleDumper)
    assert result == ("!!python/object/new:ansible.vars.hostvars.HostVars\n"
                      "hostname: test_host\n"
                      "foo: bar")

# Generated at 2022-06-23 05:33:08.729712
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    # Test case 1:
    assert AnsibleDumper.representers[AnsibleUnicode] == represent_unicode

    # Test case 2:
    assert AnsibleDumper.representers[AnsibleSequence] == yaml.representer.SafeRepresenter.represent_list

    # Test case 3:
    assert AnsibleDumper.representers[AnsibleMapping] == yaml.representer.SafeRepresenter.represent_dict

    # Test case 4:
    assert AnsibleDumper.representers[AnsibleVaultEncryptedUnicode] == represent_vault_encrypted_unicode

    # Test case 5:
    assert AnsibleDumper.representers[AnsibleUndefined] == represent_undefined

# Generated at 2022-06-23 05:33:17.406635
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    '''
    test represent_vault_encrypted_unicode()

    Parse the result of a serialized AnsibleVaultEncryptedUnicode object and
    double-check that the result is the same string. The idea is that the
    ciphertext cannot be changed by the serialization/deserialization process.
    '''
    try:
        from cryptography.fernet import Fernet
        from ansible.parsing.yaml import objects
        from ansible.parsing.vault import VaultLib
    except ImportError:
        return


# Generated at 2022-06-23 05:33:22.483847
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper(None, default_flow_style=False)
    dumped_value = dumper.represent_data(AnsibleVaultEncryptedUnicode('some_data'))
    assert dumped_value == u"!vault |\n          aW50ZXJuIGludGVybg==\n"



# Generated at 2022-06-23 05:33:27.879459
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    out = dumper.represent_binary(b'foo')
    # We need to encode the output as unicode because py3 requires a unicode
    # string and otherwise the output may be a byte string
    out = out.encode('utf-8')
    assert out == b'!!binary |\n  Zm9v\n'



# Generated at 2022-06-23 05:33:29.223296
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper



# Generated at 2022-06-23 05:33:33.787297
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = HostVars(HostVarsVars({'foo': 'bar', 'fie': 'baz'}))
    assert yaml.dump(hostvars, Dumper=AnsibleDumper) == '{foo: bar, fie: baz}\n'

# Generated at 2022-06-23 05:33:37.556959
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    data = HostVars(variable_manager=None, loader=None, hostname='example')
    data['foo'] = 1
    data['bar'] = 2
    assert dumper.represent_hostvars(data) == {'foo': 1, 'bar': 2}



# Generated at 2022-06-23 05:33:46.042190
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = SafeDumper
    representer = represent_unicode

    yaml_data = representer(dumper, 'foo')
    assert yaml_data == u'foo'

    yaml_data = representer(dumper, AnsibleUnicode('foo'))
    assert yaml_data == u'foo'

    yaml_data = representer(dumper, AnsibleUnsafeText('foo'))
    assert yaml_data == u'foo'

    yaml_data = representer(dumper, AnsibleUnsafeBytes(b'foo'))
    assert yaml_data == u'foo'



# Generated at 2022-06-23 05:33:55.781495
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources

    hostvars = HostVars(VarsWithSources({}, None, None), '192.168.0.1')
    assert isinstance(hostvars, VarsWithSources)
    assert isinstance(hostvars, HostVars)
    assert isinstance(hostvars, AnsibleMapping)

    tmp = yaml.dump({'hostvars': hostvars}, Dumper=AnsibleDumper)
    assert 'hostvars: {}' in tmp

# Generated at 2022-06-23 05:34:09.487910
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault_password = '$1$JJsvHslasdfasdfasdfasdfasdfasdf'
    vault = VaultLib(vault_password)
    vault_data = "This is the data to be encrypted"
    vault_encrypted_data = vault.encrypt(vault_data.encode('utf-8'))
    vault_unicode = AnsibleVaultEncryptedUnicode(vault_encrypted_data)
    dumper = AnsibleDumper()
    yaml_data = dumper.represent_scalar(u'!vault', vault_unicode._ciphertext.decode(), style='|')

# Generated at 2022-06-23 05:34:14.061042
# Unit test for function represent_hostvars
def test_represent_hostvars():
    '''
    represent_hostvars should not include data
    '''
    data = HostVars(vars={'test': 'test'})
    assert yaml.load(yaml.dump(data, Dumper=AnsibleDumper)) == {'test': 'test'}



# Generated at 2022-06-23 05:34:19.781088
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    my_dumper = AnsibleDumper()

    # Check ValueError, if a value is not specified
    try:
        my_dumper.add_representer(
            AnsibleVaultEncryptedUnicode,
        )
        raise AssertionError('Should not pass here')
    except ValueError:
        pass


if __name__ == '__main__':
    test_AnsibleDumper()

# Generated at 2022-06-23 05:34:23.463119
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = yaml.Dumper
    dumper.add_representer(AnsibleUnicode, represent_unicode)
    assert dumper.represent_unicode(dumper, u'#ansible-test') == u"'#ansible-test'"



# Generated at 2022-06-23 05:34:32.229604
# Unit test for function represent_unicode
def test_represent_unicode():
    # desired output string with unicode
    expected_string = u'''foo: u'bar'\n'''
    # create dumper
    dumper = AnsibleDumper()
    # create AnsibleUnicode with unicode
    ans_unicode = AnsibleUnicode(u'bar')
    # create string with unicode
    data = {u'foo': ans_unicode}
    # do the dump
    dumped_string = yaml.dump(data, Dumper=dumper)
    # compare the dumped and expected strings
    assert dumped_string == expected_string



# Generated at 2022-06-23 05:34:37.529457
# Unit test for function represent_hostvars
def test_represent_hostvars():
    h = HostVars(host_name='foo',  variables={u'bar': u'baz'})
    data = yaml.dump(h, Dumper=AnsibleDumper, default_flow_style=False)

    assert(data.strip() == u'{bar: baz}')

# Generated at 2022-06-23 05:34:41.188438
# Unit test for function represent_unicode
def test_represent_unicode():
    obj = AnsibleUnicode('hello_world')
    dumper = AnsibleDumper()
    output = dumper.represent_data(obj)
    assert output == "unicode('hello_world')\n"

# Generated at 2022-06-23 05:34:49.553662
# Unit test for function represent_unicode
def test_represent_unicode():

    # Create the AnsibleUnicode object
    safe_text_type = AnsibleUnicode('This is a unicode string')

    # Create the yaml safe representer object
    representer = yaml.representer.SafeRepresenter()

    # Use the represent_unicode function to represent the object as yaml
    yaml_output = represent_unicode(representer, safe_text_type)

    # Check that it is a string
    assert(isinstance(yaml_output, text_type))

    # Check that it is the correct string
    assert(yaml_output == u"'This is a unicode string'\n")



# Generated at 2022-06-23 05:34:59.708978
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

    output_str = dumper.represent_binary(b'foo')
    assert output_str == "!!binary \"Zm9v\"\n"

    output_str = dumper.represent_binary(b'foobar')
    assert output_str == "!!binary \"Zm9vYmFy\"\n"

    output_str = dumper.represent_binary(b'x \n\t x')
    assert output_str == "!!binary \"eCAgICB4\"\n"

    output_str = dumper.represent_binary(b'x \r\n\t x')
    assert output_str == "!!binary \"eCAgICB4\"\n"

    output_str = dumper.represent_binary(b'\n\t ')
    assert output

# Generated at 2022-06-23 05:35:01.899802
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    # Make sure AnsibleDumper can be initialized without error
    dumper = AnsibleDumper()
    assert dumper is not None

# Generated at 2022-06-23 05:35:04.393478
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == u"foo\n..."
#

# Generated at 2022-06-23 05:35:10.287629
# Unit test for function represent_unicode
def test_represent_unicode():
    data = AnsibleUnicode('abc')
    dumper = AnsibleDumper(
        default_flow_style=False,
        version=(1, 2),
        allow_unicode=True)
    expected = u"{1: 2}\n---\nabc\n...\n"
    result = yaml.dump(data, stream=None, Dumper=dumper)
    assert result == expected



# Generated at 2022-06-23 05:35:16.987571
# Unit test for function represent_undefined
def test_represent_undefined():
    # Need to set up the environment so that _fail_with_undefined_error is true
    old_env = AnsibleDumper.ignore_aliases
    AnsibleDumper.ignore_aliases = True
    try:
        rep = AnsibleDumper.represent_undefined(AnsibleDumper, AnsibleUndefined)
        # jinja's StrictUndefined returns False
        assert(rep is False)
    finally:
        AnsibleDumper.ignore_aliases = old_env

# Generated at 2022-06-23 05:35:22.152104
# Unit test for function represent_hostvars
def test_represent_hostvars():

    hv = HostVars()
    hv.set_variable('a', 'b')

    v = yaml.dump(hv, Dumper=AnsibleDumper, default_flow_style=False)
    assert v == """a: b
"""



# Generated at 2022-06-23 05:35:33.300575
# Unit test for function represent_hostvars
def test_represent_hostvars():
    '''
    Tests the ability to serialize the host variable dict
    '''

    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources

    data = {
        'a': '1',
        'b': '2',
        'v': VarsWithSources(dict(x='3', y=VarsWithSources(dict(z='4')))),
        'hv': HostVars(dict(x='5', y=HostVars(dict(z='6'))))
    }

    v = yaml.safe_dump(data, default_flow_style=False)

# Generated at 2022-06-23 05:35:43.835487
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    test_vault = VaultLib([])
    test_vault.load_cipher_class('AES256')
    test_vault.update({'vault_version': 1, 'vault_password': 'vault'})

    # try with explicit newline
    assert test_vault.dump(AnsibleVaultEncryptedUnicode(b'original\n'), 'yaml') == "!vault |\n  $ANSIBLE_VAULT;1.1;AES256\n  626f72726967686f6e6c0a\n"

    # try without newline

# Generated at 2022-06-23 05:35:46.870124
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    '''
    Tests the creation of the AnsibleDumper class.
    '''
    dumper = AnsibleDumper
    assert dumper
    # Check if there are no lines of code that are not covered by the unit tests
    print(dumper.__doc__)



# Generated at 2022-06-23 05:35:50.490970
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert represent_hostvars(AnsibleDumper, HostVars(dict())) == represent_hostvars(AnsibleDumper, HostVarsVars(dict())) == represent_hostvars(AnsibleDumper, VarsWithSources(dict()))

# Generated at 2022-06-23 05:36:01.447407
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    class FakeClass:
        pass

    ansible_dumper = AnsibleDumper(None, None, None, None, None, None, None)

    # Test the add_representer works with non-ansible classes
    ansible_dumper.add_representer(FakeClass, represent_undefined)
    assert ansible_dumper.represent_undefined == represent_undefined

    # Test the __init__ class works with Ansible classes
    ansible_dumper = AnsibleDumper()
    assert ansible_dumper.represent_undefined == represent_undefined
    assert ansible_dumper.represent_unicode == represent_unicode
    assert ansible_dumper.represent_binary == represent_binary

# Generated at 2022-06-23 05:36:04.070342
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper, type) and issubclass(AnsibleDumper, yaml.SafeDumper)
    assert hasattr(AnsibleDumper, 'add_representer')

# Generated at 2022-06-23 05:36:10.633111
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    bin_data1 = 'hello\n'
    bin_data2 = 'hello\n'.encode('utf8')
    rep1 = yaml.representer.SafeRepresenter.represent_binary(dumper, bin_data1)
    rep2 = yaml.representer.SafeRepresenter.represent_binary(dumper, bin_data2)
    assert rep1 == rep2
    assert rep1 == {'!!binary': 'aGVsbG8K'}

# Generated at 2022-06-23 05:36:15.057376
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    data = AnsibleUndefined("Not a regular string")
    result = dumper.represent_undefined(dumper, data)
    assert result == bool(data)

# Generated at 2022-06-23 05:36:16.464792
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper is not None

# Generated at 2022-06-23 05:36:23.062194
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = HostVars({}, True)
    # test undefined _host_name
    assert represent_hostvars(AnsibleDumper, data) == 'null'

    data = HostVars({u'test': u'123'}, True, host_name='localhost')
    # test localhost
    assert represent_hostvars(AnsibleDumper, data) == "{'vars': {'test': '123'}}"



# Generated at 2022-06-23 05:36:26.004594
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper(indent=2)
    result = dumper.represent_binary(binary_type('hello world'))
    assert result.value == '!!binary ""\n'



# Generated at 2022-06-23 05:36:29.500796
# Unit test for function represent_unicode
def test_represent_unicode():
    ansible = AnsibleUnicode(u'foo')
    # FIXME: is there a better way to test the function?
    assert yaml.dump(ansible, Dumper=AnsibleDumper) == u"'foo'\n"

# Generated at 2022-06-23 05:36:32.745806
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper(default_style='|', default_flow_style=False)
    result = dumper.represent_binary(b'foo')
    expected = '|\n  Zm9v\n'
    assert result == expected

# Generated at 2022-06-23 05:36:42.852589
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()
    data = AnsibleVaultEncryptedUnicode('foo')

# Generated at 2022-06-23 05:36:51.404797
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper
    class mock_data:
        _ciphertext = u'$ANSIBLE_VAULT;1.1;AES256'
    data = mock_data()
    prepped = u'!vault |\n          $ANSIBLE_VAULT;1.1;AES256'
    result = yaml.representer.SafeRepresenter.represent_scalar(dumper, u'!vault', data._ciphertext.decode(), style='|')
    assert(prepped == result)


# Generated at 2022-06-23 05:36:52.435381
# Unit test for function represent_undefined
def test_represent_undefined():
    assert(AnsibleDumper.represent_undefined(None, None) is False)

# Generated at 2022-06-23 05:37:03.102203
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = HostVars(path='localhost')

    hostvars['ansible_facts'] = {'foo': 'bar'}
    hostvars['vars'] = {'hello': 'world'}
    hostvars['group_names'] = ['ungrouped']
    hostvars['groups'] = {'ungrouped': {'hosts': ['localhost']}}
    hostvars['omit'] = 'omit_field'
    hostvars['all'] = {'omit_field': 'omit_field'}
    hostvars['complex'] = None
    hostvars['complex'] = {
        'list': [1, 2, 3],
        'dict': {'a': 1},
        'string': '123',
        'int': 1,
        'float': 1.0
    }

# Generated at 2022-06-23 05:37:06.127686
# Unit test for function represent_unicode
def test_represent_unicode():
    # Can't use assertIn, assertNotIn, assertTrue or assertFalse due to python2.6
    assert 'foo' in represent_unicode(None, u'foo')


# Generated at 2022-06-23 05:37:12.300215
# Unit test for function represent_undefined
def test_represent_undefined():
    yaml_loader = yaml.Loader('')
    yaml_loader.add_constructor(u'tag:yaml.org,2002:bool', yaml.constructor.SafeConstructor.construct_yaml_bool)
    assert yaml_loader.get_single_data() is True
    yaml_loader = yaml.Loader('nope')
    yaml_loader.add_constructor(u'tag:yaml.org,2002:bool', yaml.constructor.SafeConstructor.construct_yaml_bool)
    assert yaml_loader.get_single_data() is False

# Generated at 2022-06-23 05:37:22.818446
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.utils import dict_diff
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleUnsafeText

    a_dict = dict(
        ansible_ssh_host=AnsibleUnsafeText('172.17.0.2'),
        ansible_user=AnsibleUnsafeText('vagrant'),
        network_os=AnsibleUnsafeText('iosv'),
        ansible_connection=AnsibleUnsafeText('network_cli'),
        ansible_network_os=AnsibleUnsafeText('ios'),
        ansible_port=AnsibleUnsafeText('2222')
    )

# Generated at 2022-06-23 05:37:33.756518
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    import sys
    import os

    if sys.version_info[:2] == (2, 6):
        print('SKIP: Python 2.6 does not support null_representer in add_representer')
        return

    class FakeStream:
        def write(self, out):
            pass

    def null_representer(self, data):
        return self.represent_scalar('tag:yaml.org,2002:null', 'null', style='|')

    class MyDumper(AnsibleDumper):
        pass

    MyDumper.add_representer(
        type(None),
        null_representer,
    )

    # Dump regular data types
    result = yaml.dump(
        data={'a': 1},
        stream=FakeStream(),
        Dumper=MyDumper,
    )

# Generated at 2022-06-23 05:37:37.500803
# Unit test for function represent_undefined
def test_represent_undefined():
    '''
    Unit test for function represent_undefined
    :return:
    '''
    undef = AnsibleUndefined()
    assert AnsibleDumper.represent_undefined(None, undef) is True

# Generated at 2022-06-23 05:37:45.390160
# Unit test for function represent_hostvars
def test_represent_hostvars():
    code = '''
- hosts:
    - localhost
  gather_facts: no
  tasks:
    - debug:
        var: hostvars
    - debug:
        var: hostvars.localhost
'''
    dumper = AnsibleDumper
    in_data = {
        "_ansible_parsed": True,
        "gather_facts": "no",
        "hosts": ["localhost"],
        "tasks": [
            {
                "_ansible_verbose_always": True,
                "debug": {
                    "hostvars": {}
                }
            },
            {
                "_ansible_verbose_always": True,
                "debug": {
                    "var": {
                        "hostvars.localhost": {}
                    }
                }
            }
        ]
    }


# Generated at 2022-06-23 05:37:54.129768
# Unit test for function represent_unicode
def test_represent_unicode():

    # This is necessary for Python 3.4
    # and the test_unicode_syntax test
    # in test_loader.py
    yaml.add_representer(unicode, represent_unicode)

    # Build unicode object
    unicode_object = u'{}'.format(u'\xfc')

    # Build a yaml.dump sequence with our custom representer
    yaml_dump = yaml.dump(unicode_object, Dumper=AnsibleDumper)

    # Build a yaml.dump sequence with default representer
    yaml_dump_default = yaml.dump(unicode_object)

    # Verify that both dumps are the same
    assert yaml_dump == yaml_dump_default

# Generated at 2022-06-23 05:38:01.193945
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    val = AnsibleVaultEncryptedUnicode(b'$ANSIBLE_VAULT;11.22;AES256\n33333\n')
    result = (b'!vault |\n'
              b'          $ANSIBLE_VAULT;11.22;AES256\n'
              b'          33333\n')
    assert result == yaml.dump(val, Dumper=AnsibleDumper, default_flow_style=False)

# Generated at 2022-06-23 05:38:12.894078
# Unit test for function represent_unicode
def test_represent_unicode():
    # do not use global yaml
    yaml_load = yaml.safe_load
    yaml_dump = yaml.safe_dump

    # yaml.safe_load(text)
    assert yaml_load('- abc')[0] == u'abc'
    # yaml.safe_load(unicode)
    assert yaml_load(u'- abc')[0] == u'abc'
    # yaml.safe_load(binary)
    assert yaml_load(b'- abc')[0] == b'abc'
    # yaml.safe_load(binary, encoding='utf-8')
    assert yaml_load(b'- abc', encoding='utf-8')[0] == u'abc'
    # yaml.safe_load(binary, encoding='utf-8', allow_unic

# Generated at 2022-06-23 05:38:16.087970
# Unit test for function represent_unicode
def test_represent_unicode():
    """Make sure Unicode objects get represented properly."""
    AnsibleDumper.ignore_aliases = lambda *args: True

    assert yaml.dump(AnsibleUnicode('hello')) == u'hello\n...\n'



# Generated at 2022-06-23 05:38:22.001421
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper(
        indent=4, default_flow_style=False, sort_keys=True), AnsibleDumper)
    # Passing a value for Dumper
    assert isinstance(AnsibleDumper(
        Dumper=yaml.SafeDumper, default_flow_style=False, sort_keys=True), yaml.SafeDumper)

# Generated at 2022-06-23 05:38:28.652958
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hvars = HostVars(VarsWithSources({'var1': 'val1'}, module_vars=['var1'], host_vars=['var1']))
    data = dict(hvars)
    expected = yaml.SafeDumper.represent_dict(yaml.SafeDumper, data)
    assert represent_hostvars(yaml.SafeDumper, hvars) == expected



# Generated at 2022-06-23 05:38:35.479525
# Unit test for function represent_undefined
def test_represent_undefined():

    # Setup
    dumper = AnsibleDumper()

    # We just want to check that represent_undefined
    # is called and returns a bool.
    # So represent_sequece is updated to return True.
    called = False

    def fake_represent_undefined(self, data):
        nonlocal called
        called = True
        return True

    AnsibleDumper.add_representer(AnsibleUndefined, fake_represent_undefined)

    # Test
    dumper.represent_data(AnsibleUndefined())

    # Verify
    assert called

# Generated at 2022-06-23 05:38:38.744562
# Unit test for function represent_undefined
def test_represent_undefined():
    '''
    AnsibleUndefined should not be printed in the output
    '''
    test_string = AnsibleUndefined('test')
    assert yaml.dump(test_string) == "false\n"

# Generated at 2022-06-23 05:38:43.719011
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    # Exact match
    obj = AnsibleUndefined
    assert dumper.represent_undefined(obj)
    # Subclass of Undefined
    class UndefinedSubclass(AnsibleUndefined):
        pass
    obj = UndefinedSubclass
    assert dumper.represent_undefined(obj)


# Generated at 2022-06-23 05:38:55.422973
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    import re
    import sys

    if sys.version_info[0] < 3:
        unicode_type = unicode
    else:
        unicode_type = str

    # Make sure that the pattern for the encrypted string matches the actual results.
    #
    # This will be our test pattern.
    pattern = r'\!vault\s*\|\s*(.*)$'
    pattern = re.compile(pattern, re.MULTILINE)

    # Create a test string and encrypt it.
    test_string = u'This is a test string'

# Generated at 2022-06-23 05:39:05.781498
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # Test when __str__ returns unicode
    hv = HostVars('test')
    hv['foo'] = 'bar'
    assert yaml.dump({'foo': hv}, Dumper=AnsibleDumper) == u"foo: {'test': {'foo': u'bar'}}\n"

    # Test when __str__ returns str
    hv = HostVars('test')
    hv['foo'] = b'bar'
    assert yaml.dump({'foo': hv}, Dumper=AnsibleDumper) == u"foo: {'test': {'foo': 'bar'}}\n"

    # Test with yaml tags
    hv = HostVars('test')
    hv['foo'] = 10

# Generated at 2022-06-23 05:39:13.232203
# Unit test for function represent_binary
def test_represent_binary():
    data = AnsibleUnsafeBytes(b'123')
    # Set kwargs to something other than default,
    # so test will fail if it uses the constructor.
    kwargs = dict(indent=4)
    dumper = AnsibleDumper(**kwargs)
    ret = dumper.represent_binary(data)
    # Check if returned the original raw bytes from data, not the encoded
    assert ret == b'123\n...\n'



# Generated at 2022-06-23 05:39:17.089439
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    output = AnsibleDumper.represent_vault_encrypted_unicode(AnsibleDumper, AnsibleVaultEncryptedUnicode('foo'))
    assert output == '!vault |\n          Zm9v\n'


# Generated at 2022-06-23 05:39:19.036156
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper(indent=4, width=80, default_flow_style=False)

# Generated at 2022-06-23 05:39:26.937537
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hv = HostVars(dict(a=1, b=2))
    hvv = HostVarsVars(dict(c=3, d=4))
    hv.update(hvv)
    v = VarsWithSources(dict(e=5, f=6))
    v.update(hv)
    sample_data = dict(v)
    output = yaml.dump(sample_data, Dumper=AnsibleDumper, default_flow_style=False)
    assert output == '''a: 1
b: 2
c: 3
d: 4
e: 5
f: 6
'''
    assert isinstance(output, text_type)



# Generated at 2022-06-23 05:39:34.167258
# Unit test for function represent_binary
def test_represent_binary():
    yaml_obj = yaml.YAML()
    yaml_obj.default_flow_style = False
    yaml_obj.indent(sequence=4, offset=2)
    yaml_obj.width = 80

    yaml_str = "!!binary |\n  aGVsbG8gd29ybGQ=\n"
    output = yaml_obj.dump(binary_type("hello world")).rstrip()
    assert yaml_str == output



# Generated at 2022-06-23 05:39:36.787212
# Unit test for function represent_unicode
def test_represent_unicode():
    data = {'key': u'\N{SNOWMAN}'}
    dumper = AnsibleDumper()
    result = dumper.represent_data(data)
    assert result == '{key: "☃"}\n'



# Generated at 2022-06-23 05:39:42.296848
# Unit test for function represent_undefined
def test_represent_undefined():
    '''
    Test represent_undefined function
    '''
    # Value is AnsibleUndefined
    value = AnsibleDumper.represent_undefined(AnsibleDumper, AnsibleUndefined())
    assert value is True
    # Value is not AnsibleUndefined
    value = AnsibleDumper.represent_undefined(AnsibleDumper, 'not undefined')
    assert value is False

# Generated at 2022-06-23 05:39:53.025732
# Unit test for function represent_binary
def test_represent_binary():
    from collections import OrderedDict

# Generated at 2022-06-23 05:39:53.728573
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    pass

# Generated at 2022-06-23 05:39:59.029622
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()
    # Ciphertext is normally unicode, but in this case it doesn't matter
    ciphertext = 'ansible'
    encrypted_unicode = AnsibleVaultEncryptedUnicode(ciphertext)
    output = encrypted_unicode.__repr__()
    assert output == '!vault |\n  %s\n' % ciphertext

# Generated at 2022-06-23 05:40:03.031919
# Unit test for function represent_binary
def test_represent_binary():
    data = b'\xFF\xFE\x00\x00'
    expected = u'!!binary |\n  /wAA\n'
    assert yaml.dump(data, Dumper=AnsibleDumper) == expected



# Generated at 2022-06-23 05:40:06.086135
# Unit test for function represent_unicode
def test_represent_unicode():
    print(yaml.dump(dict(foo=AnsibleUnicode('pork chops')), Dumper=AnsibleDumper))

# Generated at 2022-06-23 05:40:10.557272
# Unit test for function represent_unicode
def test_represent_unicode():
    yaml_data = yaml.dump(
        {"foo": AnsibleUnicode(u'bar\u2026')},
        Dumper=AnsibleDumper,
        default_flow_style=False
    )
    assert yaml_data == 'foo: bar\\u2026\n'

# Generated at 2022-06-23 05:40:17.992075
# Unit test for function represent_unicode
def test_represent_unicode():
    ansible_dumper = AnsibleDumper([])
    data = u'unicode\U0001F4A9string'
    # Note: the following function call returns the following character in
    # a unicode string: U0001F4A9
    # https://www.fileformat.info/info/unicode/char/1f4a9/index.htm
    assert ansible_dumper.represent_unicode(u'unicode\U0001F4A9string') == ansible_dumper.represent_unicode(data)

# Generated at 2022-06-23 05:40:26.434036
# Unit test for function represent_unicode
def test_represent_unicode():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.unsafe_proxy import wrap_var, AnsibleUnsafeText

    # The string contains special characters, and should be quoted.
    string = "#Bad String\n"
    assert string.encode('utf-8') == b"#Bad String\n"

    ansible_unsafe_text = AnsibleUnsafeText(string, encoding='utf-8')

    assert represent_unicode(None, ansible_unsafe_text) == "!!python/unicode '#Bad String\\n'"
    assert ansible_unsafe_text.encode('utf8') == b"#Bad String\n"

    # Since represent_unicode needs to modify the string before checking if it
    # needs to be quoted, we need to call the `

# Generated at 2022-06-23 05:40:29.379262
# Unit test for function represent_binary
def test_represent_binary():
    data = b'foo'
    dumper = AnsibleDumper()
    rep = dumper.represent_binary(data)
    assert rep == u'foo'



# Generated at 2022-06-23 05:40:34.244111
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dump = yaml.dump(
        dict(
            hosts=dict(
                host1=dict(
                    ansible_host='127.0.0.1',
                    ansible_port=22,
                )
            )
        ),
        Dumper=AnsibleDumper,
    )
    assert dump == '{hosts: {host1: {ansible_host: 127.0.0.1, ansible_port: 22}}}\n'



# Generated at 2022-06-23 05:40:40.955158
# Unit test for function represent_binary
def test_represent_binary():
    '''Test represent_binary function with a safe string'''
    utf8 = b'\xe4\xe85\xe8\x94\x9f\xe3\x82\x8f\xe3\x81\x97\xe3\x81\x99\xe3\x81\x8e\xe3\x81\x9f\xe3\x82\x89\xe3\x81\x97\xe3\x81\xa6\xe3\x81\x8b\xe3\x81\x99'
    result = AnsibleDumper.represent_binary(AnsibleDumper, utf8)
    assert result.startswith(u'!!binary |')
    assert result.endswith(u'\n')



# Generated at 2022-06-23 05:40:42.790376
# Unit test for function represent_undefined
def test_represent_undefined():
    y = AnsibleDumper()
    assert y.represent_data(AnsibleUndefined) == u'null\n'

# Generated at 2022-06-23 05:40:46.449419
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, AnsibleUnicode(u"foo")) == yaml.representer.SafeRepresenter.represent_str(None, u"foo")

# Generated at 2022-06-23 05:40:51.424996
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    i = AnsibleDumper()
    assert isinstance(i, AnsibleDumper)
    yaml.representer.BaseRepresenter.add_representer(
        AnsibleUnicode,
        represent_unicode
    )

# Generated at 2022-06-23 05:40:58.529103
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper(default_style=None, default_flow_style=False)

    assert dumper.represent_unicode('a') == dumper.represent_unicode(AnsibleUnicode('a'))
    assert dumper.represent_unicode('a') == dumper.represent_unicode(AnsibleUnsafeText('a'))
    assert dumper.represent_unicode('a') == dumper.represent_unicode(AnsibleUnsafeBytes(b'a'))

# Generated at 2022-06-23 05:41:04.143474
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    for i in ("hello", u"hello", "\x01"):
        assert dumper.represent_unicode(i) == dumper.represent_unicode(u"hello")

# Generated at 2022-06-23 05:41:14.971481
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = yaml.SafeDumper


# Generated at 2022-06-23 05:41:18.595463
# Unit test for function represent_undefined
def test_represent_undefined():

    dumper = AnsibleDumper
    data = AnsibleUndefined('foo')
    try:
        represent_undefined(dumper, data)
    except SystemExit:
        pass
    else:
        raise AssertionError('doc failed to raise SystemExit exception')



# Generated at 2022-06-23 05:41:27.413091
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from test.hostvars.hostvars_data import hostvars_data
    from ansible.vars.hostvars import HostVars
    import ansible.vars.manager
    import ansible.vars.hostvars

    # Create yaml dump on HostVars object
    dump = yaml.dump(HostVars(hostvars_data))

    # Create object from yaml dump
    y = yaml.safe_load(dump)
    assert type(y) is dict

    # Expected dict
    y_dict = {
        "vars": {
            "test_var": "test_value"
        },
        "groups": {
            "group": {
                "vars": {
                    "test_var2": "test_value2"
                }
            }
        }
    }

# Generated at 2022-06-23 05:41:31.781759
# Unit test for function represent_unicode
def test_represent_unicode():
    """ Test represent_unicode """
    representer = yaml.representer.SafeRepresenter()
    string = u'helloworld'
    new_string = represent_unicode(representer, string)
    assert new_string == u'"helloworld"'

# Generated at 2022-06-23 05:41:33.604848
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, AnsibleUnicode('foo')) == represent_unicode(None, 'foo')



# Generated at 2022-06-23 05:41:36.348329
# Unit test for function represent_binary
def test_represent_binary():
    d = AnsibleDumper(indent=4, default_flow_style=False)
    result = d.represent_binary(b'bytes')
    assert result == "!!binary 'bytes'"

# Generated at 2022-06-23 05:41:46.707661
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    res = vault.encrypt('test')
    data_to_represent = AnsibleVaultEncryptedUnicode(res)
    ans_dumper = AnsibleDumper()

# Generated at 2022-06-23 05:41:54.182598
# Unit test for function represent_unicode
def test_represent_unicode():
    data = {'key': u'val'}
    assert yaml.dump(data, Dumper=AnsibleDumper) == '{key: val}\n'

    data = {'key': AnsibleUnicode(u'val')}
    assert yaml.dump(data, Dumper=AnsibleDumper) == '{key: val}\n'

    data = {'key': 'val'}
    assert yaml.dump(data, Dumper=AnsibleDumper) == '{key: val}\n'

    data = {'key': dict(key=u'val')}
    assert yaml.dump(data, Dumper=AnsibleDumper) == '{key: {key: val}}\n'

