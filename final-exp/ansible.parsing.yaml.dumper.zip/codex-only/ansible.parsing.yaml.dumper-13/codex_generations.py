

# Generated at 2022-06-23 05:31:56.718876
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper()
    repr(dumper)



# Generated at 2022-06-23 05:31:58.915606
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(
        AnsibleUnicode('a'), Dumper=AnsibleDumper
    ) == 'a\n...\n'



# Generated at 2022-06-23 05:32:05.163377
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars_obj = HostVars(var_manager=None, inventory=None)
    hostvars_obj.add_host('localhost')
    hostvars_obj['localhost'].update(dict(foo='bar'))

    output = yaml.dump(hostvars_obj, Dumper=AnsibleDumper)
    print(output)
    assert output == "localhost:\n  foo: bar\n\n"

# Generated at 2022-06-23 05:32:16.244636
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    string_data = "The secret is 42"
    encrypted_string = AnsibleVaultEncryptedUnicode(string_data)
    assert represent_vault_encrypted_unicode(AnsibleDumper, encrypted_string) == u'!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          3063643732343430343430616530333836393961383336366631333339333965376231353565333135\n          3765366533646237623039623963353231666532653165326530663931613661386335616362623337\n          333162366465396064623730356539376231363063383962\n          \n'


# Add tests for represent_hostvars and represent

# Generated at 2022-06-23 05:32:26.221053
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = {'all': {u'ansible_all_ipv4_addresses': [u'192.168.100.136', u'127.0.0.1'], u'ansible_all_ipv6_addresses': [u'::1'], u'ansible_architecture': u'x86_64', u'ansible_bios_date': u'04/01/2014', u'ansible_bios_version': u'6.00'}}
    h = HostVars(data)
    dumped = AnsibleDumper().represent_hostvars(h)
    print(dumped)

    # Check key ansible_all_ipv4_addresses in dumped

# Generated at 2022-06-23 05:32:32.513293
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(binary_type('test'), Dumper=AnsibleDumper) == '!!binary "dGVzdA=="'
    assert yaml.dump(binary_type('\x00\x01\x02\x03\x04\x05'), Dumper=AnsibleDumper) == '!!binary "AAECAwQF"\n'
    assert yaml.dump(binary_type(''), Dumper=AnsibleDumper) == '!!binary ""'

# Generated at 2022-06-23 05:32:34.174533
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dmp = AnsibleDumper()

# Generated at 2022-06-23 05:32:35.144266
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper()



# Generated at 2022-06-23 05:32:35.814320
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    AnsibleDumper()

# Generated at 2022-06-23 05:32:42.824064
# Unit test for function represent_unicode
def test_represent_unicode():
    '''
    Does the represent_unicode function work as expected?
    '''
    test_unicode = u'testme'
    ansible_representer = AnsibleDumper.represent_unicode
    python_representer = yaml.representer.SafeRepresenter.represent_str
    assert ansible_representer(AnsibleDumper, test_unicode) == python_representer(AnsibleDumper, text_type(test_unicode))



# Generated at 2022-06-23 05:32:46.270745
# Unit test for function represent_binary
def test_represent_binary():
    bin_data = b'\x80'
    assert yaml.dump(bin_data, Dumper=AnsibleDumper, default_flow_style=False) == "!!binary |\n  gA==\n"

# Generated at 2022-06-23 05:32:48.556347
# Unit test for function represent_binary
def test_represent_binary():
    data = yaml.dump({"test": "data"}, Dumper=AnsibleDumper)
    assert data == "{test: data}\n"

# Generated at 2022-06-23 05:32:59.991506
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    text = 'encrypted_data'
    encrypted_data = AnsibleVaultEncryptedUnicode(text)
    output = yaml.dump({'data': encrypted_data}, Dumper=AnsibleDumper)

# Generated at 2022-06-23 05:33:05.849187
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = HostVars()
    hostvars.vars = dict(ansible_connection='local')
    hostvars._sources = 'fake_sources'

    dump = yaml.safe_dump(hostvars, Dumper=AnsibleDumper)
    assert 'ansible_connection: local' in dump
    assert '_sources: fake_sources' in dump

# Generated at 2022-06-23 05:33:09.712153
# Unit test for function represent_unicode
def test_represent_unicode():
    # Note: we do not test represent_unicode here because it is
    # tested inside the tests for AnsibleUnicode.
    pass

# Generated at 2022-06-23 05:33:18.675487
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-23 05:33:25.845497
# Unit test for function represent_unicode
def test_represent_unicode():

    safe_text = AnsibleUnicode('test')
    safe_text_bytes = AnsibleUnicode('test'.encode('utf-8'))

    safe_text_representer = represent_unicode(None, safe_text)
    safe_text_bytes_representer = represent_unicode(None, safe_text_bytes)

    assert safe_text == text_type(safe_text_representer)
    assert 'test' in repr(safe_text_representer)
    assert ' unicode ' in repr(safe_text_representer)

    assert safe_text == text_type(safe_text_bytes_representer)
    assert 'test' in repr(safe_text_bytes_representer)
    assert ' unicode ' in repr(safe_text_bytes_representer)



# Generated at 2022-06-23 05:33:33.086116
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import Templar
    from ansible.template.safe_eval import SafeEval

    # This should not error out
    AnsibleDumper(actual_default_flow_style=None, allow_unicode=True).represent_undefined(Templar(None, SafeEval()).undefined())

    # But this should error out
    AnsibleDumper(actual_default_flow_style=None, allow_unicode=True).represent_undefined(Templar(None, SafeEval(always_fail=True)).undefined())

# Generated at 2022-06-23 05:33:41.003887
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import AnsibleUndefined
    from ansible.parsing.dataloader import DataLoader
    import yaml
    ldr = DataLoader()

    data = {'undefined_str': AnsibleUndefined, 'undefined_list': [AnsibleUndefined]}
    expected = 'undefined_str: null\nundefined_list:\n- null\n'

    assert yaml.dump(data, default_flow_style=False, Dumper=AnsibleDumper, loader=ldr) == expected

    data = {'undefined_str_in_sequence': [AnsibleUndefined]}
    expected = 'undefined_str_in_sequence:\n- null\n'


# Generated at 2022-06-23 05:33:46.350748
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    u_string = u'unicode string'
    assert dumper.represent_unicode(u_string) == u"'unicode string'"
    assert dumper.represent_unicode(u_string) == dumper.represent_unicode(u_string.encode('utf-8'))



# Generated at 2022-06-23 05:33:52.790041
# Unit test for function represent_binary
def test_represent_binary():
    dumper = yaml.Dumper()
    yaml.add_representer(binary_type,
                         lambda dumper, value: yaml.ScalarNode(tag=u'tag:yaml.org,2002:binary', value=value.decode("utf-8")),
                         Dumper=dumper.__class__)
    assert dumper.represent_scalar(u'tag:yaml.org,2002:binary', b'base64 encoded data')

# Generated at 2022-06-23 05:33:57.661756
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    undefined = AnsibleUndefined('test')

    # Calling represent_undefined with an AnsibleUndefined should raise an exception
    # while calling it with an integer should work
    assert dumper.represent_undefined(undefined) == True
    assert dumper.represent_undefined(1) == False

# Generated at 2022-06-23 05:33:58.502031
# Unit test for function represent_hostvars
def test_represent_hostvars():
    pass

# Generated at 2022-06-23 05:34:03.659260
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper(None, None, None)
    assert dumper


# Generated at 2022-06-23 05:34:12.749664
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper

    # Test for empty bytes
    cipherbytes = b''

    # Test for empty string
    ciphertext = u''

    # Test for normal data
    text = u'abc'

# Generated at 2022-06-23 05:34:15.179455
# Unit test for function represent_undefined
def test_represent_undefined():
    a = AnsibleDumper()
    a.represent_undefined(AnsibleUndefined)

test_represent_undefined()

# Generated at 2022-06-23 05:34:16.592297
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper, type)



# Generated at 2022-06-23 05:34:23.638575
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    ciphertext = AnsibleVaultEncryptedUnicode(('$ANSIBLE_VAULT;1.1;AES256\n'
                                               '3332663137376439633533643966333061366639333632643232376362383732373934353334646535\n'
                                               '3361356332613761396231353964636164303366353132633438316231633563306638313434306537\n'
                                               '6136333234326662333266626264356635386531373638646361323262303765373966303362663334\n'
                                               '3662\n'))
    dumper = AnsibleDumper()
    result = dumper.represent_vault_encrypted

# Generated at 2022-06-23 05:34:34.541341
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    '''
    Tests the output of the function represent_vault_encrypted_unicode
    '''
    data_string = AnsibleVaultEncryptedUnicode('abcdefgh')
    result = represent_vault_encrypted_unicode(yaml.representer.SafeRepresenter(), data_string)

# Generated at 2022-06-23 05:34:43.381742
# Unit test for function represent_hostvars
def test_represent_hostvars():
    a = AnsibleDumper()

    ansible1 = a.represent_hostvars({'a': 1, 'b': '2'})
    ansible2 = a.represent_dict({'a': 1, 'b': '2'})
    assert ansible1 == ansible2

    ansible1 = a.represent_hostvars({'a': 1, 'b': {'b1': '2', 'b2': 3}})
    ansible2 = a.represent_dict({'a': 1, 'b': {'b1': '2', 'b2': 3}})
    assert ansible1 == ansible2

# Generated at 2022-06-23 05:34:54.494460
# Unit test for function represent_hostvars
def test_represent_hostvars():
    test_loader = yaml.SafeLoader(None)
    test_loader.add_constructor(u'tag:yaml.org,2002:str', lambda loader, node: str(node.value))
    test_loader.add_constructor(u'tag:yaml.org,2002:map', lambda loader, node: dict(loader.construct_pairs(node)))
    test_loader.add_constructor(u'!vault', lambda loader, node: str(node.value))
    test_dict = {'var1': 'value1', 'var2': 'value2', 'var3': 'value3'}
    test_hostvars = HostVars(all_vars=test_dict, hostvars=test_dict)


# Generated at 2022-06-23 05:34:58.972736
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # AnsibleDumper is the subclass of yaml.SafeDumper
    # object_hook is a callable invoked to transform the result of
    #   dictionay parsing
    result = yaml.dump(HostVars({}), Dumper=AnsibleDumper, default_flow_style=False)
    assert result == '{}\n...\n'



# Generated at 2022-06-23 05:34:59.938301
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper

# Generated at 2022-06-23 05:35:08.320366
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # test string
    src = u'foo'

    # construct an AnsibleVaultEncryptedUnicode object
    ciphertext = text_type(u'!vault |$ANSIBLE_VAULT;1.1;AES256\n33616135633231396336316437613437646132333663663531386232383337373539303063386233\n32303534363937636262616632386335616630356430323562613937353930383361333738386438\n64323263666231666332653634613734383763316261373133313931333531643165656434616630\n336634363361353661353333313135393364313561356438\n')

# Generated at 2022-06-23 05:35:14.154807
# Unit test for function represent_unicode
def test_represent_unicode():
    """
    >>> import yaml
    >>> ansible_dumper = AnsibleDumper
    >>> ansible_dumper.add_representer(
    ...     AnsibleUnicode,
    ...     represent_unicode,
    ... )
    >>> string = u'a unicode string'
    >>> ansible_dumper.represent_unicode(string)
    u'"a unicode string"\\n'
    """



# Generated at 2022-06-23 05:35:15.815139
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper()
    assert dumper
    return dumper

# Generated at 2022-06-23 05:35:17.217321
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert(isinstance(AnsibleDumper, type))

# Generated at 2022-06-23 05:35:27.088657
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper

    assert dumper.represent_unicode(dumper, u"Hello Carem") == dumper.represent_str(dumper, u"Hello Carem")

    assert dumper.represent_unicode(dumper, u"Hello\u0020Carem") == dumper.represent_str(dumper, u"Hello\u0020Carem")

    assert dumper.represent_unicode(dumper, u"Hello\uFFFCCarem") == dumper.represent_str(dumper, u"Hello\uFFFCCarem")

# Generated at 2022-06-23 05:35:35.725407
# Unit test for function represent_binary

# Generated at 2022-06-23 05:35:46.013283
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.manager import HostVarsVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    hvv = HostVarsVars(variable_manager=VariableManager(), hostname='test_represent_hostvars')
    vws = VarsWithSources(hvv, templar=Templar())

    vws['test'] = 'test_represent_hostvars'

    assert yaml.dump(vws, Dumper=AnsibleDumper, default_flow_style=False) == 'test: test_represent_hostvars\n\n'

# Generated at 2022-06-23 05:35:54.089507
# Unit test for function represent_binary
def test_represent_binary():
    o = u'\u2122'

    # Unicode
    dumper = AnsibleDumper()
    value = dumper.represent_binary(o)
    assert type(value) == yaml.nodes.ScalarNode
    assert value.value == "\\u2122"

    # Bytes
    dumper = AnsibleDumper()
    value = dumper.represent_binary(o.encode('utf-8'))
    assert type(value) == yaml.nodes.ScalarNode
    assert value.value == "\\xe2\\x84\\xa2"

# Generated at 2022-06-23 05:35:59.636891
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-23 05:36:08.728970
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import BytesIO

    vault = VaultLib([])

# Generated at 2022-06-23 05:36:18.301114
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = yaml.representer.SafeRepresenter()
    dumper.add_representer(
        AnsibleVaultEncryptedUnicode,
        represent_vault_encrypted_unicode
    )
    # Test for object that has already been decrypted.

# Generated at 2022-06-23 05:36:22.112670
# Unit test for function represent_unicode
def test_represent_unicode():
    obj = AnsibleUnicode(u'Āé', encoding='utf-8')
    rep = AnsibleDumper.represent_unicode(None, obj)
    assert rep.value == u'Āé'

# Generated at 2022-06-23 05:36:24.320287
# Unit test for function represent_undefined
def test_represent_undefined():
    data = AnsibleUndefined()
    dumper = AnsibleDumper()

    assert dumper.represent_data(data) is None

# Generated at 2022-06-23 05:36:25.135732
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper, type)

# Generated at 2022-06-23 05:36:28.299606
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    # A Unicode string to represent
    test_data = "foo"
    # Expected YAML output form
    expected_yaml = "'foo'"
    test_yaml = dumper.represent_unicode(test_data)
    assert test_yaml == expected_yaml


# Generated at 2022-06-23 05:36:38.740286
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault.update({'password': 'secret'})
    # See https://github.com/ansible/ansible/issues/12286
    # if set_encrypted_data is not called here,
    # the dumped output will not work with Ansible 1.8.2 and earlier
    a = AnsibleVaultEncryptedUnicode(vault.encrypt('test'))
    a.set_encrypted_data(a.get_encrypted_data())
    out = yaml.dump([a,a], Dumper=AnsibleDumper, default_flow_style=False)

# Generated at 2022-06-23 05:36:43.261886
# Unit test for function represent_undefined
def test_represent_undefined():
    class MyUndefined(AnsibleUndefined):
        pass
    dumper = yaml.SafeDumper
    dumper.add_representer(AnsibleUndefined, represent_undefined)

    # expect no exception to be raised
    dumper.represent_undefined(dumper, MyUndefined)

# Generated at 2022-06-23 05:36:47.576689
# Unit test for function represent_unicode
def test_represent_unicode():
    representer = AnsibleDumper(None, None, None, None)
    assert representer.represent_unicode(u'foo') == (u'foo',)
    assert representer.represent_unicode(u'foo') == (u'foo',)

# Generated at 2022-06-23 05:36:56.755603
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    import sys
    if sys.version_info[0] == 2:
        test_string = text_type(u'foo')
    else:
        test_string = u'foo'

    # Clear the ciphertext cache
    ciphertext = AnsibleVaultEncryptedUnicode(test_string)._ciphertext
    del AnsibleVaultEncryptedUnicode._ciphertext_cache[ciphertext]

    expected = u'!vault |\n' + text_type(ciphertext)
    actual = yaml.dump(AnsibleVaultEncryptedUnicode(test_string), Dumper=AnsibleDumper, default_flow_style=False)

    assert expected.rstrip() == actual.rstrip()

# Generated at 2022-06-23 05:36:59.518154
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    try:
        AnsibleDumper()
    except:
        raise AssertionError("Instantiating AnsibleDumper throws an exception when it should not")


# Generated at 2022-06-23 05:37:00.439042
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert(AnsibleDumper)

# Generated at 2022-06-23 05:37:10.539425
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = yaml.Dumper
    dumper.add_representer(HostVars, represent_hostvars)

    # Testing the default value of ansible_hostname
    hostname = HostVars()

    dumper.add_representer(HostVars, represent_hostvars)

    name = HostVarsVars(u'name', u'test')
    hostname.add_host_var(u'name', name)

    assert yaml.dump(hostname) == u'name: test\n'

    # Testing HostVarsVars
    hostname = HostVars()

    # Empty HostVarsVars, testing default values
    vars = HostVarsVars()
    hostname.add_host_var(u'name', vars)
    assert yaml.dump(hostname) == u

# Generated at 2022-06-23 05:37:21.262034
# Unit test for function represent_binary
def test_represent_binary():

    dumper = AnsibleDumper
    binary = b'\xee\xbb\xaa\xee'
    repr_binary = yaml.representer.SafeRepresenter.represent_binary(dumper, binary)
    ref_repr_binary = "!binary |\n  -8j+e\n"

    assert repr_binary == ref_repr_binary


if __name__ == '__main__':
    import sys
    import unittest

    sys.modules['_ansible_test_mock_module'] = type(sys)('_ansible_test_mock_module')
    sys.modules['_ansible_test_mock_module'].__spec__ = type(sys)('__spec__')
    sys.modules['_ansible_test_mock_module'].__spec__.loader

# Generated at 2022-06-23 05:37:32.499431
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultEditor
    from io import StringIO
    import codecs
    # Create a vault file

# Generated at 2022-06-23 05:37:43.407943
# Unit test for function represent_undefined
def test_represent_undefined():
    class MyDumper(AnsibleDumper):
        def __init__(self, *args, **kwargs):
            super(MyDumper, self).__init__(*args, **kwargs)
            self.undefined_error = None

        def _fail_with_undefined_error(self):
            raise self.undefined_error

    dumper = MyDumper()

    obj = AnsibleUndefined('foo')
    obj.__bool__ = dumper._fail_with_undefined_error

    try:
        dumper.represent_undefined(obj)
    except KeyError as e:
        assert e.args[0] == 'foo'
    else:
        assert False, '_fail_with_undefined_error not called'

# Generated at 2022-06-23 05:37:52.458452
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # Test1
    data = HostVars(task_vars=dict(a=dict(b=2)))
    a = yaml.dump(data, Dumper=AnsibleDumper)
    assert a == "a:\n  b: 2\n"

    # Test2
    data = HostVars(task_vars=dict(a=dict(b=2)))
    d = AnsibleDumper(None, default_flow_style=False, sort_keys=True)
    a = yaml.dump(data, Dumper=d)
    assert a == "a:\n  b: 2\n"

# Generated at 2022-06-23 05:38:03.900567
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from collections import OrderedDict

    dumper = AnsibleDumper
    hostvars = HostVars()

    # test with empty hostvars
    result = dumper.represent_dict(dict(hostvars))
    assert(result == yaml.representer.SafeRepresenter.represent_dict({}))

    # test with simple hostvars
    hostvars.update({'a': 'b'})
    result = dumper.represent_dict(dict(hostvars))
    assert(result == yaml.representer.SafeRepresenter.represent_dict({'a': 'b'}))

    # test with complex hostvars
    hostvars.update({'c': OrderedDict({'d': 'e'})})
    result = dumper.represent_dict(dict(hostvars))

# Generated at 2022-06-23 05:38:06.617060
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hv = HostVars(dict(foo=1, bar=2))
    out = yaml.dump(hv, Dumper=AnsibleDumper)
    assert out == '{bar: 2, foo: 1}\n'



# Generated at 2022-06-23 05:38:11.077687
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    '''
    :return:
    '''
    # Arrange
    dumper = AnsibleDumper()
    some_str = 'Text'
    some = AnsibleVaultEncryptedUnicode(some_str)

    # Act
    value = represent_vault_encrypted_unicode(dumper, some)

    # Assert
    assert value == '!vault |\n          %s\n' % some_str

# Generated at 2022-06-23 05:38:19.661625
# Unit test for function represent_undefined
def test_represent_undefined():
    ''' Tests that represent_undefined works correctly.

    This test is not in test_utils_vars.py because the representer
    is implemented in this file.
    '''
    def test_data(data, expected):
        rep = AnsibleDumper().represent_data(data)
        assert rep == expected, 'Expected %s, got %s' % (expected, rep)

    # Test undefined data
    test_data(AnsibleUndefined(), 'null')
    test_data(AnsibleUndefined(var='foo'), 'null')

    # Test data that is not undefined
    test_data(False, 'false')
    test_data('foo', 'foo')
    test_data(2, '2')

test_represent_undefined()

# Generated at 2022-06-23 05:38:29.716805
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    import ansible.parsing.yaml.loader
    dumper = AnsibleDumper
    assert dumper.allow_unicode
    assert dumper.default_flow_style is False
    assert dumper.compress_seq is True
    assert dumper.sort_base_mapping_type is True
    assert dumper.default_style is '"'
    assert dumper.canonical is False
    assert isinstance(dumper.yaml_base_loader, ansible.parsing.yaml.loader.AnsibleSafeLoader)
    assert isinstance(dumper.yaml_base_dumper, ansible.parsing.yaml.loader.AnsibleSafeDumper)

# Generated at 2022-06-23 05:38:33.998392
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    assert u"hello" == dumper.represent_unicode(dumper, u"hello")



# Generated at 2022-06-23 05:38:41.956500
# Unit test for function represent_unicode
def test_represent_unicode():
    # repr lib bug https://bugs.python.org/issue6646
    # AnsibleUndefined should be rendered as an empty string
    assert yaml.dump({'undefined': AnsibleUndefined()}, Dumper=AnsibleDumper, default_flow_style=False) == "undefined: ''\n"
    assert yaml.dump({'undefined': False}, Dumper=AnsibleDumper, default_flow_style=False) == "undefined: no\n"
    assert yaml.dump({'undefined': True}, Dumper=AnsibleDumper, default_flow_style=False) == "undefined: yes\n"

# Generated at 2022-06-23 05:38:54.006723
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import HostVarsVars

    class MockAssignment(HostVarsVars):
        def __init__(self, inventory, vars_dict):
            super(MockAssignment, self).__init__(inventory)
            self._data = vars_dict

    loader = DataLoader()
    vm = VariableManager()
    inventory = InventoryManager(loader=loader, sources=["localhost"])

    inventory.add_host("test1")
    inventory.add_host("test2")
    inventory.get_group("all").add_host("test3")


# Generated at 2022-06-23 05:38:55.030391
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper is not None

# Generated at 2022-06-23 05:38:55.924941
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper is not None



# Generated at 2022-06-23 05:39:03.758192
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

    text_value = b"text_value"
    yaml_text = "!!binary |\n  dGV4dF92YWx1ZQo="
    assert dumper.represent_binary(dumper, text_value) == yaml_text

    text_value = b"text_value"
    yaml_text = "!!binary |\n  dGV4dF92YWx1ZQo="
    assert dumper.represent_binary(dumper, text_value) == yaml_text

# Generated at 2022-06-23 05:39:05.459393
# Unit test for function represent_undefined
def test_represent_undefined():
    yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper)

# Generated at 2022-06-23 05:39:10.045956
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    aveu = AnsibleVaultEncryptedUnicode(u'abc')
    aveu._ciphertext = b'abc'
    assert represent_vault_encrypted_unicode(None, aveu) == u'!vault |\n  abc'

# Generated at 2022-06-23 05:39:15.343783
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper
    h = HostVars()
    rep = dumper.represent_dict(h)
    assert rep == dumper.represent_dict({})
    h['foo'] = 'bar'
    rep = dumper.represent_dict(h)
    assert rep == dumper.represent_dict({'foo': 'bar'})

# Generated at 2022-06-23 05:39:16.987715
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert issubclass(AnsibleDumper, SafeDumper)

# Generated at 2022-06-23 05:39:19.806616
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper, yaml.dumper.SafeDumper)
    AnsibleDumper()

# Generated at 2022-06-23 05:39:21.810170
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper()
    assert dumper.default_flow_style is False



# Generated at 2022-06-23 05:39:24.496456
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    ad = AnsibleDumper()
    assert ad
    assert isinstance(ad, yaml.dumper.Dumper)

# Generated at 2022-06-23 05:39:32.075156
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from io import StringIO

    h = HostVars(host_name='dummy')
    h.vars = dict(a='1', b='2', c='3')
    s = StringIO()
    yaml.dump({'hostvars': h}, s, Dumper=AnsibleDumper)
    assert s.getvalue() == 'hostvars:\n  a: "1"\n  b: "2"\n  c: "3"\n'



# Generated at 2022-06-23 05:39:38.269444
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.hostvars import HostVars

    hostvars = HostVars(wrap_var({'abc': 'def'}), wrap_var({'xyx': 'zyz'}))
    assert yaml.dump(hostvars, Dumper=AnsibleDumper).strip() == '{abc: def, xyx: zyz}'



# Generated at 2022-06-23 05:39:45.033671
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(AnsibleDumper, AnsibleUnicode(u'foo')) == 'foo'
    assert represent_unicode(AnsibleDumper, AnsibleUnicode(u'\u2708')) == '\u2708'
    assert represent_unicode(AnsibleDumper, AnsibleUnicode(1)) == '1'
    assert represent_unicode(AnsibleDumper, AnsibleUnicode(u'')) == ''

# Generated at 2022-06-23 05:39:57.308107
# Unit test for function represent_binary
def test_represent_binary():
    test_ansible_dumper = AnsibleDumper()
    fake_data = binary_type('fake_data')

    class fake_loader:
        def get_single_data(self, node):
            return node.data

        def construct_yaml_binary(self, node):
            return fake_data

    fake_yaml_loader = yaml.loader.SafeLoader(yaml.reader.Reader(), yaml.scanner.Scanner(), yaml.resolver.Resolver())
    fake_yaml_loader.add_constructor(u'tag:yaml.org,2002:binary', fake_loader().get_single_data)
    fake_yaml_loader.add_multi_constructor(u'tag:yaml.org,2002:str', fake_loader().construct_yaml_binary)

# Generated at 2022-06-23 05:40:02.367691
# Unit test for function represent_hostvars
def test_represent_hostvars():

    ansible_dumper = AnsibleDumper()
    hostvars = HostVars(variables=dict(name='Bob'))

    representation = ansible_dumper.represent_hostvars(hostvars)

    assert representation == ansible_dumper.represent_dict({'name': 'Bob'})



# Generated at 2022-06-23 05:40:14.168743
# Unit test for function represent_binary
def test_represent_binary():

    # Representer for binary data
    representer = yaml.representer.SafeRepresenter.represent_binary

    # Encoded test data
    encoded = b'\xa0'

    # Generate YAML node
    node = representer(representer, encoded)

    # Generate output

# Generated at 2022-06-23 05:40:21.504755
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    b = u'unicode to test unicode handling with an embedded utf8 \u5171\u5b58'.encode('utf-8')
    out = dumper.represent_binary(dumper, b) # Call the representer directly
    assert out == u'!!binary |\n  dW5pY29kZSB0byB0ZXN0IHVuaWNvZGUgaGFuZGxpbmcgd2l0aCBhbiBl\n  bWJlZGRlZCB1dGY4IOWtjemBuA==\n'


# Generated at 2022-06-23 05:40:32.869025
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.objects import AnsibleMapping

    h = HostVars()
    h.vars = {'foo': 'bar'}

    d = AnsibleDumper()
    assert h == d.represent_data(h)

    d = AnsibleDumper()
    hh = HostVars()
    hh.vars = h
    assert {'vars': {'foo': 'bar'}} == d.represent_data(hh)

    d = AnsibleDumper()
    hhh = HostVars()
    hhh.vars = hh
    assert {'vars': {'vars': {'foo': 'bar'}}} == d.represent_data(hhh)

    d = AnsibleDumper()
    hh = HostVars()

# Generated at 2022-06-23 05:40:35.052261
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    d = AnsibleDumper()
    assert d is not None

# Generated at 2022-06-23 05:40:42.884789
# Unit test for function represent_unicode
def test_represent_unicode():
    # Make a couple objects that SafeRepresenter can't handle
    obj1 = u'\u2713'
    obj2 = b'\xe2\x9c\x93'

    # Place objects in a list
    data = [obj1, obj2]

    # Create a dumper object
    dumper = AnsibleDumper()

    # Generate yaml
    yaml.dump(data, dumper)

    # Generate actual yaml output
    output = dumper.stream.getvalue()

    # Compare to known good output
    assert output == u'- \u2713\n- !!binary |\n  w6XDtw==\n'

# Generated at 2022-06-23 05:40:45.609063
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
  assert isinstance(AnsibleDumper(),yaml.dumper.SafeDumper)

# Generated at 2022-06-23 05:40:51.114061
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()
    actual = dumper.represent_vault_encrypted_unicode(u"$ANSIBLE_VAULT;foo")
    assert actual == '!vault |\n          $ANSIBLE_VAULT;foo\n'

# Generated at 2022-06-23 05:41:01.062251
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-23 05:41:02.617234
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper(), AnsibleDumper)

# Generated at 2022-06-23 05:41:11.549425
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    yaml.add_representer(AnsibleVaultEncryptedUnicode, represent_vault_encrypted_unicode, Dumper=AnsibleDumper)


# Generated at 2022-06-23 05:41:21.820795
# Unit test for function represent_hostvars
def test_represent_hostvars():
    import io
    import glob
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    # Create a HostVars object

# Generated at 2022-06-23 05:41:26.290055
# Unit test for function represent_undefined
def test_represent_undefined():
    def assert_undefined(thing):
        dumper = AnsibleDumper()
        dumper.open()
        assert dumper.represent_undefined(thing) == True
        dumper.close()

    assert_undefined(AnsibleUndefined)



# Generated at 2022-06-23 05:41:36.078716
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-23 05:41:46.906364
# Unit test for function represent_binary
def test_represent_binary():
    data = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    assert "!!binary |\n  AAABAAEAICAQAAAAEAAQA=" == AnsibleDumper().represent_binary(data)
    data2 = u'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    assert "!!binary |\n  AAABAAEAICAQAAAAEAAQA=" == AnsibleDumper().represent_binary(data2)

# Generated at 2022-06-23 05:41:49.202565
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper) == ''



# Generated at 2022-06-23 05:41:54.264208
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_data(AnsibleUndefined) == 'false'
    assert dumper.represent_data(AnsibleUndefined("foo")) == 'false'
    assert dumper.represent_data(AnsibleUndefined("foo", "bar")) == 'false'



# Generated at 2022-06-23 05:41:58.869547
# Unit test for function represent_undefined
def test_represent_undefined():
    d = AnsibleDumper(width=4, default_flow_style=False)
    ansible_undefined = AnsibleUndefined('VAR_NAME is not defined!')
    output = u'{VAR_NAME is not defined!}'
    assert output == d.represent_data(ansible_undefined)