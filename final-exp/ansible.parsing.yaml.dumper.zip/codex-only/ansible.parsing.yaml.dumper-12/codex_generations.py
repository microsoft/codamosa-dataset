

# Generated at 2022-06-23 05:31:56.101552
# Unit test for function represent_binary
def test_represent_binary():
    assert represent_binary(None, '\x80') == u"!binary |\n  gA==\n"

# Generated at 2022-06-23 05:31:59.417678
# Unit test for function represent_binary
def test_represent_binary():
    assert AnsibleDumper.represent_binary(AnsibleDumper, b'Hello world') == '!!binary |\n  SGVsbG8gd29ybGQ=\n'

# Generated at 2022-06-23 05:32:03.690743
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    assert dumper.represent_data(AnsibleUndefined(data=None)) is dumper.represent_undefined(AnsibleUndefined(data=None))



# Generated at 2022-06-23 05:32:13.006966
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper is not None


try:
    # In python 2.6, this will fail
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM

    class AESGCM(object):
        pass


except ImportError:
    # In python2.6, this will be used instead
    from Crypto.Cipher import AES
    from Crypto.Util import Counter

    # subclass to ensure a valid __dict__
    class AESGCM(AES):
        def __init__(self, *args, **kwargs):
            AES.__init__(self, *args, **kwargs)



# Generated at 2022-06-23 05:32:21.333387
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # The data we're dumping
    test_data = {
        "foo": "bar"
    }
    # The HostVars object we need to dump
    hostvars_object = HostVars(
        hostname="test_host",
        vars=test_data
    )
    # The expected yaml output
    expected = u'!hostvars\nhostname: test_host\nvars:\n  foo: bar\n'

    dumper = AnsibleDumper()
    actual = dumper.represent_hostvars(hostvars_object)
    assert actual == expected



# Generated at 2022-06-23 05:32:25.552359
# Unit test for function represent_binary
def test_represent_binary():
    obj = AnsibleUnsafeBytes('string with \x00 null byte')
    assert yaml.dump(obj, Dumper=AnsibleDumper) == "!!binary |\n  c3RyaW5nIHdpdGggAgBudWxsIGJ5dGU=\n"

# Generated at 2022-06-23 05:32:31.866597
# Unit test for function represent_unicode
def test_represent_unicode():
    rep = yaml.representer.Representer()
    dumper = AnsibleDumper(width=100, Dumper=yaml.SafeDumper)
    dumper.add_representer(AnsibleUnicode, rep.represent_scalar)
    stream = yaml.add_representer(_unicode, represent_unicode)
    assert dumper.dump(u'foo') == stream



# Generated at 2022-06-23 05:32:42.143827
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper
    example_data = dict()
    example_data[u'key1'] = u'value1'
    example_data[u'key2'] = u'value2'
    example_data[u'key3'] = u'value3'
    example_data[u'key4'] = u'value4'
    expect_data = dict()
    expect_data[u'key1'] = u'value1'
    expect_data[u'key2'] = u'value2'
    expect_data[u'key3'] = u'value3'
    expect_data[u'key4'] = u'value4'
    assert dumper.represent_dict(example_data) == dumper.represent_dict(expect_data)

# Generated at 2022-06-23 05:32:50.926457
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    string = "test_represent_vault_encrypted_unicode"
    assert string == AnsibleVaultEncryptedUnicode(string).decrypt()

    actual = yaml.dump(AnsibleVaultEncryptedUnicode(string), Dumper=AnsibleDumper)
    assert actual == '!vault |\n  $ANSIBLE_VAULT;1.1;AES256\n  613436656637393965336530343563653861663138306665333961643531313666663563633062\n  333335626264633362393935\n'



# Generated at 2022-06-23 05:32:52.635336
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper_obj = AnsibleDumper()
    assert isinstance(dumper_obj, SafeDumper)

# Generated at 2022-06-23 05:33:00.416534
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    test = AnsibleDumper()
    assert(yaml.representer.SafeRepresenter.represent_dict == test.represent_dict)
    assert(yaml.representer.SafeRepresenter.represent_list == test.represent_list)
    assert(yaml.representer.SafeRepresenter.represent_scalar == test.represent_scalar)
    assert(yaml.representer.SafeRepresenter.represent_binary == test.represent_binary)
    assert(yaml.representer.SafeRepresenter.represent_str == test.represent_str)


# Generated at 2022-06-23 05:33:11.425724
# Unit test for function represent_hostvars
def test_represent_hostvars():

    # Test scenario 1: dict is empty
    source_dict = {}
    expected_result = '{}'
    actual_result = yaml.dump(source_dict, Dumper=AnsibleDumper, width=1000)

    assert actual_result == expected_result

    # Test scenario 2: dict is not empty
    source_dict = dict(a=1, b=2)
    expected_result = '{a: 1, b: 2}'
    actual_result = yaml.dump(source_dict, Dumper=AnsibleDumper, width=1000)

    assert actual_result == expected_result

    # Test scenario 3: dict is complex
    source_dict = dict(a=1, b=2, c='abc')
    expected_result = '{a: 1, b: 2, c: abc}'


# Generated at 2022-06-23 05:33:15.632004
# Unit test for function represent_binary
def test_represent_binary():
    """
    Test that Ansible's yaml dumper handles binary type objects
    """
    data = b"\x00\x80"
    result = yaml.dump(data, Dumper=AnsibleDumper, default_flow_style=False)
    assert result == "!!binary |-\n  AAAAAA==\n"

# Generated at 2022-06-23 05:33:19.084151
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.objects import AnsibleMapping
    rep = AnsibleDumper.represent_data
    hostvars = AnsibleMapping()
    hostvars['somevar'] = 'somevalue'
    assert rep(hostvars) == '{"somevar": "somevalue"}'

# Generated at 2022-06-23 05:33:21.726761
# Unit test for function represent_hostvars
def test_represent_hostvars():
    host = HostVars(
        {
            'a': 'b',
            'c': 'd',
        },
        vault_password=None,
    )



# Generated at 2022-06-23 05:33:33.086254
# Unit test for function represent_unicode
def test_represent_unicode():
    representer = AnsibleDumper()
    import sys
    if sys.version_info[0] < 3:
        # Input type is unicode
        ansible_unicode = AnsibleUnicode('unicode_value')
        input_data = ansible_unicode
        assert type(input_data) is unicode
        assert type(input_data) is not str
        # Output type is yaml.nodes.ScalarNode
        result = representer.represent_data(input_data)
        assert type(result) == yaml.nodes.ScalarNode

        # Input type is str
        ansible_unsafe_text = AnsibleUnsafeText(u'unicode_value')
        input_data_2 = ansible_unsafe_text
        assert type(input_data_2) is unicode
       

# Generated at 2022-06-23 05:33:35.532681
# Unit test for function represent_unicode
def test_represent_unicode():
    value = 'asdf'
    result = represent_unicode(None, value)

    assert result == 'asdf'



# Generated at 2022-06-23 05:33:45.334713
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    plaintext = "hello world"
    ciphertext = VaultLib().encrypt(plaintext)
    ciphertext = ciphertext.encode('utf-8')
    vault = AnsibleVaultEncryptedUnicode(ciphertext)
    s = AnsibleDumper().represent_vault_encrypted_unicode(vault)
    assert s == '!vault |\n          %s' % ciphertext.decode()


__all__ = ["AnsibleDumper"]

# Generated at 2022-06-23 05:33:48.418217
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    v = AnsibleVaultEncryptedUnicode('blah', 'key')
    res = represent_vault_encrypted_unicode(None, v)
    assert '!vault |' in res

# Generated at 2022-06-23 05:33:56.959913
# Unit test for function represent_hostvars
def test_represent_hostvars():
    ansible_dumper = AnsibleDumper

    # Defining hostvars as a mapping and testing with a simple key, value pair
    hostvars = {'variables': 'values'}
    hostvars_test = ansible_dumper.represent_dict(hostvars)

    # Checking the outputted string matches the expected result
    hostvars_expected_string = "!!python/object/apply:ansible.vars.manager.HostVarsVars\n  variables: values\n"
    assert hostvars_test == hostvars_expected_string



# Generated at 2022-06-23 05:34:10.353734
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode(u'foo'), Dumper=AnsibleDumper) == u'"foo"\n'
    assert yaml.dump(AnsibleUnicode(u'foo\nbar'), Dumper=AnsibleDumper) == u'"foo\nbar"\n'
    assert yaml.dump(AnsibleUnicode(u'N.B.A.A\rN.A.T.O'), Dumper=AnsibleDumper) == u'"N.B.A.A\rN.A.T.O"\n'
    assert yaml.dump(AnsibleUnicode(u'foo\xabar'), Dumper=AnsibleDumper) == u'"foo\\xabar"\n'

# Generated at 2022-06-23 05:34:15.669722
# Unit test for function represent_binary
def test_represent_binary():
    for ansiblestring in [
            AnsibleUnsafeText("\u0080"),
            AnsibleUnsafeText("\u00ff"),
            AnsibleUnsafeText("\u0100")]:
        ansiblestring = yaml.dump(ansiblestring)
        assert ansiblestring[0] == '|' and ansiblestring[1] == '\n'

# Generated at 2022-06-23 05:34:18.852449
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = yaml.Dumper(None)
    ansible_dumper = AnsibleDumper(dumper)
    assert(ansible_dumper.represent_undefined(AnsibleUndefined()) == False)

# Generated at 2022-06-23 05:34:23.526986
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVarsVars

    hvv = HostVarsVars(host=None, variables=dict())
    hvv['x'] = 'x'
    assert yaml.dump(hvv, Dumper=AnsibleDumper) == '{x: x}\n'

# Generated at 2022-06-23 05:34:30.440870
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # Setup test
    obj = HostVars(None)
    obj.variable_manager = MockVariableManager({'foo': 'bar'})
    dumper = AnsibleDumper()

    # Run test
    assert yaml.safe_dump(obj, default_flow_style=True) == yaml.safe_dump({'foo': 'bar'}, default_flow_style=True)

    # Cleanup
    del obj, dumper



# Generated at 2022-06-23 05:34:40.421109
# Unit test for function represent_undefined
def test_represent_undefined():
    with open('test_data/test_represent_undefined.yaml', 'r') as f:
        data = yaml.load(f)
        data['ansible_undefined'] = AnsibleUndefined(None)
        yaml_text = yaml.dump(data, Dumper=AnsibleDumper, default_flow_style=False)
        with open('test_data/test_represent_undefined.output.yaml', 'r') as f1:
            output = f1.read()
            assert yaml_text == output, "Output yaml should match the expected output"

test_represent_undefined()

# Generated at 2022-06-23 05:34:45.178024
# Unit test for function represent_binary
def test_represent_binary():
    bin_str = '\xfe'
    dump = yaml.dump(bin_str, Dumper=AnsibleDumper, default_flow_style=True)
    assert dump == '!!binary |\n  ' + bin_str.encode('base64').replace('\n', ' ')

# Generated at 2022-06-23 05:34:53.524132
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Test with vault_variable.
    data = AnsibleVaultEncryptedUnicode('my_vault_variable')
    dumper = AnsibleDumper
    # function's return value.
    actual = dumper.represent_data(represent_vault_encrypted_unicode(dumper, data))
    # Expected return value.
    expected = '--- !vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          34376632353436353833383462626234613338363663623032653336303132626332366432616334650a\n'
    assert actual == expected



# Generated at 2022-06-23 05:34:58.967208
# Unit test for function represent_hostvars
def test_represent_hostvars():
    class HostVars:
        pass

    d = AnsibleDumper()
    hostvars = HostVars()
    hostvars.a = 'b'
    hostvars_.c = 2
    data = d.represent_dict(hostvars)
    assert isinstance(data, dict)
    assert isinstance(data['a'], text_type)
    assert isinstance(data['b'], int)

# Generated at 2022-06-23 05:35:07.349033
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dict_data = dict(A=1)
    # Create a HostVars object with data as dict_data
    hostvars = HostVars(dict_data)

    # Create a SafeRepresenter
    safe_representer = yaml.representer.SafeRepresenter()

    # Call the represent_hostvars
    hostvars_yaml_data = represent_hostvars(safe_representer, hostvars)

    # Check the returned value from represent_hostvars
    # This is a dict with one key
    assert hostvars_yaml_data.tag == u'!!python/dict'
    yaml_dict_data = hostvars_yaml_data.value
    assert yaml_dict_data == dict_data

# Generated at 2022-06-23 05:35:10.429106
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == 'foo'
    assert dumper.represent_unicode(1) == '1'



# Generated at 2022-06-23 05:35:12.365398
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    ansible_dumper = AnsibleDumper()
    assert ansible_dumper.dumper == 'ansible'

# Generated at 2022-06-23 05:35:14.508328
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper.represent_undefined(AnsibleDumper, AnsibleUndefined()) == True

# Generated at 2022-06-23 05:35:16.251813
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper, type) is True

# Generated at 2022-06-23 05:35:21.172297
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template.template import AnsibleTemplate
    text = 'Hello {{ foo }}'
    t = AnsibleTemplate(text, keep_trailing_newline=True)
    assert text_type(t) == u'Hello \n'
    assert AnsibleDumper.represent_undefined(AnsibleDumper, t.env.undefined) is True
    assert AnsibleDumper.represent_undefined(AnsibleDumper, {'foo': t.env.undefined}) is True

# Generated at 2022-06-23 05:35:28.119689
# Unit test for function represent_hostvars
def test_represent_hostvars():
    ''' represent_hostvars should represent all the values in
        a HostVars object as a YAML mapping.
    '''
    test_data = {
        'firstvar': 'first value',
        'secondvar': 'second value',
    }

    assert yaml.dump(HostVars(vars=test_data)) == '''{firstvar: first value
secondvar: second value
}
'''

# Generated at 2022-06-23 05:35:38.918195
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader

    safe_dumper = AnsibleDumper
    safe_dumper.add_representer(AnsibleVaultEncryptedUnicode, represent_vault_encrypted_unicode)

    data = 'secret'
    yaml_data = AnsibleVaultEncryptedUnicode(data)
    yaml_str = yaml.dump(yaml_data, Dumper=safe_dumper)

    assert isinstance(yaml_str, binary_type)
    assert yaml_str.startswith('!vault ')

    yaml_data2 = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance

# Generated at 2022-06-23 05:35:45.482361
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template.safe_eval import unsafe_proxy

    # A dict dumper to pass to test_fallback_handler
    class Dumper(object):
        def __init__(self):
            self.dumped = False
        def represent_dict(self, data):
            self.dumped = True

    dumper = Dumper()
    rep = AnsibleDumper()
    rep.dumper = dumper
    rep.represent_undefined(unsafe_proxy("foo"))
    assert dumper.dumped

# Generated at 2022-06-23 05:35:52.120779
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper(default_flow_style=False)
    text = AnsibleVaultEncryptedUnicode(u'this is a test')
    output = u'!vault |\n  $ANSIBLE_VAULT;1.1;AES256\n  35356161366136326531393231666562666466393964333734646638623132653938643735373335\n  30373436306334653036663937656633653733313731666337653462386564353736616164356632\n  633637626666393737\n'
    assert dumper.represent_vault_encrypted_unicode(text) == output

# Generated at 2022-06-23 05:36:03.077697
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    import ansible.parsing.vault as vault
    cipher_block = '$ANSIBLE_VAULT;1.1;AES256\n3331633333333333633323736356631613332316430623136623233366263663932393161656634\n39643531646564613031346133383264343637666532303938373037396565643766623638373835\n6530363837353336396466666383638663135616362666464313635643635623738373835643036\n383735333639646666638363866313561636266646400\n'
    ciphertext = cipher_block.encode()
    password = 'ansible'

# Generated at 2022-06-23 05:36:06.102392
# Unit test for function represent_binary
def test_represent_binary():
    ansible_dumper = AnsibleDumper
    ansible_dumper.add_representer(
        binary_type,
        represent_binary,
    )
    result = yaml.dump(binary_type(b'foo'), Dumper=ansible_dumper)
    assert result == 'foo\n...\n'


# Generated at 2022-06-23 05:36:15.207545
# Unit test for function represent_unicode
def test_represent_unicode():
    obj = AnsibleUnicode(u'value')
    assert obj.__class__.__name__ == 'AnsibleUnicode'
    # Object of type AnsibleUnicode should be serialized as regular unicode
    data = yaml.dump(obj, default_flow_style=False, Dumper=AnsibleDumper)
    assert 'value' in data
    assert data == "!!python/object:__main__.AnsibleUnicode\n_data: value\n"

# Generated at 2022-06-23 05:36:18.624169
# Unit test for function represent_unicode
def test_represent_unicode():
    from ansible.module_utils.six import text_type
    dumper = AnsibleDumper
    assert dumper.represent_unicode(dumper, text_type(u'foo')) == dumper.represent_unicode(dumper, 'foo')

# Generated at 2022-06-23 05:36:20.115950
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper, SafeDumper)


# Generated at 2022-06-23 05:36:30.448770
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-23 05:36:41.159144
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-23 05:36:42.493950
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper()
    assert dumper is not None

# Generated at 2022-06-23 05:36:53.507305
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars, HostVarsVars
    # test for HostVars
    hv = HostVars()
    hv._set_variable('one', 1)
    hv._set_variable('two', 2)
    hv._set_variable('three', 3)
    hv._set_variable('four', 4)

    yaml.dump(hv, Dumper=AnsibleDumper)

    # test for HostVarsVars
    hvv = HostVarsVars(hv)
    yaml.dump(hvv, Dumper=AnsibleDumper)

if __name__ == "__main__":
    # run tests
    test_represent_hostvars()

# Generated at 2022-06-23 05:37:04.592892
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    results = []

    my_vault = AnsibleVaultEncryptedUnicode('test password', '$ANSIBLE_VAULT;1.1;AES256\n30616132626339653936656163333365363034663035656631636132313931333136316537303461\n30366531623738333536313462653366396365616238300a')
    results.append(my_vault)

    # Load the vault
    loader = VaultLib('test password', False)
    results.append(loader.load_decryption_key())

    # Decrypt the contents

# Generated at 2022-06-23 05:37:09.456308
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    #
    AnsibleDumper()
    #
    AnsibleDumper(indent=4)
    #
    AnsibleDumper(width=1)
    #
    AnsibleDumper(allow_unicode=True)
    #
    AnsibleDumper(line_break="\n")
    #
    AnsibleDumper(encoding='utf-8')
    #

# Generated at 2022-06-23 05:37:12.229633
# Unit test for function represent_unicode
def test_represent_unicode():
    data = AnsibleUnicode(u'\u2603')
    yaml.dump(data, stream=None, Dumper=AnsibleDumper)



# Generated at 2022-06-23 05:37:14.689637
# Unit test for function represent_undefined
def test_represent_undefined():
    y = AnsibleDumper()
    x = AnsibleUndefined
    assert y.represent_undefined(x) is False

# Generated at 2022-06-23 05:37:18.725566
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    ansible_bytes = b"bytes"
    assert yaml.representer.SafeRepresenter.represent_binary(dumper, ansible_bytes) == yaml.representer.SafeRepresenter.represent_binary(dumper, binary_type(ansible_bytes))

# Generated at 2022-06-23 05:37:22.441256
# Unit test for function represent_undefined
def test_represent_undefined():
    class DummyDumper(AnsibleDumper):
        def represent_data(self, data):
            return self.represent_data(data)

    dumper = DummyDumper()
    dumper.represent_undefined(AnsibleUndefined(""))


# Generated at 2022-06-23 05:37:33.478314
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from yaml.emitter import Emitter

    class FakeRepresenter:
        def __init__(self):
            pass

        def represent_dict(self, data):
            return 'dict'

    def func(data):
        return data

    rep = FakeRepresenter()
    # Represent AnsibleUnicode
    AnsibleDumper.add_representer(
        AnsibleUnicode,
        func,
    )
    assert AnsibleDumper.serialize(AnsibleUnicode(data='unicode')) == u'unicode'
    # Represent AnsibleSequence
    AnsibleDumper.add_representer(
        AnsibleSequence,
        func,
    )
    assert AnsibleDumper.serialize(AnsibleSequence(data=['unicode', 1])) == ["unicode", 1]


# Generated at 2022-06-23 05:37:34.221845
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper

# Generated at 2022-06-23 05:37:37.250356
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = {'test1': 'test2'}
    dumper = AnsibleDumper()
    dumper.represent_dict = lambda x: x
    assert represent_hostvars(dumper, data) == data

# Generated at 2022-06-23 05:37:39.891477
# Unit test for function represent_unicode
def test_represent_unicode():
    data = yaml.dump(AnsibleUnicode('abc'))
    assert data == u"abc\n"



# Generated at 2022-06-23 05:37:42.775527
# Unit test for function represent_hostvars
def test_represent_hostvars():
    representer = AnsibleDumper()
    data = HostVars(dict(my_var='my_value'))

    result = representer.represent_hostvars(data)

    assert result == representer.represent_dict({'my_var': 'my_value'})

# Generated at 2022-06-23 05:37:45.646518
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    result = dumper.represent_binary(binary_type("some bytes string"))
    assert result == yaml.representer.SafeRepresenter.represent_binary(dumper, binary_type("some bytes string"))



# Generated at 2022-06-23 05:37:55.052255
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, 'string') == yaml.representer.SafeRepresenter.represent_str(None, 'string')
    assert represent_unicode(None, '1') == yaml.representer.SafeRepresenter.represent_str(None, '1')
    assert represent_unicode(None, 1) == yaml.representer.SafeRepresenter.represent_str(None, '1')
    assert represent_unicode(None, 1.0) == yaml.representer.SafeRepresenter.represent_str(None, '1.0')
    assert represent_unicode(None, None) == yaml.representer.SafeRepresenter.represent_str(None, 'None')
    assert represent_unicode(None, False) == yaml.representer.SafeRepresenter.represent_str(None, 'False')

# Generated at 2022-06-23 05:37:57.464892
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    try:
        AnsibleDumper()
    except Exception:
        assert False



# Generated at 2022-06-23 05:38:06.323732
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    ansible_dumper = AnsibleDumper()
    assert ansible_dumper.add_representer(HostVars, represent_hostvars)
    assert ansible_dumper.add_representer(HostVarsVars, represent_hostvars)
    assert ansible_dumper.add_representer(VarsWithSources, represent_hostvars)
    assert ansible_dumper.add_representer(AnsibleSequence, yaml.representer.SafeRepresenter.represent_list)
    assert ansible_dumper.add_representer(AnsibleMapping, yaml.representer.SafeRepresenter.represent_dict)
    assert ansible_dumper.add_representer(AnsibleVaultEncryptedUnicode, represent_vault_encrypted_unicode)

# Generated at 2022-06-23 05:38:17.082294
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-23 05:38:19.694971
# Unit test for function represent_undefined
def test_represent_undefined():
    result = yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper)

    assert result is True or result is False


# Generated at 2022-06-23 05:38:23.420446
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = HostVars(variable_manager=None, loader=None)
    data['a'] = 'b'
    data['c'] = 'd'

    assert yaml.dump(data, Dumper=AnsibleDumper) == '{a: b, c: d}\n'



# Generated at 2022-06-23 05:38:27.763695
# Unit test for function represent_unicode
def test_represent_unicode():
    d = {'foo': u'This is the euro symbol: \u20ac'}
    assert yaml.dump(d, Dumper=AnsibleDumper) == u'{foo: This is the euro symbol: \u20ac}\n'



# Generated at 2022-06-23 05:38:29.179915
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    ad = AnsibleDumper()
    assert type(ad) == AnsibleDumper

# Generated at 2022-06-23 05:38:32.879184
# Unit test for function represent_hostvars
def test_represent_hostvars():
    d = dict(foo="bar")
    H = HostVars(d)

    y = yaml.safe_dump(H, default_flow_style=True, default_style='"')

    x = dict(foo="bar")
    assert y == x, y



# Generated at 2022-06-23 05:38:33.619458
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper

# Generated at 2022-06-23 05:38:37.796539
# Unit test for function represent_binary
def test_represent_binary():
    my_binary_data = b'I am a binary string'
    my_yaml_data = yaml.dump(my_binary_data, Dumper=AnsibleDumper)
    assert isinstance(my_yaml_data, str)

# Generated at 2022-06-23 05:38:48.230958
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    AnsibleDumper.add_representer(
        HostVars,
        represent_hostvars,
    )
    AnsibleDumper.add_representer(
        HostVarsVars,
        represent_hostvars,
    )
    AnsibleDumper.add_representer(
        VarsWithSources,
        represent_hostvars,
    )

    a = AnsibleDumper()
    assert a.representers[HostVars] == represent_hostvars
    assert a.representers[HostVarsVars] == represent_hostvars
    assert a.representers[VarsWithSources] == represent_hostvars

# Generated at 2022-06-23 05:38:52.353895
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper
    assert dumper is not None
    assert isinstance(dumper, type)



# Generated at 2022-06-23 05:38:59.110517
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # simple hostvars
    hv = HostVars('localhost')
    hv['hostvar'] = 'hostvar_value'
    hv._source = 'hostvars'
    hv2 = HostVars('localhost')
    hv2['hostvars'] = hv
    result = yaml.dump({'hostvars': hv2}, Dumper=AnsibleDumper)
    # HostVars object is replaced with dict
    assert result == '{hostvars: {hostvars: {hostvar: hostvar_value}, _source: hostvars}}\n'



# Generated at 2022-06-23 05:39:08.796299
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('ansible')
    vault.decrypt('dummy')
    data = {'test': AnsibleVaultEncryptedUnicode(vault.encrypt('test'))}

# Generated at 2022-06-23 05:39:11.482136
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper()
    assert dumper.explicit_start is True
    assert dumper.explicit_end is True

# Generated at 2022-06-23 05:39:12.929583
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    try:
        ansible_loader = AnsibleDumper()
    except NameError as e:
        assert False, "AnsibleDumper() raised NameError exception"
    else:
        assert True, "AnsibleDumper() instantiated successfully"

# Generated at 2022-06-23 05:39:16.772755
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper(None)
    assert dumper.represent_binary(b'/bin/true') == "!!binary |\n  L2Jpbi90cnVl"

# Generated at 2022-06-23 05:39:26.676301
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, AnsibleUnicode(u'string')) == represent_unicode(None, u'string')
    assert represent_unicode(None, AnsibleUnicode(u'1')) == represent_unicode(None, u'1')
    assert represent_unicode(None, AnsibleUnicode(u'1.1')) == represent_unicode(None, u'1.1')
    assert represent_unicode(None, AnsibleUnicode(u'true')) == represent_unicode(None, u'true')
    assert represent_unicode(None, AnsibleUnicode(u'false')) == represent_unicode(None, u'false')

# Generated at 2022-06-23 05:39:30.930263
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    assert dumper.represent_unicode(dumper, 'hello') == dumper.represent_str(dumper, 'hello')
    assert dumper.represent_unicode(dumper, '123') == dumper.represent_str(dumper, '123')

# Generated at 2022-06-23 05:39:33.980791
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined('hello'))



# Generated at 2022-06-23 05:39:40.679796
# Unit test for function represent_binary
def test_represent_binary():
    # We need to use a specific ascii character to ensure we are not using
    # the default encoding when using python 2.
    rep = yaml.representer.SafeRepresenter()
    # When using python3 just pass a byte string.
    ansible_byte_string = rep.represent_binary(b'\x80')
    python2_byte_string = rep.represent_scalar('tag:yaml.org,2002:binary', 'w4ADG8P5A8P5A8TH5Q==\n', style='>')

    if isinstance(ansible_byte_string, text_type):
        assert ansible_byte_string == python2_byte_string

# Generated at 2022-06-23 05:39:44.632913
# Unit test for function represent_binary
def test_represent_binary():
    data = b'\x00\x01\x02\x03\x04\x05'
    dump_data = yaml.dump(data, Dumper=AnsibleDumper)
    load_data = yaml.load(dump_data)
    assert data == load_data

# Generated at 2022-06-23 05:39:48.916975
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    assert repr(AnsibleDumper) == '<class \'ansible.parsing.yaml.dumper.AnsibleDumper\'>'

# Generated at 2022-06-23 05:39:53.442520
# Unit test for function represent_unicode
def test_represent_unicode():
    u_str = AnsibleUnicode(u"\u263a")
    result = represent_unicode(AnsibleDumper, u_str)
    assert result == u"!ansible-unicode |\n  " + u_str


# Generated at 2022-06-23 05:39:55.265355
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    # Check instance of class AnsibleDumper
    assert isinstance(AnsibleDumper, type)



# Generated at 2022-06-23 05:40:07.198961
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert yaml.dump(HostVars(hostvars_dict={u'test_host': u'test_value'}), Dumper=AnsibleDumper) == 'test_host: test_value\n'
    assert yaml.dump(HostVars(hostvars_dict={u'test_host': [u'test_value']}), Dumper=AnsibleDumper) == 'test_host:\n- test_value\n'
    assert yaml.dump(HostVars(hostvars_dict={u'test_host': {u'test_key': u'test_value'}}), Dumper=AnsibleDumper) == 'test_host:\n  test_key: test_value\n'

# Generated at 2022-06-23 05:40:08.567052
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    a = AnsibleDumper()
    assert a is not None

# Generated at 2022-06-23 05:40:14.954368
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = HostVars(hostname="localhost")
    hostvars["var1"] = "value1"
    hostvars["var2"] = "value2"
    result = yaml.dump(hostvars, Dumper=AnsibleDumper)
    assert result == '{var1: value1, var2: value2}\n'



# Generated at 2022-06-23 05:40:16.424270
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    '''
    >>> dumper = AnsibleDumper()
    '''

# Generated at 2022-06-23 05:40:19.451005
# Unit test for function represent_undefined
def test_represent_undefined():
    data = AnsibleDumper.represent_undefined(None, AnsibleUndefined())
    assert data is True

# Generated at 2022-06-23 05:40:23.286261
# Unit test for function represent_undefined
def test_represent_undefined():
    # Case StrictUndefined
    strict = AnsibleUndefined
    assert bool(strict)

    # Case AnsibleUndefined
    loose = AnsibleUndefined(strict=False)
    assert not bool(loose)



# Generated at 2022-06-23 05:40:31.054376
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    hostvars = HostVarsVars(
            dict(
                foo=dict(
                    bar=42,
                ),
            ),
            filename='fake_filename',
    )
    # Check that we are getting a string of a YAML dictionary.
    assert dumper.represent_hostvars(hostvars) == u'{foo: {bar: 42}}'



# Generated at 2022-06-23 05:40:33.772483
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(b'hello', Dumper=AnsibleDumper) == b"!binary |\n  aGVsbG8=\n"



# Generated at 2022-06-23 05:40:35.401675
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert(isinstance(AnsibleDumper(), AnsibleDumper))

# Generated at 2022-06-23 05:40:38.590413
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    data = AnsibleUndefined()
    res = yaml.dump(data, default_flow_style=False, Dumper=dumper)
    assert res == 'null\n'

# Generated at 2022-06-23 05:40:44.692318
# Unit test for function represent_binary
def test_represent_binary():

    dumper = AnsibleDumper
    output = dumper.represent_binary(dumper, b'\x16\xfa\x83\x17\xce\x1b\xc7\xdd\xc2\x7f\x94\xca\x98\x16\x9e\x0d\xc7\x98\xbb\x01\x00\x00\xff\xff\x01')
    assert output == u"!binary |\n  G6rDl6+rU3nrz/+AGJCnqnAAP9c"

# Generated at 2022-06-23 05:40:48.199507
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import AnsibleUndefined

    yaml.dump_all([{'a': AnsibleUndefined()}], AnsibleDumper)

# Generated at 2022-06-23 05:40:59.250218
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    result = AnsibleVaultEncryptedUnicode(text_type('value')).dump()

# Generated at 2022-06-23 05:41:04.591289
# Unit test for function represent_unicode
def test_represent_unicode():
    actual = yaml.dump(u'unicode!\u2713', Dumper=AnsibleDumper)
    expected = u'unicode!\u2713\n...\n'
    assert actual == expected



# Generated at 2022-06-23 05:41:09.243099
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()
    this_object = AnsibleVaultEncryptedUnicode('12345678')
    assert '!vault |\n          MDAwMDEyMzQ1Njc4\n' == dumper.represent_data(this_object)


# Generated at 2022-06-23 05:41:17.872321
# Unit test for function represent_unicode
def test_represent_unicode():
    samples = [
        u'',
        u'anything',
        u'사과',
        # This is from issue 16360.
        u'\x00\u07FF\u0800\uFFFF',
    ]

    for sample in samples:
        data = AnsibleUnicode(sample)
        expected = sample.encode('ascii', 'backslashreplace')
        actual = yaml.safe_dump(data, default_flow_style=True, indent=2)
        assert actual == "%s\n" % expected



# Generated at 2022-06-23 05:41:23.496956
# Unit test for function represent_binary
def test_represent_binary():
    from ansible.template.safe_eval import unsafe_proxy
    bin_obj = unsafe_proxy.AnsibleUnsafeBytes('h\x00i')
    s = yaml.safe_dump(bin_obj, default_flow_style=True, Dumper=AnsibleDumper)
    assert s == b'!!ansible.unsafe_proxy.AnsibleUnsafeBytes |\n  h\\x00i\n'

# Generated at 2022-06-23 05:41:26.829409
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper, type)
    assert yaml.dumper.SafeDumper == AnsibleDumper.__base__
    assert {} == AnsibleDumper.yaml_representers



# Generated at 2022-06-23 05:41:30.657502
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert yaml.dump({'hostvars': HostVars()}, Dumper=AnsibleDumper) == 'hostvars: {}\n'



# Generated at 2022-06-23 05:41:32.440177
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper
    assert dumper



# Generated at 2022-06-23 05:41:40.069465
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hv = HostVars(host_vars_dict={'testkey': 'testvalue'})
    hvv = HostVarsVars(hostvar_dict={'hostkey': 'hostvalue'})
    data = {'hostvars': hv, 'hostvarsvars': hvv}

    # Ensure that they are still of the same type
    # after they are represent_hostvars
    assert type(data['hostvars']) == HostVars
    assert type(data['hostvarsvars']) == HostVarsVars



# Generated at 2022-06-23 05:41:45.523720
# Unit test for function represent_binary
def test_represent_binary():
    data = "some string"

    # Test that data is binary_type
    assert type(data) is binary_type

    # Test that the representer is called
    dumper = AnsibleDumper()
    ret = represent_binary(dumper, data)

    # Test that the representation is a scalar
    assert ret.tag == u'!binary'

    # Test that the representation is a scalar
    assert type(ret.value) is text_type

    # Test that the new tag is correct
    assert ret.tag == u'!binary'

    # Test that the new tag is not the old tag
    assert ret.tag != u'binary'



# Generated at 2022-06-23 05:41:56.722426
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    '''ensure that the AnsibleVaultEncryptedUnicode yaml dumper works as expected'''
    from ansible.parsing.vault import VaultLib

    vault = VaultLib(password='secret')
    plaintext = "my secret string"
    ciphertext = vault.encrypt(plaintext)
    data = AnsibleVaultEncryptedUnicode(ciphertext, ciphertext=ciphertext)
    result = yaml.dump(data, Dumper=AnsibleDumper)