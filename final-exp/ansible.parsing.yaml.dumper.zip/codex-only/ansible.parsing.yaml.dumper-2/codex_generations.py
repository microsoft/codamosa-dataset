

# Generated at 2022-06-23 05:32:00.886717
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    '''Test represent_vault_encrypted_unicode'''
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    vault = VaultLib([])
    assert vault.decrypt(A('!vault |' + vault.encrypt('hello'), vault)) == 'hello'
    assert vault.decrypt(A('!vault |' + vault.encrypt('hello', version=1), vault)) == 'hello'
    assert vault.decrypt(A('!vault |' + vault.encrypt('hello', version=2), vault)) == 'hello'


# Test for function represent_hostvars

# Generated at 2022-06-23 05:32:04.899702
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    dumper.add_representer(
        AnsibleUnsafeBytes,
        represent_binary,
    )

    assert dumper.represent_binary(binary_type(b'foo')) == b"!!binary |\n  Zm9v"



# Generated at 2022-06-23 05:32:09.569602
# Unit test for function represent_unicode
def test_represent_unicode():
    class Dumper(AnsibleDumper):
        pass
    dumper = Dumper()
    result = dumper.represent_unicode(u'hello world')
    assert result == 'hello world'

# Generated at 2022-06-23 05:32:13.455795
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    result = dumper.represent_binary(b'\x00\x01\x02')
    assert result == "!!binary |-\n  AAEAAQ==", result

# Generated at 2022-06-23 05:32:22.922783
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    import codecs

    for stream in [None, codecs.getwriter('utf-8')(), object()]:
        for default_style in [None, '"', '>', '|', "'"]:
            for default_flow_style in [None, True, False]:
                try:
                    dumper = AnsibleDumper(stream, default_style, default_flow_style)
                except yaml.scanner.ScannerError:
                    pass
                except yaml.serializer.SerializerError:
                    pass
                except yaml.emitter.EmitterError:
                    pass
                except yaml.representer.RepresenterError:
                    pass
                except yaml.resolver.ResolverError:
                    pass

# Generated at 2022-06-23 05:32:25.609236
# Unit test for function represent_binary
def test_represent_binary():
    dumper = yaml.representer.SafeRepresenter()
    assert dumper.represent_binary(b'\x00') == u'!!binary |\n  AAAAAA==\n'

# Generated at 2022-06-23 05:32:36.278861
# Unit test for function represent_unicode
def test_represent_unicode():
    ''' represent_unicode should output unicode strings and unicode literals '''
    assert yaml.dump(u'foo', Dumper=AnsibleDumper) == u'"foo"\n'
    assert yaml.dump('foo', Dumper=AnsibleDumper) == u'"foo"\n'
    assert yaml.dump(u'\u03b1', Dumper=AnsibleDumper) == u'"α"\n'
    assert yaml.dump(u'\u03b1', Dumper=AnsibleDumper) == u'"α"\n'
    assert yaml.dump(u'\u03b1', Dumper=AnsibleDumper) == u'"α"\n'

# Generated at 2022-06-23 05:32:46.856889
# Unit test for function represent_unicode

# Generated at 2022-06-23 05:32:57.429526
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    nonce = b'9\x16\xd5\\\xe5\xfe\xa5\xa7\x05i\xdc\xde\x8a6b\x13\xf1'

# Generated at 2022-06-23 05:33:09.075917
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-23 05:33:11.013894
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    value = 'text'
    expected = '!vault |\n'
    assert represent_vault_encrypted_unicode(None, value) == expected

# Generated at 2022-06-23 05:33:13.885710
# Unit test for function represent_binary
def test_represent_binary():
    # For now, we just ensure that we don't create an error when building this.
    # It would be difficult to test the representation created.
    a = AnsibleDumper.add_representer(
        object,
        represent_binary,
    )

# Generated at 2022-06-23 05:33:15.637148
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    a = AnsibleDumper()
    assert type(a) == AnsibleDumper, "AnsibleDumper() is not of type AnsibleDumper"

# Generated at 2022-06-23 05:33:19.624100
# Unit test for function represent_undefined
def test_represent_undefined():
    data = AnsibleUndefined(var_name='foo')

    yaml.safe_dump(data, Dumper=AnsibleDumper)

    assert data._fail_with_undefined_error.called

# Generated at 2022-06-23 05:33:26.631969
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.yaml.vault import VaultLib
    s = "some stuff"
    v = VaultLib([])
    v_enc = v.encrypt(s)
    d = AnsibleVaultEncryptedUnicode(v_enc)
    res = represent_vault_encrypted_unicode(AnsibleDumper, d)
    assert isinstance(res, yaml.nodes.ScalarNode)
    assert res.style == '|'
    assert res.value == v_enc.decode()


# Generated at 2022-06-23 05:33:37.170067
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    adumper = AnsibleDumper()

# Generated at 2022-06-23 05:33:38.052120
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    ans = AnsibleDumper()
    assert ans

# Generated at 2022-06-23 05:33:43.393354
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = yaml.SafeDumper
    dumper.add_representer(AnsibleUndefined, represent_undefined)

    try:
        dumper.dump(AnsibleUndefined())
    except AnsibleUndefined as e:
        # Error message should be in this format
        assert 'is undefined' in str(e)

# Generated at 2022-06-23 05:33:45.928793
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'5') == u'5'



# Generated at 2022-06-23 05:33:55.532733
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-23 05:33:57.804767
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = {'a': 1, 'b': 2}
    h = HostVars(hostvars)
    assert represent_hostvars(None, h) == '{a: 1, b: 2}'



# Generated at 2022-06-23 05:34:11.484713
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import Templar
    templar = Templar(loader=None)
    dumper = AnsibleDumper
    undefined = AnsibleUndefined('nope')
    # Here the bool(undefined) will set the _fail_with_undefined_error which
    # is what we want.
    templar._fail_with_undefined_error = False
    # Make sure that does not end up in the string
    assert dumper.represent_undefined(dumper, undefined) == 'nope'
    # Now the _fail_with_undefined_error is set so the function should
    # return and error
    templar._fail_with_undefined_error = True
    try:
        dumper.represent_undefined(dumper, undefined)
    except ValueError:
        pass

# Generated at 2022-06-23 05:34:13.957055
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('hello'), Dumper=AnsibleDumper) == "hello\n...\n"



# Generated at 2022-06-23 05:34:23.750187
# Unit test for function represent_hostvars
def test_represent_hostvars():
    '''
    represent_hostvars is a representer for dictionaries, which HostVars instances are.
    However, because HostVars instances are not considered dictionaries by Python,
    we need this custom representer to ensure HostVars instances are displayed as dictionaries.
    '''
    from ansible.vars.hostvars import HostVars
    from ansible.template import AnsibleUndefined

    test = AnsibleUndefined()
    hv = HostVars(hostvars={"foo": "bar"})
    assert yaml.dump({"test": test, "hv": hv}, Dumper=AnsibleDumper) == "{'hv': {'foo': 'bar'}, 'test': None}"

# Generated at 2022-06-23 05:34:34.678829
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-23 05:34:45.397110
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-23 05:34:47.290193
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    AnsibleDumper()



# Generated at 2022-06-23 05:34:52.081614
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = yaml.SafeDumper
    dumper.add_representer(
        AnsibleUnicode,
        represent_unicode,
    )

    assert dumper.represent_scalar('tag:yaml.org,2002:str', 'foo') == \
        dumper.represent_unicode('foo')



# Generated at 2022-06-23 05:35:01.895290
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml.add_constructor("!unsafe", AnsibleLoader.construct_yaml_unsafe)

    data = u"\uc548\ub155\ud558\uc138\uc694"
    assert data == yaml.load(yaml.dump(data, Dumper=AnsibleDumper), Loader=AnsibleLoader)

    assert yaml.dump(text_type("foo"), Dumper=AnsibleDumper) == "foo\n...\n"

    data = b"\xc3\xa0\xc3\xa8\xc3\xac\xc3\xb2\xc3\xb9"

# Generated at 2022-06-23 05:35:11.343478
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = AnsibleVaultEncryptedUnicode(u'$ANSIBLE_VAULT;1.1;AES256\n3132333435363738393031323334353637383930313233343536373839303132333\n3')
    s = yaml.dump(data, Dumper=AnsibleDumper, encoding=None, allow_unicode=True)
    assert s == "!vault |\n  $ANSIBLE_VAULT;1.1;AES256\n  3132333435363738393031323334353637383930313233343536373839303132333\n  3\n"

# Generated at 2022-06-23 05:35:17.920894
# Unit test for function represent_binary
def test_represent_binary():
    # repr() for Python 2.7
    assert yaml.dump(b"foobar", Dumper=AnsibleDumper).split('\n', 1)[0] == "'foobar'"
    # repr() for Python 3.4
    assert yaml.dump(b"b'foobar'", Dumper=AnsibleDumper).split('\n', 1)[0] == "b'b\\x27foobar\\x27'"

# Generated at 2022-06-23 05:35:25.574798
# Unit test for function represent_unicode
def test_represent_unicode():
    a = {'a': 'b'}
    b = yaml.dump(a, Dumper=AnsibleDumper)
    assert b == '{a: b}\n'
    a = {'a': u'\u2713'}
    b = yaml.dump(a, Dumper=AnsibleDumper)
    assert b == u'{a: \u2713}\n', b

# Generated at 2022-06-23 05:35:28.687591
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    dumper.ignore_aliases = lambda *args: True
    assert dumper.represent_data(AnsibleUndefined) is dumper.represent_code(None)



# Generated at 2022-06-23 05:35:39.410528
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-23 05:35:43.782204
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = AnsibleVaultEncryptedUnicode("hello world")
    assert represent_vault_encrypted_unicode(AnsibleDumper(), data) == yaml.representer.SafeRepresenter.represent_scalar(u'!vault', data._ciphertext.decode(), style='|')



# Generated at 2022-06-23 05:35:44.771223
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper.represent_str

# Generated at 2022-06-23 05:35:50.846340
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.playbook.play_context import PlayContext

    obj = HostVars('anyhost')
    obj['blah'] = 1
    obj['foo'] = 2
    obj.counter = 3
    obj._play_context = PlayContext()

    yaml.dump(obj, Dumper=AnsibleDumper)



# Generated at 2022-06-23 05:36:02.374290
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Setup
    text = 'Testing represent_vault_encrypted_unicode function: '
    ciphertext = ('$ANSIBLE_VAULT;1.1;AES256\n'
                  '303539643464626265633831633766363965663734336665363934373735376164316635386230\n'
                  '6538366637373663663163356265326532313334646266343961310a6332353836303738343566\n'
                  '356438316533323339376334623938393462366565323761323664393561623661353336343665\n'
                  '353633323666366335303839346632\n')
    av_obj = AnsibleVaultEnc

# Generated at 2022-06-23 05:36:04.064286
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    ad = AnsibleDumper()
    assert(ad.tags == {})



# Generated at 2022-06-23 05:36:05.038597
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper



# Generated at 2022-06-23 05:36:14.340425
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # This is just a simple test to make sure we are not representing hostvars as
    # strings, which is the default behavior.
    from collections import namedtuple
    from ansible.vars.manager import VariableManager

    FooVars = namedtuple('FooVars', 'inventory')
    foo = FooVars(VariableManager())
    foo.inventory.hostvars['hostname'] = {'some': 'data'}
    dumped = yaml.dump(foo, Dumper=AnsibleDumper, default_flow_style=False)
    assert 'hostname: !!python/object' in dumped
    assert 'some: data' in dumped

    # This is the default behavior, we want to make sure we are not doing this
    # because hostvars are complex data structures

# Generated at 2022-06-23 05:36:24.310193
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    data = b"\x00\x01\x7f\xff"  # 4 bytes
    expect = u'!!binary |\n  AA+/\n'
    assert represent_binary(dumper, data) == expect

    data = b"\x00\x01\x7f\xff\x00\x01\x7f\xff"  # 8 bytes
    expect = u'!!binary |\n  AA+/AA+/\n'
    assert represent_binary(dumper, data) == expect

    data = b"\x00\x01\x7f\xff\x00\x01\x7f\xff\x00\x01\x7f\xff\x00\x01\x7f"  # 15 bytes

# Generated at 2022-06-23 05:36:28.995059
# Unit test for function represent_binary
def test_represent_binary():

    data = binary_type('\x00\x01\x02\x03\x04')
    dump_data = '!binary |\n  ...'
    dumper = yaml.Dumper
    dumper.represent_binary = represent_binary
    assert yaml.dump(data, Dumper=dumper) == dump_data

# Generated at 2022-06-23 05:36:31.615331
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    assert represent_vault_encrypted_unicode(AnsibleDumper, AnsibleVaultEncryptedUnicode('test')) == "!vault |\n          test"

# Generated at 2022-06-23 05:36:42.667966
# Unit test for function represent_unicode
def test_represent_unicode():
    class Dumper(yaml.Dumper):
        def encode(self, data):
            return str(data)

    dumper = Dumper(width=2)

    assert dumper.represent_unicode(u'foo') == "u'foo'"
    assert dumper.represent_unicode(u'foo\n') == "u'foo\\n'"
    assert dumper.represent_unicode(u'foo#bar') == "u'foo#bar'"
    assert dumper.represent_unicode(u'foo #bar') == "'foo #bar'"

    dumper.width = 3
    assert dumper.represent_unicode(u'foo') == "u'foo'"
    assert dumper.represent_unicode(u'foo\n') == "u'foo\\n'"

# Generated at 2022-06-23 05:36:50.539308
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = yaml.dumper.Dumper
    data = AnsibleUnicode(u'\u20ac')
    assert data.encode() == b'\xe2\x82\xac'
    d = represent_unicode(dumper, data)
    assert d == b'"\\u20ac"'
    d = yaml.dump(data, Dumper=dumper)
    assert d == b'"\\u20ac"\n...\n'



# Generated at 2022-06-23 05:36:52.472656
# Unit test for function represent_binary
def test_represent_binary():
    # create test data
    binary = b'123456'
    representer = AnsibleDumper()
    # result
    represent_binary(representer, binary)

# Generated at 2022-06-23 05:36:56.354912
# Unit test for function represent_hostvars
def test_represent_hostvars():
    result = yaml.dump(dict(test_hostvars), Dumper=AnsibleDumper)
    assert(result == 'test_hostvars: {}\n')

test_hostvars = HostVars('test_hostvars')

# Generated at 2022-06-23 05:37:06.345468
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    import pytest
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-23 05:37:11.106496
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert issubclass(AnsibleDumper, SafeDumper)
    assert yaml.Dumper is not AnsibleDumper  # Don't pollute the global namespace
    assert yaml.representer.Representer is not AnsibleDumper  # Don't pollute the global namespace

# Generated at 2022-06-23 05:37:13.914862
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    d = AnsibleDumper("foo", default_flow_style=False)
    assert d.default_flow_style == False



# Generated at 2022-06-23 05:37:17.384643
# Unit test for function represent_hostvars
def test_represent_hostvars():
    result = {}
    original = HostVars(vars=result)
    hostvars_yaml = yaml.dump(original, Dumper=AnsibleDumper)
    assert hostvars_yaml == '{}\n'

# Generated at 2022-06-23 05:37:20.330215
# Unit test for function represent_unicode
def test_represent_unicode():
    # Simple test for default
    assert yaml.dump(AnsibleUnicode('hello_world'), Dumper=AnsibleDumper) == 'hello_world\n...\n'



# Generated at 2022-06-23 05:37:22.275382
# Unit test for function represent_undefined
def test_represent_undefined():

    assert AnsibleDumper.represent_undefined(AnsibleDumper(), AnsibleUndefined()) == True  # NOQA

# Generated at 2022-06-23 05:37:23.300315
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert True, "test needed"



# Generated at 2022-06-23 05:37:26.273576
# Unit test for function represent_unicode
def test_represent_unicode():
    data = u'foo'
    assert yaml.dump(data, Dumper=AnsibleDumper) == u"!!python/unicode 'foo'\n"



# Generated at 2022-06-23 05:37:30.505187
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = {'a': 'b', 'c': 'd'}
    dumper = AnsibleDumper()
    output = dumper.represent_dict(dict(data))
    assert output == yaml.representer.SafeRepresenter.represent_dict(dumper, dict(data))

# Generated at 2022-06-23 05:37:33.836205
# Unit test for function represent_undefined
def test_represent_undefined():
    data = AnsibleUndefined('test', 'test', 'test')
    dumper = AnsibleDumper
    x = dumper.represent_undefined(dumper, data) == bool(data)
    assert x


# Generated at 2022-06-23 05:37:35.778197
# Unit test for function represent_undefined
def test_represent_undefined():
    yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper)

# Generated at 2022-06-23 05:37:38.375880
# Unit test for function represent_hostvars
def test_represent_hostvars():
    obj = AnsibleMapping({"a": 1, "b": "2"})
    assert yaml.dump(obj, Dumper=AnsibleDumper) == "{a: 1, b: '2'}"

# Generated at 2022-06-23 05:37:48.086251
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert yaml.dumper.BaseDumper.safe_dump_all is yaml.dumper.Dumper.safe_dump_all
    assert yaml.dumper.BaseDumper.add_representer is yaml.dumper.Dumper.add_representer
    assert yaml.dump is yaml.emit.dump
    assert yaml.safe_dump is yaml.emit.safe_dump

    # This will initialize the object and then execute the following calls
    # yaml.dumper.Dumper.safe_dump_all()
    # yaml.dumper.Dumper.add_representer()
    # yaml.emit.dump()
    # yaml.emit.safe_dump()
    #
    # test_AnsibleDumper.test_should_have_the_same_values_as_an

# Generated at 2022-06-23 05:37:55.779100
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.template.template import AnsibleJ2Template

    def _pkg_resources_find_loader(*args, **kwargs):
        return None

    dump_data = dict(
        foo='foo',
        bar=AnsibleUndefined(),
        baz=[AnsibleUndefined()],
        fubar='{{ foobar }}',
    )

    expected_data = dict(
        foo='foo',
        bar=False,
        baz=False,
        fubar='{{ foobar }}',
    )

    env = AnsibleJ2Template._get_j2_environment(allow_undefined=True)
    env.loader.path_exception_handler = AnsibleLoader.path_exception_handler
    env.loader.file

# Generated at 2022-06-23 05:37:59.635189
# Unit test for function represent_hostvars
def test_represent_hostvars():
    ansible_dumper = AnsibleDumper()
    hostvars = HostVars(dict(k=42))
    expected = "k: 42\n"
    assert expected == ansible_dumper.represent_data(hostvars)



# Generated at 2022-06-23 05:38:01.097094
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dump = AnsibleDumper()

    assert dump

# Generated at 2022-06-23 05:38:09.463029
# Unit test for function represent_hostvars
def test_represent_hostvars():

    a = AnsibleDumper()
    b = AnsibleUnicode("some_unicode_string")

    # To test representation, we need to get the output
    # from the module first.
    # This is the only way to get output from the module.
    # Calling the function directly from the variable
    # will show an error.
    repres = a.represent_data(b)

    # The output from represent_data is a string, not a
    # list or tuple of strings. Therefore, we have to
    # convert the string to a list before we can
    # compare the list with other lists.
    repres_list = repres.split()

    # The expected output should be a list with the
    # following structure:
    # [ '-', 'some_unicode_string' ]
    # Therefore, the following assertion should work

# Generated at 2022-06-23 05:38:18.949893
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_data('test') == 'test\n...\n'
    assert dumper.represent_data(u'test') == 'test\n...\n'
    assert dumper.represent_data(b'test') == 'test\n...\n'
    assert dumper.represent_data(AnsibleUnicode(u'test')) == 'test\n...\n'
    assert dumper.represent_data(AnsibleUnsafeText(u'test')) == 'test\n...\n'
    assert dumper.represent_data(AnsibleUnsafeBytes(b'test')) == 'test\n...\n'

# Generated at 2022-06-23 05:38:20.962220
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper, type)
    assert hasattr(AnsibleDumper, 'add_representer')

# Generated at 2022-06-23 05:38:26.363580
# Unit test for function represent_hostvars
def test_represent_hostvars():
    test_hostvars = HostVars(hostname="localhost", vars={"main": "test"})
    result = yaml.dump(test_hostvars, Dumper=AnsibleDumper)
    assert result == "main: test\n"


# Unit tests for function represent_vault_encrypted_unicode

# Generated at 2022-06-23 05:38:29.762352
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = HostVars({'data': 'foo'})

    actual = yaml.dump(data, Dumper=AnsibleDumper)

    expected = '''data: foo
'''

    assert actual == expected



# Generated at 2022-06-23 05:38:41.845518
# Unit test for function represent_undefined
def test_represent_undefined():
    rep = AnsibleDumper.represent_undefined
    # If a value is None, it is represented as 'null'
    assert rep(None) is None
    # If a value is not None and not Undefined, its bool() is used to
    # represent it
    assert rep(True) == True
    assert rep(False) == False
    assert rep(1) == True
    assert rep(0) == False
    assert rep('') == False
    assert rep('foo') == True
    assert rep(0.0) == False
    assert rep(1.0) == True
    assert rep([]) == False
    assert rep(['foo']) == True
    assert rep({}) == False
    assert rep({'foo': 'bar'}) == True
    assert rep(set()) == False
    assert rep({'foo'}) == True

# Generated at 2022-06-23 05:38:53.961792
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    yaml_str = yaml.dump(AnsibleVaultEncryptedUnicode('foo'), Dumper=AnsibleDumper, allow_unicode=True)

# Generated at 2022-06-23 05:38:55.967410
# Unit test for function represent_unicode
def test_represent_unicode():
    data = AnsibleUnicode('abc')
    assert represent_unicode(None, data) == "abc"



# Generated at 2022-06-23 05:38:58.998382
# Unit test for function represent_hostvars
def test_represent_hostvars():
    d = AnsibleDumper()
    h = HostVars()
    h['var1'] = 'value1'

    assert yaml.safe_dump(h, default_flow_style=False, Dumper=AnsibleDumper) == 'var1: value1\n'

# Generated at 2022-06-23 05:39:06.161546
# Unit test for function represent_undefined
def test_represent_undefined():
    # Just make sure this doesn't raise any error
    # Either:
    #   - There's no Undefined values in the data (i.e. all were
    #     coerced to empty strings)
    #   - The Undefined value will cause _fail_with_undefined_error
    #     to be called, and the latter will raise a YAML error
    yaml.safe_dump(dict(foo=AnsibleUndefined('')), stream=None, Dumper=AnsibleDumper)

# Generated at 2022-06-23 05:39:17.642569
# Unit test for function represent_undefined
def test_represent_undefined():
    # This is a hack to get around a test running issue.
    # In this case, AnsibleUndefined is loaded as a class
    # and the test passes. In other contexts, AnsibleUndefined
    # is loaded as a function, where the test fails (as it
    # should).
    if not isinstance(AnsibleUndefined, type):
        return
    from ansible.template import generate_ansible_safe_yaml_loader
    ud = AnsibleUndefined()
    yaml_loader = generate_ansible_safe_yaml_loader('test', None, None)
    text = yaml.safe_dump(ud, default_flow_style=False, Dumper=AnsibleDumper)
    assert text == "ERROR! Undefined variable\n"



# Generated at 2022-06-23 05:39:18.940702
# Unit test for function represent_binary
def test_represent_binary():
    # TODO: Write a unit test
    pass

# Generated at 2022-06-23 05:39:30.975384
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    ciphertext = 'secret\n'

# Generated at 2022-06-23 05:39:33.472875
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    d = AnsibleDumper(None)
    assert isinstance(d, AnsibleDumper)

# Generated at 2022-06-23 05:39:40.184639
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():

    s = yaml.dump(AnsibleVaultEncryptedUnicode("foo"))
    assert s == u'!vault |\n          ZjJkODJjYzBkMjY3YzQ2YjFkMzQ2N2E1MzUwMjcxYmYyYzc0YjYyYWYzM2U3OThkYTczNWVlYmRlYmVjNDA4OQ==\n\n'


# Generated at 2022-06-23 05:39:49.091565
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.dataloader import DataLoader

    # Ensure loading allows YAML anchors
    loader = DataLoader()
    loader.set_allow_unsafe_lookups(True)

    # Load dictionary with Vault encrypted text
    data = loader.load_from_file("test/utils/vault_encrypted_unicode.yml")

    # Ensure unicode is properly returned
    assert len(data["foo"]) == len(u"$ANSIBLE_VAULT;1.1;AES256")

    # Ensure unicode is properly returned
    assert data["foo"][0:28] == u"$ANSIBLE_VAULT;1.1;AES256"

    # Ensure unicode is properly returned

# Generated at 2022-06-23 05:39:51.079699
# Unit test for function represent_binary
def test_represent_binary():
    dumper = yaml.SafeDumper
    data = u'\u20ac'
    assert data.encode('utf-8') == dumper.represent_binary(dumper, data)



# Generated at 2022-06-23 05:39:52.743472
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # TODO: Add unit tests
    pass

# Generated at 2022-06-23 05:40:02.227586
# Unit test for function represent_binary
def test_represent_binary():
    class TestAnsibleDumper(AnsibleDumper):
        # jinja2-2.7.3-py2.7.egg/jinja2/tests/test_custom_representer.py
        def ignore_aliases(self, data):
            return True
    dumper = TestAnsibleDumper()
    data = ''.join(chr(n) for n in range(256))
    result = dumper.represent_binary(data)

# Generated at 2022-06-23 05:40:07.793415
# Unit test for function represent_binary
def test_represent_binary():
    from ansible.module_utils.six import b
    dumper = AnsibleDumper
    output = dumper.represent_binary(None, b('hello'))
    assert output == "!!binary |\n  aGVsbG8=\n", "output was: %s" % output



# Generated at 2022-06-23 05:40:19.335215
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-23 05:40:23.611050
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper(width=79)
    assert dumper.represent_undefined(AnsibleUndefined()) == dumper.represent_undefined(AnsibleUndefined(strict=True))


__all__ = ['AnsibleDumper']

# Generated at 2022-06-23 05:40:30.835351
# Unit test for function represent_unicode
def test_represent_unicode():
    value = AnsibleUnicode("value")
    dumper = yaml.SafeDumper
    assert dumper.represent_unicode is represent_unicode
    result = represent_unicode(dumper, value)
    # Ensure the expected representation is returned
    expected = yaml.representer.SafeRepresenter.represent_str(dumper, "value")
    assert result == expected



# Generated at 2022-06-23 05:40:34.473170
# Unit test for function represent_unicode
def test_represent_unicode():
    ''' ansible.parsing.yaml.dumper.represent_unicode '''
    assert represent_unicode(None, AnsibleUnicode('hello')) == u"hello"
    assert represent_unicode(None, AnsibleUnicode(u"hello")) == u"hello"
    assert represent_unicode(None, u"hello") == u"hello"



# Generated at 2022-06-23 05:40:35.501657
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper, type)

# Generated at 2022-06-23 05:40:44.598454
# Unit test for function represent_hostvars
def test_represent_hostvars():
    actual_hostvar = {'foo': 'bar', 'nested': {'a': 1}}
    expected_representation = ("---\n"
                               "foo: bar\n"
                               "nested:\n"
                               "  a: 1\n")

    assert yaml.dump(HostVars(vars=actual_hostvar), Dumper=AnsibleDumper) == expected_representation

    actual_hostvar = {'foo': 'bar', 'nested': {'a': 1}}
    expected_representation = ("---\n"
                               "foo: bar\n"
                               "nested:\n"
                               "  a: 1\n")

    assert yaml.dump(HostVars(vars=actual_hostvar), Dumper=AnsibleDumper) == expected_representation

# Generated at 2022-06-23 05:40:55.056644
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Test valid value
    plain_text = "ansible"
    encrypted_text = "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          623942383143623365237353319393331326162643033373938643462653963373263626264330a\n          386265343764393835383337306431313631323063366663636662623539666431343135643365\n          36326332306335343064613239343561396630336336666623366616561360a\n"
    # Test the function

# Generated at 2022-06-23 05:41:01.973223
# Unit test for function represent_unicode
def test_represent_unicode():
    # Tests for function represent_unicode
    dumper = AnsibleDumper

    # Test for object type AnsibleUnicode
    dumper.represent_scalar = yaml.representer.SafeRepresenter.represent_str
    obj = AnsibleUnicode('foo')
    ret = represent_unicode(dumper, obj)
    assert ret == u"foo"

    # Test for object type AnsibleUnsafeText
    dumper.represent_scalar = yaml.representer.SafeRepresenter.represent_str
    obj = AnsibleUnsafeText('foo')
    ret = represent_unicode(dumper, obj)
    assert ret == u"foo"

    # Test for object type AnsibleUnsafeBytes
    dumper.represent_scalar = yaml.representer.SafeRepresenter.represent_str
    obj

# Generated at 2022-06-23 05:41:07.349034
# Unit test for function represent_undefined
def test_represent_undefined():
    undefined = AnsibleUndefined('testing')
    # Here we're calling the AnsibleDumper.represent_undefined method instead of
    # the default method (yaml.representer.SafeRepresenter.represent_undefined)
    output = AnsibleDumper.represent_undefined(AnsibleDumper, undefined)
    assert output is True, 'represent_undefined did not return True'

# Generated at 2022-06-23 05:41:15.389473
# Unit test for function represent_binary
def test_represent_binary():
    d = yaml.Dumper()
    yaml.add_representer(binary_type, yaml.representer.SafeRepresenter.represent_binary)
    yaml.add_representer(six.text_type, yaml.representer.SafeRepresenter.represent_str)
    out = yaml.dump(six.b('foo'), Dumper=d)
    assert out == "!!binary |\n  Zm9v\n"
    out = yaml.dump(six.text_type(six.b('foo'), encoding='utf-8'), Dumper=d)
    assert out == "foo\n"

# Generated at 2022-06-23 05:41:24.831196
# Unit test for function represent_binary

# Generated at 2022-06-23 05:41:30.276880
# Unit test for function represent_binary
def test_represent_binary():
    # Setup data
    data = binary_type(b'my word')
    default_data = yaml.representer.SafeRepresenter.represent_binary(data)
    # Run the code to test
    result = represent_binary(data)
    # Verify the result
    assert result == default_data

# Generated at 2022-06-23 05:41:41.313809
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import AnsibleUndefined
    from ansible.parsing.yaml import objects, datastructure_filter

    def fail_with_undefined_error(obj, key=None, thtvars=None, **kwargs):
        raise AnsibleUndefinedVariable('{{%s}}' % key or '<no key>')

    ds = objects.AnsibleMapping()
    ds['a'] = objects.AnsibleUnsafeText('a')
    ds['b'] = objects.AnsibleUnsafeText('b')
    ds[objects.AnsibleUnsafeText('c')] = objects.AnsibleUnsafeText('c')
    ds[objects.AnsibleUnsafeText('d')] = objects.AnsibleMapping()

# Generated at 2022-06-23 05:41:42.769760
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    yaml.dump('foo', Dumper=AnsibleDumper)

# Generated at 2022-06-23 05:41:45.597699
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode(u'foo'), Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-23 05:41:52.783569
# Unit test for function represent_hostvars
def test_represent_hostvars():
    for value in [HostVars(dict(key1='value1', key2='value2'))]:
        assert dict(value) == yaml.load(yaml.dump(value, Dumper=AnsibleDumper), Loader=yaml.SafeLoader)
        assert isinstance(yaml.dump(value, Dumper=AnsibleDumper), (text_type, binary_type))

# Generated at 2022-06-23 05:42:01.702617
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.module_utils.common.yaml import AnsibleDumper
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    h = HostVars({"k1": "v1"})
    j = VariableManager()
    j.set_host_variable(host=None, varname="hostvars", value=h)
    output = yaml.dump(j._vars, Dumper=AnsibleDumer, default_flow_style=False)
    assert output == """{hostvars: {k1: v1}}\n"""

