

# Generated at 2022-06-23 05:32:01.865532
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = yaml.dumper.SafeDumper
    data = AnsibleUndefined('Test')
    dumper.add_representer(AnsibleUndefined, represent_undefined)
    result = dumper.represent_undefined(dumper, data)
    assert result is False



# Generated at 2022-06-23 05:32:04.677398
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    # Instantiate the class
    instance = AnsibleDumper(indent=4, width=80)
    # Check instance
    assert isinstance(instance, yaml.Dumper)

# Generated at 2022-06-23 05:32:08.956349
# Unit test for function represent_unicode
def test_represent_unicode():
    data = AnsibleUnicode('\n@: \n')
    assert type(yaml.dump(data, Dumper=AnsibleDumper)) is text_type



# Generated at 2022-06-23 05:32:18.060561
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible import context
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    context.CLIARGS['vault_password_file'] = None
    context.CLIARGS['ask_vault_pass'] = None

    vault = VaultLib([], None)


# Generated at 2022-06-23 05:32:27.524366
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-23 05:32:29.023795
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, 'foo') == u"'foo'"



# Generated at 2022-06-23 05:32:39.835003
# Unit test for function represent_binary
def test_represent_binary():
    d = AnsibleDumper()
    assert d.represent_binary(b'foo') == u'!!binary "Zm9v"'
    # Note: this will fail if the stream encoding is set to something else.
    assert d.represent_binary(b'\xf0\xf1\xc3\xbf').encode('utf-8') == u'!!binary "8J+Ugf/"'.encode('utf-8')
    # Check invalid encoding fails
    try:
        d.represent_binary(b'\xf0\xf1\xc3\xbf' + b'\xf0\xf1\xc3\xbf').encode('utf-8')
        assert False, "invalid encoding did not raise an exception"
    except UnicodeDecodeError:
        pass

# Generated at 2022-06-23 05:32:46.843117
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-23 05:32:48.104467
# Unit test for function represent_hostvars
def test_represent_hostvars():
    represent_hostvars(AnsibleDumper, dict(a=1, b=2))



# Generated at 2022-06-23 05:32:59.432400
# Unit test for function represent_hostvars
def test_represent_hostvars():

    def represent_hostvars_run_test(data, expected_str):
        # reset the dumper for each test
        AnsibleDumper.add_multi_representer(
            type,
            yaml.representer.SafeRepresenter.represent_data,
        )
        AnsibleDumper.add_representer(
            HostVars,
            represent_hostvars,
        )
        output = yaml.dump(data, Dumper=AnsibleDumper)
        assert output == expected_str

    # Expected output of the data

# Generated at 2022-06-23 05:33:06.552962
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    rst = dumper.represent_binary(data=b'abc')
    assert isinstance(rst, tuple)
    rst_lst, rst_style = rst
    assert isinstance(rst_lst, list)
    assert isinstance(rst_style, str)
    assert rst_lst[0] == b'abc'
    assert rst_style == '|'



# Generated at 2022-06-23 05:33:15.378627
# Unit test for function represent_hostvars
def test_represent_hostvars():
    '''This test case is specifically to check that variable names
    beginning with '_' are excluded from the dumped yaml.
    '''
    data = {
        '_hidden_var': 'bar',
        'a': 'b',
    }
    # Dump to yaml and then load it back in (to deal with yaml lib's
    # OrderedDict, which persists object instantiation order)
    # Exclude loading the private AnsibleUnicode class.
    result = yaml.load(yaml.dump(data, Dumper=AnsibleDumper), Loader=yaml.SafeLoader)
    assert '_hidden_var' not in result

# Generated at 2022-06-23 05:33:20.034065
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    d = AnsibleDumper()
    data = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.0;AES;32charshere==', 'ciphertext==')
    result = d.represent_scalar('!vault', data)
    assert result == "!vault |\n      $ANSIBLE_VAULT;1.0;AES;32charshere==\n      ciphertext=="

# Generated at 2022-06-23 05:33:21.999768
# Unit test for function represent_binary
def test_represent_binary():
    assert AnsibleDumper.represent_binary(b'\x00') == '!!binary |\n  AA=='

# Generated at 2022-06-23 05:33:33.614796
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from io import StringIO
    from ansible.vars.hostvars import HostVars

    fake_loader = DataLoader()
    fake_inventory = InventoryManager(loader=fake_loader, sources='')
    variable_manager = VariableManager(loader=fake_loader, inventory=fake_inventory)
    hostvars = HostVars(variable_manager, 'localhost')
    output = StringIO()
    yaml.dump(hostvars, output, Dumper=AnsibleDumper)
    assert output.getvalue() == "localhost:\n\n"

    # Test ansible_hostname

# Generated at 2022-06-23 05:33:35.433963
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.dump(AnsibleUndefined, Dumper=AnsibleDumper) == 'false'

# Generated at 2022-06-23 05:33:38.593490
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(None) is None

# Generated at 2022-06-23 05:33:40.059976
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper(), AnsibleDumper)

# Generated at 2022-06-23 05:33:50.374823
# Unit test for function represent_hostvars
def test_represent_hostvars():

    class FakeDict(dict):

        def __init__(self):
            super(FakeDict, self).__init__()
            self._diff_pairs = []

    class FakeDiff(object):

        def __init__(self, key, path):
            self.key = key
            self.path = path

    class FakePath(list):

        def __init__(self, diff_items):
            for diff_item in diff_items:
                self.append(diff_item)

    def make_hostvars_dict(hostvars_dict, diff_pairs):
        '''
        Creates the fake HostVars object defined in the unit test.
        '''
        hostvars_obj = HostVars('')

# Generated at 2022-06-23 05:34:01.386459
# Unit test for function represent_unicode
def test_represent_unicode():
    def _create_loader():
        loader = yaml.SafeLoader('')
        # AnsibleUnicode -> AnsibleUnicode
        loader.add_constructor(u'tag:yaml.org,2002:str',
                               lambda loader, node: AnsibleUnicode(node.value))
        # AnsibleUnsafeText -> AnsibleUnsafeText
        loader.add_constructor(u'!unsafe',
                               lambda loader, node: AnsibleUnsafeText(node.value))
        # Binary -> AnsibleUnsafeBytes
        loader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG,
                               lambda loader, node: AnsibleUnsafeBytes(loader.construct_yaml_binary(node)))
        return loader


# Generated at 2022-06-23 05:34:10.316300
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible_vault import VaultLib
    vault = VaultLib('test', 'yaml')
    vault.update({'plaintext': 'value'})
    encrypted_value = vault.dump()

    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode('!vault |\n'+",\n".join(encrypted_value.splitlines())+"\n")
    yaml.dump(ansible_vault_encrypted_unicode, sys.stdout, Dumper=AnsibleDumper, default_flow_style=False)

# Generated at 2022-06-23 05:34:12.324212
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    ansibledumper = AnsibleDumper()
    assert isinstance(ansibledumper, AnsibleDumper)

# Generated at 2022-06-23 05:34:15.946204
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper(indent=4, width=80, default_flow_style=False)
    assert dumper.indent == 4
    assert dumper.width == 80
    assert dumper.default_flow_style is False

# Generated at 2022-06-23 05:34:23.128377
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = '''
    ---
    testhost:
        ansible_host: 192.168.1.1
        ansible_port: 22
    '''
    loaded = yaml.load(data, Loader=yaml.Loader)
    assert loaded == {u'testhost': {u'ansible_host': u'192.168.1.1', u'ansible_port': 22}}
    dumped = yaml.dump(loaded, Dumper=AnsibleDumper)
    assert dumped == data

# Generated at 2022-06-23 05:34:27.475879
# Unit test for function represent_unicode
def test_represent_unicode():
    ''' test that we properly represent unicode objects '''

    # unicode string
    assert yaml.dump(u'foo', Dumper=AnsibleDumper).strip() == "foo"

    # byte string
    assert yaml.dump(b'foo', Dumper=AnsibleDumper).strip() == "foo"

# Generated at 2022-06-23 05:34:31.158754
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.safe_dump({u'safe': u"\u1234"}, default_flow_style=False, Dumper=AnsibleDumper) == \
        """safe: \u1234
"""



# Generated at 2022-06-23 05:34:39.271268
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(text_type('foo'), Dumper=AnsibleDumper) == u'foo\n...\n'
    assert yaml.dump(text_type('bar\nbaz'), Dumper=AnsibleDumper) == u'"bar\\nbaz"\n...\n'
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == u'foo\n...\n'



# Generated at 2022-06-23 05:34:42.162856
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.safe_load(yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper)) is None

# Generated at 2022-06-23 05:34:45.561265
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = AnsibleVaultEncryptedUnicode('AES256', '\n')
    assert represent_vault_encrypted_unicode(None, data) == text_type("!vault |\n  \n")



# Generated at 2022-06-23 05:34:46.919072
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper(), SafeDumper)



# Generated at 2022-06-23 05:34:53.795935
# Unit test for function represent_undefined
def test_represent_undefined():
    instance = AnsibleUndefined('hello')
    assert instance
    instance = AnsibleUndefined('')
    assert instance
    instance = AnsibleUndefined('0')
    assert instance
    instance = AnsibleUndefined(0)
    assert instance
    instance = AnsibleUndefined(False)
    assert instance
    instance = AnsibleUndefined([])
    assert instance
    instance = AnsibleUndefined({})
    assert instance
    instance = AnsibleUndefined(...)
    assert instance
    instance = AnsibleUndefined(None)
    assert False is instance

# Generated at 2022-06-23 05:35:02.322903
# Unit test for function represent_binary
def test_represent_binary():
    assert AnsibleDumper.represent_binary(AnsibleUnsafeBytes(b'\x00\x80\xFF')) == b': !!binary |\n  AAH/\n'
    assert AnsibleDumper.represent_binary(AnsibleUnsafeBytes(b'\x00')) == b': !!binary |\n  AA==\n'
    assert AnsibleDumper.represent_binary(AnsibleUnsafeBytes(b'\x80')) == b': !!binary |\n  gg==\n'
    assert AnsibleDumper.represent_binary(AnsibleUnsafeBytes(b'\xFF')) == b': !!binary |\n  /w==\n'

# Generated at 2022-06-23 05:35:07.492386
# Unit test for function represent_hostvars
def test_represent_hostvars():
    """
    Ensure we transform HostVars objects correctly into yaml format.

    :return: True if the yaml representer returns the right data
    """
    # Create dummy data
    data = VarsWithSources(
        {
            'foo': 'bar',
            'spam': 'ham',
        }
    )

    # Perform the representation
    represent_hostvars(AnsibleDumper, data)

    # Assert
    assert isinstance(data, VarsWithSources)



# Generated at 2022-06-23 05:35:18.045487
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from io import StringIO

    play = Play.load(dict(
        name = 'test_play',
        hosts = 'all',
        roles = [],
        vars = {
            'var': 'val',
        },
        tasks = [],
    ), variable_manager = VariableManager(), loader = None)

    dumper = yaml.dumper.Dumper(None, None, None, None)
    dumper.representer = AnsibleDumper.representer

    # The variable manager's hostvars is an instance of HostVars
    # while the play's _hostvars is HostVarsVars.
    # This is because HostVarsVars is a wrapper around HostVars
    # that allows access to its v

# Generated at 2022-06-23 05:35:26.100969
# Unit test for function represent_binary
def test_represent_binary():
    from ansible.module_utils.six import b

    test_data = b(b'123')

    dumper = AnsibleDumper()
    yaml_data = dumper.represent_binary(test_data)

    assert yaml_data.tag == "tag:yaml.org,2002:binary"
    assert yaml_data.value == test_data
    assert yaml_data.style == "|"



# Generated at 2022-06-23 05:35:32.032475
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import AnsibleUndefined
    from ansible.errors import AnsibleUndefinedVariable

    try:
        yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper)
        raise AssertionError('AnsibleUndefined did not raise AnsibleUndefinedVariable')
    except AnsibleUndefinedVariable as e:
        assert "Unable to look up a name" in "{0}".format(e)



# Generated at 2022-06-23 05:35:37.678901
# Unit test for function represent_hostvars
def test_represent_hostvars():
    obj = HostVars()
    obj.add_host_vars(
        host='localhost',
        variables={
            'foo': 'bar',
            'baz': True,
            'qux': 123
        }
    )

    result = yaml.dump(obj, Dumper=AnsibleDumper, default_flow_style=False)
    assert result == "localhost:\n  baz: true\n  foo: bar\n  qux: 123\n"

    obj = HostVars()
    obj.add_host_vars(
        host='localhost',
        variables={
            'foo': 'bar',
            'baz': True,
            'qux': 123
        }
    )

# Generated at 2022-06-23 05:35:46.833767
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.vars.hostvars import HostVars

    hostvars = wrap_var(HostVars())

    assert isinstance(hostvars, AnsibleBaseYAMLObject)
    assert isinstance(hostvars, HostVars)
    assert issubclass(hostvars.__class__, AnsibleBaseYAMLObject)

    data = dict(hostvars)

    # Use AnsibleDumper to dump data to yaml.
    # If Exception is thrown, assert statement will fail.
    AnsibleDumper.represent_hostvars(AnsibleDumper, data)

# Generated at 2022-06-23 05:35:54.806966
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    test_data = b'#ascii'
    expected = b'#ascii\n'
    actual = yaml.dump(test_data, Dumper=AnsibleDumper)
    assert expected == actual, "Failed to dump a simple unicode string"

    test_data = b'unicode\xe9'
    try:
        yaml.dump(test_data, Dumper=AnsibleDumper)
        assert False, "Failed to generate an exception on an unsafe unicode string"
    except UnicodeDecodeError:
        pass


# Test our safe_load_all and safe_dump functions

# Generated at 2022-06-23 05:35:56.710645
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper, type)



# Generated at 2022-06-23 05:35:59.431090
# Unit test for function represent_binary
def test_represent_binary():
    res = AnsibleDumper.represent_binary(None, b'\x00\x01\x02\x03')
    assert res == u'!!binary \x00\x01\x02\x03'

# Generated at 2022-06-23 05:36:09.631140
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template.template import AnsibleTemplate
    from ansible.playbook.play_context import PlayContext

    t = AnsibleTemplate(u"{{ test.value }}", PlayContext(become=False), loader=None)
    assert t.render({}) == u'None'

    t = AnsibleTemplate("{{ test.value }}", PlayContext(become=False), loader=None)
    assert t.render({}) == 'None'

    t = AnsibleTemplate("{{ test.value }}", PlayContext(become=False), loader=None)
    assert t.render({u'test': {}}) == u'None'

    t = AnsibleTemplate("{{ test.value }}", PlayContext(become=False), loader=None)
    assert t.render({'test': {}}) == 'None'

    t = Ans

# Generated at 2022-06-23 05:36:18.686298
# Unit test for function represent_hostvars
def test_represent_hostvars():

    class TestDumper(AnsibleDumper):
        pass

    # Test HostVars
    my_hostvars = HostVars({text_type('a'): {text_type('b'): text_type('c')}, text_type('d'): text_type('e')})

    assert TestDumper(indent=2).represent_data(my_hostvars) == "{a: {b: c}, d: e}\n"

    # Test HostVarsVars
    my_hostvarsvars = HostVarsVars(my_hostvars)

    assert TestDumper(indent=2).represent_data(my_hostvarsvars) == "{a: {b: c}, d: e}\n"

    # Test VarsWithSources
    my_vars_with_sources = Vars

# Generated at 2022-06-23 05:36:30.102645
# Unit test for function represent_undefined
def test_represent_undefined():
    class CustomDumper(AnsibleDumper):
        def __init__(self, *args, **kwargs):
            super(CustomDumper, self).__init__(*args, **kwargs)
            self.result = None

        def represent_undefined(self, data):
            self.result = super(CustomDumper, self).represent_undefined(data)
            return self.result

    # Test:
    # - The original represent_undefined from yaml.representer.SafeRepresenter is called
    dumper = CustomDumper(
        default_flow_style=False,
        default_style='"',
        indent=2,
        allow_unicode=True
    )
    data = AnsibleUndefined
    dumper.represent(data)
    assert dumper.result == yaml.representer.SafeRepresenter

# Generated at 2022-06-23 05:36:33.167186
# Unit test for function represent_binary
def test_represent_binary():
    a = AnsibleUnsafeBytes(b'\x01\x02\x03')
    assert AnsibleDumper.represent_binary(a) == "'\\x01\\x02\\x03'"

# Generated at 2022-06-23 05:36:36.130818
# Unit test for function represent_binary
def test_represent_binary():
    assert AnsibleDumper.represent_binary(b'foo\x00') == "!!binary |\n  Zm9vAA==\n"



# Generated at 2022-06-23 05:36:43.541985
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    output = yaml.dump(
        AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256', 'deadbeefdeadbeefdeadbeefdeadbeefdeadbeefdeadbeefdeadbeefdeadbeefdeadbeefdeadbeefdeadbeefdeadbeefdeadbeefdeadbeefdeadbeefdeadbeefdeadbeef'),
        Dumper=AnsibleDumper,
        default_flow_style=True
    ).strip()

    assert '$ANSIBLE_VAULT;1.1;AES256' in output

# Generated at 2022-06-23 05:36:48.429061
# Unit test for function represent_binary
def test_represent_binary():

    yaml.add_representer(bytes, represent_binary, Dumper=AnsibleDumper)
    string = 'hello world'
    b_string = string.encode('utf-8')
    yaml.dump(b_string, Dumper=AnsibleDumper)

# Generated at 2022-06-23 05:36:51.254142
# Unit test for function represent_unicode
def test_represent_unicode():
    datum = u'foobar baz'
    assert represent_unicode(AnsibleDumper, datum) == 'foobar baz\n...\n'



# Generated at 2022-06-23 05:36:52.642493
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    a = AnsibleDumper(width=1000)
    assert a.default_flow_style is False

# Generated at 2022-06-23 05:36:54.351159
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper(width=80)
    assert dumper.width == 80



# Generated at 2022-06-23 05:36:56.528552
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():

    assert isinstance(AnsibleDumper(), AnsibleDumper)

# Generated at 2022-06-23 05:36:57.243550
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper

# Generated at 2022-06-23 05:36:58.290650
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    ad = AnsibleDumper



# Generated at 2022-06-23 05:37:08.824347
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()
    encrypted_unicode_string = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\r\n383437636433303439346237636233653666656563366333316232376339396437376531643434\r\n653964623663376539663733623032613037623232616233386239313331323863663762613262\r\n333735366636643737623835646231636339316335643338656133613262663339636366393534\r\n6466623230393162366363633962313762356479313833393538666439\r\n')

# Generated at 2022-06-23 05:37:13.848752
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    undefined = AnsibleUndefined()
    if undefined:
        try:
            dumper.represent_undefined(dumper, undefined)
        except yaml.representer.RepresenterError:
            pass
        else:
            assert False, "Exception not raised"

# Generated at 2022-06-23 05:37:18.086121
# Unit test for function represent_hostvars
def test_represent_hostvars():
    question = dict(q='How much wood would a woodchuck chuck ?')
    answer = HostVars(question)
    assert yaml.dump(answer, Dumper=AnsibleDumper) == yaml.dump(question, Dumper=AnsibleDumper), "represent_hostvars error"

# Generated at 2022-06-23 05:37:21.339503
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = {"test_var": "test_value"}
    result = yaml.dump(HostVars(data), Dumper=AnsibleDumper)
    assert "test_var: test_value" in result



# Generated at 2022-06-23 05:37:23.928553
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    print(dumper.represent_hostvars({'k1': 'v1'}))



# Generated at 2022-06-23 05:37:33.189941
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    ansible_binary_string = '\x00\x01\x02'
    binary_yaml = dumper.represent_binary(ansible_binary_string)

    # Ensure the output is a string
    assert isinstance(binary_yaml, text_type)

    # Ensure the output starts with !!binary
    assert binary_yaml.startswith(u'!!binary')

    # Ensure the output ends with a newline
    assert binary_yaml.endswith(u'\n')

    # Ensure the output has a newline at the 78th column
    assert u'\n' in binary_yaml[78:]

# Generated at 2022-06-23 05:37:41.113767
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # Basicaly we want to test represent_dict response, so we're going to
    # use a dict as an argument.
    arg = {"test": "test"}

    # This is the response we're expecting.
    expect = "!<ansible.vars.hostvars.HostVars object> {'test': 'test'}"

    # This is what we actually get.
    got = represent_hostvars(AnsibleDumper, arg)

    # Are the results what we expect?
    assert expect == got

# Generated at 2022-06-23 05:37:44.259245
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper
    assert dumper.represent_hostvars(dumper, {"k": "v"}) == dumper.represent_dict({"k": "v"})


# Generated at 2022-06-23 05:37:53.813953
# Unit test for function represent_undefined
def test_represent_undefined():
    assert represent_undefined(AnsibleDumper, AnsibleUndefined()) is False
    assert represent_undefined(AnsibleDumper, text_type("test")) is True
    assert represent_undefined(AnsibleDumper, None) is True

# These specific classes are now deprecated, but some users
# may still be using them.
try:
    from ansible.vars import IncludeVars
    AnsibleDumper.add_representer(
        IncludeVars,
        represent_hostvars,
    )
except ImportError:
    pass

try:
    from ansible.vars import GroupVars
    AnsibleDumper.add_representer(
        GroupVars,
        represent_hostvars,
    )
except ImportError:
    pass

# Generated at 2022-06-23 05:38:04.206302
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert('!binary |\n  ' + (u'fÃoo\n').encode('utf-8').hex() == dumper.represent_binary(u'fÃoo'.encode('utf-8')))
    assert('!binary |\n  ' + (u'fÃoo\n').encode('latin-1').hex() == dumper.represent_binary(u'fÃoo'.encode('latin-1')))
    assert('!binary |\n  ' + (u'fÃoo\n').encode('ascii').hex() == dumper.represent_binary(u'fÃoo'.encode('ascii')))

# Generated at 2022-06-23 05:38:10.511843
# Unit test for function represent_hostvars
def test_represent_hostvars():

    data = {'key1': 'value1', 'key2': 'value2'}

    # Create a Class instance of HostVars
    obj = HostVars(data)

    # Create a instance of AnsibleDumper
    dump = AnsibleDumper()

    # Check the output of represent_hostvars
    output = dump.represent_hostvars(obj)
    assert output == {'key1': 'value1', 'key2': 'value2'}



# Generated at 2022-06-23 05:38:14.823272
# Unit test for function represent_binary
def test_represent_binary():
    """
    Unit test for function represent_binary
    """
    dumper = AnsibleDumper
    data = b'abc'
    output = dumper.represent_binary(dumper, data)
    assert output == u'!!binary |\n  YWJj'

# Generated at 2022-06-23 05:38:19.967591
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper(width=80, default_style='', default_flow_style=False)
    result = dumper.represent_binary(b'\xaa\xbb\xcc')
    assert result == "!!binary |-\n  qqz2q3q1qw==\n"



# Generated at 2022-06-23 05:38:23.855310
# Unit test for function represent_unicode
def test_represent_unicode():
    yaml_text = yaml.dump(dict(a=u'b'), Dumper=AnsibleDumper, default_flow_style=None)
    assert yaml_text == u'a: b\n'



# Generated at 2022-06-23 05:38:25.585026
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper().represent_data(AnsibleUndefined()) is False

# Generated at 2022-06-23 05:38:28.658196
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(b'abc', Dumper=AnsibleDumper, default_flow_style=False) == u'!binary |\n  YWJj\n'

# Generated at 2022-06-23 05:38:34.171618
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper
    assert dumper.represent_hostvars == represent_hostvars
    # Note: only want to represent the encrypted data
    assert dumper.represent_vault_encrypted_unicode == represent_vault_encrypted_unicode
    assert dumper.represent_unicode == represent_unicode
    assert dumper.represent_binary == represent_binary
    assert dumper.represent_undefined == represent_undefined

# Generated at 2022-06-23 05:38:40.291042
# Unit test for function represent_binary
def test_represent_binary():
    # create a dumper
    dumper = AnsibleDumper(stream=None, default_flow_style=False, indent=4, allow_unicode=True)

    # create the object for 'binary', with random value
    binary = b'\x10\x00\x00\x00\x15\x00\x00\x00\x18\x00\x00\x00\x1b\x00\x00\x00'

    assert dumper.represent_binary(binary) == u"!!binary |\n" \
        + u"  GAAAAAAAAA==\n"

# Generated at 2022-06-23 05:38:48.397565
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

# Generated at 2022-06-23 05:38:50.501346
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dmp = AnsibleDumper()

if __name__ == "__main__":
    test_AnsibleDumper()

# Generated at 2022-06-23 05:38:59.671809
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()
    data = AnsibleVaultEncryptedUnicode(unicode('haha'))
    assert(dumper.represent_scalar(u'!vault', data._ciphertext.decode(), style='|') == '!vault |\n          ZmFsc2UgWmZkV2lSc25OaVpIT0pDZyA0ejBuYXh5SXR5N1Fz\n          Qld4c3d4N1h2a2NyMjl0dHFlZ3U1Z2J6ejU3ZWFoV0RUdW1Uc1\n          lkcVVnTWpkTUZubG05ZldQMVVHND0=\n          ')


#

# Generated at 2022-06-23 05:39:04.606947
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    """
    Unit test for function `represent_vault_encrypted_unicode`
    """
    assert AnsibleDumper.represent_vault_encrypted_unicode(AnsibleDumper(), 'test') == '!vault |\n  test'

# Generated at 2022-06-23 05:39:07.494175
# Unit test for function represent_undefined
def test_represent_undefined():
    d = AnsibleDumper(width=100)
    undefined = AnsibleUndefined()
    dumped = yaml.dump(undefined, Dumper=d)
    assert dumped == 'null'


# Generated at 2022-06-23 05:39:19.141228
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():

    # Configure the VaultEncryptedUnicode and a test string
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultEditor

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    password = "hunter2"
    test_string = "MY_STRING_VALUE"

    # Encrypt the test string with the password
    vault = VaultLib([])
    vault_secret = VaultSecret(password)
    result = vault.encrypt(test_string, vault_secret)

    # Create the AnsibleVaultEncryptedUnicode object with the encrypted key
    data = AnsibleVaultEncryptedUnicode("dev1", result)

    # Use the custom Ansible

# Generated at 2022-06-23 05:39:31.332691
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    data = vault.encrypt(u'password')

# Generated at 2022-06-23 05:39:34.867689
# Unit test for function represent_unicode
def test_represent_unicode():
    data = AnsibleUnicode('abc')
    dumper = AnsibleDumper
    result = represent_unicode(dumper, data)
    assert result == u'abc'
    assert isinstance(result, text_type)

# Generated at 2022-06-23 05:39:40.281327
# Unit test for function represent_undefined
def test_represent_undefined():
    '''Make sure the AnsibleUndefined object is not written to yaml'''

    def assert_undefined(undef):
        dumper = AnsibleDumper(None)
        dumper.represent_data(undef)
        assert not dumper.output

    undef = AnsibleUndefined("undefined value")
    assert_undefined(undef)
    assert_undefined(undef())



# Generated at 2022-06-23 05:39:43.863863
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.representer.SafeRepresenter.represent_binary(AnsibleDumper, b'hello') == u'!!binary |\n' \
                                                                                           u'  aGVsbG8=\n'



# Generated at 2022-06-23 05:39:45.887797
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.serialize(b'foo', Dumper=AnsibleDumper) == "!!binary 'Zm9v'\n"



# Generated at 2022-06-23 05:39:53.672159
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    import os


# Generated at 2022-06-23 05:39:58.950155
# Unit test for function represent_undefined
def test_represent_undefined():
    # Introduce a variable which is undefined and test to make sure
    # we get the error we expect
    d = yaml.dump({'foo': AnsibleUndefined()}, Dumper=AnsibleDumper)
    assert False
    # Expected to fail with AnsibleUndefinedError
    # msg = "'dict object' has no attribute 'foo'"
    # assert str(e.value) == msg

# Generated at 2022-06-23 05:40:02.217208
# Unit test for function represent_undefined
def test_represent_undefined():
    yaml.dump_all([AnsibleUndefined(fail_on_undefined=True)], Dumper=AnsibleDumper)
    # no exception implies success

# Generated at 2022-06-23 05:40:14.124128
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert "#!yaml |\n#rules: all\n" == yaml.dump({'rules': {'all' : None}}, Dumper=AnsibleDumper, default_flow_style=False)
    assert "#!yaml |\n#rules:\n#  all:\n" == yaml.dump({'rules': {'all' : {}}}, Dumper=AnsibleDumper, default_flow_style=False)
    assert "#!yaml |\n#rules:\n#  all:\n" == yaml.dump({'rules': {'all' : { 'all' : None}}}, Dumper=AnsibleDumper, default_flow_style=False)

# Generated at 2022-06-23 05:40:24.104928
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    d = AnsibleDumper()
    assert isinstance(d.safe_represent_dict, yaml.representer.SafeRepresenter.represent_dict)
    assert isinstance(d.safe_represent_list, yaml.representer.SafeRepresenter.represent_list)
    assert isinstance(d.safe_represent_str, yaml.representer.SafeRepresenter.represent_str)
    assert isinstance(d.safe_represent_unicode, yaml.representer.SafeRepresenter.represent_unicode)
    assert isinstance(d.represent_hostvars, represent_hostvars)
    assert isinstance(d.represent_vault_encrypted_unicode, represent_vault_encrypted_unicode)
    assert isinstance(d.represent_unicode, represent_unicode)

# Generated at 2022-06-23 05:40:34.648346
# Unit test for function represent_binary
def test_represent_binary():
    # Create a string with a non-ascii character
    non_ascii_string = "abc\u1234def"
    # Create a string with an ascii character which is unsafe in YAML 1.1 but
    # safe in YAML 1.2 (which is what we are using)
    unsafe_string = "abc\x19def"
    # Create a string with a non-ascii character followed by an unsafe
    # character
    non_ascii_unsafe_string = "\u1234\x19"
    # Create a string with a null byte
    null_string = "abc\0def"
    # Create a string with a single backslash
    backslash_string = "\\"

# Generated at 2022-06-23 05:40:44.038777
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper, type)
    ad = AnsibleDumper()
    assert isinstance(ad.ignore_aliases, yaml.dumper.SafeDumper.ignore_aliases.__class__)
    assert isinstance(ad.sort_keys, yaml.dumper.SafeDumper.sort_keys.__class__)
    assert ad.anchor_templates is False
    assert ad.allow_unicode is True
    assert ad.default_flow_style is True
    assert ad.encoding is None
    assert ad.explicit_start is False
    assert ad.explicit_end is False
    assert ad.explicit_resolver is None
    assert ad.indent is 2
    assert ad.version is None
    assert ad.width is 80
    assert ad.top_level_colon_

# Generated at 2022-06-23 05:40:55.025813
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    stream = open("AnsibleDumper.yaml", "w")
    dumper = yaml.Dumper(stream, default_flow_style=False)
    dumper.add_representer(
        AnsibleUnicode,
        represent_unicode,
    )
    dumper.add_representer(
        HostVars,
        represent_hostvars,
    )
    dumper.add_representer(
        AnsibleSequence,
        yaml.representer.SafeRepresenter.represent_list,
    )
    dumper.add_representer(
        AnsibleMapping,
        yaml.representer.SafeRepresenter.represent_dict,
    )

# Generated at 2022-06-23 05:40:59.489799
# Unit test for function represent_hostvars
def test_represent_hostvars():

    hostvars = HostVars()
    hostvars.set_variable('foo', 'bar')
    hostvars.set_variable('baz', 'buz')

    output = yaml.dump(hostvars, Dumper=AnsibleDumper)

    assert output == "{foo: bar, baz: buz}\n"

# Generated at 2022-06-23 05:41:10.314390
# Unit test for function represent_undefined
def test_represent_undefined():
    yaml.representer.SafeRepresenter.add_representer(
        AnsibleUndefined,
        represent_undefined
    )

    assert yaml.dump(AnsibleUndefined(), default_flow_style=False)


# reference the dumper globally
yaml.add_representer(
    AnsibleUnicode,
    represent_unicode,
    Dumper=AnsibleDumper
)

yaml.add_representer(
    AnsibleUnsafeText,
    represent_unicode,
    Dumper=AnsibleDumper
)

yaml.add_representer(
    AnsibleUnsafeBytes,
    represent_binary,
    Dumper=AnsibleDumper
)


# Generated at 2022-06-23 05:41:11.951962
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, AnsibleUnicode("test")) == "'test'"

# Generated at 2022-06-23 05:41:16.046443
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    dumper.ignore_aliases = lambda *args: True
    from ansible.template.jinja2.debug import AnsibleUndefined
    assert dumper.represent_data(AnsibleUndefined()) == 'null\n...\n'

# Generated at 2022-06-23 05:41:18.452903
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined())



# Generated at 2022-06-23 05:41:21.156019
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper(None)
    undefined_obj = AnsibleUndefined()
    assert(bool(dumper.represent_undefined(undefined_obj)))

# Generated at 2022-06-23 05:41:29.307199
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper.add_representer, object)
    assert isinstance(AnsibleDumper.represent_data, object)
    assert isinstance(AnsibleDumper.represent_dict, object)
    assert isinstance(AnsibleDumper.represent_float, object)
    assert isinstance(AnsibleDumper.represent_int, object)
    assert isinstance(AnsibleDumper.represent_list, object)
    assert isinstance(AnsibleDumper.represent_long, object)
    assert isinstance(AnsibleDumper.represent_none, object)
    assert isinstance(AnsibleDumper.represent_scalar, object)
    assert isinstance(AnsibleDumper.represent_str, object)

# Generated at 2022-06-23 05:41:35.417717
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(u"a string", Dumper=AnsibleDumper) == 'a string\n...\n'
    assert yaml.dump(u"üñîçø∂é string", Dumper=AnsibleDumper) == 'üñîçø∂é string\n...\n'
    assert yaml.dump(u"\u00fc\u00f1\u00ee\u00e7\u00f8\u2202\u00e9 string", Dumper=AnsibleDumper) == 'üñîçø∂é string\n...\n'



# Generated at 2022-06-23 05:41:45.944585
# Unit test for function represent_undefined
def test_represent_undefined():
    class MyUndefined1(AnsibleUndefined):
        pass

    class MyUndefined2(AnsibleUndefined):
        def __bool__(self):
            return False

    if yaml.__with_libyaml__:
        class MyUndefined3(AnsibleUndefined):
            def __bool__(self):
                raise TypeError

        class MyUndefined4(AnsibleUndefined):
            def __bool__(self):
                raise ValueError

    dumper = yaml.Dumper()
    dumper.add_representer(AnsibleUndefined, represent_undefined)

    # With __bool__ not implemented
    u1 = MyUndefined1()
    try:
        yaml.dump(u1, dumper)
    except AnsibleUndefined:
        pass

# Generated at 2022-06-23 05:41:49.858434
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = HostVars(vars=None)
    assert yaml.dump(hostvars, Dumper=AnsibleDumper) == "--- {}\n"

# Generated at 2022-06-23 05:41:58.098927
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\n3239353536663730333930623135663333303733383537323338653961343265313063343065656334\n386638366231633831366463653533316262386438303534300a613763323761656331626438663935\n3261656232353565393430353162353863303330373134323164323032653561303238336562386166\n626539373635333637310a')