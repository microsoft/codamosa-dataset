

# Generated at 2022-06-23 05:31:56.898285
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    ad = AnsibleDumper()
    assert ad is not None



# Generated at 2022-06-23 05:31:59.078651
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == "!!python/unicode 'foo'\n"



# Generated at 2022-06-23 05:31:59.895086
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper is not None

# Generated at 2022-06-23 05:32:07.067461
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper(None)
    # If we have a bool but undefined data,
    # bool will be false and code will go inside _fail_with_undefined_error.
    # But if bool is true, the function will return a scalar representing bool.
    # This is because __bool__ is set on StrictUndefined in Jinja2
    # which returns False if there is Undefined data.
    # This was done as part of https://github.com/python/cpython/pull/4666
    for val in [True, False]:
        dumper.represent_undefined(val)

# Generated at 2022-06-23 05:32:12.502157
# Unit test for function represent_hostvars
def test_represent_hostvars():
    class Dummy(HostVars):
        _fact_cache = dict(test=dict(test=dict(test='test')))

    data = Dummy(dict(test='test'), dict(test='test'))
    assert yaml.dump(data, Dumper=AnsibleDumper) == '{test: test}'



# Generated at 2022-06-23 05:32:14.866897
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dump = AnsibleDumper().represent_hostvars(HostVars(dict()))
    assert list(dump)[0][0] == '{'

# Generated at 2022-06-23 05:32:25.552443
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

# Generated at 2022-06-23 05:32:31.272724
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hv = HostVars()
    hv_vars = HostVarsVars()
    hv_vars.update({'extravars': "Won't represent this"})
    hv.update({'vars': hv_vars})
    assert yaml.dump(hv) == "vars:\n"


# Generated at 2022-06-23 05:32:32.357084
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper(None)



# Generated at 2022-06-23 05:32:42.805267
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    text = vault.encrypt(b'plaintext')
    encrypted_obj = AnsibleVaultEncryptedUnicode(text, vault)
    dumped = yaml.dump([encrypted_obj], Dumper=AnsibleDumper)

# Generated at 2022-06-23 05:32:52.682808
# Unit test for function represent_binary
def test_represent_binary():
    # Test some binary data
    binary = b'\x00\x01\x02\x03\x04'
    if not yaml.__with_libyaml__:
        assert binary_type(AnsibleDumper.represent_binary(AnsibleDumper(), binary)) == b'!!binary |-\n  AAECAwQ=\n'
    else:
        assert binary_type(AnsibleDumper.represent_binary(AnsibleDumper(), binary)) == b'!!binary "AAECAwQ="\n'

    # Test some regular string data
    string = 'foo'
    assert binary_type(AnsibleDumper.represent_binary(AnsibleDumper(), string)) == b'"foo"\n'

# Generated at 2022-06-23 05:33:02.783433
# Unit test for function represent_unicode
def test_represent_unicode():
    '''
    ansible.parsing.yaml.dumper.represent_unicode tests
    :return: nothing, asserts are in the test
    '''

    test_str = u"test_str"
    test_unicode = u"test_unicode"
    test_unicode_mixed = u"test_unicode_mixed \u2694"
    test_unsafe = u"test_unsafe"

    assert isinstance(test_str, text_type)
    assert isinstance(test_unicode, text_type)
    assert isinstance(test_unicode_mixed, text_type)
    assert isinstance(test_unsafe, text_type)

    # Test that ascii-only unicode string is dumped as plain string
    # for backward compatibility

# Generated at 2022-06-23 05:33:11.606439
# Unit test for function represent_unicode
def test_represent_unicode():

    class AnsibleDumperStub(AnsibleDumper):
        '''
            A simple stub class that allows us to add representers
            for our overridden object types.
        '''

    dumper = AnsibleDumperStub()
    value = u'\u20ac'

    # AnsibleUnicode
    represented_unicode = represent_unicode(dumper, value)
    assert represented_unicode == dumper.represent_str(value)

    # AnsibleUnsafeText
    represented_unsafe_text = represent_unicode(dumper, text_type(value))
    assert represented_unsafe_text == dumper.represent_str(value)

# Generated at 2022-06-23 05:33:20.252340
# Unit test for function represent_unicode
def test_represent_unicode():
    # Tests for py2 only. In py3, above function is no op.
    import sys
    if sys.version_info[0] >= 3:
        return

    class Dumper(yaml.Dumper):
        pass

    yaml.add_representer(
        text_type,
        represent_unicode,
        Dumper=Dumper,
        Resolver=yaml.resolver.BaseResolver
    )

    yaml.add_representer(
        binary_type,
        yaml.representer.SafeRepresenter.represent_unicode,  # use this instead of represent_str to select appropriate style tag
        Dumper=Dumper,
        Resolver=yaml.resolver.BaseResolver
    )

    # assume nothing is tagged, in which case represent_str is used

# Generated at 2022-06-23 05:33:22.143461
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert len(AnsibleDumper.yaml_representers) == 8

# Generated at 2022-06-23 05:33:28.771203
# Unit test for function represent_hostvars
def test_represent_hostvars():
    test_object = HostVars(FakeVarsObject())

    # Simply instantiating the dumper is enough to cause ansible-specific
    # representers to be registered.
    dumper = AnsibleDumper
    test_value = dumper.represent_data(test_object)
    assert test_value == u"{foo: bar, bam: {one: 1, two: 2}}\n...\n"

# Generated at 2022-06-23 05:33:34.415168
# Unit test for function represent_undefined
def test_represent_undefined():
    b = AnsibleUndefined
    d = AnsibleDumper.represent_undefined(AnsibleDumper, b)
    assert d == True
    assert b._fail_with_undefined_error is True
    d = AnsibleDumper.represent_undefined(AnsibleDumper, b)
    assert d == ""
    assert b._fail_with_undefined_error is False

# Generated at 2022-06-23 05:33:46.041849
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()
    ciphertext = '$ANSIBLE_VAULT;1.1;AES256\n32303233636563363430393764353766383031613739313035303366373061396138313765323835\n39303966396332366362316432333766323935643438653839653366616636303566336337636231\n663335366463386329\n'
    aveu = AnsibleVaultEncryptedUnicode(ciphertext)

    serialized = dumper.represent_vault_encrypted_unicode(aveu)

# Generated at 2022-06-23 05:33:50.073403
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    result = dumper.represent_binary(dumper, b'a simple binary string')
    assert result == u"!binary |\n  YSBzaW1wbGUgYmluYXJ5IHN0cmluZw\n"



# Generated at 2022-06-23 05:33:53.580788
# Unit test for function represent_undefined
def test_represent_undefined():
    stream = AnsibleDumper().represent_undefined(AnsibleUndefined('Undefined'))
    assert stream.tag == 'tag:yaml.org,2002:bool'
    assert stream.value is False



# Generated at 2022-06-23 05:33:56.906833
# Unit test for function represent_undefined
def test_represent_undefined():
    def undef_to_bool(undef):
        return bool(undef)

    assert undef_to_bool(AnsibleUndefined()) is False

# Generated at 2022-06-23 05:34:04.515273
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper(indent=0)

    out = yaml.dump(AnsibleUndefined(), stream=None, Dumper=dumper,
                    allow_unicode=True, default_flow_style=False)

    assert out == u'true\n'

# Generated at 2022-06-23 05:34:13.895256
# Unit test for function represent_unicode
def test_represent_unicode():
    import sys
    import ansible.utils.unsafe_proxy as unsafe_proxy
    import ansible.utils.unsafe_proxy as unsafe_proxy

    # AnsibleUnsafeText is a subclass of AnsibleUnicode
    assert unsafe_proxy.AnsibleUnsafeText("ansible") is not unsafe_proxy.AnsibleUnicode("ansible")

    # Use 'AnsibleDumper.represent_unicode' to dump AnsibleUnicode
    ansible_unicode = unsafe_proxy.AnsibleUnicode("ansible")
    assert yaml.dump(ansible_unicode, Dumper=AnsibleDumper) == 'ansible\n...\n'

    # Use 'AnsibleDumper.represent_unicode' to dump AnsibleUnsafeText
    ansible_unsafe_text = unsafe_proxy

# Generated at 2022-06-23 05:34:18.389059
# Unit test for function represent_undefined
def test_represent_undefined():
    assert not represent_undefined(AnsibleDumper, AnsibleUndefined())
    try:
        represent_undefined(AnsibleDumper, AnsibleUndefined(fail_on_undefined=True))
    except AnsibleUndefined as e:
        assert str(e) == 'AnsibleUndefined'

# Generated at 2022-06-23 05:34:23.912460
# Unit test for function represent_binary
def test_represent_binary():
    temp_dumper = AnsibleDumper
    data = b'This\x00is\x00a\x00test'
    temp_dumper.add_multi_representer(binary_type, lambda dumper, value: dumper.represent_binary(data))
    result = temp_dumper.represent_binary(data)
    assert data == result



# Generated at 2022-06-23 05:34:31.627038
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper
    d = HostVars("myhost")
    d["foo"] = "bar"
    d["fuu"] = "baz"
    data = dict(d)
    assert data == d
    assert dumper.represent_dict(data) == dumper.represent_dict(d)
    assert dumper.represent_scalar(u'tag:yaml.org,2002:map', d) == u'{foo: bar, fuu: baz}\n'

# Generated at 2022-06-23 05:34:44.002371
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # arrange
    yaml_object = AnsibleVaultEncryptedUnicode('test_password', b'!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          643865346138663564613865643933656437383964363531356439306664653633313235303564\n          646362316134383633396261623232646563633139356631633730633936326137613563343234\n          393738646262653235326434306633\n          ')

# Generated at 2022-06-23 05:34:49.864749
# Unit test for function represent_binary
def test_represent_binary():
    test_str = b'\x80\x01'
    expected_str = '!!binary |\n' \
                   '  gICAgAQ=='

    yaml_obj = AnsibleDumper().represent_binary(test_str)
    assert isinstance(yaml_obj, text_type)
    assert yaml_obj == expected_str



# Generated at 2022-06-23 05:34:56.917684
# Unit test for function represent_unicode
def test_represent_unicode():
    '''represent_unicode should handle a variety of inputs'''
    import yaml
    yaml.dump({'tagg': 'tagg'}, Dumper=AnsibleDumper)
    yaml.dump_unicode({'tagg': 'tagg'}, Dumper=AnsibleDumper)
    yaml.dump({'tagg': u'tagg'}, Dumper=AnsibleDumper)
    yaml.dump_unicode({'tagg': u'tagg'}, Dumper=AnsibleDumper)



# Generated at 2022-06-23 05:35:00.889486
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()
    val = AnsibleVaultEncryptedUnicode('42')
    assert dumper.represent_data(val) == '!vault |\n  NDI0\n'
    assert dumper.represent_data(val).startswith('!vault')

# Generated at 2022-06-23 05:35:06.208697
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import AnsibleUndefined

    s = AnsibleUnsafeText('string')
    l = [s]

    u = AnsibleUndefined()
    l.append(u)

    o = AnsibleUnsafeText(yaml.dump(l, Dumper=AnsibleDumper))
    assert o == '[\'string\', !!python/object/apply:ansible.template.AnsibleUndefined []\n]'
    assert l == [s, u]

# Generated at 2022-06-23 05:35:08.580068
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hv = yaml.load("""{"foo": "bar"}""")
    assert hv == HostVars(foo='bar')



# Generated at 2022-06-23 05:35:11.527337
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.safe_dump(text_type("Hello World"), default_flow_style=False) == u'Hello World\n...\n'



# Generated at 2022-06-23 05:35:13.938139
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    result = dumper.represent_binary(dumper, b"Blah")
    assert result == (u'!!binary ', b'Blah')



# Generated at 2022-06-23 05:35:14.697500
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    AnsibleDumper()

# Generated at 2022-06-23 05:35:17.577276
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper, type)
    assert issubclass(AnsibleDumper, yaml.dumper.SafeDumper)

# Generated at 2022-06-23 05:35:30.410421
# Unit test for function represent_binary
def test_represent_binary():
    import types
    assert isinstance('1', text_type)
    assert isinstance(1, int)
    assert isinstance(True, int)
    assert not isinstance(True, bool)
    assert isinstance(True, types.BooleanType)
    assert isinstance(1, types.IntType)
    assert isinstance(1, types.BooleanType)  # Integer is a subclass of boolean
    assert not isinstance(1, types.FloatType)
    assert not isinstance(1.0, types.FloatType)
    assert isinstance(1.0, types.FloatType)
    assert isinstance(b'1', binary_type)
    assert not isinstance(b'1', text_type)
    assert not isinstance(u'1', binary_type)
    assert not isinstance(u'1', text_type)

# Generated at 2022-06-23 05:35:40.986753
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    vault_secret = 'ansible'
    vault_key = 'testdata/ansible-vault.key'
    vault_password_file = 'testdata/ansible-vault-password.txt'
    vault_password = loader.get_vault_password(vault_password_file=vault_password_file)

    def do_encrypt(v):
        v = VaultLib(vault_secret)
        if vault_password is None:
            vault_password = v.decrypt(vault_key)

        v = VaultLib(vault_secret, vault_password)
        return v.encrypt(v)


# Generated at 2022-06-23 05:35:52.636757
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper.yaml_representers == {}

    # Newrepresenter is added to AnsibleDumper.yaml_representers
    AnsibleDumper.add_representer(
        AnsibleUnicode,
        represent_unicode,
    )

    # New representer is added to AnsibleDumper.yaml_representers
    AnsibleDumper.add_representer(
        HostVars,
        represent_hostvars,
    )

    assert list(AnsibleDumper.yaml_representers.keys()) == [AnsibleUnicode, HostVars]
    assert AnsibleDumper.yaml_representers[AnsibleUnicode] == represent_unicode
    assert AnsibleDumper.yaml_representers[HostVars] == represent_hostvars

# Generated at 2022-06-23 05:36:03.892849
# Unit test for function represent_hostvars
def test_represent_hostvars():
    test_ansible_dumper = AnsibleDumper()
    test_data = AnsibleUnicode('test_data')
    test_dict_data = HostVars({test_data: test_data})
    test_result = test_ansible_dumper.represent_hostvars(test_dict_data)
    expected_result = test_ansible_dumper.represent_dict({text_type(test_data): test_data})
    assert test_result == expected_result

    test_unicode_data = AnsibleUnicode('test_data')
    test_dict_data = HostVars({test_unicode_data: test_unicode_data})
    test_result = test_ansible_dumper.represent_hostvars(test_dict_data)
    expected_result = test_ansible_d

# Generated at 2022-06-23 05:36:06.649269
# Unit test for function represent_undefined
def test_represent_undefined():
    yml = yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper)
    assert '::undefined' in yml



# Generated at 2022-06-23 05:36:16.356372
# Unit test for function represent_unicode
def test_represent_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    output = yaml.dump(u"\u043f\u0440\u0438\u0432\u0435\u0442", Dumper=AnsibleDumper)
    assert output == '--- \"привет\"\n'
    input = yaml.load(output, Loader=AnsibleLoader)
    assert isinstance(input, text_type)
    assert u"\u043f\u0440\u0438\u0432\u0435\u0442" == input



# Generated at 2022-06-23 05:36:20.716825
# Unit test for function represent_undefined
def test_represent_undefined():
    # use first item from list for testing
    dumper = AnsibleDumper([])
    data = AnsibleUndefined('test')

    # implicit convert to bool should happen,
    # which will invoke _fail_with_undefined_error
    assert dumper.represent_undefined(data)



# Generated at 2022-06-23 05:36:31.904078
# Unit test for function represent_undefined
def test_represent_undefined():
    '''
    Unit test for function represent_undefined
    '''
    from ansible.template import Undefined
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.parsing.yaml.loader import AnsibleLoader

    try:
        test_data = dict(a=Undefined, b=dict(c=wrap_var(Undefined), d=dict(e=Undefined)))
        # This will fail if represent_undefined is broken
        yaml.dump(test_data, Dumper=AnsibleDumper)
    except Exception as e:
        assert False, 'AnsibleDumper represent_undefined failed'


# Generated at 2022-06-23 05:36:39.192071
# Unit test for function represent_undefined
def test_represent_undefined():
    AnsibleDumper.add_representer(AnsibleUndefined, represent_undefined)

    def check_undefined_error(value):
        try:
            yaml.dump([value], Dumper=AnsibleDumper)
            raise AssertionError('should have failed with undefined error')
        except yaml.representer.RepresenterError as e:
            assert 'has no representer' in str(e)

    check_undefined_error(AnsibleUndefined())



# Generated at 2022-06-23 05:36:42.914050
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hv = HostVars({"var1": "value"})
    assert yaml.safe_dump(hv, default_flow_style=False) == '''\
{var1: value}
'''



# Generated at 2022-06-23 05:36:51.405059
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dh = AnsibleDumper()
    dh.represent_hostvars({'a': 8, 'b': 10, 'c': 12})
    s = b'{a: 8, b: 10, c: 12}\n'
    # Ideally we would test that s is an exact match of the output,
    # but we cannot due to potential differences in ordering of the keys
    # in a dict.

    # This test is an attempt to check whether the function is valid,
    # but it doesn't actually check that.

    assert s is not None



# Generated at 2022-06-23 05:36:52.447403
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dump = AnsibleDumper()
    assert type(dump) is AnsibleDumper

# Generated at 2022-06-23 05:36:54.827262
# Unit test for function represent_undefined
def test_represent_undefined():
    host_vars = AnsibleUndefined
    yaml.dump({'host_vars': host_vars}, Dumper=AnsibleDumper, default_flow_style=False)

# Generated at 2022-06-23 05:36:59.614695
# Unit test for function represent_undefined
def test_represent_undefined():
    yamldump = yaml.dump({'test1': 1, 'testundef': AnsibleUndefined()}, Dumper=AnsibleDumper, default_flow_style=False)
    assert yamldump == 'test1: 1\n'



# Generated at 2022-06-23 05:37:03.180081
# Unit test for function represent_unicode
def test_represent_unicode():
    u = u'\u1234'
    data = yaml.safe_load(yaml.dump(u, Dumper=AnsibleDumper))
    assert isinstance(data, text_type)



# Generated at 2022-06-23 05:37:04.509745
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    print(AnsibleDumper)

# Generated at 2022-06-23 05:37:11.165287
# Unit test for function represent_binary
def test_represent_binary():
    # yaml.representer.SafeRepresenter.represent_binary can't handle u'\u2026' in Python 2
    # Since '…' is valid unicode and we do use it in our tests. Force the test to UTF-8 since we
    # don't care about the value, just about escaping binary values.
    if str is unicode:
        return
    data = AnsibleUnsafeBytes(u'…')
    result = yaml.representer.SafeRepresenter.represent_binary(None, binary_type(data))
    assert result == '!binary |-\n  4oKs', str(result)


# Generated at 2022-06-23 05:37:15.697832
# Unit test for function represent_unicode
def test_represent_unicode():
    from ansible.module_utils.common.yaml import AnsibleUnicode
    obj = AnsibleUnicode('foo bar')
    assert yaml.dump(obj, Dumper=AnsibleDumper) == 'foo bar\n...\n'



# Generated at 2022-06-23 05:37:18.261850
# Unit test for function represent_hostvars
def test_represent_hostvars():
    h = HostVars({"foo": "bar"})
    assert yaml.dump(h, Dumper=AnsibleDumper) == "foo: bar\n"



# Generated at 2022-06-23 05:37:26.273600
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-23 05:37:31.523633
# Unit test for function represent_unicode
def test_represent_unicode():
    data = [
            u'{somevar}',
            u'€',
            u'월급',
            u'jaja---lol-méméméoo--a'
    ]

    for d in data:
        yield assertEqual, d, yaml.load(yaml.dump(d, Dumper=AnsibleDumper))

# Generated at 2022-06-23 05:37:39.840394
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper

    # Initializing an AnsibleUndefined object
    data = AnsibleUndefined()
    ret = dumper.represent_undefined(dumper, data)
    assert ret is not None
    assert isinstance(ret, bool)
    assert ret is False

    # Test the case where the object is not an AnsibleUndefined object
    data = 'foo'
    ret = dumper.represent_undefined(dumper, data)
    assert ret is None

# Generated at 2022-06-23 05:37:41.268090
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():

    dumper = AnsibleDumper()
    assert(dumper)



# Generated at 2022-06-23 05:37:45.096934
# Unit test for function represent_undefined
def test_represent_undefined():
    d = AnsibleDumper(default_flow_style=False)
    s = d.represent_undefined(AnsibleUndefined)
    assert s is False
    s = d.represent_undefined(AnsibleUndefined(1))
    assert s is False



# Generated at 2022-06-23 05:37:49.634686
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(AnsibleDumper.yaml_representers['tag:yaml.org,2002:str'], u'foo') == u'foo'



# Generated at 2022-06-23 05:37:52.108189
# Unit test for function represent_binary
def test_represent_binary():
    represent_binary(None, b"\xd2\x80\xa8\xa8\xf0\x90\x90\x80")



# Generated at 2022-06-23 05:38:03.626527
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-23 05:38:10.052968
# Unit test for function represent_hostvars
def test_represent_hostvars():

    dumper = AnsibleDumper
    assert dumper.represent_dict(dict(foo='bar')) == dumper.represent_dict({'foo': 'bar'})

    # assert that the representer is applied for any subclass of HostVars
    for c in (HostVars, HostVarsVars):
        assert dumper.represent_dict(dict(foo='bar')) == dumper.represent_data(c(dict(foo='bar')))



# Generated at 2022-06-23 05:38:17.662947
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = HostVars(dict(foo=1, bar=2, baz=3))
    assert data.foo == 1
    assert data.bar == 2
    assert data.baz == 3

    # Initialize the fake dumper and the result
    ansible_dumper = AnsibleDumper()
    ansible_result = ansible_dumper.represent_hostvars(data)

    # Initialize the comparison string
    compare_result = "{foo: 1, bar: 2, baz: 3}"

    # Perform the comparison
    assert ansible_result == compare_result


# Generated at 2022-06-23 05:38:29.669057
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dmp = AnsibleDumper()
    ct = '$ANSIBLE_VAULT;1.1;AES256\n35306633326632623334323130653664306132313262626336363834646630313066653233323930\n653861653561303130333836353665396439633565363933353931666365356130353830663261610a3365303937386233346237386463613962633236623564366663643566306438633064353336\n30323333613561316134666434313230646530376435393562333262636536363764333039646565\n'
    our_obj = AnsibleVaultEncryptedUn

# Generated at 2022-06-23 05:38:38.448031
# Unit test for function represent_undefined
def test_represent_undefined():
    import sys
    import pytest
    _loader = None
    if sys.version_info[0] >= 3 and sys.version_info[1] >= 4:
        # only works on python >= 3.4
        import importlib.machinery
        _loader = importlib.machinery.SourceFileLoader('test_yaml', '/tmp/test_yaml.py')
        from test_yaml import test_yaml

        def hook(mod):
            global test_yaml
            test_yaml = mod
            return test_yaml

        _loader.exec_module = hook
    else:
        # fallback for python < 3.4
        import imp
        _loader = imp.load_source('test_yaml', '/tmp/test_yaml.py')
        from test_yaml import test_yaml
   

# Generated at 2022-06-23 05:38:41.527550
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    opts = yaml.representer.SafeRepresenter.represent_dict
    obj = AnsibleDumper(opts)
    assert isinstance(obj, AnsibleDumper)

# Generated at 2022-06-23 05:38:44.663018
# Unit test for function represent_unicode
def test_represent_unicode():
    a = {'testval': AnsibleUnicode('testvalue')}
    s = yaml.dump(a, Dumper=AnsibleDumper)
    assert s == '{testval: testvalue}\n'

# Generated at 2022-06-23 05:38:51.209786
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert(AnsibleDumper.allow_unicode)
    assert(not AnsibleDumper.allow_unicode)
    assert(not AnsibleDumper.annotate_fields)
    assert(not AnsibleDumper.encoding)
    assert(not AnsibleDumper.indent)
    assert(not AnsibleDumper.line_break)
    assert(not AnsibleDumper.width)

# Generated at 2022-06-23 05:38:52.634749
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper.__name__ == 'AnsibleDumper'

# Generated at 2022-06-23 05:39:01.275114
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = "!vault |" + \
           "          $ANSIBLE_VAULT;1.1;AES256\n" + \
           "          35313162396532346461663132373836383330616230636637376339323036313830643161383664\n" + \
           "          6234633131363066610364393762633030393365613061653235340a613266633761366134613161\n" + \
           "          646233336465336639343032653831306361360a\n"

    # Create a string with leading and trailing whitespaces
    result = "!vault {data}".format(data = data)
    result = result.splitlines()
    result = "      " + "      ".join

# Generated at 2022-06-23 05:39:04.703923
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    result = dumper.represent_binary(b'foo')
    assert result == "!!binary 'Zm9v'\n"

# Generated at 2022-06-23 05:39:08.631808
# Unit test for function represent_unicode
def test_represent_unicode():
    # NOTE: using AnsibleUndefined to test the unicode with auto-conversion
    assert represent_unicode(AnsibleDumper, AnsibleUndefined('unicode value')) == 'unicode value'
    assert represent_unicode(AnsibleDumper, 'unicode value') == 'unicode value'



# Generated at 2022-06-23 05:39:20.220473
# Unit test for function represent_undefined
def test_represent_undefined():
    # Here bool will ensure _fail_with_undefined_error happens
    # if the value is Undefined.
    # This happens because Jinja sets __bool__ on StrictUndefined
    # and we need to test that Undefined returns the same result
    # as StrictUndefined for bool(Undefined)
    # See:
    #   https://github.com/pallets/jinja/blob/master/jinja2/environment.py#L837-L845
    #   https://github.com/pallets/jinja/blob/master/jinja2/environment.py#L954-L960

    undef = AnsibleUndefined('test')

    # For this test undef needs to be an instance of AnsibleUndefined
    # and not an instance of Undefined.
    # This ensures that the bool(undef

# Generated at 2022-06-23 05:39:32.635679
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-23 05:39:36.348316
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    result = dumper.represent_binary(b'this is a b\x00\x00\x00test')
    assert result == '!!binary |'
    assert isinstance(result, str)

# Generated at 2022-06-23 05:39:38.565576
# Unit test for function represent_undefined
def test_represent_undefined():
    representer = AnsibleDumper.represent_undefined
    expected = '&if-true\n'
    assert representer(representer, None) == expected

# Generated at 2022-06-23 05:39:41.222487
# Unit test for function represent_unicode
def test_represent_unicode():
    dump = AnsibleDumper()
    assert dump.represent_unicode(u'foobar') == "foobar"



# Generated at 2022-06-23 05:39:43.543409
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode(u'foo'), Dumper=AnsibleDumper) == 'foo\n...\n'

# Generated at 2022-06-23 05:39:45.928919
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump({
        'foo': 'bar'
    }, Dumper=AnsibleDumper) == '{foo: bar}\n...\n'



# Generated at 2022-06-23 05:39:53.700987
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    """Verify that data is encrypted"""

    test_data = u"test_data"
    secret = u"my_secret"
    secret_text = u"!vault |" + u"\n          " + yaml.dump(secret, Dumper=AnsibleDumper)
    data_text = u"!vault |"+ u"\n          " + yaml.dump(test_data, Dumper=AnsibleDumper)
    secret_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode(secret)
    data_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode(test_data)
    class AnsibleDumperMock:
        def represent_scalar(self, tag, value, style):
            return secret_text if value == secret else data_text

# Generated at 2022-06-23 05:40:02.715093
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Generate some encrypted data
    ciphertext = u'AEDpAyD33s1sDmzclrOGrQq3gT9F6cHU6NJkU47' \
                 u'+sIEszA8nNYkyCZ7IGndCDYX9+Dn8IfA6JybkEzFX' \
                 u'KdM0N7+ZYtJ2Vt1yy/0jDKV+NySm5Puw7F0oRmSVm' \
                 u'JHZ8b4l2q3a3hvkurdw'

    # Verify the output is as expected
    encrypted_data = AnsibleVaultEncryptedUnicode(ciphertext)

# Generated at 2022-06-23 05:40:06.303559
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert represent_hostvars(AnsibleDumper, {'a': 1, 'b': 2}) == '{a: 1, b: 2}\n'


# Generated at 2022-06-23 05:40:08.996311
# Unit test for function represent_undefined
def test_represent_undefined():
    try:
        bool(AnsibleUndefined)
    except TypeError:
        return

    assert False, "AnsibleUndefined is not defined as intended"

# Generated at 2022-06-23 05:40:17.322327
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = yaml.dumper.SafeDumper
    assert yaml.representer.SafeRepresenter.represent_str(dumper, u'hello') == u'hello\n...\n'
    dumper = AnsibleDumper
    assert AnsibleDumper.represent_unicode(dumper, u'hello') == u'hello\n...\n'
    assert AnsibleDumper.represent_unicode(dumper, u'hello') == yaml.representer.SafeRepresenter.represent_str(dumper, u'hello')

# Generated at 2022-06-23 05:40:24.464815
# Unit test for function represent_binary
def test_represent_binary():
    # Create a AnsibleDumper
    ad = AnsibleDumper()

    # Represent a string in Unicode
    a_string = 'This is a test'
    assert ad.represent_data(a_string) == "This is a test\n"

    # Represent a string in UTF-8
    a_string = u'This is another test'
    assert ad.represent_data(a_string) == "This is another test\n"

# Generated at 2022-06-23 05:40:29.545259
# Unit test for function represent_undefined
def test_represent_undefined():
    a = AnsibleUndefined('name')
    dumper = AnsibleDumper()
    dumper.add_representer(AnsibleUndefined, represent_undefined)
    dumper.represent_undefined(a)



# Generated at 2022-06-23 05:40:33.551153
# Unit test for function represent_hostvars
def test_represent_hostvars():
    """ Test that HostVars are properly rendered as a dict """
    hv = HostVars({"key": "value"})
    assert yaml.round_trip_dump(hv, default_flow_style=True) == "{key: value}\n"



# Generated at 2022-06-23 05:40:36.969191
# Unit test for function represent_unicode
def test_represent_unicode():
    dump = AnsibleDumper().represent_unicode("foo")
    assert dump.tag == 'tag:yaml.org,2002:str'
    assert dump.value == "foo"



# Generated at 2022-06-23 05:40:43.715864
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template.safe_eval import Undefined

    result = AnsibleDumper.represent_undefined(AnsibleDumper, Undefined(fail_on_undef=False))
    assert result is None

    # should throw an error
    try:
        AnsibleDumper.represent_undefined(AnsibleDumper, Undefined(fail_on_undef=True))
        assert False
    except UndefinedError:
        pass


# The following is a small program designed to create a
# full set of test cases for the to_text function.
#
# Put together like this for easy copy/pasting
#
# class Foo(unicode): pass
# class Bar(str): pass
# class Baz(object):
#     def __str__(self): return "str"
#     def __unicode__(self): return

# Generated at 2022-06-23 05:40:51.926917
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper(
        None,
        default_style=None,
        default_flow_style=None,
        canonical=None,
        indent=None,
        width=None,
        allow_unicode=None,
        line_break=None,
        encoding='utf-8',
        explicit_start=None,
        explicit_end=None,
        version=None,
        tags=None,
    )

# Generated at 2022-06-23 05:41:02.709765
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.module_utils.common.yaml import dump, dumps
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.template.safe_eval import safe_eval

    # If 'data' is a hostvars object and not a mapping, we will auto-convert it.
    data = HostVars(dict(foo='bar'))
    result = dump(data)
    assert result == 'foo: bar\n'

    # If 'data' is a hostvars object and not a mapping, we will auto-convert it.
    # But if the data is already a dict and 'from_yaml' set to true,
    # we will leave it as it is.

# Generated at 2022-06-23 05:41:05.703221
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.representer.SafeRepresenter.represent_binary(AnsibleDumper, "hello") == "!!binary \"aGVsbG8=\"\n"

# Generated at 2022-06-23 05:41:07.175187
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    obj = AnsibleVaultEncryptedUnicode(u'foo', u'bar')
    assert represent_vault_encrypted_unicode(None, obj) == u'!vault |\n          bar\n        '

# Generated at 2022-06-23 05:41:12.003481
# Unit test for function represent_unicode
def test_represent_unicode():
    obj = u'\u00f6'
    assert represent_unicode(None, obj) == yaml.representer.SafeRepresenter.represent_str(None, text_type(obj))
    obj = u'\u00f6'
    assert represent_unicode(None, obj) == yaml.representer.SafeRepresenter.represent_str(None, text_type(obj))


# Generated at 2022-06-23 05:41:14.421673
# Unit test for function represent_undefined
def test_represent_undefined():
    # represent_undefined should return bool(data)
    assert AnsibleDumper.represent_undefined(AnsibleDumper(), AnsibleUndefined()) == False

# Generated at 2022-06-23 05:41:15.902301
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    ad = AnsibleDumper()
    assert isinstance(ad, AnsibleDumper)

# Generated at 2022-06-23 05:41:19.632470
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined(fail_on_undefined=False)) is False
    assert dumper.represent_undefined(AnsibleUndefined(fail_on_undefined=True)) is False

# Generated at 2022-06-23 05:41:23.101188
# Unit test for function represent_undefined
def test_represent_undefined():
    data = AnsibleUndefined('test for represent_undefined')
    with pytest.raises(AssertionError) as exc:
        AnsibleDumper().represent_undefined(data)
    assert "test for represent_undefined" in str(exc.value)

# Generated at 2022-06-23 05:41:25.306202
# Unit test for function represent_undefined
def test_represent_undefined():
    obj = AnsibleUndefined()
    yaml.dump({'foo': obj}, Dumper=AnsibleDumper)

# Generated at 2022-06-23 05:41:32.955443
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = AnsibleVaultEncryptedUnicode(
        b'$ANSIBLE_VAULT;1.1;AES256\n61323339623030326534393837373465363336353065373631303230333232663230666535373733\n3736653466653461336161633862333362626230663864386635306461633463613535396366313334\n3530646237366439333564663732323066653266643335623461633461376363613661363133626530\n3464663735646635336362356334613933306466\n')

# Generated at 2022-06-23 05:41:43.599217
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    password = 'somepassword'
    data = AnsibleVaultEncryptedUnicode(
        text_type('''$ANSIBLE_VAULT;1.1;AES256
66623935653632643435376635623230393031346133383836333736643363333062393531326164
66353238633331666566663731633361326132620a36356636373937626564343539653337663938
63303236343863333937363538306637363830336339623561643266623163656439646336653163
30356138320a3635303365623335326230353139366261666330356566613064663965383'''))
    data._set_cipher_in_

# Generated at 2022-06-23 05:41:46.894735
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    yaml_text = represent_vault_encrypted_unicode(AnsibleDumper, AnsibleVaultEncryptedUnicode('123'))
    assert yaml_text == u"!vault |\n  MTIz\n"

# Generated at 2022-06-23 05:41:54.417834
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper()
    assert dumper.represent_hostvars(HostVars())
    assert dumper.represent_hostvars(HostVarsVars())
    assert dumper.represent_hostvars(VarsWithSources())
    assert dumper.represent_unicode(AnsibleUnicode('Hello', None))
    assert dumper.represent_unicode(AnsibleUnsafeText('Hello', None))
    assert dumper.represent_binary(AnsibleUnsafeBytes('Hello', None))

# Generated at 2022-06-23 05:42:03.782381
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

    # Generate sample data
    bytes = [92, 193, 112, 238]
    binary = b'\x5c\xc1p\xee'
    try:
        unicode = binary.decode()
    except (UnicodeDecodeError, UnicodeEncodeError):
        unicode = None

    # Test represent_binary
    output = dumper.represent_binary(binary)
    assert output == '!!binary |\n  ' + '\n  '.join('%02x' % b for b in bytes)

    # Test represent_binary with unicode=True
    output = dumper.represent_binary(binary, unicode=True)
    assert output == '!!binary |\n  ' + '\n  '.join('%02x' % b for b in bytes)

   