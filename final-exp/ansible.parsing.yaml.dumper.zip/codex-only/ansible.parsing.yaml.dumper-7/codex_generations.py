

# Generated at 2022-06-23 05:31:57.460710
# Unit test for function represent_undefined
def test_represent_undefined():
    yaml.Dumper.ignore_aliases = lambda *args: True
    data = yaml.dump(dict(foo="{{ undefined_variable }}"), Dumper=AnsibleDumper)
    # Python3: the str() call is required here
    assert str(data) == "foo: '{{ undefined_variable }}'\n"

# Generated at 2022-06-23 05:32:05.088019
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(text_type('foo')) == u'foo'
    assert dumper.represent_unicode(text_type('foo\n')) == u'|-\n  foo\n'
    assert dumper.represent_unicode(text_type('foo\nbar')) == u'|-\n  foo\n  bar'



# Generated at 2022-06-23 05:32:05.899106
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper

# Generated at 2022-06-23 05:32:10.437650
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper()
    assert dumper.ignore_aliases == True
    assert dumper.default_flow_style == False
    assert dumper.sort_keys == True

# Generated at 2022-06-23 05:32:16.132158
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper()

    # check initialized global dicts
    assert dumper.yaml_representers == yaml.representer.Representer.yaml_representers
    # check that representer for AnsibleVaultEncryptedUnicode was added
    assert AnsibleVaultEncryptedUnicode in dumper.yaml_representers.keys()
    assert represent_vault_encrypted_unicode in dumper.yaml_representers[AnsibleVaultEncryptedUnicode]


# Generated at 2022-06-23 05:32:19.450173
# Unit test for function represent_undefined
def test_represent_undefined():
    # This function only exists for code coverage
    # to run when using tox to run python3 coverage checks
    unsafe_proxy = AnsibleUnsafeText("should be caught")
    yaml.safe_dump(unsafe_proxy, Dumper=AnsibleDumper)



# Generated at 2022-06-23 05:32:28.711945
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    import sys
    if sys.version_info[0] >= 3 and sys.version_info[1] >= 4:
        import pytest
        # This tests that implicit_resolvers is not set
        # because our custom representers use '!!python/name'
        # type tags which will yield an error (cannot use type tag
        # when implicit_resolvers is set)
        with pytest.raises(yaml.constructor.ConstructorError):
            yaml.load('!!python/object:__main__.AnsibleUnicode', Loader=yaml.FullLoader)



# Generated at 2022-06-23 05:32:30.737604
# Unit test for function represent_undefined
def test_represent_undefined():
    test_data= AnsibleUndefined()
    dumper = AnsibleDumper()
    dumper.represent_data(test_data)

# Generated at 2022-06-23 05:32:35.182327
# Unit test for function represent_unicode
def test_represent_unicode():
    y = yaml.dump({'foo': AnsibleUnicode('bar')}, Dumper=AnsibleDumper)
    assert y == '{foo: bar}\n'



# Generated at 2022-06-23 05:32:40.778821
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = {'hostvars': {'host1': 'var1', 'host2': 'var2'}}
    dumper = AnsibleDumper
    result = dumper.represent_hostvars(dumper, data)
    expected = "{'host1': 'var1', 'host2': 'var2'}"
    assert ''.join(result.split()) == expected, "Expected %s got %s" % (expected, result)

# Generated at 2022-06-23 05:32:51.681243
# Unit test for function represent_binary
def test_represent_binary():
    data = AnsibleUnsafeBytes(b"\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f")

# Generated at 2022-06-23 05:32:53.901866
# Unit test for function represent_undefined
def test_represent_undefined():

    d = yaml.YAML().dump(AnsibleUndefined('undefined value'))
    assert d is None

# Generated at 2022-06-23 05:32:55.839296
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'hello') == u"!str hello"

# Generated at 2022-06-23 05:33:00.788591
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper(width=1000)

    host = HostVars(VarsWithSources({u'key1': u'value1', u'key2': u'value2'}, sources=None))
    assert host == yaml.load(dumper.represent_hostvars(host))

# Generated at 2022-06-23 05:33:11.693819
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():

    dumper = AnsibleDumper()

    assert dumper.tags['!vault'] == '!vault'
    assert dumper.allow_unicode
    assert dumper.default_style == '"'
    assert dumper.default_flow_style == False

    assert dumper.tags['!unsafe_text'] == 'tag:yaml.org,2002:str'
    assert dumper.tags['!unsafe_bytes'] == 'tag:yaml.org,2002:binary'

    assert not dumper.explicit_start
    assert not dumper.explicit_end
    assert dumper.version is None

# Generated at 2022-06-23 05:33:17.248378
# Unit test for function represent_undefined
def test_represent_undefined():
    def assert_raises(func, exception, message=None):
        try:
            func()
            assert False
        except Exception as e:
            assert type(e) == exception
            if message is not None:
                assert e.args[0] == message

    dumper = AnsibleDumper(explicit_start=True)
    assert_raises(lambda: dumper.represent_undefined(AnsibleUndefined()), yaml.representer.RepresenterError)



# Generated at 2022-06-23 05:33:20.716568
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    data = AnsibleUndefined("test")
    result = dumper.represent_undefined(dumper, data)
    assert result is True


# Generated at 2022-06-23 05:33:25.066229
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    constructor = AnsibleUnsafeBytes(b'foo')

    # test function return value
    assert dumper.represent_binary(constructor) == b'!!binary |\n  Zm9v\n'

# Generated at 2022-06-23 05:33:29.352050
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = dict(x=1, y=2)
    dict_data = dict(data)
    yaml_data = yaml.dump(dict_data, Dumper=AnsibleDumper)
    assert yaml_data == "x: 1\ny: 2\n"

# Generated at 2022-06-23 05:33:39.122882
# Unit test for function represent_unicode
def test_represent_unicode():
    '''
    Test represent_unicode function
    '''
    # Test unicode
    data = u'\n  foo: bar'
    # Test that yaml.dump will not return unicode, but str instance
    output = yaml.dump(data, Dumper=AnsibleDumper)
    assert not isinstance(output, text_type)
    # Test that output is an encoded str
    assert isinstance(output, binary_type)
    assert data.encode() in output
    # Test that if non unicode input is given, we will get an assertion error
    try:
        yaml.dump('test', Dumper=AnsibleDumper)
        assert False
    except AssertionError:
        assert True
    except Exception as e:
        assert False



# Generated at 2022-06-23 05:33:40.915785
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert 'AnsibleDumper' == AnsibleDumper.__name__



# Generated at 2022-06-23 05:33:45.379047
# Unit test for function represent_undefined
def test_represent_undefined():
    '''
    Verify represent_undefined works for AnsibleUndefined
    '''
    from ansible.template import AnsibleUndefined
    try:
        yaml.dump({'foo': AnsibleUndefined}, Dumper=AnsibleDumper)
    except Exception as e:
        assert 'AnsibleUndefined' in str(e)

# Generated at 2022-06-23 05:33:56.037667
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    for dumper_class in [SafeDumper, AnsibleDumper]:
        d = dumper_class(width=None)
        assert isinstance(d, yaml.dumper.Dumper)
        assert d.default_flow_style is False
        assert d.indent is 2
        assert d.width is None
        assert d.allow_unicode is True
        assert d.line_break is yaml.StringStream.LineBreakType.UNIX
        assert isinstance(d.represent_scalar, yaml.representer.Representer.represent_scalar)
        assert isinstance(d.represent_sequence, yaml.representer.Representer.represent_sequence)
        assert isinstance(d.represent_mapping, yaml.representer.Representer.represent_mapping)

# Generated at 2022-06-23 05:34:09.665063
# Unit test for function represent_unicode
def test_represent_unicode():
    # Test: __str__
    assert represent_unicode(None, AnsibleUnicode("test")) == yaml.representer.SafeRepresenter.represent_str(None, "test")

    # Test: __repr__
    assert represent_unicode(None, AnsibleUnicode("{!s}")) == yaml.representer.SafeRepresenter.represent_str(None, "'{!s}'")

    # Test: __unicode__
    assert represent_unicode(None, AnsibleUnicode("{!u}")) == yaml.representer.SafeRepresenter.represent_str(None, "'{!u}'")

    # Test: __bool__
    assert represent_unicode(None, AnsibleUnicode("true")) == yaml.representer.SafeRepresenter.represent_str(None, "true")

# Generated at 2022-06-23 05:34:20.473941
# Unit test for constructor of class AnsibleDumper

# Generated at 2022-06-23 05:34:31.247678
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = yaml.dumper.SafeDumper
    dumper.add_representer(
        AnsibleVaultEncryptedUnicode,
        represent_vault_encrypted_unicode,
    )

# Generated at 2022-06-23 05:34:37.268874
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    undefined_object = AnsibleUndefined('Ansible undefined', obj='object')
    actual_representation = dumper.represent_data(undefined_object)
    expected_representation = dumper.represent_data(True)
    assert actual_representation == expected_representation

# Generated at 2022-06-23 05:34:42.112071
# Unit test for function represent_binary
def test_represent_binary():
    d = AnsibleDumper(width=40)
    out = d.represent_data(u"\xFF\x40\x00\x40\x00\x40")
    assert out == "!!binary |\n  //4APgAAP4A"

# Generated at 2022-06-23 05:34:44.728595
# Unit test for function represent_binary
def test_represent_binary():
    d = AnsibleDumper()
    out = d.represent_binary(u'\u2713')
    assert out == "!!binary '3q2+7w=='"

# Generated at 2022-06-23 05:34:54.589726
# Unit test for function represent_binary
def test_represent_binary():
    test_string = u'abcd'

    yaml_string = yaml.safe_dump(test_string, indent=4, allow_unicode=True, default_flow_style=False, default_style='"', Dumper=AnsibleDumper)
    assert yaml_string == u"abcd\n"

    test_string = b'abcd'

    yaml_string = yaml.safe_dump(test_string, indent=4, allow_unicode=True, default_flow_style=False, default_style='"', Dumper=AnsibleDumper)
    assert yaml_string == u"!binary |\n  YWJjZA==\n"

    test_string = b'!\xab\xac'


# Generated at 2022-06-23 05:35:02.744386
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from jinja2.runtime import StrictUndefined

    v = VaultLib([])
    e = v.encrypt(u'foo')
    data = AnsibleVaultEncryptedUnicode(e)

# Generated at 2022-06-23 05:35:05.271788
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    data = AnsibleUnicode('hello')
    result = dumper.represent_unicode(dumper, data)
    assert result == 'hello'



# Generated at 2022-06-23 05:35:08.768216
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data_in = {"is_localhost": True, "inventory_hostname": u"localhost", "foo": u"bar"}
    data_out = "- is_localhost: true\n  inventory_hostname: localhost\n  foo: bar"
    dumper = AnsibleDumper()
    assert data_out == dumper.represent_data(data_in)



# Generated at 2022-06-23 05:35:10.288802
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper(width=100)
    assert dumper.width == 100

# Generated at 2022-06-23 05:35:13.672167
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    (res,) = dumper.represent_data({'aa': {'bb': {'cc': 'dd'}}})
    assert res == "aa:\n  bb:\n    cc: dd\n"

# Generated at 2022-06-23 05:35:16.625995
# Unit test for function represent_unicode
def test_represent_unicode():
    data = u'hello'
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(data) == u'"hello"'



# Generated at 2022-06-23 05:35:18.056303
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper()
    assert dumper is not None

# Generated at 2022-06-23 05:35:23.191147
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    datum = b"hello \x01\x02\x03"

    output = dumper.represent_binary(datum)

    assert output == u'!binary |\n  aGVsbG8gAQID\n'

# Generated at 2022-06-23 05:35:28.009520
# Unit test for function represent_undefined
def test_represent_undefined():
    undef = AnsibleUndefined
    obj = AnsibleDumper().represent_undefined(undef)
    assert obj is True
    undef._fail_with_undefined_error = True
    obj = AnsibleDumper().represent_undefined(undef)

# Generated at 2022-06-23 05:35:32.449482
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    out = dumper.represent_binary(binary_type(b'foo'))
    assert out.startswith('!binary ')
    assert dumper.represent_binary(text_type('foo')).startswith('!binary ')



# Generated at 2022-06-23 05:35:43.326889
# Unit test for function represent_hostvars
def test_represent_hostvars():
    expected = """{lookup('env', 'HOME'): \"/home/foo\", foo: bar}\n"""
    hvars = HostVars(path=None, variables=dict(foo='bar'))

# Generated at 2022-06-23 05:35:43.987423
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    pass

# Generated at 2022-06-23 05:35:53.164375
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    dumper.add_representer(
        AnsibleUnsafeBytes,
        represent_binary,
    )
    test_string = "hello"
    test_bytes = AnsibleUnsafeBytes(test_string)
    test_dict = {'bytes': test_bytes}
    # Ensure that AnsibleUnsafeBytes instance is
    # represented as a base 64 string.
    yaml_string = yaml.dump(
        test_dict,
        Dumper=dumper,
    )
    assert "aGVsbG8=\n" in yaml_string

# Generated at 2022-06-23 05:36:03.942530
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from StringIO import StringIO

    vault_password = 'secret'
    vault = VaultLib(vault_password)
    string = "New vault password: secret"
    yaml_str = vault.encrypt(text_type(string))

# Generated at 2022-06-23 05:36:06.702282
# Unit test for function represent_binary
def test_represent_binary():

    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'abc') == '!!binary |\n  YWJj\n'



# Generated at 2022-06-23 05:36:12.782446
# Unit test for function represent_binary
def test_represent_binary():

    # Using real string with utf-8 chars
    yaml.dump(b'\x80\x81\x82\x83', Dumper=AnsibleDumper)

    # Using real string with non-ascii chars
    yaml.dump(b'\xe2\x82\xac', Dumper=AnsibleDumper)

    # Using real string with non-ascii chars
    yaml.dump(b'\xba\xbf', Dumper=AnsibleDumper)



# Generated at 2022-06-23 05:36:23.846532
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    aueu = AnsibleVaultEncryptedUnicode('foo')

    # Test that we get the correct yaml output
    assert yaml.dump(aueu, Dumper=AnsibleDumper) == '!vault |\n  $ANSIBLE_VAULT;1.1;AES256\n30363136363233316532653162366561613831313439636233363535616434383966656339\n39306163353333666363343836383066316136656534396166616735336639336438653836\n653965\n'


# Test that the function AnsibleUndefined doesn't break when
# yaml.representer.SafeRepresenter.represent_bool tries to
# represent a False boolean value.

# Generated at 2022-06-23 05:36:25.621788
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper == dumper_constructor('AnsibleDumper', SafeDumper)



# Generated at 2022-06-23 05:36:29.486553
# Unit test for function represent_hostvars
def test_represent_hostvars():
    import os
    TEST_DIR = os.path.dirname(os.path.realpath(__file__))
    test_case = os.path.join(TEST_DIR, 'data', 'test_represent_hostvars.yml')
    data, vars_sources = yaml.safe_load(open(test_case, 'rb'))
    HostVars.from_source(data, vars_sources)



# Generated at 2022-06-23 05:36:39.089454
# Unit test for function represent_binary
def test_represent_binary():
    """Test function represent_binary"""

# Generated at 2022-06-23 05:36:48.269572
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    a = AnsibleVaultEncryptedUnicode()

# Generated at 2022-06-23 05:36:50.281519
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    data = b'abcd\x00'
    value = dumper.represent_binary(dumper, data)
    assert value == '!!binary "YWJjZAo="\n'

# Generated at 2022-06-23 05:36:54.788735
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper

    result = dumper.represent_hostvars(dumper, HostVars({'var1': 'val1', 'var2': 'val2'}))
    assert dict(result[0][1]) == {
        'var1': 'val1',
        'var2': 'val2'
    }

# Generated at 2022-06-23 05:37:05.582526
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars, HostVarsVars

    hostvars = HostVars(vars=dict(a=1, b=2))
    result = yaml.dump(hostvars, Dumper=AnsibleDumper)
    assert result == '{a: 1, b: 2}\n...\n'

    hostvars = HostVars(vars=dict(a=1, b=2))
    hostvars['c'] = 3
    result = yaml.dump(hostvars, Dumper=AnsibleDumper)
    assert result == '{a: 1, b: 2, c: 3}\n...\n'

    hostvars = HostVarsVars(hostvars=hostvars, vars=dict(d=4))
    result = y

# Generated at 2022-06-23 05:37:13.403017
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, 'test') == yaml.representer.SafeRepresenter.represent_str(None, text_type('test'))
    assert represent_unicode(None, 1) == yaml.representer.SafeRepresenter.represent_str(None, text_type('1'))
    assert represent_unicode(None, 1.1) == yaml.representer.SafeRepresenter.represent_str(None, text_type('1.1'))
    assert represent_unicode(None, True) == yaml.representer.SafeRepresenter.represent_str(None, text_type('True'))
    assert represent_unicode(None, [1, 2, 3]) == yaml.representer.SafeRepresenter.represent_str(None, text_type('[1, 2, 3]'))
    assert represent_

# Generated at 2022-06-23 05:37:15.310546
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.dump(AnsibleUndefined, Dumper=AnsibleDumper) == "false\n"

# Generated at 2022-06-23 05:37:17.151352
# Unit test for function represent_undefined
def test_represent_undefined():
    # Simple unit test
    assert represent_undefined(None, AnsibleUndefined()) == True


# Generated at 2022-06-23 05:37:18.863996
# Unit test for function represent_undefined
def test_represent_undefined():
    data = AnsibleUndefined
    assert AnsibleDumper.represent_undefined(VarsWithSources(), data)



# Generated at 2022-06-23 05:37:26.902052
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

# Generated at 2022-06-23 05:37:33.695026
# Unit test for function represent_hostvars
def test_represent_hostvars():

    # create an object to pass in to the data
    hostvars_object = HostVars(factory=None, all_vars=None, _get_var=None)

    # data to be passed into the function
    data = {"var1": "value1", "var2": "value2"}

    # call the function with hostvars_object as the data
    represent_hostvars(None, hostvars_object)

    # assert that the function returns the correct data that matches the data that was passed into
    # the function
    assert data == hostvars_object



# Generated at 2022-06-23 05:37:45.108773
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.manager import VariableManager
    import os
    import tempfile
    import textwrap

    # Create temporary vault password file
    vault_pass = tempfile.mktemp()
    with open(vault_pass, 'w') as f:
        os.chmod(vault_pass, 0o600)
        f.write('ansible')

    # Create encrypt/decrypt test data
    encrypt_text = """
        first:
          - item1
          - item2
          - item3
        second:
          key1: value1
          key2: value2
          key3: value3
    """

    # Encrypt test data
   

# Generated at 2022-06-23 05:37:48.643915
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper, type)



# Generated at 2022-06-23 05:37:52.022730
# Unit test for function represent_binary
def test_represent_binary():
    x = AnsibleUnsafeBytes('foo')
    res = yaml.dump(x, Dumper=AnsibleDumper)
    assert res == '!!binary |\n  Zm9v\n'


# Generated at 2022-06-23 05:38:03.576971
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    import base64
    # base64 encoded ciphertext of encrypted string "secret"
    encrypted_data_b64 = b'gAAAAABXeJ3qwjDMOccyWkp8Jvkz4f6Yu4yk4KbgU6YhU6G_lw_S2lSstBNe8nogA5BZPHP4ZK4JWL6UZY6mLy0cQKQxBz8Jog=='
    encrypted_data = base64.b64decode(encrypted_data_b64)
    vault_encrypted_string = AnsibleVaultEncryptedUnicode(encrypted_data)
    result = yaml.dump(vault_encrypted_string, Dumper=AnsibleDumper)

# Generated at 2022-06-23 05:38:06.198220
# Unit test for function represent_hostvars
def test_represent_hostvars():
    my_dumper = AnsibleDumper()
    assert my_dumper.represent_dict(dict(HostVars(dict(key1='value1')))) == {'key1': 'value1'}



# Generated at 2022-06-23 05:38:13.619138
# Unit test for function represent_unicode
def test_represent_unicode():
    sample_unicode_string = AnsibleUnicode('test unicode')
    sample_binary_string = AnsibleUnicode(b'test binary')
    sample_unsafe_text = AnsibleUnsafeText('test unsafe text')
    sample_unsafe_bytes = AnsibleUnsafeBytes(b'test unsafe bytes')
    assert yaml.dump(sample_unicode_string) == 'test unicode\n...\n'
    assert yaml.dump(sample_binary_string) == 'test binary\n...\n'
    assert yaml.dump(sample_unsafe_text) == 'test unsafe text\n...\n'
    assert yaml.dump(sample_unsafe_bytes) == 'test unsafe bytes\n...\n'



# Generated at 2022-06-23 05:38:17.105095
# Unit test for function represent_binary
def test_represent_binary():
    test_binary = binary_type(b'\x80')
    test_binary_repr = b"!binary |-\n  \x80"
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, test_binary) == test_binary_repr

# Generated at 2022-06-23 05:38:21.486106
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    assert yaml.load(yaml.dump(AnsibleVaultEncryptedUnicode('\xab\xcd', 'XYZ'), Dumper=AnsibleDumper)).encode() == '!vault |\n          XYZ\n'.encode()

# Generated at 2022-06-23 05:38:23.945580
# Unit test for function represent_undefined
def test_represent_undefined():
    test_object = AnsibleUndefined
    represent_undefined(AnsibleDumper, test_object)



# Generated at 2022-06-23 05:38:34.080659
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper()

    assert type(dumper) == AnsibleDumper
    assert dumper.__class__ == AnsibleDumper
    assert dumper.represent_seq == yaml.representer.SafeRepresenter.represent_list
    assert dumper.represent_dict == yaml.representer.SafeRepresenter.represent_dict
    assert dumper.represent_data == yaml.representer.SafeRepresenter.represent_data
    assert dumper.represent_undefined == represent_undefined
    assert dumper.represent_unicode == represent_unicode
    assert dumper.represent_binary == represent_binary
    assert dumper.represent_scalar == yaml.representer.SafeRepresenter.represent_scalar
    assert dumper.represent_list == yaml.representer.SafeRepresenter.represent_list


# Generated at 2022-06-23 05:38:43.916173
# Unit test for function represent_binary
def test_represent_binary():
    yamldump = True
    yamlobj = yaml.dump(dict(a=b'foo'), Dumper=AnsibleDumper)
    # Ensure we have a valid dictionary (in the generic sense, not a python dict)
    assert yamlobj[0] == '{'
    assert yamlobj[-1] == '}'
    # Ensure bytestrings are dumped as strings (since the YAML spec doesn't say they aren't)
    assert '!binary' not in yamlobj
    # Ensure bytestrings are dumped as strings (since the YAML spec doesn't say they aren't)
    assert "'Ym9i'\n" not in yamlobj
    # Ensure the bytestring got encoded correctly
    assert "'Zm9v'\n" in yamlobj


# Generated at 2022-06-23 05:38:48.713341
# Unit test for function represent_undefined
def test_represent_undefined():
    with pytest.raises(AnsibleError) as excinfo:
        AnsibleUndefined('obj', 'attr')
    assert 'obj' in str(excinfo.value)
    assert 'attr' in str(excinfo.value)


# Generated at 2022-06-23 05:38:57.926770
# Unit test for function represent_unicode
def test_represent_unicode():

    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    host = HostVars()
    templar = Templar(host)

    # test for the representer cases
    data = AnsibleUnicode("{% body %}")
    yaml.dump(data, Dumper=AnsibleDumper, explicit_start=True, explicit_end=True)

    data = AnsibleUnsafeText("{% body %}")
    yaml.dump(data, Dumper=AnsibleDumper, explicit_start=True, explicit_end=True)

    data = AnsibleUnsafeText("{% body %}")
    yaml.dump(data, Dumper=AnsibleDumper, explicit_start=True, explicit_end=True)


# Generated at 2022-06-23 05:39:05.592916
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()
    s = AnsibleVaultEncryptedUnicode("hi friend")
    result = dumper.represent_data(s)

# Generated at 2022-06-23 05:39:09.668687
# Unit test for function represent_undefined
def test_represent_undefined():
    try:
        AnsibleDumper.add_representer(
            AnsibleUndefined,
            represent_undefined,
        )
        assert False, "TypeError not raised"
    except TypeError:
        pass

del AnsibleDumper

# Generated at 2022-06-23 05:39:21.040526
# Unit test for function represent_binary

# Generated at 2022-06-23 05:39:24.007454
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    assert represent_vault_encrypted_unicode(AnsibleDumper, "abc") == "!vault |\n          YWJj\n          "

# Generated at 2022-06-23 05:39:32.318955
# Unit test for function represent_binary
def test_represent_binary():
    '''
    Tests the following:
        - verifies that base64 is used to represent a binary object
        - verifies that newlines are not added to the end of the output
    '''
    # The python2 yaml representer adds a final newline to the output.
    # We don't want that.
    base64_value = '{0}'.format(binary_type(b'\x00\x01\x02\x03').encode('base64')[:-1])
    output = '!binary |\n  {0}'.format(base64_value)

    # Need to represent the expected output as a binary object.
    # Otherwise we get a diff between a unicode object and a bytestring object
    expected_output = b''

# Generated at 2022-06-23 05:39:34.816501
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hv = HostVars(hostname='testhost')
    yaml.dump(hv, default_flow_style=False)



# Generated at 2022-06-23 05:39:45.082778
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars import VariableManager

    vardir = './lib/ansible/vars'
    variable_manager = VariableManager()
    variable_manager.set_host_variable('host1', 'a', '1')
    variable_manager.set_host_variable('host2', 'b', '2')
    variable_manager.set_host_variable('host3', 'c', '3')
    loader = variable_manager.get_vars(play=None, include_hostvars=True, include_delegate_to=True)
    result = yaml.dump(loader, Dumper=AnsibleDumper, default_flow_style=False)

# Generated at 2022-06-23 05:39:47.798469
# Unit test for function represent_hostvars
def test_represent_hostvars():
    yaml.dump(dict(a='a', b='b'), Dumper=AnsibleDumper)

# Generated at 2022-06-23 05:39:52.120372
# Unit test for function represent_binary
def test_represent_binary():
    import test.utils.module_runner
    runner = test.utils.module_runner.Runner()

    args = {'unsafe_bytes': b'\x01\x02\x03\x04'}
    runner.run('dump_args', args=args)



# Generated at 2022-06-23 05:39:54.534474
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(bin('string')) == "!!binary \"c3RyaW5n\"\n"



# Generated at 2022-06-23 05:40:01.375834
# Unit test for function represent_undefined
def test_represent_undefined():
    # In this case the variable isn't there in the variable file
    dumper = AnsibleDumper()
    ud = AnsibleUndefined()
    expected = 'null'
    assert dumper.represent_undefined(ud) == expected
    ud = AnsibleUndefined(errors_fatal=False)
    assert dumper.represent_undefined(ud) == expected

# Generated at 2022-06-23 05:40:03.171340
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper().represent_undefined(AnsibleUndefined(None)) is True



# Generated at 2022-06-23 05:40:14.545583
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()
    encrypted_data = AnsibleVaultEncryptedUnicode('AES256', '$ANSIBLE_VAULT;1.1;AES256\n62386162366262616237626162307735536133336c5a5a5a6e5d6b5a6c5a6a5677766f3d3d0a\n')
    output = dumper.represent_data(encrypted_data)

# Generated at 2022-06-23 05:40:20.752475
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    representer = AnsibleDumper()
    ciphertext = u'$ANSIBLE_VAULT;1.1;AES256\n'\
                 u'633762393366653435393436633762376431363962333762393266633562353935363966646164320a'\
                 u'6164376439323939646635653563613534363930616536323736366638373535623132616261360a'\
                 u'66343163626531653231633562353363353337356138626261653735373630333537666661376236'

    data = AnsibleVaultEncryptedUnicode(ciphertext=ciphertext)
    result = yaml.dump(data, Dumper=representer)

# Generated at 2022-06-23 05:40:28.966132
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    unicode_string = AnsibleUnicode.from_string('string')
    assert unicode_string == 'string'
    # Check if the answer is Unicode type and not a string
    assert type(dumper.represent_unicode(dumper, unicode_string)) is yaml.representer.SafeRepresenter.represent_unicode
    # The above function returns a String, so convert it to unicode
    assert type(dumper.represent_unicode(dumper, unicode_string).encode('utf-8')) is unicode

# Generated at 2022-06-23 05:40:34.240953
# Unit test for function represent_hostvars
def test_represent_hostvars():
    rep = yaml.representer.Representer()
    rep.add_representer(
        HostVars,
        represent_hostvars,
    )
    s = yaml.dump(HostVars(dict(a=1, b=2)), Dumper=rep)
    assert s == u'{a: 1, b: 2}\n'



# Generated at 2022-06-23 05:40:37.014153
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper
    data = dict(foo=1)
    output = dumper.represent_hostvars(dumper, data)
    assert output == dumper.represent_dict(dumper, data)

# Generated at 2022-06-23 05:40:41.514070
# Unit test for function represent_hostvars
def test_represent_hostvars():
    host = HostVars(vars={'foo': 'bar'}, machine_id='testhost')
    result = yaml.dump(host, Dumper=AnsibleDumper)

    expected_result = yaml.dump(dict(host), Dumper=AnsibleDumper)
    assert result == expected_result



# Generated at 2022-06-23 05:40:53.006651
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(b"foo") == u"!ansible-unsafe foo"
    assert dumper.represent_unicode(u"foo") == u"!ansible-unsafe foo"
    assert dumper.represent_unicode(u"\u2713") == u"!ansible-unsafe \\u2713"
    assert dumper.represent_unicode(u"\U0001f4a9") == u"!ansible-unsafe \\U0001f4a9"
    assert dumper.represent_unicode(u"Bj\xf6rn") == u"!ansible-unsafe Bj\\xf6rn"

# Generated at 2022-06-23 05:41:03.384779
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-23 05:41:04.536806
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    ansibleDumper = AnsibleDumper()

# Generated at 2022-06-23 05:41:15.422057
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # FIXME: This is a rather poor unit test, we need to look at
    # improving it in the future.
    dumper = AnsibleDumper(explicit_start=True, explicit_end=True)

# Generated at 2022-06-23 05:41:22.615051
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(AnsibleDumper, u'unicode test') == \
        yaml.representer.SafeRepresenter.represent_scalar(
            u'tag:yaml.org,2002:str', u'unicode test'
        )

    assert represent_unicode(AnsibleDumper, u'unicode test') == \
        yaml.representer.SafeRepresenter.represent_str(
            u'unicode test'
        )



# Generated at 2022-06-23 05:41:24.521531
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert hasattr(AnsibleDumper, 'add_representer')

# Generated at 2022-06-23 05:41:31.702605
# Unit test for function represent_binary
def test_represent_binary():
    output = yaml.dump(dict(binary_value=binary_type('some unicode value')), Dumper=AnsibleDumper)
    assert output == "binary_value: 'some unicode value'\n"


# AnsibleDumper returns no tags for strings, scalars or mappings by default, and
# we want to preserve this behaviour for both 1-level and 2-level accesses to
# the object, so we generate a bunch of tests for different versions of the
# object.


# Generated at 2022-06-23 05:41:42.324100
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    '''
    Check that we can represent an encrypted scalar as a yaml vault
    field.
    '''
    # test empty plaintext
    plaintext = b''

# Generated at 2022-06-23 05:41:46.717138
# Unit test for function represent_unicode
def test_represent_unicode():
    assert(yaml.dump(AnsibleUnicode(text_type('test')), Dumper=AnsibleDumper)) == "test\n"
    assert(yaml.dump(AnsibleUnicode(text_type('test')), Dumper=AnsibleDumper)) == "test\n"


# Generated at 2022-06-23 05:41:49.086322
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined)



# Generated at 2022-06-23 05:41:52.751002
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = yaml.dumper.SafeDumper
    assert represent_unicode(dumper, u'\u263a') == "\xF0\x9F\x98\xBA"
    assert represent_unicode(dumper, u'\u263a') == "\xF0\x9F\x98\xBA"



# Generated at 2022-06-23 05:42:01.363696
# Unit test for function represent_binary
def test_represent_binary():
    """
    Ensure that binary data is dumped as a YAML string, rather than a YAML
    binary block, in order to avoid a serialization incompatibility between
    PyYAML and ruamel.yaml.

    This behavior is not documented, but can be seen in the PyYAML source code
    at https://bitbucket.org/xi/pyyaml/src/default/lib3/yaml/representer.py.
    """
    assert AnsibleDumper.represent_binary(b'A\x00') == u'!!binary |\n  QQAA\n'