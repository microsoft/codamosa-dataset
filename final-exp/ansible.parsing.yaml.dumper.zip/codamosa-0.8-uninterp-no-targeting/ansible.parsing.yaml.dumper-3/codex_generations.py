

# Generated at 2022-06-20 23:50:46.577779
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()

    assert dumper.represent_unicode(u"\u2713") == "? |-\n  \u2713\n"



# Generated at 2022-06-20 23:50:56.772751
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils.six.moves.http_cookiejar import CookieJar
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils._text import to_bytes

    # Just make sure that objects that can represent themselves as
    # strings properly (ie: don't throw an exception)
    cookiejar = CookieJar()
    AnsibleDumper.add_representer(CookieJar, cookiejar.__repr__)
    string = ""
    assert cookiejar == yaml.safe_load(string)

    fileobj = StringIO()
    AnsibleDumper.add_representer(StringIO, fileobj.__repr__)
    assert fileobj == yaml.safe_load(string)

    # Test for

# Generated at 2022-06-20 23:51:08.025907
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():


    class FakeConfig:
        def __init__(self, options=[]):
            self._config_data = dict()
            for option in options:
                self._config_data[option] = True

        def __getattr__(self, option):
            return self._config_data[option]

    config = FakeConfig(['allow_unsafe'])
    ansible_dumper = AnsibleDumper(default_flow_style=False, allow_unsafe=config.allow_unsafe)
    unicode_str = "unicode"
    unicode_value = AnsibleUnicode(unicode_str)
    unicode_representation = ansible_dumper.represent_unicode(unicode_value)
    assert unicode_representation == u'unicode'

    unsafe_text = "unsafe text"
    unsafe

# Generated at 2022-06-20 23:51:16.135444
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

    # bytes
    assert dumper.represent_binary(b'\x00') == u'!!binary |\n  AA=='

    # bytes with explicit unicode()
    assert dumper.represent_binary(unicode(b'\x00', 'utf-8')) == u'!!binary |\n  AA=='

    # text
    assert dumper.represent_binary(u'\u0000') == u'!!binary |\n  AP8='

    # text with explicit str()
    assert dumper.represent_binary(str(u'\u0000')) == u'!!binary |\n  AP8='

# Generated at 2022-06-20 23:51:20.343365
# Unit test for function represent_hostvars
def test_represent_hostvars():
    d = AnsibleDumper(indent=2)
    data = HostVars(dict(a=1, b=2))
    # Manually encode data to JSON
    result = d.represent_dict(dict(data))
    expected = '''{a: 1, b: 2}'''
    assert expected == result

# Generated at 2022-06-20 23:51:31.729691
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Given: An instance of AnsibleVaultEncryptedUnicode
    data = AnsibleVaultEncryptedUnicode(u'0123456789abcdef', u'mysecret')
    dumper = AnsibleDumper()

    # When: The method is called

# Generated at 2022-06-20 23:51:35.365807
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    result = dumper.represent_binary(b'\x00\xff')
    assert result == "!!binary |\n  AA8/\n", result


# Generated at 2022-06-20 23:51:46.707005
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-20 23:51:52.154844
# Unit test for function represent_unicode
def test_represent_unicode():
    test_data = u'{ "name": "test_unicode"}'
    test_ansible_unicode = AnsibleUnicode(test_data)
    assert represent_unicode(AnsibleDumper, test_ansible_unicode) == yaml.representer.SafeRepresenter.represent_str(AnsibleDumper, text_type(test_data))



# Generated at 2022-06-20 23:51:56.065837
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper(explicit_start=True, explicit_end=True)
    assert dumper.represent_data(AnsibleUndefined()) == "null\n...\n"

# Generated at 2022-06-20 23:52:01.430942
# Unit test for function represent_binary
def test_represent_binary():
    assert represent_binary(AnsibleDumper, b'foo') == "!!binary 'Zm9v'"



# Generated at 2022-06-20 23:52:11.394086
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.playbook.play import Play
    from ansible.vars.hostvars import HostVars

    dumper = AnsibleDumper

    # Arrange
    play = Play().load({})
    play._variable_manager.set_nonpersistent_facts(dict(one=1, two=2, three=3))
    play._variable_manager.set_nonpersistent_facts(dict(four=4, five=5, six=6))
    play._variable_manager.set_nonpersistent_facts(dict(seven=7, eight=8, nine=9))
    play._variable_manager.set_nonpersistent_facts(dict(ten=10, eleven=11, twelve=12))

# Generated at 2022-06-20 23:52:22.374347
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib

    # create VaultLib object
    vault = VaultLib([])
    # encrypt the answer
    ciphertext = vault.encrypt('42')
    # create AnsibleVaultEncryptedUnicode object
    avec = AnsibleVaultEncryptedUnicode(ciphertext)
    # dump object to yaml
    yaml_representation = yaml.dump(avec, Dumper=AnsibleDumper)
    # check yaml representation
    assert '!vault' in yaml_representation
    # load yaml representation back to object
    obj = yaml.load(yaml_representation)
    # check that object is the same as original
    assert obj.ciphertext == avec.ciphertext

# Generated at 2022-06-20 23:52:22.873676
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper

# Generated at 2022-06-20 23:52:30.446918
# Unit test for function represent_unicode
def test_represent_unicode():
    # dummy data
    data = {
        '_raw_params': "text",
        'x': "{{ 'a': 'b' }}",
        'y': {
            'a': 'b',
            'c': "{{ 'd': 'e' }}"
        }
    }

    # init
    dumper = AnsibleDumper()
    # call
    data2 = dumper.represent_data(data)
    # test if result is valid
    assert data == yaml.load(data2)


# Generated at 2022-06-20 23:52:33.280574
# Unit test for function represent_unicode
def test_represent_unicode():
    string = u'привет'
    assert represent_unicode(AnsibleDumper, string) == yaml.representer.SafeRepresenter.represent_str(AnsibleDumper, string)

# Generated at 2022-06-20 23:52:40.660660
# Unit test for function represent_undefined
def test_represent_undefined():

    dumper = AnsibleDumper()
    dumper.default_flow_style = True

    assert dumper.represent_scalar('tag:yaml.org,2002:bool', False) == u'false'
    assert dumper.represent_scalar('tag:yaml.org,2002:bool', True) == u'true'
    assert dumper.represent_scalar('tag:yaml.org,2002:bool', None) is None
    assert dumper.represent_scalar('tag:yaml.org,2002:bool', AnsibleUndefined) == u'false'

# Generated at 2022-06-20 23:52:43.749189
# Unit test for function represent_unicode
def test_represent_unicode():
    ansible_yaml = AnsibleUnicode('test')
    assert yaml.dump(ansible_yaml, Dumper=AnsibleDumper) == "test\n...\n"



# Generated at 2022-06-20 23:52:48.761854
# Unit test for function represent_undefined
def test_represent_undefined():
    import StringIO
    stream = StringIO.StringIO()
    dumper = AnsibleDumper(stream)
    dumper.open({})
    dumper.represent({AnsibleUndefined(): "test_value"})
    dumper.close()
    assert stream.getvalue() == 'UndefinedError: '



# Generated at 2022-06-20 23:52:58.506747
# Unit test for function represent_undefined
def test_represent_undefined():
    ad = AnsibleDumper()
    assert ad.represent_undefined(AnsibleUndefined(None, '', '', ['a', 1], [2, 'b'])) == False
    assert ad.represent_undefined(AnsibleUndefined(None, '', '', None, None)) == False
    assert ad.represent_undefined(AnsibleUndefined(None, '', '', "", "")) == False
    assert ad.represent_undefined(AnsibleUndefined(None, '', '', None, "")) == False
    assert ad.represent_undefined(AnsibleUndefined(None, '', '', "", None)) == False



# Generated at 2022-06-20 23:53:01.603635
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.dump(AnsibleUndefined()) == 'false\n...\n'

# Generated at 2022-06-20 23:53:05.033940
# Unit test for function represent_hostvars
def test_represent_hostvars():
    result = yaml.dump(HostVars({"key1": "value1"}), Dumper=AnsibleDumper, default_flow_style=False)
    assert result == "key1: value1\n"

# Generated at 2022-06-20 23:53:11.905677
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode("a\u0300"), Dumper=AnsibleDumper) == u'\'a\\u0300\''
    assert yaml.dump(AnsibleUnicode("a\u0300", preserve_shape=True), Dumper=AnsibleDumper) == u'a\u0300'
    assert yaml.dump(AnsibleUnicode("a\u0300", preserve_shape=True), Dumper=AnsibleDumper, allow_unicode=True) == u'à'
    assert yaml.dump(AnsibleUnicode("a\u0300", preserve_shape=False), Dumper=AnsibleDumper, allow_unicode=True) == u'\'a\\u0300\''

# Generated at 2022-06-20 23:53:16.988096
# Unit test for function represent_binary
def test_represent_binary():
    class TestClass:
        def __init__(self, val):
            self.value = val

        def __str__(self):
            return self.value

    rep = AnsibleDumper.represent_binary(TestClass('hello'))
    assert type(rep) is text_type


# vim: set expandtab:

# Generated at 2022-06-20 23:53:18.778586
# Unit test for function represent_undefined
def test_represent_undefined():
    assert(yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper) == "")

# Generated at 2022-06-20 23:53:27.223834
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()

    data = AnsibleUnsafeText(u'test')
    result = yaml.representer.SafeRepresenter.represent_str(dumper, text_type(data))
    assert result == "test"

    data = AnsibleUnicode(u'test')
    result = yaml.representer.SafeRepresenter.represent_str(dumper, text_type(data))
    assert result == "test"

    data = AnsibleUnsafeText('test')
    result = yaml.representer.SafeRepresenter.represent_str(dumper, text_type(data))
    assert result == "test"



# Generated at 2022-06-20 23:53:28.161566
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper


# Generated at 2022-06-20 23:53:29.853630
# Unit test for function represent_binary
def test_represent_binary():
    assert AnsibleDumper.represent_binary(b'value\x00') == "!!binary value"


# Generated at 2022-06-20 23:53:37.082917
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host as AnsibleHost
    from ansible.inventory.group import Group as AnsibleGroup

    # Represent a simple host
    host = AnsibleHost('host_one')
    host_vars = HostVars(host)
    host_vars.add_host_vars_from_inventory(host)
    host_vars.add_host_vars_from_group('group_one', host)
    host_vars.add_host_vars_from_group('all', host)
    host_vars.add_host_vars_from_yaml({'key': 'value'}, host)
    host_vars.add_host_v

# Generated at 2022-06-20 23:53:48.713380
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars

    # Instantiate AnsibleMapping and dump to yaml.
    hvars = HostVars(
        '127.0.0.1',
        '/home/baloney/ansible/reee',
        dict(
            uno=1,
            dos=2,
            tres=3,
        )
    )

    assert hvars.__class__.__name__ == 'HostVars'
    assert hvars.get('uno') == 1
    assert hvars.get('dos') == 2
    assert hvars.get('tres') == 3
    assert hvars.hostname == '127.0.0.1'
    assert type(hvars.data) == dict

    # Our representation should be a dictionary of data with

# Generated at 2022-06-20 23:53:57.505956
# Unit test for function represent_hostvars
def test_represent_hostvars():
    class FakeDumper(object):
        pass

    fake_dumper = FakeDumper()
    fake_dumper.represent_dict = yaml.representer.SafeRepresenter.represent_dict
    assert represent_hostvars(fake_dumper, {}) == {'__ansible_hostvars__': {}}



# Generated at 2022-06-20 23:53:59.708218
# Unit test for function represent_undefined
def test_represent_undefined():
    test_value = AnsibleUndefined("test_value")
    assert test_value == "test_value"

# Generated at 2022-06-20 23:54:09.163207
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    binary_string = u'Some bytes: \xff\xff'
    b_binary_string = binary_type(binary_string)
    text_string = u'Some bytes: \ufffd\ufffd'

    # Direct repr
    binary_repr = dumper.represent_binary(b_binary_string)

    # Make sure it's the same if converted to text before using
    text_binary_string = binary_string.encode('utf-8')
    text_binary_repr = dumper.represent_binary(text_binary_string)
    assert binary_repr == text_binary_repr

    # Make sure it's not the same if different bytes are given (not utf-8)
    text_repr = dumper.represent_str(text_string)
    assert binary_

# Generated at 2022-06-20 23:54:21.138228
# Unit test for function represent_binary
def test_represent_binary():
    bytes = b'\x00\x10\x83\x10\x51\x87\x20\x92\x8b\x30\xd3\x8f\x41\x14\x93'
    # All of the following are equivalent
    assert yaml.dump(bytes, Dumper=AnsibleDumper) == u"!binary |\n  AAEBCQQGCAoL\n"
    assert yaml.dump(bytes, Dumper=AnsibleDumper) == yaml.dump(bytes, Dumper=SafeDumper)
    assert yaml.dump(bytes, Dumper=AnsibleDumper) == yaml.dump(binary_type(bytes), Dumper=SafeDumper)

# Generated at 2022-06-20 23:54:32.084653
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # Just test some basic items
    data = {'hostvars': {'host1': {'a': 1}, 'host2': {'a': 2}}}
    assert "{'host2': {'a': 2}, 'host1': {'a': 1}}" == yaml.safe_dump(data, default_flow_style=False, Dumper=AnsibleDumper)

    # Test a nested set
    data = {'hostvars': {'host1': {'a': 1}, 'host2': {'a': 2, 'b': {'c': 1}}}}
    assert "{'host2': {'b': {'c': 1}, 'a': 2}, 'host1': {'a': 1}}" == yaml.safe_dump(data, default_flow_style=False, Dumper=AnsibleDumper)

# Generated at 2022-06-20 23:54:34.067110
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    data = HostVars('a')
    data['b'] = HostVars('c')
    data['b']['d'] = 'e'
    out = list(dumper.represent_data(data))
    assert out == [
        u'b:',
        u'  d: e',
    ]


# Generated at 2022-06-20 23:54:40.732654
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = yaml.Dumper()
    dumper.add_representer(
        AnsibleUnicode,
        represent_unicode,
    )

    expected = """\
foo: 'bar'
"""
    data = AnsibleUnicode('bar')
    assert expected == yaml.dump({'foo': data}, Dumper=dumper, default_flow_style=False)



# Generated at 2022-06-20 23:54:43.479156
# Unit test for function represent_binary
def test_represent_binary():
    data = b'Initial password'
    data_encoded = 'Initial password'
    assert yaml.dump(data, Dumper=AnsibleDumper) == data_encoded

# Generated at 2022-06-20 23:54:53.852875
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    ansible_dumper = AnsibleDumper()


# Generated at 2022-06-20 23:55:00.894522
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    text = u"this is some test text"
    data = AnsibleVaultEncryptedUnicode(VaultLib.encrypt(text, VaultSecret(b"password")))
    dumper = AnsibleDumper(width=1000, default_flow_style=True)
    output = dumper.represent_data(data)

# Generated at 2022-06-20 23:55:10.850373
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = HostVars({u'foo': u'bar'})
    result = yaml.safe_dump(data, Dumper=AnsibleDumper)
    assert result == b'{foo: bar}\n...\n'



# Generated at 2022-06-20 23:55:17.545780
# Unit test for function represent_undefined
def test_represent_undefined():
    with open("../../../test/sanity/utils/test_represent_undefined.yaml", 'r') as f:
        docs = yaml.load_all(f)
        # Replace below with an assert
        for doc in docs:
            if (doc[1]['_ansible_verbose_always'] == "Test") and (str(doc[1]['undefined']) == 'error'):
                print("Yaml Dump Test: test_represent_undefined - Success")
            else:
                print("Yaml Dump Test: test_represent_undefined - Failure")

# Generated at 2022-06-20 23:55:18.764725
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper(), AnsibleDumper)

# Generated at 2022-06-20 23:55:25.135975
# Unit test for function represent_hostvars
def test_represent_hostvars():
    ''' test the represent_hostvars function '''

    class FakeDumper(object):
        ''' we need this to test the dumper '''

        def represent_dict(self, data):
            ''' override the normal dict represention in the real dumper '''
            pass

    vars = HostVars()
    vars._data = dict(one='1', two='2', three='3')
    dumper = FakeDumper()
    represent_hostvars(dumper, vars)



# Generated at 2022-06-20 23:55:35.812003
# Unit test for function represent_unicode
def test_represent_unicode():
    """
    A unit test for the function represent_unicode
    """
    # given
    class Foo:
        def __init__(self, value):
            self.value = value
        def __str__(self):
            return str(self.value)

    ansible_dumper = AnsibleDumper(indent=2, width=1000)
    # when
    ret = yaml.representer.SafeRepresenter.represent_unicode(ansible_dumper, u'foo')
    # then
    assert ret == u'"foo"\n'

    # given
    ansible_dumper = AnsibleDumper(indent=2, width=1000)
    # when
    ret = AnsibleDumper.represent_unicode(ansible_dumper, Foo(u'foo'))
    # then

# Generated at 2022-06-20 23:55:40.675519
# Unit test for function represent_binary
def test_represent_binary():
    data = AnsibleUnicode(b'\x1f[\x9e\xa1\x8e"8\xc4\x97_\x96\x1f\x86\xcb\xf9\xef')
    yaml.dump(data, stream=None, Dumper=AnsibleDumper, width=1000)



# Generated at 2022-06-20 23:55:43.378203
# Unit test for function represent_binary
def test_represent_binary():
    from ansible.module_utils import six
    # create a dummy binary string
    data = six.binary_type("\xff")
    dumper = AnsibleDumper()
    assert dumper.represent_binary(data) == u"!binary |\n  //8=\n"



# Generated at 2022-06-20 23:55:46.500938
# Unit test for function represent_undefined
def test_represent_undefined():
    data = AnsibleDumper.represent_undefined(AnsibleUndefined(is_error=False))
    assert data == {'_ansible_no_log': False}



# Generated at 2022-06-20 23:55:48.268488
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper(None)
    assert not dumper.represent_data(AnsibleUndefined)

# Generated at 2022-06-20 23:55:57.123602
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    value = dumper.represent_unicode(u'{"x": "y"}')
    assert value == u'{"x": "y"}'
    value = dumper.represent_unicode('{"x": "y"}')
    assert value == u'{"x": "y"}'
    value = dumper.represent_unicode(u'{"x": "y"}')
    assert value == u'{"x": "y"}'
    value = dumper.represent_unicode(u"{'x': 'y'}")
    assert value == u"{'x': 'y'}"

# Generated at 2022-06-20 23:56:12.790891
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.safe_dump(b'foo' , Dumper=AnsibleDumper) == "!!binary |\n  Zm9v\n"



# Generated at 2022-06-20 23:56:13.794264
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    a = AnsibleDumper



# Generated at 2022-06-20 23:56:16.333313
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dump_data = AnsibleDumper()
    assert isinstance(dump_data, yaml.dumper.Dumper)



# Generated at 2022-06-20 23:56:21.017679
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, AnsibleUnicode(b'foo')) == u'foo'
    assert represent_unicode(None, AnsibleUnsafeText(b'foo')) == u'foo'
    assert represent_unicode(None, AnsibleUnsafeBytes(b'foo')) == u'foo'


# Generated at 2022-06-20 23:56:25.307073
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.load(yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper)) == 'undefined'


if __name__ == "__main__":
    import unittest
    import doctest

    suite = unittest.TestLoader().loadTestsFromModule(sys.modules[__name__])
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-20 23:56:28.855523
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump({'sample': 'value'}, Dumper=AnsibleDumper) == '{sample: value}\n'
    assert yaml.dump({'sample': 'value'}, Dumper=AnsibleDumper) == '{sample: value}\n'
    assert yaml.dump({'sample': 'value'}, Dumper=AnsibleDumper) == '{sample: value}\n'



# Generated at 2022-06-20 23:56:31.168497
# Unit test for function represent_undefined
def test_represent_undefined():
    y = AnsibleDumper()
    x = AnsibleUndefined()
    assert y.represent_undefined(x) == x



# Generated at 2022-06-20 23:56:31.864018
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper

# Generated at 2022-06-20 23:56:33.315891
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    AnsibleDumper()



# Generated at 2022-06-20 23:56:38.159560
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = AnsibleVaultEncryptedUnicode('someciphertext')
    ret = represent_vault_encrypted_unicode(AnsibleDumper, data)
    assert ret == '!vault |\n  someciphertext'