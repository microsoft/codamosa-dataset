

# Generated at 2022-06-20 23:50:49.494971
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.plugins.loader import vars_loader

    context = PlayContext()
    manager = VariableManager()

    manager.set_fact("foo", "bar")
    host = "localhost"
    manager.set_host_variable(host, "foo", "baz")
    results = vars_loader.run(host, context, manager)

    # Make sure the VaultCiphertextUnicode object has been
    # converted to a regular unicode string.
    assert str(results['foo']) == 'baz'

    # Note: we can't test the !unsafe tag here - only in tests/unit/vars/test_

# Generated at 2022-06-20 23:50:57.473062
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()
    ctext = "AES256$8QTlTmG0AODmV$R/0HdPVuNVx/2QgX3h6AjU6ZNU6pzg7N"
    encrypted = AnsibleVaultEncryptedUnicode(ctext)
    result = dumper.represent_data(encrypted)
    assert result == "!vault |\n  " + "AES256$8QTlTmG0AODmV$R/0HdPVuNVx/2QgX3h6AjU6ZNU6pzg7N\n"

# Generated at 2022-06-20 23:51:03.864794
# Unit test for function represent_undefined
def test_represent_undefined():
    try:
        yaml.safe_dump(AnsibleUndefined(), Dumper=AnsibleDumper)
    except Exception as e:
        if 'is undefined' in text_type(e):
            # This is the error we expect, so we can treat it as success
            return
        else:
            raise

    raise AssertionError('yaml.safe_dump on an AnsibleUndefined object did not raise an exception as expected')

# Generated at 2022-06-20 23:51:07.748289
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(
        AnsibleUnicode('some string'),
        Dumper=AnsibleDumper,
        default_flow_style=False
    ) == 'some string\n...\n'



# Generated at 2022-06-20 23:51:13.464553
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    import yaml
    assert isinstance(yaml.AnsibleDumper, type)
    assert issubclass(yaml.AnsibleDumper, yaml.SafeDumper)
    assert issubclass(yaml.AnsibleDumper, AnsibleDumper)
    assert isinstance(yaml.AnsibleDumper(), yaml.SafeDumper)
    assert isinstance(yaml.AnsibleDumper(), AnsibleDumper)



# Generated at 2022-06-20 23:51:23.050585
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-20 23:51:27.080528
# Unit test for function represent_binary
def test_represent_binary():
    a = AnsibleDumper(unicode_representer=None)
    assert a.represent_binary(b'abc') == "!!binary abc", "represent_binary failed."



# Generated at 2022-06-20 23:51:33.018549
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    test_data = b'coyote'
    expected = "!!python/object/apply:yaml.representer.SafeRepresenter.represent_binary\n- !!binary \"Y29" \
               "5b3Rl\"\n"
    result = yaml.dump(test_data, Dumper=AnsibleDumper)
    assert result == expected

# Generated at 2022-06-20 23:51:44.005948
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    print()
    input_data = '!vault |' + text_type(yaml.dump(dict(password='secret')))
    expected_output = '!vault |\n  $ANSIBLE_VAULT;1.1;AES256\n  363830626236336139653961613066666261616631653731326263336535366631636133313861636\n  66664373365623536623338633962326166626061\n'
    output_data = yaml.dump(yaml.load(input_data, Loader=yaml.SafeLoader), Dumper=AnsibleDumper)
    assert output_data == expected_output

# Generated at 2022-06-20 23:51:46.144855
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode(u'foo'), Dumper=AnsibleDumper).split('\n') == [u'foo']



# Generated at 2022-06-20 23:52:01.038729
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.template import Templar
    from ansible.errors import AnsibleUndefinedVariable

    d = AnsibleDumper()
    t = Templar(loader=None)

    val = "test"
    d.represent_undefined(val)

    val = AnsibleUnsafeText(val)
    d.represent_undefined(val)

    val = AnsibleUnsafeBytes(b'test')
    d.represent_undefined(val)

    val = AnsibleUndefined()
    try:
        d.represent_undefined(val)
    except AnsibleUndefinedVariable as e:
        assert isinstance(e, AnsibleUndefinedVariable)

    val = AnsibleUndefined(obj=t, name='t')

# Generated at 2022-06-20 23:52:08.747965
# Unit test for function represent_binary
def test_represent_binary():
    # data is a binary type
    data = b'test-data'
    dumper = AnsibleDumper()
    result = dumper.represent_binary(data)
    assert result == u"!binary |\n  dGVzdC1kYXRh\n"

    # data is not a binary type
    data = u'test-data'
    dumper = AnsibleDumper()
    result = dumper.represent_binary(data)
    assert result == u"!binary |\n  dGVzdC1kYXRh\n"



# Generated at 2022-06-20 23:52:13.524174
# Unit test for function represent_binary
def test_represent_binary():
    '''
    Test function represent_binary
    '''
    # AnsibleUnsafeBytes should be serialized as yaml.representer.SafeRepresenter.represent_binary
    sample_data = AnsibleUnsafeBytes(b'binary_sample')
    assert yaml.representer.SafeRepresenter.represent_binary(AnsibleDumper(), sample_data) == \
        yaml.representer.SafeRepresenter.represent_binary(AnsibleDumper(), binary_type(sample_data))

# Generated at 2022-06-20 23:52:24.931394
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

    class TestBinaryObject:
        def __init__(self, value):
            self.data = value

        def __bytes__(self):
            return self.data

    assert dumper.represent_data(TestBinaryObject(b'foo')) == "!!binary |\n  Zm9v"
    assert dumper.represent_data(TestBinaryObject(b'foobar')) == "!!binary |\n  Zm9vYmFy"
    assert dumper.represent_data(TestBinaryObject(b'foobar\n')) == "!!binary |\n  Zm9vYmFyCg=="
    assert dumper.represent_data(TestBinaryObject(b'\n')) == "!!binary |\n  Cg=="



# Generated at 2022-06-20 23:52:29.781614
# Unit test for function represent_undefined
def test_represent_undefined():
    represent_undefined(AnsibleDumper, AnsibleUndefined())
    try:
        represent_undefined(AnsibleDumper, False)
        assert False, 'Should have thrown a TypeError'
    except TypeError:
        pass


__all__ = ['AnsibleDumper']

# Generated at 2022-06-20 23:52:31.179038
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    # Just check if it can be constructed
    ad = AnsibleDumper()

# Generated at 2022-06-20 23:52:34.804637
# Unit test for function represent_hostvars
def test_represent_hostvars():
    host_vars = HostVars({"a": "1", "b": "2"})
    value = yaml.dump(host_vars, Dumper=AnsibleDumper)
    expected_value = "a: 1\nb: 2\n"
    assert value == expected_value



# Generated at 2022-06-20 23:52:40.184438
# Unit test for function represent_binary
def test_represent_binary():
    representer = AnsibleDumper()
    assert representer.represent_binary(b'foo') == (u'!binary |\n'
                                                     u'  Zm9v\n')
    assert representer.represent_binary(b'\xe2\x98\x83') == (u'!binary |\n'
                                                            u'  4pyT\n')

# Generated at 2022-06-20 23:52:48.954165
# Unit test for function represent_hostvars
def test_represent_hostvars():
    var = HostVars()
    var['foo'] = 'bar'

    expected_type = yaml.nodes.MappingNode
    expected_tag = u'!ansible.hostvars'

    # Loading is a 2 step process, first create the node, then construct it
    representer = AnsibleDumper()
    node = representer.represent_data(var)
    data = yaml.constructor.Constructor(yaml.nodes.MappingNode()).construct(node)

    assert type(node) == expected_type
    assert node.tag == expected_tag
    assert data == var


# Generated at 2022-06-20 23:52:56.723094
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    vaunted = AnsibleVaultEncryptedUnicode(b'HELLO\n')
    vaunted._finalize()
    d = AnsibleDumper()
    assert d.represent_data(vaunted) == u'!vault |\n          AAAAAAFlRWA3KqJ8mmsXmQQD+jKMZ/Q/sPGsUJx6KjN1TbT6Peo/Nh9J6z\n          pGZJg==\n'

# Generated at 2022-06-20 23:53:01.997155
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper().represent_undefined(AnsibleUndefined()) is not None

# Generated at 2022-06-20 23:53:05.033786
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined) == dumper.represent_bool(False)



# Generated at 2022-06-20 23:53:05.475386
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    AnsibleDumper

# Generated at 2022-06-20 23:53:09.294074
# Unit test for function represent_unicode
def test_represent_unicode():
    representer = yaml.representer.SafeRepresenter
    dumper = AnsibleDumper
    data = u'abc'
    expected = representer.represent_str(dumper, text_type(data))
    actual = represent_unicode(dumper, data)
    assert actual == expected

# Generated at 2022-06-20 23:53:12.156919
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_data(AnsibleUndefined()) is True


# Generated at 2022-06-20 23:53:20.378419
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = {
        'some_key': 'some_value'
    }
    hostvars = HostVars(vars=data)
    inline = yaml.dump(hostvars, Dumper=AnsibleDumper, default_flow_style=False)
    assert inline == '{some_key: some_value}\n'
    block = yaml.dump(hostvars, Dumper=AnsibleDumper, default_flow_style=True)
    assert block == '{some_key: some_value}\n'



# Generated at 2022-06-20 23:53:30.106380
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.parsing.yaml import objects
    import os

    vault = VaultLib([])

    password = os.environ.get('ANSIBLE_VAULT_PASSWORD_FILE', None)
    password1 = VaultSecret(password)

    plaintext = "vault_plaintest_yyy_hello_world"

    plaintext = wrap_var(plaintext)
    ciphertext = vault.encrypt(plaintext, password=[password1])
    test_value = objects.AnsibleVaultEncryptedUnicode(ciphertext)

    dumper = AnsibleDumper()
    result = dumper.represent_data

# Generated at 2022-06-20 23:53:36.619134
# Unit test for function represent_binary
def test_represent_binary():
    """
    Make sure the binary-representation is what we expect,
    including that we don't raise an exception for
    characters greater than the ascii range.
    """
    dumper = AnsibleDumper
    representer = dumper.represent_str
    # Expected output
    b = b'\x00\x01\x02abc\xFF\xFE\x7F'
    expected = b": |-\n"
    expected += b"  AAECYWJj/f8=\n"
    # Make sure we don't raise an exception
    output = representer(dumper, b)
    # Make sure that the output is what we expect
    assert(output == expected)

# Generated at 2022-06-20 23:53:38.345203
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    ad = AnsibleDumper()
    assert isinstance(ad, AnsibleDumper)

# Generated at 2022-06-20 23:53:43.203014
# Unit test for function represent_unicode
def test_represent_unicode():
    for data in (u'a123', u'a\xE9b', u'a\xE9b', u'a\u03B1b', u'a\u03B1b'):
        assert represent_unicode(None, data) == "'%s'" % data



# Generated at 2022-06-20 23:53:48.314775
# Unit test for function represent_hostvars
def test_represent_hostvars():
    rep = AnsibleDumper.represent_hostvars(AnsibleDumper, {u"a": u"b"})
    assert isinstance(rep, yaml.nodes.MappingNode)



# Generated at 2022-06-20 23:53:56.850440
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # Represent an empty HostVars object
    data = HostVars()
    res = yaml.safe_dump(data, default_flow_style=False, Dumper=AnsibleDumper)
    assert res == "---\n{}\n"

    # Represent a HostVarsVars object
    data = HostVarsVars(data, "")
    res = yaml.safe_dump(data, default_flow_style=False, Dumper=AnsibleDumper)
    assert res == "---\n{}\n"

    # Represent a HostVars object with one non-AnsibleUnicode value
    data = HostVars()
    data["foo"] = "bar"
    res = yaml.safe_dump(data, default_flow_style=False, Dumper=AnsibleDumper)

# Generated at 2022-06-20 23:54:07.413932
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = yaml.Dumper()
    data = dict(is_localhost=True,
                inventory_hostname='localhost',
                ansible_hostname='localhost',
                ansible_connection='local')
    hostvars = HostVars(data)
    result = represent_hostvars(dumper, hostvars)
    assert result.startswith('{')
    assert result.endswith('}')
    # Unfortunately, there is no good way to test that the permuted
    # keys are there, so we only check that the value is there in the
    # first key we test for, since we know ansible_connection is always
    # defined.
    assert "'inventory_hostname': 'localhost'" in result
    assert ''''ansible_connection': 'local'\n''' in result



# Generated at 2022-06-20 23:54:10.521625
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    a = AnsibleDumper()
    assert a is not None
    assert a.allow_unicode is True
    assert a.default_flow_style is False
    assert a.indent is 2

# Generated at 2022-06-20 23:54:11.772576
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    if type(AnsibleDumper()) is AnsibleDumper:
        pass

# Generated at 2022-06-20 23:54:24.164481
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # We must use vault object to encrypt something
    from ansible.parsing.vault import VaultEditor
    ve = VaultEditor(None)
    assert not isinstance(ve, VaultEditor)

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    # Fake a vault encrypted string

# Generated at 2022-06-20 23:54:34.560014
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    import ansible.parsing.vault as vault

# Generated at 2022-06-20 23:54:40.781611
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    # GIVEN: An ansible dumper
    ansibleDumper = AnsibleDumper()

    # WHEN: the hostvars class is queried
    hostvars_class = ansibleDumper.representers.get(HostVars)

    # THEN: the hostvars class is an created by AnsibleDumper
    assert hostvars_class



# Generated at 2022-06-20 23:54:46.407057
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hv = HostVars(VarsWithSources())
    assert hv
    assert repr(hv) == '{}', repr(hv)

    hv['foo'] = 'bar'
    assert repr(hv) == "{'foo': 'bar'}", repr(hv)

    del hv['foo']
    assert repr(hv) == '{}', repr(hv)

# Generated at 2022-06-20 23:54:56.291865
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    # Binary string
    assert dumper.represent_binary(dumper, b"\x00\x01") == {'!!binary': 'AAE='}
    assert dumper.represent_binary(dumper, b"\x00\x01".decode('latin-1')) == {'!!binary': 'AAE='}

    # Binary string with length
    assert dumper.represent_binary(dumper, b"\x00\x01", length=5) == {'!!binary': 'AAE='}
    assert dumper.represent_binary(dumper, b"\x00\x01".decode('latin-1'), length=10) == {'!!binary': 'AAE='}

    # Byte string

# Generated at 2022-06-20 23:55:10.559455
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    # Note: in python3, the input string must be unicode. In python2, the input string should be str.
    password = text_type("mypass")
    vault = VaultLib(password)
    ciphertext = vault.encrypt(u"mypassword")
    data = AnsibleVaultEncryptedUnicode(ciphertext)

# Generated at 2022-06-20 23:55:16.757660
# Unit test for function represent_undefined
def test_represent_undefined():
    def test(data, expected_representation):
        dumper = AnsibleDumper()
        representation = dumper.represent_data(data)
        assert representation == expected_representation

    # None is not AnsibleUndefined, so it falls back to SafeDumper's default
    # representation of None.
    test(None, 'null\n...\n')

    # Represents as 'false' since AnsibleUndefined values are assumed false.
    test(AnsibleUndefined(), 'false\n...\n')

# Generated at 2022-06-20 23:55:19.658056
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = HostVars('var1', 'var2')
    assert 'var1: var1' in yaml.dump(hostvars)
    assert 'var2: var2' in yaml.dump(hostvars)

# Generated at 2022-06-20 23:55:21.627958
# Unit test for function represent_undefined
def test_represent_undefined():
    s = AnsibleUndefined()
    data = yaml.dump(s, Dumper=AnsibleDumper)
    assert data == "~\n"

# Generated at 2022-06-20 23:55:33.027166
# Unit test for function represent_hostvars

# Generated at 2022-06-20 23:55:38.860572
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    yaml.add_representer(AnsibleVaultEncryptedUnicode, represent_vault_encrypted_unicode)
    assert yaml.dump({'a': AnsibleVaultEncryptedUnicode(u'!@#$%^&*()_[]')}) == "{a: !vault |\n    !@#$%^&*()_[]\n}"
    assert yaml.dump({'a': AnsibleVaultEncryptedUnicode(u'!@#$%^&*()_[]', u'!@#$%^&*()_[]')}) == "{a: !vault |\n    !@#$%^&*()_[]\n}"

# Generated at 2022-06-20 23:55:40.974370
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(u'foo') == yaml.dump(AnsibleUnicode('foo'))


# Generated at 2022-06-20 23:55:43.364534
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    serialized = dumper.represent_binary(b'\x12\x34')
    assert serialized == "!!binary |\n  EyI=\n", serialized

# Generated at 2022-06-20 23:55:46.089816
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo bar'), Dumper=AnsibleDumper) == 'foo bar\n...\n'



# Generated at 2022-06-20 23:55:50.563402
# Unit test for function represent_unicode
def test_represent_unicode():
    data = {'foo': u'\u2713'}
    dumper = AnsibleDumper(default_flow_style=None)
    assert dumper.represent_dict(data) == yaml.representer.SafeRepresenter.represent_dict(dumper, data)



# Generated at 2022-06-20 23:56:04.520617
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    # Test when data is a dict
    data = {
        b'foo': b'bar',
        'baz': 123,
    }

    # Generate a new AnsibleDumper object
    dumper = AnsibleDumper(data)
    # Serialize dict data to a YAML formatted bytes string
    yaml.dump(data, dumper)

    # Test when data is a list
    data = ['foo', 'bar', 'baz']

    # Generate a new AnsibleDumper object
    dumper = AnsibleDumper(data)
    # Serialize list data to a YAML formatted bytes string
    yaml.dump(data, dumper)



# Generated at 2022-06-20 23:56:12.035483
# Unit test for function represent_undefined
def test_represent_undefined():

    # Representing a StrictUndefined should not raise an exception
    # and instead return some value that will evaluate to a boolean
    # false
    u = AnsibleUndefined(strict=True)
    dumper = AnsibleDumper()
    assert(dumper.represent_undefined(u) is False)

    # Representing a regular Undefined should not raise an exception
    # and instead return some value that will evaluate to a boolean
    # false
    u = AnsibleUndefined()
    dumper = AnsibleDumper()
    assert(dumper.represent_undefined(u) is False)

# Generated at 2022-06-20 23:56:23.326330
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Test simple usage
    enc = AnsibleVaultEncryptedUnicode("my test string")
    if not isinstance(enc._ciphertext, binary_type):
        raise AssertionError("ciphertext should be a binary string")
    data = yaml.dump(enc, Dumper=AnsibleDumper)
    if not isinstance(data, text_type):
        raise AssertionError("should have dumped a text string, not %s" % type(data))
    data = yaml.safe_load(data)
    if not isinstance(data, text_type):
        raise AssertionError("should have loaded a text string, not %s" % type(data))
    if data != "my test string":
        raise AssertionError("loading %s does not match original string" % data)

# Generated at 2022-06-20 23:56:25.576709
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode(u'foobar'), Dumper=AnsibleDumper) == 'foobar\n'



# Generated at 2022-06-20 23:56:29.325696
# Unit test for function represent_unicode
def test_represent_unicode():
    data = AnsibleUnicode(u'represent_unicode')
    expected_result = yaml.representer.SafeRepresenter.represent_str(AnsibleDumper, text_type(data))
    result = AnsibleDumper.represent_unicode(data)
    assert result == expected_result



# Generated at 2022-06-20 23:56:34.967048
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import StrictUndefined
    from ansible.plugins.loader import filter_loader

    data = StrictUndefined('in_data')
    # Filter
    assert 'in_data' == filter_loader.get('default')(data, 'out_data')
    # Representer
    assert represent_undefined(AnsibleDumper, data)

# Generated at 2022-06-20 23:56:44.969420
# Unit test for function represent_undefined
def test_represent_undefined():
    '''
    Test abstract function represent_undefined
    '''

    from ansible.template import Jinja2TemplateFile
    from ansible.template.unsafe_proxy import AnsibleUndefined
    from ansible.module_utils.six import PY3

    if PY3:
        from io import StringIO
    else:
        from StringIO import StringIO

    # Override _fail_with_undefined_error to test if it gets called
    def test_fail():
        raise AssertionError('_fail_with_undefined_error should not be called')

    Jinja2TemplateFile._fail_with_undefined_error = test_fail
    # This will ensure _fail_with_undefined_error happens
    # if the value is Undefined.
    # This happens because Jinja sets __bool__ on StrictUndefined

# Generated at 2022-06-20 23:56:47.932658
# Unit test for function represent_hostvars
def test_represent_hostvars():
    class hvars(HostVars):
        pass

    data = hvars()
    try:
        represent_hostvars(AnsibleDumper(), data)
    except yaml.constructor.ConstructorError:
        return False
    return True


# Generated at 2022-06-20 23:56:50.201745
# Unit test for function represent_undefined
def test_represent_undefined():
    data = AnsibleUndefined()
    AnsibleDumper.add_representer(type(data), represent_undefined)
    result = yaml.dump(data, Dumper=AnsibleDumper)
    assert result == '!ansible.undefined\n'

# Generated at 2022-06-20 23:56:53.413564
# Unit test for function represent_undefined
def test_represent_undefined():
    AnsibleDumper.add_representer(
        AnsibleUndefined,
        represent_undefined,
    )
    assert AnsibleDumper.represent_undefined(AnsibleUndefined()) is True



# Generated at 2022-06-20 23:57:09.051838
# Unit test for function represent_unicode
def test_represent_unicode():
    text = 'text'
    assert yaml.safe_dump(text, default_flow_style=False, Dumper=AnsibleDumper) == \
        "!!python/unicode 'text'\n"

# Generated at 2022-06-20 23:57:19.438544
# Unit test for function represent_unicode
def test_represent_unicode():
    # represent_unicode should not be called for standard unicode
    # strings, this would be an error
    the_str = text_type("a")
    assert not isinstance(the_str, AnsibleUnicode)
    rep = yaml.representer.SafeRepresenter()
    rep.represent_unicode = lambda x, y: "represent_unicode_called"
    assert rep.represent_unicode(the_str) != "represent_unicode_called"

    # Check that it is called for AnsibleUnicode
    my_unicode = AnsibleUnicode("a")
    assert isinstance(my_unicode, AnsibleUnicode)
    assert isinstance(my_unicode, text_type)
    assert rep.represent_unicode(my_unicode) == "represent_unicode_called"

   

# Generated at 2022-06-20 23:57:21.104242
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper
    assert dumper.add_representer == yaml.add_representer

# Generated at 2022-06-20 23:57:28.442003
# Unit test for function represent_unicode
def test_represent_unicode():
    class TestUnicode(object):
        pass

    test_unicode = TestUnicode()
    test_unicode.ansible_value = "hello \n world"
    test_unicode.__unicode__ = lambda self: self.ansible_value

    def test_unicode_str(self):
        return self.ansible_value.encode('utf-8')

    test_unicode.__str__ = test_unicode_str

    dumper = AnsibleDumper
    safe_representer = yaml.representer.SafeRepresenter()

    # We need to set the 'safe' attribute on the parent class
    # for this to work, because the parent class sets that
    # attribute to False for us, when it sets up the parent
    # representers.
    type(safe_representer).safe = True


# Generated at 2022-06-20 23:57:39.150788
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-20 23:57:49.380417
# Unit test for function represent_unicode
def test_represent_unicode():
    '''
    Test the AnsibleDumper (specifically the represent_unicode function),
    which will be used to dump playbook.
    '''
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    # Test on number value
    input_data = "1"
    input_obj = AnsibleUnicode(input_data)
    output_str = AnsibleDumper.represent_unicode(AnsibleDumper, input_obj)
    output_obj = AnsibleLoader(output_str).get_single_data()
    output_data = output_obj
    assert output_data == input_data
    # Test on string value

# Generated at 2022-06-20 23:57:51.320156
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper(), AnsibleDumper)


# Test if the AnsibleDumper class is a subclass of SafeDumper

# Generated at 2022-06-20 23:57:53.996430
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper(None)
    dumper.add_representer(
        AnsibleUndefined,
        represent_undefined,
    )
    from ansible.template.safe_eval import UndefinedError
    import pytest
    with pytest.raises(UndefinedError):
        dumper.represent_undefined(None)

# Generated at 2022-06-20 23:57:57.305525
# Unit test for function represent_binary
def test_represent_binary():
    print(yaml.dump(b'foo', Dumper=AnsibleDumper))
    print(yaml.dump(AnsibleUnsafeBytes(b'foo'), Dumper=AnsibleDumper))



# Generated at 2022-06-20 23:58:00.437071
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import Undefined
    dumper = AnsibleDumper()
    # Make sure the output is a boolean value (True)
    assert dumper.represent_data(Undefined()) == u'true'

# Generated at 2022-06-20 23:58:33.489501
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper

# Generated at 2022-06-20 23:58:36.843506
# Unit test for function represent_undefined
def test_represent_undefined():
    u = AnsibleUndefined()
    a = yaml.Dumper()
    # Note: This is what we are testing
    assert represent_undefined(a, u) == False
    assert repr(u) == 'AnsibleUndefined()'



# Generated at 2022-06-20 23:58:46.805570
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dump_data = dict(
        ansible_ssh_host='10.0.0.1',
        ansible_ssh_port=22,
        ansible_connection='ssh',
        ansible_user='user',
        ansible_password='password',
        ansible_become_password='password',
        ansible_winrm_transport='credssp',
        ansible_become_user='become',
        ansible_winrm_server_cert_validation='ignore',
        ansible_python_interpreter='python',
        ansible_powershell_shell='powershell'
    )
    dumper = AnsibleDumper
    dumper.ignore_aliases = lambda self, data: True
    result = yaml.dump(dump_data, Dumper=dumper)

# Generated at 2022-06-20 23:58:52.575280
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    ciphertext = '$ANSIBLE_VAULT;1.2;AES256;testuser2\n34396262626163666165666163396364303131383763386362383730386433343064356534376265\n64343065313131396663346239376631636266636365336431623463353736336431626263316534\n33643261323734393936336638313665663135633762316432396334626337633364346666643537\n3939\n'
    AnsibleVaultEncryptedUnicode(ciphertext, 'testuser2')



# Generated at 2022-06-20 23:59:03.300660
# Unit test for function represent_hostvars
def test_represent_hostvars():
    class Obj:
        def __init__(self, val):
            self.val = val

        def __repr__(self):
            return repr(self.val)

    hostvars = HostVars(name=Obj('hostvars.name'))
    hostvars.host_specific_vars = HostVarsVars(name=Obj('hostvars.host_specific_vars.name'))
    hostvars.get_vars()['test'] = Obj('hostvars.get_vars().test')
    hostvars.get_vars()['test2'] = 'None'

    # Represent as a dict
    dump = yaml.dump({'test': hostvars}, Dumper=AnsibleDumper)

    # Verify

# Generated at 2022-06-20 23:59:05.549514
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    result = dumper.represent_binary('test')
    assert result == "!!binary \n  dGVzdA==\n"

# Generated at 2022-06-20 23:59:09.771515
# Unit test for function represent_hostvars
def test_represent_hostvars():
    import ansible.vars.hostvars
    dumper = AnsibleDumper
    hv = ansible.vars.hostvars.HostVars({'a': 1})
    assert dumper.represent_hostvars(dumper, hv) == "!hostvars {'a': 1}"

# Generated at 2022-06-20 23:59:12.440483
# Unit test for function represent_hostvars
def test_represent_hostvars():
    vars = HostVars(host_name='foo')
    vars['bar'] = 42
    dumped = yaml.dump(dict(vars), Dumper=AnsibleDumper)
    assert dumped == '{bar: 42}\n'

# Generated at 2022-06-20 23:59:18.052915
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():

    # Assert SafeDumper is the super class of AnsibleDumper
    assert issubclass(AnsibleDumper, SafeDumper), 'AnsibleDumper should be subclass of SafeDumper'

    # Assert the constructor of class AnsibleDumper
    assert AnsibleDumper.add_representer is not None, 'Failed to import the member function add_representer from class AnsibleDumper'



# Generated at 2022-06-20 23:59:20.349449
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    try:
        ad = AnsibleDumper()
    except Exception:
        assert False
    else:
        assert True