

# Generated at 2022-06-20 23:50:43.434377
# Unit test for function represent_binary
def test_represent_binary():
    test_data = b'foo'
    expected = "'foo'"

    ad = AnsibleDumper()
    actual = ad.represent_binary(test_data)

    assert actual == expected

# Generated at 2022-06-20 23:50:45.310390
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    d = AnsibleDumper(None, default_flow_style=False)
    assert isinstance(d, AnsibleDumper)

# Generated at 2022-06-20 23:50:50.096989
# Unit test for function represent_undefined
def test_represent_undefined():
    class dummy_class:
        def __init__(self):
            self.dummy_val = None

    def dummy_function():
        pass

    # Ensure _fail_with_undefined_error gets called
    dumper = AnsibleDumper
    yaml_str = dumper.represent_undefined(dumper, AnsibleUndefined)
    yaml_str = dumper.represent_undefined(dumper, dummy_class())
    yaml_str = dumper.represent_undefined(dumper, dummy_function)

# Generated at 2022-06-20 23:50:50.706204
# Unit test for function represent_hostvars
def test_represent_hostvars():
    pass

# Generated at 2022-06-20 23:50:52.587307
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    from ansible.module_utils.common.yaml import AnsibleDumper



# Generated at 2022-06-20 23:50:54.352486
# Unit test for function represent_binary
def test_represent_binary():
    assert isinstance(yaml.dump(binary_type(b"hello")), text_type)



# Generated at 2022-06-20 23:50:58.039691
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, 'test') == yaml.representer.SafeRepresenter.represent_str(None, text_type('test'))


# Generated at 2022-06-20 23:51:01.670694
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper

    assert(dumper.represent_binary(dumper, b'foo\nbar\nbaz') == '!!binary |\n  Zm9vCmJhcgpiYXo=\n')



# Generated at 2022-06-20 23:51:11.572943
# Unit test for function represent_unicode
def test_represent_unicode():
    contents = {'a': 123, 'b': 'asd', 'c': [u'a', u'b', u'\xa9']}
    dumper = yaml.dumper.SafeDumper
    dumper.add_representer(
        AnsibleUnicode,
        represent_unicode,
    )
    dumper.represent_dict = yaml.representer.SafeRepresenter.represent_dict
    dumper.represent_str = yaml.representer.SafeRepresenter.represent_str
    dumper.represent_unicode = yaml.representer.SafeRepresenter.represent_unicode
    dumpeddata = yaml.dump(contents, Dumper=dumper)
    assert dumpeddata == '{a: 123, b: asd, c: [a, b, \xa9]}\n...\n'

# Generated at 2022-06-20 23:51:21.931772
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-20 23:51:25.131816
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    AnsibleDumper()


# Generated at 2022-06-20 23:51:32.908254
# Unit test for function represent_hostvars
def test_represent_hostvars():

    h = HostVars()
    h['testvar'] = "TestHostVars"
    h.update([('testvar2', 'Test2HostVars')])
    h.add_source('anothertest', 'TestHostVars2')

    obj = {'objkey': h}
    output = yaml.dump(obj, Dumper=AnsibleDumper)
    output2 = yaml.dump(obj, Dumper=AnsibleDumper, default_flow_style=False)

    assert(output == output2)

# Generated at 2022-06-20 23:51:43.848172
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = yaml.SafeDumper
    # Need to create an AnsibleUnicode object
    ans_unicode_obj = AnsibleUnicode("text")

    # The dumped representation is expected to be a unicode string
    dumped_str = repr(ans_unicode_obj)

    # These are the arguments passed in to this function when called
    # through the add_representer hook.
    # The self argument is the dumper object
    # The data argument is the AnsibleUnicode object
    represent_unicode(dumper, ans_unicode_obj)

    # Assert that the above function call results in an expected output
    assert dumped_str == '\'text\': {}'



# Generated at 2022-06-20 23:51:47.899629
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    # Check if type of AnsibleDumper(None) is AnsibleDumper
    assert isinstance(AnsibleDumper(None), AnsibleDumper)
    # Check if it can create a AnsibleDumper instance with a flow_style parameter
    assert isinstance(AnsibleDumper(None, None), AnsibleDumper)


# Generated at 2022-06-20 23:51:51.222440
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    ansible_dumper = AnsibleDumper(indent=4, allow_unicode=True)
    assert isinstance(ansible_dumper, AnsibleDumper)

# Generated at 2022-06-20 23:51:55.145487
# Unit test for function represent_undefined
def test_represent_undefined():
    d = AnsibleDumper()
    d.add_representer(AnsibleUndefined, represent_undefined)
    assert d.represent_data(AnsibleUndefined()) is True


# Generated at 2022-06-20 23:52:06.098290
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    aveuu = AnsibleVaultEncryptedUnicode("$ANSIBLE_VAULT;1.1;AES256", "asdf")
    test_data = {'test': aveuu}
    actual = yaml.dump(test_data)
    expected = "{test: !vault |\n  $ANSIBLE_VAULT;1.1;AES256\n  6133663366416461343164396533356330643431336564353863376333616137313961656633363466\n  3839613031613164353334336134393634653561663231373133663831626364626638363562383930\n  63663161386438373764383338643937333061\n}"

# Generated at 2022-06-20 23:52:08.933274
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    assert "test: data" == dumper.represent_hostvars(AnsibleMapping({'test': 'data'}))



# Generated at 2022-06-20 23:52:12.600259
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    # Tests require libyaml which is not installed by default,
    # so this is just a placeholder.
    data = b'foo'
    actual = dumper.represent_binary(dumper, data)
    expected = "!binary |\n  Zm9v\n"
    assert actual == expected

# Generated at 2022-06-20 23:52:13.982899
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper.represent_undefined(None, AnsibleUndefined) is True

# Generated at 2022-06-20 23:52:20.539291
# Unit test for function represent_undefined
def test_represent_undefined():
    mydumper = AnsibleDumper()
    mydumper.add_representer(AnsibleUndefined, represent_undefined)

    a = AnsibleUndefined()
    a = bool(a)
    result = mydumper.represent_data(a)
    assert result == "null\n"

# Generated at 2022-06-20 23:52:29.622320
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper
    data = AnsibleVaultEncryptedUnicode(u'blah')
    value = dumper.represent_vault_encrypted_unicode(dumper, data)
    assert value == u'!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          323462363339663034643931323162303365643663161396132333962333239383763323532653234\n          6531373331633961303538333862653837363530656133353166623237336630376538646332\n'


# Generated at 2022-06-20 23:52:32.856326
# Unit test for function represent_hostvars
def test_represent_hostvars():
    import pytest
    assert represent_hostvars(AnsibleDumper, HostVars(dict(foo='bar'))) == represent_hostvars(AnsibleDumper, dict(foo='bar'))



# Generated at 2022-06-20 23:52:37.486824
# Unit test for function represent_unicode
def test_represent_unicode():
    result = yaml.dump(["test", dict(test=dict(test=u'string'))], Dumper=AnsibleDumper)
    assert result == '- test\n- test:\n    test: string\n'

    result = yaml.dump({'test': u'string'}, Dumper=AnsibleDumper)
    assert result == 'test: string\n'

# Generated at 2022-06-20 23:52:49.058281
# Unit test for function represent_undefined
def test_represent_undefined():
    '''
    Unit test for function represent_undefined
    '''
    class TestUndefined(object):
        def __bool__(self):
            return False

        def __nonzero__(self):
            return False

    undefined = TestUndefined()
    dumper = AnsibleDumper()

    # Check that undefined is represented as False
    assert dumper.represent_data(undefined) == dumper.represent_bool(False)

    # Check that an exception is raised when undefined is true
    class TestUndefined_True(TestUndefined):
        def __bool__(self):
            return True

        def __nonzero__(self):
            return True

    undefined_true = TestUndefined_True()
    try:
        dumper.represent_data(undefined_true)
    except:
        pass

# Generated at 2022-06-20 23:53:00.674523
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = AnsibleVaultEncryptedUnicode(u'$ANSIBLE_VAULT;1.1;AES256\n35306433376664393537646130373463626234613639363738636561326263656538663561306633\n66343937366334623162303463376365313961623639373362340a37333733653566376338373034\n61383239643035393636373461306534643538313563353533313935306136616362346139393630\n653165613733646262600a')

# Generated at 2022-06-20 23:53:04.139297
# Unit test for function represent_binary
def test_represent_binary():
    yaml_data = b'foo'
    assert yaml.dump(yaml_data, Dumper=AnsibleDumper) == b'!!binary |\n  Zm9v\n'


# Generated at 2022-06-20 23:53:11.944546
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    f = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\n6330663761613866373330353365320d3963353363643066303433633165363439623562366164310d\n')
    output = yaml.dump(f, Dumper=AnsibleDumper)
    assert(output == '!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          6330663761613866373330353365320d3963353363643066303433633165363439623562366164310d\n')

# Generated at 2022-06-20 23:53:21.262076
# Unit test for function represent_unicode
def test_represent_unicode():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_text

    a_unicode = u'a unicode string: \u5b54\u5b50'
    the_str = a_unicode.encode('utf-8')
    data = {'a': a_unicode}
    out = StringIO()
    AnsibleDumper(stream=out).represent_dict(data)
    result = out.getvalue()
    assert result == to_text(u"{a: 'a unicode string: \u5b54\u5b50'}\n")



# Generated at 2022-06-20 23:53:24.698385
# Unit test for function represent_binary
def test_represent_binary():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText, AnsibleUnsafeBytes
    assert yaml.dump(AnsibleUnsafeBytes(b'hello')).strip() == "!!binary \"aGVsbG8=\""
    assert yaml.dump(AnsibleUnsafeText('hello')).strip() == "!!binary \"aGVsbG8=\""