

# Generated at 2022-06-20 23:50:45.022375
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    assert dumper.represent_undefined(dumper, AnsibleUndefined) is True

# Support serializing NaN, Infinity, and -Infinity
# See: http://pyyaml.org/attachment/ticket/160/use_inf_with_pyyaml.patch

# Generated at 2022-06-20 23:50:51.493116
# Unit test for function represent_unicode
def test_represent_unicode():

    # Create the instance of AnsibleDumper under test
    dumper = AnsibleDumper()

    # Ensure the representer operates as expected
    test_string = u'a\u1234'
    expected_result = u"'a\u1234'"
    actual_result = dumper.represent_unicode(test_string)
    assert actual_result == expected_result, 'Failed to dump unicode string'



# Generated at 2022-06-20 23:50:59.185775
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    ansible_dumper = yaml.representer.UnsafeRepresenter()
    ansible_dumper.add_representer(AnsibleVaultEncryptedUnicode, represent_vault_encrypted_unicode)

# Generated at 2022-06-20 23:51:09.739907
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv_data = """
    [all]
    localhost
    """
    inv_source = loader.load(inv_data, variable_manager=VariableManager())
    inventory = InventoryManager(loader=loader, sources=[inv_source])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager.set_host_variable(
        host='localhost',
        varname='foo',
        value='world'
    )

    host_vars = HostVars(
        inventory=inventory,
        variable_manager=variable_manager,
    )

# Generated at 2022-06-20 23:51:16.536108
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    '''Test function represent_vault_encrypted_unicode'''
    input_str = text_type('vault_string')
    input_str_unicode = AnsibleVaultEncryptedUnicode(input_str)
    input_str_unicode._ciphertext = 'ciphertext'

    output = yaml.dump(input_str_unicode, Dumper=AnsibleDumper)
    assert output == '!vault |\n  ciphertext\n'



# Generated at 2022-06-20 23:51:18.524620
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper
    assert hasattr(AnsibleDumper, 'add_representer')

# Generated at 2022-06-20 23:51:28.185020
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    import base64
    from ansible.parsing.vault import VaultLib

    v = VaultLib(None)
    ciphertext = v.encrypt(b'hello world')
    ciphertext_2 = base64.b64encode(ciphertext)

    # make sure the yaml parser doesn't barf when a vaulted string
    # is encountered in a dump
    ciphertext = AnsibleVaultEncryptedUnicode(ciphertext_2)
    dump =  yaml.dump(ciphertext, Dumper=AnsibleDumper)
    #print(dump)



# Generated at 2022-06-20 23:51:30.277575
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper, yaml.representer.SafeRepresenter)


# Generated at 2022-06-20 23:51:32.293228
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    assert dumper.represent_data(AnsibleUndefined) is True

# Generated at 2022-06-20 23:51:44.481520
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib("ansible")
    plaintext = vault.encrypt("this is a secret")
    encrypted_unicode = AnsibleVaultEncryptedUnicode(plaintext)
    # If the function represent_vault_encrypted_unicode doesn't work,
    # an exception will be thrown.

# Generated at 2022-06-20 23:51:47.221611
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper()



# Generated at 2022-06-20 23:51:56.892227
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template.safe_eval import _fail_with_undefined_error
    from ansible.template.safe_eval import UndefinedError
    dumper = yaml.Dumper(width=9999)
    dumper.org_represent_undefined = dumper.represent_undefined
    dumper.represent_undefined = represent_undefined
    res = dumper.represent_data(AnsibleUndefined())
    undef = yaml.load(res)
    assert undef is True

    try:
        _fail_with_undefined_error(res, 'somevar', dumper)
    except UndefinedError:
        pass

# Generated at 2022-06-20 23:51:58.284380
# Unit test for function represent_hostvars
def test_represent_hostvars():
    ''' represent_hostvars needs to be tested in serializer '''
    pass

# Generated at 2022-06-20 23:52:01.081506
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    ansible_dumper_obj = AnsibleDumper()
    assert hasattr(ansible_dumper_obj, 'add_representer')

# Generated at 2022-06-20 23:52:11.119214
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():

    # Prepare data
    plaintext = 'test'
    vault_obj = AnsibleVaultEncryptedUnicode(plaintext.encode(), b'12345')
    vault_obj._ciphertext = b'U2FsdGVkX1/p0nWGnwzgv/Czdw1p/F8WZMmuBPvQeXo='
    expected_ciphertext = 'U2FsdGVkX1/p0nWGnwzgv/Czdw1p/F8WZMmuBPvQeXo='

    # Prepare yaml dumper
    dumper = AnsibleDumper()

    # Call function represent_vault_encrypted_unicode

# Generated at 2022-06-20 23:52:19.972797
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import Templar
    templar = Templar(loader=None)
    dumper = AnsibleDumper
    '''
    _fail_with_undefined_error takes an argument 'obj' which is passed in
    as the second argument to the ErrorReporter constructor.
    So, this function tests that the object passed in
    to _fail_with_undefined_error is of type AnsibleUndefined.
    '''
    assert isinstance(templar._fail_with_undefined_error(obj=AnsibleUndefined()), AnsibleUndefined)

# Generated at 2022-06-20 23:52:27.496882
# Unit test for function represent_hostvars
def test_represent_hostvars():
    fake_yaml_tag = yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG
    yaml.SafeDumper.add_representer(
        type(None),
        lambda dumper, value: dumper.represent_scalar(fake_yaml_tag, u'')
    )

    fake_hostvars_data = {
        b'foo': 'bar',
        'baz': b'qux',
        'quux': None,
    }
    fake_dict_data = {
        'baz': b'qux',
        'foo': 'bar',
        'quux': '',
    }


# Generated at 2022-06-20 23:52:33.928493
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import AnsibleUndefined
    from ansible.template.safe_eval import UndefinedError

    dumper = AnsibleDumper()
    # represent_undefined will use bool on value which will call
    # _fail_with_undefined_error which will raise UndefinedError
    from ansible.template import UndefinedError
    try:
        dumper.represent_undefined(AnsibleUndefined())
    except UndefinedError as e:
        assert isinstance(e, UndefinedError)

# Generated at 2022-06-20 23:52:44.426886
# Unit test for function represent_binary
def test_represent_binary():
    dumper = yaml.SafeDumper
    dumper.add_representer(
        AnsibleUnsafeText,
        represent_unicode,
    )

    dumper.add_representer(
        AnsibleUnsafeBytes,
        represent_binary,
    )

    dumped_data = yaml.dump(b'\xe9', dumper=dumper)
    assert dumped_data == "!!binary |\n  w5c="

    dumped_data = yaml.dump(u'\xe9', dumper=dumper)
    assert dumped_data == "!!python/unicode '\\xe9'"

    dumped_data = yaml.dump(u'\xe9', dumper=dumper)
    assert dumped_data == "!!python/unicode '\\xe9'"

# Generated at 2022-06-20 23:52:48.506628
# Unit test for function represent_unicode
def test_represent_unicode():
    text = u'\u2713 unicode check mark'
    assert text.encode('utf-8') == yaml.safe_dump(text, default_flow_style=False, Dumper=AnsibleDumper)


# Generated at 2022-06-20 23:52:52.759916
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    result = yaml.dump({'key': 'value'}, Dumper=AnsibleDumper)
    assert result == '{key: value}\n'

# Generated at 2022-06-20 23:53:04.702313
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-20 23:53:09.665755
# Unit test for function represent_binary
def test_represent_binary():
    data = u'\x00\x01\x02\x03'
    # The second argument is the tag,
    # which could be u'tag:yaml.org,2002:binary', while
    # yaml.org,2002:binary is the prefix
    expected = u"!!binary |-\n  AAAEBAQ="
    result = AnsibleDumper.represent_binary(None, data)
    assert result == expected
    print(result)



# Generated at 2022-06-20 23:53:21.176961
# Unit test for function represent_undefined
def test_represent_undefined():
    # Make sure that we see no errors when convert an undefined value to YAML
    # Just check for an exception on dump and loads
    undef = AnsibleUndefined("this is a test")
    assert undef is not None
    # due to the AnsibleDumper class, representing the undefined value
    # will cause it to raise an exception
    try:
        yaml.dump(undef, AnsibleDumper)
        assert False, "the AnsibleDumper class did not raise an exception"
    except AnsibleUndefinedVariable:
        pass
    try:
        yaml.load(yaml.dump(undef, AnsibleDumper))
        assert False, "the AnsibleDumper class did not raise an exception"
    except yaml.constructor.ConstructorError:
        pass

# Generated at 2022-06-20 23:53:27.895171
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    '''
    These tests are written to test the behavior of the yaml representer,
    rather than the function in this module.
    '''
    class FakeRepr:
        def represent_scalar(self, tag, value, style=None):
            assert tag == u'!vault'

# Generated at 2022-06-20 23:53:35.878412
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-20 23:53:40.705962
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = {
        'test_host': {
            'test_var': 'test_value',
        },
    }
    expected = text_type(yaml.dump(data, Dumper=AnsibleDumper))
    assert HostVars(data).dump(AnsibleDumper) == expected



# Generated at 2022-06-20 23:53:46.940789
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    string = 'foo: bar\n'
    data = yaml.load(string)
    assert data == {u'foo': u'bar'}

    data = yaml.load(string, yaml.SafeLoader)
    assert data == {u'foo': u'bar'}

    data = yaml.load(string, AnsibleDumper)
    assert data == {u'foo': u'bar'}



# Generated at 2022-06-20 23:53:49.509900
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(binary_type(b'test'), Dumper=AnsibleDumper) == '!!binary |-\ntest\n'

# Generated at 2022-06-20 23:53:57.496756
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-20 23:54:05.491756
# Unit test for function represent_unicode
def test_represent_unicode():
    from ansible.module_utils.common.yaml import AnsibleUnicode, AnsibleDumper
    from ansible.template import Templar
    t = Templar(None, loader=None)
    assert yaml.dump(t.template('{{ foo }}', dict(foo=AnsibleUnicode(u'bar')), fail_on_undefined=False), Dumper=AnsibleDumper) == '"bar"\n'

# Generated at 2022-06-20 23:54:10.378151
# Unit test for function represent_hostvars
def test_represent_hostvars():
    ref = AnsibleDumper(None)

# Generated at 2022-06-20 23:54:11.264723
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    a = AnsibleDumper()

# Generated at 2022-06-20 23:54:12.242274
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper, type)

# Generated at 2022-06-20 23:54:16.527033
# Unit test for function represent_unicode
def test_represent_unicode():
    obj = AnsibleUnicode(u'test')
    dumped_obj = SafeDumper().represent_unicode(obj)
    assert dumped_obj == u'test'



# Generated at 2022-06-20 23:54:27.603217
# Unit test for function represent_unicode
def test_represent_unicode():
    # Test input text without unicode
    text = text_type('input text without unicode')
    dumper = yaml.dumper.SafeDumper
    ansible_dumper = AnsibleDumper
    yaml.add_representer(text_type, represent_unicode, Dumper=dumper)
    yaml_output = yaml.dump(text, Dumper=dumper)
    assert yaml_output == text
    # output of ansible should be the same as yaml output
    ansible_output = yaml.dump(text, Dumper=ansible_dumper)
    assert ansible_output == yaml_output
    # Test input text with unicode
    text = text_type('測試')

# Generated at 2022-06-20 23:54:35.469276
# Unit test for function represent_undefined
def test_represent_undefined():
    # When undefined value is found in data
    # the represent_undefined function will return a boolean
    # value. The bool function will evaluate to False
    # This will trigget the _fail_with_undefined_error
    # exception in the base class of AnsibleDumper
    def create_dumper(v):
        class TestDumper(AnsibleDumper):
            def _fail_with_undefined_error(self):
                return v

        return TestDumper()

    assert create_dumper(False).represent_undefined(AnsibleUndefined) == False
    assert create_dumper(True).represent_undefined(AnsibleUndefined) == True



# Generated at 2022-06-20 23:54:38.721384
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    ansible_dumper = AnsibleDumper()
    assert not ansible_dumper.ignore_aliases
    assert not ansible_dumper.ignore_aliases

# Generated at 2022-06-20 23:54:41.951231
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert represent_hostvars(AnsibleDumper, HostVars(dict(a=1, b=2))) == '{a: 1, b: 2}'



# Generated at 2022-06-20 23:54:46.677535
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper) is False
    assert yaml.dump({'test': AnsibleUndefined()}, Dumper=AnsibleDumper) is False
    assert yaml.dump({'test': [AnsibleUndefined()]}, Dumper=AnsibleDumper) is False

# Generated at 2022-06-20 23:54:51.130365
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper

# Generated at 2022-06-20 23:54:59.637867
# Unit test for function represent_hostvars
def test_represent_hostvars():
    import os
    import unittest
    from ansible.parsing.yaml.loader import AnsibleLoader

    test_file = os.path.join(os.path.dirname(__file__), 'hostvars.yml')

    with open(test_file) as f:
        data = f.read()

    try:
        # pyyaml._yaml.CParserError: while parsing a block scalar
        #   in "<unicode string>", line 14, column 14
        # expected '<document start>', but found '<block sequence start>'
        #   in "<unicode string>", line 1, column 1:
        #     ---
        data_parsed_orig = yaml.load(data)
        assert False
    except yaml.YAMLError:
        pass


# Generated at 2022-06-20 23:55:01.273088
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert represent_hostvars(AnsibleDumper, HostVars()) == u'{}\n...\n'

# Generated at 2022-06-20 23:55:12.680376
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    '''
    Make sure the representer for AnsibleVaultEncryptedUnicode returns valid YAML.
    '''
    import ansible.parsing.vault as vault

    yaml_obj = AnsibleVaultEncryptedUnicode(vault.encrypt('foo bar\n', None, 1))
    yaml_text = yaml.dump(yaml_obj, Dumper=AnsibleDumper, default_flow_style=False)

# Generated at 2022-06-20 23:55:16.572379
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode(u"foo"), Dumper=AnsibleDumper) == 'foo\n...\n'
    assert yaml.dump(AnsibleUnsafeText("foo"), Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-20 23:55:22.179317
# Unit test for function represent_binary
def test_represent_binary():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.errors import AnsibleError
    try:
        dummy = b'foo'
        AnsibleDumper.add_representer(
            type(dummy),
            yaml.representer.SafeRepresenter.represent_binary,
        )
    except AnsibleError:
        raise AssertionError('AnsibleDumper.add_representer test failed')


if __name__ == '__main__':
    test_represent_binary()

# Generated at 2022-06-20 23:55:26.555498
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    s = AnsibleUnicode('abc')
    result = yaml.representer.SafeRepresenter.represent_str(dumper, s)
    assert result == "abc\n...\n"



# Generated at 2022-06-20 23:55:30.835450
# Unit test for function represent_undefined
def test_represent_undefined():
    data = AnsibleUndefined()
    # Because represent_undefined returns the boolean result of
    # the data object, the following test makes sure that AnsibleUndefined
    # is evaluated to False
    assert not yaml.dump(data, Dumper=AnsibleDumper)

# Generated at 2022-06-20 23:55:32.182920
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert hasattr(AnsibleDumper, 'add_representer')

# Generated at 2022-06-20 23:55:33.999868
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    dumper.represent_undefined(AnsibleUndefined('value'))

# Generated at 2022-06-20 23:55:40.508768
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    dumper.represent_binary(b'foo\nbar') == yaml.representer.SafeRepresenter.represent_binary(dumper, b'foo\nbar')

# Generated at 2022-06-20 23:55:41.702221
# Unit test for function represent_undefined
def test_represent_undefined():
    assert represent_undefined(None, AnsibleUndefined)



# Generated at 2022-06-20 23:55:45.311689
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    a_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode('blah')
    dumper = AnsibleDumper()
    assert dumper.represent_vault_encrypted_unicode(a_vault_encrypted_unicode) == '!vault |\n          %s' % a_vault_encrypted_unicode._ciphertext.decode()



# Generated at 2022-06-20 23:55:54.559969
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    encrypted_text_string = "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          31623361343634626563336166666336366332363333633333337646136653962613963633566\n          6530653933376130636330303232346538316161333166373361303966333866616539653066\n          37353430656461626533669d"
    test_obj = AnsibleVaultEncryptedUnicode(encrypted_text_string)
    assert(yaml.dump(test_obj) == encrypted_text_string)

# Generated at 2022-06-20 23:55:59.288031
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    result = represent_vault_encrypted_unicode(AnsibleDumper, AnsibleVaultEncryptedUnicode(b'0183029b698adf4dcd4d'))
    assert result.endswith('|\n    0183029b698adf4dcd4d')


dumper = AnsibleDumper



# Generated at 2022-06-20 23:56:07.198493
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # Without this patch, the following data will throws exception with
    # error message, 'set() argument must be a mapping'.
    data_1 = {'_failed': set([u"127.0.0.1"])}
    data_2 = {'_hostvars': {u"127.0.0.1": {}}}

# Generated at 2022-06-20 23:56:14.927002
# Unit test for function represent_hostvars
def test_represent_hostvars():
    my_dict = {'hello': 'world', 'spam': 'eggs', 'foo': 'bar'}
    my_hostvars = HostVars(my_dict)

    # Note that we do not use HostVars here, and
    # so we are testing the represent_dict functionality
    assert represent_hostvars(AnsibleDumper, my_hostvars) == represent_hostvars(AnsibleDumper, my_hostvars)



# Generated at 2022-06-20 23:56:18.146388
# Unit test for function represent_unicode
def test_represent_unicode():
    """Ensure that we can represent unicode values."""
    dumper = AnsibleDumper()
    ustr = text_type('\u2740')
    assert ustr == dumper.represent_unicode(ustr)



# Generated at 2022-06-20 23:56:23.325919
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper.is_safe_attribute(None, '_ansible_ignore_errors')
    assert AnsibleDumper.is_safe_attribute(None, '_ansible_keep_prior_items')
    assert AnsibleDumper.is_safe_attribute(None, '_ansible_keep_remote_files')
    assert AnsibleDumper.is_safe_attribute(None, '_ansible_new_file_attributes')
    assert AnsibleDumper.is_safe_attribute(None, '_ansible_no_log')
    assert AnsibleDumper.is_safe_attribute(None, '_ansible_no_log_values')
    assert AnsibleDumper.is_safe_attribute(None, '_ansible_only_if_changed')
    assert AnsibleDumper.is_safe_attribute

# Generated at 2022-06-20 23:56:28.940592
# Unit test for function represent_unicode
def test_represent_unicode():
    from ansible.module_utils.six import StringIO
    stream=StringIO()
    AnsibleDumper.add_multi_representer(unicode, AnsibleDumper.represent_unicode)
    u = u'Hello\u20ac'
    yaml.dump(u, stream=stream)
    print(stream.getvalue())
    assert stream.getvalue() == u'Hello\x0a' # Euro symbol is unprintable on the terminal. 



# Generated at 2022-06-20 23:56:45.190348
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    s = u'fooé'
    assert dumper.represent_unicode(dumper, s) == dumper.represent_scalar('tag:yaml.org,2002:str', u'fooé')
    s = AnsibleUnsafeText(u'fooé')
    assert dumper.represent_unicode(dumper, s) == dumper.represent_scalar('tag:yaml.org,2002:str', u'fooé')
    assert dumper.represent_unicode(dumper, s) != dumper.represent_scalar('tag:yaml.org,2002:str', 'fooé')



# Generated at 2022-06-20 23:56:47.132120
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(b'foo', Dumper=AnsibleDumper) == '!!binary |-\n  Zm9v\n'

# Generated at 2022-06-20 23:56:51.357612
# Unit test for function represent_unicode
def test_represent_unicode():
    data = AnsibleUnicode('foo')

    # Can't use assertEqual(x, y) here because we might be comparing
    # unicode and a byte string, which are not equal in Python 2.7
    assert AnsibleDumper.represent_unicode(None, data) == yaml.representer.SafeRepresenter.represent_str(None, text_type(data))


# Generated at 2022-06-20 23:57:00.698747
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.loader import AnsibleLoader
    hv = HostVars(dict(foo='bar'))
    assert hv == AnsibleLoader('foo: bar').get_single_data()
    hvv = HostVarsVars(hv, dict(bar='foo'))
    assert hvv == AnsibleLoader('foo: bar\nbar: foo').get_single_data()
    hvv = HostVarsVars(hv, dict(bar='foo', baz=dict(biff='boff')))
    assert hvv == AnsibleLoader('foo: bar\nbar: foo\nbaz:\n  biff: boff').get_single_data()



# Generated at 2022-06-20 23:57:06.747614
# Unit test for function represent_undefined
def test_represent_undefined():
    y = AnsibleDumper()

    class AnsibleStrictUndefined(AnsibleUndefined):
        pass

    y.add_representer(
        AnsibleStrictUndefined,
        represent_undefined,
    )

    try:
        y.represent_data({
            "key": AnsibleStrictUndefined(obj=None, j2_src=None),
        })
    except Exception as e:
        assert isinstance(e, AnsibleUndefined)

# Generated at 2022-06-20 23:57:08.461481
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert(bool(AnsibleDumper))


# vim: set et ts=4 sw=4:

# Generated at 2022-06-20 23:57:09.607190
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper.represent_undefined(None, None) == 0

# Generated at 2022-06-20 23:57:11.914509
# Unit test for function represent_hostvars
def test_represent_hostvars():

    # Create an item of type HostVars
    item = HostVars({"foo": "bar"})
    yaml.dump(item, sys.stdout, Dumper=AnsibleDumper)

# Generated at 2022-06-20 23:57:13.402887
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper(indent=1, width=1, default_flow_style=1)

# Generated at 2022-06-20 23:57:22.833994
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(u'foo', Dumper=AnsibleDumper) == "foo\n...\n"
    assert yaml.dump([u'foo'], Dumper=AnsibleDumper) == "- foo\n"
    assert yaml.dump({u'foo': u'bar'}, Dumper=AnsibleDumper) == "{foo: bar}\n"
    assert yaml.dump({u'foo': {u'bar': u'baz'}}, Dumper=AnsibleDumper) == "{foo: {bar: baz}}\n"
    assert yaml.dump([{u'foo': u'bar'}], Dumper=AnsibleDumper) == "- {foo: bar}\n"



# Generated at 2022-06-20 23:57:44.287400
# Unit test for function represent_unicode
def test_represent_unicode():

    dumper = yaml.dumper.Dumper()

    data = u'unicóde'
    desired_result = u'"unicóde"'
    assert represent_unicode(dumper, data) == desired_result


# Generated at 2022-06-20 23:57:46.252001
# Unit test for function represent_undefined
def test_represent_undefined():
    assert(yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper) == '')

# Generated at 2022-06-20 23:57:46.897424
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper

# Generated at 2022-06-20 23:57:53.868932
# Unit test for function represent_binary
def test_represent_binary():
    representer = AnsibleDumper()
    repr_string = representer.represent_binary(b'foo')
    assert repr_string == '!!binary\nfoo', repr_string

    repr_string = representer.represent_binary(b'foo\nbar')
    assert repr_string == '!!binary\nfoo\nbar', repr_string

    repr_string = representer.represent_binary(b'\x00\x000123\x00')
    assert repr_string == '!!binary |\n  \x00\x000123\x00\n', repr_string

    repr_string = representer.represent_binary(b'foo\nbar\n')
    assert repr_string == '!!binary\nfoo\nbar\n', repr_string



# Generated at 2022-06-20 23:58:03.871019
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    # There is no constructor, so we create an instance from class AnsibleDumper
    dumper = AnsibleDumper()
    # Assert the class attributes
    assert dumper.default_style == '"'
    assert dumper.default_flow_style is False
    assert dumper.sort_keys == True
    # Assert the class methods
    assert dumper.add_representer(AnsibleUnsafeText, represent_unicode) == None
    assert dumper.add_representer(AnsibleMapping, yaml.representer.SafeRepresenter.represent_dict) == None
    assert dumper.add_representer(AnsibleUndefined, represent_undefined) == None
    assert dumper.add_representer(AnsibleSequence, yaml.representer.SafeRepresenter.represent_list) == None
    assert d

# Generated at 2022-06-20 23:58:08.286471
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    class FakeVaultEncryptedUnicode:
        _ciphertext = u'vault-to-be-represented'.encode('utf-8')
    data = FakeVaultEncryptedUnicode()
    assert represent_vault_encrypted_unicode(None, data)

# Generated at 2022-06-20 23:58:10.550971
# Unit test for function represent_unicode
def test_represent_unicode():
    value = repr(yaml.dump({'foo': AnsibleUnicode('bar')}, Dumper=AnsibleDumper))
    assert value == "{foo: bar}\n"



# Generated at 2022-06-20 23:58:11.705457
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    w = AnsibleDumper()
    assert w is not None

# Generated at 2022-06-20 23:58:12.929507
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode("hello") == 'hello'

# Generated at 2022-06-20 23:58:16.422701
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()
    encoded = AnsibleVaultEncryptedUnicode('foo')
    assert dumper.represent_data(encoded) == '!vault |\n  $ANSIBLE_VAULT;1.1;AES256\n  626165626f6f\n'

# Generated at 2022-06-20 23:59:12.425847
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert(AnsibleDumper)

# Generated at 2022-06-20 23:59:18.787564
# Unit test for function represent_hostvars
def test_represent_hostvars():
    ''' Test for the represent_hostvars function '''
    dumper = AnsibleDumper
    hostvars = HostVars(
        _hosts=dict(),
        _vars=dict(a=42),
        _source='my_source'
    )
    assert hostvars == {'a': 42}
    assert dumper.represent_hostvars(hostvars) == dumper.represent_data({'a': 42})



# Generated at 2022-06-20 23:59:20.301601
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper == type(yaml.Dumper)

# Generated at 2022-06-20 23:59:26.905370
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper(True, None, None, None, None, None, None)
    assert dumper.allow_unicode == True
    assert dumper.default_flow_style == None
    assert dumper.encoding == None
    assert dumper.explicit_start == None
    assert dumper.explicit_end == None
    assert dumper.indent == None
    assert dumper.line_break == None
    assert dumper.tags == None
    assert dumper.version == None
    assert dumper.top_level_colon_align == False

# Generated at 2022-06-20 23:59:35.573682
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    hostvars_obj = HostVars()
    hostvars_obj.prepend({'a': 'b', 'c': {'d': 'e'}})
    hostvars_obj.merge({'c': {'f': 'g'}})
    assert dumper.represent_hostvars(hostvars_obj) == dumper.represent_dict({'a': 'b', 'c': {'d': 'e', 'f': 'g'}})

    hostvarsvars_obj = HostVarsVars()
    hostvarsvars_obj.prepend({'a': 'b', 'c': {'d': 'e'}})
    hostvarsvars_obj.merge({'c': {'f': 'g'}})
    assert d

# Generated at 2022-06-20 23:59:41.885998
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvar_loader = {'app_id': 'demo-app-1', 'app_version': '1.0.0', 'app_setup': {'db_server': 'server-db-1'}}
    data = HostVars(hostvar_loader)
    assert yaml.dump(data, Dumper=AnsibleDumper) == '{app_id: demo-app-1, app_version: 1.0.0, app_setup: {db_server: server-db-1}}\n'



# Generated at 2022-06-20 23:59:42.850195
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert bool(AnsibleDumper) is True

# Generated at 2022-06-20 23:59:45.407820
# Unit test for function represent_hostvars
def test_represent_hostvars():
    test_object = HostVars(['1'], dict(test_item = 'test_value'))
    assert AnsibleDumper.represent_hostvars(AnsibleDumper, test_object) == {'test_item': 'test_value'}

# Generated at 2022-06-20 23:59:49.386981
# Unit test for function represent_unicode
def test_represent_unicode():
    yaml_object = AnsibleUnicode(text_type('{0}'), frozenset())
    expected_result = "!!python/unicode ''{0}''"
    assert yaml.dump(yaml_object, Dumper=AnsibleDumper)[:-2] == expected_result



# Generated at 2022-06-20 23:59:53.929656
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()
    ave = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\n1234567\n')
    text = dumper.represent_data(ave)
    assert text == u'!vault |\n  $ANSIBLE_VAULT;1.1;AES256\n  1234567\n'
