

# Generated at 2022-06-20 23:50:52.491100
# Unit test for function represent_undefined
def test_represent_undefined():
    for value in (AnsibleUnsafeText(u'foo'), AnsibleUnsafeBytes(b'foo')):
        result = AnsibleDumper.represent_data(value)
        assert result == u'"foo"\n'

    # because represent_undefined returns True
    # if the value is an AnsibleUndefined
    # _fail_with_undefined_error should be triggered
    # and the function should return without exiting.
    def dumper_represent_data(dumper, data):
        return dumper.represent_data(data)

    # None is a special case because it is not an AnsibleUndefined
    # object but it is returned by _fail_with_undefined_error as
    # something that represents undefined
    def dumper_fail_with_undefined_error(dumper, data):
        return dumper._fail

# Generated at 2022-06-20 23:50:56.442382
# Unit test for function represent_binary
def test_represent_binary():
    data = AnsibleUnsafeBytes(b"\x00\x01\x02\x03")
    dmp = AnsibleDumper(default_flow_style=False)
    actual = dmp.represent_binary(data)
    want = yaml.representer.SafeRepresenter.represent_binary(dmp, data)
    assert actual == want

# Generated at 2022-06-20 23:51:07.936052
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    actual = AnsibleVaultEncryptedUnicode('test')._ciphertext.decode()
    assert actual == '$ANSIBLE_VAULT;1.2;AES256;test\n346533316232626131346537646366383365663764323635396135303135336266393539373338\n37353464316230386434633662396561386664316138652d\n', "Ciphertext start and end should be the same as actual"

    actual = represent_vault_encrypted_unicode(0, AnsibleVaultEncryptedUnicode('test'))

# Generated at 2022-06-20 23:51:09.272320
# Unit test for function represent_undefined
def test_represent_undefined():
    data = AnsibleUndefined()
    assert yaml.dump(data, Dumper=AnsibleDumper) is None

# Generated at 2022-06-20 23:51:16.641865
# Unit test for function represent_hostvars
def test_represent_hostvars():
    def run_test(data, expected):
        dumper = yaml.SafeDumper
        dumper.ignore_aliases = lambda *args: True
        result = yaml.dump([data], Dumper=dumper)
        assert result == expected

    # Basic test
    run_test(HostVars({'foo': 'boo'}), "[{'foo': 'boo'}]\n")

    # Test with list
    run_test(HostVars({'foo': ['boo']}), "[{'foo': ['boo']}]\n")

    # Test with all types

# Generated at 2022-06-20 23:51:23.742041
# Unit test for function represent_unicode
def test_represent_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    yaml_data = b'["foo", "bar", "baz"]'
    data = yaml.load(yaml_data, Loader=AnsibleLoader)
    assert isinstance(data, list)
    assert isinstance(data[0], text_type)
    assert isinstance(data[1], text_type)
    assert isinstance(data[2], text_type)

    new_yaml = yaml.dump(data, Dumper=AnsibleDumper, default_flow_style=False)
    assert new_yaml == yaml_data



# Generated at 2022-06-20 23:51:35.566539
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper

    binary_unicode = u"\u0003\u0019\u00eb\u008f\u0006\u0016"
    assert dumper.represent_binary(binary_unicode) == "'\\x03\\x19\\xeb\\x8f\\x06\\x16'"

    binary_unicode = u"\u0003\u0019\u00eb\u008f\u0006\u0016"
    assert dumper.represent_binary(binary_unicode) == "'\\x03\\x19\\xeb\\x8f\\x06\\x16'"

    binary_byte = b"\x03\x19\xeb\x8f\x06\x16"

# Generated at 2022-06-20 23:51:46.543381
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    # Test old style (bytes)
    buf = '\x01'
    result = dumper.represent_binary(dumper, buf)
    assert isinstance(result, yaml.nodes.ScalarNode)
    assert result.tag == 'tag:yaml.org,2002:binary'
    assert result.value == u'AQ=='

    # Test new style (unicode)
    buf = utf8_b(u'\x01')
    result = dumper.represent_binary(dumper, buf)
    assert isinstance(result, yaml.nodes.ScalarNode)
    assert result.tag == 'tag:yaml.org,2002:binary'
    assert result.value == u'AQ=='

# Generated at 2022-06-20 23:51:49.929825
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert yaml.safe_dump(HostVars({'foo': 'bar'}), default_flow_style=False).strip() == '''\
foo: bar
'''



# Generated at 2022-06-20 23:51:52.666740
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b"foo")
    assert dumper.represent_binary(dumper, u"foo")

# Generated at 2022-06-20 23:52:02.800710
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(AnsibleDumper, u'foo') == u"!ansible-unicode 'foo'"
    assert represent_unicode(AnsibleDumper, b'foo') == u"!ansible-unicode 'foo'"
    assert represent_unicode(AnsibleDumper, b'\xef\xbb\xbf') == u"!ansible-unicode '\ufeff'"
    assert represent_unicode(AnsibleDumper, u'\ud842\udfb7') == u"!ansible-unicode '\\U00020bb7'"



# Generated at 2022-06-20 23:52:08.299937
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    data = AnsibleVaultEncryptedUnicode('test', vault, '$ANSIBLE_VAULT;1.1;AES256')

# Generated at 2022-06-20 23:52:11.511090
# Unit test for function represent_unicode
def test_represent_unicode():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    instance = AnsibleUnicode('foo')

    dumper = AnsibleDumper()

    assert dumper.represent_unicode(instance) == u'foo\n...\n'



# Generated at 2022-06-20 23:52:12.618127
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.dump(AnsibleUndefined()) == 'undefined'



# Generated at 2022-06-20 23:52:16.556395
# Unit test for function represent_unicode
def test_represent_unicode():
    d = AnsibleDumper()
    assert d.represent_scalar(u'tag:yaml.org,2002:str', u'foo') == "foo"



# Generated at 2022-06-20 23:52:17.528151
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper.represent_undefined(None, AnsibleUndefined())

# Generated at 2022-06-20 23:52:25.080615
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = yaml.Dumper(indent=4)
    dumper.add_representer(
        AnsibleVaultEncryptedUnicode,
        represent_vault_encrypted_unicode,
    )
    ciphertext = '$ANSIBLE_VAULT;1.1;AES256\n65636563656563656563656563656563'
    data = AnsibleVaultEncryptedUnicode(ciphertext)
    assert yaml.dump(data, Dumper=dumper) == "!vault |\n    $ANSIBLE_VAULT;1.1;AES256\n    65636563656563656563656563656563\n"

# Generated at 2022-06-20 23:52:26.900055
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper.represent_undefined(None, None) is False

# Generated at 2022-06-20 23:52:28.293993
# Unit test for function represent_undefined
def test_represent_undefined():
    assert not bool(AnsibleUndefined("value"))



# Generated at 2022-06-20 23:52:29.872358
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper(None), AnsibleDumper)

# Generated at 2022-06-20 23:52:34.501618
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper()



# Generated at 2022-06-20 23:52:45.892158
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-20 23:52:50.414204
# Unit test for function represent_hostvars
def test_represent_hostvars():
    representer = AnsibleDumper()
    hvars = HostVars()
    hvars.update({'a': 1, 'b': 2})
    assert representer.represent_hostvars(hvars) == {'a': 1, 'b': 2}



# Generated at 2022-06-20 23:52:59.206336
# Unit test for function represent_binary
def test_represent_binary():
    def _binary(b):
        return yaml.serialize(b, Dumper=AnsibleDumper, default_flow_style=False)

    assert '!!binary AAAAAA==\n' == _binary(b'\x00\x00\x00')
    assert '!!binary AQAAAAIAAAACAAAA\n' == _binary(b'\x00\x00\x00\x00\x00\x00\x00\x00')
    assert '!!binary AAABAQ==\n' == _binary(b'\x00\x00\x00\x00\x00\x00\x00')

# Generated at 2022-06-20 23:53:01.358781
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    test_dumper = AnsibleDumper()
    assert test_dumper is not None

# Generated at 2022-06-20 23:53:05.181267
# Unit test for function represent_undefined
def test_represent_undefined():
    a = AnsibleUndefined(var_name='foo')
    b = yaml.dump(a, Dumper=AnsibleDumper)
    if b != 'True':
        raise ValueError("test_represent_undefined failed")


# Generated at 2022-06-20 23:53:07.066968
# Unit test for function represent_undefined
def test_represent_undefined():
    data = AnsibleUndefined("Sorry, you found a bad undefined variable.")
    assert AnsibleDumper().represent_undefined(data)



# Generated at 2022-06-20 23:53:12.839009
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(b"a\x00", Dumper=AnsibleDumper) == '!!binary "YQA="\n'
    assert yaml.dump(b"a\x00", Dumper=AnsibleDumper, default_flow_style=True) == '!!binary "YQA="'


# Unit tests for function represent_unicode

# Generated at 2022-06-20 23:53:24.138610
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper()
    ansi_unicode = AnsibleUnicode("ansi_unicode")
    ansi_unsafe_text = AnsibleUnsafeText("ansi_unsafe_text")
    ansi_unsafe_bytes = AnsibleUnsafeBytes("ansi_unsafe_bytes")
    host_vars = HostVars("host_vars")
    host_vars_vars = HostVarsVars("host_vars_vars")
    vars_with_sources = VarsWithSources("vars_with_sources")
    ansi_seq = AnsibleSequence("ansi_seq")
    ansi_mapping = AnsibleMapping("ansi_mapping")

# Generated at 2022-06-20 23:53:29.274048
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()

    h = HostVars(hostvars=dict(hostvars=1))
    result = dumper.represent_hostvars(h)
    assert result == {'hostvars': 1}

    h.hostname
    result = dumper.represent_hostvars(h)
    assert result == {'hostvars': 1}



# Generated at 2022-06-20 23:53:35.682644
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    val = AnsibleUndefined(u'foo')
    assert dumper.represent_undefined(dumper, val) == bool(val)

# Generated at 2022-06-20 23:53:39.708852
# Unit test for function represent_hostvars
def test_represent_hostvars():
    obj = yaml.dump([HostVars(dict(test=1))], Dumper=AnsibleDumper, default_flow_style=False)
    assert obj == '- test: 1\n'



# Generated at 2022-06-20 23:53:42.388292
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper(), yaml.representer.SafeRepresenter)

# Generated at 2022-06-20 23:53:46.850729
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = {'a': 1, 'b': 2}
    expected = yaml.representer.SafeRepresenter.represent_dict(data)
    hostvars = HostVars(variables=data)

    result = represent_hostvars(None, hostvars)
    assert result == expected



# Generated at 2022-06-20 23:53:48.712202
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper()
    assert dumper.add_representer

# Generated at 2022-06-20 23:53:57.092092
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()

    # Test with empty dict
    hostvars = {}
    assert dumper.represent_dict(hostvars) == yaml.representer.SafeRepresenter.represent_dict(dumper, hostvars)

    # Test with dict
    hostvars = {'a': 1}
    assert dumper.represent_dict(hostvars) == yaml.representer.SafeRepresenter.represent_dict(dumper, hostvars)

    # Test with hostvars
    hostvars = HostVars(hostvars)
    assert dumper.represent_dict(hostvars) == yaml.representer.SafeRepresenter.represent_dict(dumper, hostvars)

    # Test with hostvarsvars
    hostvarsvars = HostVarsVars(hostvars)

# Generated at 2022-06-20 23:54:03.663435
# Unit test for function represent_unicode
def test_represent_unicode():
    # Check that objects of type AnsibleUnicode are rendered as such
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == u'"foo"\n...\n'

    # Check that objects of type str are rendered as AnsibleUnicode
    assert yaml.dump('foo', Dumper=AnsibleDumper) == u'"foo"\n...\n'



# Generated at 2022-06-20 23:54:11.272464
# Unit test for function represent_binary
def test_represent_binary():
    # First, create byte string made from UTF-8 encoded
    # string, with an embedded NUL character
    orig_str = '\x00\x04'
    s = unicode(orig_str, encoding='utf-8')

    # Now convert it back to a byte string
    s = s.encode('utf-8')

    # Instantiate AnsibleDumper object, which then registers
    # its custom representer for binary.  This
    # should allow yaml.dump to successfully output UTF-8
    # byte strings with embedded NUL characters.
    dumper = AnsibleDumper()

    # Invoke yaml.dump, and get a string back
    s2 = yaml.dump(s, Dumper=dumper)

    # Strip off any trailing whitespace
    s2 = s2.rstrip()

    # Should match

# Generated at 2022-06-20 23:54:23.572453
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host

    # We need a group, because we need a group vars dict in the hostvars
    group = Group('test_represent_hostvars')
    group.vars = {'ansible_foo': 'bar'}
    host = Host('test_represent_hostvars')

    # These are the variables to test
    host_vars = HostVars(host, group)
    group_vars = group.vars
    inventory = InventoryManager(inventory=[group])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    variable_manager._v

# Generated at 2022-06-20 23:54:34.114722
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    def get_representer(type_name):
        # Test if type is represented by function
        rep_func = AnsibleDumper.representers.get(type_name)
        return rep_func

    rep_func_unicode = get_representer(AnsibleUnicode)
    assert rep_func_unicode == represent_unicode

    rep_func_unsafe_text = get_representer(AnsibleUnsafeText)
    assert rep_func_unsafe_text == represent_unicode

    rep_func_unsafe_bytes = get_representer(AnsibleUnsafeBytes)
    assert rep_func_unsafe_bytes == represent_binary

    rep_func_hostvars = get_representer(HostVars)
    assert rep_func_hostvars == represent_hostvars

    rep_func

# Generated at 2022-06-20 23:54:39.114006
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert bool(AnsibleDumper)

# Generated at 2022-06-20 23:54:41.531283
# Unit test for function represent_undefined
def test_represent_undefined():
    assert not AnsibleDumper.represent_undefined(AnsibleDumper(), AnsibleUndefined())

# Generated at 2022-06-20 23:54:42.544165
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper is not None


# Generated at 2022-06-20 23:54:46.449183
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # pylint: disable=missing-docstring

    dumper = AnsibleDumper()

    assert dumper.represent_hostvars({'a': 1}) == {'a': 1}, 'unexpected value from AnsibleDumper.represent_hostvars()'



# Generated at 2022-06-20 23:54:47.647863
# Unit test for function represent_undefined
def test_represent_undefined():
    dump = yaml.dump({'foo': AnsibleUndefined()}, Dumper=AnsibleDumper)
    assert dump == 'foo: null\n'

# Generated at 2022-06-20 23:54:50.890796
# Unit test for function represent_undefined
def test_represent_undefined():
    ansible_dumper = AnsibleDumper()
    assert(ansible_dumper.represent_undefined(AnsibleUndefined()))
    assert(str(AnsibleUndefined()))

# Generated at 2022-06-20 23:54:55.127549
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    # data in form of HostVars({"k": "v"})
    hostvars = HostVars({"k": "v"})
    assert u"{k: v}" == dumper.represent_hostvars(hostvars)



# Generated at 2022-06-20 23:54:55.790419
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    AnsibleDumper()

# Generated at 2022-06-20 23:55:04.194388
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():

    # The presence of the following two lines makes the following test fail
    AnsibleDumper.add_representer(
        AnsibleUnicode,
        represent_unicode,
    )

    AnsibleDumper.add_representer(
        AnsibleUnsafeText,
        represent_unicode,
    )

    # Uncommenting the following line make the test success
    # AnsibleDumper.add_representer(AnsibleUnicode, yaml.representer.SafeRepresenter.represent_unicode)

    yaml.dump(AnsibleUnicode('foo'), AnsibleDumper)

    assert True

# Generated at 2022-06-20 23:55:07.396339
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    representer = represent_unicode(dumper, AnsibleUnicode(u'yaml-test'))
    assert representer == 'yaml-test'



# Generated at 2022-06-20 23:55:20.140792
# Unit test for function represent_binary
def test_represent_binary():

    import sys
    from io import BytesIO, StringIO

    class Py26BytesIO(object):
        def write(self, data):
            assert isinstance(data, bytes), "Data not bytes!"

    dumper = AnsibleDumper
    dumper.add_representer(bytes, dumper.represent_binary)

    dumper.add_multi_representer(
        bytes,
        dumper.represent_binary,
        dumper.represent_binary,
    )

    # Test Python 2 and Python 3 both
    if sys.version_info.major == 3:
        dumper.add_multi_representer(
            str,
            dumper.represent_str,
            dumper.represent_str,
        )


# Generated at 2022-06-20 23:55:21.457632
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper, type)

# Generated at 2022-06-20 23:55:23.127220
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper
    assert isinstance(dumper, type)



# Generated at 2022-06-20 23:55:34.573607
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    representer = represent_undefined
    undefined = AnsibleUndefined(u"foo")

    # Test 1
    obj = yaml.nodes.ScalarNode(u'tag:yaml.org,2002:str', 'default', style='|')
    repr = representer(dumper, undefined)
    assert repr == True, repr

    # Test 2
    obj = yaml.nodes.ScalarNode(u'tag:yaml.org,2002:str', u'foo', style='|')
    undefined.value = u'foo'
    repr = representer(dumper, undefined)
    assert repr == True, repr

    # Test 3

# Generated at 2022-06-20 23:55:36.287732
# Unit test for function represent_binary
def test_represent_binary():
    yaml_str = yaml.dump(b'\xff')
    assert yaml_str == "!binary |\n  /w==\n"
    # test_represent_binary

# Generated at 2022-06-20 23:55:44.957954
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import Templar

    templar = Templar(loader=None)
    dumper = AnsibleDumper()

    # Here Jinja will call represent_undefined
    # if the value is Undefined
    undefined = templar.from_yaml('foo: ((foo))')
    undefined = templar._fail_with_undefined_error(undefined)

    try:
        dumper.represent_data(undefined)
    except Exception as e:
        assert type(e) == AnsibleUndefinedVariable

# Generated at 2022-06-20 23:55:49.167837
# Unit test for function represent_unicode
def test_represent_unicode():
    from ansible.utils.unsafe_proxy import wrap_var

    data = wrap_var(u'foobar')
    dumper = AnsibleDumper(None)
    assert dumper.represent_unicode(data) == dumper.represent_str(text_type(data))



# Generated at 2022-06-20 23:55:54.777069
# Unit test for function represent_binary
def test_represent_binary():
    x = b'\x00\x01\x02\x03\x04'
    actual = AnsibleDumper.represent_binary(x)
    expected = "!!binary |\n  AAECAQQ="
    assert actual == expected



# Generated at 2022-06-20 23:56:04.221324
# Unit test for function represent_hostvars
def test_represent_hostvars():
    import yaml
    from ansible.vars.hostvars import HostVars

    # Test 1
    hv = HostVars(hostvars={'test': 'info'})
    assert yaml.dump({'test': hv}, Dumper=AnsibleDumper) == '{test: {test: info}}\n'

    # Test 2
    hv = HostVars(hostvars=[1, 2, 3])
    assert yaml.dump({'test': hv}, Dumper=AnsibleDumper) == '{test: [1, 2, 3]}\n'

    # Test 3
    hv = HostVars(hostvars=(1, 2, 3))

# Generated at 2022-06-20 23:56:05.179610
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper



# Generated at 2022-06-20 23:56:19.936604
# Unit test for function represent_hostvars
def test_represent_hostvars():
    output = yaml.dump(dict(HostVars({'a': 'b'})), Dumper=AnsibleDumper)
    assert output == "a: b\n"

# Generated at 2022-06-20 23:56:22.818172
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = AnsibleVaultEncryptedUnicode('test')
    dumper = AnsibleDumper()
    result = dumper.represent(data)
    assert result == '!vault |\n          test'



# Generated at 2022-06-20 23:56:24.478813
# Unit test for function represent_undefined
def test_represent_undefined():
    yaml_data = yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper)
    assert yaml_data == ''

# Generated at 2022-06-20 23:56:25.551375
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper.add_representer is not None


# Generated at 2022-06-20 23:56:28.829490
# Unit test for function represent_binary
def test_represent_binary():
    """Test the YAML SafeDumper.represent_binary method"""

    safe_dumper = yaml.representer.SafeDumper
    results = safe_dumper.represent_binary(safe_dumper, b'binary')

    assert isinstance(results, yaml.nodes.ScalarNode)
    assert results.tag == u'!binary'
    assert results.value == u'YmluYXJ5'

# Generated at 2022-06-20 23:56:39.353769
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    dumper = AnsibleDumper

# Generated at 2022-06-20 23:56:40.994755
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert not dumper.represent_undefined(AnsibleUndefined)

# Generated at 2022-06-20 23:56:43.663571
# Unit test for function represent_undefined
def test_represent_undefined():
    data = AnsibleDumper.represent_undefined(AnsibleUndefined(fail_on_undefined=True))
    assert data is False



# Generated at 2022-06-20 23:56:44.967294
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.dump(AnsibleUndefined()) == 'null\n'



# Generated at 2022-06-20 23:56:51.529754
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    ad = yaml.AnsibleDumper(indent=4, width=1000, allow_unicode=True)
    obj = AnsibleVaultEncryptedUnicode('mysecret')
    assert ad.represent_data(obj) == "!vault |\n    $ANSIBLE_VAULT;1.1;AES256\n    3963363934653837343330626331633562343761623062323363313662616236623036333761356234\n    35373765326161636537376166316430643630653232366262\n"
