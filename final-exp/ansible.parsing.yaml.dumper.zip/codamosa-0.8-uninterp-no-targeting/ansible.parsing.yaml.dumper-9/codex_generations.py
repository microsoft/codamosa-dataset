

# Generated at 2022-06-20 23:50:43.160996
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert(AnsibleDumper)

# Generated at 2022-06-20 23:50:46.615583
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    sample_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode('encrypted_string')
    assert represent_vault_encrypted_unicode(AnsibleDumper, sample_vault_encrypted_unicode) == '!vault |\n          encrypted_string'



# Generated at 2022-06-20 23:50:54.015160
# Unit test for function represent_binary
def test_represent_binary():
    # Note: this test does not seem to belong to this test module.
    # It should be moved to a new one (test_yaml_utils?), with a test
    # method test_represent_binary. And the test method should be
    # renamed to something more meaningful (say, represent_binary_works_
    # as_expected?)
    d = AnsibleDumper()
    assert d.represent_binary(b'\x00\x01\x02') == '!!binary |\n  AAEC\n'

# Generated at 2022-06-20 23:51:00.071304
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

# Generated at 2022-06-20 23:51:03.668320
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo\nbar\nbaz') == "!!binary |\n  Zm9vCmJhcgpiYXo=\n"


# Generated at 2022-06-20 23:51:07.567993
# Unit test for function represent_undefined
def test_represent_undefined():
    data = AnsibleUndefined()
    result = yaml.dump(data, Dumper=AnsibleDumper)
    assert isinstance(result, text_type)
    assert all(line.startswith('#') for line in result.splitlines())

# Generated at 2022-06-20 23:51:17.622368
# Unit test for function represent_hostvars
def test_represent_hostvars():

    dict = dict(
        _hostvars=dict(
            host0=dict(
                _ip="10.1.1.1",
                _host="host0"
            ),
            host1=dict(
                _ip="10.1.1.2",
                _host="host1"
            ),
            host2=dict(
                _ip="10.1.1.3",
                _host="host2"
            ),
            host3=dict(
                _ip="10.1.1.4",
                _host="host3"
            ),
        )
    )


# Generated at 2022-06-20 23:51:20.582385
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper(indent=2) == 2
    assert AnsibleDumper(default_flow_style=True)
    assert AnsibleDumper(default_flow_style=False)



# Generated at 2022-06-20 23:51:31.932867
# Unit test for function represent_binary
def test_represent_binary():
    # AnsibleUnsafeBytes -> !binary
    result = AnsibleDumper().represent_data(b"\x00foo\x00\xff")
    assert result == u'!binary |\n  AAZmb28A/w==\n'

    # bytes -> !binary
    result = AnsibleDumper().represent_data(b"\x00foobar\x00")
    assert result == u'!binary |\n  AAZmb29iYXIA\n'

    # bytes -> !binary without encoding
    dumper = AnsibleDumper()
    dumper.ignore_aliases = lambda data: True
    result = dumper.represent_data(b"\x00foobar\x00")
    assert result == u'!binary |\n  \x00foobar\x00\n'

    # explicitly ignore bytes

# Generated at 2022-06-20 23:51:35.623230
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(AnsibleUnicode(value="something")) == dumper.represent_unicode(u"something")



# Generated at 2022-06-20 23:51:48.246158
# Unit test for function represent_hostvars
def test_represent_hostvars():

    # Create AnsibleDumper object
    ansible_dumper = AnsibleDumper()

    # Some random variables
    version = 6
    patchlevel = 4

    # Set initialized values to HostVars object
    test_hostvars = HostVars(
        hostname='localhost',
        variables=dict(
            ansible_version=dict(
                version=version,
                patchlevel=patchlevel,
            ),
            foo='bar',
        )
    )

    # Call represent_hostvars method
    data = ansible_dumper.represent_hostvars(test_hostvars)

    # Check the returned AnsibleUnicode object
    assert isinstance(data, AnsibleUnicode)

    # Checks the values as strings

# Generated at 2022-06-20 23:51:51.479438
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert yaml.dump([1, 2, 3], Dumper=AnsibleDumper) == '[1, 2, 3]\n...\n'



# Generated at 2022-06-20 23:51:59.676676
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template.jinja2 import AnsibleJ2Template
    from ansible.vars.unsafe_proxy import wrap_var

    dumper = AnsibleDumper
    assert dumper.serialize_unicode_characters
    assert dumper.indent(3) == '   '
    assert dumper.indent(3, flow=True) == ''

    # No longer needed since Jinja2 will emit StrictUndefined
    data = wrap_var(AnsibleUndefined('foo'))
    dumper.represent_data(data)

# Generated at 2022-06-20 23:52:10.233700
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    hv = HostVars(play=None, inventory=None)
    hv.vars = dict(a="b", c="d")
    d = AnsibleDumper()
    # ansible_eth1 > ansible_eth0
    # ansible_eth0 > ansible_eth2
    # ansible_eth2 > ansible_eth3
    # ansible_eth3 > ansible_eth4
    assert d.represent_dict(hv.vars) == d.represent_dict(dict(hv.vars))
    hv.vars = dict(ansible_eth1="a", ansible_eth0="b", ansible_eth2="c", ansible_eth3="d", ansible_eth4="e")
    assert d

# Generated at 2022-06-20 23:52:21.701363
# Unit test for function represent_binary
def test_represent_binary():
    dumper = yaml.representer.SafeRepresenter()
    dumper.represent_binary = represent_binary

    # test data generated with code like:
    # print(yaml.dump(b'\x80\x81\x82\x83\x84\x85\x86\x87\x88\x89\x90\x91\x92\x93\x94\x95\x96\x97\x98\x99\x9a\x9b\x9c\x9d\x9e\x9f\xa0\xa1\xa2\xa3\xa4\xa5\xa6\xa7\xa8\xa9\xaa\xab\xac\xad\xae\xaf\xb0\xb1\xb2\xb3\xb4\xb5\

# Generated at 2022-06-20 23:52:31.955001
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # Dummy class
    class DummyUnsafeText(object):
        pass

    unsafe_text_obj = DummyUnsafeText()
    unsafe_text_obj.__str__ = lambda x: "unsafe_text"

    # Dummy class
    class DummyVaultEncryptedUnicode(object):
        pass

    vault_encrypted_unicode_obj = DummyVaultEncryptedUnicode()
    vault_encrypted_unicode_obj._ciphertext = b"ciphertext"


# Generated at 2022-06-20 23:52:38.421650
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.utils.yaml import AnsibleVaultEncryptedUnicode
    encrypt_me = 'This is a line of text.'
    encrypted = AnsibleVaultEncryptedUnicode(encrypt_me)
    assert encrypted.decrypt() == encrypt_me
    yaml_string = yaml.dump(encrypted, Dumper=AnsibleDumper, default_flow_style=False)

# Generated at 2022-06-20 23:52:41.218275
# Unit test for function represent_hostvars
def test_represent_hostvars():
    i = HostVars()
    res = represent_hostvars(AnsibleDumper, i)
    assert isinstance(res, text_type)
    assert res == '{}'

# Generated at 2022-06-20 23:52:43.500431
# Unit test for function represent_undefined
def test_represent_undefined():
    yaml_str = yaml.dump(AnsibleUndefined, Dumper=SafeDumper)
    assert not yaml_str

# Generated at 2022-06-20 23:52:46.913811
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    val = dumper.represent_data(AnsibleUndefined)
    assert val is dumper.represent_bool(False)

# Generated at 2022-06-20 23:52:55.092362
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    value = b'\x01\x02\x03\x04'
    output = dumper.represent_binary(value)

    # The trailing newline is added by the comment tag '!binary'
    assert output == "#!binary |\n" + \
                     "AQIDBAU=\n"

# Generated at 2022-06-20 23:53:02.974104
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Test expected
    data = "!vault |\n          $ANSIBLE_VAULT;1.2;AES256;ansible\n          32313161343133326431386161653662333331626535623863326261636530373436663939646166\n          653536373465653632623937336532396162626230383466\n"
    assert represent_vault_encrypted_unicode(None, AnsibleVaultEncryptedUnicode("test")) == data

# Generated at 2022-06-20 23:53:11.176961
# Unit test for function represent_unicode
def test_represent_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.common.yaml import AnsibleModuleYAMLObject
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    import time
    import os

    def assert_equal_to_yaml(data):
        dumped = yaml.dump(data, Dumper=AnsibleDumper, default_flow_style=False)
        rebuilt = yaml.load(dumped, Loader=AnsibleLoader)
        assert yaml.dump(rebuilt, Dumper=AnsibleDumper, default_flow_style=False) == dumped

    assert_equal_to_yaml(AnsibleModuleYAMLObject('value'))
    assert_equal_

# Generated at 2022-06-20 23:53:20.702877
# Unit test for function represent_unicode
def test_represent_unicode():
    from ansible.compat.tests import mock
    from ansible.compat.tests.mock import patch

    dumper = yaml.representer.Representer()
    dumper.add_representer(AnsibleUnicode, represent_unicode)

    with patch.object(dumper, 'represent_scalar') as mock_method:
        test = AnsibleUnicode('a')
        result = dumper.represent_unicode(test)

        mock_method.assert_called_once_with('tag:yaml.org,2002:str', text_type(test))
        assert result == mock_method.return_value



# Generated at 2022-06-20 23:53:22.903696
# Unit test for function represent_binary
def test_represent_binary():
    data = AnsibleUnsafeBytes(b'\xc3\xbc') # u-umlaut encoded in utf-8
    output = yaml.dump(data, Dumper=AnsibleDumper)

    assert output == "!!binary |-\n  w6E=\n"


# Generated at 2022-06-20 23:53:23.800333
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-20 23:53:32.931588
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    encrypted_text = '!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n         6237623231653335376435373962396333323431373234643839643961663233316336613733613966\n          3536333762343831623161643436653962633239663266656466343265643831616631373764633861\n          6238613838393164393264616632303631373766373532646635373362613931323133346362316639\n          3662646137376535333638663836323662376261613931333134636436646264\n          '

# Generated at 2022-06-20 23:53:34.800358
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    ansible_dumper = AnsibleDumper()
    assert ansible_dumper.__class__.__name__ == 'AnsibleDumper'



# Generated at 2022-06-20 23:53:46.839017
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import StringIO
    from ansible.parsing.yaml.loader import AnsibleLoader
    loader = AnsibleLoader(None, None)
    dumper = AnsibleDumper
    stream = StringIO()
    host = HostVars()
    host['test1'] = 0
    host['test2'] = 'value'
    host['test3'] = {'test4': 'value'}
    host['test5'] = ['value', 'value2']
    dumper.add_representer(HostVars, represent_hostvars)
    dumper.add_multi_representer(HostVars, represent_hostvars)

# Generated at 2022-06-20 23:53:48.662713
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper, type)


# Generated at 2022-06-20 23:53:58.629509
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(u'\u0080') == u'!!binary |\n  gA==\n'



# Generated at 2022-06-20 23:54:08.444750
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper(width=4096)  # 4K should be large enough line width for unit testing
    rep_string = yaml.dump(HostVars(vars={'inventory_hostname': 'test_hostname'}),
                           Dumper=dumper)
    assert rep_string == u'inventory_hostname: test_hostname\n'

    rep_string = yaml.dump(HostVarsVars(vars={'inventory_hostname': 'test_hostname'}),
                           Dumper=dumper)
    assert rep_string == u'inventory_hostname: test_hostname\n'

    rep_string = yaml.dump(VarsWithSources(vars={'inventory_hostname': 'test_hostname'}),
                           Dumper=dumper)
    assert rep

# Generated at 2022-06-20 23:54:09.466319
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper, type)

# Generated at 2022-06-20 23:54:11.732076
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper.represent_undefined(None, None) == False

if __name__ == '__main__':
    test_represent_undefined()

# Generated at 2022-06-20 23:54:24.116603
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    '''
    This is to test the function represent_vault_encrypted_unicode in common/yaml.py
    '''
    s_dumper = AnsibleDumper
    s_dumper.add_representer(
        AnsibleVaultEncryptedUnicode,
        represent_vault_encrypted_unicode,
    )


# Generated at 2022-06-20 23:54:26.068617
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper()
    assert dumper
    assert type(dumper) == AnsibleDumper

# Generated at 2022-06-20 23:54:31.373374
# Unit test for function represent_undefined
def test_represent_undefined():
    """
    Test for `ansible.utils.ansible_representer.represent_undefined`

    Args:
        None

    Returns:
        None

    Raises:
        None
    """
    # Make the object callable
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) is False

# Generated at 2022-06-20 23:54:38.171724
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    yaml.representer.SafeRepresenter.add_representer(
        AnsibleVaultEncryptedUnicode,
        represent_vault_encrypted_unicode,
    )

# Generated at 2022-06-20 23:54:48.977191
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-20 23:54:50.878490
# Unit test for function represent_binary
def test_represent_binary():
    b = AnsibleDumper().represent_binary(b'test')
    assert b == u'test', b

# Generated at 2022-06-20 23:55:08.155482
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper, type)

    x = AnsibleDumper()
    assert isinstance(x, yaml.SafeDumper)

    assert hasattr(x, 'add_representer')

# Generated at 2022-06-20 23:55:08.786283
# Unit test for function represent_hostvars
def test_represent_hostvars():
    pass

# Generated at 2022-06-20 23:55:14.125418
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    assert dumper.represent_hostvars(HostVars(None, ansible_facts={'test': 'one'})) == dumper.represent_dict({'test': 'one'})
    assert dumper.represent_hostvars(HostVarsVars({'test': 'one'})) == dumper.represent_dict({'test': 'one'})

# Generated at 2022-06-20 23:55:15.281300
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper



# Generated at 2022-06-20 23:55:22.456289
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper
    # Here we construct AnsibleVaultEncryptedUnicode object
    # using the best in class constructor.
    data = AnsibleVaultEncryptedUnicode.__new__(AnsibleVaultEncryptedUnicode, u'\xe3\x81\x82')

    result = dumper.represent_data(data)
    assert result == "!vault |\n  $ANSIBLE_VAULT;1.2;AES256;default\n  63613964663337643062313032623930333464626261656235383261623330353462336133613231320a\n", result



# Generated at 2022-06-20 23:55:33.949043
# Unit test for function represent_unicode
def test_represent_unicode():
    ''' AnsibleDumper.represent_unicode can represent AnsibleUnicode object'''
    loader = yaml.SafeLoader
    data = u'abc'
    ansible_unicode_obj = AnsibleUnicode(data)
    ansible_dumper = AnsibleDumper(width=1)

    # add represent_unicode
    yaml_expected = u'u"abc"\n...\n'
    yaml_actual = yaml.dump(ansible_unicode_obj, Dumper=ansible_dumper)

    assert yaml_actual == yaml_expected

    # del represent_unicode
    del ansible_dumper.yaml_representers[AnsibleUnicode]

# Generated at 2022-06-20 23:55:36.466880
# Unit test for function represent_unicode
def test_represent_unicode():
    input_string = '\xc2\xb5'.decode('utf-8')
    assert '\xC2\xB5' == yaml.safe_dump(AnsibleUnicode(input_string), Dumper=AnsibleDumper)



# Generated at 2022-06-20 23:55:39.001894
# Unit test for function represent_undefined
def test_represent_undefined():
    my_undefined = AnsibleUndefined()
    assert(yaml.dump({'is_undefined': my_undefined}, Dumper=AnsibleDumper))

# Generated at 2022-06-20 23:55:41.381881
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'unicode-string') == 'unicode-string\n...\n'



# Generated at 2022-06-20 23:55:47.325945
# Unit test for function represent_undefined
def test_represent_undefined():
    unsafe_proxy = AnsibleUndefined('{"foo", "bar"}')
    assert isinstance(unsafe_proxy, AnsibleUnsafeText)
    assert unsafe_proxy._data == '{"foo", "bar"}'
    assert unsafe_proxy._unsafe_proxy == True
    assert str(unsafe_proxy) == '{"foo", "bar"}'

    dumper = AnsibleDumper()
    assert True == dumper.represent_undefined(unsafe_proxy)