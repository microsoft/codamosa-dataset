

# Generated at 2022-06-20 23:50:50.125927
# Unit test for function represent_binary
def test_represent_binary():
    data = AnsibleUnsafeBytes(b'some plain text')
    result = AnsibleDumper.represent_binary(None, data)
    assert isinstance(result, text_type)
    assert result == u'!binary |\n  c29tZSBwbGFpbiB0ZXh0\n'

# Generated at 2022-06-20 23:50:54.352623
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    undefined = AnsibleUndefined()
    assert dumper.represent_undefined(dumper, undefined) is True
    try:
        assert dumper.represent_undefined(dumper, True)
    except:
        pass
    else:
        assert False

# Generated at 2022-06-20 23:50:58.383059
# Unit test for function represent_hostvars
def test_represent_hostvars():
    import io
    output = io.BytesIO()
    dumper = AnsibleDumper(output, default_flow_style=False)
    host_vars = HostVars()
    host_vars.add_host_vars({'foo': 'bar'})
    dumper.represent_hostvars(host_vars)
    output.seek(0)
    assert b'foo: bar\n' == output.read()

# Generated at 2022-06-20 23:51:01.570787
# Unit test for function represent_unicode
def test_represent_unicode():
    s = u'caf\xe9'
    s2 = yaml.dump(s, Dumper=AnsibleDumper)
    assert s2.startswith('caf\\u00e9')

# Generated at 2022-06-20 23:51:11.499638
# Unit test for function represent_unicode
def test_represent_unicode():
    # Note: function is called with self, data.  data is an AnsibleUnicode.
    # self is an object of the class, AnsibleDumper.  So we have to mock out
    # self.represent_str(self,data) to get return value.
    # Note: py2 returns unicode and py3 returns str.
    # Note: AnsibleUnicode is subclass of str.
    # We want the string value of the ansible_unicode so that
    # it is compatible with py2.  But the unicode(data) doesn't work
    # in py3 because it returns the class name.  data.encode('utf-8')
    # works, but then we have to decode it.
    self = AnsibleDumper()
    data = AnsibleUnicode('a unicode string')

# Generated at 2022-06-20 23:51:18.144004
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    ciphertext = VaultLib().encrypt(b'value')
    encrypted = AnsibleVaultEncryptedUnicode(ciphertext)
    assert represent_vault_encrypted_unicode(None, encrypted).value == '!vault |\n          %s' % ciphertext



# Generated at 2022-06-20 23:51:28.795307
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    # A byte string that contains unprintable characters
    b_str = b"fo\x00o\xffbar"

    # Represent the string with default dumper
    rep = dumper.represent_binary(dumper, b_str)
    assert rep.value == b"!!binary |-\n  Zm9vAG9iYXI=\n"

    # Represent the string with a custom tag
    rep = dumper.represent_binary(dumper, b_str, tag="tag:yaml.org,2002:bin")
    assert rep.value == b"tag:yaml.org,2002:bin |-\n  Zm9vAG9iYXI=\n"

# Generated at 2022-06-20 23:51:41.125047
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    def dumper_test(value, ciphertext, representation):
        dump = yaml.dump(value, Dumper=AnsibleDumper)
        assert dump == representation, dump

# Generated at 2022-06-20 23:51:45.974279
# Unit test for function represent_binary
def test_represent_binary():
    obj = b'\x80'
    if not yaml.safe_load(yaml.dump([obj], default_flow_style=False)) == [obj]:
        raise AssertionError('%r != %r' % (
            yaml.safe_load(yaml.dump([obj], default_flow_style=False)), [obj]))

# Generated at 2022-06-20 23:51:51.892920
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = HostVars('somehost', 'someinventory')
    hostvars.update({'some1': 'someval1', 'some2': 'someval2'})

    from io import BytesIO
    buf = BytesIO()
    yaml.dump(hostvars, buf)
    data = buf.getvalue()

    assert data == b'some1: someval1\nsome2: someval2\n'



# Generated at 2022-06-20 23:52:05.446845
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = yaml.SafeDumper

    # Test for one HostVars object
    assert dumper.represent_hostvars(dumper, HostVars({"hoge": "fuga"})) == dumper.represent_dict({'hoge': 'fuga'})

    # Test for two HostVars objects
    assert dumper.represent_hostvars(dumper, HostVars([HostVars({"foo": "bar"}), HostVars({"hoge": "fuga"})])) ==\
        dumper.represent_dict({'foo': 'bar', 'hoge': 'fuga'})

    # Test for HostVarsVars object

# Generated at 2022-06-20 23:52:13.810121
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.errors import AnsibleError
    from units.mock.patch import mock_open_context
    from io import StringIO

    vault_password_file = StringIO('')

    # Mock the vault password file
    with mock_open_context(vault_password_file, 'r', create=True):
        vault_secret = VaultSecret('foo')
        vault = VaultLib([vault_secret])
        vault_text = vault.encrypt(u'hush')

    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode(vault_text, vault, u'hush')

    # Note: The following lines are necessary in order to test
    #       represent_vault_

# Generated at 2022-06-20 23:52:21.492341
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    from ansible.parsing.yaml.loader import AnsibleLoader

    obj = dict(
        test='abc',
        embedded=dict(
            stuff=[1, 2, 3],
            more='something'
        )
    )
    yaml_str = yaml.dump(obj, Dumper=AnsibleDumper)

    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert data == obj

# Generated at 2022-06-20 23:52:23.310154
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(
        AnsibleUnicode(u'foo')
    ) == 'foo\n...\n'



# Generated at 2022-06-20 23:52:26.304366
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'\x00\x01\xff') == "!!binary |\n  AAAP/\n"

# Generated at 2022-06-20 23:52:31.354156
# Unit test for function represent_binary
def test_represent_binary():
    expected = b'!binary |\n  c2FtcGxlQGhlbHBlci5hcGk=\n'
    actual = yaml.dump({"test": AnsibleUnsafeBytes(b'sample@helper.api')},
                       Dumper=AnsibleDumper, default_flow_style=False)
    assert actual == expected

# Generated at 2022-06-20 23:52:33.450684
# Unit test for function represent_binary
def test_represent_binary():
    '''
    Test represent_binary.
    '''
    dumper = AnsibleDumper
    represent_binary(dumper, b'\xFF')

# Generated at 2022-06-20 23:52:41.877858
# Unit test for function represent_unicode
def test_represent_unicode():
    literal_unicode = u'\u2714'
    assert yaml.load(yaml.dump(literal_unicode, Dumper=AnsibleDumper)) == literal_unicode

    ansible_unicode = AnsibleUnicode(literal_unicode)
    assert yaml.load(yaml.dump(ansible_unicode, Dumper=AnsibleDumper)) == ansible_unicode

    unsafe_unicode = AnsibleUnsafeText(literal_unicode)
    assert yaml.load(yaml.dump(unsafe_unicode, Dumper=AnsibleDumper)) == unsafe_unicode



# Generated at 2022-06-20 23:52:44.329095
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.safe_dump(AnsibleUnicode('1'), default_flow_style=True) == u"1\n"



# Generated at 2022-06-20 23:52:49.954612
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hv = HostVars(fakevars1=dict(a=1, b=2, c=3))
    dumped = yaml.dump({'fakevars1': hv}, Dumper=AnsibleDumper)
    assert dumped == "fakevars1: {a: 1, b: 2, c: 3}\n"



# Generated at 2022-06-20 23:52:57.424429
# Unit test for function represent_binary
def test_represent_binary():
    value = b'test-binary'
    dumper = AnsibleDumper()
    result = dumper.represent_binary(value)
    assert result == u'!binary |\n  dGVzdC1iaW5hcnk=\n'


# Generated at 2022-06-20 23:53:06.531853
# Unit test for function represent_binary
def test_represent_binary():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    data = b'\xfdabc\xfe'
    result = yaml.dump(data, Dumper=AnsibleDumper)
    assert result == '!!binary |\n  /3hhYmM+\n'

    if AnsibleDumper.yaml_version <= (1, 1):
        data = b'\xfbabcd\xfe'
        result = yaml.dump(data, Dumper=AnsibleDumper)
        assert result == '!!binary |\n  /1phYWJjZBg=\n'

# Generated at 2022-06-20 23:53:09.059380
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper()
    assert isinstance(dumper, yaml.representer.SafeRepresenter)
    assert isinstance(dumper, yaml.serializer.Serializer)

# Generated at 2022-06-20 23:53:13.650089
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper
    data = {'var': {'name': 'John Doe'}}
    expected = """{var: {name: 'John Doe'}}\n"""
    result = dumper.represent_hostvars(dumper, data)
    assert result == expected

# Generated at 2022-06-20 23:53:17.329303
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    yaml_str = "foo"
    raw_yaml = yaml.dump(yaml_str, Dumper=AnsibleDumper)
    assert isinstance(raw_yaml, text_type)

# Generated at 2022-06-20 23:53:20.701362
# Unit test for function represent_unicode
def test_represent_unicode():
    data = AnsibleUnicode('abc')
    dumped_data = yaml.dump(data, Dumper=AnsibleDumper)
    assert dumped_data == 'abc\n...\n'

# Generated at 2022-06-20 23:53:28.249965
# Unit test for function represent_binary
def test_represent_binary():
    # Set up a dumper
    dumper = AnsibleDumper()

    # Prepare a binary string that contains a UTF-8 character
    # and the null byte
    test_string = binary_type('café\x00end', encoding='utf-8')

    # Prepare the expected result
    expected = binary_type('caf\\xc3\\xa9\\x00end')

    # Call the function to test
    result = dumper.represent_binary(test_string)

    # Check if it's equal to the expected value
    assert result == expected, 'result != %s' % expected


# Generated at 2022-06-20 23:53:32.823123
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    e = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1$my_key;my_ciphertext')
    dumper = AnsibleDumper(None, None, None, None, None, None, None, None, None)
    data = dumper.represent_data(e)
    assert data == "!vault |\n  my_ciphertext"



# Generated at 2022-06-20 23:53:39.708950
# Unit test for function represent_undefined
def test_represent_undefined():
    '''
    Unit test for function represent_undefined
    '''
    # Basic test
    dumper = AnsibleDumper
    data = 'Some text data'
    assert dumper.represent_undefined(dumper, data) == bool(data)

    # Testing non-zero integer
    data = 100
    assert dumper.represent_undefined(dumper, data) == bool(data)

    # Testing zero integer
    data = 0
    assert dumper.represent_undefined(dumper, data) == bool(data)

    # Testing True
    data = True
    assert dumper.represent_undefined(dumper, data) == bool(data)

    # Testing False
    data = False
    assert dumper.represent_undefined(dumper, data) == bool(data)

    # Testing non-empty list
   

# Generated at 2022-06-20 23:53:46.988653
# Unit test for function represent_unicode
def test_represent_unicode():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    assert yaml.dump(AnsibleUnsafeText(u'hello'), Dumper=AnsibleDumper) == u'hello\n...\n'
    try:
        yaml.dump(AnsibleUnsafeText(u'\u2713'), Dumper=AnsibleDumper)
    except UnicodeEncodeError:
        return False
    else:
        return True

# Generated at 2022-06-20 23:53:55.347517
# Unit test for function represent_binary
def test_represent_binary():
    a = AnsibleDumper()
    assert a.represent_binary(b'foo') == u'!!binary |\n  Zm9v\n'

# Generated at 2022-06-20 23:54:07.903074
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.manager import VariableManager

    dumper = AnsibleDumper()
    var_manager = VariableManager()
    var_manager.set_host_variable('127.0.0.1', 'v1', 'foo')
    var_manager.set_host_variable('127.0.0.1', 'v2', 'bar')
    var_manager.set_host_variable('127.0.0.2', 'v1', 'baz')
    var_manager.set_host_variable('127.0.0.1', 'v3', dict(a='b'))
    var_manager.set_host_variable('127.0.0.1', 'v4', dict(a=dict(b='c')))

# Generated at 2022-06-20 23:54:12.723338
# Unit test for function represent_unicode
def test_represent_unicode():
    data = 'foo'
    assert type(data) == str
    assert yaml.dump(AnsibleUnicode(data), Dumper=AnsibleDumper) == 'foo\n...\n'
    assert yaml.dump(AnsibleUnsafeText(data), Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-20 23:54:15.573440
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper.represent_hostvars is represent_hostvars

# Generated at 2022-06-20 23:54:26.411219
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    dumper = AnsibleDumper
    temp = Templar(variables=VariableManager())
    value = temp.vars_cache.set_changed_variable(temp, u'foo', u'bar')
    assert type(value) == HostVarsVars
    ret = dumper.represent_hostvars(dumper, value)
    assert ret == dumper.represent_dict(dict(value))
    value = temp.vars_cache.set_cached_variable(temp, u'foo', u'bar')
    assert type(value) == HostVarsVars
    ret = dumper.represent_hostvars(dumper, value)
    assert ret == dumper.represent_dict(dict(value))
    value = temp.vars

# Generated at 2022-06-20 23:54:33.116306
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = {'ansible_facts': {'ansible_all_ipv4_addresses': ['1.2.3.4',
                                                             '1.2.3.5']}}
    dumper = AnsibleDumper(indent=2)
    represent = dumper.represent_dict(dict(data))
    assert represent is not None
    assert type(represent) is not AnsibleUnicode
    assert type(represent) is text_type



# Generated at 2022-06-20 23:54:34.553051
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = HostVars(hostvars=dict(a=1, b=2))

    result = yaml.dump(data, Dumper=AnsibleDumper)

    assert result == '{a: 1, b: 2}\n'

# Generated at 2022-06-20 23:54:39.583428
# Unit test for function represent_unicode
def test_represent_unicode():
    # Create AnsibleUnicode object
    test_string = AnsibleUnicode(u"value")
    # Create output string and compare
    test_value = yaml.dump(test_string, Dumper=AnsibleDumper)
    assert test_value == u"value\n...\n"

# Generated at 2022-06-20 23:54:41.950542
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper, type(yaml.dumper.SafeDumper))

# Generated at 2022-06-20 23:54:46.323180
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper(width=1000)
    data = AnsibleVaultEncryptedUnicode('foo')
    result = dumper.represent_vault_encrypted_unicode(data)
    print(result)
    assert result == u'!vault |\n          foo\n'