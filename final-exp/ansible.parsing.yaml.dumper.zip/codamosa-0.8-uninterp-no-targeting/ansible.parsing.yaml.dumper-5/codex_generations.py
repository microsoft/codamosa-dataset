

# Generated at 2022-06-20 23:50:47.938220
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    # Creating an AnsibleDumper instance
    ansible_dumper = AnsibleDumper()
    # Testing for raise assertion error for level
    try:
        AnsibleDumper(level=2)
        assert False, 'AnsibleDumper should raise assertion error for level'
    except AssertionError:
        pass
    # Testing for level
    assert ansible_dumper.level == 0, 'AnsibleDumper level should be 0'

# Generated at 2022-06-20 23:50:52.672658
# Unit test for function represent_binary
def test_represent_binary():
    assert represent_binary(AnsibleDumper, '\xe9') == u'!!binary |\n  wq==\n'
    assert represent_binary(AnsibleDumper, '\xe9\xaa\xd4') == u'!!binary |\n  8J2YgQ==\n'



# Generated at 2022-06-20 23:50:55.994159
# Unit test for function represent_unicode
def test_represent_unicode():
    u = AnsibleUnicode(u'\u2713 foo')
    assert yaml.dump(u, Dumper=AnsibleDumper, default_flow_style=False) == u'\u2713 foo\n...\n'



# Generated at 2022-06-20 23:51:03.911521
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    ''' test represent_vault_encrypted_unicode'''
    # complete flow
    test_text = u'test_text'
    test_text_encoded = test_text.encode('utf-8')
    test_vault_data = AnsibleVaultEncryptedUnicode(test_text_encoded)
    result = represent_vault_encrypted_unicode(None, test_vault_data)
    assert result == u'!vault |\n  ' + test_text_encoded.decode('utf-8')

# Generated at 2022-06-20 23:51:14.152316
# Unit test for function represent_unicode
def test_represent_unicode():
    '''
    Test to ensure function represent_unicode works as expected
    '''

    class FakeDumper(object):
        '''
        A fake class to simulate yaml.representer.SafeRepresenter.represent_str
        '''
        def __init__(self):
            self.result = ''

        def represent_str(self, data):
            self.result = data

    test_data = AnsibleUnicode('foo')
    test_result = 'foo'

    dumper = FakeDumper()
    represent_unicode(dumper, test_data)
    assert dumper.result == test_result
    del test_result, dumper
    test_data = AnsibleUnsafeText('bar')
    test_result = 'bar'

    dumper = FakeDumper()

# Generated at 2022-06-20 23:51:23.444403
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # In order to test the output, we have to make a hostvars proxy object
    # that doesn't require a real HostVars object
    class HostVarsProxy(object):
        def __init__(self, vars):
            self._vars = vars
        def items(self):
            return self._vars.items()

    hv = HostVarsProxy({'key': 'value', 'key2': 'value2'})
    rep = represent_hostvars(AnsibleDumper, hv)
    assert rep == '{key: value, key2: value2}'



# Generated at 2022-06-20 23:51:35.466859
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
   import os

   # Ensure that saved fixtures for prior versions of PyYAML work
   dumper = AnsibleDumper()
   dumper.add_representer(
      AnsibleVaultEncryptedUnicode,
      represent_vault_encrypted_unicode,
   )
   test_value = AnsibleVaultEncryptedUnicode(u'$ANSIBLE_VAULT;1.1;AES256\n3539636535323738366662346361333136383362636365363161333561663233336638326231643761\n3431623138386133663039333862623132343338393864633165643465653539333539653263323163\n613463373531353361356464\n')
   test_out = yaml.dump_all

# Generated at 2022-06-20 23:51:45.801912
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from unittest import TestCase

    class MockDumper(object):
        def represent_dict(self, data):
            return data

    class TestRepresentHostvars(TestCase):
        def test_represent_hostvars(self):
            mock_dumper = MockDumper()
            hostvars = HostVars('10.0.0.1', 'test-name')
            hostvars.append("test-value")
            represent_hostvars(mock_dumper, hostvars)
            expected_result = {'10.0.0.1': "test-value", '_ansible_host_name': "test-name"}
            self.assertEquals(expected_result, hostvars)

# Generated at 2022-06-20 23:51:49.385329
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    assert represent_vault_encrypted_unicode(AnsibleDumper, AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;a_valid_vault_encrypted_string')) == u'!vault |\n          $ANSIBLE_VAULT;a_valid_vault_encrypted_string\n'


# Generated at 2022-06-20 23:51:53.333310
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = HostVars(hostvars=dict(a=1, b="Hello"))
    assert yaml.dump(hostvars, Dumper=AnsibleDumper) == u'{a: 1, b: Hello}\n'



# Generated at 2022-06-20 23:52:06.713711
# Unit test for function represent_hostvars
def test_represent_hostvars():

    # Initialize yaml parser
    data = b"---"
    loader = yaml.Loader(data)
    loader.dispatcher['!vault'] = yaml.resolver.BaseResolver.construct_yaml_str

    # Load data
    test_data = dict(
        test_host=dict(
            ansible_host='example.com'
        )
    )
    test_hostvars = HostVars(host=test_data['test_host'], name="hostvars")

    # Dump data
    output = yaml.dump(test_data, Dumper=AnsibleDumper, default_flow_style=False)

    # Check dumped data
    assert test_hostvars.name == 'hostvars'
    assert loader.get_single_data() == test_data


# Unit

# Generated at 2022-06-20 23:52:14.253305
# Unit test for function represent_undefined
def test_represent_undefined():
    '''
    Ensure old and new error behavior is the same.
    '''
    import ansible.template.safe_eval as safe_eval
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.errors import AnsibleUndefinedVariable

    # Test error-ing behavior of AnsibleUndefined
    obj = AnsibleUndefined()
    obj._fail_with_undefined_error = True

    safe_eval.setattr_on_undefined_variable_error(obj)
    as_bool = bool(obj)
    assert not as_bool

    # Test old error-ing behavior of AnsibleUnsafeText
    # If this ever changes we must update this test
    obj = AnsibleUnsafeText()

# Generated at 2022-06-20 23:52:19.194712
# Unit test for function represent_binary
def test_represent_binary():
    data = b'\x7f\x00\x00\x01'
    assert yaml.dump(data, Dumper=AnsibleDumper) == "!!binary |\n  fwAAAA==\n"

# Generated at 2022-06-20 23:52:23.916100
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    # get the constructor
    # could not use lambda as it errored out with a message:
    #     "SyntaxError: non-keyword arg after keyword arg"
    constructor = AnsibleDumper.add_constructor
    # test constructor
    constructor(
        u'tag:yaml.org,2002:str',
        lambda loader, node: AnsibleUnicode(loader.construct_scalar(node))
    )

# Generated at 2022-06-20 23:52:34.195264
# Unit test for function represent_unicode
def test_represent_unicode():
    # Test for ansible specific unicode representation
    # Useful for when we pass the value through template
    # for example {{ foo }}
    test_input_unicode = AnsibleUnicode('foo')
    test_output_unicode = yaml.representer.SafeRepresenter.represent_str(AnsibleDumper, test_input_unicode)
    assert test_output_unicode == 'foo'

    test_input_unicode2 = AnsibleUnicode('foo\n')
    test_output_unicode2 = yaml.representer.SafeRepresenter.represent_str(AnsibleDumper, test_input_unicode2)
    assert test_output_unicode2 == '"foo\n"'

    # Test for python 2.7 unicode representation of yaml
    test_input_unicode3 = text_type

# Generated at 2022-06-20 23:52:39.061007
# Unit test for function represent_binary
def test_represent_binary():
    data = AnsibleUnsafeBytes(b"this is a binary string")
    expected = yaml.representer.SafeRepresenter.represent_binary(AnsibleDumper, data)
    assert expected == b"!binary |\n  dGhpcyBpcyBhIGJpbmFyeSBzdHJpbmc"


# Generated at 2022-06-20 23:52:41.820611
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    ansible_dumper = AnsibleDumper()
    assert ansible_dumper.allow_unicode is True


# unit test for add_representer of ansible dumper

# Generated at 2022-06-20 23:52:48.100476
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template.safe_eval import Undefined
    from ansible.module_utils.six import PY3
    dumper = AnsibleDumper()
    if PY3:
        uundefined = Undefined(is_undefined=lambda self: True)
        dumper.represent_undefined(uundefined)
    else:
        undefined = Undefined()
        dumper.represent_undefined(undefined)

# Generated at 2022-06-20 23:52:51.248487
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    result = AnsibleDumper()
    assert result != None


if __name__ == '__main__':
    test_AnsibleDumper()

# Generated at 2022-06-20 23:52:55.242234
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    value = b'\x80\x88\x80\x88'
    output = dumper.represent_binary(value)
    assert output == (
        '!!binary |\n'
        '  gICAgICAg'
    )

# Generated at 2022-06-20 23:53:01.702281
# Unit test for function represent_unicode
def test_represent_unicode():
    coded = "---\n- '12345'\n- '2345'\n...\n"

    data = [u'12345', AnsibleUnicode(u'2345')]

    assert yaml.dump(data, Dumper=AnsibleDumper) == coded

# Generated at 2022-06-20 23:53:05.541649
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():

    # Test None as default value
    ad = AnsibleDumper()
    assert ad.indent == 4

    # Test integer as value
    ad = AnsibleDumper(indent=2)
    assert ad.indent == 2



# Generated at 2022-06-20 23:53:08.022574
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleMapping({u'blub': u'ab ⇒ cd'}), Dumper=AnsibleDumper) == '{blub: ab ⇒ cd}\n'

# Generated at 2022-06-20 23:53:14.001273
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Given
    dumper = AnsibleDumper
    # When
    data = AnsibleVaultEncryptedUnicode(b'gAAAAABXuJh')
    dumped = yaml.dump(data, None, default_flow_style=False, Dumper=dumper)
    # Then
    assert dumped == '!vault |\n  gAAAAABXuJh\n'

# Generated at 2022-06-20 23:53:25.162719
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    y = AnsibleDumper(width=100) # width is the maximum column width. 0 for unlimited.
    assert isinstance(y, yaml.dumper.SafeDumper)

    # unit test for add_representer()
    from ansible.module_utils.common.yaml import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    def represent_unicode(self, data):
        return yaml.representer.SafeRepresenter.represent_str(self, text_type(data))

    y = AnsibleDumper()
    y.add_representer(
        AnsibleUnicode,
        represent_unicode,
    )

    # unit test for yaml.representer.SafeRepresenter.represent_str()
    y = yaml.representer.SafeRepresenter()

# Generated at 2022-06-20 23:53:25.831448
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    AnsibleDumper()

# Generated at 2022-06-20 23:53:32.967740
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dump_data = yaml.dump({
        'host_foo': AnsibleVarsVars({
            'hostvars': {
                'hostvars_first': 'hostvars_first_value',
                'hostvars_second': 'hostvars_second_value',
            },
        }),
    }, Dumper=AnsibleDumper)

    # Make sure that host_foo is encoded as a dict
    assert dump_data == '{host_foo: {hostvars_first: hostvars_first_value, hostvars_second: hostvars_second_value}}\n'



# Generated at 2022-06-20 23:53:34.804432
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    data = AnsibleUndefined()
    assert not dumper.represent_undefined(dumper, data)



# Generated at 2022-06-20 23:53:39.495546
# Unit test for function represent_unicode
def test_represent_unicode():
    representer = AnsibleDumper(allow_unicode=True)
    result = representer.represent_unicode(u"foo")
    assert result == "foo"
    result = representer.represent_unicode(u"é")
    assert result == u"é"

# Generated at 2022-06-20 23:53:47.480573
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars

    # test data with undefined value
    data = {'a': True, 'b': AnsibleUndefined}

    # initialize HostVars with test data
    hostvars = HostVars()
    hostvars.data = data

    # run representer
    result = represent_hostvars(AnsibleDumper, hostvars)

    # initialize expected result
    expected_result = dict(data)

    assert result == expected_result

# Generated at 2022-06-20 23:53:57.518753
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary('a') == '!!binary a', 'test 1'
    assert dumper.represent_binary(b'a\xfe') == '!!binary |\n  YV5+\n', 'test 2'
    assert dumper.represent_binary(b'a\\\xfe') == '!!binary |\n  YVxcXn5+\n', 'test 3'
    assert dumper.represent_binary(b'a\\\xfe', style='double') == '!!binary "a\\\\xfe"', 'test 4'
    assert dumper.represent_binary(b'a\n\xfe') == '!!binary |\n  YQpuXn5+\n', 'test 5'

# Generated at 2022-06-20 23:53:58.875746
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper, type)

# Generated at 2022-06-20 23:54:05.006112
# Unit test for function represent_unicode
def test_represent_unicode():
    u = u'\u2665'

    output = yaml.dump({u: u}, Dumper=AnsibleDumper, allow_unicode=True)
    assert output == "!!python/object/apply:ansible.parsing.yaml.objects.AnsibleUnicode {'arguments': [u'\u2665'], 'name': '__new__'}: '\\u2665'\n"



# Generated at 2022-06-20 23:54:06.633169
# Unit test for function represent_undefined
def test_represent_undefined():
    assert(AnsibleDumper.represent_undefined(None, AnsibleUndefined()) == True)



# Generated at 2022-06-20 23:54:11.730916
# Unit test for function represent_undefined
def test_represent_undefined():
    '''
    When AnsibleUndefined gets passed in to represent_undefined, we want to
    assert that isinstance(data, AnsibleUndefined) is True. This is
    so that _fail_with_undefined_error happens. _fail_with_undefined_error
    can only happen if AnsibleUndefined is passed in.
    '''

    represent_undefined(AnsibleDumper, AnsibleUndefined())

# Generated at 2022-06-20 23:54:17.726111
# Unit test for function represent_hostvars
def test_represent_hostvars():
    output = yaml.dump(HostVars({"a": 1, "b": 2, "c": 3}), Dumper=AnsibleDumper)
    assert output == '{a: 1, b: 2, c: 3}\n'



# Generated at 2022-06-20 23:54:19.629317
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    from yaml import Dumper

    assert issubclass(AnsibleDumper, Dumper)

# Generated at 2022-06-20 23:54:21.005068
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    obj = AnsibleDumper()
    assert isinstance(obj, AnsibleDumper)

# Generated at 2022-06-20 23:54:24.780738
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    data = {'foo': 1, 'bar': [1, 2, 3]}
    hostvars = HostVars(data)
    assert dumper.represent_data(hostvars) == dumper.represent_data(data)

# Generated at 2022-06-20 23:54:30.711890
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper
    data = HostVars({}, 'bar')
    assert dumper.represent_hostvars(dumper, data) == u'{}'

    data = HostVars({'foo': 'bar'}, 'bar')
    assert dumper.represent_hostvars(dumper, data) == u'{foo: bar}'


# Generated at 2022-06-20 23:54:46.237420
# Unit test for function represent_unicode
def test_represent_unicode():
    from ansible.module_utils.common.yaml import dumps

    # The code idea is taken from https://github.com/yaml/pyyaml/issues/112
    class UnicodeDumper(SafeDumper):
        def ignore_aliases(self, data):
            return True

    # Using SafeDumper so that binary would not be base64 encoded
    assert dumps(text_type(u"test\u20ac"), Dumper=UnicodeDumper) == "test\\u20ac\n..."

    # Ensure the SafeDumper works
    assert dumps(b"test\xe2\x82\xac", Dumper=UnicodeDumper) == "test\xe2\x82\xac\n..."

    # Ensure the AnsibleDumper works

# Generated at 2022-06-20 23:54:51.521395
# Unit test for function represent_binary
def test_represent_binary():
    rep_bin = yaml.representer.SafeRepresenter.represent_binary
    rep_string = yaml.representer.SafeRepresenter.represent_str
    data = {'s1': 's1', 's2': 's2', 's3': 's3'}

    assert rep_bin(AnsibleDumper, data) == rep_string(AnsibleDumper, data)

# Generated at 2022-06-20 23:54:54.947688
# Unit test for function represent_binary
def test_represent_binary():
    b = AnsibleUnsafeBytes(b'test')
    assert yaml.safe_dump(b, allow_unicode=True, default_flow_style=False) == u'- !!binary |\n  dGVzdA==\n'

# Generated at 2022-06-20 23:54:58.804833
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    assert dumper.represent_data(dict(foo=AnsibleUndefined())) == "foo:\n"
    assert dumper.represent_data(dict(foo=AnsibleUndefined(strict=False))) == "foo: null\n"

if __name__ == '__main__':
    test_represent_undefined()

# Generated at 2022-06-20 23:55:04.352436
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = {}
    data['hostvars'] = {}
    data['hostvars']['host1'] = {}
    data['hostvars']['host1']['interface1'] = 'ib0'
    assert represent_hostvars(None, data) == {'hostvars': {'host1': {'interface1': 'ib0'}}}



# Generated at 2022-06-20 23:55:11.096504
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = '''
      a:
      - 1.0
      - 2
      - null
      -
      - four
      -
        - 1
        - 2
        - [3, 4]
        - {a: complex, b: mapping}
    '''

    print(yaml.dump(yaml.load(data, Loader=AnsibleLoader), Dumper=AnsibleDumper))

# Generated at 2022-06-20 23:55:16.446596
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    a = AnsibleDumper()
    assert a
    assert a.represent_unicode
    assert a.represent_binary
    assert a.represent_hostvars
    assert a.represent_undefined
    assert a.represent_vault_encrypted_unicode
    assert 'represent_dict' in dir(a)
    assert 'represent_list' in dir(a)
    assert 'represent_scalar' in dir(a)



# Generated at 2022-06-20 23:55:22.767573
# Unit test for function represent_unicode
def test_represent_unicode():

    tests = [
        (u'This is a unicode string.', u'"This is a unicode string."'),
        (u'This is a unicode string with non-ascii characters: \u2713', u'"This is a unicode string with non-ascii characters: \\u2713"'),
        (u'This is a unicode string with quotes: \\" \\\'', u'"This is a unicode string with quotes: \\\" \\\'"'),
    ]

    for (inp, outp) in tests:
        actual = represent_unicode(AnsibleDumper, inp)
        assert actual == outp



# Generated at 2022-06-20 23:55:27.091138
# Unit test for function represent_undefined
def test_represent_undefined():
    """
    yaml.representer.SafeRepresenter.represent_none(self, _data)
    If a value is undefined it fails and gives an error
    """
    assert represent_undefined('AnsibleUndefined') is False

# Generated at 2022-06-20 23:55:32.002306
# Unit test for function represent_hostvars
def test_represent_hostvars():

    import yaml

    yaml_str = """
    test1:
        var1: value1
        var2: value2
    """

    hv = HostVars(yaml.load(yaml_str))
    assert yaml.dump(hv, Dumper=AnsibleDumper) == yaml_str



# Generated at 2022-06-20 23:55:47.303275
# Unit test for function represent_unicode
def test_represent_unicode():
    # When
    unicode_text = text_type('abcd')
    unicode_b_text = binary_type('abcde')
    ansible_unicode_text = AnsibleUnicode(unicode_text)
    ansible_unicode_b_text = AnsibleUnicode(unicode_b_text)
    ansible_unsafe_text = AnsibleUnsafeText(unicode_text)
    ansible_unsafe_b_text = AnsibleUnsafeBytes(unicode_b_text)

    # When
    represent_unicode_text = represent_unicode(AnsibleDumper, ansible_unicode_text)
    represent_unicode_b_text = represent_unicode(AnsibleDumper, ansible_unicode_b_text)
    represent_unsafe_ascii

# Generated at 2022-06-20 23:55:52.814404
# Unit test for function represent_undefined
def test_represent_undefined():
    try:
        ansible_dumper = AnsibleDumper
        ansible_dumper.represent_undefined(None, AnsibleUndefined('foo'))
        assert False, "The dumper should have raised an exception"
    except yaml.YAMLError as e:
        assert 'undefined value found' in e.message

# Generated at 2022-06-20 23:55:54.168556
# Unit test for function represent_hostvars
def test_represent_hostvars():
    represent_hostvars(AnsibleDumper, HostVars({}))

# Generated at 2022-06-20 23:55:58.272763
# Unit test for function represent_binary
def test_represent_binary():
    yaml.add_representer(bytes, lambda dumper, value: dumper.represent_scalar(u'tag:yaml.org,2002:binary', value.decode('utf-8'), style='|'))
    data = yaml.dump("a")
    assert data == "a\n"

# Generated at 2022-06-20 23:56:05.832931
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.hostvars import HostVars
    data = HostVars()
    data['myvar'] = wrap_var(dict(name='test'))
    data['myvar2'] = wrap_var('fromdict')
    result = yaml.SafeDumper.represent_dict(AnsibleDumper(), dict(data))
    assert result == "!!python/object/apply:ansible.vars.hostvars.HostVars\n- name: myvar\n  value: {name: test}\n- name: myvar2\n  value: fromdict\n"

# Generated at 2022-06-20 23:56:12.458036
# Unit test for function represent_unicode
def test_represent_unicode():
    assert u"a" == yaml.load(yaml.dump(u"a", Dumper=AnsibleDumper))
    assert u"a" == yaml.load(yaml.dump(b"a", Dumper=AnsibleDumper))
    assert u"a" == yaml.load(yaml.dump(b"a".decode('ascii'), Dumper=AnsibleDumper))



# Generated at 2022-06-20 23:56:17.129021
# Unit test for function represent_undefined
def test_represent_undefined():
    s = yaml.safe_dump(AnsibleUndefined(), Dumper=AnsibleDumper)
    assert s == ''

# Ensure that the following types are dumped as their default
# yaml equivalents.
# Note that these representers aren't defined or used in AnsibleDumper
# because existing representers handle the types fine.

# Generated at 2022-06-20 23:56:18.849120
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper()
    assert isinstance(dumper, AnsibleDumper)

# Generated at 2022-06-20 23:56:26.232728
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper()

    assert dumper.add_implicit_resolver(
        u'tag:yaml.org,2002:null',
        type(None),
        None,
    )
    assert dumper.add_representer(AnsibleUnicode, represent_unicode)
    assert dumper.add_representer(HostVars, represent_hostvars)
    assert dumper.add_representer(
        AnsibleVaultEncryptedUnicode,
        represent_vault_encrypted_unicode,
    )

    # The code does not support passing an empty object
    assert dumper.add_multi_representer(object) is None

# Generated at 2022-06-20 23:56:38.160219
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.utils.vault import VaultLib
    vault = VaultLib([])
    password = 'secret'
    ciphertext = vault.encrypt(text_type(password))
    h = AnsibleVaultEncryptedUnicode(value=ciphertext)