

# Generated at 2022-06-20 23:50:48.493171
# Unit test for function represent_binary
def test_represent_binary():
    dump = yaml.safe_dump(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f\x10')
    heap = yaml.safe_load(dump)
    assert heap == b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f\x10'

# Generated at 2022-06-20 23:50:57.794518
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    encrypted_text = u'$ANSIBLE_VAULT;1.1;AES256\n37393330643530373835613363663131653235326539373035333035663131623666316535333038\n32353533613063366638313135653939363764306663303539356439653931633862303465613130\n363536346233303939646366313238363366653064393233376466\n'
    encrypted_unicode = AnsibleVaultEncryptedUnicode(encrypted_text)

# Generated at 2022-06-20 23:51:00.087036
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    test_data = AnsibleVaultEncryptedUnicode('AAAAAAAAAAAAAAAAAAAAANfY3q8qKj1qe/SDwJtO7M4bW4d4M4TeZrwY+AfQ')
    ansible_dumper = AnsibleDumper()
    ansible_dumper.represent_vault_encrypted_unicode(test_data)



# Generated at 2022-06-20 23:51:05.259511
# Unit test for function represent_hostvars
def test_represent_hostvars():
    h = HostVars()
    h['ansible_ssh_user'] = 'root'
    h['ansible_ssh_host'] = 'localhost'
    assert yaml.dump(h, Dumper=AnsibleDumper) == 'ansible_ssh_user: root\nansible_ssh_host: localhost\n'



# Generated at 2022-06-20 23:51:13.135748
# Unit test for function represent_undefined
def test_represent_undefined():
    # First ensure a variable that is not defined
    # calls the function _fail_with_undefined_error
    yamldump = yaml.dumper.SafeDumper()

    def mockfunc_fail_with_undefined_error(data):
        mockfunc_fail_with_undefined_error.called = True

    mockfunc_fail_with_undefined_error.called = False
    yamldump.represent_undefined = mockfunc_fail_with_undefined_error
    yamldump.generic_representer(u'foo', AnsibleUndefined(u'foo'))
    assert mockfunc_fail_with_undefined_error.called is True

    # Now ensure a variable that is defined returns a value of False
    def mockfunc_no_fail_with_undefined_error(data):
        mockfunc_

# Generated at 2022-06-20 23:51:19.111356
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    d = AnsibleDumper()
    # Create a '!vault' AnsibleVaultEncryptedUnicode
    value = AnsibleVaultEncryptedUnicode('bar')
    # represent_vault_encrypted_unicode returns a ciphertext string
    ciphertext = represent_vault_encrypted_unicode(d, value)
    assert ciphertext == u"!vault |\n          bar\n"



# Generated at 2022-06-20 23:51:23.444733
# Unit test for function represent_binary
def test_represent_binary():
    b = b'foo'
    d = AnsibleDumper(None)
    r = d.represent_binary(b)
    a = yaml.representer.SafeRepresenter.represent_binary(d, b)
    assert r == a


if __name__ == '__main__':
    test_represent_binary()

# Generated at 2022-06-20 23:51:35.467267
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper(width=float("inf"))

# Generated at 2022-06-20 23:51:37.084529
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    c = AnsibleDumper()
    assert False is c.ignore_aliases

# Generated at 2022-06-20 23:51:42.957761
# Unit test for function represent_binary
def test_represent_binary():
    yaml = AnsibleDumper(indent=2)
    assert yaml.represent_binary(b'\x00') == '!!binary |\n  AA=='
    assert yaml.represent_binary(b'\x00\x01') == '!!binary |\n  AAE=\n'



# Generated at 2022-06-20 23:51:47.737873
# Unit test for function represent_binary
def test_represent_binary():
    """
    Tests that the represent_binary function in this module
    correctly converts a str to a unicode object.
    """
    assert yaml.representer.SafeRepresenter.represent_binary(AnsibleDumper, b'hello') == u'hello'

# Generated at 2022-06-20 23:51:59.772749
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.dumper import AnsibleDumper

    u = AnsibleUnicode('test_unicode_value')
    b = AnsibleUnsafeBytes('test_binary_value')
    d = HostVars(hostvars=dict(unicode_field=u, binary_field=b))
    yaml_str = yaml.dump(d, Dumper=AnsibleDumper)

    # yaml_str is a unicode string, so we need to format it the same way
    # regardless of the Python version we're using
    yaml_str_expected = yaml_str = u'{binary_field: !!binary "test_binary_value", unicode_field: test_unicode_value}\n'

    assert yaml_str == yaml_str_expected

# Generated at 2022-06-20 23:52:10.315157
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-20 23:52:21.844854
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-20 23:52:32.138319
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    ansible_dumper = AnsibleDumper()
    ansible_dumper.add_representer(
        AnsibleVaultEncryptedUnicode,
        represent_vault_encrypted_unicode,
    )
    ciphertext = '$ANSIBLE_VAULT;1.1;AES256;someuser\n369e4cfdfd28f8c4f4cc4a4c4752a2e8d465b7021622b887cddf38d0fe4c812fc\n'
    vault_encrypted_unicode = AnsibleVaultEncryptedUnicode(ciphertext)

# Generated at 2022-06-20 23:52:33.108859
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    AnsibleDumper()
    assert True

# Generated at 2022-06-20 23:52:43.254843
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    # test for old format ansible vault
    vault = VaultLib([])

# Generated at 2022-06-20 23:52:55.041636
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    ad = AnsibleDumper(allow_unicode=True)

# Generated at 2022-06-20 23:53:00.720440
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.module_utils.common._collections_compat import OrderedDict
    test_dict = OrderedDict()
    test_dict['a'] = 'b'

    assert represent_hostvars(AnsibleDumper(), HostVars(test_dict)) == represent_hostvars(AnsibleDumper(), test_dict)



# Generated at 2022-06-20 23:53:09.962457
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    passwd = 'asdf'

# Generated at 2022-06-20 23:53:18.780318
# Unit test for function represent_undefined
def test_represent_undefined():
    yaml_dumper = AnsibleDumper()
    yaml_dumper.represent_undefined(AnsibleUndefined())
    yaml_dumper.represent_undefined(AnsibleUndefined(fail_on_undefined=False))
    yaml_dumper.represent_undefined(AnsibleUndefined(strict=True))
    yaml_dumper.represent_undefined(AnsibleUndefined(strict=True, fail_on_undefined=False))

# Generated at 2022-06-20 23:53:26.152548
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib

    vault = VaultLib(password_bytes=text_type('1234567890').encode('utf-8'))
    ciphertext = vault.encrypt(text_type('ANSIBLE'))
    data = AnsibleVaultEncryptedUnicode(ciphertext)

    dumper = AnsibleDumper()
    represent_vault_encrypted_unicode(dumper, data)
    assert dumper.result == '!vault |\n' + ciphertext.decode()

# Generated at 2022-06-20 23:53:29.683020
# Unit test for function represent_undefined
def test_represent_undefined():
    assert bool(AnsibleUndefined())
    from ansible.template import Undefined
    assert bool(Undefined())
    del Undefined
    from jinja2.runtime import Undefined
    assert not bool(Undefined())
    assert not bool(AnsibleUndefined())

# Generated at 2022-06-20 23:53:34.673826
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256;user_data\nabc')
    yaml_data = yaml.dump(data, Dumper=AnsibleDumper, default_flow_style=False)
    assert yaml_data == "!vault \n" \
      "  $ANSIBLE_VAULT;1.1;AES256;user_data\n" \
      "  abc\n"



# Generated at 2022-06-20 23:53:42.446884
# Unit test for function represent_unicode
def test_represent_unicode():
    # Python 2
    if hasattr(text_type, "decode"):
        data = text_type('[foo, bar]').decode("utf-8")
        assert represent_unicode(AnsibleDumper, data) == u'- foo\n- bar'
    else:
        data = text_type('[foo, bar]')
        assert represent_unicode(AnsibleDumper, data) == u'- foo\n- bar'


# Generated at 2022-06-20 23:53:45.619547
# Unit test for function represent_undefined
def test_represent_undefined():
    """
    Test unicode objects can be dumped, and that they do not get wrapped in quotes
    """
    assert yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper) == 'null'

# Generated at 2022-06-20 23:53:49.877274
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = yaml.Dumper()
    data = AnsibleUnicode(u'\x00\x0a\x0d')
    assert u'!!python/unicode "\u0000\n\r"' == yaml.dump([data], Dumper=AnsibleDumper)

# Generated at 2022-06-20 23:53:57.249143
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template.template import AnsibleTemplate
    dumper = AnsibleDumper
    template = AnsibleTemplate('this is a string', keep_trailing_newline=True, convert_data=False)
    assert dumper.represent_undefined(template, None)

    # Test if dumper.represent_undefined throws AttributeError
    # when the second argument is not an instance of AnsibleTemplate
    try:
        dumper.represent_undefined(True, None)
    except AttributeError:
        pass
    else:
        raise Exception("This test failed")


AnsibleDumper.add_multi_representer(
    type(None),
    yaml.representer.SafeRepresenter.represent_none,
)

# Generated at 2022-06-20 23:54:02.237416
# Unit test for function represent_unicode
def test_represent_unicode():
    d = AnsibleDumper(indent=4)
    assert d.represent_unicode(u'foo') == (u'foo\n', False)
    assert d.represent_unicode(u'foo\n') == (u'"foo\\n"\n', False)


# Generated at 2022-06-20 23:54:10.464501
# Unit test for function represent_unicode
def test_represent_unicode():
    result = represent_unicode(AnsibleDumper, 'text_type')
    assert result == yaml.representer.SafeRepresenter.represent_str(AnsibleDumper, 'text_type')

    result = represent_unicode(AnsibleDumper, b'binary_type')
    assert result == yaml.representer.SafeRepresenter.represent_str(AnsibleDumper, 'binary_type')

    result = represent_unicode(AnsibleDumper, AnsibleUnicode('text_type'))
    assert result == yaml.representer.SafeRepresenter.represent_str(AnsibleDumper, 'text_type')

    result = represent_unicode(AnsibleDumper, AnsibleUnicode(b'binary_type'))

# Generated at 2022-06-20 23:54:24.541332
# Unit test for function represent_hostvars
def test_represent_hostvars():

    # Arrange
    host_vars = HostVars(host_vars={'some-var': 'some-value'})
    host_vars_vars = HostVarsVars(host_vars={'some-var': 'some-value'})
    vars_with_sources = VarsWithSources(vars={'some-var': 'some-value'})

    # Act
    host_vars_repr = yaml.dump([host_vars], Dumper=AnsibleDumper)
    host_vars_vars_repr = yaml.dump([host_vars_vars], Dumper=AnsibleDumper)
    vars_with_sources_repr = yaml.dump([vars_with_sources], Dumper=AnsibleDumper)

    # Ass

# Generated at 2022-06-20 23:54:29.040700
# Unit test for function represent_unicode
def test_represent_unicode():
    from ansible.parsing.yaml.dumper import AnsibleUnicode

    text = u"\u20ac"
    yaml.dump(text, Dumper=AnsibleDumper)
    assert isinstance(text, AnsibleUnicode)



# Generated at 2022-06-20 23:54:32.868950
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    class TestObject():
        _ciphertext = 'test'
    assert represent_vault_encrypted_unicode(None, TestObject()) == '!vault |' + '\n  ' + 'test'

# Generated at 2022-06-20 23:54:34.470546
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper, type), "AnsibleDumper is not a class"

    assert issubclass(AnsibleDumper, yaml.dumper.SafeDumper), "AnsibleDumper is not a subclass of SafeDumper"



# Generated at 2022-06-20 23:54:42.833344
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert represent_hostvars(None, HostVars()) == {}
    assert represent_hostvars(None, {'a': 'b'}) == {'a': 'b'}

    class Foo:
        pass
    foo = Foo()
    foo.a = 'b'
    foo.bar = 'baz'
    foo.baz = HostVars()
    result = {'a': 'b', 'bar': 'baz', 'baz': {}}
    assert represent_hostvars(None, foo) == result

# Generated at 2022-06-20 23:54:46.056475
# Unit test for function represent_binary
def test_represent_binary():
    dump = yaml.dump([b'foo'], Dumper=AnsibleDumper)
    assert dump == "---\n- !!binary |\n  Zm9v\n...\n"



# Generated at 2022-06-20 23:54:48.875988
# Unit test for function represent_unicode
def test_represent_unicode():
    class TestAnsibleDumper(AnsibleDumper):
        pass

    t = TestAnsibleDumper()
    assert t.represent_unicode(u'foo') == u"!ansible-unicode 'foo'"

# Generated at 2022-06-20 23:54:53.378240
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'test') == u'!!binary "dGVzdA=="'

    # Round trip
    assert yaml.load(yaml.dump(b'test', Dumper=AnsibleDumper)) == b'test'

# Generated at 2022-06-20 23:55:00.672821
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import Jinja2Template

    env = Jinja2Template._get_cached_loader(
        dirs=[],
        contexts=[dict(fail_on_undefined=True, undefined=AnsibleUndefined)]
    )

    # test for jinja2 2.9.X
    try:
        env.loader.get_source(env, '')
    except TypeError:
        pass
    else:
        raise AssertionError('did not call _fail_with_undefined_error')

    # test for jinja2 2.9.X
    try:
        env.loader.get_source(env, '')
    except TypeError:
        pass
    else:
        raise AssertionError('did not call _fail_with_undefined_error')

# Generated at 2022-06-20 23:55:12.091638
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    import base64
    import textwrap

    plaintext_contents = 'The magic words are squeamish ossifrage'
    password = 'ansible'
    ciphertext = VaultLib.encrypt(password, plaintext_contents)
    ciphertext_b64 = base64.b64encode(ciphertext)
    ciphertext_str = ciphertext_b64.decode('utf-8')
    ciphertext_str = textwrap.fill(ciphertext_str, width=60)

# Generated at 2022-06-20 23:55:16.197825
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    output = dumper.represent_data(AnsibleUndefined([None]))

    assert output == ''

# Generated at 2022-06-20 23:55:23.594640
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultEditor
    text = 'Hello World!'
    ciphertext = VaultLib.encrypt(text.encode('utf-8'), password='$ANSIBLE_VAULT;1.1;AES256')
    vaulted_text = VaultEditor.vault_decrypt(ciphertext)
    encrypted_data = AnsibleVaultEncryptedUnicode(vaulted_text.encode('utf-8'))
    output = yaml.dump([encrypted_data], Dumper=AnsibleDumper, default_flow_style=False)

# Generated at 2022-06-20 23:55:30.238127
# Unit test for function represent_undefined
def test_represent_undefined():
    data = AnsibleUndefined('This is the message')
    assert yaml.dump(data, Dumper=AnsibleDumper)
    assert yaml.dump({'data': data}, Dumper=AnsibleDumper)
    assert yaml.dump({'data': data, 'data2': data}, Dumper=AnsibleDumper)
    assert yaml.dump([data], Dumper=AnsibleDumper)

# Generated at 2022-06-20 23:55:36.429509
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    # Create dumper object
    dumper = AnsibleDumper()

    # Represent ansible mapping
    ansible_mapping = AnsibleMapping({'key': 'value'})
    res = dumper.represent_dict(ansible_mapping)
    assert res

    # Represent ansible sequence
    ansible_sequence = AnsibleSequence(['value1', 'value2'])
    res = dumper.represent_list(ansible_sequence)
    assert res


# Generated at 2022-06-20 23:55:39.858083
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    b = AnsibleVaultEncryptedUnicode(b'hello world')
    assert represent_vault_encrypted_unicode(AnsibleDumper, b) == u'!vault |\n  hello world\n'


# Generated at 2022-06-20 23:55:46.921668
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # note: the data passed to yaml.dump() and any other YAML call
    # must be of type 'unicode'
    val = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\n3532643134353031613237386265643565336434396530323931303538353263346462373930616238630a393433376363383933663136353931366662353638346562333862316531376534333565383430353631633532353163650a3233346232363237623438346639383330646466626637646137306439336239383766393839633862326566376433666564\n')
    output = yaml.dump

# Generated at 2022-06-20 23:55:53.461477
# Unit test for function represent_undefined
def test_represent_undefined():
    class Dumper(yaml.Dumper):
        pass

    Dumper.add_representer(AnsibleUndefined, represent_undefined)

    def_value = AnsibleUndefined()
    serialized_data = yaml.dump(def_value, Dumper=Dumper)
    assert serialized_data == '_UNDEFINED_STRING_'



# Generated at 2022-06-20 23:56:01.073001
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    s = '''
a: 1
b: 2
'''

    data = AnsibleLoader(s).get_single_data()
    assert data == dict(a=1, b=2)

    assert type(data['a']) == int
    assert type(data['b']) == int

    d = AnsibleDumper()
    output = d.represent_data(data)
    assert output == """{a: 1, b: 2}\n"""



# Generated at 2022-06-20 23:56:07.472289
# Unit test for function represent_binary
def test_represent_binary():
    # GIVEN
    dumper = yaml.dumper.SafeDumper
    data = b'\x84\x20\x8e\x91\x94\x81\x98\x8a\x95\x20\x8b\x20\x8e\x91\x94\x81\x98\x8a\x95\x20\x8b\x20\x8e\x91\x94\x81\x98\x8a\x95\x20\x8b'

    # WHEN
    actual = represent_binary(dumper, data)

    # THEN
    assert '"' + data.decode() + '"' == actual

# Generated at 2022-06-20 23:56:13.938395
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    from ansible.template import Templar

    representer = AnsibleDumper(None, default_flow_style=False)
    value = Templar().template('{{ ansible_system_vendor }}', dict(), True)
    assert value._fail_with_undefined_error is False

    assert representer.represent_undefined(value) is False
    assert representer.represent_undefined(AnsibleUndefined) is False

# Generated at 2022-06-20 23:56:21.017386
# Unit test for function represent_undefined
def test_represent_undefined():
    test_data = AnsibleUndefined(missing_args=['a', 'b'])
    assert str(test_data) == '{{ a }} {{ b }}'
    assert test_data.missing_args == ['a', 'b']



# Generated at 2022-06-20 23:56:23.847117
# Unit test for function represent_undefined
def test_represent_undefined():
    class Undefined(object):
        def __bool__(self):
            return True

    dumper = AnsibleDumper()

    assert dumper.represent_data(Undefined())
    assert dumper.represent_data(AnsibleUndefined())

# Generated at 2022-06-20 23:56:25.792652
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(b'hello', Dumper=AnsibleDumper) == b"!binary |-\n  aGVsbG8=\n"



# Generated at 2022-06-20 23:56:27.010731
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper()
    assert isinstance(dumper, AnsibleDumper)

# Generated at 2022-06-20 23:56:30.272818
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    assert represent_vault_encrypted_unicode(AnsibleDumper(), AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\n')) == """!vault |
                  $ANSIBLE_VAULT;1.1;AES256
                  666262623261
                  6534376466353937663338393961326664666165633964313833623862626362666536

                  """



# Generated at 2022-06-20 23:56:32.103232
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper(), yaml.SafeDumper)

# Generated at 2022-06-20 23:56:42.666911
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.common.collections import MutableSequence

    class MockVars(dict):
        def get_all_vars(self):
            return self

    # Unit test for dict
    d = dict(a=1, b=2)
    d_mock = MockVars(dict(c=2))
    d.update(d_mock)
    res = yaml.dump(d, Dumper=AnsibleDumper)
    assert res == '{a: 1, b: 2, c: 2}\n'
    # compare with the MutableMapping
    d2 = MockVars(dict(a=1, b=2))

# Generated at 2022-06-20 23:56:45.967173
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    assert represent_vault_encrypted_unicode(AnsibleDumper, AnsibleVaultEncryptedUnicode(b'ciphertext')) == '!vault |\n          cGljaGVydGV4dAo=\n'

# Generated at 2022-06-20 23:56:49.362143
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper()
    assert dumper.__class__ == AnsibleDumper
    assert dumper.encoding == 'utf-8'
    assert yaml.SafeDumper.add_representer in dumper.__dict__['yaml_representers'].keys()


# Generated at 2022-06-20 23:56:50.177447
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper



# Generated at 2022-06-20 23:56:57.821381
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    ansible_dumper = AnsibleDumper()
    assert isinstance(ansible_dumper, AnsibleDumper)
    assert isinstance(ansible_dumper, yaml.representer.SafeRepresenter)


# Generated at 2022-06-20 23:57:07.934529
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(AnsibleUnsafeBytes(b'foo'), Dumper=AnsibleDumper) == 'foo'
    assert yaml.dump(AnsibleUnsafeBytes(b'foo\nbar'), Dumper=AnsibleDumper) == 'foo\nbar'
    assert yaml.dump(AnsibleUnsafeBytes(b'foo\tbar'), Dumper=AnsibleDumper) == 'foo\tbar'
    assert yaml.dump(AnsibleUnsafeBytes(b'foo\rbar'), Dumper=AnsibleDumper) == 'foo\rbar'
    assert yaml.dump(AnsibleUnsafeBytes(b'foo\x00bar'), Dumper=AnsibleDumper) == 'foo\x00bar'

# Generated at 2022-06-20 23:57:13.922788
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, u'unicode') == u'unicode'
    assert represent_unicode(None, u'unicode') == u'unicode'
    assert represent_unicode(None, b'byte string') == u'byte string'
    assert represent_unicode(None, 2) == u'2'
    assert represent_unicode(None, 2.0) == u'2.0'
    assert represent_unicode(None, True) == u'true'
    assert represent_unicode(None, False) == u'false'
    assert represent_unicode(None, None) == u'null'

# Generated at 2022-06-20 23:57:16.743741
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper(), yaml.dumper.Dumper)

# Constructs a new YAML dumper with the default parameters

# Generated at 2022-06-20 23:57:25.731869
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultEditor

    vault_text = VaultEditor.encrypt_string("secret", VaultLib())
    secret = AnsibleVaultEncryptedUnicode(vault_text)

# Generated at 2022-06-20 23:57:35.313283
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper

    # AnsibleUndefined
    value = AnsibleUndefined
    assert yaml.representer.SafeRepresenter.represent_undefined(dumper, value)
    assert represent_undefined(dumper, value)

    # StrictUndefined
    from jinja2.runtime import StrictUndefined
    value = StrictUndefined
    assert yaml.representer.SafeRepresenter.represent_undefined(dumper, value)
    assert represent_undefined(dumper, value)

    # Undefined
    from jinja2.runtime import Undefined
    value = Undefined
    assert not yaml.representer.SafeRepresenter.represent_undefined(dumper, value)
    assert represent_undefined(dumper, value)

# Generated at 2022-06-20 23:57:46.451288
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = AnsibleVaultEncryptedUnicode("hello world")
    actual = yaml.dump(data, Dumper=AnsibleDumper)

# Generated at 2022-06-20 23:57:48.034711
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper()
    assert isinstance(dumper, yaml.SafeDumper)

# Generated at 2022-06-20 23:57:54.727812
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = AnsibleVaultEncryptedUnicode(u'$ANSIBLE_VAULT;1.1;AES256\n3633316462363732656135616335333764313264386237613339666332346335453755663665653\n62323730356536396365616266650a346637376166623537653734643039636539373666326438\n643665346439343364653461386132386162363133393737653334666630643439313563333938\n3336353032373066\n')
    output = represent_vault_encrypted_unicode(data)

# Generated at 2022-06-20 23:57:56.054035
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():

    # Tested in test_playbook
    pass

# Generated at 2022-06-20 23:58:10.317623
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-20 23:58:14.074450
# Unit test for function represent_undefined
def test_represent_undefined():
    a = AnsibleUndefined(str(AnsibleUndefined()))
    a_str = str(a)
    assert a_str == 'VARIABLE IS NOT DEFINED!'
    assert bool(a) == False
    # Now make sure bool is actually creating the error
    try:
        bool(a)
    except AssertionError as e:
        assert 'AnsibleUndefinedVars' in str(e)

# Generated at 2022-06-20 23:58:15.310299
# Unit test for function represent_unicode
def test_represent_unicode():
    test_value = u"Hello World!"
    result = represent_unicode(None, test_value)
    assert 'Hello World!' == result

# Generated at 2022-06-20 23:58:21.221496
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import AnsibleUndefined
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources

    # Mock instance of AnsibleDumper
    foo = AnsibleDumper()

    # Test AnsibleUndefinedNod
    assert represent_undefined(foo, AnsibleUndefined())

    # Test HostVars and VarsWithSources
    assert represent_undefined(foo, HostVars('foo'))
    assert represent_undefined(foo, VarsWithSources('foo'))

# Generated at 2022-06-20 23:58:24.767764
# Unit test for function represent_unicode
def test_represent_unicode():
    import yaml
    yaml.add_representer(unicode, represent_unicode)
    s = yaml.dump(dict(a=u'\xfc'))
    assert s == u'{a: "\xfc"}\n'



# Generated at 2022-06-20 23:58:27.341103
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hv = HostVars()
    hv["eth0"] = dict(macaddress="12:34:56:78:90:12")
    d = dict(hv)
    assert d == dict(eth0=dict(macaddress="12:34:56:78:90:12"))

# Generated at 2022-06-20 23:58:33.292324
# Unit test for function represent_unicode
def test_represent_unicode():
    data = {
        'foo': AnsibleUnicode('bar'),
        'baz': AnsibleUnicode('spam'),
    }
    result = yaml.dump(data, Dumper=AnsibleDumper)
    assert result == '{foo: bar, baz: spam}\n'
    assert isinstance(result, text_type)


# Tests to ensure that type errors are properly emitted

# Generated at 2022-06-20 23:58:43.609303
# Unit test for function represent_unicode
def test_represent_unicode():
    '''represent_unicode should encode a string as needed'''
    assert represent_unicode(None, AnsibleUnicode(u'Ivan Krsti\u0107')) == u"? 'Ivan Krstić'"
    assert represent_unicode(None, AnsibleUnicode(u'Ivan Krstić')) == u"? 'Ivan Krstić'"
    assert represent_unicode(None, AnsibleUnicode(u'Ivan \x00 Krstić')) == u"? 'Ivan \\x00 Krstić'"
    assert represent_unicode(None, AnsibleUnicode(u'Ivan Krstić\x00')) == u"? 'Ivan Krstić\\x00'"

    # The test unicode string is 4-bytes long.
    # However, the character

# Generated at 2022-06-20 23:58:45.769514
# Unit test for function represent_binary
def test_represent_binary():
    result = represent_binary(AnsibleDumper, b'\x00')
    assert result == b'!!binary |-\n  AA==\n'

# Generated at 2022-06-20 23:58:51.243095
# Unit test for function represent_unicode
def test_represent_unicode():

    yaml.add_representer(
        AnsibleUnicode,
        represent_unicode,
    )

    # '\xc3\xbc' is a unicode character
    data = {'unicode_key': AnsibleUnicode(u'\xc3\xbc')}

    # If a unicode character is represented as a string
    # in AnsibleUnsafeText, it will be dumped as a unicode string
    assert yaml.dump(data, Dumper=AnsibleDumper) == "unicode_key: '\xc3\xbc'\n"

# Generated at 2022-06-20 23:59:11.737348
# Unit test for function represent_hostvars
def test_represent_hostvars():
    input = {'foo': 'bar', 'baz': 'faz'}
    output = yaml.dump({'ansible_vars': HostVars(input)}, Dumper=AnsibleDumper, default_flow_style=False)
    assert output == 'ansible_vars:\n  foo: bar\n  baz: faz\n'



# Generated at 2022-06-20 23:59:12.994658
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    repr = repr(AnsibleDumper)
    assert repr



# Generated at 2022-06-20 23:59:13.899848
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper is not None



# Generated at 2022-06-20 23:59:16.436381
# Unit test for function represent_undefined
def test_represent_undefined():
    representer = AnsibleDumper()
    assert not representer.represent_undefined(AnsibleUndefined(None, None))

# Generated at 2022-06-20 23:59:19.408755
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = {
        'a': 1,
        'b': 2,
    }
    assert AnsibleDumper().represent_hostvars(data) == '{a: 1, b: 2}'



# Generated at 2022-06-20 23:59:25.225301
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    res = AnsibleDumper(indent=2, width=80)
    assert isinstance(res, yaml.representer.SafeRepresenter)
    assert res.default_flow_style is False
    assert res.default_style is ''
    assert res.default_indent is 2
    assert res.explicit_start is True
    assert res.explicit_end is True
    assert res.canonical is False
    assert res.width is 80
    assert res.allow_unicode is True

# Generated at 2022-06-20 23:59:33.832293
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vault = VaultLib([])

    plaintext = AnsibleUnsafeText(u'foo')
    encrypted = AnsibleVaultEncryptedUnicode(vault.encrypt(plaintext))
    assert encrypted

    dumper = AnsibleDumper()
    dumper.represent_vault_encrypted_unicode(encrypted)
    # Need to see that the output is valid yaml
    yaml.safe_load(dumper.dump([encrypted]))



# Generated at 2022-06-20 23:59:38.090289
# Unit test for function represent_unicode
def test_represent_unicode():

    # Create a list of test data and results
    test_data = [u'', u'\r\n', u'\\r\\n', u'\xa0', u'\u3000']
    test_results = [u'', u'\\r\\n', u'\\\\r\\\\n', u'\\xa0', u'\\u3000']

    dumper = AnsibleDumper()
    for test_val, result in zip(test_data, test_results):
        assert dumper.represent_unicode(test_val) == result

# Generated at 2022-06-20 23:59:42.644666
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible_collections.ansible.community.plugins.filter.vault import _decrypt
    yaml_str = "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          3966653466303564383239386261626532323339323661653433613239623331306235346365333266\n          3430343732626363663231633763353563643565663237383339616239396233656232643563613939\n          65383531356233333062396336\n"

# Generated at 2022-06-20 23:59:44.201744
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode(u"unicode")) == '"unicode"\n'



# Generated at 2022-06-21 00:00:02.272394
# Unit test for function represent_binary
def test_represent_binary():
    # test to make sure it works with b'' type
    obj = AnsibleUnsafeBytes(b'\xff\xfe\xfd')
    yaml.dump(obj, Dumper=AnsibleDumper)

# Generated at 2022-06-21 00:00:09.266949
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert dict(yaml.load("""
a:
  b: a
""", Loader=yaml.FullLoader)) == {'a': {'b': 'a'}}

    assert dict(yaml.load("""
a:
  b:
    c: a
""", Loader=yaml.FullLoader)) == {'a': {'b': {'c': 'a'}}}

    assert dict(yaml.load("""
a: [{b: a}]
""", Loader=yaml.FullLoader)) == {'a': [{'b': 'a'}]}

# Generated at 2022-06-21 00:00:14.408026
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    result = yaml.dumps(AnsibleVaultEncryptedUnicode("foobar"))
    assert result == "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          666262613636663462643362313164303862313066663261323165373762356338613730653562\n          643036363264386134396239633231353138613331353264\n          313333623630306166396539633365316531396335366139\n          35383639343735\n"

# Generated at 2022-06-21 00:00:25.414200
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hvars = HostVars()
    hvars.foo = 'bar'
    hvars.hostvars['host1'] = 'host1'
    hvars.hostvars['host2'] = 'host2'
    hvars.hostvars['host3'] = 'host3'

    data = yaml.dump(hvars, default_flow_style=False)
    expected = 'foo: bar\nhostvars:\n  host1: host1\n  host2: host2\n  host3: host3\n'
    assert data == expected

    data = yaml.dump(hvars, default_flow_style=True)
    expected = '{foo: bar, hostvars: {host1: host1, host2: host2, host3: host3}}\n'


# Generated at 2022-06-21 00:00:33.295320
# Unit test for function represent_binary
def test_represent_binary():
    # Test simple binary safe data
    data = 'FOO'
    output = yaml.dump(data, default_flow_style=False, Dumper=AnsibleDumper)
    assert output == '!!binary |\n  Rk9P\n'

    # Test binary safe data that is not safe when used as value (contains | or >)
    data = 'FO|O'
    output = yaml.dump(data, default_flow_style=False, Dumper=AnsibleDumper)
    assert output == '!!binary "Rk9PXw=="\n'

    data = 'FO>O'
    output = yaml.dump(data, default_flow_style=False, Dumper=AnsibleDumper)
    assert output == '!!binary "Rk9PPg=="\n'

   

# Generated at 2022-06-21 00:00:41.383733
# Unit test for function represent_unicode
def test_represent_unicode():
    from ansible.module_utils.six import PY3
    from ansible.parsing.yaml.constructor import AnsibleConstructor

    # Multi byte characters for testing
    uni_str = u"ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖ×ØÙÚÛÜÝÞßàáâãäåæçèéêëìíîïðñòóôõö÷øùúûüýþÿ"
    bin_str = bytearray(uni_str.encode('utf-8'))
    unsafe = AnsibleUnsafeBytes(bin_str)
    # This is the way to make original(uni_