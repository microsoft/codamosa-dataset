

# Generated at 2022-06-20 23:50:42.295600
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    ret = dumper.represent_binary(b'\x01\x02')
    assert ret.value == '!!binary |\n  AQI=\n', 'unexpected representation of test binary data'

# Generated at 2022-06-20 23:50:50.026512
# Unit test for function represent_hostvars
def test_represent_hostvars():

    h1 = HostVars('localhost', {'a': '12345'})
    h2 = HostVarsVars({'a': '12345'})
    v1 = VarsWithSources({'a': '12345'}, ['file'])

    dumper = AnsibleDumper()

    data = {
        'h1': h1,
        'h2': h2,
        'v1': v1,
    }
    got = yaml.dump(data, Dumper=dumper)

    want = (
        'h1: {a: 12345}\n'
        'h2: {a: 12345}\n'
        'v1: {a: 12345}\n'
    )

    assert got == want

# Generated at 2022-06-20 23:50:58.614833
# Unit test for function represent_binary

# Generated at 2022-06-20 23:51:00.882272
# Unit test for function represent_binary
def test_represent_binary():
    data = b'\x00\x01\x02'
    yaml.dump(data, Dumper=AnsibleDumper)

# Generated at 2022-06-20 23:51:09.039396
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert yaml.dump({'a': 'b', 'c': 'd'}, Dumper=AnsibleDumper) == 'a: b\nc: d\n'
    assert yaml.dump(HostVars({'a': 'b', 'c': 'd'}), Dumper=AnsibleDumper) == 'a: b\nc: d\n'
    assert yaml.dump(HostVarsVars({'a': 'b', 'c': 'd'}), Dumper=AnsibleDumper)\
        == 'a: b\nc: d\n'



# Generated at 2022-06-20 23:51:10.273694
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper.representer.represent_undefined(None)



# Generated at 2022-06-20 23:51:17.242757
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    test = AnsibleVaultEncryptedUnicode(b'\x00\x00\x00\x00')

# Generated at 2022-06-20 23:51:24.914887
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Test with decode()
    dumper = yaml.representer.SafeRepresenter()
    dumper.represent_vault_encrypted_unicode = represent_vault_encrypted_unicode
    value = AnsibleVaultEncryptedUnicode('12345678901234567890123456789012')
    output = dumper.represent_vault_encrypted_unicode(value)
    assert output.value == '!vault |\n          AAEAABjdHlwZQAAAABVbmljYXN0VmF1bHRBQ0NQcm9jZXNzU2VjdXJlVW5pY2FzdFZhdWx0\n          AAAAUGFzc3dvcmQACg==\n'

    # Test without decode()
    d

# Generated at 2022-06-20 23:51:34.574978
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper
    assert dumper.represent_hostvars(dumper, HostVars({}, {'x': 'y'})) == dumper.represent_dict(dumper, dict(x='y'))
    assert dumper.represent_hostvars(dumper, HostVars({}, [])) == dumper.represent_dict(dumper, {})
    assert dumper.represent_hostvars(dumper, HostVars({}, set())) == dumper.represent_dict(dumper, {})
    assert dumper.represent_hostvars(dumper, HostVars({}, None)) == dumper.represent_dict(dumper, {})



# Generated at 2022-06-20 23:51:37.444064
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'bytestring') == u'!!binary "Ynl0ZXN0cmluZw==\n"'

# Generated at 2022-06-20 23:51:45.554776
# Unit test for function represent_undefined
def test_represent_undefined():
    """Test represent_undefined function
    """
    data = AnsibleUndefined()
    dumper = AnsibleDumper()
    try:
        # If represent_undefined function does not work as expected,
        # our unit test will fail
        bool(dumper.represent_undefined(data))
    except jinja2.exceptions.UndefinedError:
        pass

# Generated at 2022-06-20 23:51:51.820835
# Unit test for function represent_hostvars
def test_represent_hostvars():

    host = HostVars()
    host.add_host('host1', 'group1')
    host.add_host('host2', 'group2')
    host.add_host('host3', 'group2')
    host.add_host('host4')

    host['host1']['var1'] = 'value1'
    host['host1']['var2'] = 'value2'
    host['host2']['var3'] = 'value3'
    host['host3']['var4'] = 'value4'
    host['host4']['var5'] = 'value5'
    host['host4']['var6'] = 'value6'

    # Exercise the hostvars object
    assert host['host1']['var1'] == 'value1'

# Generated at 2022-06-20 23:51:56.170223
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = { 'x': 'y' }
    dumper = AnsibleDumper()
    res = dumper.represent_hostvars(data)
    assert res == yaml.representer.SafeRepresenter.represent_dict(dumper, data)

# Generated at 2022-06-20 23:51:57.598727
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper().represent_data(None) == ''

# Generated at 2022-06-20 23:52:00.772145
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper is not None
    assert isinstance(AnsibleDumper, type)
    assert issubclass(AnsibleDumper, SafeDumper)



# Generated at 2022-06-20 23:52:04.335593
# Unit test for function represent_binary
def test_represent_binary():

    class Dumper(AnsibleDumper):
        pass

    dumper = Dumper()

    assert dumper.represent_binary(b'\x00\x01\x02\x03') == "!!binary |\n  AAECAQ==\n"

# Generated at 2022-06-20 23:52:07.239821
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(None) is False
    assert dumper.represent_undefined(AnsibleUndefined) is True

# Generated at 2022-06-20 23:52:11.782039
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    data = AnsibleVaultEncryptedUnicode(u'this_is_a_secret$', vault, u'!vault')
    dumper = AnsibleDumper()

# Generated at 2022-06-20 23:52:19.479418
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml import objects

    test_data = {
        u'testvar1': u'testvar1_value',
        u'testvar2': u'testvar2_value',
    }

    hv = objects.HostVars(vars=test_data)

    assert hv and hv.vars
    assert hv.vars == hv

    assert yaml.dump(hv) == yaml.dump(test_data)

# Generated at 2022-06-20 23:52:20.907591
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    AnsibleDumper(yaml.representer.SafeRepresenter)

# Generated at 2022-06-20 23:52:30.205571
# Unit test for function represent_hostvars
def test_represent_hostvars():
    AnsibleDumper.add_representer(
        AnsibleUnicode,
        represent_unicode,
    )

    data = {'foo': 'bar'}
    data = HostVars(hostvars=data)
    output = '{foo: bar}\n'
    assert(yaml.dump(data, Dumper=AnsibleDumper) == output)

# Generated at 2022-06-20 23:52:32.001424
# Unit test for function represent_unicode
def test_represent_unicode():
    yaml.dump(dict(foo="bar"), Dumper=AnsibleDumper)


# Generated at 2022-06-20 23:52:38.440788
# Unit test for function represent_unicode
def test_represent_unicode():
    # Stub the object. yaml.safe_dump would normally wrap this object in
    # the AnsibleDumper class
    class Stub:
        def represent_scalar(self, tag, value, style=None):
            return yaml.representer.SafeRepresenter.represent_unicode(self, value)

    stub = Stub()
    assert(represent_unicode(stub, 'foo') == u"'foo'")
    assert(represent_unicode(stub, '') == u"''")
    assert(represent_unicode(stub, '\n') == u"'\n'")
    assert(represent_unicode(stub, '\t') == u"'\t'")
    assert(represent_unicode(stub, '\r') == u"'\r'")

# Generated at 2022-06-20 23:52:44.713240
# Unit test for function represent_undefined
def test_represent_undefined():
    # we are testing with an empty AnsibleUnsafeText since we have a different
    # repr method registered for it.
    test1 = AnsibleUnsafeText()
    assert AnsibleUnsafeText() != True

    the_yaml = yaml.dump(test1)
    assert the_yaml == 'null\n'

    # ensure that it is still true inside the yaml-based variable
    assert yaml.load(the_yaml) == True

# Generated at 2022-06-20 23:52:49.906489
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dump_data = dict(key1='value1', key2='value2')
    dump_data = HostVars(dump_data)
    data = yaml.dump(dump_data, Dumper=AnsibleDumper)
    assert data == 'key1: value1\nkey2: value2\n'

# Generated at 2022-06-20 23:52:51.007925
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    temp = AnsibleDumper



# Generated at 2022-06-20 23:53:02.094167
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = yaml.SafeDumper

# Generated at 2022-06-20 23:53:05.863216
# Unit test for function represent_undefined
def test_represent_undefined():
    AnsibleDumper.add_representer(
        AnsibleUndefined,
        represent_undefined,
    )
    assert yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper) == 'false'

# Generated at 2022-06-20 23:53:07.952707
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert issubclass(AnsibleDumper, yaml.Dumper), "AnsibleDumper is not subclass of yaml.Dumper"

# Generated at 2022-06-20 23:53:20.008561
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from textwrap import dedent
    from ansible.utils.unsafe_proxy import to_unsafe_text
    hostvars = HostVars(
        hostname='example.org',
        vars={"test": to_unsafe_text(u"\u203d"), "test1": to_unsafe_text(u"\u203d"), "test2": to_unsafe_text(u"\u203d")}
    )

    dumper = AnsibleDumper
    dump = dedent('''\
        hostname: example.org
        test: "‽"
        test1: "‽"
        test2: "‽"
    ''')
    result = yaml.dump([hostvars], Dumper=dumper, default_flow_style=False)
    assert result == dump


# Generated at 2022-06-20 23:53:25.119184
# Unit test for function represent_undefined
def test_represent_undefined():
    assert not AnsibleDumper.represent_undefined(AnsibleUndefined())

# Generated at 2022-06-20 23:53:26.900896
# Unit test for function represent_binary
def test_represent_binary():
    s = AnsibleDumper.represent_binary(None, 'héllo')
    assert s == "!!binary |\n  aMOxbGzDp2zDpg==\n"

# Generated at 2022-06-20 23:53:31.030879
# Unit test for function represent_binary
def test_represent_binary():
    test_data = b"\xa7\x9b\xd2"
    dumper = AnsibleDumper.for_data(test_data)
    dumper_output = dumper.represent_data(test_data)
    assert(dumper_output == binary_type(test_data, 'utf-8'))



# Generated at 2022-06-20 23:53:33.112562
# Unit test for function represent_unicode
def test_represent_unicode():
    ''' represent_unicode should return a string when passed a string '''
    answer = represent_unicode('hello')
    assert answer == 'hello'



# Generated at 2022-06-20 23:53:38.789128
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    encrypted_text = vault.encrypt("test_text")
    text_type("test_text")

# Generated at 2022-06-20 23:53:50.391768
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

# Generated at 2022-06-20 23:53:53.792699
# Unit test for function represent_undefined
def test_represent_undefined():
    import yaml
    assert yaml.safe_load(yaml.dump(yaml.undefined, Dumper=AnsibleDumper)) is False

# Generated at 2022-06-20 23:54:00.013391
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    # and str (which is the same as text_type)
    assert dumper.represent_unicode(u'foo') == u"'foo'"
    assert dumper.represent_unicode(b'foo') == u"'foo'"
    assert dumper.represent_unicode(AnsibleUnicode(u'foo')) == u"'foo'"



# Generated at 2022-06-20 23:54:09.366685
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible import constants as C
    from ansible.template import Templar

    templar = Templar(loader=None, variables={})
    assert templar.template({'foo': C.DEFAULT_UNDEFINED_VAR_BEHAVIOR}, fail_on_undefined=False) == dict(foo='')
    assert templar.template({'foo': C.DEFAULT_UNDEFINED_VAR_BEHAVIOR}, fail_on_undefined=True) == dict(foo='')

    # This line should not throw an exception
    yaml.dump({'foo': C.DEFAULT_UNDEFINED_VAR_BEHAVIOR}, Dumper=AnsibleDumper)

    # This line should not throw an exception

# Generated at 2022-06-20 23:54:13.355693
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = dict(
        a=1,
        b=2,
    )
    result = yaml.dump(HostVars(data), Dumper=AnsibleDumper)
    assert result == '---\na: 1\nb: 2\n'



# Generated at 2022-06-20 23:54:21.005484
# Unit test for function represent_hostvars
def test_represent_hostvars():
    expected_data = '{}'
    test_vars = HostVars(dict())
    data = yaml.safe_dump(test_vars, default_flow_style=False, Dumper=AnsibleDumper)
    assert data == expected_data

# Generated at 2022-06-20 23:54:28.275536
# Unit test for function represent_undefined
def test_represent_undefined():
    """Test function represent_undefined

    Test the represent_undefined function when the value is
    an AnsibleUndefined value.
    """
    import pytest
    dumper = AnsibleDumper
    ansible_undefined = AnsibleUndefined('foo')
    actual = dumper.represent_undefined(dumper, ansible_undefined)
    with pytest.raises(AnsibleUndefined) as ex:
        bool(actual)
    assert ex.value.message == ansible_undefined.message

# Generated at 2022-06-20 23:54:29.692683
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper.add_representer is not None


# Generated at 2022-06-20 23:54:31.834150
# Unit test for function represent_undefined
def test_represent_undefined():
    r = AnsibleDumper()
    # Scalar
    v = AnsibleUndefined()
    result = r.represent_undefined(v)
    assert result is False

    # Sequence
    v = [AnsibleUndefined()]
    result = r.represent_undefined(v)
    assert result is False

    # Mapping
    v = {'x': AnsibleUndefined()}
    result = r.represent_undefined(v)
    assert result is False

# Generated at 2022-06-20 23:54:36.441792
# Unit test for function represent_binary
def test_represent_binary():
    buf = bytearray()
    dumper = AnsibleDumper(buf)

    # utf-8 'é'
    assert dumper.represent_binary(bytearray([0xc3, 0xa9])) == u'!binary |\n  w6k=\n'

    # latin-1 'é'
    assert dumper.represent_binary(bytearray([0xe9])) == u'!binary |\n  gw==\n'

# Generated at 2022-06-20 23:54:47.728408
# Unit test for function represent_unicode
def test_represent_unicode():
    '''
    This tests that the AnsibleUnicode object is dumped as a string.
    '''

    from io import BytesIO
    from ansible.template import Templar

    fake_loader = DictDataLoader({'foo.yml': '''
- 1
- 'foo'
- baz

- { foo: 'bar', 'foo2': 'bar2' }
'''})
    t = Templar(loader=fake_loader)
    data = t.template('foo.yml')

    yaml_data = BytesIO()
    yaml.dump(data, yaml_data, Dumper=AnsibleDumper, default_flow_style=False)
    yaml_data = yaml_data.getvalue()


# Generated at 2022-06-20 23:54:53.408464
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # Make some data
    data = HostVars(dict(ansible_os_family='Debian', ansible_distribution='Ubuntu'))
    # Check output
    assert yaml.dump(data, Dumper=AnsibleDumper) == "ansible_os_family: Debian\nansible_distribution: Ubuntu\n"



# Generated at 2022-06-20 23:54:56.044341
# Unit test for function represent_undefined
def test_represent_undefined():
    '''
    was causing a crash, issue #24392
    '''
    assert yaml.dump([AnsibleUndefined()], Dumper=AnsibleDumper) == '[]\n'

# Generated at 2022-06-20 23:55:00.618477
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # Create a HostVars object
    foo = dict(somekey='somevalue')
    hostvars = HostVars(foo, '')
    # Serialize the HostVars object to a YAML string
    yaml_string = yaml.dump(hostvars, default_flow_style=False)
    # Ensure the YAML string matches expectations - it should be the
    # serialized version of the dict inside the HostVars object
    assert yaml_string == 'somekey: somevalue\n...\n'



# Generated at 2022-06-20 23:55:02.543203
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.dump(AnsibleUndefined()) == u'_undefined_'

# Generated at 2022-06-20 23:55:17.880015
# Unit test for function represent_hostvars
def test_represent_hostvars():
    loader = yaml.SafeLoader
    assert len(loader.yaml_constructors) == len(yaml.SafeLoader.yaml_constructors)

    # Note: TestVarsWithSource.var1.value is a str of '1'
    #       TestVarsWithSource.var2.value is a int of 2
    #       TestVarsWithSource.var3.value is a bool of True

# Generated at 2022-06-20 23:55:26.743106
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib()
    secret = vault.encrypt(u'secret')
    assert type(secret) is AnsibleVaultEncryptedUnicode
    yaml_dump = yaml.dump([secret], Dumper=AnsibleDumper)
    yaml_dump = yaml_dump.replace(secret._ciphertext.decode(), u'xxx')
    assert yaml_dump == u'- !vault |\n  $ANSIBLE_VAULT;1.1;AES256\n  xxx\n  \n  \n  \n'

# Generated at 2022-06-20 23:55:31.024371
# Unit test for function represent_hostvars
def test_represent_hostvars():
    d = HostVars(dict(a=2, b=dict(c=3)))
    assert yaml.load(yaml.dump(d, Dumper=AnsibleDumper)) == dict(a=2, b=dict(c=3))



# Generated at 2022-06-20 23:55:34.714307
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper(None, default_flow_style=False)
    data = AnsibleUnicode('foo')
    data_repr = dumper.represent_unicode(data)

    assert data_repr.value == u"'foo'"



# Generated at 2022-06-20 23:55:38.328902
# Unit test for function represent_unicode
def test_represent_unicode():
    data = "abcd"
    dumper = AnsibleDumper()
    r = dumper.represent_unicode(data)

    assert r is not None


# Generated at 2022-06-20 23:55:40.764919
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    AnsibleDumper()


# unit test for method of class AnsibleDumper represent_vault_encrypted_unicode
# given input to method
# return None

# Generated at 2022-06-20 23:55:46.458760
# Unit test for function represent_binary
def test_represent_binary():
    """
    Test to ensure that binary data is dumped instead of being
    escaped.

    This is important in order to dump SSH keys to files
    """
    binary_data = b"\xff\x00\xff\x00\xff"
    escaped_binary_data = binary_data.decode('string_escape')
    dumped = yaml.dump(binary_data, Dumper=AnsibleDumper)
    if binary_data not in dumped:
        assert(escaped_binary_data in dumped)

# Generated at 2022-06-20 23:55:48.273810
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert "test_AnsibleDumper" == AnsibleDumper.__name__



# Generated at 2022-06-20 23:55:57.807027
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    result = dumper.represent_binary(u'foo')
    assert isinstance(result, str)
    assert isinstance(result, binary_type)
    result = dumper.represent_binary(b'foo')
    assert isinstance(result, str)
    assert isinstance(result, binary_type)
    result = dumper.represent_binary(b'f\\x6f')
    assert isinstance(result, str)
    assert isinstance(result, binary_type)
    result = dumper.represent_binary(b'f\\x6fo')
    assert isinstance(result, str)
    assert isinstance(result, binary_type)

# Generated at 2022-06-20 23:56:00.776271
# Unit test for function represent_undefined
def test_represent_undefined():
    obj = AnsibleUndefined()
    try:
        AnsibleDumper.add_representer(
            AnsibleUndefined,
            represent_undefined,
        )
    except AssertionError:
        pass

# Generated at 2022-06-20 23:56:23.038755
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template.safe_eval import Undefined
    dumper = AnsibleDumper(undefined_str=None)
    data = AnsibleUndefined()
    output = dumper.represent_data(data)
    assert output is Undefined
    data = AnsibleUndefined(fail_on_undefined=True)
    output = dumper.represent_data(data)
    assert output is True

# Generated at 2022-06-20 23:56:26.863050
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.manager import VariableManager

    variables = VariableManager()
    variables.add_host_vars('testhost', {'foo': 'bar', 'baz': 'bam'})

    assert yaml.dump(variables._hostvars, Dumper=AnsibleDumper) == '''{testhost: {baz: bam, foo: bar}}
'''



# Generated at 2022-06-20 23:56:28.066256
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper.__bases__ == (SafeDumper,)

# Generated at 2022-06-20 23:56:38.441180
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-20 23:56:39.796579
# Unit test for function represent_undefined
def test_represent_undefined():
    assert represent_undefined('AnsibleDumper', AnsibleUndefined())



# Generated at 2022-06-20 23:56:45.637683
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.module_utils.six import StringIO
    from ansible.parsing.yaml import objects

    ds = dict(foo='bar')
    hv = objects.HostVars(ds)
    stream = StringIO()
    dumper = AnsibleDumper(stream, default_flow_style=False)
    dumper.represent_hostvars(hv)
    assert stream.getvalue() == "{foo: bar}"

# Generated at 2022-06-20 23:56:47.153291
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert hasattr(AnsibleDumper, 'add_representer')

# Generated at 2022-06-20 23:56:53.536322
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # Create hostvars object
    hostvars = HostVars("hostname")
    vars = dict(
        google="good",
        yahoo="ok",
        bing="great",
    )

    # Set the variables
    for k, v in vars.items():
        hostvars.set_variable(k, v)

    # Dump the hostvars
    dumped_hostvars = yaml.dump(hostvars, Dumper=AnsibleDumper)

    # Load the dumped hostvars
    loaded_hostvars = yaml.safe_load(dumped_hostvars)

    # Test loaded hostvars
    assert loaded_hostvars == vars

# Generated at 2022-06-20 23:56:57.398862
# Unit test for function represent_unicode
def test_represent_unicode():
    _u = AnsibleUnicode(u'foo \u2665 bar')
    assert yaml.dump(_u, Dumper=AnsibleDumper) ==  "'foo \u2665 bar'\n"


# Generated at 2022-06-20 23:56:58.387672
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper is not None

# Generated at 2022-06-20 23:57:11.630581
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = HostVars(vars=dict(a=1,b=2,c=3))
    assert yaml.dump(hostvars, Dumper=AnsibleDumper) == '{a: 1, b: 2, c: 3}\n'

# Generated at 2022-06-20 23:57:16.839832
# Unit test for function represent_unicode
def test_represent_unicode():
    sample_data = u'{"key": "漢字"}'
    data = yaml.load(sample_data)
    yaml_data = yaml.dump(data, Dumper=AnsibleDumper, default_flow_style=False)
    assert yaml_data == u"key: '漢字'\n"


# Generated at 2022-06-20 23:57:18.597576
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    t = AnsibleDumper()
    assert t



# Generated at 2022-06-20 23:57:24.886624
# Unit test for function represent_binary
def test_represent_binary():
    assert_bytes = b'''
!!binary |
    dGVzdAo=
'''
    assert_str = u'''
!!binary |
    dGVzdAo=
'''

    data = b'test\n'
    assert AnsibleDumper.represent_binary(data) == assert_bytes
    assert yaml.round_trip_load(assert_bytes) == data

    data = u'test\n'
    assert AnsibleDumper.represent_binary(data) == assert_str
    assert yaml.round_trip_load(assert_str) == data

# Generated at 2022-06-20 23:57:27.479933
# Unit test for function represent_hostvars
def test_represent_hostvars():
    yaml_data = u'---\n{}\n...\n'
    hostvars = HostVars()
    dumps_data = yaml.dump(hostvars, Dumper=AnsibleDumper)
    assert dumps_data == yaml_data



# Generated at 2022-06-20 23:57:30.444234
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary('ça va') == "!binary |\n  xc3xaa\n  2076\n  6120"

# Generated at 2022-06-20 23:57:41.236617
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    undefined = AnsibleUndefined

    # AnsibleUndefined() must return True if it is undefined
    assert(bool(undefined()) is True)

    # AnsibleUndefined() must retrun False if it is not undefined
    assert(bool(undefined(var='_undefined_')) is False)

    # When we pass AnsibleUndefined() to represent_undefined,
    # it should return an empty string
    assert(dumper.represent_undefined(dumper, undefined()) == '')
    assert(dumper.represent_undefined(dumper, undefined(var='_undefined_')) == '')

    # When we pass AnsibleUndefined(var='_undefined_') to
    # represent_undefined, it should return a string representation
    # of AnsibleUndefined

# Generated at 2022-06-20 23:57:51.105444
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-20 23:58:00.057748
# Unit test for function represent_binary
def test_represent_binary():
    dumper = yaml.representer.SafeRepresenter()
    dumper.add_representer(
        AnsibleUnsafeBytes,
        represent_binary,
    )

    test_data = AnsibleUnsafeBytes(b'123\x00')
    # UnsafeBytes was added in py2.7 https://github.com/ansible/ansible/issues/33884
    if hasattr(test_data, '_encoded'):
        assert dumper.represent_binary(test_data) == '!!binary 123\\0'
    else:
        assert dumper.represent_binary(test_data) == '!!binary |-\n  123\\000'

    test_data = AnsibleUnsafeBytes(b'123')

# Generated at 2022-06-20 23:58:10.138075
# Unit test for function represent_unicode
def test_represent_unicode():
    class AnsibleDumper(SafeDumper):
        '''
        A simple stub class that allows us to add representers
        for our overridden object types.
        '''

    AnsibleDumper.add_representer(
        AnsibleUnicode,
        represent_unicode,
    )

    ret = yaml.safe_dump('föö', Dumper=AnsibleDumper)
    assert ret == "föö\n"

    ret = yaml.safe_dump(['föö'], Dumper=AnsibleDumper)
    assert ret == "- föö\n"

    ret = yaml.safe_dump({'föö': 'bär'}, Dumper=AnsibleDumper)
    assert ret == "föö: bär\n"



# Generated at 2022-06-20 23:58:39.169277
# Unit test for function represent_unicode
def test_represent_unicode():
    represent_unicode(SafeDumper, u"This is a test")
    represent_unicode(SafeDumper, u"This is a test with a \u2022")
    represent_unicode(SafeDumper, u"This is a test with a \uFEFF")

# Generated at 2022-06-20 23:58:44.392597
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

    class FakeVaultData:
        _ciphertext = b'foo'

    fake_vault_data = FakeVaultData()
    vault_data = represent_vault_encrypted_unicode(dumper, fake_vault_data)
    assert vault_data == '!vault |\n          Zm9v\n'

# Generated at 2022-06-20 23:58:51.893510
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, 'spam') == yaml.representer.SafeRepresenter.represent_str(None, 'spam')
    assert represent_unicode(None, '\ud83d\ude0e') == yaml.representer.SafeRepresenter.represent_str(None, '\\ud83d\\ude0e')
    assert represent_unicode(None, '\ud83d\udc4c') == yaml.representer.SafeRepresenter.represent_str(None, '\\ud83d\\udc4c')
    assert represent_unicode(None, '\u2615') == yaml.representer.SafeRepresenter.represent_str(None, '\\u2615')
    assert represent_unicode(None, '\u1f600') == yaml.representer.SafeRepresenter.represent_

# Generated at 2022-06-20 23:58:55.147703
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    u = u'\u6b22'
    assert dumper.represent_scalar(u'tag:yaml.org,2002:str', u) == "--- '%s'\n...\n" % u

# Generated at 2022-06-20 23:58:56.746549
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper, type)



# Generated at 2022-06-20 23:59:02.072013
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()
    test_data = '$ANSIBLE_VAULT;1.1;AES256'
    expected_result = u'!vault |\n  $ANSIBLE_VAULT;1.1;AES256'
    result = dumper.represent_scalar(u'!vault', test_data, style='|')
    assert result == expected_result

# Generated at 2022-06-20 23:59:04.556638
# Unit test for function represent_binary
def test_represent_binary():
    result = represent_binary(None, "test")
    assert result == "!!binary |-\n  dGVzdA==\n"

# Generated at 2022-06-20 23:59:08.969197
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper) == "!error &id001 'The field \'None\' has an invalid value, which includes an undefined variable. The error was: \'AnsibleUndefined object has no element \'None\''\n"


# TODO: deprecate this

# Generated at 2022-06-20 23:59:11.139706
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper(None, None, None)
    undefined_obj = AnsibleUndefined()
    assert dumper.represent_undefined(undefined_obj) == True

# Generated at 2022-06-20 23:59:14.927065
# Unit test for function represent_unicode
def test_represent_unicode():
    strings = [text_type("Basic unicode"), text_type("Non-ASCII: \u3042")]
    for s in strings:
        assert represent_unicode(AnsibleDumper, s) == yaml.representer.SafeRepresenter.represent_unicode(AnsibleDumper, s)