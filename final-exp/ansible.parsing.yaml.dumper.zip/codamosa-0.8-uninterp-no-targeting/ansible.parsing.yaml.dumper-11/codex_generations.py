

# Generated at 2022-06-20 23:50:46.578080
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    for data in (dict(), list()):
        assert dumper.represent_undefined(data) is True

    data = AnsibleUndefined('spam')
    assert dumper.represent_undefined(data) is True

    class BadUndefined:
        pass
    data = BadUndefined()
    assert dumper.represent_undefined(data) is True

# Generated at 2022-06-20 23:50:56.772183
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hvars = HostVars()

    hvars.add_host('localhost')
    hvars.get('localhost').set_variable('x', 1)
    hvars.get('localhost').set_variable('y', 2)

    hvars.add_host('127.0.0.1')
    hvars.get('127.0.0.1').set_variable('x', 3)
    hvars.get('127.0.0.1').set_variable('y', 4)

    hvars.add_host('0.0.0.0')
    hvars.get('0.0.0.0').set_variable('x', 5)
    hvars.get('0.0.0.0').set_variable('y', 6)


# Generated at 2022-06-20 23:51:07.282186
# Unit test for function represent_undefined
def test_represent_undefined():
    AnsibleDumper = yaml.SafeDumper

    class AnsibleRepresentUndefinedUndefined:
        def __bool__(self):
            return False

        def __nonzero__(self):
            return False

    def represent_undefined_undefined(self, data):
        return bool(data)
    AnsibleDumper.add_representer(AnsibleRepresentUndefinedUndefined, represent_undefined_undefined)

    yaml.dump([AnsibleRepresentUndefinedUndefined()], Dumper=AnsibleDumper)
    yaml.dump([AnsibleRepresentUndefinedUndefined()], Dumper=AnsibleDumper)
    yaml.dump([AnsibleRepresentUndefinedUndefined()], Dumper=AnsibleDumper)

# Generated at 2022-06-20 23:51:10.924609
# Unit test for function represent_unicode
def test_represent_unicode():
    # Create a dummy dumper to pass to represent_unicode
    class AnsibleDumperStub(yaml.Dumper):
        pass

    d = AnsibleDumperStub()
    assert 'foo' == represent_unicode(d, 'foo')
    assert 'foo' == represent_unicode(d, u'foo')

# Generated at 2022-06-20 23:51:12.824635
# Unit test for function represent_binary
def test_represent_binary():
    assert AnsibleDumper().represent_binary('foo') == '!!binary |\n  Zm9v\n'

# Generated at 2022-06-20 23:51:19.772490
# Unit test for function represent_binary
def test_represent_binary():
    # Use long for Python 2 and 3 compat
    test_str = 'some text'
    test_bytes = b'\x00\x01\x02\x03'
    data = [test_str, test_bytes]

    result = yaml.dump(data, Dumper=AnsibleDumper)
    assert result == u'- !!binary |\n  c29tZSB0ZXh0\n- !!binary |\n  AAECAw==\n'



# Generated at 2022-06-20 23:51:23.444285
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper.add_representer == yaml.add_representer
    assert AnsibleDumper.represent_str == yaml.representer.SafeRepresenter.represent_str

# Generated at 2022-06-20 23:51:35.469015
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    '''
    Check that the vault encrypted unicode is properly represented.
    '''

    # Normally this comes from a file, but we'll use a direct string.
    vault_pass_file_content = 'mysecretpassword'

    # Normal use is to load the vault password from file, then
    # construct a vault object from that.
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(vault_pass_file_content)

    # Now we create the text to encrypt and encrypt it
    text_to_encrypt = 'mysekret'

    # Encrypt the text
    ciphertext = vault.encrypt(text_to_encrypt)

    # The resulting ciphertext is stored in an AnsibleVaultEncryptedUnicode object
    from ansible.parsing.yaml.objects import Ansible

# Generated at 2022-06-20 23:51:37.851141
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.safe_dump({'undefined': AnsibleUndefined('foo')}, default_flow_style=False) == """undefined: null
"""

# Generated at 2022-06-20 23:51:48.533232
# Unit test for function represent_binary
def test_represent_binary():
    from ansible.module_utils.common.yaml import _dump_data, _load_data, AnsibleDumper
    from ansible.module_utils.six import BytesIO

    dumper = AnsibleDumper(allow_unicode=True)
    dumper.add_representer(
        AnsibleUnsafeBytes,
        represent_binary,
    )

    # First, writing binary data to file
    bdata = {u'byte_string_key': b'binary_value'}
    xfd = BytesIO()
    dumper.dump(bdata, xfd)
    xfd.seek(0)
    xdata = xfd.read()

    # Initialize a data dictionary with a proper safe yaml structure
    data = {u'byte_string_key': u'binary_value'}

# Generated at 2022-06-20 23:51:55.470529
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(yaml.representer.SafeRepresenter(), AnsibleUnicode('0', style='|')) == \
            (yaml.representer.SafeRepresenter.represent_str(yaml.representer.SafeRepresenter(), text_type('0')))


# Generated at 2022-06-20 23:52:01.931244
# Unit test for function represent_unicode
def test_represent_unicode():
    # Create an AnsibleUnicode object to represent
    a_unicode_obj = AnsibleUnicode('a')

    # Call represent_unicode
    represent_unicode(yaml.representer.SafeRepresenter, a_unicode_obj)
    # Don't know how to check if object was represented correctly
    # Will have to do this manually

if __name__ == "__main__":
    test_represent_unicode()

# Generated at 2022-06-20 23:52:09.858945
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vault_password = VaultLib.create_password(10)

    ciphertext = AnsibleVaultEncryptedUnicode.dump(
        vault_password,
        VaultLib.encrypt(b'plain_text', vault_password),
    )

    assert ciphertext == AnsibleDumper.represent_vault_encrypted_unicode(
        AnsibleDumper,
        AnsibleVaultEncryptedUnicode(ciphertext),
    )


# Generated at 2022-06-20 23:52:12.252646
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    # First test case with default parameter
    dumper = AnsibleDumper()
    # Result must be an instance of AnsibleDumper
    assert isinstance(dumper, AnsibleDumper)



# Generated at 2022-06-20 23:52:20.410635
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper(indent=2)

    import datetime
    dumper.add_representer(
        datetime.datetime,
        lambda dumper, value: dumper.represent_scalar('tag:yaml.org,2002:timestamp', value.isoformat())
    )

    print(yaml.dump([datetime.datetime.now()], Dumper=dumper))

if __name__ == '__main__':
    test_AnsibleDumper()

# Generated at 2022-06-20 23:52:23.450533
# Unit test for function represent_unicode
def test_represent_unicode():
    data = yaml.load(u'{foo: bar}')
    assert data == {'foo': 'bar'}
    assert type(data['foo']) == text_type



# Generated at 2022-06-20 23:52:28.935117
# Unit test for function represent_binary
def test_represent_binary():
    """Test for AnsibleDumper"""
    # initialize objects
    ansible_dumper = AnsibleDumper()
    ansible_binary = AnsibleUnsafeBytes(b'binary_data')

    data = ansible_dumper.represent_binary(ansible_binary)
    assert data == '!!binary "YmluYXJ5X2RhdGE="\n'

# Generated at 2022-06-20 23:52:34.080852
# Unit test for function represent_binary
def test_represent_binary():
    test_data = {'a': six.b('\xF1\xF2\xF3\xF4')}
    output = yaml.safe_dump(test_data, default_style='|', Dumper=AnsibleDumper, allow_unicode=True)
    assert output == 'a: !!binary |\n  8wMlwoPCt1A=\n'

# Generated at 2022-06-20 23:52:35.776172
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    assert dumper.represent_undefined(dumper, AnsibleUndefined) is True

# Generated at 2022-06-20 23:52:42.705312
# Unit test for function represent_undefined
def test_represent_undefined():
    '''
    Test the yaml dumper by passing AnsibleUndefined (which is not
    in the BaseYAMLObject tree).
    '''
    # BaseYAMLObject is not a superclass of AnsibleUndefined
    # so it should not match the representer for BaseYAMLObject
    data = AnsibleUndefined()
    dump = yaml.dump(data, Dumper=AnsibleDumper)
    assert dump == 'False\n'



# Generated at 2022-06-20 23:52:48.047213
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper.represent_undefined(AnsibleDumper, AnsibleUndefined()) == False

# Generated at 2022-06-20 23:52:59.351109
# Unit test for function represent_unicode
def test_represent_unicode():
    # Ensure we are consistent with the base dumper
    sut = yaml.representer.SafeRepresenter.represent_str
    assert sut(AnsibleDumper, 'foo') == sut(yaml.representer.SafeRepresenter, 'foo')

    # Test that the base dumper doesn't accept the unicode type
    try:
        sut(AnsibleDumper, unicode('string'))
        assert False
    except TypeError:
        pass

    # Test that the AnsibleDumper does accept the unicode type
    assert sut(AnsibleDumper, unicode('string')) == sut(yaml.representer.SafeRepresenter, 'string')

    # Test that both dumpers accept str

# Generated at 2022-06-20 23:53:05.498514
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    value = AnsibleUndefined('test_represent_undefined')
    ret = dumper.represent_undefined(dumper, value)
    assert not ret, "represent_undefined should return False"

    # Ensure that we do not crash if the value is not an AnsibleUndefined
    dumper.represent_undefined(dumper, 'not_undefined')



# Generated at 2022-06-20 23:53:12.313005
# Unit test for function represent_hostvars

# Generated at 2022-06-20 23:53:16.113356
# Unit test for function represent_binary
def test_represent_binary():

    obj = AnsibleUnsafeBytes(b'foo')
    assert AnsibleDumper.represent_binary(None, obj) == yaml.representer.SafeRepresenter.represent_binary(None, b'foo')

# Generated at 2022-06-20 23:53:18.687636
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(binary_type('\xe2\x98\x83'), Dumper=AnsibleDumper) == '!!binary |\n  4pi='

# Generated at 2022-06-20 23:53:21.620180
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('test'), Dumper=AnsibleDumper, allow_unicode=True) == u"{test}\n...\n"

# Generated at 2022-06-20 23:53:28.399244
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper(None, None, None)

    data = 'test'
    assert dumper.represent_unicode(data) == {'tag': 'tag:yaml.org,2002:str', 'value': 'test'}

    data = u'test'
    assert dumper.represent_unicode(data) == {'tag': 'tag:yaml.org,2002:str', 'value': 'test'}

    data = AnsibleUnicode(u'test')
    assert dumper.represent_unicode(data) == {'tag': 'tag:yaml.org,2002:str', 'value': 'test'}

    data = AnsibleUnsafeText(u'test')

# Generated at 2022-06-20 23:53:37.029669
# Unit test for function represent_unicode
def test_represent_unicode():

    # These will be checked
    stringA = AnsibleUnicode(u'{ "foo": "bar" }')
    stringB = b'{ "foo": "bar" }'
    stringC = u'{ "foo": "bar" }'
    stringD = u'{ "foo": "bar" }'
    stringE = AnsibleUnsafeText(u'{ "foo": "bar" }')
    stringF = AnsibleUnsafeBytes(b'{ "foo": "bar" }')

    # Not checked
    stringG = u'{ "foo": "bar" }'
    stringH = b'{ "foo": "bar" }'

    # Result
    result1 = yaml.representer.SafeRepresenter.represent_str(stringA)
    result2 = yaml.representer.SafeRepresenter.represent

# Generated at 2022-06-20 23:53:39.976046
# Unit test for function represent_undefined
def test_represent_undefined():
    def execute_test(data):
        return yaml.dump(data, Dumper=AnsibleDumper)

    assert execute_test(AnsibleUndefined()) == ""


# Force the fallback to work

# Generated at 2022-06-20 23:53:50.810826
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo\nbar\x00\xffbaz') == "!!binary |\n  Zm9vCmJhcj/9cmJheg==\n"

# Generated at 2022-06-20 23:53:58.020510
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-20 23:54:04.962999
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = HostVars()
    dump_result = yaml.dump(hostvars, Dumper=AnsibleDumper)
    assert {} == yaml.load(dump_result)

    hostvars['host1'] = HostVarsVars(dict(key1='value1'))
    dump_result = yaml.dump(hostvars, Dumper=AnsibleDumper)
    assert {'host1': {'key1': 'value1'}} == yaml.load(dump_result)

# Generated at 2022-06-20 23:54:11.895683
# Unit test for function represent_binary
def test_represent_binary():
    # NOTE: The test is a bit brittle because of the way that
    #       represent_binary() works. If a change is ever made in the
    #       line:
    #       return yaml.representer.SafeRepresenter.represent_binary(self, binary_type(data))
    #       to, for example:
    #       return yaml.representer.SafeRepresenter.represent_binary(self, binary_type(data, encoding='utf-8'))
    #       the test will fail. With that in mind, if a change is ever made to represent_binary()
    #       it's important to remember to update this test as well.
    dumper = AnsibleDumper
    original_binary_representer = yaml.representer.SafeRepresenter.represent_binary

# Generated at 2022-06-20 23:54:18.400904
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    string = b"test\r\r\n\r\n"
    expected_results = u'!binary ' + u'\\r\\r\\n\\r\\n'
    assert expected_results == dumper.represent_binary(string)



# Generated at 2022-06-20 23:54:23.437511
# Unit test for function represent_binary
def test_represent_binary():
    text = b'123'
    expected = '!!binary |\n  MTIz'

    actual = yaml.dump(text, Dumper=AnsibleDumper)

    assert actual == expected

# Generated at 2022-06-20 23:54:33.999790
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Not going to test for Vault here
    # But test it was called with the right parameters
    mock_dumper = AnsibleDumper(width=10)
    mock_dumper.represent_scalar = lambda *args, **kwargs: (args, kwargs)

    # Test default style
    args, kwargs = represent_vault_encrypted_unicode(mock_dumper, AnsibleVaultEncryptedUnicode('string'))
    assert args == (u'!vault', mock_dumper.represent_scalar.return_value)
    assert kwargs == dict(style=None)

    # Test using style=">|"

# Generated at 2022-06-20 23:54:45.799463
# Unit test for function represent_unicode
def test_represent_unicode():

    yaml.add_representer(
        text_type,
        represent_unicode,
        Dumper=yaml.SafeDumper
    )

    # Assume unicode data
    data = u'test unicode'
    assert yaml.safe_dump(data) == u'test unicode\n'

    # Assume unicode data as text
    data = text_type(u'test unicode')
    assert yaml.safe_dump(data) == u'test unicode\n'

    # Assume unicode data as bytes
    data = binary_type(u'test unicode')
    assert yaml.safe_dump(data) == u'test unicode\n'

    # Assume binary data as text
    data = text_type(b'test binary')
    assert yaml.safe_dump(data)

# Generated at 2022-06-20 23:54:55.719630
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():

    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib

    vault = VaultLib([])
    item = AnsibleVaultEncryptedUnicode('password', vault)
    # This is the default string representation from VaultLib
    # The string does not start with '$ANSIBLE_VAULT'

# Generated at 2022-06-20 23:54:59.834713
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars_data_1 = {"name1": "value1"}
    hostvars_test_1 = HostVars(hostvars_data_1)
    repr_test_1 = yaml.dump(hostvars_test_1, default_flow_style=True, Dumper=AnsibleDumper)
    assert repr_test_1 == '{name1: value1}\n...\n'



# Generated at 2022-06-20 23:55:17.590499
# Unit test for function represent_unicode
def test_represent_unicode():
    ret = yaml.dump(AnsibleUnicode("michael\tdehaan"),
                    default_flow_style=False,
                    Dumper=AnsibleDumper)
    assert ret == '"michael\\tdehaan"\n'



# Generated at 2022-06-20 23:55:21.626654
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    data = HostVars(name="localhost", variables=dict(var1="var1"))
    assert dumper.represent_hostvars(data) == dumper.represent_dict(dict(name="localhost", variables=dict(var1="var1")))



# Generated at 2022-06-20 23:55:26.335326
# Unit test for function represent_binary
def test_represent_binary():
    from ansible.module_utils.six import binary_type

    dumper = AnsibleDumper(indent=0)

    assert '''foo: !!binary |
  YmFy
''' == binary_type(dumper.represent_binary(b'bar'))

# Generated at 2022-06-20 23:55:30.585559
# Unit test for function represent_unicode
def test_represent_unicode():
    ''' represent_unicode should return a string when passed a unicode object '''
    stub_data = u'stub_data'
    stub_result = represent_unicode(AnsibleDumper, stub_data)
    assert isinstance(stub_result, text_type)

# Generated at 2022-06-20 23:55:31.911730
# Unit test for function represent_unicode
def test_represent_unicode():
    # TODO: write unit tests for this function
    return


# Generated at 2022-06-20 23:55:35.810491
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(u'\x00\x01\x02\x03\x04\x05\x06\x07') == "!!binary |\n  AAEBCQoLDw==\n"

# Generated at 2022-06-20 23:55:39.300333
# Unit test for function represent_unicode
def test_represent_unicode():
    test_value = "test-value"
    assert yaml.dump(AnsibleUnicode(test_value), Dumper=AnsibleDumper) == "test-value\n...\n"

# Generated at 2022-06-20 23:55:43.065979
# Unit test for function represent_unicode
def test_represent_unicode():
    d = AnsibleDumper()
    data = AnsibleUnicode('\x00\x01')
    expect = "!!python/unicode ''\\x00\\x01''\n"
    assert d.represent_unicode(data) == expect
    data = AnsibleUnsafeText('\x00\x01')
    expect = "!!python/unicode ''\\x00\\x01''\n"
    assert d.represent_unicode(data) == expect



# Generated at 2022-06-20 23:55:54.775914
# Unit test for function represent_unicode
def test_represent_unicode():
    yaml_data = u'Hello\u2665World!'
    yaml_data_encoded = yaml_data.encode('utf8')
    assert yaml_data == yaml.load(yaml_data_encoded, Loader=yaml.BaseLoader)
    assert yaml_data_encoded == yaml.dump(yaml_data, Dumper=AnsibleDumper, default_flow_style=False).encode('utf8')
    assert yaml_data_encoded == yaml.dump(AnsibleUnicode(yaml_data), Dumper=AnsibleDumper, default_flow_style=False).encode('utf8')

# Generated at 2022-06-20 23:56:00.235095
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    # Note: This is a test for the constructor only.
    # We do not test yaml.constructor.SafeConstructor,
    # instead we should be testing AnsibleConstructor,
    # but there is no unit test for AnsibleConstructor
    assert yaml.constructor.BaseConstructor.construct_yaml_map == yaml.constructor.SafeConstructor.construct_yaml_map



# Generated at 2022-06-20 23:56:34.917927
# Unit test for function represent_undefined
def test_represent_undefined():
    obj = AnsibleUndefined()
    repr = AnsibleDumper().represent_data(obj)
    assert repr == '~'


# for testing, see units
if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-20 23:56:41.035798
# Unit test for function represent_hostvars
def test_represent_hostvars():

    class HostVars1(HostVars):

        def __init__(self, *args, **kwargs):
            super(HostVars1, self).__init__(*args, **kwargs)
            self._data["first"] = "first"
            self._data["second"] = "second"

    hostvars1 = HostVars1()
    assert yaml.dump(hostvars1, Dumper=AnsibleDumper) == "{first: first, second: second}\n"



# Generated at 2022-06-20 23:56:46.563262
# Unit test for function represent_unicode
def test_represent_unicode():

    ansible_unicode = AnsibleUnicode('foo')
    assert yaml.dump(ansible_unicode) == 'foo\n...\n'

    # Note that this preserves the hash key
    ansible_unsafe_text = AnsibleUnsafeText('foo')
    assert yaml.dump(ansible_unsafe_text) == '|\n  foo\n...\n'



# Generated at 2022-06-20 23:56:50.557694
# Unit test for function represent_unicode
def test_represent_unicode():
    inner = ['"My string"']
    nested = [('value', AnsibleUnicode(inner[0]))]
    data = [('key', AnsibleMapping(nested))]
    mapping = AnsibleMapping(data)
    assert yaml.dump(mapping, Dumper=AnsibleDumper) == "key:\n  value: '\"My string\"'\n"

# Generated at 2022-06-20 23:56:52.611396
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.vars.unsafe_proxy import wrap_var

    data = wrap_var(u'foobar')
    represent_vault_encrypted_unicode(AnsibleDumper, data)



# Generated at 2022-06-20 23:57:02.436107
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert yaml.load(yaml.dump(HostVars(dict()), Dumper=AnsibleDumper)) == dict()
    assert yaml.load(yaml.dump(HostVars(dict(a=1)), Dumper=AnsibleDumper)) == dict(a=1)

    # And a HostVarsVars
    assert yaml.load(yaml.dump(HostVarsVars(dict(a=1)), Dumper=AnsibleDumper)) == dict(a=1)

    # And a VarsWithSources
    assert yaml.load(yaml.dump(VarsWithSources(dict(a=1)), Dumper=AnsibleDumper)) == dict(a=1)



# Generated at 2022-06-20 23:57:06.436195
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert not dumper.represent_data(AnsibleUndefined())
    assert not dumper.represent_data(AnsibleUndefined(strict=False))
    assert not dumper.represent_data(AnsibleUndefined(error=ValueError('foo')))

# Generated at 2022-06-20 23:57:14.184863
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    test_value = AnsibleVaultEncryptedUnicode(u'TestString', u'TestKey')
    yaml_out = yaml.dump({'test': test_value}, Dumper=AnsibleDumper)
    yaml_out.strip()

# Generated at 2022-06-20 23:57:18.553922
# Unit test for function represent_unicode
def test_represent_unicode():
    yaml.add_representer(AnsibleUnicode, represent_unicode, Dumper=AnsibleDumper)
    data = {'key': 'value'}
    yaml.dump(data, Dumper=AnsibleDumper)

# Generated at 2022-06-20 23:57:21.184119
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():

    output = yaml.dump(AnsibleVaultEncryptedUnicode("blah"), Dumper=AnsibleDumper)
    assert output == '!vault |\n  blah'



# Generated at 2022-06-20 23:59:09.127070
# Unit test for function represent_undefined
def test_represent_undefined():
    m = AnsibleDumper()
    v = AnsibleUndefined("Undefined")
    out = yaml.dump(v, default_flow_style=None, Dumper=AnsibleDumper)
    assert out == '{}'

# Generated at 2022-06-20 23:59:15.311223
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    ciphertext = {'$ANSIBLE_VAULT;1.1;AES256\n314d61316032313761330a66393931643935303466306565383861636338306531326137643966660a346632396433653964663935646637306435313238636437333666626462623863656131613731390a66353734663136323663346231353865313135363034656535366361613665333035396533343962386366616461653931333663616632636434336393833306364396138663663313866363163346635343264663238653132656465626161373566663464\n'}
    result = represent_vault

# Generated at 2022-06-20 23:59:23.423352
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    fake_input = 'abcde'

    output = dumper.represent_unicode(dumper, AnsibleUnicode(fake_input))
    assert output == "\"abcde\""

    output = dumper.represent_unicode(dumper, AnsibleUnsafeText(fake_input))
    assert output == "\"abcde\""

    dumper.allow_unicode = False
    output = dumper.represent_unicode(dumper, AnsibleUnsafeText(fake_input))
    assert output == "\"abcde\""
    dumper.allow_unicode = True



# Generated at 2022-06-20 23:59:26.979578
# Unit test for function represent_unicode
def test_represent_unicode():
    # If a unicode string is provided as input to represent_unicode,
    # a unicode string should be returned.
    loader = AnsibleDumper
    test_input = u'test'
    assert isinstance(represent_unicode(loader, test_input), text_type)



# Generated at 2022-06-20 23:59:28.811092
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # We cannot use assertEqual here as the objects converted
    # by represent_hostvars are dicts.
    assert represent_hostvars(None, HostVars(dict(a=1))) == represent_hostvars(None, dict(a=1))



# Generated at 2022-06-20 23:59:32.351193
# Unit test for function represent_unicode
def test_represent_unicode():
    # Test the special case when data = u'\x00'
    dumper = AnsibleDumper
    data = u'\x00'
    expected = u'!!python/unicode "\x00"'
    result = dumper.represent_unicode(dumper, data)
    assert result == expected



# Generated at 2022-06-20 23:59:38.881847
# Unit test for function represent_hostvars
def test_represent_hostvars():

    class DummyVars(object):

        def keys(self):
            return ['key1', 'key2']

        def __contains__(self, key):
            return key in self.keys()

        def __getitem__(self, key):
            return key + '-value'

    class DummyHostVars(object):

        def __contains__(self, key):
            return key in ['key1', 'key2']

        def __getitem__(self, key):
            return key + '-value'

        def get_vars(self, host):
            return DummyVars()

    output = represent_hostvars(None, DummyHostVars())
    print(output)
    assert output == '{key1: key1-value, key2: key2-value}'



# Generated at 2022-06-20 23:59:41.176395
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_data(AnsibleUndefined()) is not None

# Generated at 2022-06-20 23:59:49.710136
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper(default_flow_style=None, sort_keys=True)

    # Test with a plugin that doesn't need undef_to_none
    data = {
        'test_value': None,
        'test_dict': {'test_value': None},
        'test_list': ['test_value', None]
    }

    dumper.undefined = AnsibleUndefined
    assert yaml.dump(data, Dumper=dumper) == """\
test_dict:
  test_value: null
test_list:
- test_value
- null
test_value: null
"""

    # Test with a plugin that does need undef_to_none

# Generated at 2022-06-20 23:59:50.506449
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper is not None