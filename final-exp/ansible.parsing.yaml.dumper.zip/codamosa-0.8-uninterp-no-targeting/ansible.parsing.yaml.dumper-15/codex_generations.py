

# Generated at 2022-06-20 23:50:52.955882
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-20 23:50:59.686797
# Unit test for function represent_unicode
def test_represent_unicode():
    ''' make sure we can represent unicode strings correctly
        to be later loaded by `yaml.load()` or `yaml.safe_load()` '''

    output = yaml.dump(u'\u263a', Dumper=AnsibleDumper)
    # Let's see if it is correctly dumped
    assert output == "unicode_symbol: '☺'\n"

    # Safe loader will load unicode string
    input_str = yaml.safe_load(output)
    # Let's see if the unicode character was correctly loaded
    assert input_str == u'☺'

    # Loader won't load unicode string
    input_str = yaml.load(output)
    # As we can see, the unicode character was not loaded

# Generated at 2022-06-20 23:51:00.736755
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper()
    assert 1

# Generated at 2022-06-20 23:51:10.956791
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()
    # Fake encrypted data
    data = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.2;AES256;myhost\n33464323133343065366162333363343434316362353935336338616331643335336236353334650a63366463646165643638393835343064653964363830383366656462303665353038643733306435\n')
    # Make sure the dumper doesn't error out
    output = dumper.represent_vault_encrypted_unicode(data)

# Generated at 2022-06-20 23:51:13.135464
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert represent_hostvars(None, HostVars({'x': 'y'})) == {'x': 'y'}



# Generated at 2022-06-20 23:51:22.830373
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper()

    assert dumper.allow_unicode == SafeDumper.allow_unicode
    # noinspection PyProtectedMember
    assert dumper._dict_representers == SafeDumper._dict_representers
    # noinspection PyProtectedMember
    assert dumper._seq_representers == SafeDumper._seq_representers
    # noinspection PyProtectedMember
    assert dumper._tag_representers == SafeDumper._tag_representers
    # noinspection PyProtectedMember
    assert dumper._tag_registry == SafeDumper._tag_registry
    # noinspection PyProtectedMember
    assert dumper._tag_class_map == SafeDumper._tag_class_map
    assert dumper.use_encoding == SafeDumper.use_encoding
    assert dumper

# Generated at 2022-06-20 23:51:34.959448
# Unit test for function represent_unicode
def test_represent_unicode():
    yaml.add_representer(
        text_type,
        yaml.representer.SafeRepresenter.represent_str,
        Dumper=yaml.representer.SafeRepresenter
    )
    yaml.add_representer(
        text_type,
        represent_unicode,
        Dumper=AnsibleDumper
    )
    data = {
        'unicode_string': text_type(u"\u2713"),
        'bytestring': b"\xe2\x9c\x93",
    }
    result = yaml.dump(data, Dumper=AnsibleDumper)
    assert result == '{unicode_string: "✓", bytestring: !!binary |-\n  2q3yuI=\n}'



# Generated at 2022-06-20 23:51:36.486562
# Unit test for function represent_binary
def test_represent_binary():
    from ansible.module_utils.six import StringIO
    import yaml

    yaml_text = '"43"\n'
    stream = StringIO(yaml_text)
    assert yaml.safe_load(stream) == '43'



# Generated at 2022-06-20 23:51:41.124197
# Unit test for function represent_binary
def test_represent_binary():
    output = yaml.dump(b'Some\x00Binary\xFFString', Dumper=AnsibleDumper)
    assert output == "!!binary |\n  U29tZSRCBaW5hcnklRlN0cmluZw==\n"

# Generated at 2022-06-20 23:51:50.037065
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-20 23:52:03.692655
# Unit test for function represent_unicode
def test_represent_unicode():
    yamldata = yaml.dump(text_type(u'helloworld'), Dumper=AnsibleDumper)
    assert yamldata == "helloworld\n...\n"

    yamldata = yaml.dump(binary_type('helloworld'), Dumper=AnsibleDumper)
    assert yamldata == "helloworld\n...\n"

    yamldata = yaml.dump(AnsibleUnsafeText('helloworld'), Dumper=AnsibleDumper)
    assert yamldata == "helloworld\n...\n"

    yamldata = yaml.dump(AnsibleUnsafeBytes('helloworld'), Dumper=AnsibleDumper)
    assert yamldata == "helloworld\n...\n"

# Generated at 2022-06-20 23:52:08.480724
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode(u'123'), Dumper=AnsibleDumper) == u'123\n...\n'
    assert yaml.dump(AnsibleUnicode(u'"123"'), Dumper=AnsibleDumper) == u'"123"\n'


# Generated at 2022-06-20 23:52:12.992570
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from io import BytesIO
    output = BytesIO()

    dumper = AnsibleDumper(None, None, None, None, None, None, None, output)
    represent_hostvars(dumper, HostVars(VarsWithSources({'a': 'b'},
                                                        hostvars_var_name='test')))
    result = output.getvalue()
    assert b'test: {a: b}\n' == result



# Generated at 2022-06-20 23:52:17.654715
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = HostVars({"a": 1, "b": 2})
    dumped = yaml.dump(data, Dumper=AnsibleDumper)
    assert dumped == "{a: 1, b: 2}\n"

# Generated at 2022-06-20 23:52:26.160862
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-20 23:52:35.577274
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

# Generated at 2022-06-20 23:52:47.205499
# Unit test for function represent_hostvars
def test_represent_hostvars():
    '''Test represent_hostvars func'''

    data = dict(
        ansible_all_ipv4_addresses=['1.2.3.4']
    )

    assert represent_hostvars(None, HostVars(data)) == represent_hostvars(None, HostVarsVars(data)) == \
           represent_hostvars(None, VarsWithSources(data)) == yaml.representer.SafeRepresenter.represent_dict(None, data)

    # Test representation of data that could not be serialized in JSON
    data = dict(
        ansible_all_ipv4_addresses=['1.2.3.4'],
        my_custom_var=AnsibleUnicode('foo'),
    )


# Generated at 2022-06-20 23:52:51.687750
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper
    hostvars = HostVars({"a": 1})
    ret = represent_hostvars(dumper, hostvars)
    assert ret == yaml.representer.SafeRepresenter.represent_dict(
        dumper, {"a": 1})

# Generated at 2022-06-20 23:52:55.728170
# Unit test for function represent_unicode
def test_represent_unicode():

    assert yaml.dump(u'\u2600', Dumper=AnsibleDumper) == '\n- ☀\n'
    assert yaml.dump(u'\U0001f30e', Dumper=AnsibleDumper) == '\n- 🌎\n'

# Generated at 2022-06-20 23:52:59.105721
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = AnsibleVaultEncryptedUnicode(u'hello', u'vaultstring')
    assert yaml.dump(data) == "!vault |\n  vaultstring\n"

# Generated at 2022-06-20 23:53:11.002044
# Unit test for function represent_binary
def test_represent_binary():
    # Test 1
    ansible_dumper = AnsibleDumper()
    output = ansible_dumper.represent_binary('\x80\x90\xa0')
    assert output == u"!!binary |\n  gICCg4KDgA==\n"

    # Test 2
    ansible_dumper = AnsibleDumper()
    output = ansible_dumper.represent_binary('string')
    assert output == u"!!binary |\n  c3RyaW5n\n"

    # Test 3
    ansible_dumper = AnsibleDumper()
    output = ansible_dumper.represent_binary('str\x00ing')
    assert output == u"!!binary |\n  c3RyAGluZw==\n"

    # Test 4

# Generated at 2022-06-20 23:53:22.836459
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleVaultEncryptedUnicode

    vault_password = 'sekret'

    vault = VaultLib([])
    ciphertext = vault.encrypt(vault_password, u'hello world')
    encrypted = AnsibleVaultEncryptedUnicode(ciphertext)

    yaml_vault_text = yaml.dump(encrypted, Dumper=AnsibleDumper)

# Generated at 2022-06-20 23:53:32.054901
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.yaml import objects
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

    plaintext = "The secret is a peach"
    ciphertext = vault.encrypt(plaintext)

    vault_object = objects.AnsibleVaultEncryptedUnicode(ciphertext)
    # !!!!
    # This is a quick hack to work around VaultLib.
    # It doesn't support decrypting ciphertext created by
    # previous versions that don't set the version
    # See https://github.com/ansible/ansible-modules-core/issues/5570
    vault_object._ciphertext = ciphertext

    yaml_representation = yaml.dump(vault_object, Dumper=AnsibleDumper)


# Generated at 2022-06-20 23:53:34.833247
# Unit test for function represent_undefined
def test_represent_undefined():
    # Make sure we fail if the value is Undefined
    data = AnsibleUndefined('value')
    assert bool(data) is False

    # Make sure we work if it is a string
    data = 'value'
    assert bool(data) is True

# Generated at 2022-06-20 23:53:40.849281
# Unit test for function represent_binary
def test_represent_binary():
    representer = yaml.representer.SafeRepresenter(
        default_style='|',
        default_flow_style=True)
    test_string = '\xa0omg\x81'
    expected_output = "|-\n  " + "\\xa0omg\\x81"
    assert representer.represent_binary(test_string) == expected_output

# Generated at 2022-06-20 23:53:43.771708
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    assert dumper.represent_unicode(dumper, "test") == "test"



# Generated at 2022-06-20 23:53:54.102074
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(b'password')
    mypassword = u'This is a testing password'

    represent = represent_vault_encrypted_unicode(AnsibleDumper, vault.encrypt(mypassword))


# Generated at 2022-06-20 23:53:56.567445
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnsafeText(u'foo'), Dumper=AnsibleDumper) == u'foo\n...\n'

# Generated at 2022-06-20 23:54:07.171034
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    u = AnsibleVaultEncryptedUnicode('hello')

# Generated at 2022-06-20 23:54:09.935524
# Unit test for function represent_undefined
def test_represent_undefined():
    repr = AnsibleDumper()
    data = AnsibleUndefined()
    output = repr.represent_undefined(data)
    assert output == bool(data)



# Generated at 2022-06-20 23:54:18.015212
# Unit test for function represent_binary
def test_represent_binary():
    yaml_dumper = yaml.representer.SafeRepresenter.represent_binary
    assert yaml_dumper(None, b'foo') == u'!binary |\n  Zm9v'



# Generated at 2022-06-20 23:54:24.924800
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    result = dumper.represent_binary(dumper, b'!\x01\x02\x03')
    assert  result == "!!binary 'AQID'\n"


# We want to also be able to represent unicode objects
# since the json module would convert them to strings.
# Note: use yaml.representer.SafeRepresenter.represent_str
# instead of just represent_str, because it is only registered
# in the SafeDumper.

# Generated at 2022-06-20 23:54:26.459404
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert issubclass(AnsibleDumper, yaml.SafeDumper)

# Generated at 2022-06-20 23:54:36.015452
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-20 23:54:47.418099
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-20 23:54:50.142125
# Unit test for function represent_binary
def test_represent_binary():
    assert represent_binary(None, '\n') == '|-\n\n'
    assert represent_binary(None, '\\') == '|-\n\n\\'

# Generated at 2022-06-20 23:54:53.420599
# Unit test for function represent_undefined
def test_represent_undefined():
    val = AnsibleUndefined('test_represent_undefined')
    dumper = AnsibleDumper(width=4096)
    res = dumper.represent_data(val)
    assert(res is False)

# Generated at 2022-06-20 23:54:57.753154
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper()

    assert dumper.allow_unicode is True
    assert dumper.default_flow_style is False
    assert dumper.encoding is 'utf-8'
    assert dumper.explicit_start is True
    assert dumper.sort_keys is False
    assert isinstance(dumper.represent_scalar, yaml.representer.SafeRepresenter.represent_str)
    assert dumper.use_unicode is True


dumper = AnsibleDumper()



# Generated at 2022-06-20 23:55:08.494781
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-20 23:55:11.823447
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dump = yaml.dump(AnsibleVaultEncryptedUnicode("secret", b"abcdef"))
    assert dump == "!vault |\n  YWJjZGVm\n"
