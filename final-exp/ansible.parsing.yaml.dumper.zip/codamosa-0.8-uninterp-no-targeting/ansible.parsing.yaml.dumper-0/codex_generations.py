

# Generated at 2022-06-20 23:50:42.336288
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    a = AnsibleDumper()

    assert a is not None

# Generated at 2022-06-20 23:50:46.691829
# Unit test for function represent_unicode
def test_represent_unicode():
    dump_data = dict(ascii_text='abc', unicode_text=u'abc\u1234')
    dumped = yaml.safe_dump(dump_data, default_flow_style=False)
    assert dumped == 'ascii_text: abc\nunicode_text: abc\u1234\n'



# Generated at 2022-06-20 23:50:56.840816
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'data') == '!!binary |\n  ZGF0YQ==\n'

    # This also does not work in 2.7
    # assert dumper.represent_binary(binary_type('data', 'ascii')) == '!!binary |\n  ZGF0YQ==\n'
    # assert dumper.represent_binary(binary_type('data', 'utf-8')) == '!!binary |\n  ZGF0YQ==\n'

    # But these work in 2.7, we might need to accept these values in AnsibleUnsafeBytes.
    # assert dumper.represent_binary(binary_type('data', 'latin-1')) == '!!binary |\n  ZGF0YQ==\n'


# Generated at 2022-06-20 23:51:04.454246
# Unit test for function represent_hostvars
def test_represent_hostvars():
    obj = HostVars()
    obj.vars = dict(foo=1, bar=2)
    obj.task_vars = dict(baz='a', foo='b')
    obj.group_vars = dict(app='app1')
    obj.inventory_hostname = 'testhost'

    expected = """\
{foo: 1, bar: 2}""".split()
    actual = yaml.dump(obj, Dumper=AnsibleDumper, default_flow_style=False).split()

    assert expected == actual



# Generated at 2022-06-20 23:51:05.762912
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, u"\ud83d\ude02") == u": !!binary |\n  8J+Ygw==\n"

# Generated at 2022-06-20 23:51:11.642707
# Unit test for function represent_hostvars
def test_represent_hostvars():

    # We need to do this because we are instantiating
    # this class below.
    class TestSafeDumper(yaml.SafeDumper):
        pass

    TestSafeDumper.add_representer(
        HostVars,
        represent_hostvars,
    )

    result = yaml.dump(HostVars({'a': '1', 'b': '2'}), Dumper=TestSafeDumper, default_flow_style=False)

    assert result == '{a: 1, b: 2}\n'

# Generated at 2022-06-20 23:51:22.003840
# Unit test for function represent_binary

# Generated at 2022-06-20 23:51:32.230749
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper
    assert isinstance(dumper, type(SafeDumper))
    assert isinstance(dumper, type(yaml.SafeDumper))
    assert isinstance(dumper, type(yaml.dumper.Dumper))
    assert dumper.yaml_representers == {
        AnsibleUnicode: represent_unicode,
        AnsibleSequence: yaml.representer.SafeRepresenter.represent_list,
        AnsibleMapping: yaml.representer.SafeRepresenter.represent_dict,
        AnsibleVaultEncryptedUnicode: represent_vault_encrypted_unicode,
        AnsibleUndefined: represent_undefined,
    }



# Generated at 2022-06-20 23:51:39.208321
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = {'foo': HostVars({'one': 1}, vault_password='secret')}

    output = yaml.dump(data, Dumper=AnsibleDumper, default_flow_style=False)
    assert output == b'foo: {one: 1}\n'
    assert isinstance(yaml.load(output, Loader=AnsibleLoader), dict)



# Generated at 2022-06-20 23:51:49.483182
# Unit test for function represent_unicode
def test_represent_unicode():
    a = yaml.dump(dict(foo=u'bar'), default_flow_style=True, Dumper=AnsibleDumper)
    b = yaml.dump(dict(foo='bar'), default_flow_style=True, Dumper=AnsibleDumper)
    assert a == b
    a = yaml.dump(dict(foo=u'bar\x00'), default_flow_style=True, Dumper=AnsibleDumper)
    b = yaml.dump(dict(foo='bar\x00'), default_flow_style=True, Dumper=AnsibleDumper)
    assert a == b
    a = yaml.dump(dict(foo=u"bar\n"), default_flow_style=True, Dumper=AnsibleDumper)

# Generated at 2022-06-20 23:51:55.957501
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper
    data = HostVars({"test": "value"})
    result = yaml.dump(data, Dumper=dumper)
    assert(result == '{test: value}\n')



# Generated at 2022-06-20 23:52:02.752139
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = HostVars(fake_host=dict(fake_var=5))
    result = yaml.dump(hostvars, Dumper=AnsibleDumper)
    assert isinstance(result, text_type)
    assert result == '!!python/object/apply:ansible.vars.hostvars.HostVars {fake_host: {fake_var: 5}}\n'
    assert isinstance(yaml.load(result), HostVars)



# Generated at 2022-06-20 23:52:03.940448
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    ansible_dumper = AnsibleDumper()

# Generated at 2022-06-20 23:52:07.940859
# Unit test for function represent_unicode
def test_represent_unicode():
    from ansible.utils.unsafe_proxy import wrap_var

    result = yaml.dump({'unicode': wrap_var(u'hello')}, Dumper=AnsibleDumper)
    assert result == u"{unicode: 'hello'}\n"

# Generated at 2022-06-20 23:52:13.348563
# Unit test for function represent_unicode
def test_represent_unicode():
    '''
    This function tests for correct encoding
    of unicode characters in AnsibleUnicode
    '''
    test_cases = {
        u'\u0026': '&',
    }
    for case in test_cases:
        dump_str = yaml.dump(case, Dumper=AnsibleDumper, default_flow_style=False)
        assert test_cases[case] in dump_str, "Failed to dump unicode: %s\nDump string: %s" % (case, dump_str)



# Generated at 2022-06-20 23:52:24.429789
# Unit test for function represent_binary
def test_represent_binary():
    # We use yaml.dump to test represent_binary
    # yaml.dump uses yaml.emitter.Emitter to generate an emitter instance
    # and then calls emitter.serialize to serialize the data
    # If we can output the data and catch it, that means represent_binary works
    # If we get some error, that means represent_binary does not work

    # Create a yaml.emitter.Emitter object
    # yaml.emitter.Emitter uses yaml.emitter.Serializer to serialize the data
    # and append the serialized data to the stream
    stream = yaml.emitter.Emitter()

    # Create a yaml.representer.SafeRepresenter object
    # The argument 'None' means no explicit typemapper.

# Generated at 2022-06-20 23:52:30.304896
# Unit test for function represent_undefined
def test_represent_undefined():
    # Make sure we get a failure when trying to represent Undefined.
    # The function should fail with UndefinedError and not some other error
    # like TypeError.
    from ansible.template import UndefinedError

    dumper = AnsibleDumper()
    try:
        dumper.represent_undefined("foo")
    except UndefinedError:
        pass
    except TypeError:
        assert False

# Generated at 2022-06-20 23:52:37.739950
# Unit test for function represent_unicode
def test_represent_unicode():
    class TestAnsibleDumper(AnsibleDumper):
        def increase_indent(self, flow=False, indentless=False):
            return
    # no special mapping in base class
    # using a text string instead of unicode object
    assert yaml.representer.SafeRepresenter.represent_str(
        TestAnsibleDumper(), 'test_data') == u'"test_data"\n'

    # using unicode object
    assert yaml.representer.SafeRepresenter.represent_str(
        TestAnsibleDumper(), text_type('test_data')) == u'"test_data"\n'

    # using an AnsibleUnicode object

# Generated at 2022-06-20 23:52:40.334995
# Unit test for function represent_binary
def test_represent_binary():
    print(binary_type(b'\xfc\xe6\x01\xcb'))

# Check if the key of dict is binary

# Generated at 2022-06-20 23:52:44.079240
# Unit test for function represent_undefined
def test_represent_undefined():
    data = {'test': AnsibleUndefined}
    AnsibleDumper.add_representer(
        AnsibleUndefined,
        represent_undefined,
    )
    yaml.dump(data, Dumper=AnsibleDumper)

# Generated at 2022-06-20 23:52:50.563553
# Unit test for function represent_unicode
def test_represent_unicode():
    yaml_str = yaml.dump(
        u'ni\xf1o',
        default_flow_style=False,
        Dumper=AnsibleDumper,
    )

    assert yaml_str == "- niño\n"



# Generated at 2022-06-20 23:52:51.922363
# Unit test for function represent_undefined
def test_represent_undefined():
    assert bool(represent_undefined(None, AnsibleUndefined()))



# Generated at 2022-06-20 23:52:59.451228
# Unit test for function represent_binary
def test_represent_binary():
    '''Test represent_binary()'''
    # Note: must use 'str' in Python 2.
    # In Python 2, 'str' is ASCII.
    s = str(chr(0) * 64)
    # Create a binary string (must use 'bytes' in Python 3).
    b = b'\x00' * 64
    # Dump the data.
    yml = yaml.dump(b)
    # Test.
    assert yml == u'!!binary |\n  {}\n'.format(s)

# Generated at 2022-06-20 23:53:07.952859
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert hasattr(AnsibleDumper, 'add_representer')
    assert hasattr(AnsibleDumper, 'represent_hostvars')
    assert hasattr(AnsibleDumper, 'represent_vault_encrypted_unicode')
    assert hasattr(AnsibleDumper, 'represent_unicode')
    assert hasattr(AnsibleDumper, 'represent_binary')
    assert hasattr(AnsibleDumper, 'represent_undefined')


if __name__ == '__main__':
    test_AnsibleDumper()

# Generated at 2022-06-20 23:53:09.540687
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    my_dumper = AnsibleDumper()
    assert my_dumper

# Generated at 2022-06-20 23:53:11.542133
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    AnsibleDumper(indent=2, width=1000, allow_unicode=True)

# Generated at 2022-06-20 23:53:12.577113
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper is not None

# Generated at 2022-06-20 23:53:21.494636
# Unit test for function represent_unicode
def test_represent_unicode():
    '''
    Test represent_unicode function which handles AnsibleUnicode
    :return:
    '''
    unicode_data = 'PASSWORD'
    unicode_obj = AnsibleUnicode(unicode_data)

    dumper = AnsibleDumper()
    result_obj = dumper.represent_unicode(unicode_obj)
    ansible_unicode_dict = {'tag': u'!ansible/unicode', 'value': u'PASSWORD'}

    assert result_obj == ansible_unicode_dict


# Tests for represent_binary

# Generated at 2022-06-20 23:53:29.460408
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hvars = HostVars(dict(a=1))

    # this is the same test code that was previously used to
    # determine if the change to the HostVars class caused
    # the regression causing the need for this class
    hvars.a = 1
    assert hvars.a == 1
    assert repr(hvars.a) == "1"
    assert '1' in str(hvars)
    assert 'a=1' in str(hvars)

    serialized = yaml.dump(hvars, Dumper=yaml.Dumper)
    assert serialized == "a: 1\n"



# Generated at 2022-06-20 23:53:31.365538
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    try:
        AnsibleDumper()
    except Exception:
        raise AssertionError("AnsibleDumper instantiation failed")

# Generated at 2022-06-20 23:53:40.493867
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dump_value = yaml.dump([AnsibleVaultEncryptedUnicode(u'$ANSIBLE_VAULT;1.1;AES256;ansible\ntest')], Dumper=AnsibleDumper, default_style=None)
    expected_value = text_type("- !vault |\n  $ANSIBLE_VAULT;1.1;AES256;ansible\n  test\n")
    assert dump_value == expected_value

# Generated at 2022-06-20 23:53:48.714313
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.manager import VariableManager

    vm = VariableManager()
    vm.hostvars = {'host': {'fact': 42}}
    data = vm.get_vars(loader=None, host=None, include_hostvars=True, use_cache=False)
    # make a copy of the data as we will alter data
    data_copy = data.copy()
    assert AnsibleDumper().represent_data(data) == AnsibleDumper().represent_data(data_copy)



# Generated at 2022-06-20 23:53:50.668091
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    AnsibleDumper(open('yaml_files/test_1.yaml', 'r'))

# Generated at 2022-06-20 23:53:57.250436
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    text_type('foo')

    # create string for test
    my_bytes = b'foo\x80\x81\x82\x83'

    # create object that contains string
    class MyClass(object):
        def __init__(self, val):
            self.val = val
    my_obj = MyClass(my_bytes)

    # ensure that it dumps correctly
    yaml_string = yaml.dump(my_obj, Dumper=dumper)
    # ensure that it loads correctly
    my_obj2 = yaml.load(yaml_string)
    assert my_obj.val == my_obj2.val

# Generated at 2022-06-20 23:54:07.903411
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Test unicode input
    input = AnsibleVaultEncryptedUnicode(u"This is a unicode string")
    output = yaml.dump(input, Dumper=AnsibleDumper)

# Generated at 2022-06-20 23:54:11.388822
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper(indent=2, default_flow_style=False)
    assert dumper.represent_binary(b'foo\nbar') == "!!binary |\n  Zm9vCmJhcg==\n"



# Generated at 2022-06-20 23:54:16.113403
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    data = b'foo'
    # The function represent_binary should return a string
    data = dumper.represent_binary(data)
    assert type(data) == str

# Generated at 2022-06-20 23:54:17.249625
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    data = HostVars()
    assert dumper.represent_hostvars(data) == dumper.represent_dict(dict())

# Generated at 2022-06-20 23:54:18.725197
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert(AnsibleDumper is not None)



# Generated at 2022-06-20 23:54:22.807201
# Unit test for function represent_binary
def test_represent_binary():
    byte_string = '//+AA=='
    expected_representation = "!!binary '%s'\n" % byte_string

    representer = AnsibleDumper.represent_binary
    result = representer(AnsibleDumper, byte_string)

    assert result == expected_representation



# Generated at 2022-06-20 23:54:30.372335
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert yaml.safe_dump(binary_type("test\r\n"), Dumper=dumper) == yaml.safe_dump(binary_type("test\r\n"))

# Generated at 2022-06-20 23:54:34.077735
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hv = HostVars()
    hv["foo"] = "bar"
    hv["baz"] = "qux"
    hostvars = AnsibleDumper.represent_hostvars(hv)
    assert hostvars == "foo: bar\nbaz: qux\n"



# Generated at 2022-06-20 23:54:39.532971
# Unit test for function represent_unicode
def test_represent_unicode():
    u = yaml.serializer.SafeRepresenter.represent_unicode
    uni = text_type(u'["\u2603", "\xe9", "\u20ac", "\U0010ffff"]')
    assert uni == u(u'["\u2603", "\xe9", "\u20ac", "\U0010ffff"]')



# Generated at 2022-06-20 23:54:43.080219
# Unit test for function represent_undefined
def test_represent_undefined():
    '''
    Unit test for function represent_undefined
    '''
    yaml.dump(AnsibleUndefined('test_undefined'), Dumper=AnsibleDumper)

# Generated at 2022-06-20 23:54:44.341644
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper


# Generated at 2022-06-20 23:54:51.076778
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(b'a', Dumper=AnsibleDumper) == 'a\n...\n'
    assert yaml.dump(b'\n', Dumper=AnsibleDumper) == '|-\n  \n'
    assert yaml.dump(b'\t', Dumper=AnsibleDumper) == '|-\n  \\t\n'
    assert yaml.dump(b'\x01', Dumper=AnsibleDumper) == '|-\n  \\x01\n'

# Generated at 2022-06-20 23:54:59.608107
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    plaintext = u'Jane Smith'
    password = 'password'

    vault = VaultLib([password])
    ciphertext = vault.encrypt(plaintext)
    encrypted_unicode = AnsibleVaultEncryptedUnicode(ciphertext)
    dump = yaml.dump([encrypted_unicode], Dumper=AnsibleDumper, default_flow_style=False)

# Generated at 2022-06-20 23:55:10.997377
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-20 23:55:12.980912
# Unit test for function represent_undefined
def test_represent_undefined():
    test_data = {'foo': AnsibleUndefined}
    yaml.dump(test_data, Dumper=AnsibleDumper)

# Generated at 2022-06-20 23:55:16.876407
# Unit test for function represent_unicode
def test_represent_unicode():
    data = {u'unicode': AnsibleUnicode('test')}
    dumped = yaml.dump(data, Dumper=AnsibleDumper, default_flow_style=False)
    expected = '''---
unicode: test
'''
    assert dumped == expected



# Generated at 2022-06-20 23:55:35.718550
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    result = vault.encrypt('foobar')
    actual = yaml.dump({'foo': AnsibleVaultEncryptedUnicode(result)}, Dumper=AnsibleDumper, default_flow_style=False).strip()

# Generated at 2022-06-20 23:55:39.042521
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper(allow_unicode=True)
    undefined = AnsibleUndefined('here')
    undefined_str = yaml.dump(undefined, Dumper=dumper)
    assert 'Error in templating' in undefined_str

# Generated at 2022-06-20 23:55:42.393665
# Unit test for function represent_unicode
def test_represent_unicode():
    ret = yaml.dump(text_type(u'abc \N{SNOWMAN}'), Dumper=AnsibleDumper, default_flow_style=True)
    assert ret == u'!ansible_safe "abc \N{SNOWMAN}"\n'



# Generated at 2022-06-20 23:55:48.084894
# Unit test for function represent_hostvars
def test_represent_hostvars():
    import yaml
    from ansible.vars.manager import VarsManager
    myinput = dict(a=1, b=2)
    myhostvars = VarsManager(hostvars=myinput)
    myoutput = yaml.safe_dump({'hv': myhostvars}, default_flow_style=False, Dumper=AnsibleDumper)
    assert myoutput.strip() == '{hv: {a: 1, b: 2}}'

    # Test nested HostVars
    myinput = dict(a=1, b=2)
    myhostvars = VarsManager(hostvars=myinput)
    mynest = dict(c=myhostvars)

# Generated at 2022-06-20 23:55:50.876875
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    ansible_dumper = AnsibleDumper(indent=4)

    assert isinstance(ansible_dumper, type(AnsibleDumper))

# Generated at 2022-06-20 23:55:54.220286
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    # Test unicode_representer
    value = u'123'
    assert value == yaml.representer.SafeRepresenter.represent_str(dumper, value)



# Generated at 2022-06-20 23:56:02.367014
# Unit test for function represent_undefined
def test_represent_undefined():

    def test_func(arg):
        # this function will be replaced with a mock in the test
        return repr(arg)

    from ansible.template import _fail_with_undefined_error
    from ansible.template.safe_eval import Undefined
    _fail_with_undefined_error = test_func

    # Setup an Undefined object to be dumped
    undef = Undefined()
    undef.__bool__ = lambda: False
    data = {'foo': undef}

    try:
        yaml.dump(data, Dumper=AnsibleDumper)
        assert False
    except Exception as e:
        assert str(e) == repr(undef)

# Generated at 2022-06-20 23:56:03.868567
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper([])
    assert dumper.represent_unicode(u'foo') == "foo"

# Generated at 2022-06-20 23:56:04.793576
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert type(AnsibleDumper) is type

# Generated at 2022-06-20 23:56:15.276616
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # Test a single variable
    hostvars = HostVars()
    hostvars['foo'] = 'bar'
    data = yaml.load(yaml.dump(hostvars, Dumper=AnsibleDumper))
    assert data['foo'] == 'bar'

    # Test 2 variables
    hostvars['bar'] = 'baz'
    data = yaml.load(yaml.dump(hostvars, Dumper=AnsibleDumper))
    assert data['bar'] == 'baz'

    # Test a variable where the base variable starts with an underscore
    hostvars['_foo'] = 'bar'
    data = yaml.load(yaml.dump(hostvars, Dumper=AnsibleDumper))
    assert data['_foo'] == 'bar'

    # Test a variable where the deeper

# Generated at 2022-06-20 23:56:35.744415
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(AnsibleDumper, AnsibleUnicode(u'abc')) == u"!ansible-unicode 'abc'"


# Generated at 2022-06-20 23:56:44.838001
# Unit test for function represent_binary
def test_represent_binary():
    """
    Tests to make sure it's behaving as expected with
    both string and bytes data.
    """
    def _verify(data):
        valid_outputs = (
            b"!!binary 'YmluYXJ5ZGF0YQ=='",
            u"!!binary 'YmluYXJ5ZGF0YQ=='",
            "'YmluYXJ5ZGF0YQ=='",
        )
        assert data in valid_outputs

    dumper = AnsibleDumper()
    output = dumper.represent_binary(u'binarydata')
    _verify(output)

    output = dumper.represent_binary(b'binarydata')
    _verify(output)

test_represent_binary()

# Generated at 2022-06-20 23:56:47.424790
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'),
                     default_flow_style=False,
                     Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-20 23:56:48.895547
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper()
    assert isinstance(dumper, AnsibleDumper)

# Generated at 2022-06-20 23:56:50.328496
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_data(AnsibleUndefined()) == False

# Generated at 2022-06-20 23:56:50.815659
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    AnsibleDumper()

# Generated at 2022-06-20 23:56:52.755994
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_data(AnsibleUndefined(fail_on_undefined=True)) is None

# Generated at 2022-06-20 23:56:54.864115
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == "foo\n..."



# Generated at 2022-06-20 23:56:55.526064
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper

# Generated at 2022-06-20 23:56:58.914822
# Unit test for function represent_unicode
def test_represent_unicode():
    input_string = "byte string"
    ans = yaml.dump(input_string)
    assert ans == u'tag:yaml.org,2002:str\nfoo\n...\n'

# Generated at 2022-06-20 23:58:21.650747
# Unit test for function represent_unicode
def test_represent_unicode():
    '''
    get a unicode(str) object
    '''
    u_obj = text_type("abc")
    assert isinstance(u_obj, text_type)
    yaml_str = yaml.dump(u_obj, Dumper=AnsibleDumper,
            default_flow_style=False)
    assert yaml_str == "!!python/unicode 'abc'\n"


# Generated at 2022-06-20 23:58:26.198184
# Unit test for function represent_hostvars
def test_represent_hostvars():
    import io
    import io
    import sys
    import _io
    import collections

    output = io.StringIO()

    class FakeOutputStream:
         def __init__(self, stream):
             self.stream = stream
         def write(self, text, nonl=False):
             self.stream.write(text)

    sys.stdout = FakeOutputStream(sys.stdout)
    yaml.dump(dict(hostvars=dict(test="testval")), output, Dumper=AnsibleDumper)

    assert output.getvalue() == "hostvars:\n  test: testval\n"

# Generated at 2022-06-20 23:58:33.163569
# Unit test for function represent_binary
def test_represent_binary():
    # By default represent_binary should represent byte strings with the !!binary tag.
    # If this is not the case, that tag is not supported by libyaml, and we need to use
    # the !!str tag.
    dumper = AnsibleDumper()
    data = dumper.represent_binary(b'', '!!binary')
    assert isinstance(data, yaml.ScalarNode)
    assert data.value == ''
    assert data.style == '|'
    assert data.tag == '!!binary'

# Generated at 2022-06-20 23:58:38.165572
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hv = HostVars()
    hv.update(dict(a=1, b=2))
    assert represent_hostvars(yaml.dumper.Dumper(), hv) == yaml.representer.SafeRepresenter.represent_dict(yaml.dumper.Dumper(), dict(a=1, b=2))



# Generated at 2022-06-20 23:58:40.179550
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    assert dumper.represent_data(AnsibleUndefined) is not None


# Note: only want to represent the encrypted data

# Generated at 2022-06-20 23:58:43.283107
# Unit test for function represent_binary
def test_represent_binary():
    '''
    Dump binary string to yaml format.
    '''
    for data in ['bin', b'bin']:
        assert yaml.dum

# Generated at 2022-06-20 23:58:51.274357
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\n3539343033333063386264326362373033646137656631623861616430336532653966623863343133333\n6393036336331643134656365663635376639333732303931636331376133313365383732323763316664\n65313930383465313230363833613333353936333435653733363038643561303\n')

# Generated at 2022-06-20 23:59:01.514642
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    import ansible.parsing.vault
    from ansible.parsing.yaml.loader import AnsibleLoader

    args = [ '--ask-vault-pass', '--vault-password-file=%s' % '/dev/zero' ]
    vault_password = ansible.parsing.vault.get_vault_password(args, '/dev/zero', None)


# Generated at 2022-06-20 23:59:05.761748
# Unit test for function represent_unicode
def test_represent_unicode():
    from ansible.module_utils.common.yaml import AnsibleDumper
    from ansible.module_utils.six import text_type

    text = text_type(u'foo')
    assert text == AnsibleDumper.represent_unicode(AnsibleDumper, text), 'represent_unicode failed'

# Generated at 2022-06-20 23:59:07.601909
# Unit test for function represent_binary
def test_represent_binary():
    my_string = AnsibleUnsafeBytes(b'{}')
    tmp = AnsibleDumper().represent_binary(my_string)
    assert tmp == u'!!binary |\n  e30='

    tmp = AnsibleDumper().represent_data(my_string)
    assert tmp == u'!!binary |\n  e30='

