

# Generated at 2022-06-20 23:50:46.717811
# Unit test for function represent_hostvars
def test_represent_hostvars():
    import datetime
    v = HostVars(dict(
        hello='world',
        foo='bar',
        the_time=datetime.datetime(2017, 2, 4, 2, 4, 2, 6),
    ))
    expected = yaml.safe_dump({'hello': 'world', 'foo': 'bar', 'the_time': '2017-02-04T02:04:02.000006'},
                              default_flow_style=False)
    dumped = yaml.safe_dump(v, default_flow_style=False, Dumper=AnsibleDumper)
    assert dumped == expected



# Generated at 2022-06-20 23:50:48.851310
# Unit test for function represent_unicode
def test_represent_unicode():
    # Verify this doesn't raise an Exception
    represent_unicode(AnsibleDumper, 'foo')



# Generated at 2022-06-20 23:50:50.225743
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper(None, None, None)
    assert dumper

# Generated at 2022-06-20 23:50:57.146957
# Unit test for function represent_unicode
def test_represent_unicode():
    test_data = dict(
        ansible_unicode=AnsibleUnicode('unicode_test'),
        ansible_unsafe_text=AnsibleUnsafeText('unsafe_test'),
        ansible_unsafe_bytes=AnsibleUnsafeBytes(b'bytes_test'),
    )
    assert yaml.dump(test_data, Dumper=AnsibleDumper) == 'ansible_unsafe_bytes: "bytes_test"\nansible_unsafe_text: unsafe_test\nansible_unicode: unicode_test\n'

# Generated at 2022-06-20 23:51:04.314167
# Unit test for function represent_binary
def test_represent_binary():
    loader = yaml.SafeLoader
    dumper = AnsibleDumper
    yaml_data = AnsibleUnsafeBytes('hello world')
    yaml_repr = dumper.represent_binary(dumper, yaml_data)
    assert yaml_repr == '!!binary |-\n  aGVsbG8gd29ybGQ=\n'
    data = loader.construct_yaml_binary(loader, yaml_repr)
    assert data == yaml_data

# Generated at 2022-06-20 23:51:09.890899
# Unit test for function represent_undefined
def test_represent_undefined():
    # All of these should return True when passed to represent_undefined
    assert bool(1)
    assert bool(AnsibleUndefined('test'))
    assert bool(AnsibleUndefined(5.5))
    assert bool(AnsibleUndefined(True))
    assert bool(AnsibleUndefined(False))
    assert bool(AnsibleUndefined([]))
    assert bool(AnsibleUndefined({}))

    # All of these should return False when passed to represent_undefined
    assert not bool(None)
    assert not bool(0)
    assert not bool('')
    assert not bool([])
    assert not bool({})
    assert not bool(())
    assert not bool(set())

# Generated at 2022-06-20 23:51:15.732670
# Unit test for function represent_unicode
def test_represent_unicode():
    # Create a test object from unicode
    u = u'\u00e9'
    testobj = dict(
        ansible_for_unicode=u,
    )

    # Create expected results
    expected = """\
ansible_for_unicode: "\\u00e9"
"""

    # Convert test object to YAML repr
    emit = yaml.dump(testobj, default_flow_style=False)
    #print("emit")
    #print(emit)
    #assert emit == expected
    #print(yaml.dump(testobj))


# Generated at 2022-06-20 23:51:18.965000
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump({
        b'foo': binary_type('bar'),
    }, Dumper=AnsibleDumper) == '{foo: !!binary |-\n    bar\n}'

# Generated at 2022-06-20 23:51:21.741059
# Unit test for function represent_hostvars
def test_represent_hostvars():
    import collections
    yaml.dump({'a': {'hello': 'world'}}, stream=None, Dumper=AnsibleDumper)
    assert isinstance(AnsibleDumper.dispatch, collections.defaultdict)

# Generated at 2022-06-20 23:51:25.315458
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper
    assert dumper.represent_hostvars(dumper, HostVars({"a": "b"})) == dumper.represent_dict({"a": "b"})



# Generated at 2022-06-20 23:51:31.051692
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b"\x00\x01\x02\x03") == "!!binary |\n  AAECAQ==\n"


# EOF

# Generated at 2022-06-20 23:51:43.344606
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    import base64
    # construct the object to represent

# Generated at 2022-06-20 23:51:47.169795
# Unit test for function represent_binary
def test_represent_binary():
    test_string = "abc123"
    dumper = AnsibleDumper
    result = binary_type(base64.b64encode(test_string.encode('utf-8')).decode('ascii'))
    assert result == dumper.represent_binary(dumper, test_string)

# Generated at 2022-06-20 23:51:59.068182
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.plugins.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    secret = 'secret'
    ciphertext = VaultLib.encrypt(secret)
    mock_data = AnsibleVaultEncryptedUnicode(ciphertext)
    d = AnsibleDumper()

# Generated at 2022-06-20 23:52:04.191661
# Unit test for function represent_unicode
def test_represent_unicode():
    unicode_obj = AnsibleUnicode("test string")
    dumper = AnsibleDumper
    expected = yaml.representer.SafeRepresenter.represent_str(dumper, text_type(unicode_obj))
    result = dumper.represent_unicode(dumper, unicode_obj)
    assert result == expected



# Generated at 2022-06-20 23:52:13.156943
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # python2
    if yaml.__with_libyaml__:
        expected_yaml_list = u"""{a: 0, b: 1}
"""
    else:
        expected_yaml_list = u"""{a: 0, b: 1}
..."""
    hostvars_value = HostVars({u'a': 0, u'b': 1})
    dump_result_list = yaml.dump(hostvars_value, Dumper=AnsibleDumper, default_flow_style=False)
    assert dump_result_list == expected_yaml_list
    # python3
    if yaml.__with_libyaml__:
        expected_yaml_dict = u"""{a: 0, b: 1}
"""

# Generated at 2022-06-20 23:52:17.781470
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    result = dumper.represent_unicode(u'foo')
    assert result == yaml.representer.SafeRepresenter.represent_str(dumper, u'foo')



# Generated at 2022-06-20 23:52:21.931738
# Unit test for function represent_hostvars
def test_represent_hostvars():
    h = HostVars({'test': 'ok', 'test2': 'ok2'})
    h = h.copy()
    data = AnsibleDumper().represent_data({'test_dict': h})
    assert data == 'test_dict: {test: ok, test2: ok2}\n'



# Generated at 2022-06-20 23:52:26.163410
# Unit test for function represent_hostvars
def test_represent_hostvars():
    d = AnsibleDumper()
    output = d.represent_hostvars(HostVars(dict(a=1), HostVarsVars({'a': 1}), VarsWithSources('', {'a': 1})))
    assert output == d.represent_dict({'a': 1})



# Generated at 2022-06-20 23:52:30.860551
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVarsVars

    d = AnsibleDumper()
    hostvars = HostVarsVars.from_play("all", "localhost")
    hostvars.vars.update({u'foo': u'bar', u'baz': u'quux'})
    buf = d.represent_hostvars(hostvars)

    assert buf == yaml.compose(yaml.load("""
---
foo: 'bar'
baz: 'quux'
"""), Loader=yaml.SafeLoader, Dumper=d)

# Generated at 2022-06-20 23:52:38.829006
# Unit test for function represent_hostvars
def test_represent_hostvars():
    my_dict = SafeDumper.represent_dict(AnsibleDumper(None, None), dict(foo='bar'))
    my_hostvars = represent_hostvars(AnsibleDumper(None, None), HostVars({'hostname': 'localhost', 'foo': 'bar'}, None, None))
    assert my_dict == my_hostvars
    assert my_dict == u'{foo: bar}\n'
    assert isinstance(my_dict, text_type)



# Generated at 2022-06-20 23:52:50.708577
# Unit test for function represent_hostvars
def test_represent_hostvars():
    h = yaml.load('''
        ---
        a: 1
        ''', Loader=yaml.Loader)
    y = yaml.load('''
        ---
        !ansible.builtin.hostvars
        a: 1
        ''', Loader=yaml.Loader)
    assert type(h) == dict
    assert type(y) == HostVars

    data = {'k': 'v'}
    d = AnsibleDumper()
    m = d.represent_hostvars(data)
    assert type(m) == yaml.nodes.MappingNode

    class Foo(VarsWithSources):
        def __init__(self, data):
            self.data = data

    foo = Foo(data)
    f = d.represent_hostvars(foo)
    assert type

# Generated at 2022-06-20 23:52:53.396383
# Unit test for function represent_undefined
def test_represent_undefined():
    # Undefined object should always return false
    assert not represent_undefined(None, AnsibleUndefined())

# Generated at 2022-06-20 23:52:57.273180
# Unit test for function represent_unicode
def test_represent_unicode():
    '''Test represent_unicode function'''
    unicode_object = AnsibleUnicode(u'\xb5')
    assert '\xc2\xb5' == yaml.dump(unicode_object, Dumper=AnsibleDumper)



# Generated at 2022-06-20 23:53:09.294435
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    def yaml_represent(self, data):
        return self.represent_scalar(u'tag:yaml.org,2002:str', text_type(data), style='|')

    # Sadly we have no way of retrieving the generated output.
    # This hack is necessary so that we can theoretically test this function.
    yaml.add_representer(A, yaml_represent)

    class A(object):
        def __init__(self, val):
            self._ciphertext = val

        def __str__(self):
            return "class A (%s)" % self._ciphertext

    import sys
    orig_stdout = sys.stdout

# Generated at 2022-06-20 23:53:16.167777
# Unit test for function represent_undefined
def test_represent_undefined():
    # On py3 SafeRepresenter() returns a class that represents str()
    # as a string, not a literal
    dumper = yaml.SafeRepresenter()
    yaml.representer.SafeRepresenter.add_representer(
        AnsibleUndefined, represent_undefined
    )(dumper)
    result = dumper.represent_data(AnsibleUndefined())
    assert result == "None"



# Generated at 2022-06-20 23:53:26.689785
# Unit test for function represent_binary
def test_represent_binary():

    class TestAnsibleDumper(AnsibleDumper):
        '''
        A simple stub class that allows us to add representers
        for our overridden object types.
        '''

    # Create an instance of AnsibleDumper for testing
    dumper = TestAnsibleDumper()

    # Test strings

# Generated at 2022-06-20 23:53:28.735296
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    undefined = AnsibleUndefined("message")
    assert dumper.represent_undefined(dumper, undefined)

# Generated at 2022-06-20 23:53:31.365645
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    # No need to test constructor as it is a simple wrapper.
    # As long as it runs and doesn't throw any exception,
    # we can consider it as successful instantiation.
    dumper = AnsibleDumper()

# Generated at 2022-06-20 23:53:36.337727
# Unit test for function represent_binary
def test_represent_binary():
    # Test AnsibleDumper on binary_type
    import sys
    if sys.version_info.major == 2:
        data = binary_type(b'\xc3\xa8')
    else:
        data = binary_type('\xe8', 'UTF-8')
    assert data == b'\xc3\xa8'
    actual = yaml.dump(data, Dumper=AnsibleDumper, allow_unicode=True)
    assert actual == b'!!binary |\n  w6E=\n'



# Generated at 2022-06-20 23:53:45.568497
# Unit test for function represent_hostvars
def test_represent_hostvars():
    h = HostVars()
    h.update({u'key1': u'value1', u'key2': u'value2'})
    assert 'key1: value1\nkey2: value2' == yaml.dump(h, Dumper=AnsibleDumper, default_flow_style=False)



# Generated at 2022-06-20 23:53:47.864114
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper()
    assert dumper.__class__.__name__ == 'AnsibleDumper'

# Generated at 2022-06-20 23:53:50.565764
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    test_data = HostVars()
    result = dumper.represent_hostvars(test_data)
    assert result == u'{}'

# Generated at 2022-06-20 23:53:53.792485
# Unit test for function represent_binary
def test_represent_binary():
    u = AnsibleUnsafeBytes(b'hello')
    d = AnsibleDumper()
    assert b"!binary |\n  aGVsbG8=" == d.represent_binary(u)



# Generated at 2022-06-20 23:53:57.233584
# Unit test for function represent_binary
def test_represent_binary():
    data = b'\n'
    assert AnsibleDumper.represent_binary(None, data) == (
        '!!binary |-\n'
        '  Cg==\n'
    )



# Generated at 2022-06-20 23:53:58.975224
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper().represent_data(AnsibleUndefined())



# Generated at 2022-06-20 23:54:07.837711
# Unit test for function represent_hostvars
def test_represent_hostvars():
    '''
    Basic test for function represent_hostvars
    '''
    import io
    from ansible.vars.hostvars import HostVars

    test_output = u'''{yaml_key: yaml_value, y_key: y_value}
'''
    hostvars = HostVars({u'yaml_key': u'yaml_value', u'y_key': u'y_value'}, vault_password=u'vault')
    output = io.StringIO()
    yaml.dump({u'hostvars': hostvars}, output, Dumper=AnsibleDumper)

    assert output.getvalue() == test_output



# Generated at 2022-06-20 23:54:10.691375
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    assert dumper.represent_unicode(dumper, u'foo') == yaml.representer.SafeRepresenter.represent_str(dumper, 'foo')

# Generated at 2022-06-20 23:54:17.721775
# Unit test for function represent_undefined
def test_represent_undefined():
    # This tests the dumper can handle undefined values and that
    # it doesn't crash (as it would if the dumper did not handle
    # undefined values correctly)
    data = dict(
        undefined_value=AnsibleUndefined
    )
    result = yaml.dump(data, Dumper=AnsibleDumper)
    assert result == ''



# Generated at 2022-06-20 23:54:25.124314
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    ansible_dumper = AnsibleDumper()
    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode(api_version=2, cipher='b', salt='c', hmac='d', iterations=5, ciphertext='e')
    result = yaml.representer.SafeRepresenter.represent_scalar(ansible_dumper, u'!vault', ansible_vault_encrypted_unicode._ciphertext.decode(), style='|')
    assert result == u'!vault |\n  e'


# Generated at 2022-06-20 23:54:38.880374
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-20 23:54:49.584267
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-20 23:54:53.408277
# Unit test for function represent_unicode
def test_represent_unicode():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    string = u'str\u1234ing'
    assert(string == AnsibleUnicode(string))

# Generated at 2022-06-20 23:54:55.384789
# Unit test for function represent_undefined
def test_represent_undefined():
    undefined = AnsibleUndefined('unit test')
    d = AnsibleDumper(default_flow_style=False)
    assert bool(undefined)

# Generated at 2022-06-20 23:54:57.196232
# Unit test for function represent_binary
def test_represent_binary():
    result = yaml.dump(b'test')
    assert result == "!!binary |\n  dGVzdA=="



# Generated at 2022-06-20 23:54:59.669158
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.dump({'a': AnsibleUndefined()}, Dumper=AnsibleDumper) == \
           """\
{\"a\": \"{{ a }}\"}
"""

# Generated at 2022-06-20 23:55:09.441113
# Unit test for function represent_hostvars
def test_represent_hostvars():
    import io

    dumper = AnsibleDumper(explicit_start=True, explicit_end=True)

    class DummyVars(HostVars):
        def get_vars(self, loader, path, entities, cache=True):
            return {'testing': 123}

    assert yaml.dump(DummyVars(), Dumper=AnsibleDumper, default_flow_style=False) == '---\nhostvars:\n    testing: 123\n\n'

    with io.BytesIO() as stream:
        dumper.dump(DummyVars(), stream)
        assert stream.getvalue() == b'---\nhostvars:\n    testing: 123\n\n'

# Generated at 2022-06-20 23:55:11.293060
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper(width=1000)
    assert dumper.width == 1000

# Generated at 2022-06-20 23:55:15.579141
# Unit test for function represent_unicode
def test_represent_unicode():
    # Prepare test data
    input_str = u"test input string"
    expected_result = u"test input string\n"
    # Do the test
    dumper = AnsibleDumper()
    actual_result = dumper.represent_unicode(input_str)
    # Verify test result
    assert actual_result == expected_result



# Generated at 2022-06-20 23:55:23.282936
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():

    import StringIO


# Generated at 2022-06-20 23:55:44.859940
# Unit test for function represent_unicode
def test_represent_unicode():
    text_data = 'this is a test'
    dumper = AnsibleDumper
    output1 = dumper.represent_unicode(dumper, AnsibleUnicode(text_data))
    output2 = dumper.represent_unicode(dumper, AnsibleUnsafeText(text_data))
    assert output1 == output2
    assert output1 == "this is a test"
    byte_data = b'abc123'
    output3 = dumper.represent_binary(dumper, AnsibleUnsafeBytes(byte_data))
    assert output3 == "YWJjMTIz"



# Generated at 2022-06-20 23:55:56.097865
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-20 23:56:04.296199
# Unit test for function represent_binary
def test_represent_binary():
    # define a function to make the test
    def test_func(input_data):
        stream = yaml.dump(input_data, Dumper=AnsibleDumper)
        # we expect the first char to be '!', the second char to be '\n'
        return stream[0], stream[1]

    # check that we get '!', '\n' when we feed the function a str
    assert test_func(u'\u2603') == ('!', '\n')

    # check that we get '!', '\n' when we feed the function a str
    assert test_func(b'\xe2\x98\x83') == ('!', '\n')



# Generated at 2022-06-20 23:56:05.832906
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.dump([AnsibleUndefined()], Dumper=AnsibleDumper) == "[None]\n"

# Generated at 2022-06-20 23:56:16.928822
# Unit test for function represent_binary
def test_represent_binary():

    plaintext = binary_type('hello')

# Generated at 2022-06-20 23:56:18.694676
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper.represent_undefined(AnsibleDumper(None), "test") is False

# Generated at 2022-06-20 23:56:22.708379
# Unit test for function represent_binary
def test_represent_binary():
    yaml_data = b"\x01\x02\x03\x04"
    
    yaml_string = yaml.dump(yaml_data, Dumper=AnsibleDumper)
    assert len(yaml_string) == 0
    assert yaml_string == ""

# Generated at 2022-06-20 23:56:24.054446
# Unit test for function represent_undefined
def test_represent_undefined():
    undefined = AnsibleDumper.represent_undefined(AnsibleUndefined())
    assert undefined is False

# Generated at 2022-06-20 23:56:26.232662
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper
    d = {'a': 'b'}
    assert dumper.represent_hostvars(dumper, d) == dumper.represent_dict(d)

# Generated at 2022-06-20 23:56:31.271405
# Unit test for function represent_hostvars
def test_represent_hostvars():
    def _test_represent_hostvars(value):
        assert yaml.dump(value, Dumper=AnsibleDumper) == data
    data = """test:
- true"""
    value = {b'test': [True]}
    _test_represent_hostvars(value)
    data = """test:
  foo: true"""
    value = {b'test': {b'foo': True}}
    _test_represent_hostvars(value)
    data = """test: true"""
    value = {b'test': True}
    _test_represent_hostvars(value)
    data = """test:
  - foo: true"""
    value = {b'test': [{b'foo': True}]}
    _test_represent_hostvars(value)


# Generated at 2022-06-20 23:57:05.294117
# Unit test for function represent_hostvars
def test_represent_hostvars():
    d = AnsibleDumper()
    data_in = b'abc'
    data_out = 'abc'
    assert d.represent_unicode(data_in) == data_out



# Generated at 2022-06-20 23:57:13.509131
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-20 23:57:18.501657
# Unit test for function represent_binary
def test_represent_binary():
    data = AnsibleUnsafeBytes('test')
    dumper = AnsibleDumper()
    dumper.add_representer(AnsibleUnsafeBytes, represent_binary)
    assert dumper.represent_data(data) == '!binary |\n  dGVzdA==\n'

# Generated at 2022-06-20 23:57:19.824202
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert hasattr(AnsibleDumper, 'add_multi_representer')

# Generated at 2022-06-20 23:57:24.660936
# Unit test for function represent_undefined
def test_represent_undefined():
    def throw_exception():
        raise Exception('AnsibleUndefined should be caught by represent_undefined')

    # Make sure when AnsibleUndefined, the false value will trigger the exception.
    assert not AnsibleUndefined.exception or throw_exception()

    # Make sure when not AnsibleUndefined, the true value will not trigger the exception.
    assert AnsibleUnicode.exception or not throw_exception()


# Generated at 2022-06-20 23:57:27.271693
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    assert(dumper.represent_data(AnsibleUndefined(fail_on_undefined=True)) == True)
    assert(dumper.represent_data(AnsibleUndefined(fail_on_undefined=False)) == False)

# Generated at 2022-06-20 23:57:31.624990
# Unit test for function represent_binary
def test_represent_binary():
    sut = AnsibleDumper()
    data = AnsibleUnsafeBytes(b'caf\xc3\xa9')
    assert yaml.representer.SafeRepresenter.represent_binary(sut, binary_type(data)) == sut.represent_binary(data)



# Generated at 2022-06-20 23:57:35.893560
# Unit test for function represent_hostvars
def test_represent_hostvars():
    d = AnsibleDumper()
    d1 = {('extra', 'ssl_verify'): True}
    hv = HostVars(host_name='test.example.com',
                  host_vars=d1)
    yaml_out = d.represent_dat

# Generated at 2022-06-20 23:57:43.018277
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    # Test without constructor argument
    AnsibleDumper()

    # Test with empty constructor argument
    AnsibleDumper(dict())

    # Test with invalid constructor arguments
    try:
        AnsibleDumper(tag="tag", sorter=False)
    except Exception as e:
        assert "is not a valid constructor argument" in str(e)

    try:
        AnsibleDumper(sorter=False)
    except Exception as e:
        assert "is not a valid constructor argument" in str(e)

# Generated at 2022-06-20 23:57:52.150040
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

    # Test with no encoding
    test_bytes = b'abcd'
    result = dumper.represent_binary(test_bytes)

    assert result.value == b'abcd'
    assert isinstance(result.value, binary_type)

    # Test with unicode encoding
    test_bytes = b'\xE6\x97\xA5\xE6\x9C\xAC\xE8\xAA\x9E'
    result = dumper.represent_binary(test_bytes)

    assert isinstance(result.value, binary_type)
    assert isinstance(result.style, text_type)

    test_string = '日本語'
    result = dumper.represent_binary(test_string)
