

# Generated at 2022-06-20 23:50:50.729284
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

    # Test empty binary
    assert dumper.represent_binary(b'') == u"!binary |\n  "

    # Test binary with newline
    assert dumper.represent_binary(b'\n') == u"!binary |\n  \\n"

    # Test binary with space
    assert dumper.represent_binary(b' ') == u"!binary |\n  "

    # Test binary with newline and space
    assert dumper.represent_binary(b' \n') == u"!binary |\n  \\ \n"

    # Test binary without newline ending with space
    assert dumper.represent_binary(b' \n ') == u"!binary |\n  \\ \n\\ \n"

# Generated at 2022-06-20 23:50:57.472991
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader

    yaml_data = """
    foo: "{{ foo }}"
    """

    data = AnsibleLoader(yaml.load(yaml_data)).get_single_data()
    templar = Templar(loader=None)
    new_data = templar.do_template_complex(data, {})
    dumped = yaml.dump(new_data, Dumper=AnsibleDumper)

    assert dumped == "---\nfoo: 'true'\n"

# Generated at 2022-06-20 23:50:59.304363
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
  assert repr(AnsibleDumper()) == '<AnsibleDumper>'

# Generated at 2022-06-20 23:51:00.736718
# Unit test for function represent_undefined
def test_represent_undefined():
    assert not yaml.serialize(AnsibleUndefined())

# Generated at 2022-06-20 23:51:10.318377
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    loader = yaml.Loader()
    data = yaml.load('''
- test1
- test2
    ''', loader)
    assert data == [u'test1', u'test2']

    dumper = AnsibleDumper(width=1)
    data = yaml.dump(data, dumper)
    assert data == u'''- test1
- test2\n'''

    loader = yaml.SafeLoader(width=1)
    data = yaml.load('''
- test1
- test2
    ''', loader)
    assert data == [u'test1', u'test2']

    data = yaml.dump(data, dumper)
    assert data == u'''- test1
- test2\n'''

# Generated at 2022-06-20 23:51:15.185058
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():

    # Test with no arguments
    my_ansible_dumper = AnsibleDumper()

    # Test with a single argument
    my_ansible_dumper = AnsibleDumper('my_single_argument')

    # Test with multiple arguments
    my_ansible_dumper = AnsibleDumper(my_arg1='my_arg1', my_arg2='my_arg2')

# Generated at 2022-06-20 23:51:24.267109
# Unit test for function represent_binary

# Generated at 2022-06-20 23:51:36.318382
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from io import StringIO
    from ansible.vars.manager import VariableManager

    fake_host = 'fake_host'
    variable_manager = VariableManager()
    variable_manager.set_host_variable(fake_host, 'fake_host_result', 'fake_host_result_data')
    variable_manager.set_host_variable(fake_host, 'fake_host_result2', 'fake_host_result2_data')
    data = variable_manager.get_vars(loader=None, play=None, host=fake_host)

    out = StringIO()
    yaml.dump(data, out, Dumper=AnsibleDumper, default_flow_style=False)
    result = out.getvalue()

# Generated at 2022-06-20 23:51:47.332591
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper(width=10000)
    # Just load a simple mapping with a value set to None
    data = AnsibleMapping({'foo': None})
    # Represent the None value
    yaml_data = dumper.represent_data(data)
    # Convert to text, split on new line and check for the key: value pair
    yaml_data = yaml_data.decode()
    lines = yaml_data.splitlines()
    assert 'foo:' in lines
    # Just load a simple mapping with a value set to Undefined
    data = AnsibleMapping({'foo': AnsibleUndefined('foo')})
    # Represent the None value
    yaml_data = dumper.represent_data(data)
    # Convert to text, split on new line and check for the key: value pair
    yaml

# Generated at 2022-06-20 23:51:51.680529
# Unit test for function represent_undefined
def test_represent_undefined():
    dump = yaml.dump(AnsibleUndefined, Dumper=AnsibleDumper, default_flow_style=False)
    expected = "--- False"
    assert dump == expected, "yaml.dump of AnsibleUndefined failed: %s" % dump

# Generated at 2022-06-20 23:51:58.965787
# Unit test for function represent_unicode
def test_represent_unicode():
    data = {u'fo\xf6': u'b\xe4r'}
    config = AnsibleDumper(default_style=None).represent_unicode(data)
    assert config == u"!!python/unicode '{u'fo\\\\xf6': u'b\\\\xe4r'}'"



# Generated at 2022-06-20 23:52:09.725180
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    # Constructor should store args
    dumper = AnsibleDumper(indent=3)
    assert dumper.default_style == ''
    assert dumper.default_flow_style is False
    assert dumper.indent == 3
    assert dumper.block_seq_indent == 2
    assert dumper.top_level_colon_align is False
    assert dumper.prefix_colon is None

    dumper = AnsibleDumper(indent=4, default_flow_style=True,
                           block_seq_indent=3, top_level_colon_align=True)
    assert dumper.default_style == ''
    assert dumper.default_flow_style is True
    assert dumper.indent == 4
    assert dumper.block_seq_indent == 3
    assert dumper.top

# Generated at 2022-06-20 23:52:12.143549
# Unit test for function represent_unicode
def test_represent_unicode():
    # setup
    instance = AnsibleDumper(None)

    # test
    output = instance.represent_unicode(u"test")

    # assert
    assert output == "test"



# Generated at 2022-06-20 23:52:16.785736
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    test_data = AnsibleVaultEncryptedUnicode('test_data')
    assert represent_vault_encrypted_unicode(AnsibleDumper, test_data) == '!vault |\n  test_data'


# Generated at 2022-06-20 23:52:20.061546
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    print(dumper.represent_data(AnsibleUndefined()))
    print(dumper.represent_data(AnsibleUndefined('msg')))

# Generated at 2022-06-20 23:52:22.175572
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    from ansible.template import Undefined
    assert Undefined.__reduce__ is AnsibleDumper()._undefined_repr_reduce



# Generated at 2022-06-20 23:52:24.243059
# Unit test for function represent_binary
def test_represent_binary():
    assert b'!binary |' in yaml.dump(b'foo', Dumper=AnsibleDumper)



# Generated at 2022-06-20 23:52:34.415727
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    # if no options are given it should create a yaml dumper with safe filter
    od = AnsibleDumper()
    assert od.safe_represent_bin is True
    assert od.indent is None
    assert od.width is None
    assert od.allow_unicode is True
    assert od.line_break is None
    assert od.encoding is None
    assert od.explicit_start is False
    assert od.explicit_end is False
    assert od.version is None
    assert od.tags is None
    assert od.block_seq_indent is None
    assert od.top_level_colon_align is False
    assert od.prefix_colon is False
    assert od.quoting is None
    assert od.preserve_quotes is None
    assert od.default_flow_style is False

# Generated at 2022-06-20 23:52:42.654433
# Unit test for function represent_binary
def test_represent_binary():
    representer = yaml.representer.SafeRepresenter()
    representer.represent_binary = represent_binary

    value = b'\x80\x81\x82\xff'
    expected_output = "!!binary |\n  gICAg4LuIAo="
    output = yaml.dump(value, Dumper=AnsibleDumper, default_flow_style=False)

    # Strip yaml version, as it is not expected
    if output.startswith('%YAML 1.1\n'):
        output = output[9:]

    assert output == expected_output



# Generated at 2022-06-20 23:52:52.360873
# Unit test for function represent_hostvars
def test_represent_hostvars():
    """
    Make sure that there are no regexp issues with
    the functions used with represent_dict
    See: #14700
    """
    dumper = AnsibleDumper()
    assert dumper.represent_tree(HostVars({"foo": "bar"})) == ("{foo: bar}\n", 4)

    assert dumper.represent_tree(HostVarsVars({
        "foo": "bar",
        "baz": "foo",
        "bar": "baz",
    })) == ("{foo: bar,\n"
            " bar: baz,\n"
            " baz: foo}\n", 10)

# Generated at 2022-06-20 23:53:00.818240
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager

    vm = VariableManager()

    dumper = AnsibleDumper
    d = {'hostvars': HostVars(vm=vm)}
    data = yaml.load(yaml.dump(d, Dumper=dumper), Loader=AnsibleLoader)
    assert data == d

# Generated at 2022-06-20 23:53:04.702223
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    data = b"Hello World"
    expected = u'!!binary \"SGVsbG8gV29ybGQ=\"\n'
    assert dumper.represent_binary(dumper, data) == expected



# Generated at 2022-06-20 23:53:07.862581
# Unit test for function represent_hostvars
def test_represent_hostvars():

    test_dict = {'a': 1, 'b': 2}
    hv = HostVars()
    hv.update(test_dict)
    dumped = yaml.dump(hv, Dumper=AnsibleDumper, default_flow_style=False)
    assert dumped == 'a: 1\nb: 2\n'

# Generated at 2022-06-20 23:53:12.014409
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import Jinja2Environment

    env = Jinja2Environment()
    def fixture():
        return env.from_string("{{ test_var }}").render({})
    assert fixture.__name__ == 'fixture'
    try:
        fixture()
    except ansible.errors.AnsibleError as e:
        assert 'Unable to look up a name or access' in str(e)
        assert 'fixture' in str(e)
        assert 'test_var' in str(e)

# Generated at 2022-06-20 23:53:15.855149
# Unit test for function represent_unicode
def test_represent_unicode():
    '''Return unicode string as yaml unicode'''
    yaml_str = yaml.dump(u'string')
    assert yaml_str == "u'string'\n..."



# Generated at 2022-06-20 23:53:19.909972
# Unit test for function represent_unicode
def test_represent_unicode():
    unicode_obj = AnsibleUnicode(u"unicode string")
    assert yaml.dump(unicode_obj, Dumper=AnsibleDumper, default_flow_style=False) == u"!!python/unicode 'unicode string'\n"



# Generated at 2022-06-20 23:53:21.399526
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dummy = AnsibleDumper()
    assert dummy is not None

# Generated at 2022-06-20 23:53:25.702948
# Unit test for function represent_binary
def test_represent_binary():
    from ansible.utils._text import to_bytes
    from ansible.template import Templar
    templetor = Templar()
    yaml_str = templetor.template(to_bytes("{{ 'binary is true' | to_yaml }}"))
    assert b': binary is true\n' == yaml_str

# Generated at 2022-06-20 23:53:31.934367
# Unit test for function represent_binary
def test_represent_binary():
    '''
    Test that we handle binary data properly and do not error
    '''
    # Test data
    test_data = b'\xd6\xec\xc7\xd0\r\r\r\r\r\r\r\r\r\r'

    # Test dumper
    test_dumper = AnsibleDumper()

    # Test assert
    assert test_dumper.represent_binary(test_data) == "!!binary |\n  w+GisetCgo=\n"



# Generated at 2022-06-20 23:53:35.779620
# Unit test for function represent_binary
def test_represent_binary():
    # Setup
    dumper = AnsibleDumper
    data = b'xxx'
    expected = '\n'.join([
        '!!binary |',
        '  eHh4',
    ])

    # Run
    result = yaml.scalarstring.BaseScalarString.__str__(dumper.represent_binary(dumper, data))

    # Verify
    assert result == expected



# Generated at 2022-06-20 23:53:40.446300
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    ad = AnsibleDumper()
    assert ad.default_flow_style is False
    assert ad.indent == 4



# Generated at 2022-06-20 23:53:51.881844
# Unit test for function represent_undefined
def test_represent_undefined():

    # test raw Undefined
    assert yaml.dump(AnsibleUndefined()) == ''

    class UndefinedObj(object):
        pass

    # test true Undefined
    assert yaml.dump(AnsibleUndefined(UndefinedObj)) == ''
    assert yaml.dump(AnsibleUndefined(UndefinedObj())) == ''

    # test false Undefined
    assert yaml.dump(AnsibleUndefined(None)) == 'null'
    assert yaml.dump(AnsibleUndefined(False)) == 'false'
    assert yaml.dump(AnsibleUndefined(True)) == 'true'
    assert yaml.dump(AnsibleUndefined('string')) == 'string'
    assert yaml.dump(AnsibleUndefined(1)) == '1'

# Generated at 2022-06-20 23:53:55.336712
# Unit test for function represent_undefined
def test_represent_undefined():
    def check_undefined(x):
        if isinstance(x, AnsibleUndefined):
            raise AssertionError('Found AnsibleUndefined')

    assert_raises(AssertionError, check_undefined, AnsibleUndefined())



# Generated at 2022-06-20 23:54:02.492603
# Unit test for function represent_binary
def test_represent_binary():

    dumper = AnsibleDumper
    # plain ascii
    result = dumper.represent_binary(dumper, b'foo')
    assert result == '!!binary |\n  Zm9v\n'
    # unicode
    result = dumper.represent_binary(dumper, 'привет')
    assert result == '!!binary |\n  0JHRgtC+0LTQuNC80LDRhtC40Y8=\n'

# Generated at 2022-06-20 23:54:05.006461
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert represent_hostvars(None, HostVars(dict(a=42))) == yaml.representer.SafeRepresenter.represent_dict(None, dict(a=42))

# Generated at 2022-06-20 23:54:10.311908
# Unit test for function represent_hostvars
def test_represent_hostvars():
    '''
    Test for represent_hostvars
    '''
    hostvar = HostVars(hostvars=None)
    hostvar.data = {'foo': 'bar'}
    ansible_dump = yaml.dump({'test': hostvar}, Dumper=AnsibleDumper)

    assert ansible_dump == '''\
test:
  foo: bar
'''



# Generated at 2022-06-20 23:54:12.481816
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    represent_undefined(dumper, AnsibleUndefined(':-)'))



# Generated at 2022-06-20 23:54:20.726832
# Unit test for function represent_hostvars
def test_represent_hostvars():
    '''
    This unit test ensures the AnsibleDumper can dump the hostvars object.

    :return:
    '''
    # This is the dictionary to dump
    test_dict = {'body': HostVars({'test': 'hi'})}

    expected = "body: {test: hi}\n"

    dumper = AnsibleDumper
    output = yaml.dump(test_dict, Dumper=dumper)

    assert output == expected



# Generated at 2022-06-20 23:54:24.541797
# Unit test for function represent_binary
def test_represent_binary():
    import io
    output = io.BytesIO()
    o = AnsibleDumper(stream=output)
    o.represent_binary(b"\x02\x05")

    assert output.getvalue() == "!!binary |\n  AgU=\n"



# Generated at 2022-06-20 23:54:28.274923
# Unit test for function represent_binary
def test_represent_binary():
    result = yaml.safe_dump(b"\x80\x81", Dumper=AnsibleDumper)
    assert result == "!!binary |\n  gICAg\n"



# Generated at 2022-06-20 23:54:32.608994
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    """Ensures the constructor for AnsibleDumper returns an instance of AnsibleDumper"""
    assert isinstance(AnsibleDumper(), AnsibleDumper)

# Generated at 2022-06-20 23:54:32.929500
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    AnsibleDumper()

# Generated at 2022-06-20 23:54:34.086302
# Unit test for function represent_unicode
def test_represent_unicode():
    string = u'ansible'
    expected_value = "ansible\n"
    dumper = AnsibleDumper
    assert represent_unicode(dumper, string) == expected_value

# Generated at 2022-06-20 23:54:45.886040
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault_secret = b'$ANSIBLE_VAULT;1.1;AES256'
    vault_password = b"password"
    vault = VaultLib([])
    ciphertext, salt, hmac_digest = vault.encrypt(vault_password, b"secret")
    ciphertext = vault_secret + salt + hmac_digest + ciphertext
    data = AnsibleVaultEncryptedUnicode(ciphertext)
    dumped_data = AnsibleDumper().represent_data(data)

# Generated at 2022-06-20 23:54:55.473779
# Unit test for function represent_undefined
def test_represent_undefined():
    # Continuous integration
    from ansible.template import ansible_template

    plain_text = '{{ foo }}'
    plain_text_result = ansible_template(plain_text)
    plain_text_result_should_be = u'NO VALUE'

    assert plain_text_result == plain_text_result_should_be

    complex_plain_text = '{{ item.test }}: {{ item.test2 }}'
    complex_plain_text_result = ansible_template(complex_plain_text)
    complex_plain_text_result_should_be = u'NO VALUE: NO VALUE'

    assert complex_plain_text_result == complex_plain_text_result_should_be
    # End of unit test for function represent_undefined



# Generated at 2022-06-20 23:54:57.563408
# Unit test for function represent_unicode
def test_represent_unicode():
    x = yaml.dump(text_type('abc'), Dumper=AnsibleDumper)
    assert x == "!!python/unicode 'abc'\n"



# Generated at 2022-06-20 23:55:02.720011
# Unit test for function represent_unicode
def test_represent_unicode():
    # create an AnsibleUnicode object
    value = u'\u0430\u0431'
    obj = AnsibleUnicode(value)

    # create and verify an AnsibleDumper
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(obj) == u'\u0430\u0431'



# Generated at 2022-06-20 23:55:07.346153
# Unit test for function represent_hostvars
def test_represent_hostvars():

    hostvars = HostVars()
    hostvars.update({'one': 'two'})

    assert yaml.dump({'hostvars': hostvars}, Dumper=AnsibleDumper) == u"---\nhostvars: {one: two}\n"


# Generated at 2022-06-20 23:55:14.652817
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # Empty hash
    assert yaml.dump(HostVars({}), Dumper=AnsibleDumper) == '{}\n...\n'

    # non-empty hash
    assert yaml.dump(HostVars({'name': 'val1'}), Dumper=AnsibleDumper) == '{name: val1}\n...\n'

    # hash with None value
    assert yaml.dump(HostVars({'name': None}), Dumper=AnsibleDumper) == '{name: null}\n...\n'



# Generated at 2022-06-20 23:55:21.913214
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.config.manager import ConfigManager
    from ansible.parsing.yaml.objects import AnsibleMapping

    # Note: This is a very limited test, but since most of the code is
    #       removed it is enough.

    config = ConfigManager()

    data = {'hostvars': HostVars(config)}
    result = yaml.dump(data, Dumper=AnsibleDumper)

    # We only do a very limited test here.
    # We do not test the order of the items, nor the
    # order of the items in a hostvars item.
    assert result == '{hostvars: {}}\n'



# Generated at 2022-06-20 23:55:31.178255
# Unit test for function represent_undefined
def test_represent_undefined():
    try:
        yaml.dump(AnsibleUndefined, Dumper=AnsibleDumper)
    except Exception:
        # This is the expected behavior
        pass
    else:
        raise Exception("AnsibleUndefined did not raise an exception with {0}".format(yaml.__version__))



# Generated at 2022-06-20 23:55:32.931971
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined) == True

# Generated at 2022-06-20 23:55:37.808942
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():

    # Prepare to run the test
    v = AnsibleVaultEncryptedUnicode()

    # Test the function
    result = represent_vault_encrypted_unicode(AnsibleDumper, v)

    # Make sure the function call worked
    assert '!vault |' in result
    assert '$ANSIBLE_VAULT' in result

# Generated at 2022-06-20 23:55:39.858062
# Unit test for function represent_unicode
def test_represent_unicode():
    representer = represent_unicode
    message_text = 'hello world'
    assert representer(None, message_text) == message_text

# Generated at 2022-06-20 23:55:42.077579
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert yaml.dump(HostVars({"a": "b"}), Dumper=AnsibleDumper) == "a: b\n"



# Generated at 2022-06-20 23:55:53.204280
# Unit test for function represent_unicode
def test_represent_unicode():
    # UnsafeText should be represented as unicode, not
    # as a float or integer.
    data = AnsibleUnsafeText(u'123')
    data1 = yaml.load(yaml.dump(data, Dumper=AnsibleDumper))
    data2 = yaml.load(yaml.dump(data, Dumper=AnsibleDumper, default_flow_style=True))
    assert data == data1  # UnsafeText should be represented as unicode
    assert data == data2  # UnsafeText should be represented as unicode
    assert isinstance(data1, text_type)  # data1 should be a unicode string
    assert isinstance(data2, text_type)  # data2 should be a unicode string

    # UnsafeBytes should be represented as binary, not
    # as a float or integer

# Generated at 2022-06-20 23:55:55.196690
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined('foo'))

# Generated at 2022-06-20 23:55:58.011770
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert represent_unicode(dumper, 'foo') == u'foo'
    assert represent_unicode(dumper, b'foo') == u'foo'

# Generated at 2022-06-20 23:55:59.638874
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    AnsibleDumper(sys.stdout, default_flow_style=False)

# Generated at 2022-06-20 23:56:07.376496
# Unit test for function represent_binary
def test_represent_binary():
    data = AnsibleUnsafeBytes(b'\xde\xad\xbe\xef')
    assert(yaml.dump(data, Dumper=AnsibleDumper).strip() == b'!binary |\n  3q2+7w==')

    data = AnsibleUnsafeBytes(b'\xde\xad\xbe\xef'*8)
    assert(yaml.dump(data, Dumper=AnsibleDumper).strip() == b'!binary |\n  3q2+7w==3q2+7w==3q2+7w==3q2+7w==3q2+7w==3q2+7w==3q2+7w==3q2+7w==')


# Generated at 2022-06-20 23:56:14.830747
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    dumper = AnsibleDumper()
    assert dumper.__class__.__name__ == 'AnsibleDumper'



# Generated at 2022-06-20 23:56:19.029677
# Unit test for function represent_binary
def test_represent_binary():
    assert AnsibleDumper.represent_binary(AnsibleDumper(), b'foo') == "!!binary |-\n  foo"
    assert AnsibleDumper.represent_binary(AnsibleDumper(), b'f' + b'\x00' + b'o') == "!!binary |-\n  f\x00o"

# Generated at 2022-06-20 23:56:23.537821
# Unit test for function represent_unicode
def test_represent_unicode():
    '''represent_unicode should return the unicode string'''

    unicode_object = ansible_unicode('de_DE')
    dumped_object = yaml.dump(unicode_object, Dumper=AnsibleDumper)

    assert dumped_object == 'de_DE\n...\n'



# Generated at 2022-06-20 23:56:25.995901
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert type(AnsibleDumper(sys.stdout)) is AnsibleDumper
    assert type(AnsibleDumper(sys.stdout).add_representer(AnsibleUnicode, represent_unicode)) is AnsibleDumper

# Generated at 2022-06-20 23:56:27.682681
# Unit test for function represent_undefined
def test_represent_undefined():
    # Here bool() will ensure _fail_with_undefined_error happens
    test_data = {'key': AnsibleUndefined}
    assert not(bool(test_data))



# Generated at 2022-06-20 23:56:37.991718
# Unit test for function represent_hostvars
def test_represent_hostvars():

    # Prepare hostvars
    hostvars = HostVars(host_vars_dict={'hostname': 'host', 'ip_address': '1.2.3.4', 'new_var': 'foo'})
    hostvars._add_host_vars_from_inventory(host_group_vars_dict={'hostgroup': 'group', 'ip_address': '1.2.3.5'})
    hostvars._add_host_vars_from_inventory(play_context_vars={'play': 'play', 'ip_address': '1.2.3.6'})
    hostvars._set_variable('ip_address', '1.2.3.7')
    hostvars._set_variable('hostname', 'host_override')

    # Represent hostvars

# Generated at 2022-06-20 23:56:43.537979
# Unit test for function represent_hostvars
def test_represent_hostvars():
    '''
    Look for the string "hostvars" in the output of represent_hostvars. This
    is the original test from ansible/utils/__init__.py. Security tests for
    represent_hostvars are below.
    '''
    h = HostVars({'foo': 'bar'})
    assert represent_hostvars(None, h).find(u'hostvars') > 0



# Generated at 2022-06-20 23:56:46.561701
# Unit test for function represent_undefined
def test_represent_undefined():
    try:
        AnsibleDumper.add_representer(
            AnsibleUndefined,
            yaml.representer.SafeRepresenter.represent_undefined,
        )
        assert False, "Expected exception, got none"
    except:
        pass

# Generated at 2022-06-20 23:56:52.671202
# Unit test for function represent_binary
def test_represent_binary():
    def returns_given_value(v):
        return v

    assert yaml.dump(binary_type('abc'), Dumper=AnsibleDumper, default_flow_style=False, default_style=None) == "!!binary \"YWJj\"\n"

    # Ensure that yaml.dumps without no_alias_dumper is not compatible with AnsibleDumper
    assert yaml.dump(binary_type('abc'), Dumper=AnsibleDumper, default_flow_style=False, default_style=None, no_alias_dumper=True) != "!!binary \"YWJj\"\n"



# Generated at 2022-06-20 23:57:03.201626
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    '''
    Tests ability to safely dump AnsibleVaultEncryptedUnicode.

    This unit test is a bit special in that it tests not only
    the ability of the YAML dumper to properly dump a
    AnsibleVaultEncryptedUnicode, but also the ability of the
    YAML loader to load the resultant data back in.  This unit
    test is thus more of an integration test than a unit test.
    '''
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    data = 'super test'
    password = 'super test password'

    cipher = VaultLib([password])
    ciphertext = cipher.encrypt(data)

    dumper = AnsibleDumper()
    dumped_data = dumper

# Generated at 2022-06-20 23:57:09.050909
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.dump(AnsibleUndefined())



# Generated at 2022-06-20 23:57:15.555613
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = AnsibleVaultEncryptedUnicode('!vault |$ANSIBLE_VAULT;1.1;AES256\r\nsome_ciphertext')
    data2 = AnsibleVaultEncryptedUnicode('some_ciphertext')
    assert data != data2

    dumper = AnsibleDumper(None, None)

    def _represent_scalar(tag, value, style=None):
        return {tag: value, 'style': style}

    dumper.represent_scalar = _represent_scalar

    result = dumper.represent_vault_encrypted_unicode(data)
    assert result == {'!vault': 'some_ciphertext', 'style': '|'}

    # This should fail because the data doesn't have a vault header
    import pytest

# Generated at 2022-06-20 23:57:24.958343
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.template import AnsibleTemplate
    from ansible.constants import DEFAULT_VAULT_ID_MATCH
    # For now only test the default vault id match
    t = AnsibleTemplate(b'{{ foo | to_nice_yaml }}', None, vault_password_file='/dev/null', vault_id_match=DEFAULT_VAULT_ID_MATCH)
    h = HostVars()
    h.set_variable('foo', 'bar')
    v = VaultLib(b'123456')

# Generated at 2022-06-20 23:57:28.998858
# Unit test for function represent_hostvars
def test_represent_hostvars():
    yaml.add_representer(HostVars, represent_hostvars)
    yaml.add_representer(HostVarsVars, represent_hostvars)
    yaml.add_representer(VarsWithSources, represent_hostvars)
    hostvars = HostVars(vars=dict(var1='somevalue', var2='{{var1}}'))
    out = yaml.dump(hostvars, default_flow_style=False)

    assert out == '''\
var1: somevalue
var2: '{{var1}}'
'''
    hostvars_vars = HostVarsVars(vars=dict(var1='somevalue', var2='{{var1}}'))
    out = yaml.dump(hostvars_vars, default_flow_style=False)

# Generated at 2022-06-20 23:57:31.214547
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper.represent_undefined(None, 'text') == True
    assert AnsibleDumper.represent_undefined(None, None) == False

# Generated at 2022-06-20 23:57:34.402287
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    assert dumper.represent_hostvars(HostVars({"foo":"bar"}, "path/to/file")) == dumper.represent_dict({"foo":"bar"})

# Generated at 2022-06-20 23:57:39.426993
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dict_obj = dict(a=1, b=2, c=3)
    hostvars = HostVars(hostvars=dict_obj)
    dumper = AnsibleDumper()

    result = dumper.represent_data(hostvars)
    expected = dumper.represent_dict(dict_obj)
    assert result == expected

# Generated at 2022-06-20 23:57:46.815333
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.template import Templar

    t = Templar()
    orig = {
        'user': 'apache',
        'group': 'apache',
        'uid': '42',
        'gid': '42',
    }
    wrapped = HostVars(t, orig)

    representer = AnsibleDumper()
    expected = yaml.representer.SafeRepresenter.represent_dict(representer, orig)
    result = representer.represent_hostvars(wrapped)

    assert result == expected

# Generated at 2022-06-20 23:57:49.766753
# Unit test for function represent_binary
def test_represent_binary():
    test_data = AnsibleUnsafeBytes('test')
    yaml_string = yaml.dump(test_data, Dumper=AnsibleDumper)
    assert yaml_string == b'test\n...\n'

# Generated at 2022-06-20 23:57:53.448239
# Unit test for function represent_binary
def test_represent_binary():
    """represent_binary should serialize data bytes to base64"""
    # given
    data = 'hello world'
    expected_result = "!!binary |\n  aGVsbG8gd29ybGQ=\n"
    # when
    result = yaml.dump(data, Dumper=AnsibleDumper)
    # then
    assert result == expected_result



# Generated at 2022-06-20 23:58:00.396507
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, AnsibleUnicode(u'hello')) == AnsibleUnicode('hello')

# Generated at 2022-06-20 23:58:10.316183
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert yaml.dump(dict(), Dumper=AnsibleDumper) == u'{}\n...\n'
    assert yaml.dump(dict(a=1), Dumper=AnsibleDumper) == u'{a: 1}\n...\n'
    assert yaml.dump(HostVars({}), Dumper=AnsibleDumper) == u'{}\n...\n'
    assert yaml.dump(HostVars({'a': 1}), Dumper=AnsibleDumper) == u'{a: 1}\n...\n'
    assert yaml.dump(HostVarsVars({'a': 1}), Dumper=AnsibleDumper) == u'{a: 1}\n...\n'

# Generated at 2022-06-20 23:58:16.345885
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper.ignore_aliases is yaml.dumper.SafeDumper.ignore_aliases

    assert AnsibleDumper(width=60, indent=2, default_style=None,
                         default_flow_style=False, canonical=False,
                         indentless=False, allow_unicode=True,
                         line_break='\n', encoding='utf-8',
                         explicit_start=False, explicit_end=False,
                         tags=None, sort_keys=True).ignore_aliases is yaml.dumper.SafeDumper.ignore_aliases

    assert AnsibleDumper().ignore_aliases is yaml.dumper.SafeDumper.ignore_aliases

    assert AnsibleDumper.ignore_aliases is yaml.dumper.SafeDumper.ignore_aliases

    # Dumping Jinja2.

# Generated at 2022-06-20 23:58:19.511122
# Unit test for function represent_undefined
def test_represent_undefined():
    text = yaml.dump(
        AnsibleUndefined(),
        Dumper=AnsibleDumper
    )
    assert text == 'False\n'



# Generated at 2022-06-20 23:58:22.356307
# Unit test for function represent_hostvars
def test_represent_hostvars():
    class A:
        pass

    a = A()
    setattr(a, 'data', dict(a=1))
    setattr(a, '_is_hostvars', True)
    data = yaml.dump(a, Dumper=AnsibleDumper)
    assert data == 'a: 1\n'

# Generated at 2022-06-20 23:58:23.738182
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined) == False



# Generated at 2022-06-20 23:58:28.594163
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper(width=10)
    assert "\n!vault |\n          $ANSIBLE_VAULT;1.2;AES256;super_secret\n          3639393939333333653237373836383065653337303165633464336134623563393063376\n          6365303433633166653432313437333035343066363839393531353237\n" == dumper.represent_vault_encrypted_unicode(
        AnsibleVaultEncryptedUnicode(u"9999936492786800ee3701ec4d3a4b63c0c7cce043c1ef4231473054f6899511277", "super_secret"))

# Generated at 2022-06-20 23:58:30.105330
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper(None), object)


# Unit tests for function represent_hostvars

# Generated at 2022-06-20 23:58:35.973770
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    data = {}
    stream = open('/etc/profile', 'w')

    dumper = AnsibleDumper(stream, default_flow_style=True)
    dumper.add_representer(HostVars, represent_hostvars)

    dumper.open()
    dumper.descend(data)
    dumper.represent(data)
    dumper.close()

    stream.close()



# Generated at 2022-06-20 23:58:46.058119
# Unit test for function represent_undefined

# Generated at 2022-06-20 23:58:54.811424
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    # Instantiate class
    dumper = AnsibleDumper()
    assert dumper is not None, 'Failed to instantiate AnsibleDumper'

# Generated at 2022-06-20 23:58:57.082229
# Unit test for function represent_binary
def test_represent_binary():
    assert AnsibleDumper().represent_binary(b'\x01\x02\x03\x04') == u'!!binary "\\x01020304"'

# Generated at 2022-06-20 23:58:59.321488
# Unit test for function represent_undefined
def test_represent_undefined():
    # Does not error out
    yaml.dump(AnsibleUndefined(), default_flow_style=True)

# Generated at 2022-06-20 23:59:03.900254
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_vault_encrypted_unicode(AnsibleVaultEncryptedUnicode(b'\x02\x02\x02\x03\x04\xff')) == "!vault |\n  BADc3NlcjEyMzRx\n"

# Generated at 2022-06-20 23:59:07.674272
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():

    aveu = AnsibleVaultEncryptedUnicode("test")

    assert represent_vault_encrypted_unicode(AnsibleDumper(None), aveu) == "!vault |\n          dGVzdA==\n"


# Generated at 2022-06-20 23:59:14.623470
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    test_text = "The quick brown fox jumped over the lazy dog\n"
    test_key = "The quick brown fox jumped over the lazy dog\n"
    test_vault = AnsibleVaultEncryptedUnicode(text=test_text, key=test_key)
    yaml_serialized = yaml.dump(test_vault, Dumper=AnsibleDumper)

# Generated at 2022-06-20 23:59:17.672135
# Unit test for function represent_binary
def test_represent_binary():
    data = AnsibleUnsafeBytes('spam')
    assert yaml.dump(data, Dumper=AnsibleDumper) == '!!binary |\n  c3BhbQ==\n'



# Generated at 2022-06-20 23:59:20.662197
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(AnsibleDumper, AnsibleUnicode('val')) == yaml.representer.SafeRepresenter.represent_str(AnsibleDumper, 'val')


# Generated at 2022-06-20 23:59:29.685538
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.vault import VaultLib

    test_value = {'version': 2, 'cipher': 'aes256', 'hmac': 'sha256', 'data': 'crCKjnI/NYiC/eZ/3qBdNz/sgosb9X0vf2bMHpePjBo='}
    vault_pwd = 'ansible'
    vault = VaultLib([vault_pwd])
    test_value = vault.decrypt(test_value)
    data = AnsibleVaultEncryptedUnicode(vault, vault_pwd, test_value)

    yaml.dump({'foo': data}, Dumper=AnsibleDumper, width=1000)

# Generated at 2022-06-20 23:59:34.247899
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    _test = { HostVars("host1"): { "foo": "bar" }, HostVars("host2"): { "baz": "quux" } }
    assert yaml.dump(_test, Dumper=AnsibleDumper) == "foo: bar\nbaz: quux\n"

# Generated at 2022-06-20 23:59:44.657053
# Unit test for function represent_hostvars
def test_represent_hostvars():
    import ansible.parsing.dataloader
    loader = ansible.parsing.dataloader.DataLoader()
    world = AnsibleSequence(loader.load_from_file("test/unit/test_utils.py", '', '', None))
    assert yaml.dump({'foo': world}, Dumper=AnsibleDumper) == 'foo: {__ansible_vars: !HostVars}\n'


# Generated at 2022-06-20 23:59:49.677715
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(AnsibleDumper, "text") == "text"
    assert represent_unicode(AnsibleDumper, "0x7") == "0x7"
    assert represent_unicode(AnsibleDumper, "0xAG") == "0xAG"
    assert represent_unicode(AnsibleDumper, "0xag") == "0xag"

# Generated at 2022-06-20 23:59:53.675045
# Unit test for function represent_binary
def test_represent_binary():
    data = dict(a=u'\U0001F4A9'.encode('utf-8'))
    encoded = yaml.dump(data, Dumper=AnsibleDumper)
    assert encoded == '{a: !!binary |\n' + '  wqXDk/8=\n'



# Generated at 2022-06-21 00:00:04.214419
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    '''yaml.dump did not take into account representers that were defined in AnsibleDumper
    '''
    from ansible.parsing import vault
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

# Generated at 2022-06-21 00:00:06.726478
# Unit test for function represent_binary
def test_represent_binary():
    represent_binary(AnsibleDumper, 'a')
    represent_binary(AnsibleDumper, 'a') == "!!binary 'YQ=='\n"

# Generated at 2022-06-21 00:00:12.657259
# Unit test for function represent_binary
def test_represent_binary():
    ''' yaml.representer.SafeRepresenter.represent_binary() '''

    # x = "abc" encoded to ASCII
    x = 'abc'

    # y = "abc" encoded to UTF-16
    y = '\xff\xfea\x00b\x00c\x00'

    s = represent_binary(AnsibleDumper, x)
    assert (s == '!!binary |-\n  YWJj\n')

    t = represent_binary(AnsibleDumper, y)
    assert (t == '!!binary |-\n  //8=\n')

# Generated at 2022-06-21 00:00:14.321847
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper.represent_undefined(AnsibleUndefined()) == True

# Generated at 2022-06-21 00:00:24.049170
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    dumper.ignore_aliases = lambda *args: True

    hostvars = HostVars()
    hostvars.add_host_vars({"a": "b", "c": "d"}, hostname="localhost")
    hostvars.add_host_vars({"a": "e", "x": "y"}, hostname="remotehost")

    assert yaml.dump(hostvars, Dumper=AnsibleDumper) == """
{a: b, c: d}
localhost:
  a: b
  c: d
remotehost:
  a: e
  x: y
""".lstrip()



# Generated at 2022-06-21 00:00:26.675716
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    data = AnsibleUnicode('someString')
    assert dumper.represent_unicode(data) == dumper.represent_str(text_type(data))

# Generated at 2022-06-21 00:00:33.961436
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():

    # Create a temporary dumper class (since we don't want to change
    # SafeDumper in the production code)
    class VaultEncryptedDumper(yaml.SafeDumper):
        def __init__(self):
            super(VaultEncryptedDumper, self).__init__()
            self.add_representer(AnsibleVaultEncryptedUnicode, represent_vault_encrypted_unicode)

    from ansible.parsing.vault import VaultLib
    cipher_text = VaultLib.encrypt('test')

    value = AnsibleVaultEncryptedUnicode(cipher_text)