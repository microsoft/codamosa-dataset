

# Generated at 2022-06-20 23:50:41.787106
# Unit test for function represent_undefined
def test_represent_undefined():
    assert not yaml.dump({'var': AnsibleUndefined()}, Dumper=AnsibleDumper)

# Generated at 2022-06-20 23:50:45.543908
# Unit test for function represent_binary
def test_represent_binary():
    result = yaml.dump(b'test_binary', Dumper=AnsibleDumper).strip()
    # Verify that the result is a base64 encoded string
    assert result.startswith("!ansible/binary |")
    assert result.endswith("=")

# Generated at 2022-06-20 23:50:46.703666
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    x = AnsibleDumper(None)


# Generated at 2022-06-20 23:50:48.850938
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    import sys
    d = AnsibleDumper(sys.stdout)
    assert isinstance(d, AnsibleDumper)

# Generated at 2022-06-20 23:50:51.967788
# Unit test for function represent_binary
def test_represent_binary():
    assert AnsibleDumper.represent_binary(None, b'foo\nbar') == u"!binary |-\n  Zm9vCmJhcg==\n"

# Generated at 2022-06-20 23:50:56.628875
# Unit test for function represent_undefined
def test_represent_undefined():
    fake_data = AnsibleUndefined()
    dumper = yaml.SafeDumper(indent=0, width=1000, allow_unicode=True)
    represented_data = dumper.represent_data(fake_data)
    result = yaml.dump([fake_data], Dumper=dumper, default_flow_style=False)
    assert b'!<!UNDEFINED> ' in result

# Generated at 2022-06-20 23:51:01.523690
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper.org_init == yaml.SafeDumper.__init__
    assert AnsibleDumper.org_represent_str == yaml.SafeDumper.represent_str
    assert AnsibleDumper.org_represent_unicode == yaml.representer.SafeRepresenter.represent_unicode



# Generated at 2022-06-20 23:51:11.461372
# Unit test for function represent_binary
def test_represent_binary():
    d = yaml.Dumper()
    d.represent_bin = represent_binary
    data = AnsibleUnsafeBytes(b'\x8a\xa9')
    assert d.represent_binary(data)

    d = yaml.Dumper()
    d.represent_bin = represent_binary
    data = AnsibleUnsafeBytes(bytes(b'\x8a\xa9'))
    assert d.represent_binary(data)

    d = yaml.Dumper()
    d.represent_bin = represent_binary
    data = AnsibleUnsafeBytes(b'\xa3\xb3')
    assert d.represent_binary(data)

    d = yaml.Dumper()
    d.represent_bin = represent_binary

# Generated at 2022-06-20 23:51:15.050983
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hvar = HostVars(hostvars=dict(a=1, b=2))
    assert yaml.dump(hvar, Dumper=AnsibleDumper) == '{a: 1, b: 2}'



# Generated at 2022-06-20 23:51:18.720330
# Unit test for function represent_unicode
def test_represent_unicode():
    data = u'{#foo}'
    dumped = yaml.dump(data, Dumper=AnsibleDumper)
    assert dumped == u'{#foo}\n'



# Generated at 2022-06-20 23:51:21.968400
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    d = AnsibleDumper()

# Generated at 2022-06-20 23:51:31.782075
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = HostVars()
    hostvars.add_host("host01", {"ansible_host":"host01.ansible.com"})
    hostvars.add_host("host02", {"ansible_host":"host02.ansible.com"})
    hostvars.add_host("host03", {"ansible_host":"host03.ansible.com"})
    hostvars_representation = represent_hostvars(AnsibleDumper, hostvars)
    assert hostvars_representation == yaml.representer.SafeRepresenter.represent_dict(AnsibleDumper, dict(hostvars))



# Generated at 2022-06-20 23:51:32.908008
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    a = AnsibleDumper



# Generated at 2022-06-20 23:51:35.215617
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    obj = AnsibleDumper(width=80)
    assert isinstance(obj, yaml.Dumper)

# Generated at 2022-06-20 23:51:43.246626
# Unit test for function represent_binary
def test_represent_binary():
    data = '\x80\x81\x82\x83'
    dumper = AnsibleDumper()

    # With repr_style set to 'bytes'
    assert dumper.represent_binary(data, style='|') == '|\n  gICAgICAg\n'

    # With repr_style set to 'str'
    assert dumper.represent_binary(data, style='"') == '"\\x80\\x81\\x82\\x83"\n'



# Generated at 2022-06-20 23:51:48.912959
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(u'foo', Dumper=AnsibleDumper).strip() == "foo"
    assert yaml.dump(u'foo\n', Dumper=AnsibleDumper).strip() == "|-\n  foo"
    assert yaml.dump(u'foo\\', Dumper=AnsibleDumper).strip() == "foo\\"
    assert yaml.dump(AnsibleUnsafeText('foo'), Dumper=AnsibleDumper).strip() == "foo"

# Generated at 2022-06-20 23:51:52.309146
# Unit test for function represent_binary
def test_represent_binary():
    data = {'bytes': b'hello'}
    assert yaml.load(yaml.dump(data, Dumper=AnsibleDumper), Loader=yaml.SafeLoader) == data



# Generated at 2022-06-20 23:52:02.799327
# Unit test for function represent_unicode
def test_represent_unicode():

    # Can't create new instance of representer class
    # so use existing SafeRepresenter
    representer = yaml.representer.SafeRepresenter()

    repr = represent_unicode(representer, u"abc")
    assert repr == representer.represent_str(u"abc")

    repr = represent_unicode(representer, u"0")
    assert repr == representer.represent_str(u"0")

    repr = represent_unicode(representer, u"")
    assert repr == representer.represent_str(u"")

    repr = represent_unicode(representer, u"\u0000")
    assert repr == representer.represent_str(u"\u0000")


# Generated at 2022-06-20 23:52:03.990314
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert isinstance(AnsibleDumper, type)

# Generated at 2022-06-20 23:52:13.013192
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # This is the test of the function, not of the function called by the function
    # So this is not a true unit test
    data = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;6.95;AES256\nblahblahblah', 'password')
    # This is a test of the function; mock is not used to test the function being mocked
    dumper = yaml.representer.SafeRepresenter.represent_unicode
    yaml.representer.SafeRepresenter.represent_unicode = represent_vault_encrypted_unicode
    with open('/tmp/test_represent_vault_encrypted_unicode.yml', 'w') as test_file:
        yaml.dump(data, test_file, Dumper=SafeDumper)

# Generated at 2022-06-20 23:52:21.661824
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(b'\xFF', Dumper=AnsibleDumper) == '!!binary |-\n  //8=\n'
    assert yaml.dump(chr(255), Dumper=AnsibleDumper) == '\uFFFD'



# Generated at 2022-06-20 23:52:31.908480
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # Test a normal dict
    data = dict(a=1, b=2, c=3)
    dumper = AnsibleDumper()
    result = dumper.represent_dict(dict(data))
    assert result == "a: 1\nb: 2\nc: 3\n"

    # Test a Hostvars instance
    hv = HostVars()
    hv.data = data
    dumper = AnsibleDumper()
    result = dumper.represent_dict(dict(hv))
    assert result == "a: 1\nb: 2\nc: 3\n"

    # Test an empty HostVars instance
    hv = HostVars()
    dumper = AnsibleDumper()
    result = dumper.represent_dict(dict(hv))
    assert result == ""



# Generated at 2022-06-20 23:52:37.395695
# Unit test for function represent_unicode
def test_represent_unicode():
    """
    Basic test of the represent_unicode function from the AnsibleDumper
    class.
    """
    from ansible.utils.unsafe_proxy import wrap_var

    a = wrap_var("foo")
    b = wrap_var("bar")

    result = AnsibleDumper.represent_unicode(AnsibleDumper, a)
    assert result == u"foo", "expected foo, got %s" % result

    result = AnsibleDumper.represent_unicode(AnsibleDumper, b)
    assert result == u"bar", "expected bar, got %s" % result



# Generated at 2022-06-20 23:52:39.544017
# Unit test for function represent_undefined
def test_represent_undefined():
    data = AnsibleUndefined
    output = AnsibleDumper.represent_undefined(data)
    assert output is False

# Generated at 2022-06-20 23:52:42.705380
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode(u'ansible'), default_flow_style=True, default_style=None, Dumper=AnsibleDumper) == u'ansible\n...\n'

# Generated at 2022-06-20 23:52:54.426201
# Unit test for function represent_undefined
def test_represent_undefined():

    # We need to install the dumper to get a more accurate test
    # since the yaml.load() uses the dumper.
    yaml.add_representer(AnsibleUndefined, represent_undefined, Dumper=AnsibleDumper)

    # If we define a variable that is really a StrictUndefined but looks
    # like a unicode string or number in the data structure, it should
    # fail.
    data = yaml.load("""
test1: "{{ variable1 }}"
test2: "{{ variable2 }}"
test3: {{ variable3 }}""")

    assert yaml.dump(data) == """\
test1: "{{ variable1 }}"
test2: "{{ variable2 }}"
test3: {{ variable3 }}\n"""


# Generated at 2022-06-20 23:53:05.765473
# Unit test for function represent_unicode
def test_represent_unicode():

    dumper = AnsibleDumper

    class Struct:
        def __init__(self, value):
            self.value = value

        def __getitem__(self, key):
            return self.value

    # Test with str
    value = 'apple'
    representation = represent_unicode(dumper, value)
    assert isinstance(representation, text_type)
    assert representation == value

    # Test with unicode
    value = u'apple'
    representation = represent_unicode(dumper, value)
    assert isinstance(representation, text_type)
    assert representation == value

    # Test with non-string
    value = Struct(u'apple')
    representation = represent_unicode(dumper, value)
    assert isinstance(representation, text_type)
    assert representation == 'apple'

    #

# Generated at 2022-06-20 23:53:16.889405
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    test_data = 'hello world'
    obj = AnsibleVaultEncryptedUnicode(test_data)

# Generated at 2022-06-20 23:53:26.905336
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper

    hostvars = HostVars({'foo': 'bar'})
    hostvarsvars = HostVarsVars('hostvars', parent_block=hostvars)
    varswithsources = VarsWithSources({'baz': 'test'})

    assert dumper.represent_hostvars(hostvars) == \
        dumper.represent_dict({'foo': 'bar'})

    assert dumper.represent_hostvars(hostvarsvars) == \
        dumper.represent_dict({'foo': 'bar'})

    assert dumper.represent_hostvars(varswithsources) == \
        dumper.represent_dict({'baz': 'test'})



# Generated at 2022-06-20 23:53:31.693355
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    data = AnsibleUndefined('foo')
    # process and comment from represent_undefined
    # Here bool will ensure _fail_with_undefined_error happens if the value
    # is Undefined.
    # This happens because Jinja sets __bool__ on StrictUndefined
    assert bool(data) == True
    result = dumper.represent_undefined(dumper, data)

# Generated at 2022-06-20 23:53:51.791936
# Unit test for function represent_binary
def test_represent_binary():

    from ansible.module_utils.common.yaml import AnsibleDumper, AnsibleSafeDumper

    data = b'#!bin\n\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\xff\xff'

    # test non-safe mode
    result = yaml.dump(data, Dumper=AnsibleDumper)
    assert result == u'\n!!binary |-\n  #!bin\\n\\x00\\x00\\x00\\x01\\x00\\x00\\x00\\x01\\x00\\x00\\x00\\x01\\x00\\x00\\xff\\xff\n'

    # test safe mode

# Generated at 2022-06-20 23:53:56.558834
# Unit test for function represent_binary
def test_represent_binary():
    # Test
    assert None == AnsibleDumper.represent_binary(None)

    # Test with '\n'
    from ansible.module_utils.six import PY3
    if PY3:
        assert '!binary\n\'\\n\'' == AnsibleDumper.represent_binary(b'\n')
    else:
        assert '!binary |-\n  \\n' == AnsibleDumper.represent_binary(b'\n')

# Generated at 2022-06-20 23:54:04.292487
# Unit test for function represent_hostvars
def test_represent_hostvars():
    h = HostVars()
    h["x"] = 4
    h["y"] = {"a": 2, "b": 3}
    h["z"] = [1, 2, "a"]
    result = yaml.dump(h, Dumper=AnsibleDumper, default_flow_style=False)
    expected_result = '''\
x: 4
y:
  a: 2
  b: 3
z:
  - 1
  - 2
  - a
'''
    assert result == expected_result



# Generated at 2022-06-20 23:54:05.310751
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert AnsibleDumper is not None

# Generated at 2022-06-20 23:54:16.875372
# Unit test for function represent_undefined
def test_represent_undefined():
    import sys
    import warnings

    from ansible.template import UndefinedError

    for stdout_setting in (False, True):
        for warning_setting in (False, True):
            for stdout_capture, stdout_restore in (
                (True, True),     # capture and restore stdout
                (True, False),    # capture stdout but don't restore
                (False, False)    # don't capture stdout or restore
            ):
                if stdout_capture:
                    out = sys.stdout
                    captured = None
                else:
                    captured = out = None


# Generated at 2022-06-20 23:54:20.515894
# Unit test for function represent_unicode
def test_represent_unicode():
    # Was crashing < 2.7.5 https://github.com/ansible/ansible/issues/12042
    dumper = AnsibleDumper()
    dumper.represent_unicode(u'\u2603')



# Generated at 2022-06-20 23:54:31.509228
# Unit test for function represent_undefined
def test_represent_undefined():
    # First test: Normal flow, will return True, the representer returns void
    class FakeRep(object):
        def represent_void(self):
            return

    fake_rep = FakeRep()
    yaml_result = represent_undefined(fake_rep, 'some_value')
    assert yaml_result
    assert not hasattr(fake_rep, '_fail_with_undefined_error')

    # Second test: _throw_error_if_undefined is set and the representer is void
    class FakeRep(object):
        pass

    fake_rep = FakeRep()
    fake_rep._throw_error_if_undefined = True
    yaml_result = represent_undefined(fake_rep, 'some_value')
    assert not yaml_result

# Generated at 2022-06-20 23:54:38.291439
# Unit test for function represent_binary
def test_represent_binary():
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    template = b'{{ansible_date_time.epoch}}'
    basedir = 'test/utils/template_replacement'
    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_loader(loader)
    variable_manager.extra_vars = {'ansible_date_time': {'epoch': b'\xc3\xb3\xc3\xb3'}}
    templar = Templar(loader=loader, variable_manager=variable_manager, fail_on_undefined=False)

# Generated at 2022-06-20 23:54:45.810548
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert represent_hostvars(AnsibleDumper, HostVars({'k1': 'v1'})) == '{k1: v1}\n'
    assert represent_hostvars(AnsibleDumper, VarsWithSources({'k1': 'v1'})) == '{k1: v1}\n'
    assert represent_hostvars(AnsibleDumper, HostVarsVars({'k1': 'v1'})) == '{k1: v1}\n'


# Generated at 2022-06-20 23:54:51.220261
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-20 23:55:12.091709
# Unit test for function represent_binary
def test_represent_binary():
    dumper = yaml.SafeDumper
    assert repr(dumper.represent_binary(dumper, b'\x01')) == repr(b'\x01')



# Generated at 2022-06-20 23:55:17.335314
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    class FakeData(object):
        _ciphertext = '$ANSIBLE_VAULT;1.1;AES256\n'
    x = AnsibleVaultEncryptedUnicode(FakeData())
    y = represent_vault_encrypted_unicode(AnsibleDumper(), x)
    assert y == '!vault |\n  $ANSIBLE_VAULT;1.1;AES256\n'

# Generated at 2022-06-20 23:55:24.100657
# Unit test for function represent_binary
def test_represent_binary():
    # FIXME: This is a minimal test. Better tests would be nice...
    dumper = AnsibleDumper([])
    assert (
        dumper.represent_binary(b'\x00\x01\x02\x03') ==
        yaml.representer.SafeRepresenter.represent_binary(dumper, b'\x00\x01\x02\x03')
    )
    assert (
        dumper.represent_binary(b'\\x00\\x01\\x02\\x03') ==
        yaml.representer.SafeRepresenter.represent_binary(dumper, b'\\x00\\x01\\x02\\x03')
    )

# Generated at 2022-06-20 23:55:35.116491
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

# Generated at 2022-06-20 23:55:37.363956
# Unit test for function represent_undefined
def test_represent_undefined():
    import yaml
    yaml.safe_dump(AnsibleUndefined, default_flow_style=False)

# Generated at 2022-06-20 23:55:45.223785
# Unit test for function represent_binary
def test_represent_binary():
    import datetime
    from .yaml_loader import AnsibleUnsafeLoader

    data = dict(a=1, b=2, c=[1, 2, 3, 4, 5], d=dict(a=True, b=False, c='a value'), e=datetime.datetime(2017, 1, 12, 12, 41))
    data['f'] = binary_type(b'\xe2\x98\x83')

    dumped = yaml.dump(data, default_flow_style=False, Dumper=AnsibleDumper)
    assert dumped.count(b'"') == 3

    loaded = yaml.load(dumped, Loader=AnsibleUnsafeLoader)
    assert len(loaded) == 6
    assert isinstance(loaded['f'], AnsibleUnsafeBytes)

# Generated at 2022-06-20 23:55:46.174698
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    assert(AnsibleDumper is not None)

# Generated at 2022-06-20 23:55:52.664056
# Unit test for function represent_hostvars
def test_represent_hostvars():
    yaml.SafeDumper.add_representer(HostVars, represent_hostvars)
    yaml.SafeDumper.add_representer(HostVarsVars, represent_hostvars)
    hostvars = HostVars({"foo": "bar"})
    assert yaml.dump({'hostvars': hostvars}) == u'hostvars: {foo: bar}\n'



# Generated at 2022-06-20 23:55:57.593721
# Unit test for function represent_binary
def test_represent_binary():
    data = {b'foo': b'bar'}
    expected = u"!python/object/apply:dict\n- - !python/binary | dmFv\n  - !python/binary | dmFy"
    actual = yaml.dump(data, Dumper=AnsibleDumper, default_flow_style=False)
    assert actual == expected


# Generated at 2022-06-20 23:55:59.202216
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    assert represent_vault_encrypted_unicode(None, None) is None

# Generated at 2022-06-20 23:56:36.909487
# Unit test for constructor of class AnsibleDumper
def test_AnsibleDumper():
    yaml.dump('test', Dumper=AnsibleDumper)

# Generated at 2022-06-20 23:56:46.600849
# Unit test for function represent_unicode
def test_represent_unicode():
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.parsing.yaml.objects import AnsibleUnicode

    assert yaml.dump(wrap_var(1)) == u'!!python/object/apply:int [ 1 ]\n'

    # Following are for types which represent_unicode would apply
    obj = AnsibleUnicode('1')
    assert yaml.dump(obj) == u'1\n...\n'

    obj = AnsibleUnsafeText('1')
    assert yaml.dump(obj) == u'1\n...\n'

    obj = AnsibleUnsafeBytes('1')

# Generated at 2022-06-20 23:56:49.087594
# Unit test for function represent_binary
def test_represent_binary():

    data = b'test'
    d = AnsibleDumper(width=20)

    result = d.represent_binary(data)

    assert result == '!!binary |-\n  dGVzdA=='

# Generated at 2022-06-20 23:56:51.664356
# Unit test for function represent_unicode
def test_represent_unicode():
    data = {u'a': u'\u03ba'}
    output = yaml.dump(data, Dumper=AnsibleDumper)
    assert output == u'{a: "\\u03ba"}\n'



# Generated at 2022-06-20 23:56:54.864267
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    dumper.add_representer(
        AnsibleUnsafeBytes,
        represent_binary,
    )
    output = yaml.dump(dict(test_strings=[AnsibleUnsafeBytes(b"abc"), AnsibleUnsafeBytes(b"abc")]), Dumper=dumper)
    assert output == "test_strings:\n- !!binary abc\n- !!binary abc\n"

# Generated at 2022-06-20 23:56:57.863833
# Unit test for function represent_undefined
def test_represent_undefined():
    '''
    We want this to return False
    '''
    assert AnsibleDumper.represent_undefined(AnsibleDumper, AnsibleUndefined()) is False

# Generated at 2022-06-20 23:57:02.634761
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()
    data = AnsibleVaultEncryptedUnicode('0.0.0.')
    assert dumper.represent_scalar(u'!vault', data._ciphertext.decode(), style='|') == '!vault |\n  AAAAAAQAAAAAAAAAAAAAAAAAAAAAA\n'

# Generated at 2022-06-20 23:57:06.949093
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = {'var1': 'var1_value', 'var2': 'var2_value'}
    hostvars = HostVars(data)
    assert represent_hostvars(AnsibleDumper(), hostvars) == yaml.representer.SafeRepresenter.represent_dict(AnsibleDumper(), data)



# Generated at 2022-06-20 23:57:09.285795
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper([])
    data = b'foo'
    result = represent_binary(dumper, data)
    assert result == '!!binary:Zm9v'

# Generated at 2022-06-20 23:57:13.477236
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    ciphertext = '[__vault-encrypted__]'
    data = AnsibleVaultEncryptedUnicode(ciphertext)
    representer = AnsibleDumper()
    expected_result = '!vault |\n          {}\n'.format(ciphertext)
    actual_result = representer.represent_scalar(u'!vault', data._ciphertext.decode(), style='|')
    assert actual_result == expected_result

# Generated at 2022-06-20 23:58:34.819268
# Unit test for function represent_undefined
def test_represent_undefined():
    dummy_data = AnsibleUndefined
    assert AnsibleDumper.represent_undefined(AnsibleDumper, dummy_data)

# Generated at 2022-06-20 23:58:36.712525
# Unit test for function represent_hostvars
def test_represent_hostvars():
    d = yaml.dump(HostVars('localhost', {'a': 1}))
    assert d == "a: 1\n"


# Generated at 2022-06-20 23:58:41.132657
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper(indent=0)
    assert dumper.represent_binary(b'foo') == u'!binary |\n  Zm9v'
    assert dumper.represent_binary(b'foo bar') == u'!binary |\n  Zm9vIGJhcg=='



# Generated at 2022-06-20 23:58:50.121095
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, u'test') == yaml.representer.SafeRepresenter.represent_str(None, u'test')
    assert represent_unicode(None, u'\u03d3') == yaml.representer.SafeRepresenter.represent_str(None, u'\u03d3')
    assert represent_unicode(None, u'\u03d4') == yaml.representer.SafeRepresenter.represent_str(None, u'\u03d4')
    assert represent_unicode(None, u'\u03d5') == yaml.representer.SafeRepresenter.represent_str(None, u'\u03d5')

# Generated at 2022-06-20 23:58:52.027638
# Unit test for function represent_undefined
def test_represent_undefined():
    data = AnsibleUndefined(AnsibleUndefined.NO_VALUE)
    dumper = AnsibleDumper()
    result = dumper.represent_undefined(data)
    assert result == repr(data)

# Generated at 2022-06-20 23:59:02.069347
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = AnsibleVaultEncryptedUnicode('test')

# Generated at 2022-06-20 23:59:08.133478
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    result = dumper.represent_data(u"A unicode string")
    assert result.startswith(u'!ansible_safe "')
    assert result.endswith(u'"')
    # Ensure that the unicode string is not converted to a string
    assert isinstance(result, unicode)


if __name__ == "__main__":
    test_represent_unicode()

# Generated at 2022-06-20 23:59:10.670762
# Unit test for function represent_undefined
def test_represent_undefined():
    data = yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper)
    assert data == "\n"
    data = yaml.safe_load(data)
    assert data is False

# Generated at 2022-06-20 23:59:17.622013
# Unit test for function represent_unicode
def test_represent_unicode():
    from ansible.utils.unicode import to_bytes

    x = yaml.dump([u'\xfc'], Dumper=AnsibleDumper)
    # print(repr(x))
    assert to_bytes(x) == b"- !!python/unicode \"\\u00fc\"\n"

    x = yaml.dump([u'foo'], Dumper=AnsibleDumper)
    # print(repr(x))
    assert to_bytes(x) == b"- !!python/unicode \"foo\"\n"


# Generated at 2022-06-20 23:59:20.252645
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert yaml.dump(HostVars(dict(foo=1)), Dumper=AnsibleDumper) == '{foo: 1}\n...\n'
