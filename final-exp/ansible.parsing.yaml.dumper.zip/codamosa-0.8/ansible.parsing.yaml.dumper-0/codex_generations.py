

# Generated at 2022-06-22 13:51:03.517783
# Unit test for function represent_hostvars
def test_represent_hostvars():
    represent_hostvars(AnsibleDumper, HostVars({'var1': 'value1', 'var2': 'value2'}))


# Generated at 2022-06-22 13:51:07.930204
# Unit test for function represent_binary
def test_represent_binary():
    import random
    for i in range(100):
        byte_array = bytes(bytearray([random.randint(0, 255) for _ in range(random.randint(1, 10))]))
        assert yaml.dump(byte_array, Dumper=AnsibleDumper) == yaml.dump(binary_type(byte_array), default_flow_style=False, Dumper=yaml.representer.SafeRepresenter)



# Generated at 2022-06-22 13:51:14.775543
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    unicode_str = u'\u263a \U0001f602'
    expected_result = u"!!python/unicode '☺ \\U0001f602'"
    result = dumper.represent_unicode(dumper, unicode_str)
    assert result == expected_result, "Expected result does not match with actual: %s" % result


# Generated at 2022-06-22 13:51:26.178264
# Unit test for function represent_unicode
def test_represent_unicode():
    class TestAnsibleDumper(AnsibleDumper):
        def represent_unicode(self, data):
            '''
            Represent an AnsibleUnicode object
            '''
            return self.represent_scalar(u'tag:yaml.org,2002:str', unicode(data), style='"')

    test_dumper = TestAnsibleDumper()
    test_dumper.add_representer(AnsibleUnicode, test_dumper.represent_unicode)
    test_data = {u'unicode': AnsibleUnicode(u'unicode object')}
    result = yaml.dump(test_data, test_dumper)
    assert result == u'unicode: unicode object\n'

# Generated at 2022-06-22 13:51:27.808965
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(binary_type('hello'), Dumper=AnsibleDumper) != ''


# Generated at 2022-06-22 13:51:31.524426
# Unit test for function represent_binary
def test_represent_binary():

    # Test represent_binary()
    assert yaml.representer.SafeRepresenter.represent_binary(None, 'a\n\x00c') == \
        u'!!binary |\n  YQBjAGMA\n'

# Generated at 2022-06-22 13:51:35.696990
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = HostVars()

    hostvars["foo"] = "bar"
    hostvars["baz"] = "qux"

    assert yaml.dump(hostvars, Dumper=AnsibleDumper) == ("---\n" "foo: bar\n" "baz: qux\n")



# Generated at 2022-06-22 13:51:47.640240
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 13:51:50.334839
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    result = dumper.represent_hostvars(HostVars())
    assert result == '{}\n...\n'



# Generated at 2022-06-22 13:51:54.152718
# Unit test for function represent_binary
def test_represent_binary():
    from ansible.module_utils.compat import binary_type
    assert yaml.safe_dump(binary_type(b'foo'), Dumper=AnsibleDumper) == "!!binary |\n  Zm9v\n"



# Generated at 2022-06-22 13:51:59.544766
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper(width=100)
    result = dumper.represent_scalar('tag:yaml.org,2002:bool', False)
    assert result == 'false\n'

# Generated at 2022-06-22 13:52:11.032811
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dump = AnsibleDumper()
    data = AnsibleVaultEncryptedUnicode("vault_password_file", b"my_encrypted_text")
    output = dump.represent_vault_encrypted_unicode(data)

# Generated at 2022-06-22 13:52:15.054320
# Unit test for function represent_unicode
def test_represent_unicode():
    yaml.dump(AnsibleUnicode(u'foobar'), AnsibleDumper)
    yaml.dump(AnsibleUnsafeText(u'foobar'), AnsibleDumper)

# Generated at 2022-06-22 13:52:17.720773
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_data(AnsibleUndefined()) is yaml.representer.SafeRepresenter.represent_undefined(dumper, None)

# Generated at 2022-06-22 13:52:22.362329
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = AnsibleVaultEncryptedUnicode(u'foo')
    dumper = yaml.SafeDumper
    result = represent_vault_encrypted_unicode(dumper, data)
    assert result == u'!vault |\n  foo'



# Generated at 2022-06-22 13:52:28.384994
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.manager import VariableManager

    test_vars = {}
    test_vars['foo'] = {'test1': 'test2'}

    hvars = HostVars(test_vars)
    test_vm = VariableManager()
    test_vm.extra_vars['hvars'] = hvars

    # Return the whole object
    expected = {'hvars': {'foo': {'test1': 'test2'}}}
    output = yaml.dump(test_vm, Dumper=AnsibleDumper)
    assert output == yaml.dump(expected, Dumper=AnsibleDumper)


# Generated at 2022-06-22 13:52:36.868762
# Unit test for function represent_unicode
def test_represent_unicode():
    def assert_reps_equal(s):
        assert yaml.dump(s, Dumper=AnsibleDumper) == yaml.dump(text_type(s), Dumper=AnsibleDumper)

    assert_reps_equal(u'Árvíztűrő tükörfúrógép')
    assert_reps_equal(u'\u0BB5\u0BC6\u0BB3\u0BBF')
    assert_reps_equal(u'\u263a')



# Generated at 2022-06-22 13:52:48.987614
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVars, HostVarsVars
    from ansible.template import AnsibleUndefined

# Generated at 2022-06-22 13:52:53.499145
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    data = bytearray(b'some binary data: \x00\x01')
    assert dumper.represent_binary(dumper, data) == yaml.representer.SafeDumper.represent_binary(dumper, data)

# Generated at 2022-06-22 13:53:04.198513
# Unit test for function represent_undefined
def test_represent_undefined():
    '''
    Ensure the (bool) test in represent_undefined is functional
    '''
    u = AnsibleUndefined
    # Test 0 (pass)
    try:
        AnsibleDumper.add_representer(AnsibleUndefined, represent_undefined)
        y = yaml.dump(u, Dumper=AnsibleDumper)
    except:
        raise AssertionError('Test 0 Failed')

    # Test 1 (fail - bad test)
    AnsibleDumper.add_representer(AnsibleUndefined, represent_undefined)
    try:
        y = yaml.dump(u, Dumper=AnsibleDumper)
        raise AssertionError('Test 1 Failed')
    except AnsibleUndefined as e:
        pass

# Generated at 2022-06-22 13:53:19.127980
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-22 13:53:31.744719
# Unit test for function represent_unicode
def test_represent_unicode():
    representer = AnsibleDumper()
    
    data = AnsibleUnicode('foo')
    answer = representer.represent_unicode(data)
    assert answer == 'foo'

    data = AnsibleUnsafeText('foo')
    answer = representer.represent_unicode(data)
    assert answer == 'foo'

    data = AnsibleUnsafeBytes('foo')
    answer = representer.represent_binary(data)
    assert answer == b'foo'

    data = HostVars(foo='bar')
    answer = representer.represent_hostvars(data)
    assert answer == dict(data)

    data = AnsibleSequence([1, 2, 3, 4, 5])
    answer = representer.represent_list(data)
    assert answer == [1, 2, 3, 4, 5]

   

# Generated at 2022-06-22 13:53:36.185500
# Unit test for function represent_unicode
def test_represent_unicode():
    yaml.add_representer(AnsibleUnicode, represent_unicode, Dumper=yaml.SafeDumper)
    yaml.dump(u'abc', default_flow_style=False)
    yaml.add_representer(AnsibleUnicode, None, Dumper=yaml.SafeDumper)



# Generated at 2022-06-22 13:53:41.198066
# Unit test for function represent_undefined
def test_represent_undefined():
    obj = AnsibleUndefined('foo')
    try:
        AnsibleDumper.represent_undefined(AnsibleDumper, obj)
    except yaml.representer.RepresenterError as e:
        msg = yaml.representer.RepresenterError.__str__(e)
        assert msg == "'foo' is undefined"

# Generated at 2022-06-22 13:53:52.234524
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Default
    data = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\r\n3635373837333632326537666665356663636136613332653635383465386332623162356362373\r\n61376264376235366130643938396464636364313766386439366337373262396232326635643665\r\n6634363538326136333061316635666231643339323064373464323833633235373639\r\n')

# Generated at 2022-06-22 13:54:02.510990
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import AnsibleUndefined
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    v = VariableManager()
    v.set_fact('var', AnsibleUndefined, use_cache=False)
    v.set_fact('var2', AnsibleUnsafeText(AnsibleUndefined), use_cache=False)

    assert yaml.dump({'a': v.get_fact('var'), 'b': v.get_fact('var2')}, Dumper=AnsibleDumper) == ("{a: '{{undefined_variable}}', b: '{{undefined_variable}}'}\n")

# Generated at 2022-06-22 13:54:11.956855
# Unit test for function represent_undefined
def test_represent_undefined():
    rep = AnsibleDumper()
    data = AnsibleUndefined

    # Represent should be false (even though AnsibleUndefined is True in
    # boolean sense) and should except
    # For example, when parsing like below:
    #   def foo():
    #       var = {}
    #       var['x']|bool
    #   end
    # `var['x']` should be represent as False, and not raise Exception
    assert rep.represent_undefined(data) is False

    # This should except
    #   var = {}
    #   var['x']
    try:
        rep.represent_undefined(data, event=None)
        assert False
    except AnsibleUndefined as e:
        assert isinstance(e, AnsibleUndefined)



# Generated at 2022-06-22 13:54:18.362293
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # Create data for test
    hv = HostVars()
    vars_dict = {'var_one': 'A', 'var_two': 'B'}
    hv._data = vars_dict

    # Create the dumper
    dumper = AnsibleDumper()

    # Call function
    my_rep = represent_hostvars(dumper, hv)

    # Check for result
    expected_rep = dumper.represent_dict(vars_dict)
    assert my_rep == expected_rep



# Generated at 2022-06-22 13:54:20.726375
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper
    hvars = HostVars(hostname='testhost')
    hvars._variable_manager = 'test manager'
    hvars.hostvars = {'some_key': 'some value'}
    assert dumper.represent_hostvars(dumper, hvars) == dumper.represent_dict(dumper, hvars.hostvars)


# Generated at 2022-06-22 13:54:22.149448
# Unit test for function represent_unicode
def test_represent_unicode():
    data = u'fake data'
    d = yaml.dump(data, Dumper=AnsibleDumper, encoding=None)
    assert u"!!python/unicode 'fake data'" in d


# Generated at 2022-06-22 13:54:33.154528
# Unit test for function represent_unicode
def test_represent_unicode():
    """
    Ensure AnsibleUnicode and str are properly represented by
    represent_unicode().
    """
    if hasattr(yaml, 'CSafeDumper'):
        dumper = yaml.CSafeDumper
    else:
        dumper = yaml.SafeDumper

    s = "Simple string"
    assert represent_unicode(dumper, s) == yaml.representer.SafeRepresenter.represent_str(dumper, s)

    u = AnsibleUnicode(s)
    assert represent_unicode(dumper, u) == yaml.representer.SafeRepresenter.represent_unicode(dumper, text_type(u))

# Generated at 2022-06-22 13:54:43.080643
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    uni_str1 = AnsibleVaultEncryptedUnicode()
    uni_str1._ciphertext = b'$ANSIBLE_VAULT;1.2;AES256;test_host\r\ntest_user\r\ntest_pass\r\n'
    uni_str2 = AnsibleVaultEncryptedUnicode()
    uni_str2._ciphertext = 'test'
    res1 = represent_vault_encrypted_unicode(None, uni_str1)
    res2 = represent_vault_encrypted_unicode(None, uni_str2)
    assert res1 == res2

# Generated at 2022-06-22 13:54:50.361058
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, AnsibleUnicode(u'foo')) == yaml.representer.SafeRepresenter.represent_str(None, u'foo')
    assert repr(represent_unicode(None, AnsibleUnicode(u'foo'))) == repr(yaml.representer.SafeRepresenter.represent_str(None, u'foo'))

# Generated at 2022-06-22 13:54:52.974157
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper['tagged_binary']
    data = b'\x00\r\n'
    assert dumper.represent_binary(data) == "!binary \"AA0NCg==\"\n"

# Generated at 2022-06-22 13:55:02.186653
# Unit test for function represent_undefined
def test_represent_undefined():
    from io import StringIO
    from ansible.template import Undefined

    # We can only test the output for the case where we dump
    # a variable that is undefined to a YAML file, but we need
    # to make sure we don't get an error from dump, and we need
    # to make sure the variable is represented in the output
    # as an empty string (i.e. it exists, so that the variable
    # appears in the file, with a value of "").

    # Unit tests are limited to YAML 1.1 and earlier
    if yaml.__version__.startswith('1.2'):
        yaml_version = '1.1'
    else:
        yaml_version = '1.0'

    yaml_str = '''
var1:
'''


# Generated at 2022-06-22 13:55:11.924237
# Unit test for function represent_binary
def test_represent_binary():
    test_string = 'gAAAAABZvhjKHn-wQdK2ZoRYP-kCn7aKnljXtYyae_faPNlA1Bjqw4sC4pZ-nB_DxoaAjP9XSXeozT1TASI2q3s_z0s4pI4Jx76lDgHcVAXB-S-0yTmTQTKzwZdsyNtNzOZOKA'
    yaml_data = '!!binary |\n'
    yaml_data += '  ' + test_string
    yaml_out = yaml.dump(test_string, AnsibleDumper)
    assert yaml_out == yaml_data

# Generated at 2022-06-22 13:55:14.631778
# Unit test for function represent_undefined
def test_represent_undefined():
    d = AnsibleDumper()
    assert d.represent_data(AnsibleUndefined) == 'null\n...\n'

# Generated at 2022-06-22 13:55:19.191455
# Unit test for function represent_binary
def test_represent_binary():
    assert b'\x00\x01\x02\x03\x04\x05\x06\x07' == binary_type(yaml.load(yaml.dump(b'\x00\x01\x02\x03\x04\x05\x06\x07')))

# Generated at 2022-06-22 13:55:21.572449
# Unit test for function represent_undefined
def test_represent_undefined():
    # Test if undefined is returned with full_traceback
    yaml.dump([AnsibleUndefined('foo')], Dumper=AnsibleDumper)



# Generated at 2022-06-22 13:55:25.508308
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import AnsibleUndefined
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = AnsibleUndefined('test_represent_undefined')
    try:
        AnsibleLoader(data).get_single_data()
        # Should have thrown an exception
        assert False
    except yaml.YAMLError:
        assert True

# Generated at 2022-06-22 13:55:34.151598
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined)

# Generated at 2022-06-22 13:55:37.833779
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hv = HostVars()
    hv['foo'] = 'bar'
    assert yaml.dump({'foo': 'bar'}, Dumper=AnsibleDumper) == yaml.dump(hv, Dumper=AnsibleDumper)



# Generated at 2022-06-22 13:55:49.707119
# Unit test for function represent_unicode
def test_represent_unicode():

    # Test with ansible_unicode
    data = AnsibleUnicode('foo')
    text_type_data = 'foo'
    output = yaml.dump([data], Dumper=AnsibleDumper)
    expected_output = "- foo\n"
    assert output == expected_output

    # Test with ansible_unsafe_text
    data = AnsibleUnsafeText('foo')
    text_type_data = 'foo'
    output = yaml.dump([data], Dumper=AnsibleDumper)
    expected_output = "- foo\n"
    assert output == expected_output

    # Test with ansible_unsafe_bytes
    data = AnsibleUnsafeBytes('foo')
    text_type_data = 'foo'

# Generated at 2022-06-22 13:55:58.227462
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-22 13:56:05.291569
# Unit test for function represent_binary
def test_represent_binary():
    unsafe_str_to_test = 'test string åéîøü'
    ansible_bytes_obj = AnsibleUnsafeBytes(unsafe_str_to_test.encode())
    yaml_output = yaml.dump(ansible_bytes_obj, Dumper=AnsibleDumper)
    assert yaml_output == u"!!binary |\n  dGVzdCBzdHJpbmcgw6nDqSDDqcOt\n"

# Generated at 2022-06-22 13:56:12.682944
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u"Foo") == u"Foo\n"
    assert dumper.represent_unicode(u"False") == u"False\n"
    assert dumper.represent_unicode(u"True") == u"True\n"
    assert dumper.represent_unicode(u"None") == u"None\n"

    # will not be quoted
    assert dumper.represent_unicode(u"2014") == u"2014\n"

    # will be represent as string
    assert dumper.represent_unicode(u"2014.12") == u"2014.12\n"
    assert dumper.represent_unicode(u"2014.12.12") == u"2014.12.12\n"

    # will be quoted


# Generated at 2022-06-22 13:56:20.887519
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('secretpassword')
    ciphertext = vault.encrypt(b'data')

# Generated at 2022-06-22 13:56:30.065116
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import modified_unsafe_proxy
    dumper = AnsibleDumper
    # Here we assume represent_undefined(dumper, AnsibleUndefined('foo')) == True
    assert dumper.represent_undefined(AnsibleUndefined('foo')) == True

    # Simulate using older (less secure) ansible-2.5 pyyaml with ansible 2.6 or newer
    # (no bool() on undefined)
    # This is unstable, as the following code is not supported in ansible 2.5
    # see https://github.com/ansible/ansible/issues/52253
    if hasattr(modified_unsafe_proxy, '__bool__'):
        assert bool(AnsibleUndefined('foo')) == True
    # Else: (again for one of the older ansible-2.5

# Generated at 2022-06-22 13:56:34.152360
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()
    output = represent_vault_encrypted_unicode(dumper, AnsibleVaultEncryptedUnicode('\n'))
    # Old versions of ansible and yaml use === instead of |+ (in 1.2.x)
    assert output in (u'!vault |\n          \n', u'!vault |+\n          \n', u'!vault ===\n          \n')



# Generated at 2022-06-22 13:56:46.123223
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_data(u'abc') == u'abc\n...\n'
    assert dumper.represent_data(u'abc\n') == u"'abc\\n'\n"
    assert dumper.represent_data(u'abc\n\n') == u"'abc\\n\\n'\n"
    assert dumper.represent_data(u'abc\n\n\n') == u"'abc\\n\\n\\n'\n"
    assert dumper.represent_data(u'a\u0394\u03a3\u03a3\u0395') == u"'a\\u0394\\u03a3\\u03a3\\u0395'\n"

# Generated at 2022-06-22 13:57:08.876313
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02') == "!!binary |\n  AAEC\n"
    assert dumper.represent_binary(b'\x00\x01\x02', flow_style=True) == "!!binary \"AAEC\""
    assert dumper.represent_binary(b'\x00\x01\x02', style='>') == "!!binary >\n  AAEC\n"



# Generated at 2022-06-22 13:57:15.505638
# Unit test for function represent_hostvars
def test_represent_hostvars():
    '''
    Unit test for the function `represent_hostvars`

    :returns: success
    '''
    hostvars = HostVars(vars=dict(a=dict(b=1, c=2)))
    func = AnsibleDumper.representers[HostVarsVars]
    result = func(AnsibleDumper, hostvars)
    assert result == "a:\n  b: 1\n  c: 2\n"

    hostvars = HostVars(vars=dict(a=dict(b=1, c=2), d=3))
    func = AnsibleDumper.representers[HostVarsVars]
    result = func(AnsibleDumper, hostvars)

# Generated at 2022-06-22 13:57:19.157075
# Unit test for function represent_binary
def test_represent_binary():
    # repr() returns "b'...'"
    assert repr(yaml.dump(b'test123').encode()) == repr(yaml.dump(binary_type(b'test123')).encode())

# Generated at 2022-06-22 13:57:20.769215
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    assert represent_vault_encrypted_unicode(None, 'foo') == '!vault |\n          foo\n'

# Generated at 2022-06-22 13:57:28.463236
# Unit test for function represent_binary
def test_represent_binary():
    from ansible.module_utils.common.yaml import AnsibleDumper

    assert b'!binary |\n  AQIDBAUGBwgJCgsMDQ4P\n' == yaml.dump(b'\x01\x02\x03\x04\x05\x06\x07\x08', Dumper=AnsibleDumper, default_flow_style=False)
    assert b"'''\n\\x01\\x02\\x03\\x04\\x05\\x06\\x07\\x08\n'''" == yaml.dump(b'\x01\x02\x03\x04\x05\x06\x07\x08', Dumper=AnsibleDumper, default_flow_style=False, line_break='\n')

# Generated at 2022-06-22 13:57:33.279593
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = HostVars({u"abc": u"123", u"def": 456})
    s = yaml.safe_dump(data, default_flow_style=False, default_style=None, Dumper=AnsibleDumper)
    yaml_ans = '''abc: 123
def: 456
'''
    assert s == yaml_ans



# Generated at 2022-06-22 13:57:38.148482
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()
    data = 'test'
    encrypted_data = AnsibleVaultEncryptedUnicode(data)
    assert dumper.represent_scalar(u'!vault', data, style='|') == dumper.represent_vault_encrypted_unicode(encrypted_data)

# Generated at 2022-06-22 13:57:47.763174
# Unit test for function represent_unicode
def test_represent_unicode():
    obj = ''
    obj += chr(7)
    obj += chr(9)
    obj += chr(10)
    obj += chr(12)
    obj += chr(13)
    obj += chr(27)
    obj += chr(32)
    obj += chr(33)
    obj += chr(35)
    obj += chr(39)
    obj += chr(42)
    obj += chr(45)
    obj += chr(60)
    obj += chr(61)
    obj += chr(62)
    obj += chr(63)
    obj += chr(64)
    obj += chr(91)
    obj += chr(92)
    obj += chr(93)
    obj += chr(94)
    obj += chr

# Generated at 2022-06-22 13:57:53.762695
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Following string is 1234567890123456 in plain text
    ciphertext = '$ANSIBLE_VAULT;1.1;AES256\n3830326333383132656635306338323233353931316532653638323563396133386166643762633864\n3232386163366632366564376261626530653766343739643632303337303662303935373963356262\n6664376266656239376638383438393435396164326530356161376531333164653831616237326331\n656631646132313961333266343538643839656430353464\n'
    value = AnsibleVaultEncryptedUnicode(ciphertext)

    output

# Generated at 2022-06-22 13:57:59.141323
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper(default_flow_style=False)
    assert dumper.represent_vault_encrypted_unicode(AnsibleVaultEncryptedUnicode('AES256', 'foo')) == ('!vault |\n'
                                                                                                       '          $ANSIBLE_VAULT;1.1;AES256\n'
                                                                                                       '          666f6f0a\n')

# Generated at 2022-06-22 13:58:35.867376
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    ciphertext = vault.encrypt('test')
    data = AnsibleVaultEncryptedUnicode(ciphertext)
    assert data._ciphertext == ciphertext
    assert yaml.dump(data, Dumper=AnsibleDumper) == '!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          63313962353334386261626363366130353665323134613761653033326334353934373033323035\n          63626238316531343965383264366231313534346261353339\n'

# Generated at 2022-06-22 13:58:45.231200
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import VarsWithSources
    import yaml

    vm = VariableManager()
    vm._fact_cache = dict(foo=1, bar=True)
    vm._vars_cache = dict(koo=1, lo=True)
    vm._vars_cache_files = []
    vm._vars_cache_sources = ['secret']
    vm._vars_cache_sources_sources = ['secret']

    hostvars = HostVars(vm=vm)
    assert yaml.dump(hostvars, Dumper=AnsibleDumper) == '\n'.join

# Generated at 2022-06-22 13:58:55.661503
# Unit test for function represent_undefined
def test_represent_undefined():
    obj = AnsibleUndefined('value from some jinja2 expression')
    # This actually does not get called. obj.__bool__ is called
    # instead.  This is only for demonstration purposes
    def raise_exception(*args, **kwargs):
        raise ValueError('Unexpected call to represent_undefined')
    setattr(AnsibleDumper, 'represent_undefined', raise_exception)
    try:
        # Will raise ValueError from raise_exception()
        yaml.dump([obj], Dumper=AnsibleDumper)
        raise AssertionError('Should be unreachable')
    except ValueError:
        pass
    delattr(AnsibleDumper, 'represent_undefined')

# Generated at 2022-06-22 13:59:03.930980
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.dumper import AnsibleDumper

    ciphertext = VaultLib.encrypt('secret-password', 'dangerous-password')

# Generated at 2022-06-22 13:59:14.363723
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.module_utils.common._collections_compat import MutableMapping

    class TestVars(MutableMapping):
        def __init__(self):
            self.data = {
                'foo': 'bar',
                'baz': 'qux'
            }

        def __getitem__(self, key):
            return self.data[key]

        def __setitem__(self, key, value):
            self.data[key] = value

        def __delitem__(self, key):
            del self.data[key]

        def __iter__(self):
            return iter(self.data)

        def __len__(self):
            return len(self.data)

    test_vars = TestVars()


# Generated at 2022-06-22 13:59:20.196648
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    vault = VaultLib("ansible")
    ciphertext = vault.encrypt("foo")
    ciphertext_unicode = AnsibleVaultEncryptedUnicode(ciphertext)
    result = represent_vault_encrypted_unicode(AnsibleDumper, ciphertext_unicode)
    assert result == u'!vault |\n          ' + ciphertext.decode() + '\n'

# Generated at 2022-06-22 13:59:24.806215
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Create a variable, encrypt it and then use the dumper to verify
    # the behavior of represent_vaule_encrypted_unicode.
    from ansible.parsing.vault import VaultLib

    password = "foobar"
    vault = VaultLib([])
    data = "baz"

    vault.update(password, data)
    ciphertext = vault.encrypt(password, data)
    test_obj = AnsibleVaultEncryptedUnicode(ciphertext)

    dumper = AnsibleDumper()
    result = dumper.represent_data(test_obj)

    # The result should be a string that starts with '!vault |'
    assert(result.startswith("!vault |\n"))

    # The dump should have the same length as the ciphertext when
    # split in lines.


# Generated at 2022-06-22 13:59:29.021787
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = HostVars(hostvars_dict={'test': 'data'})
    hostvars_yaml = yaml.dump(hostvars, Dumper=AnsibleDumper)
    assert hostvars_yaml == "{test: data}\n...\n"



# Generated at 2022-06-22 13:59:35.311254
# Unit test for function represent_undefined
def test_represent_undefined():
    safedumper = yaml.SafeDumper
    safedumper.add_representer(
        AnsibleUndefined,
        represent_undefined,
    )
    # yaml.dump function is called with allow_unicode being None
    # at safe_dump function of yaml/__init__.py
    ansible_undefined = yaml.dump(AnsibleUndefined, Dumper=safedumper,
                                  allow_unicode=None, width=1000)
    assert bool(ansible_undefined)

# Generated at 2022-06-22 13:59:46.693202
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.modules.vault import VaultLib
