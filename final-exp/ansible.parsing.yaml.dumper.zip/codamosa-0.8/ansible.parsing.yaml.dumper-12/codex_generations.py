

# Generated at 2022-06-22 13:51:06.719276
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    hostvars = HostVars()
    hostvars['somevalue'] = "Fake Value"
    output = dumper.represent_dict(dict(hostvars))
    assert output.value == "{'somevalue': 'Fake Value'}"



# Generated at 2022-06-22 13:51:18.493960
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-22 13:51:29.330246
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    ansible_dumper = AnsibleDumper()

# Generated at 2022-06-22 13:51:34.920290
# Unit test for function represent_binary
def test_represent_binary():
    '''
    Define bytes object
    Create a AnsibleDumper object
    Define object with bytes variable
    Call represent method with object variable
    '''
    bytes_val = b'\x00\x01\x02\x03\x04\x05\x06\x07'
    dumper = AnsibleDumper
    bytes_obj = {'key': bytes_val}
    dumper.represent_binary(bytes_obj)

# Generated at 2022-06-22 13:51:39.569733
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = HostVars()
    data["foo"] = "bar"
    ansible_dumper = AnsibleDumper()
    # This is a little hack to get the representer for HostVars
    # to return a string.  We don't want to actually write to
    # a stream.
    ansible_dumper.stream = text_type()
    result = text_type(ansible_dumper.represent_data(data))
    assert result == text_type('{"foo": "bar"}')



# Generated at 2022-06-22 13:51:46.035109
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = yaml.Dumper()
    assert(dumper.represent_undefined(None) == False)
    assert(dumper.represent_undefined(False) == False)
    assert(dumper.represent_undefined(1) == True)
    assert(dumper.represent_undefined(0) == True)
    assert(dumper.represent_undefined('a') == True)

# Generated at 2022-06-22 13:51:57.881548
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # AnsibleDumper is not a child of PyYAML, create a child class to run tests
    class TestRepresenter(SafeDumper):
        pass

    TestRepresenter.add_representer(
        HostVars,
        represent_hostvars,
    )

    # Create hostvars instance
    hostvars_obj = HostVars()

    hostvars_dict = dict(
        dict_var='dict',
        list_var=['list'],
        set_var=set('set'),
        tuple_var=('tuple',),
    )

    for (key, val) in hostvars_dict.items():
        hostvars_obj[key] = val


# Generated at 2022-06-22 13:52:09.854643
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert yaml.dump({'foo': HostVars(name='bar')}, Dumper=AnsibleDumper, default_flow_style=False) == 'foo: {}\n'
    assert yaml.dump({'foo': HostVars(name='bar')}, Dumper=AnsibleDumper, default_flow_style=True) == '{foo: {}}'
    assert yaml.dump({'foo': HostVarsVars(name='bar')}, Dumper=AnsibleDumper, default_flow_style=False) == 'foo: {}\n'
    assert yaml.dump({'foo': HostVarsVars(name='bar')}, Dumper=AnsibleDumper, default_flow_style=True) == '{foo: {}}'

# Generated at 2022-06-22 13:52:15.202406
# Unit test for function represent_hostvars
def test_represent_hostvars():
    test_data = HostVars(
        host='test_host',
        variables=dict(a='test_a', b='test_b')
    )

    assert yaml.safe_dump(test_data, Dumper=AnsibleDumper) == 'a: test_a\nb: test_b\n'



# Generated at 2022-06-22 13:52:26.268283
# Unit test for function represent_unicode
def test_represent_unicode():
    '''ensure AnsibleUnicode objects are handled correctly.'''

    obj = AnsibleUnicode(u'world', unsafe=True)
    assert yaml.dump(obj) == u'world'

    obj = AnsibleUnicode(u"I'm afraid I can't do that.", unsafe=True)
    assert yaml.dump(obj) == u"I'm afraid I can't do that."

    obj = AnsibleUnicode(u'world', unsafe=False)
    assert yaml.dump(obj) == u"'world'"

    obj = AnsibleUnicode(u"I'm afraid I can't do that.", unsafe=False)
    assert yaml.dump(obj) == u"'I'm afraid I can''t do that.'"

# Generated at 2022-06-22 13:52:32.429537
# Unit test for function represent_binary
def test_represent_binary():
    data = AnsibleUnsafeBytes(b'\x00\x01\x02\x03\x04')
    assert AnsibleDumper.represent_binary(data) == "!!binary |\n  AAECAwQF"

# Generated at 2022-06-22 13:52:34.685901
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    yaml.dump(AnsibleUndefined(), stream=None, Dumper=dumper)

# Generated at 2022-06-22 13:52:46.710694
# Unit test for function represent_unicode
def test_represent_unicode():
    '''
    Test the AnsibleUnicode representer.
    '''

    class TestDumper(AnsibleDumper):
        '''
        This is required because we need to override the default_style
        and default_flow_style of the SafeDumper class. If we don't,
        we cannot test against the exact output.

        For more info:
        http://pyyaml.org/ticket/64

        :kwarg default_flow_style: the default flow style for the dumper
        :kwarg default_style: the default scalar style for the dumper
        '''
        def __init__(self, **kwargs):
            self.default_flow_style = kwargs.pop('default_flow_style', None)
            self.default_style = kwargs.pop('default_style', None)
           

# Generated at 2022-06-22 13:52:58.842659
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    data = AnsibleVaultEncryptedUnicode('hello')
    output = yaml.dump({'hello': data}, Dumper=AnsibleDumper)

# Generated at 2022-06-22 13:53:01.578070
# Unit test for function represent_undefined
def test_represent_undefined():
    ansible_obj = AnsibleUndefined()
    rep = yaml.representer.SafeRepresenter.represent_undefined(None, ansible_obj)
    assert rep



# Generated at 2022-06-22 13:53:10.492827
# Unit test for function represent_unicode
def test_represent_unicode():
    from io import StringIO
    import sys

    # This test is here mostly as a demo
    value = u"ação"

    # We cannot use a regular stringIO.StringIO for some reason
    # This fails with UnicodeEncodeError: 'ascii' codec can't encode character u'\xe7' in position 2: ordinal not in range(128)
    #
    # Hack from https://stackoverflow.com/questions/4545661/unicodedecodeerror-when-redirecting-to-file
    #
    class UnicodeIOStream(object):
        def __init__(self, buffer=None):
            if buffer is None:
                buffer = StringIO()
            self.buffer = buffer
            self.encoding = 'utf-8'


# Generated at 2022-06-22 13:53:18.473411
# Unit test for function represent_undefined
def test_represent_undefined():
    # This dumps without error
    yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper)

    # This dumps with error
    try:
        yaml.dump(dict(fail=AnsibleUndefined()), Dumper=AnsibleDumper)
        assert False
    except Exception as e:
        assert 'undefined var: \'vars.fail\'' in str(e), 'Incorrect error'

if __name__ == "__main__":
    test_represent_undefined()

# Generated at 2022-06-22 13:53:23.485282
# Unit test for function represent_binary
def test_represent_binary():
    assert "!!binary \"aGVsbG8gd29ybGQ=\"" == yaml.dump(b"hello world", Dumper=AnsibleDumper, default_flow_style=False)
    assert "!!binary \"\"" == yaml.dump(b"", Dumper=AnsibleDumper, default_flow_style=False)

# Generated at 2022-06-22 13:53:27.757681
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = yaml.Dumper
    dumper.represent_unicode = represent_unicode
    data = 'test'
    assert dumper.represent_unicode(dumper, data) == u'test\n...\n'



# Generated at 2022-06-22 13:53:37.509896
# Unit test for function represent_binary
def test_represent_binary():
    '''
    Test case for the function represent_binary.
    '''
    test_dumper = yaml.dumper.SafeDumper()

    def invoke_function(data):
        '''
        Simple wrapper to invoke the function.
        Functions are picky about arguments.
        '''
        return represent_binary(test_dumper, data)

    output = invoke_function(b'a test string')
    assert output == "!!binary |-\n  YSB0ZXN0IHN0cmluZw=="

    # Test a few edge cases
    output = invoke_function(b'\x00\x01\x02\x03\xff')
    assert output == "!!binary |-\n  AAECAw=="

    output = invoke_function(b'\x00\x01\x02')


# Generated at 2022-06-22 13:53:50.679112
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault_password = '$ANSIBLE_VAULT;1.1;AES256\n33363036656133326637623537353634333666373035663631366639363136363362373966333761\n3939336465396664656566643036343732643438326436333863613337366235682d0a'
    vault = VaultLib(vault_password)
    encrypted = vault.encrypt(b'test')
    variable = AnsibleVaultEncryptedUnicode(encrypted)
    assert variable._ciphertext == encrypted
    dumper = AnsibleDumper()
    result = dumper.represent_vault_encrypted_unicode(variable)

# Generated at 2022-06-22 13:53:56.026479
# Unit test for function represent_unicode
def test_represent_unicode():
    # Setup
    data = AnsibleUnicode('test')
    yaml_dumper = AnsibleDumper()
    output = yaml_dumper.represent_data(data)

    # Exercise
    expected = u'test'
    # Verify
    assert output == expected



# Generated at 2022-06-22 13:54:00.115955
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = yaml.dumper.SafeDumper
    assert yaml.dump(HostVars(dict(a=1, b=2)), Dumper=dumper, default_flow_style=False) == 'a: 1\nb: 2\n'

# Generated at 2022-06-22 13:54:06.005661
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # Setup
    data = HostVars('inventory_hostname')
    data['foo'] = 'bar'
    data['baz'] = 'bam'

    # Test
    data_str = yaml.dump(data, Dumper=AnsibleDumper)

    # Assert
    assert data_str == "---\nbaz: bam\nfoo: bar\n"



# Generated at 2022-06-22 13:54:15.755628
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    rep = yaml.representer.SafeRepresenter()

# Generated at 2022-06-22 13:54:17.190729
# Unit test for function represent_undefined
def test_represent_undefined():
    AnsibleDumper().represent_undefined(AnsibleUndefined())



# Generated at 2022-06-22 13:54:26.003491
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    '''
    Test that represent_vault_encrypted_unicode properly
    encrypts and decrypts a token using a provided password.
    '''
    import getpass
    from ansible.parsing.vault import VaultLib

    # Setup password and token
    password = getpass.getpass()
    token = getpass.getpass()
    assert password != token

    # Setup cipher_text
    dumper = AnsibleDumper()
    cipher_text = dumper.represent_vault_encrypted_unicode(VaultLib(password).encode(token))

# Generated at 2022-06-22 13:54:29.152491
# Unit test for function represent_unicode
def test_represent_unicode():
    test_string = 'value'
    dumper = AnsibleDumper()
    out = dumper.represent_unicode(test_string)
    assert out == 'value'

# Generated at 2022-06-22 13:54:35.100968
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = HostVars({"foo": "bar"})
    expected = yaml.dump({'foo': 'bar'}, Dumper=SafeDumper, default_flow_style=False)
    result = yaml.dump(hostvars, Dumper=AnsibleDumper, default_flow_style=False)
    assert result == expected

# Generated at 2022-06-22 13:54:45.560485
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-22 13:54:53.448326
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = HostVars(
        {
            'data': {
                'var1': 'value1'
            }
        }
    )
    dumped = yaml.dump(hostvars, Dumper=AnsibleDumper)
    assert dumped == '{data: {var1: value1}}\n'



# Generated at 2022-06-22 13:55:02.843456
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.errors import AnsibleError, AnsibleInternalError, AnsibleOptionsError
    import getpass
    try:
        vault_password = getpass.getpass(prompt="Vault password: ")
    except EOFError:
        raise AnsibleOptionsError("No vault password supplied")
    vault = VaultLib(vault_password)
    ciphertext = vault.encrypt('test')
    encrypted_unicode = AnsibleVaultEncryptedUnicode(ciphertext)
    dumper = AnsibleDumper()
    ciphertext_str = dumper.represent_data(encrypted_unicode)
    print(ciphertext_str)

# Generated at 2022-06-22 13:55:12.637246
# Unit test for function represent_binary
def test_represent_binary():
    """Testing handling of binary data in yaml dump"""
    data = binary_type(b'\x8f')
    # Python 3.2+
    if hasattr(yaml, 'add_representer'):
        dumper = yaml.SafeDumper
        yaml.add_representer(
            binary_type,
            yaml.representer.SafeRepresenter.represent_binary
        )
    # Python 2
    else:
        dumper = yaml.dumper.SafeDumper
        dumper.add_representer(
            binary_type,
            yaml.representer.SafeRepresenter.represent_binary
        )

    assert yaml.dump(data, Dumper=dumper) == binary_type('binary-data: !!binary |\n\t8f\n')


# Generated at 2022-06-22 13:55:20.194660
# Unit test for function represent_unicode
def test_represent_unicode():

    # Given: a string starting with 'unicode:', and a
    #        a SafeRepresenter instance
    test_string = u'unicode: YAML'
    r = yaml.representer.SafeRepresenter()
    r.default_style = ''
    r.default_flow_style = False

    # When: represent_unicode runs
    result = represent_unicode(r, test_string)

    # Then: result should match the expected format.
    assert result.value == 'unicode: YAML'



# Generated at 2022-06-22 13:55:26.614076
# Unit test for function represent_binary
def test_represent_binary():
    # Test with unicode char in binary data
    binary = 'Ansible\xe2\x80\xa2'.encode('utf-8')
    assert AnsibleDumper.represent_binary(AnsibleDumper, binary) == u'!!binary |\n  QW5zaWJsZcKl\n'

    # Test with non-unicode char in binary data
    binary = 'Ansible\x00'.encode('utf-8')
    assert AnsibleDumper.represent_binary(AnsibleDumper, binary) == u'!!binary |\n  QW5zaWJsZQA=\n'

# Generated at 2022-06-22 13:55:27.983167
# Unit test for function represent_binary
def test_represent_binary():
    assert(yaml.representer.SafeRepresenter().represent_binary(b'\x00\x01\x02')) == '!!binary |-\n  AAEC\n'

# Generated at 2022-06-22 13:55:34.962618
# Unit test for function represent_unicode
def test_represent_unicode():
    # pylint: disable=too-few-public-methods
    class FakeStream:
        def __init__(self):
            self.str = ''

        def write(self, str_):
            self.str += str_

    obj = AnsibleUnicode('test')
    stream = FakeStream()
    representer = yaml.representer.SafeRepresenter()
    represent_unicode(representer, obj, stream)
    assert stream.str == 'test'



# Generated at 2022-06-22 13:55:37.833800
# Unit test for function represent_undefined
def test_represent_undefined():
    data = AnsibleUndefined(fail_in_filter=True)
    dumper = AnsibleDumper()
    result = bool(dumper.represent_undefined(data))
    assert result



# Generated at 2022-06-22 13:55:39.308526
# Unit test for function represent_undefined
def test_represent_undefined():
    assert True == represents_undef(AnsibleUndefined())



# Generated at 2022-06-22 13:55:42.754623
# Unit test for function represent_unicode
def test_represent_unicode():
    d = AnsibleDumper()
    represent_unicode(d, '\n')



# Generated at 2022-06-22 13:55:56.856048
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    d = AnsibleDumper()
    data = b'$ANSIBLE_VAULT;1.1;AES256;ansible\n656465646564656465646564656465646564656465646564656465646564656\n463456346546345634563456'

# Generated at 2022-06-22 13:55:59.858608
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined(obj=VarsWithSources())) is False

# Generated at 2022-06-22 13:56:03.229320
# Unit test for function represent_unicode
def test_represent_unicode():
    test_str = u'test'
    assert represent_unicode(None, test_str) == represent_unicode(None, AnsibleUnicode(test_str))

# Generated at 2022-06-22 13:56:08.656967
# Unit test for function represent_hostvars
def test_represent_hostvars():
    yaml.dump({'key': HostVars(None, {})}, Dumper=yaml.dumper.Dumper) == '{key: {}}\n...\n'

    yaml.dump({'key': HostVars(None, {"k": "v"})}, Dumper=yaml.dumper.Dumper) == '{key: {k: v}}\n...\n'



# Generated at 2022-06-22 13:56:11.892982
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template.template import AnsibleUndefined
    assert AnsibleDumper.represent_undefined(AnsibleDumper, AnsibleUndefined()) is False

# Generated at 2022-06-22 13:56:17.360010
# Unit test for function represent_unicode
def test_represent_unicode():
    assert AnsibleDumper.represent_unicode(AnsibleDumper, 'foo') == u'foo'
    assert AnsibleDumper.represent_unicode(AnsibleDumper, b'foo') == u'foo'
    assert AnsibleDumper.represent_unicode(AnsibleDumper, 1) == u'1'
    assert AnsibleDumper.represent_unicode(AnsibleDumper, b'\xe9') == u'\xe9'



# Generated at 2022-06-22 13:56:19.858117
# Unit test for function represent_unicode
def test_represent_unicode():
    data = AnsibleUnicode('test')
    yaml.dump(data, stream=None, Dumper=AnsibleDumper)


# Generated at 2022-06-22 13:56:24.699883
# Unit test for function represent_undefined
def test_represent_undefined():
    m = AnsibleDumper()
    # Here bool will ensure _fail_with_undefined_error happens
    # if the value is Undefined.
    # This happens because Jinja sets __bool__ on StrictUndefined
    m.represent_undefined(False)

# Generated at 2022-06-22 13:56:27.541311
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # TODO: better way to test this?
    assert repr(represent_hostvars(AnsibleDumper, {'foo': 'bar'})) == "represent_dict({'foo': 'bar'})"



# Generated at 2022-06-22 13:56:32.372475
# Unit test for function represent_binary
def test_represent_binary():
    input_binary = b'some_binary_string'
    test_dumper = AnsibleDumper(default_flow_style=True)
    output = test_dumper.represent_binary(input_binary)
    assert output == "!binary |\n  c29tZV9iaW5hcnlfc3RyaW5n\n"

# Generated at 2022-06-22 13:56:43.512362
# Unit test for function represent_binary
def test_represent_binary():
    assert b'aW52YWxpZA==\n' == yaml.safe_dump(b'invalid', Dumper=AnsibleDumper)



# Generated at 2022-06-22 13:56:53.905124
# Unit test for function represent_unicode
def test_represent_unicode():
    def check_represent_unicode(value, expected):
        stream = yaml.emitter.Emitter(AnsibleDumper.stream)
        AnsibleDumper.stream = stream
        AnsibleDumper.represent_unicode(value)
        result = ''.join([event[1] for event in stream.events])
        assert result == expected

    check_represent_unicode(
        u'Águila',
        u'"Águila"\n'
    )

    check_represent_unicode(
        u'- Águila',
        u'- "Águila"\n'
    )

    check_represent_unicode(
        u'a: Águila',
        u'a: "Águila"\n'
    )

# Generated at 2022-06-22 13:57:02.157253
# Unit test for function represent_unicode
def test_represent_unicode():
    # Simple test, no ordering of keys, no unicode
    data = {
        'string': 'string',
        'int': 1,
        'float': 1.5,
        'list': [1, 2, 'string'],
        'dict': {
            'list': [1, 2, 'string'],
            'dict': {
                'string': 'string',
            },
        },
    }

    result = yaml.dump(data, Dumper=AnsibleDumper, default_flow_style=False)
    assert result == '''\
string: string
int: 1
float: 1.5
list:
- 1
- 2
- string
dict:
  list:
  - 1
  - 2
  - string
  dict:
    string: string
'''

    # Simple test, ordering

# Generated at 2022-06-22 13:57:10.675668
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    binary = b"\x00\x01\x02\x03"
    result = dumper.represent_binary(binary)
    assert result == u"!!binary |\n  AAECAQ=="
    result = dumper.represent_binary(binary, style='>')
    assert result == u"!binary |-\n  AAECAQ=="
    # !binary | is ignored.
    result = dumper.represent_binary(binary, style='|')
    assert result == u"!!binary |\n  AAECAQ=="


# Generated at 2022-06-22 13:57:19.865973
# Unit test for function represent_hostvars
def test_represent_hostvars():
    class DummyModule:
        def __init__(self):
            self.params = dict()
            self.params['var1'] = 'it worked'
            self.params['var2'] = 'it worked again'

    # This is not a real module. It just needs to have a params attribute
    module = DummyModule()

    # Need to create a class that has a params attribute
    hostvars = HostVars(module)

    # Do the test
    assert represent_hostvars(None, hostvars) == dict(module.params)


# Stub class needed for unit test

# Generated at 2022-06-22 13:57:22.976469
# Unit test for function represent_binary
def test_represent_binary():
    data = AnsibleUnsafeBytes("\x00\x01\x02\x03")
    d = yaml.Dumper
    result = represent_binary(d, data)
    assert result == '!!binary |\n  AAEAAQ==\n'

# Generated at 2022-06-22 13:57:28.232679
# Unit test for function represent_binary
def test_represent_binary():
    from _io import BytesIO
    original_io = yaml.representer.SafeRepresenter.io
    try:
        yaml.representer.SafeRepresenter.io = BytesIO()
        represent_binary(None, b"\x00\x01\x02")
        assert yaml.representer.SafeRepresenter.io.getvalue() == b"? !!binary |\n  AAEC\n"
    finally:
        yaml.representer.SafeRepresenter.io = original_io

# Generated at 2022-06-22 13:57:35.750531
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib

    data = AnsibleVaultEncryptedUnicode(VaultLib().encrypt('secret'))
    # Bytes and strings are different in python2 and python3
    # and yaml has options to represent binary data differently
    # pipe, single-quoted and double-quoted
    # The base64 representation is the same in python2 and python3
    # and being base64 it can be represented in all three ways
    # single-quoted, double-quoted, pipe

# Generated at 2022-06-22 13:57:45.689858
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    h = Host('h1')
    vm = VariableManager()
    vm._vars_per_host = {}
    vm._vars_per_host['h1'] = {'ansible_host': 'foo'}
    h.vars = vm.get_vars(play=None, host=h)
    d = AnsibleDumper()
    # No need to __str__ here, the YAML API doesn't like it.  It's
    # been a while since the API changed.
    assert d.represent_hostvars(h.vars)



# Generated at 2022-06-22 13:57:56.668442
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = {
        u'name': u'test',
        u'vars': {
            u'foo': u'bar',
            u'baz': u'qux'
        },
        u'children': {
            u'default': {
                u'vars': {
                    u'test': u'value'
                }
            }
        }
    }
    expected = u'name: test\n' \
               u'vars:\n  foo: bar\n  baz: qux\n' \
               u'children:\n  default:\n    vars:\n      test: value\n'
    hostvars = HostVars(data)
    assert expected == yaml.dump(hostvars, Dumper=AnsibleDumper)

# Generated at 2022-06-22 13:58:19.992034
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.template.safe_eval import ansible_safe_eval

    dumper = AnsibleDumper()
    data = u'{{ hello }}'
    val = ansible_safe_eval(data)

    assert isinstance(val, AnsibleUnicode)

    # Check for the correct dumper output
    yaml_out = dumper.represent_unicode(val)
    assert yaml_out == u'"{{ hello }}"'



# Generated at 2022-06-22 13:58:21.161215
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined())

# Generated at 2022-06-22 13:58:23.422727
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper(indent=2)
    undefined = AnsibleUndefined("foo")
    represent_undefined(dumper, undefined)

# Generated at 2022-06-22 13:58:24.764213
# Unit test for function represent_undefined
def test_represent_undefined():
    represent_undefined(AnsibleDumper, AnsibleUndefined())

# Generated at 2022-06-22 13:58:30.802445
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = yaml.Dumper
    dumper.ignore_aliases = lambda self, data: True
    d = { 'key': 'value'}
    h = HostVars(host_data = d)
    output = yaml.dump(h, Dumper=dumper)

    assert output == "---\nkey: value\n"


# Generated at 2022-06-22 13:58:38.159417
# Unit test for function represent_hostvars
def test_represent_hostvars():
    """represent_hostvars: convert HostVars to dict and dump as string"""
    hv = HostVars(host_specific_var=dict(foo='bar'), group_vars=dict(group_var=dict(foo='bar')))
    yaml_str = yaml.dump(hv, Dumper=AnsibleDumper)
    yaml_dict = yaml.load(yaml_str)
    assert yaml_dict['host_specific_var']['foo'] == 'bar'
    assert yaml_dict['group_vars']['group_var']['foo'] == 'bar'
    assert yaml_dict == dict(host_specific_var=dict(foo='bar'), group_vars=dict(group_var=dict(foo='bar')))



# Generated at 2022-06-22 13:58:43.262130
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = {'hostvars': HostVars({"a": "b"}, per_host_overrides={"a": "c"})}
    expected_yaml = 'hostvars: a: c'

    yaml_text = yaml.dump(data, Dumper=AnsibleDumper, default_flow_style=False)

    assert yaml_text == expected_yaml



# Generated at 2022-06-22 13:58:47.891177
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # Unit test for function represent_hostvars
    assert represent_hostvars(None, HostVars()) == \
        yaml.representer.SafeRepresenter.represent_dict(None, {})
    assert represent_hostvars(None,
                              HostVars({'a': {'b': 'c'}})) == \
        yaml.representer.SafeRepresenter.represent_dict(
            None, {
                'a': {
                    'b': 'c',
                },
            }
        )



# Generated at 2022-06-22 13:58:50.389809
# Unit test for function represent_undefined
def test_represent_undefined():
    with pytest.raises(yaml.representer.RepresenterError):
        yaml.safe_dump(AnsibleUndefined(), Dumper=AnsibleDumper)

# Generated at 2022-06-22 13:58:57.176238
# Unit test for function represent_undefined
def test_represent_undefined():
    # ansible.template.AnsibleUndefined - this is what is returned from Jinja2
    # when a variable is not defined and we have strict: True
    from ansible.template import AnsibleUndefined
    obj = AnsibleUndefined()

    assert isinstance(obj, AnsibleUndefined)
    r = AnsibleDumper.represent_undefined(AnsibleDumper, obj)
    assert r is None