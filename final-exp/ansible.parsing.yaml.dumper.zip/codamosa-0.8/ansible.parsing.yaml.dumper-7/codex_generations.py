

# Generated at 2022-06-22 13:51:13.503000
# Unit test for function represent_undefined
def test_represent_undefined():
    # Does not raise an error
    yaml.safe_dump([AnsibleUndefined()], Dumper=AnsibleDumper)
    # Raise an error
    try:
        yaml.safe_dump([AnsibleUndefined()], Dumper=yaml.SafeDumper)
    except Exception:
        pass
    else:
        raise AssertionError('Representing an AnsibleUndefined raised no exception')

# Generated at 2022-06-22 13:51:19.120145
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = HostVars(AnsibleMapping({u'mid': u'ctos', u'user': u'root', u'host': u'localhost', u'cluster': u'cluster1'}))
    assert yaml.dump(hostvars, Dumper=AnsibleDumper, default_flow_style=False) == 'host: localhost\nmid: ctos\nuser: root\ncluster: cluster1\n'

# Generated at 2022-06-22 13:51:26.399183
# Unit test for function represent_hostvars
def test_represent_hostvars():
    HOST = 'host'
    VAR1 = 'var1'
    VAR2 = 'var2'
    VALUE = 'value'
    representer = AnsibleDumper.yaml_representers[HostVars]
    data = HostVars(HOST)
    data[VAR1] = VALUE
    data[VAR2] = VALUE
    result = representer(AnsibleDumper, data)
    assert result == "{var2: value, var1: value}".encode()

# Generated at 2022-06-22 13:51:31.919168
# Unit test for function represent_unicode
def test_represent_unicode():
    ''' represent_unicode should handle strings with strings in them'''
    dumper = AnsibleDumper()

    foo = u'foo'
    bar = u'bar'
    expected = dumper.represent_data({u'foo': u'bar'})
    output = dumper.represent_unicode(u'{0}={1}'.format(foo, bar))

    assert output == expected


# Generated at 2022-06-22 13:51:39.709028
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    '''
    Represent_vault_encrypted_unicode runs the following test:
    - Test that ansible.parsing is present and get the ansible.parsing.vault module.
    - Test that ansible.parsing.vault module is present.
    - Test that VaultLib class is present.
    - Test that the vault class initiated.
    - Test that vault_data variable is a ansible.parsing.yaml.objects.AnsibleVaultEncryptedUnicode class.
    - Test the returned value is equal to the original value.
    '''
    import ansible.utils.display as Display

    Display.verbosity = 4

    # Test that vault_data is a ansible.parsing.yaml.objects.AnsibleVaultEncryptedUnicode class.
    # Test the returned value is

# Generated at 2022-06-22 13:51:51.766856
# Unit test for function represent_unicode
def test_represent_unicode():

    # Generate test data
    u = u'\u041b\u0435\u0432 \u041d\u0438\u043a\u043e\u043b\u0430\u0435\u0432\u0438\u0447 \u041d\u0438\u043a\u043e\u043d\u043e\u0432'
    test_data = [
        u,
        u.encode('utf8'),
        u.encode('utf16'),
        u.encode('utf32')
    ]

    # Build test data
    tests = []
    for data in test_data:
        tests.append({'data': data})

    # Perform tests
    results = []
    for test in tests:
        data = test['data']
        result = yaml

# Generated at 2022-06-22 13:51:53.509773
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert yaml.dump(HostVars({"foo": "bar"})) == "foo: bar\n"

# Generated at 2022-06-22 13:51:57.773662
# Unit test for function represent_binary
def test_represent_binary():
    d = yaml.load(yaml.dump(b"\x00\x01\x02\xff"), Loader=yaml.SafeLoader)
    assert d == b"\x00\x01\x02\xff"

# Generated at 2022-06-22 13:52:01.370333
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    data = binary_type(b'\xff\x00')
    assert dumper.represent_binary(dumper, data) == u'!!binary |\n  /wAA\n'

# Generated at 2022-06-22 13:52:11.912971
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    s = AnsibleVaultEncryptedUnicode('hello')
    dumper = AnsibleDumper(None, None)
    # The vault password needs to be set to convert the ciphertext
    # to the original text.
    ctext = dumper.represent_vault_encrypted_unicode(s)

# Generated at 2022-06-22 13:52:19.060033
# Unit test for function represent_unicode
def test_represent_unicode():
    d = AnsibleDumper()
    assert d.represent_unicode(AnsibleUnicode('mystr')) == "mystr"
    assert d.represent_unicode(AnsibleUnsafeText('mystr')) == "mystr"
    assert d.represent_unicode(AnsibleUnsafeBytes('mystr')) == "mystr"



# Generated at 2022-06-22 13:52:24.100803
# Unit test for function represent_unicode
def test_represent_unicode():
    from ansible.module_utils.common.yaml import AnsibleUnicode
    dump1 = yaml.dump(AnsibleUnicode("A string"))
    dump2 = yaml.dump(text_type("A string"))
    assert dump1 == dump2



# Generated at 2022-06-22 13:52:36.008106
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    '''
    Example YAML text dump of AnsibleVaultEncryptedUnicode
    !vault |
        $ANSIBLE_VAULT;1.1;AES256
        62323739373034343139396531333266313163356133636535346566376433613739336330316638
        39653739300a37373364323061636562336632316536336635626532666633306565313239366533
        3232613431660a63353635643661303532626336306536313239
    '''
    plaintext = AnsibleVaultEncryptedUnicode('value')

# Generated at 2022-06-22 13:52:39.934832
# Unit test for function represent_undefined
def test_represent_undefined():
    undefined = AnsibleUndefined('')
    result = AnsibleDumper().represent_data(undefined)
    assert result == '!!python/object/apply:ansible.parsing.yaml.objects.AnsibleUndefined []\n'

# Generated at 2022-06-22 13:52:50.432683
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # Create a HostVars object with some data
    hv = HostVars(host_vars='192.168.56.1', group_vars=[], vars_source=[], hashvars=None, groups=[])
    hv['test'] = 'test'

    # Use the object in a regular Python structure so it can be YAML serialized
    struct = {'test': hv}

    # Serialize the structure using our represent_hostvars function
    serial = yaml.dump(struct, Dumper=AnsibleDumper)

    # Check the result
    assert serial == 'test:\n  192.168.56.1: {\n    test: test\n  }\n'



# Generated at 2022-06-22 13:52:54.382429
# Unit test for function represent_binary
def test_represent_binary():
    data = AnsibleDumper({'f': '/path/to/file'})
    assert data.data == '{f: !!binary |\n  L3BhdGgvdG8vZmlsZQ==\n'


# Generated at 2022-06-22 13:53:00.490034
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    ansible_dumper = AnsibleDumper()

    # create the dummy class required for testing
    class Foo:
        def __init__(self):
            self._ciphertext = u'bar'

    actual = represent_vault_encrypted_unicode(ansible_dumper, Foo())
    expected = u"!vault |\n  bar\n"
    assert actual == expected

# Generated at 2022-06-22 13:53:04.724238
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    assert represent_vault_encrypted_unicode(None, AnsibleVaultEncryptedUnicode("test")) == u'!vault |'
    from ansible.parsing.vault import VaultLib
    assert represent_vault_encrypted_unicode(None, VaultLib("test").encrypt("test")) == u'!vault |'

# Generated at 2022-06-22 13:53:11.900085
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars, HostVarsVars
    from ansible.vars.manager import VarsWithSources
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.loader import AnsibleLoader
    import json

    class TestHostVars(HostVars):

        def __init__(self, loader, nodes):
            self._loader = loader
            self._nodes = nodes
            self._templar = Templar(loader=loader)

    class TestHostVarsVars(HostVarsVars):

        def __init__(self):
            super(TestHostVarsVars, self).__init__()
            self._loader = AnsibleLoader(None, None)

# Generated at 2022-06-22 13:53:15.934525
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, u'\u20ac') == yaml.representer.SafeRepresenter.represent_str(None, text_type(u'\u20ac'))

# Generated at 2022-06-22 13:53:23.905214
# Unit test for function represent_undefined
def test_represent_undefined():
    assert represent_undefined.__name__ == 'represent_undefined'
    dumper = AnsibleDumper(None, None, None)
    result = dumper.represent_data(AnsibleUndefined)
    assert result is True
    result = dumper.represent_data(False)
    assert result is False

# Generated at 2022-06-22 13:53:32.585389
# Unit test for function represent_unicode
def test_represent_unicode():

    unicode_sample = AnsibleUnicode(u'\u00a3')  # unicode pound sign (\u00a3)

    if yaml.__with_libyaml__:
        # The LibYAML bindings return a str not a unicode string by default.
        # This is fixed in the C code.
        assert represent_unicode(AnsibleDumper, unicode_sample) == '!!python/unicode "\xa3"'
    else:
        assert represent_unicode(AnsibleDumper, unicode_sample) == '!python/unicode "\xa3"'



# Generated at 2022-06-22 13:53:34.925281
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dumpb(binary_type('x')) == "!!binary 'eA=='\n"


# Generated at 2022-06-22 13:53:46.043832
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    original_string = "abc, def, ghi"
    encrypted_string = "!vault |\n  $ANSIBLE_VAULT;1.1;AES256\n  386436313437646633386334373335633465306536393438333630396439616133326261336565\n  31373536306130626262636561643366343336396438333561393263313230\n"
    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode(original_string)
    dumper = AnsibleDumper()
    assert dumper.represent_vault_encrypted_unicode(ansible_vault_encrypted_unicode) == encrypted_string

# Generated at 2022-06-22 13:53:48.961471
# Unit test for function represent_undefined
def test_represent_undefined():
    yaml_output = repr(yaml.dump(AnsibleUndefined(), default_flow_style=None, Dumper=AnsibleDumper))
    assert yaml_output == "False"

# Generated at 2022-06-22 13:53:51.501635
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import AnsibleUndefined
    assert AnsibleDumper.represent_undefined(AnsibleDumper, AnsibleUndefined("undefined"))

# Generated at 2022-06-22 13:54:03.019385
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib, VaultSecret
    secret = VaultSecret(['test'])
    vault_obj = VaultLib([])
    with vault_obj.locked():
        data = AnsibleVaultEncryptedUnicode(vault_obj, vault_obj.encrypt(text_type('foobar'),
            secret, None, 1, 0, b'$ANSIBLE_VAULT;1.1;AES256'))
        actual = yaml.dump(dict(data), Dumper=AnsibleDumper)

# Generated at 2022-06-22 13:54:06.286181
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = AnsibleMapping({u'foo': u'bar'})
    dumper = AnsibleDumper()
    assert dumper.represent_hostvars(data) == dumper.represent_dict(dict(data))



# Generated at 2022-06-22 13:54:10.712495
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper(**yaml.composer.Composer.DEFAULT_COMPOSER_ARGS)
    assert yaml.representer.SafeRepresenter.represent_str(dumper, 'UNDEFINED') == yaml.representer.SafeRepresenter.represent_undefined(dumper, AnsibleUndefined('UNDEFINED'))

# Generated at 2022-06-22 13:54:19.891705
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(None) == yaml.representer.SafeRepresenter.represent_binary(dumper, None)
    assert dumper.represent_binary(b'') == yaml.representer.SafeRepresenter.represent_binary(dumper, b'')
    assert dumper.represent_binary(b'a') == yaml.representer.SafeRepresenter.represent_binary(dumper, b'a')
    assert dumper.represent_binary(b'a\n') == yaml.representer.SafeRepresenter.represent_binary(dumper, b'a\n')

# Generated at 2022-06-22 13:54:23.034165
# Unit test for function represent_unicode
def test_represent_unicode():
    data = AnsibleUnicode(u"foo")
    assert yaml.dump(data, Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-22 13:54:33.156744
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.manager import VarsManager
    from ansible.parsing.utils.addresses import parse_address
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # Place vars into host places in inventory
    myhost = Host(name='testhost')
    myhost.vars = VarsManager()
    myhost.vars.data['hostvar1'] = 'hostvar1value'
    mygroup = Group(name='testgroup')
    mygroup.vars = VarsManager()
    mygroup.vars.data['groupvar1'] = 'groupvar1value'
    myhost.set_variable

# Generated at 2022-06-22 13:54:39.714614
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    q = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256')
    q._ciphertext = b'\nYmVuamFtZSBtZWdhdXN0cmVu\n'
    output = yaml.dump(q, Dumper=AnsibleDumper)
    assert output.startswith('!vault |-\n')

# Generated at 2022-06-22 13:54:46.798134
# Unit test for function represent_hostvars
def test_represent_hostvars():

    from ansible.parsing.yaml import AnsibleLoader
    yaml_result = '''{
  "test_host": { "test_var": "test_value" }
}'''
    test_hostvars = HostVars()
    test_hostvars['test_host']['test_var'] = 'test_value'
    result = yaml.dump(test_hostvars, Dumper=AnsibleDumper, default_flow_style=False)
    assert result == yaml_result
    parsed_result = AnsibleLoader(yaml_result).get_single_data()

    assert parsed_result == test_hostvars



# Generated at 2022-06-22 13:54:56.035149
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Create a AnsibleVaultEncryptedUnicode object
    obj = AnsibleVaultEncryptedUnicode(u'some plain text', u'some password')
    obj.decrypt(u'some password')

    # Create a yaml.dumper.SafeDumper object
    dumper = SafeDumper()

    # Create a yaml.representer.SafeRepresenter object
    representer = yaml.representer.SafeRepresenter()

    # Represent the object using the representer
    data = representer.represent_scalar(u'!vault', obj._ciphertext, style='|')

    # Dump the data using the dumper

# Generated at 2022-06-22 13:55:03.761636
# Unit test for function represent_binary
def test_represent_binary():
    def check(data, expected):
        result = AnsibleDumper.represent_binary(None, data)
        assert result == expected

    # ASCII
    check(b"foo", b"!binary |\n  Zm9v")
    check(b"~", b"!binary |\n  ~")
    check(b"\x7f", b"!binary |\n  zg==")
    check(b"\x80", b"!binary |\n  gA==")
    check(b"foobar", b"!binary |\n  Zm9vYmFy")

    # Misaligned
    check(b"\x03", b"!binary |\n  Aw==")
    check(b"\x03\x03", b"!binary |\n  AAA=")

# Generated at 2022-06-22 13:55:07.326282
# Unit test for function represent_hostvars
def test_represent_hostvars():
    var = HostVars(variable='banana')
    assert (
        yaml.dump(var, Dumper=AnsibleDumper) ==
        'banana: {  }\n'
    )



# Generated at 2022-06-22 13:55:12.415460
# Unit test for function represent_binary
def test_represent_binary():
    test_data = b"\x5d\x63\x62\x33\x64\x35\x35\x65\x61\x39\x34\x66\x30\x36\x65\x66"
    assert yaml.dump(test_data, Dumper=AnsibleDumper) == '!!binary |\n  XWRiMzU1ZWE5NGYwNmVm\n'


# Generated at 2022-06-22 13:55:17.677503
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars import HostVars
    h = HostVars(dict(a=1, b=2, c=3))
    s = yaml.dump(h, Dumper=AnsibleDumper)
    assert s == '{a: 1, b: 2, c: 3}\n...\n'

# Generated at 2022-06-22 13:55:22.544620
# Unit test for function represent_unicode
def test_represent_unicode():

    class Dumper(object):
        def represent_str(self, data):
            return "str"

    dumper = Dumper()

    assert represent_unicode(dumper, "string") == "str"
    assert represent_unicode(dumper, u"string") == "str"
    assert represent_unicode(dumper, AnsibleUnicode("string")) == "str"

# Generated at 2022-06-22 13:55:33.047585
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hv = HostVars({'key1': 'value1'}, None)
    hvv = HostVarsVars({'key1': 'value1'}, None)
    dumper = AnsibleDumper()
    assert dumper.represent_data(hv) == u'{key1: value1}\n...\n'
    assert dumper.represent_data(hvv) == u'{key1: value1}\n...\n'

# Generated at 2022-06-22 13:55:41.284976
# Unit test for function represent_binary
def test_represent_binary():
    # Ensure that the output of represent_binary is not in the form of
    # "%" followed by arbitrary number of characters.
    #
    # https://github.com/ansible/ansible/issues/14333
    #
    # For example, if new_data was "%a", then the output from
    # represent_binary will be "%25a".
    #
    # For example, if new_data was "%a%b", then the output from
    # represent_binary will be "%25a%25b".
    #
    # We want to make sure that the form of the output does
    # not conform to this pattern.
    new_data = "%a"
    new_instance = AnsibleDumper(explicit_start=True, explicit_end=True)
    output = new_instance.represent_binary(new_data)
   

# Generated at 2022-06-22 13:55:52.607139
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    stream = yaml.dump(AnsibleVaultEncryptedUnicode(b'foo'), Dumper=AnsibleDumper, explicit_start=True)

# Generated at 2022-06-22 13:55:56.651308
# Unit test for function represent_binary
def test_represent_binary():
    rep_binary = yaml.representer.SafeRepresenter.represent_binary

    # No-op
    try:
        assert rep_binary(None, '\x00\x00\x00\x00') == '\x00\x00\x00\x00'
    except AssertionError:
        raise AssertionError('Failed to represent binary data')



# Generated at 2022-06-22 13:56:01.973139
# Unit test for function represent_unicode
def test_represent_unicode():
    test_data = AnsibleUnicode('hello world')
    result = yaml.dump_all([test_data], Dumper=AnsibleDumper)
    assert result == '--- hello world\n'



# Generated at 2022-06-22 13:56:04.118172
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert AnsibleDumper.represent_hostvars(None, {'a':'b'}) == "a: b\n"

# Generated at 2022-06-22 13:56:15.467392
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    d = AnsibleDumper()

# Generated at 2022-06-22 13:56:18.610636
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = HostVars({'foo': 'bar'})
    stream = yaml.dump(data, Dumper=AnsibleDumper, default_flow_style=False)
    assert stream == "foo: bar\n"

# Generated at 2022-06-22 13:56:28.998820
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper(None, default_flow_style=False, indent=2, width=80)

# Generated at 2022-06-22 13:56:35.534758
# Unit test for function represent_hostvars
def test_represent_hostvars():

    class Test:
        def __init__(self, data):
            self.data = data

        def get_all_vars(self):
            return self.data

    hosts_vars = HostVars(
        vars=Test(
            data=dict(
                a=1,
                b=2,
            )
        ),
        groups=Test(
            data=dict(
                c=3,
                d=4,
            )
        ),
    )

    expected = dict(
        a=1,
        b=2,
        group_names=['all'],
        groups=dict(
            all=dict(
                c=3,
                d=4,
            ),
        ),
    )
