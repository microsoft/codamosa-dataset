

# Generated at 2022-06-22 13:51:15.833382
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib

    dummy_password = '$6$salt$password'
    raw_data = 'secrets'
    vault = VaultLib([dummy_password])
    ciphertext = vault.encrypt(raw_data)
    encrypted_unicode = AnsibleVaultEncryptedUnicode(ciphertext)
    result = represent_vault_encrypted_unicode(AnsibleDumper, encrypted_unicode)

    assert result is not None
    assert result == "!vault |\n  %s" % ciphertext

# Generated at 2022-06-22 13:51:19.431744
# Unit test for function represent_binary
def test_represent_binary():
    """Ensure we can represent a binary type when it contains NULL"""
    md = AnsibleDumper()
    md.represent_binary(b"abc\0def")


# Generated at 2022-06-22 13:51:23.473453
# Unit test for function represent_unicode
def test_represent_unicode():
    class FakeDumper:
        def represent_scalar(self, value, data, style=None):
            return '^fake_unicode^'

    assert represent_unicode(FakeDumper(), u'hello') == '^fake_unicode^'

# Generated at 2022-06-22 13:51:27.974652
# Unit test for function represent_binary
def test_represent_binary():
    """
    Test that represent_binary properly returns a string of the correct format
    """
    yaml.add_representer(bytes, represent_binary)
    yaml_str = yaml.dump(b'\x00\x01\x02')
    assert yaml_str == '!!binary |\n  AAEC\n'

# Generated at 2022-06-22 13:51:31.715168
# Unit test for function represent_hostvars
def test_represent_hostvars():
    obj = AnsibleDumper()
    data = {'foo': 'bar', 'blah': {'a': 'b'}}
    assert obj.represent_dict(data) == obj.represent_hostvars(HostVars(data))



# Generated at 2022-06-22 13:51:34.881528
# Unit test for function represent_undefined
def test_represent_undefined():
    '''Unit test for function represent_undefined'''
    try:
        yaml.dump(AnsibleUndefined, Dumper=AnsibleDumper)
    except Exception as e:
        assert 'is undefined' in str(e)

# Generated at 2022-06-22 13:51:46.646373
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'unicode str') == dumper.represent_unicode(AnsibleUnicode(u'unicode str'))
    assert dumper.represent_unicode(u'unicode str') == dumper.represent_unicode(AnsibleUnsafeText(u'unicode str'))
    assert dumper.represent_unicode(u'unicode str') == dumper.represent_unicode(AnsibleUnsafeBytes(b'unicode str'))
    assert dumper.represent_unicode(u'unicode str') == dumper.represent_unicode('unicode str')
    assert dumper.represent_unicode(u'unicode str') == dumper.represent_unicode('unicode str'.encode('utf-8'))
   

# Generated at 2022-06-22 13:51:53.920801
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    assert dumper.represent_hostvars(HostVars({'bar': 'baz'})) == {'bar': 'baz'}
    assert dumper.represent_hostvars(HostVarsVars({'bar': 'baz'})) == {'bar': 'baz'}
    assert dumper.represent_hostvars(VarsWithSources({'bar': 'baz'})) == {'bar': 'baz'}



# Generated at 2022-06-22 13:51:59.179381
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # simple test to make sure we can represent hostvars
    hv = HostVars(dict(a=1, b=2))
    data = yaml.dump(hv, Dumper=AnsibleDumper)
    data = yaml.safe_load(data)
    assert data == hv.data

# Generated at 2022-06-22 13:52:00.679262
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'\x00foo\x00') == u'!!binary |\n  AAZmb28A'
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v'

# Generated at 2022-06-22 13:52:12.454973
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    templar = Templar(loader=None, variables={}, fail_on_undefined=False)
    value = templar.template(AnsibleUndefined())
    assert value == '', 'Template returned incorrect value: "%s"' % value
    templar = Templar(loader=None, variables={}, fail_on_undefined=True)
    assert templar.template(AnsibleUndefined()) == 'VARIABLE IS NOT DEFINED!', 'Template returned incorrect value'

# Generated at 2022-06-22 13:52:22.313672
# Unit test for function represent_unicode
def test_represent_unicode():
    import sys
    import codecs
    import StringIO

    if sys.version_info[0] == 2:
        assert isinstance(u'foo', AnsibleUnicode)

    yaml_string = u'foo: !copy $bar\n'
    dumper = AnsibleDumper(indent = 4, default_flow_style = False)
    buf = StringIO.StringIO()

    dumper.add_representer(
        AnsibleUnicode,
        represent_unicode,
    )

    dumper.dump(yaml_string, buf)

    assert buf.getvalue() == u'foo: !copy $bar\n'

# Generated at 2022-06-22 13:52:33.079173
# Unit test for function represent_binary
def test_represent_binary():
    data_yaml_objs = [
        b'',
        b'binary data\x00and some unicode: \u2603',
        b'binary data\x00and some ansible unicode: \x01\x02\x03'
    ]
    for data in data_yaml_objs:
        res = represent_binary(AnsibleDumper, data)
        # We are expecting base64 encoded string.
        data_base64 = data.encode('base64')
        # Remove the new line
        data_base64 = data_base64[:-1]

        assert res.value == text_type(data_base64), \
            "Representation of binary data failed."



# Generated at 2022-06-22 13:52:35.966535
# Unit test for function represent_binary
def test_represent_binary():
    rep = AnsibleDumper.represent_binary

    assert rep(AnsibleDumper, b'foo') == rep(SafeDumper, b'foo')


# Generated at 2022-06-22 13:52:39.420657
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert b"!!binary |\n  aGVsbG8gd29ybGQ=" == dumper.represent_binary(b"hello world")



# Generated at 2022-06-22 13:52:48.280995
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256;foo\nbar\nbaz\n')
    dumper = AnsibleDumper()
    output = dumper.represent_vault_encrypted_unicode(data)
    assert isinstance(output, yaml.nodes.ScalarNode)
    assert output.value == '!vault |\n  $ANSIBLE_VAULT;1.1;AES256;foo\n  bar\n  baz\n'
    assert output.style == '|'

# Generated at 2022-06-22 13:53:00.339302
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, AnsibleUnicode('string')) == represent_unicode(None, text_type('string'))
    assert represent_unicode(None, AnsibleUnicode('unicode string')) == represent_unicode(None, text_type('unicode string'))
    assert represent_unicode(None, AnsibleUnicode(u'unicode string')) == represent_unicode(None, text_type('unicode string'))
    assert represent_unicode(None, AnsibleUnicode('unicode \u2022 string')) == represent_unicode(None, text_type('unicode \u2022 string'))

# Generated at 2022-06-22 13:53:03.633795
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    # Example from 3.0.0 doc string
    assert dumper.represent_binary(binary_type(b'123')) == u'!!binary |\n  MTIz\n'



# Generated at 2022-06-22 13:53:09.773168
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dump = AnsibleDumper().represent_vault_encrypted_unicode(AnsibleVaultEncryptedUnicode('test'))
    assert dump == '!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          6461643233303265663239666336623665393365363239343534626338336262336239396162663933\n          353865626461386133613931623431346638393962626431630a333661373831336166626239626438\n          383131396635356239616633626138663161376138313238663235393566316135633661\n\n'



# Generated at 2022-06-22 13:53:18.248245
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml import objects

    data = HostVars(hostvars=dict(foo='bar'))

    # Convert to YAML
    dumped_data = yaml.dump(data, Dumper=AnsibleDumper)

    # Convert to object
    loaded_data = yaml.load(dumped_data)

    assert isinstance(loaded_data, AnsibleMapping)
    assert list(loaded_data.keys()) == ['foo']
    assert loaded_data['foo'] == 'bar'



# Generated at 2022-06-22 13:53:24.172409
# Unit test for function represent_unicode
def test_represent_unicode():
    assert AnsibleDumper.represent_unicode(None, "foo") == yaml.representer.SafeRepresenter.represent_str(None, text_type("foo"))

# Generated at 2022-06-22 13:53:28.671489
# Unit test for function represent_hostvars
def test_represent_hostvars():
    '''
    Test dict output from Hostvars object
    '''
    out = yaml.dump(HostVars('test'), Dumper=AnsibleDumper, default_flow_style=False)
    assert out == "---\ntest: {}\n"



# Generated at 2022-06-22 13:53:33.512659
# Unit test for function represent_undefined
def test_represent_undefined():
    data = dict(a=1, b=AnsibleUndefined(obj='c'))
    try:
        yaml.dump(data, Dumper=AnsibleDumper)
    except yaml.representer.RepresenterError:
        assert False, 'Answer representer failed'



# Generated at 2022-06-22 13:53:45.502414
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    my_dumper = yaml.dumper.SafeDumper
    my_dumper.add_representer(
        AnsibleVaultEncryptedUnicode,
        represent_vault_encrypted_unicode
    )

# Generated at 2022-06-22 13:53:48.328662
# Unit test for function represent_undefined
def test_represent_undefined():
    data = AnsibleUndefined()
    dumper = AnsibleDumper
    dumper.add_representer(AnsibleUndefined, represent_undefined)
    result = bool(data)
    assert(result)

# Generated at 2022-06-22 13:54:00.427666
# Unit test for function represent_unicode
def test_represent_unicode():
    data = dict(number=42, string='forty-two')
    data_unicode = dict(number=42, string=u'forty-two')
    data_mixed = dict(number=42, string=u'forty-two', string2=b'for\xc3\xa7i')

    # test unicode
    data_unicode_yaml = yaml.dump(data_unicode, Dumper=AnsibleDumper, default_flow_style=False)
    assert isinstance(data_unicode_yaml, text_type)
    assert 'forty-two' in data_unicode_yaml
    assert isinstance(data_unicode_yaml, text_type)

    # test not unicode

# Generated at 2022-06-22 13:54:03.213923
# Unit test for function represent_hostvars
def test_represent_hostvars():
    foo = HostVars(dict(bar='baz'))
    result = yaml.dump(foo, Dumper=AnsibleDumper)
    assert result == 'bar: baz\n'

# Generated at 2022-06-22 13:54:06.691499
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    undefined = AnsibleUndefined()
    assert dumper.represent_undefined(undefined) is False
    assert dumper.represent_undefined(True) is True

# Generated at 2022-06-22 13:54:10.753580
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    value = False
    result = dumper.represent_binary(value)
    assert result == u"!!binary ''"

    value = b"foo"
    result = dumper.represent_binary(value)
    assert result == u"!binary |\n  Zm9v"

# Generated at 2022-06-22 13:54:17.230622
# Unit test for function represent_binary
def test_represent_binary():
    # Action: Create a bytes object with some data in it, then indicate that we want to serialize it with AnsibleDumper
    # Expect: See a YAML | representation of the string
    # Ensure: The output is as expected

    test_data = b'Hello world'
    expected_output = u'|\n  SGVsbG8gd29ybGQ=\n'

    stream = yaml.emit(test_data, Dumper=AnsibleDumper)
    assert stream == expected_output



# Generated at 2022-06-22 13:54:26.436209
# Unit test for function represent_binary
def test_represent_binary():
    '''
    This test ensures that the data type of the object passed in is retained
    when the represent_binary function converts it to binary.

    This is important, else
    yaml.safe_dump(data, DefaultFlowStyle=False)
    will result in yaml.representer.RepresenterError: cannot represent an object: <memory at 0x7fae6c6066f8>

    See https://github.com/ansible/ansible/issues/28219

    '''
    data = AnsibleUnsafeBytes('hello world')
    binary_object = represent_binary(AnsibleDumper, data)
    assert isinstance(binary_object.value, binary_type)

# Generated at 2022-06-22 13:54:28.718879
# Unit test for function represent_undefined
def test_represent_undefined():
    assert isinstance(AnsibleDumper.represent_undefined(AnsibleDumper, AnsibleUndefined()), bool)

# Generated at 2022-06-22 13:54:40.375538
# Unit test for function represent_undefined
def test_represent_undefined():
    test_vars = {}
    test_vars['undef_bool'] = AnsibleUndefined(val_type='bool')
    test_vars['undef_str'] = AnsibleUndefined(val_type='str')
    test_vars['undef_int'] = AnsibleUndefined(val_type='int')
    test_vars['undef_real'] = AnsibleUndefined(val_type='real')
    test_vars['undef_none'] = AnsibleUndefined(val_type='none')

    # Trick to get test to pass, and not loop infinitely on !Undefined
    def my_error_func(value, *args, **kwargs):
        raise ValueError('my_error_func')


# Generated at 2022-06-22 13:54:43.742493
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert(yaml.round_trip_dump(HostVars({"name": "value"}), Dumper=AnsibleDumper) == '{name: value}\n')



# Generated at 2022-06-22 13:54:50.924681
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = HostVars()
    hostvars.add_host_vars('127.0.0.1', dict(foo='bar'))

    yaml_out = yaml.dump(hostvars, Dumper=AnsibleDumper)
    assert yaml_out == '---\n127.0.0.1:\n  foo: bar\n\n'

# Generated at 2022-06-22 13:55:02.004559
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Note: The test_unicode will fail if the class
    # AnsibleVaultEncryptedUnicode is not used to create
    # the AnsibleVaultEncryptedUnicode object
    test_data_1 = AnsibleVaultEncryptedUnicode(u'$ANSIBLE_VAULT;1.1;AES256;ansible\n3964343738366131733164623266633138613365333764353861636563376561383437353030346233310a62363966333130666330623333623664623731316535653137623935613830353865393164346330650a34613230356366373363336365616539396163326461656232306562336331646465666261643266\n')

# Generated at 2022-06-22 13:55:04.976554
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    result = dumper.represent_binary(dumper, b'w00t')
    assert result.value == b'w00t'



# Generated at 2022-06-22 13:55:13.615379
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # pylint: disable=unused-variable,unused-argument
    # we want to use the dumper to check if the representer is working
    def check(data, expected):
        dumper = ansible_dumper
        output = dumper.represent_hostvars(data)
        assert (output == expected)

    data = HostVars(
        {u'vars': u'a'},
        {u'vars': u'b'},
        {u'vars': u'c'},
        {u'vars': u'd'}
    )
    expected = yaml.representer.SafeRepresenter.represent_dict(None, dict(a='a', b='b', c='c', d='d'))
    check(data, expected)


# Generated at 2022-06-22 13:55:23.904220
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-22 13:55:28.655488
# Unit test for function represent_unicode
def test_represent_unicode():
    test = (b'\xF3\xA0\x80\x80',)
    assert yaml.safe_dump(test, Dumper=AnsibleDumper) == "['\\u00f38080']\n"

# Generated at 2022-06-22 13:55:39.902867
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()
    rep = represent_vault_encrypted_unicode(dumper,
                                            AnsibleVaultEncryptedUnicode(b'$ANSIBLE_VAULT;1.1;AES256\r\n6635346634323766633937623930313034356537366335393837653637616366633931366631633966\r\nb242270a31a26a66515e1cb9f1c5e5d52bd2b06f5ee538ab2cbc3b29add4476b\r\n'))

# Generated at 2022-06-22 13:55:44.809749
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hv = HostVars({'key1': 'value1'})
    out = yaml.dump(hv, Dumper=AnsibleDumper, default_flow_style=False)
    assert out == "key1: value1\n"



# Generated at 2022-06-22 13:55:49.175279
# Unit test for function represent_undefined
def test_represent_undefined():
    # When we want to test the representation of AnsibleUndefined, we can't
    # pickle the object, so we need another one that has an empty 'data'
    # attribute.  The same goes for other classes like this one.
    class Undefined:
        def __init__(self, obj=None):
            pass

        def __getstate__(self):
            return {}

        def __setstate__(self, state):
            pass

    class TestVars(HostVars):
        def __init__(self, hostvars=None):
            pass

        def __getstate__(self):
            return {}

        def __setstate__(self, state):
            pass

    class TestVarsVars(HostVarsVars):
        def __init__(self, hostvars=None):
            pass


# Generated at 2022-06-22 13:55:53.327463
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import StrictUndefined
    from ansible.parsing.yaml.dumper import AnsibleDumper

    dumper = AnsibleDumper()
    assert dumper.represent_undefined(StrictUndefined()) == bool(StrictUndefined())

# Generated at 2022-06-22 13:55:55.834920
# Unit test for function represent_hostvars
def test_represent_hostvars():
    v = HostVars(vars={'a': 'b'})
    dump = yaml.dump(v, Dumper=AnsibleDumper)
    assert dump == '{a: b}\n...\n'

# Generated at 2022-06-22 13:56:07.867574
# Unit test for function represent_binary
def test_represent_binary():
    dump = yaml.dump(
        AnsibleUnsafeBytes(b'test'),
        Dumper=AnsibleDumper,
        default_flow_style=False,
    )
    # Yamllint is quite sensitive to indentation.
    # pylint: disable=no-member
    assert dump == '!!binary "dGVzdA==\n"'
    dump = yaml.dump(
        AnsibleUnsafeBytes(b'test'),
        Dumper=AnsibleDumper,
        default_flow_style=True,
    )
    assert dump == '!!binary "dGVzdA==\n"'
    # Ensure it can be loaded again.
    # pylint: disable=unnecessary-lambda
    data = yaml.load(dump)
    assert data == b'test'



# Generated at 2022-06-22 13:56:12.192173
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper([])
    result = dumper.represent_unicode(u'test')
    assert result == u'test'

    result = dumper.represent_unicode(None)
    assert result == u'null'



# Generated at 2022-06-22 13:56:16.355598
# Unit test for function represent_unicode
def test_represent_unicode():
    res = represent_unicode(AnsibleDumper, AnsibleUnicode('abc'))
    assert res == u'"abc"\n'
    res = represent_unicode(AnsibleDumper, AnsibleUnsafeText(u'\u2219'))
    assert res == u'u"\\u2219"\n'



# Generated at 2022-06-22 13:56:27.110811
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 13:56:32.473216
# Unit test for function represent_hostvars
def test_represent_hostvars():
    import ansible.constants as C

    C.HOST_VAR_METHOD = 'vars'
    host_var_manager = HostVars(load_vars=False)
    host_var_manager.update({'foo': 'bar'})

    import json
    assert json.dumps(host_var_manager, cls=AnsibleDumper) == '{"foo": "bar"}'



# Generated at 2022-06-22 13:56:39.118899
# Unit test for function represent_unicode
def test_represent_unicode():
    data = AnsibleUnicode("Foo")
    ret = yaml.dump(data, Dumper=AnsibleDumper)
    assert ret == "Foo\n...\n"



# Generated at 2022-06-22 13:56:49.124664
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    """
    Unit test for function represent_vault_encrypted_unicode
    """
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
    from cryptography.hazmat.backends import default_backend
    from ansible.parsing.vault import VaultLib

    # setup a base64 encoded AES256 key
    # python3 -c "import binascii; import os; print(binascii.b2a_base64(os.urandom(32)).strip())"
    b64_key = b'xTXgCvoe2Ej+8LRyJh1zgTt+jS1E7BGP9Z2QJx3q4b4='

    # encrypting a unicode object
    un

# Generated at 2022-06-22 13:56:53.285930
# Unit test for function represent_unicode
def test_represent_unicode():
    data = AnsibleUnicode(u'foo')
    dumper = yaml.representer.SafeRepresenter()
    result = represent_unicode(dumper, data)
    assert result == u'foo\n...\n'



# Generated at 2022-06-22 13:56:58.207545
# Unit test for function represent_undefined
def test_represent_undefined():
    data = AnsibleUndefined()
    result = yaml.dump([data], default_flow_style=False, Dumper=AnsibleDumper)
    assert '[null]' in result
    data = AnsibleUndefined("foo")
    result = yaml.dump([data], default_flow_style=False, Dumper=AnsibleDumper)
    assert '[null]' in result

# Generated at 2022-06-22 13:57:01.442991
# Unit test for function represent_binary
def test_represent_binary():
    # Some binary data which is not valid utf-8
    binary_data = "Arta\xe4nger".encode('iso-8859-15')
    assert yaml.dump(binary_data, Dumper=AnsibleDumper) == '!!binary "QXJ0YcO2bmdlcg==\n"\n'

# Generated at 2022-06-22 13:57:09.082745
# Unit test for function represent_hostvars
def test_represent_hostvars():
    s = [text_type(u'foo'), text_type(u'bar')]

    class Foo(HostVars):
        pass

    foo = Foo(s)
    assert (
        yaml.dump(foo, Dumper=AnsibleDumper).replace('\n', '').replace('  ', '') ==
        text_type("!!python/object/apply:ansible.module_utils.common.yaml.objects.HostVars - - foo - bar")
    )



# Generated at 2022-06-22 13:57:10.928884
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode(b'foobar'), Dumper=AnsibleDumper) == u"foobar\n..."

# Generated at 2022-06-22 13:57:15.622672
# Unit test for function represent_undefined
def test_represent_undefined():
    """Ensure AnsibleUndefined is properly represented.

    This is done by calling AnsibleUndefined.__bool__ which will
    result in an exception being raised if it is not correctly
    represented.
    """
    AnsibleUndefined() # no exception



# Generated at 2022-06-22 13:57:25.151431
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    ''' verify that vault encrypted unicode is represented correctly '''

    # create a dummy object to represent

# Generated at 2022-06-22 13:57:28.474009
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    data = AnsibleUndefined('hello world')
    result = dumper.represent_data(data)
    assert result == "hello world"

# Generated at 2022-06-22 13:57:39.072994
# Unit test for function represent_binary
def test_represent_binary():
    # This tests a bug in pyYAML where the UTF-8 indicator is added to the
    # output if the string only contains ASCII characters.
    payload = 'foo: !binary |\n    SGVsbG8sIHdvcmxk\n'
    assert yaml.dump(dict(foo=b'Hello, world'), Dumper=AnsibleDumper).split('\n') == [payload.replace(',', '')]

# Generated at 2022-06-22 13:57:48.140931
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    data = b'aGVsbG8gd29ybGQK'
    data = AnsibleUnsafeBytes(data)
    templar = Templar(host_list=['test'], variables=VariableManager(), loader=None, shared_loader_obj=None, context=PlayContext())
    templar.set_available_variables({'var': data})
    # In python 2 and python 3, we need to encode data as 'utf-8'
    test_data = {'var': 'aGVsbG8gd29ybGQK'}
    assert(represent_hostvars(None, templar.available_variables) == test_data)




# Generated at 2022-06-22 13:57:51.054605
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert AnsibleUndefined('foo') == dumper.represent_data(AnsibleUndefined('foo'))

# Generated at 2022-06-22 13:57:56.168446
# Unit test for function represent_binary
def test_represent_binary():
    import base64
    dumper = AnsibleDumper()
    # base64.b64encode returns bytes
    b64str = base64.b64encode(b'\xde\xad\xbe\xef')
    assert dumper.represent_binary(b'\xde\xad\xbe\xef') == b'!!binary |-\n  ' + b64str



# Generated at 2022-06-22 13:58:04.462858
# Unit test for function represent_unicode
def test_represent_unicode():
    from io import StringIO
    from ansible.parsing.yaml.dumper import AnsibleUnicode

    yaml_str = u'test: this is a test'
    yaml_unicode = AnsibleUnicode(yaml_str)

    stream = StringIO()
    AnsibleDumper.add_representer(
        AnsibleUnicode,
        represent_unicode
    )
    AnsibleDumper(stream=stream, default_flow_style=False).represent(yaml_unicode)
    result = stream.getvalue()

    assert result == yaml_str + "\n...\n"

# Generated at 2022-06-22 13:58:06.739783
# Unit test for function represent_binary
def test_represent_binary():
    output = yaml.dump(dict(a='1234'), Dumper=AnsibleDumper)
    assert '1234' in output



# Generated at 2022-06-22 13:58:13.122459
# Unit test for function represent_undefined
def test_represent_undefined():
    representer = AnsibleDumper.yaml_representers[AnsibleUndefined]
    # Here bool will ensure _fail_with_undefined_error happens
    # if the value is Undefined.
    # This happens because Jinja sets __bool__ on StrictUndefined
    assert representer.represent_data(AnsibleUndefined(fail_on_undefined=True))
    assert representer.represent_data(AnsibleUndefined())

# Generated at 2022-06-22 13:58:16.450095
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper(None)
    assert dumper.represent_data(AnsibleUndefined()) == 'undefined_variable_or_function'


# Generated at 2022-06-22 13:58:18.247469
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()
    x = AnsibleVaultEncryptedUnicode('ciphertext')
    dumper.represent_data(x)

# Generated at 2022-06-22 13:58:21.680963
# Unit test for function represent_unicode
def test_represent_unicode():
    from inspect import getsourcefile
    from os.path import abspath, dirname, join
    assert abspath(getsourcefile(test_represent_unicode)) == abspath(
        join(dirname(__file__), 'yaml.py'))
    assert represent_unicode(None, AnsibleUnicode('foo')) == u"foo"

