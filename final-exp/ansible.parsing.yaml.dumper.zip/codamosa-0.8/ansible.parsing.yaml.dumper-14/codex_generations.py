

# Generated at 2022-06-22 13:51:07.337491
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert represent_hostvars(AnsibleDumper, HostVars(dict(k1='v1', k2='v2'))) == represent_hostvars(AnsibleDumper, dict(k1='v1', k2='v2'))


# Generated at 2022-06-22 13:51:18.866220
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence

    dumper = AnsibleDumper(default_flow_style=False)

    # Testing empty and simple cases
    assert dumper.represent_hostvars(HostVars()) == dumper.represent_dict({'__ansible_vars': {}})
    assert dumper.represent_hostvars(HostVars({'k1': 'v1'})) == dumper.represent_dict({'__ansible_vars': {'k1': 'v1'}})

    # Testing complex cases

# Generated at 2022-06-22 13:51:29.765160
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper(width=999999)
    if dumper.represent_undefined(AnsibleUndefined('')) is False:
        pass


yaml.add_representer(
    AnsibleUnicode,
    represent_unicode,
    Dumper=AnsibleDumper,
)

yaml.add_representer(
    AnsibleUnsafeText,
    represent_unicode,
    Dumper=AnsibleDumper,
)

yaml.add_representer(
    AnsibleUnsafeBytes,
    represent_binary,
    Dumper=AnsibleDumper,
)

yaml.add_representer(
    HostVars,
    represent_hostvars,
    Dumper=AnsibleDumper,
)


# Generated at 2022-06-22 13:51:33.127203
# Unit test for function represent_binary
def test_represent_binary():
    data = b'\x00\x01\x02\x03'
    dumper = AnsibleDumper()
    result = dumper.represent_binary(data)
    assert result == "!!binary |\n  AAECA\n"

# Generated at 2022-06-22 13:51:41.092415
# Unit test for function represent_unicode
def test_represent_unicode():
    test_yaml = '''\
        ---
        - a
        - b
        '''
    test_data = ''
    data = yaml.safe_load(test_yaml)
    assert(data == [u'a', u'b'])
    test_data = yaml.dump_all(data, Dumper=AnsibleDumper)
    assert(test_data == test_yaml)
    test_data = yaml.dump_all([data[0]], Dumper=AnsibleDumper)
    assert(test_data == '''\
- a
''')

    assert(yaml.dump_all([u'a', u'b'], Dumper=AnsibleDumper) == test_yaml)



# Generated at 2022-06-22 13:51:52.885149
# Unit test for function represent_unicode
def test_represent_unicode():

    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == "foo"
    assert dumper.represent_unicode(u'\x00\x01\x02\x03') == "\x00\x01\x02\x03"
    assert dumper.represent_unicode(u'\u8001') == "\u8001"
    assert dumper.represent_unicode(u'\uff61') == "\uff61"
    assert dumper.represent_unicode(u'\uff63') == "\uff63"
    assert dumper.represent_unicode(u'\uff9f') == "\uff9f"
    assert dumper.represent_unicode(u'\U0001d121') == "\U0001d121"

# Generated at 2022-06-22 13:51:56.346664
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper.represent_undefined(AnsibleDumper(None), AnsibleUndefined) is False
    assert AnsibleDumper.represent_undefined(AnsibleDumper(None), True)



# Generated at 2022-06-22 13:52:01.530831
# Unit test for function represent_unicode
def test_represent_unicode():
    assert(yaml.dump(u'example') == yaml.dump(AnsibleUnicode(u'example')))
    assert(yaml.dump(u"line\nbreaks") == yaml.dump(AnsibleUnicode(u"line\nbreaks")))



# Generated at 2022-06-22 13:52:05.247395
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(b'0' + b'\xff' * 50000) == u'!!binary |\n' + b'0' + b'\xff' * 50000 + b'\n'

# Generated at 2022-06-22 13:52:09.815103
# Unit test for function represent_binary
def test_represent_binary():
    data = AnsibleUnsafeBytes('hello world')
    output = yaml.dump(data, Dumper=AnsibleDumper, default_flow_style=False)
    assert output == "!!binary |\n  aGVsbG8gd29ybGQ=\n"



# Generated at 2022-06-22 13:52:15.152551
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    data = b'hello'
    assert dumper.represent_binary(data) == u'hello'

# Generated at 2022-06-22 13:52:19.788451
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hv = HostVars('test_host', dict(test_key='test_value'))
    yaml_output = yaml.dump(hv, Dumper=AnsibleDumper)
    expected_output = "test_host:\n  test_key: test_value\n"
    assert yaml_output == expected_output



# Generated at 2022-06-22 13:52:27.614525
# Unit test for function represent_hostvars
def test_represent_hostvars():

    class TestRepresentHostVars(object):
        def __init__(self, data):
            self.data = data
        def __getitem__(self, name):
            return self.data[name]

    my_data = TestRepresentHostVars({'test':'test'})
    expected = yaml.representer.SafeRepresenter.represent_dict(my_data)
    actual = represent_hostvars(None, my_data)
    assert expected == actual

# Generated at 2022-06-22 13:52:33.183760
# Unit test for function represent_hostvars
def test_represent_hostvars():

    assert represent_hostvars(AnsibleDumper, HostVars(**{'foo': 'bar'})) == "!!python/object/apply:ansible.vars.hostvars.HostVars foo='bar'"
    print(represent_hostvars(AnsibleDumper, HostVars(**{'foo': 'bar'})))

# Generated at 2022-06-22 13:52:38.812625
# Unit test for function represent_undefined
def test_represent_undefined():
    AnsibleDumper.add_representer(
        AnsibleUndefined,
        represent_undefined,
    )
    import jinja2
    from ansible.template import AnsibleUndefined
    env = jinja2.Environment()
    tmpl = env.from_string('{{ foo }}')
    assert(tmpl.render(foo=AnsibleUndefined) == '')

# Generated at 2022-06-22 13:52:40.723817
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(AnsibleDumper, 'hello') == u"u'hello'"



# Generated at 2022-06-22 13:52:47.213906
# Unit test for function represent_unicode
def test_represent_unicode():
    data = AnsibleUnicode(u'test')
    assert yaml.dump(data, Dumper=AnsibleDumper).strip() == "test"
    data = AnsibleUnicode(u'test\u2063\u2063')
    assert yaml.dump(data, Dumper=AnsibleDumper).strip() == "test\u2063\u2063"



# Generated at 2022-06-22 13:52:48.567792
# Unit test for function represent_unicode
def test_represent_unicode():
    result = represent_unicode(None, u'foo')
    assert result == u"'foo'"

# Generated at 2022-06-22 13:53:00.596996
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultEditor
    from ansible.module_utils.common.yaml import AnsibleDumper
    d = AnsibleDumper()

    vault = VaultEditor(None)
    ciphertext = vault._encrypt_bytes(b'plaintext')
    data = AnsibleVaultEncryptedUnicode(ciphertext)

    # expected: !vault |
    #           $ANSIBLE_VAULT;1.1;AES256
    #           6436356630353766393932356630386266316562366634333461336330633135326130363739363861
    #           316437323939653038346662643862316461386

# Generated at 2022-06-22 13:53:10.012676
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = HostVars('test.example.com')
    data['var1'] = ['this is a list', 'of items', 'to test with']
    data['var2'] = dict(var1='this is a dict', var2='of items', var3='to test with')
    data['var3'] = 'this is a string'
    data['var4'] = AnsibleUnicode('this is a unicode object')
    data['var5'] = AnsibleUnsafeBytes('this is a byte object')
    data['var6'] = AnsibleUnsafeText('this is a text object')


# Generated at 2022-06-22 13:53:13.221800
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.dump(AnsibleUndefined()) == 'null\n...\n'

# Generated at 2022-06-22 13:53:15.889474
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert yaml.dump(HostVars({'test': 'success'}), Dumper=AnsibleDumper) == '{test: success}\n'



# Generated at 2022-06-22 13:53:19.297853
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper.represent_undefined is represent_undefined
    assert yaml.dump(
        AnsibleUndefined(),
        Dumper=AnsibleDumper,
        default_flow_style=False
    ) == "False"



# Generated at 2022-06-22 13:53:29.282645
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()

    # Prevent test failures due to different yaml constructor in PyYAML 4.1
    yaml.representer.SafeRepresenter.add_representer(
        AnsibleUndefined,
        yaml.representer.SafeRepresenter.represent_str,
    )

    try:
        dumper.serialize(AnsibleUndefined())
    except yaml.representer.RepresenterError:
        pass
    else:
        raise Exception('AnsibleUndefined obj should have failed serialize')


if __name__ == "__main__":
    test_represent_undefined()

# Generated at 2022-06-22 13:53:38.225740
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()
    data = 'my secret text'
    data = AnsibleVaultEncryptedUnicode(data)
    result = dumper.represent(data)
    assert isinstance(result.value, text_type)

# Generated at 2022-06-22 13:53:41.197433
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    result = dumper.represent_binary(binary_type(b'foo'))
    assert result == u"!binary \\\n  Zm9v"

# Generated at 2022-06-22 13:53:52.232340
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

    # Test if ciphertext is properly set
    ciphertext = '$ANSIBLE_VAULT;1.1;AES256'
    ciphertext += '\n6641333837643033366236376236656465323362616365326339333234633931376434613663'
    ciphertext += '\n\n66643538666436306637313666343538663363306637316466333031\n'
    ciphertext += '66373138663730646634373066373230663732386637303566373034663635316637333766373136'

# Generated at 2022-06-22 13:53:57.394667
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    data = AnsibleUndefined

    # If we don't mock _fail_with_undefined_error
    # this will cause a stack trace
    dumper._fail_with_undefined_error = lambda *args: None
    assert dumper.represent_undefined(data)



# Generated at 2022-06-22 13:54:07.401725
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    obj = VaultLib(b"vaultpassword")
    data = obj.dump(text_type('value'))
    repr = AnsibleDumper().represent_vault_encrypted_unicode(data)

# Generated at 2022-06-22 13:54:10.235051
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper(width=40)
    encrypted = AnsibleVaultEncryptedUnicode('test')
    assert dumper.represent_vault_encrypted_unicode(encrypted) == dumper.represent_scalar(u'!vault', 'test', style='|')

# Generated at 2022-06-22 13:54:15.510208
# Unit test for function represent_undefined
def test_represent_undefined():
    undefined = AnsibleUndefined('message')
    o = AnsibleDumper.represent_undefined(undefined)
    assert o is False


# Generated at 2022-06-22 13:54:20.715049
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    dumper.add_representer(AnsibleUndefined, represent_undefined)
    assert not dumper.represent_data(AnsibleUndefined())
    # Here we don't want the test to fail for undefined value,
    # because we want to test the representer function
    dumper.ignore_aliases = True
    assert not dumper.represent_data(AnsibleUndefined())

# Generated at 2022-06-22 13:54:28.328728
# Unit test for function represent_binary
def test_represent_binary():
    # Test the function represent_binary

    # Here the function represent_binary will output the original data
    # when the data contains characters from 0x00 to 0x7f

    # Define a string
    string = 'abc'

    # Define a bytes
    bytes = b'abc'

    # Dump the string
    string_dumped = yaml.dump(string)

    # Dump the bytes
    bytes_dumped = yaml.dump(bytes)

    # Compare the dumped string and dumped bytes
    assert (string_dumped == bytes_dumped)

    # Here the function represent_binary will use hex to represent data
    # when the data contains characters beyond 0x7f

    # Define a string
    string = '\x80'

    # Define a bytes
    bytes = b'\x80'

    # D

# Generated at 2022-06-22 13:54:34.713739
# Unit test for function represent_undefined
def test_represent_undefined():
    import os
    import sys
    import json

    # Python on Windows doesn't have the same objects as Linux so we
    # can't import the same class. We try to import the class but only
    # raise an AssertionError if the class does not exist.
    try:
        # Python3
        from types import SimpleNamespace

        class Undefined(SimpleNamespace):
            def __bool__(self):
                return False
    except ImportError:
        # Python2
        from ansible.template import StrictUndefined as Undefined

    assert Undefined("foo") is not None
    assert Undefined("foo").__bool__() is False

    AnsibleUndefined.__bool__ = Undefined("foo").__bool__
    AnsibleUndefined.__nonzero__ = Undefined("foo").__bool__
    AnsibleUndefined.__

# Generated at 2022-06-22 13:54:41.624913
# Unit test for function represent_binary
def test_represent_binary():
    b = b'\x80\x03X\x04\x00\x00\x00testq\x00.'

    # data is bytes
    assert yaml.dump(b'\x80\x03X\x04\x00\x00\x00testq\x00.') == '!!binary |\n  gICAgAB0ZXN0cQ==\n'

    # data is str
    assert yaml.dump('hello world') == 'hello world\n'



# Generated at 2022-06-22 13:54:44.410191
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper(None)
    assert dumper.represent_data(AnsibleUndefined()) == 'null'

# Generated at 2022-06-22 13:54:47.528031
# Unit test for function represent_binary
def test_represent_binary():
    assert None == AnsibleDumper.represent_binary(None, None)

# Generated at 2022-06-22 13:54:50.471545
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper(None, None, None)
    assert not dumper.represent_undefined(None)



# Generated at 2022-06-22 13:54:55.671117
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = yaml.Dumper(width=80)

    hostvars = HostVars(vars={'test_var': 'test_val'}, vault_vars={'test_vault_var': 'test_vault_val'})
    hostvars_parsed = yaml.safe_load(yaml.dump(hostvars, Dumper=AnsibleDumper, width=80))
    assert isinstance(hostvars_parsed, dict)



# Generated at 2022-06-22 13:55:00.935857
# Unit test for function represent_undefined
def test_represent_undefined():
    with open("/tmp/ansible_represent_undefined_test.yaml", "w") as f:
        yaml.dump(AnsibleUndefined("BugReport"), stream=f, Dumper=AnsibleDumper)
    with open("/tmp/ansible_represent_undefined_test.yaml", "r") as f:
        content = f.read()
        assert content == ""

# Generated at 2022-06-22 13:55:07.070064
# Unit test for function represent_hostvars
def test_represent_hostvars():
    a = {'a': '1'}
    assert represent_hostvars(None, HostVars(a)) == represent_hostvars(None, HostVarsVars(a)) == represent_hostvars(None, VarsWithSources(a))

# Generated at 2022-06-22 13:55:13.985003
# Unit test for function represent_hostvars
def test_represent_hostvars():

    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.vars.manager import VariableManager

    sample = dict(
        a=1,
        b=2,
        c=3,
    )

    # Make sure we wrap it in VariableManager so we get a HostVars object
    sample = VariableManager().add_host_vars("host1", sample)

    result = yaml.dump(sample, Dumper=AnsibleDumper)
    # Note: using safe_dump so it doesn't end up with "!!python/object:..."
    assert result == yaml.safe_dump(dict(sample), default_flow_style=False)



# Generated at 2022-06-22 13:55:17.081255
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = HostVars(dict(k1='v1'))
    dumper = AnsibleDumper()

# Generated at 2022-06-22 13:55:22.718608
# Unit test for function represent_hostvars
def test_represent_hostvars():
    sample_hostvars = dict(
        a=1,
        b=2,
        c=3
    )

    hostvars = HostVars(hostvars=sample_hostvars, module_vars=sample_hostvars)

    assert hostvars == sample_hostvars

    hostvars_yaml = yaml.dump(hostvars, Dumper=AnsibleDumper, default_flow_style=False)
    assert hostvars_yaml == yaml.dump(sample_hostvars, Dumper=AnsibleDumper, default_flow_style=False)



# Generated at 2022-06-22 13:55:34.010490
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.module_utils.common.yaml import from_yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.hostvars import HostVars
    assert _data_structure_equality(from_yaml('{foo: bar}'),
                                    HostVars(AnsibleMapping(foo='bar')))
    assert _data_structure_equality(from_yaml('{foo: bar}'),
                                    HostVarsVars(AnsibleMapping(foo='bar')))
    assert _data_structure_equality(from_yaml('{foo: bar}'),
                                    VarsWithSources(AnsibleMapping(foo='bar')))



# Generated at 2022-06-22 13:55:41.749191
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # 1. Simple hostvars with no magic
    data = HostVars(vars=dict(a=dict(b=1, c=2, d=3)),
                    hostvar_sources=['foo'],
                    pre_tasks=['bar'])
    assert yaml.dump(data, Dumper=AnsibleDumper) == 'a:\n  b: 1\n  c: 2\n  d: 3\n'

    # 2. hostvars with magic
    data = HostVars(vars=dict(a=dict(b=1, c=2, d=3)),
                    hostvar_sources=['foo'],
                    pre_tasks=['bar'])

# Generated at 2022-06-22 13:55:45.835120
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = HostVars(dict(foo='bar'))
    assert hostvars.foo == 'bar'
    data = AnsibleDumper().represent_hostvars(hostvars)

    assert data == 'foo: bar\n'



# Generated at 2022-06-22 13:55:56.097749
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hv = HostVars()
    d = hv.to_dict()
    hv['a'] = 10
    d['a'] = 10

    s = yaml.dump(d, Dumper=AnsibleDumper)
    s2 = yaml.dump(hv, Dumper=AnsibleDumper)

    assert s == s2
    assert s == "a: 10\n"

    hv['c'] = AnsibleUnicode('hello')
    d['c'] = text_type('hello')

    s = yaml.dump(d, Dumper=AnsibleDumper)
    s2 = yaml.dump(hv, Dumper=AnsibleDumper)

    assert s == s2
    assert s == "a: 10\nc: hello\n"


# Generated at 2022-06-22 13:56:08.265707
# Unit test for function represent_hostvars
def test_represent_hostvars():
    h = HostVars()
    h.data = {'a': '1', 'b': '2'}
    h.add_host('hosta')
    h.add_host('hostb')
    h.add_host('hostc')
    h.set_variable('a', '1', 'hosta')
    h.set_variable('b', '2', 'hostb')
    h.set_variable('b', '3', 'hostc')
    assert represent_hostvars(AnsibleDumper, h) == '{a: 1, b: 3}'
    # The 'hosta' and 'hostb' entries are included because they are
    # in the HostVars object (data).
    h.remove_host('hostb')
    assert represent_hostvars(AnsibleDumper, h)

# Generated at 2022-06-22 13:56:16.152187
# Unit test for function represent_hostvars
def test_represent_hostvars():
    obj = HostVars({})
    assert yaml.dump(obj, Dumper=AnsibleDumper) == '{}\n...\n'
    obj = HostVars({'item1': 'value1'})
    assert yaml.dump(obj, Dumper=AnsibleDumper) == 'item1: value1\n...\n'
    assert type(yaml.load(yaml.dump(obj, Dumper=AnsibleDumper), Loader=yaml.SafeLoader)) is dict