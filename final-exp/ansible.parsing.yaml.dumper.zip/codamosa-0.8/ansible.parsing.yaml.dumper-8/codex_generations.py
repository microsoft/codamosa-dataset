

# Generated at 2022-06-22 13:51:05.433390
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper(width=9999)
    data = b"\x01\x02\x03\x04"
    assert dumper.represent_binary(data) == "!!binary |\n  AQIDBA==\n"



# Generated at 2022-06-22 13:51:12.555963
# Unit test for function represent_binary
def test_represent_binary():
    representer = AnsibleDumper()
    test_data = b'This\nThat\rOther'
    test_result = representer.represent_binary(test_data)
    test_expected = ('!!binary |\n'
                     '  VGhpcyBUaGF0IE90aGVyCg==')
    assert test_result == test_expected



# Generated at 2022-06-22 13:51:16.698161
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

    assert dumper.represent_binary("\x00\xff") == "!!binary |\n  AA8=\n"
    assert dumper.represent_binary("\xa3") == "!!binary |\n  oQ==\n"

# Generated at 2022-06-22 13:51:19.978212
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    dumped = dumper.represent_undefined(AnsibleUndefined(strict=True, obj='foo', meth_name='bar'))
    assert dumped == "AnsibleUndefinedVariable: 'foo' (bar)"



# Generated at 2022-06-22 13:51:28.225828
# Unit test for function represent_binary
def test_represent_binary():

    # empty string
    dumper = AnsibleDumper
    result = dumper.represent_binary(dumper, '')
    assert result == u'!!binary ""'

    # string with special character
    dumper = AnsibleDumper
    result = dumper.represent_binary(dumper, '\t\n')
    assert result == u'!!binary "\\t\\n"'

    # string with unicode character
    dumper = AnsibleDumper
    result = dumper.represent_binary(dumper, u'\u0623')
    assert result == u'!!binary "\\u0623"'



# Generated at 2022-06-22 13:51:37.746997
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # Test HostVars type
    hostvars = HostVars(host=None)
    hostvars.get = lambda: {'a': '1'}
    assert yaml.dump({'x': hostvars}, Dumper=AnsibleDumper) == '{x: {a: 1}}'

    # Test HostVarsVars type
    hostvarsvars = HostVarsVars(name='x', host=None)
    hostvarsvars.get = lambda: {'a': '1'}
    assert yaml.dump({'x': hostvarsvars}, Dumper=AnsibleDumper) == '{x: {a: 1}}'

    # Test VarsWithSources type
    vars_with_sources = VarsWithSources({'a': '1'}, [])

# Generated at 2022-06-22 13:51:40.381859
# Unit test for function represent_undefined
def test_represent_undefined():
    r = AnsibleDumper(None)
    r.represent_undefined(AnsibleUndefined("test_represent_undefined"))



# Generated at 2022-06-22 13:51:52.307810
# Unit test for function represent_unicode
def test_represent_unicode():
    # Test string
    u = u'\x80abc'

    # Test with SafeRepresenter
    """
    We can't use normal representation for this type
    because the constructor of SafeRepresenter uses
    yaml.representer.SafeRepresenter.represent_str
    type(self.represent_str) == <type 'builtin_function_or_method'>
    """
    ansible_dumper = AnsibleDumper
    actual_yaml = ansible_dumper.represent_unicode(ansible_dumper, u)
    expected_yaml = u'!!python/unicode \'\\x80abc\''

    assert actual_yaml == expected_yaml

    # Test with yaml.representer.SafeRepresenter
    yaml_dumper = yaml.representer.SafeRepresenter
    actual_yaml = yaml

# Generated at 2022-06-22 13:52:03.571484
# Unit test for function represent_unicode
def test_represent_unicode():
    yaml.add_representer(
        AnsibleUnicode,
        represent_unicode
    )
    value = u'The\x95quick\x92brown\x92fox\x92jumped\x92over\x92the\x92lazy\x92dog'
    data = AnsibleUnicode(value)
    # By default AnsibleUnicode converts the value to a string with the
    # exception of when it is a single character, in which case it returns a
    # character.
    assert yaml.dump(data, Dumper=yaml.SafeDumper) == u'{0}\n'.format(value)
    assert yaml.dump(u'b', Dumper=yaml.SafeDumper) == u'b\n'

# Generated at 2022-06-22 13:52:09.641851
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():

    # Create data
    data = AnsibleVaultEncryptedUnicode('test')

    # Run function
    a = AnsibleDumper.represent_vault_encrypted_unicode(AnsibleDumper, data)

    # Verify result
    assert (a[0] == '!vault ')
    assert (a[1] == 'test')
    assert (a[2] == {'style': '|'})

# Generated at 2022-06-22 13:52:17.608928
# Unit test for function represent_undefined
def test_represent_undefined():
    instance = AnsibleDumper()
    # SafeDumper has default representer for bool
    assert instance.represent_bool(False) == instance.represent_scalar(u'tag:yaml.org,2002:bool', u'false')
    # SafeDumper has no default representer for AnsibleUndefined
    assert instance.represent_undefined(AnsibleUndefined()) is True

# Generated at 2022-06-22 13:52:22.261481
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    obj = AnsibleVaultEncryptedUnicode('ciphertext', 'plaintext')
    assert represent_vault_encrypted_unicode(AnsibleDumper, obj) == '!vault |\n  Y2lwaGVydGV4dAo='



# Generated at 2022-06-22 13:52:28.039294
# Unit test for function represent_binary
def test_represent_binary():

    # Create a binary unicode string with some
    test_string = u"\U0001F60E"

    # Create an AnsibleDumper instance
    ad = AnsibleDumper()

    # Assert the proper representation
    assert ad.represent_binary(test_string) == "!!binary |-\n  4pyQ4p2i\n"

# Generated at 2022-06-22 13:52:31.842831
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(u'this is a test') == u'this is a test\n...\n'
    assert yaml.dump(u'user@\xc4\x85') == u'user@\xc4\x85\n...\n'
    assert yaml.dump(u'this is a test\u2603') == u'this is a test\u2603\n...\n'  # Snowman
    assert yaml.dump(u'\n\n\u2603') == u'\n\n\u2603\n...\n'

# Generated at 2022-06-22 13:52:43.215588
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    ciphertext = b'$ANSIBLE_VAULT;1.1;AES256\n' \
                 b'613434383539663864356637633961643464353465326438623132303265343533623337653461\n' \
                 b'3239333765653739356530343039643264653765333938343831366303266363631316532363735\n' \
                 b'653038613036623037376562306266353766653133346664353634383334666465633064333264\n' \
                 b'656431623130353862643837353632643236333738623037373130393932303031363734313166\n' \
                

# Generated at 2022-06-22 13:52:53.170833
# Unit test for function represent_hostvars
def test_represent_hostvars():
    """
    AnsibleDumper.represent_hostvars() should convert the HostVars object to
    dict, if dict is passed as params, represent_hostvars should work same
    as represent_dict.
    """
    hostvars = HostVars('dummy')
    representer = yaml.representer.SafeRepresenter()
    representer.represent_hostvars(hostvars)
    hostvars.set_variable('var_name', 'var_value')
    data = dict(hostvars)
    assert representer.represent_hostvars(data) == representer.represent_dict(data)



# Generated at 2022-06-22 13:52:58.842724
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(b'hello', Dumper=AnsibleDumper) == "!!binary |\n  aGVsbG8=\n"
    assert yaml.dump(b'hello', default_flow_style=True, Dumper=AnsibleDumper) == "!!binary 'aGVsbG8='"



# Generated at 2022-06-22 13:53:02.227880
# Unit test for function represent_hostvars
def test_represent_hostvars():

    from ansible.module_utils.common.yaml import AnsibleDumper

    c = HostVars()
    c['a'] = 'foo'
    c['b'] = {'c': 'bar'}

    assert yaml.dump(c, Dumper=AnsibleDumper) == '---\na: foo\nb:\n  c: bar\n', "Representer function represent_hostvars failed"



# Generated at 2022-06-22 13:53:08.395189
# Unit test for function represent_binary
def test_represent_binary():
    # All values are converted to bytes before being represented
    input_values = [
        b'123',
        123,
        '123',
        u'123',
        [1, 2, 3],
        (1, 2, 3)
    ]
    expected_values = [
        b'123',
        b'{}',
        b'123',
        b'123',
        b'[1, 2, 3]',
        b'{1, 2, 3}'
    ]
    for (input_value, expected_value) in zip(input_values, expected_values):
        assert AnsibleDumper.represent_binary(input_value) == expected_value

# Generated at 2022-06-22 13:53:13.560861
# Unit test for function represent_binary
def test_represent_binary():
    represent_binary_test = AnsibleDumper.representers[binary_type]
    assert represent_binary_test(AnsibleDumper, b"\x00\xff") == "!!binary |\n  AA8=\n"

# Generated at 2022-06-22 13:53:19.463230
# Unit test for function represent_unicode
def test_represent_unicode():
    assert dict(yaml.load(text_type(AnsibleUnicode(u'hi\u2026')))) == dict(yaml.load(yaml.safe_dump(u'hi\u2026')))



# Generated at 2022-06-22 13:53:24.061753
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = AnsibleDumper.represent_hostvars(None, HostVars({'a': 'b'}))
    assert data == u'{a: b}\n'



# Generated at 2022-06-22 13:53:35.243793
# Unit test for function represent_undefined

# Generated at 2022-06-22 13:53:40.566166
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = yaml.Dumper(allow_unicode=True)
    dumper.add_representer(
        AnsibleUnicode,
        represent_unicode,
    )
    dumped = yaml.dump(AnsibleUnicode('foo'), dumper)
    assert dumped == 'foo\n...\n'

# Generated at 2022-06-22 13:53:44.649173
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    data = u'Test String'
    assert yaml.representer.SafeRepresenter.represent_str(dumper, text_type(data)) == represent_unicode(dumper, data)



# Generated at 2022-06-22 13:53:49.346495
# Unit test for function represent_binary
def test_represent_binary():
    """
    Demonstrate issue #25521, in which dumping bytes to YAML was causing
    yaml.dump to throw an exception.
    """
    assert yaml.dump(binary_type(b"\x00"), Dumper=AnsibleDumper) == u'!!binary |\n  AAAAAA==\n'



# Generated at 2022-06-22 13:53:56.026056
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    # Test unicode string
    represent_unicode(dumper, u'unicode')
    # Test ansible unicode string
    represent_unicode(dumper, AnsibleUnicode(u'unicode'))
    # Test unsafe text
    represent_unicode(dumper, AnsibleUnsafeText(u'unsafe text'))


# Generated at 2022-06-22 13:54:00.468315
# Unit test for function represent_unicode
def test_represent_unicode():
    a = dict(a=dict(b=text_type("\x80\x81")))
    result = yaml.dump(a)
    assert result == b"a:\n    b: '\\x80\\x81'\n"



# Generated at 2022-06-22 13:54:03.260791
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = yaml.Dumper
    dumper.add_representer(AnsibleUndefined, represent_undefined)
    result = dumper.represent_data(AnsibleUndefined())
    assert result == ""

# Generated at 2022-06-22 13:54:07.084704
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = dict(one=1, two=2, three=3)
    dumper = AnsibleDumper()
    output = dumper.represent_hostvars(data)
    assert output == dumper.represent_dict(data)

# Generated at 2022-06-22 13:54:18.333102
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader

    vault_hash = VaultLib().encrypt('password', 'secret')
    data = AnsibleVaultEncryptedUnicode(VaultSecret('password', vault_hash))

    # FIXME: with Ansible 2.5.0, output is !vault |', b'$ANSIBLE_VAULT;1.1;AES256', '6637363266643830356465373335636165623862373464313363626235373835623861646466373166396130306434656563303264

# Generated at 2022-06-22 13:54:25.438166
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleMapping, AnsibleUnicode

    test_datas = [HostVars(dict()), HostVarsVars(dict()), VarsWithSources(dict()),
                  AnsibleVaultEncryptedUnicode(b'$ANSIBLE_VAULT;1.1;AES256', b'darksecret'),
                  AnsibleUnicode(u'Tested'), AnsibleMapping(dict(test=1))]

    for test_data in test_datas:
        yaml.dump(test_data, Dumper=AnsibleDumper)

# Generated at 2022-06-22 13:54:32.486727
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    data = u'こんにちは'
    encoded_data = data.encode(u'utf-8').decode(u'unicode_escape')
    assert encoded_data == u'\\u3053\\u3093\\u306b\\u3061\\u306f'
    dumped_data = dumper.represent_binary(encoded_data)
    assert dumped_data == u'!binary |\n  \\u3053\\u3093\\u306b\\u3061\\u306f\n'

# Generated at 2022-06-22 13:54:44.790633
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\n34373963346138646236653835373532643361663732613237313837333730353832643764333361\n36303532666136376232303162333662303331623730666331623762373330653166326362316339\n393537636336386235330a39646661316234623931316539346433366537376564353333623562653\n5363139663030623363333862613261313439373732323562313733356230353934336237353639\n65333463633736346637\n')
    assert "!vault |\n"

# Generated at 2022-06-22 13:54:55.755245
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper

    out = dumper.represent_binary(dumper, 'abc'.decode('ascii'))
    assert out.value == '{}'.format('abc'.encode('base64')).replace('\n', '')

    out = dumper.represent_binary(dumper, 'abc'.encode('ascii'))
    assert out.value == '{}'.format('abc'.encode('base64')).replace('\n', '')

    out = dumper.represent_binary(dumper, 'abç'.decode('utf-8'))
    assert out.value == '{}'.format('abç'.encode('base64')).replace('\n', '')

    out = dumper.represent_binary(dumper, 'abç'.encode('utf-8'))


# Generated at 2022-06-22 13:54:59.782013
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = HostVars(hostvars=dict(test=True))
    assert yaml.dump({'hostvars': hostvars}, Dumper=AnsibleDumper) == 'hostvars: {test: true}\n'


# Generated at 2022-06-22 13:55:06.825047
# Unit test for function represent_unicode
def test_represent_unicode():
    yaml.representer.SafeRepresenter.add_representer(
        AnsibleUnicode,
        represent_unicode,
    )
    data = AnsibleUnicode("test")
    dumper = AnsibleDumper
    dumper.ignore_aliases = lambda *args: True
    # Don't use assertEqual here, since the strings are not equal
    assert dumper.represent_unicode(data) == "test"


# Generated at 2022-06-22 13:55:13.356713
# Unit test for function represent_undefined
def test_represent_undefined():
    # pylint: disable=unused-variable

    # Here we have to use object() due to the fact that bool(AnsibleUndefined)
    # will return False since __bool__ on StrictUndefined returns bool(self.obj)
    # which is False in this case.
    data = object()
    assert data is not None
    assert bool(data) is True

    dumper = AnsibleDumper
    assert dumper is not None

    result = dumper.represent_undefined(None, data)
    assert result is not None
    assert bool(result) is True
    assert result == bool(data)

# Generated at 2022-06-22 13:55:16.520070
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == u'!!binary |-\n  Zm9v\n'



# Generated at 2022-06-22 13:55:20.109968
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = HostVars(fakeinventory=dict(var1=1, var2=2))
    assert yaml.dump(data, Dumper=AnsibleDumper) == 'fakeinventory:\n  var1: 1\n  var2: "2"\n'


# Generated at 2022-06-22 13:55:27.832756
# Unit test for function represent_undefined
def test_represent_undefined():
    class TrueStrictUndefined(AnsibleUndefined):
        def __bool__(self):
            return True

        def __nonzero__(self):
            return True

    class FalseStrictUndefined(AnsibleUndefined):
        def __bool__(self):
            return False

        def __nonzero__(self):
            return False

    yaml_true = yaml.dump({'true': TrueStrictUndefined()}, Dumper=AnsibleDumper)
    yaml_false = yaml.dump({'false': FalseStrictUndefined()}, Dumper=AnsibleDumper)

    assert yaml_true == yaml_false

# Generated at 2022-06-22 13:55:38.454916
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # The yaml module does not allow extra arguments to the Dumper class.
    # Need to use type() to create a new class.
    # Need to use super() because the base class is object

    class Dumper(yaml.SafeDumper, object):
        pass

    Dumper.add_representer(
        AnsibleVaultEncryptedUnicode,
        represent_vault_encrypted_unicode,
    )


# Generated at 2022-06-22 13:55:50.370702
# Unit test for function represent_binary
def test_represent_binary():
    '''test_represent_binary tests the function represent_binary'''
    # We need a dumper object that has the function `represent_str`
    # and `represent_binary`
    dumper_obj = yaml.representer.SafeRepresenter()
    # Add the function `represent_str` to the dumper object
    dumper_obj.represent_str = yaml.representer.SafeRepresenter.represent_str
    # Add the function `represent_binary` to the dumper object
    dumper_obj.represent_binary = yaml.representer.SafeRepresenter.represent_binary
    # Assert that represent_binary returns an object with a class of
    # yaml.nodes.ScalarNode
    assert isinstance(represent_binary(dumper_obj, b'foo'), yaml.nodes.ScalarNode)

# Generated at 2022-06-22 13:55:54.214419
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib

    vault = VaultLib([])
    value = vault.encrypt(u'foo')
    leaked_object = yaml.representer.SafeRepresenter()
    leaked_object.represent_vault_encrypted_unicode(value)

# Generated at 2022-06-22 13:56:04.604852
# Unit test for function represent_unicode
def test_represent_unicode():
    import sys
    import cStringIO

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestRepresentUnicode(unittest.TestCase):
        def setUp(self):
            self.dumper = yaml.Dumper(stream=cStringIO.StringIO(), default_style=None, default_flow_style=False)
        def test_represent_unicode(self):
            ret = represent_unicode(self.dumper, u'\u22ef')
            self.assertEqual(ret, u'\u22ef')

    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-22 13:56:10.079136
# Unit test for function represent_undefined
def test_represent_undefined():
    loader = yaml.SafeLoader('')
    yaml.add_constructor(u"!undef", lambda loader, undef: AnsibleUndefined(undef.value), Loader=loader)
    dump_data = yaml.dump(yaml.load("!undef 'value'"), Dumper=AnsibleDumper)
    assert dump_data == "'value'\n"

# Generated at 2022-06-22 13:56:19.886563
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-22 13:56:22.866813
# Unit test for function represent_undefined
def test_represent_undefined():
    d = AnsibleDumper()
    d.represent_data(AnsibleUndefined(''))



# Generated at 2022-06-22 13:56:29.330526
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    assert dumper.represent_unicode(u'x') == u'x\n'
    assert dumper.represent_unicode(u'\u3042') == u'\u3042\n'
    assert dumper.represent_unicode(u'\U00012345') == u'\U00012345\n'
    assert dumper.represent_unicode(u"\x00\x01\x7F\x80\xFF") == u'\x00\x01\x7f\u20ac\xff\n'


# Generated at 2022-06-22 13:56:31.261517
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert not dumper.represent_undefined(AnsibleUndefined('foo'))
    assert dumper.represent_undefined(True)

# Generated at 2022-06-22 13:56:37.860074
# Unit test for function represent_unicode
def test_represent_unicode():
    result = yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper)
    assert result == 'foo\n...\n'


# Generated at 2022-06-22 13:56:42.122182
# Unit test for function represent_hostvars
def test_represent_hostvars():
    ex = dict(a=1,b=2)
    h = HostVars(ex)
    actual = AnsibleDumper().represent_hostvars(h)
    assert actual == yaml.representer.SafeRepresenter().represent_dict(ex)



# Generated at 2022-06-22 13:56:45.001569
# Unit test for function represent_undefined
def test_represent_undefined():
    undef = AnsibleUndefined('hi')
    _str = yaml.dump(undef)
    assert _str == "DEFAULT_ERROR_MSG_TEMPLATE"

# Generated at 2022-06-22 13:56:48.051202
# Unit test for function represent_binary
def test_represent_binary():
    representer = AnsibleDumper(width=4096)
    expected = u"!!binary |\n  dGVzdA==\n"
    output = representer.represent_binary(None, 'test')
    assert output == expected

# Generated at 2022-06-22 13:56:53.622095
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    loaded = AnsibleVaultEncryptedUnicode('value')
    y = AnsibleDumper.represent_vault_encrypted_unicode(AnsibleDumper, loaded)
    assert y[0].value
    assert y[1] == '!vault'
    assert y[2] == 'value'
    assert y[3] == '|'

# Generated at 2022-06-22 13:56:55.692189
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert represent_hostvars(AnsibleDumper, {'a': 'b'}) == {'a': 'b'}

# Generated at 2022-06-22 13:56:59.598003
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    input_data = b'\x81'
    expected_output = "!!binary |-\n  wA==\n"
    output = dumper.represent_binary(dumper, input_data)
    assert output == expected_output



# Generated at 2022-06-22 13:57:05.408060
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(SafeDumper(), 'foo') == represent_unicode(SafeDumper(), u'foo')
    assert represent_unicode(SafeDumper(), 'foo') == yaml.representer.SafeRepresenter.represent_str(SafeDumper(), 'foo')


# Generated at 2022-06-22 13:57:10.379306
# Unit test for function represent_unicode
def test_represent_unicode():
    data = AnsibleUnicode(b'foo')
    data.__ansible_safe__ = False
    plain_representer = yaml.representer.SafeRepresenter.represent_str
    result = plain_representer(SafeDumper, data)
    assert result == "'foo'"
    result = represent_unicode(SafeDumper, data)
    assert result == 'foo'



# Generated at 2022-06-22 13:57:15.129576
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = {u'foo': u'bar'}
    output = u'{foo: bar}\n'
    dumper = AnsibleDumper()
    assert output == dumper.represent_hostvars(data)


# Generated at 2022-06-22 13:57:21.519015
# Unit test for function represent_binary
def test_represent_binary():
    dumper = yaml.dumper.SafeDumper
    dumper.add_representer(
        AnsibleUnsafeBytes,
        represent_binary,
    )
    assert yaml.dump(b'abc', Dumper=dumper) == yaml.dump(b'abc')

# Generated at 2022-06-22 13:57:24.236308
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert yaml.dump(HostVars(dict(a=1, b=2)), Dumper=AnsibleDumper, default_flow_style=False) == "a: 1\nb: 2\n"



# Generated at 2022-06-22 13:57:28.259533
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    unicode_string = u'\u2600'  # sun
    ansible_unicode = AnsibleUnicode(unicode_string)

    expected_result = u'sun'
    result = dumper.represent_unicode(dumper, ansible_unicode)

    assert result == expected_result


# Generated at 2022-06-22 13:57:32.362130
# Unit test for function represent_unicode
def test_represent_unicode():
    inp = ansible_unicode = AnsibleUnicode(u"unicode_string")
    exp = u"unicode_string"
    out = yaml.dump(inp, Dumper=AnsibleDumper)
    assert out == exp



# Generated at 2022-06-22 13:57:43.908712
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper
    data1 = u"password"
    data2 = b"\xc3\xbcberpass"

# Generated at 2022-06-22 13:57:50.124047
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 13:57:53.872087
# Unit test for function represent_binary
def test_represent_binary():

    class TestDumper(yaml.representer.SafeRepresenter):
        def represent_binary(self, data):
            raise Exception("I was called")

        def represent_str(self, data):
            return data

    dumper = TestDumper(indent=2, width=80, default_flow_style=False)
    dumper.represent_binary(data=b"\x82\xac\xef")

# Generated at 2022-06-22 13:58:04.343438
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-22 13:58:08.135712
# Unit test for function represent_binary
def test_represent_binary():
    output = binary_type(yaml.dump(AnsibleUnsafeBytes(b'ab\x00\x01\x02\x03'), Dumper=AnsibleDumper))
    assert output == '--- !!binary "YWJAAECAwQK"\n'

# Generated at 2022-06-22 13:58:16.575362
# Unit test for function represent_binary
def test_represent_binary():
    class TestAnsibleDumper(AnsibleDumper):
        pass

    assert text_type(TestAnsibleDumper().represent_scalar('tag:yaml.org,2002:binary', 'some-binary-value', style='|')) == \
        "some-binary-value"

    assert text_type(TestAnsibleDumper().represent_scalar('tag:yaml.org,2002:binary', AnsibleUnsafeBytes('some-binary-value'), style='|')) == \
        "some-binary-value"



# Generated at 2022-06-22 13:58:21.181479
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('unittest'), Dumper=AnsibleDumper) == 'unittest\n...\n'



# Generated at 2022-06-22 13:58:31.791306
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = AnsibleVaultEncryptedUnicode(b'$ANSIBLE_VAULT;1.1;AES256\n61636661396136616639643737356438656338373065633365393633623900000b00000b66696e6973686572746d616e0000')
    dumper = AnsibleDumper()
    result = dumper.represent_vault_encrypted_unicode(data)
    assert result == '!vault |\n  $ANSIBLE_VAULT;1.1;AES256\n  61636661396136616639643737356438656338373065633365393633623900000b\n  00000b66696e6973686572746d616e0000'

# Generated at 2022-06-22 13:58:36.294472
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper(indent=4)
    data = AnsibleVaultEncryptedUnicode(b'encrypted data')
    result = dumper.represent_data(data)
    assert result.startswith('!vault')



# Generated at 2022-06-22 13:58:39.421856
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, bytearray(b'hello')) == '!binary |\n  aGVsbG8=\n'

# Generated at 2022-06-22 13:58:42.743570
# Unit test for function represent_undefined
def test_represent_undefined():
    data = AnsibleUndefined()
    assert not bool(data)
    assert AnsibleDumper.represent_undefined(None, data) == False
    assert AnsibleUnsafeText(data) == ''
    assert not bool(AnsibleUnsafeText(AnsibleUndefined()))

# Generated at 2022-06-22 13:58:47.843428
# Unit test for function represent_binary
def test_represent_binary():
    dumper = yaml.dumper.Dumper
    dumper.add_representer(
        AnsibleUnsafeBytes,
        represent_binary,
    )
    assert dumper.represent_binary(dumper, AnsibleUnsafeBytes(b"\x00\x01\x02")) == '!!binary |\n  AAEC\n'
    assert dumper.represent_binary(dumper, AnsibleUnsafeBytes(b"hello\x00world")) == '!!binary |\n  aGVsbG8Ad29ybGQ=\n'


# Generated at 2022-06-22 13:58:57.165217
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    # Here we pass a bool, which should be returned as is
    result = dumper.represent_data(True)
    assert 'true\n' == result
    # Here we pass Undefined, which should set the fail flag
    with pytest.raises(yaml.representer.RepresenterError) as excinfo:
        dumper.represent_data(AnsibleUndefined)
    assert 'is undefined' in str(excinfo.value)
    # Here we pass a string, which should be represented normally
    result = dumper.represent_data('abc')
    assert 'abc\n' == result

# Generated at 2022-06-22 13:59:00.548167
# Unit test for function represent_binary
def test_represent_binary():
    data = AnsibleUnsafeBytes("\x80")
    yaml_string = yaml.dump(data, default_flow_style=False)
    assert yaml_string == "!!binary |-\n  uHg=\n"

# Generated at 2022-06-22 13:59:04.883326
# Unit test for function represent_binary
def test_represent_binary():
    class MockDumper(object):
        def represent_scalar(self, tag, value, style=None):
            return 'tag: {0}, value: {1}'.format(tag, value)
    dumper = MockDumper()
    binary_data = AnsibleUnsafeBytes(b'\x00\x00\x00')
    actual = represent_binary(dumper, binary_data)
    expected = 'tag: !!binary, value: |-\n  AAAAAA=='
    assert actual == expected

# Generated at 2022-06-22 13:59:13.998934
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    # Here we manually set the tag
    # so that _fail_with_undefined_error doesn't happen.
    # _fail_with_undefined_error happens for other tags.
    # This is why we are checking that _fail_with_undefined_error
    # doesn't happen even if we change the tag.
    dumper.add_representer(
        AnsibleUndefined,
        represent_undefined,
        yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG,
    )
    dumper.dump([1, AnsibleUndefined, 3])



# Generated at 2022-06-22 13:59:29.128477
# Unit test for function represent_unicode
def test_represent_unicode():

    # Ensure the ansible_yaml_representer is used
    data = AnsibleUnicode(u'some data')
    yaml_data = yaml.dump(data, Dumper=AnsibleDumper)

    assert yaml_data in [
        u'!ansible_safe "' + u'some data' + u'"\n',
        u'!ansible_safe "' + u'some data' + u'"\n...\n',
        u'!ansible_safe ' + u'"' + u'some data' + u'"\n',
        u'!ansible_safe ' + u'"' + u'some data' + u'"\n...\n',
    ]



# Generated at 2022-06-22 13:59:39.320900
# Unit test for function represent_unicode
def test_represent_unicode():
    # Example yaml file
    orig_yaml = '''
    key0: value0
    key1:
      - item0
      - item1
    key2: [ another, list ]
    key3:
      key4: value4
    '''
    # Example dictionary with unicode values
    orig_dict = {
        u'key0': u'value0',
        u'key1': [u'item0', u'item1'],
        u'key2': [u'another', u'list'],
        u'key4': {
            u'key4': u'value4'
        }
    }
    # Parse the yaml and compare it to the original dictionary
    new_dict = yaml.safe_load(orig_yaml)
    assert new_dict == orig_dict

# Generated at 2022-06-22 13:59:43.260520
# Unit test for function represent_unicode
def test_represent_unicode():
    unicode_object = AnsibleUnicode('unicode value')
    dumper = AnsibleDumper
    assert dumper.represent_unicode(unicode_object) == u"'unicode value'\n"



# Generated at 2022-06-22 13:59:46.891463
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    rep_unicode = dumper.representers[text_type]

    assert rep_unicode(dumper, text_type('')) == rep_unicode(dumper, text_type('foo'))



# Generated at 2022-06-22 13:59:53.868398
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode(u'string')) == u"'string'\n"
    assert yaml.dump(AnsibleUnicode(u'string\n')) == u"'string\n'\n"
    assert yaml.dump(AnsibleUnicode(u'"string"')) == u"'\"string\"'\n"
    assert yaml.dump(AnsibleUnicode(u'string"\n')) == u"'string\"\n'\n"



# Generated at 2022-06-22 13:59:59.654119
# Unit test for function represent_unicode
def test_represent_unicode():
    # For python2, strings are already unicode
    assert represent_unicode(None, b'foo') == u'foo'
    assert represent_unicode(None, text_type(u'bar')) == u'bar'

    # For python3, strings must be converted to unicode
    assert represent_unicode(None, b'foo') == u'foo'
    assert represent_unicode(None, text_type(u'bar')) == u'bar'



# Generated at 2022-06-22 14:00:10.408838
# Unit test for function represent_unicode
def test_represent_unicode():
    '''
    Test normal string
    '''
    test_string = 'this is a test string'
    result_string = yaml.dump(test_string, Dumper=AnsibleDumper)
    assert result_string == "this is a test string\n"

    '''
    Test unicode string
    '''
    test_string = u'\u043f\u0440\u0438\u0432\u0435\u0442 \u043c\u0438\u0440'
    result_string = yaml.dump(test_string, Dumper=AnsibleDumper)
    assert result_string == "--- \u043f\u0440\u0438\u0432\u0435\u0442 \u043c\u0438\u0440\n"

# Generated at 2022-06-22 14:00:15.489412
# Unit test for function represent_unicode
def test_represent_unicode():
    from ansible.release import __version__
    s = u"h\u0029llo"
    out = yaml.dump(s, Dumper=AnsibleDumper).rstrip()
    expected = u"%YAML 1.2\n---\n0.1.0:" + s
    assert out == expected, "got %s instead of %s" % (out, expected)

# Generated at 2022-06-22 14:00:19.863123
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper(stream=None)
    data = AnsibleUnicode("test")
    result = dumper.represent_data(data)
    assert result == u'test\n...\n'



# Generated at 2022-06-22 14:00:27.837133
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = yaml.dumper.SafeDumper
    dumper.add_representer(
        AnsibleUnicode,
        represent_unicode,
    )
    dumper.add_representer(
        AnsibleUnsafeText,
        represent_unicode,
    )
    dumper.add_representer(
        AnsibleUnsafeBytes,
        represent_binary,
    )
    a_unicode = AnsibleUnicode(u'babou')
    a_unsafe_text = AnsibleUnsafeText(u'babou')
    a_unsafe_bytes = AnsibleUnsafeBytes(b'babou')
    result_a_unicode = yaml.safe_dump(a_unicode, default_flow_style=False, Dumper=dumper)
    result_a_uns

# Generated at 2022-06-22 14:00:32.033773
# Unit test for function represent_unicode
def test_represent_unicode():
    item = AnsibleUnicode("text string")
    yaml.add_representer(type(AnsibleUnicode("")), represent_unicode)
    encoded = yaml.dump(item, Dumper=AnsibleDumper)
    assert encoded == "text string\n"

# Generated at 2022-06-22 14:00:36.278704
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    unicode = AnsibleUnicode('testing unicode')
    assert represent_unicode(dumper, unicode) == yaml.representer.SafeRepresenter.represent_str(dumper, 'testing unicode')


# Generated at 2022-06-22 14:00:38.119520
# Unit test for function represent_unicode
def test_represent_unicode():

    data = AnsibleUnicode('foo')

    dumper = AnsibleDumper()
    dumper.represent_unicode(data)



# Generated at 2022-06-22 14:00:42.851875
# Unit test for function represent_unicode
def test_represent_unicode():
    # Check that the representer correctly handles text type
    assert yaml.dump(u'Test text', Dumper=AnsibleDumper) == 'Test text\n...\n'

    assert yaml.dump('Test text', Dumper=AnsibleDumper) == 'Test text\n...\n'



# Generated at 2022-06-22 14:00:44.580864
# Unit test for function represent_unicode
def test_represent_unicode():
    s = u'@foo'
    result = yaml.dump(s, Dumper=AnsibleDumper)
    assert result == u"'@foo'\n"


# Generated at 2022-06-22 14:00:54.961783
# Unit test for function represent_unicode
def test_represent_unicode():
    # 'AnsibleUnicode' is a subclass of 'six.text_type' in Python2
    assert issubclass(AnsibleUnicode, text_type)
    # 'AnsibleUnicode' is a subclass of 'str' in Python3
    assert issubclass(AnsibleUnicode, str)

    # 'six.text_type' is a subclass of 'str' in Python2
    assert issubclass(text_type, str)

    data_value_1 = AnsibleUnicode("test_text_1")
    data_value_2 = AnsibleUnicode("test_text_2")

    dumper = AnsibleDumper(indent=4, default_flow_style=False)
    data = {data_value_1: data_value_2}

# Generated at 2022-06-22 14:00:57.737838
# Unit test for function represent_unicode
def test_represent_unicode():
    data = AnsibleUnicode('some string')
    assert yaml.dump({'some_key': data}, Dumper=AnsibleDumper).strip() == 'some_key: some string'


# Generated at 2022-06-22 14:01:00.387871
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('unicode string'), Dumper=AnsibleDumper) == 'unicode string'

