

# Generated at 2022-06-22 13:51:12.298016
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    u1 = u"\u062a"
    dumped = yaml.safe_dump(u1, Dumper=dumper)
    assert dumped == u'!!python/unicode "\\u062a\\n"\n'



# Generated at 2022-06-22 13:51:16.517109
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    u = AnsibleVaultEncryptedUnicode('test')
    d = AnsibleDumper()
    assert d.represent_vault_encrypted_unicode(u) == d.represent_scalar(u'!vault', 'test', style='|')

# Generated at 2022-06-22 13:51:22.504865
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = yaml.dumper.SafeDumper
    dumper.add_representer(AnsibleUndefined, represent_undefined)
    assert yaml.dump(AnsibleUndefined("foo"), Dumper=dumper) == "!!python/object/new:ansible.template.AnsibleUndefined foo"



# Generated at 2022-06-22 13:51:25.461820
# Unit test for function represent_unicode
def test_represent_unicode():
    # test1: Unicode string
    data = u"\u65e5\u672c\u8a9e"
    expected_output = u"!ansible-unicode |-\n  日本語"

    dumper = AnsibleDumper()
    assert dumper.represent_unicode(data) == expected_output



# Generated at 2022-06-22 13:51:28.929438
# Unit test for function represent_binary
def test_represent_binary():
    '''
    This is used to test the output of represent_binary()

    :input : some content
    :return : output of represent_binary
    '''
    data = b'encoded text'
    repr_text = yaml.dumps(data, Dumper=AnsibleDumper)
    return repr_text


if __name__ == '__main__':
    print(test_represent_binary())

# Generated at 2022-06-22 13:51:37.540413
# Unit test for function represent_binary
def test_represent_binary():
    import inspect
    import os
    import sys

    filename = os.path.abspath(inspect.getfile(inspect.currentframe()))
    tests_path = os.path.dirname(os.path.dirname(filename))
    module_path = os.path.join(tests_path, 'modules')

    if module_path not in sys.path:
        sys.path.append(module_path)

    from ansible.modules.system import service
    m = AnsibleDumper()
    b = m.represent_binary(binary_type(service.__file__.encode()))
    assert '!!binary' in b
    assert b[-2:] == '\\n'



# Generated at 2022-06-22 13:51:49.321394
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault_secret = 'mysecret'
    vault = VaultLib(password=vault_secret)
    vault_text = u'This is not a secret'
    ciphertext = vault.encrypt(vault_text.encode('utf8'))
    ciphertext = vault.decrypt(ciphertext.encode('utf8'))
    ciphertext = AnsibleVaultEncryptedUnicode(ciphertext)
    result = yaml.dump(ciphertext, Dumper=AnsibleDumper, default_flow_style=False)

# Generated at 2022-06-22 13:51:53.731809
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    data = b"\x00\x01"
    ret = dumper.represent_data(data)
    assert ret == dumper.represent_str("\x00\x01")
    assert isinstance(ret, binary_type)

# Generated at 2022-06-22 13:51:58.975415
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = {
        'item1': 'value1',
    }
    result = yaml.dump(data, Dumper=AnsibleDumper)
    assert result == """item1: value1
""", \
        "Expected dump of hostvars to be equal"



# Generated at 2022-06-22 13:52:10.666569
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    d = yaml.Dumper(explicit_start=True, explicit_end=True)
    representer = d.represent_data

    # Test proper string format required by '|' style
    data = b'AES256|7b94c04b48d92c9665946e2bbedc6776296a68dbdafe3827b1f7ad00c881d5b5e5d0e5c5f5c0094e7fa4d3e4387b4c4b6bb9dfa8f7aaddc3b3bf7cadca42b8c7e'
    md = representer(data)

# Generated at 2022-06-22 13:52:19.438415
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    assert represent_vault_encrypted_unicode(AnsibleDumper, AnsibleVaultEncryptedUnicode(u"foobar")) == u"!vault |\n  $ANSIBLE_VAULT;1.1;AES256\n  31633163376630396433373637663835396633353262616434373663396265666637353431663538\n  613336347d0a\n"

# Generated at 2022-06-22 13:52:26.046310
# Unit test for function represent_hostvars
def test_represent_hostvars():

    def verified_represent_hostvars(self, data):
        return self.represent_dict(dict(data))

    verified_presenter = yaml.representer.SafeRepresenter.represent_dict
    verified_presenter.__globals__ = AnsibleDumper.add_representer.__globals__
    assert verified_represent_hostvars == verified_presenter



# Generated at 2022-06-22 13:52:33.648689
# Unit test for function represent_hostvars
def test_represent_hostvars():
    """ Test represent_hostvars.

    Test the function `represent_hostvars` to see if it behaves as expected.

    For example:

    >>> from ansible.parsing.yaml import AnsibleDumper
    >>> data = AnsibleDumper.represent_hostvars("Test")
    >>> data
    "Test"
    """
    from ansible.parsing.yaml import AnsibleDumper
    assert AnsibleDumper.represent_hostvars("Test") == "Test"


# Generated at 2022-06-22 13:52:38.867275
# Unit test for function represent_hostvars
def test_represent_hostvars():
    actual = yaml.dump(dict(mydict=dict(mykey=dict(myvar='myvalue'))), Dumper=AnsibleDumper, default_flow_style=False)
    expected = text_type('''
mydict:
  mykey:
    myvar: myvalue
''')
    assert actual == expected



# Generated at 2022-06-22 13:52:50.236460
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(u'\u0080') == "u'\\x80'\n"

    dumper = yaml.Dumper(encoding='utf-8')
    dumper.add_representer(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG,
                           represent_unicode)
    assert dumper.dump({u'\u0080': u'foo'}) == "{u'\\x80': u'foo'}\n"

    dumper.add_representer(yaml.resolver.BaseResolver.DEFAULT_SCALAR_TAG,
                           represent_unicode)
    assert dumper.dump(u'\u0080') == "u'\\x80'\n"



# Generated at 2022-06-22 13:53:00.197701
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    # Test a binary string
    s = dumper.represent_binary(b"\xff\xfe\x00\x01\x02\x03\x04\x05")
    assert s == "!!binary |\n  //8AAAAQIDBAU="
    # Test a unicode string
    # Note this is here to ensure we don't break
    # represent_binary for strings
    s = dumper.represent_binary("\xff\xfe\x00\x01\x02\x03\x04\x05")
    assert s == "!!binary |\n  /v8AAAAQIDBAU="

# Generated at 2022-06-22 13:53:04.810393
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    assert represent_vault_encrypted_unicode(None, AnsibleVaultEncryptedUnicode(b'\x00\x01\x02\x03')) == \
        yaml.representer.SafeRepresenter.represent_scalar(None, u'\u0000\u0001\u0002\u0003', style='|')



# Generated at 2022-06-22 13:53:07.346455
# Unit test for function represent_binary
def test_represent_binary():
    assert AnsibleDumper.represent_binary(None, b'abc').value == b"'abc'"

# Generated at 2022-06-22 13:53:13.720553
# Unit test for function represent_undefined
def test_represent_undefined():
    if yaml.__version__ != '3.12':
        raise AssertionError(
            "represent_undefined is only intended for use with PyYAML 3.12")

    assert AnsibleDumper.represent_undefined(AnsibleDumper, AnsibleUndefined) == NotImplemented



# Generated at 2022-06-22 13:53:18.430927
# Unit test for function represent_binary
def test_represent_binary():
    '''
    Dumper should use the same method for represent binary as it used
    for represent bytes.
    '''
    dumper = AnsibleDumper()
    dumper.add_representer(bytes, dumper.represent_str)
    assert dumper.represent_data(b'a') == dumper.represent_data(b'a')

# Generated at 2022-06-22 13:53:23.727711
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.load(yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper)) is None

# Generated at 2022-06-22 13:53:26.964128
# Unit test for function represent_hostvars
def test_represent_hostvars():
    yaml.dump({'test': HostVars(dict(a=1, b=2, c=3))}, Dumper=AnsibleDumper, default_flow_style=False)

# Generated at 2022-06-22 13:53:37.320599
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-22 13:53:41.499013
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, binary_type(b'\x11\x22\x33')) == ("!!binary |\n  "
                                                                           "ExIyMzM=\n")



# Generated at 2022-06-22 13:53:44.449266
# Unit test for function represent_undefined
def test_represent_undefined():

    data = AnsibleUndefined()

    dump_data = yaml.dump(data, Dumper=AnsibleDumper)

    assert dump_data == 'false\n...\n'

# Generated at 2022-06-22 13:53:56.074835
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    plaintext = u"test"
    vault = AnsibleVaultEncryptedUnicode(plaintext, b'$ANSIBLE_VAULT;1.1;AES256;user1\n3761313837326231386565303638306439343534316332626266636664313661360a61323863656265393437356432636333383739376166316663303037373232393\n')
    result = yaml.dump(vault, Dumper=AnsibleDumper, default_flow_style=False)

# Generated at 2022-06-22 13:54:00.117002
# Unit test for function represent_hostvars
def test_represent_hostvars():
    item = AnsibleUnicode('string')
    item = HostVars(entry=item)
    assert yaml.dump(item, Dumper=AnsibleDumper) == 'string\n...\n'



# Generated at 2022-06-22 13:54:09.366543
# Unit test for function represent_binary
def test_represent_binary():
    # There are probably cases where bytes on PY2 won't work, but
    # this is enough to get the functionality working to help with
    # the migration to PY3
    if yaml.__with_libyaml__:
        # We have to generate byte strings on python 2, not unicode
        # strings.  libyaml doesn't support unicode strings in the
        # binary wrapper and any attempt to do so will result in
        # a yaml.YAMLError exception
        bytes_string = b"this is a test of represent_binary"
    else:
        bytes_string = u"this is a test of represent_binary"

    # Because this function is only usable when __with_libyaml__ is true
    # there is no way we can use the standard libyaml test here
    # instead we use the plain SafeDumper

# Generated at 2022-06-22 13:54:17.995178
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    new_loader = yaml.SafeLoader
    new_loader.add_constructor(u'!vault', yaml.constructor.SafeConstructor.construct_yaml_str)


# Generated at 2022-06-22 13:54:26.497261
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    vault = VaultLib(b'dummy_password')

    yaml.add_representer(AnsibleVaultEncryptedUnicode, represent_vault_encrypted_unicode)

    # Use VaultLib to encrypt plaintext data and insert it into AnsibleVaultEncryptedUnicode
    plaintext_data = vault.encrypt(b"This is plaintext")
    data = AnsibleVaultEncryptedUnicode(plaintext_data)

    # Dump the encrypted data to a string
    dumped_data = yaml.dump([data], Dumper=AnsibleDumper, default_flow_style=False)

# Generated at 2022-06-22 13:54:30.780409
# Unit test for function represent_unicode
def test_represent_unicode():

    assert represent_unicode(None, u'foo') == yaml.representer.SafeRepresenter.represent_str(None, u'foo')

# Generated at 2022-06-22 13:54:34.416140
# Unit test for function represent_undefined
def test_represent_undefined():
    with pytest.raises(yaml.representer.RepresenterError):
        represent_undefined(AnsibleDumper, AnsibleUndefined())

# Generated at 2022-06-22 13:54:38.310919
# Unit test for function represent_hostvars
def test_represent_hostvars():
    import yaml
    data = {'var1': 1, 'var2': 2}
    hv = HostVars(data)
    yaml.dump(hv, Dumper=AnsibleDumper, default_flow_style=False)

# Generated at 2022-06-22 13:54:40.930236
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hv = HostVars({"testvar": "testvalue"}, "testhost")
    assert yaml.dump(hv) == "testhost:\n    testvar: testvalue\n"

# Generated at 2022-06-22 13:54:46.599759
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    d = AnsibleVaultEncryptedUnicode(b'$ANSIBLE_VAULT;1.1;AES256', '$ANSIBLE_VAULT;1.1;AES256', 'AES256', 'This is text')
    assert AnsibleDumper.represent_vault_encrypted_unicode(AnsibleDumper, d) == AnsibleDumper.represent_text(AnsibleDumper, '\n'.join((d.vault_version, d.cipher, d._ciphertext.decode('utf-8'))))

# Generated at 2022-06-22 13:54:49.666145
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.dump(AnsibleUndefined('bogus'), Dumper=AnsibleDumper) == 'None\n...\n'

# Generated at 2022-06-22 13:54:57.182581
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Create an instance of the AnsibleVaultEncryptedUnicode object
    vaeu = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\n336437336532653237373764613532626432623331656139623663616336636262373730316366366635\n353036346633363866613061666233346165613037303632323666643637303431316131383938306633\n393932396232346336623033616265623339383431303961653537613233383464383539343339633161\n37633666326261333361666666613561386338643837643136')

    a = Ansible

# Generated at 2022-06-22 13:55:04.194664
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper

# Generated at 2022-06-22 13:55:13.244821
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    '''
    Test that AnsibleVaultEncryptedUnicode objects are serialized with the
    !vault tag.
    '''
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import os
    import tempfile

    # Create a temp directory
    tmpdir = tempfile.mkdtemp(prefix='ansible_vault_test_')

    # Create a vault password file
    (vault_password_fd, vault_password_path) = tempfile.mkstemp(dir=tmpdir, text=True)
    os.write(vault_password_fd, b"ansible")
    os.close(vault_password_fd)



# Generated at 2022-06-22 13:55:14.429793
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # Tested elsewhere
    assert True



# Generated at 2022-06-22 13:55:25.716280
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-22 13:55:29.125319
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b"foo") == u"!!binary \"Zm9v\""



# Generated at 2022-06-22 13:55:31.973994
# Unit test for function represent_unicode
def test_represent_unicode():
    yaml.add_representer(text_type, represent_unicode)
    assert yaml.dump('foo') == 'foo\n...\n'

# Generated at 2022-06-22 13:55:34.710845
# Unit test for function represent_unicode
def test_represent_unicode():
    value = AnsibleUnicode('hello')
    output = yaml.dump(value, Dumper=AnsibleDumper)
    assert output == 'hello\n...\n'

# Generated at 2022-06-22 13:55:36.863224
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('test')) == 'test\n...\n'



# Generated at 2022-06-22 13:55:41.160754
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    data = {'foo': 'bar'}
    hostvars = HostVars()
    hostvars.add_host('localhost', data, False)
    result = dumper.represent_data(hostvars)
    expected = "!!python/object/new:ansible.vars.hostvars.HostVars\nhostvars: {localhost: {foo: bar}}"
    assert result.strip() == expected

# Generated at 2022-06-22 13:55:52.525814
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from .test_yaml_objects import _assert_ips


# Generated at 2022-06-22 13:55:59.173760
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    import base64

    vault_password = 'mysecret'
    vault = VaultLib(vault_password)

# Generated at 2022-06-22 13:56:07.140001
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper(indent=2)
    result = dumper.represent_binary(b'foo\nbar\n')
    assert result == (
        "!!python/object/apply:yaml.add_representer\n"
        "[binary,\n"
        " !!python/object/apply:yaml.representer.SafeRepresenter.represent_binary,\n"
        " [!!binary \"Zm9vCmJhcgo=\"]]\n"
    )

# Generated at 2022-06-22 13:56:16.355831
# Unit test for function represent_hostvars
def test_represent_hostvars():

    # Test for HostVars class
    test_hostvars = HostVars(host='testhost', variables={'testkey': 'testvalue'})
    assert(yaml.dump(test_hostvars) == ("{testkey: testvalue}\n"))

    # Test for HostVars class
    test_hostvarsvars = HostVarsVars(host='testhost', variables={'testkey': 'testvalue'})
    assert(yaml.dump(test_hostvarsvars) == ("{testkey: testvalue}\n"))

    # Test for VarsWithSources class
    test_varswithsources = VarsWithSources(host='testhost', variables={'testkey': 'testvalue'})

# Generated at 2022-06-22 13:56:26.936018
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

    data = b'foo'
    assert dumper.represent_binary(data) == yaml.representer.SafeRepresenter.represent_binary(dumper, binary_type(data))

    data = AnsibleUnsafeBytes(b'foo')
    assert dumper.represent_binary(data) == yaml.representer.SafeRepresenter.represent_binary(dumper, binary_type(data))



# Generated at 2022-06-22 13:56:29.993545
# Unit test for function represent_hostvars
def test_represent_hostvars():
    h = HostVars('localhost', {'k1': 'v1'})
    actual = yaml.dump(dict(h), Dumper=AnsibleDumper)
    assert actual == '{k1: v1}\n'



# Generated at 2022-06-22 13:56:32.630573
# Unit test for function represent_unicode
def test_represent_unicode():
    # Represent empty string
    assert represent_unicode(None, AnsibleUnicode(u'')) == u''

    # Represent non-empty string
    assert represent_unicode(None, AnsibleUnicode(u'foo')) == u'foo'


# Generated at 2022-06-22 13:56:38.719179
# Unit test for function represent_hostvars
def test_represent_hostvars():
    lines = []

    mock_self = type('MockSelf', (object,), {
        'represent_dict': lambda self, data: lines.extend(['{', '}'])
    })(object())

    represent_hostvars(mock_self, HostVars(object()))

    assert lines == ['{', '}']

# Generated at 2022-06-22 13:56:48.803140
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    class FakeVaultEncryptedUnicode(object):
        def __init__(self, ciphertext):
            self._ciphertext = ciphertext

    # data with non-ASCII chars
    data = FakeVaultEncryptedUnicode(u'Höllo!').__dict__
    obj = represent_vault_encrypted_unicode(AnsibleDumper(), data)
    assert obj == u'!vault |\n  Höllo!\n'

    # data with trailing backslash
    data = FakeVaultEncryptedUnicode(u'Hello\\').__dict__
    obj = represent_vault_encrypted_unicode(AnsibleDumper(), data)
    assert obj == u'!vault |\n  Hello\\\n'

    # data with quotes
    data = FakeVaultEncryptedUnic

# Generated at 2022-06-22 13:56:59.339747
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.safe_dump(AnsibleUnicode('foo'), default_flow_style=False, Dumper=AnsibleDumper) == 'foo\n...\n'
    assert yaml.safe_dump(AnsibleVaultEncryptedUnicode('bar'), default_flow_style=False, Dumper=AnsibleDumper) == '!vault |\n  $ANSIBLE_VAULT;1.1;AES256\n  3133353165323532626335636661636665666637633837333634383565666131353837666532636635\n  6262363466363638393737616661646533373963313931323531366461393538346335653961336563\n  62393665\n'
    assert y

# Generated at 2022-06-22 13:57:05.916233
# Unit test for function represent_hostvars
def test_represent_hostvars():

    hv = HostVars()
    hv['foo'] = dict(bar='baz')
    hv['i'] = dict(p='q')

    assert yaml.safe_dump(hv, Dumper=AnsibleDumper) == 'foo:\n    bar: baz\ni:\n    p: q\n'



# Generated at 2022-06-22 13:57:10.138932
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    yaml.add_representer(
        AnsibleVaultEncryptedUnicode,
        represent_vault_encrypted_unicode,
        Dumper=AnsibleDumper
    )
    test_str = AnsibleVaultEncryptedUnicode(u'test')
    yaml.dump(test_str, Dumper=AnsibleDumper)

# Generated at 2022-06-22 13:57:15.442153
# Unit test for function represent_binary
def test_represent_binary():
    func = AnsibleDumper.representers[binary_type]
    assert func == represent_binary
    assert func(AnsibleDumper, b'\xff\x00\x0f\xaa') == "!!binary |\n  /wAA\n"

# Generated at 2022-06-22 13:57:23.965068
# Unit test for function represent_unicode
def test_represent_unicode():
    # create a dumper and set it to use the custom representer
    dumper = AnsibleDumper
    dumper.add_representer(
        AnsibleUnicode,
        represent_unicode,
    )

    assert dumper.represent_unicode('hello world') == dumper.represent_unicode(u'hello world')
    assert dumper.represent_unicode(u'hello world') == "'hello world'"
    assert dumper.represent_unicode(AnsibleUnicode(u'hello world')) == dumper.represent_unicode(u'hello world')
    assert dumper.represent_unicode(AnsibleUnicode(u'hello world')) == "'hello world'"



# Generated at 2022-06-22 13:57:45.616787
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # create empty AnsibleVaultEncryptedUnicode object
    av = AnsibleVaultEncryptedUnicode()
    # dump empty AnsibleVaultEncryptedUnicode object
    yaml.dump(av, Dumper=AnsibleDumper, default_flow_style=False)
    # dump AnsibleVaultEncryptedUnicode object with ciphertext

# Generated at 2022-06-22 13:57:56.938706
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.dumper import AnsibleDumper

    editor = VaultEditor(None)
    teststring = 'This is the secret!'
    ciphertext = editor.encrypt(teststring)
    # mimic _get_prepped_value from VaultEditor.encrypt
    ciphertext = binary_type(ciphertext, 'utf-8')
    test_vault_str = AnsibleVaultEncryptedUnicode(ciphertext)

    # mimic how ansible-vault encrypt stores the vaulted data
    constructor = AnsibleConstructor(resolver=None)

# Generated at 2022-06-22 13:58:07.895079
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # When the data is a unicode string and the cipher is a unicode string
    # we should get out a unicode string
    data = AnsibleVaultEncryptedUnicode(u'abc', u'abc')
    expected = u'!vault |\n          YWJjCg==\n'
    result = yaml.dump(data, Dumper=AnsibleDumper, default_flow_style=False)
    assert expected == result

    # When data is not unicode and we want unicode out
    data = AnsibleVaultEncryptedUnicode(u'abc', b'abc')

# Generated at 2022-06-22 13:58:12.808918
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    assert(represent_vault_encrypted_unicode(AnsibleDumper, AnsibleVaultEncryptedUnicode('data')) == '!vault |\n          YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4\n          eXo=\n')

# Generated at 2022-06-22 13:58:18.883275
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dump = yaml.dumps({'test': HostVars(host_vars={'testhost1': {'testvar': 'testval'}})}, default_flow_style=False, Dumper=AnsibleDumper)

    assert dump == """\
!<HostVars>
testhost1:
  testvar: testval
"""

# TODO: test_represent_vault_encrypted_unicode


# Generated at 2022-06-22 13:58:24.218241
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    # Use the AnsibleUndefined class directly
    e = AnsibleUndefined('This is a test')
    s = dumper.represent_undefined(dumper, e)
    assert not s
    # Create an instance in a dict
    d = {'foo': AnsibleUndefined()}
    s = dumper.represent_dict(d)
    assert not s
    # Create an instance in a list
    l = [AnsibleUndefined()]
    s = dumper.represent_list(l)
    assert not s
    # Create an instance of an AnsibleUnsafeText
    s = dumper.represent_unicode(AnsibleUnsafeText(AnsibleUndefined()))
    assert not s
    # Create an AnsibleUnsafeText in a dict

# Generated at 2022-06-22 13:58:34.060074
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    import base64
    from ansible.parsing.vault import VaultLib
    tmp_vault_pass = 'ansible'

    vl = VaultLib(tmp_vault_pass)
    encrypted = vl.encrypt('asdf')
    data = AnsibleVaultEncryptedUnicode(encrypted)
    dumper = AnsibleDumper()
    result = dumper.represent_vault_encrypted_unicode(data)
    assert result.startswith('!vault')

    # This is how the vault encrypted string really looks like
    result_base64_decoded = base64.b64decode(''.join(result.split('\n')))

    # Check for validity of the output

# Generated at 2022-06-22 13:58:40.226947
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    hv = HostVars('test.example.com')
    hv.update(dict(var1=dict(key1='value1')))
    output = yaml.dump(hv, Dumper=AnsibleDumper)
    assert output == "var1:\n  key1: value1\n"


# Generated at 2022-06-22 13:58:47.478563
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert(dumper.represent_binary(dumper, b'\n') == "|-\n  !binary |\n    Cg==\n")
    assert(dumper.represent_binary(dumper, b'\n\n') == "|-\n  !binary |\n    Cgo=\n")
    assert(dumper.represent_binary(dumper, b'\n\n\n') == "|-\n  !binary |\n    Cgog\n")
    assert(dumper.represent_binary(dumper, b'\n\n\n\n') == "|-\n  !binary |\n    CgogCg==\n")

# Generated at 2022-06-22 13:58:58.794577
# Unit test for function represent_unicode
def test_represent_unicode():
    # Test for UNSAFE text
    result = yaml.dump(['test_represent_unicode', AnsibleUnsafeText(u'\u0430')], Dumper=AnsibleDumper)
    assert result == '- test_represent_unicode\n- !!python/unicode "\u0430"\n'
    # Test for UNSAFE bytes
    result = yaml.dump([b'test_represent_unicode', AnsibleUnsafeBytes(b'\u0430')], Dumper=AnsibleDumper)
    assert result == '- test_represent_unicode\n- !!python/unicode "\u0430"\n'
    # Test for UNSAFE str

# Generated at 2022-06-22 13:59:28.057016
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert represent_hostvars(None, HostVars(dict())) == dict()
    assert represent_hostvars(None, HostVars({"foo": "bar"})) == {"foo": "bar"}
    assert represent_hostvars(None, HostVars({"foo": "bar"})) == {"foo": "bar"}



# Generated at 2022-06-22 13:59:36.899399
# Unit test for function represent_undefined
def test_represent_undefined():
    class TestAnsibleDumper(AnsibleDumper):

        def represent_undefined(self, data):
            # Here bool will ensure _fail_with_undefined_error happens
            # if the value is Undefined.
            # This happens because Jinja sets __bool__ on StrictUndefined
            return bool(data)

        # Jinja2 tests depend on this error being triggered
        # we test for it in ansible.template.test_template
        def _fail_with_undefined_error(
            self,
            obj
        ):
            raise Exception('test: undefined error')

    dumper = TestAnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined('test')) is False

# Generated at 2022-06-22 13:59:47.250961
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    temp_obj = AnsibleVaultEncryptedUnicode("1234", "MyString", "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          62346436346464346461316439336531643062336330306433613164346362653034306162323061\n          61336131633235643637333539383566396234356164323330643465393161653263313761396331\n          383636396234393862366338323866356666383039\n")

# Generated at 2022-06-22 13:59:51.604951
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    r = AnsibleDumper()
    s = AnsibleVaultEncryptedUnicode(u'foo')
    assert r.represent_vault_encrypted_unicode(s) == '!vault |\n          %s' % s._ciphertext.decode()

# Generated at 2022-06-22 14:00:00.588006
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 14:00:11.288413
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from collections import namedtuple

    def match_data(expected_data, data):
        for key, expected_value in expected_data.items():
            value = data.get(key)
            if isinstance(value, namedtuple):
                match_data(expected_value, value)
            else:
                assert value == expected_value

    variable_manager = VariableManager()
    variable_manager.set_host_variable("h1", "v1", "g1")
    variable_manager.set_host_variable("h1", "v2", "g1")
    variable_manager.set_host_variable("h2", "v1", "g2")


# Generated at 2022-06-22 14:00:14.153127
# Unit test for function represent_unicode
def test_represent_unicode():
    data = 'test'
    assert yaml.dump(data, Dumper=AnsibleDumper, default_flow_style=False) == '"test"\n'



# Generated at 2022-06-22 14:00:19.636461
# Unit test for function represent_binary
def test_represent_binary():
    test_str = b'This is a b\'test\''
    test_str_quoted = '!!binary |\n  VGhpcyBpcyBhIGInZXN0Jw==\n'
    assert AnsibleDumper.represent_binary(None, test_str) == test_str_quoted


# Generated at 2022-06-22 14:00:24.183167
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(u'\u2713') == '"\\u2713"\n'
    assert yaml.dump(u'\U0001F4A9') == '"\\U0001F4A9"\n'
    assert yaml.dump(u'\U0001F4A9'.encode('utf-16-le')) == '"\\ufffd\\U0001F4A9"\n'

# Generated at 2022-06-22 14:00:29.165809
# Unit test for function represent_binary
def test_represent_binary():
    assert binary_type(yaml.dump(b'hello')) == binary_type("'hello'\n")
    assert binary_type(AnsibleDumper(None, default_flow_style=False).represent_binary(b'hello')) == binary_type("!!binary |\n  aGVsbG8=\n")
    assert binary_type(AnsibleDumper(None, default_flow_style=True).represent_binary(b'hello')) == binary_type("!!binary 'aGVsbG8='\n")

