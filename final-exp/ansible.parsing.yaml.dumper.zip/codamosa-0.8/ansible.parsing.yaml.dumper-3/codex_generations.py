

# Generated at 2022-06-22 13:51:13.405323
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    ustr = '\u2767'
    output1 = dumper.represent_unicode(dumper, text_type(ustr))
    output2 = dumper.represent_unicode(dumper, bytes_to_text(ustr.encode('utf-8')))
    output3 = u'!ansible_unsafe {}'.format(ustr)
    assert output1 == output2 == output3


# Generated at 2022-06-22 13:51:22.369352
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template.safe_eval import ansible_safe_eval

    # Test only for _fail_with_undefined_error being called or not and not
    # for exception type being thrown as _fail_with_undefined_error has been
    # overridden not to raise an exception

    # _fail_with_undefined_error should be called
    ansible_safe_eval.STRICT_UNDEFINED = True
    assert represent_undefined(None, AnsibleUndefined)
    ansible_safe_eval.STRICT_UNDEFINED = False

    # _fail_with_undefined_error should be called
    ansible_safe_eval.STRICT_UNDEFINED = True
    assert represent_undefined(None, AnsibleUndefined)

# Generated at 2022-06-22 13:51:29.930637
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars import HostVars
    from ansible.compat.tests.mock import patch
    from io import StringIO
    hostvars = HostVars(dict(a=1))

    with patch.object(AnsibleDumper, 'represent_dict') as mock_method:
        mock_method.return_value = u'foo'
        f = StringIO()
        dumper = AnsibleDumper(f)
        represent_hostvars(dumper, hostvars)

        mock_method.assert_called_with(hostvars)

# Generated at 2022-06-22 13:51:37.544348
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class TestClass:
        def __bool__(self):
            raise AssertionError()

    o = TestClass()

    dumper = AnsibleDumper()
    try:
        dumper.represent_data(o)
    except AssertionError as e:
        pass


AnsibleDumper.add_multi_representer(
    type(None),
    yaml.representer.SafeRepresenter.represent_none,
)

AnsibleDumper.ignore_aliases = lambda self, data: True

safe_dump = yaml.dump
dump = yaml.dump

# Generated at 2022-06-22 13:51:44.641723
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper
    original = {'a': 'ok', 'b': {'c': 'ok'}}
    expected = dumper.represent_dict(original)
    hvars = HostVars(original)
    actual = dumper.represent_hostvars(hvars)
    assert expected == actual
    actual2 = dumper.represent_hostvars(HostVars(original))
    assert expected == actual2



# Generated at 2022-06-22 13:51:48.744804
# Unit test for function represent_hostvars
def test_represent_hostvars():
    test_data = HostVars({'a': 1})
    assert yaml.dump(test_data, Dumper=AnsibleDumper) == 'a: 1\n'


if __name__ == '__main__':
    test_represent_hostvars()

# Generated at 2022-06-22 13:52:00.789539
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    secret = 'test'
    vault_secret = AnsibleVaultEncryptedUnicode(secret)

# Generated at 2022-06-22 13:52:02.786234
# Unit test for function represent_binary
def test_represent_binary():
    data = AnsibleUnsafeBytes('test')
    dumper = yaml.representer.SafeRepresenter()
    dumper.represent_binary(data)
    dumper.represent_binary(None)
    if dumper.represent_binary(data) != dumper.represent_str(data):
        raise AssertionError()

# Generated at 2022-06-22 13:52:12.480426
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():

    # Note: only want to represent the encrypted data
    dumper = AnsibleDumper(None)
    result = dumper.represent_scalar(u'!vault', AnsibleVaultEncryptedUnicode('test')._ciphertext.decode(), style="|")

# Generated at 2022-06-22 13:52:15.824917
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode(u'foo'), Dumper=AnsibleDumper) == u'foo\n...\n'



# Generated at 2022-06-22 13:52:29.698325
# Unit test for function represent_unicode
def test_represent_unicode():
    from ansible.module_utils.six import StringIO

    # unicode string
    data = u"test_represent_unicode"
    stream = StringIO()
    AnsibleDumper.represent_unicode(AnsibleDumper, data)
    AnsibleDumper.represent_unicode(AnsibleDumper, data).encode('utf-8').decode('utf-8', errors='strict')
    AnsibleDumper.represent_unicode(AnsibleDumper, data).encode('utf-16', 'surrogatepass').decode('utf-16')

    # non-unicode string
    data = b'test_represent_unicode'
    stream = StringIO()
    AnsibleDumper.represent_unicode(AnsibleDumper, data)

# Generated at 2022-06-22 13:52:32.705110
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    repr = yaml.dump(AnsibleUndefined, Dumper=dumper)
    assert repr == ''

# Generated at 2022-06-22 13:52:34.170899
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    dumper.represent_unicode('foo')

# Generated at 2022-06-22 13:52:45.539174
# Unit test for function represent_unicode
def test_represent_unicode():
    # Pre Ansible 2.5, the representation was '1.2'
    assert yaml.dump(AnsibleUnicode('1.2'), Dumper=AnsibleDumper).strip() == '1.2'

    # Post Ansible 2.5, it should be '1.2'
    assert yaml.dump(AnsibleUnicode('1.2'), Dumper=AnsibleDumper).strip() == '1.2'

    # Post Ansible 2.5, it should be '1.2'
    assert yaml.dump(AnsibleUnicode('1.2'), Dumper=AnsibleDumper).strip() == '1.2'

    # Post Ansible 2.5, it should be '1.2'

# Generated at 2022-06-22 13:52:53.121796
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    Dumper = AnsibleDumper
    data = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\nblahblahblahblahblah')
    result = Dumper.represent_vault_encrypted_unicode(Dumper, data)
    assert result == "!vault |\n  $ANSIBLE_VAULT;1.1;AES256\n  blahblahblahblahblah\n"

# Generated at 2022-06-22 13:52:57.509080
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # This should not raise an exception
    foo = AnsibleVaultEncryptedUnicode('foo')
    bar = AnsibleVaultEncryptedUnicode(foo)
    AnsibleDumper.represent_vault_encrypted_unicode(bar)

# Generated at 2022-06-22 13:53:01.925124
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(AnsibleDumper, '\xc3\xbf') == u'!u8 \'\xff\''
    assert represent_unicode(AnsibleDumper, '\xc3\xbf'.decode('utf8')) == u'!u \'\xff\''


# Generated at 2022-06-22 13:53:04.239921
# Unit test for function represent_hostvars
def test_represent_hostvars():

    data = {'a': 1, 'b': 2}
    assert represent_hostvars(None, data) == represent_hostvars(None, HostVars(data))

# Generated at 2022-06-22 13:53:10.455249
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    string = AnsibleVaultEncryptedUnicode("$ANSIBLE_VAULT;1.1;AES256\n62626262626262626262626262626262626262626262626262626262626262626262626262626262\n626262626262626262626262626262")
    assert represent_vault_encrypted_unicode(AnsibleDumper(), string) == '!vault |\n  $ANSIBLE_VAULT;1.1;AES256\n  62626262626262626262626262626262626262626262626262626262626262626262626262626262\n  626262626262626262626262626262\n'


# Generated at 2022-06-22 13:53:11.543211
# Unit test for function represent_hostvars
def test_represent_hostvars():
    pass


# Generated at 2022-06-22 13:53:23.714818
# Unit test for function represent_undefined
def test_represent_undefined():
    import ansible.utils.unsafe_proxy
    assert represent_undefined(None, ansible.utils.unsafe_proxy.AnsibleUndefined("<unit test>"))

try:
    from typing import TypeVar, Optional, Any
    T = TypeVar("T", AnsibleUnicode, AnsibleUnsafeText)
    U = TypeVar("U")

    class AnsibleDumper_T(AnsibleDumper):
        def represent_data(self, data):
            # type: (T) -> Any
            return self.represent_data(data)  # type: ignore

        def represent_data(self, data):
            # type: (U) -> Any
            return self.represent_data(data)  # type: ignore
except ImportError:
    pass

# Generated at 2022-06-22 13:53:35.006578
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-22 13:53:46.794312
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():

    test_data1 = AnsibleVaultEncryptedUnicode("I'm a ninja turtle.")
    test_data2 = AnsibleVaultEncryptedUnicode("My name is not Raphael.")
    test_data3 = AnsibleVaultEncryptedUnicode("YEAH!")
    assert represent_vault_encrypted_unicode(AnsibleDumper, test_data1) == "!vault |\n          c3BlY2lhbCBoZWFkcw=="
    assert represent_vault_encrypted_unicode(AnsibleDumper, test_data2) == "!vault |\n          c3BlY2lhbCBoZWFkcw=="

# Generated at 2022-06-22 13:53:51.702763
# Unit test for function represent_unicode
def test_represent_unicode():
    sequence = [
        AnsibleUnicode(1),
        AnsibleUnicode(2),
        AnsibleUnicode(3),
    ]

    assert yaml.dump(sequence, Dumper=AnsibleDumper) == text_type(
        u'[1, 2, 3]\n'
    )


# Generated at 2022-06-22 13:54:03.215042
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-22 13:54:08.892081
# Unit test for function represent_unicode
def test_represent_unicode():
    try:
        # Since both the following classes are marked with __metaclass__
        # = EncodingType, they should be able to use the same representer
        # function.
        from ansible.parsing.yaml.objects import AnsibleSequence

        assert(represent_unicode is represent_binary)
    except ImportError:
        # Deal with a packaging bug in Ansible 1.4
        pass



# Generated at 2022-06-22 13:54:18.543543
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    value = AnsibleVaultEncryptedUnicode('8dvfYGTjbPpRqRjE45J6GpU6FzfYl1TsQr19Z6CcZ/hDZF0MRxa3qLqm9yvQKm1h')

# Generated at 2022-06-22 13:54:26.898415
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    string = '$ANSIBLE_VAULT;1.1;AES256\n'
    string += '356366376664613030313962653961646134383538656531386362366565396139653933363561\n'
    string += '39666164366639393037636562653064333038353865343663316662320a636133313731386142\n'
    string += '373638326335306561633831613031393830643862633135313531373631623166373162653031\n'
    string += '63653665323536633762313663376139660a303866666436626264323962656463643561333963\n'

# Generated at 2022-06-22 13:54:33.835785
# Unit test for function represent_unicode
def test_represent_unicode():
    expected_output = "b'abc'\n"
    ansible_unicode = AnsibleUnicode('abc')

    unsafe_text = AnsibleUnsafeText('abc')

    unsafe_bytes = AnsibleUnsafeBytes('abc')
    actual_output = yaml.dump(ansible_unicode, Dumper=AnsibleDumper)
    assert actual_output == expected_output
    actual_output = yaml.dump(unsafe_text, Dumper=AnsibleDumper)
    assert actual_output == expected_output
    actual_output = yaml.dump(unsafe_bytes, Dumper=AnsibleDumper)
    assert actual_output == "abc\n..."



# Generated at 2022-06-22 13:54:39.022220
# Unit test for function represent_unicode
def test_represent_unicode():
    data = u'foo: \t \n \t \nbar: baz'

    # Note: using yaml.load() instead of yaml.safe_load()
    # to get the original string obj
    assert data == yaml.load(
        yaml.dump(data, Dumper=AnsibleDumper)
    )



# Generated at 2022-06-22 13:54:45.395077
# Unit test for function represent_undefined
def test_represent_undefined():
    import sys
    dumper = AnsibleDumper(width=100, default_flow_style=False, stream=sys.stdout)
    assert dumper.represent_undefined(AnsibleUndefined())



# Generated at 2022-06-22 13:54:55.781592
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 13:55:03.645051
# Unit test for function represent_hostvars
def test_represent_hostvars():

    dumper_obj = AnsibleDumper()
    assert dumper_obj.represent_hostvars(HostVars({'f1': 'v1', 'f2': {'f2.1': 'v2.1', 'f2.2': 'v2.2'}})) == \
        {'f1': 'v1', 'f2': {'f2.1': 'v2.1', 'f2.2': 'v2.2'}}

# Generated at 2022-06-22 13:55:12.963421
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = {u'a': '1', u'b': '2', u'c': '3'}
    v = VarsWithSources(vars=data)
    # VarsWithSources can be represented by a dict, so the result is:
    # {'a': '1', 'c': '3', 'b': '2'}
    assert yaml.dump(v, Dumper=AnsibleDumper, default_flow_style=False) == \
        u"{a: 1, b: 2, c: 3}\n"
    # but HostVarsVars can't.
    v = HostVarsVars(vars=data)

# Generated at 2022-06-22 13:55:20.398891
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import fail_with_undefined_error
    from ansible.utils.unsafe_proxy import wrap_var

    dumper = AnsibleDumper()

    assert dumper.represent_undefined(fail_with_undefined_error(wrap_var(AnsibleUndefined)))

    # fails if object type is not AnsibleUndefined
    try:
        dumper.represent_undefined(fail_with_undefined_error(wrap_var(int(1))))
        assert False
    except AssertionError:
        pass

# Generated at 2022-06-22 13:55:27.819812
# Unit test for function represent_undefined
def test_represent_undefined():
    # Make sure that we raise a failure if _fail_with_undefined_error is set.
    # This is normally set in Ansible's AnsibleUndefined, but we want to
    # test the underlying function here, so set the flag manually
    u = AnsibleUndefined()
    u._fail_with_undefined_error = True

    try:
        represent_undefined(AnsibleDumper(), u)
    except Exception as e:
        assert 'AnsibleUndefinedVariable: error while evaluating conditional' in e.args[0]
        assert 'AnsibleUndefinedVariable: One or more undefined variables: \'undefined\'' in e.args[0]

    # Make sure that we don't raise a failure if _fail_with_undefined_error is not set.
    # This is normally set in Ansible's AnsibleUndefined,

# Generated at 2022-06-22 13:55:34.837545
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import AnsibleUndefined
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # False, according to python equality rules
    assert AnsibleUndefined("foo") == "foo"
    assert AnsibleUndefined("foo") != "bar"
    assert AnsibleUndefined("foo") != 1
    assert AnsibleUndefined("foo") != b"foo"
    assert AnsibleUndefined("foo") != AnsibleUnsafeText("foo")

# Generated at 2022-06-22 13:55:40.712932
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    vault = VaultLib([])
    ciphertext = vault.encrypt('test value')
    encrypted_unicode = AnsibleVaultEncryptedUnicode(ciphertext)
    dumped_ciphertext = yaml.dump(encrypted_unicode, Dumper=AnsibleDumper)
    assert dumped_ciphertext == u'!vault |\n  ' + ciphertext + u'\n'

# Generated at 2022-06-22 13:55:46.433741
# Unit test for function represent_undefined
def test_represent_undefined():
    # Note: Since a function is passed as third argument,
    # bool() will be invoked.
    # So representer.BaseRepresenter.represent_bool()
    # will be called which will again call this function.
    # That's why here we need to return True/False.
    class Dummy(object):
        pass
    dump = yaml.dumps(Dummy())
    assert dump == 'true\n'

# Generated at 2022-06-22 13:55:56.651481
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = {
        'hosts': {
            'host1': {
                'host_name': 'host1',
            },
            'host2': {
                'host_name': 'host2',
            },
        },
        'groups': {
            'group1': {
                'hosts': ['host1', 'host2'],
                'group_name': 'group1',
            },
        },
    }
    hostvars = HostVars(data)

    assert yaml.dump(hostvars, Dumper=AnsibleDumper) == """\
{hosts: {host1: {host_name: host1}, host2: {host_name: host2}},
groups: {group1: {hosts: [host1, host2], group_name: group1}}}
"""


#