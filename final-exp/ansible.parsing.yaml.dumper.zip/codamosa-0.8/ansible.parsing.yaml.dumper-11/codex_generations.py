

# Generated at 2022-06-22 13:51:09.987426
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u"!u'foo'\n"



# Generated at 2022-06-22 13:51:13.705984
# Unit test for function represent_unicode
def test_represent_unicode():

    dumper = AnsibleDumper

    input = AnsibleUnicode('abc')

    output = dumper.represent_unicode(dumper, input)

    assert output == "'abc'\n"



# Generated at 2022-06-22 13:51:22.557708
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.manager import find_needle

    test_hv = HostVars(dict(test_var='test_value', test_var_two='test_value_two'), 'inventory_hostname_short')
    test_hvv = HostVarsVars(ansible_vars=dict(test_var='test_value'))
    represent_hostvars(None, test_hv)  # hostvars, no defined variables
    represent_hostvars(None, test_hvv)  # defined variables, no hostvars

    needle = dict(test_var_two='test_value_two')

# Generated at 2022-06-22 13:51:26.084204
# Unit test for function represent_binary
def test_represent_binary():
    data = b'i\x9ci'
    expected_yaml = '!!binary "aS9jaQ==\\n"'
    assert yaml.dump(data, Dumper=AnsibleDumper) == expected_yaml

# Generated at 2022-06-22 13:51:32.360883
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    expected = '!vault |\n          \'AES256\'\n          \'ciphertext\'\n'
    ansible_unicode = AnsibleUnicode('test')
    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode(ansible_unicode)
    actual = AnsibleDumper.represent_vault_encrypted_unicode(AnsibleDumper, ansible_vault_encrypted_unicode)
    assert actual == expected

# Generated at 2022-06-22 13:51:38.673475
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # Tests that an object of type HostVars is represented as a dictionary
    hostvars = HostVars()
    hostvars.add_public('ansible_host', '10.10.10.10')
    hostvars.add_public('ansible_user', 'myuser')
    hostvars.add_private('ansible_password', 'mypass')
    output = yaml.dump([hostvars], Dumper=AnsibleDumper, default_flow_style=False)
    assert output.strip() == "- ansible_host: 10.10.10.10\n  ansible_user: myuser"

# Generated at 2022-06-22 13:51:40.789631
# Unit test for function represent_hostvars
def test_represent_hostvars():
    t = yaml.load('{}')
    assert isinstance(t, dict)


# Generated at 2022-06-22 13:51:52.672037
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    obj = AnsibleVaultEncryptedUnicode(u'$ANSIBLE_VAULT;1.1;AES256\n63343531353433323961633864396230333765613861323165326139356466336534666463356339\n31356565643936343164613239643633376363643930663365396365336231636438363466653265\n3962613438363232383633383761643133373835386630653339\n')
    dumper = AnsibleDumper()
    val = dumper.represent_data(obj)

# Generated at 2022-06-22 13:52:05.154588
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader

    secret = "Vault encrypted string.\n"
    vault_secret = VaultLib(password=u'test').encrypt(secret.encode('utf-8'))
    value = AnsibleVaultEncryptedUnicode(vault_secret)
    dump = yaml.dump(value, Dumper=AnsibleDumper, default_flow_style=False)

# Generated at 2022-06-22 13:52:13.375379
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 13:52:18.697417
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    binary = b'\xff\xa3'
    assert dumper.represent_binary(dumper, binary) == \
        u"!!binary |\n" + \
        u"  /+M1\n"

# Generated at 2022-06-22 13:52:21.300220
# Unit test for function represent_unicode
def test_represent_unicode():
    yaml.dump(u'foo', Dumper=AnsibleDumper)



# Generated at 2022-06-22 13:52:28.414703
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper(width=4096)

# Generated at 2022-06-22 13:52:40.240171
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    ciphertext = '$ANSIBLE_VAULT;1.1;AES256;testuser_testhost_testpid_1000\n393930343562616663323730623633363439666335353336303336643735336430333566383561\n303362643965613066336663356537613262636136656563653134663161666339326262613535\n373833316661303637376262626136666530363930353431393733636537626536626236333439\n65333065\n'
    dumper = AnsibleDumper()
    result = dumper.represent_scalar(u'!vault', ciphertext.decode(), style='|')

# Generated at 2022-06-22 13:52:52.164205
# Unit test for function represent_undefined
def test_represent_undefined():
    # Arbitrary values will work as long as they are not
    # an AnsibleUndefined._object
    previous_value = text_type('foo')
    new_value = text_type('bar')

    # Save original _object
    prev_object = AnsibleUndefined._object
    AnsibleUndefined._object = previous_value

    # Test if False when we expect it to be
    assert represent_undefined(AnsibleDumper, False) is False
    assert represent_undefined(AnsibleDumper, 1) is False
    assert represent_undefined(AnsibleDumper, []) is False
    assert represent_undefined(AnsibleDumper, {}) is False

    # Test that it is True when we expect it to be
    assert represent_undefined(AnsibleDumper, AnsibleUndefined()) is True

   

# Generated at 2022-06-22 13:52:59.418679
# Unit test for function represent_undefined
def test_represent_undefined():
    # _fail_with_undefined_error is encapsulated in AnsibleDumper
    # so it doesn't exist to be patched without creating our own Dumper
    # which might be better to do for testing.
    # However for now here is a simple test for the function and
    # it does give us coverage for this function in case the
    # function were to change.
    assert not represent_undefined(AnsibleDumper, AnsibleUndefined())

# Generated at 2022-06-22 13:53:03.142137
# Unit test for function represent_unicode
def test_represent_unicode():
    doc = dict(invalid_utf8_bytes=b'\xff')
    dump = yaml.dump(doc)
    assert dump == u"invalid_utf8_bytes: \"\\xff\"\n"
    assert isinstance(dump, text_type)

# Generated at 2022-06-22 13:53:06.592376
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert not dumper.represent_undefined(AnsibleUndefined('foo'))
    assert not dumper.represent_undefined(AnsibleUndefined())

# Generated at 2022-06-22 13:53:13.663804
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # This is what SafeDumper.represent_str would return:
    str_repr = "'dGVzdA=='\n"

    test_object = AnsibleVaultEncryptedUnicode('test')
    assert represent_vault_encrypted_unicode(AnsibleDumper, test_object) == str_repr

# Generated at 2022-06-22 13:53:21.227049
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(dict(value=u'foobar'), Dumper=AnsibleDumper) == 'value: foobar\n'
    # Something we want escaped
    assert yaml.dump(dict(value=AnsibleUnicode(u"foo\nbar")), Dumper=AnsibleDumper) == 'value: "foo\\nbar"\n'
    # Something we don't want escaped
    assert yaml.dump(dict(value=AnsibleUnicode(u"foo\tbar")), Dumper=AnsibleDumper) == 'value: "foo\tbar"\n'


# Generated at 2022-06-22 13:53:34.637084
# Unit test for function represent_undefined
def test_represent_undefined():
    '''
    Verify that the AnsibleUndefined object will pass through the YAML
    representer correctly, resulting in a _fail_with_undefined_error
    call.
    '''
    # This test is necessary because YAML calls the bool() function of
    # the object it is dumping. So if we don't add the correct __bool__
    # to AnsibleUndefined in the jinja2 library, then this test will fail.
    # See https://github.com/ansible/ansible/issues/14134
    from ansible.template import Jinja2Template
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-22 13:53:38.371301
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = AnsibleVaultEncryptedUnicode('test')
    assert represent_vault_encrypted_unicode(AnsibleDumper, data) == "!vault |\n  test\n"

# Generated at 2022-06-22 13:53:49.007794
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    '''
    Ensure that the !vault tag is properly set
    '''
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    password = 'password'
    vault = AnsibleVaultEncryptedUnicode()
    ciphertext = vault.vault.encrypt(password, 'secret password for testing')
    vault._ciphertext = ciphertext
    assert isinstance(vault, AnsibleVaultEncryptedUnicode)
    reversed_vault = yaml.load(yaml.dump(vault, Dumper=AnsibleDumper), Loader=yaml.SafeLoader)
    assert isinstance(reversed_vault, AnsibleVaultEncryptedUnicode)
    assert reversed_vault._ciphertext == ciphertext

# Generated at 2022-06-22 13:53:59.973022
# Unit test for function represent_binary
def test_represent_binary():
    '''
    Test that we can dump binary data using the YAML representer.
    '''
    # Python 2 / Python 3 compatibility
    try:
        basestring
    except NameError:
        basestring = str

    # Python 3 / str is unicode
    # Python 2 / str is binary
    binary_data = 'binary data\x00abcd'
    data = basestring(binary_data)
    dumper = AnsibleDumper
    dumped = dumper.represent_binary(dumper, data)
    assert dumped is not None
    assert dumped == "!!binary |\n  " + "YmluYXJ5IGRhdGEAAGFiYw==\n"

# Generated at 2022-06-22 13:54:04.092309
# Unit test for function represent_unicode
def test_represent_unicode():
    data = {'foo': 'yÖ'}

    output = yaml.dump(data, Dumper=AnsibleDumper)

    assert isinstance(output, text_type)
    assert output == 'foo: yÖ\n'



# Generated at 2022-06-22 13:54:14.221407
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Note: We are able to reuse the same unit test for the functions
    # represent_vault_encrypted_unicode and represent_unicode since
    # we had added represent_unicode as a representer for AnsibleVaultEncryptedUnicode
    # during AnsibleDumper.add_representer above.
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    dumper = AnsibleDumper

# Generated at 2022-06-22 13:54:20.221251
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper(width=1000)
    unicode_value = u'\x80\x81\x82\x83\u20ac'
    binary_value = unicode_value.encode('utf-8')
    assert '\x80\x81\x82\x83\u20ac' == dumper.represent_data(unicode_value)
    assert '\x80\x81\x82\x83\u20ac' == dumper.represent_data(binary_value)

# Generated at 2022-06-22 13:54:25.205975
# Unit test for function represent_binary
def test_represent_binary():
    class TestData:
        def __bytes__(self):
            return b'hello world'
    data = TestData()
    assert yaml.dump(data, Dumper=AnsibleDumper) == '!!python/object/new:ansible.module_utils.common.yaml.objects.AnsibleUnsafeBytes {data: !!binary "aGVsbG8gd29ybGQ="}\n'


# Generated at 2022-06-22 13:54:31.538957
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    import ansible.parsing.vault
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    plaintext = u'asdf'
    password = u'asdf'

    vault = VaultLib([])
    ciphertext = vault.encrypt(plaintext, password=password)
    ciphertext_unicode = ciphertext
    data = AnsibleVaultEncryptedUnicode(ciphertext_unicode)
    result = represent_vault_encrypted_unicode(AnsibleDumper, data)
    assert result.endswith('!vault |')

# Generated at 2022-06-22 13:54:36.401400
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper(width=1000)
    stream = dumper.stream
    dumper.represent_undefined(AnsibleUndefined())
    assert stream.getvalue() == u''

# Generated at 2022-06-22 13:54:44.894302
# Unit test for function represent_undefined
def test_represent_undefined():
    result = ''
    try:
        AnsibleDumper.add_representer(
            AnsibleUndefined,
            represent_undefined,
        )
        result = yaml.dump(AnsibleUndefined(failed=False), Dumper=AnsibleDumper)
    except yaml.representer.RepresenterError:
        pass
    return result

# Generated at 2022-06-22 13:54:49.714406
# Unit test for function represent_undefined
def test_represent_undefined():
    assert not represent_undefined(None, object())
    assert not represent_undefined(None, AnsibleUndefined(obj='test',
                                                          hint='HINT!'))

# Generated at 2022-06-22 13:54:50.613638
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper) == ''

# Generated at 2022-06-22 13:54:52.175304
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    assert dumper.represent_undefined(AnsibleUndefined())



# Generated at 2022-06-22 13:54:54.279680
# Unit test for function represent_unicode
def test_represent_unicode():
    data = b'foo'
    ansible_dumper = AnsibleDumper
    ansible_dumper.represent_unicode(ansible_dumper, data)
    assert True

# Generated at 2022-06-22 13:54:59.266871
# Unit test for function represent_binary
def test_represent_binary():
    # This is a byte string with a byte representing a newline
    # character, which is a common way of representing a binary
    # string when writing unit tests.
    val = b'foo\nbaz'
    assert val == yaml.load(yaml.dump(val, Dumper=AnsibleDumper))



# Generated at 2022-06-22 13:55:06.875695
# Unit test for function represent_binary
def test_represent_binary():
    from io import StringIO
    from ansible.module_utils.six import b

    dumper = AnsibleDumper(StringIO(), default_flow_style=False)
    value = b("value")
    result = dumper.represent_binary(value)
    assert result is not None
    assert result.tag == b("tag:yaml.org,2002:binary")
    assert result.value == b("dmFsdWU=\n")
    assert result.style == b("|")

# Generated at 2022-06-22 13:55:14.335950
# Unit test for function represent_unicode
def test_represent_unicode():
    # Note: Need to test
    #  1. unicode string
    #  2. byte string
    #  3. number
    #  4. None
    #  5. objects and types other than string and number
    #  6. ansible unicode type

    # We require the types to be encoded
    # This is important while testing byte string
    dumper = yaml.Dumper(allow_unicode=True)

    # Monkey patch the representer to use
    dumper.add_representer(
        AnsibleUnicode,
        represent_unicode,
    )

    # This is not a ansible unicode type
    # 1 & 3
    rv = dumper.represent_unicode('இலவசமா?')

# Generated at 2022-06-22 13:55:24.384753
# Unit test for function represent_unicode
def test_represent_unicode():
    "Test represent_unicode for non-ascii unicode"
    # Setup the dumper
    a_unicode = u"\u20ac3.50"
    a_bytes = b'\xe2\x82\xac3.50'
    dumper = AnsibleDumper

    # We want to test that this outputs a correct string
    yaml_str = dumper.represent_unicode(dumper, a_unicode)

    # The returned value should be a representer node
    assert isinstance(yaml_str, yaml.representer.RepresenterNode)

    # The tag of that value should be: tag:yaml.org,2002:str
    assert yaml_str.tag == u'tag:yaml.org,2002:str'

    # The value should be the bytes encoding of the unicode
   

# Generated at 2022-06-22 13:55:34.524800
# Unit test for function represent_binary
def test_represent_binary():
    representer = yaml.representer.SafeRepresenter()
    dumper = yaml.SafeDumper
    dumper.add_representer(binary_type, representer.represent_binary)

    class AutoDumper(dumper):
        def ignore_aliases(self, data):
            return True

    class AutoRepresenter(representer):
        def ignore_aliases(self, data):
            return True

    representer_orig = dumper.represent_binary
    representer_all = AutoRepresenter.represent_binary
    assert representer_orig(dumper, "") == representer_all(AutoDumper, b"")

# Generated at 2022-06-22 13:55:39.612204
# Unit test for function represent_binary
def test_represent_binary():
    dumper = yaml.SafeDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v\n'
    assert dumper.represent_binary(dumper, 'foo') == u"!!binary |\n  Zm9v\n"

# Generated at 2022-06-22 13:55:48.876724
# Unit test for function represent_unicode
def test_represent_unicode():
    # Test non-ASCII characters in unicode
    udata = u'\u2665'
    assert represent_unicode(None, udata) == udata
    # Test non-ASCII characters in str
    udata = b'\xe2\x99\xa5'
    assert represent_unicode(None, udata) == udata
    # Test NoneType in unicode
    udata = None
    assert represent_unicode(None, udata) == udata
    # Test NoneType in str
    udata = b'None'
    assert represent_unicode(None, udata) == udata

# Generated at 2022-06-22 13:55:57.783623
# Unit test for function represent_undefined
def test_represent_undefined():
    '''
    Test function represent_undefined.

    This will ensure that AnsibleUndefined
    works with `bool` as intended, meaning
    _fail_with_undefined_error is called.
    '''
    from ansible.template.vars import AnsibleUndefined

    # define the things yaml.add_representer needs
    class Dumper(object):
        pass

    dumper = Dumper()
    dumper.represent_scalar = lambda foo, bar, baz: None

    # do not use the actual function here
    representer = lambda self, data: True
    # call add_representer with our stub
    yaml.add_representer(AnsibleUndefined, representer, Dumper=dumper)

    # ensure our stub is called
    assert representer(dumper, 'foo')
    #

# Generated at 2022-06-22 13:56:02.286452
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    data = AnsibleUndefined()
    assert dumper.represent_data(data) is False
    data = 'test'
    assert dumper.represent_data(data) is True

# Generated at 2022-06-22 13:56:08.537504
# Unit test for function represent_binary
def test_represent_binary():
    from ansible.compat.tests.mock import patch
    test_dumper = yaml.SafeDumper

    represent_binary(test_dumper, '123')

    with patch.object(test_dumper, 'represent_scalar') as represent_scalar_mock:
        represent_binary(test_dumper, b'123')
        represent_scalar_mock.assert_called_once_with('!binary', 'MTIz', style='|')

# Generated at 2022-06-22 13:56:10.822800
# Unit test for function represent_binary
def test_represent_binary():
    assert AnsibleDumper.represent_binary(bytes("foo", "ascii")) == b"!binary |\n  Zm9v\n"

# Generated at 2022-06-22 13:56:17.334068
# Unit test for function represent_binary
def test_represent_binary():
    """ This method unit tests the represent_binary function in this file.
        This method simply dumps the test_str to yaml and loads it back in.
        If the test_str is not loaded in correctly, an AssertionError is thrown.
    """
    test_str = b'test'
    assert_str = yaml.dump(test_str)
    assert yaml.load(assert_str) == test_str

# Generated at 2022-06-22 13:56:19.774762
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    rep = dumper.represent_undefined(dumper, AnsibleUndefined())
    assert(rep is True)

# Generated at 2022-06-22 13:56:29.656388
# Unit test for function represent_undefined
def test_represent_undefined():
    d = yaml.dumper.SafeDumper(
        None,
        default_flow_style=False,
    )

    t = AnsibleUndefined
    assert d.represent_undefined(t) is t


yaml.add_representer(AnsibleUnicode, represent_unicode)
yaml.add_representer(AnsibleUnsafeText, represent_unicode)
yaml.add_representer(AnsibleUnsafeBytes, represent_binary)
yaml.add_representer(HostVars, represent_hostvars)
yaml.add_representer(HostVarsVars, represent_hostvars)
yaml.add_representer(VarsWithSources, represent_hostvars)

# Generated at 2022-06-22 13:56:33.094346
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    unicode_data = u"unicode string"
    assert isinstance(dumper.represent_unicode(dumper, unicode_data), yaml.representer.ScalarNode)
    assert dumper.represent_unicode(dumper, unicode_data).tag == u'tag:yaml.org,2002:str'


# Generated at 2022-06-22 13:56:39.755017
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    result = dumper.represent_binary('b\x9a\x04\x00\x00')
    expected = u'!!binary |\n  biFwaA==\n'
    assert result == expected

# Generated at 2022-06-22 13:56:43.860665
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper

    data = 'foo\nbar'
    s = yaml.ScalarNode('tag:yaml.org,2002:str', data)
    assert dumper.represent_scalar(u'!binary', data) == s


# Generated at 2022-06-22 13:56:46.715825
# Unit test for function represent_unicode
def test_represent_unicode():
    ''' Test the function represent_unicode to ensure it encodes unicode '''
    assert(yaml.dump(u'unicode string') == yaml.dump(text_type(u'unicode string')))

# Generated at 2022-06-22 13:56:48.340150
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(AnsibleDumper, 'hello world') == 'hello world'



# Generated at 2022-06-22 13:56:58.925225
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template.safe_eval import _fail_with_undefined_error

    # Without this, the function is not called
    yaml.add_representer(AnsibleUndefined, represent_undefined)

    # These 3 lines should be enough, but there
    # is an issue with the fact that Undefined
    # class is not affected by the _fail_with_undefined_error
    # decorator and also the fact that BaseLoader does
    # not support constructor argument
    yaml.add_constructor(
        u'tag:yaml.org,2002:bool',
        yaml.constructor.SafeConstructor.construct_yaml_bool
    )

# Generated at 2022-06-22 13:57:10.493817
# Unit test for function represent_unicode
def test_represent_unicode():
    from ansible.parsing.yaml import objects
    from ansible.module_utils.six import binary_type
    utf8_string = u'Fran\xe7ois'
    unicode_obj = objects.AnsibleUnicode(utf8_string)
    assert unicode_obj == utf8_string
    assert unicode_obj._dump_data() == utf8_string
    assert isinstance(unicode_obj, text_type)
    assert not isinstance(unicode_obj, binary_type)
    assert unicode_obj._has_ansible_types()
    assert unicode_obj._dump_data() == utf8_string
    assert objects.ansible_types(u'Fran\xe7ois') == unicode_obj

# Generated at 2022-06-22 13:57:14.838242
# Unit test for function represent_unicode
def test_represent_unicode():
    a_unicode = AnsibleUnicode(u'foo')
    assert represent_unicode(AnsibleDumper, a_unicode) == u'foo', 'Unicode handling failed'



# Generated at 2022-06-22 13:57:16.838437
# Unit test for function represent_undefined
def test_represent_undefined():
    assert represent_undefined(AnsibleDumper, AnsibleUndefined()) is False

# Generated at 2022-06-22 13:57:21.444339
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import StrictUndefined
    from ansible.vars.hostvars import HostVarsVars

    hvv = HostVarsVars()
    hvv.update({'rendered': StrictUndefined})
    hvv.update({'computed': StrictUndefined})
    assert hvv == represent_undefined(None, hvv)

# Generated at 2022-06-22 13:57:23.853538
# Unit test for function represent_undefined
def test_represent_undefined():
    some_undefined = AnsibleUndefined('some_undefined')
    assert yaml.dump([some_undefined], Dumper=AnsibleDumper) == '- _ansible_undefined_variable\n'

# Generated at 2022-06-22 13:57:27.954143
# Unit test for function represent_undefined
def test_represent_undefined():
    ad = AnsibleDumper()
    assert ad.represent_data(AnsibleUndefined()) == False

# Generated at 2022-06-22 13:57:31.837631
# Unit test for function represent_unicode
def test_represent_unicode():

    class FooUnicode(object):
        def __unicode__(self):
            return 'foo'

    assert yaml.dump(FooUnicode(), Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-22 13:57:42.896426
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    # Input string contains special characters, needs to be quoted with ""
    expected = u'"&_%*"'
    actual = dumper.represent_unicode(u'&_%*')
    assert actual == expected

    # Input string does not contain special characters, quoted with ''
    expected = u"'%YAML 1.1---'"
    actual = dumper.represent_unicode(u'%YAML 1.1---')
    assert actual == expected

    # Input string contains a single ' which is not quoted
    expected = u"'%YAML:1.0'"
    actual = dumper.represent_unicode(u'%YAML:1.0')
    assert actual == expected



# Generated at 2022-06-22 13:57:44.471665
# Unit test for function represent_undefined
def test_represent_undefined():

    dumper = AnsibleDumper(None, None, None, None)

    assert not dumper.represent_undefined(AnsibleUndefined(None))

# Generated at 2022-06-22 13:57:46.120620
# Unit test for function represent_undefined
def test_represent_undefined():
    y = yaml.dump(AnsibleUndefined, Dumper=AnsibleDumper)
    assert y is None

# Generated at 2022-06-22 13:57:52.781077
# Unit test for function represent_binary
def test_represent_binary():
    text = "abc\x01\x02\x03abc"
    assert yaml.dump(text, Dumper=AnsibleDumper) == "!!binary |+\n  YWJjADEAYwBiAGMAYwBiAGM=\n"
    assert yaml.load(yaml.dump(text, Dumper=AnsibleDumper)) == text

# Generated at 2022-06-22 13:58:02.686679
# Unit test for function represent_unicode
def test_represent_unicode():
    # Test with simple string
    string = u"Ansible is great"
    assert represent_unicode(AnsibleDumper, string) == yaml.representer.SafeRepresenter.represent_str(AnsibleDumper, text_type(string))

    # Test with special characters
    string = u"Ansible® is great"
    assert represent_unicode(AnsibleDumper, string) == yaml.representer.SafeRepresenter.represent_str(AnsibleDumper, text_type(string))

    # Test with non-ASCII characters
    string = u"Barçá"
    assert represent_unicode(AnsibleDumper, string) == yaml.representer.SafeRepresenter.represent_str(AnsibleDumper, text_type(string))

# Generated at 2022-06-22 13:58:05.904291
# Unit test for function represent_binary
def test_represent_binary():
    yaml_obj = AnsibleDumper([b'value'], default_flow_style=False)
    assert yaml_obj.represent_data(b'value') == '!!binary "dmFsdWU="\n'

# Generated at 2022-06-22 13:58:17.177647
# Unit test for function represent_undefined
def test_represent_undefined():
    # Need to patch the _fail_with_undefined_error to prevent the
    # test from failing
    import ansible.template.safe_eval
    real_func = ansible.template.safe_eval._fail_with_undefined_error

    def fake(*args, **kwargs):
        pass

    ansible.template.safe_eval._fail_with_undefined_error = fake
    try:
        # This will call _fail_with_undefined_error if
        # represent_undefined is not called
        yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper)
    finally:
        # Restore the original function
        ansible.template.safe_eval._fail_with_undefined_error = real_func

# This is needed for AnsibleInclude to be serialized

# Generated at 2022-06-22 13:58:21.397848
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    from ansible.template.safe_eval import Undefined
    import jinja2.runtime

    assert dumper.represent_undefined(
        AnsibleUndefined(
            Undefined(
                lineno=0,
                name='foo')))
    assert dumper.represent_undefined(
        AnsibleUndefined(
            jinja2.runtime.Undefined(
                name='foo')))

# Generated at 2022-06-22 13:58:27.378536
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    result = dumper.represent_unicode(dumper, u"I am a string")
    assert type(result) == yaml.ScalarNode

# Generated at 2022-06-22 13:58:31.369805
# Unit test for function represent_binary
def test_represent_binary():
    dumped = yaml.dump(AnsibleUnsafeBytes(b'\xF0\x9F\x98\x80'), Dumper=AnsibleDumper)
    assert dumped == '!!binary |-\n  8J+YgA==\n'

# Generated at 2022-06-22 13:58:35.449931
# Unit test for function represent_unicode
def test_represent_unicode():
    u1 = u'H\xe9llo'
    u2 = u'H\xe9llo'
    assert represent_unicode(None, u1) == represent_unicode(None, u2)


# Generated at 2022-06-22 13:58:39.001009
# Unit test for function represent_unicode
def test_represent_unicode():
    class TestUnicode:
        def __repr__(self):
            return 'unicode_me'

    assert yaml.dump(TestUnicode(), Dumper=AnsibleDumper) == 'unicode_me'



# Generated at 2022-06-22 13:58:40.972229
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(b'foo', Dumper=AnsibleDumper) == "!!binary |\n  Zm9v\n"

# Generated at 2022-06-22 13:58:48.202917
# Unit test for function represent_binary
def test_represent_binary():
    def check(input, output):
        dumper = yaml.dumper.Dumper()
        dumper.representers['!ansible.binary'] = represent_binary
        assert dumper.represent_scalar('!ansible.binary', input) == output
        dumper.representers['!ansible.binary'] = yaml.representer.SafeRepresenter.represent_binary

# Generated at 2022-06-22 13:58:50.678458
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, u'abc') == yaml.representer.SafeRepresenter.represent_str(None, text_type(u'abc'))


# Generated at 2022-06-22 13:59:00.656504
# Unit test for function represent_binary
def test_represent_binary():
    from ansible.parsing.yaml.loader import AnsibleLoader
    dumper = AnsibleDumper
    obj = b'foo'
    output = dumper.represent_binary(dumper, obj)
    assert obj == output
    assert isinstance(output, AnsibleUnsafeBytes)
    assert output == b'foo'
    input = b'!binary |\n  Zm9v\n'
    buf = yaml.compat.string_type(input)
    result = yaml.load(buf, Loader=AnsibleLoader)
    assert obj == result
    assert isinstance(result, AnsibleUnsafeBytes)
    assert result == b'foo'

# Generated at 2022-06-22 13:59:04.116080
# Unit test for function represent_unicode
def test_represent_unicode():
    repr_1 = yaml.representer.SafeRepresenter.represent_str(AnsibleDumper(), u'1')
    repr_2 = yaml.representer.SafeRepresenter.represent_str(AnsibleDumper(), '1')
    assert repr_1 == repr_2 == "1\n..."



# Generated at 2022-06-22 13:59:06.731252
# Unit test for function represent_unicode
def test_represent_unicode():
    repr_data = AnsibleDumper.represent_unicode(b"foo")
    expected = yaml.representer.SafeRepresenter.represent_str(b"foo")

    assert repr_data == expected

# Generated at 2022-06-22 13:59:18.637823
# Unit test for function represent_unicode
def test_represent_unicode():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.manager import VarsManager
    yaml_obj = VarsManager()

    ev = 'ev'
    ev_unicode = u'ev'
    assert type(ev_unicode) == unicode

    iv = 'iv'
    iv_unicode = u'iv'
    assert type(iv_unicode) == unicode

    cv = 'cv'
    cv_unicode = u'cv'
    assert type(cv_unicode) == unicode

    scv = 'scv'
    scv_unicode = u'scv'
    assert type(scv_unicode) == unicode

    tc = 'tc'
    tc_unicode = u'tc'

# Generated at 2022-06-22 13:59:20.593957
# Unit test for function represent_binary
def test_represent_binary():
    b = binary_type("abc")
    d = AnsibleDumper()
    representation = d.represent_binary(b)
    assert representation == '!!binary "YWJj"'

# Generated at 2022-06-22 13:59:31.873510
# Unit test for function represent_unicode
def test_represent_unicode():
    ''' unit test for represent_unicode
    this test is identical to the test case in yaml/test/test_representer.py
    '''
    # Generate an unicode
    u = ''.join([chr(n) for n in range(0x30, 0x3A)])
    u = u.encode('utf-8').decode('utf-8')

    # Represent
    dumper = yaml.representer.SafeRepresenter()

    yaml_data = dumper.represent_unicode(u)
    assert yaml_data
    assert yaml_data.startswith('0: ')
    assert yaml_data.endswith('\\n        ')
    assert u in yaml_data


# Generated at 2022-06-22 13:59:35.432480
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump('hello world', Dumper=AnsibleDumper) == 'hello world\n...\n'
    assert yaml.dump(AnsibleUnicode('hello world'), Dumper=AnsibleDumper) == 'hello world\n...\n'

# Generated at 2022-06-22 13:59:45.401177
# Unit test for function represent_binary
def test_represent_binary():
    ''' representation of a binascii encoded string '''
    data = 'i\xc3\xb1t\xc3\xabrn\xc3\xa2ti\xc3\xb4n\xc3\xa0liz\xc3\xa6ti\xc3\xb8n'
    expected = "!!binary |\n      aSDDhcOKYW5pYyBpbiBjbGllbnQgc2VydmljZSB3aXRoIGZhY2Vib29rIGFuZCBjb21tZXJjZS4="
    result = yaml.dump(data, Dumper=AnsibleDumper)
    assert expected == result

# Generated at 2022-06-22 13:59:51.806321
# Unit test for function represent_unicode
def test_represent_unicode():
    from ansible.utils.unsafe_proxy import wrap_var

    data = wrap_var(dict(a=u'A', b=1, c='two'))
    data['c'] = wrap_var(data['c'])
    result = yaml.dump(data, Dumper=AnsibleDumper)
    assert result == text_type(
        'a: A\n'
        'b: 1\n'
        'c: two\n'
    )

# Generated at 2022-06-22 14:00:00.062642
# Unit test for function represent_unicode
def test_represent_unicode():
    """Make sure represent_unicode returns the expected type"""
    # UTF-8 support
    unicode_str = u"\u6709\u52b9"
    assert isinstance(represent_unicode(None, unicode_str), unicode)

    # Latin-1 support
    unicode_str = u"\xff"
    assert isinstance(represent_unicode(None, unicode_str), unicode)

    # This is a string
    str_str = "spam"
    assert isinstance(represent_unicode(None, str_str), unicode)

    # This is a string
    # str_str = "spam"
    # assert isinstance(represent_binary(None, str_str), unicode)

# Generated at 2022-06-22 14:00:10.707955
# Unit test for function represent_unicode
def test_represent_unicode():
    # Test against an unicode string
    unicode_string = u'Test unicode string'
    unicode_string_yaml = yaml.dump(unicode_string, Dumper=AnsibleDumper)
    assert unicode_string_yaml == u'- {}\n'.format(unicode_string)
    # Test against an unicode object
    unicode_obj = AnsibleUnicode(unicode_string)
    unicode_obj_yaml = yaml.dump(unicode_obj, Dumper=AnsibleDumper)
    assert unicode_obj_yaml == u'- {}\n'.format(unicode_string)
    # Test against an unsafe text object
    unsafe_text_obj = AnsibleUnsafeText(unicode_string)

# Generated at 2022-06-22 14:00:21.624994
# Unit test for function represent_binary
def test_represent_binary():
    # Test with a string that is not a valid UTF-8 sequence
    # (which is the problematic case in Python 2.x)
    bad_utf8_sequence = u'm\ufffd\u007f'
    bad_utf8_as_bytes = bad_utf8_sequence.encode('utf-8', 'replace')
    rep = yaml.representer.SafeRepresenter.represent_binary(AnsibleDumper, bad_utf8_as_bytes)
    if yaml.__with_libyaml__:
        assert rep == u'!binary >\n  %s\n' % bad_utf8_as_bytes.decode('utf-8', 'replace')

# Generated at 2022-06-22 14:00:29.032056
# Unit test for function represent_binary