

# Generated at 2022-06-22 13:51:10.414307
# Unit test for function represent_hostvars
def test_represent_hostvars():
    import json
    from io import StringIO
    # This test checks that represent_hostvars works with HostVars, HostVarsVars and VarsWithSources
    yaml_data = dict(a=1)
    data = HostVars(yaml_data)
    output = StringIO()
    AnsibleDumper(output).represent_hostvars(data)
    json_data = json.loads(output.getvalue())
    assert json_data == yaml_data

    yaml_data = dict(a=1)
    data = HostVarsVars(yaml_data)
    output = StringIO()
    AnsibleDumper(output).represent_hostvars(data)
    json_data = json.loads(output.getvalue())
    assert json_data == yaml_data


# Generated at 2022-06-22 13:51:15.359188
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode('a') == u"'a'"
    assert represent_unicode(u'a') == u"'a'"
    assert represent_unicode(u'\u2034') == u"'\\u2034'"
    assert represent_unicode(u'\u2034'.encode('utf-8')) == u"'\\u2034'"

# Generated at 2022-06-22 13:51:20.981175
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = yaml.YAML()
    dumper.Representer = AnsibleDumper
    encrypted = AnsibleVaultEncryptedUnicode(b'abc', b'ciphertext')
    result = dumper.represent_data(encrypted, default_flow_style=True)
    assert result == '!vault |\n  ciphertext\n'

# Generated at 2022-06-22 13:51:32.062247
# Unit test for function represent_unicode
def test_represent_unicode():
    result = yaml.dump(u'\u263a'.encode('utf-8'), Dumper=AnsibleDumper, encoding=None, allow_unicode=False)
    assert result == "!!!python/unicode '\xe2\x98\xba'"

    result = yaml.dump(u'\u263a'.encode('utf-8'), Dumper=AnsibleDumper, encoding=None, allow_unicode=True)
    assert result == "!!!python/unicode '\\u263a'"

    result = yaml.dump(u'\u263a', Dumper=AnsibleDumper, encoding=None, allow_unicode=False)
    assert result == "!!!python/unicode '\xe2\x98\xba'"


# Generated at 2022-06-22 13:51:36.174838
# Unit test for function represent_unicode
def test_represent_unicode():
    foo = {'foo': 'bar'}
    assert yaml.dump(foo, default_flow_style=False).startswith('foo: bar')
    foo = {u'foo': u'bar'}
    assert yaml.dump(foo, default_flow_style=False).startswith('foo: bar')



# Generated at 2022-06-22 13:51:40.243410
# Unit test for function represent_binary
def test_represent_binary():
    # Strings are always unicode, so we need to fake a
    # bytearray
    bin_data = bytearray(b"\x00\x01\xFF\xFF\xFF")
    for i in range(0,5):
        bin_data[i] = i
    out_data = AnsibleDumper.represent_binary(AnsibleDumper,bin_data)
    assert out_data == u"!binary |\n  AAEC/w==\n"

# Generated at 2022-06-22 13:51:49.905457
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    data = {"foo": "bar"}
    hostvars = HostVars(data, "path", "name")
    test_result = dumper.represent_hostvars(hostvars)
    assert u'!hostvars' == test_result.value[0].value
    assert u'name' == test_result.value[1].value
    assert type(test_result.value[2].value) is yaml.nodes.MappingNode
    assert 'foo' == test_result.value[2].value.value[0][0].value
    assert 'bar' == test_result.value[2].value.value[0][1].value

# Generated at 2022-06-22 13:51:53.597381
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper
    hv = HostVars(dict({"foo": "bar"}))
    assert dumper.represent_data(hv) == "foo: bar\n"

# Generated at 2022-06-22 13:51:58.313926
# Unit test for function represent_hostvars
def test_represent_hostvars():

    from ansible.vars.hostvars import HostVars
    hv = HostVars()
    hv.update({'name': 'test'})

    assert represent_hostvars(None, hv) == {'name': 'test'}



# Generated at 2022-06-22 13:52:03.509932
# Unit test for function represent_unicode
def test_represent_unicode():
    representer = represent_unicode
    dumper = AnsibleDumper
    config = None
    data = 'hello'
    expected = yaml.representer.SafeRepresenter.represent_str(dumper, text_type(data))

    assert representer(dumper, data) == expected



# Generated at 2022-06-22 13:52:08.946605
# Unit test for function represent_binary
def test_represent_binary():
    data = AnsibleUnsafeBytes(b'abcd')
    d = AnsibleDumper()
    assert d.represent_data(data) == "!!binary >\n  YWJjZA==\n\n"

# Generated at 2022-06-22 13:52:11.068111
# Unit test for function represent_unicode
def test_represent_unicode():
    dumps = AnsibleDumper().serialize(AnsibleUnicode(u"str"))
    assert dumps == 'str\n...\n'



# Generated at 2022-06-22 13:52:17.493597
# Unit test for function represent_binary
def test_represent_binary():
    # Make a binary
    binary = b'\n\x00\x01\x02\x03'

    # Convert it to YAML
    yaml_binary = yaml.dump(binary, Dumper=AnsibleDumper)

    # Assert it's what you would expect
    assert yaml_binary == "!!binary |\n  CgAAAQID\n"



# Generated at 2022-06-22 13:52:29.499380
# Unit test for function represent_binary
def test_represent_binary():
    data = b'test'

    Object = yaml.representer.SafeRepresenter
    Object.yaml_representers['str'] = lambda dumper, data: dumper.represent_str(data)
    Object.yaml_representers[binary_type] = lambda dumper, data: dumper.represent_str(data)

    loader = yaml.SafeLoader
    loader.add_constructor(
        u'tag:yaml.org,2002:str',
        lambda loader, node: loader.construct_yaml_str(node),
    )

    dumper = AnsibleDumper
    dumper.add_representer(
        AnsibleUnsafeBytes,
        lambda dumper, data: dumper.represent_str(binary_type(data)),
    )


# Generated at 2022-06-22 13:52:37.099107
# Unit test for function represent_binary
def test_represent_binary():
    data = b'Hello \x1b[1;15;31mWorld\x1b[0m'
    expect = "!!python/object/apply:binhex.b2a_hex - 'Hello \\x1b[1;15;31mWorld\\x1b[0m'\n"
    representer = yaml.representer.SafeRepresenter()
    representer.add_representer(binary_type, represent_binary)
    assert expect == representer.represent_data(data)

# Generated at 2022-06-22 13:52:47.459880
# Unit test for function represent_binary
def test_represent_binary():
    """
    This unit test checks that only unicode is dumped.
    """
    yaml.add_representer(binary_type, yaml.representer.SafeRepresenter.represent_binary)
    assert yaml.dump(b'foo', Dumper=yaml.Dumper) == 'foo\n...\n'
    assert yaml.dump(binary_type(b'foo'), Dumper=yaml.Dumper) == 'foo\n...\n'
    yaml.add_representer(binary_type, represent_binary)
    assert yaml.dump(binary_type(b'foo'), Dumper=yaml.Dumper) == 'foo\n...\n'

# Generated at 2022-06-22 13:52:59.566037
# Unit test for function represent_binary
def test_represent_binary():
    text = b'\x92\xab\xfc\x05\xa2\x7f\x00\x1eU\x10\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\xff\xff\xff\xff\x00\x00\xff\xff\xff\xff\xff\xff\xff\x00\x00\x00\x00'
    res = represent_binary(AnsibleDumper, text)
    assert len(res) == 2
    assert res[0] == '!!binary |'

# Generated at 2022-06-22 13:53:01.379440
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(AnsibleDumper, "string") == "string\n...\n"

# Generated at 2022-06-22 13:53:08.483768
# Unit test for function represent_binary
def test_represent_binary():

    def repr_encoded(byte):
        if byte < 0x80:
            if byte >= 0x20 and byte <= 0x7E:
                return chr(byte)
            else:
                return "\\x%02x" % byte
        else:
            return "\\x%02x" % byte

    def repr_bytes(data):
        return "\"{0}\"".format("".join([repr_encoded(byte) for byte in data]))

    assert represent_binary(None, b'foo') == repr_bytes(b'foo')

# Generated at 2022-06-22 13:53:13.614519
# Unit test for function represent_unicode
def test_represent_unicode():
    yaml_str = yaml.dump([{u'foo': u'bar'}], Dumper=AnsibleDumper)
    assert yaml_str == u'[{foo: bar}]\n'



# Generated at 2022-06-22 13:53:30.535402
# Unit test for function represent_binary
def test_represent_binary():
    ''' Test represent_binary method '''
    # create a new AnsibleDumper object
    AnsibleDumper = yaml.Dumper
    dumper = AnsibleDumper(width=8)
    dumper.open()

    # create a new AnsibleUnsafeBytes object
    b64_str = "aGVsbG8="
    val = AnsibleUnsafeBytes(b64_str)

    # call represent_binary on the AnsibleUnsafeBytes object
    ret = represent_binary(dumper, val)

    # check the return value is as expected
    assert repr(ret) == repr(u"!!binary 'aGVsbG8='")
    assert ret.tag == 'tag:yaml.org,2002:binary'
    assert ret.style == '|'



# Generated at 2022-06-22 13:53:35.556636
# Unit test for function represent_binary
def test_represent_binary():
    test_string = b'\x00\xff\xaa'
    expected_string = '!!binary |\n' + test_string.decode('utf-8').encode('base64').replace('\n', '')
    assert AnsibleDumper.represent_binary(AnsibleDumper(None), test_string) == expected_string

# Generated at 2022-06-22 13:53:44.694140
# Unit test for function represent_undefined
def test_represent_undefined():
    # Test UndefinedStr
    assert AnsibleDumper.represent_undefined(None, AnsibleUndefined(AnsibleUnsafeText(u'test'))) is True
    # Test UndefinedNonStr
    assert AnsibleDumper.represent_undefined(None, AnsibleUndefined(2)) is True
    # Test UndefinedStr
    assert AnsibleDumper.represent_undefined(None, AnsibleUndefined(2, 'foo')) is True
    # Test missing args (should not cause a traceback)
    AnsibleDumper.represent_undefined(None, AnsibleUndefined())



# Generated at 2022-06-22 13:53:50.045673
# Unit test for function represent_binary
def test_represent_binary():
    # Unit test for function represent_binary
    import os
    from ansible.errors import AnsibleError
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vault import VaultEditor

    file_name = 'test_represent_binary.yml'
    temp_file = 'test_represent_binary_temp.yml'
    vault_password_file = 'test_vault_password.txt'
    with open('test_represent_binary.yml', 'w') as f:
        f.write("""---
byte: '\\377'""")
    with open(vault_password_file, 'w') as f:
        f.write("""hunter2""")

# Generated at 2022-06-22 13:53:58.899764
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper(default_style='|', default_flow_style=False)
    dumper.represent_binary(binary_type(b'\x00\x01\x02\x03\x04\x05'))
    dumper.represent_binary(binary_type(b'\x00\x01\x02\x03\x04\x05\x06'))
    dumper.represent_binary(binary_type(b'\x00\x01\x02\x03\x04\x05\x06\x07'))

# Generated at 2022-06-22 13:54:03.984007
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'hi') == dumper.represent_scalar('tag:yaml.org,2002:binary', b'aGk=\n', style='|')


# Generated at 2022-06-22 13:54:06.992542
# Unit test for function represent_binary
def test_represent_binary():
    yaml.add_representer(bytes, represent_binary)
    dumped = yaml.dump(b'foo\nbar')
    assert dumped == '!!binary |\n  Zm9vCmJhcg==\n'

# Generated at 2022-06-22 13:54:16.614675
# Unit test for function represent_binary
def test_represent_binary():
    '''
    AnsibleDumper.add_representer should not replace the 'bytes'
    YAML type but instead the 'binary' type.

    see https://github.com/ansible/ansible/pull/44485

    >>> yaml.dump(binarytype)
    '\\x01'
    '''

    binarytype = b"\x01"
    y = yaml.dump(binarytype, Dumper=AnsibleDumper)
    assert y == "'\\x01'\n"


if __name__ == '__main__':
    from ansible.utils.display import Display
    display = Display()

# Generated at 2022-06-22 13:54:19.070447
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.safe_load(yaml.dump(dict(a=AnsibleUndefined()), Dumper=AnsibleDumper)) == dict(a=dict(_undefined=True))

# Generated at 2022-06-22 13:54:25.130077
# Unit test for function represent_binary
def test_represent_binary():
    from ansible.module_utils.six import PY3
    # We must not emit "!!python/str", because
    # some old versions of ruamel.yaml do not
    # like it.
    data = b'\x80'
    if PY3:
        assert AnsibleDumper.represent_binary(None, data) == "!!binary |\n  gAAAAA"
    else:
        assert AnsibleDumper.represent_binary(None, data) == "!!binary |\n  gAAAAA=="
