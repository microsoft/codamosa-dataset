

# Generated at 2022-06-22 13:51:14.875751
# Unit test for function represent_unicode
def test_represent_unicode():

    # Unicode string
    input_str = u'\u2713'
    output_str = yaml.dump(input_str, Dumper=AnsibleDumper)
    expected_str = u'!!python/unicode ' + input_str + '\n'
    assert output_str == expected_str

    # Unicode string that should be dumped as a string
    input_str = u'abc'
    output_str = yaml.dump(input_str, Dumper=AnsibleDumper)
    expected_str = u'abc\n...\n'
    assert output_str == expected_str

# Generated at 2022-06-22 13:51:22.601976
# Unit test for function represent_undefined
def test_represent_undefined():
    # Because bool of AnsibleUndefined is always False,
    # construct False object here.
    class FalseObject:
        def __len__(self):
            return 0
        def __bool__(self):
            return False
    undefined = FalseObject()
    assert AnsibleDumper.represent_undefined(undefined) is False


# TODO: Remove this once a proper fix is made down in ansible.vars.manager.VarsWithSource

# Generated at 2022-06-22 13:51:24.385220
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    assert represent_unicode(dumper, 'helloworld') == yaml.representer.SafeRepresenter.represent_str(dumper, 'helloworld')



# Generated at 2022-06-22 13:51:29.174755
# Unit test for function represent_binary
def test_represent_binary():
    a = list(range(256))
    for i in a:
        b = binary_type(bytearray([i]))
        c = AnsibleUnsafeBytes(b)
        d = AnsibleDumper.represent_binary(c)
        e = AnsibleDumper.represent_unicode(c)
        assert d == e


# Generated at 2022-06-22 13:51:34.795327
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    rep = AnsibleDumper.represent_vault_encrypted_unicode
    u = AnsibleVaultEncryptedUnicode('!vault foo')
    result = rep(AnsibleDumper, u)
    assert result == '!vault |\n  foo\n'
    result = rep(AnsibleDumper, u'!vault foo')
    assert result == '!vault |\n  foo\n'

# Generated at 2022-06-22 13:51:39.493575
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import Templar
    from ansible.template.vars import AnsibleJ2Vars

    t = Templar(loader=None, variables=AnsibleJ2Vars(loader=None, variables=dict(foo=dict(bar=42))))

    d = AnsibleUndefined()
    d.__class__.__setattr__(d, '_templar', t)
    assert yaml.dump({'foo': {'bar': d}}) == u'{foo: {bar: null}}\n'

# Generated at 2022-06-22 13:51:45.199791
# Unit test for function represent_binary
def test_represent_binary():
    d = AnsibleDumper([])
    result = d.represent_binary(b'a\x01b')
    assert result == u"!!binary |-\na\x01b\n"
    b = yaml.load(result, Loader=yaml.BaseLoader)
    assert b == b'a\x01b'

# Generated at 2022-06-22 13:51:47.244374
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper) == 'false\n'

# Generated at 2022-06-22 13:51:48.971596
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    output = yaml.dump(
        AnsibleVaultEncryptedUnicode(b'fakecipher'),
        Dumper=AnsibleDumper,
        default_flow_style=False,
        )
    print(output)
    assert output == '!vault |\n  fakecipher\n'

# Generated at 2022-06-22 13:52:01.172796
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-22 13:52:06.216541
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, 'foo'.encode()) == "!!binary 'Zm9v'\n"

# Generated at 2022-06-22 13:52:07.892974
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.safe_dump(AnsibleUndefined(), default_flow_style=False, Dumper=AnsibleDumper) == '\n'

# Generated at 2022-06-22 13:52:10.143944
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('Hello, world!'), Dumper=AnsibleDumper) == "'Hello, world!'\n"

# Generated at 2022-06-22 13:52:12.793668
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode(u'foo'), Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-22 13:52:16.603731
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    dumper.open = False
    data = AnsibleUndefined('not defined')
    output = dumper.represent_undefined(data)
    assert output is False

# Generated at 2022-06-22 13:52:28.039740
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    my_vault = VaultLib([u'changeme'])
    x = AnsibleVaultEncryptedUnicode(u'test', my_vault)
    y = AnsibleDumper.represent_vault_encrypted_unicode(None, x)
    assert y == "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          3064303332656436393163656534393635636665643034313464353630626464626162313736613230\n          6130376533613037663739363131363664323634313663376263313935613231333635306330616131\n          "

# Generated at 2022-06-22 13:52:33.652036
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import AnsibleUndefined
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    data = [AnsibleMapping(), AnsibleSequence(), AnsibleUndefined(), AnsibleUndefined()]
    yaml.dump(data, Dumper=AnsibleDumper)

# Generated at 2022-06-22 13:52:40.623267
# Unit test for function represent_hostvars
def test_represent_hostvars():
    import copy

    dumper = AnsibleDumper()

    hostvars = HostVars({"var1": "value1"})
    expected_result = {'var1': 'value1'}

    for hostvar in (hostvars, copy.copy(hostvars), copy.deepcopy(hostvars)):
        result = yaml.load(dumper.represent_hostvars(hostvar), Loader=yaml.SafeLoader)
        assert result == expected_result

# Generated at 2022-06-22 13:52:49.336704
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hvars = HostVars()
    hvars._host = 'foo.bar'
    hvars._vars = {'var1': 'var1', 'var2': 'var2'}

    assert yaml.dump(hvars, Dumper=AnsibleDumper) == """
_ansible_no_log: false
_ansible_verbosity: 0
_ansible_version: 2.4.0.0-dev3
_ansible_syslog_facility: LOG_USER
var1: var1
var2: var2
""".strip()

# Generated at 2022-06-22 13:52:54.280365
# Unit test for function represent_binary
def test_represent_binary():
    _bytes = b'\x00\x01\x02\x03'
    result = yaml.representer.SafeRepresenter.represent_binary(AnsibleDumper, _bytes)
    assert result == u'!!binary |\n  AAECAw==\n'


# Generated at 2022-06-22 13:53:00.885915
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary('hello') == '!binary |\n  aGVsbG8=\n'
    assert dumper.represent_binary(b'\xab\xcd') == '!binary |\n  q/Eh\n'

# Generated at 2022-06-22 13:53:08.448584
# Unit test for function represent_binary
def test_represent_binary():
    # To test we need a subclass of SafeDumper that adds the represent_binary function.
    # But the function needs to be an instance function, not a static function.
    # Therefore, we create a subclass that adds represent_binary as an instance function.
    class SubSafeDumper(yaml.representer.SafeRepresenter):
        pass
    SubSafeDumper.represent_binary = represent_binary
    representer = SubSafeDumper()
    test_bytes = binary_type(b'\x7F\x8F\x9F\xA7\xB7\xC1\xD1\xE1\xF1\xF8\xFF')
    # Test that our represent_binary function works.

# Generated at 2022-06-22 13:53:20.159347
# Unit test for function represent_hostvars
def test_represent_hostvars():
    a = dict()
    a['ansible_processor_count'] = 4
    a['ansible_all_ipv4_addresses'] = ['1.2.3.4']
    a['ansible_default_ipv4'] = dict()
    a['ansible_default_ipv4']['address'] = '1.2.3.4'
    a['ansible_default_ipv4']['gateway'] = '1.2.3.4'
    a['ansible_default_ipv4']['interface'] = 'eth0'
    a['ansible_default_ipv4']['macaddress'] = '00:00:00:00:00:00'
    a['ansible_default_ipv4']['netmask'] = '255.255.255.0'
   

# Generated at 2022-06-22 13:53:32.585310
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-22 13:53:34.924957
# Unit test for function represent_undefined
def test_represent_undefined():
    representer = AnsibleDumper()
    assert representer.represent_undefined(AnsibleUndefined(name='foo', obj='bar')) is False

# Generated at 2022-06-22 13:53:46.752007
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # Test HostVars
    hostvars = HostVars({'host_2': {'host_2_var': 'host_2_value'}})
    hostvars_dict = yaml.dump(hostvars, Dumper=AnsibleDumper, default_flow_style=False)
    assert hostvars_dict == '''{
    host_2: {
        host_2_var: host_2_value
    }
}\n'''

    hostvars = HostVars(host_2={'host_2_var': 'host_2_value'})
    hostvars_dict = yaml.dump(hostvars, Dumper=AnsibleDumper, default_flow_style=False)

# Generated at 2022-06-22 13:53:52.536114
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

    # bytes
    output = dumper.represent_binary(b"\x00\x01\x02")
    assert output == "!!binary |\n  AAEC\n"

    # string
    output = dumper.represent_binary("\x00\x01\x02")
    assert output == "!!binary |\n  AAEC\n"

# Generated at 2022-06-22 13:53:57.246899
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = {'aaa': 'bbb'}
    hostvars = HostVars(data)
    result = yaml.dump(hostvars, Dumper=AnsibleDumper, default_flow_style=False)
    assert(result == "aaa: bbb\n")

# Generated at 2022-06-22 13:53:59.676721
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    assert dumper.represent_undefined(dumper, AnsibleUndefined())

# Generated at 2022-06-22 13:54:05.179230
# Unit test for function represent_hostvars
def test_represent_hostvars():
    import sys
    import io
    stream = io.StringIO()
    h = HostVars()
    d = {'foo': 'bar'}
    h['hostname'] = d
    yaml.dump(h, stream, Dumper=AnsibleDumper, default_flow_style=False, allow_unicode=True)
    output = stream.getvalue()
    assert output == "hostname:\n  foo: bar\n"

# Generated at 2022-06-22 13:54:16.691331
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('mysecret')
    plain = 'hello world'
    cipher = vault.encrypt(plain)
    enc = AnsibleVaultEncryptedUnicode(cipher)
    assert plain != cipher
    assert enc._ciphertext == cipher

    yaml_text = yaml.dump({'myvar': enc}, Dumper=AnsibleDumper)
    assert '!vault' in yaml_text
    assert cipher not in yaml_text
    assert plain not in yaml_text

    yaml_data = yaml.load(yaml_text)
    assert '!vault' not in yaml_data
    assert 'myvar' in yaml_data
    assert cipher not in yaml_data

# Generated at 2022-06-22 13:54:20.307934
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    data = AnsibleUnsafeBytes("#!/bin/sh")
    assert dumper.represent_binary(data) == "!binary |\n  IyEvYmluL3NoCg==\n"



# Generated at 2022-06-22 13:54:27.980178
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib

    vault_password = 'password'
    # Test for python2.7
    ciphertext = '$ANSIBLE_VAULT;1.1;AES256\n30393165323466373237373365373634363561343737306436376562316364323939373837363561\n3661676364627563376261326564343966363730386538376535343066306266303161313766633963\n6637381312d0a'
    vault = VaultLib(vault_password)
    data = vault.decrypt(ciphertext)
    data = AnsibleVaultEncryptedUnicode(data)

# Generated at 2022-06-22 13:54:34.415921
# Unit test for function represent_undefined
def test_represent_undefined():
    # We need to create an instance, because it's an old style class
    dumper = AnsibleDumper()
    # Our function should return bool(data) which raises DataUndefined error
    var = AnsibleUndefined()
    var._fail_with_undefined_error = True
    try:
        dumper.represent_undefined(var)
    except Exception as ex:
        assert isinstance(ex, yaml.representer.RepresenterError)

# Generated at 2022-06-22 13:54:45.202300
# Unit test for function represent_hostvars

# Generated at 2022-06-22 13:54:50.834951
# Unit test for function represent_undefined
def test_represent_undefined():
    '''
    Unit test for function represent_undefined
    '''
    from ansible.template import Undefined
    dumper = AnsibleDumper
    value = Undefined(strict=True)
    assert dumper.represent_undefined(dumper, value)



# Generated at 2022-06-22 13:54:56.322960
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    assert(represent_vault_encrypted_unicode(AnsibleDumper, AnsibleVaultEncryptedUnicode("supersecretpassword"))) == "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          333162663766376331353864633837663935336630393865316233336231643237633237346636\n          653561386235623330313339626262643034376333653337363033636163393865\n          \n"

# Generated at 2022-06-22 13:55:02.762175
# Unit test for function represent_binary
def test_represent_binary():
    import os
    text_stream = open(os.path.join(os.path.dirname(__file__), '..', 'data', 'utf8.txt'), mode='rb')
    result = AnsibleDumper().represent_binary(text_stream.read())
    assert result == "!binary |-\n  SQtNC60LDQtyDQtNC40YLQtdC80LXQvdGP0LfQvtCy0LDQu9Cw\n  0LrQsNC20LTQtdC60LAg0LrQsNC70LrQsNC8\n"

# Generated at 2022-06-22 13:55:04.917181
# Unit test for function represent_binary
def test_represent_binary():
    assert represent_binary(None, '\xc3\xbc') == "!!binary |\n  yw=="

# Generated at 2022-06-22 13:55:10.810776
# Unit test for function represent_unicode
def test_represent_unicode():
    assert (yaml.dump(u'hello', Dumper=AnsibleDumper)) == u'hello\n...\n'
    assert (yaml.dump([u'hello', u'world'], Dumper=AnsibleDumper)) == u'- hello\n- world\n'
    assert (yaml.dump({u'k': u'hello'}, Dumper=AnsibleDumper)) == u'k: hello\n'


# Generated at 2022-06-22 13:55:24.566054
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    expect = '!vault |\n' + '          $ANSIBLE_VAULT;1.1;AES256\n' + '          64313461376539383264343065356633363032363135313338643439653335396139373761376266\n' + '          31373536663533333263383530343535326439666238616264633162313739653437333166633262\n' + '          6534\n'

# Generated at 2022-06-22 13:55:31.839004
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(AnsibleDumper(), u'hello world') == u'hello world'
    assert represent_unicode(AnsibleDumper(), u'hello\u3000world') == u"hello\u3000world"
    assert represent_unicode(AnsibleDumper(), u'\u2620') == u"\u2620"


# Add new style test here to ensure representer is present

# Generated at 2022-06-22 13:55:40.598569
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.unsafe_proxy import wrap_var, is_unsafe_proxy
    from ansible.vars.manager import wrap_var as wrap_var_two
    from ansible.vars.manager import is_safe_key

    hostvars = HostVars(hostname='localhost')
    hostvars['foo'] = 12
    hostvars['bar'] = wrap_var({'bam': 'foo'})
    hostvars['bam'] = wrap_var([1,2,3])
    hostvars['baz'] = wrap_var_two('baz')
    hostvars['baz_two'] = wrap_var_two(ansible_unsafe_proxy=False, value='password')

    yaml

# Generated at 2022-06-22 13:55:44.055124
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import StrictUndefined
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(StrictUndefined(''))



# Generated at 2022-06-22 13:55:48.536870
# Unit test for function represent_hostvars

# Generated at 2022-06-22 13:55:56.357466
# Unit test for function represent_undefined
def test_represent_undefined():
    # Note that this function is for unit testing only.
    # We are not using assertRaises because it does
    # not work in Python 2.6, and is not recommended
    # for newer versions either. See
    # http://docs.python.org/2.7/library/unittest.html#deprecated-aliases

    try:
        AnsibleDumper.add_representer(
            AnsibleUndefined,
            represent_undefined,
        )(AnsibleDumper(), AnsibleUndefined())
        raise AssertionError('Did not catch exception')
    except yaml.representer.RepresenterError:
        pass

# Generated at 2022-06-22 13:56:08.498614
# Unit test for function represent_undefined
def test_represent_undefined():
    class MyUndefined(AnsibleUndefined):
        def __init__(self, s, value):
            self._s = s
            self._value = value

        def __repr__(self):
            return self._s

        def __eq__(self, other):
            if isinstance(other, MyUndefined):
                return self._value == other._value
            return False

        def __ne__(self, other):
            return not self.__eq__(other)

    u1 = MyUndefined("MyUndefined(1)", 1)
    u2 = MyUndefined("MyUndefined(2)", 2)
    l = [1, '', False, u1, u2]
    d = dict(a=1, b='', c=False, d=u1, e=u2)

    # Make sure that

# Generated at 2022-06-22 13:56:10.195501
# Unit test for function represent_binary
def test_represent_binary():
    assert AnsibleDumper.represent_binary(AnsibleDumper(), b"a") == u"!!binary a"

# Generated at 2022-06-22 13:56:17.803790
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleUnicode

    hostvars = HostVars(hostname='hostname')
    hostvars.vars = AnsibleMapping()
    hostvars.vars['foo'] = AnsibleUnicode('bar')
    hostvars_dumped = yaml.dump(hostvars, Dumper=AnsibleDumper)
    assert hostvars_dumped == 'foo: bar\n'



# Generated at 2022-06-22 13:56:26.378329
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # create a hostvars object with vars
    hv = HostVars()
    hv['one'] = 'foo'
    hv['two'] = 'bar'
    # load it back and verify vars are there
    hv_yaml = yaml.dump([hv], Dumper=AnsibleDumper, default_flow_style=False)
    hv2 = yaml.safe_load(hv_yaml)[0]
    assert hv2['one'] == hv['one']
    assert hv2['two'] == hv['two']


# Generated at 2022-06-22 13:56:46.477575
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.playbook.task_include import TaskInclude
    if not TaskInclude._role_params:
        TaskInclude.parse_role_vars(dict())
    task_include = TaskInclude()
    task_include._role_params = dict(roles=[dict(role_path='/path/to/role')])
    input_ = dict(
        myvar1='myvar1_val',
        myvar2='myvar2_val'
    )

# Generated at 2022-06-22 13:56:50.460770
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dict_data = {'h1': HostVars({'v1': 'value1', 'v2': 'value2'})}
    yaml_data = yaml.dump(dict_data, default_flow_style=False)
    assert yaml_data == '''h1:
  v1: value1
  v2: value2
'''

# Generated at 2022-06-22 13:56:54.775296
# Unit test for function represent_undefined
def test_represent_undefined():
    data = AnsibleUndefined
    ansible_yaml_dumper = AnsibleDumper
    res = ansible_yaml_dumper.represent_undefined(ansible_yaml_dumper, data)
    assert res == bool(data)

# Generated at 2022-06-22 13:56:59.494162
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    unicode_object = u"This is an unicode object"
    assert dumper.represent_unicode(dumper, unicode_object) == u"!ansible/unicode 'This is an unicode object'"
    assert dumper.represent_str(dumper, unicode_object) == u"'This is an unicode object'"



# Generated at 2022-06-22 13:57:10.966194
# Unit test for function represent_binary
def test_represent_binary():
    data = AnsibleUnsafeBytes(b'hello')
    assert yaml.dump(data, Dumper=AnsibleDumper) == "!!binary |\n  aGVsbG8=\n"

    # Test that the same binary content is dumped identically (binary form is canonical)
    # with different constructors
    assert yaml.dump(AnsibleUnsafeBytes(data), Dumper=AnsibleDumper) == "!!binary |\n  aGVsbG8=\n"
    assert yaml.dump(data.decode('ascii'), Dumper=AnsibleDumper) == "!!binary |\n  aGVsbG8=\n"

# Generated at 2022-06-22 13:57:22.404553
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # Test with HostVars
    x = HostVars(vars={'foo': 'bar'})

    # For a dict the output should just be the dict
    assert represent_hostvars(Dumper(), x) == '{foo: bar}'

    # Test with HostVarsVars
    x = HostVarsVars(vars={'foo': 'bar'})

    # For a dict the output should just be the dict
    assert represent_hostvars(Dumper(), x) == '{foo: bar}'

    # Test with VarsWithSources
    x = VarsWithSources(vars={'foo': 'bar'})

    # For a dict the output should just be the dict
    assert represent_hostvars(Dumper(), x) == '{foo: bar}'



# Generated at 2022-06-22 13:57:24.748406
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    assert represent_vault_encrypted_unicode(yaml.dumper.Dumper(), AnsibleVaultEncryptedUnicode("foobar")) == "!vault |\n  foobar\n"

# Generated at 2022-06-22 13:57:27.454038
# Unit test for function represent_unicode
def test_represent_unicode():
    foo = AnsibleUnicode('baz')
    assert yaml.safe_dump(foo, Dumper=AnsibleDumper) == u"baz\n...\n"



# Generated at 2022-06-22 13:57:35.413767
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib

    data = u'This a test string for vault'
    vault = VaultLib([u'password'])
    ciphertext = vault.encrypt(data)
    test = AnsibleVaultEncryptedUnicode(ciphertext)

    rep = AnsibleDumper.represent_scalar(u'!vault', test, style='|')

# Generated at 2022-06-22 13:57:38.108534
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.dump({'foo': AnsibleUndefined()}, Dumper=AnsibleDumper)

# Generated at 2022-06-22 13:57:56.352268
# Unit test for function represent_unicode
def test_represent_unicode():
    output = yaml.dump(AnsibleUnicode('foobar'))
    assert output == 'foobar\n'
    output = yaml.dump(AnsibleUnicode('f\x00oobar'))
    assert output == 'f?oobar\n'
    output = yaml.dump(AnsibleUnicode('f\x00oobar'), allow_unicode=True)
    assert output == 'f?oobar\n'
    output = yaml.dump(AnsibleUnicode('f\x00oobar'), default_flow_style=False, allow_unicode=True)
    assert output == '- !!python/unicode \'f?oobar\'\n'


# Generated at 2022-06-22 13:57:59.897007
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    undefined = AnsibleUndefined
    s = dumper.represent_data(undefined)
    assert s == 'None'

# SafeDumper does not support !!unsafe
# We subclass it to add support for !!unsafe

# Generated at 2022-06-22 13:58:04.947014
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    r = dumper.represent_binary(dumper, text_type(b'\x00\x00\x00'))
    assert r == yaml.representer.SafeRepresenter.represent_binary(dumper, binary_type(b'\x00\x00\x00'))

# Generated at 2022-06-22 13:58:16.410099
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib

# Generated at 2022-06-22 13:58:21.094698
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    test_data = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256;dummy_account\ndummy_encrypted_text\n', None)
    dump_data = AnsibleDumper.represent_vault_encrypted_unicode(test_data)
    assert dump_data == "!vault |\n  $ANSIBLE_VAULT;1.1;AES256;dummy_account\n  dummy_encrypted_text\n\n"

# Generated at 2022-06-22 13:58:23.421829
# Unit test for function represent_binary
def test_represent_binary():
    test_data = b'some binary data'
    out = represent_binary(None, test_data)
    assert isinstance(out, text_type)

# Generated at 2022-06-22 13:58:33.507279
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()
    text = 'my secret text'
    vault_enc = AnsibleVaultEncryptedUnicode(text.encode('utf-8'))

    vault_text = dumper.represent_vault_encrypted_unicode(vault_enc)

# Generated at 2022-06-22 13:58:36.381688
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == "'foo'\n"

# Generated at 2022-06-22 13:58:37.949762
# Unit test for function represent_undefined
def test_represent_undefined():
    x = AnsibleDumper()
    x.represent_undefined(AnsibleUndefined())


# Generated at 2022-06-22 13:58:44.565621
# Unit test for function represent_binary
def test_represent_binary():
    # This tests that when using represent_binary, the base64
    # string produced will contain a newline character on every
    # 76th character.
    s = b'abcde\x00abcde\x00abcde\x00abcde\x00abcde\x00abcde\x00abcde\x00'
    result = AnsibleDumper.represent_binary(s)
    assert result.startswith("!!binary |\n  ")
    assert result.endswith("\n")
    assert result.count("\n") == 2

# Generated at 2022-06-22 13:59:00.148741
# Unit test for function represent_hostvars
def test_represent_hostvars():
    fake_data = HostVars(
        host_name="localhost",
        hostvars={"a": "a", "b": {"b1": "b1", "b2": "b2"}}
    )
    serialized = yaml.dump(fake_data, Dumper=AnsibleDumper, default_flow_style=False)
    assert serialized == '''\
a: a
b:
  b1: b1
  b2: b2
'''



# Generated at 2022-06-22 13:59:03.234727
# Unit test for function represent_binary
def test_represent_binary():
    data = b'foo\nbar\r\n'
    res = yaml.dump(data, Dumper=AnsibleDumper)
    exp = '!!binary |\n  Zm9vCmJhcgpyCg==\n'
    assert res == exp

# Generated at 2022-06-22 13:59:04.620588
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode(u'abc')) == 'abc\n...\n'



# Generated at 2022-06-22 13:59:08.552383
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # Sample values
    hostname = "hostname"
    vars_value = [1, 2, 3]
    variables = HostVars(hostname, vars_value)

    # Represent with AnsibleDumper
    repr_variables = AnsibleDumper.represent_hostvars(AnsibleDumper, variables)

    # Result
    assert repr_variables is not None
    # Check the keys are the same
    assert list(repr_variables)[0] == hostname
    # Check if the value is an array
    assert isinstance(repr_variables[hostname], list)
    # Check the values
    assert repr_variables[hostname] == vars_value

# Generated at 2022-06-22 13:59:14.546347
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(AnsibleUnsafeBytes(b'foo'), default_flow_style=True, Dumper=AnsibleDumper) == "!!binary >\n  Zm9v\n"
    assert yaml.dump(AnsibleUnsafeBytes(b'foo'), default_flow_style=False, Dumper=AnsibleDumper) == "!!binary |\n  Zm9v\n"



# Generated at 2022-06-22 13:59:18.064377
# Unit test for function represent_undefined
def test_represent_undefined():
    '''Test for the AnsibleDumper.add_representer for AnsibleUndefined'''
    dump = AnsibleDumper.represent(AnsibleUndefined)
    assert dump is False
    dump = AnsibleDumper.represent(42)
    assert dump is True

# Generated at 2022-06-22 13:59:23.552321
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

    # Test for string with length 255
    data = ''.join(['a' for x in range(255)])
    result = dumper.represent_binary(data)
    assert result == '!!binary |\n  ' + 'YQ' * 128 + 'YQ' * 127

    # Test for string with length 256
    data = ''.join(['a' for x in range(256)])
    result = dumper.represent_binary(data)
    assert result == '!!binary |\n  ' + 'YQ' * 128 + 'YQ==' + 'YQ' * 126

    # Test for string with length 1024
    data = ''.join(['a' for x in range(1024)])
    result = dumper.represent_binary(data)

# Generated at 2022-06-22 13:59:29.270391
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template.jinja2.environment import StrictUndefined
    from ansible.template import Templar
    import jinja2

    fake_loader = jinja2.DictLoader({})
    templar = Templar(loader=fake_loader)

    undefined_value = StrictUndefined()
    assert templar._fail_with_undefined_error(undefined_value)

# Generated at 2022-06-22 13:59:32.567565
# Unit test for function represent_unicode
def test_represent_unicode():
    input_data = b'Hello World\n'
    expected_output = b"Hello World\n"

    output_data = yaml.dump(input_data, Dumper=AnsibleDumper, default_flow_style=False)
    assert output_data == expected_output

# Generated at 2022-06-22 13:59:39.048033
# Unit test for function represent_binary
def test_represent_binary():
    from io import BytesIO
    output = BytesIO()
    dumper = AnsibleDumper(stream=output, default_flow_style=False)
    dumper.open()
    dumper.represent_binary(b'a\n')
    dumper.close()
    output.seek(0)
    data = output.read().decode()
    assert data == '!!binary |\n  YQo=\n', data

# Generated at 2022-06-22 13:59:58.504687
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper.represent_undefined(None, AnsibleUndefined()) is False
    try:
        from jinja2.runtime import StrictUndefined
    except ImportError:
        pass
    else:
        assert AnsibleDumper.represent_undefined(None, StrictUndefined()) is False

# Generated at 2022-06-22 14:00:09.414904
# Unit test for function represent_undefined
def test_represent_undefined():
    # When fail_on_undefined is True we want _fail_with_undefined_error to be
    # called, which should raise AnsibleUndefinedVariable.
    dumper = AnsibleDumper
    dumper.ignore_aliases = lambda self, data: True
    dumper.represent_undefined = represent_undefined
    dumper.fail_on_undefined = True
    try:
        result = dumper.represent_data(AnsibleUndefined(name='foo'))
    except AnsibleUndefinedVariable:
        result = True
    assert result is True

    # When fail_on_undefined is False we want _fail_with_undefined_error not to
    # be called, so no need to test that.
    dumper = AnsibleDumper
    dumper.ignore_aliases = lambda self, data: True

# Generated at 2022-06-22 14:00:20.185864
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    test_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode('my_ciphertext')
    assert test_vault_encrypted_unicode._ciphertext == b'my_ciphertext'

    test_yaml_string = yaml.dump(test_vault_encrypted_unicode, Dumper=AnsibleDumper)

    assert '!vault |' in test_yaml_string
    assert test_yaml_string.count('\n') == 1
    assert 'my_ciphertext' in test_yaml_string

    # If the data isn't unicode, do not use |-style encoding
    test_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode(b'my_ciphertext')


# Generated at 2022-06-22 14:00:25.280834
# Unit test for function represent_binary
def test_represent_binary():

    from tempfile import TemporaryFile
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes

    f1 = TemporaryFile()
    f1.write(b'Binary Data')
    f1.seek(0)
    assert yaml.dump(f1, Dumper=AnsibleDumper, default_flow_style=False) == '\n!!python/object:tempfile.TemporaryFile {}\n\n'

    assert yaml.dump(AnsibleUnsafeBytes(b"Binary Data"), Dumper=AnsibleDumper, default_flow_style=False) == '!!binary "QmluYXJ5IERhdGE="\n'

# Generated at 2022-06-22 14:00:31.142005
# Unit test for function represent_unicode
def test_represent_unicode():
    dump_str = yaml.dump(
        AnsibleUnicode('password: no secret'),
        default_flow_style=False,
        Dumper=AnsibleDumper
    )
    assert dump_str == u'password: no secret\n...\n'

    dump_bytes = yaml.dump(
        AnsibleUnicode('password: no secret'),
        default_flow_style=False,
        Dumper=AnsibleDumper
    ).encode('utf-8')
    assert dump_bytes == b'password: no secret\n...\n'

    assert yaml.dump(
        AnsibleUnicode(u'password: no secret'),
        default_flow_style=False,
        Dumper=AnsibleDumper
    ) == "password: no secret\n...\n"


#

# Generated at 2022-06-22 14:00:41.437130
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    ansible_dumper = AnsibleDumper()
    vault = VaultLib([])
    _plaintext = u"mytestplain"
    _password = u"test"
    secret = vault.encrypt(_plaintext, _password)
    assert ansible_dumper.represent_data(secret) == "!vault |\n  $ANSIBLE_VAULT;1.1;AES256\n  356635303165653634326331626265396366366431343239653361663432623764653961336637\n  6331626565323765396232303766656530373435373866653337663564313633\n"

# Generated at 2022-06-22 14:00:44.441147
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode(u'yaml', 'utf-8'), Dumper=AnsibleDumper) == u'yaml\n...\n'
    assert yaml.dump(AnsibleUnicode(u'\u3042', 'utf-8'), Dumper=AnsibleDumper) == u'\u3042\n...\n'

# Generated at 2022-06-22 14:00:49.251895
# Unit test for function represent_binary
def test_represent_binary():
    '''Test for represent_binary'''
    my_dumper = AnsibleDumper
    my_dumper.add_representer(
        AnsibleUnsafeBytes,
        represent_binary,
    )
    yaml.safe_dump(b"foo: bar", default_flow_style=False)
    yaml.safe_dump(AnsibleUnsafeBytes(b"foo: bar"), default_flow_style=False)



# Generated at 2022-06-22 14:01:00.552439
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 14:01:04.486155
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    s = u'\u1234'  # <-- utf-8-encoded string, assuming ascii compatible encoding
    assert dumper.represent_unicode(dumper, s) == dumper.represent_str(s)
    s = u'\u1234\u5678'  # <-- utf-8-encoded string, assuming ascii compatible encoding
    assert dumper.represent_unicode(dumper, s) == dumper.represent_str(s)
