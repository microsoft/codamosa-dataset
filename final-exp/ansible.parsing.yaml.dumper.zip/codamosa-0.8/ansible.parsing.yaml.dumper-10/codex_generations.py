

# Generated at 2022-06-22 13:51:10.493931
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.dataloader import DataLoader
    from collections import OrderedDict
    from io import StringIO

    fake_loader = DataLoader()
    fake_loader.set_basedir('/test/path')
    h = HostVars()
    h.update(dict(a=1, b=2, c=3))
    h.update(dict(d=4))
    h.add_file('d.yml')
    h.update_vars(dict(c=5))
    f = StringIO()
    yaml.dump(h, f, Dumper=AnsibleDumper)
    parsed_file = yaml.safe_load(f.getvalue())
    print(parsed_file)
    assert '!hostvars' in f.getvalue()

# Generated at 2022-06-22 13:51:14.789172
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    bad_utf8 = b'\xc3\x28'
    good_utf8 = b'\xc3\xa9'
    assert dumper.represent_unicode(dumper, bad_utf8) == "!!python/unicode '\\xc3('"

# Generated at 2022-06-22 13:51:17.424118
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    assert dumper.represent_hostvars(dict(a=1)) == dumper.represent_dict(dict(a=1))



# Generated at 2022-06-22 13:51:28.143521
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper
    x = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\n6162636465666768696A6B6C6D6E6F707172737475767778797A\n7A6F5E6D5C6B5A69586746535241504746414D4C5B5A59666768\n')

# Generated at 2022-06-22 13:51:33.468188
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    d = AnsibleDumper
    for secret in ("AES256", "AES256|plaintext"):
        encrypted_unicode = AnsibleVaultEncryptedUnicode(secret)
        rep = represent_vault_encrypted_unicode(d, encrypted_unicode)
        assert rep == "!vault |\n  {0}".format(secret)

# Generated at 2022-06-22 13:51:34.712665
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.safe_dump(AnsibleUndefined()) == ''



# Generated at 2022-06-22 13:51:40.229647
# Unit test for function represent_binary
def test_represent_binary():
    inner = dict(key='value')
    item = {'binary_item': binary_type(yaml.dump(inner, encoding='utf-8'), encoding='utf-8')}
    dumper = AnsibleDumper.from_representer(yaml.representer.SafeRepresenter)
    assert dumper.represent_data(item) == '{binary_item}\n'

# Generated at 2022-06-22 13:51:42.918759
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper(width=10000)
    assert dumper.represent_data(AnsibleUndefined()) == False



# Generated at 2022-06-22 13:51:47.245344
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper(width=None)
    result = dumper.represent_data(AnsibleUndefined(var_name='foo'))
    assert result == '_undefined_foo'


# FIXME: in YAML2, this isn't needed

# Generated at 2022-06-22 13:51:55.184229
# Unit test for function represent_unicode
def test_represent_unicode():
    '''
    Ensure unicode objects are dumped as strings
    '''

    # Create a yaml serializer
    dumper = yaml.SafeDumper

    # Create a dict with a unicode string
    unicode_dict = {u'testkey': u'testvalue'}

    # Dump yaml from dict
    temp_str = yaml.dump(unicode_dict, Dumper=dumper)

    # Assert that string was dumped as a unicode string
    assert temp_str == u'testkey: testvalue\n'



# Generated at 2022-06-22 13:51:59.485496
# Unit test for function represent_unicode
def test_represent_unicode():
    x = AnsibleDumper.represent_unicode(None, u'foo')
    assert x.endswith("foo\n")

# Generated at 2022-06-22 13:52:00.788914
# Unit test for function represent_unicode
def test_represent_unicode():
    pass



# Generated at 2022-06-22 13:52:02.597637
# Unit test for function represent_binary
def test_represent_binary():
    from six import BytesIO
    output = BytesIO()
    AnsibleDumper(stream=output).represent_binary(b'foo')
    assert output.getvalue() == b'!!binary |\n  Zm9v\n'



# Generated at 2022-06-22 13:52:12.403968
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    hostvars = HostVars(dict(foo=42, bar='42'), variables=VariableManager())
    assert yaml.dump(hostvars, Dumper=AnsibleDumper) == 'foo: 42\nbar: "42"\n'

    # hostvars vars
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    play_context = PlayContext()

    hostvars = HostVarsVars(inventory, play_context)
    assert yaml.dump(hostvars, Dumper=AnsibleDumper) == ''

# Generated at 2022-06-22 13:52:17.821441
# Unit test for function represent_unicode
def test_represent_unicode():
    nonascii = 'nonascii \xe4\xe4'
    data = dict(foo=AnsibleUnicode(nonascii))
    assert yaml.dump(data, Dumper=AnsibleDumper) == "{foo: 'nonascii \\xe4\\xe4'}\n"



# Generated at 2022-06-22 13:52:19.637949
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(u'abc') == "!!python/unicode 'abc'\n"


# Generated at 2022-06-22 13:52:28.283261
# Unit test for function represent_hostvars
def test_represent_hostvars():
    h = HostVarsVars()
    h['a'] = 'A'
    h['b'] = 3
    h['c'] = [1, 2]
    h['d'] = {'a': 'A', 'b': 'B'}

    yaml_str = yaml.dump({'h': h}, Dumper=AnsibleDumper)

    assert(yaml_str == '{h: {a: A, b: 3, c: [1, 2], d: {a: A, b: B}}}\n')



# Generated at 2022-06-22 13:52:34.222631
# Unit test for function represent_hostvars
def test_represent_hostvars():
    h = HostVars({'var1': 'v1', 'var2': 'v2', 'var3': 'v3'})
    assert yaml.dump(h, Dumper=AnsibleDumper).splitlines() == [
        'var1: v1',
        'var2: v2',
        'var3: v3'
    ]



# Generated at 2022-06-22 13:52:44.153013
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = HostVars()
    hostvars.data['foo'] = 'bar'
    hostvars.data['boo'] = {'baz': 'faz'}

    # Test that we can dump yaml from the hostvars object
    assert yaml.dump(hostvars, Dumper=AnsibleDumper) == "{foo: bar, boo: {baz: faz}}"

    # Test that config is getting passed through to representer
    assert yaml.dump(hostvars, Dumper=AnsibleDumper, indent=4) == "{\n    foo: bar,\n    boo: {\n        baz: faz\n    }\n}"



# Generated at 2022-06-22 13:52:48.663495
# Unit test for function represent_binary
def test_represent_binary():
    # bytes
    assert yaml.dump(b'foo', Dumper=AnsibleDumper)[0] == '!'
    # basestring
    assert yaml.dump(u'foo', Dumper=AnsibleDumper)[0] == '\''

# Generated at 2022-06-22 13:52:52.874881
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(b'foo', Dumper=AnsibleDumper).strip() == '!!binary |\n  Zm9v'


# Generated at 2022-06-22 13:53:04.031730
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

    # Test binary encoding
    value_bytes = b'\x01\x02\x03'
    expected_output = u'!!binary |\n  AQID\n'
    actual_output = dumper.represent_binary(value_bytes)
    assert actual_output == expected_output

    # Test binary empty string
    value_bytes = b''
    expected_output = u'!!binary |\n  \n'
    actual_output = dumper.represent_binary(value_bytes)
    assert actual_output == expected_output

    # Test binary encoding with unsafe characters
    value_bytes = b'\x01\xff\x03'
    expected_output = u'!!binary |\n  AQ/D\n'

# Generated at 2022-06-22 13:53:10.326944
# Unit test for function represent_binary
def test_represent_binary():
    data = b"\x00\x11\x22\x33\x44\x55\x66\x77\x88\x99\xaa\xbb\xcc\xdd\xee\xff"
    assert yaml.dump(data, Dumper=AnsibleDumper) == "!!binary |\n  AAEKCQoLFQ4RFhgYGhocHiIjJCUmJygpKissLS4vMDEyMzQ1Njc4\n  OTw9P0BBQkNERUZHSElKS0xNTk9QUVJTVFVWV1hZWmFiY2RlZmdo\n  aWprbG1ub3BxcnN0dXZ3eHl6e3w="



# Generated at 2022-06-22 13:53:16.587753
# Unit test for function represent_binary
def test_represent_binary():
    dumper = yaml.dumper.Dumper
    dumper.add_representer(
        AnsibleUnsafeBytes,
        represent_binary,
    )
    assert dumper.represent_binary(dumper, b'\x01\x02\x03') == b'?\n- \'\x01\n- \'\x02\n- \'\x03'

# Generated at 2022-06-22 13:53:23.677142
# Unit test for function represent_binary
def test_represent_binary():
    # create a binary string
    data = bytearray(b'\x09\x31\x41\xff')
    # create instance of AnsibleDumper
    instance = AnsibleDumper()
    # make sure that a binary string is represented in
    # Base64 format
    representation = instance.represent_binary(data)
    # base64 encoded string
    assert representation == u'!!binary |\n  CQYxQWZm\n', 'representation is wrong %r' % representation



# Generated at 2022-06-22 13:53:28.260827
# Unit test for function represent_binary
def test_represent_binary():
    # Normal case
    data = AnsibleUnsafeBytes(b'\x06\x00\x02')
    assert yaml.representer.SafeRepresenter.represent_binary(None, data) == '!!binary |\n  CAAA\n'



# Generated at 2022-06-22 13:53:32.245206
# Unit test for function represent_binary
def test_represent_binary():
    func = AnsibleDumper.yaml_representers[binary_type]
    assert func(None, '0x01') == '!!binary |-\n  MDA=\n'
    assert func(None, '0x') == '!!binary |-\n  \n'

# Generated at 2022-06-22 13:53:35.672049
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    output = dumper.represent_binary(b"this is a test")
    assert output == u"!!binary |-\n  dGhpcyBpcyBhIHRlc3Q=\n"

# Generated at 2022-06-22 13:53:41.147539
# Unit test for function represent_binary
def test_represent_binary():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import b
    value = b("\xff")
    assert to_text(yaml.dump(value, Dumper=AnsibleDumper), errors='surrogate_or_strict') == u"!binary |\n  /w==\n"

# Generated at 2022-06-22 13:53:47.895628
# Unit test for function represent_binary
def test_represent_binary():
    '''
    AnsibleDumper.add_representer(
        AnsibleUnsafeBytes,
        represent_binary,
    )
    '''
    string = b'Hello World'
    expected = '!!binary |\n  SGVsbG8gV29ybGQ='
    result = yaml.dump(string, Dumper=AnsibleDumper)
    assert result == expected, 'result:\n%s\nexpected:\n%s' % (result, expected)