

# Generated at 2022-06-22 13:51:03.982278
# Unit test for function represent_unicode
def test_represent_unicode():
    data = AnsibleUnicode("hello world")
    result = yaml.dump(data, Dumper=AnsibleDumper, default_flow_style=False)
    assert result == "\"hello world\"\n"



# Generated at 2022-06-22 13:51:08.790839
# Unit test for function represent_unicode
def test_represent_unicode():

    def check(input_unicode, expected_str):
        output_str = yaml.dump(input_unicode, Dumper=AnsibleDumper, default_flow_style=False)
        assert output_str == expected_str

    check(u"1.\U000f0000.3", u"1.\U000f0000.3\n")
    check(u"1.\N{SOUTH EAST ARROW}.3", u"1.\N{SOUTH EAST ARROW}.3\n")



# Generated at 2022-06-22 13:51:11.821518
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import StrictUndefined
    obj = StrictUndefined()
    assert not AnsibleDumper().represent_undefined(obj)

# Generated at 2022-06-22 13:51:16.828008
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper(None).represent_data({None: None}) == 'null: null\n'
    assert AnsibleDumper(None).represent_data({1: AnsibleUndefined()}) == '1: null\n'
    assert AnsibleDumper(None).represent_data({1: AnsibleUndefined()}) == '1: null\n'

# Generated at 2022-06-22 13:51:21.017237
# Unit test for function represent_binary
def test_represent_binary():
    a = AnsibleDumper()
    assert a.represent_scalar(u'tag:yaml.org,2002:binary', '\x01\x02\x03\x04', style='|') == \
           AnsibleUnicode(u'tag:yaml.org,2002:binary\n\x01\x02\x03\x04')

# Generated at 2022-06-22 13:51:23.889124
# Unit test for function represent_unicode
def test_represent_unicode():
    obj = AnsibleUnicode(u'foo')
    assert represent_unicode(None, obj) == u"'foo'\n"

# Generated at 2022-06-22 13:51:24.930639
# Unit test for function represent_hostvars
def test_represent_hostvars():
    pass



# Generated at 2022-06-22 13:51:28.182566
# Unit test for function represent_unicode
def test_represent_unicode():
    yaml_unicode = yaml.dump(AnsibleUnicode('test_string'), Dumper=AnsibleDumper, default_flow_style=False)
    assert yaml_unicode == 'test_string\n'



# Generated at 2022-06-22 13:51:32.746291
# Unit test for function represent_hostvars
def test_represent_hostvars():
    sample_data = {'some_var': 'my value'}
    sample_object = HostVars(sample_data, 'some_file')
    test_object = AnsibleDumper()

    assert test_object.represent_hostvars(sample_object) == test_object.represent_dict(sample_data)

# Generated at 2022-06-22 13:51:40.076460
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from collections import namedtuple
    from ansible.template import Templar
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Create a test string
    secret_string = 'my vaulted string'

    # Encrypt it
    vault = VaultLib([])
    encrypted_string = vault.encrypt(secret_string)

    # Create a AnsibleVaultEncryptedUnicode instance similar to what we get
    # when decrypting a vault file
    cipher_name, cipher_version, ciphertext = encrypted_string.split('$')

# Generated at 2022-06-22 13:51:46.448025
# Unit test for function represent_hostvars
def test_represent_hostvars():
    h = HostVars({"a": 1}, "b.yml")
    d = AnsibleDumper(width=100)
    output = d.represent_dict(dict(h))
    assert yaml.load(output) == {"b.yml": {"a": 1}}

# Generated at 2022-06-22 13:51:49.590147
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(b'hello\xc3\x9f', Dumper=AnsibleDumper) == \
        '!!binary |-\n  aGVsbG8M\n'

# Generated at 2022-06-22 13:51:54.011549
# Unit test for function represent_unicode
def test_represent_unicode():

    dumper = AnsibleDumper()
    dumper.add_representer(
        AnsibleUnicode,
        represent_unicode,
    )

    assert dumper.represent_unicode(u'test') == dumper.represent_str('test')



# Generated at 2022-06-22 13:52:06.312244
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    assert represent_vault_encrypted_unicode(None, AnsibleVaultEncryptedUnicode("hello")) == "!vault |\n  $ANSIBLE_VAULT;1.1;AES256\n  323366616332336338346439353337663161653866386234396631633539616233663538343539\n  333837333436383466333261666233336230396335643466666564353062666336643139643533\n  383964356539313533636130393636623637343530333830376439353332393862316361316466\n  63643635663231656133373933303763303565\n"

# Generated at 2022-06-22 13:52:13.754316
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper
    hvar = HostVars()
    hvar.add('foo', 'bar')
    print(yaml.dump(hvar, Dumper=AnsibleDumper, default_flow_style=False))
    assert yaml.dump(hvar, Dumper=dumper, default_flow_style=False) == 'foo: bar\n'
    hvars = HostVarsVars()
    hvars.add('foo', 'bar')
    print(yaml.dump(hvars, Dumper=AnsibleDumper, default_flow_style=False))
    assert yaml.dump(hvars, Dumper=dumper, default_flow_style=False) == 'foo: bar\n'
    vws = VarsWithSources()

# Generated at 2022-06-22 13:52:16.608342
# Unit test for function represent_unicode
def test_represent_unicode():
    from ansible.utils.unsafe_proxy import wrap_var

    assert yaml.dump([wrap_var('foo')], Dumper=AnsibleDumper) == '- foo\n'

# Generated at 2022-06-22 13:52:24.447084
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # Setup AnsibleUnsafeText object
    setup = u"{u'foo': u'bar'}"

    # Convert setup object to hostvars
    hvars = HostVars(setup)

    # Render hostvars object as a yaml string
    output = yaml.dump(dict(hvars), Dumper=AnsibleDumper, default_flow_style=False)

    # Asserts the output is rendered in correct format
    assert output == u"{foo: bar}\n"



# Generated at 2022-06-22 13:52:32.149086
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    # We cannot use the dumper.represent_unicode function directly here
    # because it does not expect to be given a SafeRepresenter object.
    # Instead it expects to be the method of the object.
    # This means the first parameter is "self", which is a SafeRepresenter
    # object.
    ansible_unicode = AnsibleUnicode(value='string')
    result = dumper.represent_unicode(dumper, ansible_unicode)
    assert result == "string"

# Generated at 2022-06-22 13:52:38.103269
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    aue = AnsibleVaultEncryptedUnicode("$ANSIBLE_VAULT;1.1;AES256\n" +
                                       "393939393939393939393939393939393939393939393939393939393939\n" +
                                       "393939393939393939393939393939393939393939393939393939393939\n")
    result = yaml.dump(aue, Dumper=AnsibleDumper)

# Generated at 2022-06-22 13:52:41.068878
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper
    assert dumper.represent_hostvars(dumper, {}) == dumper.represent_dict(dumper, {})



# Generated at 2022-06-22 13:52:50.638555
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    test_unicode_text = 'this is a test'
    test_unicode_object = AnsibleVaultEncryptedUnicode(test_unicode_text)
    assert(represent_vault_encrypted_unicode(None, test_unicode_object) ==
           yaml.representer.SafeRepresenter.represent_scalar(None, u'!vault', test_unicode_text, style='|'))

# Generated at 2022-06-22 13:52:57.162697
# Unit test for function represent_unicode
def test_represent_unicode():
    data = AnsibleUnicode(u'f\xf6\xf6')
    # pylint: disable=protected-access
    assert yaml.representer.SafeRepresenter.represent_str(AnsibleDumper, text_type(data)) == u'"f\\xf6\\xf6"'
    # pylint: enable=protected-access


# Generated at 2022-06-22 13:53:07.835677
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-22 13:53:13.560697
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    data = AnsibleUnsafeBytes(b'hello world')
    assert dumper.represent_binary(dumper, data) == yaml.representer.SafeRepresenter.represent_binary(dumper, binary_type(data))



# Generated at 2022-06-22 13:53:24.014063
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # test our special case agains the regular representer
    representer = yaml.representer.SafeRepresenter.represent_str

# Generated at 2022-06-22 13:53:28.171598
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    test_data = u'abc'
    assert dumper.represent_unicode(dumper, test_data) == dumper.represent_str(dumper, text_type(test_data))



# Generated at 2022-06-22 13:53:37.564316
# Unit test for function represent_unicode

# Generated at 2022-06-22 13:53:38.995557
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, None) is None



# Generated at 2022-06-22 13:53:50.245686
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256

    vault = VaultLib([])
    password = VaultPassword('test')
    secret = VaultSecret('AES256', password)
    encrypted = vault.encrypt(secret, 'Test')
    encrypted = AnsibleVaultEncryptedUnicode(encrypted, secret)

    dumper = AnsibleDumper(default_flow_style=False, allow_unicode=True)
    output = dumper.represent_vault_encrypted_unicode(encrypted)

    # The vault string should be all ascii characters
    assert all(ord(c) < 128 for c in output)

    #

# Generated at 2022-06-22 13:54:01.961365
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 13:54:09.579834
# Unit test for function represent_binary
def test_represent_binary():
    yaml.dumper.SafeDumper.represent_binary(None, b'\xff')

# Generated at 2022-06-22 13:54:14.513961
# Unit test for function represent_binary
def test_represent_binary():
    data = AnsibleUnsafeBytes(b"\x80\x81\x82")
    dumper = AnsibleDumper
    # Return value is an encoded string object
    ret = dumper.represent_binary(dumper, data)
    assert isinstance(ret, text_type)
    # Return value is encoded in Base64
    assert ret == text_type(b"!!binary |\n  gICBgg==\n")

# Generated at 2022-06-22 13:54:21.312876
# Unit test for function represent_binary
def test_represent_binary():
    # Test for a str
    dumper = AnsibleDumper(None)
    result = dumper.represent_binary('\x00\x01\x02')
    expected_result = (u"!!binary |\n"
                       u"  AAEC\n")
    assert result == expected_result

    # Test for unicode
    result = dumper.represent_binary(u'\u0020')
    expected_result = (u"!!binary |\n"
                       u"  IQ==\n")
    assert result == expected_result

    # Test for integer
    result = dumper.represent_binary(50)
    expected_result = (u"!!binary |\n"
                       u"  MQ==\n")
    assert result == expected_result

# Generated at 2022-06-22 13:54:24.156247
# Unit test for function represent_binary
def test_represent_binary():
    assert(yaml.dump(b'\x00\x01\x02\x03\x04', Dumper=AnsibleDumper).rstrip() == b"!!binary |\n  AAECAwQF")



# Generated at 2022-06-22 13:54:33.346050
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    text = u'ZHVja2ly'
    # Note: We test using text and bytes in the same test case so that
    # we can use assertEqual.
    # Note: We need to decode the result from bytes to text so that
    # the result can be compared with text.
    assert dumper.represent_binary(dumper, text) == dumper.represent_binary(dumper, text.encode()).decode()
    assert dumper.represent_binary(dumper, text.encode()) == '!!binary |\n  ZHVja2ly'
    assert dumper.represent_binary(dumper, text.encode(u'utf-16')) == '!!binary |\n  R0FcDw=='

# Generated at 2022-06-22 13:54:37.504765
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    yaml_data = dumper.represent_binary(b'password:')
    assert yaml_data == '!!binary |\n  cGFzc3dvcmQ6'

# Generated at 2022-06-22 13:54:44.490482
# Unit test for function represent_binary
def test_represent_binary():
    # construct a binary string with embedded nulls
    s = AnsibleUnsafeBytes(b'\x00\x01\x02Hello\x00World!\x00')
    # use yaml_dumper to represent this binary data
    dumper = AnsibleDumper()
    resp = dumper.represent_binary(s)
    # check expected result
    assert resp == u'!binary |\n  AAECCgRsaGVsbG8ACEF3b3JsZCE=\n'

# Generated at 2022-06-22 13:54:49.075290
# Unit test for function represent_binary
def test_represent_binary():
    assert AnsibleDumper.represent_binary(None, b'foo') == u'!binary |\n  Zm9v\n'


# Generated at 2022-06-22 13:54:53.329052
# Unit test for function represent_binary
def test_represent_binary():
    o = AnsibleUnsafeBytes(b'\xBE\xEF')
    w = yaml.dumper.SafeDumper()
    w.allow_unicode = True
    d = AnsibleDumper(w)
    result = d.represent_binary(o)
    assert result == u'? !!binary |\n  +gD4\n'

# Generated at 2022-06-22 13:55:02.846970
# Unit test for function represent_binary
def test_represent_binary():
    # empty string
    test_str = b''
    test_str_yaml = yaml.safe_dump(test_str, default_flow_style=False)
    assert test_str_yaml == "''\n"

    # string with printable chars
    test_str = b"\x42"
    test_str_yaml = yaml.safe_dump(test_str, default_flow_style=False)
    assert test_str_yaml == "!!binary |\n  Qg==\n"

    # string with non-printable chars
    test_str = b"\x01\x02\x04\x08"
    test_str_yaml = yaml.safe_dump(test_str, default_flow_style=False)