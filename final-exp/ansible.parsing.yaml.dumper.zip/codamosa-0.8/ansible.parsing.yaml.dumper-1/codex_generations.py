

# Generated at 2022-06-22 13:51:03.484701
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert represent_hostvars(None, HostVars({'foo': 'bar'})) == {'foo': 'bar'}


# Generated at 2022-06-22 13:51:07.144946
# Unit test for function represent_unicode
def test_represent_unicode():
    represent_unicode_dumper = AnsibleDumper()

    unicode_value = u'unicode'

    represent_unicode_dumper.add_representer(
        AnsibleUnicode,
        represent_unicode,
    )

    assert(represent_unicode_dumper.represent_data(unicode_value) == u'unicode\n')



# Generated at 2022-06-22 13:51:18.757537
# Unit test for function represent_undefined

# Generated at 2022-06-22 13:51:22.752539
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.dump(AnsibleUndefined, Dumper=AnsibleDumper) == 'None\n'
    assert yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper) == 'None\n'

# Generated at 2022-06-22 13:51:27.277392
# Unit test for function represent_unicode
def test_represent_unicode():
    try:
        # python 2.7
        unicode
    except NameError:
        test_unicode = "Python3 string"
    else:
        test_unicode = unicode("Python2 string")
    data = AnsibleUnicode(test_unicode)
    dumper = AnsibleDumper()
    result = dumper.represent_unicode(data)
    if test_unicode != result.value:
        raise AssertionError("Expected {} to be returned but got {}".format(test_unicode, result.value))

# Generated at 2022-06-22 13:51:30.883474
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import undefined
    dumper = AnsibleDumper
    undefined = undefined()
    dumper.add_representer(type(undefined), represent_undefined)
    dumper.represent_data(undefined)

# Generated at 2022-06-22 13:51:39.184159
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper(None, None, None, None)
    hv1 = HostVars(dict(host="host1", port="100"))
    hv2 = HostVars(dict(host="host2", port="200"))
    hvv = HostVarsVars([hv1, hv2], dict(host="local", port="56"))
    vws = VarsWithSources(hvv, [], [{'source': 'A', 'key': 'A', 'value': 'A'}, {'source': 'B', 'key': 'B', 'value': 'B', 'locations': ['var1', 'var2']}])


# Generated at 2022-06-22 13:51:41.696105
# Unit test for function represent_undefined
def test_represent_undefined():
    obj = AnsibleUndefined(name='TEST')
    AnsibleDumper.represent_undefined(None, obj)

# Generated at 2022-06-22 13:51:47.739773
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper().represent_undefined('not-undefined') is None
    assert AnsibleDumper().represent_undefined(AnsibleUndefined()) is None
    import pytest
    with pytest.raises(yaml.representer.RepresenterError):
        AnsibleDumper().represent_undefined(AnsibleUndefined(fail_on_undefined=True))

# Generated at 2022-06-22 13:51:52.883416
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # Create a unique Hostvars object for the test
    hostvars = HostVars(vars=dict(foo='bar'))

    # Check output
    assert yaml.safe_dump({'a': hostvars}, Dumper=AnsibleDumper) == '{a: {foo: bar}}\n'



# Generated at 2022-06-22 13:52:07.448454
# Unit test for function represent_hostvars
def test_represent_hostvars():

    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.play_context import PlayContext

    context = PlayContext()
    data = AnsibleLoader(None, context).get_single_data('''
    ---
    a:
      b:
        c: value
    ''')

    # test plain dict values, with and without context
    assert yaml.safe_dump(HostVars(data), default_flow_style=False) == '\n'.join((
        'a:',
        '  b:',
        '    c: value',
    )) + '\n'


# Generated at 2022-06-22 13:52:10.101328
# Unit test for function represent_unicode
def test_represent_unicode():
    data = AnsibleUnicode('abc')
    result = represent_unicode(None, data)
    assert isinstance(result, yaml.ScalarNode)


# Generated at 2022-06-22 13:52:22.000740
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    assert dumper.represent_unicode(dumper, u'foo') == u'foo'
    assert dumper.represent_unicode(dumper, u'foo\nbar') == u'>\n  foo\n  bar'
    assert dumper.represent_unicode(dumper, u'foo\nbar\nbaz') == u'>\n  foo\n  bar\n  baz'
    assert dumper.represent_unicode(dumper, u'foo\u03bc') == u'foo\u03bc'
    assert dumper.represent_unicode(dumper, u'foo\u03bc\nbar') == u'>\n  foo\u03bc\n  bar'
    assert dumper.represent_unicode(dumper, 'foo') == u'foo'

# Generated at 2022-06-22 13:52:28.181752
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    # represent_undefined must return a true (bool) value, so we can
    # check it in ansible/template/__init__.py
    # But don't output anything to yaml
    assert dumper.represent_undefined(False) is True


# Lookup python2/python3 compatible types
_strtype = text_type
_bytestype = binary_type

# Generated at 2022-06-22 13:52:37.592444
# Unit test for function represent_unicode
def test_represent_unicode():
    data = AnsibleUnicode('\xF0\x9F\x90\x8D')
    assert yaml.dump(data, Dumper=AnsibleDumper, default_flow_style=False) == u'test: \U0001f40d'
    assert yaml.dump(data, Dumper=AnsibleDumper, default_flow_style=True) == '{test: 🐍}\n'
    assert yaml.dump({'test': data}, Dumper=AnsibleDumper, default_flow_style=False) == u'test:\n  test: \U0001f40d'



# Generated at 2022-06-22 13:52:44.098294
# Unit test for function represent_hostvars
def test_represent_hostvars():
    '''
    Testing that represent_hostvars is returning the expected dict
    '''

    data = {
        u'a': u'A',
        u'b': u'B',
    }
    hostvars = HostVars(data)
    dump = yaml.dump(hostvars, Dumper=AnsibleDumper)
    assert dump == u"{a: A, b: B}\n"



# Generated at 2022-06-22 13:52:57.011717
# Unit test for function represent_unicode
def test_represent_unicode():
    # Check that it works for a unicode object.
    u = u'foo'
    assert isinstance(u, text_type)
    repr_u = represent_unicode(AnsibleDumper, u)
    assert isinstance(repr_u, text_type)
    assert repr_u == u'foo\n...\n'

    # Check that it works for a string that happens to be latin-1.
    l1 = 'foo'
    assert isinstance(l1, text_type)
    assert isinstance(l1, str)
    repr_l1 = represent_unicode(AnsibleDumper, l1)
    assert isinstance(repr_l1, text_type)
    assert repr_l1 == u'foo\n...\n'

    # Check that it works for a string that happens

# Generated at 2022-06-22 13:53:02.259406
# Unit test for function represent_hostvars
def test_represent_hostvars():
    h = HostVars({"foo": "bar"})
    rep = AnsibleDumper.represent_hostvars(h)
    assert rep == {'foo': 'bar'}

    h = HostVars({"foo": "bar"})
    rep = AnsibleDumper.represent_hostvars(h)
    assert rep == {"foo": "bar"}

# Generated at 2022-06-22 13:53:07.276139
# Unit test for function represent_unicode
def test_represent_unicode():
    from ansible.template import template

    dumper = AnsibleDumper
    data = template.AnsibleUndefined(var_name='var_name', task_vars=dict())
    try:
        dumper.represent_unicode(data)
    except Exception as e:
        if 'jinja2.exceptions.UndefinedError' not in e.__class__.__name__:
            raise
        # pass, test passed
    else:
        raise

# vim: set filetype=python sw=4 :

# Generated at 2022-06-22 13:53:19.624324
# Unit test for function represent_binary
def test_represent_binary():
    test_data = [{
        'data': b'\xff\xfe\xfd',
        'expected': u'\x00\xff\x00\xfe\x00\xfd'
    }, {
        'data': b'\xab\xba\x04',
        'expected': u'\x00\xab\x00\xba\x00\x04'
    }, {
        'data': b'\x00\x01\x02',
        'expected': u'\x00\x00\x00\x01\x00\x02'
    }]

    dumper = AnsibleDumper()

    # This function has a side effect of setting the line_break
    # attribute on the dumper to: line_break = self.represent_scalar(u'tag:yaml

# Generated at 2022-06-22 13:53:37.712508
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()
    # Creating a test AnsibleVaultEncryptedUnicode object
    aveu = AnsibleVaultEncryptedUnicode('test')
    # Creating byte string from .to_yaml
    bs = dumper.represent_vault_encrypted_unicode(aveu).encode()

# Generated at 2022-06-22 13:53:48.871758
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    variable_manager = VariableManager()
    hostvars = HostVars(variable_manager=variable_manager, hostname='test')
    hostvars.vars['test_var'] = 'test_val'
    hostvars.vars['undefined_var'] = AnsibleUndefined
    hostvars.vars['binary_var'] = b'test_binary'
    hostvars.vars['unsafe_text_var'] = AnsibleUnsafeText(u'test_unsafe_text')
    hostvars.vars['unsafe_bytes_var'] = AnsibleUnsafeBytes(b'test_unsafe_bytes')
    data = hostvars

# Generated at 2022-06-22 13:53:59.434422
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Test when data._ciphertext is valid string
    secret_input = AnsibleVaultEncryptedUnicode(u'ansible', u'secret')
    assert represent_vault_encrypted_unicode(AnsibleDumper, secret_input) == u'!vault |\n  U0dwRmZnc0pZSE9XZ0xRZGVvOFZ5WlN5c0NYODl2QzFhNGx1K0M3Z3B2Q2VuNVhB\n  allzZnRUZGd1TjA4WFU=\n'

# Test when data._ciphertext is empty string

# Generated at 2022-06-22 13:54:04.591460
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = '1234567890abcdef'
    ciphertext = AnsibleVaultEncryptedUnicode(data)
    dumper = AnsibleDumper(None, None, None)

    assert represent_vault_encrypted_unicode(dumper, ciphertext) == "!vault |\n          "+"\n          ".join([data[i:i+60] for i in range(0, len(data), 60)])

# Generated at 2022-06-22 13:54:08.154549
# Unit test for function represent_binary
def test_represent_binary():
    data_bytes = b'\xff\x00'

    dumper = AnsibleDumper()

    # Just make sure this will not fail
    yaml.representer.SafeRepresenter.represent_binary(dumper, data_bytes)

# Generated at 2022-06-22 13:54:10.367110
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert yaml.dump(HostVars({'a': '1'}), Dumper=AnsibleDumper).next().endswith('a: 1')



# Generated at 2022-06-22 13:54:16.536169
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.round_trip_load(yaml.dump(b'\x00\x01\x02\x03\x04')) == b'\x00\x01\x02\x03\x04'
    assert yaml.round_trip_load(yaml.dump(b'\x00\x01\x02\x03\x04', Dumper=AnsibleDumper)) == b'\x00\x01\x02\x03\x04'



# Generated at 2022-06-22 13:54:25.466371
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = AnsibleVaultEncryptedUnicode(value='some_value')

# Generated at 2022-06-22 13:54:33.858433
# Unit test for function represent_binary
def test_represent_binary():

    assert yaml.safe_dump(b'\x00', Dumper=AnsibleDumper) == b'!!binary |-\n  AA==\n'
    assert yaml.safe_dump(b'\x00\x01', Dumper=AnsibleDumper) == b'!!binary |-\n  AAIA\n'
    assert yaml.safe_dump(b'\x00\x01\x02', Dumper=AnsibleDumper) == b'!!binary |-\n  AAIC\n'
    assert yaml.safe_dump(b'\x00\x01\x02\x03', Dumper=AnsibleDumper) == b'!!binary |-\n  AAID\n'

# Generated at 2022-06-22 13:54:39.022712
# Unit test for function represent_hostvars
def test_represent_hostvars():
    '''Test represent_hostvars()'''

    hostvars = HostVars(hostvars={'foo': 'bar'})
    dumper = AnsibleDumper()
    result = dumper.represent_hostvars(hostvars)

    assert result is not None
    assert result.value == "{foo: bar}"



# Generated at 2022-06-22 13:54:55.004224
# Unit test for function represent_binary
def test_represent_binary():
    string = b'\x80\x00\x00\x00'
    assert yaml.dump(string, Dumper=AnsibleDumper) == u'!!binary |\n  gAAAAAAAAA=\n'



# Generated at 2022-06-22 13:55:00.064306
# Unit test for function represent_binary
def test_represent_binary():
    representer = yaml.representer.SafeRepresenter()
    binary_string = b'\x9b\xa2\x10\xac'
    output = representer.represent_binary(binary_string)
    assert isinstance(output, str)
    assert output == binary_string.decode('ISO-8859-1')

# Generated at 2022-06-22 13:55:04.697250
# Unit test for function represent_binary
def test_represent_binary():
    data = b'hi'
    rep = yaml.representer.SafeRepresenter()
    assert represent_binary(rep, data) == yaml.representer.SafeRepresenter.represent_binary(rep, binary_type(data))

# Generated at 2022-06-22 13:55:13.492372
# Unit test for function represent_binary
def test_represent_binary():
    representer = AnsibleDumper.yaml_representers[binary_type]

    result = representer(AnsibleDumper, u'foo'.encode('utf-8'))
    assert result == b'!!binary |\n  Zm9v\n'

    # Check that the default yaml dumper can render bytes objects correctly
    assert yaml.dump(u'foo'.encode('utf-8'), Dumper=yaml.SafeDumper) == '!!binary |\n  Zm9v\n'

    # Previously the unicode method was used to dump binary.
    # This is not correct and the test exists to ensure this
    # does not regress again.
    assert yaml.dump(u'foo'.encode('utf-8'), Dumper=yaml.SafeDumper) != 'foo'

    # Previously the unic

# Generated at 2022-06-22 13:55:23.790209
# Unit test for function represent_binary
def test_represent_binary():
    # We have to use a generic loader/dumper, since we need to load data
    # that was given back to us by the generic dumper.

    test_data = '\x8e\x0b\x9f\xcb'
    d = {'test': test_data}

    # Load data with generic dumper
    yd = yaml.YAML()
    yd.default_flow_style = None
    yd.indent(mapping=2, sequence=4, offset=2)
    yd.width = 80

    result = yd.dump(d)
    assert result == '---\ntest: !!binary |-\n  x8eQF3q7\n'

    # Now load resulting data with our custom dumper.
    # If represent_binary fails to represent the data properly
   

# Generated at 2022-06-22 13:55:29.421067
# Unit test for function represent_binary
def test_represent_binary():
  dumper = yaml.SafeDumper()
  dumper.represent_binary = represent_binary
  result = yaml.dump(b'foo', Dumper=dumper)
  assert isinstance(result, text_type)
  assert result == "!!binary \"Zm9v\"\n"

# Generated at 2022-06-22 13:55:35.003897
# Unit test for function represent_binary
def test_represent_binary():
    """
    Test ability to convert binary strings to yaml-safe strings
    """
    data = b'hello world'
    dumper = yaml.dumper.SafeDumper
    r = yaml.representer.SafeRepresenter.represent_binary(dumper, data)
    assert(r == '!!binary \'aGVsbG8gd29ybGQ=\'')

# Generated at 2022-06-22 13:55:42.100126
# Unit test for function represent_binary
def test_represent_binary():

    class AnsibleDumperForTest(AnsibleDumper):
        def represent_binary(self, data):
            return yaml.representer.SafeRepresenter.represent_binary(self, binary_type(data))

    # test binary without replace
    obj = AnsibleDumperForTest(allow_unicode=True, default_style=None)
    s = 'a binary string'
    expected_output = b"a binary string\n"
    output = obj.represent_binary(s)
    assert output == expected_output

    # test binary with replace
    obj = AnsibleDumperForTest(allow_unicode=True, default_style=None, encoding="replace")
    s = 'a binary string'
    expected_output = b"a ?inary string\n"
    output = obj.represent_binary(s)

# Generated at 2022-06-22 13:55:44.681639
# Unit test for function represent_binary
def test_represent_binary():
    dumper = yaml.SafeDumper(allow_unicode=True)
    binary_data = dumper.represent_binary(b'\xe7\x94\xa8')
    assert binary_data == '!!binary |-\n  w7DD\n'

# Generated at 2022-06-22 13:55:46.901991
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper(None)
    assert dumper.represent_binary(b'foo') == u'!binary |\n  Zm9v\n'



# Generated at 2022-06-22 13:55:57.540273
# Unit test for function represent_binary
def test_represent_binary():
    """Unit test for function represent_binary
    """
    from ansible.parsing.yaml.loader import AnsibleLoader

    source = "test_value: !!binary foo"
    data = yaml.load(source, Loader=AnsibleLoader)
    representer = AnsibleDumper.yaml_representers[binary_type]
    output = representer(AnsibleDumper, data['test_value'])
    expected = "!!binary 'Zm9v'\n"
    assert output == expected

# Generated at 2022-06-22 13:56:01.334129
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'\xff') == u'!!binary |\n  /w=='



# Generated at 2022-06-22 13:56:12.071460
# Unit test for function represent_binary
def test_represent_binary():
    # Test default
    dumper = AnsibleDumper(default_style='|')
    data = b'some binary data'
    expected = u'|-\n  c29tZSBiaW5hcnkgZGF0YQ=='
    result = yaml.dump(data, Dumper=dumper)
    assert result == expected

    # Test folding whitespace, in this case tabs
    dumper = AnsibleDumper(default_style='>')
    data = b'some binary data\t\t\t\t\t'
    expected = u'>-\n  c29tZSBiaW5hcnkgZGF0YQ==\t\t\t\t\t'
    result = yaml.dump(data, Dumper=dumper)
    assert result == expected

# Generated at 2022-06-22 13:56:16.545751
# Unit test for function represent_binary
def test_represent_binary():
    # generate test data
    data = dict(binary=binary_type("blah"))

    # represent the data
    output = yaml.dump(data, Dumper=AnsibleDumper, default_flow_style=False)

    # clean the output and make sure it matches the data
    assert output.strip() == "{binary: !!binary 'YmxhaA=='}"

# Generated at 2022-06-22 13:56:19.681762
# Unit test for function represent_binary
def test_represent_binary():
    orig_data = '\x80'
    result = represent_binary(AnsibleDumper, AnsibleUnsafeBytes(orig_data))
    assert result == "!!binary |\n  gA==\n"

# Generated at 2022-06-22 13:56:24.197460
# Unit test for function represent_binary
def test_represent_binary():
    value = AnsibleUnsafeBytes(b'\x00\x01\x02')
    result = yaml.representer.SafeRepresenter.represent_binary(None, value)
    assert result == '!!binary |\n  AAAA\n'

# Generated at 2022-06-22 13:56:30.670009
# Unit test for function represent_binary
def test_represent_binary():
    ''' Testing yaml.represent_binary(self, data) '''

    from yaml.compat import StringIO
    from io import StringIO
    from sys import version_info

    stream = StringIO()
    dumper = AnsibleDumper(stream)

    string = "I am a string"
    if version_info[0] == 3:
        # Python 3
        string = string.encode('utf-8')

    data = {"foo": string}

    dumper.represent_data(data)
    stream.seek(0)
    assert stream.read() == "{foo: !!binary '%s'}\n" % string.decode()

# Generated at 2022-06-22 13:56:37.764824
# Unit test for function represent_binary
def test_represent_binary():
    # When input is not encoded bytes
    assert AnsibleDumper.represent_binary(
        SafeDumper,
        'abc'
    ) == "'abc'"

    # When input is encoded bytes
    assert AnsibleDumper.represent_binary(
        SafeDumper,
        b'abc'
    ) == "!!binary 'YWJj'\n"

    # when input is None
    assert AnsibleDumper.represent_binary(
        SafeDumper,
        None
    ) == 'null'



# Generated at 2022-06-22 13:56:40.418856
# Unit test for function represent_binary
def test_represent_binary():
    rep = AnsibleDumper.represent_binary
    assert rep(None, b'foo') == rep(None, u'foo')



# Generated at 2022-06-22 13:56:44.952832
# Unit test for function represent_binary
def test_represent_binary():
    yaml_str = yaml.dump(dict(a=b'\x00\x01\x02\x0a'), Dumper=yaml.SafeDumper)
    assert yaml_str == '{a: !!binary "\\x00\\x01\\x02\\n"}\n'



# Generated at 2022-06-22 13:56:55.220422
# Unit test for function represent_binary
def test_represent_binary():
    representer = AnsibleDumper.yaml_representers[binary_type]
    represention = representer(AnsibleDumper, b'ansible')
    assert represention == u'!!binary |\n      YW5zaWJsZQ==\n'



# Generated at 2022-06-22 13:56:57.684531
# Unit test for function represent_binary
def test_represent_binary():
    output = yaml.dump('a', Dumper=AnsibleDumper)
    assert output == 'a\n...\n'

# Generated at 2022-06-22 13:57:00.287946
# Unit test for function represent_binary
def test_represent_binary():
    output = b'!binary |\n  dGVzdC11bmljb2Rl'
    ansible_dumper = AnsibleDumper()
    assert output == ansible_dumper.represent_data(b'test-unicode')

# Generated at 2022-06-22 13:57:06.163622
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    binary = binary_type(b'\x00\x01\x02')
    assert dumper.represent_binary(binary) == (u'!!binary ' + u'\n' + u'AAEC')



# Generated at 2022-06-22 13:57:07.284957
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(b'somebody once told me', Dumper=AnsibleDumper) == 'somebody once told me\n...\n'

# Generated at 2022-06-22 13:57:09.614310
# Unit test for function represent_binary
def test_represent_binary():
    data = u'\u2605'
    dumper = AnsibleDumper()
    rep = dumper.represent_data(data)
    print(rep)
    rep = dumper.represent_data(data.encode('utf-8'))
    print(rep)


if __name__ == '__main__':
    test_represent_binary()

# Generated at 2022-06-22 13:57:11.374430
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(b'foo', Dumper=AnsibleDumper) == "!!binary |-\n  Zm9v\n"

# Generated at 2022-06-22 13:57:17.163966
# Unit test for function represent_binary
def test_represent_binary():
    data = b'aGVsbG8gd29ybGQ\n'
    dumper = AnsibleDumper
    yaml_out = dumper.represent_data(data)
    assert yaml_out == "!!binary |\n  aGVsbG8gd29ybGQ=\n"

# Generated at 2022-06-22 13:57:21.747217
# Unit test for function represent_binary
def test_represent_binary():
    a = AnsibleDumper()
    # byte literal
    assert a.represent_binary(b'foo') == u'!binary |\n  Zm9v\n'
    # bytearray literal
    assert a.represent_binary(bytearray(b'foo')) == u'!binary |\n  Zm9v\n'



# Generated at 2022-06-22 13:57:25.112365
# Unit test for function represent_binary
def test_represent_binary():
    def _check(value, expected):
        dumper = AnsibleDumper()
        dumper.represent_binary(value) == expected

    _check('\x6a\x6d\x65\x73', 'ZmVlZGJhY2s=\n')



# Generated at 2022-06-22 13:57:35.440589
# Unit test for function represent_binary
def test_represent_binary():
    from ansible.parsing.yaml.common import AnsibleDumper
    data = AnsibleDumper().represent_binary(b'foo\n')
    assert isinstance(data, binary_type)
    assert data == b"!binary |\n  Zm9vCg==\n"

# Generated at 2022-06-22 13:57:38.769946
# Unit test for function represent_binary
def test_represent_binary():
    test_string = b'Hello'
    assert AnsibleDumper.represent_binary(test_string) == yaml.representer.SafeRepresenter.represent_binary(test_string)

# Generated at 2022-06-22 13:57:42.819803
# Unit test for function represent_binary
def test_represent_binary():
    if yaml.safe_dump({'k': 'v'}, Dumper=AnsibleDumper).find('k') != -1:
        return
    else:
        raise Exception("represent_binary() failed")

# Generated at 2022-06-22 13:57:44.864440
# Unit test for function represent_binary
def test_represent_binary():
    assert represent_binary(None, b'\x00\x01\x02\x03\x04') == 'AQIDBAU=\n'

# Generated at 2022-06-22 13:57:46.830573
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper(None)
    assert dumper.represent_binary(b'123') == '!!binary |\n  MTIz\n'



# Generated at 2022-06-22 13:57:51.257676
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    result = dumper.represent_binary(dumper, u'\xc3\xa9')
    assert isinstance(result, text_type)
    assert result == "!!binary |\n  w6k=\n"

# Generated at 2022-06-22 13:57:53.345562
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary is not yaml.representer.SafeRepresenter.represent_binary

# Generated at 2022-06-22 13:57:55.848681
# Unit test for function represent_binary
def test_represent_binary():
    d = AnsibleDumper()
    assert yaml.representer.SafeRepresenter.represent_binary(d, b'a') == u'!!binary "YQ=="\n'

# Generated at 2022-06-22 13:57:58.627591
# Unit test for function represent_binary
def test_represent_binary():
    string = "abc\n def"
    assert AnsibleDumper.represent_binary(None, string) == '!!binary |\n  YWJjCiBkZWY=\n'



# Generated at 2022-06-22 13:58:03.267717
# Unit test for function represent_binary
def test_represent_binary():
    dumper = yaml.dumper.SafeDumper
    for bin in (b'\x00\x01', b'\x01\x00'):
        assert(bin == yaml.representer.SafeRepresenter.represent_binary(dumper, bin))



# Generated at 2022-06-22 13:58:14.228997
# Unit test for function represent_binary
def test_represent_binary():
    string = b'\x80\n'
    assert yaml.dump(string) == u'!!binary "gAoK"\n', (u'\n%s' % yaml.dump(string))



# Generated at 2022-06-22 13:58:16.776711
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(b'foo', Dumper=AnsibleDumper) == u'foo\n...\n'



# Generated at 2022-06-22 13:58:19.007116
# Unit test for function represent_binary
def test_represent_binary():
    data = b'\x80'
    assert yaml.dump(data, Dumper=AnsibleDumper) == "!!binary 'gA=='\n"

# Generated at 2022-06-22 13:58:21.683304
# Unit test for function represent_binary
def test_represent_binary():
    rep = AnsibleDumper.represent_binary

    # Test for python version 2 and 3.
    # Actually in python 3 this test is not necessary but we need to test
    # if bytes will work in python 2.
    assert rep(None, "data".encode()) == "!!binary data\n"



# Generated at 2022-06-22 13:58:24.956426
# Unit test for function represent_binary
def test_represent_binary():
    assert represent_binary(AnsibleDumper, AnsibleUnsafeBytes(b'foo')) == "!!binary |\n  Zm9v"


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-22 13:58:28.275133
# Unit test for function represent_binary
def test_represent_binary():
    res = yaml.representer.SafeRepresenter.represent_binary(None, '\x01')
    assert res == '!!binary "AQ=="'

# Generated at 2022-06-22 13:58:35.459795
# Unit test for function represent_binary
def test_represent_binary():
    import yaml.dumper
    import yaml.serializer
    import yaml.representer

    class Dumper(yaml.dumper.BaseDumper):
        def __init__(self):
            yaml.dumper.BaseDumper.__init__(self, yaml.serializer.Serializer(), yaml.representer.Representer())

    dumper = Dumper()
    assert dumper.represent_binary(b'a') == '!binary "YQ==\n"'
    assert dumper.represent_binary(b'a ') == '!binary "YSA=\n"'
    assert dumper.represent_binary(b'a a') == '!binary "YSAg\n"'
    assert dumper.represent_binary(b'a a ') == '!binary "YSAgIA==\n"'


# Generated at 2022-06-22 13:58:37.774009
# Unit test for function represent_binary
def test_represent_binary():
    expected_output = "<BINARY>\n"
    x = AnsibleDumper().represent_binary(b"this is a binary string")
    assert x == expected_output

# Generated at 2022-06-22 13:58:41.302619
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper(width=float("inf"))
    data = b'foo'
    yaml_data = dumper.represent_data(data)
    assert yaml_data == "!!binary |-\n  Zm9v"

# Generated at 2022-06-22 13:58:47.679203
# Unit test for function represent_binary
def test_represent_binary():
    dumper = yaml.SafeDumper
    dumper.add_representer(binary_type, represent_binary)

    b1 = binary_type('Hello world!')
    b2 = binary_type('Foo=')
    b3 = binary_type('Foo\\tbar')

    cases = [
        (b1, "'Hello world!'"),
        (b2, "!!binary 'Rm9vPQ=='"),
        (b3, "!!binary 'Rm9vCmJhcg=='"),
    ]

    for input_bytes, expected in cases:
        result = yaml.dump(input_bytes, Dumper=dumper)
        assert result == expected