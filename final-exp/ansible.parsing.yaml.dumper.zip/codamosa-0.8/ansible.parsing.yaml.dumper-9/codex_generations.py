

# Generated at 2022-06-22 13:51:10.530661
# Unit test for function represent_unicode
def test_represent_unicode():
    ''' unit tests for function represent_unicode '''
    from ansible.utils.unsafe_proxy import wrap_var

    data = wrap_var(u'foo')
    dumper = AnsibleDumper()
    ret = dumper.represent_data(data)
    assert ret == text_type('foo')

    data = wrap_var(u'foo\n')
    dumper = AnsibleDumper()
    ret = dumper.represent_data(data)
    assert ret == text_type(u'|-\n  foo\n')

    data = wrap_var(u'foo\nbar\nbaz')
    dumper = AnsibleDumper()
    ret = dumper.represent_data(data)

# Generated at 2022-06-22 13:51:13.303305
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import native_undefined_representer
    from ansible.template import StrictUndefined

    assert native_undefined_representer(StrictUndefined('foo'))

# Generated at 2022-06-22 13:51:16.229992
# Unit test for function represent_undefined
def test_represent_undefined():
    a = AnsibleUndefined('Test')
    dumper = AnsibleDumper()
    result = dumper.represent_undefined(a)
    assert(result)

# Generated at 2022-06-22 13:51:23.088547
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    data = AnsibleUndefined(var_name='foo', fail_on_undefined=False)
    # We test that the representer is called and that the _fail_with_undefined_error
    # function isn't.
    # This happens, if the representer returns a boolean that evaluates to False.
    assert dumper.represent_undefined(dumper, data) is False

# Generated at 2022-06-22 13:51:28.703045
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    vault_encrypted_unicode = AnsibleVaultEncryptedUnicode(u'$ANSIBLE_VAULT;1.1;AES256\n313233343536373839303132333435363738393061')
    yaml.dump(vault_encrypted_unicode, sys.stdout)


import sys

if __name__ == "__main__":
    test_represent_vault_encrypted_unicode()

# Generated at 2022-06-22 13:51:31.966469
# Unit test for function represent_undefined
def test_represent_undefined():

    from ansible.template import generate
    dumper = AnsibleDumper
    out = dumper.represent_data(generate.Undefined)

    assert bool is type(out)
    assert out is True

# Generated at 2022-06-22 13:51:39.126691
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('secret')
    yml = AnsibleVaultEncryptedUnicode(vault.encrypt('abc'))
    yml = represent_vault_encrypted_unicode(AnsibleDumper, yml)
    assert yml == u'!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          356635363933393034363363166343465663733623665623338633539373166656437373261393230\n          333330653832656466366332363638656466343064633431636661630a'

# Generated at 2022-06-22 13:51:42.089047
# Unit test for function represent_unicode
def test_represent_unicode():
    result = yaml.safe_dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper)
    assert result == 'foo\n...\n'



# Generated at 2022-06-22 13:51:49.636126
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = HostVars()
    hostvars.add_host('127.0.0.1', dict(a=1, b=2))
    hostvars.add_host('127.0.0.2', dict(a=3, b=4))

    expected = '''\
{a: 1, b: 2}
{a: 3, b: 4}
'''
    assert yaml.dump(hostvars, Dumper=AnsibleDumper, default_flow_style=False) == expected

# Generated at 2022-06-22 13:51:53.318538
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'hello\x00') == yaml.representer.SafeRepresenter().represent_binary(b'hello\x00')



# Generated at 2022-06-22 13:52:00.736514
# Unit test for function represent_unicode
def test_represent_unicode():
    # Create data for test
    test_data = {'key1': AnsibleUnicode('test_unicode')}

    # Verify results
    assert yaml.safe_dump(test_data, default_flow_style=False, Dumper=AnsibleDumper) == 'key1: test_unicode\n'



# Generated at 2022-06-22 13:52:08.398644
# Unit test for function represent_binary
def test_represent_binary():
    """ yaml.representer.SafeRepresenter.represent_binary will try to return
        a scalar even if binary is b'something' or u'something' which is not a
        scalar for yaml.

        represent_binary returns a sequence
    """
    dumper = AnsibleDumper()
    data = b'something'
    output = dumper.represent_binary(data)
    assert output == u'!!binary |\n  c29tZXRoaW5n\n'

# Generated at 2022-06-22 13:52:14.796671
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('abc')) == "abc\n...\n"
    assert yaml.dump(AnsibleUnicode('café')) == "café\n...\n"
    assert yaml.dump(AnsibleUnicode('Бо́гдан')) == "Бо́гдан\n...\n"



# Generated at 2022-06-22 13:52:19.440165
# Unit test for function represent_undefined
def test_represent_undefined():
    AnsibleDumper.add_representer(
        AnsibleUndefined,
        represent_undefined,
    )
    f = AnsibleDumper.represent_undefined

    assert isinstance(f(None), bool)

    try:
        f(AnsibleUndefined())
        raise AssertionError()
    except Exception:
        pass

# Generated at 2022-06-22 13:52:27.713984
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():

    class FakeDumper(object):

        def represent_scalar(self, tag, value, style):
            return 'represent_scalar(%r, %r, %r)' % (tag, value, style)

    fake_dumper = FakeDumper()
    assert represent_vault_encrypted_unicode(fake_dumper, AnsibleVaultEncryptedUnicode(b'hello')) == 'represent_scalar(u\'!vault\', u\'hello\', \'|\')'

# Generated at 2022-06-22 13:52:39.563793
# Unit test for function represent_binary
def test_represent_binary():
    fake_bin_data = 'fake_bin_data'
    base64_fake_bin_data = 'ZmFrZV9iaW5fZGF0YQ=='
    original_represent_binary = yaml.representer.SafeRepresenter.represent_binary

    try:
        # Monkeypatch yaml.representer.SafeRepresenter.represent_binary()
        yaml.representer.SafeRepresenter.represent_binary = lambda *a: (fake_bin_data, None)

        # Call test function
        res = represent_binary(None, None) # pylint: disable=not-callable

        assert res == binary_type(base64_fake_bin_data)
    finally:
        # Restore original yaml.representer.SafeRepresenter.represent_binary
        yaml.representer.SafeRepresenter.represent_

# Generated at 2022-06-22 13:52:51.260139
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 13:52:55.213592
# Unit test for function represent_unicode
def test_represent_unicode():
    # This test is just meant to check that unicode
    # can be dumped to yaml.
    # It is testing a yaml feature not an Ansible feature
    class Test:
        key = u'domain.com'
        value = text_type(u'192.168.1.1')

    class Wrapper:
        test = Test()

    wrapper = Wrapper()
    text = yaml.dum

# Generated at 2022-06-22 13:53:06.449126
# Unit test for function represent_hostvars
def test_represent_hostvars():
    safe_dict = dict(ansible_all_ipv4_addresses=['10.20.30.40', '100.110.120.130'],
                     ansible_architecture='x86_64',
                     ansible_default_ipv4=dict(address='10.20.30.40',
                                               alias='enp0s3',
                                               gateway='10.20.30.1',
                                               interface='enp0s3',
                                               macaddress='08:00:27:65:b7:c2',
                                               metric=100,
                                               mtu=1500,
                                               netmask='255.255.255.0',
                                               network='10.20.30.0',
                                               type='ether'))

# Generated at 2022-06-22 13:53:12.227988
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    if not yaml.__with_libyaml__:
        return

    dumper = AnsibleDumper
    encrypted_text = b'$ANSIBLE_VAULT;1.2;AES256;bar\n3630373735643337303964366666326235343363633861333238633735316634313166633863\n383464653836656263613765326366646361333562313061\n'
    representer = represent_vault_encrypted_unicode
    node = representer(dumper, encrypted_text)
    output = yaml.dump(node)

# Generated at 2022-06-22 13:53:16.919774
# Unit test for function represent_hostvars
def test_represent_hostvars():
    rep = AnsibleDumper.represent_hostvars({})
    assert rep == {'__omit_place_holder__': None}



# Generated at 2022-06-22 13:53:23.639751
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper

    # string
    assert dumper.represent_binary(dumper, 'a') == dumper.represent_str(dumper, 'a')

    # bytes
    assert dumper.represent_binary(dumper, b'a') == dumper.represent_bytes(dumper, b'a')

    # unicode
    assert dumper.represent_binary(dumper, u'a') == dumper.represent_str(dumper, u'a')

# Generated at 2022-06-22 13:53:26.834131
# Unit test for function represent_undefined
def test_represent_undefined():
    yaml_output = yaml.dump(AnsibleUndefined, Dumper=AnsibleDumper)
    assert yaml_output == 'null\n'

# Generated at 2022-06-22 13:53:37.309239
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-22 13:53:44.252789
# Unit test for function represent_hostvars
def test_represent_hostvars():
    class FakeDumper():
        def represent_dict(self, data):
            return 'foo'

    fixture = {u'ansible_eth0': {u'ipv4': {u'address': u'10.0.0.10', u'netmask': u'255.255.255.0', u'macaddress': u'fe:ed:fa:ce:be:ef'}}}
    expected = 'foo'

    assert represent_hostvars(FakeDumper(), fixture) == expected

# Generated at 2022-06-22 13:53:49.965515
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()
    encrypted_unicode = AnsibleVaultEncryptedUnicode(u'fööbär')
    assert '!vault |\n          QVBJTkFMWV9BVVRPX0FDQ0VTU19DSEFSMg==\n' == dumper.represent_vault_encrypted_unicode(encrypted_unicode)

# Generated at 2022-06-22 13:54:00.336515
# Unit test for function represent_binary
def test_represent_binary():
    # Normal binary data
    data_binary = '\x00\x01\x02\x03\x04\x05\x06\x07'
    dumper = yaml.SafeDumper()
    s = dumper.represent_binary(data_binary)
    assert s == u'!!binary |\n    AAECAwQFBgc=\n'

    # Unicode strings with special characters
    data_unicode = u"I am a 'unicode' string, a\n"
    s = dumper.represent_unicode(data_unicode)
    assert s == u"!!python/unicode 'I am a \\'unicode\\' string, a\\n'\n"

# Generated at 2022-06-22 13:54:03.116375
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = HostVars({'a': 'b'})
    assert yaml.safe_dump(hostvars, default_flow_style=False) == 'a: b\n'



# Generated at 2022-06-22 13:54:05.356219
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper) == 'undefined'



# Generated at 2022-06-22 13:54:08.238439
# Unit test for function represent_undefined
def test_represent_undefined():
    data = AnsibleUndefined("Testing undef")

    # In Python 2, this will cause an exception trying to access _obj
    assert AnsibleDumper.represent_undefined(AnsibleDumper(), data) is False

# Generated at 2022-06-22 13:54:19.921354
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 13:54:24.237784
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-22 13:54:25.161388
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert represent_hostvars

# Generated at 2022-06-22 13:54:27.845453
# Unit test for function represent_undefined
def test_represent_undefined():
    data = AnsibleUndefined
    assert AnsibleDumper.represent_undefined(AnsibleDumper, data) == False



# Generated at 2022-06-22 13:54:35.596041
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    yaml_dict = {'password': '$ANSIBLE_VAULT;0.1;AES256;dummy\naW5kZXgNCnBhc3N3b3JkCg==\n'}
    assert yaml.dump(yaml_dict, Dumper=AnsibleDumper) == "password: !vault |\n          $ANSIBLE_VAULT;0.1;AES256;dummy\n          aW5kZXgNCnBhc3N3b3JkCg==\n\n"

# Generated at 2022-06-22 13:54:38.635548
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(b'\xc3\xb6', Dumper=AnsibleDumper) == "!!binary |\n  w6k=\n"

# Generated at 2022-06-22 13:54:45.532769
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import generate_ansible_safe_yaml
    from ansible.template import AnsibleUndefined
    from io import StringIO
    input_data = {'containing': {'undefined': AnsibleUndefined}}
    fdata = StringIO()
    generate_ansible_safe_yaml(input_data, fdata, dumper=AnsibleDumper)
    result = fdata.getvalue()
    assert result == "containing: {undefined: 'VARIABLE IS NOT DEFINED!'}\n"

# Generated at 2022-06-22 13:54:49.126865
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_data(AnsibleUndefined('message')) is True



# Generated at 2022-06-22 13:54:57.060477
# Unit test for function represent_binary
def test_represent_binary():
    data = b'\x90\xF1\x90\xF2'

    # data = None
    assert b'null' == AnsibleDumper.represent_data(data)

    # data = bytes
    data = b'\x90\xF1\x90\xF2'
    assert b'!!binary |\n  Fk8VFk8V' == AnsibleDumper.represent_data(data)

    # data = bytearray
    data = bytearray(b'\x90\xF1\x90\xF2')
    assert b'!!binary |\n  Fk8VFk8V' == AnsibleDumper.represent_data(data)

    # data = str
    data = '\x90\xF1\x90\xF2'
   

# Generated at 2022-06-22 13:54:59.741017
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    result = dumper.represent_undefined(AnsibleUndefined())
    assert isinstance(result, bool)
    assert result is False

# Generated at 2022-06-22 13:55:06.184445
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper) == ''
    # Make sure that binary data is still encoded
    assert yaml.dump(b'\x00\x01', Dumper=AnsibleDumper) == '!!binary |\n  AAEC\n'

# Generated at 2022-06-22 13:55:15.895522
# Unit test for function represent_binary
def test_represent_binary():

    res = binary_type(b'\x00\x01\x02\x03\x04')
    ansible_dumper = AnsibleDumper
    # yaml.representer.SafeRepresenter.represent_binary will return
    # an object of type yaml.nodes.ScalarNode
    expected_result = ansible_dumper.represent_binary(ansible_dumper, res)
    sample_result = AnsibleUnsafeBytes(b'\x00\x01\x02\x03\x04')
    # yaml.representer.SafeRepresenter.represent_binary will return
    # an object of type yaml.nodes.ScalarNode
    assert isinstance(ansible_dumper.represent_binary(ansible_dumper, sample_result), expected_result.__class__)
    assert ans

# Generated at 2022-06-22 13:55:20.658839
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    class FakeStr(object):
        def __init__(self, value):
            self.value = value

        def __str__(self):
            return self.value

    assert dumper.represent_binary(dumper, FakeStr('foo')) == yaml.representer.SafeRepresenter.represent_str(dumper, 'foo')

# Generated at 2022-06-22 13:55:23.671594
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert(represent_hostvars(AnsibleDumper, HostVars()) == {})
    assert(represent_hostvars(AnsibleDumper, HostVarsVars()) == {})

# Generated at 2022-06-22 13:55:26.181337
# Unit test for function represent_undefined
def test_represent_undefined():
    yaml_data = yaml.dump(AnsibleUndefined())
    assert not yaml_data

# Generated at 2022-06-22 13:55:37.455448
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    ciphertext = AnsibleVaultEncryptedUnicode.from_string('mystring', ensure_newlines=True)
    output = yaml.dump([ciphertext], Dumper=AnsibleDumper)

# Generated at 2022-06-22 13:55:42.756393
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    data = {'a': 1, 'b': 2}
    assert dumper.represent_hostvars(HostVars(data)) == dumper.represent_dict(data)



# Generated at 2022-06-22 13:55:53.329185
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-22 13:55:59.509408
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\naW1wb3J0IHBhc3N3b3JkCnBhc3N3b3JkID0gImFudGlzYmxlIgphbG9iYWwgY2FnZXN0CmNhZ2VzdCA9ICJtYXRjaCIKCg==\n')

# Generated at 2022-06-22 13:56:02.549061
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == dumper.represent_undefined('')

# Generated at 2022-06-22 13:56:10.642640
# Unit test for function represent_undefined
def test_represent_undefined():
    yaml_string = yaml.dump(AnsibleUndefined("foo"))
    assert yaml_string == "!!python/object/new:ansible.template.Undefined foo\n"



# Generated at 2022-06-22 13:56:16.151281
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    from ansible.template.safe_eval import Undefined
    from jinja2.runtime import StrictUndefined
    for data in (Undefined(), StrictUndefined):
        result = dumper.represent_undefined(data)
        assert result is True

# Generated at 2022-06-22 13:56:26.898360
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Setup
    d = AnsibleDumper

    # Test with valid data
    data = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256;mykey12345678901234567890\n363033323430366230373939383038323033653431343233343533303566306431333138633738\n613566326235393731353036353338363339386463626563346133313130366534366630653261\n3138353339623466363164343963376138363363633735303835336637386466653764')
    value = d.represent_data(data)

# Generated at 2022-06-22 13:56:33.798939
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper().represent_undefined(None) == 'null'
    assert AnsibleDumper().represent_undefined('string') == 'string'
    assert AnsibleDumper().represent_undefined(1) == '1'
    assert AnsibleDumper().represent_undefined(1.2) == '1.2'
    assert AnsibleDumper().represent_undefined([1, 2, 3]) == '[1, 2, 3]'
    assert AnsibleDumper().represent_undefined({1: 2}) == '{1: 2}'
    assert AnsibleDumper().represent_undefined(True) == 'true'
    assert AnsibleDumper().represent_undefined(False) == 'false'
    assert AnsibleDumper().represent_undefined(AnsibleUndefined()) is None

# Generated at 2022-06-22 13:56:38.267605
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():

    foo = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\n33323331323334313$ANSIBLE_VAULT;1.1;AES256\n333233313233343136$ANSIBLE_VAULT;1.1;AES256\n33323331323334313')

    data = dict(foo=foo)
    output = yaml.dump(data, Dumper=AnsibleDumper, default_flow_style=False)


# Generated at 2022-06-22 13:56:44.152556
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-22 13:56:49.165149
# Unit test for function represent_undefined
def test_represent_undefined():
    undefined_var = AnsibleUndefined(var_name='undefined_var', obj=None, safe=True, include_debug_info=True)
    assert yaml.dump(undefined_var, Dumper=AnsibleDumper) == 'undefined_var'
    assert yaml.dump(undefined_var, Dumper=AnsibleDumper, default_flow_style=True) == 'undefined_var'

# Generated at 2022-06-22 13:56:59.598826
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = AnsibleVaultEncryptedUnicode('This is encrypted', b'\xff' * 16)
    # The original function in vault.py fails the test
    # represent_str(self, data.decode(), style='|')
    # self.represent_scalar(u'!vault', data.decode())
    # When you print the object, it gives
    # !vault |
    #          AES256:c/qE8Mk5M5Ff7X+CT3q3P8WutjKGJ+F6ZQ2oZV7AHrJhcjV7X9T+T0Ftjb
    #          CighoDn0+G1fJxHcfCWSTJGKjXyX9uyzcuu+nFa1jKGJ+

# Generated at 2022-06-22 13:57:09.129277
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible_collections.notstdlib.moveitallout.plugins.filter.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    text = u'hello world'
    ciphertext = VaultLib.encrypt(text, 'test', False)
    obj = AnsibleVaultEncryptedUnicode(text, ciphertext)
    yaml.safe_dump(obj, default_flow_style=False, Dumper=AnsibleDumper)


if __name__ == '__main__':
    test_represent_vault_encrypted_unicode()

# Generated at 2022-06-22 13:57:15.655864
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib

    vault = VaultLib('VaultPassword')
    data = vault.encrypt(u'test')
    encrypted_data = AnsibleVaultEncryptedUnicode(data)
    assert(represent_vault_encrypted_unicode(SafeDumper(), encrypted_data) == "!vault |\n  $ANSIBLE_VAULT;1.1;AES256\n  3264363366643335316632636665623939313265373339353338333239626461343466633461396337\n  3463663632313066393361633961323062333530653938313465626263646363336361353133343366\n  32363634303534\n")

# Generated at 2022-06-22 13:57:28.042286
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible_collections.ansible.community.tests.unit.compat import unittest
    from ansible.template import jinja2_native

    class TestClass(unittest.TestCase):
        def test_undefined(self):
            with self.assertRaises(jinja2_native.UndefinedError):
                represent_undefined(self, AnsibleUndefined('test_undefined'))

    tc = TestClass()
    tc.test_undefined()

# Generated at 2022-06-22 13:57:33.488939
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    assert dumper.represent_undefined(dumper, AnsibleUndefined) is True
    # Undefined is an instance of bool, so if it gets to this point,
    # it won't raise an exception.
    assert dumper.represent_undefined(dumper, bool) is False
    # For example, an empty list has no __bool__ attribute
    assert dumper.represent_undefined(dumper, []) is False

# Generated at 2022-06-22 13:57:37.564854
# Unit test for function represent_undefined
def test_represent_undefined():
    obj = AnsibleUndefined('test_represent_undefined')
    assert bool(obj) is True
    # This will cause _fail_with_undefined_error to happen and
    # will raise an error.
    assert obj == obj

# Generated at 2022-06-22 13:57:38.772103
# Unit test for function represent_undefined
def test_represent_undefined():
    assert(yaml.dump(AnsibleUndefined()) == '')

# Generated at 2022-06-22 13:57:41.688360
# Unit test for function represent_undefined
def test_represent_undefined():
    data = AnsibleUndefined()
    dumper = AnsibleDumper()
    dumper._represent_undefined(data)

# Generated at 2022-06-22 13:57:43.407184
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleUndefined is AnsibleDumper.represent_undefined(None, AnsibleUndefined())

# Generated at 2022-06-22 13:57:47.737268
# Unit test for function represent_undefined
def test_represent_undefined():
    '''Test represent_undefined with assertRaises'''
    # We know AnsibleUndefined.__bool__ needs to throw a
    # FailWithUndefinedError, or the test will fail
    try:
        bool(AnsibleUndefined(name='foo'))
    except AnsibleUndefined as e:
        # Warnings module wants an object that has a .name attribute. Try and
        # make this compatible
        assert e.name == 'foo'

# Generated at 2022-06-22 13:57:51.217524
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    str_undef = dumper.represent_data(AnsibleUndefined)
    assert isinstance(str_undef, str)
    assert str_undef == 'null'

# Generated at 2022-06-22 13:58:00.640059
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.parsing.yaml import load
    from ansible.module_utils.six import PY2
    from ansible.template import Undefined

    if PY2:
        undefined = Undefined('foo')
        assert yaml.dump(undefined) == 'foo'
        assert yaml.load(yaml.dump(undefined)) is undefined
    else:
        undefined = Undefined()

        # The following is based on the yaml.dump() implementation
        # in Python 2.7.13.
        #
        # The only interesting part is inside the call to
        # _fail_with_undefined_error, where we check that the Undefined
        # value is passed as the original_value argument.
        #
        # This confirms that represent_undefined is doing the right thing.

# Generated at 2022-06-22 13:58:05.909486
# Unit test for function represent_undefined
def test_represent_undefined():
    # Here we are testing for the behaviour of represent_undefined
    # when __bool__ on StrictUndefined is defined
    data = AnsibleUndefined()
    data.__bool__ = lambda: True
    result = represent_undefined(None, data)
    assert result is True
