

# Generated at 2022-06-22 13:51:07.588695
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('test'), Dumper=AnsibleDumper) == "test\n...\n"



# Generated at 2022-06-22 13:51:16.702840
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    v = AnsibleVaultEncryptedUnicode('foo')
    d = AnsibleDumper()
    assert d.represent_vault_encrypted_unicode(v) == "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          35373465353139653662313162383133363732333161653437666634343138313063386234633530\n          35343736303638393864636132333438663133343366386200\n", 'Vault string incorrect'

# Generated at 2022-06-22 13:51:18.482631
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert '<test>' == dumper.represent_binary(dumper, '<test>')

# Generated at 2022-06-22 13:51:29.334901
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    '''
    Test that the return value of represent_vault_encrypted_unicode is
    of the form !vault |
      <scalar>
    '''
    dumper = AnsibleDumper(default_flow_style=False)
    expected_first_line = '!vault |\n'
    expected_second_line = '  Scalar\n'
    # Construct a vault encrypted unicode
    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode('Scalar')
    # Call the dumper
    actual = dumper.represent_vault_encrypted_unicode(ansible_vault_encrypted_unicode)
    # Test that the return value is correct
    assert expected_first_line == actual[0]
    assert expected_second_line == actual[1]



# Generated at 2022-06-22 13:51:33.513335
# Unit test for function represent_unicode
def test_represent_unicode():
    test_data = {u'\N{EURO SIGN}': u'\N{DOLLAR SIGN}'}

    assert yaml.dump(test_data, Dumper=AnsibleDumper) == \
        u"{'\\u20ac': '$'}\n"



# Generated at 2022-06-22 13:51:43.627534
# Unit test for function represent_hostvars
def test_represent_hostvars():
    xdata = b'xdata'
    ydata = b'ydata'

    x1 = AnsibleUnsafeBytes(xdata)
    y1 = AnsibleUnsafeBytes(ydata)

    x1_expected_result = yaml.representer.SafeRepresenter.represent_binary(xdata)
    y1_expected_result = yaml.representer.SafeRepresenter.represent_binary(ydata)

    hv = HostVars({'x': x1, 'y': y1},
                  {'x': x1, 'y': y1},
                  {'x': x1, 'y': y1},
                  {'x': x1, 'y': y1})

    result = yaml.representer.SafeRepresenter.represent_dict(hv)

    y1_expected_result = yaml.represent

# Generated at 2022-06-22 13:51:55.023176
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 13:52:03.116957
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    d = AnsibleDumper()
    # A trivial case, ciphertext not encrypted by AnsibleVault
    ciphertext = b'hello'
    secret = AnsibleVaultEncryptedUnicode(ciphertext)
    # The result will be !vault |2-
    # hello
    # See http://yaml.org/type/binary.html
    result = d.represent_vault_encrypted_unicode(secret)
    assert result == "!vault |2-\n  hello\n"

# Generated at 2022-06-22 13:52:08.099208
# Unit test for function represent_unicode
def test_represent_unicode():
    y = AnsibleUnicode('abc')
    yaml_data = yaml.safe_dump(y, default_flow_style=False)
    assert yaml_data == "!!python/unicode 'abc'\n", 'Expected a unicode tag to be part of the yaml content'


# Generated at 2022-06-22 13:52:14.394943
# Unit test for function represent_binary
def test_represent_binary():

    dumper = AnsibleDumper(width=float('Inf'))

    # A byte string, base64-encoded data
    data = binary_type(b'abc123\n')
    value = dumper.represent_binary(data)
    expected = "!binary |-\n  YWJjMTIzCg==\n"
    assert value == expected


# Generated at 2022-06-22 13:52:28.237581
# Unit test for function represent_unicode
def test_represent_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Unicode is to be preserved by default
    if yaml.__with_libyaml__:
        assert yaml.dump(u'ünicøde', Dumper=AnsibleDumper) == u'ünicøde\n...\n'
    else:
        assert yaml.dump(u'ünicøde', Dumper=AnsibleDumper) == u'"ünicøde"\n'
    assert yaml.load(u'ünicøde', Loader=AnsibleLoader) == u'ünicøde'

    # Unicode is to be base64 encoded if unsafe_proxy is turned on

# Generated at 2022-06-22 13:52:31.100924
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'

# Generated at 2022-06-22 13:52:35.826178
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars

    h = HostVars(vars=dict(a=1))
    assert yaml.dump({'x': h}, Dumper=AnsibleDumper) == "x: {'a': 1}\n"



# Generated at 2022-06-22 13:52:42.176592
# Unit test for function represent_undefined
def test_represent_undefined():
    from .common.loader_fixture import LoaderModuleFixture

    dumper = AnsibleDumper
    dumpee = object
    ex = LoaderModuleFixture('dummy_module')
    dumper.add_multi_representer(ex, lambda dumper, dumpee: dumper.represent_scalar('!test', 'test'))

    assert yaml.dump(set(), Dumper=dumper) == '{}'

# Generated at 2022-06-22 13:52:43.940261
# Unit test for function represent_unicode
def test_represent_unicode():
    data = AnsibleUnicode('Hello World')
    # Because we can not just compare the two objects, use dump to
    # convert them to strings and compare directly.
    assert yaml.dump(data, Dumper=yaml.SafeDumper) == yaml.dump(data, Dumper=AnsibleDumper)

# Generated at 2022-06-22 13:52:56.829018
# Unit test for function represent_unicode
def test_represent_unicode():
    uu = u'\ufffd'
    us = u'\u1234'
    s = 'unicode'

    dumper = yaml.Dumper()
    def represent_unicode(self, data):
        return yaml.representer.SafeRepresenter.represent_unicode(self, text_type(data))

    dumper.add_representer(AnsibleUnicode, represent_unicode)

    # encode unicode to utf-8
    assert yaml.dump(uu, Dumper=dumper, encoding='utf-8', allow_unicode=True) == u'--- "\ufffd"\n...\n'
    assert yaml.dump(us, Dumper=dumper, encoding='utf-8', allow_unicode=True) == u'--- "\u1234"\n...\n'


# Generated at 2022-06-22 13:53:02.490116
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert represent_hostvars(AnsibleDumper, HostVars(temporary=None, _hostvars=None)) == represent_hostvars(AnsibleDumper, HostVarsVars(temporary=None, _hostvars=None)) == represent_hostvars(AnsibleDumper, VarsWithSources(temporary=None, _hostvars=None))



# Generated at 2022-06-22 13:53:10.870399
# Unit test for function represent_unicode
def test_represent_unicode():
    # Create mock object to test method
    class safe_representer:
        def represent_str(self, data):
            return yaml.representer.SafeRepresenter.represent_str(self, data)

    mock_safe_representer = safe_representer()

    class ansible_unicode:
        def __init__(self, value):
            self.value = value

        # Python 3
        def __str__(self):
            return text_type(self.value)

        # Python 2
        def __unicode__(self):
            return text_type(self.value)

    # Test Unicode
    mock_ansible_unicode = ansible_unicode('testing')
    # Python 2
    if hasattr(mock_ansible_unicode, '__unicode__'):
        u = mock_ansible_

# Generated at 2022-06-22 13:53:22.742776
# Unit test for function represent_undefined
def test_represent_undefined():
    ansible_dumper = AnsibleDumper()

    # Test bad type
    try:
        ansible_dumper.represent_data(object())
    except Exception as e:
        assert isinstance(e, yaml.representer.RepresenterError)
    else:
        # This path should not be reached
        assert False

    # Test undefined value
    ansible_dumper.chained_undefined = False
    representation = ansible_dumper.represent_scalar('tag:yaml.org,2002:str', None)
    assert representation == 'null'

    # Test undefined value with chain
    ansible_dumper.chained_undefined = True
    representation = ansible_dumper.represent_scalar('tag:yaml.org,2002:str', None)
    assert representation == 'null'

    #

# Generated at 2022-06-22 13:53:27.060589
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert represent_hostvars(AnsibleDumper, HostVars({'foo': 'bar'})) == yaml.representer.SafeRepresenter.represent_dict(None, {'foo': 'bar'})



# Generated at 2022-06-22 13:53:33.421999
# Unit test for function represent_binary
def test_represent_binary():
    obj = '\xbb\xaa'
    rep = yaml.representer.SafeRepresenter()
    output = AnsibleDumper.represent_binary(rep, obj)
    assert output == u'!!binary \xbb\xaa'

# Generated at 2022-06-22 13:53:45.415935
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.manager import VariableManager

    data = {
        'key1': 'value1',
        'key2': 'value2',
    }

    var_manager = VariableManager()
    var_manager.set_host_variable(host='localhost', varname='key1', value='value1')
    var_manager.set_host_variable(host='localhost', varname='key2', value='value2')

    hostvars = HostVars(var_manager)
    hostvars['localhost'] = lambda: data
    result = yaml.dump(hostvars, Dumper=AnsibleDumper, default_flow_style=False)


# Generated at 2022-06-22 13:53:48.217572
# Unit test for function represent_hostvars
def test_represent_hostvars():
    d = yaml.dump(dict(one=1, two=2), Dumper=AnsibleDumper)
    assert d == '{one: 1, two: 2}\n'



# Generated at 2022-06-22 13:54:00.384446
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-22 13:54:03.533828
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    result = dumper.represent_binary(b'foo')
    assert result == "!!binary \"Zm9v\""
    result = dumper.represent_binary(None)
    assert result is None

# Generated at 2022-06-22 13:54:07.711454
# Unit test for function represent_hostvars
def test_represent_hostvars():
    d = dict(a=1, b="string")
    var = HostVars(d)
    y = yaml.dump(var, Dumper=AnsibleDumper)
    assert y == '{a: 1, b: "string"}\n...\n'


# Generated at 2022-06-22 13:54:10.631339
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(bytearray([10, 20, 30]), Dumper=AnsibleDumper) == '!!python/object/apply:bytearray [10, 20, 30]\n'



# Generated at 2022-06-22 13:54:13.609323
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import AnsibleUndefined

    data = AnsibleUndefined

    dumper = AnsibleDumper
    assert dumper.represent_undefined(dumper, data) is True



# Generated at 2022-06-22 13:54:18.473930
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == "!!binary |\n    Zm9v\n"
    assert dumper.represent_binary(dumper, 'foo') == "!!binary |\n    Zm9v\n"
    assert dumper.represent_binary(dumper, u'foo') == "!!binary |\n    Zm9v\n"

# Generated at 2022-06-22 13:54:26.839740
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():

    # Sample data
    ciphertext = '$ANSIBLE_VAULT;1.1;AES256\n' \
                 '34386639346333366264393066353365343265373038353333313162376239356463623262626366\n' \
                 '30623236653263626531376533653962333335613961323163326130316663376139663164323337\n' \
                 '36326132333334346361396266626231666331653866376236\n'

    # Here we need to create a AnsibleVaultEncryptedUnicode object
    # as argument for represent_vault_encrypted_unicode()
    data = AnsibleVaultEncryptedUnicode(ciphertext)

    # Prepare an Ans

# Generated at 2022-06-22 13:54:32.870903
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = AnsibleVaultEncryptedUnicode("thevault", "thesecret", text_type("thetext"))
    dumper = AnsibleDumper()
    actual = dumper.represent_data(data)
    expected = '!vault |\n  c2hhZG93IGVuY3J5cHQgdmFsdCB0aGV0ZXh0\n'
    assert actual == expected

# Generated at 2022-06-22 13:54:38.218765
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    assert(yaml.load(yaml.dump(
        AnsibleVaultEncryptedUnicode('my_secret', 'encrypted'),
        Dumper=AnsibleDumper
    )) == AnsibleVaultEncryptedUnicode('my_secret', 'encrypted'))

# Generated at 2022-06-22 13:54:46.781156
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = yaml.SafeDumper

# Generated at 2022-06-22 13:54:54.464865
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.objects import AnsibleMapping
    assert yaml.dump(dict(a=1, b=2), Dumper=AnsibleDumper) == '{a: 1, b: 2}\n'
    assert yaml.dump(AnsibleMapping({'a': 1, 'b': 2}), Dumper=AnsibleDumper) == '{a: 1, b: 2}\n'
    assert yaml.dump(HostVars(dict(a=1, b=2)), Dumper=AnsibleDumper) == '{a: 1, b: 2}\n'

# Generated at 2022-06-22 13:55:00.422277
# Unit test for function represent_unicode
def test_represent_unicode():
    ''' represent_unicode should represent a unicode object
    '''

    # Create dumps object to use for testing
    dumper = AnsibleDumper

    # Create unicode object to test
    unicode_obj = text_type('Test Unicode Object')

    # Compare results
    assert dumper.represent_unicode(unicode_obj) == dumper.represent_str(unicode_obj)



# Generated at 2022-06-22 13:55:04.975785
# Unit test for function represent_unicode
def test_represent_unicode():
    obj = u'{ "foo": "bar" }'
    output = yaml.dump(obj, Dumper=AnsibleDumper)
    assert u'"{ \\"foo\\": \\"bar\\" }"\n' == output


# Generated at 2022-06-22 13:55:13.613934
# Unit test for function represent_binary
def test_represent_binary():
    encoded_text = b'\xc3\x85\xc3\x84\xc3\x96'
    encoded_text_as_unicode = u'\xc3\x85\xc3\x84\xc3\x96'
    assert b'AAAAA' == yaml.representer.SafeRepresenter.represent_binary(None, b'AAAAA')

# Generated at 2022-06-22 13:55:17.985139
# Unit test for function represent_binary
def test_represent_binary():
    import base64
    value = binary_type(base64.b64decode('YWJjZA=='))
    assert yaml.dump(value, Dumper=AnsibleDumper) == "!!binary |\n  YWJjZA==\n"

# Generated at 2022-06-22 13:55:26.361240
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-22 13:55:37.592169
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-22 13:55:43.219266
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert represent_unicode(dumper, AnsibleUnicode('test')) == u'test'

# Generated at 2022-06-22 13:55:45.590533
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(dict(data=b'foo'), Dumper=AnsibleDumper) == b'{data: !!binary "Zm9v"}\n'

# Generated at 2022-06-22 13:55:55.879353
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = yaml.dumper.Dumper()
    dumper.representer = AnsibleDumper()

# Generated at 2022-06-22 13:56:07.907228
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    obj = AnsibleVaultEncryptedUnicode("mysecret")
    result = represent_vault_encrypted_unicode(AnsibleDumper, obj)

    import sys
    assert sys.version_info >= (3,)

# Generated at 2022-06-22 13:56:11.423975
# Unit test for function represent_unicode
def test_represent_unicode():
    AnsibleDumper.add_representer(
        str,
        represent_unicode
    )

    test_str = 'test'
    assert yaml.dump(test_str, Dumper=AnsibleDumper) == u'test\n...\n'

# Generated at 2022-06-22 13:56:20.017345
# Unit test for function represent_hostvars
def test_represent_hostvars():

    hv = HostVars('/path')
    hv['foo'] = 'bar'
    hv._metadata['foo'] = 2
    hv['c'] = 'd'
    hv._metadata['c'] = 4

    s = AnsibleDumper.represent_hostvars(hv)
    assert isinstance(s, yaml.nodes.MappingNode)
    assert s.tag == u'tag:yaml.org,2002:map'
    assert len(s.value) == 2
    assert s.value[0][0].value == 'foo'
    assert s.value[0][1].value == 'bar'
    assert s.value[1][0].value == 'c'
    assert s.value[1][1].value == 'd'



# Generated at 2022-06-22 13:56:25.163414
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    sample_data = AnsibleUnicode('sample string')
    ansible_string = dumper.represent_unicode(dumper, sample_data)
    assert isinstance(ansible_string, text_type)
    assert repr(ansible_string) == repr('sample string')

# Generated at 2022-06-22 13:56:32.269085
# Unit test for function represent_undefined
def test_represent_undefined():
    class MyAnsibleDumper(SafeDumper):
        def represent_undefined(self, data):
            if hasattr(data, '_fail_with_undefined_error'):
                data._fail_with_undefined_error()
            return super(MyAnsibleDumper, self).represent_undefined(data)

        add_representer(AnsibleUndefined, represent_undefined)

    MyAnsibleDumper().represent_undefined(AnsibleUndefined())



# Generated at 2022-06-22 13:56:36.987797
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert AnsibleDumper(None).represent_hostvars(HostVars(HostVarsVars({
        'foo': 'bar',
        'baz': 'bang',
    }))) == '{foo: bar, baz: bang}'



# Generated at 2022-06-22 13:56:47.519061
# Unit test for function represent_binary
def test_represent_binary():
    import sys

    # First we create a dumper
    dumper = AnsibleDumper(None, None, None, None)

    # Encoding for output stream
    if sys.stdout.encoding:
        stream_encoding = sys.stdout.encoding
    else:
        # Fallback if sys.stdout.encoding is None
        stream_encoding = 'UTF-8'

    if hasattr(dumper, 'encoding'):
        # In PyYaml 5.1, SafeDumper.encoding was renamed to SafeDumper.stream_encoding
        dumper.encoding = stream_encoding

    # Test with binary unicode

# Generated at 2022-06-22 13:56:55.349853
# Unit test for function represent_binary
def test_represent_binary():

    dumper = AnsibleDumper

    if not yaml.__with_libyaml__:
        assert dumper.represent_binary(dumper, b'foo') == '!!binary |\n  Zm9v\n'
    else:
        assert dumper.represent_binary(dumper, b'foo') == '!!binary "Zm9v"\n'

# Generated at 2022-06-22 13:57:02.636924
# Unit test for function represent_unicode
def test_represent_unicode():
    # Set up some objects
    unicode_str = r'abcdefg'
    unicode_str_unicode = unicode(r'abc\u00E8\u00EF', 'utf-8')
    unicode_str_ansible_unicode = AnsibleUnicode(r'abc\u00E8\u00EF')
    yaml_object = AnsibleDumper()

    # Test with Unicode object
    yaml_object.represent_unicode(unicode_str_unicode)
    yaml_object.represent_unicode(unicode_str_ansible_unicode)

    # Test with str object
    yaml_object.represent_unicode(unicode_str)


# Generated at 2022-06-22 13:57:11.557595
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined())

ANSIBLE_YAML_ORIG_DUMP_KWARGS = dict(
    Dumper=AnsibleDumper,
    default_flow_style=False,
    allow_unicode=True,
)
ANSIBLE_YAML_ORIG_DUMP_KWARGS_ORI = dict(
    Dumper=yaml.SafeDumper,
    default_flow_style=False,
    allow_unicode=True,
)
ANSIBLE_YAML_ORIG_LOAD_KWARGS = {
    "Loader": yaml.SafeLoader,
}

# Generated at 2022-06-22 13:57:16.650507
# Unit test for function represent_binary
def test_represent_binary():
    assert AnsibleDumper.represent_binary(None, b'hello') == AnsibleDumper.represent_scalar(u'tag:yaml.org,2002:binary', u'aGVsbG8=\n')



# Generated at 2022-06-22 13:57:20.563709
# Unit test for function represent_undefined
def test_represent_undefined():
    repr_undefined = AnsibleDumper.yaml_representers[AnsibleUndefined]
    assert repr_undefined(None, AnsibleUndefined()) is False
    assert list(repr_undefined(None, bool(AnsibleUndefined())))[0][0] == 'Undefined'

# Generated at 2022-06-22 13:57:28.538621
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml import AnsibleLoader
    from ansible.utils.unsafe_proxy import wrap_var

    data = HostVars(
        host_name='foo',
        vars=VarsWithSources(
            hostvars=HostVarsVars(
                ansible_fqdn='foo.bar.example.org',
                ansible_hostname='foo',
            ),
            hostvars_from_file=HostVarsVars(
                ansible_fqdn='foo.bar.example.org',
            ),
        )
    )

    # Because `from_dict` isn't a member of HostVars, pyyaml will call __getattr__
    # and we need to make sure that works before pyyaml calls `represent_dict`
    assert data.from_dict == {}

# Generated at 2022-06-22 13:57:34.072328
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(AnsibleUnicode('foo')) == dumper.represent_str(text_type('foo'))
    assert dumper.represent_unicode(AnsibleUnsafeText('foo')) == dumper.represent_str(text_type('foo'))
    assert dumper.represent_unicode(AnsibleUnsafeBytes('foo')) == dumper.represent_binary(binary_type('foo'))

# Generated at 2022-06-22 13:57:43.678620
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Data
    va = AnsibleVaultEncryptedUnicode(vars={}, vault_id='test', vault_secret=[], vault_password_file='', _ciphertext='abc')
    # Create a yaml.representer.SafeRepresenter instance
    yrs = yaml.representer.SafeRepresenter()
    # Use this instance to represent vault encrypted text
    yrs.represent_scalar = lambda *a, **kw: 'represent_scalar_called'
    # Assert it was called when we feed it `va`
    assert represent_vault_encrypted_unicode(yrs, va) == 'represent_scalar_called'

# Generated at 2022-06-22 13:57:49.824781
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    assert yaml.dump(AnsibleVaultEncryptedUnicode(u'hello world'), Dumper=AnsibleDumper) == '!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          3133646637386438653365663030633662363965306634353862373263633164623361613236623535\n          3763386137653761323061336335396632343663396335623430376236363835646638646234666539\n          3564633265643235396636653266373865623463356134653231376133313562666564613037356438\n          38373230\n'

# Generated at 2022-06-22 13:57:59.662653
# Unit test for function represent_unicode
def test_represent_unicode():
    text = u"u'\u041b\u0435\u0432 \u041d\u0438\u043a\u043e\u043b\u0430\u0435\u0432\u0438\u0447 \u0422\u043e\u043b\u0441\u0442\u043e\u0439'"
    answer = u'u\'\\u041b\\u0435\\u0432 \\u041d\\u0438\\u043a\\u043e\\u043b\\u0430\\u0435\\u0432\\u0438\\u0447 \\u0422\\u043e\\u043b\\u0441\\u0442\\u043e\\u0439\''
    assert repr(yaml.load(text, Loader=yaml.SafeLoader))

# Generated at 2022-06-22 13:58:08.772156
# Unit test for function represent_binary
def test_represent_binary():
    bin_bytes = b'\x80\x01\x02\x03\x83\x01'
    test_bin = AnsibleUnsafeBytes(bin_bytes).to_text()
    assert test_bin == "'\\x80\\x01\\x02\\x03\\x83\\x01'"

# Generated at 2022-06-22 13:58:19.823167
# Unit test for function represent_binary
def test_represent_binary():

    '''
    Make sure that if a binary value is passed to represent_binary
    that the value is converted to base64.
    '''

    # Create a new dumper class with the represent_binary method
    # overridden so the method can be tested.
    class TestDumper(AnsibleDumper):
        def represent_binary(self, data):
            return yaml.representer.SafeRepresenter.represent_binary(self, data)

    # Get an instance of our dumper class
    yaml_dumper = TestDumper()

    # Create a binary value
    binary_value = b'This is a binary value'

    # Check the output from represent_binary
    assert yaml_dumper.represent_binary(binary_value)['binary'] == 'True'

    # Check the data from represent_binary
    assert yaml_

# Generated at 2022-06-22 13:58:21.238348
# Unit test for function represent_unicode
def test_represent_unicode():
    string = AnsibleUnicode("asdf")
    assert represent_unicode(None, string) == "asdf"



# Generated at 2022-06-22 13:58:32.088312
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml import objects
    from ansible.parsing.yaml.dumper import AnsibleDumper  # For unit test

    vault_password = 'myvaultpassword'
    vault = VaultLib(vault_password)
    ciphertext = vault.encrypt('hello')
    ciphertext = objects.AnsibleVaultEncryptedUnicode(ciphertext, vault_password=vault_password)

# Generated at 2022-06-22 13:58:43.039037
# Unit test for function represent_undefined
def test_represent_undefined():
    # This test needs to be run in a separate process because loading
    # yaml will result in creating the default Loader and Dumper classes
    # that will be cached in the global variables
    # _yaml_base_loader_class/_yaml_base_dumper_class inside the
    # yaml.loader/dumper modules.
    # The classes created by the following import would be lost if
    # the test is run in the same process as the other tests.
    import yaml.loader
    import yaml.dumper
    # Explicitly set the base Loader/Dumper classes to None to avoid
    # the caching of the above import
    yaml.loader._yaml_base_loader_class = None
    yaml.dumper._yaml_base_dumper_class = None

# Generated at 2022-06-22 13:58:46.958351
# Unit test for function represent_undefined
def test_represent_undefined():
    empty_stream = open(u'/dev/null', u'w')
    dumper = AnsibleDumper(stream=empty_stream)

    # Test for when value is AnsibleUndefined
    assert dumper.represent_undefined(AnsibleUndefined) is True

    # Test for when value is not AnsibleUndefined
    assert dumper.represent_undefined(u'bogus_value') == False


# Generated at 2022-06-22 13:58:58.440638
# Unit test for function represent_unicode
def test_represent_unicode():
    test_data = [
        "this is a test",
        u"this is a test",
        b"this is a test",
        AnsibleUnicode(u"this is a test"),
        AnsibleUnsafeText(u"this is a test"),
        AnsibleUnsafeBytes(b"this is a test"),
    ]

    expected_output = text_type("this is a test")

    dumper = AnsibleDumper(indent=0, width=80,
                           default_flow_style=False, allow_unicode=True)

    for entry in test_data:
        actual_output = dumper.represent_scalar('tag:yaml.org,2002:str', text_type(entry))

# Generated at 2022-06-22 13:59:04.312814
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('example'), Dumper=AnsibleDumper) == "example\n"

    # Make sure the unicode string isn't double-quoted
    s = 'witness the example'
    assert yaml.dump(
        AnsibleUnicode("example {}".format(s)), Dumper=AnsibleDumper
    ) == "example witness the example\n"

    # Corner case, empty unicode string
    assert yaml.dump(AnsibleUnicode(""), Dumper=AnsibleDumper) == "\n"



# Generated at 2022-06-22 13:59:09.251343
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'\x9f\x00\x00\x00') == '!!binary |\n  +AQAAAA==\n'
    assert dumper.represent_binary(dumper, b'\x00') == '!!binary |\n  AAA=\n'

# Generated at 2022-06-22 13:59:11.581057
# Unit test for function represent_undefined
def test_represent_undefined():
    data = AnsibleUndefined('test')
    dumper = AnsibleDumper()
    result = dumper.represent_undefined(data)
    assert result

# Generated at 2022-06-22 13:59:20.893475
# Unit test for function represent_hostvars
def test_represent_hostvars():
    ansibledumper = AnsibleDumper()
    hostvars = HostVars({u'ansible_foo': u'bar'})
    assert hostvars == {u'ansible_foo': u'bar'}, u"hostvars creation failed"
    reprhostvars = ansibledumper.represent_dict(hostvars)
    assert reprhostvars == u'{ansible_foo: bar}\n', u"represent_hostvars failed"


# Generated at 2022-06-22 13:59:27.126250
# Unit test for function represent_undefined
def test_represent_undefined():
    yaml_dump = yaml.dump({'foo': 1, 'bar': AnsibleUndefined()}, Dumper=AnsibleDumper)
    assert yaml_dump == "{foo: 1}\n...\n"



# Generated at 2022-06-22 13:59:29.751415
# Unit test for function represent_hostvars
def test_represent_hostvars():
    my_dump = yaml.dump({'a': 'b', 'c': 'd'}, Dumper=AnsibleDumper, default_flow_style=False)
    assert my_dump == "a: b\nc: d\n"

# Generated at 2022-06-22 13:59:32.068377
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode(u'foo'), Dumper=AnsibleDumper, default_flow_style=False) == "foo\n..."



# Generated at 2022-06-22 13:59:34.960875
# Unit test for function represent_unicode
def test_represent_unicode():
    data = AnsibleUnicode("Hello World")
    output = yaml.dump(data, Dumper=AnsibleDumper)
    assert output == text_type('Hello World\n')


# Generated at 2022-06-22 13:59:46.321538
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.module_utils.common.yaml import AnsibleDumper
    from io import StringIO
    output = StringIO()
    dumper = AnsibleDumper(output)
    data = {
        'a': 1,
        'b': 2,
        'c': HostVarsVars({'c1': [1], 'c2': 2}),
        'd': HostVars({'d1': {'d11': 1}}),
    }
    result = dumper.represent(data)

# Generated at 2022-06-22 13:59:48.286864
# Unit test for function represent_unicode
def test_represent_unicode():
    yaml.dump(['foo', u'bar', u'baz'], Dumper=AnsibleDumper)


# Generated at 2022-06-22 13:59:52.808108
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = AnsibleVaultEncryptedUnicode(u'hello')
    expected = b'!vault |\n          ' + data._ciphertext
    dumper = yaml.dumper.Dumper(width=60)
    assert dumper.represent_data(data) == expected



# Generated at 2022-06-22 13:59:54.838987
# Unit test for function represent_unicode
def test_represent_unicode():
    data = AnsibleUnicode('42')
    assert yaml.dump(data, Dumper=AnsibleDumper) == '42\n...\n'



# Generated at 2022-06-22 14:00:01.386388
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = dict(
        key1=dict(
            key2="value2",
            key3=dict(
                key4="value4",
                key5="value5"
            )
        )
    )

    dump_data = yaml.dump(data, Dumper=AnsibleDumper, default_flow_style=False)
    assert dump_data == '''\
key1:
  key2: value2
  key3:
    key4: value4
    key5: value5
'''

# Generated at 2022-06-22 14:00:13.842661
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    assert dumper.represent_unicode(dumper, AnsibleUnicode(u'foo')) == dumper.represent_unicode(dumper, text_type('foo'))
    assert dumper.represent_unicode(dumper, AnsibleUnicode(u'bar')) == dumper.represent_unicode(dumper, text_type('bar'))
    assert dumper.represent_unicode(dumper, AnsibleUnicode(u'baz')) == dumper.represent_unicode(dumper, text_type('baz'))



# Generated at 2022-06-22 14:00:24.068006
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.constants import DEFAULT_VAULT_ID_MATCH
    result = VaultLib(DEFAULT_VAULT_ID_MATCH).encrypt(u'myteststring')

# Generated at 2022-06-22 14:00:27.974921
# Unit test for function represent_undefined
def test_represent_undefined():
    yaml.representer.SafeRepresenter.add_representer(AnsibleUndefined, represent_undefined)
    yaml_dump = yaml.dump([AnsibleUndefined()], Dumper=AnsibleDumper)
    assert isinstance(yaml_dump, text_type)
    assert yaml.load(yaml_dump, Loader=yaml.SafeLoader) == [True]

# Generated at 2022-06-22 14:00:30.065624
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(repr, u'foo') == 'foo'
    assert represent_unicode(repr, AnsibleUnsafeText(u'bar')) == 'bar'
    assert represent_unicode(repr, text_type(u'baz')) == 'baz'

# Generated at 2022-06-22 14:00:31.556244
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b"foo\n") == u"!binary |\n  Zm9vCg==\n"



# Generated at 2022-06-22 14:00:37.865422
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # Dummy data
    dummy = {
        'a': 'b'
    }
    # Create a hostvars object
    hv = HostVars(dummy)
    # Check that representers from base class is used
    # YAML output
    yaml.dump(
        hv,
        Dumper=AnsibleDumper,
    )
    yaml.dump(
        HostVars({}),
        Dumper=AnsibleDumper,
    )



# Generated at 2022-06-22 14:00:42.392122
# Unit test for function represent_binary
def test_represent_binary():
    test_string = str(b'Hello World')
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, test_string) == b'!!binary |\n  SGVsbG8gV29ybGQ=\n'



# Generated at 2022-06-22 14:00:48.927142
# Unit test for function represent_unicode
def test_represent_unicode():
    # The root object is not a Unicode object
    test_obj = {
        'abc': 'def',
        'ghi': u'jkl'
    }

    test_str = yaml.safe_dump(test_obj, default_flow_style=False)
    assert test_str == u'abc: def\nghi: jkl\n'

    # The root object is a Unicode object
    test_obj = u'a: b'

    test_str = yaml.safe_dump(test_obj, default_flow_style=False, Dumper=AnsibleDumper)
    assert test_str == u'"a: b"\n'

# Generated at 2022-06-22 14:00:54.395107
# Unit test for function represent_binary
def test_represent_binary():
    test_data = b'\x00F\x00o\x00o'
    dumper = AnsibleDumper
    result = dumper.represent_binary(dumper, test_data)
    assert result == "!!binary 'AGYK'\n"

# Generated at 2022-06-22 14:01:02.954622
# Unit test for function represent_binary
def test_represent_binary():

    # Check if represent_binary correctly re-encode the unicode string
    data = b'\xc2\xa9' # unicode string
    expected_output = b'\xc2\xa9'
    output = yaml.representer.SafeRepresenter.represent_binary(SafeDumper, data)
    assert output == expected_output

    # Check if represent_binary correctly re-encode the base64 encoded unicode string 
    data = b'\xa3b\x89\x87\x97\x99\x9a\x9e' # base64 encoded unicode string
    expected_output = b'wq/kcO2lLg=='
    output = yaml.representer.SafeRepresenter.represent_binary(SafeDumper, data)
    assert output == expected_output

    # Check if represent_binary