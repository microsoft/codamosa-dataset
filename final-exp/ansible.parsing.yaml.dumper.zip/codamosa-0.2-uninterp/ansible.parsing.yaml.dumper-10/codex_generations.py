

# Generated at 2022-06-22 16:16:54.970983
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, AnsibleUnicode('foo')) == yaml.representer.SafeRepresenter.represent_str(None, 'foo')


# Generated at 2022-06-22 16:17:06.400390
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault.update({'vault_password_file': './test/ansible-vault-password'})
    vault_text = vault.encrypt('test')
    vault_text = vault_text.replace('\n', '')
    vault_text = vault_text.replace('\r', '')
    vault_text = vault_text.replace(' ', '')
    vault_text = vault_text.replace('\t', '')
    vault_text = vault_text.replace('\x0b', '')
    vault_text = vault_text.replace('\x0c', '')
    vault_text = vault_text.replace('\x0e', '')

# Generated at 2022-06-22 16:17:14.536386
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u'foo'
    assert dumper.represent_unicode(u'foo\nbar') == u'foo\nbar'
    assert dumper.represent_unicode(u'foo\tbar') == u'foo\tbar'
    assert dumper.represent_unicode(u'foo\u1234bar') == u'foo\u1234bar'
    assert dumper.represent_unicode(u'foo\u1234bar') == u'foo\u1234bar'
    assert dumper.represent_unicode(u'foo\u1234bar') == u'foo\u1234bar'

# Generated at 2022-06-22 16:17:17.616910
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    data = HostVars(dict(a=1, b=2))
    assert dumper.represent_hostvars(data) == dumper.represent_dict(dict(a=1, b=2))



# Generated at 2022-06-22 16:17:26.887632
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars

    hv = HostVars(host_vars={'a': 'b'})
    assert yaml.dump(hv, Dumper=AnsibleDumper) == '{a: b}\n...\n'

    hvv = HostVarsVars(host_vars={'a': 'b'})
    assert yaml.dump(hvv, Dumper=AnsibleDumper) == '{a: b}\n...\n'

    vws = VarsWithSources(host_vars={'a': 'b'})

# Generated at 2022-06-22 16:17:29.248923
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode(u'foo'), Dumper=AnsibleDumper) == u'foo\n...\n'



# Generated at 2022-06-22 16:17:31.691520
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert yaml.dump(HostVars({'a': 'b'}), Dumper=AnsibleDumper) == '{a: b}\n...\n'


# Generated at 2022-06-22 16:17:34.088275
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, AnsibleUnicode('foo')) == yaml.representer.SafeRepresenter.represent_str(None, 'foo')



# Generated at 2022-06-22 16:17:43.480458
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    vault = VaultLib([])

# Generated at 2022-06-22 16:17:52.159952
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

# Generated at 2022-06-22 16:18:06.127005
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vault = VaultLib([])
    secret = vault.encrypt(b'foo')
    data = AnsibleVaultEncryptedUnicode(secret)

# Generated at 2022-06-22 16:18:10.470201
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = HostVars(host_vars={'a': 1, 'b': 2})
    assert yaml.dump(hostvars, Dumper=AnsibleDumper) == '{a: 1, b: 2}\n'



# Generated at 2022-06-22 16:18:18.697867
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault_text = vault.encrypt('test')
    vault_text = vault_text.replace('\n', '')
    vault_text = vault_text.replace('\r', '')
    vault_text = vault_text.replace(' ', '')
    vault_text = vault_text.replace('\t', '')
    vault_text = vault_text.replace('\f', '')
    vault_text = vault_text.replace('\v', '')
    vault_text = vault_text.replace('\b', '')
    vault_text = vault_text.replace('\a', '')
    vault_text = vault_text.replace('\0', '')

# Generated at 2022-06-22 16:18:31.331514
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

# Generated at 2022-06-22 16:18:42.434145
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault.update({'password': 'secret'})
    encrypted_text = vault.encrypt('test')

# Generated at 2022-06-22 16:18:44.427241
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == u'!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:18:52.074071
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u'foo'
    assert dumper.represent_unicode(u'\u2713') == u'\u2713'
    assert dumper.represent_unicode(u'\u2713'.encode('utf-8')) == u'\u2713'
    assert dumper.represent_unicode(u'\u2713'.encode('utf-16')) == u'\u2713'
    assert dumper.represent_unicode(u'\u2713'.encode('utf-32')) == u'\u2713'
    assert dumper.represent_unicode(u'\u2713'.encode('latin-1')) == u'\u2713'
    assert dumper.represent

# Generated at 2022-06-22 16:19:00.534783
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault.update({'foo': 'bar'})
    ciphertext = vault.dump()
    encrypted_unicode = AnsibleVaultEncryptedUnicode(ciphertext)

# Generated at 2022-06-22 16:19:07.285384
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:19:09.346632
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_data(AnsibleUndefined()) is False

# Generated at 2022-06-22 16:19:17.071350
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars

    hv = HostVars({"a": "b"})
    assert yaml.dump(hv, Dumper=AnsibleDumper) == "a: b\n"

    hvv = HostVarsVars({"a": "b"})
    assert yaml.dump(hvv, Dumper=AnsibleDumper) == "a: b\n"

    vws = VarsWithSources({"a": "b"})
    assert yaml.dump(vws, Dumper=AnsibleDumper) == "a: b\n"



# Generated at 2022-06-22 16:19:26.936462
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u'foo'
    assert dumper.represent_unicode(u'foo\nbar') == u'foo\nbar'
    assert dumper.represent_unicode(u'foo\nbar\nbaz') == u'foo\nbar\nbaz'
    assert dumper.represent_unicode(u'foo\nbar\nbaz\n') == u'foo\nbar\nbaz\n'
    assert dumper.represent_unicode(u'foo\nbar\nbaz\n\n') == u'foo\nbar\nbaz\n\n'

# Generated at 2022-06-22 16:19:31.904667
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    assert represent_vault_encrypted_unicode(None, AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\nblahblahblah\n')) == '!vault |\n  $ANSIBLE_VAULT;1.1;AES256\n  blahblahblah\n'

# Generated at 2022-06-22 16:19:34.117499
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x01\x02\x03') == u'!!binary |\n  AQID\n'

# Generated at 2022-06-22 16:19:36.409486
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode(u'foo'), Dumper=AnsibleDumper) == u'foo\n...\n'



# Generated at 2022-06-22 16:19:41.665428
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode(u'foo'), Dumper=AnsibleDumper) == u'foo\n...\n'



# Generated at 2022-06-22 16:19:48.508446
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v\n'
    assert dumper.represent_binary(dumper, b'foo\n') == u'!!binary |\n  Zm9vCg==\n'
    assert dumper.represent_binary(dumper, b'foo\nbar\n') == u'!!binary |\n  Zm9vCmJhcgo=\n'
    assert dumper.represent_binary(dumper, b'foo\nbar\nbaz\n') == u'!!binary |\n  Zm9vCmJhcgpiYXoK\n'

# Generated at 2022-06-22 16:19:59.472973
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsManager
    from ansible.vars.sources import DataSource
    from ansible.vars.sources import DataSourceVariable
    from ansible.vars.sources import DataSourceFact
    from ansible.vars.sources import DataSourceCache
    from ansible.vars.sources import DataSourceCachePlugin

    # Create a HostVars object

# Generated at 2022-06-22 16:20:01.072623
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper) == ''

# Generated at 2022-06-22 16:20:03.206434
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02') == u'!!binary |\n  AAEC\n'

# Generated at 2022-06-22 16:20:16.989917
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault_text = vault.encrypt('test')
    vault_text = vault_text.replace('\n', '')
    vault_text = vault_text.replace('\r', '')
    vault_text = vault_text.replace('\t', '')
    vault_text = vault_text.replace(' ', '')
    vault_text = vault_text.replace('\x00', '')
    vault_text = vault_text.replace('\x01', '')
    vault_text = vault_text.replace('\x02', '')
    vault_text = vault_text.replace('\x03', '')
    vault_text = vault_text.replace('\x04', '')
    vault_text = vault_

# Generated at 2022-06-22 16:20:19.024529
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-22 16:20:29.295443
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:20:39.222972
# Unit test for function represent_binary
def test_represent_binary():
    assert AnsibleDumper.represent_binary(b'\x00\x01\x02\x03') == '!!binary |\n  AAECAw==\n'
    assert AnsibleDumper.represent_binary(b'\x00\x01\x02\x03', style='>') == '!!binary >\n  AAECAw==\n'
    assert AnsibleDumper.represent_binary(b'\x00\x01\x02\x03', style='|') == '!!binary |\n  AAECAw==\n'
    assert AnsibleDumper.represent_binary(b'\x00\x01\x02\x03', style='"') == '!!binary "AAECAw=="\n'

# Generated at 2022-06-22 16:20:43.261047
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == "foo\n...\n"



# Generated at 2022-06-22 16:20:46.951710
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode(u'foo'), Dumper=AnsibleDumper) == u'foo\n...\n'



# Generated at 2022-06-22 16:20:50.054808
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-22 16:20:53.375518
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    hostvars = HostVars({"foo": "bar"})
    assert dumper.represent_hostvars(hostvars) == dumper.represent_dict({"foo": "bar"})


# Generated at 2022-06-22 16:21:03.174354
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:21:05.537362
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined) == True


# Generated at 2022-06-22 16:21:17.321001
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.template import AnsibleUndefined

    hostvars = HostVars(dict(a=1, b=2, c=3))
    hostvars_vars = HostVarsVars(hostvars)
    vars_with_sources = VarsWithSources(dict(a=1, b=2, c=3))
    unsafe_text = AnsibleUnsafeText(u'unsafe_text')
    unsafe_bytes = AnsibleUnsafe

# Generated at 2022-06-22 16:21:30.063449
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u'foo'
    assert dumper.represent_unicode(u'foo\nbar') == u'foo\nbar'
    assert dumper.represent_unicode(u'foo\u1234') == u'foo\u1234'
    assert dumper.represent_unicode(u'foo\u1234\nbar') == u'foo\u1234\nbar'
    assert dumper.represent_unicode(u'foo\u1234\nbar\u4321') == u'foo\u1234\nbar\u4321'

# Generated at 2022-06-22 16:21:39.523589
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'
    assert yaml.dump(AnsibleUnicode('foo\nbar'), Dumper=AnsibleDumper) == 'foo\nbar\n...\n'
    assert yaml.dump(AnsibleUnicode('foo\nbar\n'), Dumper=AnsibleDumper) == 'foo\nbar\n\n...\n'
    assert yaml.dump(AnsibleUnicode('foo\nbar\n\n'), Dumper=AnsibleDumper) == 'foo\nbar\n\n\n...\n'

# Generated at 2022-06-22 16:21:44.280783
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode(u'foo'), Dumper=AnsibleDumper) == u'foo\n...\n'



# Generated at 2022-06-22 16:21:46.185960
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == False

# Generated at 2022-06-22 16:21:50.895575
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined(fail_on_undefined=False)) == False
    assert dumper.represent_undefined(AnsibleUndefined(fail_on_undefined=True)) == True

# Generated at 2022-06-22 16:21:54.118893
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = HostVars(dict(a=1, b=2))
    assert yaml.dump(data, Dumper=AnsibleDumper) == '{a: 1, b: 2}\n...\n'



# Generated at 2022-06-22 16:21:56.362482
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-22 16:21:58.660018
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02') == u'!!binary |\n  AAEC\n'



# Generated at 2022-06-22 16:22:01.905359
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    assert dumper.represent_undefined(dumper, AnsibleUndefined()) == True
    assert dumper.represent_undefined(dumper, 'foo') == False

# Generated at 2022-06-22 16:22:14.092964
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) is False

# Generated at 2022-06-22 16:22:23.064685
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, u'foo') == u'foo'
    assert represent_unicode(None, u'foo\nbar') == u'foo\nbar'
    assert represent_unicode(None, u'foo\nbar\nbaz') == u'foo\nbar\nbaz'
    assert represent_unicode(None, u'foo\nbar\nbaz\n') == u'foo\nbar\nbaz\n'
    assert represent_unicode(None, u'foo\nbar\nbaz\n\n') == u'foo\nbar\nbaz\n\n'
    assert represent_unicode(None, u'foo\nbar\nbaz\n\n\n') == u'foo\nbar\nbaz\n\n\n'

# Generated at 2022-06-22 16:22:35.139040
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:22:42.739813
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars

    hostvars = HostVars(dict(a=1, b=2))
    hostvarsvars = HostVarsVars(dict(a=1, b=2))
    varswithsources = VarsWithSources(dict(a=1, b=2))

    assert yaml.dump(hostvars, Dumper=AnsibleDumper) == '{a: 1, b: 2}\n...\n'
    assert yaml.dump(hostvarsvars, Dumper=AnsibleDumper) == '{a: 1, b: 2}\n...\n'

# Generated at 2022-06-22 16:22:53.405913
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:23:03.547173
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02') == "!!binary |\n  AAEC\n"

# Generated at 2022-06-22 16:23:11.173881
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.hostvars import HostVars, HostVarsVars
    from ansible.vars.manager import VarsWithSources

    # Test HostVars
    hostvars = HostVars(hostname='testhost')
    hostvars.add_host_vars(dict(a=1, b=2))
    hostvars.add_host_vars(dict(c=3, d=4))
    hostvars.add_host_vars(dict(e=5, f=6))
    hostvars.add_host_vars(dict(g=7, h=8))
    hostvars.add_host_vars(dict(i=9, j=10))

# Generated at 2022-06-22 16:23:20.985664
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault.update({'vault_password_file': 'test/ansible/test_vault.txt'})
    data = vault.encrypt('test')

# Generated at 2022-06-22 16:23:24.363088
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # Create a HostVars object
    hostvars = HostVars(host_vars_dict={'a': 1, 'b': 2})

    # Create a yaml object
    yaml_object = yaml.dump(hostvars, Dumper=AnsibleDumper)

    # Check that the yaml object is correct
    assert yaml_object == '{a: 1, b: 2}\n'



# Generated at 2022-06-22 16:23:25.713304
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined) == False

# Generated at 2022-06-22 16:23:54.965756
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

# Generated at 2022-06-22 16:24:04.118500
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault_text = vault.encrypt('test')
    vault_encrypted_unicode = AnsibleVaultEncryptedUnicode(vault_text)

# Generated at 2022-06-22 16:24:05.785337
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) is True

# Generated at 2022-06-22 16:24:07.673560
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw==\n'

# Generated at 2022-06-22 16:24:19.215902
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars

    # Create a HostVars object
    hv = HostVars(VariableManager())
    hv['foo'] = 'bar'
    hv['baz'] = 'qux'

    # Create a HostVarsVars object
    hvv = HostVarsVars(VariableManager())
    hvv['foo'] = 'bar'
    hvv['baz'] = 'qux'

    # Create a AnsibleMapping object
    am = AnsibleMapping()
    am['foo'] = 'bar'

# Generated at 2022-06-22 16:24:21.192913
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == True

# Generated at 2022-06-22 16:24:28.559936
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u'foo'
    assert dumper.represent_unicode(u'foo\nbar') == u'foo\nbar'
    assert dumper.represent_unicode(u'foo\tbar') == u'foo\tbar'
    assert dumper.represent_unicode(u'foo\rbar') == u'foo\rbar'
    assert dumper.represent_unicode(u'foo\u2026bar') == u'foo\u2026bar'
    assert dumper.represent_unicode(u'foo\u0000bar') == u'foo\u0000bar'
    assert dumper.represent_unicode(u'foo\u0001bar') == u'foo\u0001bar'

# Generated at 2022-06-22 16:24:42.718495
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v\n'
    assert dumper.represent_binary(dumper, b'foo\nbar') == u'!!binary |\n  Zm9vCmJhcg==\n'
    assert dumper.represent_binary(dumper, b'foo\nbar\nbaz') == u'!!binary |\n  Zm9vCmJhcgpiYXo=\n'
    assert dumper.represent_binary(dumper, b'foo\nbar\nbaz\n') == u'!!binary |\n  Zm9vCmJhcgpiYXoK\n'

# Generated at 2022-06-22 16:24:51.589666
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-22 16:24:55.966052
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_vault_encrypted_unicode(AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\n')) == '!vault |\n  $ANSIBLE_VAULT;1.1;AES256\n'

# Generated at 2022-06-22 16:25:47.720679
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources

    hv = HostVars()
    hv['a'] = 1
    hv['b'] = 2
    hv['c'] = 3
    hv['d'] = 4
    hv['e'] = 5
    hv['f'] = 6
    hv['g'] = 7
    hv['h'] = 8
    hv['i'] = 9
    hv['j'] = 10
    hv['k'] = 11
    hv['l'] = 12
    hv['m'] = 13
    hv['n'] = 14
    hv['o'] = 15

# Generated at 2022-06-22 16:25:51.660779
# Unit test for function represent_hostvars
def test_represent_hostvars():
    d = AnsibleDumper()
    hv = HostVars(dict(a=1, b=2))
    assert d.represent_hostvars(hv) == d.represent_dict(dict(a=1, b=2))



# Generated at 2022-06-22 16:25:56.442594
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    hostvars = HostVars(dict(a=1, b=2))
    assert dumper.represent_hostvars(hostvars) == dumper.represent_dict(dict(a=1, b=2))



# Generated at 2022-06-22 16:26:02.626977
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault.update({'password': 'secret'})
    ciphertext = vault.encrypt('mysecret')
    # Note: the ciphertext is a bytes object
    assert isinstance(ciphertext, bytes)
    # Note: the ciphertext is base64 encoded

# Generated at 2022-06-22 16:26:04.513240
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) is False

# Generated at 2022-06-22 16:26:16.542256
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault_text = vault.encrypt('test')
    encrypted_text = AnsibleVaultEncryptedUnicode(vault_text)

# Generated at 2022-06-22 16:26:22.306373
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v\n'
    assert dumper.represent_binary(dumper, b'foo\nbar') == u'!!binary |\n  Zm9vCmJhcg==\n'
    assert dumper.represent_binary(dumper, b'foo\nbar\nbaz') == u'!!binary |\n  Zm9vCmJhcgpiYXo=\n'
    assert dumper.represent_binary(dumper, b'foo\nbar\nbaz\n') == u'!!binary |\n  Zm9vCmJhcgpiYXoK\n'

# Generated at 2022-06-22 16:26:32.240121
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsManager
    from ansible.vars.sources import DataSource

    hv = HostVars(VarsManager())
    hv.add_host_vars_from_datasource(DataSource('test', {}))
    hv.add_host_vars_from_datasource(DataSource('test', {'a': 1}))
    hv.add_host_vars_from_datasource(DataSource('test', {'b': 2}))
    hv.add_host_vars_from_datasource(DataSource('test', {'c': 3}))


# Generated at 2022-06-22 16:26:44.399199
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v\n'
    assert dumper.represent_binary(dumper, b'foo\n') == u'!!binary |\n  Zm9vCg==\n'
    assert dumper.represent_binary(dumper, b'foo\nbar') == u'!!binary |\n  Zm9vCmJhcg==\n'
    assert dumper.represent_binary(dumper, b'foo\nbar\n') == u'!!binary |\n  Zm9vCmJhcgo=\n'

# Generated at 2022-06-22 16:26:56.179353
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()