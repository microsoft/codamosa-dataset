

# Generated at 2022-06-22 16:17:01.936082
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u'foo'
    assert dumper.represent_unicode(u'foo\nbar') == u'foo\nbar'
    assert dumper.represent_unicode(u'foo\tbar') == u'foo\tbar'
    assert dumper.represent_unicode(u'foo\u1234bar') == u'foo\u1234bar'
    assert dumper.represent_unicode(u'foo\u1234bar') == u'foo\u1234bar'
    assert dumper.represent_unicode(u'foo\u1234bar') == u'foo\u1234bar'

# Generated at 2022-06-22 16:17:03.721383
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == True

# Generated at 2022-06-22 16:17:13.081439
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u'foo'
    assert dumper.represent_unicode(u'foo\nbar') == u'foo\nbar'
    assert dumper.represent_unicode(u'foo\tbar') == u'foo\tbar'
    assert dumper.represent_unicode(u'foo\u1234') == u'foo\u1234'
    assert dumper.represent_unicode(u'foo\u1234\nbar') == u'foo\u1234\nbar'
    assert dumper.represent_unicode(u'foo\u1234\tbar') == u'foo\u1234\tbar'

# Generated at 2022-06-22 16:17:24.770849
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(AnsibleDumper, u'foo') == u'foo'
    assert represent_unicode(AnsibleDumper, u'foo\nbar') == u'foo\nbar'
    assert represent_unicode(AnsibleDumper, u'foo\tbar') == u'foo\tbar'
    assert represent_unicode(AnsibleDumper, u'foo\u1234bar') == u'foo\u1234bar'
    assert represent_unicode(AnsibleDumper, u'foo\u1234bar') == u'foo\u1234bar'
    assert represent_unicode(AnsibleDumper, u'foo\u1234bar') == u'foo\u1234bar'

# Generated at 2022-06-22 16:17:30.756687
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode(u'foo'), Dumper=AnsibleDumper) == u'foo\n...\n'
    assert yaml.dump(AnsibleUnicode(u'foo\nbar'), Dumper=AnsibleDumper) == u'|\n  foo\n  bar\n'
    assert yaml.dump(AnsibleUnicode(u'foo\nbar\nbaz'), Dumper=AnsibleDumper) == u'|\n  foo\n  bar\n  baz\n'
    assert yaml.dump(AnsibleUnicode(u'foo\nbar\nbaz\n'), Dumper=AnsibleDumper) == u'|\n  foo\n  bar\n  baz\n'

# Generated at 2022-06-22 16:17:34.215930
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined(fail_on_undefined=False)) is False
    assert dumper.represent_undefined(AnsibleUndefined(fail_on_undefined=True)) is True

# Generated at 2022-06-22 16:17:43.572882
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault.update({'password': 'secret'})
    plaintext = 'hello world'
    ciphertext = vault.encrypt(plaintext)
    ciphertext = ciphertext.encode('utf-8')
    ciphertext = AnsibleVaultEncryptedUnicode(ciphertext)

# Generated at 2022-06-22 16:17:46.222203
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == dumper.represent_str(dumper, 'foo')

# Generated at 2022-06-22 16:17:47.661259
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) is False

# Generated at 2022-06-22 16:17:50.340269
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw=='

# Generated at 2022-06-22 16:18:04.243396
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars

    # Create a HostVars object
    hv = HostVars()
    hv['foo'] = 'bar'
    hv['baz'] = 'qux'

    # Create a HostVarsVars object
    hvv = HostVarsVars()
    hvv['foo'] = 'bar'
    hvv['baz'] = 'qux'

    # Create a VariableManager object
    vm = VariableManager()
    vm.set_host_variable('foo', 'bar')

# Generated at 2022-06-22 16:18:14.716044
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes

    hv = HostVars()
    hv.add_host('host1', dict(a=1, b=2))
    hv.add_host('host2', dict(a=3, b=4))

    vws = VarsWithSources()
    vws.add_host('host1', dict(a=1, b=2))
    vws.add_host('host2', dict(a=3, b=4))

    hvv = HostVarsVars()

# Generated at 2022-06-22 16:18:24.857505
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault_text = vault.encrypt('test')
    encrypted_text = AnsibleVaultEncryptedUnicode(vault_text)

# Generated at 2022-06-22 16:18:29.471773
# Unit test for function represent_unicode
def test_represent_unicode():
    # Test that unicode strings are dumped as strings
    # and not as !!python/unicode
    data = u'\u2713'
    dumped = yaml.dump(data, Dumper=AnsibleDumper)
    assert dumped == u'\u2713\n...\n'



# Generated at 2022-06-22 16:18:34.901680
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_data(AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\n')) == '!vault |\n  $ANSIBLE_VAULT;1.1;AES256\n'


# Generated at 2022-06-22 16:18:44.237940
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper

# Generated at 2022-06-22 16:18:50.786757
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.vars.hostvars import HostVars

    hv = HostVars(dict(a=1, b=2))
    yaml_str = yaml.dump(hv, Dumper=AnsibleDumper)
    assert yaml_str == '{a: 1, b: 2}\n'

    hv2 = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert hv2 == hv

# Generated at 2022-06-22 16:18:54.093141
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == u'!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:19:03.747031
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault.update({'password': 'secret'})
    ciphertext = vault.encrypt('test')
    encrypted_unicode = AnsibleVaultEncryptedUnicode(ciphertext)

# Generated at 2022-06-22 16:19:14.156555
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources

    h = HostVars()
    h.add_host_vars(host='host1', vars=dict(a=1, b=2))
    h.add_host_vars(host='host2', vars=dict(a=3, b=4))

    v = VarsWithSources()
    v.add_source('host1', dict(a=1, b=2))
    v.add_source('host2', dict(a=3, b=4))

    assert yaml.dump(h, Dumper=AnsibleDumper) == yaml.dump(v, Dumper=AnsibleDumper)



# Generated at 2022-06-22 16:19:26.397766
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, u'foo') == u'foo'
    assert represent_unicode(None, u'foo\nbar') == u'foo\nbar'
    assert represent_unicode(None, u'foo\tbar') == u'foo\tbar'
    assert represent_unicode(None, u'foo\rbar') == u'foo\rbar'
    assert represent_unicode(None, u'foo\x00bar') == u'foo\x00bar'
    assert represent_unicode(None, u'foo\u1234bar') == u'foo\u1234bar'
    assert represent_unicode(None, u'foo\U00012345bar') == u'foo\U00012345bar'

# Generated at 2022-06-22 16:19:29.562714
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-22 16:19:32.317275
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw=='

# Generated at 2022-06-22 16:19:35.288248
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw==\n'

# Generated at 2022-06-22 16:19:46.680659
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, AnsibleUnicode(u'foo')) == u'foo'
    assert represent_unicode(None, AnsibleUnicode(u'foo\nbar')) == u'foo\nbar'
    assert represent_unicode(None, AnsibleUnicode(u'foo\tbar')) == u'foo\tbar'
    assert represent_unicode(None, AnsibleUnicode(u'foo\rbar')) == u'foo\rbar'
    assert represent_unicode(None, AnsibleUnicode(u'foo\x00bar')) == u'foo\x00bar'
    assert represent_unicode(None, AnsibleUnicode(u'foo\u1234bar')) == u'foo\u1234bar'

# Generated at 2022-06-22 16:19:55.507625
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

# Generated at 2022-06-22 16:20:01.869094
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_data(AnsibleUndefined()) is False


# Generated at 2022-06-22 16:20:05.112549
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = {'a': 1, 'b': 2}
    hostvars = HostVars(data)
    assert represent_hostvars(None, hostvars) == represent_hostvars(None, data)



# Generated at 2022-06-22 16:20:17.032623
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode(u'foo'), Dumper=AnsibleDumper) == u'foo\n...\n'
    assert yaml.dump(AnsibleUnicode(u'foo\nbar'), Dumper=AnsibleDumper) == u'|-\n  foo\n  bar\n'
    assert yaml.dump(AnsibleUnicode(u'foo\nbar\nbaz'), Dumper=AnsibleDumper) == u'|2-\n  foo\n  bar\n  baz\n'
    assert yaml.dump(AnsibleUnicode(u'foo\nbar\nbaz\n'), Dumper=AnsibleDumper) == u'|2-\n  foo\n  bar\n  baz\n'


# Generated at 2022-06-22 16:20:25.687420
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, u'foo') == u"'foo'"
    assert represent_unicode(None, u'foo\nbar') == u"'foo\\nbar'"
    assert represent_unicode(None, u'foo\tbar') == u"'foo\\tbar'"
    assert represent_unicode(None, u'foo\u00a9') == u"'foo\\xa9'"
    assert represent_unicode(None, u'foo\u20ac') == u"'foo\\u20ac'"
    assert represent_unicode(None, u'foo\U0001d10b') == u"'foo\\U0001d10b'"
    assert represent_unicode(None, u'foo\U0001d10b\u20ac') == u"'foo\\U0001d10b\\u20ac'"
    assert represent_unicode

# Generated at 2022-06-22 16:20:38.297592
# Unit test for function represent_binary

# Generated at 2022-06-22 16:20:48.011219
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault_text = vault.encrypt('test')
    vault_text = vault_text.decode()
    vault_text = AnsibleVaultEncryptedUnicode(vault_text)
    assert vault_text._ciphertext == b'test'
    assert vault_text._ciphertext.decode() == 'test'

# Generated at 2022-06-22 16:20:49.343924
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02') == u'!!binary |\n  AAEC\n'

# Generated at 2022-06-22 16:20:58.908769
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(password='password')
    encrypted_data = vault.encrypt('test')
    encrypted_unicode = AnsibleVaultEncryptedUnicode(encrypted_data)

# Generated at 2022-06-22 16:21:00.592457
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == False

# Generated at 2022-06-22 16:21:03.456692
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-22 16:21:05.307100
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == True

# Generated at 2022-06-22 16:21:07.915490
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert yaml.dump(HostVars({'a': 'b'}), Dumper=AnsibleDumper) == '{a: b}\n...\n'



# Generated at 2022-06-22 16:21:15.377716
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault_text = vault.encrypt('test')
    encrypted_text = AnsibleVaultEncryptedUnicode(vault_text)
    assert yaml.dump(encrypted_text, Dumper=AnsibleDumper) == '!vault |\n  $ANSIBLE_VAULT;1.1;AES256\n  6331316239626265623166613233376135613231623262613761323231333761623231323337613\n  613231623262613761323231333761623231323337613\n'

# Generated at 2022-06-22 16:21:22.688897
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

# Generated at 2022-06-22 16:21:40.524191
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsVars

    hv = HostVars({"a": "b"})
    assert yaml.dump(hv, Dumper=AnsibleDumper) == "{a: b}\n"

    hvv = HostVarsVars({"a": "b"})
    assert yaml.dump(hvv, Dumper=AnsibleDumper) == "{a: b}\n"

    vws = VarsWithSources({"a": "b"})

# Generated at 2022-06-22 16:21:53.090777
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, u'foo') == u'foo'
    assert represent_unicode(None, u'foo\nbar') == u'foo\nbar'
    assert represent_unicode(None, u'foo\tbar') == u'foo\tbar'
    assert represent_unicode(None, u'foo\u1234bar') == u'foo\u1234bar'
    assert represent_unicode(None, u'foo\u1234bar\n') == u'foo\u1234bar\n'
    assert represent_unicode(None, u'foo\u1234bar\t') == u'foo\u1234bar\t'

# Generated at 2022-06-22 16:22:00.653217
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw==\n'

# Generated at 2022-06-22 16:22:03.446738
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper(None)
    assert dumper.represent_undefined(AnsibleUndefined()) is False
    assert dumper.represent_undefined(AnsibleUndefined(strict=False)) is False
    assert dumper.represent_undefined(AnsibleUndefined(strict=True)) is False

# Generated at 2022-06-22 16:22:05.901797
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == "foo\n..."



# Generated at 2022-06-22 16:22:08.812845
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == u'!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:22:15.485320
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u'foo'
    assert dumper.represent_unicode(u'foo\nbar') == u'foo\nbar'
    assert dumper.represent_unicode(u'foo\nbar\nbaz') == u'foo\nbar\nbaz'
    assert dumper.represent_unicode(u'foo\nbar\nbaz\n') == u'foo\nbar\nbaz\n'
    assert dumper.represent_unicode(u'foo\nbar\nbaz\n\n') == u'foo\nbar\nbaz\n\n'

# Generated at 2022-06-22 16:22:17.997216
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == u'!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:22:20.251723
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:22:23.181085
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == "foo\n...\n"



# Generated at 2022-06-22 16:22:33.059320
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined) == True

# Generated at 2022-06-22 16:22:39.370825
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v\n'



# Generated at 2022-06-22 16:22:41.912644
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x01\x02\x03') == u'!!binary |\n  AQID\n'

# Generated at 2022-06-22 16:22:43.474253
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == True

# Generated at 2022-06-22 16:22:45.179386
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined())

# Generated at 2022-06-22 16:22:47.949006
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == u'!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:22:59.225634
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:23:01.075893
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_data(AnsibleUndefined()) is False

# Generated at 2022-06-22 16:23:03.473361
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == "!!binary |\n  AAECAw==\n"

# Generated at 2022-06-22 16:23:05.746480
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_data(AnsibleUndefined()) == dumper.represent_data(False)

# Generated at 2022-06-22 16:23:33.288240
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw==\n'
    assert dumper.represent_binary(b'\x00\x01\x02\x03', style='>') == u'!!binary >\n  AAECAw==\n'
    assert dumper.represent_binary(b'\x00\x01\x02\x03', style='|') == u'!!binary |\n  AAECAw==\n'
    assert dumper.represent_binary(b'\x00\x01\x02\x03', style='"') == u'!!binary "\\x00\\x01\\x02\\x03"\n'
    assert dumper.represent_

# Generated at 2022-06-22 16:23:44.169520
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v\n'
    assert dumper.represent_binary(dumper, b'foo\nbar') == u'!!binary |\n  Zm9vCmJhcg==\n'
    assert dumper.represent_binary(dumper, b'foo\nbar\nbaz') == u'!!binary |\n  Zm9vCmJhcgpiYXo=\n'
    assert dumper.represent_binary(dumper, b'foo\nbar\nbaz\n') == u'!!binary |\n  Zm9vCmJhcgpiYXoK\n'

# Generated at 2022-06-22 16:23:54.858686
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:24:04.050259
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper

# Generated at 2022-06-22 16:24:10.197315
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v\n'
    assert dumper.represent_binary(dumper, b'foo\n') == u'!!binary |\n  Zm9vCg==\n'
    assert dumper.represent_binary(dumper, b'foo\nbar') == u'!!binary |\n  Zm9vCmJhcg==\n'
    assert dumper.represent_binary(dumper, b'foo\nbar\n') == u'!!binary |\n  Zm9vCmJhcgo=\n'

# Generated at 2022-06-22 16:24:22.130843
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:24:24.287707
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'\x00\x01\x02\x03') == '!!binary |\n  AAECAw==\n'

# Generated at 2022-06-22 16:24:28.746027
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v\n'
    assert dumper.represent_binary(dumper, b'foo\n') == u'!!binary |\n  Zm9vCg==\n'
    assert dumper.represent_binary(dumper, b'foo\nbar') == u'!!binary |\n  Zm9vCmJhcg==\n'

# Generated at 2022-06-22 16:24:34.778318
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == '!!binary |\n  AAECAw==\n'
    assert dumper.represent_binary(b'\x00\x01\x02\x03', style='>') == '!!binary >\n  AAECAw==\n'

# Generated at 2022-06-22 16:24:37.043436
# Unit test for function represent_binary
def test_represent_binary():
    assert AnsibleDumper.represent_binary(None, b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAQ=='

# Generated at 2022-06-22 16:24:54.898819
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == u'!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:24:57.097653
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECA\n'

# Generated at 2022-06-22 16:25:03.753430
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper

# Generated at 2022-06-22 16:25:06.923814
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02') == u'!!binary |\n  AAEC\n'

# Generated at 2022-06-22 16:25:13.441089
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == '!!binary |\n  AAECA'

# Generated at 2022-06-22 16:25:16.458049
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == "!!binary |\n  AAECAw==\n"

# Generated at 2022-06-22 16:25:18.261636
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02') == u'!!binary |\n  AAEC\n'

# Generated at 2022-06-22 16:25:20.222475
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03\x04') == u'!!binary |\n  AAECAwQF\n'

# Generated at 2022-06-22 16:25:29.912476
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == u'!!binary |\n  Zm9v\n'
    assert dumper.represent_binary(b'foo\n') == u'!!binary |\n  Zm9vCg==\n'
    assert dumper.represent_binary(b'foo\nbar') == u'!!binary |\n  Zm9vCmJhcg==\n'
    assert dumper.represent_binary(b'foo\nbar\n') == u'!!binary |\n  Zm9vCmJhcgo=\n'

# Generated at 2022-06-22 16:25:32.003717
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == u'!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:26:14.837003
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u"!binary |\n  Zm9v\n"
    assert dumper.represent_binary(dumper, b'foo\nbar') == u"!binary |\n  Zm9vCmJhcg==\n"
    assert dumper.represent_binary(dumper, b'foo\nbar\nbaz') == u"!binary |\n  Zm9vCmJhcgpiYXo=\n"
    assert dumper.represent_binary(dumper, b'foo\nbar\nbaz\n') == u"!binary |\n  Zm9vCmJhcgpiYXoK\n"

# Generated at 2022-06-22 16:26:17.658341
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw==\n'

# Generated at 2022-06-22 16:26:19.794458
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw=='

# Generated at 2022-06-22 16:26:21.952003
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02') == u'!!binary |\n  AAEC\n'

# Generated at 2022-06-22 16:26:25.447970
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw==\n'

# Generated at 2022-06-22 16:26:33.766765
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper

# Generated at 2022-06-22 16:26:36.340652
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02') == u'!!binary |\n  AAEC\n'

# Generated at 2022-06-22 16:26:47.831374
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()