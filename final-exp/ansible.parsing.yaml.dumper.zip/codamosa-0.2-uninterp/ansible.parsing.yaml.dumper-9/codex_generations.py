

# Generated at 2022-06-22 16:16:55.012906
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper.represent_undefined(AnsibleDumper, AnsibleUndefined())

# Generated at 2022-06-22 16:17:06.859974
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-22 16:17:14.772317
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == "!!binary |\n  Zm9v\n"
    assert dumper.represent_binary(dumper, b'foo\n') == "!!binary |\n  Zm9vCg==\n"
    assert dumper.represent_binary(dumper, b'foo\nbar') == "!!binary |\n  Zm9vCmJhcg==\n"
    assert dumper.represent_binary(dumper, b'foo\nbar\n') == "!!binary |\n  Zm9vCmJhcgo=\n"

# Generated at 2022-06-22 16:17:21.847802
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    data = b'\x00\x01\x02\x03'
    expected = '!!binary |\n  AAECAw==\n'
    assert dumper.represent_binary(data) == expected

# Generated at 2022-06-22 16:17:30.600538
# Unit test for function represent_binary
def test_represent_binary():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper


# Generated at 2022-06-22 16:17:40.915455
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    hv = HostVars(host_vars=dict(a=1, b=2))
    hvv = HostVarsVars(host_vars=dict(a=1, b=2))
    vws = VarsWithSources(host_vars=dict(a=1, b=2))
    hv_str = yaml.dump(hv, Dumper=AnsibleDumper, default_flow_style=False)

# Generated at 2022-06-22 16:17:51.069889
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u'foo'
    assert dumper.represent_unicode(u'foo\nbar') == u'foo\nbar'
    assert dumper.represent_unicode(u'foo\tbar') == u'foo\tbar'
    assert dumper.represent_unicode(u'foo\x00bar') == u'foo\x00bar'
    assert dumper.represent_unicode(u'foo\u1234bar') == u'foo\u1234bar'
    assert dumper.represent_unicode(u'foo\u1234bar') == u'foo\u1234bar'
    assert dumper.represent_unicode(u'foo\u1234bar') == u'foo\u1234bar'

# Generated at 2022-06-22 16:18:02.820245
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u'foo'
    assert dumper.represent_unicode(u'foo\nbar') == u'foo\nbar'
    assert dumper.represent_unicode(u'foo\tbar') == u'foo\tbar'
    assert dumper.represent_unicode(u'foo\x00bar') == u'foo\x00bar'
    assert dumper.represent_unicode(u'foo\u1234bar') == u'foo\u1234bar'
    assert dumper.represent_unicode(u'foo\u1234bar') == u'foo\u1234bar'
    assert dumper.represent_unicode(u'foo\u1234bar') == u'foo\u1234bar'

# Generated at 2022-06-22 16:18:04.672321
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == False

# Generated at 2022-06-22 16:18:06.482190
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_data(AnsibleUndefined) == False

# Generated at 2022-06-22 16:18:17.697695
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

# Generated at 2022-06-22 16:18:23.088616
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw==\n'

# Generated at 2022-06-22 16:18:25.101385
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined) is False

# Generated at 2022-06-22 16:18:33.522809
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper

# Generated at 2022-06-22 16:18:35.340350
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == True

# Generated at 2022-06-22 16:18:49.866835
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

# Generated at 2022-06-22 16:18:52.474840
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECA\n'

# Generated at 2022-06-22 16:18:56.042673
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw==\n'

# Generated at 2022-06-22 16:19:05.905650
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager

    host = Host('testhost')
    group = Group('testgroup')
    group.add_host(host)
    inventory = InventoryManager(hosts=[host], groups=[group])
    variable_manager = VariableManager(loader=None, inventory=inventory)

    hostvars = HostVars(host, variable_manager)
    hostvars.set_variable('testkey', 'testvalue')

# Generated at 2022-06-22 16:19:09.679576
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == '!!binary |\n  AAECAw==\n'

# Generated at 2022-06-22 16:19:21.868713
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u"!ansible-unicode 'foo'"
    assert dumper.represent_unicode(u'foo\nbar') == u"!ansible-unicode |\n  foo\n  bar"
    assert dumper.represent_unicode(u'foo\nbar\n') == u"!ansible-unicode |\n  foo\n  bar\n  "
    assert dumper.represent_unicode(u'foo\nbar\n\n') == u"!ansible-unicode |\n  foo\n  bar\n  \n  "

# Generated at 2022-06-22 16:19:33.047036
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.template import AnsibleUndefined

    # Test HostVars
    test_hostvars = HostVars(host_vars={'test_key': 'test_value'})
    assert represent_hostvars(None, test_hostvars) == {'test_key': 'test_value'}

    # Test HostVarsVars
    test_hostvarsvars = HostVarsVars(host_vars={'test_key': 'test_value'})

# Generated at 2022-06-22 16:19:36.623163
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) is False
    assert dumper.represent_undefined(AnsibleUndefined(strict=False)) is False
    assert dumper.represent_undefined(AnsibleUndefined(strict=True)) is True

# Generated at 2022-06-22 16:19:47.251132
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault.decrypt = lambda x: x

# Generated at 2022-06-22 16:19:51.802571
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    assert dumper.represent_unicode(dumper, 'foo') == dumper.represent_str(dumper, 'foo')
    assert dumper.represent_unicode(dumper, u'foo') == dumper.represent_unicode(dumper, 'foo')

# Generated at 2022-06-22 16:19:54.835080
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, AnsibleUnicode('foo')) == yaml.representer.SafeRepresenter.represent_str(None, 'foo')



# Generated at 2022-06-22 16:20:04.289828
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw==\n'
    assert dumper.represent_binary(b'\x00\x01\x02\x03', style='>') == u'!!binary >\n  AAECAw==\n'
    assert dumper.represent_binary(b'\x00\x01\x02\x03', style='|') == u'!!binary |\n  AAECAw==\n'
    assert dumper.represent_binary(b'\x00\x01\x02\x03', style='"') == u'!!binary "\\x00\\x01\\x02\\x03"\n'
    assert dumper.represent_

# Generated at 2022-06-22 16:20:06.591701
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_data(AnsibleUndefined()) is False

# Generated at 2022-06-22 16:20:10.699429
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    data = b'\x00\x01\x02\x03'
    result = dumper.represent_binary(dumper, data)
    assert result == '!!binary |\n  AAECAw==\n'

# Generated at 2022-06-22 16:20:15.433263
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == False
    assert dumper.represent_undefined(AnsibleUndefined(strict=False)) == False
    assert dumper.represent_undefined(AnsibleUndefined(strict=True)) == True

# Generated at 2022-06-22 16:20:25.808240
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = HostVars({"a": "b"})
    assert represent_hostvars(None, data) == {'a': 'b'}



# Generated at 2022-06-22 16:20:38.031953
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources

    hv = HostVars()
    hv['foo'] = 'bar'
    hv['baz'] = 'qux'

    hvv = HostVarsVars()
    hvv['foo'] = 'bar'
    hvv['baz'] = 'qux'

    vws = VarsWithSources()
    vws['foo'] = 'bar'
    vws['baz'] = 'qux'


# Generated at 2022-06-22 16:20:47.879634
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper

# Generated at 2022-06-22 16:20:53.386995
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:20:55.277004
# Unit test for function represent_undefined
def test_represent_undefined():
    # Test that represent_undefined returns True when data is Undefined
    assert represent_undefined(AnsibleDumper, AnsibleUndefined()) is True

    # Test that represent_undefined returns False when data is not Undefined
    assert represent_undefined(AnsibleDumper, 'foo') is False

# Generated at 2022-06-22 16:20:58.917698
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_data(AnsibleVaultEncryptedUnicode('foo')) == '!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          666f6f0a\n'

# Generated at 2022-06-22 16:21:09.522765
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault_text = vault.encrypt('test')
    vault_text = vault_text.strip()
    vault_text = vault_text.split('\n')
    vault_text = '\n'.join(vault_text[1:-1])
    vault_text = vault_text.encode('utf-8')
    vault_text = AnsibleVaultEncryptedUnicode(vault_text)

# Generated at 2022-06-22 16:21:16.924006
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    ciphertext = vault.encrypt('test')
    encrypted_unicode = AnsibleVaultEncryptedUnicode(ciphertext)

# Generated at 2022-06-22 16:21:19.180447
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == u'!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:21:23.995311
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == False

# Generated at 2022-06-22 16:22:01.905578
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v\n'
    assert dumper.represent_binary(dumper, b'foo\nbar') == u'!!binary |\n  Zm9vCmJhcg==\n'

# Generated at 2022-06-22 16:22:12.002373
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, u'foo') == u'foo'
    assert represent_unicode(None, u'foo\nbar') == u'foo\nbar'
    assert represent_unicode(None, u'foo\nbar\nbaz') == u'foo\nbar\nbaz'
    assert represent_unicode(None, u'foo\nbar\nbaz\n') == u'foo\nbar\nbaz\n'
    assert represent_unicode(None, u'foo\nbar\nbaz\n\n') == u'foo\nbar\nbaz\n\n'
    assert represent_unicode(None, u'foo\nbar\nbaz\n\n\n') == u'foo\nbar\nbaz\n\n\n'

# Generated at 2022-06-22 16:22:18.110402
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper

# Generated at 2022-06-22 16:22:19.948501
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == '!!binary |\n  AAECAw==\n'

# Generated at 2022-06-22 16:22:24.857093
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00') == '!!binary |\n  AA==\n'
    assert dumper.represent_binary(b'\x00\x01') == '!!binary |\n  AAE=\n'
    assert dumper.represent_binary(b'\x00\x01\x02') == '!!binary |\n  AAEC\n'
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == '!!binary |\n  AAECAw==\n'
    assert dumper.represent_binary(b'\x00\x01\x02\x03\x04') == '!!binary |\n  AAECAwQ=\n'
    assert dumper.represent_binary

# Generated at 2022-06-22 16:22:35.935719
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u'foo'
    assert dumper.represent_unicode(u'foo\nbar') == u'foo\nbar'
    assert dumper.represent_unicode(u'foo\tbar') == u'foo\tbar'
    assert dumper.represent_unicode(u'foo\u2026bar') == u'foo\u2026bar'
    assert dumper.represent_unicode(u'foo\u2603bar') == u'foo\u2603bar'
    assert dumper.represent_unicode(u'foo\uD83D\uDE00bar') == u'foo\U0001F600bar'

# Generated at 2022-06-22 16:22:43.088453
# Unit test for function represent_unicode

# Generated at 2022-06-22 16:22:53.698580
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u"'foo'"
    assert dumper.represent_unicode(u'foo\nbar') == u"'foo\nbar'"
    assert dumper.represent_unicode(u'foo\u2026') == u"'foo\u2026'"
    assert dumper.represent_unicode(u'foo\u2026bar') == u"'foo\u2026bar'"
    assert dumper.represent_unicode(u'foo\u2026\nbar') == u"'foo\u2026\nbar'"
    assert dumper.represent_unicode(u'foo\nbar\u2026') == u"'foo\nbar\u2026'"

# Generated at 2022-06-22 16:23:04.421280
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:23:14.784672
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u'foo'
    assert dumper.represent_unicode(u'foo\nbar') == u'foo\nbar'
    assert dumper.represent_unicode(u'foo\tbar') == u'foo\tbar'
    assert dumper.represent_unicode(u'foo\x00bar') == u'foo\x00bar'
    assert dumper.represent_unicode(u'foo\u1234bar') == u'foo\u1234bar'
    assert dumper.represent_unicode(u'foo\u1234bar') == u'foo\u1234bar'
    assert dumper.represent_unicode(u'foo\u1234bar') == u'foo\u1234bar'

# Generated at 2022-06-22 16:24:13.218169
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:24:15.586691
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:24:24.800108
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw==\n'
    assert dumper.represent_binary(b'\x00\x01\x02\x03\x04') == u'!!binary |\n  AAECAwQ=\n'
    assert dumper.represent_binary(b'\x00\x01\x02\x03\x04\x05') == u'!!binary |\n  AAECAwQF\n'
    assert dumper.represent_binary(b'\x00\x01\x02\x03\x04\x05\x06') == u'!!binary |\n  AAECAwQFBg==\n'

# Generated at 2022-06-22 16:24:29.996940
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == u'!!binary |\n  Zm9v\n'
    assert dumper.represent_binary(b'foo\n') == u'!!binary |\n  Zm9vCg==\n'
    assert dumper.represent_binary(b'foo\nbar') == u'!!binary |\n  Zm9vCmJhcg==\n'
    assert dumper.represent_binary(b'foo\nbar\n') == u'!!binary |\n  Zm9vCmJhcgo=\n'

# Generated at 2022-06-22 16:24:42.739874
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03\x04') == u'!!binary |\n  AAECAwQF\n'
    assert dumper.represent_binary(b'\x00\x01\x02\x03\x04', style='>') == u'!!binary >\n  AAECAwQF\n'
    assert dumper.represent_binary(b'\x00\x01\x02\x03\x04', style='|') == u'!!binary |\n  AAECAwQF\n'

# Generated at 2022-06-22 16:24:51.590544
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper

# Generated at 2022-06-22 16:25:00.405021
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:25:02.762616
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02') == "!!binary |\n  AAEC\n"

# Generated at 2022-06-22 16:25:05.865233
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:25:16.838405
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:26:19.880047
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:26:29.962439
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:26:32.002961
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == u'!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:26:44.358873
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:26:56.180652
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == u'!!binary |\n  Zm9v\n'
    assert dumper.represent_binary(b'foo\n') == u'!!binary |\n  Zm9vCg==\n'
    assert dumper.represent_binary(b'foo\nbar') == u'!!binary |\n  Zm9vCmJhcg==\n'
    assert dumper.represent_binary(b'foo\nbar\n') == u'!!binary |\n  Zm9vCmJhcgo=\n'