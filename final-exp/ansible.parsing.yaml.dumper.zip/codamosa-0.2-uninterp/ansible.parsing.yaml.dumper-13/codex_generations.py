

# Generated at 2022-06-22 16:17:00.820592
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v\n'
    assert dumper.represent_binary(dumper, b'foo\n') == u'!!binary |\n  Zm9vCg==\n'
    assert dumper.represent_binary(dumper, b'foo\nbar') == u'!!binary |\n  Zm9vCmJhcg==\n'
    assert dumper.represent_binary(dumper, b'foo\nbar\n') == u'!!binary |\n  Zm9vCmJhcgo=\n'

# Generated at 2022-06-22 16:17:04.537674
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw==\n'

# Generated at 2022-06-22 16:17:07.132995
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02') == "!!binary |\n  AAEC\n"

# Generated at 2022-06-22 16:17:08.285717
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) is False

# Generated at 2022-06-22 16:17:15.435569
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars

    hv = HostVars({"a": 1, "b": 2})
    hvv = HostVarsVars({"a": 1, "b": 2})
    vws = VarsWithSources({"a": 1, "b": 2})

    assert yaml.dump(hv, Dumper=AnsibleDumper) == '{a: 1, b: 2}\n...\n'
    assert yaml.dump(hvv, Dumper=AnsibleDumper) == '{a: 1, b: 2}\n...\n'

# Generated at 2022-06-22 16:17:20.798272
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    assert dumper.represent_undefined(dumper, AnsibleUndefined()) == True

# Generated at 2022-06-22 16:17:27.920178
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u"'foo'"
    assert dumper.represent_unicode(u'foo\nbar') == u"'foo\nbar'"
    assert dumper.represent_unicode(u'foo\u1234bar') == u"'foo\u1234bar'"
    assert dumper.represent_unicode(u'foo\u1234bar\n') == u"'foo\u1234bar\n'"
    assert dumper.represent_unicode(u'foo\u1234bar\n\n') == u"'foo\u1234bar\n\n'"
    assert dumper.represent_unicode(u'foo\u1234bar\n\n\n') == u"'foo\u1234bar\n\n\n'"

# Generated at 2022-06-22 16:17:31.515384
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper
    data = HostVars(dict(a=1, b=2))
    assert dumper.represent_hostvars(dumper, data) == dumper.represent_dict(dumper, dict(a=1, b=2))



# Generated at 2022-06-22 16:17:33.917311
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:17:37.375534
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-22 16:17:45.542924
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib()
    vault.update({'password': 'secret'})
    encrypted_data = vault.encrypt('test')
    encrypted_data = AnsibleVaultEncryptedUnicode(encrypted_data)

# Generated at 2022-06-22 16:17:46.986816
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == False

# Generated at 2022-06-22 16:17:54.156082
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:17:59.306247
# Unit test for function represent_undefined
def test_represent_undefined():
    # Test with StrictUndefined
    assert AnsibleDumper.represent_undefined(AnsibleDumper, AnsibleUndefined(strict=True)) is False
    # Test with Undefined
    assert AnsibleDumper.represent_undefined(AnsibleDumper, AnsibleUndefined(strict=False)) is False

# Generated at 2022-06-22 16:18:02.629776
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:18:04.864010
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.dump(AnsibleUndefined, Dumper=AnsibleDumper) == 'null\n...\n'

# Generated at 2022-06-22 16:18:07.572131
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == u'!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:18:17.356046
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    ciphertext = vault.encrypt('test')
    encrypted_unicode = AnsibleVaultEncryptedUnicode(ciphertext)

# Generated at 2022-06-22 16:18:30.411844
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault.update({'password': 'secret'})
    ciphertext = vault.encrypt('password')
    encrypted_unicode = AnsibleVaultEncryptedUnicode(ciphertext)

# Generated at 2022-06-22 16:18:34.680712
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw=='

# Generated at 2022-06-22 16:18:43.703038
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = {'a': 'b'}
    hostvars = HostVars(data)
    assert yaml.dump(hostvars, Dumper=AnsibleDumper) == '{a: b}\n...\n'



# Generated at 2022-06-22 16:18:45.285185
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == False

# Generated at 2022-06-22 16:18:47.540704
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-22 16:18:48.974776
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) is False

# Generated at 2022-06-22 16:18:57.407409
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:19:07.960168
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vault = VaultLib([])
    vault.update({'password': 'secret'})
    ciphertext = vault.encrypt('my secret')
    data = AnsibleVaultEncryptedUnicode(ciphertext)

# Generated at 2022-06-22 16:19:18.029752
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:19:23.076022
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo')) == "foo\n...\n"



# Generated at 2022-06-22 16:19:26.067614
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-22 16:19:35.399328
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.template import AnsibleUndefined

    hv = HostVars()
    hv['a'] = 'b'
    hv['c'] = AnsibleUndefined
    hv['d'] = VarsWithSources()
    hv['d']['e'] = 'f'
    hv['d']['g'] = AnsibleUndefined

    assert yaml.dump(hv, Dumper=AnsibleDumper) == '{a: b, c: null, d: {e: f, g: null}}\n'



# Generated at 2022-06-22 16:19:42.220432
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw==\n'

# Generated at 2022-06-22 16:19:55.039286
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars

    hv = HostVars({"a": "b"})
    hvv = HostVarsVars({"a": "b"})
    vws = VarsWithSources({"a": "b"})

    assert yaml.dump(hv, Dumper=AnsibleDumper) == '{a: b}\n...\n'
    assert yaml.dump(hvv, Dumper=AnsibleDumper) == '{a: b}\n...\n'
    assert yaml.dump(vws, Dumper=AnsibleDumper) == '{a: b}\n...\n'


# Unit

# Generated at 2022-06-22 16:19:57.415411
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == False

# Generated at 2022-06-22 16:20:05.751195
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault_text = vault.encrypt(u'foo')
    data = AnsibleVaultEncryptedUnicode(vault_text)

# Generated at 2022-06-22 16:20:17.463631
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    assert dumper.represent_unicode(dumper, u'foo') == dumper.represent_str(dumper, 'foo')
    assert dumper.represent_unicode(dumper, u'foo\nbar') == dumper.represent_str(dumper, 'foo\nbar')
    assert dumper.represent_unicode(dumper, u'foo\nbar') == dumper.represent_str(dumper, 'foo\nbar')
    assert dumper.represent_unicode(dumper, u'foo\nbar') == dumper.represent_str(dumper, 'foo\nbar')
    assert dumper.represent_unicode(dumper, u'foo\nbar') == dumper.represent_str(dumper, 'foo\nbar')
    assert dumper.represent

# Generated at 2022-06-22 16:20:22.470764
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vault = VaultLib([])
    vault_text = vault.encrypt('foo')
    encrypted_text = AnsibleVaultEncryptedUnicode(vault_text)

# Generated at 2022-06-22 16:20:25.008216
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw==\n'

# Generated at 2022-06-22 16:20:37.171921
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

# Generated at 2022-06-22 16:20:47.041630
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault.update({'password': 'secret'})

# Generated at 2022-06-22 16:20:50.473559
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw==\n'

# Generated at 2022-06-22 16:20:55.473722
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == '!!binary |\n  AAECAw==\n'

# Generated at 2022-06-22 16:21:05.622714
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:21:14.731290
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.template import AnsibleUndefined

    hostvars = HostVars(dict(a=1, b=2))
    assert yaml.dump(hostvars, Dumper=AnsibleDumper) == '{a: 1, b: 2}\n...\n'

    hostvars = HostVarsVars(dict(a=1, b=2))

# Generated at 2022-06-22 16:21:22.651439
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02') == u'!!binary |\n  AAEC\n'
    assert dumper.represent_binary(b'\x00\x01\x02', style='>') == u'!!binary >\n  AAEC\n'
    assert dumper.represent_binary(b'\x00\x01\x02', style='|') == u'!!binary |\n  AAEC\n'
    assert dumper.represent_binary(b'\x00\x01\x02', style='"') == u'!!binary "\\x00\\x01\\x02"\n'
    assert dumper.represent_binary(b'\x00\x01\x02', style='\'') == u

# Generated at 2022-06-22 16:21:29.318014
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(AnsibleDumper, u'foo') == u'foo'
    assert represent_unicode(AnsibleDumper, u'foo\nbar') == u'foo\nbar'
    assert represent_unicode(AnsibleDumper, u'foo\tbar') == u'foo\tbar'
    assert represent_unicode(AnsibleDumper, u'foo\x00bar') == u'foo\x00bar'
    assert represent_unicode(AnsibleDumper, u'foo\u1234bar') == u'foo\u1234bar'



# Generated at 2022-06-22 16:21:32.613987
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    data = AnsibleUnicode('test')
    assert dumper.represent_unicode(dumper, data) == dumper.represent_str(dumper, 'test')



# Generated at 2022-06-22 16:21:35.407168
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = HostVars({"foo": "bar"})
    assert yaml.dump(hostvars, Dumper=AnsibleDumper) == '{foo: bar}\n'



# Generated at 2022-06-22 16:21:37.944110
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw==\n'

# Generated at 2022-06-22 16:21:40.007525
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper(None, None, None)
    assert dumper.represent_undefined(AnsibleUndefined) is False

# Generated at 2022-06-22 16:21:44.003980
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    undefined = AnsibleUndefined('foo')
    assert dumper.represent_undefined(dumper, undefined) is True

# Generated at 2022-06-22 16:21:50.273416
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw==\n'

# Generated at 2022-06-22 16:21:56.173407
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert yaml.dump(HostVars({'a': 1}), Dumper=AnsibleDumper) == '{a: 1}\n'
    assert yaml.dump(HostVarsVars({'a': 1}), Dumper=AnsibleDumper) == '{a: 1}\n'
    assert yaml.dump(VarsWithSources({'a': 1}), Dumper=AnsibleDumper) == '{a: 1}\n'



# Generated at 2022-06-22 16:21:57.881461
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hv = HostVars({"a": "b"})
    assert yaml.dump(hv, Dumper=AnsibleDumper) == "a: b\n"



# Generated at 2022-06-22 16:22:05.452477
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-22 16:22:08.699780
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = HostVars(dict(foo='bar'))
    assert yaml.dump(data, Dumper=AnsibleDumper) == '{foo: bar}\n'



# Generated at 2022-06-22 16:22:22.017046
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-22 16:22:24.232010
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper) == ''

# Generated at 2022-06-22 16:22:26.700505
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    undefined = AnsibleUndefined()
    assert dumper.represent_undefined(dumper, undefined) is True

# Generated at 2022-06-22 16:22:30.169210
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw==\n'

# Generated at 2022-06-22 16:22:38.432265
# Unit test for function represent_unicode
def test_represent_unicode():
    # Test with a simple string
    assert represent_unicode(AnsibleDumper, 'foo') == u'foo'

    # Test with a unicode string
    assert represent_unicode(AnsibleDumper, u'\u20ac') == u'\u20ac'

    # Test with a string containing a unicode character
    assert represent_unicode(AnsibleDumper, '\u20ac') == u'\u20ac'

    # Test with a string containing a unicode character
    assert represent_unicode(AnsibleDumper, '\xe2\x82\xac') == u'\u20ac'

    # Test with a string containing a unicode character
    assert represent_unicode(AnsibleDumper, '\xc2\xa2') == u'\xa2'

    # Test with a

# Generated at 2022-06-22 16:22:53.657514
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u'foo'
    assert dumper.represent_unicode(u'foo\nbar') == u'foo\nbar'
    assert dumper.represent_unicode(u'foo\tbar') == u'foo\tbar'
    assert dumper.represent_unicode(u'foo\u1234bar') == u'foo\u1234bar'
    assert dumper.represent_unicode(u'foo\u1234bar') == u'foo\u1234bar'
    assert dumper.represent_unicode(u'foo\u1234bar') == u'foo\u1234bar'

# Generated at 2022-06-22 16:22:57.225136
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-22 16:23:00.921462
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper
    data = HostVars(dict(a=1, b=2))
    assert dumper.represent_hostvars(dumper, data) == dumper.represent_dict(dumper, dict(a=1, b=2))



# Generated at 2022-06-22 16:23:10.240782
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u'foo'
    assert dumper.represent_unicode(u'foo\nbar') == u'foo\nbar'
    assert dumper.represent_unicode(u'foo\nbar\nbaz') == u'foo\nbar\nbaz'
    assert dumper.represent_unicode(u'foo\nbar\nbaz\n') == u'foo\nbar\nbaz\n'
    assert dumper.represent_unicode(u'foo\nbar\nbaz\n\n') == u'foo\nbar\nbaz\n\n'

# Generated at 2022-06-22 16:23:12.108044
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_data(AnsibleUndefined()) is None

# Generated at 2022-06-22 16:23:21.635940
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'
    assert yaml.dump(AnsibleUnicode('foo\nbar'), Dumper=AnsibleDumper) == 'foo\nbar\n...\n'
    assert yaml.dump(AnsibleUnicode('foo\nbar\nbaz'), Dumper=AnsibleDumper) == '|-\n  foo\n  bar\n  baz\n...\n'
    assert yaml.dump(AnsibleUnicode('foo\nbar\nbaz\n'), Dumper=AnsibleDumper) == '|-\n  foo\n  bar\n  baz\n  \n...\n'

# Generated at 2022-06-22 16:23:23.451814
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == '!!binary |\n  AAECAw==\n'

# Generated at 2022-06-22 16:23:28.527893
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) is True

# Generated at 2022-06-22 16:23:30.472176
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-22 16:23:33.847389
# Unit test for function represent_undefined
def test_represent_undefined():
    # Test with a value that is not undefined
    assert yaml.dump(True, Dumper=AnsibleDumper) == 'true\n...\n'

    # Test with a value that is undefined
    assert yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper) == 'null\n...\n'

# Generated at 2022-06-22 16:23:49.892735
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # Test with HostVars object
    data = HostVars(dict(foo='bar'))
    assert yaml.dump(data, Dumper=AnsibleDumper) == '{foo: bar}\n...\n'

    # Test with HostVarsVars object
    data = HostVarsVars(dict(foo='bar'))
    assert yaml.dump(data, Dumper=AnsibleDumper) == '{foo: bar}\n...\n'

    # Test with VarsWithSources object
    data = VarsWithSources(dict(foo='bar'))
    assert yaml.dump(data, Dumper=AnsibleDumper) == '{foo: bar}\n...\n'



# Generated at 2022-06-22 16:24:02.583311
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:24:04.116350
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == True


# Generated at 2022-06-22 16:24:09.500808
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsManager
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    hv = HostVars(VarsManager())
    hv['a'] = 'b'
    hv['c'] = 'd'
    hv['e'] = 'f'

    assert isinstance(hv, AnsibleMapping)
    assert isinstance(AnsibleDumper.represent_hostvars(AnsibleDumper, hv), yaml.nodes.MappingNode)

# Generated at 2022-06-22 16:24:13.384872
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == False

# Generated at 2022-06-22 16:24:15.701122
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-22 16:24:22.736100
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources

    hv = HostVars({"a": "b"})
    assert yaml.dump(hv, Dumper=AnsibleDumper) == '{a: b}\n'

    hv = HostVars({"a": "b"})
    assert yaml.dump(VarsWithSources(hv), Dumper=AnsibleDumper) == '{a: b}\n'



# Generated at 2022-06-22 16:24:25.893602
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == False
    assert dumper.represent_undefined(AnsibleUndefined(fail_on_undefined=False)) == True
    assert dumper.represent_undefined(AnsibleUndefined(fail_on_undefined=True)) == False

# Generated at 2022-06-22 16:24:31.697786
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    vault = VaultLib([])
    vault.update({'password': 'secret'})
    ciphertext = vault.encrypt('test')
    data = AnsibleVaultEncryptedUnicode(ciphertext)

# Generated at 2022-06-22 16:24:40.070412
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:25:12.498311
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == "!!binary |\n  Zm9v\n"
    assert dumper.represent_binary(b'\x00\x01\x02\x03\x04') == "!!binary |\n  AAECAwQF\n"
    assert dumper.represent_binary(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f') == "!!binary |\n  AAECAwQFBgcICQoLDA0ODw==\n"

# Generated at 2022-06-22 16:25:17.525833
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

# Generated at 2022-06-22 16:25:19.273745
# Unit test for function represent_undefined
def test_represent_undefined():
    data = AnsibleUndefined()
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(data) is False

# Generated at 2022-06-22 16:25:29.813221
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, u'foo') == u'foo'
    assert represent_unicode(None, u'foo\nbar') == u'foo\nbar'
    assert represent_unicode(None, u'foo\nbar\nbaz') == u'foo\nbar\nbaz'
    assert represent_unicode(None, u'foo\nbar\nbaz\n') == u'foo\nbar\nbaz\n'
    assert represent_unicode(None, u'foo\nbar\nbaz\n\n') == u'foo\nbar\nbaz\n\n'
    assert represent_unicode(None, u'foo\nbar\nbaz\n\n\n') == u'foo\nbar\nbaz\n\n\n'

# Generated at 2022-06-22 16:25:38.063190
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    ciphertext = vault.encrypt('test')
    encrypted_unicode = AnsibleVaultEncryptedUnicode(ciphertext)

# Generated at 2022-06-22 16:25:47.777227
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw==\n'
    assert dumper.represent_binary(b'\x00\x01\x02\x03\x04') == u'!!binary |\n  AAECAwQ=\n'
    assert dumper.represent_binary(b'\x00\x01\x02\x03\x04\x05') == u'!!binary |\n  AAECAwQF\n'
    assert dumper.represent_binary(b'\x00\x01\x02\x03\x04\x05\x06') == u'!!binary |\n  AAECAwQFBg==\n'

# Generated at 2022-06-22 16:25:58.037580
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode(u'foo'), Dumper=AnsibleDumper) == u'foo\n...\n'
    assert yaml.dump(AnsibleUnicode(u'foo\nbar'), Dumper=AnsibleDumper) == u'|-\n  foo\n  bar\n'
    assert yaml.dump(AnsibleUnicode(u'foo\nbar\nbaz'), Dumper=AnsibleDumper) == u'|-\n  foo\n  bar\n  baz\n'
    assert yaml.dump(AnsibleUnicode(u'foo\nbar\nbaz\n'), Dumper=AnsibleDumper) == u'|-\n  foo\n  bar\n  baz\n'

# Generated at 2022-06-22 16:26:03.289857
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.template import AnsibleUndefined

    hv = HostVars(dict(a=1, b=2))
    hvv = HostVarsVars(dict(c=3, d=4))
    vws = VarsWithSources(dict(e=5, f=6))
    am = AnsibleMapping(dict(g=7, h=8))
    au = AnsibleUndefined()


# Generated at 2022-06-22 16:26:15.418310
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources

    hv = HostVars({"a": 1, "b": 2})
    hv_vars = HostVarsVars(hv)
    vws = VarsWithSources(hv_vars)

    assert yaml.dump(hv, Dumper=AnsibleDumper) == '{a: 1, b: 2}\n...\n'
    assert yaml.dump(hv_vars, Dumper=AnsibleDumper) == '{a: 1, b: 2}\n...\n'
    assert yaml.dump(vws, Dumper=AnsibleDumper) == '{a: 1, b: 2}\n...\n'

# Generated at 2022-06-22 16:26:16.339870
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) is True