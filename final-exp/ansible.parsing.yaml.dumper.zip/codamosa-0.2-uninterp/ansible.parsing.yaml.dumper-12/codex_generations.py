

# Generated at 2022-06-22 16:17:01.677250
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

# Generated at 2022-06-22 16:17:11.754788
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources

    hostvars = HostVars(hostname='testhost')
    hostvars.add_source('test_source', 'test_source_data')
    hostvars.set('test_key', 'test_value')

    dumper = AnsibleDumper()
    dumper.represent_hostvars(hostvars)

    assert isinstance(dumper.represent_hostvars(hostvars), AnsibleMapping)

    vars_with_sources = VarsWithSources(hostvars)
    dumper.represent_hostvars(vars_with_sources)


# Generated at 2022-06-22 16:17:15.818429
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    assert dumper.represent_undefined(dumper, AnsibleUndefined())

# Generated at 2022-06-22 16:17:17.956923
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined) is False

# Generated at 2022-06-22 16:17:27.157299
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    hv = HostVars(dict(a=1, b=2))
    hvv = HostVarsVars(dict(a=1, b=2))
    vws = VarsWithSources(dict(a=1, b=2))

    assert isinstance(represent_hostvars(AnsibleDumper, hv), AnsibleMapping)
    assert isinstance(represent_hostvars(AnsibleDumper, hvv), AnsibleMapping)
   

# Generated at 2022-06-22 16:17:29.489481
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, AnsibleUnicode('foo')) == yaml.representer.SafeRepresenter.represent_str(None, 'foo')



# Generated at 2022-06-22 16:17:34.849557
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.hostvars import HostVars

    dumper = AnsibleDumper()
    data = HostVars(AnsibleMapping())
    data['foo'] = 'bar'
    data['baz'] = 'qux'
    assert dumper.represent_hostvars(data) == dumper.represent_dict(dict(data))

# Generated at 2022-06-22 16:17:43.960176
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == u'!!binary |\n  Zm9v\n'
    assert dumper.represent_binary(b'foo\n') == u'!!binary |\n  Zm9vCg==\n'
    assert dumper.represent_binary(b'foo\nbar') == u'!!binary |\n  Zm9vCmJhcg==\n'
    assert dumper.represent_binary(b'foo\nbar\n') == u'!!binary |\n  Zm9vCmJhcgo=\n'

# Generated at 2022-06-22 16:17:52.438774
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault_text = vault.encrypt('test')
    vault_unicode = AnsibleVaultEncryptedUnicode(vault_text)

# Generated at 2022-06-22 16:18:04.579368
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    h = Host('testhost')
    g = Group('testgroup')
    g.add_host(h)
    vm = VariableManager()
    vm.set_host_variable(h, 'foo', 'bar')
    vm.set_host_variable(h, 'baz', 'qux')
    vm.set_host_variable(h, 'ansible_ssh_host', '127.0.0.1')
    vm.set_host_variable(h, 'ansible_ssh_port', 22)
    vm.set_host_variable(h, 'ansible_ssh_user', 'root')

# Generated at 2022-06-22 16:18:08.165527
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_data(AnsibleUndefined()) == dumper.represent_data(False)

# Generated at 2022-06-22 16:18:17.664651
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.manager import VariableManager

    templar = Templar(loader=None, variables=VariableManager())
    templar._fail_on_undefined = True

    # Test with StrictUndefined
    data = AnsibleMapping(templar, {'a': templar.from_yaml('a: {{ foo }}')})
    assert yaml.dump(data, Dumper=AnsibleDumper) == '{a: {}}\n'

    # Test with Undefined
    data = AnsibleMapping(templar, {'a': templar.from_yaml('a: {{ foo }}', convert_bare=True)})

# Generated at 2022-06-22 16:18:21.738136
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper.represent_undefined(AnsibleDumper, AnsibleUndefined()) is False

# Generated at 2022-06-22 16:18:24.638236
# Unit test for function represent_unicode
def test_represent_unicode():
    data = AnsibleUnicode('test')
    assert yaml.dump(data, Dumper=AnsibleDumper) == 'test\n...\n'



# Generated at 2022-06-22 16:18:33.287250
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper(None)

# Generated at 2022-06-22 16:18:43.302940
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\n3534363339356533343735306635373837333530653534373735333935343737353335343633393565333437353066353738373335306535343737353339353437373533\n')

# Generated at 2022-06-22 16:18:51.564961
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

# Generated at 2022-06-22 16:19:00.101825
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

# Generated at 2022-06-22 16:19:01.960804
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, u'foo') == u'foo'



# Generated at 2022-06-22 16:19:13.125690
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault.update({'vault_password_file': './test/ansible-vault-password'})
    vault_text = vault.encrypt('test')
    vault_text = vault_text.replace('\n', '')
    vault_text = vault_text.replace('\r', '')
    vault_text = vault_text.replace('\t', '')
    vault_text = vault_text.replace(' ', '')
    vault_text = vault_text.replace('\x0b', '')
    vault_text = vault_text.replace('\x0c', '')
    vault_text = vault_text.replace('\x0d', '')

# Generated at 2022-06-22 16:19:21.636570
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsManager
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.clean import strip_internal_keys

    hv = HostVars(VarsManager())
    hv['foo'] = wrap_var(u'bar')
    hv['baz'] = wrap_var(u'qux')

    assert strip_internal_keys(yaml.load(yaml.dump(hv, Dumper=AnsibleDumper))) == {'foo': u'bar', 'baz': u'qux'}



# Generated at 2022-06-22 16:19:32.925516
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault.update({'vault_password_file': 'vault_password_file'})
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext)
    encrypted_unicode = AnsibleVaultEncryptedUnicode(ciphertext)

# Generated at 2022-06-22 16:19:39.625455
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources

    hv = HostVars()
    hv['foo'] = 'bar'
    hv['baz'] = 'qux'

    vws = VarsWithSources()
    vws['foo'] = 'bar'
    vws['baz'] = 'qux'

    assert yaml.dump(hv, Dumper=AnsibleDumper) == '{foo: bar, baz: qux}\n'
    assert yaml.dump(vws, Dumper=AnsibleDumper) == '{foo: bar, baz: qux}\n'



# Generated at 2022-06-22 16:19:43.044671
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECA\n'

# Generated at 2022-06-22 16:19:55.038452
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:20:01.235991
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined())

# Generated at 2022-06-22 16:20:07.565952
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'
    assert yaml.dump(AnsibleUnicode('foo\nbar'), Dumper=AnsibleDumper) == 'foo\nbar\n...\n'
    assert yaml.dump(AnsibleUnicode('foo\nbar\nbaz'), Dumper=AnsibleDumper) == '|-\n  foo\n  bar\n  baz\n'
    assert yaml.dump(AnsibleUnicode('foo\nbar\nbaz\n'), Dumper=AnsibleDumper) == '|-\n  foo\n  bar\n  baz\n'

# Generated at 2022-06-22 16:20:18.716824
# Unit test for function represent_binary
def test_represent_binary():
    # Test for python 2.6
    if hasattr(yaml, 'CSafeDumper'):
        dumper = yaml.CSafeDumper
    else:
        dumper = yaml.SafeDumper

    # Test for python 2.6
    if hasattr(yaml, 'CSafeLoader'):
        loader = yaml.CSafeLoader
    else:
        loader = yaml.SafeLoader

    represent_binary(dumper, b'foo')
    represent_binary(dumper, b'foo\nbar')
    represent_binary(dumper, b'foo\nbar\nbaz')
    represent_binary(dumper, b'foo\nbar\nbaz\n')
    represent_binary(dumper, b'foo\nbar\nbaz\n\n')

# Generated at 2022-06-22 16:20:28.995467
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v\n'
    assert dumper.represent_binary(dumper, b'foo\n') == u'!!binary |\n  Zm9vCg==\n'
    assert dumper.represent_binary(dumper, b'foo\nbar') == u'!!binary |\n  Zm9vCmJhcg==\n'
    assert dumper.represent_binary(dumper, b'foo\nbar\n') == u'!!binary |\n  Zm9vCmJhcgo=\n'

# Generated at 2022-06-22 16:20:39.045454
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars

    hv = HostVars({"a": "b"})
    assert yaml.dump(hv, Dumper=AnsibleDumper) == '{a: b}\n...\n'

    hvv = HostVarsVars({"a": "b"})
    assert yaml.dump(hvv, Dumper=AnsibleDumper) == '{a: b}\n...\n'

    vws = VarsWithSources({"a": "b"})
    assert yaml.dump(vws, Dumper=AnsibleDumper) == '{a: b}\n...\n'

# Generated at 2022-06-22 16:20:46.900984
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, AnsibleUnicode(u'foo')) == yaml.representer.SafeRepresenter.represent_str(None, u'foo')



# Generated at 2022-06-22 16:20:57.127501
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    vault.update('test')
    encrypted_text = vault.encrypt('test')
    encrypted_unicode = AnsibleVaultEncryptedUnicode(encrypted_text)

# Generated at 2022-06-22 16:21:07.091229
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Note: this is a unit test for a function in this file,
    # not a functional test for Ansible.
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vault = VaultLib([])
    vault.update({'password': 'test'})
    ciphertext = vault.encrypt('test')
    data = AnsibleVaultEncryptedUnicode(ciphertext)

# Generated at 2022-06-22 16:21:09.442958
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined) == False

# Generated at 2022-06-22 16:21:16.871269
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u"!ansible-unicode 'foo'"
    assert dumper.represent_unicode(u'foo\nbar') == u"!ansible-unicode |-\n  foo\n  bar"
    assert dumper.represent_unicode(u'foo\nbar\nbaz') == u"!ansible-unicode |-\n  foo\n  bar\n  baz"
    assert dumper.represent_unicode(u'foo\nbar\nbaz\n') == u"!ansible-unicode |-\n  foo\n  bar\n  baz\n  "

# Generated at 2022-06-22 16:21:22.966003
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u"'foo'"
    assert dumper.represent_unicode(u'foo\nbar') == u"'foo\nbar'"
    assert dumper.represent_unicode(u'foo\tbar') == u"'foo\tbar'"
    assert dumper.represent_unicode(u'foo\u1234') == u"'foo\u1234'"
    assert dumper.represent_unicode(u'foo\u1234\nbar') == u"'foo\u1234\nbar'"
    assert dumper.represent_unicode(u'foo\u1234\tbar') == u"'foo\u1234\tbar'"

# Generated at 2022-06-22 16:21:26.302630
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == u'!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:21:28.932672
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper) == 'null\n...\n'

# Generated at 2022-06-22 16:21:30.581859
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == False

# Generated at 2022-06-22 16:21:32.837083
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_data(AnsibleUndefined) == False


# Generated at 2022-06-22 16:21:54.155827
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    dumper.add_representer(
        AnsibleUnsafeBytes,
        represent_binary,
    )

# Generated at 2022-06-22 16:22:00.085623
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

# Generated at 2022-06-22 16:22:02.905422
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = {'a': 1, 'b': 2}
    hostvars = HostVars(data)
    assert yaml.dump(hostvars, Dumper=AnsibleDumper) == yaml.dump(data, Dumper=AnsibleDumper)



# Generated at 2022-06-22 16:22:05.695697
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == u"foo\n..."



# Generated at 2022-06-22 16:22:14.149200
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources

    hv = HostVars()
    hv['foo'] = 'bar'
    hv['baz'] = 'qux'

    hvv = HostVarsVars()
    hvv['foo'] = 'bar'
    hvv['baz'] = 'qux'

    vws = VarsWithSources()
    vws['foo'] = 'bar'
    vws['baz'] = 'qux'

    assert yaml.dump(hv, Dumper=AnsibleDumper) == '{foo: bar, baz: qux}\n'

# Generated at 2022-06-22 16:22:16.241979
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == False

# Generated at 2022-06-22 16:22:18.902372
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode(u'foo'), Dumper=AnsibleDumper) == u'foo\n...\n'



# Generated at 2022-06-22 16:22:22.181102
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) is False
    assert dumper.represent_undefined(AnsibleUndefined(strict=False)) is False
    assert dumper.represent_undefined(AnsibleUndefined(strict=True)) is False

# Generated at 2022-06-22 16:22:30.128514
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v\n'
    assert dumper.represent_binary(dumper, b'foo\n') == u'!!binary |\n  Zm9vCg==\n'
    assert dumper.represent_binary(dumper, b'foo\nbar') == u'!!binary |\n  Zm9vCmJhcg==\n'

# Generated at 2022-06-22 16:22:38.409744
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

# Generated at 2022-06-22 16:22:53.062977
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02') == u'!!binary |\n  AAEC\n'

# Generated at 2022-06-22 16:22:54.677052
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) is False

# Generated at 2022-06-22 16:23:00.921269
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:23:03.292579
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw==\n'

# Generated at 2022-06-22 16:23:11.074983
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault.decrypt = lambda x: x

# Generated at 2022-06-22 16:23:12.783613
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) is False

# Generated at 2022-06-22 16:23:22.089187
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.template import AnsibleUndefined

    hv = HostVars(host_name='testhost')
    hv['testkey'] = 'testvalue'
    hv['testkey2'] = AnsibleUnsafeText('testvalue2')
    hv['testkey3'] = AnsibleUnsafeBytes('testvalue3')
    hv['testkey4'] = AnsibleUndefined()


# Generated at 2022-06-22 16:23:27.419795
# Unit test for function represent_undefined
def test_represent_undefined():
    # Test with StrictUndefined
    from ansible.template import StrictUndefined
    strict_undefined = StrictUndefined(obj='foo')
    assert AnsibleDumper.represent_undefined(AnsibleDumper(), strict_undefined) is False

    # Test with Undefined
    from ansible.template import Undefined
    undefined = Undefined(obj='foo')
    assert AnsibleDumper.represent_undefined(AnsibleDumper(), undefined) is False

# Generated at 2022-06-22 16:23:34.855911
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars

    assert yaml.dump(HostVars({"a": "b"}), Dumper=AnsibleDumper) == "{a: b}\n"
    assert yaml.dump(HostVarsVars({"a": "b"}), Dumper=AnsibleDumper) == "{a: b}\n"
    assert yaml.dump(VarsWithSources({"a": "b"}), Dumper=AnsibleDumper) == "{a: b}\n"

# Generated at 2022-06-22 16:23:37.464284
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECA'

# Generated at 2022-06-22 16:24:37.948313
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v\n'
    assert dumper.represent_binary(dumper, b'foo\nbar') == u'!!binary |\n  Zm9vCmJhcg==\n'
    assert dumper.represent_binary(dumper, b'foo\nbar\n') == u'!!binary |\n  Zm9vCmJhcgo=\n'
    assert dumper.represent_binary(dumper, b'foo\nbar\n\n') == u'!!binary |\n  Zm9vCmJhcgoK\n'

# Generated at 2022-06-22 16:24:51.005978
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper

# Generated at 2022-06-22 16:24:59.828716
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:25:02.234469
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:25:12.658595
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:25:17.542939
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:25:23.068032
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECA\n'
    assert dumper.represent_binary(b'\x00\x01\x02\x03', style='>') == u'!!binary >\n  AAECA\n'
    assert dumper.represent_binary(b'\x00\x01\x02\x03', style='|') == u'!!binary |\n  AAECA\n'
    assert dumper.represent_binary(b'\x00\x01\x02\x03', style='"') == u'!!binary "AAECA"\n'

# Generated at 2022-06-22 16:25:31.647965
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    dumper.add_representer(
        AnsibleUnsafeBytes,
        represent_binary,
    )

# Generated at 2022-06-22 16:25:37.393514
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:25:47.253795
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:26:21.685062
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper

# Generated at 2022-06-22 16:26:24.829777
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(b'foo', Dumper=AnsibleDumper) == "!!binary |\n  Zm9v\n"



# Generated at 2022-06-22 16:26:27.342330
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    data = b'hello'
    assert dumper.represent_binary(dumper, data) == dumper.represent_str(dumper, 'hello')

# Generated at 2022-06-22 16:26:34.704235
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:26:45.113513
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:26:48.463751
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == u'!!binary |\n  Zm9v\n'