

# Generated at 2022-06-22 16:16:55.354041
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == dumper.represent_str(dumper, 'foo')

# Generated at 2022-06-22 16:17:06.746515
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v\n'
    assert dumper.represent_binary(dumper, b'foo\nbar') == u'!!binary |\n  Zm9vCmJhcg==\n'
    assert dumper.represent_binary(dumper, b'foo\nbar\nbaz') == u'!!binary |\n  Zm9vCmJhcgpiYXo=\n'
    assert dumper.represent_binary(dumper, b'foo\nbar\nbaz\n') == u'!!binary |\n  Zm9vCmJhcgpiYXoK\n'

# Generated at 2022-06-22 16:17:14.720966
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

# Generated at 2022-06-22 16:17:20.084818
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault.update({'password': 'secret'})

# Generated at 2022-06-22 16:17:23.690289
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper
    hostvars = HostVars({"a": "b"})
    assert dumper.represent_hostvars(hostvars) == dumper.represent_dict({"a": "b"})

# Generated at 2022-06-22 16:17:25.453924
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_data(AnsibleUndefined) == dumper.represent_data(True)

# Generated at 2022-06-22 16:17:27.331452
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) is False

# Generated at 2022-06-22 16:17:29.010129
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    assert dumper.represent_undefined(dumper, AnsibleUndefined()) == True

# Generated at 2022-06-22 16:17:33.252446
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode(u'foo'), Dumper=AnsibleDumper) == 'foo\n...\n'
    assert yaml.dump(AnsibleUnicode(u'foo'), Dumper=AnsibleDumper, default_flow_style=True) == "'foo'\n"



# Generated at 2022-06-22 16:17:42.891993
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, u'foo') == u'foo'
    assert represent_unicode(None, u'foo\nbar') == u'foo\nbar'
    assert represent_unicode(None, u'foo\tbar') == u'foo\tbar'
    assert represent_unicode(None, u'foo\rbar') == u'foo\rbar'
    assert represent_unicode(None, u'foo\u1234bar') == u'foo\u1234bar'
    assert represent_unicode(None, u'foo\u1234bar\n') == u'foo\u1234bar\n'
    assert represent_unicode(None, u'foo\u1234bar\t') == u'foo\u1234bar\t'

# Generated at 2022-06-22 16:17:47.426237
# Unit test for function represent_unicode
def test_represent_unicode():
    data = AnsibleUnicode(u'foo')
    assert yaml.dump(data, Dumper=AnsibleDumper) == u'foo\n...\n'



# Generated at 2022-06-22 16:17:49.125631
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_data(AnsibleUndefined()) is None

# Generated at 2022-06-22 16:17:59.351495
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u'foo'
    assert dumper.represent_unicode(u'\u20ac') == u'\u20ac'
    assert dumper.represent_unicode(u'\u20ac'.encode('utf-8')) == u'\u20ac'
    assert dumper.represent_unicode(u'\u20ac'.encode('latin-1')) == u'\u20ac'
    assert dumper.represent_unicode(u'\u20ac'.encode('ascii', 'replace')) == u'?'
    assert dumper.represent_unicode(u'\u20ac'.encode('ascii', 'xmlcharrefreplace')) == u'&#8364;'


# Generated at 2022-06-22 16:18:01.713634
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) is False

# Generated at 2022-06-22 16:18:04.048107
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) is False



# Generated at 2022-06-22 16:18:14.507927
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:18:16.064795
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-22 16:18:21.742821
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hv = HostVars(dict(a=1, b=2))
    assert yaml.dump(hv, Dumper=AnsibleDumper) == '{a: 1, b: 2}\n...\n'



# Generated at 2022-06-22 16:18:32.010644
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault_text = vault.encrypt('test')
    vault_encrypted_unicode = AnsibleVaultEncryptedUnicode(vault_text)

# Generated at 2022-06-22 16:18:33.937601
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == False

# Generated at 2022-06-22 16:18:43.267045
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw==\n'

# Generated at 2022-06-22 16:18:51.539016
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:18:56.002751
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    hostvars = HostVars({"a": "b"})
    assert dumper.represent_hostvars(hostvars) == dumper.represent_dict({"a": "b"})



# Generated at 2022-06-22 16:19:05.866409
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
   

# Generated at 2022-06-22 16:19:09.192556
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-22 16:19:18.857399
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'
    assert yaml.dump(AnsibleUnicode('foo\nbar'), Dumper=AnsibleDumper) == '|-\n  foo\n  bar\n'
    assert yaml.dump(AnsibleUnicode('foo\nbar\nbaz'), Dumper=AnsibleDumper) == '|-\n  foo\n  bar\n  baz\n'
    assert yaml.dump(AnsibleUnicode('foo\nbar\nbaz\n'), Dumper=AnsibleDumper) == '|-\n  foo\n  bar\n  baz\n'

# Generated at 2022-06-22 16:19:27.654298
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault.update({'vault_password_file': 'test/test_vault.txt'})
    vault.load()
    vault_text = vault.encrypt('test')
    vault_text = vault_text.replace('\n', '')
    vault_text = vault_text.replace('\r', '')
    vault_text = vault_text.replace('\t', '')
    vault_text = vault_text.replace(' ', '')
    vault_text = vault_text.replace('\x00', '')
    vault_text = vault_text.replace('\x01', '')
    vault_text = vault_text.replace('\x02', '')

# Generated at 2022-06-22 16:19:37.080430
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u"'foo'"
    assert dumper.represent_unicode(u'foo\nbar') == u"'foo\nbar'"
    assert dumper.represent_unicode(u'foo\u1234bar') == u"'foo\u1234bar'"
    assert dumper.represent_unicode(u'foo\u1234bar') == u"'foo\u1234bar'"
    assert dumper.represent_unicode(u'foo\u1234bar') == u"'foo\u1234bar'"
    assert dumper.represent_unicode(u'foo\u1234bar') == u"'foo\u1234bar'"

# Generated at 2022-06-22 16:19:42.381198
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-22 16:19:55.038924
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:20:05.720041
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault.update({'password': 'secret'})
    ciphertext = vault.encrypt('test')
    data = AnsibleVaultEncryptedUnicode(ciphertext)

# Generated at 2022-06-22 16:20:17.421385
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, u'foo') == u'foo'
    assert represent_unicode(None, u'foo\nbar') == u'foo\nbar'
    assert represent_unicode(None, u'foo\rbar') == u'foo\rbar'
    assert represent_unicode(None, u'foo\tbar') == u'foo\tbar'
    assert represent_unicode(None, u'foo\x00bar') == u'foo\x00bar'
    assert represent_unicode(None, u'foo\u1234bar') == u'foo\u1234bar'
    assert represent_unicode(None, u'foo\U00012345bar') == u'foo\U00012345bar'

# Generated at 2022-06-22 16:20:22.455203
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == u'!!binary |\n  Zm9v\n'
    assert dumper.represent_binary(b'foo\n') == u'!!binary |\n  Zm9vCg==\n'
    assert dumper.represent_binary(b'foo\n\n') == u'!!binary |\n  Zm9vCgo=\n'
    assert dumper.represent_binary(b'foo\n\n\n') == u'!!binary |\n  Zm9vCgoK\n'
    assert dumper.represent_binary(b'foo\n\n\n\n') == u'!!binary |\n  Zm9vCgoKCg==\n'

# Generated at 2022-06-22 16:20:34.231779
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.manager import VarsManager
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.template import Templar

    # Test for HostVars
    data = HostVars(hostname='testhost')
    data['var1'] = 'value1'
    data['var2'] = 'value2'
    data['var3'] = 'value3'
    data['var4'] = 'value4'
    data['var5'] = 'value5'

# Generated at 2022-06-22 16:20:40.143230
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, AnsibleUnicode(u'foo')) == yaml.representer.SafeRepresenter.represent_str(None, u'foo')
    assert represent_unicode(None, AnsibleUnicode(u'foo')) == yaml.representer.SafeRepresenter.represent_unicode(None, u'foo')
    assert represent_unicode(None, AnsibleUnicode(u'foo')) == yaml.representer.SafeRepresenter.represent_unicode(None, u'foo')



# Generated at 2022-06-22 16:20:41.861922
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == False

# Generated at 2022-06-22 16:20:44.511064
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    data = AnsibleUnicode('test')
    assert dumper.represent_unicode(dumper, data) == dumper.represent_str(dumper, text_type(data))



# Generated at 2022-06-22 16:20:55.120740
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:20:57.609328
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-22 16:21:07.917068
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault_text = vault.encrypt('test')
    encrypted_text = AnsibleVaultEncryptedUnicode(vault_text)

# Generated at 2022-06-22 16:21:18.697257
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault.update({'password': 'secret'})
    ciphertext = vault.encrypt('test')
    encrypted_unicode = AnsibleVaultEncryptedUnicode(ciphertext)

# Generated at 2022-06-22 16:21:23.941670
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) is False

# Generated at 2022-06-22 16:21:26.223597
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == False

# Generated at 2022-06-22 16:21:29.174276
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02') == u'!!binary |\n  AAEC\n'

# Generated at 2022-06-22 16:21:38.386905
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-22 16:21:44.465834
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:21:55.465923
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    vault = VaultLib([])

# Generated at 2022-06-22 16:21:57.099677
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined) is False

# Generated at 2022-06-22 16:22:05.529097
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:22:07.480898
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper.represent_undefined(AnsibleDumper, AnsibleUndefined()) == True

# Generated at 2022-06-22 16:22:19.056854
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    data = b'\x00\x01\x02\x03'
    result = dumper.represent_binary(dumper, data)
    assert result == '!!binary |\n  AAECAw==\n'

# Generated at 2022-06-22 16:22:22.580848
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, AnsibleUnicode('foo')) == represent_unicode(None, 'foo')
    assert represent_unicode(None, AnsibleUnicode('foo')) == yaml.representer.SafeRepresenter.represent_str(None, 'foo')
    assert represent_unicode(None, AnsibleUnicode('foo')) == yaml.representer.SafeRepresenter.represent_unicode(None, 'foo')



# Generated at 2022-06-22 16:22:34.478808
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, u'foo') == u'foo'
    assert represent_unicode(None, u'foo\nbar') == u'foo\nbar'
    assert represent_unicode(None, u'foo\u1234') == u'foo\u1234'
    assert represent_unicode(None, 'foo') == u'foo'
    assert represent_unicode(None, 'foo\nbar') == u'foo\nbar'
    assert represent_unicode(None, 'foo\u1234') == u'foo\u1234'
    assert represent_unicode(None, 'foo\x00bar') == u'foo\x00bar'

# Generated at 2022-06-22 16:22:42.171836
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars

    hv = HostVars({"a": "b"})
    assert yaml.dump(hv, Dumper=AnsibleDumper) == 'a: b\n'

    hvv = HostVarsVars({"a": "b"})
    assert yaml.dump(hvv, Dumper=AnsibleDumper) == 'a: b\n'

    vws = VarsWithSources({"a": "b"})
    assert yaml.dump(vws, Dumper=AnsibleDumper) == 'a: b\n'

# Generated at 2022-06-22 16:22:44.128381
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(u'foo', Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-22 16:22:54.765123
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:23:01.019131
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u"!ansible-unicode 'foo'"
    assert dumper.represent_unicode(u'foo\nbar') == u"!ansible-unicode |-\n  foo\n  bar"
    assert dumper.represent_unicode(u'foo\nbar\nbaz') == u"!ansible-unicode |-\n  foo\n  bar\n  baz"
    assert dumper.represent_unicode(u'foo\nbar\nbaz\n') == u"!ansible-unicode |-\n  foo\n  bar\n  baz\n  "

# Generated at 2022-06-22 16:23:09.534127
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import AnsibleUndefined

    hv = HostVars(dict(a=1, b=2, c=3))
    assert yaml.dump(hv, Dumper=AnsibleDumper) == '{a: 1, b: 2, c: 3}\n...\n'

    hvv = HostVarsVars(dict(a=1, b=2, c=3))

# Generated at 2022-06-22 16:23:16.988862
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:23:23.982058
# Unit test for function represent_binary
def test_represent_binary():
    # Test with a string
    assert yaml.dump(b'foo', Dumper=AnsibleDumper) == "!!binary |\n  Zm9v\n"

    # Test with a list
    assert yaml.dump([b'foo', b'bar'], Dumper=AnsibleDumper) == "- !!binary |\n    Zm9v\n- !!binary |\n    YmFy\n"

    # Test with a dict
    assert yaml.dump({'foo': b'bar'}, Dumper=AnsibleDumper) == "{foo: !!binary |\n    YmFy\n}"

# Generated at 2022-06-22 16:23:47.026443
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == "!!binary |\n  AAECAw==\n"

# Generated at 2022-06-22 16:23:51.912794
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    data = b'\x00\x01\x02\x03'
    result = dumper.represent_binary(dumper, data)
    assert result == '!!binary |\n  AAECA'

# Generated at 2022-06-22 16:24:02.757717
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v\n'
    assert dumper.represent_binary(dumper, b'foo\n') == u'!!binary |\n  Zm9vCg==\n'
    assert dumper.represent_binary(dumper, b'foo\nbar') == u'!!binary |\n  Zm9vCmJhcg==\n'
    assert dumper.represent_binary(dumper, b'foo\nbar\nbaz') == u'!!binary |\n  Zm9vCmJhcgpiYXo=\n'
    assert dumper.represent_binary(dumper, b'foo\nbar\nbaz\n') == u

# Generated at 2022-06-22 16:24:04.647861
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == "!!binary |\n  AAECAw==\n"

# Generated at 2022-06-22 16:24:10.506718
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v\n'
    assert dumper.represent_binary(dumper, b'foo\nbar') == u'!!binary |\n  Zm9vCmJhcg==\n'
    assert dumper.represent_binary(dumper, b'foo\nbar\n') == u'!!binary |\n  Zm9vCmJhcgo=\n'
    assert dumper.represent_binary(dumper, b'foo\nbar\n\n') == u'!!binary |\n  Zm9vCmJhcgoK\n'

# Generated at 2022-06-22 16:24:22.322587
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:24:24.046848
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01') == u'!!binary |\n  AAECA==\n'

# Generated at 2022-06-22 16:24:25.729102
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == u'!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:24:27.570198
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == u'!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:24:31.242145
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == "!!binary |\n  AAECAw==\n"

# Generated at 2022-06-22 16:25:02.974072
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02') == u'!!binary |\n  AAEC\n'

# Generated at 2022-06-22 16:25:12.936622
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:25:18.688123
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    # Test with bytes
    data = b'\x00\x01\x02\x03\x04'
    expected = "!!binary |\n  AAECAQQ="
    assert dumper.represent_binary(dumper, data) == expected
    # Test with bytearray
    data = bytearray(b'\x00\x01\x02\x03\x04')
    assert dumper.represent_binary(dumper, data) == expected

# Generated at 2022-06-22 16:25:29.779266
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:25:31.614533
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(b'foo', Dumper=AnsibleDumper) == '!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:25:37.377849
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:25:39.650514
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:25:44.723637
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == u"!binary |\n  Zm9v\n"
    assert dumper.represent_binary(b'foo\n') == u"!binary |\n  Zm9vCg==\n"

# Generated at 2022-06-22 16:25:50.851831
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v\n'
    assert dumper.represent_binary(dumper, b'foo\n') == u'!!binary |\n  Zm9vCg==\n'
    assert dumper.represent_binary(dumper, b'foo\nbar') == u'!!binary |\n  Zm9vCmJhcg==\n'
    assert dumper.represent_binary(dumper, b'foo\nbar\nbaz') == u'!!binary |\n  Zm9vCmJhcgpjYXo=\n'
    assert dumper.represent_binary(dumper, b'foo\nbar\nbaz\n') == u

# Generated at 2022-06-22 16:25:54.921332
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw=='