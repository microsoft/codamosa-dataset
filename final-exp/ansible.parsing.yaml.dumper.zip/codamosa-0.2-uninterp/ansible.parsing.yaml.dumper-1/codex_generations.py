

# Generated at 2022-06-22 16:17:05.227377
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.manager import VariableManager

    templar = Templar(loader=AnsibleLoader(None, variable_manager=VariableManager()))
    assert templar.template('{{ foo }}', dict(foo=AnsibleUndefined()), fail_on_undefined=True) == ''

    # This is the important test, that the dumper doesn't throw an exception
    # when it encounters an AnsibleUndefined object.
    assert yaml.dump(dict(foo=AnsibleUndefined()), Dumper=AnsibleDumper) == '{foo: null}\n'

# Generated at 2022-06-22 16:17:13.845191
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u'foo'
    assert dumper.represent_unicode(u'foo\nbar') == u'foo\nbar'
    assert dumper.represent_unicode(u'foo\tbar') == u'foo\tbar'
    assert dumper.represent_unicode(u'foo\x00bar') == u'foo\x00bar'
    assert dumper.represent_unicode(u'foo\u1234bar') == u'foo\u1234bar'
    assert dumper.represent_unicode(u'foo\U00012345bar') == u'foo\U00012345bar'

# Generated at 2022-06-22 16:17:24.798807
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

# Generated at 2022-06-22 16:17:34.227134
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    vault = VaultLib([])
    vault.password = 'secret'
    ciphertext = vault.encrypt('foo')
    encrypted_unicode = AnsibleVaultEncryptedUnicode(ciphertext)

# Generated at 2022-06-22 16:17:43.573519
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inv)
    host = inv.get_host('localhost')
    hostvars = HostVars(host, variable_manager)
    hostvars.set_variable('foo', 'bar')
    hostvars.set_variable('baz', 'qux')
    hostvars.set_variable('ansible_connection', 'local')
    hostvars.set_variable('ansible_host', 'localhost')
    hostvars.set_variable('ansible_user', 'root')
    host

# Generated at 2022-06-22 16:17:45.594884
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) is True

# Generated at 2022-06-22 16:17:53.275816
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-22 16:17:55.810569
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u"!binary |\n  Zm9v\n"

# Generated at 2022-06-22 16:17:59.941308
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03\x04') == u'!!binary |\n  AAECAwQF\n'

# Generated at 2022-06-22 16:18:01.850887
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper.represent_undefined(None, AnsibleUndefined()) == True

# Generated at 2022-06-22 16:18:14.387477
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import AnsibleUndefined

    h = HostVars()
    h.add_host_vars(host='host1', vars=dict(a=1, b=2))
    h.add_host_vars(host='host2', vars=dict(a=3, b=4))
    h.add_host_vars(host='host3', vars=dict(a=5, b=6))

    v = VarsWithSources(h)
    v.add_source(host='host1', source='file1', vars=dict(a=7, b=8))


# Generated at 2022-06-22 16:18:24.605566
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper(None)
    assert dumper.represent_unicode(u'foo') == u'foo'
    assert dumper.represent_unicode(u'foo\nbar') == u'foo\nbar'
    assert dumper.represent_unicode(u'foo\u1234bar') == u'foo\u1234bar'
    assert dumper.represent_unicode(u'foo\u00e9bar') == u'foo\u00e9bar'
    assert dumper.represent_unicode(u'foo\u00e9bar\n') == u'foo\u00e9bar\n'
    assert dumper.represent_unicode(u'foo\u00e9bar\n\n') == u'foo\u00e9bar\n\n'
    assert d

# Generated at 2022-06-22 16:18:33.287194
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u"'foo'"
    assert dumper.represent_unicode(u'foo\nbar') == u"'foo\\nbar'"
    assert dumper.represent_unicode(u'foo\tbar') == u"'foo\\tbar'"
    assert dumper.represent_unicode(u'foo\u1234bar') == u"'foo\\u1234bar'"
    assert dumper.represent_unicode(u'foo\u1234bar\n') == u"'foo\\u1234bar\\n'"
    assert dumper.represent_unicode(u'foo\u1234bar\t') == u"'foo\\u1234bar\\t'"

# Generated at 2022-06-22 16:18:37.864473
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper
    data = HostVars(dict(a=1, b=2))
    assert dumper.represent_hostvars(dumper, data) == dumper.represent_dict(dict(a=1, b=2))



# Generated at 2022-06-22 16:18:43.270819
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) is False

# Generated at 2022-06-22 16:18:51.539399
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

# Generated at 2022-06-22 16:19:00.445919
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    assert dumper.represent_unicode(dumper, u'foo') == u"'foo'"
    assert dumper.represent_unicode(dumper, u'foo\nbar') == u"'foo\\nbar'"
    assert dumper.represent_unicode(dumper, u'foo\tbar') == u"'foo\\tbar'"
    assert dumper.represent_unicode(dumper, u'foo\u2022bar') == u"'foo\\u2022bar'"
    assert dumper.represent_unicode(dumper, u'foo\u2022bar') == u"'foo\\u2022bar'"
    assert dumper.represent_unicode(dumper, u'foo\u2022bar') == u"'foo\\u2022bar'"

# Generated at 2022-06-22 16:19:02.847910
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw==\n'

# Generated at 2022-06-22 16:19:06.175985
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03\x04') == u'!!binary |\n  AAECAwQF\n'

# Generated at 2022-06-22 16:19:09.204747
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper) == 'null\n...\n'

# Generated at 2022-06-22 16:19:13.245864
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    assert dumper.represent_undefined(dumper, AnsibleUndefined) is False

# Generated at 2022-06-22 16:19:16.778284
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    data = b'\x00\x01\x02\x03'
    assert dumper.represent_binary(dumper, data) == u'!!binary |\n  AAECAw==\n'

# Generated at 2022-06-22 16:19:26.649663
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u'foo'
    assert dumper.represent_unicode(u'foo\nbar') == u'foo\nbar'
    assert dumper.represent_unicode(u'foo\nbar\n') == u'foo\nbar\n'
    assert dumper.represent_unicode(u'foo\nbar\n\n') == u'foo\nbar\n\n'
    assert dumper.represent_unicode(u'foo\nbar\n\n\n') == u'foo\nbar\n\n\n'

# Generated at 2022-06-22 16:19:34.770801
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert represent_hostvars(AnsibleDumper, HostVars({'a': 'b'})) == represent_hostvars(AnsibleDumper, {'a': 'b'})
    assert represent_hostvars(AnsibleDumper, HostVarsVars({'a': 'b'})) == represent_hostvars(AnsibleDumper, {'a': 'b'})
    assert represent_hostvars(AnsibleDumper, VarsWithSources({'a': 'b'})) == represent_hostvars(AnsibleDumper, {'a': 'b'})

# Generated at 2022-06-22 16:19:37.343572
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_data(AnsibleUndefined()) == 'null\n...\n'

# Generated at 2022-06-22 16:19:44.682124
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    data = HostVars({'a': 'b'})
    assert dumper.represent_hostvars(data) == dumper.represent_dict({'a': 'b'})



# Generated at 2022-06-22 16:19:55.108235
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v\n'
    assert dumper.represent_binary(dumper, b'foo\nbar') == u'!!binary |\n  Zm9vCmJhcg==\n'
    assert dumper.represent_binary(dumper, b'foo\nbar\n') == u'!!binary |\n  Zm9vCmJhcgo=\n'
    assert dumper.represent_binary(dumper, b'foo\nbar\n\n') == u'!!binary |\n  Zm9vCmJhcgoK\n'

# Generated at 2022-06-22 16:20:04.481807
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, u'foo') == u'foo'
    assert represent_unicode(None, u'foo\nbar') == u'foo\nbar'
    assert represent_unicode(None, u'foo\u1234') == u'foo\u1234'
    assert represent_unicode(None, u'foo\u1234\nbar') == u'foo\u1234\nbar'
    assert represent_unicode(None, u'foo\u1234\nbar\u4321') == u'foo\u1234\nbar\u4321'
    assert represent_unicode(None, u'foo\u1234\nbar\u4321\n') == u'foo\u1234\nbar\u4321\n'

# Generated at 2022-06-22 16:20:06.590529
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined) is True

# Generated at 2022-06-22 16:20:11.059514
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    data = {'a': 1, 'b': 2}
    hostvars = HostVars(data)
    assert dumper.represent_hostvars(hostvars) == dumper.represent_dict(data)



# Generated at 2022-06-22 16:20:18.238197
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x01\x02\x03\x04') == '!!binary |\n  AQIDBA==\n'

# Generated at 2022-06-22 16:20:26.757027
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v\n'
    assert dumper.represent_binary(dumper, b'foo\nbar') == u'!!binary |\n  Zm9vCmJhcg==\n'
    assert dumper.represent_binary(dumper, b'foo\nbar\nbaz') == u'!!binary |\n  Zm9vCmJhcgpiYXo=\n'
    assert dumper.represent_binary(dumper, b'foo\nbar\nbaz\n') == u'!!binary |\n  Zm9vCmJhcgpiYXoK\n'

# Generated at 2022-06-22 16:20:30.693940
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:20:39.409444
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources

    hv = HostVars(hostname='testhost')
    hv['foo'] = 'bar'
    hv['baz'] = 'qux'

    vws = VarsWithSources(hostname='testhost')
    vws['foo'] = 'bar'
    vws['baz'] = 'qux'

    for obj in [hv, vws]:
        assert isinstance(obj, AnsibleMapping)
        assert isinstance(obj, HostVars)
        assert isinstance(obj, VarsWithSources)

        data = yaml.dump(obj, Dumper=AnsibleDumper)


# Generated at 2022-06-22 16:20:48.577841
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault_text = vault.encrypt('test')
    encrypted_unicode = AnsibleVaultEncryptedUnicode(vault_text)

# Generated at 2022-06-22 16:20:51.725634
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02') == u'!!binary |\n  AAEC\n'



# Generated at 2022-06-22 16:21:01.156535
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'
    assert yaml.dump(AnsibleUnicode('foo\nbar'), Dumper=AnsibleDumper) == 'foo\nbar\n...\n'
    assert yaml.dump(AnsibleUnicode('foo\nbar\n'), Dumper=AnsibleDumper) == 'foo\nbar\n\n...\n'
    assert yaml.dump(AnsibleUnicode('foo\nbar\n\n'), Dumper=AnsibleDumper) == 'foo\nbar\n\n\n...\n'

# Generated at 2022-06-22 16:21:11.515727
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'
    assert yaml.dump(AnsibleUnicode('foo\nbar'), Dumper=AnsibleDumper) == '|-\n  foo\n  bar\n'
    assert yaml.dump(AnsibleUnicode('foo\nbar\nbaz'), Dumper=AnsibleDumper) == '|-\n  foo\n  bar\n  baz\n'
    assert yaml.dump(AnsibleUnicode('foo\nbar\nbaz\n'), Dumper=AnsibleDumper) == '|-\n  foo\n  bar\n  baz\n'

# Generated at 2022-06-22 16:21:14.030633
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw==\n'

# Generated at 2022-06-22 16:21:22.454454
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources

    dumper = AnsibleDumper
    data = HostVars(AnsibleMapping())
    assert dumper.represent_hostvars(dumper, data) == dumper.represent_dict(dict(data))

    data = HostVarsVars(AnsibleMapping())
    assert dumper.represent_hostvars(dumper, data) == dumper.represent_dict(dict(data))

    data = VarsWithSources(AnsibleMapping())
    assert dumper.represent_hostvars(dumper, data) == dumper.represent_dict(dict(data))

# Generated at 2022-06-22 16:21:35.294325
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == False

# Generated at 2022-06-22 16:21:42.733664
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw==\n'
    assert dumper.represent_binary(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\t\n\x0b\x0c\r\x0e\x0f') == u'!!binary |\n  AAECAwQFBgcICQoLDA0ODw==\n'

# Generated at 2022-06-22 16:21:44.882996
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == True

# Generated at 2022-06-22 16:21:50.372714
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_data(AnsibleUndefined) is False
    assert dumper.represent_data(AnsibleUndefined(fail_on_undefined=False)) is False
    assert dumper.represent_data(AnsibleUndefined(fail_on_undefined=True)) is False

# Generated at 2022-06-22 16:21:52.723169
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-22 16:21:56.639838
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_vault_encrypted_unicode(AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\n')) == '!vault |\n  $ANSIBLE_VAULT;1.1;AES256\n'

# Generated at 2022-06-22 16:22:04.522099
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.hostvars import HostVars, HostVarsVars

    data = {'a': 'b'}
    hostvars = HostVars(data)
    hostvarsvars = HostVarsVars(hostvars)

    yaml_data = yaml.dump(hostvarsvars, Dumper=AnsibleDumper, default_flow_style=False)
    assert yaml_data == 'a: b\n'

    yaml_data = yaml.dump(hostvars, Dumper=AnsibleDumper, default_flow_style=False)
    assert yaml_data == 'a: b\n'



# Generated at 2022-06-22 16:22:07.323334
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode(u'foo'), Dumper=AnsibleDumper) == u'foo\n...\n'



# Generated at 2022-06-22 16:22:14.902653
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader

    vault = VaultLib([])
    vault.password = 'test'
    ciphertext = vault.encrypt('test')
    encrypted = AnsibleVaultEncryptedUnicode(ciphertext)
    data = {'test': encrypted}
    yaml_data = yaml.dump(data, Dumper=AnsibleDumper, default_flow_style=False)

# Generated at 2022-06-22 16:22:23.405520
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    ciphertext = vault.encrypt(b'foo')
    encrypted_unicode = AnsibleVaultEncryptedUnicode(ciphertext)

# Generated at 2022-06-22 16:22:38.029859
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == False
    assert dumper.represent_undefined(AnsibleUndefined(fail_on_undefined=True)) == True

# Generated at 2022-06-22 16:22:40.763165
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    data = AnsibleUndefined
    assert dumper.represent_undefined(dumper, data) is False

# Generated at 2022-06-22 16:22:42.577684
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_data(AnsibleUndefined()) == dumper.represent_data(False)

# Generated at 2022-06-22 16:22:49.016695
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == '!!binary |\n  Zm9v\n'
    assert dumper.represent_binary(dumper, b'foo\n') == '!!binary |\n  Zm9vCg==\n'
    assert dumper.represent_binary(dumper, b'foo\nbar\nbaz\n') == '!!binary |\n  Zm9vCmJhcgoK\n'

# Generated at 2022-06-22 16:22:52.685628
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_vault_encrypted_unicode(AnsibleVaultEncryptedUnicode('test')) == u'!vault |\n          test\n'

# Generated at 2022-06-22 16:22:54.327517
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == False

# Generated at 2022-06-22 16:22:57.183305
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    assert dumper.represent_undefined(dumper, AnsibleUndefined()) == True

# Generated at 2022-06-22 16:23:06.253090
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.sources import DataSource
    from ansible.vars.sources import DataSourceVariable
    from ansible.vars.sources import DataSourceFact
    from ansible.vars.sources import DataSourceCache
    from ansible.vars.sources import DataSourceCommandLine
    from ansible.vars.sources import DataSourceInventory
    from ansible.vars.sources import DataSourceInventoryDirectory
    from ansible.vars.sources import DataSourceInventoryScript

# Generated at 2022-06-22 16:23:10.777704
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode(u'foo'), Dumper=AnsibleDumper) == u'foo\n...\n'



# Generated at 2022-06-22 16:23:13.374734
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw==\n'

# Generated at 2022-06-22 16:23:29.236987
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-22 16:23:31.525567
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == True

# Generated at 2022-06-22 16:23:32.727831
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == True

# Generated at 2022-06-22 16:23:43.571841
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-22 16:23:49.763820
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, u'foo') == u'foo'
    assert represent_unicode(None, u'foo\nbar') == u'foo\nbar'
    assert represent_unicode(None, u'foo\nbar\nbaz') == u'foo\nbar\nbaz'
    assert represent_unicode(None, u'foo\nbar\nbaz\n') == u'foo\nbar\nbaz\n'
    assert represent_unicode(None, u'foo\nbar\nbaz\n\n') == u'foo\nbar\nbaz\n\n'
    assert represent_unicode(None, u'foo\nbar\nbaz\n\n\n') == u'foo\nbar\nbaz\n\n\n'

# Generated at 2022-06-22 16:23:54.411628
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined())

# Generated at 2022-06-22 16:23:56.240729
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) is False

# Generated at 2022-06-22 16:24:05.342741
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsManager
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    h = HostVars(VarsManager())
    h.add_host_vars_from_inventory(dict(
        a=dict(b=dict(c=1)),
        d=dict(e=dict(f=2)),
    ))

    data = AnsibleMapping(h)
    result = yaml.dump(data, Dumper=AnsibleDumper)
    assert result == '{a: {b: {c: 1}}, d: {e: {f: 2}}}\n'

    # Test that the data is still valid Y

# Generated at 2022-06-22 16:24:07.096046
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_data(AnsibleUndefined) is False



# Generated at 2022-06-22 16:24:08.933605
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == "foo\n..."



# Generated at 2022-06-22 16:24:34.509827
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper.represent_undefined(None, AnsibleUndefined()) == True

# Generated at 2022-06-22 16:24:36.348356
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_data(AnsibleUndefined()) == dumper.represent_data(False)

# Generated at 2022-06-22 16:24:38.233501
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper(None)
    assert dumper.represent_undefined(AnsibleUndefined) == True

# Generated at 2022-06-22 16:24:51.005611
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-22 16:24:54.274475
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw==\n'

# Generated at 2022-06-22 16:24:55.406022
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper.represent_undefined(None, AnsibleUndefined) is False

# Generated at 2022-06-22 16:25:00.850316
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert represent_hostvars(None, HostVars(dict(a=1, b=2))) == represent_hostvars(None, dict(a=1, b=2))
    assert represent_hostvars(None, HostVarsVars(dict(a=1, b=2))) == represent_hostvars(None, dict(a=1, b=2))
    assert represent_hostvars(None, VarsWithSources(dict(a=1, b=2))) == represent_hostvars(None, dict(a=1, b=2))

# Generated at 2022-06-22 16:25:03.089764
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02') == u'!!binary |\n  AAEC\n'

# Generated at 2022-06-22 16:25:06.924063
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert represent_hostvars(AnsibleDumper, HostVars(dict(a=1, b=2))) == represent_hostvars(AnsibleDumper, dict(a=1, b=2))

# Generated at 2022-06-22 16:25:13.986479
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = HostVars(dict(a=1, b=2))
    assert yaml.dump(hostvars, Dumper=AnsibleDumper) == '{a: 1, b: 2}\n'



# Generated at 2022-06-22 16:26:02.351968
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, AnsibleUnicode(u'foo')) == yaml.representer.SafeRepresenter.represent_str(None, u'foo')
    assert represent_unicode(None, AnsibleUnsafeText(u'foo')) == yaml.representer.SafeRepresenter.represent_str(None, u'foo')
    assert represent_unicode(None, AnsibleUnsafeBytes(b'foo')) == yaml.representer.SafeRepresenter.represent_binary(None, b'foo')



# Generated at 2022-06-22 16:26:07.353493
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-22 16:26:09.631457
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper) == ''

# Generated at 2022-06-22 16:26:12.046875
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode(u'foo'), Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-22 16:26:20.101004
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    hv = HostVars(dict(a=1, b=2))
    hvv = HostVarsVars(dict(c=3, d=4))
    vws = VarsWithSources(dict(e=5, f=6))
    aus = AnsibleUnsafeText(u'unsafe')

    data = dict(
        hv=hv,
        hvv=hvv,
        vws=vws,
        aus=aus,
    )


# Generated at 2022-06-22 16:26:30.349626
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vault = VaultLib([])
    encrypted_text = vault.encrypt('test')
    encrypted_unicode = AnsibleVaultEncryptedUnicode(encrypted_text)

# Generated at 2022-06-22 16:26:33.006987
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = HostVars(host_vars=dict(a=1, b=2))
    assert yaml.dump(hostvars, Dumper=AnsibleDumper) == '{a: 1, b: 2}\n...\n'



# Generated at 2022-06-22 16:26:35.748548
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_data(AnsibleUndefined()) is None

# Generated at 2022-06-22 16:26:38.439743
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x01\x02\x03\x04') == u'!!binary |\n  AQIDBA==\n'

# Generated at 2022-06-22 16:26:48.720554
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.hostvars import HostVars

    # Create a hostvars object
    hv = HostVars(VariableManager())
    hv.add_host('testhost')
    hv.set_host_variable('testhost', 'foo', 'bar')

    # Create a yaml object
    yaml_obj = AnsibleMapping(hv)

    # Dump the yaml object
    yaml_dump = yaml.dump(yaml_obj, Dumper=AnsibleDumper)

    # Check the yaml object
    assert yaml_dump == '{foo: bar}\n'