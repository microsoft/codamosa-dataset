

# Generated at 2022-06-22 16:16:49.996914
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) is True

# Generated at 2022-06-22 16:16:51.678172
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) is False

# Generated at 2022-06-22 16:16:54.768388
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:17:06.156054
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    ciphertext = vault.encrypt(b'foo')
    data = AnsibleVaultEncryptedUnicode(ciphertext)

# Generated at 2022-06-22 16:17:07.959945
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper.represent_undefined(AnsibleDumper, AnsibleUndefined()) == True

# Generated at 2022-06-22 16:17:15.295962
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault.update({'password': 'secret'})
    encrypted_data = vault.encrypt('my secret')
    encrypted_unicode = AnsibleVaultEncryptedUnicode(encrypted_data)

# Generated at 2022-06-22 16:17:24.209514
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Test with a unicode string
    data = AnsibleVaultEncryptedUnicode(u'foo')
    assert represent_vault_encrypted_unicode(None, data) == u'!vault |\n          Zm9v\n'

    # Test with a byte string
    data = AnsibleVaultEncryptedUnicode(b'foo')
    assert represent_vault_encrypted_unicode(None, data) == u'!vault |\n          Zm9v\n'



# Generated at 2022-06-22 16:17:27.032873
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    data = HostVars(dict(a=1, b=2))
    assert dumper.represent_hostvars(data) == dumper.represent_dict(dict(a=1, b=2))



# Generated at 2022-06-22 16:17:37.378534
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    hostvars = HostVars()
    hostvars.add_host_vars(host='host1', variables={'var1': 'value1'})
    hostvars.add_host_vars(host='host2', variables={'var2': 'value2'})
    hostvars.add_host_vars(host='host3', variables={'var3': 'value3'})
    hostvars.add_host_vars(host='host4', variables={'var4': 'value4'})
    hostvars.add_host_vars(host='host5', variables={'var5': 'value5'})
    hostvars.add_host_vars(host='host6', variables={'var6': 'value6'})

# Generated at 2022-06-22 16:17:47.103289
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    assert dumper.represent_unicode(dumper, u'foo') == dumper.represent_str(dumper, 'foo')
    assert dumper.represent_unicode(dumper, u'foo') == dumper.represent_unicode(dumper, 'foo')
    assert dumper.represent_unicode(dumper, u'foo') == dumper.represent_unicode(dumper, u'foo')

# Generated at 2022-06-22 16:17:50.417078
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == False

# Generated at 2022-06-22 16:17:52.441253
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == dumper.represent_str(dumper, 'foo')

# Generated at 2022-06-22 16:17:55.638221
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03\x04') == u'!!binary |\n  AAECAwQF\n'

# Generated at 2022-06-22 16:17:59.306109
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == u'!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:18:10.759908
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    assert dumper.represent_unicode(dumper, u'foo') == u"!ansible-unicode 'foo'"
    assert dumper.represent_unicode(dumper, u'foo\nbar') == u"!ansible-unicode |-\n  foo\n  bar"
    assert dumper.represent_unicode(dumper, u'foo\nbar\n') == u"!ansible-unicode |-\n  foo\n  bar\n  "
    assert dumper.represent_unicode(dumper, u'foo\nbar\n\n') == u"!ansible-unicode |-\n  foo\n  bar\n  \n  "
    assert dumper.represent_unicode(dumper, u'foo\nbar\n\n\n')

# Generated at 2022-06-22 16:18:17.049496
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

# Generated at 2022-06-22 16:18:30.175965
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:18:34.248109
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert yaml.dump(HostVars(dict(a=1, b=2)), Dumper=AnsibleDumper) == '{a: 1, b: 2}\n...\n'



# Generated at 2022-06-22 16:18:43.941247
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper

# Generated at 2022-06-22 16:18:51.844009
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u'foo'
    assert dumper.represent_unicode(u'foo\nbar') == u'foo\nbar'
    assert dumper.represent_unicode(u'foo\u1234') == u'foo\u1234'
    assert dumper.represent_unicode(u'foo\u1234\nbar') == u'foo\u1234\nbar'
    assert dumper.represent_unicode(u'foo\u1234\nbar\u4321') == u'foo\u1234\nbar\u4321'

# Generated at 2022-06-22 16:19:02.919039
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    assert dumper.represent_unicode(dumper, u'foo') == u"!ansible-unicode 'foo'"
    assert dumper.represent_unicode(dumper, u'foo\nbar') == u"!ansible-unicode |\n  foo\n  bar"
    assert dumper.represent_unicode(dumper, u'foo\nbar\nbaz') == u"!ansible-unicode |\n  foo\n  bar\n  baz"
    assert dumper.represent_unicode(dumper, u'foo\nbar\nbaz\n') == u"!ansible-unicode |+\n  foo\n  bar\n  baz\n"

# Generated at 2022-06-22 16:19:08.963167
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper

# Generated at 2022-06-22 16:19:10.237257
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == False

# Generated at 2022-06-22 16:19:12.159493
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == False

# Generated at 2022-06-22 16:19:15.697986
# Unit test for function represent_unicode
def test_represent_unicode():
    '''
    Test that the representer works with unicode strings.
    '''
    assert yaml.dump(u'foo', Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-22 16:19:17.910210
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode(u'foo'), Dumper=AnsibleDumper) == u'foo\n...\n'



# Generated at 2022-06-22 16:19:19.851780
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode(u'foo'), Dumper=AnsibleDumper) == u'foo\n...\n'



# Generated at 2022-06-22 16:19:23.419617
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == False

# Generated at 2022-06-22 16:19:34.118482
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02') == u'!!binary |\n  AAEC\n'

# Generated at 2022-06-22 16:19:35.462839
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    data = AnsibleUndefined
    assert dumper.represent_undefined(dumper, data) is False

# Generated at 2022-06-22 16:19:42.792712
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == u'foo\n...\n'



# Generated at 2022-06-22 16:19:49.271529
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == u'!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:19:50.793219
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == False

# Generated at 2022-06-22 16:20:02.013063
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault.update({'password': 'secret'})
    vault.rekey()
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext)
    encrypted_unicode = AnsibleVaultEncryptedUnicode(ciphertext)

# Generated at 2022-06-22 16:20:13.351440
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

# Generated at 2022-06-22 16:20:19.737260
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw=='

# Generated at 2022-06-22 16:20:30.064518
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw==\n'
    assert dumper.represent_binary(b'\x00\x01\x02\x03\x04') == u'!!binary |\n  AAECAwQ=\n'
    assert dumper.represent_binary(b'\x00\x01\x02\x03\x04\x05') == u'!!binary |\n  AAECAwQF\n'
    assert dumper.represent_binary(b'\x00\x01\x02\x03\x04\x05\x06') == u'!!binary |\n  AAECAwQFBg==\n'

# Generated at 2022-06-22 16:20:39.728629
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import Templar
    from ansible.template.safe_eval import safe_eval

    templar = Templar(loader=None)
    data = templar.template("{{ foo }}", dict(foo=AnsibleUndefined), fail_on_undefined=False)
    assert data == ""

    data = templar.template("{{ foo }}", dict(foo=AnsibleUndefined), fail_on_undefined=True)
    assert data == ""

    data = templar.template("{{ foo }}", dict(foo=AnsibleUndefined), fail_on_undefined=True, convert_bare=False)
    assert data == ""

    data = templar.template("{{ foo }}", dict(foo=AnsibleUndefined), fail_on_undefined=True, convert_bare=True)
   

# Generated at 2022-06-22 16:20:47.096939
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault_str = vault.encrypt(b'foo')
    data = AnsibleVaultEncryptedUnicode(vault_str)

# Generated at 2022-06-22 16:20:57.304489
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault_text = vault.encrypt('test')
    vault_text = vault_text.replace('\n', '')
    vault_text = vault_text.replace('\r', '')
    vault_text = vault_text.replace('\t', '')
    vault_text = vault_text.replace(' ', '')
    vault_text = vault_text.replace('\x00', '')
    vault_text = vault_text.replace('\x01', '')
    vault_text = vault_text.replace('\x02', '')
    vault_text = vault_text.replace('\x03', '')
    vault_text = vault_text.replace('\x04', '')
    vault_text = vault_

# Generated at 2022-06-22 16:21:15.288690
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

# Generated at 2022-06-22 16:21:18.500237
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-22 16:21:30.064396
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # Test that represent_hostvars works with a HostVars object
    hostvars = HostVars(host_vars={'a': 'b'})
    assert yaml.dump(hostvars, Dumper=AnsibleDumper) == '{a: b}\n...\n'

    # Test that represent_hostvars works with a HostVarsVars object
    hostvarsvars = HostVarsVars(host_vars={'a': 'b'})
    assert yaml.dump(hostvarsvars, Dumper=AnsibleDumper) == '{a: b}\n...\n'

    # Test that represent_hostvars works with a VarsWithSources object
    varswithsources = VarsWithSources(host_vars={'a': 'b'})
    assert yaml

# Generated at 2022-06-22 16:21:33.060026
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECA\n'

# Generated at 2022-06-22 16:21:41.521471
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, u'foo') == u'foo'
    assert represent_unicode(None, u'foo\nbar') == u'foo\nbar'
    assert represent_unicode(None, u'foo\nbar\nbaz') == u'foo\nbar\nbaz'
    assert represent_unicode(None, u'foo\nbar\nbaz\n') == u'foo\nbar\nbaz\n'
    assert represent_unicode(None, u'foo\nbar\nbaz\n\n') == u'foo\nbar\nbaz\n\n'
    assert represent_unicode(None, u'foo\nbar\nbaz\n\n\n') == u'foo\nbar\nbaz\n\n\n'

# Generated at 2022-06-22 16:21:45.318904
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw==\n'

# Generated at 2022-06-22 16:21:47.807267
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == False

# Generated at 2022-06-22 16:21:52.738499
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert represent_hostvars(AnsibleDumper, HostVars(dict())) == represent_hostvars(AnsibleDumper, HostVarsVars(dict()))
    assert represent_hostvars(AnsibleDumper, HostVars(dict())) == represent_hostvars(AnsibleDumper, VarsWithSources(dict()))

# Generated at 2022-06-22 16:21:54.635066
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == False

# Generated at 2022-06-22 16:21:56.812335
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == True
    assert dumper.represent_undefined(AnsibleUndefined(var_name='foo')) == True

# Generated at 2022-06-22 16:22:17.877501
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-22 16:22:24.656255
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    hostvars = HostVars(
        dict(
            a=1,
            b=2,
            c=3,
            d=VarsWithSources(
                dict(
                    e=4,
                    f=5,
                    g=6,
                ),
                dict(
                    e=['a', 'b', 'c'],
                    f=['d', 'e', 'f'],
                    g=['g', 'h', 'i'],
                ),
            ),
            h=AnsibleUnsafeText('unsafe'),
        ),
    )


# Generated at 2022-06-22 16:22:27.965350
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02') == u'!!binary |\n  AAEC\n'

# Generated at 2022-06-22 16:22:29.838146
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == True

# Generated at 2022-06-22 16:22:32.975123
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-22 16:22:45.600855
# Unit test for function represent_unicode
def test_represent_unicode():
    # Test with a string
    data = 'test'
    result = represent_unicode(AnsibleDumper, data)
    assert result == "test"

    # Test with a unicode string
    data = u'test'
    result = represent_unicode(AnsibleDumper, data)
    assert result == "test"

    # Test with an AnsibleUnicode
    data = AnsibleUnicode('test')
    result = represent_unicode(AnsibleDumper, data)
    assert result == "test"

    # Test with an AnsibleUnsafeText
    data = AnsibleUnsafeText('test')
    result = represent_unicode(AnsibleDumper, data)
    assert result == "test"



# Generated at 2022-06-22 16:22:47.785041
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined) == True

# Generated at 2022-06-22 16:22:59.064824
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u'foo'
    assert dumper.represent_unicode(u'foo\nbar') == u'foo\nbar'
    assert dumper.represent_unicode(u'foo\tbar') == u'foo\tbar'
    assert dumper.represent_unicode(u'foo\x00bar') == u'foo\x00bar'
    assert dumper.represent_unicode(u'foo\u1234bar') == u'foo\u1234bar'
    assert dumper.represent_unicode(u'foo\u1234bar') == u'foo\u1234bar'
    assert dumper.represent_unicode(u'foo\u1234bar') == u'foo\u1234bar'

# Generated at 2022-06-22 16:23:00.921106
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) is False

# Generated at 2022-06-22 16:23:10.240868
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:23:54.412473
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) is False

# Generated at 2022-06-22 16:24:03.810173
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import VarsWithSources
    from ansible.vars.hostvars import HostVarsManager
    from ansible.vars.hostvars import HostVarsVarsManager
    from ansible.vars.hostvars import VarsWithSourcesManager

    # Test HostVars
    hv = HostVars(AnsibleMapping())
    hv['a'] = 'b'
    hv['c'] = 'd'
    hv['e'] = 'f'

# Generated at 2022-06-22 16:24:05.749757
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_data(AnsibleUndefined()) == dumper.represent_data(True)

# Generated at 2022-06-22 16:24:07.857230
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    assert dumper.represent_hostvars(HostVars(dict(a=1, b=2))) == dumper.represent_dict(dict(a=1, b=2))



# Generated at 2022-06-22 16:24:19.457582
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    vault = VaultLib([])
    ciphertext = vault.encrypt('test')

# Generated at 2022-06-22 16:24:23.023207
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert represent_hostvars(AnsibleDumper, HostVars(dict(a=1, b=2))) == represent_hostvars(AnsibleDumper, dict(a=1, b=2))



# Generated at 2022-06-22 16:24:23.998404
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) is False

# Generated at 2022-06-22 16:24:31.608041
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u'foo'
    assert dumper.represent_unicode(u'foo\nbar') == u'foo\nbar'
    assert dumper.represent_unicode(u'foo\nbar\nbaz') == u'foo\nbar\nbaz'
    assert dumper.represent_unicode(u'foo\nbar\nbaz\n') == u'foo\nbar\nbaz\n'
    assert dumper.represent_unicode(u'foo\nbar\nbaz\n\n') == u'foo\nbar\nbaz\n\n'

# Generated at 2022-06-22 16:24:39.982084
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x01\x02\x03') == u'!!binary |\n  AQID\n'
    assert dumper.represent_binary(b'\x01\x02\x03\x04') == u'!!binary |\n  AQIDBA==\n'
    assert dumper.represent_binary(b'\x01\x02\x03\x04\x05') == u'!!binary |\n  AQIDBAU=\n'
    assert dumper.represent_binary(b'\x01\x02\x03\x04\x05\x06') == u'!!binary |\n  AQIDBAUG\n'

# Generated at 2022-06-22 16:24:46.252567
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:26:18.686736
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.template import AnsibleUndefined
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # Test HostVars
    hv = HostVars()
    hv.add_host_vars(host='host1', variables=dict(a=1, b=2))
    hv.add_host_vars(host='host2', variables=dict(c=3, d=4))

# Generated at 2022-06-22 16:26:20.129048
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_data(AnsibleUndefined()) == dumper.represent_data(False)

# Generated at 2022-06-22 16:26:23.884078
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    data = HostVars(dict(a=1, b=2))
    assert dumper.represent_hostvars(data) == dumper.represent_dict(dict(a=1, b=2))



# Generated at 2022-06-22 16:26:33.006225
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v\n'
    assert dumper.represent_binary(dumper, b'foo\nbar') == u'!!binary |\n  Zm9vCmJhcg==\n'
    assert dumper.represent_binary(dumper, b'foo\nbar\nbaz') == u'!!binary |\n  Zm9vCmJhcgpiYXo=\n'
    assert dumper.represent_binary(dumper, b'foo\nbar\nbaz\n') == u'!!binary |\n  Zm9vCmJhcgpiYXoK\n'

# Generated at 2022-06-22 16:26:36.498123
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-22 16:26:47.940555
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault_text = vault.encrypt('test')
    vault_obj = AnsibleVaultEncryptedUnicode(vault_text)
    assert vault_obj._ciphertext == vault_text
    assert vault_obj._text is None
    assert vault_obj._decrypted is False
    assert vault_obj.decrypted is False
    assert vault_obj.ciphertext == vault_text
    assert vault_obj.text is None
    assert vault_obj.vault_id is None
    assert vault_obj.vault_version is None
    assert vault_obj.vault_checksum is None
    assert vault_obj.vault_blocksize is None
    assert vault_obj.vault_hmac is None
    assert vault_