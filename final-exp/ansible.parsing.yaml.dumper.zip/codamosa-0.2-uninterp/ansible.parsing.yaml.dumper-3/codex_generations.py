

# Generated at 2022-06-22 16:16:54.032989
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == False

# Generated at 2022-06-22 16:16:57.355341
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    data = b'\x00\x01'
    result = dumper.represent_binary(dumper, data)
    assert result == "!!binary |\n  AAEC\n"

# Generated at 2022-06-22 16:17:08.446296
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import wrap_var

    hv = HostVars({"foo": "bar"})
    hvv = HostVarsVars(hv, "foo")
    vws = VarsWithSources(hvv, "foo")
    vm = VariableManager()
    vm.set_host_variable(wrap_var(vws), "foo")

    dumper = AnsibleDumper()
    assert dumper.represent_hostvars(vm.get_vars()) == dumper.represent_dict({"foo": "bar"})

# Generated at 2022-06-22 16:17:10.449652
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    assert dumper.represent_undefined(dumper, AnsibleUndefined()) == False


# Generated at 2022-06-22 16:17:12.614899
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:17:19.086409
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper
    data = HostVars(dict(a=1, b=2))
    assert dumper.represent_hostvars(dumper, data) == dumper.represent_dict(dumper, dict(a=1, b=2))



# Generated at 2022-06-22 16:17:21.720028
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'

# Generated at 2022-06-22 16:17:30.401580
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw==\n'
    assert dumper.represent_binary(b'\x00\x01\x02\x03', style='>') == u'!!binary >\n  AAECAw==\n'
    assert dumper.represent_binary(b'\x00\x01\x02\x03', style='|') == u'!!binary |\n  AAECAw==\n'
    assert dumper.represent_binary(b'\x00\x01\x02\x03', style='"') == u'!!binary "\\x00\\x01\\x02\\x03"\n'
    assert dumper.represent_

# Generated at 2022-06-22 16:17:32.717832
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper) == 'null\n...\n'

# Generated at 2022-06-22 16:17:36.276544
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02') == u'!!binary |\n  AAEC\n'



# Generated at 2022-06-22 16:17:50.855144
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:18:02.530673
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, u'foo') == u'foo'
    assert represent_unicode(None, u'foo\nbar') == u'foo\nbar'
    assert represent_unicode(None, u'foo\nbar\nbaz') == u'foo\nbar\nbaz'
    assert represent_unicode(None, u'foo\nbar\nbaz\n') == u'foo\nbar\nbaz\n'
    assert represent_unicode(None, u'foo\nbar\nbaz\n\n') == u'foo\nbar\nbaz\n\n'
    assert represent_unicode(None, u'foo\nbar\nbaz\n\n\n') == u'foo\nbar\nbaz\n\n\n'

# Generated at 2022-06-22 16:18:04.803240
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper) == 'null\n...\n'

# Generated at 2022-06-22 16:18:15.117640
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-22 16:18:21.594760
# Unit test for function represent_binary
def test_represent_binary():
    # Test for python2
    if yaml.representer.SafeRepresenter.represent_binary.__module__ == 'yaml.representer':
        assert yaml.representer.SafeRepresenter.represent_binary(None, b'foo') == '!!binary |\n  Zm9v\n'
    # Test for python3
    else:
        assert yaml.representer.SafeRepresenter.represent_binary(None, b'foo') == '!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:18:25.473882
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == False
    assert dumper.represent_undefined(AnsibleUndefined(strict=False)) == False
    assert dumper.represent_undefined(AnsibleUndefined(strict=True)) == True

# Generated at 2022-06-22 16:18:29.765929
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    data = AnsibleUnsafeBytes(b'\x00\x01\x02\x03\x04')
    assert dumper.represent_binary(dumper, data) == "!!binary |\n  AAECAwQF\n"

# Generated at 2022-06-22 16:18:41.437791
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources

    hv = HostVars(hostname='testhost')
    hv['foo'] = 'bar'
    hv['baz'] = 'qux'

    hvv = HostVarsVars(hostname='testhost')
    hvv['foo'] = 'bar'
    hvv['baz'] = 'qux'

    vws = VarsWithSources(hostname='testhost')
    vws['foo'] = 'bar'
    vws['baz'] = 'qux'

    data = [hv, hvv, vws]


# Generated at 2022-06-22 16:18:50.813402
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:18:53.300773
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_data(AnsibleUndefined()) is False

# Generated at 2022-06-22 16:19:04.954820
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault_text = vault.encrypt('test')
    encrypted_text = AnsibleVaultEncryptedUnicode(vault_text)

# Generated at 2022-06-22 16:19:07.868939
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-22 16:19:17.990259
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, u'foo') == u'foo'
    assert represent_unicode(None, u'foo\nbar') == u'foo\nbar'
    assert represent_unicode(None, u'foo\nbar\nbaz') == u'foo\nbar\nbaz'
    assert represent_unicode(None, u'foo\nbar\nbaz\n') == u'foo\nbar\nbaz\n'
    assert represent_unicode(None, u'foo\nbar\nbaz\n\n') == u'foo\nbar\nbaz\n\n'
    assert represent_unicode(None, u'foo\nbar\nbaz\n\n\n') == u'foo\nbar\nbaz\n\n\n'

# Generated at 2022-06-22 16:19:22.516321
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == False

# Generated at 2022-06-22 16:19:33.436635
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-22 16:19:39.875013
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # Test with HostVars
    hostvars = HostVars(dict(a=1, b=2))
    assert yaml.dump(hostvars, Dumper=AnsibleDumper) == '{a: 1, b: 2}\n...\n'

    # Test with HostVarsVars
    hostvarsvars = HostVarsVars(dict(a=1, b=2))
    assert yaml.dump(hostvarsvars, Dumper=AnsibleDumper) == '{a: 1, b: 2}\n...\n'

    # Test with VarsWithSources
    varswithsources = VarsWithSources(dict(a=1, b=2))

# Generated at 2022-06-22 16:19:47.576766
# Unit test for function represent_unicode
def test_represent_unicode():
    '''
    Test the represent_unicode function.
    '''
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u"!ansible-unicode 'foo'"
    assert dumper.represent_unicode(u'foo\nbar') == u"!ansible-unicode |-\n  foo\n  bar"
    assert dumper.represent_unicode(u'foo\nbar\n') == u"!ansible-unicode |-\n  foo\n  bar\n  "
    assert dumper.represent_unicode(u'foo\nbar\n\n') == u"!ansible-unicode |-\n  foo\n  bar\n  \n  "



# Generated at 2022-06-22 16:19:51.132369
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) is False
    assert dumper.represent_undefined(AnsibleUndefined(strict=False)) is None

# Generated at 2022-06-22 16:19:53.667025
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) is False

# Generated at 2022-06-22 16:19:55.893020
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) is False

# Generated at 2022-06-22 16:20:06.717489
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-22 16:20:18.082287
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.template import AnsibleUndefined

    h = HostVars(dict(a=1, b=2))
    hv = HostVarsVars(dict(a=1, b=2))
    v = VarsWithSources(dict(a=1, b=2))
    u = AnsibleUnsafeText(u'foo')
    b = AnsibleUnsafeBytes(b'foo')
    ud = AnsibleUndefined()

    # Test Host

# Generated at 2022-06-22 16:20:21.265552
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    hostvars = HostVars({"foo": "bar"})
    assert yaml.dump(hostvars, Dumper=AnsibleDumper) == '{foo: bar}\n'

# Generated at 2022-06-22 16:20:23.589645
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode(u'foo'), Dumper=AnsibleDumper) == u'foo\n...\n'



# Generated at 2022-06-22 16:20:25.238706
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == True

# Generated at 2022-06-22 16:20:28.015003
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper.represent_undefined(None, AnsibleUndefined()) is False

# Generated at 2022-06-22 16:20:38.477152
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u"'foo'"
    assert dumper.represent_unicode(u'foo\nbar') == u"'foo\nbar'"
    assert dumper.represent_unicode(u'foo\u1234bar') == u"'foo\u1234bar'"
    assert dumper.represent_unicode(u'foo\u1234bar\n') == u"'foo\u1234bar\n'"
    assert dumper.represent_unicode(u'foo\u1234bar\n\n') == u"'foo\u1234bar\n\n'"
    assert dumper.represent_unicode(u'foo\u1234bar\n\n\n') == u"'foo\u1234bar\n\n\n'"

# Generated at 2022-06-22 16:20:42.546590
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    assert dumper.represent_undefined(dumper, AnsibleUndefined()) == True

# Generated at 2022-06-22 16:20:54.500262
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:21:04.599593
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:21:22.722484
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-22 16:21:24.398878
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03\x04') == u'!!binary |\n  AAECAwQF\n'



# Generated at 2022-06-22 16:21:30.695238
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars

    h = HostVars(dict(a=1, b=2))
    assert yaml.dump(h, Dumper=AnsibleDumper) == '{a: 1, b: 2}\n...\n'

    h = HostVarsVars(dict(a=1, b=2))
    assert yaml.dump(h, Dumper=AnsibleDumper) == '{a: 1, b: 2}\n...\n'

    h = VarsWithSources(dict(a=1, b=2))

# Generated at 2022-06-22 16:21:40.045104
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Create a host
    host = Host(name="test_host")
    host.vars = HostVarsVars(host=host)
    host.vars.update({"var1": "value1", "var2": "value2"})

    # Create a group

# Generated at 2022-06-22 16:21:47.816311
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()
    ciphertext = '$ANSIBLE_VAULT;1.1;AES256\n353737363336353935333436663737336435356537393737303535373534363533353737363336353935333436663737336435356537393737303535373534363533\n'
    data = AnsibleVaultEncryptedUnicode(ciphertext)
    result = dumper.represent_vault_encrypted_unicode(data)

# Generated at 2022-06-22 16:21:49.831858
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper.represent_undefined(AnsibleDumper, AnsibleUndefined())

# Generated at 2022-06-22 16:21:56.397221
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(AnsibleDumper, 'foo') == u'foo'
    assert represent_unicode(AnsibleDumper, u'foo') == u'foo'
    assert represent_unicode(AnsibleDumper, AnsibleUnicode('foo')) == u'foo'
    assert represent_unicode(AnsibleDumper, AnsibleUnsafeText('foo')) == u'foo'
    assert represent_unicode(AnsibleDumper, AnsibleUnsafeBytes('foo')) == u'foo'



# Generated at 2022-06-22 16:22:04.173106
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u'foo'
    assert dumper.represent_unicode(u'foo\nbar') == u'foo\nbar'
    assert dumper.represent_unicode(u'foo\nbar\n') == u'foo\nbar\n'
    assert dumper.represent_unicode(u'foo\nbar\n\n') == u'foo\nbar\n\n'
    assert dumper.represent_unicode(u'foo\nbar\n\n\n') == u'foo\nbar\n\n\n'

# Generated at 2022-06-22 16:22:06.066954
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == True

# Generated at 2022-06-22 16:22:13.732935
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(variable_manager, 'localhost')
    hostvars.update({'foo': 'bar'})
    hostvars.update({'baz': 'qux'})

    assert yaml.dump(hostvars, Dumper=AnsibleDumper) == '{foo: bar, baz: qux}\n'



# Generated at 2022-06-22 16:22:37.386538
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars

    hostvars = HostVars({"a": 1})
    hostvars_vars = HostVarsVars({"a": 1})
    vars_with_sources = VarsWithSources({"a": 1})

    assert yaml.dump(hostvars, Dumper=AnsibleDumper) == '{a: 1}\n'
    assert yaml.dump(hostvars_vars, Dumper=AnsibleDumper) == '{a: 1}\n'

# Generated at 2022-06-22 16:22:40.944943
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hv = HostVars(dict(foo='bar'))
    assert yaml.dump(hv, Dumper=AnsibleDumper) == '{foo: bar}\n...\n'



# Generated at 2022-06-22 16:22:42.426327
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) is False

# Generated at 2022-06-22 16:22:53.063342
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import AnsibleUndefined

    hostvars = HostVars(dict(a=1, b=2))
    assert yaml.dump(hostvars, Dumper=AnsibleDumper) == '{a: 1, b: 2}\n...\n'

    hostvars = HostVarsVars(dict(a=1, b=2))
    assert yaml.dump(hostvars, Dumper=AnsibleDumper) == '{a: 1, b: 2}\n...\n'

    hostv

# Generated at 2022-06-22 16:23:03.298578
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = HostVars()
    hostvars.add_host('host1')
    hostvars.add_host('host2')
    hostvars.set_variable('host1', 'var1', 'value1')
    hostvars.set_variable('host2', 'var2', 'value2')
    hostvars.set_variable('host2', 'var3', 'value3')
    hostvars.set_variable('host1', 'var4', 'value4')
    hostvars.set_variable('host1', 'var5', 'value5')


# Generated at 2022-06-22 16:23:11.096110
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

# Generated at 2022-06-22 16:23:14.155666
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01') == '!!binary |\n  AAEC\n'

# Generated at 2022-06-22 16:23:15.914058
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined) == False

# Generated at 2022-06-22 16:23:24.777358
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

# Generated at 2022-06-22 16:23:31.364784
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault_text = vault.encrypt('test')
    encrypted_text = AnsibleVaultEncryptedUnicode(vault_text)