

# Generated at 2022-06-22 16:17:00.823487
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper, default_flow_style=True) == '"foo"\n'
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper, default_flow_style=False) == 'foo\n...\n'
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper, default_flow_style=None) == 'foo\n...\n'

# Generated at 2022-06-22 16:17:04.536582
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw==\n'

# Generated at 2022-06-22 16:17:07.591983
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hv = HostVars({"foo": "bar"})
    assert yaml.dump(hv, Dumper=AnsibleDumper) == "foo: bar\n"



# Generated at 2022-06-22 16:17:15.095091
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u"'foo'"
    assert dumper.represent_unicode(u'foo\nbar') == u"'foo\nbar'"
    assert dumper.represent_unicode(u'foo\nbar\n') == u"'foo\nbar\n'"
    assert dumper.represent_unicode(u'foo\nbar\n\n') == u"'foo\nbar\n\n'"
    assert dumper.represent_unicode(u'foo\nbar\n\n\n') == u"'foo\nbar\n\n\n'"
    assert dumper.represent_unicode(u'foo\nbar\n\n\n\n') == u"'foo\nbar\n\n\n\n'"

# Generated at 2022-06-22 16:17:21.105549
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper) == 'null\n...\n'

# Generated at 2022-06-22 16:17:22.845431
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == True

# Generated at 2022-06-22 16:17:29.579262
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x01\x02\x03') == u'!!binary |\n  AQID'
    assert dumper.represent_binary(b'\x01\x02\x03', style='|') == u'!!binary |\n  AQID'
    assert dumper.represent_binary(b'\x01\x02\x03', style='>') == u'!!binary >\n  AQID'
    assert dumper.represent_binary(b'\x01\x02\x03', style='<') == u'!!binary <\n  AQID'
    assert dumper.represent_binary(b'\x01\x02\x03', style='-') == u'!!binary -\n  AQID'
    assert d

# Generated at 2022-06-22 16:17:39.831516
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()
    data = AnsibleVaultEncryptedUnicode(u'hello')

# Generated at 2022-06-22 16:17:44.419170
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-22 16:17:52.621847
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars

    hostvars = HostVars(dict(a=1, b=2))
    assert yaml.dump(hostvars, Dumper=AnsibleDumper) == '{a: 1, b: 2}\n...\n'

    hostvars = HostVarsVars(dict(a=1, b=2))
    assert yaml.dump(hostvars, Dumper=AnsibleDumper) == '{a: 1, b: 2}\n...\n'

    hostvars = VarsWithSources(dict(a=1, b=2))

# Generated at 2022-06-22 16:17:58.245844
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-22 16:18:01.418910
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    data = b'foo'
    assert dumper.represent_binary(data) == u'!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:18:03.716566
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper) == 'null\n...\n'

# Generated at 2022-06-22 16:18:05.614802
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == False

# Generated at 2022-06-22 16:18:08.888619
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw==\n'

# Generated at 2022-06-22 16:18:10.902727
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined) is False

# Generated at 2022-06-22 16:18:18.861001
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

# Generated at 2022-06-22 16:18:22.686898
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined) is False

# Generated at 2022-06-22 16:18:32.465124
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:18:35.822178
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == '!!binary |\n  AAECAw==\n'

# Generated at 2022-06-22 16:18:49.922344
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault.update({'password': 'password'})

# Generated at 2022-06-22 16:18:58.759802
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

# Generated at 2022-06-22 16:19:00.880477
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-22 16:19:03.502785
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    data = b'\x00\x01\x02\x03'
    expected = u'!!binary |\n  AAECAw==\n'
    assert dumper.represent_binary(dumper, data) == expected

# Generated at 2022-06-22 16:19:14.237951
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-22 16:19:16.968487
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode(u'foo'), Dumper=AnsibleDumper) == u'foo\n...\n'



# Generated at 2022-06-22 16:19:26.810387
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault_text = vault.encrypt('test')
    vault_text = vault_text.encode('utf-8')
    vault_text = vault_text.decode('utf-8')
    vault_text = AnsibleVaultEncryptedUnicode(vault_text)

# Generated at 2022-06-22 16:19:31.468607
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) is False
    assert dumper.represent_undefined(AnsibleUndefined(strict=False)) is False
    assert dumper.represent_undefined(AnsibleUndefined(strict=True)) is False

# Generated at 2022-06-22 16:19:33.058811
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined) is False

# Generated at 2022-06-22 16:19:38.164520
# Unit test for function represent_binary
def test_represent_binary():
    # Test for python2
    if yaml.representer.SafeRepresenter.represent_binary == represent_binary:
        assert yaml.dump(b'\x00\x01\x02\x03', Dumper=AnsibleDumper) == '!!binary |\n  AAECAw==\n'
    # Test for python3
    else:
        assert yaml.dump(b'\x00\x01\x02\x03', Dumper=AnsibleDumper) == '!!binary |\n  AAEBAQ==\n'

# Generated at 2022-06-22 16:19:46.357646
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host

    host = Host(name='testhost')
    variable_manager = VariableManager()
    variable_manager.set_host_variable(host, 'foo', 'bar')
    variable_manager.set_host_variable(host, 'baz', 'qux')

    hostvars = HostVars(host, variable_manager)

    assert yaml.dump(hostvars, Dumper=AnsibleDumper) == '{foo: bar, baz: qux}\n'



# Generated at 2022-06-22 16:19:55.364642
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

# Generated at 2022-06-22 16:20:02.187343
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-22 16:20:05.159495
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == False
    assert dumper.represent_undefined(AnsibleUndefined(strict=False)) == None

# Generated at 2022-06-22 16:20:08.121953
# Unit test for function represent_hostvars
def test_represent_hostvars():
    h = HostVars({"a": "b"})
    assert yaml.dump(h, Dumper=AnsibleDumper) == '{a: b}\n...\n'

# Generated at 2022-06-22 16:20:10.656581
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined())

# Generated at 2022-06-22 16:20:20.058298
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault_text = vault.encrypt('test')
    vault_text = vault_text.decode()
    vault_text = vault_text.replace('\n', '')
    vault_text = vault_text.replace('\r', '')
    vault_text = vault_text.replace('\t', '')
    vault_text = vault_text.replace(' ', '')
    vault_text = vault_text.replace('\x00', '')
    vault_text = vault_text.replace('\x01', '')
    vault_text = vault_text.replace('\x02', '')
    vault_text = vault_text.replace('\x03', '')

# Generated at 2022-06-22 16:20:30.428660
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == u'!!binary |\n  Zm9v\n'
    assert dumper.represent_binary(b'foo\nbar') == u'!!binary |\n  Zm9vCmJhcg==\n'
    assert dumper.represent_binary(b'foo\nbar\nbaz') == u'!!binary |\n  Zm9vCmJhcgpiYXo=\n'
    assert dumper.represent_binary(b'foo\nbar\nbaz\n') == u'!!binary |\n  Zm9vCmJhcgpiYXoK\n'
    assert dumper.represent_binary(b'foo\nbar\nbaz\n\n')

# Generated at 2022-06-22 16:20:38.546779
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)
    variable_manager.set_host_variable('localhost', 'foo', 'bar')
    hostvars = HostVars(variable_manager, 'localhost')
    assert yaml.dump(hostvars, Dumper=AnsibleDumper) == '{foo: bar}\n...\n'

# Generated at 2022-06-22 16:20:44.506576
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    data = AnsibleUndefined
    # Here bool will ensure _fail_with_undefined_error happens
    # if the value is Undefined.
    # This happens because Jinja sets __bool__ on StrictUndefined
    assert bool(data)
    assert dumper.represent_undefined(dumper, data) is True

# Generated at 2022-06-22 16:20:58.269137
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

# Generated at 2022-06-22 16:21:01.543251
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = {'a': 'b'}
    hostvars = HostVars(data)
    assert yaml.dump(hostvars, Dumper=AnsibleDumper) == '{a: b}\n...\n'



# Generated at 2022-06-22 16:21:11.675469
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import VarsWithSources

# Generated at 2022-06-22 16:21:18.253395
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault_text = vault.encrypt('test')
    vault_text = vault_text.replace('\n', '')
    vault_text = vault_text.replace('\r', '')
    vault_text = vault_text.replace('\t', '')
    vault_text = vault_text.replace(' ', '')
    vault_text = vault_text.replace('\\', '')
    vault_text = vault_text.replace('"', '')
    vault_text = vault_text.replace('\'', '')
    vault_text = vault_text.replace('\x00', '')
    vault_text = vault_text.replace('\x01', '')

# Generated at 2022-06-22 16:21:30.062603
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u"!ansible-unicode 'foo'"
    assert dumper.represent_unicode(u'foo\nbar') == u"!ansible-unicode |\n  foo\n  bar"
    assert dumper.represent_unicode(u'foo\nbar\nbaz') == u"!ansible-unicode |\n  foo\n  bar\n  baz"
    assert dumper.represent_unicode(u'foo\nbar\nbaz\n') == u"!ansible-unicode |\n  foo\n  bar\n  baz\n  "

# Generated at 2022-06-22 16:21:37.255459
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    hostvars = HostVars(variable_manager, 'localhost')
    hostvars.update({'foo': 'bar'})

    assert yaml.dump(hostvars, Dumper=AnsibleDumper) == '{foo: bar}\n'



# Generated at 2022-06-22 16:21:39.673323
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-22 16:21:43.622513
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined) is False

# Generated at 2022-06-22 16:21:51.621852
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault_text = vault.encrypt(b'foo')
    vault_text = vault_text.decode()
    data = AnsibleVaultEncryptedUnicode(vault_text)
    dumper = AnsibleDumper()
    result = dumper.represent_scalar(u'!vault', data._ciphertext.decode(), style='|')
    assert result == '!vault |\n          %s\n' % vault_text

# Generated at 2022-06-22 16:21:53.985365
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == u'!!binary |\n  Zm9v\n'
    assert dumper.represent_binary(b'foo\n') == u'!!binary |\n  Zm9vCg==\n'

# Generated at 2022-06-22 16:22:05.682598
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault.update({'password': 'secret'})
    ciphertext = vault.encrypt('test')
    encrypted_unicode = AnsibleVaultEncryptedUnicode(ciphertext)

# Generated at 2022-06-22 16:22:07.628613
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) is False

# Generated at 2022-06-22 16:22:15.067980
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources

    hv = HostVars()
    hv['a'] = 1
    hv['b'] = 2
    hv['c'] = 3
    hv['d'] = 4
    hv['e'] = 5
    hv['f'] = 6
    hv['g'] = 7
    hv['h'] = 8
    hv['i'] = 9
    hv['j'] = 10
    hv['k'] = 11
    hv['l'] = 12
    hv['m'] = 13
    hv['n'] = 14
    hv['o'] = 15
    hv['p'] = 16
    hv['q'] = 17
    hv['r']

# Generated at 2022-06-22 16:22:17.725121
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(b'foo', Dumper=AnsibleDumper) == "!!binary |\n  Zm9v\n"



# Generated at 2022-06-22 16:22:19.994708
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-22 16:22:25.460596
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources

    hv = HostVars(host_vars=dict(a=1, b=2))
    hv_vars = HostVarsVars(host_vars=dict(a=1, b=2))
    vws = VarsWithSources(host_vars=dict(a=1, b=2))


# Generated at 2022-06-22 16:22:36.246894
# Unit test for function represent_binary
def test_represent_binary():
    assert AnsibleDumper.represent_binary(b'\x00\x01') == u'!!binary |\n  AAEC\n'
    assert AnsibleDumper.represent_binary(b'\x00\x01', style='>') == u'!!binary >\n  AAEC\n'
    assert AnsibleDumper.represent_binary(b'\x00\x01', style='|') == u'!!binary |\n  AAEC\n'
    assert AnsibleDumper.represent_binary(b'\x00\x01', style='"') == u'!!binary "\\x00\\x01"\n'
    assert AnsibleDumper.represent_binary(b'\x00\x01', style="'") == u"!!binary '\\x00\\x01'\n"
    assert Ansible

# Generated at 2022-06-22 16:22:38.642679
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-22 16:22:48.549071
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources

    hostvars = HostVars()
    hostvars.add_host_vars(host='localhost', variables=dict(a=1, b=2, c=3))
    hostvars.add_host_vars(host='otherhost', variables=dict(a=1, b=2, c=3))
    hostvars.add_host_vars(host='otherhost', variables=dict(a=1, b=2, c=3))

    # Test with HostVars
    data = AnsibleMapping(hostvars)

# Generated at 2022-06-22 16:22:52.226233
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECA\n'

# Generated at 2022-06-22 16:23:10.104578
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECA\n'
    assert dumper.represent_binary(b'\x00\x01\x02\x03', style='>') == u'!!binary >\n  AAECA\n'
    assert dumper.represent_binary(b'\x00\x01\x02\x03', style='|') == u'!!binary |\n  AAECA\n'
    assert dumper.represent_binary(b'\x00\x01\x02\x03', style='"') == u'!!binary "\\x00\\x01\\x02\\x03"\n'

# Generated at 2022-06-22 16:23:20.284610
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars

    h = HostVars({"a": "b"})
    assert yaml.dump(h, Dumper=AnsibleDumper) == '{a: b}\n...\n'

    h = HostVarsVars({"a": "b"})
    assert yaml.dump(h, Dumper=AnsibleDumper) == '{a: b}\n...\n'

    h = VarsWithSources({"a": "b"})
    assert yaml.dump(h, Dumper=AnsibleDumper) == '{a: b}\n...\n'



# Generated at 2022-06-22 16:23:21.506241
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(b'foo', Dumper=AnsibleDumper) == '!!binary |\n  Zm9v\n'



# Generated at 2022-06-22 16:23:27.008443
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode(u'foo'), Dumper=AnsibleDumper) == u'foo\n...\n'
    assert yaml.dump(AnsibleUnicode(u'foo\nbar'), Dumper=AnsibleDumper) == u'|-\n  foo\n  bar\n'
    assert yaml.dump(AnsibleUnicode(u'foo\nbar\n'), Dumper=AnsibleDumper) == u'|-\n  foo\n  bar\n  \n'
    assert yaml.dump(AnsibleUnicode(u'foo\nbar\n\n'), Dumper=AnsibleDumper) == u'|-\n  foo\n  bar\n  \n  \n'

# Generated at 2022-06-22 16:23:29.876634
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw==\n'

# Generated at 2022-06-22 16:23:33.001962
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper.represent_undefined(AnsibleDumper, AnsibleUndefined()) is False
    assert AnsibleDumper.represent_undefined(AnsibleDumper, None) is True

# Generated at 2022-06-22 16:23:43.922674
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:23:46.471713
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    hostvars = HostVars({"foo": "bar"})
    assert dumper.represent_hostvars(hostvars) == dumper.represent_dict({"foo": "bar"})



# Generated at 2022-06-22 16:23:50.093948
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper
    assert dumper.represent_hostvars(dumper, HostVars(dict(a=1))) == dumper.represent_dict(dict(a=1))
    assert dumper.represent_hostvars(dumper, HostVarsVars(dict(a=1))) == dumper.represent_dict(dict(a=1))
    assert dumper.represent_hostvars(dumper, VarsWithSources(dict(a=1))) == dumper.represent_dict(dict(a=1))

# Generated at 2022-06-22 16:24:02.584441
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == u'!!binary |\n  Zm9v\n'
    assert dumper.represent_binary(b'foo\nbar') == u'!!binary |\n  Zm9vCmJhcg==\n'
    assert dumper.represent_binary(b'foo\nbar\nbaz') == u'!!binary |\n  Zm9vCmJhcgpiYXo=\n'
    assert dumper.represent_binary(b'foo\nbar\nbaz\n') == u'!!binary |\n  Zm9vCmJhcgpiYXoK\n'
    assert dumper.represent_binary(b'foo\nbar\nbaz\n\n')

# Generated at 2022-06-22 16:24:29.339300
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:24:35.652077
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02') == u'!!binary |\n  AAEC\n'

# Generated at 2022-06-22 16:24:40.256781
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, AnsibleUnicode('foo')) == yaml.representer.SafeRepresenter.represent_str(None, 'foo')
    assert represent_unicode(None, AnsibleUnsafeText('foo')) == yaml.representer.SafeRepresenter.represent_str(None, 'foo')
    assert represent_unicode(None, AnsibleUnsafeBytes('foo')) == yaml.representer.SafeRepresenter.represent_binary(None, b'foo')

# Generated at 2022-06-22 16:24:42.313525
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:24:51.364451
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:25:00.238234
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault_text = vault.encrypt('test')
    vault_text = vault_text.decode('utf-8')
    vault_text = vault_text.split('\n')
    vault_text = '\n'.join(vault_text[1:-1])
    vault_text = vault_text.replace('$ANSIBLE_VAULT;', '')
    vault_text = vault_text.replace(';', '')
    vault_text = vault_text.strip()
    vault_text = vault_text.encode('utf-8')
    vault_text = AnsibleVaultEncryptedUnicode(vault_text)

# Generated at 2022-06-22 16:25:06.265147
# Unit test for function represent_binary

# Generated at 2022-06-22 16:25:08.163111
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    assert dumper.represent_undefined(dumper, AnsibleUndefined()) == True

# Generated at 2022-06-22 16:25:13.749151
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw==\n'

# Generated at 2022-06-22 16:25:15.434193
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) is True

# Generated at 2022-06-22 16:26:02.001085
# Unit test for function represent_undefined
def test_represent_undefined():
    # Test with a value that is not undefined
    assert AnsibleDumper.represent_undefined(AnsibleDumper, 'foo') is True

    # Test with a value that is undefined
    assert AnsibleDumper.represent_undefined(AnsibleDumper, AnsibleUndefined) is False

# Generated at 2022-06-22 16:26:14.048501
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.sources import DataSource
    from ansible.vars.sources import DataSourceVariable
    from ansible.vars.sources import DataSourceFact
    from ansible.vars.sources import DataSourceCache
    from ansible.vars.sources import DataSourceCachePlugin
    from ansible.vars.sources import DataSourceCacheRole
    from ansible.vars.sources import DataSourceCacheFile
    from ansible.vars.sources import DataSourceCacheInventory

# Generated at 2022-06-22 16:26:15.741491
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined) == False

# Generated at 2022-06-22 16:26:17.397504
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined) is False

# Generated at 2022-06-22 16:26:22.384872
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v\n'
    assert dumper.represent_binary(dumper, b'foo\nbar') == u'!!binary |\n  Zm9vCmJhcg==\n'
    assert dumper.represent_binary(dumper, b'foo\nbar\n') == u'!!binary |\n  Zm9vCmJhcgo=\n'
    assert dumper.represent_binary(dumper, b'foo\nbar\nbaz') == u'!!binary |\n  Zm9vCmJhcgpiYXo=\n'

# Generated at 2022-06-22 16:26:32.240925
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault_text = vault.encrypt('test')
    encrypted_unicode = AnsibleVaultEncryptedUnicode(vault_text)

# Generated at 2022-06-22 16:26:35.707919
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == False

# Generated at 2022-06-22 16:26:47.221530
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u'foo'
    assert dumper.represent_unicode(u'foo\nbar') == u'foo\nbar'
    assert dumper.represent_unicode(u'foo\tbar') == u'foo\tbar'
    assert dumper.represent_unicode(u'foo\u1234bar') == u'foo\u1234bar'
    assert dumper.represent_unicode(u'foo\u1234bar') == u'foo\u1234bar'
    assert dumper.represent_unicode(u'foo\u1234bar') == u'foo\u1234bar'