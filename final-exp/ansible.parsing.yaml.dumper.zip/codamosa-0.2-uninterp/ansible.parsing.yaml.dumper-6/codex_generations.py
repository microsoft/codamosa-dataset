

# Generated at 2022-06-22 16:17:03.042645
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vault = VaultLib([])
    vault_text = vault.encrypt('test')
    assert isinstance(vault_text, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-22 16:17:12.650167
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u'foo'
    assert dumper.represent_unicode(u'foo\n') == u'foo\n'
    assert dumper.represent_unicode(u'foo\nbar') == u'foo\nbar'
    assert dumper.represent_unicode(u'foo\nbar\n') == u'foo\nbar\n'
    assert dumper.represent_unicode(u'foo\nbar\nbaz') == u'foo\nbar\nbaz'
    assert dumper.represent_unicode(u'foo\nbar\nbaz\n') == u'foo\nbar\nbaz\n'

# Generated at 2022-06-22 16:17:24.772115
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inv)
    variable_manager.set_host_variable('localhost', 'foo', 'bar')
    variable_manager.set_host_variable('localhost', 'baz', 'qux')
    variable_manager.set_host_variable('localhost', 'ansible_host', '127.0.0.1')
    variable_manager.set_host_variable('localhost', 'ansible_connection', 'local')
    variable_manager.set_host_variable('localhost', 'ansible_port', '22')

# Generated at 2022-06-22 16:17:27.289499
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    data = AnsibleUndefined
    result = dumper.represent_undefined(dumper, data)
    assert result is False

# Generated at 2022-06-22 16:17:29.605221
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == u'!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:17:39.872559
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault.decrypt = lambda x: x
    vault.encrypt = lambda x: x

# Generated at 2022-06-22 16:17:45.723549
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import AnsibleUndefined

    data = HostVars({"foo": "bar"})
    assert yaml.dump(data, Dumper=AnsibleDumper) == '{foo: bar}\n...\n'

    data = HostVarsVars({"foo": "bar"})
    assert yaml.dump(data, Dumper=AnsibleDumper) == '{foo: bar}\n...\n'

    data = VarsWithSources({"foo": "bar"})

# Generated at 2022-06-22 16:17:53.387163
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

# Generated at 2022-06-22 16:18:05.315187
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes

    # Test HostVars
    hv = HostVars(host_vars=dict(a=1, b=2))
    assert yaml.dump(hv, Dumper=AnsibleDumper) == '{a: 1, b: 2}\n...\n'

    # Test HostVarsVars
    hvv = HostVarsVars(host_vars=dict(a=1, b=2))

# Generated at 2022-06-22 16:18:07.005632
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == False

# Generated at 2022-06-22 16:18:17.945470
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources

    hv = HostVars(hostname='testhost')
    hv['foo'] = 'bar'
    hv['baz'] = 'qux'

    hvv = HostVarsVars(hostname='testhost')
    hvv['foo'] = 'bar'
    hvv['baz'] = 'qux'

    vws = VarsWithSources(hostname='testhost')
    vws['foo'] = 'bar'
    vws['baz'] = 'qux'

    data = [hv, hvv, vws]

# Generated at 2022-06-22 16:18:30.924152
# Unit test for function represent_binary

# Generated at 2022-06-22 16:18:34.680762
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02') == '!!binary |\n  AAEC\n'

# Generated at 2022-06-22 16:18:44.102469
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u"!ansible-unicode 'foo'"
    assert dumper.represent_unicode(u'foo\nbar') == u"!ansible-unicode |\n  foo\n  bar"
    assert dumper.represent_unicode(u'foo\nbar\n') == u"!ansible-unicode |\n  foo\n  bar\n"
    assert dumper.represent_unicode(u'foo\nbar\n\n') == u"!ansible-unicode |\n  foo\n  bar\n  \n"

# Generated at 2022-06-22 16:18:51.924061
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:19:00.501006
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes

    # Test HostVars
    hv = HostVars(host_name='localhost')
    hv['foo'] = 'bar'
    hv['baz'] = AnsibleUnsafeText('unsafe')
    hv['bin'] = AnsibleUnsafeBytes(b'unsafe')
    hv['vws'] = VarsWithSources(host_name='localhost')
    hv['vws']['foo'] = 'bar'

# Generated at 2022-06-22 16:19:03.466975
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == u'!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:19:14.196304
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    templar = Templar(loader=AnsibleLoader(None))

    data = HostVars(templar, 'localhost', {})
    data['foo'] = 'bar'
    data['baz'] = 1
    data['bam'] = True
    data['boo'] = False
    data['bop'] = None
    data['bup'] = AnsibleUndefined
    data['bip'] = AnsibleMapping()
    data['bap'] = AnsibleSequence()

# Generated at 2022-06-22 16:19:21.137752
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == "!!binary |\n  Zm9v\n"
    assert dumper.represent_binary(b'foo\nbar') == "!!binary |\n  Zm9vCmJhcg==\n"
    assert dumper.represent_binary(b'foo\nbar\n') == "!!binary |\n  Zm9vCmJhcgo=\n"
    assert dumper.represent_binary(b'foo\nbar\n\n') == "!!binary |\n  Zm9vCmJhcgoK\n"

# Generated at 2022-06-22 16:19:32.638304
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault_text = vault.encrypt('test')
    vault_text = vault_text.encode('utf-8')
    vault_text = vault_text.decode('utf-8')
    vault_text = AnsibleVaultEncryptedUnicode(vault_text)

# Generated at 2022-06-22 16:19:47.636113
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, u'foo') == u'foo'
    assert represent_unicode(None, u'foo\nbar') == u'foo\nbar'
    assert represent_unicode(None, u'foo\tbar') == u'foo\tbar'
    assert represent_unicode(None, u'foo\x00bar') == u'foo\x00bar'
    assert represent_unicode(None, u'foo\u1234bar') == u'foo\u1234bar'
    assert represent_unicode(None, u'foo\U00012345bar') == u'foo\U00012345bar'
    assert represent_unicode(None, u'foo\U00012345bar') == u'foo\U00012345bar'

# Generated at 2022-06-22 16:19:50.887709
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-22 16:20:02.105174
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault.update({'password': 'secret'})
    ciphertext = vault.encrypt('password')
    encrypted_unicode = AnsibleVaultEncryptedUnicode(ciphertext)

# Generated at 2022-06-22 16:20:13.529656
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper

# Generated at 2022-06-22 16:20:20.412554
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined(fail_on_undefined=False)) is False
    assert dumper.represent_undefined(AnsibleUndefined(fail_on_undefined=True)) is False

# Generated at 2022-06-22 16:20:23.513009
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    hostvars = HostVars({"a": "b"})
    assert dumper.represent_hostvars(hostvars) == dumper.represent_dict({"a": "b"})



# Generated at 2022-06-22 16:20:35.424541
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-22 16:20:38.261278
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == "!!binary |\n  AAECAw==\n"

# Generated at 2022-06-22 16:20:47.991887
# Unit test for function represent_unicode
def test_represent_unicode():
    # Test with a simple string
    assert represent_unicode(None, u'hello') == u'hello'

    # Test with a string that contains a non-ascii character
    assert represent_unicode(None, u'\u20ac') == u'\u20ac'

    # Test with a string that contains a non-ascii character
    assert represent_unicode(None, u'\u20ac') == u'\u20ac'

    # Test with a string that contains a non-ascii character
    assert represent_unicode(None, u'\u20ac') == u'\u20ac'

    # Test with a string that contains a non-ascii character
    assert represent_unicode(None, u'\u20ac') == u'\u20ac'

    # Test with a string that contains

# Generated at 2022-06-22 16:20:50.055342
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_data(AnsibleUndefined()) is False

# Generated at 2022-06-22 16:21:04.681974
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, u'foo') == u'foo'
    assert represent_unicode(None, u'foo\nbar') == u'foo\nbar'
    assert represent_unicode(None, u'foo\nbar\nbaz') == u'foo\nbar\nbaz'
    assert represent_unicode(None, u'foo\nbar\nbaz\n') == u'foo\nbar\nbaz\n'
    assert represent_unicode(None, u'foo\nbar\nbaz\n\n') == u'foo\nbar\nbaz\n\n'
    assert represent_unicode(None, u'foo\nbar\nbaz\n\n\n') == u'foo\nbar\nbaz\n\n\n'

# Generated at 2022-06-22 16:21:14.067089
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    ciphertext = vault.encrypt(b'foo')
    data = AnsibleVaultEncryptedUnicode(ciphertext)

# Generated at 2022-06-22 16:21:22.718690
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault.update({'vault_password_file': 'test/ansible/test_vault.txt'})
    vault_text = vault.encrypt('test')
    vault_text = vault_text.replace('$ANSIBLE_VAULT;', '!vault;')
    vault_text = vault_text.replace('\n', '\n\n')
    vault_text = vault_text.replace('\n\n', '\n')
    vault_text = vault_text.replace('\n', '\n\n')
    vault_text = vault_text.replace('\n\n', '\n')
    vault_text = vault_text.replace('\n', '\n\n')
    vault_text

# Generated at 2022-06-22 16:21:25.536611
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) is False

# Generated at 2022-06-22 16:21:35.449421
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import Templar
    templar = Templar(loader=None)
    templar.environment.undefined = AnsibleUndefined
    templar.environment.undefined_to_string = lambda x: 'foo'
    templar.environment.strict_undefined = False
    templar.environment.finalize = lambda x: x
    templar.environment.keep_trailing_newline = False
    templar.environment.trim_blocks = False
    templar.environment.lstrip_blocks = False
    templar.environment.newline_sequence = '\n'
    templar.environment.block_start_string = '{%'
    templar.environment.block_end_string = '%}'

# Generated at 2022-06-22 16:21:37.060675
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == False

# Generated at 2022-06-22 16:21:43.793017
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Create a dummy object
    class Dummy:
        def __init__(self, ciphertext):
            self._ciphertext = ciphertext

    # Create a dummy object

# Generated at 2022-06-22 16:21:55.004780
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafeVariable

    # Test HostVars
    hostvars = HostVars(hostname='testhost')
   

# Generated at 2022-06-22 16:21:56.394986
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined())

# Generated at 2022-06-22 16:21:59.698872
# Unit test for function represent_unicode
def test_represent_unicode():
    # Test that unicode strings are not converted to ascii
    # when dumped to yaml
    data = u'\u2603'
    yaml_data = yaml.dump(data, Dumper=AnsibleDumper)
    assert yaml_data == u'\u2603\n...\n'



# Generated at 2022-06-22 16:22:07.480642
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-22 16:22:14.998914
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'
    assert yaml.dump(AnsibleUnicode('foo\nbar'), Dumper=AnsibleDumper) == 'foo\nbar\n...\n'
    assert yaml.dump(AnsibleUnicode('foo\nbar\nbaz'), Dumper=AnsibleDumper) == '|-\n  foo\n  bar\n  baz\n...\n'
    assert yaml.dump(AnsibleUnicode('foo\nbar\nbaz\n'), Dumper=AnsibleDumper) == '|-\n  foo\n  bar\n  baz\n...\n'

# Generated at 2022-06-22 16:22:23.433347
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:22:27.054603
# Unit test for function represent_undefined
def test_represent_undefined():
    # Test for undefined value
    assert AnsibleDumper.represent_undefined(AnsibleDumper, AnsibleUndefined())

    # Test for defined value
    assert not AnsibleDumper.represent_undefined(AnsibleDumper, 'defined')

# Generated at 2022-06-22 16:22:37.056655
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'
    assert yaml.dump(AnsibleUnicode('foo\nbar'), Dumper=AnsibleDumper) == 'foo\nbar\n...\n'
    assert yaml.dump(AnsibleUnicode('foo\nbar\nbaz'), Dumper=AnsibleDumper) == '|-\n  foo\n  bar\n  baz\n...\n'
    assert yaml.dump(AnsibleUnicode('foo\nbar\nbaz\n'), Dumper=AnsibleDumper) == '|-\n  foo\n  bar\n  baz\n...\n'

# Generated at 2022-06-22 16:22:43.381989
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, u'foo') == u'foo'
    assert represent_unicode(None, u'foo\nbar') == u'foo\nbar'
    assert represent_unicode(None, u'foo\nbar\nbaz') == u'foo\nbar\nbaz'
    assert represent_unicode(None, u'foo\nbar\nbaz\n') == u'foo\nbar\nbaz\n'
    assert represent_unicode(None, u'foo\nbar\nbaz\n\n') == u'foo\nbar\nbaz\n\n'
    assert represent_unicode(None, u'foo\nbar\nbaz\n\n\n') == u'foo\nbar\nbaz\n\n\n'

# Generated at 2022-06-22 16:22:45.946336
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u"!binary |\n  Zm9v\n"

# Generated at 2022-06-22 16:22:54.573988
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == u'!!binary |\n  Zm9v\n'
    assert dumper.represent_binary(b'foo\n') == u'!!binary |\n  Zm9vCg==\n'
    assert dumper.represent_binary(b'foo\nbar') == u'!!binary |\n  Zm9vCmJhcg==\n'
    assert dumper.represent_binary(b'foo\nbar\n') == u'!!binary |\n  Zm9vCmJhcgo=\n'

# Generated at 2022-06-22 16:23:05.159118
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:23:15.372823
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u"!ansible-unicode 'foo'"
    assert dumper.represent_unicode(u'foo\nbar') == u"!ansible-unicode |\n  foo\n  bar"
    assert dumper.represent_unicode(u'foo\nbar\nbaz') == u"!ansible-unicode |\n  foo\n  bar\n  baz"
    assert dumper.represent_unicode(u'foo\nbar\nbaz\n') == u"!ansible-unicode |\n  foo\n  bar\n  baz\n  "

# Generated at 2022-06-22 16:23:35.525839
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:23:42.451578
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == "!!binary |\n  Zm9v\n"
    assert dumper.represent_binary(dumper, b'foo\nbar') == "!!binary |\n  Zm9vCmJhcg==\n"
    assert dumper.represent_binary(dumper, b'foo\nbar\nbaz') == "!!binary |\n  Zm9vCmJhcgpiYXo=\n"

# Generated at 2022-06-22 16:23:47.120517
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\t\n\x0b\x0c\r\x0e\x0f') == "!!binary |\n  AAECAwQFBgcICQoLDA0ODxAREhMUFRYXGBkaGxwdHh8="

# Generated at 2022-06-22 16:23:55.012995
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

# Generated at 2022-06-22 16:23:56.643471
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == False

# Generated at 2022-06-22 16:24:05.817810
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:24:10.031003
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == False
    assert dumper.represent_undefined(AnsibleUndefined(fail_on_undefined=False)) == False
    assert dumper.represent_undefined(AnsibleUndefined(fail_on_undefined=True)) == True

# Generated at 2022-06-22 16:24:13.884986
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == False

# Generated at 2022-06-22 16:24:23.472979
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    encrypted_data = vault.encrypt('test')
    encrypted_data = AnsibleVaultEncryptedUnicode(encrypted_data)

# Generated at 2022-06-22 16:24:30.436933
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    hv = HostVars(host_vars=dict(a=1, b=2))
    hvv = HostVarsVars(host_vars=dict(a=1, b=2))
    vws = VarsWithSources(host_vars=dict(a=1, b=2))

    for obj in [hv, hvv, vws]:
        yaml_str = yaml.dump(obj, Dumper=AnsibleDumper)


# Generated at 2022-06-22 16:25:07.255224
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-22 16:25:16.388711
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, u'foo') == u'foo'
    assert represent_unicode(None, u'foo\nbar') == u'foo\nbar'
    assert represent_unicode(None, u'foo\nbar\nbaz') == u'foo\nbar\nbaz'
    assert represent_unicode(None, u'foo\nbar\nbaz\n') == u'foo\nbar\nbaz\n'
    assert represent_unicode(None, u'foo\nbar\nbaz\n\n') == u'foo\nbar\nbaz\n\n'
    assert represent_unicode(None, u'foo\nbar\nbaz\n\n\n') == u'foo\nbar\nbaz\n\n\n'

# Generated at 2022-06-22 16:25:22.288966
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u"!ansible-unicode 'foo'"
    assert dumper.represent_unicode(u'foo\nbar') == u"!ansible-unicode |\n  foo\n  bar"
    assert dumper.represent_unicode(u'foo\nbar\nbaz') == u"!ansible-unicode |\n  foo\n  bar\n  baz"
    assert dumper.represent_unicode(u'foo\nbar\nbaz\n') == u"!ansible-unicode |\n  foo\n  bar\n  baz\n  "

# Generated at 2022-06-22 16:25:31.105867
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsManager
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.manager import VarsWithSources

    hostvars = HostVars(VarsManager())
    hostvars.add_host('host1')
    hostvars.set_host_variable('host1', 'var1', 'value1')
    hostvars.set_host_variable('host1', 'var2', 'value2')
    hostvars.set_host_variable('host1', 'var3', 'value3')
    hostvars.set_host_variable('host1', 'var4', 'value4')

# Generated at 2022-06-22 16:25:37.093366
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode(u'foo'), Dumper=AnsibleDumper) == 'foo\n...\n'
    assert yaml.dump(AnsibleUnicode(u'foo\nbar'), Dumper=AnsibleDumper) == '"foo\\nbar"\n'
    assert yaml.dump(AnsibleUnicode(u'foo\\bar'), Dumper=AnsibleDumper) == '"foo\\\\bar"\n'
    assert yaml.dump(AnsibleUnicode(u'foo"bar'), Dumper=AnsibleDumper) == '"foo\\"bar"\n'
    assert yaml.dump(AnsibleUnicode(u'foo\'bar'), Dumper=AnsibleDumper) == '"foo\'bar"\n'

# Generated at 2022-06-22 16:25:39.414561
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02') == u'!!binary |\n  AAEC\n'

# Generated at 2022-06-22 16:25:48.532541
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, u'foo') == u'foo'
    assert represent_unicode(None, u'foo\nbar') == u'foo\nbar'
    assert represent_unicode(None, u'foo\nbar\nbaz') == u'foo\nbar\nbaz'
    assert represent_unicode(None, u'foo\nbar\nbaz\n') == u'foo\nbar\nbaz\n'
    assert represent_unicode(None, u'foo\nbar\nbaz\n\n') == u'foo\nbar\nbaz\n\n'
    assert represent_unicode(None, u'foo\nbar\nbaz\n\n\n') == u'foo\nbar\nbaz\n\n\n'

# Generated at 2022-06-22 16:25:51.136683
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode(u'foo'), Dumper=AnsibleDumper) == u'foo\n...\n'



# Generated at 2022-06-22 16:25:59.577058
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources

    hv = HostVars({"a": 1, "b": 2})
    assert yaml.dump(hv, Dumper=AnsibleDumper) == '{a: 1, b: 2}\n...\n'

    hv = HostVars({"a": 1, "b": 2})
    hv.add_source("/path/to/file")
    assert yaml.dump(hv, Dumper=AnsibleDumper) == '{a: 1, b: 2}\n...\n'

    hv = HostVars({"a": 1, "b": 2})
    hv.add_source("/path/to/file")
    hv.add_source

# Generated at 2022-06-22 16:26:10.798077
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    host = Host(name='localhost')
    group = Group(name='group')
    group.add_host(host)
    inventory.add_group(group)
    inventory.add_host(host)

    variable_manager.set_host_variable(host, 'foo', 'bar')
    variable_manager.set_host_variable(host, 'baz', 'qux')

    host