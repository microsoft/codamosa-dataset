

# Generated at 2022-06-22 16:16:51.090006
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper
    data = HostVars(dict(a=1, b=2))
    assert dumper.represent_hostvars(dumper, data) == dumper.represent_dict(dict(a=1, b=2))



# Generated at 2022-06-22 16:17:03.042770
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:17:07.486745
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, AnsibleUnicode('foo')) == represent_unicode(None, 'foo')
    assert represent_unicode(None, AnsibleUnicode('foo')) == yaml.representer.SafeRepresenter.represent_str(None, 'foo')



# Generated at 2022-06-22 16:17:09.812651
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == u'!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:17:11.521297
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == True

# Generated at 2022-06-22 16:17:24.741935
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u'foo'
    assert dumper.represent_unicode(u'foo\nbar') == u'foo\nbar'
    assert dumper.represent_unicode(u'foo\x00bar') == u'foo\x00bar'
    assert dumper.represent_unicode(u'foo\x7fbar') == u'foo\x7fbar'
    assert dumper.represent_unicode(u'foo\x80bar') == u'foo\uFFFDbar'
    assert dumper.represent_unicode(u'foo\u20acbar') == u'foo\u20acbar'

# Generated at 2022-06-22 16:17:30.737826
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u'foo'
    assert dumper.represent_unicode(u'foo\nbar') == u'foo\nbar'
    assert dumper.represent_unicode(u'foo\u1234bar') == u'foo\u1234bar'
    assert dumper.represent_unicode(u'foo\u1234bar') == u'foo\u1234bar'
    assert dumper.represent_unicode(u'foo\u1234bar') == u'foo\u1234bar'
    assert dumper.represent_unicode(u'foo\u1234bar') == u'foo\u1234bar'

# Generated at 2022-06-22 16:17:33.116534
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02') == u'!!binary |\n  AAEC\n'

# Generated at 2022-06-22 16:17:42.806819
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsVars

    h = HostVars({"a": 1, "b": 2})
    hv = HostVarsVars(h)
    v = VarsWithSources(hv)

    d = AnsibleDumper()

# Generated at 2022-06-22 16:17:51.358152
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = {'a': 1, 'b': 2}
    hostvars = HostVars(data)
    result = yaml.dump(hostvars, Dumper=AnsibleDumper, default_flow_style=False)
    assert result == 'a: 1\nb: 2\n'

    # Test that we can load the data back
    new_hostvars = yaml.load(result, Loader=AnsibleLoader)
    assert new_hostvars == hostvars
    assert new_hostvars.data == hostvars.data



# Generated at 2022-06-22 16:17:55.132275
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) is False

# Generated at 2022-06-22 16:18:05.952592
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Test with a unicode string
    data = AnsibleVaultEncryptedUnicode(u'foo')
    assert represent_vault_encrypted_unicode(AnsibleDumper, data) == u'!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          666f6f0a\n'

    # Test with a byte string
    data = AnsibleVaultEncryptedUnicode(b'foo')
    assert represent_vault_encrypted_unicode(AnsibleDumper, data) == u'!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          666f6f0a\n'



# Generated at 2022-06-22 16:18:08.851332
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, AnsibleUnicode('foo')) == yaml.representer.SafeRepresenter.represent_str(None, 'foo')



# Generated at 2022-06-22 16:18:17.854559
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault.update({'vault_password_file': 'test/test_vault.txt'})
    vault_text = vault.encrypt('test')
    data = AnsibleVaultEncryptedUnicode(vault_text)

# Generated at 2022-06-22 16:18:30.842364
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault.update({'password': 'secret'})
    data = vault.encrypt('test')

# Generated at 2022-06-22 16:18:33.794733
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == True

# Generated at 2022-06-22 16:18:43.648848
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars

    h = HostVars({"a": "b"})
    assert yaml.dump(h, Dumper=AnsibleDumper) == '{a: b}\n...\n'

    h = HostVarsVars({"a": "b"})
    assert yaml.dump(h, Dumper=AnsibleDumper) == '{a: b}\n...\n'

    h = VarsWithSources({"a": "b"})
    assert yaml.dump(h, Dumper=AnsibleDumper) == '{a: b}\n...\n'



# Generated at 2022-06-22 16:18:51.709268
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:19:00.466056
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    encrypted_text = vault.encrypt('test')
    encrypted_unicode = AnsibleVaultEncryptedUnicode(encrypted_text)

# Generated at 2022-06-22 16:19:11.589618
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    ciphertext = vault.encrypt('test')
    encrypted_unicode = AnsibleVaultEncryptedUnicode(ciphertext)

# Generated at 2022-06-22 16:19:23.066082
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.template import AnsibleUndefined

    hv = HostVars(host_vars={'a': 'b'})
    hvv = HostVarsVars(host_vars={'a': 'b'})
    vws = VarsWithSources(host_vars={'a': 'b'})
    am = AnsibleMapping(host_vars={'a': 'b'})
    au = AnsibleUndefined()


# Generated at 2022-06-22 16:19:26.067620
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == u'!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:19:27.523285
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x01\x02\x03\x04') == u'!!binary |\n  AQIDBA==\n'

# Generated at 2022-06-22 16:19:30.306403
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper(None, None, None)
    assert dumper.represent_undefined(AnsibleUndefined) is False

# Generated at 2022-06-22 16:19:32.969869
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw==\n'

# Generated at 2022-06-22 16:19:33.849120
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined) == True

# Generated at 2022-06-22 16:19:40.082051
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v\n'
    assert dumper.represent_binary(dumper, b'foo\n') == u'!!binary |\n  Zm9vCg==\n'
    assert dumper.represent_binary(dumper, b'foo\nbar') == u'!!binary |\n  Zm9vCmJhcg==\n'
    assert dumper.represent_binary(dumper, b'foo\nbar\n') == u'!!binary |\n  Zm9vCmJhcgo=\n'

# Generated at 2022-06-22 16:19:42.226893
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper(None)
    assert dumper.represent_undefined(AnsibleUndefined()) is False

# Generated at 2022-06-22 16:19:52.139627
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u'foo'
    assert dumper.represent_unicode(u'foo\nbar') == u'foo\nbar'
    assert dumper.represent_unicode(u'foo\tbar') == u'foo\tbar'
    assert dumper.represent_unicode(u'foo\u1234bar') == u'foo\u1234bar'

# Generated at 2022-06-22 16:20:02.458876
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault.update({'password': 'secret'})
    data = vault.encrypt('test')

# Generated at 2022-06-22 16:20:12.615117
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw==\n'

# Generated at 2022-06-22 16:20:23.551520
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources

    hv = HostVars(hostname='localhost')
    hv['a'] = 1
    hv['b'] = 2
    hv['c'] = 3

    vws = VarsWithSources(hostname='localhost')
    vws['a'] = 1
    vws['b'] = 2
    vws['c'] = 3

    assert represent_hostvars(None, hv) == represent_hostvars(None, vws)

# Generated at 2022-06-22 16:20:35.469773
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(AnsibleDumper, 'test') == yaml.representer.SafeRepresenter.represent_str(AnsibleDumper, 'test')
    assert represent_unicode(AnsibleDumper, u'test') == yaml.representer.SafeRepresenter.represent_str(AnsibleDumper, 'test')
    assert represent_unicode(AnsibleDumper, AnsibleUnicode('test')) == yaml.representer.SafeRepresenter.represent_str(AnsibleDumper, 'test')
    assert represent_unicode(AnsibleDumper, AnsibleUnsafeText('test')) == yaml.representer.SafeRepresenter.represent_str(AnsibleDumper, 'test')
    assert represent_unicode(AnsibleDumper, AnsibleUnsafeBytes('test'))

# Generated at 2022-06-22 16:20:37.345143
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == True

# Generated at 2022-06-22 16:20:42.496334
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_data(AnsibleUndefined) is False

# Generated at 2022-06-22 16:20:54.500974
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources

    hv = HostVars(hostname='testhost')
    hv['testkey'] = 'testvalue'
    hv['testkey2'] = 'testvalue2'
    hv['testkey3'] = 'testvalue3'
    hv['testkey4'] = 'testvalue4'

    hv2 = HostVars(hostname='testhost2')
    hv2['testkey'] = 'testvalue'
    hv2['testkey2'] = 'testvalue2'
    hv2['testkey3'] = 'testvalue3'

# Generated at 2022-06-22 16:21:04.599483
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault.update({'vault_password_file': 'test/ansible/test_vault.txt'})
    vault_text = vault.encrypt('test')
    vault_text = vault_text.replace('\n', '')
    vault_text = vault_text.replace('\r', '')
    vault_text = vault_text.replace('\\', '\\\\')
    vault_text = vault_text.replace('"', '\\"')
    vault_text = vault_text.replace('\t', '\\t')
    vault_text = vault_text.replace('\b', '\\b')
    vault_text = vault_text.replace('\f', '\\f')

# Generated at 2022-06-22 16:21:06.644930
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper) == 'null\n...\n'

# Generated at 2022-06-22 16:21:15.527061
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u'foo'
    assert dumper.represent_unicode(u'foo\nbar') == u'foo\nbar'
    assert dumper.represent_unicode(u'foo\tbar') == u'foo\tbar'
    assert dumper.represent_unicode(u'foo\u1234bar') == u'foo\u1234bar'
    assert dumper.represent_unicode(u'foo\u1234\nbar') == u'foo\u1234\nbar'
    assert dumper.represent_unicode(u'foo\u1234\tbar') == u'foo\u1234\tbar'

# Generated at 2022-06-22 16:21:18.496888
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw==\n'

# Generated at 2022-06-22 16:21:38.145917
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault_text = vault.encrypt('test')
    encrypted_text = AnsibleVaultEncryptedUnicode(vault_text)

# Generated at 2022-06-22 16:21:44.364424
# Unit test for function represent_binary
def test_represent_binary():
    # Test that represent_binary works as expected
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == u'!!binary |\n  Zm9v\n'
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw==\n'
    assert dumper.represent_binary(b'\x00\x01\x02\x03\x04\x05\x06\x07') == u'!!binary |\n  AAECAwQFBgc=\n'

# Generated at 2022-06-22 16:21:55.388284
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars

    hv = HostVars({"a": "b"})
    hvv = HostVarsVars({"a": "b"})
    vws = VarsWithSources({"a": "b"})

    assert yaml.dump(hv, Dumper=AnsibleDumper) == '{a: b}\n...\n'
    assert yaml.dump(hvv, Dumper=AnsibleDumper) == '{a: b}\n...\n'
    assert yaml.dump(vws, Dumper=AnsibleDumper) == '{a: b}\n...\n'

# Generated at 2022-06-22 16:21:56.686885
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-22 16:22:04.779552
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == u'!!binary |\n  Zm9v\n'
    assert dumper.represent_binary(b'foo\n') == u'!!binary |\n  Zm9vCg==\n'
    assert dumper.represent_binary(b'foo\nbar') == u'!!binary |\n  Zm9vCmJhcg==\n'
    assert dumper.represent_binary(b'foo\nbar\n') == u'!!binary |\n  Zm9vCmJhcgo=\n'

# Generated at 2022-06-22 16:22:12.073576
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsManager
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.clean import strip_internal_keys

    data = HostVars(VarsManager())
    data['foo'] = wrap_var(u'bar')
    data['baz'] = wrap_var(u'qux')

    assert yaml.dump(data, Dumper=AnsibleDumper) == '{foo: bar, baz: qux}\n'



# Generated at 2022-06-22 16:22:18.131154
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes

    hostvars = HostVars({"a": 1, "b": 2})
    assert yaml.dump(hostvars, Dumper=AnsibleDumper) == "{a: 1, b: 2}\n"

    hostvars = HostVarsVars({"a": 1, "b": 2})
    assert yaml.dump(hostvars, Dumper=AnsibleDumper) == "{a: 1, b: 2}\n"

    hostvars

# Generated at 2022-06-22 16:22:19.558498
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper(width=1000)
    assert dumper.represent_undefined(AnsibleUndefined) == False

# Generated at 2022-06-22 16:22:23.786030
# Unit test for function represent_binary
def test_represent_binary():
    # Test for python3
    if hasattr(yaml, 'representer'):
        dumper = AnsibleDumper
        representer = yaml.representer.SafeRepresenter
    else:
        dumper = AnsibleDumper
        representer = yaml.representer.BaseRepresenter

    # Test for python2
    if hasattr(representer, 'represent_binary'):
        assert dumper.represent_binary(b'foo') == representer.represent_binary(dumper, b'foo')
    else:
        assert dumper.represent_binary(b'foo') == representer.represent_str(dumper, b'foo')

# Generated at 2022-06-22 16:22:34.930491
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars

    hv = HostVars({"a": 1})
    hvv = HostVarsVars({"a": 1})
    vws = VarsWithSources({"a": 1})

    assert yaml.dump(hv, Dumper=AnsibleDumper) == '{a: 1}\n...\n'
    assert yaml.dump(hvv, Dumper=AnsibleDumper) == '{a: 1}\n...\n'
    assert yaml.dump(vws, Dumper=AnsibleDumper) == '{a: 1}\n...\n'

# Generated at 2022-06-22 16:22:46.886272
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw==\n'

# Generated at 2022-06-22 16:22:49.613364
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw==\n'

# Generated at 2022-06-22 16:23:01.115399
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import AnsibleUndefined

    hostvars = HostVars({"a": 1, "b": 2})
    assert yaml.dump(hostvars, Dumper=AnsibleDumper) == '{a: 1, b: 2}\n...\n'

    hostvars = HostVarsVars({"a": 1, "b": 2})
    assert yaml.dump(hostvars, Dumper=AnsibleDumper) == '{a: 1, b: 2}\n...\n'

    hostv

# Generated at 2022-06-22 16:23:10.565080
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper

# Generated at 2022-06-22 16:23:17.503027
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == u"!binary |\n  Zm9v\n"
    assert dumper.represent_binary(b'foo\n') == u"!binary |\n  Zm9vCg==\n"
    assert dumper.represent_binary(b'foo\nbar') == u"!binary |\n  Zm9vCmJhcg==\n"
    assert dumper.represent_binary(b'foo\nbar\n') == u"!binary |\n  Zm9vCmJhcgo=\n"
    assert dumper.represent_binary(b'foo\nbar\nbaz') == u"!binary |\n  Zm9vCmJhcgpiYXo=\n"


# Generated at 2022-06-22 16:23:19.425552
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == "foo\n..."



# Generated at 2022-06-22 16:23:21.777642
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw==\n'



# Generated at 2022-06-22 16:23:23.728031
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper) == ''

# Generated at 2022-06-22 16:23:30.727498
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault_text = vault.encrypt('test')
    vault_text = vault_text.replace('\n', '')
    vault_text = vault_text.replace('\r', '')
    vault_text = vault_text.replace(' ', '')
    vault_text = vault_text.replace('\t', '')
    vault_text = vault_text.replace('\f', '')
    vault_text = vault_text.replace('\v', '')
    vault_text = vault_text.replace('\b', '')
    vault_text = vault_text.replace('\a', '')
    vault_text = vault_text.replace('\0', '')

# Generated at 2022-06-22 16:23:36.285627
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    hv = HostVars(host_vars=dict(a=1, b=2))
    hvv = HostVarsVars(host_vars=dict(a=1, b=2))
    vws = VarsWithSources(host_vars=dict(a=1, b=2))
    hv_unsafe = HostVars(host_vars=dict(a=AnsibleUnsafeText(u'a'), b=AnsibleUnsafeText(u'b')))
    hvv_unsafe = HostVarsV

# Generated at 2022-06-22 16:24:05.381461
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inv)
    host = inv.get_host('localhost')
    variable_manager.set_host_variable(host, 'foo', 'bar')
    variable_manager.set_host_variable(host, 'baz', 'qux')
    hostvars = HostVars(host, variable_manager)
    assert yaml.dump(hostvars, Dumper=AnsibleDumper) == '{foo: bar, baz: qux}\n'



# Generated at 2022-06-22 16:24:07.484384
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = {'a': 1, 'b': 2}
    dumper = AnsibleDumper()
    assert dumper.represent_hostvars(data) == dumper.represent_dict(data)

# Generated at 2022-06-22 16:24:10.449530
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw==\n'

# Generated at 2022-06-22 16:24:22.285090
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECA\n'
    assert dumper.represent_binary(b'\x00\x01\x02\x03', style='>') == u'!!binary >\n  AAECA\n'
    assert dumper.represent_binary(b'\x00\x01\x02\x03', style='|') == u'!!binary |\n  AAECA\n'
    assert dumper.represent_binary(b'\x00\x01\x02\x03', style='"') == u'!!binary "\\x00\\x01\\x02\\x03"\n'

# Generated at 2022-06-22 16:24:28.040022
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    hv = HostVars(dict(a=1, b=2))
    hv.add_source('test')
    hv.add_source('test2')
    hv.add_source('test3')
    hv.add_source('test4')
    hv.add_source('test5')
    hv.add_source('test6')
    hv.add_source('test7')
    hv.add_source('test8')
    hv.add_source('test9')
    hv.add_source('test10')
    hv.add_

# Generated at 2022-06-22 16:24:42.719332
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    secret = vault.encrypt('secret')
    assert secret.startswith('$ANSIBLE_VAULT;')
    assert secret.endswith('\n')
    assert secret.count('\n') == 1
    assert secret.count('\r') == 0
    assert secret.count('\r\n') == 0
    assert secret.count('\n\r') == 0
    assert secret.count('\r\n\r\n') == 0
    assert secret.count('\n\n') == 0
    assert secret.count('\r\r') == 0
    assert secret.count('\r\r\n') == 0
    assert secret.count('\n\r\r') == 0

# Generated at 2022-06-22 16:24:51.615512
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsManager
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.manager import VarsWithSources

    hv = HostVars(VarsManager())
    hv['a'] = 'b'
    hv['c'] = 'd'
    assert represent_hostvars(None, hv) == {'a': 'b', 'c': 'd'}

    hvv = HostVarsVars(VarsManager())
    hvv['a'] = 'b'
    hvv['c'] = 'd'
    assert represent_hostvars(None, hvv) == {'a': 'b', 'c': 'd'}

    vws = Vars

# Generated at 2022-06-22 16:24:54.565079
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:25:02.039795
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import AnsibleUndefined

    hv = HostVars(hostname='testhost')
    hv['test_key'] = 'test_value'
    hv['test_key2'] = AnsibleUnsafeText('test_value2')
    hv['test_key3'] = AnsibleUndefined()
    hv['test_key4'] = VarsWithSources()
    hv['test_key4']['test_key5'] = 'test_value5'
    hv['test_key4']['test_key6'] = AnsibleUnsafeText('test_value6')


# Generated at 2022-06-22 16:25:04.452561
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined())

# Generated at 2022-06-22 16:25:36.224127
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars
    from ansible.template import AnsibleUndefined

    hv = HostVars({"foo": "bar"})
    hvv = HostVarsVars({"foo": "bar"})
    vws = VarsWithSources({"foo": "bar"})

    assert yaml.dump(hv, Dumper=AnsibleDumper) == '{foo: bar}\n...\n'
    assert yaml.dump(hvv, Dumper=AnsibleDumper) == '{foo: bar}\n...\n'

# Generated at 2022-06-22 16:25:38.321005
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(b'foo', Dumper=AnsibleDumper) == 'foo\n...\n'

# Generated at 2022-06-22 16:25:47.885213
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:25:58.085505
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == u'!!binary |\n  Zm9v\n'
    assert dumper.represent_binary(b'foo\nbar') == u'!!binary |\n  Zm9vCmJhcg==\n'
    assert dumper.represent_binary(b'foo\nbar\nbaz') == u'!!binary |\n  Zm9vCmJhcgpiYXo=\n'
    assert dumper.represent_binary(b'foo\nbar\nbaz\n') == u'!!binary |\n  Zm9vCmJhcgpiYXoK\n'
    assert dumper.represent_binary(b'foo\nbar\nbaz\n\n')

# Generated at 2022-06-22 16:25:59.555686
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == False

# Generated at 2022-06-22 16:26:10.797794
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources

    h = HostVars()
    h.add_host_vars(host='host1', variables={'a': 1})
    h.add_host_vars(host='host2', variables={'b': 2})
    h.add_host_vars(host='host3', variables={'c': 3})

    d = AnsibleDumper()
    d.represent_hostvars(h)

    h = VarsWithSources()
    h.add_host_vars(host='host1', variables={'a': 1})

# Generated at 2022-06-22 16:26:19.387444
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.clean import clean_facts
    from ansible.module_utils.six import PY3

    if PY3:
        from io import StringIO
    else:
        from StringIO import StringIO

    h = HostVars()
    h.add_host_vars_from_inventory(dict(
        ansible_ssh_host='1.2.3.4',
        ansible_ssh_port=22,
        ansible_ssh_user='joe',
        ansible_ssh_pass='secret',
        ansible_sudo_pass='secret',
    ))

# Generated at 2022-06-22 16:26:25.230369
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.hostvars import HostVars

    hv = HostVars()
    hv['foo'] = 'bar'
    hv['baz'] = 'qux'

    assert yaml.dump(hv, Dumper=AnsibleDumper) == '{foo: bar, baz: qux}\n'



# Generated at 2022-06-22 16:26:33.642204
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00') == "!!binary |\n  AA==\n"
    assert dumper.represent_binary(b'\x00\x01') == "!!binary |\n  AAE=\n"
    assert dumper.represent_binary(b'\x00\x01\x02') == "!!binary |\n  AAEC\n"
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == "!!binary |\n  AAECAw==\n"
    assert dumper.represent_binary(b'\x00\x01\x02\x03\x04') == "!!binary |\n  AAECAwQ=\n"
    assert dumper.represent_binary

# Generated at 2022-06-22 16:26:44.521621
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources

    # Test with HostVars
    hv = HostVars()
    hv.add_host_vars('host1', dict(a='b'))
    hv.add_host_vars('host2', dict(c='d'))

    assert yaml.dump(hv, Dumper=AnsibleDumper) == '{host1: {a: b}, host2: {c: d}}\n'

    # Test with VarsWithSources
    vws = VarsWithSources()
    vws.add_host_vars('host1', dict(a='b'))
    vws.add_host_vars('host2', dict(c='d'))
