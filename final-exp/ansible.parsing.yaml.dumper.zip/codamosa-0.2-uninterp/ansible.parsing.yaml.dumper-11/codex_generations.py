

# Generated at 2022-06-22 16:17:03.033434
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, AnsibleUnicode('foo')) == yaml.representer.SafeRepresenter.represent_str(None, 'foo')
    assert represent_unicode(None, AnsibleUnsafeText('foo')) == yaml.representer.SafeRepresenter.represent_str(None, 'foo')
    assert represent_unicode(None, AnsibleUnsafeBytes('foo')) == yaml.representer.SafeRepresenter.represent_binary(None, b'foo')
    assert represent_unicode(None, 'foo') == yaml.representer.SafeRepresenter.represent_str(None, 'foo')
    assert represent_unicode(None, b'foo') == yaml.representer.SafeRepresenter.represent_binary(None, b'foo')



# Generated at 2022-06-22 16:17:05.861506
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02') == u'!!binary |\n  AAEC\n'

# Generated at 2022-06-22 16:17:14.192336
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

# Generated at 2022-06-22 16:17:19.938184
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

# Generated at 2022-06-22 16:17:22.351044
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined) is True

# Generated at 2022-06-22 16:17:23.847048
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_data(AnsibleUndefined()) is None

# Generated at 2022-06-22 16:17:26.179276
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw==\n'

# Generated at 2022-06-22 16:17:36.277429
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u"'foo'"
    assert dumper.represent_unicode(u'foo\nbar') == u"'foo\nbar'"
    assert dumper.represent_unicode(u'foo\x00bar') == u"'foo\x00bar'"
    assert dumper.represent_unicode(u'foo\u1234bar') == u"'foo\u1234bar'"
    assert dumper.represent_unicode(u'foo\u1234bar') == u"'foo\u1234bar'"
    assert dumper.represent_unicode(u'foo\u1234bar') == u"'foo\u1234bar'"

# Generated at 2022-06-22 16:17:43.573627
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v\n'
    assert dumper.represent_binary(dumper, b'foo\n') == u'!!binary |\n  Zm9vCg==\n'
    assert dumper.represent_binary(dumper, b'foo\nbar') == u'!!binary |\n  Zm9vCmJhcg==\n'
    assert dumper.represent_binary(dumper, b'foo\nbar\n') == u'!!binary |\n  Zm9vCmJhcgo=\n'

# Generated at 2022-06-22 16:17:46.836363
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    data = b'\x00\x01\x02\x03'
    result = dumper.represent_binary(dumper, data)
    assert result == "!!binary |\n  AAECAw==\n"

# Generated at 2022-06-22 16:17:50.854331
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode(u'foo'), Dumper=AnsibleDumper) == u'foo\n...\n'



# Generated at 2022-06-22 16:17:52.287707
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) is False

# Generated at 2022-06-22 16:17:54.309909
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper) == 'null\n'

# Generated at 2022-06-22 16:18:06.218596
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\t\n\x0b\x0c\r\x0e\x0f') == "!!binary |\n  AAECAwQFBgcICQoLDA0ODxAREhMUFRYXGBkaGxwdHh8="

# Generated at 2022-06-22 16:18:16.238493
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

# Generated at 2022-06-22 16:18:21.854907
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined(fail_on_undefined=True))
    assert dumper.represent_undefined(AnsibleUndefined(fail_on_undefined=False))

# Generated at 2022-06-22 16:18:24.975808
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == u'!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:18:28.206822
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECA\n'

# Generated at 2022-06-22 16:18:34.525351
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    hv = HostVars({"a": "b"})
    hvv = HostVarsVars({"a": "b"})
    vws = VarsWithSources({"a": "b"})
    aus = AnsibleUnsafeText("b")

    dumper = AnsibleDumper()
    assert dumper.represent_hostvars(hv) == dumper.represent_dict(dict(hv))
    assert dumper.represent_hostvars(hvv) == dumper.represent_dict(dict(hvv))
   

# Generated at 2022-06-22 16:18:37.462849
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper) == 'null\n...\n'

# Generated at 2022-06-22 16:18:47.813337
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars
    from ansible.template import AnsibleUndefined

    # Test HostVars
    hv = HostVars(host_vars={'a': 'b'})
    assert yaml.dump(hv, Dumper=AnsibleDumper) == '{a: b}\n'

    # Test HostVarsVars
    hvv = HostVarsVars(host_vars={'a': 'b'})
    assert yaml.dump(hvv, Dumper=AnsibleDumper) == '{a: b}\n'

    # Test VarsWithSources

# Generated at 2022-06-22 16:18:56.831183
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert represent_hostvars(None, HostVars({'a': 'b'})) == {'a': 'b'}
    assert represent_hostvars(None, HostVarsVars({'a': 'b'})) == {'a': 'b'}
    assert represent_hostvars(None, VarsWithSources({'a': 'b'})) == {'a': 'b'}

# Generated at 2022-06-22 16:18:59.256318
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-22 16:19:10.150970
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper

# Generated at 2022-06-22 16:19:12.041773
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_data(AnsibleUndefined()) is None

# Generated at 2022-06-22 16:19:20.729882
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()
    data = AnsibleVaultEncryptedUnicode('test')

# Generated at 2022-06-22 16:19:23.361281
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) is False

# Generated at 2022-06-22 16:19:25.471467
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) is False

# Generated at 2022-06-22 16:19:35.849494
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault.update({'password': 'secret'})
    plaintext = u'hello world'
    ciphertext = vault.encrypt(plaintext)
    encrypted = AnsibleVaultEncryptedUnicode(ciphertext)
    assert ciphertext == encrypted._ciphertext
    assert ciphertext != plaintext
    assert plaintext == vault.decrypt(ciphertext)
    assert plaintext != ciphertext
    assert plaintext == vault.decrypt(encrypted)
    assert plaintext != encrypted
    assert ciphertext == vault.decrypt(str(encrypted))
    assert ciphertext != str(encrypted)
    assert ciphertext == vault.decrypt(unicode(encrypted))
    assert ciphertext != unicode(encrypted)
    assert ciphertext == vault.dec

# Generated at 2022-06-22 16:19:46.844429
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault_text = vault.encrypt(u'foo')

# Generated at 2022-06-22 16:20:00.022247
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault.update({'vault_password_file': 'test/test_vault.py'})
    vault_text = vault.encrypt('test')

# Generated at 2022-06-22 16:20:06.944817
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v\n'
    assert dumper.represent_binary(dumper, b'foo\nbar') == u'!!binary |\n  Zm9vCmJhcg==\n'
    assert dumper.represent_binary(dumper, b'foo\nbar\nbaz') == u'!!binary |\n  Zm9vCmJhcgpiYXo=\n'
    assert dumper.represent_binary(dumper, b'foo\nbar\nbaz\n') == u'!!binary |\n  Zm9vCmJhcgpiYXoK\n'

# Generated at 2022-06-22 16:20:18.238792
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:20:26.755830
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper

# Generated at 2022-06-22 16:20:29.835904
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == True

# Generated at 2022-06-22 16:20:32.149954
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper) == 'False\n...\n'

# Generated at 2022-06-22 16:20:37.617734
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = {'a': 'b'}
    hostvars = HostVars(data)
    assert represent_hostvars(None, hostvars) == represent_hostvars(None, data)
    assert represent_hostvars(None, hostvars) == yaml.representer.SafeRepresenter.represent_dict(None, data)



# Generated at 2022-06-22 16:20:44.273404
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hv = HostVars()
    hv['foo'] = 'bar'
    hv['baz'] = 'qux'
    assert yaml.dump(hv, Dumper=AnsibleDumper) == '{foo: bar, baz: qux}\n'



# Generated at 2022-06-22 16:20:47.212666
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02') == u'!!binary |\n  AAEC\n'

# Generated at 2022-06-22 16:20:50.823675
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hv = HostVars(dict(foo='bar'))
    assert yaml.dump(hv, Dumper=AnsibleDumper) == '{foo: bar}\n...\n'



# Generated at 2022-06-22 16:21:03.256964
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

# Generated at 2022-06-22 16:21:13.059567
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault_text = vault.encrypt('test')
    encrypted_unicode = AnsibleVaultEncryptedUnicode(vault_text)

# Generated at 2022-06-22 16:21:22.610910
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, u'foo') == u'foo'
    assert represent_unicode(None, u'foo\nbar') == u'foo\nbar'
    assert represent_unicode(None, u'foo\nbar\nbaz') == u'foo\nbar\nbaz'
    assert represent_unicode(None, u'foo\nbar\nbaz\n') == u'foo\nbar\nbaz\n'
    assert represent_unicode(None, u'foo\nbar\nbaz\n\n') == u'foo\nbar\nbaz\n\n'
    assert represent_unicode(None, u'foo\nbar\nbaz\n\n\n') == u'foo\nbar\nbaz\n\n\n'

# Generated at 2022-06-22 16:21:26.709936
# Unit test for function represent_undefined
def test_represent_undefined():
    # Here bool will ensure _fail_with_undefined_error happens
    # if the value is Undefined.
    # This happens because Jinja sets __bool__ on StrictUndefined
    assert bool(AnsibleUndefined()) is True

# Generated at 2022-06-22 16:21:36.908973
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

# Generated at 2022-06-22 16:21:43.700919
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!binary |\n  Zm9v\n'
    assert dumper.represent_binary(dumper, b'foo\nbar') == u'!binary |\n  Zm9vCmJhcg==\n'
    assert dumper.represent_binary(dumper, b'foo\nbar\nbaz') == u'!binary |\n  Zm9vCmJhcgpiYXo=\n'
    assert dumper.represent_binary(dumper, b'foo\nbar\nbaz\n') == u'!binary |\n  Zm9vCmJhcgpiYXoK\n'

# Generated at 2022-06-22 16:21:54.898598
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    hostvars = HostVars()
    hostvars.add_host_vars(host='localhost', vars=dict(a=1, b=2))
    hostvars.add_host_vars(host='127.0.0.1', vars=dict(c=3, d=4))
    hostvars.add_host_vars(host='::1', vars=dict(e=5, f=6))

# Generated at 2022-06-22 16:21:56.331116
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == False

# Generated at 2022-06-22 16:21:57.460761
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == False

# Generated at 2022-06-22 16:22:05.990524
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

# Generated at 2022-06-22 16:22:11.967234
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_data(AnsibleUndefined()) is False

# Generated at 2022-06-22 16:22:14.148778
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = {'foo': 'bar'}
    assert represent_hostvars(None, data) == yaml.representer.SafeRepresenter.represent_dict(None, data)

# Generated at 2022-06-22 16:22:16.242147
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == True

# Generated at 2022-06-22 16:22:24.009637
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.manager import VariableManager

    data = {
        'foo': 'bar',
        'baz': 'qux',
    }

    hv = HostVars(data)
    hvv = HostVarsVars(hv, 'all')
    vm = VariableManager()
    vm.set_host_variable(hvv)

    # We need to use AnsibleLoader here because the data is not
    # a normal python dict.
    # We need to use AnsibleMapping here because the data is not
    # a normal python dict.
    # We need to use AnsibleDumper here because we have added a
    # representer for HostVars.

# Generated at 2022-06-22 16:22:35.446347
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

# Generated at 2022-06-22 16:22:42.870097
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u"!ansible-unicode 'foo'"
    assert dumper.represent_unicode(u'foo\nbar') == u"!ansible-unicode |-\n  foo\n  bar"
    assert dumper.represent_unicode(u'foo\nbar\nbaz') == u"!ansible-unicode |-\n  foo\n  bar\n  baz"
    assert dumper.represent_unicode(u'foo\nbar\nbaz\n') == u"!ansible-unicode |-\n  foo\n  bar\n  baz\n  "

# Generated at 2022-06-22 16:22:53.489732
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault_text = vault.encrypt('test')
    vault_obj = AnsibleVaultEncryptedUnicode(vault_text)
    assert vault_obj._ciphertext == vault_text
    assert vault_obj._text is None
    assert vault_obj._decrypted is False
    assert vault_obj._cipher is None
    assert vault_obj._version is None
    assert vault_obj._hmac is None
    assert vault_obj._chunk_size is None
    assert vault_obj._salt is None
    assert vault_obj._iv is None
    assert vault_obj._key is None
    assert vault_obj._hmac_key is None
    assert vault_obj._unlocked is False
    assert vault_obj._password

# Generated at 2022-06-22 16:23:03.617929
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources

    hv = HostVars(hostname='testhost')
    hv['foo'] = 'bar'
    hv['baz'] = 'qux'

    vws = VarsWithSources(hostname='testhost')
    vws['foo'] = 'bar'
    vws['baz'] = 'qux'

    hvv = HostVarsVars(hostname='testhost')
    hvv['foo'] = 'bar'
    hvv['baz'] = 'qux'

    for obj in [hv, vws, hvv]:
        assert isinstance(obj, AnsibleMapping)
       

# Generated at 2022-06-22 16:23:11.174046
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:23:12.997881
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_data(AnsibleUndefined) is False

# Generated at 2022-06-22 16:23:31.005690
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault.decrypt = lambda x: x
    vault.encrypt = lambda x: x
    data = AnsibleVaultEncryptedUnicode(vault, u'foo')
    assert yaml.dump(data, Dumper=AnsibleDumper) == u'!vault |\n  foo\n'

# Generated at 2022-06-22 16:23:36.392312
# Unit test for function represent_unicode
def test_represent_unicode():
    # Create a string with a non-ascii character
    test_string = u'\u00e9'
    # Create a yaml string with the non-ascii character
    yaml_string = u'\u00e9'
    # Create an AnsibleUnicode object with the non-ascii character
    ansible_unicode = AnsibleUnicode(test_string)
    # Create a yaml object with the non-ascii character
    yaml_unicode = yaml.representer.SafeRepresenter.represent_str(AnsibleDumper, yaml_string)
    # Create a yaml object with the AnsibleUnicode object
    ansible_unicode_yaml = AnsibleDumper.represent_unicode(ansible_unicode)
    # Compare the yaml objects
    assert ans

# Generated at 2022-06-22 16:23:37.944925
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined) is True

# Generated at 2022-06-22 16:23:40.445181
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(AnsibleDumper, AnsibleUnicode('foo')) == u"!ansible-unicode 'foo'"



# Generated at 2022-06-22 16:23:48.471890
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:23:52.075631
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, AnsibleUnicode('foo')) == yaml.representer.SafeRepresenter.represent_str(None, 'foo')


# Generated at 2022-06-22 16:23:56.009101
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    hostvars = HostVars(dict(a=1, b=2))
    assert dumper.represent_hostvars(hostvars) == dumper.represent_dict(dict(a=1, b=2))



# Generated at 2022-06-22 16:23:58.637443
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == u'!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:24:02.355982
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper
    data = HostVars({"a": "b"})
    assert dumper.represent_hostvars(dumper, data) == dumper.represent_dict(dumper, {"a": "b"})



# Generated at 2022-06-22 16:24:04.229259
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == "foo\n...\n"



# Generated at 2022-06-22 16:24:26.768033
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode(u'foo'), Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-22 16:24:32.070906
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, 'foo') == yaml.representer.SafeRepresenter.represent_str(None, 'foo')
    assert represent_unicode(None, u'foo') == yaml.representer.SafeRepresenter.represent_str(None, 'foo')
    assert represent_unicode(None, AnsibleUnicode('foo')) == yaml.representer.SafeRepresenter.represent_str(None, 'foo')
    assert represent_unicode(None, AnsibleUnsafeText('foo')) == yaml.representer.SafeRepresenter.represent_str(None, 'foo')
    assert represent_unicode(None, AnsibleUnsafeBytes('foo')) == yaml.representer.SafeRepresenter.represent_binary(None, b'foo')

# Generated at 2022-06-22 16:24:40.403679
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault.update({'password': 'secret'})
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext)
    encrypted_unicode = AnsibleVaultEncryptedUnicode(ciphertext)

# Generated at 2022-06-22 16:24:46.737380
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, AnsibleUnicode('foo')) == u'foo'
    assert represent_unicode(None, AnsibleUnicode(u'foo')) == u'foo'
    assert represent_unicode(None, AnsibleUnicode(u'foo')) == u'foo'
    assert represent_unicode(None, AnsibleUnicode(u'foo')) == u'foo'
    assert represent_unicode(None, AnsibleUnicode(u'foo')) == u'foo'
    assert represent_unicode(None, AnsibleUnicode(u'foo')) == u'foo'
    assert represent_unicode(None, AnsibleUnicode(u'foo')) == u'foo'

# Generated at 2022-06-22 16:24:57.722211
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault.update({'vault_password_file': 'test/test_vault.txt'})
    vault.load()
    data = vault.encrypt('test')

# Generated at 2022-06-22 16:25:03.883162
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars

    data = HostVars({"a": "b"})
    assert represent_hostvars(AnsibleDumper, data) == '{a: b}'

    data = HostVarsVars({"a": "b"})
    assert represent_hostvars(AnsibleDumper, data) == '{a: b}'

    data = VarsWithSources({"a": "b"})
    assert represent_hostvars(AnsibleDumper, data) == '{a: b}'

# Generated at 2022-06-22 16:25:13.454374
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault_text = vault.encrypt('test')
    vault_text = vault_text.replace('$ANSIBLE_VAULT;', '')
    vault_text = vault_text.replace('\n', '')
    vault_text = vault_text.replace('\r', '')
    vault_text = vault_text.replace('\t', '')
    vault_text = vault_text.replace(' ', '')
    vault_text = vault_text.replace('\x00', '')
    vault_text = vault_text.replace('\x01', '')
    vault_text = vault_text.replace('\x02', '')
    vault_text = vault_text.replace('\x03', '')
    vault_

# Generated at 2022-06-22 16:25:19.110582
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, AnsibleUnicode('foo')) == yaml.representer.SafeRepresenter.represent_str(None, 'foo')
    assert represent_unicode(None, AnsibleUnsafeText('foo')) == yaml.representer.SafeRepresenter.represent_str(None, 'foo')
    assert represent_unicode(None, AnsibleUnsafeBytes('foo')) == yaml.representer.SafeRepresenter.represent_binary(None, b'foo')



# Generated at 2022-06-22 16:25:22.742466
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x01\x02\x03') == u'!!binary |\n  AQID\n'

# Generated at 2022-06-22 16:25:26.701455
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined(fail_on_undefined=True)) is False
    assert dumper.represent_undefined(AnsibleUndefined(fail_on_undefined=False)) is True

# Generated at 2022-06-22 16:26:17.733958
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == u'foo\n...\n'
    assert yaml.dump(AnsibleUnicode('foo\nbar'), Dumper=AnsibleDumper) == u'|-\n  foo\n  bar\n'
    assert yaml.dump(AnsibleUnicode('foo\n\nbar'), Dumper=AnsibleDumper) == u'|-\n  foo\n\n  bar\n'
    assert yaml.dump(AnsibleUnicode('foo\n\n\nbar'), Dumper=AnsibleDumper) == u'|-\n  foo\n\n\n  bar\n'

# Generated at 2022-06-22 16:26:19.159928
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == True

# Generated at 2022-06-22 16:26:21.149787
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-22 16:26:31.353369
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault_text = vault.encrypt('test')
    vault_encrypted_unicode = AnsibleVaultEncryptedUnicode(vault_text)

# Generated at 2022-06-22 16:26:33.723762
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper.represent_undefined(None, AnsibleUndefined())

# Generated at 2022-06-22 16:26:36.635018
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02') == u'!!binary |\n  AAEC\n'

# Generated at 2022-06-22 16:26:38.207398
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) is False

# Generated at 2022-06-22 16:26:40.801808
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-22 16:26:50.145514
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault.update({'password': 'secret'})
    ciphertext = vault.encrypt('my secret')
    encrypted_unicode = AnsibleVaultEncryptedUnicode(ciphertext)
    dumper = AnsibleDumper()