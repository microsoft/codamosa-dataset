

# Generated at 2022-06-22 16:16:58.284236
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'
    assert yaml.dump(AnsibleUnicode('foo\nbar'), Dumper=AnsibleDumper) == 'foo\nbar\n...\n'
    assert yaml.dump(AnsibleUnicode('foo\nbar\nbaz'), Dumper=AnsibleDumper) == '|-\n  foo\n  bar\n  baz\n...\n'


# Generated at 2022-06-22 16:17:00.193442
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    assert dumper.represent_undefined(dumper, AnsibleUndefined()) == True

# Generated at 2022-06-22 16:17:10.961004
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw==\n'
    assert dumper.represent_binary(b'\x00\x01\x02\x03', style='>') == u'!!binary >\n  AAECAw==\n'
    assert dumper.represent_binary(b'\x00\x01\x02\x03', style='|') == u'!!binary |\n  AAECAw==\n'
    assert dumper.represent_binary(b'\x00\x01\x02\x03', style='"') == u'!!binary "\\x00\\x01\\x02\\x03"\n'
    assert dumper.represent_

# Generated at 2022-06-22 16:17:15.609032
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) is False

# Generated at 2022-06-22 16:17:25.284409
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources

    hv = HostVars(dict(a=1, b=2))
    hv2 = HostVars(dict(c=3, d=4))
    hv3 = HostVars(dict(e=5, f=6))
    hv4 = HostVars(dict(g=7, h=8))
    hv5 = HostVars(dict(i=9, j=10))
    hv6 = HostVars(dict(k=11, l=12))
    hv7 = HostVars(dict(m=13, n=14))

# Generated at 2022-06-22 16:17:26.607871
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) is False

# Generated at 2022-06-22 16:17:36.840370
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-22 16:17:39.188341
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = {'a': 1, 'b': 2}
    assert represent_hostvars(None, data) == yaml.representer.SafeRepresenter.represent_dict(None, data)

# Generated at 2022-06-22 16:17:43.203491
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_data(AnsibleUndefined) is False

# Generated at 2022-06-22 16:17:44.636017
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:17:52.531919
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources

    hv = HostVars({"a": 1, "b": 2})
    hvv = HostVarsVars({"a": 1, "b": 2})
    vws = VarsWithSources({"a": 1, "b": 2})

    assert represent_hostvars(None, hv) == represent_hostvars(None, hvv) == represent_hostvars(None, vws) == {'a': 1, 'b': 2}

# Generated at 2022-06-22 16:17:54.503812
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined) == False

# Generated at 2022-06-22 16:18:06.398744
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-22 16:18:09.976454
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    assert dumper.represent_undefined(dumper, AnsibleUndefined()) == True
    assert dumper.represent_undefined(dumper, 'foo') == False

# Generated at 2022-06-22 16:18:11.516141
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, AnsibleUnicode('foo')) == yaml.representer.SafeRepresenter.represent_str(None, 'foo')



# Generated at 2022-06-22 16:18:13.223602
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper.represent_undefined(AnsibleDumper, AnsibleUndefined()) == True

# Generated at 2022-06-22 16:18:18.500164
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    ciphertext = vault.encrypt(b"test")
    data = AnsibleVaultEncryptedUnicode(ciphertext)

# Generated at 2022-06-22 16:18:22.307257
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) is False

# Generated at 2022-06-22 16:18:32.300793
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'\x00\x01\x02\x03') == '!!binary |\n  AAECAw==\n'
    assert dumper.represent_binary(dumper, b'\x00\x01\x02\x03\x04') == '!!binary |\n  AAECAwQ=\n'
    assert dumper.represent_binary(dumper, b'\x00\x01\x02\x03\x04\x05') == '!!binary |\n  AAECAwQF\n'

# Generated at 2022-06-22 16:18:42.616355
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault.update({'vault_password_file': 'test/test_vault.txt'})
    vault_text = vault.encrypt('test')
    vault_encrypted_unicode = AnsibleVaultEncryptedUnicode(vault_text)
    assert vault_encrypted_unicode._ciphertext == vault_text
    assert vault_encrypted_unicode._text is None
    assert vault_encrypted_unicode._vault is None
    assert vault_encrypted_unicode._vault_password is None
    assert vault_encrypted_unicode._vault_password_file is None
    assert vault_encrypted_unicode._vault_ids is None
    assert vault_encrypted_unicode._vault_version is None
    assert vault_

# Generated at 2022-06-22 16:18:47.484646
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:18:49.518604
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(b'foo', Dumper=AnsibleDumper) == "!!binary |\n  Zm9v\n"



# Generated at 2022-06-22 16:18:51.843749
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-22 16:18:54.628624
# Unit test for function represent_unicode
def test_represent_unicode():
    data = AnsibleUnicode('foo')
    assert yaml.dump(data, Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-22 16:19:04.711812
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:19:08.060422
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = HostVars({"foo": "bar"})
    assert yaml.dump(hostvars, Dumper=AnsibleDumper) == '{foo: bar}\n...\n'



# Generated at 2022-06-22 16:19:18.067922
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-22 16:19:26.071491
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'
    assert yaml.dump(AnsibleUnicode('foo\nbar'), Dumper=AnsibleDumper) == 'foo\nbar\n...\n'
    assert yaml.dump(AnsibleUnicode('foo\nbar\nbaz'), Dumper=AnsibleDumper) == '|-\n  foo\n  bar\n  baz\n...\n'


# Generated at 2022-06-22 16:19:27.043925
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    assert dumper.represent_undefined(dumper, AnsibleUndefined) is False

# Generated at 2022-06-22 16:19:36.696552
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:19:47.687584
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u'foo'
    assert dumper.represent_unicode(u'foo\nbar') == u'foo\nbar'
    assert dumper.represent_unicode(u'foo\nbar\n') == u'foo\nbar\n'
    assert dumper.represent_unicode(u'foo\n\nbar\n') == u'foo\n\nbar\n'
    assert dumper.represent_unicode(u'foo\n\nbar') == u'foo\n\nbar'
    assert dumper.represent_unicode(u'foo\n\n\nbar') == u'foo\n\n\nbar'

# Generated at 2022-06-22 16:19:55.859210
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == 'foo\n...\n'
    assert yaml.dump(AnsibleUnicode('foo\nbar'), Dumper=AnsibleDumper) == 'foo\nbar\n...\n'
    assert yaml.dump(AnsibleUnicode('foo\nbar\n'), Dumper=AnsibleDumper) == 'foo\nbar\n\n...\n'
    assert yaml.dump(AnsibleUnicode('foo\nbar\n\n'), Dumper=AnsibleDumper) == 'foo\nbar\n\n\n...\n'

# Generated at 2022-06-22 16:20:04.668183
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault.update({'password': 'secret'})
    ciphertext = vault.encrypt('hello world')
    encrypted_unicode = AnsibleVaultEncryptedUnicode(ciphertext)

# Generated at 2022-06-22 16:20:08.395369
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hv = HostVars(dict(a=1, b=2))
    assert yaml.dump(hv, Dumper=AnsibleDumper) == '{a: 1, b: 2}\n...\n'



# Generated at 2022-06-22 16:20:19.265682
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v\n'
    assert dumper.represent_binary(dumper, b'foo\nbar') == u'!!binary |\n  Zm9vCmJhcg==\n'
    assert dumper.represent_binary(dumper, b'foo\nbar\n') == u'!!binary |\n  Zm9vCmJhcgo=\n'
    assert dumper.represent_binary(dumper, b'foo\nbar\n\n') == u'!!binary |\n  Zm9vCmJhcgoK\n'

# Generated at 2022-06-22 16:20:21.536642
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, AnsibleUnicode('foo')) == yaml.representer.SafeRepresenter.represent_str(None, 'foo')



# Generated at 2022-06-22 16:20:23.287287
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == True

# Generated at 2022-06-22 16:20:34.681179
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    from ansible.vars.hostvars import HostVarsVars

    hv = HostVars({"a": "b"})
    hvv = HostVarsVars(hv, "a")
    vws = VarsWithSources({"a": "b"}, [hvv])

    assert yaml.dump(hv, Dumper=AnsibleDumper) == "a: b\n"
    assert yaml.dump(hvv, Dumper=AnsibleDumper) == "b\n"
    assert yaml.dump(vws, Dumper=AnsibleDumper) == "a: b\n"

# Generated at 2022-06-22 16:20:42.890879
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, u'foo') == u'foo'
    assert represent_unicode(None, u'foo\nbar') == u'foo\nbar'
    assert represent_unicode(None, u'foo\u1234bar') == u'foo\u1234bar'
    assert represent_unicode(None, u'foo\u1234bar\n') == u'foo\u1234bar\n'
    assert represent_unicode(None, u'foo\u1234bar\n\n') == u'foo\u1234bar\n\n'
    assert represent_unicode(None, u'foo\u1234bar\n\n\n') == u'foo\u1234bar\n\n\n'

# Generated at 2022-06-22 16:20:54.621652
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v\n'
    assert dumper.represent_binary(dumper, b'foo\nbar') == u'!!binary |\n  Zm9vCmJhcg==\n'
    assert dumper.represent_binary(dumper, b'foo\x00bar') == u'!!binary |\n  Zm9vAGJhcg==\n'
    assert dumper.represent_binary(dumper, b'foo\x00bar\n') == u'!!binary |\n  Zm9vAGJhcg==\n'

# Generated at 2022-06-22 16:21:03.640737
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper
    data = HostVars({"test": "test"})
    assert dumper.represent_hostvars(dumper, data) == dumper.represent_dict(dumper, {"test": "test"})



# Generated at 2022-06-22 16:21:05.622029
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == True

# Generated at 2022-06-22 16:21:08.594363
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('test'), Dumper=AnsibleDumper) == 'test\n...\n'



# Generated at 2022-06-22 16:21:10.171253
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_data(AnsibleUndefined) is False

# Generated at 2022-06-22 16:21:17.346622
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u"!ansible-unicode 'foo'"
    assert dumper.represent_unicode(u'foo\nbar') == u"!ansible-unicode |\n  foo\n  bar"
    assert dumper.represent_unicode(u'foo\nbar\nbaz') == u"!ansible-unicode |\n  foo\n  bar\n  baz"
    assert dumper.represent_unicode(u'foo\nbar\nbaz\n') == u"!ansible-unicode |\n  foo\n  bar\n  baz\n  "

# Generated at 2022-06-22 16:21:30.063006
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:21:39.484708
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault_text = vault.encrypt('test')
    vault_text = vault_text.decode()
    encrypted_text = AnsibleVaultEncryptedUnicode(vault_text)
    assert encrypted_text._ciphertext == vault_text.encode()

# Generated at 2022-06-22 16:21:44.280633
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == u'!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:21:46.184562
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_data(AnsibleUndefined()) is None

# Generated at 2022-06-22 16:21:49.973981
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw==\n'

# Generated at 2022-06-22 16:22:01.721391
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('foo'), Dumper=AnsibleDumper) == "foo\n..."



# Generated at 2022-06-22 16:22:07.786926
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources

    hostvars = HostVars()
    hostvars.add_host('localhost', VarsWithSources({'a': 'b'}, [], [], []))

    assert yaml.dump(hostvars, Dumper=AnsibleDumper) == 'localhost:\n  a: b\n'



# Generated at 2022-06-22 16:22:15.089189
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault.update({'password': 'secret'})
    vault.rekey({'new_password': 'secret2'})
    ciphertext = vault.encrypt('hello world')
    encrypted_unicode = AnsibleVaultEncryptedUnicode(ciphertext)

# Generated at 2022-06-22 16:22:18.074638
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == '!!binary |\n  AAECAw==\n'

# Generated at 2022-06-22 16:22:19.698519
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined) == False

# Generated at 2022-06-22 16:22:21.237282
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == u"!ansible-unicode 'foo'"



# Generated at 2022-06-22 16:22:22.321342
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    assert dumper.represent_undefined(dumper, AnsibleUndefined) is False

# Generated at 2022-06-22 16:22:34.405171
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB


# Generated at 2022-06-22 16:22:46.745687
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault.update({'vault_password': 'vault_password'})
    vault_text = vault.encrypt('test')
    vault_encrypted_unicode = AnsibleVaultEncryptedUnicode(vault_text)

# Generated at 2022-06-22 16:22:51.097984
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined(fail_on_undefined=True)) is False
    assert dumper.represent_undefined(AnsibleUndefined(fail_on_undefined=False)) is True

# Generated at 2022-06-22 16:23:12.863838
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03\x04') == u'!!binary |\n  AAECAwQF\n'

# Generated at 2022-06-22 16:23:15.870930
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == dumper.represent_str(dumper, text_type('foo'))

# Generated at 2022-06-22 16:23:24.704870
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:23:31.326195
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

# Generated at 2022-06-22 16:23:41.252331
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    secret = vault.encrypt('secret')

# Generated at 2022-06-22 16:23:48.731467
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

# Generated at 2022-06-22 16:23:52.753729
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    data = b'\x00\x01\x02\x03'
    result = dumper.represent_binary(dumper, data)
    assert result == u'!!binary |\n  AAECA'

# Generated at 2022-06-22 16:24:02.793567
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == "!!binary |\n  Zm9v\n"
    assert dumper.represent_binary(dumper, b'foo\nbar') == "!!binary |\n  Zm9vCmJhcg==\n"
    assert dumper.represent_binary(dumper, b'foo\nbar\nbaz') == "!!binary |\n  Zm9vCmJhcgpiYXo=\n"
    assert dumper.represent_binary(dumper, b'foo\nbar\nbaz\n') == "!!binary |\n  Zm9vCmJhcgpiYXoK\n"

# Generated at 2022-06-22 16:24:04.675004
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw==\n'

# Generated at 2022-06-22 16:24:10.502286
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

# Generated at 2022-06-22 16:24:31.654069
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == u'!!binary |\n  Zm9v\n'
    assert dumper.represent_binary(b'foo\nbar') == u'!!binary |\n  Zm9vCmJhcg==\n'
    assert dumper.represent_binary(b'foo\nbar\nbaz') == u'!!binary |\n  Zm9vCmJhcgpiYXo=\n'
    assert dumper.represent_binary(b'foo\nbar\nbaz\n') == u'!!binary |\n  Zm9vCmJhcgpiYXoK\n'
    assert dumper.represent_binary(b'foo\nbar\nbaz\n\n')

# Generated at 2022-06-22 16:24:40.010763
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper

# Generated at 2022-06-22 16:24:42.014203
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u"!binary |\n  Zm9v\n"

# Generated at 2022-06-22 16:24:51.187311
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02') == u'!!binary |\n  AAEC\n'
    assert dumper.represent_binary(b'\x00\x01\x02', style='>') == u'!!binary >\n  AAEC\n'
    assert dumper.represent_binary(b'\x00\x01\x02', style='|') == u'!!binary |\n  AAEC\n'
    assert dumper.represent_binary(b'\x00\x01\x02', style='"') == u'!!binary "\\x00\\x01\\x02"\n'
    assert dumper.represent_binary(b'\x00\x01\x02', style='\'') == u

# Generated at 2022-06-22 16:24:54.160888
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == u'!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:25:01.522679
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'foo') == u'!!binary |\n  Zm9v\n'
    assert dumper.represent_binary(dumper, b'foo\nbar') == u'!!binary |\n  Zm9vCmJhcg==\n'
    assert dumper.represent_binary(dumper, b'foo\nbar\nbaz') == u'!!binary |\n  Zm9vCmJhcgpiYXo=\n'
    assert dumper.represent_binary(dumper, b'foo\nbar\nbaz\n') == u'!!binary |\n  Zm9vCmJhcgpiYXoK\n'

# Generated at 2022-06-22 16:25:12.409696
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

# Generated at 2022-06-22 16:25:17.471620
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault_str = vault.encrypt('test')
    vault_obj = AnsibleVaultEncryptedUnicode(vault_str)

# Generated at 2022-06-22 16:25:23.081778
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault.update({'password': 'secret'})
    plaintext = u'hello world'
    ciphertext = vault.encrypt(plaintext)
    encrypted_unicode = AnsibleVaultEncryptedUnicode(ciphertext)
    assert ciphertext == encrypted_unicode._ciphertext
    assert plaintext == encrypted_unicode.decrypt(vault)
    assert ciphertext == encrypted_unicode.encrypt(vault)
    assert ciphertext == encrypted_unicode._ciphertext
    assert plaintext == encrypted_unicode.decrypt(vault)
    assert ciphertext == encrypted_unicode.encrypt(vault)
    assert ciphertext == encrypted_unicode._ciphertext
    assert plaintext == encrypted_unicode

# Generated at 2022-06-22 16:25:31.677380
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault_text = vault.encrypt('test')
    vault_encrypted_unicode = AnsibleVaultEncryptedUnicode(vault_text)

# Generated at 2022-06-22 16:26:10.723905
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02\x03') == u'!!binary |\n  AAECAw==\n'

# Generated at 2022-06-22 16:26:13.198101
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00\x01\x02') == u'!!binary |\n  AAEC\n'

# Generated at 2022-06-22 16:26:20.767290
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == u'!!binary |\n  Zm9v\n'
    assert dumper.represent_binary(b'foo\n') == u'!!binary |\n  Zm9vCg==\n'
    assert dumper.represent_binary(b'foo\nbar') == u'!!binary |\n  Zm9vCmJhcg==\n'
    assert dumper.represent_binary(b'foo\nbar\n') == u'!!binary |\n  Zm9vCmJhcgo=\n'

# Generated at 2022-06-22 16:26:23.509168
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == u'!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:26:32.764058
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper

# Generated at 2022-06-22 16:26:36.459779
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == u'!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:26:38.737074
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == u'!!binary |\n  Zm9v\n'

# Generated at 2022-06-22 16:26:49.290685
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()