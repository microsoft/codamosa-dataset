

# Generated at 2022-06-25 04:32:02.833788
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.yaml.dumper import represent_vault_encrypted_unicode
    pass

# Generated at 2022-06-25 04:32:04.653497
# Unit test for function represent_unicode
def test_represent_unicode():
    str_0 = 'iC@bVev.\t'
    var_0 = represent_unicode(str_0)



# Generated at 2022-06-25 04:32:07.586997
# Unit test for function represent_undefined
def test_represent_undefined():

    test_i = 0
    for test_i in range(100):
        print('Test', test_i)
        if test_i == 99:
            test_i/0
            break
        var_0 = represent_undefined('test_i')


# Generated at 2022-06-25 04:32:09.415705
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Test case 0
    str_0 = '6HBn.Z*?'
    var_0 = represent_vault_encrypted_unicode(str_0)

# Generated at 2022-06-25 04:32:16.262241
# Unit test for function represent_unicode
def test_represent_unicode():
    param_0 = '~C*z.xH7'
    ansible_method_call(param_0)
    str_0 = 'XV)\\'
    var_0 = yaml.representer.SafeRepresenter.represent_str(str_0, text_type(str_0))



# Generated at 2022-06-25 04:32:20.218571
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = yaml.Dumper(str)
    result = represent_hostvars(dumper, HostVars(str))
    assert result == dumper.represent_dict(dict(HostVars(str)))


# Generated at 2022-06-25 04:32:24.130468
# Unit test for function represent_undefined
def test_represent_undefined():
    # In this test we set up a ansible variable and then call represent_undefined
    # to see if we can convert the variable to yaml data. The variable is a str
    a_str = 'my_string_to_convert'
    var_0 = represent_undefined(a_str)
    print("return value: ", var_0)


# Generated at 2022-06-25 04:32:25.666831
# Unit test for function represent_binary
def test_represent_binary():
    var_0 = '6HBn.Z*?'
    var_0 = represent_binary(var_0)


# Generated at 2022-06-25 04:32:34.343835
# Unit test for function represent_undefined
def test_represent_undefined():
    # Test with a class that does not have __bool__ set
    class Test0(AnsibleUndefined):
        pass
    test0 = Test0()

    test_with_proxy = represent_undefined(test0)
    assert test_with_proxy is True

    # Test with a class that does have __bool__ set
    class Test1(AnsibleUndefined):
        def __bool__(self):
            return False
    test1 = Test1()

    test_with_proxy = represent_undefined(test1)
    assert test_with_proxy is False


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 04:32:39.650198
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    str_0 = '6HBn.Z*?'
    var_0 = represent_vault_encrypted_unicode(str_0)
    assert var_0 == '!vault |\n  6HBn.Z*?\n'

if __name__ == '__main__':
    test_represent_vault_encrypted_unicode()

# Generated at 2022-06-25 04:32:47.857316
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper
    obj = AnsibleVaultEncryptedUnicode('topsecret', cipher='AES')
    res = represent_vault_encrypted_unicode(dumper, obj)
    expected = dumper.represent_scalar(u'!vault', b'AES|topsecret')
    assert res == expected

# Generated at 2022-06-25 04:32:55.381191
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import AnsibleUndefined
    from io import StringIO
    from yaml import Dumper
    from yaml import Loader

    # These are private methods so this is a poor test for _fail_with_undefined_error
    # but we need to test yaml.dump() with a representer so this is as good as it gets
    def my_represent_undefined(self, data):
        return bool(data)

    output = StringIO()
    d = Dumper(stream=output, default_flow_style=False, explicit_start=True)
    d.add_representer(AnsibleUndefined, my_represent_undefined)
    d.dump(AnsibleUndefined())
    assert output.getvalue() == 'undefined\n...\n'

    output = StringIO()
    d = D

# Generated at 2022-06-25 04:33:01.000431
# Unit test for function represent_binary
def test_represent_binary():
    test_data = (
        (b'\x01\x02\xff', '!!binary |\n  AQKy/w==\n'),
        (b'\x01\x02\\\xff', '!!binary |\n  AQLC/w==\n'),
    )
    for input, output in test_data:
        assert AnsibleDumper.represent_binary(input) == output

# Generated at 2022-06-25 04:33:04.079141
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper.represent_undefined(AnsibleDumper, None)
    assert AnsibleDumper.represent_undefined(AnsibleDumper, AnsibleUndefined())

# Generated at 2022-06-25 04:33:07.801319
# Unit test for function represent_undefined
def test_represent_undefined():
    yamldumper = AnsibleDumper()
    try:
        yamldumper.represent_undefined(AnsibleUndefined)
    except Exception as e:
        assert False, str(e)

# Generated at 2022-06-25 04:33:11.656315
# Unit test for function represent_binary
def test_represent_binary():
    data = AnsibleDumper.represent_binary(b'foo\xfa')
    assert data == u'!!binary |\n  foo/A==', data
    data = AnsibleDumper.represent_binary(b'\x00\x01\x02')
    assert data == u'!!binary |\n  AAEC', data

# Generated at 2022-06-25 04:33:14.555259
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert yaml.dump({'_ansible_no_log': True}, Dumper=AnsibleDumper) == '{_ansible_no_log: true}\n'



# Generated at 2022-06-25 04:33:16.270437
# Unit test for function represent_unicode
def test_represent_unicode():
    data = AnsibleUnicode(u"Test")
    repr = yaml.dump(data)
    assert repr == "Test\n"

# Generated at 2022-06-25 04:33:24.012686
# Unit test for function represent_hostvars
def test_represent_hostvars():
    AnsibleDumper.add_representer(
        HostVars,
        represent_hostvars,
    )
    AnsibleDumper.add_multi_representer(
        dict,
        yaml.representer.SafeRepresenter.represent_dict,
    )
    o = yaml.dump({'hostvars': HostVars(vars={'ip': '10.0.0.1', 'inventory_hostname': 'test'})})
    assert o == '{hostvars: {inventory_hostname: test, ip: 10.0.0.1}}\n'

# Generated at 2022-06-25 04:33:26.579340
# Unit test for function represent_hostvars
def test_represent_hostvars():
    h = HostVars(HostVarsVars({'a': 'b'}))
    out = yaml.dump(h, Dumper=AnsibleDumper)
    assert out == '{a: b}\n...\n'



# Generated at 2022-06-25 04:33:35.202227
# Unit test for function represent_binary
def test_represent_binary():
    import sys

    # try with a bunch of python version to check if output is in the expected
    # format
    for version in ('2.6', '2.7', '3.2', '3.3'):
        yaml.__version__ = version
        if sys.version_info[0] > 2:
            assert yaml.dump(b'abc', Dumper=AnsibleDumper) == '!binary |\r\n  YWJj\r\n'
        else:
            assert yaml.dump(b'abc', Dumper=AnsibleDumper) == '!binary |\r\n  YWJj\r\n'

# Generated at 2022-06-25 04:33:41.576704
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    yaml.add_representer(
        AnsibleVaultEncryptedUnicode,
        represent_vault_encrypted_unicode,
    )
    assert yaml.dump(AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256~password~password~password~password~~~~~'), Dumper=yaml.SafeDumper) == '!vault |\n  $ANSIBLE_VAULT;1.1;AES256~password~password~password~password~~~~~\n\n'
    yaml.SafeRepresenter.ignore_aliases = lambda self, data: True

# Generated at 2022-06-25 04:33:49.576911
# Unit test for function represent_binary

# Generated at 2022-06-25 04:33:51.531919
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper.represent_undefined(None, AnsibleUndefined())

# Generated at 2022-06-25 04:33:58.505055
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    assert "a: b" == dumper.represent_scalar("!hostvars", HostVars({"a": "b"}))
    assert "a: b" == dumper.represent_scalar("!hostvars", HostVarsVars({"a": "b"}))
    assert "a: b" == dumper.represent_scalar("!hostvars", VarsWithSources({"a": "b"}))



# Generated at 2022-06-25 04:34:05.953376
# Unit test for function represent_binary
def test_represent_binary():
    representer = yaml.representer.SafeRepresenter()
    representer.add_representer(
        AnsibleUnsafeBytes,
        represent_binary,
    )
    assert representer.represent_data(b'foo bar') == '!binary |-\n  foo bar\n'

# Generated at 2022-06-25 04:34:09.527217
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('1'), Dumper=AnsibleDumper) == u"1\n"



# Generated at 2022-06-25 04:34:18.018217
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    """Function:represent_vault_encrypted_unicode()
    """
    ad = AnsibleDumper(width=79, indent=2, canonical=False, default_style='"', default_flow_style=False)
    encrypted_data = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\n33303965353934366131623337356663373438663632336231306533303736333465353465303939\n35653630383061666339616662613664333139383965376461616138356363353133663863636365\n')
    test_result = represent_vault_encrypted_unicode(ad, encrypted_data)

# Generated at 2022-06-25 04:34:21.916727
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = hostvars_test_data()
    output = yaml.dump(data, Dumper=AnsibleDumper)
    print(output)
    assert output == 'bar: 2\nfoo: 1\n'



# Generated at 2022-06-25 04:34:27.965892
# Unit test for function represent_hostvars
def test_represent_hostvars():
    test_data = {'dict': HostVars(fake_vars={'a': 1, 'b': 2, 'c': 3}, hostname='test_host')}
    yml = yaml.dump(test_data, Dumper=AnsibleDumper, default_flow_style=False)

    assert yml == """\
dict:
  a: 1
  b: 2
  c: 3
"""
    assert isinstance(yml, text_type)
    assert isinstance(SafeDumper().represent_dict(dict(test_data['dict'])), list)



# Generated at 2022-06-25 04:34:42.281513
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-25 04:34:48.315350
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    dumper.add_representer(
        AnsibleUnicode,
        represent_unicode)
    assert dumper.represent_unicode(AnsibleUnicode('foo')) == u"!ansible-unicode |\n  foo"



# Generated at 2022-06-25 04:34:54.874615
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib

    vault_password = "asdfasdf"
    vault = VaultLib(vault_password)

    fake_data_to_encrypt = "asdfasdf"
    encrypted_data = vault.encrypt(fake_data_to_encrypt)
    vault_encrypted_object = AnsibleVaultEncryptedUnicode(encrypted_data)

    dump_data = AnsibleDumper().represent_data(vault_encrypted_object)


# Generated at 2022-06-25 04:35:04.425230
# Unit test for function represent_binary
def test_represent_binary():
    from ansible.template.safe_eval import unsafe_proxy

    # bytes
    dumper = AnsibleDumper
    s = u'\u1234'
    r = represent_binary(dumper, unsafe_proxy(s.encode('utf-16-le')))
    assert r == u"!binary |-\n  EAAAQQ==\n"

    # unicode
    s = u'\u1234'
    r = represent_binary(dumper, unsafe_proxy(s))
    assert r == u"!binary |-\n  EAAAQQ==\n"



# Generated at 2022-06-25 04:35:06.166535
# Unit test for function represent_undefined
def test_represent_undefined():
    data = AnsibleUndefined('foo')
    assert(repr(data) == 'foo')

# Generated at 2022-06-25 04:35:13.818903
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = {
        'key1': 'value1',
        'key2': 'value2',
    }
    data = HostVars(data=data)
    result = yaml.dump(data, Dumper=AnsibleDumper, default_flow_style=False)
    assert result == u'{key1: value1, key2: value2}\n'


# Generated at 2022-06-25 04:35:19.727036
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper(None, None)
    assert dumper.represent_unicode(u'test') == "test"
    assert dumper.represent_unicode(u'test') == "test"
    assert dumper.represent_unicode(u'test\n') == "test\n"



# Generated at 2022-06-25 04:35:23.299584
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hv = HostVars()
    hv['foo'] = 'bar'
    hv['baz'] = 'foobar'

    dumper = AnsibleDumper()
    dumper.represent_hostvars(hv)

    hvv = HostVarsVars()
    hvv['foo'] = 'bar'

    dumper.represent_hostvars(hvv)



# Generated at 2022-06-25 04:35:28.115791
# Unit test for function represent_unicode
def test_represent_unicode():
    actual_result = yaml.dump({'implicit_string': 'implicit_string'}, Dumper=AnsibleDumper, default_flow_style=True)
    assert actual_result == '{implicit_string: implicit_string}\n'

# Generated at 2022-06-25 04:35:30.670317
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = HostVars({'a': 1, 'b': 2})
    res = AnsibleDumper.represent_hostvars(data)
    assert res == '{a: 1, b: 2}'

# Generated at 2022-06-25 04:35:56.211374
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    ciphertext = bytearray(b"\xEA\x8D\x88\xE4\xD4\x1B\xCD\xB3")
    encrypted = AnsibleVaultEncryptedUnicode(ciphertext)
    yaml_str = yaml.dump(dict(foo=encrypted), Dumper=AnsibleDumper)

# Generated at 2022-06-25 04:35:59.500136
# Unit test for function represent_hostvars
def test_represent_hostvars():
    import yaml

    stream = 'data: [foo, bar]'
    yaml_data = yaml.safe_load(stream)
    assert yaml_data['data'] == ['foo', 'bar']

    stream = 'data: {foo: bar}'
    yaml_data = yaml.safe_load(stream)
    assert yaml_data['data'] == {'foo': 'bar'}

# Generated at 2022-06-25 04:36:09.808977
# Unit test for function represent_hostvars
def test_represent_hostvars():

    def compare_dumped_data(data, expected):
        dumped_data = yaml.safe_dump(
            data,
            default_flow_style=False,
            Dumper=AnsibleDumper
        )
        assert dumped_data == expected

    data = HostVars({"a": 1, "b": 2}, [])
    expected = "\n".join((
        "a: 1",
        "b: 2",
        ""
    ))
    compare_dumped_data(data, expected)

    data = HostVarsVars({"c": 3, "d": 4})
    expected = "\n".join((
        "c: 3",
        "d: 4",
        ""
    ))
    compare_dumped_data(data, expected)


# Generated at 2022-06-25 04:36:20.449462
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars import VariableManager

    data = { 'var1': 'value1',
             'var2': 'value2',
             'var3': 'value3',
           }

    v = VariableManager()
    hv = HostVars(v, "test_host", data=data)
    v.add_host_vars("test_host", hv)

    def represent_hostvars(self, data):
        return yaml.Dumper.represent_dict(self, data)

    def represent_hostvarsvar(self, data):
        return yaml.Dumper.represent_str(self, data)

    yaml.Dumper.add_representer(
        HostVars,
        represent_hostvars,
    )


# Generated at 2022-06-25 04:36:30.869347
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    representer = AnsibleDumper()
    ciphertext = '$ANSIBLE_VAULT;1.1;AES256\n333635...'
    data = AnsibleVaultEncryptedUnicode(ciphertext)
    yaml_data = representer.represent_data(data)
    assert '!vault |' in yaml_data
    assert yaml_data.endswith('\n')
    # Representer does not surround encrypted data with single quotes,
    # so we have to make sure the result is a valid yaml string.
    # We use yaml.load to load the yaml result,
    # which always return a python object.
    # The test will pass if it returns the correct python object.
    assert yaml.load(yaml_data) == data


# Generated at 2022-06-25 04:36:35.600198
# Unit test for function represent_unicode
def test_represent_unicode():
    result = represent_unicode(None, 'foo')
    if isinstance(result, text_type):
        result = result.encode('utf-8')
    assert result == 'foo'



# Generated at 2022-06-25 04:36:40.949084
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = dict(foo=1, bar=2)
    data = HostVars().get_vars(None, data)
    output = yaml.dump(data, Dumper=AnsibleDumper, default_flow_style=False)
    assert output == '---\n' \
                      'foo: 1\n' \
                      'bar: 2\n'



# Generated at 2022-06-25 04:36:42.937625
# Unit test for function represent_unicode
def test_represent_unicode():
    assert(yaml.dump(AnsibleUnicode(u'foo'), Dumper=AnsibleDumper, default_flow_style=False) == 'foo\n')



# Generated at 2022-06-25 04:36:53.132757
# Unit test for function represent_binary
def test_represent_binary():
    # Representer accepts binary if it contains only characters in the range 0x20 - 0x7e
    representer = AnsibleDumper.yaml_representers[binary_type]
    assert representer.represent_binary(AnsibleDumper, b"foo") is not None

    # Representer fails if binary contains characters outside the range 0x20 - 0x7E

# Generated at 2022-06-25 04:36:58.006817
# Unit test for function represent_binary
def test_represent_binary():
    dump = (AnsibleDumper.represent_binary)('123')
    assert dump == '!!binary "MTIz"' # u'MTIz'



# Generated at 2022-06-25 04:37:50.995585
# Unit test for function represent_binary
def test_represent_binary():
    ansible_unicode_0 = module_0.AnsibleUnicode()
    ansible_binary_0 = module_0.AnsibleBinary()
    ansible_dumper_0 = AnsibleDumper(ansible_binary_0, ansible_unicode_0)
    str_0 = ',-m2Sb:_o[d8ry'
    str_1 = '!^e\x0c$*RCa'
    ansible_mapping_0 = module_0.AnsibleMapping(str_1)
    ansible_dumper_0.represent_dict(ansible_mapping_0)
    float_0 = 787.0896568869931
    var_0 = represent_binary(str_0, float_0)


# Generated at 2022-06-25 04:37:58.824480
# Unit test for function represent_binary
def test_represent_binary():
    arg_0 = ''                                         # Array
    arg_1 = None                                       # Object
    arg_2 = False                                      # Bool
    arg_3 = '|'                                        # String
    arg_4 = False                                      # Bool
    arg_5 = object()                                   # Object
    try:
        ansible.module_utils.common.yaml.represent_binary(arg_0, arg_1, arg_2, arg_3, arg_4, arg_5)
        assert False
    except ValueError:
        assert True


# Generated at 2022-06-25 04:38:04.856151
# Unit test for function represent_binary
def test_represent_binary():
    ansible_unicode_0 = module_0.AnsibleUnicode()
    ansible_dumper_0 = AnsibleDumper(ansible_unicode_0, ansible_unicode_0)
    str_0 = 'S-8X%E#\x13sQs@4q'
    dict_0 = {str_0: str_0}
    vars_with_sources_0 = module_2.VarsWithSources(**dict_0)
    host_vars_vars_0 = module_3.HostVarsVars(str_0, vars_with_sources_0)
    var_0 = represent_binary(ansible_dumper_0, host_vars_vars_0)
    set_0 = set()
    tuple_0 = ()
    var_

# Generated at 2022-06-25 04:38:08.191969
# Unit test for function represent_binary
def test_represent_binary():
    ansible_unsafe_bytes_0 = module_0.AnsibleUnsafeBytes()
    ansible_unsafe_bytes_1 = module_0.AnsibleUnsafeBytes(ansible_unsafe_bytes_0)
    ansible_unsafe_bytes_2 = module_0.AnsibleUnsafeBytes(ansible_unsafe_bytes_1)
    ansible_dumper_0 = AnsibleDumper(ansible_unsafe_bytes_1, ansible_unsafe_bytes_2)
    var_0 = represent_binary(ansible_dumper_0, ansible_unsafe_bytes_1)


# Generated at 2022-06-25 04:38:16.175782
# Unit test for function represent_binary
def test_represent_binary():
    ansible_unicode_0 = module_0.AnsibleUnicode()
    ansible_dumper_0 = AnsibleDumper(ansible_unicode_0, ansible_unicode_0)
    str_0 = '"MFH9*K(d>b0*9'
    dict_0 = {str_0: str_0}
    vars_with_sources_0 = module_2.VarsWithSources(**dict_0)
    host_vars_vars_0 = module_3.HostVarsVars(str_0, vars_with_sources_0)
    var_0 = ansible_dumper_0.represent_data(host_vars_vars_0)

# Generated at 2022-06-25 04:38:23.906346
# Unit test for function represent_binary
def test_represent_binary():
    ansible_unicode_0 = module_0.AnsibleUnicode()
    ansible_dumper_0 = AnsibleDumper(ansible_unicode_0, ansible_unicode_0)
    set_0 = set()
    str_0 = 'G#4]4M\x06\r<C'
    dict_0 = {set_0: str_0, str_0: ansible_unicode_0}
    vars_with_sources_0 = module_2.VarsWithSources(**dict_0)
    host_vars_vars_0 = module_3.HostVarsVars(str_0, vars_with_sources_0)
    var_0 = ansible_dumper_0.represent_data(host_vars_vars_0)
   

# Generated at 2022-06-25 04:38:31.588672
# Unit test for function represent_binary
def test_represent_binary():
    ansible_unicode_0 = module_0.AnsibleUnicode()
    ansible_dumper_0 = AnsibleDumper(ansible_unicode_0, ansible_unicode_0)
    str_0 = ']{Qyx6E0U'
    ansible_unicode_1 = module_0.AnsibleUnicode()
    vars_with_sources_1 = module_2.VarsWithSources(**{str_0: ansible_unicode_1})
    ansible_dumper_1 = AnsibleDumper(str_0, vars_with_sources_1)
    list_0 = [str_0]
    ansible_dumper_2 = AnsibleDumper(str_0, vars_with_sources_1)
    var_0 = represent

# Generated at 2022-06-25 04:38:41.015392
# Unit test for function represent_binary
def test_represent_binary():
    ansible_unicode_0 = module_0.AnsibleUnicode()
    ansible_dumper_0 = AnsibleDumper(ansible_unicode_0, ansible_unicode_0)
    str_0 = '"MFH9*K(d>b0*9'
    dict_0 = {str_0: str_0}
    vars_with_sources_0 = module_2.VarsWithSources(**dict_0)
    host_vars_vars_0 = module_3.HostVarsVars(str_0, vars_with_sources_0)
    var_0 = ansible_dumper_0.represent_data(host_vars_vars_0)

# Generated at 2022-06-25 04:38:49.746985
# Unit test for function represent_binary
def test_represent_binary():
    ansible_unsafe_bytes_1 = module_0.AnsibleUnsafeBytes()
    ansible_dumper_2 = AnsibleDumper(ansible_unsafe_bytes_1)
    str_5 = '0!G2;4}9UY]\t4'
    dict_3 = {str_5: str_5}
    set_1 = set()
    ansible_dumper_3 = AnsibleDumper(set_1, {}, vars_with_sources_1)
    str_6 = 'oTbb@f3%vZM\x0c:v?'
    str_7 = '%]i.2_Y#yyKA22tPpMG'
    set_2 = {str_6: [str_7, str_1]}
    var_8 = represent_vault

# Generated at 2022-06-25 04:39:00.339240
# Unit test for function represent_binary
def test_represent_binary():
    ansible_unsafe_bytes_0 = module_0.AnsibleUnsafeBytes()
    ansible_unsafe_bytes_1 = module_0.AnsibleUnsafeBytes(ansible_unsafe_bytes_0)
    ansible_unicode_0 = module_0.AnsibleUnicode()
    ansible_dumper_0 = AnsibleDumper(ansible_unsafe_bytes_1, ansible_unicode_0)
    str_0 = '\nA\x15&9hfR\x0f4\x02G'
    ansible_vault_encrypted_unicode_0 = module_0.AnsibleVaultEncryptedUnicode(str_0, str_0)
    str_1 = '|'
    str_2 = '!vault'
    ansible

# Generated at 2022-06-25 04:39:47.704425
# Unit test for function represent_binary
def test_represent_binary():
    ansible_dumper_0 = AnsibleDumper()
    str_0 = 'x_JPKq3'
    unicode_0 = u'GZZ"y?s8\n'
    ansible_unicode_0 = module_0.AnsibleUnicode(str_0, unicode_0)
    binary_0 = ansible_dumper_0.represent_data(ansible_unicode_0)


# Generated at 2022-06-25 04:39:49.768701
# Unit test for function represent_binary
def test_represent_binary():
    ansible_dumper_1 = AnsibleDumper()
    str_0 = '"@'
    var_0 = represent_binary(ansible_dumper_1, str_0)


# Generated at 2022-06-25 04:39:59.298925
# Unit test for function represent_binary
def test_represent_binary():
    ansible_unicode_0 = module_0.AnsibleUnicode()
    ansible_dumper_0 = AnsibleDumper(ansible_unicode_0, ansible_unicode_0)
    ansible_unicode_1 = module_0.AnsibleUnicode()
    str_0 = '\x1c"\t^3q\x10\t\x1c\x03\t\x0b\x07\x1c'
    data = str_0
    str_1 = '_tG~w'
    dict_0 = {str_1: str_1}
    ansi_color_vm_0 = ansible_dumper_0.represent_binary(data)

# Generated at 2022-06-25 04:40:05.728243
# Unit test for function represent_binary
def test_represent_binary():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_dumper_0 = AnsibleDumper(ansible_unicode_0, ansible_unicode_0)
    str_0 = '1'
    byte_0 = ord('\x01')
    byte_1 = ord('\x00')
    byte_2 = ord('\x00')
    byte_3 = ord('\x00')
    bytes_0 = b'\x01\x00\x00\x00'
    bytes_1 = b'\x01\x00\x00\x00'
    ansible_unsafe_bytes_0 = AnsibleUnsafeBytes(bytes_0, byte_3)
    list_0 = [str_0, byte_0, byte_1, byte_2, byte_3]


# Generated at 2022-06-25 04:40:14.867141
# Unit test for function represent_binary
def test_represent_binary():
    ansible_unsafe_bytes_0 = module_0.AnsibleUnsafeBytes(bytearray())
    ansible_dumper_0 = AnsibleDumper(ansible_unsafe_bytes_0, ansible_unsafe_bytes_0)
    set_0 = set()
    tuple_0 = ()
    str_0 = 'Q<6"BH6`\x0cM\rL'
    str_1 = 'u6N'
    str_2 = '0!G2;4}9UY]\t4'
    ansible_dumper_1 = AnsibleDumper(str_0, str_1, str_2)
    ansible_unicode_0 = module_0.AnsibleUnicode(**set_0)
    var_0 = ansible_dumper_

# Generated at 2022-06-25 04:40:21.577135
# Unit test for function represent_binary
def test_represent_binary():
    ansible_dumper_0 = AnsibleDumper()
    ansible_unicode_0 = module_0.AnsibleUnicode()
    ansible_unicode_1 = module_0.AnsibleUnicode()
    dict_0 = {ansible_unicode_0: ansible_unicode_1}
    ansible_dumper_1 = AnsibleDumper(**dict_0)
    ansible_dumper_2 = AnsibleDumper(ansible_unicode_0, ansible_unicode_1)
    ansible_dumper_3 = AnsibleDumper(ansible_unicode_0, ansible_unicode_0)
    ansible_dumper_4 = AnsibleDumper(ansible_unicode_1, ansible_unicode_1)
    ansible_dumper

# Generated at 2022-06-25 04:40:31.399499
# Unit test for function represent_binary

# Generated at 2022-06-25 04:40:40.238333
# Unit test for function represent_binary
def test_represent_binary():
    ansible_binary_0 = module_0.AnsibleBinary()
    ansible_binary_1 = None
    ansible_dumper_0 = AnsibleDumper(ansible_binary_0, ansible_binary_1)
    dict_0 = {}
    float_0 = -581.89
    list_0 = [dict_0]
    ansible_sequence_0 = module_0.AnsibleSequence(dict_0, float_0, list_0)
    dict_1 = {ansible_sequence_0: ansible_sequence_0}
    var_0 = ansible_dumper_0.represent_dict(dict_1)
    var_1 = ansible_dumper_0.represent_dict(dict_1)

# Generated at 2022-06-25 04:40:48.050491
# Unit test for function represent_binary
def test_represent_binary():
    ansible_unsafe_bytes_0 = module_0.AnsibleUnsafeBytes()
    var_0 = represent_binary(ansible_unsafe_bytes_0)
    str_0 = ';k7PU'
    ansible_unsafe_text_0 = module_0.AnsibleUnsafeText(**{str_0: str_0})
    var_1 = represent_binary(ansible_unsafe_text_0)

# Generated at 2022-06-25 04:40:52.460794
# Unit test for function represent_binary
def test_represent_binary():

    ansible_dumper_2 = AnsibleDumper()
    dict_3 = {}
    str_5 = ','
    str_6 = 'z4i1.\x0bD\t;'
    set_1 = {str_5}
    tuple_2 = (str_6,)
    var_8 = represent_binary(tuple_2)
    tuple_3 = ()
    ansible_dumper_2.represent_data(tuple_3)
    var_9 = ansible_dumper_2.represent_data(var_8)
    tuple_4 = (dict_3, var_9, var_8, set_1)
    dict_3[str_6] = tuple_4
    ansible_dumper_2.represent_data(dict_3)
