

# Generated at 2022-06-25 04:32:03.137918
# Unit test for function represent_binary
def test_represent_binary():
    float_0 = -392.0
    var_0 = represent_binary(float_0)


# Generated at 2022-06-25 04:32:05.712927
# Unit test for function represent_unicode
def test_represent_unicode():
    s = "this is a string"
    var_0 = AnsibleUnicode(s)
    var_1 = represent_unicode(var_0)
    assert s == var_1


# Generated at 2022-06-25 04:32:08.711739
# Unit test for function represent_undefined
def test_represent_undefined():
    var_a = False
    var_a = represent_undefined(var_a)
    var_b = True
    var_b = represent_undefined(var_b)


if __name__ == "__main__":
    test_case_0()
    test_represent_undefined()

# Generated at 2022-06-25 04:32:09.459607
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert callable(represent_hostvars)



# Generated at 2022-06-25 04:32:12.297208
# Unit test for function represent_hostvars
def test_represent_hostvars():
    float_0 = -392.0
    var_0 = represent_hostvars(float_0)
    print(var_0)
    print(type(var_0))

# Generated at 2022-06-25 04:32:22.249503
# Unit test for function represent_hostvars
def test_represent_hostvars():
    print("importing yaml...")
    import yaml
    print("finished importing yaml.")
    print("yaml.dump({'abc': {'def': 123}}) is %s\n" % yaml.dump({'abc': {'def': 123}}))
    print("yaml.dump({'abc': {'def': 123}}, Dumper=AnsibleDumper) is %s\n" % yaml.dump({'abc': {'def': 123}}, Dumper=AnsibleDumper))

# Generated at 2022-06-25 04:32:29.375746
# Unit test for function represent_binary
def test_represent_binary():
    # Tests if function returns correct type.
    # NOTE: We don't want binary data in our return
    # objects.
    ansible_dumper_0 = AnsibleDumper()
    var_0 = ansible_dumper_0.represent_binary(b'foo')
    assert isinstance(var_0, str)


# Generated at 2022-06-25 04:32:32.027561
# Unit test for function represent_unicode
def test_represent_unicode():
    ansible_dumper = AnsibleDumper()
    float_0 = -392.0
    var_0 = represent_unicode(ansible_dumper, float_0)


# Generated at 2022-06-25 04:32:37.685199
# Unit test for function represent_binary
def test_represent_binary():
    mock_self = object()
    mock_data = object()

    mock_self._base_represent_binary = MagicMock()

    mock_self._base_represent_binary.return_value = 'string'

    result = represent_binary(mock_self, mock_data)

    assert result == 'string'
    mock_self._base_represent_binary.assert_called_once_with(mock_data)



# Generated at 2022-06-25 04:32:39.845012
# Unit test for function represent_unicode
def test_represent_unicode():
    var_0 = represent_unicode('Gelatinous', 'Enormous')


# Generated at 2022-06-25 04:32:51.692652
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.vars.unsafe_proxy import AnsibleVaultEncryptedUnicode

    str_0 = 'this is a string'
    str_1 = 'this is an Encrypted string'
    str_2 = 'this is a non-Encrypted string'
    str_3 = 'this is an another Encrypted string'
    ansible_vault = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault._ciphertext = str_1
    #assert represent_vault_encrypted_unicode(ansible_vault) == str_2
    ansible_vault._ciphertext = str_3
    #assert represent_vault_encrypted_unicode(ansible_vault) == str_3

if __name__ == "__main__":
    test_represent_vault

# Generated at 2022-06-25 04:32:54.698474
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    str_0 = 'this is a string'
    #assert AnsibleDumper.represent_vault_encrypted_unicode(str_0) == '"string"', "Calculating the output failed"
    assert True

# Generated at 2022-06-25 04:33:00.832237
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = AnsibleVaultEncryptedUnicode(u'$ANSIBLE_VAULT;1.1;AES256\r\n...\r\n')
    dumper = AnsibleDumper()
    ret_0 = dumper.represent_scalar(u'!vault', data._ciphertext.decode(), style='|')

    # Check return value
    assert ret_0 == u'!vault |\n  $ANSIBLE_VAULT;1.1;AES256\r\n...\r\n'


# Generated at 2022-06-25 04:33:09.721415
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.representer.SafeRepresenter.represent_binary(AnsibleDumper, "ansible") == "'YW5zaWJsZQ==\\n'"
    assert yaml.representer.SafeRepresenter.represent_binary(AnsibleDumper, 'ansible') == "'YW5zaWJsZQ==\\n'"
    assert yaml.representer.SafeRepresenter.represent_binary(AnsibleDumper, u'ansible') == "'YW5zaWJsZQ==\\n'"
    assert yaml.representer.SafeRepresenter.represent_binary(AnsibleDumper, b'ansible') == "'YW5zaWJsZQ==\\n'"

# Generated at 2022-06-25 04:33:13.044693
# Unit test for function represent_binary
def test_represent_binary():
    str_0 = 'this is a string'
    dumper_0 = AnsibleDumper

    result = represent_binary(dumper_0, str_0)

    assert result == 'this is a string'


# Generated at 2022-06-25 04:33:15.166651
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    result = represent_vault_encrypted_unicode(AnsibleDumper, str_0)
    assert result == ({}, str_0, '|')


# Generated at 2022-06-25 04:33:17.181122
# Unit test for function represent_unicode
def test_represent_unicode():
    str_0 = 'this is a string'
    str_1 = text_type(str_0)
    assert(str_1 == u'this is a string')



# Generated at 2022-06-25 04:33:19.555296
# Unit test for function represent_undefined
def test_represent_undefined():
    str_1 = 'this is a string'
    str_undefined = 'this is a string'
    assert yaml.dump(str_undefined, Dumper=AnsibleDumper).strip() == str_1


# Generated at 2022-06-25 04:33:21.819610
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # If there is no data passed to the function, it returns a scalar object
    assert represent_vault_encrypted_unicode(test_case_0, 'foo') is None


# Generated at 2022-06-25 04:33:22.976444
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    with pytest.raises(Exception):
        pass


# Generated at 2022-06-25 04:33:30.259123
# Unit test for function represent_binary
def test_represent_binary():
    value_string = b'\x00\x08\x10\x18'
    test_result = yaml.representer.SafeRepresenter.represent_binary(None, value_string)

    assert test_result == u"!binary |-\n  AAECAQ==\n"



# Generated at 2022-06-25 04:33:33.081146
# Unit test for function represent_binary
def test_represent_binary():
    data = AnsibleUnsafeBytes(b'binary')
    d = AnsibleDumper(None)
    result = d.represent_binary(data)
    assert result == "!!python/object/apply:ansible.parsing.yaml.objects.AnsibleUnsafeBytes [b'binary']\n"



# Generated at 2022-06-25 04:33:35.820302
# Unit test for function represent_unicode
def test_represent_unicode():
    u = yaml.load("""
    a:
      - a_unicode_value
    """)

    # Given a YAML document with a unicode value,
    # when the document is yaml dumped,
    # then the resulting utf-8 bytes contain a unicode value.
    #
    # Note: this string is utf-8 bytes, not a unicode string
    utf8_bytes = yaml.dump(u, Dumper=AnsibleDumper)
    assert b'\xC3' in utf8_bytes
    assert b'a_unicode_value' in utf8_bytes



# Generated at 2022-06-25 04:33:46.692200
# Unit test for function represent_unicode
def test_represent_unicode():
    test_unicode = '''
---
- hosts:
    - test1
    - test2
  vars:
    key: "{{ inventory_hostname }}"
    list:
      - 1
      - 2
      - 3
      - "{{ 4 }}"
      - 5
      - "{{ 6 }}"
      - 7
  tasks:
  - debug:
      msg: "{{ inventory_hostname }}"
  - shell: "echo {{ inventory_hostname }}"
'''

# Generated at 2022-06-25 04:33:55.787587
# Unit test for function represent_unicode
def test_represent_unicode():
    data = {'foo': 'bar'}
    fd = open('/tmp/foo.yaml', 'w')
    fd.write(yaml.dump(data, Dumper=AnsibleDumper, default_flow_style=False))
    fd.close()

    fd = open('/tmp/foo.yaml', 'r')
    new_data = yaml.safe_load(fd)
    fd.close()

    assert new_data['foo'] == 'bar'

# Generated at 2022-06-25 04:34:02.093751
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = "password"
    # text_type is required to put the data in unicode format
    data = text_type(data)
    # Setting up some encryption
    cipher = vault_encrypt_text(data)
    # Creating a vault object
    vobj = vault_decrypt_text(cipher)

    # Setting up a representer object
    representer = AnsibleDumper()
    # Representing the object
    rep = represent_vault_encrypted_unicode(representer, vobj)

    # Using assertTrue to check if the representation is true
    assertTrue(rep)


# Generated at 2022-06-25 04:34:12.375903
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Represent a AnsibleVaultEncryptedUnicode type with multiple line
    plaintext = u'''---
- hosts: all
  become: yes
  sudo: yes
  gather_facts: no
  tasks:
    - name: "Wait until the container is up"
      local_action:
        module: wait_for
        port: 80
        host: "{{ item }}"
        delay: 5
        timeout: 300
      with_items:
        - "{{ item }}"
'''

# Generated at 2022-06-25 04:34:17.054756
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    """ this function tests the represent_vault_encrypted_unicode function
    """
    from collections import namedtuple

    TestVault = namedtuple('AnsibleVaultEncryptedUnicode', ('_ciphertext'))
    plain = 'this is plain text'
    cipher = TestVault(plain)
    assert represent_vault_encrypted_unicode(AnsibleDumper, cipher) == '!vault |1+\n'

# Generated at 2022-06-25 04:34:24.164846
# Unit test for function represent_unicode
def test_represent_unicode():
    # Note that using keyword arguments to instantiate
    # a SafeRepresenter will not work since the keyword
    # arguments are not passed to the base class.
    rep = yaml.representer.SafeRepresenter()
    rep.add_representer(
        AnsibleUnicode,
        represent_unicode,
    )
    stream = AnsibleUnicode(u'ö')
    assert yaml.dump(stream, Dumper=AnsibleDumper) == 'o'



# Generated at 2022-06-25 04:34:26.607151
# Unit test for function represent_binary
def test_represent_binary():
    s = '\x00\x00'
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, s) == "!!binary |\n  AAA=\n"

# Generated at 2022-06-25 04:34:32.533273
# Unit test for function represent_binary
def test_represent_binary():
    represent_binary(AnsibleDumper, b'foo')

# Generated at 2022-06-25 04:34:35.110672
# Unit test for function represent_binary
def test_represent_binary():
    representer = AnsibleDumper()
    data = b'foo'
    value = representer.represent_binary(data)
    assert value == b'!!binary "Zm9v"'


# Generated at 2022-06-25 04:34:42.200077
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

    # Testing the output of a basic string
    data = AnsibleVaultEncryptedUnicode('ciphertext')
    output = dumper.represent_data(data)
    assert output == '!vault |\n  %YAML 1.1\n  --- !binary |\n    Y2lwaGVydGV4dA==\n...\n'

    # Testing the output of a more complex string with new lines
    data = AnsibleVaultEncryptedUnicode('ciphertext\nciphertext\nciphertext')
    output = dumper.represent_data(data)

# Generated at 2022-06-25 04:34:49.662423
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = 'some_cipher_text'
    data = AnsibleVaultEncryptedUnicode(data)
    assert isinstance(data, AnsibleVaultEncryptedUnicode)
    value = represent_vault_encrypted_unicode(AnsibleDumper, data)
    assert isinstance(value, AnsibleUnicode)
    assert '!vault' in text_type(value)
    assert 'some_cipher_text' in text_type(value)

# Generated at 2022-06-25 04:35:00.692013
# Unit test for function represent_binary
def test_represent_binary():
    # These tests are based on the test_represent_scalar function
    # of yaml.representer #1.1.3

    # Empty string
    representer = yaml.representer.SafeRepresenter()
    represent_binary = representer.represent_binary
    assert represent_binary('') == "''"

    # String with backslash

# Generated at 2022-06-25 04:35:06.063469
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(b'i\xea\x8b\xba\x88').startswith(u'!!binary |\n  aWu1w6nigIoK      \n')

# Generated at 2022-06-25 04:35:08.825160
# Unit test for function represent_hostvars
def test_represent_hostvars():
    d = AnsibleDumper()
    output = d.represent_data(HostVars())
    assert output == "!!python/object:ansible.vars.hostvars.HostVars {}"

# Generated at 2022-06-25 04:35:11.902052
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert represent_hostvars(AnsibleDumper, {"data": "123"}) == {'data': '123'}

# Generated at 2022-06-25 04:35:17.964017
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import AnsibleUndefined
    value = AnsibleUndefined()
    dumper = AnsibleDumper()
    result = dumper.represent_data(value)
    assert(result == "")

# Generated at 2022-06-25 04:35:23.044239
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    assert represent_vault_encrypted_unicode(AnsibleDumper, b'$ANSIBLE_VAULT;1.1;AES256\n3363646537366531343565666365656634303930323535306532303537356239613663623338c') == '!vault |\n  $ANSIBLE_VAULT;1.1;AES256\n  3363646537366531343565666365656634303930323535306532303537356239613663623338c'


# Generated at 2022-06-25 04:35:36.596526
# Unit test for function represent_hostvars
def test_represent_hostvars():

    hv = HostVars()
    assert repr(hv) == "HostVars({}, {})"

    hv['var1'] = 'value1'
    hv['var2'] = 'value2'

    # This is what we're checking
    assert repr(hv) == "HostVars({'var1': 'value1', 'var2': 'value2'}, {})"
    assert repr(hv._hostvars_variables) == "{}"

    hv = HostVars()
    hv.update({'var1': 'value1', 'var2': 'value2'})
    assert repr(hv) == "HostVars({'var1': 'value1', 'var2': 'value2'}, {})"

# Generated at 2022-06-25 04:35:43.876257
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    ansible_dumper = AnsibleDumper()

    # create an AnsibleVaultEncryptedUnicode instance
    # with ciphertext 'ansible'
    ciphertext = AnsibleVaultEncryptedUnicode._encrypt_text('ansible', b'12345')
    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode(ciphertext)

    actual = ansible_dumper.represent_scalar(u'!vault', ansible_vault_encrypted_unicode._ciphertext.decode(), style='|')

    assert actual == "!vault 'ansible'\n"

# Generated at 2022-06-25 04:35:46.962993
# Unit test for function represent_binary
def test_represent_binary():
    _binary = AnsibleDumper.represent_binary(binary_type('foo'))
    assert _binary == (yaml.representer.SafeRepresenter.represent_binary(None, binary_type('foo')))



# Generated at 2022-06-25 04:35:52.936437
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.loader import AnsibleLoader

    assert AnsibleLoader(HostVars({"foo": "bar"})).get_single_data() == {"foo": "bar"}


###


# Generated at 2022-06-25 04:35:55.314091
# Unit test for function represent_undefined
def test_represent_undefined():
    result = yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper)
    assert result == ''


# Generated at 2022-06-25 04:36:01.600812
# Unit test for function represent_hostvars

# Generated at 2022-06-25 04:36:10.861462
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    representer = AnsibleDumper()

# Generated at 2022-06-25 04:36:17.977387
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Arrange
    dumper = AnsibleDumper
    rep = dumper.representers[AnsibleVaultEncryptedUnicode]


# Generated at 2022-06-25 04:36:21.056613
# Unit test for function represent_unicode
def test_represent_unicode():
    # TODO
    pass


if __name__ == '__main__':
    test_represent_unicode()

# Generated at 2022-06-25 04:36:24.481861
# Unit test for function represent_undefined
def test_represent_undefined():
    ansible_dumper = AnsibleDumper
    test_data = AnsibleUndefined('unit test')
    ansible_dumper.add_representer(
        AnsibleUndefined,
        represent_undefined,
    )
    ansible_dumper.represent_undefined(ansible_dumper, test_data)

# Generated at 2022-06-25 04:36:41.575966
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dump = yaml.dump(HostVars(dict(a=1, b=2)), Dumper=AnsibleDumper)
    result = yaml.load(dump)
    assert result == dict(a=1, b=2)



# Generated at 2022-06-25 04:36:53.020556
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-25 04:36:57.434485
# Unit test for function represent_binary
def test_represent_binary():
    ''' Tests represent_binary function '''

    representer = AnsibleDumper()
    result = representer.represent_binary(representer, "test")
    assert type(result) == yaml.nodes.ScalarNode

# vim: set expandtab ts=4 sw=4:

# Generated at 2022-06-25 04:36:59.638804
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    data = AnsibleUndefined()
    obj = dumper.represent_data(data)
    assert not obj


__all__ = ['AnsibleDumper']

# Generated at 2022-06-25 04:37:03.180018
# Unit test for function represent_undefined
def test_represent_undefined():
    assert represent_undefined(None, AnsibleUndefined()) == True
    assert represent_undefined(None, object()) == None


# Generated at 2022-06-25 04:37:12.861684
# Unit test for function represent_binary
def test_represent_binary():
    # AnsibleSafeDumper(
    #     default_style='|', default_flow_style=False,
    #     canonical=False, indent=4, width=80, line_break='\n',
    #     encoding=None, explicit_start=None, explicit_end=None,
    #     version=None, tags=None)
    dumper = AnsibleDumper(width=80)
    r = dumper.represent_binary("\x00\x7f\xff\xfe")
    assert r == u'!!binary "AP8/"\n'

    dumper = AnsibleDumper(width=80)
    r = dumper.represent_binary("\x00\x7f\xff\xfe", style='>')
    assert r == u'!!binary ">AP8/"\n'

# Unit test

# Generated at 2022-06-25 04:37:15.274773
# Unit test for function represent_hostvars
def test_represent_hostvars():
    h = HostVars({
        "a": "b",
        "c": "d"
    })
    assert represent_hostvars(None, h) == "a: b\nc: d\n"

# Generated at 2022-06-25 04:37:25.009617
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    rep = AnsibleDumper.representers.get(AnsibleVaultEncryptedUnicode)
    obj = AnsibleVaultEncryptedUnicode("my_secret")

# Generated at 2022-06-25 04:37:25.723668
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    ''' This function is only to make this module importable in tests
    '''
    pass

# Generated at 2022-06-25 04:37:30.137392
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    yaml_out = """!vault |
          $ANSIBLE_VAULT;1.1;AES256
          39646666633534663233393166373039663266663635333137613762633931613731376137396334
          64623433336665653839333061303436393565306538393961613030623131633861316133393239
          3136386465363562346139
          ---------------END_VAULT_BLOB---------------
          """

# Generated at 2022-06-25 04:38:01.396717
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert(True)

# Generated at 2022-06-25 04:38:07.107183
# Unit test for function represent_binary
def test_represent_binary():
    """
    Test the output of represent_binary.

    If a datatype is changed, test_yaml.YamlTestCase.test_syntax_datatypes
    needs to be updated as well.
    """

    assert yaml.dump(dict({"a": "b"}), Dumper=AnsibleDumper) == '{a: b}\n'
    assert yaml.dump(dict({"a": AnsibleUnsafeBytes("b")}), Dumper=AnsibleDumper) == '{a: !!binary b}\n'

# Generated at 2022-06-25 04:38:08.741788
# Unit test for function represent_undefined
def test_represent_undefined():
    yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper, default_flow_style=False)

# Generated at 2022-06-25 04:38:13.516904
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    d = AnsibleDumper([])
    assert d.represent_vault_encrypted_unicode(AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\n\n')) == "!vault |\n  $ANSIBLE_VAULT;1.1;AES256\n\n"



# Generated at 2022-06-25 04:38:22.164584
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.safe_dump(u'abcd', Dumper=AnsibleDumper) == 'abcd\n...\n'
    assert yaml.safe_dump(u'#### abcd', Dumper=AnsibleDumper) == '#### abcd\n...\n'
    assert yaml.safe_dump(u'#### abcd #####', Dumper=AnsibleDumper) == '#### abcd #####\n...\n'
    assert yaml.safe_dump(u'<test> abcd </test>', Dumper=AnsibleDumper) == '<test> abcd </test>\n...\n'



# Generated at 2022-06-25 04:38:25.276774
# Unit test for function represent_undefined
def test_represent_undefined():
    rep = yaml.dumper.SafeDumper()
    assert rep.represent_undefined(AnsibleUndefined()) == False

# Generated at 2022-06-25 04:38:31.940632
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-25 04:38:37.370215
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = {'a': 1, 'b': 2}
    result = yaml.dump(data, Dumper=AnsibleDumper, default_flow_style=False)
    assert result == 'a: 1\nb: 2\n'



# Generated at 2022-06-25 04:38:39.299252
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.safe_dump(AnsibleUndefined(), default_flow_style=True, Dumper=AnsibleDumper) == ''

# Generated at 2022-06-25 04:38:45.412231
# Unit test for function represent_undefined
def test_represent_undefined():

    # We can't directly use AnsibleDumper here because it is used by
    # yaml.safe_dump and if we use it here then it will start calling
    # yaml.SafeDumper.represent_dict instead of yaml.BaseRepresenter.represent_dict
    # which is failing an assert and the test is failing.
    rep = AnsibleDumper()

    # We are just checking the return value of this function, function should
    # return False if an undefined value is passed to it
    ret = rep.represent_undefined(AnsibleUndefined)
    assert not ret

    # We are just checking the return value of this function, function should
    # return True if any value other than undefined is passed to it
    ret = rep.represent_undefined(1)
    assert ret

# Generated at 2022-06-25 04:39:53.349504
# Unit test for function represent_hostvars
def test_represent_hostvars():
    float_0 = -710.3
    ansible_vault_encrypted_unicode_0 = module_0.AnsibleVaultEncryptedUnicode(float_0)
    str_2 = 'XJ9Tt*8waP|{<8"'
    set_0 = {str_2}
    ansible_unicode_0 = module_0.AnsibleUnicode()
    ansible_dumper_0 = AnsibleDumper(set_0, str_2, ansible_unicode_0)
    list_0 = [ansible_unicode_0, ansible_vault_encrypted_unicode_0]
    float_1 = 1948.0

# Generated at 2022-06-25 04:40:02.285253
# Unit test for function represent_hostvars
def test_represent_hostvars():
    ansible_mapping_0 = module_0.AnsibleMapping()
    ansible_mapping_1 = module_0.AnsibleMapping()
    ansible_sequence_0 = module_0.AnsibleSequence(ansible_mapping_1)
    ansible_sequence_1 = module_0.AnsibleSequence(ansible_mapping_0, ansible_sequence_0)
    ansible_mapping_1.update(ansible_sequence_0, ansible_mapping_0)
    ansible_mapping_1.update(ansible_sequence_1, ansible_mapping_0)
    ansible_mapping_0.update(ansible_mapping_1, ansible_sequence_0)

# Generated at 2022-06-25 04:40:07.735687
# Unit test for function represent_binary
def test_represent_binary():
    float_0 = -398.1
    list_0 = [-398.1, -398.1, float_0, float_0]
    float_1 = -398.1
    ansible_vault_encrypted_unicode_0 = module_0.AnsibleVaultEncryptedUnicode(float_1)
    ansible_unicode_0 = module_0.AnsibleUnicode(list_0, ansible_vault_encrypted_unicode_0)
    str_0 = '|'
    set_0 = {str_0}
    ansible_dumper_0 = AnsibleDumper(set_0, str_0, ansible_unicode_0)

# Generated at 2022-06-25 04:40:15.908344
# Unit test for function represent_hostvars
def test_represent_hostvars():
    float_0 = -1326.6
    ansible_vault_encrypted_unicode_0 = module_0.AnsibleVaultEncryptedUnicode(float_0)
    str_0 = '&w1H'
    float_1 = 0.76
    str_1 = '8PJzuz*tO'
    set_0 = {str_1, str_0}
    ansible_unicode_0 = module_0.AnsibleUnicode()
    ansible_dumper_0 = AnsibleDumper(set_0, str_0, ansible_unicode_0)
    list_0 = [ansible_vault_encrypted_unicode_0, ansible_unicode_0]

# Generated at 2022-06-25 04:40:24.959054
# Unit test for function represent_hostvars
def test_represent_hostvars():
    float_0 = -710.3
    ansible_vault_encrypted_unicode_0 = module_0.AnsibleVaultEncryptedUnicode(float_0)
    str_0 = 'XJ9Tt*8waP|{<8"'
    set_0 = {str_0}
    ansible_unicode_0 = module_0.AnsibleUnicode()
    ansible_dumper_0 = AnsibleDumper(set_0, str_0, ansible_unicode_0)
    list_0 = [ansible_unicode_0, ansible_vault_encrypted_unicode_0]
    var_0 = ansible_dumper_0.represent_data(list_0)
    float_1 = 1.0
    ansible_dumper_1 = AnsibleD

# Generated at 2022-06-25 04:40:31.682005
# Unit test for function represent_binary
def test_represent_binary():
    function_0 = represent_binary
    float_0 = -710.3
    ansible_vault_encrypted_unicode_0 = module_0.AnsibleVaultEncryptedUnicode(float_0)
    str_0 = 'XJ9Tt*8waP|{<8"'
    set_0 = {str_0, ansible_vault_encrypted_unicode_0}
    ansible_unicode_0 = module_0.AnsibleUnicode()
    ansible_dumper_0 = AnsibleDumper(set_0, str_0, ansible_unicode_0, ansible_vault_encrypted_unicode_0)
    ansible_dumper_1 = AnsibleDumper(float_0, str_0, ansible_dumper_0)

# Generated at 2022-06-25 04:40:40.448173
# Unit test for function represent_hostvars
def test_represent_hostvars():
    float_0 = -710.3
    ansible_vault_encrypted_unicode_0 = module_0.AnsibleVaultEncryptedUnicode(float_0)
    str_0 = 'XJ9Tt*8waP|{<8"'
    set_0 = {str_0}
    ansible_unicode_0 = module_0.AnsibleUnicode()
    ansible_dumper_0 = AnsibleDumper(set_0, str_0, ansible_unicode_0)
    list_0 = [ansible_unicode_0, ansible_vault_encrypted_unicode_0]
    var_0 = ansible_dumper_0.represent_data(list_0)
    float_1 = 1948.0
    ansible_dumper_1 = AnsibleD

# Generated at 2022-06-25 04:40:48.083515
# Unit test for function represent_binary
def test_represent_binary():
    str_0 = 'C6gIa6,O\x1f|>Q'
    str_1 = ':\\J_u#7%B!\x1d'
    str_2 = 'm\x1b!{8<)%c'
    str_3 = 'Wf*8n2g\x1d'
    str_4 = 'iRtnKM1'
    str_5 = 'x3_1K'
    ansible_unicode_0 = module_0.AnsibleUnicode()
    ansible_dumper_0 = AnsibleDumper(str_5, str_4, ansible_unicode_0)
    ansible_unsafe_bytes_0 = module_0.AnsibleUnsafeBytes(str_2)

# Generated at 2022-06-25 04:40:52.481833
# Unit test for function represent_hostvars

# Generated at 2022-06-25 04:40:55.251905
# Unit test for function represent_binary
def test_represent_binary():
    '''
    Ensure the function returns a binary string
    '''
    string_0 = b'ansible_test'
    if not isinstance(string_0, binary_type):
        raise AssertionError('Representer test failed: %s' % string_0)
