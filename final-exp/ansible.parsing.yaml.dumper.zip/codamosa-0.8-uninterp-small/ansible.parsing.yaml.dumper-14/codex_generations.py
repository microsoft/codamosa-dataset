

# Generated at 2022-06-25 04:32:04.691054
# Unit test for function represent_binary
def test_represent_binary():
    var_0 = AnsibleUnsafeText()
    var_0.__init__()
    with pytest.raises(yaml.representer.RepresenterError) as pytest__exception:
        represent_binary(var_0, var_0)


# Generated at 2022-06-25 04:32:07.054765
# Unit test for function represent_hostvars
def test_represent_hostvars():
    set_0 = set()
    var_0 = represent_hostvars(set_0)
    assert round(var_0, 1) == round(0.0, 1)



# Generated at 2022-06-25 04:32:13.121134
# Unit test for function represent_binary
def test_represent_binary():
    # This is just to test the representer function and not AnsibleDumper as a whole
    data = None
    representer = yaml.representer.SafeRepresenter()
    actual = represent_binary(representer, data)
    expected = yaml.representer.SafeRepresenter.represent_binary(representer, binary_type(data))
    assert actual == expected

test_case_0()
test_represent_binary()

# Generated at 2022-06-25 04:32:22.314641
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Ensure that the function reloads the correct tags
    check_0 = yaml.Dumper()
    get_0 = check_0.open()
    get_1 = yaml.representer.SafeRepresenter.represent_str
    get_2 = '!vault'
    get_3 = 'YWJjZGVmZ2hpamtsbW5vcAFjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXoBcXJzdHV2d3h5egRhZmdoaWprbG1ub3BxcnN0dXZ3eHl6'
    get_4 = '|'
    get_5 = get_1(get_0, get_2, get_3, get_4)

# Generated at 2022-06-25 04:32:23.929690
# Unit test for function represent_undefined
def test_represent_undefined():
    set_0 = set()
    var_0 = represent_undefined(set_0)
    assert var_0 is False


# Generated at 2022-06-25 04:32:33.252334
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    text = "ANSIBLE_VAULT;1.1;AES256"
    ciphertext = "eJxlj81OwjAQRfd+BSJoBUOi1geH0RREygQ2XKZhWkHg5i5Ay5pq3IxS1iSlyYlDj51Cd0F9X0i4z4QJ07FioKTeofl0tTnjK7QTvTbTdD1XnK1RhHNVVmvwgAiFYEfC6bW/6KHU6"
    data = AnsibleVaultEncryptedUnicode(ciphertext)
    assert text in represent_vault_encrypted_unicode(data)


# Generated at 2022-06-25 04:32:38.952680
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    var_0 = 'hello'
    var_1 = AnsibleVaultEncryptedUnicode(var_0)
    set_0 = AnsibleDumper()
    result = represent_vault_encrypted_unicode(set_0, var_1)
    assert result == '!vault |\n  hello\n'

# Generated at 2022-06-25 04:32:39.820145
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    assert represent_vault_encrypted_unicode(None, None) is None


# Generated at 2022-06-25 04:32:40.700154
# Unit test for function represent_unicode
def test_represent_unicode():
    pass
    # not implemented


# Generated at 2022-06-25 04:32:42.578498
# Unit test for function represent_undefined
def test_represent_undefined():
    ansible_rep_palette = AnsibleUndefined()
    ansible_rep_palette.__bool__()


# Generated at 2022-06-25 04:32:47.861003
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault_secret = VaultLib.new()
    vault_text = u"$ANSIBLE_VAULT;1.1;AES256\nblahblahblahblah\n"
    ciphertext = vault_secret.encrypt(vault_text)
    ciphertext = ciphertext.decode('utf-8')
    ciphertext = ciphertext.splitlines()[1].encode('utf-8')
    ansible_vault_obj = AnsibleVaultEncryptedUnicode(ciphertext)
    dumper = AnsibleDumper()

# Generated at 2022-06-25 04:32:50.100370
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    assert dumper.represent_unicode(u'a') == dumper.represent_unicode('a')


# Generated at 2022-06-25 04:32:57.865568
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper
    assert dumper.represent_hostvars(dumper, HostVars({'a': 'b'})) == {'a': 'b'}
    assert dumper.represent_hostvars(dumper, HostVars(dict(a=1, b=2, c=3))) == dict(a=1, b=2, c=3)
    h = HostVarsVars()
    h['a'] = 1
    h['b'] = 2
    h['c'] = 3
    assert dumper.represent_hostvars(dumper, h) == dict(a=1, b=2, c=3)

# Generated at 2022-06-25 04:33:08.573242
# Unit test for function represent_binary
def test_represent_binary():
    from ansible.compat.tests import unittest
    from ansible.module_utils.common.yaml import AnsibleDumper
    import yaml
    import sys

    class TestRepresentBinary(unittest.TestCase):
        def test_represent_single_byte(self):
            data = b'\x00'
            expected = '!!binary |\n  AAA=\n'
            result = yaml.dump(data, Dumper=AnsibleDumper)
            self.assertEqual(result, expected)

        def test_represent_multiple_bytes(self):
            data = b'\x00\x01\x80\x81\xFF'
            expected = '!!binary |\n  AAECAwQFBgc=\n'

# Generated at 2022-06-25 04:33:20.004485
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Testing represent_vault_encrypted_unicode
    # Need to import AnsibleVaultEncryptedUnicode here
    # because the above import is a representation
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText, AnsibleUnsafeBytes
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.constructor import AnsibleConstructorError
    from ansible.template import AnsibleUndefined
    from ansible.vars.manager import VarsManager


# Generated at 2022-06-25 04:33:28.158270
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    d = AnsibleDumper(width=10000)
    data = AnsibleVaultEncryptedUnicode(b'$ANSIBLE_VAULT;1.1;AES256\n383332313935316533316135323430363136356561353533353262393437383566303932346633\n3631303635383065393663316363623365383162666162350a\n')
    result = d.represent_vault_encrypted_unicode(data)

# Generated at 2022-06-25 04:33:34.002843
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-25 04:33:40.536705
# Unit test for function represent_unicode
def test_represent_unicode():
    obj = yaml.serializer.Serializer()
    obj.encoding = 'utf-8'

    assert obj.serialize(['Test String']) == "[Test String]\n"
    assert obj.serialize(['Test String', 'Test String 2']) == "[Test String, Test String 2]\n"
    assert obj.serialize(["'Test' String"]) == "['Test' String]\n"
    assert obj.serialize(['\x43\x4c\x4f\x4e\x22\x20String']) == "[CLON\" String]\n"
    assert obj.serialize(['\x43\x4c\x4f\x4e\x22\x20String\n']) == "[CLON\" String\n]\n"

# Generated at 2022-06-25 04:33:47.553395
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.module_utils.common.yaml.objects import AnsibleMapping
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager(loader=None, sources='localhost,')
    variable_manager = VariableManager(loader=None, inventory=inventory)

    h = HostVars(variable_manager, 'localhost')
    h['localhost'] = 'foo'
    assert represent_hostvars(None, h) == represent_hostvars(None, dict(h))

    # The ansible variable_manager will change empty dict to AnsibleMapping,
    # make sure that it can be represented.
    variable_manager.set_nonpersistent_facts({'_ansible_no_log': True})

# Generated at 2022-06-25 04:33:53.279990
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    data = {'some': 'data'}
    host = HostVars(data)
    repr = yaml.safe_dump(host, Dumper=dumper, default_flow_style=False)
    assert repr == "---\nsome: data\n"



# Generated at 2022-06-25 04:33:59.801218
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    assert dumper.represent_binary(dumper, b'hello') == u'!!binary |\n  aGVsbG8=\n'



# Generated at 2022-06-25 04:34:05.123723
# Unit test for function represent_binary
def test_represent_binary():
    result = yaml.representer.BaseRepresenter.represent_binary(None, 'foo'.encode())
    assert result == "!binary |-\n  Zm9v\n"

# Generated at 2022-06-25 04:34:13.893952
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert yaml.dump(HostVars({'a': '3', 'b': 5}), Dumper=AnsibleDumper) == """{a: 3, b: 5}"""
    assert yaml.dump(HostVarsVars({'a': '3', 'b': 5}), Dumper=AnsibleDumper) == """{a: 3, b: 5}"""
    assert yaml.dump(VarsWithSources({'a': '3', 'b': VarsWithSources({'x': 'y'})}), Dumper=AnsibleDumper) == """{a: 3, b: {x: y}}"""



# Generated at 2022-06-25 04:34:22.753784
# Unit test for function represent_hostvars
def test_represent_hostvars():
    ''' Test representer function for hostvars.

    hostvars is an object which contains lots of other objects, including
    recursion, so this is a test of hostvars
    '''
    # Create a variable for the test, and an expected value
    hv = HostVars({'k1': u'v1', 'k2': 2})
    hv.vars = hv
    hv.vars.vars = hv.vars
    hv.vars.vars.vars = hv.vars.vars

    # Ensure that recursive object is rendered as expected
    expected = dict(k1='v1', k2=2)
    assert dict(hv) == expected
    assert hv.vars.vars.vars.vars.vars.vars.vars.vars

# Generated at 2022-06-25 04:34:28.032232
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper(None)
    # Test represent_unicode with str
    u_obj = u'foo'
    data = dumper.represent_unicode(u_obj)
    assert data == u"foo\n..."

    # Test represent_unicode with unicode
    u_obj = u'foo\u263a'
    data = dumper.represent_unicode(u_obj)
    assert data == u"foo\u263a\n..."



# Generated at 2022-06-25 04:34:30.594859
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, AnsibleUnicode("my_string")) == represent_unicode(None, u"my_string")



# Generated at 2022-06-25 04:34:36.035987
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    yaml.add_representer(
        AnsibleVaultEncryptedUnicode,
        represent_vault_encrypted_unicode
    )

    # Test representation of vault encrypted unicode object

# Generated at 2022-06-25 04:34:42.125873
# Unit test for function represent_unicode
def test_represent_unicode():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import AnsibleUndefined

    yaml_str = yaml.dump(['foo', AnsibleUnsafeText(u'bar'), AnsibleUndefined(u'baz', 42)], Dumper=AnsibleDumper)
    assert yaml_str == "- foo\n- bar\n- baz\n"

# Generated at 2022-06-25 04:34:50.101326
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-25 04:34:56.217935
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # construct an AnsibleVaultEncryptedUnicode object
    import ansible.parsing.vault as vault
    a = vault.VaultLib()
    b = a.encrypt("hello world")
    av_obj = ansible.parsing.yaml.objects.AnsibleVaultEncryptedUnicode(b)
    # dump it
    result = yaml.dump(av_obj, Dumper=AnsibleDumper)
    # check the results

# Generated at 2022-06-25 04:35:08.002645
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    value = u'hello world'
    av = AnsibleVaultEncryptedUnicode(value.encode())
    assert not av._is_encoded
    assert av._ciphertext == av._decoded_text
    assert av._ciphertext == value.encode()
    d = AnsibleDumper()
    assert d.represent_data(av) == ansible_representation(av)



# Generated at 2022-06-25 04:35:10.451777
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert yaml.dump(HostVars(dict(a=1, b=2)), default_flow_style=True, Dumper=AnsibleDumper) == '{a: 1, b: 2}\n...\n'



# Generated at 2022-06-25 04:35:21.080365
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib

    vault = VaultLib([], 'password')
    data = b'hello world'
    encrypted_data = vault.encrypt(data)
    vault_data = AnsibleVaultEncryptedUnicode(encrypted_data)

    assert vault_data._ciphertext == encrypted_data

    yaml_data = yaml.dump(vault_data, Dumper=AnsibleDumper)


# Generated at 2022-06-25 04:35:28.642402
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper

# Generated at 2022-06-25 04:35:36.384824
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper(indent=2)
    value = u'This is my secret variable'

# Generated at 2022-06-25 04:35:39.350765
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    data = b'\x00\x01\x02'
    # data when converted to SafeRepresenter will have the following
    # representation: !!binary |
    #    AAEC
    representation = dumper.represent_binary(dumper, data)
    assert representation.startswith('!!binary |')
    assert representation.endswith('\n')

# Generated at 2022-06-25 04:35:45.765389
# Unit test for function represent_unicode
def test_represent_unicode():
    data_in = b'\xe2\x9c\x93'
    data_out = b'\xe2\x9c\x93'

    assert data_in == data_out

    data_in = b'\xe2\x9c\x93\n'
    data_out = b'\xe2\x9c\x93\n'

    assert data_in == data_out

    data_in = u'\xe2\x9c\x93'
    data_out = u'\xe2\x9c\x93'

    assert data_in == data_out

    data_in = u'\xe2\x9c\x93\n'
    data_out = u'\xe2\x9c\x93\n'

    assert data_in == data_out

# Generated at 2022-06-25 04:35:54.645408
# Unit test for function represent_unicode
def test_represent_unicode():
    unicode_text = 'unicode text'
    yaml_text = yaml.dump({'unicode': unicode_text}, Dumper=AnsibleDumper)
    assert list(yaml.load_all(yaml_text))[0]['unicode'] == unicode_text

    unicode_text = u'unicode text'
    yaml_text = yaml.dump({'unicode': unicode_text}, Dumper=AnsibleDumper)
    assert list(yaml.load_all(yaml_text))[0]['unicode'] == unicode_text



# Generated at 2022-06-25 04:36:03.651204
# Unit test for function represent_binary
def test_represent_binary():
    '''
    This tests the representation of bytes objects
    '''
    import sys

    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnsafeBytes


# Generated at 2022-06-25 04:36:08.285634
# Unit test for function represent_binary
def test_represent_binary():
    from ansible.module_utils.six.moves import StringIO
    stream = StringIO()
    dumper = AnsibleDumper(stream, default_flow_style=False)
    dumper.open()
    dumper.represent(binary_type(b"test\r\nvalue"))
    dumper.close()
    assert stream.getvalue() == 'test\\r\\nvalue\n...\n'

# Generated at 2022-06-25 04:36:28.539175
# Unit test for function represent_binary
def test_represent_binary():
    dict_0 = None
    bytes_0 = None
    int_0 = -3305
    str_0 = 'failed to update users password: %s'
    str_1 = 'f~+{W]pM7rZy8\x0b0K)%'
    float_0 = -1293.8
    tuple_0 = (str_0, str_1, float_0)
    ansible_dumper_0 = AnsibleDumper(dict_0, int_0, dict_0, tuple_0)
    int_1 = 952
    ansible_dumper_1 = AnsibleDumper(dict_0, bytes_0, ansible_dumper_0, int_1)
    str_2 = '.H]JP5.f9-j%H\tt'

# Generated at 2022-06-25 04:36:39.505849
# Unit test for function represent_binary
def test_represent_binary():
    dict_0 = None
    bytes_0 = None
    int_0 = -3305
    str_0 = 'failed to update users password: %s'
    str_1 = 'f~+{W]pM7rZy8\x0b0K)%'
    float_0 = -1293.8
    tuple_0 = (str_0, str_1, float_0)
    ansible_dumper_0 = AnsibleDumper(dict_0, int_0, dict_0, tuple_0)
    int_1 = 952
    ansible_dumper_1 = AnsibleDumper(dict_0, bytes_0, ansible_dumper_0, int_1)
    str_2 = '.H]JP5.f9-j%H\tt'

# Generated at 2022-06-25 04:36:44.230618
# Unit test for function represent_binary
def test_represent_binary():
    dict_0 = None
    bytes_0 = None
    int_0 = -3305
    str_0 = 'failed to update users password: %s'
    str_1 = 'f~+{W]pM7rZy8\x0b0K)%'
    float_0 = -1293.8
    tuple_0 = (str_0, str_1, float_0)
    ansible_dumper_0 = AnsibleDumper(dict_0, int_0, dict_0, tuple_0)
    int_1 = 952
    ansible_dumper_1 = AnsibleDumper(dict_0, bytes_0, ansible_dumper_0, int_1)
    str_2 = '.H]JP5.f9-j%H\tt'

# Generated at 2022-06-25 04:36:53.530487
# Unit test for function represent_binary
def test_represent_binary():
    dict_0 = None
    bytes_0 = None
    int_0 = -3305
    str_0 = 'failed to update users password: %s'
    str_1 = 'f~+{W]pM7rZy8\x0b0K)%'
    float_0 = -1293.8
    tuple_0 = (str_0, str_1, float_0)
    ansible_dumper_0 = AnsibleDumper(dict_0, int_0, dict_0, tuple_0)
    int_1 = 952
    ansible_dumper_1 = AnsibleDumper(dict_0, bytes_0, ansible_dumper_0, int_1)
    str_2 = '.H]JP5.f9-j%H\tt'

# Generated at 2022-06-25 04:37:01.148270
# Unit test for function represent_binary
def test_represent_binary():
    dict_0 = None
    bytes_0 = None
    int_0 = -3305
    str_0 = 'failed to update users password: %s'
    str_1 = 'f~+{W]pM7rZy8\x0b0K)%'
    float_0 = -1293.8
    tuple_0 = (str_0, str_1, float_0)
    ansible_dumper_0 = AnsibleDumper(dict_0, int_0, dict_0, tuple_0)
    int_1 = 952
    ansible_dumper_1 = AnsibleDumper(dict_0, bytes_0, ansible_dumper_0, int_1)
    str_2 = '.H]JP5.f9-j%H\tt'

# Generated at 2022-06-25 04:37:10.065587
# Unit test for function represent_binary
def test_represent_binary():
	dict_0 = None
	bytes_0 = None
	int_0 = 1093
	str_0 = '~yA\x0b$\/\t'
	str_1 = '7V,iX9)1JoQ}'
	float_0 = -8734.3
	tuple_0 = (bytes_0, str_1, float_0)
	ansible_dumper_0 = AnsibleDumper(dict_0, int_0, dict_0, tuple_0)
	ansible_dumper_1 = AnsibleDumper()
	int_1 = 17
	ansible_dumper_2 = AnsibleDumper(dict_0, int_1, ansible_dumper_0, int_1)

# Generated at 2022-06-25 04:37:19.735876
# Unit test for function represent_binary
def test_represent_binary():
    dict_0 = None
    bytes_0 = None
    int_0 = -3305
    str_0 = 'failed to update users password: %s'
    str_1 = 'f~+{W]pM7rZy8\x0b0K)%'
    float_0 = -1293.8
    tuple_0 = (str_0, str_1, float_0)
    ansible_dumper_0 = AnsibleDumper(dict_0, int_0, dict_0, tuple_0)
    int_1 = 952
    ansible_dumper_1 = AnsibleDumper(dict_0, bytes_0, ansible_dumper_0, int_1)
    str_2 = '.H]JP5.f9-j%H\tt'

# Generated at 2022-06-25 04:37:30.639103
# Unit test for function represent_binary
def test_represent_binary():
    dict_0 = None
    bytes_0 = None
    int_0 = -3305
    str_0 = 'failed to update users password: %s'
    str_1 = 'f~+{W]pM7rZy8\x0b0K)%'
    float_0 = -1293.8
    tuple_0 = (str_0, str_1, float_0)
    ansible_dumper_0 = AnsibleDumper(dict_0, int_0, dict_0, tuple_0)
    int_1 = 952
    ansible_dumper_1 = AnsibleDumper(dict_0, bytes_0, ansible_dumper_0, int_1)
    str_2 = '.H]JP5.f9-j%H\tt'

# Generated at 2022-06-25 04:37:40.985915
# Unit test for function represent_binary
def test_represent_binary():
    dict_0 = None
    bytes_0 = None
    int_0 = -3305
    str_0 = 'failed to update users password: %s'
    str_1 = 'f~+{W]pM7rZy8\x0b0K)%'
    float_0 = -1293.8
    tuple_0 = (str_0, str_1, float_0)
    ansible_dumper_0 = AnsibleDumper(dict_0, int_0, dict_0, tuple_0)
    int_1 = 952
    ansible_dumper_1 = AnsibleDumper(dict_0, bytes_0, ansible_dumper_0, int_1)
    str_2 = '.H]JP5.f9-j%H\tt'

# Generated at 2022-06-25 04:37:47.135686
# Unit test for function represent_binary
def test_represent_binary():
    dict_0 = None
    int_0 = -738
    dict_1 = None
    str_0 = '!vault'
    str_1 = '|'
    ansible_vault_encrypted_unicode_0 = module_1.AnsibleVaultEncryptedUnicode(str_0)
    str_2 = 't'
    int_1 = 754
    ansible_dumper_0 = AnsibleDumper(dict_0, int_0, dict_1, ansible_vault_encrypted_unicode_0)
    int_2 = 729
    ansible_dumper_1 = AnsibleDumper(dict_0, int_2, ansible_dumper_0, int_1)
    str_3 = '\t'

# Generated at 2022-06-25 04:38:15.394363
# Unit test for function represent_binary
def test_represent_binary():
    pass # tests are run from a different module


# Generated at 2022-06-25 04:38:23.739295
# Unit test for function represent_binary
def test_represent_binary():
    dict_0 = None
    bytes_0 = None
    int_0 = -3305
    str_0 = 'failed to update users password: %s'
    str_1 = 'f~+{W]pM7rZy8\x0b0K)%'
    float_0 = -1293.8
    tuple_0 = (str_0, str_1, float_0)
    ansible_dumper_0 = AnsibleDumper(dict_0, int_0, dict_0, tuple_0)
    int_1 = 952
    ansible_dumper_1 = AnsibleDumper(dict_0, bytes_0, ansible_dumper_0, int_1)
    str_2 = '.H]JP5.f9-j%H\tt'

# Generated at 2022-06-25 04:38:27.867667
# Unit test for function represent_binary
def test_represent_binary():
    data = AnsibleUnsafeBytes('asdf')
    d = AnsibleDumper()
    results = yaml.representer.SafeRepresenter.represent_binary(d, data)
    assert 'asdf' in results
    assert isinstance(results, str)


# Generated at 2022-06-25 04:38:29.751432
# Unit test for function represent_binary
def test_represent_binary():
    ansible_dumper_0 = AnsibleDumper()
    ansible_unicode_0 = module_1.AnsibleUnicode()
    represent_binary(ansible_dumper_0, ansible_unicode_0)


# Generated at 2022-06-25 04:38:38.211204
# Unit test for function represent_binary
def test_represent_binary():
    dict_0 = None
    int_0 = -84
    dict_1 = None
    tuple_0 = None
    ansible_dumper_0 = AnsibleDumper(dict_0, int_0, dict_1, tuple_0)
    ansible_dumper_1 = AnsibleDumper(dict_0, int_0, dict_1, tuple_0)
    ansible_dumper_2 = AnsibleDumper(dict_0, int_0, dict_1, tuple_0)
    ansible_dumper_3 = AnsibleDumper(dict_0, int_0, dict_1, tuple_0)
    ansible_dumper_4 = AnsibleDumper(dict_0, int_0, dict_1, tuple_0)

# Generated at 2022-06-25 04:38:44.791303
# Unit test for function represent_binary
def test_represent_binary():
    dict_0 = None
    bytes_0 = None
    int_0 = -3305
    str_0 = 'failed to update users password: %s'
    str_1 = 'f~+{W]pM7rZy8\x0b0K)%'
    float_0 = -1293.8
    tuple_0 = (str_0, str_1, float_0)
    ansible_dumper_0 = AnsibleDumper(dict_0, int_0, dict_0, tuple_0)
    int_1 = 952
    ansible_dumper_1 = AnsibleDumper(dict_0, bytes_0, ansible_dumper_0, int_1)
    ansible_binary_0 = module_1.AnsibleBinary()
    var_0 = represent_binary

# Generated at 2022-06-25 04:38:54.456050
# Unit test for function represent_binary
def test_represent_binary():
    dict_0 = None
    bytes_0 = b'\x00\x01\x02\x03\x04\x05\x06\x07'
    int_0 = -3305
    str_0 = 'failed to update users password: %s'
    str_1 = 'f~+{W]pM7rZy8\x0b0K)%'
    float_0 = -1293.8
    tuple_0 = (str_0, str_1, float_0)
    ansible_dumper_0 = AnsibleDumper(dict_0, int_0, dict_0, tuple_0)
    int_1 = 952
    ansible_dumper_1 = AnsibleDumper(dict_0, bytes_0, ansible_dumper_0, int_1)
   

# Generated at 2022-06-25 04:38:56.158535
# Unit test for function represent_binary
def test_represent_binary():
    ansible_dumper_0 = AnsibleDumper()



# Generated at 2022-06-25 04:39:02.777636
# Unit test for function represent_binary
def test_represent_binary():
    # Test for '__init__' feature of class AnsibleDumper
    # __init__(self, default_style=None, default_flow_style=False, canonical=None, indent=None, width=None, allow_unicode=None, line_break=None, encoding=None, explicit_start=None, explicit_end=None, version=None, tags=None)
    # AnsibleDumper(self, stream, default_flow_style=None, canonical=None, indent=None, width=None, allow_unicode=None, line_break=None, encoding=None, explicit_start=None, explicit_end=None, version=None, tags=None)
    # Tests for TypeError raised by AnsibleDumper.add_representer when 'data'
    # is not an instance of AnsibleUnsafeBytes.
    ansible_unic

# Generated at 2022-06-25 04:39:13.538643
# Unit test for function represent_binary
def test_represent_binary():
    dict_0 = None
    bytes_0 = None
    int_0 = -3305
    str_0 = 'failed to update users password: %s'
    str_1 = 'f~+{W]pM7rZy8\x0b0K)%'
    float_0 = -1293.8
    tuple_0 = (str_0, str_1, float_0)
    ansible_dumper_0 = AnsibleDumper(dict_0, int_0, dict_0, tuple_0)
    int_1 = 952
    ansible_dumper_1 = AnsibleDumper(dict_0, bytes_0, ansible_dumper_0, int_1)
    str_2 = '.H]JP5.f9-j%H\tt'