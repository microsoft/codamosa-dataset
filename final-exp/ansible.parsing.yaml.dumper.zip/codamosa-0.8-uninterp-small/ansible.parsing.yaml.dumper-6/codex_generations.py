

# Generated at 2022-06-25 04:32:02.872002
# Unit test for function represent_unicode
def test_represent_unicode():
    text_0 = None
    var_0 = represent_unicode(text_0)


# Generated at 2022-06-25 04:32:04.738835
# Unit test for function represent_undefined
def test_represent_undefined():

    # Setup
    data = AnsibleUndefined

    # Test
    var_0 = represent_undefined(data)



# Generated at 2022-06-25 04:32:05.445583
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert False


# Generated at 2022-06-25 04:32:07.467837
# Unit test for function represent_unicode
def test_represent_unicode():
    text_0 = None
    var_0 = represent_unicode(text_0)


# Generated at 2022-06-25 04:32:11.170070
# Unit test for function represent_unicode
def test_represent_unicode():
    bytes_0 = None
    var_0 = represent_unicode(bytes_0)

# Generated at 2022-06-25 04:32:12.301325
# Unit test for function represent_unicode
def test_represent_unicode():
    unicode_0 = None
    var_0 = represent_unicode(unicode_0)


# Generated at 2022-06-25 04:32:13.677072
# Unit test for function represent_undefined
def test_represent_undefined():
    data = AnsibleUndefined('test')
    expected = False
    result = represent_undefined(data)
    assert result == expected



# Generated at 2022-06-25 04:32:16.506104
# Unit test for function represent_unicode
def test_represent_unicode():
    represent_unicode(text_type(), text_type())


# Generated at 2022-06-25 04:32:17.974458
# Unit test for function represent_undefined
def test_represent_undefined():
    data = Undefined('')
    # This should fail for the reason explained in the comments
    # above.
    assert not represent_undefined(None, data)

# Generated at 2022-06-25 04:32:22.642495
# Unit test for function represent_undefined
def test_represent_undefined():
  assert False
  ansible_0 = AnsibleDumper(None, None, None, None)
  undefined_0 = AnsibleUndefined()
  var_0 = represent_undefined(ansible_0, undefined_0)


# Generated at 2022-06-25 04:32:34.106424
# Unit test for function represent_binary
def test_represent_binary():
    representer = yaml.representer.SafeRepresenter()
    # Create a binary string of all ascii characters from 0 to 127

# Generated at 2022-06-25 04:32:40.353730
# Unit test for function represent_unicode
def test_represent_unicode():
    # Try to represent unicode with no issue
    # str -> unicode
    assert yaml.load(yaml.dump(text_type('string'), Dumper=AnsibleDumper, default_flow_style=False)) == text_type('string')
    # bytes -> unicode
    assert yaml.load(yaml.dump(binary_type('bytes'), Dumper=AnsibleDumper, default_flow_style=False)) == text_type('bytes')

# Generated at 2022-06-25 04:32:49.651825
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()

    # HostVars
    hostvars = HostVars(host_name='hostname')
    hostvars.update({'key1': {'subkey1': 'value1'}})
    hostvars.update({'key2': {'subkey2': 'value2'}})
    assert dumper.represent_hostvars(hostvars) == dumper.represent_dict({'key1': {'subkey1': 'value1'}, 'key2': {'subkey2': 'value2'}})

    # HostVarsVars
    hostvarsvars = HostVarsVars(host_name='hostname')
    hostvarsvars.update({'key1': {'subkey1': 'value1'}})
    hostvarsvars.update

# Generated at 2022-06-25 04:32:59.105996
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    vault = VaultLib(None)
    ciphertext = vault.encrypt(b'test')
    encrypted_str = AnsibleVaultEncryptedUnicode(ciphertext=ciphertext)

# Generated at 2022-06-25 04:33:03.100655
# Unit test for function represent_hostvars
def test_represent_hostvars():
    d = AnsibleDumper()
    r = d.represent_hostvars({'foo': 'bar'})
    assert r == d.represent_dict({'foo': 'bar'})



# Generated at 2022-06-25 04:33:05.596207
# Unit test for function represent_unicode
def test_represent_unicode():
    dump = yaml.dump(dict(key='value'), Dumper=AnsibleDumper, default_flow_style=False)
    assert 'value' in dump

# Generated at 2022-06-25 04:33:14.824100
# Unit test for function represent_unicode
def test_represent_unicode():
    data = dict(
        ansible_string_with_nulls=u'\x00\x01\x02\x03\x04',
        ansible_binary_string=u'\x00\x01\x02\x03\x04',
        ansible_string=u'òùìò',
        ansible_integer=1000,
        ansible_float=1000000.95,
    )

    output = yaml.dump(data, Dumper=AnsibleDumper, default_flow_style=True)


# Generated at 2022-06-25 04:33:16.185424
# Unit test for function represent_unicode
def test_represent_unicode():
    yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper)

# Generated at 2022-06-25 04:33:21.898350
# Unit test for function represent_unicode
def test_represent_unicode():
    data = b'\xef\xbb\xbffoo: bar\n'
    expected_result = text_type("foo: bar\n")
    assert (yaml.load(data) == yaml.load(expected_result))

# Generated at 2022-06-25 04:33:28.764073
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    # Instantiate a class that mimics StrictUndefined, which is usually in Jinja
    # This class defines its boolean value to be False

    class mimicked_strictundefined:
        def __init__(self, value):
            self.value = value

        def __bool__(self):
            return False

    # Ensure _fail_with_undefined_error will be called in represent_undefined
    # function
    result = dumper.represent_undefined(dumper, mimicked_strictundefined('a'))
    if result:
        raise AssertionError('represent_undefined did not call _fail_with_undefined_error')

# Generated at 2022-06-25 04:33:38.595310
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hv = HostVars(host='localhost')
    hv.set_variable('myvar', 'myval')
    hv.set_variable('othervar', 'otherval')
    hv.set_variable('not_a_host', 'localhost', delete_host=True)
    hv.set_variable('not_a_host', 'localhost')

    assert yaml.load(yaml.dump(hv, Dumper=AnsibleDumper), Loader=yaml.SafeLoader) == {'localhost': {'othervar': 'otherval', 'myvar': 'myval', 'not_a_host': 'localhost'}}

    hv.extend(HostVars(host='some_other_host'))

# Generated at 2022-06-25 04:33:40.569208
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert yaml.dump(HostVars({"a": 1, "b": 2}), Dumper=AnsibleDumper) == "a: 1\nb: 2\n"



# Generated at 2022-06-25 04:33:46.364898
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    d = AnsibleDumper()

# Generated at 2022-06-25 04:33:54.676301
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    dumper.check_scalar = None
    dumper.default_flow_style = None
    dumper.explicit_start = None
    dumper.explicit_end = None
    dumper.default_style = None
    dumper.canonical = None
    dumper.indent = None
    dumper.width = None
    dumper.line_break = None
    dumper.encoding = None
    dumper.version = None
    dumper.tags = None
    dumper.block_seq_indent = None
    dumper.top_level_colon_align = None
    dumper.prefix_colon = None
    dumper.quotation_flags = None
    dumper.preserve_quotes = None
    dumper.single_quoted = None

# Generated at 2022-06-25 04:34:00.171488
# Unit test for function represent_binary
def test_represent_binary():
    representer = AnsibleDumper.yaml_representers[binary_type]
    value = binary_type(b'12345\x00')
    assert representer(None, value) == u'!!binary |\n  MTIzNDU=\n'

# Generated at 2022-06-25 04:34:06.140795
# Unit test for function represent_binary
def test_represent_binary():
    yaml.dump({u"\u2603": u"\u2141"}, stream=None, Dumper=AnsibleDumper)
    yaml.dump({b"\xe2\x98\x83": b"\xe2\x85\x81"}, stream=None, Dumper=AnsibleDumper)

# Generated at 2022-06-25 04:34:12.010320
# Unit test for function represent_binary
def test_represent_binary():

    from ansible.parsing.yaml.objects import AnsibleUnsafeBytes

    bytes_obj = AnsibleUnsafeBytes(b"test")
    assert yaml.dump(bytes_obj, Dumper=AnsibleDumper) == '!!binary |\n' \
                                                        '  dGVzdA==\n'



# Generated at 2022-06-25 04:34:21.879091
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper(indent=4,
                           default_flow_style=False,
                           tags=None)

# Generated at 2022-06-25 04:34:27.120592
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    aveu = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;AES256;123456789012345678901234567890123\n1234567890123456\n')
    result = represent_vault_encrypted_unicode(AnsibleDumper, aveu)
    assert result == yaml.representer.SafeRepresenter.represent_str(AnsibleDumper, aveu._ciphertext.decode())

# Generated at 2022-06-25 04:34:30.477394
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert represent_hostvars(None, HostVars(dict(foo="bar"))) == yaml.representer.SafeRepresenter.represent_dict(None, dict(foo="bar"))



# Generated at 2022-06-25 04:34:38.708641
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper) == 'true\n'

# Generated at 2022-06-25 04:34:44.155747
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = AnsibleVaultEncryptedUnicode('foo')
    yaml.add_representer(AnsibleVaultEncryptedUnicode, represent_vault_encrypted_unicode)
    yaml_representation = yaml.dump(data, Dumper=yaml.SafeDumper)
    assert yaml_representation == '!vault |\n  foo\n'

# Generated at 2022-06-25 04:34:49.446415
# Unit test for function represent_binary
def test_represent_binary():
    # example data
    data = b'\x01$'
    # ensure the function can process binary data
    assert yaml.dump(data, Dumper=AnsibleDumper) == '!!binary |-\n  AQQK'

# Generated at 2022-06-25 04:35:00.669395
# Unit test for function represent_undefined
def test_represent_undefined():
    # data is a Dummy object with its __bool__ set to false
    data = AnsibleUndefined(u'foo')
    data.__bool__ = lambda self: False
    dumper = AnsibleDumper()
    assert represent_undefined(dumper, data) is False

    # data is a Dummy object with its __bool__ set to true
    data = AnsibleUndefined(u'foo')
    data.__bool__ = lambda self: True
    assert represent_undefined(dumper, data) is True

    # data is a Dummy object with __bool__ not set
    data = AnsibleUndefined(u'foo')
    assert represent_undefined(dumper, data) is True


# Generated at 2022-06-25 04:35:02.873586
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    ansible_undefined = AnsibleUndefined()
    assert dumper.represent_undefined(ansible_undefined)



# Generated at 2022-06-25 04:35:03.965993
# Unit test for function represent_undefined
def test_represent_undefined():
    yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper)

# Generated at 2022-06-25 04:35:10.948379
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = AnsibleVaultEncryptedUnicode('string to encrypt')

    # we cannot rely on yaml.add_representer to add our object type to SafeRepresenter directly
    # because it just works for the first add_representer call, the second will not work
    yaml.SafeRepresenter.add_representer(
        AnsibleVaultEncryptedUnicode,
        represent_vault_encrypted_unicode,
    )

    val = yaml.safe_dump(data)
    assert(val == "!vault |\n  string to encrypt\n")

    # cleanup
    del yaml.SafeRepresenter.representers[AnsibleVaultEncryptedUnicode]

# Generated at 2022-06-25 04:35:21.976074
# Unit test for function represent_binary

# Generated at 2022-06-25 04:35:33.309552
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib

# Generated at 2022-06-25 04:35:37.502068
# Unit test for function represent_binary
def test_represent_binary():
    data = b'\xde@\x00\x00\x00\x00\x00\x00'
    expected_output = "!!binary |\n  " + " ".join("%02x" % ord(b) for b in data)

    actual_output = yaml.safe_dump(binary_type(data), default_flow_style=True, Dumper=AnsibleDumper)

    assert(actual_output == expected_output)



# Generated at 2022-06-25 04:35:58.484699
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib

    # Represent encrypted data using AnsibleVaultEncryptedUnicode type
    vault_pass = 'secret'
    aveu = AnsibleVaultEncryptedUnicode(u'hello', vault_pass)
    assert aveu == u'hello'

    actual = represent_vault_encrypted_unicode(None, aveu)

# Generated at 2022-06-25 04:36:08.936349
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    '''
    Make sure the table lookups and logic in the represent_vault_encrypted_unicode function work as expected
    '''

    class TestVaultEncryptedUnicode(object):
        def __init__(self, ciphertext):
            self._ciphertext = ciphertext

    class Dumper(object):
        def represent_scalar(self, tag, value, style):
            return '%s, %s, %s' % (tag, value, style)

    ciphertext = 'AES256:m5hbZplz9XUoxh6UdW6LpM1+jg6eM2Qf5BdHwp2O3fA='
    v = TestVaultEncryptedUnicode(ciphertext)

    # test expected values
    assert represent_vault_encrypted_unic

# Generated at 2022-06-25 04:36:19.845904
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    loader = DataLoader()
    vault = VaultLib([])

    # example ciphered data
    data = vault.encrypt('foo', "my secret")

    # expected result

# Generated at 2022-06-25 04:36:26.370710
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Create test data
    class Data(object):
        def __init__(self, ciphertext):
            self._ciphertext = ciphertext
        pass

    data = Data(b'$ANSIBLE_VAULT;1.1;AES256')

    # Expected result of the function
    expected_result = '!vault |\n          $ANSIBLE_VAULT;1.1;AES256'

    # Actual result from function
    actual_result = represent_vault_encrypted_unicode(None, data)

    # Assert actual result is equal to expected result
    assert actual_result == expected_result

    # End of unit test

# Generated at 2022-06-25 04:36:31.559031
# Unit test for function represent_unicode
def test_represent_unicode():
    from ansible.module_utils.common.yaml import AnsibleDumper

    yaml.add_representer(text_type, yaml.representer.SafeRepresenter.represent_str)

    assert yaml.dump(text_type("test"), Dumper=AnsibleDumper, default_flow_style=False) == "test\n...\n"
    assert yaml.dump(binary_type("test"), Dumper=AnsibleDumper, default_flow_style=False) == b"test\n...\n"

# Generated at 2022-06-25 04:36:35.347671
# Unit test for function represent_undefined
def test_represent_undefined():
    dump_data = yaml.dump({"name": AnsibleUndefined()}, Dumper=AnsibleDumper)
    assert dump_data == "name: null\n"

# Generated at 2022-06-25 04:36:39.354716
# Unit test for function represent_unicode
def test_represent_unicode():
    data = u'test'
    assert yaml.dump(data, Dumper=AnsibleDumper) == 'test\n...\n'

# Generated at 2022-06-25 04:36:44.190465
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(AnsibleDumper, AnsibleUnicode('foo')) == u"!ansible-unicode 'foo'"
    assert represent_unicode(AnsibleDumper, AnsibleUnsafeText('foo')) == u"!ansible-unsafe 'foo'"
    assert represent_unicode(AnsibleDumper, AnsibleUnsafeBytes('foo')) == u"!ansible-unsafe 'foo'"



# Generated at 2022-06-25 04:36:48.642970
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    a_dict = dict(a_dict=dict(b_dict=dict(c_data='d_value')))
    a_hostvars = HostVars(a_dict)
    dumper.represent_dict(a_hostvars)



# Generated at 2022-06-25 04:36:52.917758
# Unit test for function represent_hostvars
def test_represent_hostvars():

    assert yaml.dump(HostVars(dict(a=1, b=2)), Dumper=AnsibleDumper) == '{a: 1, b: 2}\n'
    assert yaml.dump(HostVarsVars(dict(a=1, b=2)), Dumper=AnsibleDumper) == '{a: 1, b: 2}\n'

# Generated at 2022-06-25 04:37:28.650546
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert represent_hostvars(None, {'key': 'value'}) == 'key: value'
    assert represent_hostvars(None, {}) == ''
    assert represent_hostvars(None, {'key': ['value1', 'value2']}) == 'key:\n- value1\n- value2'
    assert represent_hostvars(None, {'key': {'key1': 'value1'}}) == 'key:\nkey1: value1'



# Generated at 2022-06-25 04:37:30.108334
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'foo') == "!!binary 'Zm9v'\n"

# Generated at 2022-06-25 04:37:33.294498
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    hostvars = HostVars({"somevar": "somevalue"})
    answer = yaml.load(dumper.represent_data(hostvars))
    assert answer == hostvars.data


# Generated at 2022-06-25 04:37:36.519273
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    result = dumper.represent_undefined(dumper, AnsibleUndefined)
    assert result == True

# Generated at 2022-06-25 04:37:43.445351
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-25 04:37:46.067876
# Unit test for function represent_binary
def test_represent_binary():
    from ansible.module_utils.six import BytesIO

    stream = BytesIO()
    yaml.dump_all([b"\xff"], stream, Dumper=AnsibleDumper)
    assert stream.getvalue() == "--- !!binary |\n  /w==\n"

# Generated at 2022-06-25 04:37:53.154983
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    ad = AnsibleDumper(default_flow_style=False)

# Generated at 2022-06-25 04:38:02.035940
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    '''
    Tests the represent_vault_encrypted_unicode function.
    '''

    ciphertext = u'$ANSIBLE_VAULT;1.1;AES256\n3935303165323735343730666232393062323465383666376233666561633734616137613366\n3939373563396164383264323937373663386361656338630a37353739393061336532323532\n395f656336313862626232633432373739633264366335336236653462613162343162356365\n386337353132616232306566\n'

# Generated at 2022-06-25 04:38:06.041647
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dict_data = dict(a=1, b=2, c=3)
    hostvars = HostVars(dict_data)
    dumped_dict = yaml.dump(hostvars, Dumper=AnsibleDumper)
    assert dumped_dict == '{a: 1, b: 2, c: 3}\n'



# Generated at 2022-06-25 04:38:11.419979
# Unit test for function represent_unicode
def test_represent_unicode():
    class AnsibleDumperTest(yaml.Dumper):
        def represent_unicode(self, data):
            return yaml.representer.SafeRepresenter.represent_str(self, text_type(data))

    a = AnsibleDumperTest()
    a.represent_unicode('hello') == u'hello'