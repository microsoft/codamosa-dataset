

# Generated at 2022-06-25 04:32:04.165828
# Unit test for function represent_undefined
def test_represent_undefined():
    # Setup input parameters (mock)
    data = 'data'
    
    # Exercise SUT
    result = represent_undefined(data)
    
    # Verify results (mock)
    assert result is True



# Generated at 2022-06-25 04:32:07.046682
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    int_0 = 151
    var_0 = represent_vault_encrypted_unicode(int_0)


# Generated at 2022-06-25 04:32:08.064830
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert represent_hostvars(int_0) == '151'


# Generated at 2022-06-25 04:32:09.342461
# Unit test for function represent_unicode
def test_represent_unicode():
    int_0 = 151
    var_0 = represent_unicode(int_0)


# Generated at 2022-06-25 04:32:13.205760
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # Get a reference to the function to be tested
    func = yaml.representer.SafeRepresenter.represent_dict

    # Create the needed input data (we use HostVars here, just as a
    # convenient example
    data = HostVars({
        'foo': 'bar',
        'baz': [1, 2, 3],
    })

    # Create the expected output
    expected = {
        'foo': 'bar',
        'baz': [1, 2, 3],
    }

    # Test the function
    func(dict(data))

# Generated at 2022-06-25 04:32:15.796769
# Unit test for function represent_binary
def test_represent_binary():
    pass


# Generated at 2022-06-25 04:32:18.002226
# Unit test for function represent_unicode
def test_represent_unicode():
    int_0 = 'k'
    var_0 = represent_unicode(int_0)


# Generated at 2022-06-25 04:32:20.480148
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    int_0 = 151
    var_0 = represent_vault_encrypted_unicode(int_0)


# Generated at 2022-06-25 04:32:26.935731
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # For example, here we define the expected type and value of
    # the return from the function. This is not strictly necessary
    # in a unit test but good practice in the case of complex
    # functions
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(" ")
    expected_type =  AnsibleVaultEncryptedUnicode
    expected_return_value = ansible_vault_encrypted_unicode_0

    # Now create the test input
    ansible_dumper_0 = SafeDumper()
    ansible_dumper_0._top_level = True
    ansible_dumper_0.explicit_start = True
    ansible_dumper_0.indent = 2
    string_0 = " "
    ansible_dumper_0._indent = string

# Generated at 2022-06-25 04:32:29.789032
# Unit test for function represent_hostvars
def test_represent_hostvars():
    a = {'key': 'value'}
    assert represent_hostvars(a) == represent_hostvars(a)
    assert not represent_hostvars(a) == represent_hostvars(b)



# Generated at 2022-06-25 04:32:41.392242
# Unit test for function represent_unicode
def test_represent_unicode():
    from ansible.parsing.utils.yaml import from_yaml

    # unicode -> unicode
    assert isinstance(from_yaml(u'foo', AnsibleDumper), text_type)
    assert isinstance(from_yaml(u'foo', AnsibleDumper), AnsibleUnicode)
    # str -> unicode
    assert isinstance(from_yaml('foo', AnsibleDumper), text_type)
    assert isinstance(from_yaml('foo', AnsibleDumper), AnsibleUnicode)
    # bytes -> unicode
    assert isinstance(from_yaml(b'foo', AnsibleDumper), text_type)
    assert isinstance(from_yaml(b'foo', AnsibleDumper), AnsibleUnicode)
    # bytearray -> unicode

# Generated at 2022-06-25 04:32:51.692812
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper(default_flow_style=False)

# Generated at 2022-06-25 04:32:59.519604
# Unit test for function represent_hostvars
def test_represent_hostvars():
    ansible_dumper = AnsibleDumper()
    hostvars = HostVars({"k1": "v1"})

    # Without adding HostVars to the dumper,
    # the output will be different from what we expect
    with pytest.raises(TypeError):
        ansible_dumper.represent_data(hostvars)

    ansible_dumper.add_representer(HostVars, represent_hostvars)
    output = ansible_dumper.represent_data(hostvars)
    expected = '''
    k1: v1
    {}
    '''.format(text_type(''))
    assert(output == expected)



# Generated at 2022-06-25 04:33:09.037008
# Unit test for function represent_unicode
def test_represent_unicode():
    # Create a couple of unicode strings to test
    test_unicode_string_1 = u"This is a string with 'quotes'"
    test_unicode_string_2 = u"This is a string with quotes in unicode: \u201c\u201d"
    # Yamlify them
    new_string_1 = yaml.dump({'string': test_unicode_string_1}, Dumper=AnsibleDumper)
    new_string_2 = yaml.dump({'string': test_unicode_string_2}, Dumper=AnsibleDumper)
    # Load them
    new_string_1_loaded = yaml.safe_load(new_string_1)
    new_string_2_loaded = yaml.safe_load(new_string_2)
    # Check to see if they

# Generated at 2022-06-25 04:33:10.309354
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper.represent_undefined(None, 0)



# Generated at 2022-06-25 04:33:11.733160
# Unit test for function represent_binary
def test_represent_binary():
    t = AnsibleDumper().represent_binary(b'\x01\x02')
    assert t is not None

# Generated at 2022-06-25 04:33:14.624209
# Unit test for function represent_binary
def test_represent_binary():
    data = b'\x80\x02cq\x01K\x01\x86q\x02}q\x03.'

    assert data == AnsibleDumper.represent_binary(data)

# Generated at 2022-06-25 04:33:16.955547
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    data = {'hi': 'there'}
    result = dumper.represent_hostvars(data)
    assert result == dumper.represent_dict(dict(data))

# Generated at 2022-06-25 04:33:21.708246
# Unit test for function represent_undefined
def test_represent_undefined():
    extra_args = dict(undefined=None)
    safe_representer = yaml.SafeDumper(None, **extra_args)
    assert not safe_representer.represent_undefined(None)



# Generated at 2022-06-25 04:33:29.385377
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    import sys
    import os
    import time
    import tempfile
    import getpass
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256

    tempdir = tempfile.mkdtemp()
    vault_password_file = os.path.join(tempdir, 'vault_pass.txt')
    unencrypted_data = 'secret'
    encrypted_data = VaultAES256.encrypt(VaultSecret(vault_password_file), unencrypted_data)

    with open(vault_password_file, 'wb') as f:
        f.write(getpass.getpass().encode())

    vault_obj = VaultLib(vault_password_file)
    data = vault

# Generated at 2022-06-25 04:33:39.204971
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    astr = u'\u2713'
    encrypted = AnsibleVaultEncryptedUnicode(astr, binary_type(u'QWxhZGRpbjpvcGVuIHNlc2FtZQ=='))
    assert yaml.dump(encrypted, Dumper=AnsibleDumper) == '!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          63396361653232386332616665316136653238633961623966633036356536393739346535383061\n          643537306666343161306637373966313136363034656165623939346162373264\n          \n'

# Generated at 2022-06-25 04:33:40.437960
# Unit test for function represent_undefined
def test_represent_undefined():
    assert(yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper) == '\n')

# Generated at 2022-06-25 04:33:47.500919
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = AnsibleVaultEncryptedUnicode('test')
    stream = yaml.StringIO()
    dumper = AnsibleDumper(stream)
    dumper.represent_vault_encrypted_unicode(data)
    result = stream.getvalue().strip()

    # This is what the result should be

# Generated at 2022-06-25 04:33:58.747160
# Unit test for function represent_hostvars
def test_represent_hostvars():
    '''
    Test represent_hostvars function
    '''
    # Test with HostVars instance
    hostvars = HostVars(dict(a='A', b=False))
    assert yaml.dump(hostvars, Dumper=AnsibleDumper, default_flow_style=False) == u'!hostvars\na: A\nb: false\n'
    # Test with HostVarsVars instance
    hostvars = HostVarsVars(dict(a='A', b=False))
    assert yaml.dump(hostvars, Dumper=AnsibleDumper, default_flow_style=False) == u'!hostvars\na: A\nb: false\n'
    # Test with VarsWithSources instance

# Generated at 2022-06-25 04:34:08.765994
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.template import AnsibleUndefined

    x = AnsibleVaultEncryptedUnicode(u"bogus", u"bogus")
    x._ciphertext = VaultLib().encrypt(u"bogus", u"This is a test")

    # here we're writing out our encrypted test string, and encoding to ascii because that's what
    # yaml normally does

# Generated at 2022-06-25 04:34:12.625615
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = yaml.Dumper
    dumper.add_representer(
        AnsibleUnicode,
        represent_unicode
    )

    assert dumper.represent_scalar('tag:yaml.org,2002:str', u'foo') == 'foo\n...\n'



# Generated at 2022-06-25 04:34:14.924550
# Unit test for function represent_hostvars
def test_represent_hostvars():
    output = AnsibleDumper.represent_hostvars(
        {'one': 'two'}
    )
    assert output == '!hostvars\n  one: two\n'


# Generated at 2022-06-25 04:34:18.587531
# Unit test for function represent_binary
def test_represent_binary():
    yaml.add_representer(bytearray, lambda dumper, data: dumper.represent_scalar('tag:yaml.org,2002:binary', base64.b64encode(data).decode('ascii'), style='|'))
    byte_string = bytearray('Test'.encode('ascii'))

# Generated at 2022-06-25 04:34:20.415526
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.dump(AnsibleUndefined, Dumper=AnsibleDumper) == ""

# Generated at 2022-06-25 04:34:28.782492
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Test basic representation
    aveu = AnsibleVaultEncryptedUnicode("!vault |\n  $ANSIBLE_VAULT;1.1;AES256\n  63633892306437653964653734383635666264373066643437623762316432383065333962626266\n  61633962306261323031316535346533613631366131613035393162653933383461316165393035\n  63373831323365383566376161366238393733343533396462616665393531366637363931376237\n  626538663062663363333065343030326465626330613365633539620a")

# Generated at 2022-06-25 04:34:49.019921
# Unit test for function represent_unicode
def test_represent_unicode():
    ansible_dumper_0 = None
    bool_0 = True
    str_0 = 'O!O$IP'
    int_0 = 732
    ansible_dumper_1 = AnsibleDumper(ansible_dumper_0, bool_0, str_0, int_0)
    bool_1 = False
    list_0 = [bool_0]
    ansible_vault_encrypted_unicode_0 = module_1.AnsibleVaultEncryptedUnicode(list_0)
    var_0 = ansible_dumper_1.represent_data(ansible_vault_encrypted_unicode_0)
    var_1 = represent_undefined(bool_1)
    str_1 = 'hIR4(Z*RfH,#C'
    tuple_0 = ()


# Generated at 2022-06-25 04:35:00.628825
# Unit test for function represent_undefined
def test_represent_undefined():
    ansible_dumper_0 = None
    bool_0 = True
    str_0 = 'BSy4PqU}\n'
    int_0 = 958
    ansible_dumper_1 = AnsibleDumper(ansible_dumper_0, bool_0, str_0, int_0)
    tuple_0 = ()
    ansible_undefined_0 = module_2.AnsibleUndefined()
    bool_1 = False
    var_0 = represent_undefined(bool_1)
    var_1 = ansible_undefined_0._fail_with_undefined_error()
    bool_2 = False
    repr_0 = repr(bool_2)
    str_1 = 'N+B;2Kj<bt&+]XWKl'

# Generated at 2022-06-25 04:35:09.241249
# Unit test for function represent_hostvars
def test_represent_hostvars():
    ansible_dumper_0 = None
    bool_0 = True
    str_0 = '%c=q?7,'
    int_0 = 216
    ansible_dumper_1 = AnsibleDumper(ansible_dumper_0, bool_0, str_0, int_0)
    bool_1 = False
    host_vars_0 = module_3.HostVars(bool_1)
    var_0 = represent_hostvars(ansible_dumper_1, host_vars_0)
    float_0 = 1000.0
    host_vars_1 = module_3.HostVars(float_0)

# Generated at 2022-06-25 04:35:19.191229
# Unit test for function represent_undefined
def test_represent_undefined():
    ansible_dumper_0 = None
    bool_0 = True
    str_0 = 'O!O$IP'
    int_0 = 732
    ansible_dumper_1 = AnsibleDumper(ansible_dumper_0, bool_0, str_0, int_0)
    bool_1 = False
    list_0 = [bool_0]
    ansible_vault_encrypted_unicode_0 = module_1.AnsibleVaultEncryptedUnicode(list_0)
    var_0 = ansible_dumper_1.represent_data(ansible_vault_encrypted_unicode_0)
    var_1 = represent_undefined(bool_1)
    str_1 = 'hIR4(Z*RfH,#C'
    tuple_0 = ()


# Generated at 2022-06-25 04:35:20.742208
# Unit test for function represent_undefined
def test_represent_undefined():
    var_0 = None
    var_1 = ansible_undefined_0._fail_with_undefined_error()
    return var_1


# Generated at 2022-06-25 04:35:22.636296
# Unit test for function represent_undefined
def test_represent_undefined():
    ansible_undefined_0 = module_2.AnsibleUndefined()
    var_0 = represent_undefined(ansible_undefined_0)


# Generated at 2022-06-25 04:35:26.854181
# Unit test for function represent_undefined

# Generated at 2022-06-25 04:35:35.830224
# Unit test for function represent_unicode
def test_represent_unicode():
    ansible_dumper_0 = None
    bool_0 = True
    str_0 = 'O!O$IP'
    int_0 = 732
    ansible_dumper_1 = AnsibleDumper(ansible_dumper_0, bool_0, str_0, int_0)
    bool_1 = False
    list_0 = [bool_0]
    ansible_vault_encrypted_unicode_0 = module_1.AnsibleVaultEncryptedUnicode(list_0)
    var_0 = ansible_dumper_1.represent_data(ansible_vault_encrypted_unicode_0)
    var_1 = represent_undefined(bool_1)
    str_1 = 'hIR4(Z*RfH,#C'
    tuple_0 = ()


# Generated at 2022-06-25 04:35:44.039159
# Unit test for function represent_unicode
def test_represent_unicode():
    ansible_dumper_0 = None
    bool_0 = False
    str_0 = '2X9?8WUN+ZK'
    int_0 = 990
    ansible_dumper_1 = AnsibleDumper(ansible_dumper_0, bool_0, str_0, int_0)
    str_1 = 't0&z9;jKt++q#'
    tuple_0 = ()
    str_2 = 'j^%(a=inQ`;X'
    tuple_1 = (tuple_0, str_2)
    ansible_dumper_1.represent_unicode(tuple_1)


# Generated at 2022-06-25 04:35:49.538709
# Unit test for function represent_undefined
def test_represent_undefined():
    ansible_dumper_0 = None
    bool_0 = True
    str_0 = 'j2&YW8iVt-k'
    int_0 = 931
    ansible_dumper_1 = AnsibleDumper(ansible_dumper_0, bool_0, str_0, int_0)
    bool_1 = True
    list_0 = [0, bool_1]
    ansible_undefined_0 = module_2.AnsibleUndefined()
    tuple_0 = (list_0, ansible_undefined_0)
    var_0 = represent_undefined(tuple_0)

# Generated at 2022-06-25 04:36:14.226103
# Unit test for function represent_hostvars
def test_represent_hostvars():
    ansible_dumper_0 = None
    bool_0 = False
    str_0 = 'm62_i=_JjK'
    int_0 = 732
    ansible_dumper_1 = AnsibleDumper(ansible_dumper_0, bool_0, str_0, int_0)
    bool_1 = True
    list_0 = [bool_0]
    ansible_vault_encrypted_unicode_0 = module_1.AnsibleVaultEncryptedUnicode(list_0)
    var_0 = ansible_dumper_1.represent_data(ansible_vault_encrypted_unicode_0)
    host_vars_0 = module_3.HostVars()
    bool_2 = host_vars_0._get_cache_ref()._get_

# Generated at 2022-06-25 04:36:18.291570
# Unit test for function represent_undefined
def test_represent_undefined():
    ansible_dumper_0 = AnsibleDumper()

    ansible_undefined_0 = AnsibleUndefined()
    result = ansible_dumper_0.represent_data(ansible_undefined_0)

    assert result is True


# Generated at 2022-06-25 04:36:25.644681
# Unit test for function represent_unicode
def test_represent_unicode():
    ansible_dumper_0 = None
    bool_0 = True
    int_0 = 564
    str_0 = 'T@nPhG'
    ansible_dumper_1 = AnsibleDumper(ansible_dumper_0, bool_0, str_0, int_0)
    tuple_0 = ()
    str_1 = 'uF6U^c6JGX'
    tuple_1 = (tuple_0, str_1)
    var_0 = represent_unicode(tuple_1)


# Generated at 2022-06-25 04:36:29.690894
# Unit test for function represent_unicode
def test_represent_unicode():
    text_type_0 = None
    var = represent_unicode(text_type_0)


# Generated at 2022-06-25 04:36:40.007188
# Unit test for function represent_hostvars
def test_represent_hostvars():
    bool_0 = False
    str_0 = 'd)B'
    int_0 = 2
    ansible_dumper_0 = AnsibleDumper(bool_0, str_0, int_0)
    bool_1 = True
    list_0 = [bool_1]
    ansible_vault_encrypted_unicode_0 = module_1.AnsibleVaultEncryptedUnicode(list_0)
    var_0 = represent_hostvars(bool_0, ansible_vault_encrypted_unicode_0)
    var_1 = represent_undefined(bool_1)
    str_1 = 'y0zm*C'
    tuple_0 = ()
    str_2 = '6hSiE*-X$#ls'

# Generated at 2022-06-25 04:36:44.202209
# Unit test for function represent_undefined
def test_represent_undefined():
    # FIXME
    pass


# Generated at 2022-06-25 04:36:50.773438
# Unit test for function represent_binary
def test_represent_binary():
    ansible_dumper_0 = None
    bool_0 = True
    str_0 = 'cFSM'
    int_0 = 325
    ansible_dumper_1 = AnsibleDumper(ansible_dumper_0, bool_0, str_0, int_0)
    ansible_unsafe_bytes_0 = module_1.AnsibleUnsafeBytes('hCG2R@iR')
    var_0 = represent_binary(ansible_unsafe_bytes_0)


# Generated at 2022-06-25 04:36:58.240332
# Unit test for function represent_binary
def test_represent_binary():
    ansible_dumper_0 = None
    bool_0 = True
    str_0 = 'i^BXoI)x;'
    int_0 = 519
    ansible_dumper_1 = AnsibleDumper(ansible_dumper_0, bool_0, str_0, int_0)
    str_1 = 'S0S+-^&,q'
    var_0 = represent_binary(str_1)


# Generated at 2022-06-25 04:37:06.768775
# Unit test for function represent_undefined
def test_represent_undefined():
    if sys.version_info >= (3, 0):
        ansible_dumper_0 = None
        bool_0 = True
        str_0 = 'O!O$IP'
        int_0 = 732
        ansible_dumper_1 = AnsibleDumper(ansible_dumper_0, bool_0, str_0, int_0)
        bool_1 = False
        list_0 = [bool_0]
        ansible_vault_encrypted_unicode_0 = module_1.AnsibleVaultEncryptedUnicode(list_0)
        var_0 = ansible_dumper_1.represent_data(ansible_vault_encrypted_unicode_0)
        var_1 = represent_undefined(bool_1)

# Generated at 2022-06-25 04:37:12.766498
# Unit test for function represent_unicode
def test_represent_unicode():
    ansible_dumper_0 = None
    bool_0 = True
    str_0 = 'O!O$IP'
    int_0 = 732
    ansible_dumper_1 = AnsibleDumper(ansible_dumper_0, bool_0, str_0, int_0)
    tuple_0 = ()
    str_1 = 'v&d_o#G@BL+CGy2'
    tuple_1 = (tuple_0, str_1)
    var_0 = represent_unicode(tuple_1)


# Generated at 2022-06-25 04:37:30.925158
# Unit test for function represent_unicode
def test_represent_unicode():
    var_0 = None
    bool_0 = True
    str_0 = 'DIBg;8W5'
    int_0 = 145
    ansible_dumper_0 = AnsibleDumper(var_0, bool_0, str_0, int_0)
    var_1 = None
    var_2 = ansible_dumper_0.represent_unicode(var_1)


# Generated at 2022-06-25 04:37:38.520735
# Unit test for function represent_unicode
def test_represent_unicode():
    var_0 = None
    bool_0 = True
    str_0 = 'O!O$IP'
    int_0 = 732
    ansible_dumper_0 = AnsibleDumper(var_0, bool_0, str_0, int_0)
    ansible_unicode_0 = module_1.AnsibleUnicode()
    var_1 = ansible_dumper_0.represent_unicode(ansible_unicode_0)


# Generated at 2022-06-25 04:37:44.955158
# Unit test for function represent_unicode
def test_represent_unicode():
    str_0 = 'O!O$IP'
    any_0 = None
    any_1 = None
    var_0 = AnsibleUnicode(str_0, any_0, any_1)
    var_1 = None
    var_2 = False
    var_3 = 'O!O$IP'
    int_0 = 732
    ansible_dumper_0 = AnsibleDumper(var_1, var_2, var_3, int_0)

    # Test with valid parameters
    str_1 = 'O!O$IP'
    any_2 = None
    any_3 = None
    var_4 = AnsibleUnicode(str_1, any_2, any_3)
    var_5 = ansible_dumper_0.represent_unicode(var_4)
   

# Generated at 2022-06-25 04:37:49.906242
# Unit test for function represent_unicode
def test_represent_unicode():
    var_2 = None
    bool_3 = True
    str_1 = 'PE^IY'
    int_1 = 516
    ansible_dumper_1 = AnsibleDumper(var_2, bool_3, str_1, int_1)
    ansible_unsafe_text_0 = module_1.AnsibleUnsafeText()
    var_3 = ansible_dumper_1.represent_data(ansible_unsafe_text_0)


# Generated at 2022-06-25 04:37:58.077105
# Unit test for function represent_unicode
def test_represent_unicode():
    bool_0 = True
    str_0 = 'O!O$IP'
    int_0 = 732
    ansible_dumper_0 = AnsibleDumper(bool_0, str_0, int_0)
    ansible_unicode_0 = module_1.AnsibleUnicode()
    var_0 = ansible_dumper_0.represent_unicode(ansible_unicode_0)
    assert isinstance(var_0, str)


# Generated at 2022-06-25 04:38:02.905684
# Unit test for function represent_unicode
def test_represent_unicode():
    var_0 = 'V'*10
    bool_0 = True
    str_0 = 'O!O$IP'
    int_0 = 732
    ansible_dumper_0 = AnsibleDumper(var_0, bool_0, str_0, int_0)
    bool_1 = False
    str_1 = 'Zr@[f]n3lw|'
    var_1 = ansible_dumper_0.represent_unicode(bool_1, str_1)
    assert (var_1 is not None)


# Generated at 2022-06-25 04:38:07.689043
# Unit test for function represent_unicode
def test_represent_unicode():
    var_2 = None
    bool_3 = True
    str_1 = 'O!O$IP'
    int_1 = 732
    ansible_dumper_0 = AnsibleDumper(var_2, bool_3, str_1, int_1)
    ansible_unicode_0 = module_1.AnsibleUnicode()
    var_3 = ansible_dumper_0.represent_unicode(ansible_unicode_0)


# Generated at 2022-06-25 04:38:15.878092
# Unit test for function represent_unicode
def test_represent_unicode():
    var_0 = None
    bool_0 = True
    str_0 = 'O!O$IP'
    int_0 = 732
    ansible_dumper_0 = AnsibleDumper(var_0, bool_0, str_0, int_0)
    bool_1 = False
    bool_2 = [bool_0]
    ansible_dumper_0.stream = bool_1
    ansible_dumper_0.default_flow_style = bool_1
    ansible_dumper_0.indent = int_0
    ansible_dumper_0.width = int_0
    ansible_dumper_0.allow_unicode = bool_1
    ansible_dumper_0.line_break = '\r'

# Generated at 2022-06-25 04:38:21.470184
# Unit test for function represent_unicode
def test_represent_unicode():
    var_0 = None
    var_1 = True
    var_2 = 'HNrFske'
    var_3 = -24
    ansible_dumper_0 = AnsibleDumper(var_0, var_1, var_2, var_3)
    ansible_unicode_0 = AnsibleUnicode()
    var_4 = ansible_dumper_0.represent_data(ansible_unicode_0)

# Generated at 2022-06-25 04:38:28.825163
# Unit test for function represent_unicode
def test_represent_unicode():
    var_0 = None
    bool_0 = True
    str_0 = 'O!O$IP'
    int_0 = 732
    ansible_dumper_0 = AnsibleDumper(var_0, bool_0, str_0, int_0)
    unicode_0 = AnsibleUnicode()
    var_1 = ansible_dumper_0.represent_unicode(unicode_0)
    assert var_1 == 'O!O$IP'
