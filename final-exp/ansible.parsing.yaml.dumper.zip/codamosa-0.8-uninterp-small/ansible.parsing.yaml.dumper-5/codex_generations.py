

# Generated at 2022-06-25 04:32:03.931026
# Unit test for function represent_unicode
def test_represent_unicode():
    str_0 = None
    var_0 = represent_unicode(str_0)


# Generated at 2022-06-25 04:32:05.512909
# Unit test for function represent_unicode
def test_represent_unicode():
    str_0 = None
    var_0 = represent_unicode(str_0)


# Generated at 2022-06-25 04:32:11.208073
# Unit test for function represent_undefined
def test_represent_undefined():
    # Here bool will ensure _fail_with_undefined_error happens
    # if the value is Undefined.
    # This happens because Jinja sets __bool__ on StrictUndefined
    assert represent_undefined(None) is True

# Generated at 2022-06-25 04:32:12.330677
# Unit test for function represent_unicode
def test_represent_unicode():
    str_0 = None
    var_0 = represent_unicode(str_0)



# Generated at 2022-06-25 04:32:13.203337
# Unit test for function represent_binary
def test_represent_binary():
    # FIXME : Write unit tests for represent_binary
    # Skip for now
    pass


# Generated at 2022-06-25 04:32:16.514836
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.module_utils._text import to_text

    assert represent_vault_encrypted_unicode(None, to_text(b'foo', errors='surrogate_or_strict')) == 'b\'foo\''
    assert represent_vault_encrypted_unicode(None, to_text(b'foo', errors='replace')) == 'b\'foo\''
    assert represent_vault_encrypted_unicode(None, to_text(b'foo', errors='ignore')) == 'b\'foo\''


# Generated at 2022-06-25 04:32:22.094464
# Unit test for function represent_unicode
def test_represent_unicode():
    for obj in [AnsibleUnicode(u'foo'), AnsibleUnsafeText("ansible"), AnsibleUnsafeBytes("ansible")]:
        print(yaml.dump([obj], Dumper=AnsibleDumper))


# Generated at 2022-06-25 04:32:27.140495
# Unit test for function represent_binary
def test_represent_binary():
    data = b''
    self = AnsibleDumper()
    assert(represent_binary(self, data) == b'\n')


# Generated at 2022-06-25 04:32:33.015241
# Unit test for function represent_undefined
def test_represent_undefined():
    try:
        from json import loads, dumps
    except ImportError:
        from simplejson import loads, dumps
    str_0 = None
    var_0 = dumps(str_0)


# Generated at 2022-06-25 04:32:37.194794
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    str_0 = None
    var_0 = represent_vault_encrypted_unicode(str_0)


# Generated at 2022-06-25 04:32:43.290502
# Unit test for function represent_binary
def test_represent_binary():
    byte_array = b'\x01\x02\x03\x04\x05\x06\x07\x08\t\n\x0b\x0c\r\x0e\x0f\x10\x11'
    yaml_data = yaml.dump(byte_array, Dumper=AnsibleDumper)
    assert yaml_data == '!!binary |\n  AQIDBAUGBwgJCgsMDQ4PEA==\n'

# Generated at 2022-06-25 04:32:46.713149
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    u = AnsibleUnicode('foo')

    if yaml.__with_libyaml__:
        assert dumper.represent_unicode(u) == "!!python/unicode 'foo'"

    else:
        assert dumper.represent_unicode(u) == u'foo'


# Generated at 2022-06-25 04:32:52.573596
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = HostVars(file_name="test")

    hostvars._get_host_vars(host="host_name")["test"] = "test_value"

    output = yaml.dump({"test": hostvars})

    expected = """\
{test: {host_name: {test: test_value}}}
"""
    assert output == expected



# Generated at 2022-06-25 04:33:01.709265
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    import ansible.vars.unsafe_proxy
    from ansible.parsing.vault import VaultLib

    secret = 'secret'
    vault_pass = 'password'
    vault_data = ansible.vars.unsafe_proxy.UnsafeVaultSecret(secret)
    ciphertext = VaultLib(vault_pass).encrypt(secret)

    assert ciphertext == vault_data._ciphertext

    # Using the real output as a reference point doesn't make much sense
    # as it's based on the version of PyYAML being used.
    # The output is also not deterministic.
    output = yaml.dump(vault_data, default_flow_style=False, Dumper=AnsibleDumper)
    assert output.startswith('!vault |')

# Generated at 2022-06-25 04:33:09.504907
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    value = vault.encrypt('hello world')

    data = AnsibleVaultEncryptedUnicode(value)
    assert represent_vault_encrypted_unicode(None, data) == u'!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          366135303338643836336430636464353966643038366131613661316336613162663165313465\n          616236356438333430623131303233353563386238393534336662616538663164373835633730\n          653732\n          '

# Generated at 2022-06-25 04:33:16.209772
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'\x00') == '0'
    assert dumper.represent_binary(b'\x04') == '0'
    assert dumper.represent_binary(b'\x80') == '0'
    assert dumper.represent_binary(b'\x0a') == '0a'
    assert dumper.represent_binary(b'\x01\x02\x03\x04') == '01020304'

# Generated at 2022-06-25 04:33:25.241765
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = "hello world"
    ciphertext = b"$ANSIBLE_VAULT;1.1;AES256;test\r\n353362633539343863323664326138356231323332653962613463336539646162643262363537\r\n"
    plaintext = b"hello world\n"
    vault_id = "test"

    test_aueu = AnsibleVaultEncryptedUnicode(vault_id, ciphertext, plaintext)
    assert test_aueu._ciphertext == ciphertext
    assert test_aueu._plaintext == plaintext
    assert test_aueu._vault_id == vault_id
    dumper = AnsibleDumper()
    # Re-test the output to ensure representer is sane
    assert dumper.represent

# Generated at 2022-06-25 04:33:30.407160
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib

    secret = 'mysecret'
    vault = VaultLib([])
    encrypt_string = vault.encrypt(secret)

    value = AnsibleVaultEncryptedUnicode(encrypt_string)

    loader = AnsibleLoader(None, yaml_dumper=AnsibleDumper)
    data = loader.construct_yaml_map(None)
    data['value'] = value

    assert data == {'value': value}

# Generated at 2022-06-25 04:33:39.879904
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Create an AnsibleVaultEncryptedUnicode object
    vault_obj = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256;test_string\n63663265353633396537366635333437383131623562616339373566336561666233373066343637\n62653738373431316232373637343761646366633932316162313639316633626262313363386361\n3638393839623332633734663364356665643366')

    # Call the function
    vault_out = represent_vault_encrypted_unicode(None, vault_obj)

    # Check the output

# Generated at 2022-06-25 04:33:41.176074
# Unit test for function represent_binary
def test_represent_binary():
    b = AnsibleDumper(None)
    b.represent_binary(b'test')

# Generated at 2022-06-25 04:33:54.066686
# Unit test for function represent_unicode
def test_represent_unicode():
    # This is test for python 2
    from ansible.module_utils.pycompat24 import get_exception

    do_unicode = u'\u5317'
    do_str = '\xe5\x8c\x97'
    assert isinstance(AnsibleDumper.represent_unicode(None, do_unicode), text_type)
    assert isinstance(AnsibleDumper.represent_unicode(None, do_str), text_type)

    try:
        AnsibleDumper.represent_unicode(None, do_str.decode("utf-8"))
    except get_exception() as e:
        assert 'decoding Unicode' in str(e)

    # This is test for python 3

# Generated at 2022-06-25 04:34:04.232634
# Unit test for function represent_undefined
def test_represent_undefined():
    undefined = AnsibleUndefined('hello')

    def _fail_with_undefined_error(data):
        yaml.representer.SafeRepresenter.represent_undefined(undefined)

    assert undefined.__bool__() is False

    from ansible.template.safe_eval import UndefinedError
    from nose.tools import assert_raises

    # Note: Can't do this in 2.6 as it is expecting UndefinedError class
    # instead of UndefinedError instance in assert_raises
    #assert_raises(UndefinedError, _fail_with_undefined_error, undefined)

    try:
        _fail_with_undefined_error(undefined)
    except UndefinedError:
        pass

# Generated at 2022-06-25 04:34:08.555636
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.safe_load(yaml.dump([AnsibleUndefined()], Dumper=AnsibleDumper)) == [False]

# Generated at 2022-06-25 04:34:17.202388
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    """
    Ansible's Dumper should correctly encrypt unicode objects with AnsibleVaultEncryptedUnicode
    """
    data = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\n646531393163353235316531633165313135386266643332313564353832333134303464353237\n36326539643437626232373033653833613161323138616637623265396361660a36306563616366\n37626238616233383138613231323864306262613666353237623631563034393332653731326233\n616630653964303231323533626263303366613366\n')


# Generated at 2022-06-25 04:34:23.365362
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    # py2
    if hasattr(yaml, 'CSafeDumper'):
        assert dumper.represent_binary(b'\x00') == '!!binary |\n  AA=='
    # py3
    else:
        assert dumper.represent_binary(b'\x00') == '!!binary |\n  AA=='



# Generated at 2022-06-25 04:34:28.226093
# Unit test for function represent_binary
def test_represent_binary():
    # For example, the value of package_gpg_key on fedora is binary
    value = binary_type('\x99\xb2\x8d\x0a\xac\x85\x5d\xc5\x04\xdd\xef\x95\x19\x8c\x8f\x81\x06\x9c')
    # This must not raise an exception
    AnsibleDumper.represent_binary(None, value)

# Generated at 2022-06-25 04:34:30.742369
# Unit test for function represent_unicode
def test_represent_unicode():
    d = AnsibleDumper()
    assert d.represent_unicode(u'abc') == u"'abc'\n"



# Generated at 2022-06-25 04:34:32.452824
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.dump(AnsibleUndefined(fail_on_undefined=True), Dumper=AnsibleDumper) is None



# Generated at 2022-06-25 04:34:36.601584
# Unit test for function represent_unicode
def test_represent_unicode():
    yaml_dict = dict()
    yaml_dict['ansible_variable'] = AnsibleUnicode('value')
    yaml = yaml.dump(yaml_dict, Dumper=AnsibleDumper, default_flow_style=False, allow_unicode=True)
    assert 'ansible_variable: value' in yaml


# Generated at 2022-06-25 04:34:46.174966
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import get_file_vault_secret
    import os
    import tempfile


# Generated at 2022-06-25 04:34:55.438082
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(u'foo', Dumper=AnsibleDumper) == 'foo\n...\n'



# Generated at 2022-06-25 04:35:06.642250
# Unit test for function represent_undefined
def test_represent_undefined():
    import os
    import tempfile

    dumper = AnsibleDumper
    l1 = AnsibleUnicode("a string")
    l2 = AnsibleUnsafeText("a unsafe string")
    l3 = AnsibleUnsafeBytes("a unsafe bytes")
    l4 = HostVars({"key": "value"})
    l5 = HostVarsVars({"key": "value"})
    l6 = VarsWithSources({"key": "value"})
    l7 = AnsibleSequence(["a", "b", "c"])
    l8 = AnsibleMapping({"key": "value"})

# Generated at 2022-06-25 04:35:14.102427
# Unit test for function represent_binary
def test_represent_binary():
    # The yaml library calls the `test_represent_binary` function as
    # part of its own unit tests.  We need to add a fake test here
    # so that function appears to the yaml library to be a valid
    # unit test.

    # we do not want to run any actual tests here but we do want
    # to make sure that the yaml library does not skip over our
    # custom module
    pass

# Generated at 2022-06-25 04:35:21.061433
# Unit test for function represent_unicode
def test_represent_unicode():
    '''
    Test represent_unicode function
    '''
    dumper = yaml.dumper.SafeDumper
    data = 'abc'
    representative = yaml.representer.SafeRepresenter.represent_str
    assert represent_unicode(dumper, data) == representative(dumper, text_type(data))
    assert repr(represent_unicode(dumper, data)) == repr(representative(dumper, text_type(data)))

# Generated at 2022-06-25 04:35:26.059270
# Unit test for function represent_undefined
def test_represent_undefined():
    # test that None is not undefined
    assert AnsibleDumper.represent_undefined(None) is False
    # test that a dict is still a dict
    assert AnsibleDumper.represent_undefined({}) is False
    # test that a AnsibleUndefined is undefined
    assert AnsibleDumper.represent_undefined(AnsibleUndefined)


# for the json_dict compat layer
from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject, AnsibleMapping

from ansible.parsing.ajson import AnsiJSONEncoder, AnsiJSONDecoder

from io import StringIO
from ansible.utils.unsafe_proxy import wrap_var
from ansible.parsing.ajson import AnsibleJSONEncoder, AnsibleJSONDecoder

from collections import Mapping

# Generated at 2022-06-25 04:35:32.135241
# Unit test for function represent_unicode
def test_represent_unicode():
    from textwrap import dedent
    # Setup
    class MyDumper(AnsibleDumper):
        pass

    MyDumper.add_representer(
        AnsibleUnicode,
        represent_unicode,
    )

    dumper = MyDumper.safe_representer
    # Exercise
    data = AnsibleUnicode('test_unicode')
    # Verify
    assert dumper.represent_unicode(data) == dedent("""\
    'test_unicode'
    """)


# Generated at 2022-06-25 04:35:34.609678
# Unit test for function represent_unicode
def test_represent_unicode():
    source_obj = AnsibleUnicode("input")
    expected_output = text_type("input")
    actual_output = represent_unicode(AnsibleDumper, source_obj)
    assert expected_output == actual_output



# Generated at 2022-06-25 04:35:39.768494
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    assert represent_undefined(dumper, AnsibleUndefined()) == False
    assert represent_undefined(dumper, "test") == "test"

# Generated at 2022-06-25 04:35:47.075262
# Unit test for function represent_unicode
def test_represent_unicode():
    ansible_dumper = AnsibleDumper()
    expected_value = b'bar'
    ansible_unicode = AnsibleUnicode(expected_value)
    ret_val = ansible_dumper.represent_unicode(ansible_unicode)
    assert ret_val == expected_value



# Generated at 2022-06-25 04:35:52.618359
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper(undefined=AnsibleUndefined)
    assert dumper.represent_undefined(AnsibleUndefined(u"not empty")) is True

# Generated at 2022-06-25 04:36:15.793911
# Unit test for function represent_binary
def test_represent_binary():
    # needed for unit teste, as we would otherwise get
    # a stack overflow when calling a YAML method.
    yaml.representer.BaseRepresenter.ignore_aliases = lambda self, data: True

    assert yaml.dump(b'foo', Dumper=AnsibleDumper).strip() == b'!!binary |\n  Zm9v'
    assert yaml.dump(['foo', u'bar'], Dumper=AnsibleDumper).strip() == b'''\
!!seq [
  !!binary |
    Zm9v
  bar,
]'''

# Generated at 2022-06-25 04:36:25.705961
# Unit test for function represent_undefined
def test_represent_undefined():
    loader = yaml.loader.SafeLoader
    dumper = AnsibleDumper

    result_dumper = dumper.dump(AnsibleUndefined())

    # The error message should match the error message in the representer
    expected_dumper = 'undefined value is not JSON serializable'

    try:
        loader.load(result_dumper)
        assert False
    except yaml.representer.RepresenterError as e:
        # str(e) has a leading and trailing newline
        result_loader = str(e).strip()
    else:
        assert False

    assert expected_dumper == result_loader

if __name__ == '__main__':
    test_represent_undefined()

# Generated at 2022-06-25 04:36:30.975799
# Unit test for function represent_binary
def test_represent_binary():
    yaml.add_representer(bytes, represent_binary)
    yaml_data = yaml.dump(b'\xff')
    assert yaml_data == '!!binary |\n  /8=\n', yaml_data

# Generated at 2022-06-25 04:36:39.550511
# Unit test for function represent_binary
def test_represent_binary():

    # Test with a blank string
    test_input = AnsibleUnsafeBytes(b'')
    expected_output = yaml.representer.SafeRepresenter.represent_binary(
        AnsibleDumper,
        test_input,
    )

    assert expected_output == "!binary ''"

    # Test with a non-blank string
    test_input = AnsibleUnsafeBytes('test')
    expected_output = yaml.representer.SafeRepresenter.represent_binary(
        AnsibleDumper,
        test_input,
    )

    assert expected_output == "!binary 'dGVzdA=='"

# Generated at 2022-06-25 04:36:44.272410
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    data = {'foo': 'bar'}
    vault_password = 'test'
    vault = VaultLib([vault_password])
    ciphertext = vault.encrypt(b'just testing vault')
    data['test'] = AnsibleVaultEncryptedUnicode(ciphertext)
    output = yaml.dump(data, Dumper=AnsibleDumper, default_flow_style=False, width=1024)


# Generated at 2022-06-25 04:36:50.516679
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    dumper.add_representer(AnsibleUndefined, represent_undefined)

    try:
        dumper.represent_undefined(AnsibleUndefined())
    except UndefinedError as e:
        assert e.message == AnsibleUndefined.message

    try:
        dumper.represent_undefined(AnsibleUndefined('hello'))
    except UndefinedError as e:
        assert e.message == 'hello'

# Generated at 2022-06-25 04:37:00.980347
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

# Generated at 2022-06-25 04:37:04.603941
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()

    assert dumper.represent_unicode('Hello World') == u"'Hello World'"
    assert dumper.represent_unicode(u'Hello World') == u"'Hello World'"



# Generated at 2022-06-25 04:37:09.409923
# Unit test for function represent_binary
def test_represent_binary():

    # If a string is already encoded as binary
    # ensure the encoding is respected

    input_value = b'This is already binary'
    output_value = b'This is already binary'
    assert yaml.dump(input_value, Dumper=AnsibleDumper) == output_value + b'\n...\n'



# Generated at 2022-06-25 04:37:14.443039
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = AnsibleVaultEncryptedUnicode(u'foo')
    result = AnsibleDumper().represent_vault_encrypted_unicode(data)
    assert '!vault' in result[0]

# Generated at 2022-06-25 04:37:51.805161
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    try:
        import ansible.plugins.vault as vault
    except ImportError:
        pytest.skip("Vault not installed")

    a = AnsibleVaultEncryptedUnicode(vault.VaultLib().encrypt("foo"))
    assert yaml.dump([a], Dumper=AnsibleDumper) == u'- !vault |\n  $ANSIBLE_VAULT;1.1;AES256\n  65633262313335386631646334376233326466373261666339623765363437376333626436393735\n  38336637366236373534656631333164663539636562333334613332643337\n'

# Generated at 2022-06-25 04:38:00.397296
# Unit test for function represent_unicode
def test_represent_unicode():
    from ansible import constants
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.unsafe_proxy import wrap_var

    data = wrap_var(u'Iñtërnâtiônàlizætiøn')
    yaml.dump({'a': data}, Dumper=AnsibleDumper, default_flow_style=False)

    # Note: Fails with UnicodeDecodeError without the decode() call
    assert yaml.dump({'a': data}, Dumper=AnsibleDumper, default_flow_style=False) == u'a: Iñtërnâtiônàlizætiøn\n'

# Generated at 2022-06-25 04:38:08.265729
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import Templar
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.parsing.yaml import load, dump
    from collections import namedtuple

    x = namedtuple('UndefinedWrapper', ['key', 'results'])
    y = namedtuple('UndefinedWrapper', ['key', 'results'])
    undef1 = Templar.Undefined("varname is undefined", obj=x(key="foo", results=[]))
    undef2 = Templar.Undefined("varname is undefined", obj=y(key="foo", results=[]))
    data = dict(
        undef=undef1,
    )

# Generated at 2022-06-25 04:38:12.008438
# Unit test for function represent_unicode
def test_represent_unicode():
    unicode_obj = AnsibleUnicode(unicodestring=u'unicode')
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(unicode_obj) == u'unicode'

# Generated at 2022-06-25 04:38:13.746106
# Unit test for function represent_undefined
def test_represent_undefined():

    dump = yaml.dump(AnsibleUndefined(), Dumper=AnsibleDumper)
    assert dump == '~\n'

# Generated at 2022-06-25 04:38:21.292646
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    # Test will fail if represent_undefined does not return bool
    dumper.add_representer(
        AnsibleUndefined,
        represent_undefined,
    )
    # Allowed if Undefined object is empty
    assert dumper.represent_undefined(AnsibleUndefined()) is False
    # Test will fail if Undefined object is not empty
    assert dumper.represent_undefined(AnsibleUndefined('AnsibleUndefined'))



# Generated at 2022-06-25 04:38:30.689398
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = HostVars(host_specific_var='host_specific_var')
    # Test repr without pretty print and without default flow style
    # (which is compact block by default), so we can compare with
    # the compact block form.
    result = yaml.dump(data, Dumper=AnsibleDumper, default_flow_style=None,
                       canonical=True)
    assert result == "---\n" \
                     "host_specific_var: host_specific_var\n"
    # Test pretty print, which should use the AnsibleDumper default
    # flow style which is flow.
    result = yaml.dump(data, Dumper=AnsibleDumper, canonical=True)
    assert result == "---\n" \
                     "host_specific_var: host_specific_var\n"



# Generated at 2022-06-25 04:38:33.531067
# Unit test for function represent_binary
def test_represent_binary():
    stream = yaml.dump(b'asdf', Dumper=AnsibleDumper)
    assert stream == 'asdf\n...'



# Generated at 2022-06-25 04:38:40.778545
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    """
    AnsibleVaultEncryptedUnicode obj
    """

    # Fake object
    class AVEU:
        def __init__(self, ciphertext):
            self._ciphertext = ciphertext

    av = AVEU(ciphertext='test_ciphertest')

    dumper = AnsibleDumper()
    result = dumper.represent_vault_encrypted_unicode(av)

    # convert Results to string
    result = ''.join([str(item) for item in result])

    # Remove new line char from last element
    result = result[:result.rfind('\n')]

    # compare result with expected

# Generated at 2022-06-25 04:38:44.557425
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    assert dumper.represent_undefined(dumper, AnsibleUndefined()) is False
    assert dumper.represent_undefined(dumper, 'abcdef') is True

# Generated at 2022-06-25 04:39:49.294753
# Unit test for function represent_hostvars
def test_represent_hostvars():
    obj = yaml.load(yaml.dump(dict(a=1, b=list(range(10,100,10)), c='string'), Dumper=AnsibleDumper))
    assert obj == {'a': 1, 'b': list(range(10, 100, 10)), 'c': 'string'}


if __name__ == '__main__':
    import sys
    import doctest
    doctest.testmod(sys.modules[__name__])
    # test_represent_hostvars()

# Generated at 2022-06-25 04:39:50.715170
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode('test')) == u'test\n...\n'



# Generated at 2022-06-25 04:39:52.356740
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined()) == True

# Generated at 2022-06-25 04:39:53.908448
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(b'foo', Dumper=AnsibleDumper) == "!!binary |\n  Zm9v\n"

# Generated at 2022-06-25 04:40:02.851847
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib

    vault = VaultLib([])
    enclave_data = b'$ANSIBLE_VAULT;1.2;AES256;test\n6331386430323138643031323139333066343331393933313461633630366130316635373530653732\n3937343733663933366637376534363264346537653032373533666639656666343066393639323632\ntesttest'
    ciphertext = vault.decrypt(enclave_data)
    vaulttext = AnsibleVaultEncryptedUnicode(ciphertext)

# Generated at 2022-06-25 04:40:07.364661
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()
    vaulted_data = AnsibleVaultEncryptedUnicode('foo')
    result = dumper.represent_vault_encrypted_unicode(vaulted_data)
    assert result == "!vault |\n          Zm9vCg==\n"


# Generated at 2022-06-25 04:40:14.077267
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from io import StringIO
    from yaml import dump
    from collections import OrderedDict

    d = OrderedDict([(u'foo', u'bar'), (u'baz', u'qux')])
    h = HostVars({})
    h['hostvars'] = d

    output = StringIO()
    dump(h, output, Dumper=AnsibleDumper)
    # Note: ordering is lost in yaml dump, but the test guarantees that
    # the data is there.
    assert output.getvalue() == """!hostvars {foo: bar, baz: qux}
"""  # noqa



# Generated at 2022-06-25 04:40:16.344983
# Unit test for function represent_hostvars
def test_represent_hostvars():
    """Creates a YAML string for a HostVars object."""
    assert yaml.dump({'a': HostVars({}, [])}, Dumper=AnsibleDumper) == 'a: {}\n'

# Generated at 2022-06-25 04:40:22.580114
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()

    # Test 1: This should return bool(True)
    data = AnsibleUndefined('bar')
    result = dumper.represent_undefined(data)
    assert result == True

    # Test 2: This should return bool(False)
    class MyUndefined(AnsibleUndefined):
        def __bool__(self):
            return False

    data = MyUndefined('bar')
    result = dumper.represent_undefined(data)
    assert result == False

# Generated at 2022-06-25 04:40:29.283685
# Unit test for function represent_unicode
def test_represent_unicode():
    d = yaml.representer.SafeRepresenter()
    assert d.represent_unicode('foo') == "foo"
    assert d.represent_unicode(u'foo') == "foo"
    assert d.represent_unicode(b'foo') == "foo"
    assert d.represent_unicode(1) == "1"
    assert d.represent_unicode(1.0) == "1.0"
    assert d.represent_unicode(True) == "True"

