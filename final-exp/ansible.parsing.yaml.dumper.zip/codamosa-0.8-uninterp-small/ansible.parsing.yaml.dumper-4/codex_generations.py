

# Generated at 2022-06-25 04:32:02.615383
# Unit test for function represent_unicode
def test_represent_unicode():
    assert True # TODO: implement your test here



# Generated at 2022-06-25 04:32:03.139946
# Unit test for function represent_binary
def test_represent_binary():
    pass

# Generated at 2022-06-25 04:32:09.253381
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Both of these should work without issue
    unicode_0 = AnsibleVaultEncryptedUnicode('x')
    yaml.dump(unicode_0, Dumper=AnsibleDumper)
    volatile_0 = AnsibleVaultEncryptedUnicode(b'x')
    yaml.dump(volatile_0, Dumper=AnsibleDumper)



# Generated at 2022-06-25 04:32:10.393340
# Unit test for function represent_undefined
def test_represent_undefined():
    bool_1 = None
    var_1 = represent_undefined(bool_1)


# Generated at 2022-06-25 04:32:12.269849
# Unit test for function represent_binary
def test_represent_binary():
    bool_0 = None
    var_0 = represent_binary(bool_0)
    assert var_0 is not None

# Generated at 2022-06-25 04:32:16.515240
# Unit test for function represent_hostvars
def test_represent_hostvars():
    bool_0 = None
    var_0 = represent_hostvars(bool_0)


# Generated at 2022-06-25 04:32:16.903737
# Unit test for function represent_undefined
def test_represent_undefined():
    assert True



# Generated at 2022-06-25 04:32:21.318340
# Unit test for function represent_unicode
def test_represent_unicode():
    bool_0 = None
    var_0 = represent_unicode(bool_0)



# Generated at 2022-06-25 04:32:24.713727
# Unit test for function represent_binary
def test_represent_binary():
    unicode_0 = 'test_value'
    ansible_ds = {'foo': 'bar', 'baz': 'qux'}
    function_call_0 = represent_binary(unicode_0, ansible_ds)
    expected_result_0 = True
    assert function_call_0 == expected_result_0

# Generated at 2022-06-25 04:32:26.575683
# Unit test for function represent_hostvars
def test_represent_hostvars():
    print("t0")
    test_case_0()


# Generated at 2022-06-25 04:32:33.096859
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    out = dumper.represent_binary(dumper, '\x00')
    assert out == "!!binary |\n  AA=="


# Generated at 2022-06-25 04:32:38.083405
# Unit test for function represent_unicode
def test_represent_unicode():
    yaml_text = yaml.dump(dict(ansible_variable=b'hello world'), Dumper=AnsibleDumper)
    assert b"ansible_variable: hello world\n" == yaml_text


# Generated at 2022-06-25 04:32:40.824015
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert represent_hostvars(AnsibleDumper({}), HostVars({u'myhost': u'test'})) == u'{myhost: test}'



# Generated at 2022-06-25 04:32:44.109433
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():

    dumper = AnsibleDumper(Dumper=yaml.dumper.Dumper)
    data = AnsibleVaultEncryptedUnicode('vault encrypted text')
    assert dumper.represent_vault_encrypted_unicode(data) == '!vault |\n          vault encrypted text'



# Generated at 2022-06-25 04:32:50.795736
# Unit test for function represent_undefined
def test_represent_undefined():
    # Populating the ansible "undefined" variable with value
    AnsibleUndefined.__bool__ = lambda x: True
    data = {"key1": "value1", "key2": AnsibleUndefined("undefined", "undefined")}
    result = yaml.dump(data, Dumper=AnsibleDumper)
    # Assert if result does not contain the populated value
    assert result.find('key2: undefined') == -1
    assert result.find('key2:') != -1

# Generated at 2022-06-25 04:33:00.202436
# Unit test for function represent_binary
def test_represent_binary():
    """Test function represent_binary with CRLF line endings"""
    # default yaml.dump() uses CRLF line endings
    yaml_data = {"foo": b"bar\r\n"}
    # Test python2 and python3 safe_dump
    for dump_func in [SafeDumper.safe_dump, yaml.safe_dump]:
        result = dump_func(yaml_data, allow_unicode=False)
        assert result == '{foo: !!binary |-\r\n  ' \
            'YmFyCg==\r\n'
        result = dump_func(yaml_data, allow_unicode=True)
        assert result == '{foo: !!binary |-\r\n  ' \
            'YmFyCg==\r\n'

# Generated at 2022-06-25 04:33:09.321877
# Unit test for function represent_hostvars
def test_represent_hostvars():
    h1 = HostVars(vars)
    h1.update(vars2)
    # ansible_ssh_host is not serializable
    assert represent_hostvars(None, h1) == yaml.safe_load("""
- {'host_name': 'host1', 'hostvars': {'group_names': ['ungrouped'], 'inventory_hostname': 'host1'}}
- {'host_name': 'host2', 'hostvars': {'group_names': ['group1', 'group2'], 'inventory_hostname': 'host2'}}
""")
    # Make sure set_variable works
    h1.set_variable('foo', 'bar')

# Generated at 2022-06-25 04:33:17.814094
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-25 04:33:24.580893
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

    ciphertext = "AES256$32$b6ef8ee6b6488e03729b21a9bc9d3f3d$My+secret+message."
    veu = AnsibleVaultEncryptedUnicode(ciphertext)
    result = dumper.represent_data(veu)
    assert result == u'!vault |\n  AES256$32$b6ef8ee6b6488e03729b21a9bc9d3f3d$My+secret+message.'

# Generated at 2022-06-25 04:33:33.320427
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Create a dumper with the right tag prefix
    dumper = AnsibleDumper(tagged_value_prefix='!vault')
    # Create a plain dictionary and make sure the existing
    # representer is used
    plain = {'foo': 'bar'}
    assert yaml.representer.SafeRepresenter.represent_dict(dumper, plain) == dumper.represent_dict(plain)
    # Create a vault encrypted dictionary and make sure we
    # use our custom representer for vault data
    valuted = {'foo': AnsibleVaultEncryptedUnicode('vault(bar)')}
    assert dumper.represent_dict(valuted) != yaml.representer.SafeRepresenter.represent_dict(dumper, valuted)

# Generated at 2022-06-25 04:33:48.740046
# Unit test for function represent_binary
def test_represent_binary():
    int_0 = 479
    bytes_0 = b':\xd1\x95\x14\xde\x18\xba\xec\xf5\x9e\x00\xe5\x00r\xdf\xcf\x99\xba\xc5\xaa\xeb\x9c\x82\x83\x1e\xbb\xab\xca\x0b\xce\xdc\x9a\xb1\xea\xb3\x7f\x8a\x82C\x07\xa2'
    str_0 = 'nV(v'
    str_1 = '\t*\xb4c\xc4\xf7\xda'
    bool_0 = True

# Generated at 2022-06-25 04:33:59.670488
# Unit test for function represent_unicode
def test_represent_unicode():
    int_0 = 333
    bytes_0 = b'\x08\x12\x11j\t\xf8'
    str_0 = 'oT'
    str_1 = '!vault'
    bool_0 = True
    ansible_dumper_0 = AnsibleDumper(str_0, str_0, str_1, bool_0)
    ansible_mapping_0 = module_2.AnsibleMapping(bool_0, str_0, int_0, ansible_dumper_0, str_0)
    ansible_mapping_1 = module_2.AnsibleMapping(ansible_mapping_0, int_0, bool_0, str_0, ansible_dumper_0)
    ansible_mapping_2 = module_2.AnsibleM

# Generated at 2022-06-25 04:34:08.789611
# Unit test for function represent_hostvars
def test_represent_hostvars():
    int_0 = 105
    bytes_0 = b'J\x92\xba\xeeo\xda\x9d|\xb3\x1a\xac'
    str_0 = ''
    str_1 = 'P]n'
    bool_0 = True
    ansible_dumper_0 = AnsibleDumper(str_1, str_0, str_1, bool_0)
    list_0 = [str_1, bool_0, bool_0]
    list_1 = [bool_0, ansible_dumper_0, list_0]
    list_2 = [ansible_dumper_0, list_1]
    list_3 = [str_1, str_1, str_0]
    dict_0 = dict()

# Generated at 2022-06-25 04:34:17.426502
# Unit test for function represent_unicode
def test_represent_unicode():
    str_0 = 'ye0@f,Fw'
    dict_0 = None
    ansible_dumper_0 = AnsibleDumper(dict_0, dict_0, dict_0, dict_0)
    str_1 = 'T\x1f'
    ansible_dumper_0.represent_str(str_0, str_1)

# Generated at 2022-06-25 04:34:20.647284
# Unit test for function represent_hostvars
def test_represent_hostvars():
# Run this test in a subshell so that this module-level fixtures are cleaned
# up before pytest's own fixtures are put in place.
    pass


# Generated at 2022-06-25 04:34:28.888162
# Unit test for function represent_hostvars
def test_represent_hostvars():
    int_0 = 400
    bytes_0 = b'\xd6k,\xa9\x16+'
    str_0 = 'jehP~{^r'
    str_1 = '"MK+1qKY*Xo@'
    bool_0 = True
    ansible_dumper_0 = AnsibleDumper(str_0, str_0, str_1, bool_0)
    list_0 = [ansible_dumper_0, str_0, ansible_dumper_0]
    ansible_undefined_0 = module_1.AnsibleUndefined(str_0)
    dict_0 = None
    tuple_0 = (ansible_undefined_0, ansible_dumper_0, dict_0)
    ansible_vault_encrypted_unicode_0 = module

# Generated at 2022-06-25 04:34:34.255132
# Unit test for function represent_unicode
def test_represent_unicode():
    ansible_dumper_0 = AnsibleDumper('Ie\x14qr\xd6 \x00\xb0\x8a\x9a\xf9\x8ej\xb6\xa4:\x97\xc6x')

    # Call function
    tested_0 = represent_unicode(ansible_dumper_0)

    # Assertions
    assert tested_0 == ansible_dumper_0


# Generated at 2022-06-25 04:34:45.862005
# Unit test for function represent_unicode
def test_represent_unicode():
    int_0 = 400
    bytes_0 = b'\xd6k,\xa9\x16+'
    str_0 = 'jehP~{^r'
    str_1 = '"MK+1qKY*Xo@'
    bool_0 = True
    ansible_dumper_0 = AnsibleDumper(str_0, str_0, str_1, bool_0)
    list_0 = [ansible_dumper_0, str_0, ansible_dumper_0]
    ansible_undefined_0 = module_1.AnsibleUndefined(str_0)
    dict_0 = None
    tuple_0 = (ansible_undefined_0, ansible_dumper_0, dict_0)
    ansible_vault_encrypted_unicode_0 = module

# Generated at 2022-06-25 04:34:51.645075
# Unit test for function represent_undefined
def test_represent_undefined():
    int_0 = 436
    bool_0 = True
    str_0 = '\n        Return a single named information item from the lsb_release command\n        output data source of the OS distribution.\n\n        For details, see :func:`distro.lsb_release_attr`.\n        '
    float_0 = None
    tuple_0 = (int_0, str_0, str_0, float_0)
    var_0 = represent_undefined(tuple_0)
    var_1 = represent_undefined(bool_0)


# Generated at 2022-06-25 04:35:00.781279
# Unit test for function represent_undefined
def test_represent_undefined():
    int_0 = 541
    str_0 = 'ER!_r095wjRp]5'
    str_1 = 'J\xc2\xb3/\xd6\xa5\x89\x1a0\xa6\x0f\xbe\x06\x9a\xa0\xda\x07\xfd\x8a\x07\xfd\x8a'
    bool_0 = True
    ansible_dumper_0 = AnsibleDumper(str_1, str_0, str_0, bool_0)
    list_0 = [ansible_dumper_0, str_0, ansible_dumper_0]
    ansible_undefined_0 = module_1.AnsibleUndefined(str_0)

# Generated at 2022-06-25 04:35:11.546219
# Unit test for function represent_binary
def test_represent_binary():
    int_0 = 400
    bytes_0 = b'\xd6k,\xa9\x16+'
    str_0 = 'jehP~{^r'
    str_1 = '"MK+1qKY*Xo@'
    bool_0 = True
    ansible_dumper_0 = AnsibleDumper(str_0, str_0, str_1, bool_0)
    list_0 = [ansible_dumper_0, str_0, ansible_dumper_0]
    ansible_undefined_0 = module_1.AnsibleUndefined(str_0)
    dict_0 = None
    tuple_0 = (ansible_undefined_0, ansible_dumper_0, dict_0)
    ansible_vault_encrypted_unicode_0 = module

# Generated at 2022-06-25 04:35:22.622473
# Unit test for function represent_hostvars
def test_represent_hostvars():
    int_0 = 400
    bytes_0 = b'\xd6k,\xa9\x16+'
    str_0 = 'jehP~{^r'
    str_1 = '"MK+1qKY*Xo@'
    bool_0 = True
    ansible_dumper_0 = AnsibleDumper(str_0, str_0, str_1, bool_0)
    list_0 = [ansible_dumper_0, str_0, ansible_dumper_0]
    ansible_undefined_0 = module_1.AnsibleUndefined(str_0)
    dict_0 = None
    tuple_0 = (ansible_undefined_0, ansible_dumper_0, dict_0)
    ansible_vault_encrypted_unicode_0 = module

# Generated at 2022-06-25 04:35:33.363856
# Unit test for function represent_unicode
def test_represent_unicode():
    print('Testing represent_unicode')
    int_0 = 400
    bytes_0 = b'\xd6k,\xa9\x16+'
    str_0 = 'jehP~{^r'
    str_1 = '"MK+1qKY*Xo@'
    bool_0 = True
    ansible_dumper_0 = AnsibleDumper(str_0, str_0, str_1, bool_0)
    list_0 = [ansible_dumper_0, str_0, ansible_dumper_0]
    ansible_undefined_0 = module_1.AnsibleUndefined(str_0)
    dict_0 = None
    tuple_0 = (ansible_undefined_0, ansible_dumper_0, dict_0)
    ansible_v

# Generated at 2022-06-25 04:35:39.410470
# Unit test for function represent_unicode
def test_represent_unicode():
    # Correct type error
    try:
        # Check exist of variable
        if 'ansible_dumper_0' in locals():
            # Check type matches
            if not isinstance(ansible_dumper_0, AnsibleDumper):
                raise TypeError
            int_0 = 84
            var_0 = represent_unicode(ansible_dumper_0)
            var_1 = yaml.representer.SafeRepresenter.represent_str(int_0)
        else:
            raise Exception
    except TypeError as err:
        print('Type Error: {}'.format(err))
    except Exception as err:
        print('Variable does not exists: {}'.format(err))
    else:
        pass
    finally:
        pass


# Generated at 2022-06-25 04:35:50.582408
# Unit test for function represent_binary
def test_represent_binary():
    int_0 = 400
    bytes_0 = b'\xd6k,\xa9\x16+'
    str_0 = 'jehP~{^r'
    str_1 = '"MK+1qKY*Xo@'
    bool_0 = True
    ansible_dumper_0 = AnsibleDumper(str_0, str_0, str_1, bool_0)
    list_0 = [ansible_dumper_0, str_0, ansible_dumper_0]
    ansible_undefined_0 = module_1.AnsibleUndefined(str_0)
    dict_0 = None
    tuple_0 = (ansible_undefined_0, ansible_dumper_0, dict_0)
    ansible_vault_encrypted_unicode_0 = module

# Generated at 2022-06-25 04:35:59.645634
# Unit test for function represent_hostvars
def test_represent_hostvars():
    int_0 = 400
    str_0 = 'jehP~{^r'
    str_1 = '"MK+1qKY*Xo@'
    bool_0 = True
    ansible_dumper_0 = AnsibleDumper(str_0, str_0, str_1, bool_0)
    list_0 = [ansible_dumper_0, str_0, ansible_dumper_0]
    ansible_undefined_0 = module_1.AnsibleUndefined(str_0)
    dict_0 = None
    tuple_0 = (ansible_undefined_0, ansible_dumper_0, dict_0)
    ansible_vault_encrypted_unicode_0 = module_2.AnsibleVaultEncryptedUnicode(tuple_0)
   

# Generated at 2022-06-25 04:36:09.950251
# Unit test for function represent_undefined
def test_represent_undefined():
    int_0 = 469
    bytes_0 = b'#@\xad\xb5\x8e\x10'
    str_0 = 'p$\xc3\x9c5\xab'
    bool_0 = False
    float_0 = None
    tuple_0 = (bytes_0, float_0, float_0, float_0)
    ansible_dumper_0 = AnsibleDumper(bytes_0, ansible_dumper_0, str_0, tuple_0)
    bool_1 = bool(ansible_dumper_0)
    bool_2 = bool(tuple_0)
    ansible_undefined_0 = module_1.AnsibleUndefined(int_0)
    bool_3 = bool(ansible_undefined_0)


# Generated at 2022-06-25 04:36:20.569282
# Unit test for function represent_unicode
def test_represent_unicode():
    int_0 = 1415
    bytes_0 = b't\x02\x90\xa8\x11\xd1s\xe1\xbd\xa8\x83\xc9'
    str_0 = 'lk[i>6a\'\x00'
    str_1 = 'ZH6T*h}-LN'
    bool_0 = True
    ansible_dumper_0 = AnsibleDumper(str_0, str_0, str_1, bool_0)
    list_0 = [str_1, ansible_dumper_0, bytes_0]
    ansible_undefined_0 = module_1.AnsibleUndefined(str_0)
    dict_0 = None
    tuple_0 = (str_1, list_0, dict_0)
    ansible

# Generated at 2022-06-25 04:36:26.450004
# Unit test for function represent_binary
def test_represent_binary():
    bytes_0 = '\xe8\xbc\xd1\xce\xabB\xea\xb2\x80\xe1\x9b\xec\x00\xd0\x19\xfe\x90'
    var_0 = represent_binary(bytes_0)



# Generated at 2022-06-25 04:36:36.540608
# Unit test for function represent_unicode
def test_represent_unicode():
    int_0 = 400
    bytes_0 = b'\xd6k,\xa9\x16+'
    str_0 = 'jehP~{^r'
    str_1 = '"MK+1qKY*Xo@'
    bool_0 = True
    ansible_dumper_0 = AnsibleDumper(str_0, str_0, str_1, bool_0)
    list_0 = [ansible_dumper_0, str_0, ansible_dumper_0]
    ansible_undefined_0 = module_1.AnsibleUndefined(str_0)
    dict_0 = None
    tuple_0 = (ansible_undefined_0, ansible_dumper_0, dict_0)
    ansible_vault_encrypted_unicode_0 = module

# Generated at 2022-06-25 04:36:58.001761
# Unit test for function represent_hostvars
def test_represent_hostvars():
    int_0 = 0
    int_1 = 7
    ansible_dumper_0 = AnsibleDumper(int_0, int_0, int_1, int_1)
    ansible_dumper_1 = ansible_dumper_0.represent_dict(int_0)


# Generated at 2022-06-25 04:37:04.565182
# Unit test for function represent_hostvars
def test_represent_hostvars():
    int_0 = 700
    dict_0 = {int_0: int_0, int_0: int_0}
    tuple_0 = (int_0, dict_0, int_0)
    var_0 = represent_hostvars(int_0, tuple_0)


# Generated at 2022-06-25 04:37:06.211935
# Unit test for function represent_binary
def test_represent_binary():
    assert False



# Generated at 2022-06-25 04:37:13.716895
# Unit test for function represent_hostvars
def test_represent_hostvars():
    int_0 = 400
    bytes_0 = b'\xd6k,\xa9\x16+'
    str_0 = 'jehP~{^r'
    ansible_dumper_0 = AnsibleDumper(int_0, bytes_0, str_0, True)
    var_0 = represent_hostvars(int_0)
    var_1 = represent_hostvars(feat)
    int_1 = 1434
    bool_0 = True
    ansible_dumper_1 = AnsibleDumper(False, True, int_1, bool_0)
    var_2 = represent_hostvars(ansible_dumper_0)

# Generated at 2022-06-25 04:37:23.407937
# Unit test for function represent_hostvars
def test_represent_hostvars():
    int_0 = -372
    str_0 = '9)PtJ\x04\xc1\x1c"'
    int_1 = -1273
    ansible_unicode_0 = AnsibleUnicode(int_1)
    dict_0 = {str_0: int_0}
    tuple_0 = (dict_0, ansible_unicode_0, str_0)
    hostvars_0 = module_2.HostVars(tuple_0)
    ansible_unicode_1 = None
    ansible_vault_encrypted_unicode_0 = None
    dict_1 = {str_0: int_0, str_0: hostvars_0, str_0: ansible_unicode_1, str_0: ansible_vault_encrypted_unicode_0}

# Generated at 2022-06-25 04:37:26.990569
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dict_0 = { 'a': 'b', 'c': [1, 2] }
    var_0 = represent_hostvars(dict_0)
    assert isinstance(var_0, dict)


# Generated at 2022-06-25 04:37:37.069767
# Unit test for function represent_hostvars
def test_represent_hostvars():
    int_0 = 400
    bytes_0 = b'\xd6k,\xa9\x16+'
    str_0 = 'jehP~{^r'
    str_1 = '"MK+1qKY*Xo@'
    bool_0 = True
    ansible_dumper_0 = AnsibleDumper(str_0, str_0, str_1, bool_0)
    dict_0 = {str_1: bytes_0, str_0: str_1, str_1: bytes_0, str_0: str_0, str_1: bytes_0, str_1: str_0}
    ansible_mapping_0 = None
    var_0 = represent_hostvars(int_0)

# Generated at 2022-06-25 04:37:38.449465
# Unit test for function represent_binary
def test_represent_binary():
    # Dummy function for testing.
    pass


# Generated at 2022-06-25 04:37:42.355206
# Unit test for function represent_unicode
def test_represent_unicode():
    ansible_unicode_0 = module_2.AnsibleUnicode(None)
    var_5 = represent_unicode(ansible_unicode_0)


# Generated at 2022-06-25 04:37:48.024840
# Unit test for function represent_unicode
def test_represent_unicode():
    int_0 = 400
    bytes_0 = b'\xd6k,\xa9\x16+'
    str_0 = 'jehP~{^r'
    str_1 = '"MK+1qKY*Xo@'
    bool_0 = True
    ansible_dumper_0 = AnsibleDumper(str_0, str_0, str_1, bool_0)
    list_0 = [ansible_dumper_0, str_0, ansible_dumper_0]
    ansible_undefined_0 = module_1.AnsibleUndefined(str_0)
    dict_0 = None
    tuple_0 = (ansible_undefined_0, ansible_dumper_0, dict_0)
    ansible_vault_encrypted_unicode_0 = module

# Generated at 2022-06-25 04:38:30.396117
# Unit test for function represent_hostvars
def test_represent_hostvars():
    int_0 = 400
    bytes_0 = b'\xd6k,\xa9\x16+'
    str_0 = 'jehP~{^r'
    str_1 = '"MK+1qKY*Xo@'
    bool_0 = True
    ansible_dumper_0 = AnsibleDumper(str_0, str_0, str_1, bool_0)
    list_0 = [ansible_dumper_0, str_0, ansible_dumper_0]
    ansible_undefined_0 = module_1.AnsibleUndefined(str_0)
    dict_0 = None
    tuple_0 = (ansible_undefined_0, ansible_dumper_0, dict_0)
    ansible_vault_encrypted_unicode_0 = module

# Generated at 2022-06-25 04:38:33.215172
# Unit test for function represent_binary
def test_represent_binary():
    ansible_dumper_0 = AnsibleDumper()
    ansible_dumper_0.represent_binary(ansible_unsafe_bytes_0)


# Generated at 2022-06-25 04:38:34.618051
# Unit test for function represent_binary
def test_represent_binary():
    assert represent_binary(True) == yaml.representer.SafeRepresenter.represent_binary(True)


# Generated at 2022-06-25 04:38:41.684814
# Unit test for function represent_binary
def test_represent_binary():
    int_0 = 27
    str_0 = '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-25 04:38:49.928102
# Unit test for function represent_hostvars
def test_represent_hostvars():
    int_0 = 152
    bytes_0 = b'\x18\xfd\x8a\xcf'
    str_0 = '\xa0<\xd8\x18\xe9D\xbd\xed'
    str_1 = '\x19'
    bool_0 = False
    ansible_dumper_0 = AnsibleDumper(str_1, str_1, str_1, bool_0)
    str_2 = 'L(p\xad\x8b\x97\xebi\xef'
    bytes_1 = b'\x9f\xe4\x86\x8e\xa4\x92\xdb\xaa\x8d\xcb\x94\xa5\x14M'

# Generated at 2022-06-25 04:39:00.526625
# Unit test for function represent_binary
def test_represent_binary():
    # Call function with args
    result = represent_binary(None, b'\xd6k,\xa9\x16+')
    assert result == "\xd6k,\xa9\x16+"
    # Call function with args
    result = represent_binary(None, b'\x98\x19\x10\x1a\x1d\x1c*\xc0\x10\x18\x85\x1c\x1b\x1d\x1b\x9e')
    assert result == "^x\x98\x19\x10\x1a\x1d\x1c*\xc0\x10\x18\x85\x1c\x1b\x1d\x1b\x9e"
    # Call function with args
    result = represent_

# Generated at 2022-06-25 04:39:04.721047
# Unit test for function represent_binary
def test_represent_binary():
    list_0 = ['y.Y', None, b'\xaf\x07\x93\x07\x8e\xe2\xca\x93\x9c\xb8\x99\xfe\x93\xa7M\x13\xcd\xa9\xfa\xc7\x91\x92\x1b\xa0\x7f\xfd\xac\x0c\x1b\xce\xe7\x83\xed\x82\x8e\x14\xb3\xda\xc1\x19\xe8\x0f\x07\x19\x86\x8f\xd6A\xec\xd7', False]
    ansible_mapping_0 = None
    ansible_sequence_0 = module_2.Ansible

# Generated at 2022-06-25 04:39:13.680335
# Unit test for function represent_binary
def test_represent_binary():
    int_0 = 421
    bytes_0 = b'\xd6k,\xa9\x16+'
    str_0 = 'jehP~{^r'
    str_1 = '"MK+1qKY*Xo@'
    bool_0 = True
    ansible_dumper_0 = AnsibleDumper(str_0, str_0, str_1, bool_0)
    list_0 = [ansible_dumper_0, str_0, ansible_dumper_0]
    ansible_undefined_0 = module_1.AnsibleUndefined(str_0)
    dict_0 = None
    tuple_0 = (ansible_undefined_0, ansible_dumper_0, dict_0)
    ansible_vault_encrypted_unicode_0 = module

# Generated at 2022-06-25 04:39:19.246209
# Unit test for function represent_binary
def test_represent_binary():
    int_0 = 2769
    bytes_0 = b'\xad\xc0\xe5.\xcb\x9e\xdd\xa5\x90\x8f\xb1\xb5\xd7\xba\x08\xa9t\xe1\x9b\x1a\xcf\xda\xb2'
    str_0 = '-XK(}b=\x1d'
    str_1 = '"MK+1qKY*Xo@'
    bool_0 = True

# Generated at 2022-06-25 04:39:25.780682
# Unit test for function represent_hostvars
def test_represent_hostvars():
  ansible_dumper_0 = AnsibleDumper(list_0, ansible_undefined_0, ansible_dumper_0, bool_0)
  float_0 = None
  ansible_dumper_0 = None
  ansible_dumper_0 = AnsibleDumper(list_0, ansible_undefined_0, ansible_dumper_0, float_0)
  ansible_dumper_0 = AnsibleDumper(list_0, ansible_undefined_0, ansible_dumper_0, bool_0)
  ansible_dumper_0 = AnsibleDumper(list_0, ansible_undefined_0, ansible_dumper_0, float_0)

# Generated at 2022-06-25 04:40:36.842571
# Unit test for function represent_binary
def test_represent_binary():
    print("Represent binary")
    int_0 = 400
    bytes_0 = b'\xd6k,\xa9\x16+'
    str_0 = 'jehP~{^r'
    str_1 = '"MK+1qKY*Xo@'
    bool_0 = True
    ansible_dumper_0 = AnsibleDumper(str_0, str_0, str_1, bool_0)
    list_0 = [ansible_dumper_0, str_0, ansible_dumper_0]
    ansible_undefined_0 = module_1.AnsibleUndefined(str_0)
    dict_0 = None
    tuple_0 = (ansible_undefined_0, ansible_dumper_0, dict_0)
    ansible_vault_encrypted

# Generated at 2022-06-25 04:40:37.537880
# Unit test for function represent_binary
def test_represent_binary():
    pass


# Generated at 2022-06-25 04:40:47.810734
# Unit test for function represent_binary
def test_represent_binary():
    int_0 = 400
    bytes_0 = b'\xd6k,\xa9\x16+'
    str_0 = 'jehP~{^r'
    str_1 = '"MK+1qKY*Xo@'
    bool_0 = True
    ansible_dumper_0 = AnsibleDumper(str_0, str_0, str_1, bool_0)
    list_0 = [ansible_dumper_0, str_0, ansible_dumper_0]
    ansible_undefined_0 = module_1.AnsibleUndefined(str_0)
    dict_0 = None
    tuple_0 = (ansible_undefined_0, ansible_dumper_0, dict_0)
    ansible_vault_encrypted_unicode_0 = module

# Generated at 2022-06-25 04:40:54.542566
# Unit test for function represent_binary
def test_represent_binary():
    int_0 = 400
    bytes_0 = b'\xd6k,\xa9\x16+'
    str_0 = 'jehP~{^r'
    str_1 = '"MK+1qKY*Xo@'
    bool_0 = True
    ansible_dumper_0 = AnsibleDumper(str_0, str_0, str_1, bool_0)
    list_0 = [ansible_dumper_0, str_0, ansible_dumper_0]
    ansible_undefined_0 = module_1.AnsibleUndefined(str_0)
    dict_0 = None
    tuple_0 = (ansible_undefined_0, ansible_dumper_0, dict_0)
    ansible_vault_encrypted_unicode_0 = module

# Generated at 2022-06-25 04:41:00.667157
# Unit test for function represent_binary
def test_represent_binary():
    int_0 = 400
    bytes_0 = b'\xd6k,\xa9\x16+'
    str_0 = 'jehP~{^r'
    str_1 = '"MK+1qKY*Xo@'
    bool_0 = True
    ansible_dumper_0 = AnsibleDumper(str_0, str_0, str_1, bool_0)
    list_0 = [ansible_dumper_0, str_0, ansible_dumper_0]
    ansible_undefined_0 = module_1.AnsibleUndefined(str_0)
    dict_0 = None
    tuple_0 = (ansible_undefined_0, ansible_dumper_0, dict_0)
    ansible_vault_encrypted_unicode_0 = module

# Generated at 2022-06-25 04:41:09.558866
# Unit test for function represent_binary
def test_represent_binary():
    int_0 = 1559
    str_0 = '\xb8[\xff\xa3\xab\n\xe9\xe8\xea;\xe4\x88\x02#\xdb\x13c\xa4\x05\x9f\x8c\x1d'
    str_1 = '\x82\x97\x1f\x9c\xf1\xdd'
    ansible_dumper_0 = AnsibleDumper(str_0, str_1, str_1)
    set_0 = {ansible_dumper_0}
    bool_0 = True
    list_0 = [ansible_dumper_0, bool_0]
    float_0 = None

# Generated at 2022-06-25 04:41:18.300654
# Unit test for function represent_binary
def test_represent_binary():
    int_0 = None
    bytes_0 = b'$H\xc5\xe0\x1a\x11'
    str_0 = 'M\x13\xf3\x95\xc0\x01\x14\xcb\xb3\x9b'
    ansible_dumper_0 = AnsibleDumper(bytes_0, int_0, str_0)
    float_0 = None
    set_0 = {ansible_dumper_0, ansible_dumper_0, float_0}
    list_0 = [bytes_0, bytes_0, bytes_0, str_0]

# Generated at 2022-06-25 04:41:28.081409
# Unit test for function represent_binary
def test_represent_binary():
    str_0 = '\n        Return a single named information item from the lsb_release command\n        output data source of the OS distribution.\n\n        For details, see :func:`distro.lsb_release_attr`.\n        '
    int_0 = 734
    ansible_dumper_0 = AnsibleDumper(str_0, str_0, str_0, int_0)
    bool_0 = True
    bytes_0 = b'\x1b\xcfi\xed\xdd\xfaM\xd8\x90\x1f\xa6\xcbx'
    tuple_0 = (bytes_0, bytes_0, ansible_dumper_0, bool_0, bytes_0)

# Generated at 2022-06-25 04:41:34.205696
# Unit test for function represent_binary
def test_represent_binary():
    ansible_dumper_0 = AnsibleDumper('', '', '', True)
    bytes_0 = b'\xda\xf4\xff\xfe\xa8\xc2\xdb1\x01\xed\x9c\x97\xd1\x00\xcb\x04\x85\x00'
    int_0 = 11340
    var_0 = represent_binary(int_0)


# Generated at 2022-06-25 04:41:43.888358
# Unit test for function represent_binary
def test_represent_binary():
    int_0 = 117
    str_0 = '^'
    bool_0 = True
    ansible_dumper_0 = AnsibleDumper(str_0, str_0, str_0, bool_0)
    list_0 = [int_0, str_0, ansible_dumper_0]
    float_0 = 0.19
    dict_0 = {str_0: float_0, str_0: int_0, str_0: ansible_dumper_0, str_0: float_0, str_0: float_0, str_0: float_0}
    int_1 = 115
    tuple_0 = (float_0, int_1, ansible_dumper_0)
    var_0 = ansible_dumper_0.represent_dict(dict_0)
    int