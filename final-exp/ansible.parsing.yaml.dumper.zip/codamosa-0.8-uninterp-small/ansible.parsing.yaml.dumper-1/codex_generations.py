

# Generated at 2022-06-25 04:32:06.755454
# Unit test for function represent_binary
def test_represent_binary():
    # create a simple string
    test_data = "This is a test"

    # create an instance of the AnsibleDumper class
    rep = AnsibleDumper()

    # call the represent_binary method of the AnsibleDumper class
    test_result = rep.represent_binary(test_data)

    # Note the answer has a leading space which is why it is surrounded in quotes
    assert test_result == " 'This is a test'\n", "Did not output the expected string"


# Generated at 2022-06-25 04:32:07.852136
# Unit test for function represent_unicode
def test_represent_unicode():
    int_0 = 1420
    var_0 = represent_unicode(int_0)


# Generated at 2022-06-25 04:32:11.350569
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    pass


# Generated at 2022-06-25 04:32:13.379003
# Unit test for function represent_hostvars
def test_represent_hostvars():
    string_0 = 'hostvars'
    string_1 = 'hostvars'
    var_0 = {string_0: (string_1, string_0)}
    var_1 = represent_hostvars(var_0, string_0)



# Generated at 2022-06-25 04:32:18.463031
# Unit test for function represent_binary
def test_represent_binary():
    value = b'vagrant'
    dumper = AnsibleDumper
    result = dumper.represent_binary(dumper, value)
    assert result == b'vagrant'


# Generated at 2022-06-25 04:32:20.862336
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert represent_hostvars("self", "data") == "self.represent_dict(dict(data))"


# Generated at 2022-06-25 04:32:27.127413
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    rep_enc_1 = represent_vault_encrypted_unicode(AnsibleVaultEncryptedUnicode("Pass1234"))
    rep_enc_2 = represent_vault_encrypted_unicode(AnsibleVaultEncryptedUnicode("Pass1234"))
    rep_enc_3 = represent_vault_encrypted_unicode(AnsibleVaultEncryptedUnicode("Pass1234"))
    rep_enc_4 = represent_vault_encrypted_unicode(AnsibleVaultEncryptedUnicode("Pass1234"))
    rep_enc_5 = represent_vault_encrypted_unicode(AnsibleVaultEncryptedUnicode("Pass1234"))
    rep_enc_6 = represent_vault_encrypted_unicode(AnsibleVaultEncryptedUnicode("Pass1234"))
   

# Generated at 2022-06-25 04:32:32.876641
# Unit test for function represent_undefined
def test_represent_undefined():
    # Define a Mock instance of class AnsibleDumper
    mock_self = AnsibleDumper()

    # Define a test input, of type AnsibleUndefined
    test_input = AnsibleUndefined('boom', 'local')

    # Call the mock, with the test input
    # This should cause an exception, which means the function worked properly
    try:
        mock_self.represent_undefined(test_input)
    except:
        pass


# Generated at 2022-06-25 04:32:34.382840
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    value = 'test_value'
    assert value == represent_vault_encrypted_unicode(value)


# Generated at 2022-06-25 04:32:37.790417
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    print('Testing represent_vault_encrypted_unicode')
    int_0 = 1420
    var_0 = represent_vault_encrypted_unicode(int_0)


# Generated at 2022-06-25 04:32:48.757403
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():

    # test data
    plaintext = b'abcdefghijklmnopqrstuvwxyz\n1234567890\n'

    # test encryption
    password = b'ansible'
    vault = '$ANSIBLE_VAULT;1.1;AES256\n336537396633636339653937323063343837383731386138313231366532653737393336663637\n396365316561373364346536633862373764363839336634623236636336643865326231336436\n353039323732623139623931366134626566386463666261646566303135346533313266643030\n3537616131393863666462\n'

# Generated at 2022-06-25 04:32:51.266603
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(u'☃'.encode('utf-8')) == '!!binary "8J+RgA=="'

# Generated at 2022-06-25 04:33:00.545384
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    d = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\n63343536633837303931626665656635343966646237626437316362633736303739623963323166\n65316130343831623631633735376631653264393031643036633064326366366434333964613032\n34373533623839336364333830393465653064343033643733656433333333346438353836377d0a\n')

# Generated at 2022-06-25 04:33:04.989754
# Unit test for function represent_hostvars
def test_represent_hostvars():
    a = AnsibleDumper()
    data = HostVars(dict(a=42, b='foo'))
    expected = dict([(u'a', 42), (u'b', u'foo')])
    actual = yaml.load(a.represent_hostvars(data))
    assert expected == actual

# Generated at 2022-06-25 04:33:09.237562
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(AnsibleDumper, AnsibleUnicode('test')) == u"'test'"
    assert represent_unicode(AnsibleDumper, AnsibleUnsafeText('test')) == u"'test'"
    assert represent_unicode(AnsibleDumper, AnsibleUnsafeBytes('test')) == u'<BASE64 ENCODED BINARY DATA>'



# Generated at 2022-06-25 04:33:17.069488
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    test_data = AnsibleVaultEncryptedUnicode(None, b'hightower: !vault |\n          $ANSIBLE_VAULT;1.1;AES256\n......\n')
    ansible_dumper = AnsibleDumper()
    expect_output = ansible_dumper.represent_scalar(u'!vault', test_data._ciphertext.decode(), style='|')

    real_output = represent_vault_encrypted_unicode(ansible_dumper, test_data)

    assert expect_output == real_output

# Generated at 2022-06-25 04:33:22.777971
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.safe_dump(AnsibleUndefined(), default_flow_style=False, Dumper=AnsibleDumper) == 'null\n'
    assert yaml.safe_dump(AnsibleUndefined('test'), default_flow_style=False, Dumper=AnsibleDumper) == 'null\n'

# Generated at 2022-06-25 04:33:31.907252
# Unit test for function represent_hostvars
def test_represent_hostvars():

    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleUnicode, AnsibleSequence

    test_hostvars = HostVars(hostvars=dict(
        foo=AnsibleUnicode('bar'),
        baz=AnsibleSequence([AnsibleUnicode('qux'),
                             AnsibleUnicode('corge')])
    ))

    print(yaml.dump(test_hostvars, Dumper=AnsibleDumper, default_flow_style=False))

    # Simple test to ensure the ansible_ssh_host hostvar is not
    # dumped in the output, as it is not supposed to be serialized
    # to disk.

# Generated at 2022-06-25 04:33:35.757167
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(u'foo', Dumper=AnsibleDumper) == u'foo\n...\n'



# Generated at 2022-06-25 04:33:43.021228
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    va = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT|1.1$HEXSTRINGHERE==')
    assert(represent_vault_encrypted_unicode(AnsibleDumper, va) == '!vault |\n  $ANSIBLE_VAULT|1.1$HEXSTRINGHERE==\n')

# Generated at 2022-06-25 04:33:58.689754
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    vault = VaultLib(password_file=None)
    test_pass = 'test passworD'
    ciphertext = vault.encrypt(test_pass)
    data = AnsibleVaultEncryptedUnicode(ciphertext.decode())
    rep_vault_encrypted_unicode = represent_vault_encrypted_unicode(AnsibleDumper, data)

# Generated at 2022-06-25 04:34:05.612622
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    b = binary_type('\x80')
    assert dumper.represent_binary(dumper, b) == yaml.representer.SafeRepresenter.represent_binary(dumper, b)


# Generated at 2022-06-25 04:34:12.426821
# Unit test for function represent_undefined
def test_represent_undefined():
    """
    Test that AnsibleUndefined raises
    :return:
    """
    dumper = AnsibleDumper()
    data = AnsibleUndefined('mydata')
    try:
        dumper.represent_undefined(data)
    except AnsibleUndefined as e:
        assert e.args[0] == 'mydata'
    else:
        raise AssertionError('AnsibleUndefined should have raised an exception')

# Generated at 2022-06-25 04:34:19.803612
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256;ansible\n383432323966663161333366373936663830356634376233316235623338633534393266646138\n36653630356433316135626631623661306138663235336138653530393433303234333133353733\n30353937383366373936663830356634376233316235623338633534393266646138366536303564\n')
    actual = represent_vault_encrypted_unicode(None, data)

# Generated at 2022-06-25 04:34:25.367923
# Unit test for function represent_unicode
def test_represent_unicode():
    o = AnsibleUnicode('hello world')
    test_data = {'foo': o}

    ansible_dumper = AnsibleDumper()
    ansible_dumper.ignore_aliases = lambda *args: True

    result = yaml.dump(test_data, Dumper=ansible_dumper, default_flow_style=True)
    assert result == '{foo: hello world}\n...\n'



# Generated at 2022-06-25 04:34:34.802488
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    import base64
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    value = vault.encrypt('test')
    # Test with encrypted value
    assert '$ANSIBLE_VAULT;1.1;' in yaml.dump(value, Dumper=AnsibleDumper)
    # Test with unencrypted value
    assert 'test' in yaml.dump(value._text, Dumper=AnsibleDumper)
    # Test with binary encrypted value
    base64_encrypted_value = base64.b64encode(value._ciphertext).decode()
    assert base64_encrypted_value in yaml.dump(value._ciphertext, Dumper=AnsibleDumper)
    # Test with binary unencrypted value
    base64_unencrypted_value = base64.b64

# Generated at 2022-06-25 04:34:37.711506
# Unit test for function represent_undefined
def test_represent_undefined():
    representer = AnsibleDumper()
    try:
        representer.represent_data(yaml.representer.RepresenterError)
        raise Exception('AnsibleDumper.represent_undefined is not working')
    except yaml.representer.RepresenterError:
        pass

# Generated at 2022-06-25 04:34:46.734103
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars, HostVarsVars

    h = HostVars(dict(a="foo", c=dict(b="bar")))
    assert(yaml.safe_dump(h, default_flow_style=False) == u'a: foo\nc:\n  b: bar\n')

    v = HostVarsVars(dict(a="foo", c=dict(b="bar")))
    assert(yaml.safe_dump(v, default_flow_style=False) == u'a: foo\nc:\n  b: bar\n')

    # See https://github.com/ansible/ansible/issues/17417
    # This is a regression of 2.1, the test shouldn't raise the exception:
    #   AttributeError: '_HostVarsV

# Generated at 2022-06-25 04:34:48.510211
# Unit test for function represent_undefined
def test_represent_undefined():
    yaml.dump({}, Dumper=AnsibleDumper, default_flow_style=False)

# Generated at 2022-06-25 04:34:55.252985
# Unit test for function represent_hostvars
def test_represent_hostvars():
    a = HostVars()
    a['b'] = 'c'
    assert yaml.dump(a, Dumper=AnsibleDumper) == '{b: c}\n'

# Generated at 2022-06-25 04:35:22.822875
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    str_0 = 'K  9'
    str_1 = 'T'
    bool_0 = True
    str_2 = 'J]D'
    str_3 = '=hXeJL'
    ansible_unsafe_bytes_0 = None
    list_0 = [str_1, str_1, str_2, str_2, str_0, str_1, str_3]
    list_1 = []
    str_4 = 'idm'
    bool_1 = False
    ansible_undefined_0 = None
    host_vars_vars_0 = module_2.HostVarsVars(list_0, list_1)
    float_0 = 100.0

# Generated at 2022-06-25 04:35:33.397263
# Unit test for function represent_binary
def test_represent_binary():
    str_1 = '\t\t4'
    str_2 = 'm!'
    str_3 = '\x00\x00\x00'
    str_4 = 'd6\x07'
    str_5 = 'y) E=3'
    ansible_unsafe_bytes_0 = module_1.AnsibleUnsafeBytes(str_1)
    ansible_unsafe_bytes_1 = module_1.AnsibleUnsafeBytes(str_2)
    ansible_unsafe_bytes_2 = module_1.AnsibleUnsafeBytes(str_3)
    ansible_unsafe_bytes_3 = module_1.AnsibleUnsafeBytes(str_4)
    ansible_unsafe_bytes_4 = module_1.AnsibleUnsafeBytes(str_5)

# Generated at 2022-06-25 04:35:36.443779
# Unit test for function represent_binary
def test_represent_binary():
    str_0 = 'B8G7}w-Eo^:G'

    # str -> bytes
    def callit(str_0):
        return yaml.representer.SafeRepresenter.represent_binary(str_0)
    var_0 = callit(str_0)



# Generated at 2022-06-25 04:35:42.746025
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    str_0 = 'l=H\rE[j'
    ansible_unsafe_bytes_0 = None
    list_0 = [ansible_unsafe_bytes_0, ansible_unsafe_bytes_0, str_0]
    list_1 = []
    str_1 = '%d\rU'
    bool_0 = False
    ansible_undefined_0 = None
    float_0 = 100.0
    ansible_dumper_0 = AnsibleDumper(str_1, bool_0, bool_0, bool_0, ansible_undefined_0, float_0)
    ansible_unsafe_text_0 = module_1.AnsibleUnsafeText()

# Generated at 2022-06-25 04:35:51.327416
# Unit test for function represent_binary
def test_represent_binary():
    str_0 = '- kIG8}FQlHubY'
    ansible_unsafe_bytes_0 = None
    list_0 = [ansible_unsafe_bytes_0, ansible_unsafe_bytes_0, str_0]
    list_1 = []
    str_1 = '%d\rU'
    bool_0 = False
    ansible_undefined_0 = None
    float_0 = 100.0
    ansible_dumper_0 = AnsibleDumper(str_1, bool_0, bool_0, bool_0, ansible_undefined_0, float_0)
    ansible_unsafe_text_0 = module_1.AnsibleUnsafeText()

# Generated at 2022-06-25 04:35:58.783135
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    ansible_dumper_0 = AnsibleDumper()
    ansible_dumper_1 = AnsibleDumper()
    ansible_vault_encrypted_unicode_0 = module_3.AnsibleVaultEncryptedUnicode()
    var_0 = represent_vault_encrypted_unicode(ansible_dumper_1, ansible_vault_encrypted_unicode_0)
    ansible_dumper_2 = AnsibleDumper()
    ansible_vault_encrypted_unicode_1 = module_3.AnsibleVaultEncryptedUnicode()
    var_1 = represent_vault_encrypted_unicode(ansible_dumper_2, ansible_vault_encrypted_unicode_1)
    ansible_vault_encrypted_unicode_2 = module_3.Ans

# Generated at 2022-06-25 04:36:05.085982
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    str_0 = '|'
    str_1 = '!'
    str_2 = ']e'
    ansible_dumper_0 = None
    ansible_vault_encrypted_unicode_0 = module_3.AnsibleVaultEncryptedUnicode(str_2, str_2)
    var_0 = represent_vault_encrypted_unicode(ansible_dumper_0)


# Generated at 2022-06-25 04:36:15.615129
# Unit test for function represent_binary
def test_represent_binary():
    str_0 = '%d\rU'
    bool_0 = False
    ansible_undefined_0 = None
    float_0 = 100.0
    ansible_dumper_0 = AnsibleDumper(str_0, bool_0, bool_0, bool_0, ansible_undefined_0, float_0)
    ansible_dumper_1 = AnsibleDumper(list_1, ansible_dumper_0, float_0, ansible_unsafe_text_0, bool_0, ansible_undefined_0, list_1)
    ansible_unsafe_bytes_0 = module_1.AnsibleUnsafeBytes(list_1)
    var_0 = represent_binary(ansible_dumper_1)


# Generated at 2022-06-25 04:36:26.386776
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # See if we can represent a AnsibleVaultEncryptedUnicode object
    str_0 = '8?9-i0!.GqybM^&6){/}6'
    ansible_unsafe_bytes_0 = None
    bool_0 = False
    ansible_undefined_0 = None
    float_0 = 100.0
    ansible_dumper_0 = AnsibleDumper(str_0, bool_0, bool_0, bool_0, ansible_undefined_0, float_0)
    str_1 = '0J*~E!tZ_3tZB'
    str_2 = '9\r5'
    bool_1 = True
    str_3 = 'u]ZHh'

# Generated at 2022-06-25 04:36:36.430341
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    str_0 = '!vault'
    str_1 = 'Y1'
    bool_0 = False
    ansible_undefined_0 = None
    float_0 = 100.0
    ansible_dumper_0 = AnsibleDumper(str_0, bool_0, bool_0, bool_0, ansible_undefined_0, float_0)
    var_0 = ansible_dumper_0.represent_scalar(str_0, str_1)
    str_2 = '-k4>|1'
    str_3 = '2Q[JT'
    str_4 = '- JW8s}/J3#G'
    str_5 = '8|Y0f'

# Generated at 2022-06-25 04:37:04.231050
# Unit test for function represent_binary
def test_represent_binary():
    str_0 = '- kIG8}FQlHubY'
    ansible_unsafe_bytes_0 = None
    list_0 = [ansible_unsafe_bytes_0, ansible_unsafe_bytes_0, str_0]
    list_1 = []
    str_1 = '%d\rU'
    bool_0 = False
    ansible_undefined_0 = None
    float_0 = 100.0
    ansible_dumper_0 = AnsibleDumper(str_1, bool_0, bool_0, bool_0, ansible_undefined_0, float_0)
    ansible_unsafe_text_0 = module_1.AnsibleUnsafeText()

# Generated at 2022-06-25 04:37:13.222650
# Unit test for function represent_binary
def test_represent_binary():
    str_0 = 'Fq3nX@N'
    ansible_unsafe_bytes_0 = module_1.AnsibleUnsafeBytes()
    ansible_dumper_0 = AnsibleDumper(str_0, str_0, str_0, ansible_unsafe_bytes_0, str_0)
    str_1 = '^8W`2'
    list_0 = []
    var_0 = represent_binary(ansible_dumper_0)
    host_vars_vars_0 = module_2.HostVarsVars(str_0, str_0, str_0, str_0, str_0, str_0)
    host_vars_vars_1 = module_2.HostVarsVars(str_0, list_0)
    ansible_dumper

# Generated at 2022-06-25 04:37:15.788346
# Unit test for function represent_binary
def test_represent_binary():
    ansible_unsafe_bytes_0 = None
    ansible_dumper_0 = AnsibleDumper(ansible_unsafe_bytes_0)
    var_0 = represent_binary(ansible_dumper_0)


# Generated at 2022-06-25 04:37:20.968260
# Unit test for function represent_binary
def test_represent_binary():
    bool_0 = False
    ansible_dumper_0 = AnsibleDumper(bool_0, bool_0, bool_0)
    ansible_unsafe_bytes_0 = module_1.AnsibleUnsafeBytes()
    str_0 = '{'
    var_0 = represent_binary(ansible_dumper_0)
    var_1 = represent_binary(ansible_unsafe_bytes_0)
    ansible_unsafe_text_0 = module_1.AnsibleUnsafeText(str_0, str_0)
    var_2 = represent_unicode(ansible_unsafe_text_0)
    ansible_unsafe_bytes_1 = module_1.AnsibleUnsafeBytes(str_0, str_0)

# Generated at 2022-06-25 04:37:30.702523
# Unit test for function represent_binary
def test_represent_binary():
    str_0 = '*=@z+'
    str_1 = '-kIG8}FQlHubY'
    ansible_unsafe_bytes_0 = module_1.AnsibleUnsafeBytes()
    list_0 = [ansible_unsafe_bytes_0]
    ansible_sequence_0 = module_3.AnsibleSequence(str_1, str_0, *list_0)
    ansible_dumper_0 = AnsibleDumper(ansible_sequence_0, ansible_sequence_0)
    ansible_vault_encrypted_unicode_0 = module_3.AnsibleVaultEncryptedUnicode()
    ansible_undefined_0 = module_4.AnsibleUndefined(*list_0, **{})
    host_vars_0 = module_

# Generated at 2022-06-25 04:37:34.366700
# Unit test for function represent_binary
def test_represent_binary():
    print('We are testing represent_binary')
    pass


# Generated at 2022-06-25 04:37:39.720245
# Unit test for function represent_binary
def test_represent_binary():
    ansible_dumper_0 = AnsibleDumper(str_0, bool_0, bool_0, bool_0, ansible_undefined_0, float_0)
    ansible_unsafe_bytes_0 = module_1.AnsibleUnsafeBytes(str_0)
    var_0 = represent_binary(ansible_dumper_0, ansible_unsafe_bytes_0)


# Generated at 2022-06-25 04:37:46.174517
# Unit test for function represent_binary
def test_represent_binary():
    str_0 = 'f[!FF'
    dict_0 = {str_0: str_0}
    ansible_dumper_0 = AnsibleDumper(dict_0)
    str_1 = 'k:C|\r>@'
    ansible_unsafe_bytes_0 = module_1.AnsibleUnsafeBytes(str_1)
    var_0 = represent_binary(ansible_dumper_0, ansible_unsafe_bytes_0)
    ansible_unsafe_text_0 = module_1.AnsibleUnsafeText(str_0)
    ansible_dumper_1 = AnsibleDumper(ansible_unsafe_text_0)
    var_1 = represent_binary(ansible_dumper_1, ansible_unsafe_text_0)
    ans

# Generated at 2022-06-25 04:37:48.025310
# Unit test for function represent_binary
def test_represent_binary():
    assert represent_binary(AnsibleDumper([]), None) == None


# Generated at 2022-06-25 04:37:54.570954
# Unit test for function represent_binary
def test_represent_binary():
    str_0 = 'g'
    str_1 = 'G`o'
    ansible_unsafe_bytes_0 = module_1.AnsibleUnsafeBytes(str_0)
    float_0 = -100.0
    ansible_dumper_0 = AnsibleDumper(str_0, ansible_unsafe_bytes_0, str_0, str_1, float_0)
    var_0 = represent_binary(ansible_dumper_0, ansible_unsafe_bytes_0)
    ansible_unsafe_text_0 = module_1.AnsibleUnsafeText(str_1)
    var_1 = represent_binary(ansible_dumper_0, ansible_unsafe_text_0)

# Generated at 2022-06-25 04:38:31.340039
# Unit test for function represent_binary
def test_represent_binary():
    str_0 = 'p5,VXt'
    str_1 = '%d\rU'
    bool_0 = False
    ansible_undefined_0 = None
    float_0 = 100.0
    ansible_dumper_0 = AnsibleDumper(str_1, bool_0, bool_0, bool_0, ansible_undefined_0, float_0)
    ansible_unsafe_bytes_0 = module_1.AnsibleUnsafeBytes(ansible_dumper_0, str_0)
    ansible_dumper_1 = AnsibleDumper(bool_0, float_0)
    str_2 = 'm{'
    str_3 = 'H2M99\rY'
    str_4 = 'o{'

# Generated at 2022-06-25 04:38:38.199806
# Unit test for function represent_binary
def test_represent_binary():
    ansible_unsafe_bytes_0 = module_1.AnsibleUnsafeBytes()
    ansible_dumper_0 = AnsibleDumper(ansible_unsafe_bytes_0)
    var_0 = ansible_dumper_0.represent_binary(ansible_unsafe_bytes_0)
    assert var_0 == ''


# Generated at 2022-06-25 04:38:44.765729
# Unit test for function represent_binary
def test_represent_binary():
   ansible_unsafe_bytes_0 = None
   str_0 = 'V7dJtZaA4n9'
   list_0 = [ansible_unsafe_bytes_0, ansible_unsafe_bytes_0, str_0]
   host_vars_vars_0 = module_2.HostVarsVars(list_0, ansible_unsafe_bytes_0)
   ansible_dumper_0 = AnsibleDumper(host_vars_vars_0, ansible_unsafe_bytes_0)
   str_1 = '+dL_I#jFZdf'
   str_2 = '+dL_I#jFZdf'
   str_3 = '+dL_I#jFZdf'

# Generated at 2022-06-25 04:38:54.315337
# Unit test for function represent_binary
def test_represent_binary():
    ansible_unsafe_bytes_0 = None
    int_0 = 9
    ansible_dumper_0 = AnsibleDumper(int_0, ansible_unsafe_bytes_0)
    var_0 = represent_binary(ansible_dumper_0)
    ansible_dumper_1 = AnsibleDumper(ansible_dumper_0)
    ansible_unicode_0 = module_1.AnsibleUnicode()
    str_0 = ';.5X5q&1Z'
    var_1 = ansible_dumper_1.represent_data(ansible_unicode_0)
    str_1 = '#/VuR'

# Generated at 2022-06-25 04:39:02.095735
# Unit test for function represent_binary
def test_represent_binary():
    str_0 = '#'
    ansible_unsafe_bytes_0 = None
    list_0 = [ansible_unsafe_bytes_0, ansible_unsafe_bytes_0, str_0]
    list_1 = []
    str_1 = '%d\rU'
    bool_0 = False
    ansible_undefined_0 = None
    float_0 = 100.0
    ansible_dumper_0 = AnsibleDumper(str_1, bool_0, bool_0, bool_0, ansible_undefined_0, float_0)
    ansible_unsafe_bytes_1 = module_1.AnsibleUnsafeBytes(ansible_undefined_0, *list_1, **{str_0: str_0})
    ansible_unsafe_bytes_2

# Generated at 2022-06-25 04:39:13.282182
# Unit test for function represent_binary
def test_represent_binary():
    int_0 = 64
    ansible_unsafe_bytes_0 = module_1.AnsibleUnsafeBytes()
    ansible_dumper_0 = AnsibleDumper(int_0, ansible_unsafe_bytes_0)
    var_0 = represent_binary(ansible_dumper_0)
    str_0 = '- 1V7P'
    float_0 = 94.5
    ansible_unsafe_bytes_1 = module_1.AnsibleUnsafeBytes()
    ansible_dumper_1 = AnsibleDumper(str_0, float_0, ansible_unsafe_bytes_1)
    var_1 = represent_binary(ansible_dumper_1)
    str_1 = '~sOy3qBI'
    bool_0 = False
    int_1

# Generated at 2022-06-25 04:39:24.346068
# Unit test for function represent_binary
def test_represent_binary():
    #
    # Input parameters
    #   self: a simple stub class that allows us to add representers for our overridden object types
    #   data: represent binary data as base64 encoded strings
    #
    # Return value
    #   Return value of function represent_scalar
    #

    str_5 = '/=5Q/k:7z!o,6'
    str_6 = 'XYbLYdY\n    '
    ansible_sequence_1 = module_3.AnsibleSequence(str_6)
    ansible_dumper_4 = AnsibleDumper(str_5, ansible_sequence_1)
    ansible_unsafe_text_1 = module_1.AnsibleUnsafeText(str_5)

# Generated at 2022-06-25 04:39:33.048476
# Unit test for function represent_binary
def test_represent_binary():
    str_0 = 'wRdI\tM'
    str_1 = 'Dm0A'
    ansible_mapping_0 = module_3.AnsibleMapping(str_1, str_1)
    str_2 = '#J4$)oA'
    dict_0 = {str_0: str_1, str_0: ansible_mapping_0}
    ansible_unsafe_bytes_0 = module_1.AnsibleUnsafeBytes([str_0, str_2], **dict_0)
    ansible_dumper_0 = AnsibleDumper(str_0)
    var_0 = represent_binary(ansible_dumper_0, ansible_unsafe_bytes_0)
    str_3 = 'KPm^'

# Generated at 2022-06-25 04:39:40.545655
# Unit test for function represent_binary
def test_represent_binary():
    str_0 = 'V7|'
    bool_0 = False
    ansible_undefined_0 = None
    float_0 = 100.0
    ansible_dumper_0 = AnsibleDumper(str_0, bool_0, bool_0, bool_0, ansible_undefined_0, float_0)
    str_1 = ' '
    str_2 = '}LZ'
    ansible_unsafe_bytes_0 = module_1.AnsibleUnsafeBytes(str_1, str_2)
    var_0 = represent_binary(ansible_dumper_0, ansible_unsafe_bytes_0)


# Generated at 2022-06-25 04:39:47.168711
# Unit test for function represent_binary
def test_represent_binary():
    str_5 = 'binary'
    ansible_unsafe_bytes_1 = None
    ansible_dumper_4 = AnsibleDumper(str_5, ansible_unsafe_bytes_1, str_5, str_5)
    ansible_unsafe_bytes_0 = module_1.AnsibleUnsafeBytes()
    ansible_dumper_5 = AnsibleDumper(str_5, ansible_unsafe_bytes_1, ansible_unsafe_bytes_0, str_5)
    str_6 = 'kIG8}FQlHubY'
    ansible_dumper_6 = AnsibleDumper(ansible_dumper_4, ansible_dumper_5, ansible_dumper_5, str_6)

# Generated at 2022-06-25 04:40:46.901495
# Unit test for function represent_binary
def test_represent_binary():
    # Test case - 0
    # Execute
    str_0 = '|Z=bs:Nl#@'
    ansible_unsafe_bytes_0 = None
    str_1 = 'uJZRnK7'
    str_2 = 'V\'Qy~q3Cd'
    str_3 = '\x15\x02\x19\x0c\r>\x05\x0f\x1cY\x14:\x12\x15'
    str_4 = '\x0cI\x1e'
    str_5 = '2'
    bool_0 = False
    ansible_undefined_0 = None

# Generated at 2022-06-25 04:40:53.838704
# Unit test for function represent_binary
def test_represent_binary():
    ansible_unsafe_text_0 = module_1.AnsibleUnsafeText()
    ansible_dumper_0 = AnsibleDumper(ansible_unsafe_text_0)
    ansible_unsafe_bytes_0 = module_1.AnsibleUnsafeBytes()
    var_0 = ansible_dumper_0.represent_binary(ansible_unsafe_bytes_0)


# Generated at 2022-06-25 04:40:54.639693
# Unit test for function represent_binary
def test_represent_binary():
    pass


# Generated at 2022-06-25 04:40:59.804585
# Unit test for function represent_binary

# Generated at 2022-06-25 04:41:08.290720
# Unit test for function represent_binary
def test_represent_binary():
    str_0 = 'dJOp#'
    ansible_unsafe_bytes_0 = None
    list_0 = [ansible_unsafe_bytes_0, ansible_unsafe_bytes_0, str_0]
    list_1 = []
    str_1 = '%d\rU'
    bool_0 = False
    ansible_undefined_0 = None
    float_0 = 100.0
    ansible_dumper_0 = AnsibleDumper(str_1, bool_0, bool_0, bool_0, ansible_undefined_0, float_0)
    ansible_unsafe_text_0 = module_1.AnsibleUnsafeText()

# Generated at 2022-06-25 04:41:17.735594
# Unit test for function represent_binary
def test_represent_binary():
    str_0 = '- kIG8}FQlHubY'
    ansible_unsafe_bytes_0 = None
    list_0 = [ansible_unsafe_bytes_0, ansible_unsafe_bytes_0, str_0]
    list_1 = []
    str_1 = '%d\rU'
    bool_0 = False
    ansible_undefined_0 = None
    float_0 = 100.0
    ansible_dumper_0 = AnsibleDumper(str_1, bool_0, bool_0, bool_0, ansible_undefined_0, float_0)
    ansible_unsafe_text_0 = module_1.AnsibleUnsafeText()

# Generated at 2022-06-25 04:41:27.599080
# Unit test for function represent_binary
def test_represent_binary():
    # Test
    ansible_unsafe_bytes_0 = None
    str_0 = '- kIG8}FQlHubY'
    list_0 = [ansible_unsafe_bytes_0, ansible_unsafe_bytes_0, str_0]
    list_1 = []
    str_1 = '%d\rU'
    bool_0 = False
    ansible_undefined_0 = None
    float_0 = 100.0
    ansible_dumper_0 = AnsibleDumper(str_1, bool_0, bool_0, bool_0, ansible_undefined_0, float_0)
    ansible_unsafe_text_0 = module_1.AnsibleUnsafeText()

# Generated at 2022-06-25 04:41:37.733927
# Unit test for function represent_binary
def test_represent_binary():
    str_0 = 'q3NgF(D#9~t^(zL-5r~2'
    ansible_dumper_0 = AnsibleDumper()
    ansible_unsafe_bytes_0 = module_1.AnsibleUnsafeBytes()
    ansible_dumper_1 = AnsibleDumper(ansible_unsafe_bytes_0, ansible_unsafe_bytes_0, str_0)
    var_0 = represent_binary(ansible_dumper_1)
    str_1 = 'A6/l^a'
    ansible_unicode_0 = module_1.AnsibleUnicode(str_0, str_0)
    ansible_mapping_0 = module_3.AnsibleMapping(ansible_unicode_0, str_1)
   

# Generated at 2022-06-25 04:41:46.752158
# Unit test for function represent_binary
def test_represent_binary():
    str_0 = '%c\x1d'
    ansible_unsafe_bytes_0 = None
    list_0 = [ansible_unsafe_bytes_0, ansible_unsafe_bytes_0, str_0]
    list_1 = []
    str_1 = '%d\rU'
    bool_0 = False
    ansible_undefined_0 = None
    float_0 = 100.0
    ansible_dumper_0 = AnsibleDumper(str_1, bool_0, bool_0, bool_0, ansible_undefined_0, float_0)
    ansible_unsafe_text_0 = module_1.AnsibleUnsafeText()

# Generated at 2022-06-25 04:41:55.922173
# Unit test for function represent_binary
def test_represent_binary():
    str_0 = '/5%3i@'
    str_1 = 'X_,R\\i"kKp~'
    str_2 = 'g:,A_,V.Z< '
    ansible_dumper_0 = AnsibleDumper(str_0, str_1, str_2)
    str_3 = '5,/Xt'
    ansible_unsafe_bytes_0 = module_1.AnsibleUnsafeBytes(str_0, str_0, str_3)
    var_0 = represent_binary(ansible_dumper_0, ansible_unsafe_bytes_0)
