

# Generated at 2022-06-25 04:32:04.165643
# Unit test for function represent_undefined
def test_represent_undefined():
    test_case_0()


# Generated at 2022-06-25 04:32:07.864056
# Unit test for function represent_undefined
def test_represent_undefined():
    float_0 = -117.835
    var_0 = represent_undefined(float_0)
    assert var_0 == True


# Generated at 2022-06-25 04:32:16.086679
# Unit test for function represent_hostvars
def test_represent_hostvars():
    float_0 = -117.835
    int_0 = -146
    str_0 = 'utf-8'
    list_0 = [float_0]
    list_1 = [int_0]
    list_2 = [str_0]
    list_3 = [list_0, list_1, list_2]
    list_4 = [set_0, list_1]
    list_5 = [dict_0]
    list_6 = [dict_1]
    list_7 = [list_2, list_2, list_0]
    list_8 = [str_0]
    list_9 = [float_0]
    list_10 = [int_0]
    list_11 = [list_10, list_9, list_8]

# Generated at 2022-06-25 04:32:25.075706
# Unit test for function represent_unicode
def test_represent_unicode():
    ansible_va_ob = AnsibleVaultEncryptedUnicode()
    ansible_va_ob._ciphertext = b'foo'
    ansible_unicode_ob = AnsibleUnicode()
    ansible_unicode_ob = u'foo'
    ansible_unsafe_bytes_ob = AnsibleUnsafeBytes()
    ansible_unsafe_bytes_ob = b'foo'
    host_bvars_ob = HostVarsVars()
    host_bvars_ob.name = u'foo'
    host_bvars_ob.values = [u'foo']
    host_vars_ob = HostVars()
    host_vars_ob.get = lambda _: [host_bvars_ob]

# Generated at 2022-06-25 04:32:27.951189
# Unit test for function represent_unicode
def test_represent_unicode():
    sample_data = u'\u54c7'
    var_0 = represent_unicode(sample_data)


# Generated at 2022-06-25 04:32:31.072087
# Unit test for function represent_unicode
def test_represent_unicode():
    unsafe_text = b'unsecure'
    result_0 = represent_unicode(unsafe_text)
    assert type(result_0) == bool
    assert result_0 == True



# Generated at 2022-06-25 04:32:34.345956
# Unit test for function represent_undefined
def test_represent_undefined():
    # noinspection PyNoneFunctionAssignment
    float_0 = -117.835
    # noinspection PyNoneFunctionAssignment
    var_0 = represent_undefined(float_0)
    assert var_0 == False



# Generated at 2022-06-25 04:32:38.823347
# Unit test for function represent_binary
def test_represent_binary():
    binary_0 = b'\x1B\x63\xC0\x02\x80\xD1\x3C\x85\xDE\xA5\x61\x8F'
    var_0 = represent_binary(binary_0)


# Generated at 2022-06-25 04:32:39.919380
# Unit test for function represent_binary
def test_represent_binary():
    float_0 = 1.2


# Generated at 2022-06-25 04:32:46.858717
# Unit test for function represent_unicode
def test_represent_unicode():
    # Test with real AnsibleUnsafeText
    str_0 = text_type('foo')
    var_0 = AnsibleUnsafeText(str_0)
    var_1 = represent_unicode(var_0)
    # Test with normal text
    str_1 = text_type('foo')
    var_2 = represent_unicode(str_1)
    # Test with real AnsibleUnsafeBytes
    bytes_0 = b'foo'
    var_3 = AnsibleUnsafeBytes(bytes_0)
    var_4 = represent_unicode(var_3)
    # Test with normal bytes
    bytes_1 = b'foo'
    var_5 = represent_unicode(bytes_1)

# Generated at 2022-06-25 04:32:50.784347
# Unit test for function represent_unicode
def test_represent_unicode():
    ansible_unicode_0 = "hello world"
    result = represent_unicode(ansible_unicode_0)


# Generated at 2022-06-25 04:32:53.173123
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = {'foo': 'bar'}
    dumper = AnsibleDumper
    dumper.represent_hostvars(dumper, data)


# Generated at 2022-06-25 04:32:56.909041
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars_0 = HostVars(
        # FIXME: missing data argument
    )
    data_0 = None
    assert hostvars_0.represent_dict(data_0) == None
    assert hostvars_0.represent_dict() == None


# Generated at 2022-06-25 04:33:00.534915
# Unit test for function represent_binary
def test_represent_binary():
    yaml_data = b'test_data'
    new_yaml_data = represent_binary(yaml_data)
    assert new_yaml_data == yaml_data

# Generated at 2022-06-25 04:33:02.906054
# Unit test for function represent_binary
def test_represent_binary():
    f1 = 'test_value1'
    rval = represent_binary(f1)


# Generated at 2022-06-25 04:33:04.545183
# Unit test for function represent_undefined
def test_represent_undefined():
    assert represent_undefined(AnsibleDumper(None, None, None), AnsibleUndefined)


# Generated at 2022-06-25 04:33:06.631122
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper.represent_undefined(AnsibleDumper(), AnsibleUndefined('test_input'))

# Generated at 2022-06-25 04:33:12.202896
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()

    ho = HostVars()
    ho.hostname = 'host1'

    ho.vars = {'a': 1, 'b': 2, 'c': '3'}
    result = dumper.represent_hostvars(ho)
    assert result == {'a': 1, 'b': 2, 'c': '3'}

    ho.vars.update({'aa': 11, 'bb': 22, 'cc': '33'})
    result = dumper.represent_hostvars(ho)
    assert result == {'a': 1, 'b': 2, 'c': '3', 'aa': 11, 'bb': 22, 'cc': '33'}

    ho.vars = {'dd': 11}
    result = dumper.represent_hostvars(ho)

# Generated at 2022-06-25 04:33:22.263405
# Unit test for function represent_binary
def test_represent_binary():
    assert represent_binary(AnsibleDumper, b'\x00\x10') == b"!binary |\n  AAAAAA==\n"
    assert represent_binary(AnsibleDumper, b'\x00\x10\x20') == b"!binary |\n  AAAGk=\n"
    assert represent_binary(AnsibleDumper, b'\x00\x10\x20\x30') == b"!binary |\n  AAAGkAA=\n"
    assert represent_binary(AnsibleDumper, b'\x00\x10\x20\x30\x40') == b"!binary |\n  AAAGkAAHg==\n"

# Generated at 2022-06-25 04:33:31.375532
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    yaml.YAML.dump(object, stream, Dumper=yaml.RoundTripDumper)
    a = 'AAECAwQFBgcICQoLDA0ODxAREhMUFRYXGBkaGxwdHh8='
    # Make sure our function is not raising an exception
    try:
        represent_vault_encrypted_unicode(float_0, a)
    except:
        raise AssertionError('AnsibleDumper.represent_vault_encrypted_unicode raised an exception')
    assert True


# Generated at 2022-06-25 04:33:35.212240
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Test internal function calls
    represent_vault_encrypted_unicode
    # Test internal function calls
    # Test internal function calls
    # Test internal function calls
    # Test internal function calls
    # Test internal function calls
    # Test internal function calls

# Generated at 2022-06-25 04:33:38.674749
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert isinstance(represent_hostvars(AnsibleDumper(), 1), bool) is True

# Generated at 2022-06-25 04:33:42.811564
# Unit test for function represent_undefined
def test_represent_undefined():
    # Test that represent_undefined returns None
    float_1 = 0.1
    assert var == float_1
    # Test that represent_undefined fails when the input is not  a list
    float_2 = 0.2
    assert var == float_2
    # Test that represent_undefined returns None
    float_3 = 0.3
    assert var == float_3


# Generated at 2022-06-25 04:33:46.475172
# Unit test for function represent_unicode
def test_represent_unicode():
    a_unicode_string = u'{}'
    assert AnsibleDumper.represent_unicode(a_unicode_string) == '\'{}\''
    assert AnsibleDumper.represent_unicode(a_unicode_string) != '\u2604'
    assert AnsibleDumper.represent_unicode(a_unicode_string) != '1.2'


# Generated at 2022-06-25 04:33:54.211364
# Unit test for function represent_unicode

# Generated at 2022-06-25 04:34:00.194968
# Unit test for function represent_binary
def test_represent_binary():
    data_b = [65, 66, 67]
    data_h = '414243'
    data_s = b'ABC'

    assert yaml.dump(data_b, Dumper=AnsibleDumper) == "{!!python/tuple [65, 66, 67]}\n"
    assert yaml.dump(data_h, Dumper=AnsibleDumper) == "415243\n"
    assert yaml.dump(data_s, Dumper=AnsibleDumper) == "ABC\n"


# Generated at 2022-06-25 04:34:03.435702
# Unit test for function represent_undefined
def test_represent_undefined():
    r = AnsibleDumper()
    r.represent_undefined(None)



# Generated at 2022-06-25 04:34:12.837959
# Unit test for function represent_binary
def test_represent_binary():
    i = 0
    
    # Test case setup
    x = "I will not buy this record, it is scratched."
    y = "My hovercraft is full of eels."
    z = "I'd like to be under the sea, in an octopus's garden."
    
    # Test case edge setup
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    
    
    # Test case 1
    case_1_input = (x == x)
    case_1_output = y
    case_1_expect = z

# Generated at 2022-06-25 04:34:13.999285
# Unit test for function represent_binary
def test_represent_binary():
    data = "test"
    yaml.dump(data)


# Generated at 2022-06-25 04:34:17.999613
# Unit test for function represent_undefined
def test_represent_undefined():
    float_0 = 1.2
    data_0 = AnsibleUndefined(data=float_0)
    loader_0 = AnsibleDumper()
    result_0 = loader_0.represent_undefined(data=data_0)
    assert result_0


# Generated at 2022-06-25 04:34:20.266774
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    pass

# Generated at 2022-06-25 04:34:26.858052
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    '''
    This is a stub test case for checking the format of exceptions
    thrown from the function.
    '''
    from ansible.module_utils.common.yaml import make_yaml_safe
    from ansible.vars.unsafe_proxy import wrap_var
    encoded = wrap_var('test')
    result = make_yaml_safe(encoded)
    ansible_dumper = AnsibleDumper()

    ansible_dumper.represent_vault_encrypted_unicode(result)
    return True # The test passed


# Generated at 2022-06-25 04:34:29.004285
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = {}
    dumper = AnsibleDumper()

    represent_hostvars(dumper, data)
    assert data == {}


# Generated at 2022-06-25 04:34:30.594234
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert 1 == 1
    return



# Generated at 2022-06-25 04:34:38.489615
# Unit test for function represent_hostvars
def test_represent_hostvars():
    scalar_0 = AnsibleUnicode('scalar_0')
    list_0 = list()
    tuple_0 = tuple()
    dictionary_0 = dict()
    items = [scalar_0, list_0, tuple_0, dictionary_0]
    # Test with a set of valid inputs
    # We are using HostVars as the data type
    hostvars = HostVars()
    # hostvars.update(items)
    # result = represent_hostvars(AnsibleDumper(), hostvars)
    # assert(result == """{scalar_0: '', list_0: [], tuple_0: [], dictionary_0: {}}""")
    # Test with a set of valid inputs
    # We are using HostVars as the data type
    hostvars = HostVars

# Generated at 2022-06-25 04:34:47.143436
# Unit test for function represent_binary
def test_represent_binary():
    from ansible.module_utils.common.yaml import AnsibleDumper
    from ansible.module_utils.six import binary_type
    binary_type_0 = binary_type('\x82')
    binary_type_1 = binary_type('\xef\xbc\xa1')
    binary_type_2 = binary_type('\xd7\x90\xd7\x91\xd7\x92')
    assert(AnsibleDumper.represent_binary(binary_type_0) == u'!binary |\n  +Ao=\n')
    assert(AnsibleDumper.represent_binary(binary_type_1) == u'!binary |\n  +/v8=\n')

# Generated at 2022-06-25 04:34:52.987585
# Unit test for function represent_undefined
def test_represent_undefined():
    obj = object()
    h = AnsibleDumper.represent_undefined(obj)
    o = AnsibleDumper.represent_undefined(obj, top=True)
    print(h)
    print(o)
    if hasattr(h, '__getitem__'):
        assert h['__ansible_undefined__'], "__ansible_undefined__ tag should be present in an object"
        assert o['__ansible_undefined__'], "__ansible_undefined__ tag should be present in an object"
    else:
        assert h == {'__ansible_undefined__': True}, "__ansible_undefined__ tag should be present in an object"
        assert o == {'__ansible_undefined__': True}, "__ansible_undefined__ tag should be present in an object"


# Generated at 2022-06-25 04:34:56.522802
# Unit test for function represent_undefined
def test_represent_undefined():
    float_0 = 1.2
    ansible_dump_0 = AnsibleDumper.represent_undefined(float_0)
    print('ansible_dump_0: {0}'.format(ansible_dump_0))



# Generated at 2022-06-25 04:35:06.798720
# Unit test for function represent_undefined
def test_represent_undefined():
    # Test that it works for simple types and scalars
    ansible_representer = yaml.representer.SafeRepresenter()
    yaml.representer.SafeRepresenter.add_representer(
        bool,
        lambda *args: ansible_representer.represent_scalar('bool', 'false')
    )
    assert AnsibleDumper().represent_data(AnsibleUndefined()) == 'false\n...\n'

    # Test that it works for complex types
    yaml.representer.SafeRepresenter.add_representer(
        text_type,
        lambda *args: ansible_representer.represent_scalar('str', 'false')
    )
    assert AnsibleDumper().represent_data(AnsibleUndefined()) == 'false\n...\n'

    # Test that it works for complex

# Generated at 2022-06-25 04:35:13.260075
# Unit test for function represent_binary
def test_represent_binary():

    # AnsibleUnsafeBytes
    data = b'\x00\x01\x02\x03'
    if not isinstance(represent_binary(None, data), str):
        raise AssertionError()

    # Binary type
    data = b'\x00\x01\x02\x03'
    if not isinstance(represent_binary(None, data), str):
        raise AssertionError()

    # Non-binary type
    data = '\x00\x01\x02\x03'
    if not isinstance(represent_binary(None, data), str):
        raise AssertionError()


if __name__ == '__main__':
    test_case_0()
    test_represent_binary()

# Generated at 2022-06-25 04:35:23.419577
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-25 04:35:26.033304
# Unit test for function represent_binary
def test_represent_binary():
    udata = u'bytes'
    data = AnsibleUnsafeBytes(udata)
    representer = yaml.representer.SafeRepresenter()
    result = represent_binary(representer, data)

    assert isinstance(result, yaml.nodes.ScalarNode)
    assert result.style == '|'



# Generated at 2022-06-25 04:35:30.891113
# Unit test for function represent_hostvars
def test_represent_hostvars():
    """
    >>> import collections
    >>> dumper = yaml.dumper.Dumper
    >>> dumper.add_representer(collections.defaultdict, represent_hostvars)
    >>> data = collections.defaultdict(dict)
    >>> data['foo'] = 'bar'
    >>> print(yaml.dump(data))
    foo: bar
    <BLANKLINE>
    """



# Generated at 2022-06-25 04:35:33.151065
# Unit test for function represent_binary
def test_represent_binary():
    a = AnsibleDumper()
    assert a.represent_binary(b'\x00\x01\x02\x03\x04') == '!!binary |\n  AAECAwQF\n'

# Generated at 2022-06-25 04:35:34.469724
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper.represent_undefined(AnsibleDumper(), AnsibleUndefined())



# Generated at 2022-06-25 04:35:44.789316
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = HostVars()
    hostvars.setvar('test', 'test')
    hostvarsvars = HostVarsVars(hostvars)
    hostvarsvars.setvar('test', 'test')  # setvar not required
    varswithsources = VarsWithSources()
    varswithsources.setvar('test', 'test')
    varswithsources.add_source('test')
    assert represent_hostvars(None, hostvars) == yaml.representer.SafeRepresenter.represent_dict(None, dict(hostvars))
    assert represent_hostvars(None, hostvarsvars) == yaml.representer.SafeRepresenter.represent_dict(None, dict(hostvarsvars))

# Generated at 2022-06-25 04:35:50.671352
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    variable_manager = VariableManager()
    hv = HostVars(hostname='foo', variables=variable_manager)

    host_vars_test = hv.get_vars()
    host_vars_test['foo'] = ['bar', 'baz']

    stream = yaml.dump(host_vars_test, default_flow_style=False, Dumper=AnsibleDumper)
    assert isinstance(stream, text_type)

    # Make sure that the output looks like what we would expect
    assert stream == u"foo:\n- bar\n- baz\n\n"

# Generated at 2022-06-25 04:35:55.890633
# Unit test for function represent_unicode
def test_represent_unicode():

    # Test cases
    test_data = [
        b'foo',
    ]

    # Expected results
    expected_results = [
        'foo\n...\n',
    ]

    # Run the tests
    for idx, input in enumerate(test_data):
        test = AnsibleDumper.represent_unicode(AnsibleDumper, input)
        assert test == expected_results[idx]



# Generated at 2022-06-25 04:36:00.554416
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()

    # confirm that unicode strings are unmodified
    string = u'Normal String'
    result = dumper.represent_unicode(string)
    assert result == yaml.representer.SafeRepresenter.represent_str(dumper, string)

    # confirm that Ansicode strings are converted to unicode
    ac = AnsibleUnicode(value=u'unicode')
    result = dumper.represent_unicode(ac)
    assert result == yaml.representer.SafeRepresenter.represent_str(dumper, text_type(ac))



# Generated at 2022-06-25 04:36:07.438565
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    test_list = [
        {
            "a": HostVars(
                {
                    'test': 1
                }
            )
        },
        {
            "b": HostVarsVars(
                {
                    'test': 2
                }
            )
        }
    ]
    expected_output = "[{a: {test: 1}}, {b: {test: 2}}]"
    output = yaml.dump(test_list, Dumper=AnsibleDumper, default_flow_style=False)
    assert output == expected_output

# Generated at 2022-06-25 04:36:16.204499
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    original_unicode = AnsibleVaultEncryptedUnicode('AnsibleVaultEncryptedUnicode', b'123456789012345678901234567890')
    yaml.dumper = AnsibleDumper
    assert yaml.dumper.represent_vault_encrypted_unicode(yaml.dumper, original_unicode) == u'!vault |\n  MTIzNDU2Nzg5MDEyMzQ1Njc4OTAxMjM0NTY3ODkw'

# Generated at 2022-06-25 04:36:26.412623
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()

    assert dumper.represent_data(AnsibleUndefined) == ''

    class myundef(AnsibleUndefined):
        def __init__(self, *args, **kwargs):
            pass
    assert dumper.represent_data(myundef()) == ''

    class myundef(AnsibleUndefined):
        def __init__(self, *args, **kwargs):
            pass

        def __bool__(self):
            return False

        __nonzero__ = __bool__
    assert dumper.represent_data(myundef()) == ''

    class myundef(AnsibleUndefined):
        def __init__(self, *args, **kwargs):
            pass

        def __bool__(self):
            return True

        __nonzero__ = __

# Generated at 2022-06-25 04:36:27.842596
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    dumper.represent_undefined(AnsibleUndefined(obj=False))



# Generated at 2022-06-25 04:36:32.679628
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.objects import AnsibleMapping
    d = AnsibleMapping()
    d.update({u"k1": u"v1"})
    s = yaml.dump(d, Dumper=AnsibleDumper)
    assert s == "k1: v1\n"

# Generated at 2022-06-25 04:36:42.276526
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    import ansible.plugins.loader
    ansible.plugins.loader.get_all_plugin_loaders()

    # TODO: skip or fix
    # FIXME: fix in v2.2.0
    # Error:
    #   Traceback (most recent call last):
    #       File "/var/tmp/ansible_NyB0Jr/ansible_module_vars.py", line 100, in <module>
    #           main()
    #       File "/var/tmp/ansible_NyB0Jr/ansible_module_vars.py", line 75, in main
    #           changed=is_changed(result)
    #       File "/var/tmp/ansible_NyB0Jr/ansible_modlib.zip/ansible/module_utils/basic.py", line 73, in is_changed

# Generated at 2022-06-25 04:36:45.325374
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.loader import AnsibleLoader

    h = HostVars()
    h['key'] = 'value'
    dumper = AnsibleDumper
    d = text_type(yaml.dump(h, Dumper=dumper))
    data = yaml.load(d, Loader=AnsibleLoader)
    assert 'key' in data

# Generated at 2022-06-25 04:36:54.963489
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = yaml.YAML()
    dumper.default_flow_style = False
    dumper.representer = AnsibleDumper

    hostvars = HostVars()
    hostvars.add_host_vars(
        hostname='HOST_NAME',
        variables={
            'ansible_connection': 'HOST_CONNECTION',
            'ansible_host': 'HOST_IP',
            'ansible_user': 'HOST_USER',
            'ansible_become': False,
        }
    )

    result = dumper.dump(hostvars)

# Generated at 2022-06-25 04:37:01.193149
# Unit test for function represent_binary
def test_represent_binary():
    obj = AnsibleDumper()
    data = b'a\x1d\xf8\x08\xb2\xbd\xd7\xeb\xf9'
    result = obj.represent_binary(data)
    assert result == "!!binary |\n" \
                     "  YXFkz5mDyJ/v8/WU\n"


# Unit tests for function represent_unicode

# Generated at 2022-06-25 04:37:02.256287
# Unit test for function represent_undefined
def test_represent_undefined():

    yaml.dump(AnsibleUndefined, Dumper=AnsibleDumper)

# Generated at 2022-06-25 04:37:12.808478
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = HostVars(
        dict(
            self=HostVarsVars(
                dict(
                    foo='bar',
                ),
            ),
        ),
    )
    expected = u'self:\n  foo: bar\n'
    dumped = yaml.dump(data, Dumper=AnsibleDumper)
    assert dumped == expected
    loaded = yaml.load(dumped)
    assert loaded == dict(data)
    # Extra stuff we expect to get from yaml.load
    assert repr(type(loaded['self'])) == "<class 'ansible.vars.hostvars.HostVarsVars'>"
    assert repr(type(loaded['self']['foo'])) == "<class 'ansible.module_utils.common.yaml.objects.AnsibleUnicode'>"


# Unit

# Generated at 2022-06-25 04:37:41.126694
# Unit test for function represent_unicode
def test_represent_unicode():
    # We only test the output of the function and not the inner logic
    str_0 = '\x94=\x0eFk\xbc\xe7\xb6\x7f?\x8e\x86\x86\x1f\xc4\xa4\xa4\x9d\xfa\x88\x04\x03,\x18\t\xe2<\xd4\x85\x9e\xee\xdb\x98\xfe\x91\xd7\xfe\xe9\xfa\xa0\xdf\xe0@\x1f\x03\xa0='
    str_1 = '\x1f\x03\xa0='

# Generated at 2022-06-25 04:37:51.410860
# Unit test for function represent_unicode
def test_represent_unicode():
    str_0 = 'nK&e'
    str_1 = '%(dict_0)s is not a valid attr for a %(dict_1)s'
    float_0 = -1773.0
    str_2 = 'application/json';
    str_3 = 'extra/bar'
    str_4 = '!\x1d\x1f\x13^\x0c\xeb\xef'
    str_5 = 'processes'
    int_0 = None
    ansible_dumper_0 = AnsibleDumper(float_0, int_0)
    tuple_0 = (str_0, str_1, ansible_dumper_0, str_2, str_3)

# Generated at 2022-06-25 04:38:00.965076
# Unit test for function represent_unicode
def test_represent_unicode():
    str_0 = 'ZGKk\\'
    str_1 = 'Unknown or undocumentable plugin type: %s'
    float_0 = 2072.37178
    str_2 = 'z'
    dict_0 = {str_1: str_2, str_2: str_0}
    bool_0 = True
    int_0 = None
    ansible_dumper_0 = AnsibleDumper(bool_0, int_0)
    tuple_0 = (dict_0, dict_0, ansible_dumper_0, str_2)
    str_3 = 'processor_nproc'
    ansible_undefined_0 = module_1.AnsibleUndefined(dict_0)

# Generated at 2022-06-25 04:38:08.597416
# Unit test for function represent_unicode
def test_represent_unicode():
    str_0 = '\x84\xd7\xcf\x0b\xa9\xb7\x9e\x8b'
    list_0 = [str_0, str_0, str_0, str_0, str_0, str_0]
    tuple_0 = (list_0, list_0)
    tuple_1 = [tuple_0]
    set_0 = {tuple_1}
    dict_0 = {str_0: tuple_0, str_0: set_0, str_0: tuple_0}
    float_0 = 18.81352
    dict_1 = {"1\t\xa8\xbd\xd6l": dict_0, str_0: float_0, str_0: float_0, str_0: set_0}
    var_

# Generated at 2022-06-25 04:38:16.309980
# Unit test for function represent_unicode
def test_represent_unicode():
    str_0 = '\n'
    bytes_0 = b'\x1f\x19\x86\x0c\x06\x80\xf6\x85\xe1\x871\x9c1\xaf\xda\x8e\\\x18\xef\xc7)o\x91'
    int_0 = 1010
    float_0 = -847.0
    dict_0 = {int_0: float_0}
    bytes_1 = b'\x1f\x19\x86\x0c\x06\x80\xf6\x85\xe1\x871\x9c1\xaf\xda\x8e\\\x18\xef\xc7)o\x91'
    bool_0 = False
    set_0

# Generated at 2022-06-25 04:38:23.953306
# Unit test for function represent_unicode
def test_represent_unicode():
    ansible_unicode_0 = module_1.AnsibleUnicode()
    str_0 = '\x1d\x1f\x8f\x03\xbc\x1b\x04\xe8\xcd'
    str_1 = 't'
    str_2 = '|'
    ansible_dumper_0 = AnsibleDumper()
    bytes_0 = b'\xc7\xfa\x0f+\x03\xe6\xfc\xe1'
    bytes_1 = b'\xbc\xb3\xbc\x83\x0f+\x03\xe6'
    float_0 = 2746.7
    float_1 = 3
    var_0 = represent_unicode(float_0)
    int_0 = None
    int_

# Generated at 2022-06-25 04:38:31.633889
# Unit test for function represent_unicode
def test_represent_unicode():
    str_0 = 'dcf'
    str_1 = 'debug'
    str_2 = "local"
    str_3 = "no"
    int_0 = 599
    str_4 = "xw\xc2\x81"
    tuple_0 = (str_0, str_2, str_3, str_1)
    tuple_1 = (str_1, str_4, str_4)
    bytes_0 = b'*\x8e^<\xad\x00\xa3\x9e\x97\xd7\xb5\x0c\x0e\x11\xee\xbc\xcd\xa5\x9a\x1b\xfc\x7f\x8a\xf7\xdc\xda\x08\x87'
   

# Generated at 2022-06-25 04:38:39.367457
# Unit test for function represent_unicode
def test_represent_unicode():
    str_0 = 'ZGKk\\'
    str_1 = 'Unknown or undocumentable plugin type: %s'
    float_0 = 2072.37178
    str_2 = 'z'
    dict_0 = {str_1: str_2, str_2: str_0}
    bool_0 = True
    int_0 = None
    ansible_dumper_0 = AnsibleDumper(bool_0, int_0)
    tuple_0 = (dict_0, dict_0, ansible_dumper_0, str_2)
    str_3 = 'processor_nproc'
    ansible_undefined_0 = module_1.AnsibleUndefined(dict_0)

# Generated at 2022-06-25 04:38:48.341637
# Unit test for function represent_unicode
def test_represent_unicode():
    str_0 = 'pkzZ\x15'
    str_1 = '\x1c\x83>|\x9b\x0f\xda\xd2\x11\xf8\xc1\x07\x9d\x9f\xdc\x99\xd5\xe2Q'
    ansible_dumper_0 = AnsibleDumper(str_0, str_1)
    str_2 = 'ZGKk\\'
    str_3 = 'Unknown or undocumentable plugin type: %s'
    ansible_unicode_0 = AnsibleUnicode(str_0, str_1)
    var_0 = represent_unicode(ansible_unicode_0, str_3, str_2)


# Generated at 2022-06-25 04:38:51.205875
# Unit test for function represent_unicode
def test_represent_unicode():
    str_0 = 'mf[gh'
    str_1 = '"\\'



# Generated at 2022-06-25 04:39:13.543286
# Unit test for function represent_unicode

# Generated at 2022-06-25 04:39:24.365971
# Unit test for function represent_unicode
def test_represent_unicode():
    string_0 = 'K('
    string_1 = 'inventory_hostname'
    ansible_unicode_0 = module_1.AnsibleUnicode(string_1)
    string_2 = 'K('
    string_3 = 'K('
    string_4 = 'K('
    list_0 = [string_0, string_1, ansible_unicode_0, string_2, string_3, string_4]
    string_5 = 'inventory_hostname'
    ansible_unicode_1 = module_1.AnsibleUnicode(string_5)
    string_6 = 'K('
    string_7 = 'K('
    string_8 = 'K('

# Generated at 2022-06-25 04:39:32.860514
# Unit test for function represent_unicode
def test_represent_unicode():
    str_0 = '@\xc3\x9b2'
    dict_0 = {}
    dict_yaml_0 = dict_0
    dict_0 = {'a': 'value'}
    dict_0 = {}
    dict_yaml_1 = dict_0
    dict_0 = {'a': 'value'}
    dict_0 = {}
    dict_yaml_2 = dict_0
    dict_0 = {'a': 'value'}
    dict_0 = {}
    dict_yaml_3 = dict_0
    dict_0 = {'a': 'value'}
    dict_0 = {}
    dict_yaml_4 = dict_0
    dict_0 = {'a': 'value'}


# Generated at 2022-06-25 04:39:39.654780
# Unit test for function represent_unicode
def test_represent_unicode():
    str_0 = '`@'
    str_1 = 'g'
    float_0 = 412.769
    float_1 = 668.66408
    bytes_0 = b'\x1b\x9b'
    dict_0 = {str_0: str_1, str_1: float_1}
    bool_0 = True
    int_0 = None
    ansible_dumper_0 = AnsibleDumper(bool_0, int_0)
    tuple_0 = (dict_0, float_1, float_0, float_0)
    str_2 = 'hosts'
    str_3 = 'hosts'
    ansible_undefined_0 = module_1.AnsibleUndefined(dict_0)

# Generated at 2022-06-25 04:39:49.366100
# Unit test for function represent_unicode
def test_represent_unicode():
    str_0 = 'ssid'
    list_0 = []
    int_0 = None
    ansible_dumper_0 = AnsibleDumper(list_0, int_0)
    dict_0 = {str_0: str_0}
    unicode_0 = module_2.AnsibleUnicode(dict_0)
    var_0 = represent_unicode(unicode_0)
    str_1 = 'Z'
    tuple_0 = (str_0, str_1)
    str_2 = '\x1e\xfa\xf2\xae\xfe\r\x16\x0b\x1b\xaf\xa3\x00}'
    dict_1 = {str_2: tuple_0}
    unicode_1 = module_2.Ansible

# Generated at 2022-06-25 04:39:58.833868
# Unit test for function represent_unicode
def test_represent_unicode():
    str_0 = 's\xfc\xe4'
    ansible_unsafe_text_0 = AnsibleUnsafeText(str_0)
    var_0 = represent_unicode(ansible_unsafe_text_0)
    str_1 = '\\'
    str_2 = '\\'
    str_3 = '\\'
    tuple_0 = (str_3, str_3, str_2, str_1)
    ansible_sequence_0 = AnsibleSequence(tuple_0)
    str_4 = '_'
    str_5 = '_'
    str_6 = '_'
    tuple_1 = (str_6, str_5, str_5, str_4)
    ansible_sequence_1 = AnsibleSequence(tuple_1)
    str_

# Generated at 2022-06-25 04:40:05.356573
# Unit test for function represent_unicode
def test_represent_unicode():
    str_0 = 'z_\x03'
    str_1 = 'z'
    dict_0 = {str_1: str_0}
    int_0 = None
    ansible_dumper_0 = AnsibleDumper(True, int_0)
    tuple_0 = (dict_0, dict_0, ansible_dumper_0, str_1)
    str_2 = 'dTjz'
    ansible_undefined_0 = module_1.AnsibleUndefined(dict_0)
    dict_1 = {str_2: ansible_undefined_0}
    var_0 = ansible_dumper_0.represent_data(dict_1)
    float_0 = -1486.3082

# Generated at 2022-06-25 04:40:14.461901
# Unit test for function represent_unicode
def test_represent_unicode():
    str_0 = 'ZGKk\\'
    str_1 = 'Unknown or undocumentable plugin type: %s'
    str_2 = 'z'
    dict_0 = {str_1: str_2, str_2: str_0}
    bool_0 = True
    int_0 = None
    ansible_dumper_0 = AnsibleDumper(bool_0, int_0)
    tuple_0 = (dict_0, dict_0, ansible_dumper_0, str_2)
    str_3 = 'processor_nproc'
    ansible_undefined_0 = module_1.AnsibleUndefined(dict_0)
    dict_1 = {str_3: bool_0, str_0: ansible_undefined_0}
    var_0 = ansible_d

# Generated at 2022-06-25 04:40:18.555004
# Unit test for function represent_unicode
def test_represent_unicode():
    str_0 = 'Q'
    str_1 = '~\x1a\x99\t\x1d\x14\x06\x0b\x94\xca\xad\xf0\xea\xa9\x97\x91'
    str_2 = '\x97s<\xdc\x16\x83\x9a\x94\x0f\x87\x94\x10\xba\xd3\xcc\t\xa0\xfd\xd1\x93\x83\x17\x0b'
    set_0 = {str_1, str_0, str_0, str_2}
    list_0 = []
    list_1 = []
    dict_0 = {str_0: list_0}

# Generated at 2022-06-25 04:40:24.332905
# Unit test for function represent_unicode
def test_represent_unicode():
    var_0 = ansible_dumper_0.represent_data(dict_1)
    var_1 = represent_unicode(var_0)
    str_0 = 'ZGKk\\'
    str_1 = 'Unknown or undocumentable plugin type: %s'
    float_0 = 2072.37178
    str_2 = 'z'
    dict_0 = {str_1: str_2, str_2: str_0}
    bool_0 = True
    int_0 = None
    ansible_dumper_0 = AnsibleDumper(bool_0, int_0)
    tuple_0 = (dict_0, dict_0, ansible_dumper_0, str_2)
    str_3 = 'processor_nproc'
    ansible_undefined_0 = module_1