

# Generated at 2022-06-25 04:32:02.948333
# Unit test for function represent_hostvars
def test_represent_hostvars():
    obj_0 = HostVars()
    var_0 = represent_hostvars(obj_0)

# Generated at 2022-06-25 04:32:08.605202
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = 'var_0.1'

    # Test with a valid parameter
    # Expected result: The value returned by represent_dict(dict(data))
    test_func = represent_hostvars(AnsibleDumper, data)
    assert test_func == represent_dict(dict(data))

    # Test with a invalid parameter
    # Expected result: The value returned by represent_dict(dict(data))
    test_func = represent_hostvars(AnsibleDumper, 'abc')
    assert test_func == represent_dict(dict(data))


# Generated at 2022-06-25 04:32:09.827780
# Unit test for function represent_binary
def test_represent_binary():
    string = 'Aoede'
    expected = "Aoede"
    actual = represent_binary(string)
    assert actual == expected

# Generated at 2022-06-25 04:32:12.996456
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    str_0 = 'Rkt])"0jD~LZPGy'
    var_0 = represent_vault_encrypted_unicode(str_0)
    assert var_0 == '``!vault``'


# Generated at 2022-06-25 04:32:19.664289
# Unit test for function represent_hostvars
def test_represent_hostvars():

    data = {u'ansible_distribution_version': u'14.10', u'python_version': u'2.7.6', u'ansible_machine_id': u'/etc/machine-id', u'ansible_distribution': u'Ubuntu', u'ansible_user_dir': u'/home/default/.ansible'}

    ansible_module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=False
    )

    return_value = represent_hostvars(ansible_module, data)


# Generated at 2022-06-25 04:32:21.201401
# Unit test for function represent_hostvars
def test_represent_hostvars():
    for i in range(4):
        print(i)
        # Test code here


# Generated at 2022-06-25 04:32:24.290957
# Unit test for function represent_binary
def test_represent_binary():
    obj = AnsibleUnsafeBytes('otkW8VuI6wc^7VvU')
    exp = yaml.representer.SafeRepresenter.represent_binary(obj)
    assert exp == "otkW8VuI6wc^7VvU"



# Generated at 2022-06-25 04:32:27.260203
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    str_0 = 'Rkt])"0jD~LZPGy'
    var_0 = represent_vault_encrypted_unicode(str_0)


# Generated at 2022-06-25 04:32:37.109845
# Unit test for function represent_hostvars
def test_represent_hostvars():
    var_1 = AnsibleDumper()
    var_2 = {
        'hostvars': {
            'var_3': 'var_3_value',
            'var_4': 'var_4_value',
            'var_4_value': 'var_4_value',
            'var_5': 'var_5_value',
            'var_6': 'var_6_value',
            'var_7': 'var_7_value',
        },
    }
    var_8 = represent_hostvars(var_1, var_2)

# Generated at 2022-06-25 04:32:39.843855
# Unit test for function represent_binary
def test_represent_binary():
    str_0 = b'Rkt])"0jD~LZPGy'
    var_0 = represent_binary(str_0)


# Generated at 2022-06-25 04:32:48.561217
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hv = HostVars()
    hv._host = 'testhost'
    hv.update({'foo': 'bar'})
    s = yaml.dump({'el': hv}, Dumper=AnsibleDumper)
    expected = r'''{el: "{'foo': 'bar'}"}
'''
    assert s == expected


# Generated at 2022-06-25 04:32:53.856740
# Unit test for function represent_unicode
def test_represent_unicode():
    str_0 = 'otkW8VuI6wc^7VvU'
    str_1 = 'qoEgvzsWw8@cYJh1'
    str_2 = 'B6z0U6kLg6z1U6kL'

    # Test type of _ansible_vault
    assert(isinstance(str_0, binary_type))



# Generated at 2022-06-25 04:33:02.558073
# Unit test for function represent_undefined
def test_represent_undefined():
    str_0 = 'otkW8VuI6wc^7VvU'
    str_1 = 'Sf2xMJ90mI'
    str_2 = '4k^GA'
    str_3 = '{'
    str_4 = 'd5^5QL2+NU'
    str_5 = 'X'
    str_6 = '%u3'
    str_7 = '_'
    str_8 = 'B?+C9xd}Q'
    ansible_dumper_0 = ansible.template.Jinja2TemplateModule.environment
    ansible_undefined_0 = ansible.template.Jinja2TemplateModule.UNDEFINED
    ansible_undefined_1 = ansible.template.Jinja2TemplateModule.UNDEFINED
    ans

# Generated at 2022-06-25 04:33:05.088934
# Unit test for function represent_unicode
def test_represent_unicode():
    str_0 = '2GZM1^'
    str_1 = 'Ypx%c'
    assert str_0 == str_1


# Generated at 2022-06-25 04:33:09.421122
# Unit test for function represent_undefined
def test_represent_undefined():
    str_0 = 'otkW8VuI6wc^7VvU'
    str_1 = ''

    assert AnsibleDumper.represent_undefined(str_0) == str_1

if __name__ == '__main__':
    test_case_0()

    test_represent_undefined()

# Generated at 2022-06-25 04:33:11.132350
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    str_0 = 'otkW8VuI6wc^7VvU'
    assert str_0 == represent_vault_encrypted_unicode((AnsibleVaultEncryptedUnicode(str_0)))



# Generated at 2022-06-25 04:33:21.734930
# Unit test for function represent_undefined
def test_represent_undefined():
    # Test for case 0
    str_0 = 'otkW8VuI6wc^7VvU'
    # Test for case 1
    str_1 = 'U6wc^otkW8V'
    # Test for case 2
    str_2 = 'V7VuI'
    # Test for case 3
    str_3 = '^otkW8V'
    # Test for case 4
    str_4 = 'I6wc^7VvU'
    # Test for case 5
    str_5 = '^otkW8V'
    # Test for case 6
    str_6 = 'I6wc^7VvU'
    # Test for case 7
    str_7 = '^otkW8V'
    # Test for case 8

# Generated at 2022-06-25 04:33:29.415578
# Unit test for function represent_undefined
def test_represent_undefined():
    str_1 = 'IJFtRe[0@C;*e'
    str_2 = '0^&Nh58<@N!N'
    str_2 = 'tT$>F;rzpL{'
    str_1 = 'u^%4hB!o#=M!x'
    str_0 = 'b7f{1QXR`F>`1'
    str_2 = '5nH{zrgUP3$!'
    str_0 = 'X7V&'
    str_0 = 'yO<N'
    str_0 = 'ry7F{Z$XGZF('
    str_1 = 'Fa#}5M"'
    str_0 = '_U6e'
    str_0 = 'g&q3K'
    str_

# Generated at 2022-06-25 04:33:32.193817
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert isinstance(test_case_0(), str)


# Generated at 2022-06-25 04:33:38.921733
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    t_0 = AnsibleVaultEncryptedUnicode(
        AnsibleUnsafeText('otkW8VuI6wc^7VvU')
    )
    str_1 = '!!python/object/apply:ansible.parsing.yaml.objects.AnsibleVaultEncryptedUnicode ['
    str_2 = '!!python/unicode OtkW8VuI6wc^7VvU'
    str_3 = ']'
    str_4 = '{0}{1} {2} {3}'.format(str_1, text_type(str_2), text_type(str_3), text_type(str_4))
    t_1 = set([str_4])
    for str_5 in t_1:
        assert str_5 in str_4
   

# Generated at 2022-06-25 04:33:48.115507
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    yaml_0 = test_case_0()
    yaml_1 = '!'
    yaml_2 = 'vault'
    yaml_3 = '|'
    yaml_4 = 'otkW8VuI6wc^7VvU'
    assert yaml_0 == yaml_1 + yaml_2 + ' ' + yaml_3 + ' ' + yaml_4

if __name__ == "__main__":
    test_represent_vault_encrypted_unicode()

# Generated at 2022-06-25 04:33:53.496296
# Unit test for function represent_binary
def test_represent_binary():
    o = yaml.representer.SafeRepresenter()
    try:
        yaml.representer.SafeRepresenter.represent_binary(o, str_0)
    except TypeError as e:
        assert "SafeRepresenter can only represent" in str(e)



# Generated at 2022-06-25 04:34:00.652413
# Unit test for function represent_undefined
def test_represent_undefined():
    u = OppositeSide('X')
    represent_undefined(u)
    assertEqual(u.val, 1)
    u = OppositeSide('2')
    represent_undefined(u)
    assertEqual(u.val, -1)
    u = OppositeSide('2.0')
    represent_undefined(u)
    assertEqual(u.val, -1)
    u = OppositeSide('foo')
    represent_undefined(u)
    assertEqual(u.val, -1)
    u = OppositeSide('foo')
    represent_undefined(u)
    assertEqual(u.val, -1)




# Generated at 2022-06-25 04:34:03.688221
# Unit test for function represent_hostvars
def test_represent_hostvars():
    expected = True
    actual = test_case_0()
    assert expected == actual



# Generated at 2022-06-25 04:34:12.901492
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    str_0 = 'otkW8VuI6wc^7VvU'
    str_1 = 'Hello world!'
    str_2 = '!'
    str_3 = '$ANY$'
    str_4 = '$ANSIBLE_VAULT;1.1;AES256'
    obj = AnsibleVaultEncryptedUnicode(str_4)
    obj._ciphertext = str_3
    obj._vault_password = str_2
    dumper = AnsibleDumper
    dumper.add_representer(
        AnsibleVaultEncryptedUnicode,
        represent_vault_encrypted_unicode,
    )
    str_5 = obj._ciphertext.decode()

# Generated at 2022-06-25 04:34:16.679561
# Unit test for function represent_binary
def test_represent_binary():
    str_0 = 'otkW8VuI6wc^7VvU'
    AnsibleDumper.add_representer(
        AnsibleUnsafeBytes,
        represent_binary,
    )
    assert  str_0  == 'otkW8VuI6wc^7VvU'



# Generated at 2022-06-25 04:34:21.082341
# Unit test for function represent_binary
def test_represent_binary():
    o = yaml.representer.SafeRepresenter()
    try:
        yaml.representer.SafeRepresenter.represent_binary(o, b'G\xceA\x08\xce\xfa\x85\xa8\xc8\xdf\x85\xfe \t\xa9\x8e')
    except RuntimeError as e:
        if text_type(e) != 'cannot represent an object: <_io.BufferedRandom name=30>':
            raise Exception('Unexpected error raised when calling represent_binary: ' + text_type(e))


# Generated at 2022-06-25 04:34:27.798699
# Unit test for function represent_binary
def test_represent_binary():
    from ansible.module_utils.six import text_type
    # Make sure it is not a string
    str_0 = text_type('')
    # Make sure it is not a bool
    bool_0 = bool(0)
    # Test the default branch
    # Test the branch that sets data to text_type
    # Test the branch that sets data to str_0
    # Test the branch that sets data to bool_0
    # Test the branch that calls yaml.representer.SafeRepresenter.represent_str
    # Test the branch that calls represent_scalar
    pass



# Generated at 2022-06-25 04:34:31.443492
# Unit test for function represent_binary
def test_represent_binary():
    s = b'foobar'
    data = yaml.safe_dump(s, default_style='|', default_flow_style=False)
    assert data == '|-\n  foobar\n'


# Generated at 2022-06-25 04:34:32.574274
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert represent_hostvars('self', 'data') == None


# Generated at 2022-06-25 04:34:40.600536
# Unit test for function represent_undefined
def test_represent_undefined():
    test_str = 'YvZcn*R!hF0x(JeW'
    result = dumper.represent_undefined(test_str)
    assert result == 'JsuM$s*B@H8s#Cd0'


# Generated at 2022-06-25 04:34:41.367712
# Unit test for function represent_hostvars
def test_represent_hostvars():
    pass


# Generated at 2022-06-25 04:34:43.118717
# Unit test for function represent_unicode
def test_represent_unicode():
    assert AnsibleDumper().represent_unicode(1) == '1'


# Generated at 2022-06-25 04:34:50.033669
# Unit test for function represent_unicode
def test_represent_unicode():

    str_0 = 'otkW8VuI6wc^7VvU'

    # Test with a str
    repr(AnsibleDumper.represent_unicode(str_0))

    #Test with a unicode
    repr(AnsibleDumper.represent_unicode(text_type(str_0)))


# Generated at 2022-06-25 04:35:00.703949
# Unit test for function represent_hostvars
def test_represent_hostvars():
    str_0 = 'z9D)Wy'
    str_0 = '{' + str_0 + '}'
    str_1 = 'j'
    str_0 = str_0 + str_1
    str_1 = 'J'
    str_0 = str_0 + str_1
    str_1 = 'J'
    str_0 = str_0 + str_1
    str_1 = 'q'
    str_0 = str_0 + str_1
    str_1 = '@'
    str_0 = str_0 + str_1
    str_1 = '@'
    str_0 = str_0 + str_1
    str_1 = 'F'
    str_0 = str_0 + str_1
    str_1 = 'J'

# Generated at 2022-06-25 04:35:08.542708
# Unit test for function represent_hostvars
def test_represent_hostvars():
    num_0 = AnsibleUnicode ('nNgV7F^rSPFMuY7p')
    dict_0 = dict(num_0)
    str_0 = 'DjKPh$SQ^t0Z9t^g'
    num_1 = AnsibleSequence (dict_0)
    dict_1 = dict(num_1)
    dict_2 = dict(key=num_0, num_1=dict_1)
    dict_3 = dict(key=dict_2)
    num_2 = AnsibleSequence (dict_3)
    dict_4 = dict(num_2)


# Generated at 2022-06-25 04:35:09.848945
# Unit test for function represent_undefined
def test_represent_undefined():
    str_0 = 'otkW8VuI6wc^7VvU'


# Generated at 2022-06-25 04:35:10.807951
# Unit test for function represent_undefined
def test_represent_undefined():
    str_0 = 'otkW8VuI6wc^7VvU'



# Generated at 2022-06-25 04:35:18.003324
# Unit test for function represent_unicode
def test_represent_unicode():
    from ansible.parsing.yaml.dumper import represent_unicode
    dumper = AnsibleDumper
    data = 'otkW8VuI6wc^7VvY'

    assert represent_unicode(dumper, data) == yaml.representer.SafeRepresenter.represent_str(dumper, text_type(data))


# Generated at 2022-06-25 04:35:24.336155
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from copy import deepcopy
    str_0 = 'vaiM5bEe1^'
    str_1 = 'h4P'
    str_2 = 'bW9kdWxlLnN5cw=='
    dict_0 = dict()
    dict_0['B'] = str_0
    dict_0['@'] = str_1
    dict_0['4'] = str_2
    dict_1 = dict()
    dict_1['B'] = str_0
    dict_1['@'] = str_1
    dict_1['4'] = str_2
    dict_2 = dict()
    dict_2['B'] = str_0
    dict_2['@'] = str_1
    dict_2['4'] = str_2
    dict_2['hostvars']

# Generated at 2022-06-25 04:35:31.536800
# Unit test for function represent_undefined
def test_represent_undefined():
    t = AnsibleUndefined()
    # A representation of the data must be returned, not the data itself.
    assert yaml.dump(t, Dumper=AnsibleDumper) == ''

dump = lambda data, **kwargs: yaml.dump(data, Dumper=AnsibleDumper, **kwargs)

# Generated at 2022-06-25 04:35:32.753712
# Unit test for function represent_binary
def test_represent_binary():
    s = b'test'
    result = yaml.dump(s, Dumper=AnsibleDumper)
    assert result == "!!binary |\n  dGVzdA==\n"

# Generated at 2022-06-25 04:35:43.251569
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-25 04:35:47.923882
# Unit test for function represent_hostvars
def test_represent_hostvars():
    import datetime
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    class TestAnsibleDumper(unittest.TestCase):

        def setUp(self):
            self.maxDiff = None
            self.my_hostvars = HostVars()

# Generated at 2022-06-25 04:35:52.334679
# Unit test for function represent_unicode
def test_represent_unicode():
    data = {
        'foo': AnsibleUnicode(u'bar'),
        'baz': AnsibleUnicode(u'moo'),
        }

    data1 = {
        'foo': u'bar',
        'baz': u'moo',
        }

    assert yaml.dump(data, Dumper=AnsibleDumper) == yaml.dump(data1, Dumper=yaml.Dumper)



# Generated at 2022-06-25 04:35:55.680632
# Unit test for function represent_unicode
def test_represent_unicode():
    data = yaml.load(yaml.dump(["content", ("content",)], Dumper=AnsibleDumper))
    assert "content" == data[0]
    assert ("content", ) == data[1]


# Generated at 2022-06-25 04:35:56.701682
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.load(yaml.dump(u'test')) == u'test'

# Generated at 2022-06-25 04:36:02.456466
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-25 04:36:09.780921
# Unit test for function represent_binary
def test_represent_binary():
    # bytes and bytearray are alias to each other in Python 3
    # https://github.com/python/cpython/blob/3.7/Lib/types.py
    # but we want to treat them separately.
    # If we can't, we can remove bytearray from this test
    for obj in [
        b'\x7f',
        bytearray(b'\x7f'),
    ]:
        dumper = AnsibleDumper()
        dumper.represent_binary(obj)

# Generated at 2022-06-25 04:36:20.426610
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()

# Generated at 2022-06-25 04:36:30.876488
# Unit test for function represent_binary
def test_represent_binary():
    # Note: need to mock the return type because of the
    # way the yaml library works
    mock_binary_type = yaml.representer.SafeRepresenter.represent_binary(None,
                                                                        None)
    assert mock_binary_type == yaml.MappingNode('tag:yaml.org,2002:binary',
                                                {},
                                                flow_style=False)

# Generated at 2022-06-25 04:36:42.160397
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dump_data = yaml.dump(
        AnsibleVaultEncryptedUnicode("foo"),
        Dumper=AnsibleDumper)

# Generated at 2022-06-25 04:36:47.008405
# Unit test for function represent_binary
def test_represent_binary():
    d = AnsibleDumper()
    r = d.represent_binary("\x00\x01\x02\x03")
    assert r == "!!binary |\n  AAECAw==\n", \
        "Represented binary string not as expected: %s" % r

# Generated at 2022-06-25 04:36:49.732358
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    output = dumper.represent_unicode(u'abc')
    assert output == "abc"



# Generated at 2022-06-25 04:36:54.584243
# Unit test for function represent_undefined
def test_represent_undefined():
    result = yaml.dump(AnsibleUndefined()).strip()
    assert result == 'null'

# Generated at 2022-06-25 04:36:57.292178
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    result = dumper.represent_undefined(dumper, AnsibleUndefined)
    assert False is result

# Generated at 2022-06-25 04:37:05.442556
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import get_file_vault_secret
    from ansible.parsing.vault import get_vault_secrets

    vault_pass = get_file_vault_secret(['tests/vault/test_vault.txt'])

# Generated at 2022-06-25 04:37:08.615279
# Unit test for function represent_binary
def test_represent_binary():
    data = b'A binary string'
    assert yaml.safe_dump(data, Dumper=AnsibleDumper) == "!!binary |\n  QSBiaW5hcnkgc3RyaW5n\n"



# Generated at 2022-06-25 04:37:15.395054
# Unit test for function represent_binary
def test_represent_binary():
    # Produces quoted output if not using represent_binary
    assert AnsibleDumper().represent_binary(b'\x1f\x8b\x08') == u'!binary |\n  H4sICAAAAA==\n'

# Generated at 2022-06-25 04:37:19.411716
# Unit test for function represent_binary
def test_represent_binary():
    assert list(yaml.safe_dump("foo", Dumper=AnsibleDumper)) == [b'foo\n']
    assert list(yaml.safe_dump(b"foo", Dumper=AnsibleDumper)) == [b"foo\n"]
    assert list(yaml.safe_dump(u"foo", Dumper=AnsibleDumper)) == [b"foo\n"]

# Generated at 2022-06-25 04:37:43.133193
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from six import PY3
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    if PY3:
        from io import StringIO
    else:
        from io import BytesIO as StringIO

    hv = HostVars(None)
    hv['a'] = 1
    hv['b'] = {'b1': 'b1', 'b2': 'b2'}
    hv['c'] = 'test'

    hvv = HostVarsVars(hv)
    hvv['a'] = 1
    hvv['b'] = {'b1': 'b1', 'b2': 'b2'}
    hvv['c'] = 'test'

    output = StringIO()

# Generated at 2022-06-25 04:37:50.187973
# Unit test for function represent_undefined
def test_represent_undefined():
    ansible_dumper = AnsibleDumper()
    from ansible.template import Undefined

    # passing undefined
    print(ansible_dumper.represent_data(Undefined()))
    #bool(Undefined) is True
    #print(bool(Undefined()))
    #Test for _fail_with_undefined_error
    #print(Undefined()._fail_with_undefined_error(msg="Test"))

    # passing value other than undefined
    print(ansible_dumper.represent_data(1))

# Generated at 2022-06-25 04:38:00.833189
# Unit test for function represent_hostvars
def test_represent_hostvars():
    """This is a representation for the hostvars, this way we don't produce the
    '!!python/object/apply:ansible.vars.hostvars.HostVarsVars'
    """

# Generated at 2022-06-25 04:38:03.847896
# Unit test for function represent_unicode
def test_represent_unicode():
    data = "some\nmultiline"
    result = yaml.dump(data, Dumper=AnsibleDumper)
    assert result == "some multiline\n..."



# Generated at 2022-06-25 04:38:07.230602
# Unit test for function represent_hostvars
def test_represent_hostvars():
    '''
    The method must return a valid scalar node
    '''
    obj = {}
    d = AnsibleDumper(None, None, None)
    result = represent_hostvars(d, obj)
    assert result.tag == u'tag:yaml.org,2002:map'
    assert result.style == ''



# Generated at 2022-06-25 04:38:09.711800
# Unit test for function represent_undefined
def test_represent_undefined():

    assert represent_undefined(None, AnsibleUndefined()) is True
    assert represent_undefined(None, AnsibleUndefined(error_msg='TEST')) is True

# Generated at 2022-06-25 04:38:14.502856
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    vars_with_sources = VarsWithSources()
    vars_with_sources['foo'] = 'bar'
    vars_with_sources['baz'] = 'qux'
    v = dumper.represent_data(vars_with_sources)
    assert v == "foo: bar\nbaz: qux\n"

# Generated at 2022-06-25 04:38:23.542205
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Test normal behavior
    dumper = yaml.SafeDumper
    yaml.SafeDumper.add_representer(
        AnsibleVaultEncryptedUnicode,
        represent_vault_encrypted_unicode,
    )
    out = yaml.dump({"foo": AnsibleVaultEncryptedUnicode("bar")}, default_flow_style=False, Dumper=dumper)

# Generated at 2022-06-25 04:38:31.404067
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import template
    from ansible.template.safe_eval import safe_eval
    from ansible.module_utils.six import StringIO
    from ansible.template import generate_ansible_template_vars
    datastructure = dict(
        stdout=generate_ansible_template_vars(),
        stderr=generate_ansible_template_vars(),
    )
    safe_eval(
        u'ansible_all_ipv4_address_bonds',
        variables=datastructure['stdout'],
        locals={},
    )
    assert bool(datastructure['stdout']['ansible_all_ipv4_address_bonds']) is False
    buf = StringIO()

# Generated at 2022-06-25 04:38:38.197565
# Unit test for function represent_undefined
def test_represent_undefined():
    # AnsibleUndefined doesn't have repr, __repr__, __str__
    # But it does set __bool__.
    # Hence, we need to call bool on it.
    yaml.dump({1: 2}, Dumper=AnsibleDumper)
    yaml.dump({1: AnsibleUndefined()}, Dumper=AnsibleDumper)