

# Generated at 2022-06-25 04:32:07.566359
# Unit test for function represent_unicode
def test_represent_unicode():
    string_0 = 'foo'
    var_0 = represent_unicode(string_0)



# Generated at 2022-06-25 04:32:09.010674
# Unit test for function represent_binary
def test_represent_binary():
    bool_0 = False
    bytes_0 = b'is_a_test'
    var_0 = represent_binary(bool_0, bytes_0)


# Generated at 2022-06-25 04:32:13.316821
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Execute function
    try:
        result = represent_vault_encrypted_unicode()
        # Check for unexpected keyword arguments
        if 'kwargs' in result and not isinstance(result['kwargs'], dict):
            raise Exception('Unexpected keyword arguments')
    except Exception:
        # Check exception type
        e = sys.exc_info()[1]
        if not isinstance(e, TypeError):
            raise Exception('Unexpected exception type "%s"' % (e.__class__))
        # Check number of arguments
        if not 'takes exactly 2 arguments' in str(e):
            raise Exception('Unexpected exception message "%s"' % (e))
        else:
            return

    raise Exception('Expected a TypeError')


# Generated at 2022-06-25 04:32:24.528721
# Unit test for function represent_unicode

# Generated at 2022-06-25 04:32:27.909918
# Unit test for function represent_undefined
def test_represent_undefined():
    # type: () -> None
    """
    Test function for function represent_undefined
    """
    undefined = AnsibleUndefined('Test case')
    result = represent_undefined(undefined)


# Generated at 2022-06-25 04:32:29.574080
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert represent_hostvars(1, 2) == None


# Generated at 2022-06-25 04:32:30.144354
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert True

# Generated at 2022-06-25 04:32:32.068496
# Unit test for function represent_binary
def test_represent_binary():
    # Test function output against known result.
    # Test function output against known result.
    assert callable(represent_binary)



# Generated at 2022-06-25 04:32:41.891224
# Unit test for function represent_unicode
def test_represent_unicode():
    from ansible.module_utils.six import text_type
    from ansible.template import AnsibleUndefined

    bool_0 = False
    int_0 = 0
    float_0 = 0.0
    str_0 = text_type()
    str_1 = text_type("abc")

# Generated at 2022-06-25 04:32:48.626096
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = {
        'foo': 'bar',
        'baz': 'xen',
    }

    r = represent_hostvars({}, data)
    assert 'foo' in r.value
    assert 'baz' in r.value

    r = represent_hostvars(None, data)
    assert 'foo' in r.value
    assert 'baz' in r.value

# Generated at 2022-06-25 04:32:54.130110
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.module_utils.common.yaml import AnsibleDumper
    from ansible.template import Undefined

    dumper = AnsibleDumper()
    undef = Undefined()

    assert bool(dumper.represent_undefined(undef)) is True

# Generated at 2022-06-25 04:32:57.983867
# Unit test for function represent_hostvars
def test_represent_hostvars():
    class Foo:
        def __init__(self, bar):
            self.bar = bar
        def __str__(self):
            return self.bar

    foo = Foo('spam')

    assert represent_hostvars({'foo': foo}) == {'foo': 'spam'}


# Generated at 2022-06-25 04:33:06.861227
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\nblahblahblahblahblahblahblahblahblahblahblahblahblahblahblahblahblah')
    assert(represent_vault_encrypted_unicode(None, data) == '!vault |\n  $ANSIBLE_VAULT;1.1;AES256\n  blahblahblahblahblahblahblahblahblahblahblahblahblahblahblahblahblah\n')



# Generated at 2022-06-25 04:33:12.335771
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    import string
    import random

    def random_crypt_str():
        return ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(10))

    # are we actually encrypting something?
    def test_crypt_str(dumper, data):
        serialized = yaml.dump(data, Dumper=dumper)
        assert type(serialized) == str
        assert len(serialized) > 0
        assert len(serialized.split('\n')) == 1
        assert len(serialized.split(': ')) == 1
        assert serialized.startswith('!vault ')

    def get_dumper():
        return AnsibleDumper()


# Generated at 2022-06-25 04:33:16.048222
# Unit test for function represent_unicode
def test_represent_unicode():
    # for now, just make sure we can call it
    AnsibleDumper.represent_unicode(
        AnsibleDumper,
        AnsibleUnicode('unicode text', 'utf-16'),
    )



# Generated at 2022-06-25 04:33:19.893310
# Unit test for function represent_binary
def test_represent_binary():
    from ansible.parsing.yaml import objects
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes

    data = AnsibleUnsafeBytes('\x13\x14')
    yaml.add_representer(AnsibleUnsafeBytes, represent_binary)
    teststring = yaml.safe_dump(data)
    data2 = yaml.load(teststring)
    assert isinstance(data2, AnsibleUnsafeBytes)
    assert isinstance(data2, objects.AnsibleUnsafeBytes)

    # old test, should be removed when python 2 support is dropped
    data = AnsibleUnsafeText('\x13\x14')
    teststring = yaml.safe_dump(data)

# Generated at 2022-06-25 04:33:24.783550
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars_obj = HostVars(host_name='vm1', groups=dict(), vault_files=dict(), host_vars=dict())
    hostvars_str = yaml.dump([hostvars_obj], Dumper=AnsibleDumper)
    assert hostvars_str == '- ansible_host: vm1\n  groups: {}\n  host_vars: {}\n  vault_files: {}\n'



# Generated at 2022-06-25 04:33:33.874716
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    def check_data(dumper, data):
        node = dumper.represent_data(data)
        assert node.tag == u'!vault'
        assert node.value == data._ciphertext.decode()
        assert node.style == '|'

    dumper = AnsibleDumper()

    data = AnsibleVaultEncryptedUnicode(b'abc')
    check_data(dumper, data)

    data = AnsibleVaultEncryptedUnicode('abc')
    check_data(dumper, data)

    dumper.allow_unicode = False
    data = AnsibleVaultEncryptedUnicode('abc')
    check_data(dumper, data)

    dumper.allow_unicode = True
    data = AnsibleVaultEncryptedUnicode('abc')
    check_data

# Generated at 2022-06-25 04:33:39.769122
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = yaml.SafeDumper()
    dumper.add_representer(AnsibleUndefined, represent_undefined)

    assert dumper.represent_data(AnsibleUndefined()) == dumper.represent_bool(True)
    assert dumper.represent_data(AnsibleUndefined(strict=True)) == dumper.represent_bool(True)
    assert dumper.represent_data(AnsibleUndefined(fail_on_undefined=True)) == dumper.represent_bool(True)
    assert dumper.represent_data(AnsibleUndefined(strict=True, fail_on_undefined=True)) == dumper.represent_bool(True)



# Generated at 2022-06-25 04:33:43.814466
# Unit test for function represent_unicode
def test_represent_unicode():
    data = {
        "ansible_loop_var": "item",
        "ansible_facts": {
          "ansible_os_family": "RedHat",
          "ansible_selinux": {
            "status": "disabled"
          }
        }
    }
    result = yaml.dump(data, Dumper=AnsibleDumper)
    assert isinstance(result, text_type)

# Generated at 2022-06-25 04:33:49.261776
# Unit test for function represent_binary
def test_represent_binary():
    represent_binary(None, b'\x00\xa3\x00')  # Won't raise a TypeError

# Generated at 2022-06-25 04:33:58.345974
# Unit test for function represent_hostvars
def test_represent_hostvars():
    def do_test(data, result):
        assert represent_hostvars(None, data) == (result, None)

    do_test({"a": "alpha"}, "{'a': 'alpha'}")
    do_test({"a": "alpha", "b": "beta"}, "{'a': 'alpha', 'b': 'beta'}")
    do_test({"a": ["alpha", "alpha1"]}, "{'a': ['alpha', 'alpha1']}")
    do_test({"a": {"c": "gamma"}}, "{'a': {'c': 'gamma'}}")

# Generated at 2022-06-25 04:34:03.574279
# Unit test for function represent_unicode
def test_represent_unicode():
    data = AnsibleUnicode(1)
    result = represent_unicode(None, data)
    assert result == u"1"


# Generated at 2022-06-25 04:34:06.189559
# Unit test for function represent_unicode
def test_represent_unicode():
    res = yaml.dump(AnsibleUnicode('foo'))
    assert res == 'foo\n...\n'



# Generated at 2022-06-25 04:34:12.350472
# Unit test for function represent_unicode
def test_represent_unicode():
    data = dict(key1=b'value1', key2=42, key3=dict(key4=u'value4'))
    result = yaml.dump(data, Dumper=AnsibleDumper, allow_unicode=True)
    assert result == '''key1: "value1"
key2: 42
key3: {key4: value4}
'''

# Generated at 2022-06-25 04:34:15.825249
# Unit test for function represent_undefined
def test_represent_undefined():
    for yaml_dumper in [
        yaml.SafeDumper,
        AnsibleDumper,
    ]:
        try:
            # Note: if this doesn't raise an exception, the tests fail
            yaml.dump([AnsibleUndefined()], Dumper=yaml_dumper)
        except Exception:
            pass



# Generated at 2022-06-25 04:34:19.101776
# Unit test for function represent_undefined
def test_represent_undefined():
    data = AnsibleUndefined()

    for Dumper in [yaml.SafeDumper, AnsibleDumper]:
        representation = yaml.dump(data, Dumper=Dumper)
        assert representation == '!!python/object/apply:ansible.template.base.TemplateUndefined []\n'


# Generated at 2022-06-25 04:34:21.916360
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumped = yaml.dump(HostVars({'foo': 'bar'}), Dumper=AnsibleDumper)
    assert dumped == 'foo: bar\n'


# Generated at 2022-06-25 04:34:31.162547
# Unit test for function represent_undefined
def test_represent_undefined():

    payload = '''
        vault:
          var: !vault |
            $ANSIBLE_VAULT;1.1;AES256
            61303437393332306261613061653630393737356339623237663832656239643261396131623362
            6262623230613237636164383063320a633031373533663839316531353132313666613738343636
            3834653930333665646632333862613963346135616566356231343266340a363564626637383662
            33636666346262303538636135613365656233376638336262623739626237623233623731646163
            3931396637303761
    '''

# Generated at 2022-06-25 04:34:38.922340
# Unit test for function represent_binary
def test_represent_binary():
    # make sure we can represent bytes using UTF-8
    dumper = AnsibleDumper()
    data = binary_type(b'\xe5\x8a\xb1\xe6\x9c\x88\xe3\x81\xae\xe6\xbe\x8c\xe5\xb0\x8f\xe6\x97\x85\xe8\xa1\x8c\xe3\x81\xa8\xe7\x9b\x98\xe4\xba\x88\xe3\x80\x82')
    expected = text_type(u'!!binary |\n    5aKH44CL44Gv44Ki44Gr44Kq44Gu44CM44G+44Gf44KL')
    result = dumper.represent_binary(data)


# Generated at 2022-06-25 04:34:48.055445
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    assert represent_vault_encrypted_unicode(AnsibleDumper, AnsibleVaultEncryptedUnicode('foo')) == '!vault |\n          Zm9v'

assert yaml.dump(AnsibleVaultEncryptedUnicode('foo'), Dumper=AnsibleDumper) == '!vault |\n          Zm9v'

# Generated at 2022-06-25 04:34:53.327581
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-25 04:34:57.392696
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper(indent=0, width=80, initial_indent='', subsequent_indent='')
    repr_binary = dumper.represent_binary(b'hello\x00')
    assert repr_binary == "!binary |-\n  aGVsbG8A\n"

# Generated at 2022-06-25 04:35:02.835601
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    value = AnsibleVaultEncryptedUnicode(u'$ANSIBLE_VAULT;1.1;AES256\nblahblahblahblahblahblahblah')
    result = represent_vault_encrypted_unicode(None, value)
    expected_result = {'!vault': 'blahblahblahblahblahblahblah'}
    assert result == expected_result

# Generated at 2022-06-25 04:35:06.051196
# Unit test for function represent_binary
def test_represent_binary():
    data = AnsibleUnsafeBytes('protected data')
    #construction of the object is tested elsewhere
    dumper = AnsibleDumper([])
    #represent_binary uses 'b' prefix
    assert dumper.represent_data(data) == "!!binary 'protected data'\n"

# Generated at 2022-06-25 04:35:07.370759
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.dump({'test': AnsibleUndefined()}, Dumper=AnsibleDumper) == '{test: !!bool False}\n'

# Generated at 2022-06-25 04:35:12.026742
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(u'\u263a', Dumper=AnsibleDumper) == "'☺'\n"


# Generated at 2022-06-25 04:35:19.793722
# Unit test for function represent_binary
def test_represent_binary():
    '''
    Test for AnsibleDumper.represent_binary method
    '''

    # Test data
    data = u'\u0080.code'

    # Call the function under test
    output = AnsibleDumper().represent_binary(data)

    # Assertions
    assert output == u'!!binary |-\n  wqO6LmNvZGU=\n', output

# Generated at 2022-06-25 04:35:22.089198
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    # Using bool will trigger the special case handler in represent_undefined
    assert bool(dumper.represent_data(AnsibleUndefined())) == False


# Generated at 2022-06-25 04:35:29.646850
# Unit test for function represent_binary
def test_represent_binary():
    # String
    assert yaml.dump(b'hi this is a string') == 'hi this is a string\n...\n'

    # Bytes
    assert yaml.dump(b'hi this is a string', default_style='|') == 'hi this is a string\n'
    assert yaml.dump(b'hi this is a string', default_style='|') == 'hi this is a string\n'

# Generated at 2022-06-25 04:35:46.615583
# Unit test for function represent_binary
def test_represent_binary():
    representer = yaml.representer.BaseRepresenter()
    assert representer.represent_binary(binary_type(b'\xff')) == u'!!binary |\n  /w==\n'

# Generated at 2022-06-25 04:35:56.299473
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host  import Host
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.facts.virtual.lspci import FactsVirtualLspciModule
    from ansible.module_utils.facts.system.distribution import FactsSystemDistributionModule
    from ansible.module_utils.facts.system.pkg_mgr import FactsSystemPkgMgrModule
    from ansible.module_utils.facts.network.interfaces import FactsNetworkInterfacesModule

    loader = DataLoader()

    d = dict(a=1, b=2)
    host = Host(name="testhost")
    host.vars = d
    inventory = loader.inventory

    inventory.add_host(host)

# Generated at 2022-06-25 04:36:06.425257
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()

    # Test that ansible.utils.unsafe_proxy.AnsibleUnsafeBytes
    # is represented as a binary type
    assert yaml.representer.SafeRepresenter.represent_binary(dumper, b'\x00\x01\x02') ==\
           yaml.representer.SafeRepresenter.represent_binary(dumper, AnsibleUnsafeBytes(b'\x00\x01\x02'))

    # Test that ansible.utils.unsafe_proxy.AnsibleUnsafeText
    # is represented as a binary type

# Generated at 2022-06-25 04:36:16.772055
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    encrypted_str = vault.encrypt('test')
    vault_unicode = AnsibleVaultEncryptedUnicode(encrypted_str)
    dumped_data = yaml.dump([vault_unicode], Dumper=AnsibleDumper)

# Generated at 2022-06-25 04:36:24.346273
# Unit test for function represent_binary
def test_represent_binary():
    yaml.add_representer(binary_type, represent_binary, Dumper=AnsibleDumper)

    data = b'\xfe\xff\xff\xfe\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    dumped = yaml.dump(data, Dumper=AnsibleDumper)
    assert dumped == '!binary |\n  //+kAA=\n'

# Generated at 2022-06-25 04:36:34.641722
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    encrypted_data = VaultLib([VaultSecret('hunter2')]).encrypt('test')
    vault_encrypted_unicode = AnsibleVaultEncryptedUnicode(value=encrypted_data)


# Generated at 2022-06-25 04:36:41.449398
# Unit test for function represent_hostvars
def test_represent_hostvars():

    dumper = AnsibleDumper(None)

    host1 = HostVars('host1')
    host1_vars = {
        "a": 1,
        "b": "mystring",
        "c": [1, 2, 3],
        "d": {"k1": "v1", "k2": "v2"},
    }
    host1.set_variable('vars', host1_vars)

    s = dumper.represent_hostvars(host1)

    assert s == dumper.represent_dict(host1_vars)

# Generated at 2022-06-25 04:36:46.644759
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = HostVars(dict(a=1, b=2))
    result = yaml.dump(data, Dumper=AnsibleDumper)
    assert result == '{a: 1, b: 2}\n'



# Generated at 2022-06-25 04:36:49.382264
# Unit test for function represent_undefined
def test_represent_undefined():
    rep = AnsibleDumper.represent_undefined(None, AnsibleUndefined)
    assert rep == False



# Generated at 2022-06-25 04:36:51.459547
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    undefined = AnsibleUndefined('message')
    assert dumper.represent_undefined.func(dumper, undefined)